package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.Cache;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.state.WidgetFrame;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  public static final int WRAP_BEHAVIOR_HORIZONTAL_ONLY = 1;
  
  public static final int WRAP_BEHAVIOR_INCLUDED = 0;
  
  public static final int WRAP_BEHAVIOR_SKIPPED = 3;
  
  public static final int WRAP_BEHAVIOR_VERTICAL_ONLY = 2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  public WidgetFrame frame = new WidgetFrame(this);
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean horizontalSolvingPass = false;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  private boolean mAnimated;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  private int mHeightOverride = -1;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtualLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  private int mWidthOverride = -1;
  
  private int mWrapBehaviorInParent = 0;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public String stringId;
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  private boolean verticalSolvingPass = false;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private void getSceneString(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "      size", paramInt1, 0);
    serializeAttribute(paramStringBuilder, "      min", paramInt2, 0);
    serializeAttribute(paramStringBuilder, "      max", paramInt3, 2147483647);
    serializeAttribute(paramStringBuilder, "      matchMin", paramInt5, 0);
    serializeAttribute(paramStringBuilder, "      matchDef", paramInt6, 0);
    serializeAttribute(paramStringBuilder, "      matchPercent", paramFloat1, 1.0F);
    paramStringBuilder.append("    },\n");
  }
  
  private void getSceneString(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("    ");
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("'");
    if (paramConstraintAnchor.mGoneMargin != Integer.MIN_VALUE || paramConstraintAnchor.mMargin != 0) {
      paramStringBuilder.append(",");
      paramStringBuilder.append(paramConstraintAnchor.mMargin);
      if (paramConstraintAnchor.mGoneMargin != Integer.MIN_VALUE) {
        paramStringBuilder.append(",");
        paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
        paramStringBuilder.append(",");
      } 
    } 
    paramStringBuilder.append(" ] ,\n");
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  private void serializeAnchor(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, float paramFloat1, float paramFloat2) {
    if (paramFloat1 == paramFloat2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramFloat1);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramInt1);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeCircle(StringBuilder paramStringBuilder, ConstraintAnchor paramConstraintAnchor, float paramFloat) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("circle : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeDimensionRatio(StringBuilder paramStringBuilder, String paramString, float paramFloat, int paramInt) {
    if (paramFloat == 0.0F)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  [");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramInt);
    paramStringBuilder.append("");
    paramStringBuilder.append("],\n");
  }
  
  private void serializeSize(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "size", paramInt1, -2147483648);
    serializeAttribute(paramStringBuilder, "min", paramInt2, 0);
    serializeAttribute(paramStringBuilder, "max", paramInt3, 2147483647);
    serializeAttribute(paramStringBuilder, "matchMin", paramInt5, 0);
    serializeAttribute(paramStringBuilder, "matchDef", paramInt6, 0);
    serializeAttribute(paramStringBuilder, "matchPercent", paramInt6, 1);
    paramStringBuilder.append("},\n");
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   8: astore #28
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   18: astore #27
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   28: astore #30
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   38: astore #29
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   48: astore #26
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   54: astore #24
    //   56: aload #24
    //   58: ifnull -> 173
    //   61: aload #24
    //   63: ifnull -> 85
    //   66: aload #24
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #11
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   92: astore #24
    //   94: aload #24
    //   96: ifnull -> 118
    //   99: aload #24
    //   101: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: iconst_1
    //   105: aaload
    //   106: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   109: if_acmpne -> 118
    //   112: iconst_1
    //   113: istore #12
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #12
    //   121: aload_0
    //   122: getfield mWrapBehaviorInParent : I
    //   125: istore #4
    //   127: iload #4
    //   129: iconst_1
    //   130: if_icmpeq -> 166
    //   133: iload #4
    //   135: iconst_2
    //   136: if_icmpeq -> 156
    //   139: iload #4
    //   141: iconst_3
    //   142: if_icmpeq -> 173
    //   145: iload #11
    //   147: istore #13
    //   149: iload #12
    //   151: istore #11
    //   153: goto -> 179
    //   156: iload #12
    //   158: istore #11
    //   160: iconst_0
    //   161: istore #13
    //   163: goto -> 179
    //   166: iload #11
    //   168: istore #13
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #13
    //   176: iconst_0
    //   177: istore #11
    //   179: aload_0
    //   180: getfield mVisibility : I
    //   183: bipush #8
    //   185: if_icmpne -> 223
    //   188: aload_0
    //   189: getfield mAnimated : Z
    //   192: ifne -> 223
    //   195: aload_0
    //   196: invokevirtual hasDependencies : ()Z
    //   199: ifne -> 223
    //   202: aload_0
    //   203: getfield mIsInBarrier : [Z
    //   206: astore #24
    //   208: aload #24
    //   210: iconst_0
    //   211: baload
    //   212: ifne -> 223
    //   215: aload #24
    //   217: iconst_1
    //   218: baload
    //   219: ifne -> 223
    //   222: return
    //   223: aload_0
    //   224: getfield resolvedHorizontal : Z
    //   227: istore #12
    //   229: iload #12
    //   231: ifne -> 241
    //   234: aload_0
    //   235: getfield resolvedVertical : Z
    //   238: ifeq -> 489
    //   241: iload #12
    //   243: ifeq -> 339
    //   246: aload_1
    //   247: aload #28
    //   249: aload_0
    //   250: getfield mX : I
    //   253: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   256: aload_1
    //   257: aload #27
    //   259: aload_0
    //   260: getfield mX : I
    //   263: aload_0
    //   264: getfield mWidth : I
    //   267: iadd
    //   268: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   271: iload #13
    //   273: ifeq -> 339
    //   276: aload_0
    //   277: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   280: astore #24
    //   282: aload #24
    //   284: ifnull -> 339
    //   287: aload_0
    //   288: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   291: ifeq -> 322
    //   294: aload #24
    //   296: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   299: astore #24
    //   301: aload #24
    //   303: aload_0
    //   304: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   307: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   310: aload #24
    //   312: aload_0
    //   313: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   316: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   319: goto -> 339
    //   322: aload_1
    //   323: aload_1
    //   324: aload #24
    //   326: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   329: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   332: aload #27
    //   334: iconst_0
    //   335: iconst_5
    //   336: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   339: aload_0
    //   340: getfield resolvedVertical : Z
    //   343: ifeq -> 464
    //   346: aload_1
    //   347: aload #30
    //   349: aload_0
    //   350: getfield mY : I
    //   353: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   356: aload_1
    //   357: aload #29
    //   359: aload_0
    //   360: getfield mY : I
    //   363: aload_0
    //   364: getfield mHeight : I
    //   367: iadd
    //   368: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   371: aload_0
    //   372: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   375: invokevirtual hasDependents : ()Z
    //   378: ifeq -> 396
    //   381: aload_1
    //   382: aload #26
    //   384: aload_0
    //   385: getfield mY : I
    //   388: aload_0
    //   389: getfield mBaselineDistance : I
    //   392: iadd
    //   393: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   396: iload #11
    //   398: ifeq -> 464
    //   401: aload_0
    //   402: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   405: astore #24
    //   407: aload #24
    //   409: ifnull -> 464
    //   412: aload_0
    //   413: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   416: ifeq -> 447
    //   419: aload #24
    //   421: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   424: astore #24
    //   426: aload #24
    //   428: aload_0
    //   429: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   432: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   435: aload #24
    //   437: aload_0
    //   438: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   441: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   444: goto -> 464
    //   447: aload_1
    //   448: aload_1
    //   449: aload #24
    //   451: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   454: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   457: aload #29
    //   459: iconst_0
    //   460: iconst_5
    //   461: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   464: aload_0
    //   465: getfield resolvedHorizontal : Z
    //   468: ifeq -> 489
    //   471: aload_0
    //   472: getfield resolvedVertical : Z
    //   475: ifeq -> 489
    //   478: aload_0
    //   479: iconst_0
    //   480: putfield resolvedHorizontal : Z
    //   483: aload_0
    //   484: iconst_0
    //   485: putfield resolvedVertical : Z
    //   488: return
    //   489: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   492: ifnull -> 512
    //   495: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   498: astore #24
    //   500: aload #24
    //   502: aload #24
    //   504: getfield widgets : J
    //   507: lconst_1
    //   508: ladd
    //   509: putfield widgets : J
    //   512: iload_2
    //   513: ifeq -> 787
    //   516: aload_0
    //   517: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   520: astore #24
    //   522: aload #24
    //   524: ifnull -> 787
    //   527: aload_0
    //   528: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   531: ifnull -> 787
    //   534: aload #24
    //   536: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   539: getfield resolved : Z
    //   542: ifeq -> 787
    //   545: aload_0
    //   546: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   549: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   552: getfield resolved : Z
    //   555: ifeq -> 787
    //   558: aload_0
    //   559: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   562: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   565: getfield resolved : Z
    //   568: ifeq -> 787
    //   571: aload_0
    //   572: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   575: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   578: getfield resolved : Z
    //   581: ifeq -> 787
    //   584: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   587: ifnull -> 607
    //   590: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   593: astore #24
    //   595: aload #24
    //   597: aload #24
    //   599: getfield graphSolved : J
    //   602: lconst_1
    //   603: ladd
    //   604: putfield graphSolved : J
    //   607: aload_1
    //   608: aload #28
    //   610: aload_0
    //   611: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   614: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   617: getfield value : I
    //   620: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   623: aload_1
    //   624: aload #27
    //   626: aload_0
    //   627: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   630: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   633: getfield value : I
    //   636: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   639: aload_1
    //   640: aload #30
    //   642: aload_0
    //   643: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   646: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   649: getfield value : I
    //   652: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   655: aload_1
    //   656: aload #29
    //   658: aload_0
    //   659: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   662: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   665: getfield value : I
    //   668: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   671: aload_1
    //   672: aload #26
    //   674: aload_0
    //   675: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   678: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   681: getfield value : I
    //   684: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   687: aload_0
    //   688: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   691: ifnull -> 776
    //   694: iload #13
    //   696: ifeq -> 735
    //   699: aload_0
    //   700: getfield isTerminalWidget : [Z
    //   703: iconst_0
    //   704: baload
    //   705: ifeq -> 735
    //   708: aload_0
    //   709: invokevirtual isInHorizontalChain : ()Z
    //   712: ifne -> 735
    //   715: aload_1
    //   716: aload_1
    //   717: aload_0
    //   718: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   721: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   724: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   727: aload #27
    //   729: iconst_0
    //   730: bipush #8
    //   732: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   735: iload #11
    //   737: ifeq -> 776
    //   740: aload_0
    //   741: getfield isTerminalWidget : [Z
    //   744: iconst_1
    //   745: baload
    //   746: ifeq -> 776
    //   749: aload_0
    //   750: invokevirtual isInVerticalChain : ()Z
    //   753: ifne -> 776
    //   756: aload_1
    //   757: aload_1
    //   758: aload_0
    //   759: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   762: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   765: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   768: aload #29
    //   770: iconst_0
    //   771: bipush #8
    //   773: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   776: aload_0
    //   777: iconst_0
    //   778: putfield resolvedHorizontal : Z
    //   781: aload_0
    //   782: iconst_0
    //   783: putfield resolvedVertical : Z
    //   786: return
    //   787: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   790: ifnull -> 810
    //   793: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   796: astore #24
    //   798: aload #24
    //   800: aload #24
    //   802: getfield linearSolved : J
    //   805: lconst_1
    //   806: ladd
    //   807: putfield linearSolved : J
    //   810: aload_0
    //   811: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   814: ifnull -> 1011
    //   817: aload_0
    //   818: iconst_0
    //   819: invokespecial isChainHead : (I)Z
    //   822: ifeq -> 843
    //   825: aload_0
    //   826: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   829: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   832: aload_0
    //   833: iconst_0
    //   834: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   837: iconst_1
    //   838: istore #12
    //   840: goto -> 849
    //   843: aload_0
    //   844: invokevirtual isInHorizontalChain : ()Z
    //   847: istore #12
    //   849: aload_0
    //   850: iconst_1
    //   851: invokespecial isChainHead : (I)Z
    //   854: ifeq -> 875
    //   857: aload_0
    //   858: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   861: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   864: aload_0
    //   865: iconst_1
    //   866: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   869: iconst_1
    //   870: istore #14
    //   872: goto -> 881
    //   875: aload_0
    //   876: invokevirtual isInVerticalChain : ()Z
    //   879: istore #14
    //   881: iload #12
    //   883: ifne -> 939
    //   886: iload #13
    //   888: ifeq -> 939
    //   891: aload_0
    //   892: getfield mVisibility : I
    //   895: bipush #8
    //   897: if_icmpeq -> 939
    //   900: aload_0
    //   901: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   904: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   907: ifnonnull -> 939
    //   910: aload_0
    //   911: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   914: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   917: ifnonnull -> 939
    //   920: aload_1
    //   921: aload_1
    //   922: aload_0
    //   923: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   926: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   929: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   932: aload #27
    //   934: iconst_0
    //   935: iconst_1
    //   936: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   939: iload #14
    //   941: ifne -> 1004
    //   944: iload #11
    //   946: ifeq -> 1004
    //   949: aload_0
    //   950: getfield mVisibility : I
    //   953: bipush #8
    //   955: if_icmpeq -> 1004
    //   958: aload_0
    //   959: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   962: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   965: ifnonnull -> 1004
    //   968: aload_0
    //   969: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   972: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   975: ifnonnull -> 1004
    //   978: aload_0
    //   979: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   982: ifnonnull -> 1004
    //   985: aload_1
    //   986: aload_1
    //   987: aload_0
    //   988: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   991: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   994: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   997: aload #29
    //   999: iconst_0
    //   1000: iconst_1
    //   1001: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1004: iload #12
    //   1006: istore #15
    //   1008: goto -> 1017
    //   1011: iconst_0
    //   1012: istore #14
    //   1014: iconst_0
    //   1015: istore #15
    //   1017: aload_0
    //   1018: getfield mWidth : I
    //   1021: istore #5
    //   1023: aload_0
    //   1024: getfield mMinWidth : I
    //   1027: istore #6
    //   1029: iload #5
    //   1031: istore #4
    //   1033: iload #5
    //   1035: iload #6
    //   1037: if_icmpge -> 1044
    //   1040: iload #6
    //   1042: istore #4
    //   1044: aload_0
    //   1045: getfield mHeight : I
    //   1048: istore #6
    //   1050: aload_0
    //   1051: getfield mMinHeight : I
    //   1054: istore #7
    //   1056: iload #6
    //   1058: istore #5
    //   1060: iload #6
    //   1062: iload #7
    //   1064: if_icmpge -> 1071
    //   1067: iload #7
    //   1069: istore #5
    //   1071: aload_0
    //   1072: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1075: iconst_0
    //   1076: aaload
    //   1077: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1080: if_acmpeq -> 1089
    //   1083: iconst_1
    //   1084: istore #12
    //   1086: goto -> 1092
    //   1089: iconst_0
    //   1090: istore #12
    //   1092: aload_0
    //   1093: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1096: iconst_1
    //   1097: aaload
    //   1098: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1101: if_acmpeq -> 1110
    //   1104: iconst_1
    //   1105: istore #16
    //   1107: goto -> 1113
    //   1110: iconst_0
    //   1111: istore #16
    //   1113: aload_0
    //   1114: aload_0
    //   1115: getfield mDimensionRatioSide : I
    //   1118: putfield mResolvedDimensionRatioSide : I
    //   1121: aload_0
    //   1122: getfield mDimensionRatio : F
    //   1125: fstore_3
    //   1126: aload_0
    //   1127: fload_3
    //   1128: putfield mResolvedDimensionRatio : F
    //   1131: aload_0
    //   1132: getfield mMatchConstraintDefaultWidth : I
    //   1135: istore #7
    //   1137: aload_0
    //   1138: getfield mMatchConstraintDefaultHeight : I
    //   1141: istore #8
    //   1143: fload_3
    //   1144: fconst_0
    //   1145: fcmpl
    //   1146: ifle -> 1486
    //   1149: aload_0
    //   1150: getfield mVisibility : I
    //   1153: bipush #8
    //   1155: if_icmpeq -> 1486
    //   1158: iload #7
    //   1160: istore #6
    //   1162: aload_0
    //   1163: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1166: iconst_0
    //   1167: aaload
    //   1168: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1171: if_acmpne -> 1186
    //   1174: iload #7
    //   1176: istore #6
    //   1178: iload #7
    //   1180: ifne -> 1186
    //   1183: iconst_3
    //   1184: istore #6
    //   1186: iload #8
    //   1188: istore #7
    //   1190: aload_0
    //   1191: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1194: iconst_1
    //   1195: aaload
    //   1196: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1199: if_acmpne -> 1214
    //   1202: iload #8
    //   1204: istore #7
    //   1206: iload #8
    //   1208: ifne -> 1214
    //   1211: iconst_3
    //   1212: istore #7
    //   1214: aload_0
    //   1215: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1218: iconst_0
    //   1219: aaload
    //   1220: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1223: if_acmpne -> 1269
    //   1226: aload_0
    //   1227: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1230: iconst_1
    //   1231: aaload
    //   1232: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1235: if_acmpne -> 1269
    //   1238: iload #6
    //   1240: iconst_3
    //   1241: if_icmpne -> 1269
    //   1244: iload #7
    //   1246: iconst_3
    //   1247: if_icmpne -> 1269
    //   1250: aload_0
    //   1251: iload #13
    //   1253: iload #11
    //   1255: iload #12
    //   1257: iload #16
    //   1259: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1262: iload #5
    //   1264: istore #8
    //   1266: goto -> 1460
    //   1269: aload_0
    //   1270: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1273: iconst_0
    //   1274: aaload
    //   1275: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1278: if_acmpne -> 1357
    //   1281: iload #6
    //   1283: iconst_3
    //   1284: if_icmpne -> 1357
    //   1287: aload_0
    //   1288: iconst_0
    //   1289: putfield mResolvedDimensionRatioSide : I
    //   1292: aload_0
    //   1293: getfield mResolvedDimensionRatio : F
    //   1296: aload_0
    //   1297: getfield mHeight : I
    //   1300: i2f
    //   1301: fmul
    //   1302: f2i
    //   1303: istore #9
    //   1305: aload_0
    //   1306: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1309: iconst_1
    //   1310: aaload
    //   1311: astore #24
    //   1313: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1316: astore #25
    //   1318: iload #5
    //   1320: istore #4
    //   1322: iload #7
    //   1324: istore #8
    //   1326: aload #24
    //   1328: aload #25
    //   1330: if_acmpeq -> 1350
    //   1333: iconst_0
    //   1334: istore #12
    //   1336: iconst_4
    //   1337: istore #7
    //   1339: iload #9
    //   1341: istore #5
    //   1343: iload #8
    //   1345: istore #6
    //   1347: goto -> 1505
    //   1350: iload #9
    //   1352: istore #5
    //   1354: goto -> 1468
    //   1357: iload #5
    //   1359: istore #8
    //   1361: aload_0
    //   1362: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1365: iconst_1
    //   1366: aaload
    //   1367: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1370: if_acmpne -> 1460
    //   1373: iload #5
    //   1375: istore #8
    //   1377: iload #7
    //   1379: iconst_3
    //   1380: if_icmpne -> 1460
    //   1383: aload_0
    //   1384: iconst_1
    //   1385: putfield mResolvedDimensionRatioSide : I
    //   1388: aload_0
    //   1389: getfield mDimensionRatioSide : I
    //   1392: iconst_m1
    //   1393: if_icmpne -> 1406
    //   1396: aload_0
    //   1397: fconst_1
    //   1398: aload_0
    //   1399: getfield mResolvedDimensionRatio : F
    //   1402: fdiv
    //   1403: putfield mResolvedDimensionRatio : F
    //   1406: aload_0
    //   1407: getfield mResolvedDimensionRatio : F
    //   1410: aload_0
    //   1411: getfield mWidth : I
    //   1414: i2f
    //   1415: fmul
    //   1416: f2i
    //   1417: istore #5
    //   1419: iload #5
    //   1421: istore #8
    //   1423: aload_0
    //   1424: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1427: iconst_0
    //   1428: aaload
    //   1429: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1432: if_acmpeq -> 1460
    //   1435: iload #5
    //   1437: istore #8
    //   1439: iload #6
    //   1441: istore #7
    //   1443: iconst_0
    //   1444: istore #12
    //   1446: iconst_4
    //   1447: istore #6
    //   1449: iload #4
    //   1451: istore #5
    //   1453: iload #8
    //   1455: istore #4
    //   1457: goto -> 1505
    //   1460: iload #4
    //   1462: istore #5
    //   1464: iload #8
    //   1466: istore #4
    //   1468: iload #6
    //   1470: istore #8
    //   1472: iload #7
    //   1474: istore #6
    //   1476: iconst_1
    //   1477: istore #12
    //   1479: iload #8
    //   1481: istore #7
    //   1483: goto -> 1505
    //   1486: iload #8
    //   1488: istore #6
    //   1490: iload #4
    //   1492: istore #8
    //   1494: iconst_0
    //   1495: istore #12
    //   1497: iload #5
    //   1499: istore #4
    //   1501: iload #8
    //   1503: istore #5
    //   1505: aload_0
    //   1506: getfield mResolvedMatchConstraintDefault : [I
    //   1509: astore #24
    //   1511: aload #24
    //   1513: iconst_0
    //   1514: iload #7
    //   1516: iastore
    //   1517: aload #24
    //   1519: iconst_1
    //   1520: iload #6
    //   1522: iastore
    //   1523: aload_0
    //   1524: iload #12
    //   1526: putfield mResolvedHasRatio : Z
    //   1529: iload #12
    //   1531: ifeq -> 1557
    //   1534: aload_0
    //   1535: getfield mResolvedDimensionRatioSide : I
    //   1538: istore #8
    //   1540: iload #8
    //   1542: ifeq -> 1551
    //   1545: iload #8
    //   1547: iconst_m1
    //   1548: if_icmpne -> 1557
    //   1551: iconst_1
    //   1552: istore #17
    //   1554: goto -> 1560
    //   1557: iconst_0
    //   1558: istore #17
    //   1560: iload #12
    //   1562: ifeq -> 1589
    //   1565: aload_0
    //   1566: getfield mResolvedDimensionRatioSide : I
    //   1569: istore #8
    //   1571: iload #8
    //   1573: iconst_1
    //   1574: if_icmpeq -> 1583
    //   1577: iload #8
    //   1579: iconst_m1
    //   1580: if_icmpne -> 1589
    //   1583: iconst_1
    //   1584: istore #16
    //   1586: goto -> 1592
    //   1589: iconst_0
    //   1590: istore #16
    //   1592: aload_0
    //   1593: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1596: iconst_0
    //   1597: aaload
    //   1598: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1601: if_acmpne -> 1617
    //   1604: aload_0
    //   1605: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   1608: ifeq -> 1617
    //   1611: iconst_1
    //   1612: istore #18
    //   1614: goto -> 1620
    //   1617: iconst_0
    //   1618: istore #18
    //   1620: iload #18
    //   1622: ifeq -> 1631
    //   1625: iconst_0
    //   1626: istore #5
    //   1628: goto -> 1631
    //   1631: aload_0
    //   1632: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1635: invokevirtual isConnected : ()Z
    //   1638: iconst_1
    //   1639: ixor
    //   1640: istore #20
    //   1642: aload_0
    //   1643: getfield mIsInBarrier : [Z
    //   1646: astore #24
    //   1648: aload #24
    //   1650: iconst_0
    //   1651: baload
    //   1652: istore #22
    //   1654: aload #24
    //   1656: iconst_1
    //   1657: baload
    //   1658: istore #21
    //   1660: aload_0
    //   1661: getfield mHorizontalResolution : I
    //   1664: iconst_2
    //   1665: if_icmpeq -> 2000
    //   1668: aload_0
    //   1669: getfield resolvedHorizontal : Z
    //   1672: ifne -> 2000
    //   1675: iload_2
    //   1676: ifeq -> 1804
    //   1679: aload_0
    //   1680: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1683: astore #24
    //   1685: aload #24
    //   1687: ifnull -> 1804
    //   1690: aload #24
    //   1692: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1695: getfield resolved : Z
    //   1698: ifeq -> 1804
    //   1701: aload_0
    //   1702: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1705: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1708: getfield resolved : Z
    //   1711: ifne -> 1717
    //   1714: goto -> 1804
    //   1717: iload_2
    //   1718: ifeq -> 2000
    //   1721: aload_1
    //   1722: aload #28
    //   1724: aload_0
    //   1725: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1728: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1731: getfield value : I
    //   1734: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1737: aload_1
    //   1738: aload #27
    //   1740: aload_0
    //   1741: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1744: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1747: getfield value : I
    //   1750: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1753: aload_0
    //   1754: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1757: ifnull -> 2000
    //   1760: iload #13
    //   1762: ifeq -> 2000
    //   1765: aload_0
    //   1766: getfield isTerminalWidget : [Z
    //   1769: iconst_0
    //   1770: baload
    //   1771: ifeq -> 2000
    //   1774: aload_0
    //   1775: invokevirtual isInHorizontalChain : ()Z
    //   1778: ifne -> 2000
    //   1781: aload_1
    //   1782: aload_1
    //   1783: aload_0
    //   1784: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1787: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1790: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1793: aload #27
    //   1795: iconst_0
    //   1796: bipush #8
    //   1798: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1801: goto -> 2000
    //   1804: aload_0
    //   1805: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1808: astore #24
    //   1810: aload #24
    //   1812: ifnull -> 1829
    //   1815: aload_1
    //   1816: aload #24
    //   1818: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1821: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1824: astore #24
    //   1826: goto -> 1832
    //   1829: aconst_null
    //   1830: astore #24
    //   1832: aload_0
    //   1833: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1836: astore #25
    //   1838: aload #25
    //   1840: ifnull -> 1857
    //   1843: aload_1
    //   1844: aload #25
    //   1846: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1849: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1852: astore #25
    //   1854: goto -> 1860
    //   1857: aconst_null
    //   1858: astore #25
    //   1860: aload_0
    //   1861: getfield isTerminalWidget : [Z
    //   1864: iconst_0
    //   1865: baload
    //   1866: istore #23
    //   1868: aload_0
    //   1869: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1872: astore #31
    //   1874: aload #31
    //   1876: iconst_0
    //   1877: aaload
    //   1878: astore #32
    //   1880: aload_0
    //   1881: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1884: astore #33
    //   1886: aload_0
    //   1887: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1890: astore #34
    //   1892: aload_0
    //   1893: getfield mX : I
    //   1896: istore #8
    //   1898: aload_0
    //   1899: getfield mMinWidth : I
    //   1902: istore #9
    //   1904: aload_0
    //   1905: getfield mMaxDimension : [I
    //   1908: iconst_0
    //   1909: iaload
    //   1910: istore #10
    //   1912: aload_0
    //   1913: getfield mHorizontalBiasPercent : F
    //   1916: fstore_3
    //   1917: aload #31
    //   1919: iconst_1
    //   1920: aaload
    //   1921: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1924: if_acmpne -> 1933
    //   1927: iconst_1
    //   1928: istore #19
    //   1930: goto -> 1936
    //   1933: iconst_0
    //   1934: istore #19
    //   1936: aload_0
    //   1937: aload_1
    //   1938: iconst_1
    //   1939: iload #13
    //   1941: iload #11
    //   1943: iload #23
    //   1945: aload #25
    //   1947: aload #24
    //   1949: aload #32
    //   1951: iload #18
    //   1953: aload #33
    //   1955: aload #34
    //   1957: iload #8
    //   1959: iload #5
    //   1961: iload #9
    //   1963: iload #10
    //   1965: fload_3
    //   1966: iload #17
    //   1968: iload #19
    //   1970: iload #15
    //   1972: iload #14
    //   1974: iload #22
    //   1976: iload #7
    //   1978: iload #6
    //   1980: aload_0
    //   1981: getfield mMatchConstraintMinWidth : I
    //   1984: aload_0
    //   1985: getfield mMatchConstraintMaxWidth : I
    //   1988: aload_0
    //   1989: getfield mMatchConstraintPercentWidth : F
    //   1992: iload #20
    //   1994: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   1997: goto -> 2000
    //   2000: aload #30
    //   2002: astore #25
    //   2004: aload #29
    //   2006: astore #24
    //   2008: iload #11
    //   2010: istore #18
    //   2012: aload #27
    //   2014: astore #29
    //   2016: iload_2
    //   2017: ifeq -> 2196
    //   2020: aload_0
    //   2021: astore #27
    //   2023: aload #27
    //   2025: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2028: astore #30
    //   2030: aload #30
    //   2032: ifnull -> 2193
    //   2035: aload #30
    //   2037: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2040: getfield resolved : Z
    //   2043: ifeq -> 2193
    //   2046: aload #27
    //   2048: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2051: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2054: getfield resolved : Z
    //   2057: ifeq -> 2193
    //   2060: aload #27
    //   2062: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2065: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2068: getfield value : I
    //   2071: istore #5
    //   2073: aload_1
    //   2074: astore #30
    //   2076: aload #30
    //   2078: aload #25
    //   2080: iload #5
    //   2082: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2085: aload #27
    //   2087: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2090: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2093: getfield value : I
    //   2096: istore #5
    //   2098: aload #24
    //   2100: astore #31
    //   2102: aload #30
    //   2104: aload #31
    //   2106: iload #5
    //   2108: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2111: aload #30
    //   2113: aload #26
    //   2115: aload #27
    //   2117: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2120: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2123: getfield value : I
    //   2126: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2129: aload #27
    //   2131: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2134: astore #32
    //   2136: aload #32
    //   2138: ifnull -> 2187
    //   2141: iload #14
    //   2143: ifne -> 2187
    //   2146: iload #18
    //   2148: ifeq -> 2187
    //   2151: aload #27
    //   2153: getfield isTerminalWidget : [Z
    //   2156: iconst_1
    //   2157: baload
    //   2158: ifeq -> 2184
    //   2161: aload #30
    //   2163: aload #30
    //   2165: aload #32
    //   2167: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2170: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2173: aload #31
    //   2175: iconst_0
    //   2176: bipush #8
    //   2178: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2181: goto -> 2187
    //   2184: goto -> 2187
    //   2187: iconst_0
    //   2188: istore #5
    //   2190: goto -> 2199
    //   2193: goto -> 2196
    //   2196: iconst_1
    //   2197: istore #5
    //   2199: aload_0
    //   2200: astore #30
    //   2202: aload_1
    //   2203: astore #31
    //   2205: aload #26
    //   2207: astore #32
    //   2209: aload #30
    //   2211: getfield mVerticalResolution : I
    //   2214: iconst_2
    //   2215: if_icmpne -> 2224
    //   2218: iconst_0
    //   2219: istore #5
    //   2221: goto -> 2224
    //   2224: iload #5
    //   2226: ifeq -> 2641
    //   2229: aload #30
    //   2231: getfield resolvedVertical : Z
    //   2234: ifne -> 2641
    //   2237: aload #30
    //   2239: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2242: iconst_1
    //   2243: aaload
    //   2244: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2247: if_acmpne -> 2263
    //   2250: aload #30
    //   2252: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   2255: ifeq -> 2263
    //   2258: iconst_1
    //   2259: istore_2
    //   2260: goto -> 2265
    //   2263: iconst_0
    //   2264: istore_2
    //   2265: iload_2
    //   2266: ifeq -> 2272
    //   2269: iconst_0
    //   2270: istore #4
    //   2272: aload #30
    //   2274: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2277: astore #26
    //   2279: aload #26
    //   2281: ifnull -> 2299
    //   2284: aload #31
    //   2286: aload #26
    //   2288: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2291: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2294: astore #26
    //   2296: goto -> 2302
    //   2299: aconst_null
    //   2300: astore #26
    //   2302: aload #30
    //   2304: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2307: astore #27
    //   2309: aload #27
    //   2311: ifnull -> 2329
    //   2314: aload #31
    //   2316: aload #27
    //   2318: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2321: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2324: astore #27
    //   2326: goto -> 2332
    //   2329: aconst_null
    //   2330: astore #27
    //   2332: aload #30
    //   2334: getfield mBaselineDistance : I
    //   2337: ifgt -> 2350
    //   2340: aload #30
    //   2342: getfield mVisibility : I
    //   2345: bipush #8
    //   2347: if_icmpne -> 2487
    //   2350: aload #30
    //   2352: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2355: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2358: ifnull -> 2438
    //   2361: aload #31
    //   2363: aload #32
    //   2365: aload #25
    //   2367: aload_0
    //   2368: invokevirtual getBaselineDistance : ()I
    //   2371: bipush #8
    //   2373: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2376: pop
    //   2377: aload #31
    //   2379: aload #32
    //   2381: aload #31
    //   2383: aload #30
    //   2385: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2388: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2391: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2394: aload #30
    //   2396: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2399: invokevirtual getMargin : ()I
    //   2402: bipush #8
    //   2404: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2407: pop
    //   2408: iload #18
    //   2410: ifeq -> 2432
    //   2413: aload #31
    //   2415: aload #26
    //   2417: aload #31
    //   2419: aload #30
    //   2421: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2424: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2427: iconst_0
    //   2428: iconst_5
    //   2429: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2432: iconst_0
    //   2433: istore #11
    //   2435: goto -> 2491
    //   2438: aload #30
    //   2440: getfield mVisibility : I
    //   2443: bipush #8
    //   2445: if_icmpne -> 2471
    //   2448: aload #31
    //   2450: aload #32
    //   2452: aload #25
    //   2454: aload #30
    //   2456: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2459: invokevirtual getMargin : ()I
    //   2462: bipush #8
    //   2464: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2467: pop
    //   2468: goto -> 2487
    //   2471: aload #31
    //   2473: aload #32
    //   2475: aload #25
    //   2477: aload_0
    //   2478: invokevirtual getBaselineDistance : ()I
    //   2481: bipush #8
    //   2483: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2486: pop
    //   2487: iload #20
    //   2489: istore #11
    //   2491: aload #30
    //   2493: getfield isTerminalWidget : [Z
    //   2496: iconst_1
    //   2497: baload
    //   2498: istore #19
    //   2500: aload #30
    //   2502: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2505: astore #31
    //   2507: aload #31
    //   2509: iconst_1
    //   2510: aaload
    //   2511: astore #32
    //   2513: aload #30
    //   2515: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2518: astore #33
    //   2520: aload #30
    //   2522: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2525: astore #34
    //   2527: aload #30
    //   2529: getfield mY : I
    //   2532: istore #5
    //   2534: aload #30
    //   2536: getfield mMinHeight : I
    //   2539: istore #8
    //   2541: aload #30
    //   2543: getfield mMaxDimension : [I
    //   2546: iconst_1
    //   2547: iaload
    //   2548: istore #9
    //   2550: aload #30
    //   2552: getfield mVerticalBiasPercent : F
    //   2555: fstore_3
    //   2556: aload #31
    //   2558: iconst_0
    //   2559: aaload
    //   2560: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2563: if_acmpne -> 2572
    //   2566: iconst_1
    //   2567: istore #17
    //   2569: goto -> 2575
    //   2572: iconst_0
    //   2573: istore #17
    //   2575: aload_0
    //   2576: aload_1
    //   2577: iconst_0
    //   2578: iload #18
    //   2580: iload #13
    //   2582: iload #19
    //   2584: aload #27
    //   2586: aload #26
    //   2588: aload #32
    //   2590: iload_2
    //   2591: aload #33
    //   2593: aload #34
    //   2595: iload #5
    //   2597: iload #4
    //   2599: iload #8
    //   2601: iload #9
    //   2603: fload_3
    //   2604: iload #16
    //   2606: iload #17
    //   2608: iload #14
    //   2610: iload #15
    //   2612: iload #21
    //   2614: iload #6
    //   2616: iload #7
    //   2618: aload #30
    //   2620: getfield mMatchConstraintMinHeight : I
    //   2623: aload #30
    //   2625: getfield mMatchConstraintMaxHeight : I
    //   2628: aload #30
    //   2630: getfield mMatchConstraintPercentHeight : F
    //   2633: iload #11
    //   2635: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2638: goto -> 2641
    //   2641: iload #12
    //   2643: ifeq -> 2702
    //   2646: aload_0
    //   2647: astore #26
    //   2649: aload #26
    //   2651: getfield mResolvedDimensionRatioSide : I
    //   2654: iconst_1
    //   2655: if_icmpne -> 2680
    //   2658: aload_1
    //   2659: aload #24
    //   2661: aload #25
    //   2663: aload #29
    //   2665: aload #28
    //   2667: aload #26
    //   2669: getfield mResolvedDimensionRatio : F
    //   2672: bipush #8
    //   2674: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2677: goto -> 2702
    //   2680: aload_1
    //   2681: aload #29
    //   2683: aload #28
    //   2685: aload #24
    //   2687: aload #25
    //   2689: aload #26
    //   2691: getfield mResolvedDimensionRatio : F
    //   2694: bipush #8
    //   2696: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2699: goto -> 2702
    //   2702: aload_0
    //   2703: astore #24
    //   2705: aload #24
    //   2707: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2710: invokevirtual isConnected : ()Z
    //   2713: ifeq -> 2755
    //   2716: aload_1
    //   2717: aload #24
    //   2719: aload #24
    //   2721: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2724: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2727: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2730: aload #24
    //   2732: getfield mCircleConstraintAngle : F
    //   2735: ldc_w 90.0
    //   2738: fadd
    //   2739: f2d
    //   2740: invokestatic toRadians : (D)D
    //   2743: d2f
    //   2744: aload #24
    //   2746: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2749: invokevirtual getMargin : ()I
    //   2752: invokevirtual addCenterPoint : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget;FI)V
    //   2755: aload #24
    //   2757: iconst_0
    //   2758: putfield resolvedHorizontal : Z
    //   2761: aload #24
    //   2763: iconst_0
    //   2764: putfield resolvedVertical : Z
    //   2767: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    ConstraintAnchor constraintAnchor;
    if (paramType1 == ConstraintAnchor.Type.CENTER) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.TOP);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.BOTTOM);
        boolean bool = true;
        if ((constraintAnchor1 != null && constraintAnchor1.isConnected()) || (constraintAnchor != null && constraintAnchor.isConnected())) {
          paramInt = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0);
          paramInt = 1;
        } 
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0);
        } 
        if (paramInt != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0);
          return;
        } 
        if (paramInt != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0);
          return;
        } 
        if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0);
          return;
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
          return;
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor2 = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor2, 0);
        constraintAnchor.connect(constraintAnchor2, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
      ConstraintAnchor constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
      if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
        if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
          constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
          if (constraintAnchor1 != null)
            constraintAnchor1.reset(); 
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_Y);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_X);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } 
        constraintAnchor3.connect(constraintAnchor2, paramInt);
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mAnimated = paramConstraintWidget.mAnimated;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public void getSceneString(StringBuilder paramStringBuilder) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("  ");
    stringBuilder.append(this.stringId);
    stringBuilder.append(":{\n");
    paramStringBuilder.append(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualWidth:");
    stringBuilder.append(this.mWidth);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualHeight:");
    stringBuilder.append(this.mHeight);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualLeft:");
    stringBuilder.append(this.mX);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualTop:");
    stringBuilder.append(this.mY);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    getSceneString(paramStringBuilder, "left", this.mLeft);
    getSceneString(paramStringBuilder, "top", this.mTop);
    getSceneString(paramStringBuilder, "right", this.mRight);
    getSceneString(paramStringBuilder, "bottom", this.mBottom);
    getSceneString(paramStringBuilder, "baseline", this.mBaseline);
    getSceneString(paramStringBuilder, "centerX", this.mCenterX);
    getSceneString(paramStringBuilder, "centerY", this.mCenterY);
    getSceneString(paramStringBuilder, "    width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    getSceneString(paramStringBuilder, "    height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "    dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "    horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "    verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "    horizontalChainStyle", this.mHorizontalChainStyle, 0);
    serializeAttribute(paramStringBuilder, "    verticalChainStyle", this.mVerticalChainStyle, 0);
    paramStringBuilder.append("  }");
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapBehaviorInParent() {
    return this.mWrapBehaviorInParent;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDimensionOverride() {
    return (this.mWidthOverride != -1 || this.mHeightOverride != -1);
  }
  
  public boolean hasResolvedTargets(int paramInt1, int paramInt2) {
    if (paramInt1 == 0) {
      if (this.mLeft.mTarget != null && this.mLeft.mTarget.hasFinalValue() && this.mRight.mTarget != null && this.mRight.mTarget.hasFinalValue())
        return (this.mRight.mTarget.getFinalValue() - this.mRight.getMargin() - this.mLeft.mTarget.getFinalValue() + this.mLeft.getMargin() >= paramInt2); 
    } else if (this.mTop.mTarget != null && this.mTop.mTarget.hasFinalValue() && this.mBottom.mTarget != null && this.mBottom.mTarget.hasFinalValue()) {
      return (this.mBottom.mTarget.getFinalValue() - this.mBottom.getMargin() - this.mTop.mTarget.getFinalValue() + this.mTop.getMargin() >= paramInt2);
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isAnimated() {
    return this.mAnimated;
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isHorizontalSolvingPassDone() {
    return this.horizontalSolvingPass;
  }
  
  public boolean isInBarrier(int paramInt) {
    return this.mIsInBarrier[paramInt];
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtualLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isVerticalSolvingPassDone() {
    return this.verticalSolvingPass;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void markHorizontalSolvingPassDone() {
    this.horizontalSolvingPass = true;
  }
  
  public void markVerticalSolvingPassDone() {
    this.verticalSolvingPass = true;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    return (dimensionBehaviour1 == DimensionBehaviour.MATCH_CONSTRAINT && dimensionBehaviour2 == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (arrayOfDimensionBehaviour[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = bool2;
      if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt2 = this.mMaxDimension;
    arrayOfInt2[0] = Integer.MAX_VALUE;
    arrayOfInt2[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtualLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
    int[] arrayOfInt1 = this.mResolvedMatchConstraintDefault;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    this.mWidthOverride = -1;
    this.mHeightOverride = -1;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resetSolvingPassFlag() {
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
  }
  
  public StringBuilder serialize(StringBuilder paramStringBuilder) {
    paramStringBuilder.append("{\n");
    serializeAnchor(paramStringBuilder, "left", this.mLeft);
    serializeAnchor(paramStringBuilder, "top", this.mTop);
    serializeAnchor(paramStringBuilder, "right", this.mRight);
    serializeAnchor(paramStringBuilder, "bottom", this.mBottom);
    serializeAnchor(paramStringBuilder, "baseline", this.mBaseline);
    serializeAnchor(paramStringBuilder, "centerX", this.mCenterX);
    serializeAnchor(paramStringBuilder, "centerY", this.mCenterY);
    serializeCircle(paramStringBuilder, this.mCenter, this.mCircleConstraintAngle);
    serializeSize(paramStringBuilder, "width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    serializeSize(paramStringBuilder, "height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    paramStringBuilder.append("}\n");
    return paramStringBuilder;
  }
  
  public void setAnimated(boolean paramBoolean) {
    this.mAnimated = paramBoolean;
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    if (this.resolvedHorizontal)
      return; 
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    if (this.resolvedVertical)
      return; 
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt3 = this.mMinWidth;
    if (paramInt1 < paramInt3)
      this.mWidth = paramInt3; 
    if (this.mMatchConstraintMaxWidth > 0 && this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mWidth = Math.min(this.mWidth, this.mMatchConstraintMaxWidth); 
    if (this.mMatchConstraintMaxHeight > 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mHeight = Math.min(this.mHeight, this.mMatchConstraintMaxHeight); 
    paramInt3 = this.mWidth;
    if (paramInt1 != paramInt3)
      this.mWidthOverride = paramInt3; 
    paramInt1 = this.mHeight;
    if (paramInt2 != paramInt1)
      this.mHeightOverride = paramInt1; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              return; 
            this.mBaseline.mGoneMargin = paramInt;
            return;
          } 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxWidth = paramInt2;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtualLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxHeight = paramInt2;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapBehaviorInParent(int paramInt) {
    if (paramInt >= 0 && paramInt <= 3)
      this.mWrapBehaviorInParent = paramInt; 
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      int i = this.mMatchConstraintMinWidth;
      if (i > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (i == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #7
    //   69: iload #6
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #7
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #6
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #6
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #7
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #7
    //   137: istore #5
    //   139: iload #7
    //   141: ldc 2147483647
    //   143: if_icmpne -> 157
    //   146: iconst_0
    //   147: istore_3
    //   148: iconst_0
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #6
    //   154: iconst_0
    //   155: istore #5
    //   157: iload #6
    //   159: iload_3
    //   160: isub
    //   161: istore #6
    //   163: iload #5
    //   165: iload #4
    //   167: isub
    //   168: istore #5
    //   170: iload #9
    //   172: ifeq -> 180
    //   175: aload_0
    //   176: iload_3
    //   177: putfield mX : I
    //   180: iload #8
    //   182: ifeq -> 191
    //   185: aload_0
    //   186: iload #4
    //   188: putfield mY : I
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 211
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield mWidth : I
    //   205: aload_0
    //   206: iconst_0
    //   207: putfield mHeight : I
    //   210: return
    //   211: iload #9
    //   213: ifeq -> 273
    //   216: iload #6
    //   218: istore_3
    //   219: aload_0
    //   220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   223: iconst_0
    //   224: aaload
    //   225: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield mWidth : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield mWidth : I
    //   255: aload_0
    //   256: getfield mMinWidth : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield mWidth : I
    //   273: iload #8
    //   275: ifeq -> 335
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: if_acmpne -> 312
    //   293: aload_0
    //   294: getfield mHeight : I
    //   297: istore #4
    //   299: iload #5
    //   301: istore_3
    //   302: iload #5
    //   304: iload #4
    //   306: if_icmpge -> 312
    //   309: iload #4
    //   311: istore_3
    //   312: aload_0
    //   313: iload_3
    //   314: putfield mHeight : I
    //   317: aload_0
    //   318: getfield mMinHeight : I
    //   321: istore #4
    //   323: iload_3
    //   324: iload #4
    //   326: if_icmpge -> 335
    //   329: aload_0
    //   330: iload #4
    //   332: putfield mHeight : I
    //   335: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 127
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore_1
    //   56: iload #4
    //   58: istore #5
    //   60: iload #6
    //   62: istore_3
    //   63: aload_1
    //   64: ifnull -> 127
    //   67: iload #4
    //   69: istore #5
    //   71: iload #6
    //   73: istore_3
    //   74: aload_1
    //   75: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   78: getfield resolved : Z
    //   81: ifeq -> 127
    //   84: iload #4
    //   86: istore #5
    //   88: iload #6
    //   90: istore_3
    //   91: aload_0
    //   92: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   95: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   98: getfield resolved : Z
    //   101: ifeq -> 127
    //   104: aload_0
    //   105: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   108: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   111: getfield value : I
    //   114: istore #5
    //   116: aload_0
    //   117: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   120: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   123: getfield value : I
    //   126: istore_3
    //   127: iload #7
    //   129: istore #6
    //   131: iload #8
    //   133: istore #4
    //   135: iload_2
    //   136: ifeq -> 219
    //   139: aload_0
    //   140: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   143: astore_1
    //   144: iload #7
    //   146: istore #6
    //   148: iload #8
    //   150: istore #4
    //   152: aload_1
    //   153: ifnull -> 219
    //   156: iload #7
    //   158: istore #6
    //   160: iload #8
    //   162: istore #4
    //   164: aload_1
    //   165: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   168: getfield resolved : Z
    //   171: ifeq -> 219
    //   174: iload #7
    //   176: istore #6
    //   178: iload #8
    //   180: istore #4
    //   182: aload_0
    //   183: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   186: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   189: getfield resolved : Z
    //   192: ifeq -> 219
    //   195: aload_0
    //   196: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   199: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   202: getfield value : I
    //   205: istore #6
    //   207: aload_0
    //   208: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   211: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   214: getfield value : I
    //   217: istore #4
    //   219: iload_3
    //   220: iload #5
    //   222: isub
    //   223: iflt -> 298
    //   226: iload #4
    //   228: iload #6
    //   230: isub
    //   231: iflt -> 298
    //   234: iload #5
    //   236: ldc_w -2147483648
    //   239: if_icmpeq -> 298
    //   242: iload #5
    //   244: ldc 2147483647
    //   246: if_icmpeq -> 298
    //   249: iload #6
    //   251: ldc_w -2147483648
    //   254: if_icmpeq -> 298
    //   257: iload #6
    //   259: ldc 2147483647
    //   261: if_icmpeq -> 298
    //   264: iload_3
    //   265: ldc_w -2147483648
    //   268: if_icmpeq -> 298
    //   271: iload_3
    //   272: ldc 2147483647
    //   274: if_icmpeq -> 298
    //   277: iload #4
    //   279: ldc_w -2147483648
    //   282: if_icmpeq -> 298
    //   285: iload_3
    //   286: istore #7
    //   288: iload #4
    //   290: istore_3
    //   291: iload #4
    //   293: ldc 2147483647
    //   295: if_icmpne -> 309
    //   298: iconst_0
    //   299: istore_3
    //   300: iconst_0
    //   301: istore #5
    //   303: iconst_0
    //   304: istore #6
    //   306: iconst_0
    //   307: istore #7
    //   309: aload_0
    //   310: iload #5
    //   312: iload #6
    //   314: iload #7
    //   316: iload_3
    //   317: invokevirtual setFrame : (IIII)V
    //   320: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      FIXED = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      WRAP_CONTENT = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      MATCH_CONSTRAINT = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour4;
      $VALUES = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */