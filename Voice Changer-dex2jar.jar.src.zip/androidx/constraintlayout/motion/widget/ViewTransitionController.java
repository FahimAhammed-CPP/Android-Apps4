package androidx.constraintlayout.motion.widget;

import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.SharedValues;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class ViewTransitionController {
  private String TAG = "ViewTransitionController";
  
  ArrayList<ViewTransition.Animate> animations;
  
  private final MotionLayout mMotionLayout;
  
  private HashSet<View> mRelatedViews;
  
  ArrayList<ViewTransition.Animate> removeList = new ArrayList<ViewTransition.Animate>();
  
  private ArrayList<ViewTransition> viewTransitions = new ArrayList<ViewTransition>();
  
  public ViewTransitionController(MotionLayout paramMotionLayout) {
    this.mMotionLayout = paramMotionLayout;
  }
  
  private void listenForSharedVariable(final ViewTransition viewTransition, final boolean isSet) {
    final int listen_for_id = viewTransition.getSharedValueID();
    final int listen_for_value = viewTransition.getSharedValue();
    ConstraintLayout.getSharedValues().addListener(viewTransition.getSharedValueID(), new SharedValues.SharedValuesListener() {
          public void onNewValue(int param1Int1, int param1Int2, int param1Int3) {
            param1Int3 = viewTransition.getSharedValueCurrent();
            viewTransition.setSharedValueCurrent(param1Int2);
            if (listen_for_id == param1Int1 && param1Int3 != param1Int2)
              if (isSet) {
                if (listen_for_value == param1Int2) {
                  param1Int2 = ViewTransitionController.this.mMotionLayout.getChildCount();
                  for (param1Int1 = 0; param1Int1 < param1Int2; param1Int1++) {
                    View view = ViewTransitionController.this.mMotionLayout.getChildAt(param1Int1);
                    if (viewTransition.matchesView(view)) {
                      param1Int3 = ViewTransitionController.this.mMotionLayout.getCurrentState();
                      ConstraintSet constraintSet = ViewTransitionController.this.mMotionLayout.getConstraintSet(param1Int3);
                      ViewTransition viewTransition = viewTransition;
                      ViewTransitionController viewTransitionController = ViewTransitionController.this;
                      viewTransition.applyTransition(viewTransitionController, viewTransitionController.mMotionLayout, param1Int3, constraintSet, new View[] { view });
                    } 
                  } 
                } 
              } else if (listen_for_value != param1Int2) {
                param1Int2 = ViewTransitionController.this.mMotionLayout.getChildCount();
                for (param1Int1 = 0; param1Int1 < param1Int2; param1Int1++) {
                  View view = ViewTransitionController.this.mMotionLayout.getChildAt(param1Int1);
                  if (viewTransition.matchesView(view)) {
                    param1Int3 = ViewTransitionController.this.mMotionLayout.getCurrentState();
                    ConstraintSet constraintSet = ViewTransitionController.this.mMotionLayout.getConstraintSet(param1Int3);
                    ViewTransition viewTransition = viewTransition;
                    ViewTransitionController viewTransitionController = ViewTransitionController.this;
                    viewTransition.applyTransition(viewTransitionController, viewTransitionController.mMotionLayout, param1Int3, constraintSet, new View[] { view });
                  } 
                } 
              }  
          }
        });
  }
  
  private void viewTransition(ViewTransition paramViewTransition, View... paramVarArgs) {
    String str;
    StringBuilder stringBuilder;
    int i = this.mMotionLayout.getCurrentState();
    if (paramViewTransition.mViewTransitionMode != 2) {
      if (i == -1) {
        str = this.TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("No support for ViewTransition within transition yet. Currently: ");
        stringBuilder.append(this.mMotionLayout.toString());
        Log.w(str, stringBuilder.toString());
        return;
      } 
      ConstraintSet constraintSet = this.mMotionLayout.getConstraintSet(i);
      if (constraintSet == null)
        return; 
      str.applyTransition(this, this.mMotionLayout, i, constraintSet, (View[])stringBuilder);
      return;
    } 
    str.applyTransition(this, this.mMotionLayout, i, null, (View[])stringBuilder);
  }
  
  public void add(ViewTransition paramViewTransition) {
    this.viewTransitions.add(paramViewTransition);
    this.mRelatedViews = null;
    if (paramViewTransition.getStateTransition() == 4) {
      listenForSharedVariable(paramViewTransition, true);
      return;
    } 
    if (paramViewTransition.getStateTransition() == 5)
      listenForSharedVariable(paramViewTransition, false); 
  }
  
  void addAnimation(ViewTransition.Animate paramAnimate) {
    if (this.animations == null)
      this.animations = new ArrayList<ViewTransition.Animate>(); 
    this.animations.add(paramAnimate);
  }
  
  void animate() {
    ArrayList<ViewTransition.Animate> arrayList = this.animations;
    if (arrayList == null)
      return; 
    Iterator<ViewTransition.Animate> iterator = arrayList.iterator();
    while (iterator.hasNext())
      ((ViewTransition.Animate)iterator.next()).mutate(); 
    this.animations.removeAll(this.removeList);
    this.removeList.clear();
    if (this.animations.isEmpty())
      this.animations = null; 
  }
  
  boolean applyViewTransition(int paramInt, MotionController paramMotionController) {
    for (ViewTransition viewTransition : this.viewTransitions) {
      if (viewTransition.getId() == paramInt) {
        viewTransition.mKeyFrames.addAllFrames(paramMotionController);
        return true;
      } 
    } 
    return false;
  }
  
  void enableViewTransition(int paramInt, boolean paramBoolean) {
    for (ViewTransition viewTransition : this.viewTransitions) {
      if (viewTransition.getId() == paramInt) {
        viewTransition.setEnabled(paramBoolean);
        break;
      } 
    } 
  }
  
  void invalidate() {
    this.mMotionLayout.invalidate();
  }
  
  boolean isViewTransitionEnabled(int paramInt) {
    for (ViewTransition viewTransition : this.viewTransitions) {
      if (viewTransition.getId() == paramInt)
        return viewTransition.isEnabled(); 
    } 
    return false;
  }
  
  void remove(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield viewTransitions : Ljava/util/ArrayList;
    //   4: invokevirtual iterator : ()Ljava/util/Iterator;
    //   7: astore_3
    //   8: aload_3
    //   9: invokeinterface hasNext : ()Z
    //   14: ifeq -> 38
    //   17: aload_3
    //   18: invokeinterface next : ()Ljava/lang/Object;
    //   23: checkcast androidx/constraintlayout/motion/widget/ViewTransition
    //   26: astore_2
    //   27: aload_2
    //   28: invokevirtual getId : ()I
    //   31: iload_1
    //   32: if_icmpne -> 8
    //   35: goto -> 40
    //   38: aconst_null
    //   39: astore_2
    //   40: aload_2
    //   41: ifnull -> 58
    //   44: aload_0
    //   45: aconst_null
    //   46: putfield mRelatedViews : Ljava/util/HashSet;
    //   49: aload_0
    //   50: getfield viewTransitions : Ljava/util/ArrayList;
    //   53: aload_2
    //   54: invokevirtual remove : (Ljava/lang/Object;)Z
    //   57: pop
    //   58: return
  }
  
  void removeAnimation(ViewTransition.Animate paramAnimate) {
    this.removeList.add(paramAnimate);
  }
  
  void touchEvent(MotionEvent paramMotionEvent) {
    int j = this.mMotionLayout.getCurrentState();
    if (j == -1)
      return; 
    if (this.mRelatedViews == null) {
      this.mRelatedViews = new HashSet<View>();
      for (ViewTransition viewTransition : this.viewTransitions) {
        int m = this.mMotionLayout.getChildCount();
        int k;
        for (k = 0; k < m; k++) {
          View view = this.mMotionLayout.getChildAt(k);
          if (viewTransition.matchesView(view)) {
            view.getId();
            this.mRelatedViews.add(view);
          } 
        } 
      } 
    } 
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    Rect rect = new Rect();
    int i = paramMotionEvent.getAction();
    ArrayList<ViewTransition.Animate> arrayList = this.animations;
    if (arrayList != null && !arrayList.isEmpty()) {
      Iterator<ViewTransition.Animate> iterator = this.animations.iterator();
      while (iterator.hasNext())
        ((ViewTransition.Animate)iterator.next()).reactTo(i, f1, f2); 
    } 
    if (i != 0 && i != 1)
      return; 
    ConstraintSet constraintSet = this.mMotionLayout.getConstraintSet(j);
    for (ViewTransition viewTransition : this.viewTransitions) {
      if (viewTransition.supports(i))
        for (View view : this.mRelatedViews) {
          if (!viewTransition.matchesView(view))
            continue; 
          view.getHitRect(rect);
          if (rect.contains((int)f1, (int)f2))
            viewTransition.applyTransition(this, this.mMotionLayout, j, constraintSet, new View[] { view }); 
        }  
    } 
  }
  
  void viewTransition(int paramInt, View... paramVarArgs) {
    ViewTransition viewTransition;
    ArrayList<View> arrayList = new ArrayList();
    Iterator<ViewTransition> iterator = this.viewTransitions.iterator();
    View view = null;
    while (iterator.hasNext()) {
      ViewTransition viewTransition1 = iterator.next();
      if (viewTransition1.getId() == paramInt) {
        int j = paramVarArgs.length;
        for (int i = 0; i < j; i++) {
          view = paramVarArgs[i];
          if (viewTransition1.checkTags(view))
            arrayList.add(view); 
        } 
        if (!arrayList.isEmpty()) {
          viewTransition(viewTransition1, arrayList.<View>toArray(new View[0]));
          arrayList.clear();
        } 
        viewTransition = viewTransition1;
      } 
    } 
    if (viewTransition == null)
      Log.e(this.TAG, " Could not find ViewTransition"); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\motion\widget\ViewTransitionController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */