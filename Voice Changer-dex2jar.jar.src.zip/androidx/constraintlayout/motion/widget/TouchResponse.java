package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.R;
import androidx.core.widget.NestedScrollView;
import org.xmlpull.v1.XmlPullParser;

class TouchResponse {
  public static final int COMPLETE_MODE_CONTINUOUS_VELOCITY = 0;
  
  public static final int COMPLETE_MODE_SPRING = 1;
  
  private static final boolean DEBUG = false;
  
  private static final float EPSILON = 1.0E-7F;
  
  static final int FLAG_DISABLE_POST_SCROLL = 1;
  
  static final int FLAG_DISABLE_SCROLL = 2;
  
  static final int FLAG_SUPPORT_SCROLL_UP = 4;
  
  private static final int SEC_TO_MILLISECONDS = 1000;
  
  private static final int SIDE_BOTTOM = 3;
  
  private static final int SIDE_END = 6;
  
  private static final int SIDE_LEFT = 1;
  
  private static final int SIDE_MIDDLE = 4;
  
  private static final int SIDE_RIGHT = 2;
  
  private static final int SIDE_START = 5;
  
  private static final int SIDE_TOP = 0;
  
  private static final String TAG = "TouchResponse";
  
  private static final float[][] TOUCH_DIRECTION;
  
  private static final int TOUCH_DOWN = 1;
  
  private static final int TOUCH_END = 5;
  
  private static final int TOUCH_LEFT = 2;
  
  private static final int TOUCH_RIGHT = 3;
  
  private static final float[][] TOUCH_SIDES;
  
  private static final int TOUCH_START = 4;
  
  private static final int TOUCH_UP = 0;
  
  private float[] mAnchorDpDt = new float[2];
  
  private int mAutoCompleteMode = 0;
  
  private float mDragScale = 1.0F;
  
  private boolean mDragStarted = false;
  
  private float mDragThreshold = 10.0F;
  
  private int mFlags = 0;
  
  boolean mIsRotateMode = false;
  
  private float mLastTouchX;
  
  private float mLastTouchY;
  
  private int mLimitBoundsTo = -1;
  
  private float mMaxAcceleration = 1.2F;
  
  private float mMaxVelocity = 4.0F;
  
  private final MotionLayout mMotionLayout;
  
  private boolean mMoveWhenScrollAtTop = true;
  
  private int mOnTouchUp = 0;
  
  float mRotateCenterX = 0.5F;
  
  float mRotateCenterY = 0.5F;
  
  private int mRotationCenterId = -1;
  
  private int mSpringBoundary = 0;
  
  private float mSpringDamping = 10.0F;
  
  private float mSpringMass = 1.0F;
  
  private float mSpringStiffness = Float.NaN;
  
  private float mSpringStopThreshold = Float.NaN;
  
  private int[] mTempLoc = new int[2];
  
  private int mTouchAnchorId = -1;
  
  private int mTouchAnchorSide = 0;
  
  private float mTouchAnchorX = 0.5F;
  
  private float mTouchAnchorY = 0.5F;
  
  private float mTouchDirectionX = 0.0F;
  
  private float mTouchDirectionY = 1.0F;
  
  private int mTouchRegionId = -1;
  
  private int mTouchSide = 0;
  
  static {
    float[] arrayOfFloat1 = { 0.5F, 0.0F };
    float[] arrayOfFloat2 = { 1.0F, 0.5F };
    float[] arrayOfFloat3 = { 0.5F, 1.0F };
    float[] arrayOfFloat4 = { 0.0F, 0.5F };
    float[] arrayOfFloat5 = { 1.0F, 0.5F };
    TOUCH_SIDES = new float[][] { arrayOfFloat1, { 0.0F, 0.5F }, arrayOfFloat2, arrayOfFloat3, { 0.5F, 0.5F }, arrayOfFloat4, arrayOfFloat5 };
    arrayOfFloat1 = new float[] { -1.0F, 0.0F };
    arrayOfFloat2 = new float[] { 1.0F, 0.0F };
    arrayOfFloat3 = new float[] { -1.0F, 0.0F };
    arrayOfFloat4 = new float[] { 1.0F, 0.0F };
    TOUCH_DIRECTION = new float[][] { { 0.0F, -1.0F }, { 0.0F, 1.0F }, arrayOfFloat1, arrayOfFloat2, arrayOfFloat3, arrayOfFloat4 };
  }
  
  TouchResponse(Context paramContext, MotionLayout paramMotionLayout, XmlPullParser paramXmlPullParser) {
    this.mMotionLayout = paramMotionLayout;
    fillFromAttributeList(paramContext, Xml.asAttributeSet(paramXmlPullParser));
  }
  
  public TouchResponse(MotionLayout paramMotionLayout, OnSwipe paramOnSwipe) {
    this.mMotionLayout = paramMotionLayout;
    this.mTouchAnchorId = paramOnSwipe.getTouchAnchorId();
    int i = paramOnSwipe.getTouchAnchorSide();
    this.mTouchAnchorSide = i;
    if (i != -1) {
      float[][] arrayOfFloat1 = TOUCH_SIDES;
      this.mTouchAnchorX = arrayOfFloat1[i][0];
      this.mTouchAnchorY = arrayOfFloat1[i][1];
    } 
    i = paramOnSwipe.getDragDirection();
    this.mTouchSide = i;
    float[][] arrayOfFloat = TOUCH_DIRECTION;
    if (i < arrayOfFloat.length) {
      this.mTouchDirectionX = arrayOfFloat[i][0];
      this.mTouchDirectionY = arrayOfFloat[i][1];
    } else {
      this.mTouchDirectionY = Float.NaN;
      this.mTouchDirectionX = Float.NaN;
      this.mIsRotateMode = true;
    } 
    this.mMaxVelocity = paramOnSwipe.getMaxVelocity();
    this.mMaxAcceleration = paramOnSwipe.getMaxAcceleration();
    this.mMoveWhenScrollAtTop = paramOnSwipe.getMoveWhenScrollAtTop();
    this.mDragScale = paramOnSwipe.getDragScale();
    this.mDragThreshold = paramOnSwipe.getDragThreshold();
    this.mTouchRegionId = paramOnSwipe.getTouchRegionId();
    this.mOnTouchUp = paramOnSwipe.getOnTouchUp();
    this.mFlags = paramOnSwipe.getNestedScrollFlags();
    this.mLimitBoundsTo = paramOnSwipe.getLimitBoundsTo();
    this.mRotationCenterId = paramOnSwipe.getRotationCenterId();
    this.mSpringBoundary = paramOnSwipe.getSpringBoundary();
    this.mSpringDamping = paramOnSwipe.getSpringDamping();
    this.mSpringMass = paramOnSwipe.getSpringMass();
    this.mSpringStiffness = paramOnSwipe.getSpringStiffness();
    this.mSpringStopThreshold = paramOnSwipe.getSpringStopThreshold();
    this.mAutoCompleteMode = paramOnSwipe.getAutoCompleteMode();
  }
  
  private void fill(TypedArray paramTypedArray) {
    int j = paramTypedArray.getIndexCount();
    for (int i = 0; i < j; i++) {
      int k = paramTypedArray.getIndex(i);
      if (k == R.styleable.OnSwipe_touchAnchorId) {
        this.mTouchAnchorId = paramTypedArray.getResourceId(k, this.mTouchAnchorId);
      } else if (k == R.styleable.OnSwipe_touchAnchorSide) {
        k = paramTypedArray.getInt(k, this.mTouchAnchorSide);
        this.mTouchAnchorSide = k;
        float[][] arrayOfFloat = TOUCH_SIDES;
        this.mTouchAnchorX = arrayOfFloat[k][0];
        this.mTouchAnchorY = arrayOfFloat[k][1];
      } else if (k == R.styleable.OnSwipe_dragDirection) {
        k = paramTypedArray.getInt(k, this.mTouchSide);
        this.mTouchSide = k;
        float[][] arrayOfFloat = TOUCH_DIRECTION;
        if (k < arrayOfFloat.length) {
          this.mTouchDirectionX = arrayOfFloat[k][0];
          this.mTouchDirectionY = arrayOfFloat[k][1];
        } else {
          this.mTouchDirectionY = Float.NaN;
          this.mTouchDirectionX = Float.NaN;
          this.mIsRotateMode = true;
        } 
      } else if (k == R.styleable.OnSwipe_maxVelocity) {
        this.mMaxVelocity = paramTypedArray.getFloat(k, this.mMaxVelocity);
      } else if (k == R.styleable.OnSwipe_maxAcceleration) {
        this.mMaxAcceleration = paramTypedArray.getFloat(k, this.mMaxAcceleration);
      } else if (k == R.styleable.OnSwipe_moveWhenScrollAtTop) {
        this.mMoveWhenScrollAtTop = paramTypedArray.getBoolean(k, this.mMoveWhenScrollAtTop);
      } else if (k == R.styleable.OnSwipe_dragScale) {
        this.mDragScale = paramTypedArray.getFloat(k, this.mDragScale);
      } else if (k == R.styleable.OnSwipe_dragThreshold) {
        this.mDragThreshold = paramTypedArray.getFloat(k, this.mDragThreshold);
      } else if (k == R.styleable.OnSwipe_touchRegionId) {
        this.mTouchRegionId = paramTypedArray.getResourceId(k, this.mTouchRegionId);
      } else if (k == R.styleable.OnSwipe_onTouchUp) {
        this.mOnTouchUp = paramTypedArray.getInt(k, this.mOnTouchUp);
      } else if (k == R.styleable.OnSwipe_nestedScrollFlags) {
        this.mFlags = paramTypedArray.getInteger(k, 0);
      } else if (k == R.styleable.OnSwipe_limitBoundsTo) {
        this.mLimitBoundsTo = paramTypedArray.getResourceId(k, 0);
      } else if (k == R.styleable.OnSwipe_rotationCenterId) {
        this.mRotationCenterId = paramTypedArray.getResourceId(k, this.mRotationCenterId);
      } else if (k == R.styleable.OnSwipe_springDamping) {
        this.mSpringDamping = paramTypedArray.getFloat(k, this.mSpringDamping);
      } else if (k == R.styleable.OnSwipe_springMass) {
        this.mSpringMass = paramTypedArray.getFloat(k, this.mSpringMass);
      } else if (k == R.styleable.OnSwipe_springStiffness) {
        this.mSpringStiffness = paramTypedArray.getFloat(k, this.mSpringStiffness);
      } else if (k == R.styleable.OnSwipe_springStopThreshold) {
        this.mSpringStopThreshold = paramTypedArray.getFloat(k, this.mSpringStopThreshold);
      } else if (k == R.styleable.OnSwipe_springBoundary) {
        this.mSpringBoundary = paramTypedArray.getInt(k, this.mSpringBoundary);
      } else if (k == R.styleable.OnSwipe_autoCompleteMode) {
        this.mAutoCompleteMode = paramTypedArray.getInt(k, this.mAutoCompleteMode);
      } 
    } 
  }
  
  private void fillFromAttributeList(Context paramContext, AttributeSet paramAttributeSet) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.OnSwipe);
    fill(typedArray);
    typedArray.recycle();
  }
  
  float dot(float paramFloat1, float paramFloat2) {
    return paramFloat1 * this.mTouchDirectionX + paramFloat2 * this.mTouchDirectionY;
  }
  
  public int getAnchorId() {
    return this.mTouchAnchorId;
  }
  
  public int getAutoCompleteMode() {
    return this.mAutoCompleteMode;
  }
  
  public int getFlags() {
    return this.mFlags;
  }
  
  RectF getLimitBoundsTo(ViewGroup paramViewGroup, RectF paramRectF) {
    int i = this.mLimitBoundsTo;
    if (i == -1)
      return null; 
    View view = paramViewGroup.findViewById(i);
    if (view == null)
      return null; 
    paramRectF.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    return paramRectF;
  }
  
  int getLimitBoundsToId() {
    return this.mLimitBoundsTo;
  }
  
  float getMaxAcceleration() {
    return this.mMaxAcceleration;
  }
  
  public float getMaxVelocity() {
    return this.mMaxVelocity;
  }
  
  boolean getMoveWhenScrollAtTop() {
    return this.mMoveWhenScrollAtTop;
  }
  
  float getProgressDirection(float paramFloat1, float paramFloat2) {
    float f = this.mMotionLayout.getProgress();
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    f = this.mTouchDirectionX;
    if (f != 0.0F) {
      float[] arrayOfFloat1 = this.mAnchorDpDt;
      if (arrayOfFloat1[0] == 0.0F)
        arrayOfFloat1[0] = 1.0E-7F; 
      return paramFloat1 * f / arrayOfFloat1[0];
    } 
    float[] arrayOfFloat = this.mAnchorDpDt;
    if (arrayOfFloat[1] == 0.0F)
      arrayOfFloat[1] = 1.0E-7F; 
    return paramFloat2 * this.mTouchDirectionY / arrayOfFloat[1];
  }
  
  public int getSpringBoundary() {
    return this.mSpringBoundary;
  }
  
  public float getSpringDamping() {
    return this.mSpringDamping;
  }
  
  public float getSpringMass() {
    return this.mSpringMass;
  }
  
  public float getSpringStiffness() {
    return this.mSpringStiffness;
  }
  
  public float getSpringStopThreshold() {
    return this.mSpringStopThreshold;
  }
  
  RectF getTouchRegion(ViewGroup paramViewGroup, RectF paramRectF) {
    int i = this.mTouchRegionId;
    if (i == -1)
      return null; 
    View view = paramViewGroup.findViewById(i);
    if (view == null)
      return null; 
    paramRectF.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    return paramRectF;
  }
  
  int getTouchRegionId() {
    return this.mTouchRegionId;
  }
  
  boolean isDragStarted() {
    return this.mDragStarted;
  }
  
  void processTouchEvent(MotionEvent paramMotionEvent, MotionLayout.MotionTracker paramMotionTracker, int paramInt, MotionScene paramMotionScene) {
    float[] arrayOfFloat;
    if (this.mIsRotateMode) {
      processTouchRotateEvent(paramMotionEvent, paramMotionTracker, paramInt, paramMotionScene);
      return;
    } 
    paramMotionTracker.addMovement(paramMotionEvent);
    paramInt = paramMotionEvent.getAction();
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2)
          return; 
        float f1 = paramMotionEvent.getRawY() - this.mLastTouchY;
        float f2 = paramMotionEvent.getRawX() - this.mLastTouchX;
        if (Math.abs(this.mTouchDirectionX * f2 + this.mTouchDirectionY * f1) > this.mDragThreshold || this.mDragStarted) {
          float f3 = this.mMotionLayout.getProgress();
          if (!this.mDragStarted) {
            this.mDragStarted = true;
            this.mMotionLayout.setProgress(f3);
          } 
          paramInt = this.mTouchAnchorId;
          if (paramInt != -1) {
            this.mMotionLayout.getAnchorDpDt(paramInt, f3, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
          } else {
            float f = Math.min(this.mMotionLayout.getWidth(), this.mMotionLayout.getHeight());
            float[] arrayOfFloat2 = this.mAnchorDpDt;
            arrayOfFloat2[1] = this.mTouchDirectionY * f;
            arrayOfFloat2[0] = f * this.mTouchDirectionX;
          } 
          float f4 = this.mTouchDirectionX;
          float[] arrayOfFloat1 = this.mAnchorDpDt;
          if (Math.abs((f4 * arrayOfFloat1[0] + this.mTouchDirectionY * arrayOfFloat1[1]) * this.mDragScale) < 0.01D) {
            arrayOfFloat1 = this.mAnchorDpDt;
            arrayOfFloat1[0] = 0.01F;
            arrayOfFloat1[1] = 0.01F;
          } 
          if (this.mTouchDirectionX != 0.0F) {
            f1 = f2 / this.mAnchorDpDt[0];
          } else {
            f1 /= this.mAnchorDpDt[1];
          } 
          f3 = Math.max(Math.min(f3 + f1, 1.0F), 0.0F);
          f1 = f3;
          if (this.mOnTouchUp == 6)
            f1 = Math.max(f3, 0.01F); 
          f3 = f1;
          if (this.mOnTouchUp == 7)
            f3 = Math.min(f1, 0.99F); 
          f1 = this.mMotionLayout.getProgress();
          if (f3 != f1) {
            paramInt = f1 cmp 0.0F;
            if (paramInt == 0 || f1 == 1.0F) {
              boolean bool;
              MotionLayout motionLayout = this.mMotionLayout;
              if (paramInt == 0) {
                bool = true;
              } else {
                bool = false;
              } 
              motionLayout.endTrigger(bool);
            } 
            this.mMotionLayout.setProgress(f3);
            paramMotionTracker.computeCurrentVelocity(1000);
            f1 = paramMotionTracker.getXVelocity();
            f3 = paramMotionTracker.getYVelocity();
            if (this.mTouchDirectionX != 0.0F) {
              f1 /= this.mAnchorDpDt[0];
            } else {
              f1 = f3 / this.mAnchorDpDt[1];
            } 
            this.mMotionLayout.mLastVelocity = f1;
          } else {
            this.mMotionLayout.mLastVelocity = 0.0F;
          } 
          this.mLastTouchX = paramMotionEvent.getRawX();
          this.mLastTouchY = paramMotionEvent.getRawY();
          return;
        } 
      } else {
        this.mDragStarted = false;
        paramMotionTracker.computeCurrentVelocity(1000);
        float f1 = paramMotionTracker.getXVelocity();
        float f2 = paramMotionTracker.getYVelocity();
        float f4 = this.mMotionLayout.getProgress();
        paramInt = this.mTouchAnchorId;
        if (paramInt != -1) {
          this.mMotionLayout.getAnchorDpDt(paramInt, f4, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
        } else {
          float f = Math.min(this.mMotionLayout.getWidth(), this.mMotionLayout.getHeight());
          float[] arrayOfFloat1 = this.mAnchorDpDt;
          arrayOfFloat1[1] = this.mTouchDirectionY * f;
          arrayOfFloat1[0] = f * this.mTouchDirectionX;
        } 
        float f3 = this.mTouchDirectionX;
        arrayOfFloat = this.mAnchorDpDt;
        float f5 = arrayOfFloat[0];
        f5 = arrayOfFloat[1];
        if (f3 != 0.0F) {
          f1 /= arrayOfFloat[0];
        } else {
          f1 = f2 / arrayOfFloat[1];
        } 
        if (!Float.isNaN(f1)) {
          f2 = f1 / 3.0F + f4;
        } else {
          f2 = f4;
        } 
        if (f2 != 0.0F && f2 != 1.0F) {
          paramInt = this.mOnTouchUp;
          if (paramInt != 3) {
            if (f2 < 0.5D) {
              f3 = 0.0F;
            } else {
              f3 = 1.0F;
            } 
            f2 = f1;
            if (paramInt == 6) {
              f2 = f1;
              if (f4 + f1 < 0.0F)
                f2 = Math.abs(f1); 
              f3 = 1.0F;
            } 
            f1 = f2;
            if (this.mOnTouchUp == 7) {
              f1 = f2;
              if (f4 + f2 > 1.0F)
                f1 = -Math.abs(f2); 
              f3 = 0.0F;
            } 
            this.mMotionLayout.touchAnimateTo(this.mOnTouchUp, f3, f1);
            if (0.0F >= f4 || 1.0F <= f4) {
              this.mMotionLayout.setState(MotionLayout.TransitionState.FINISHED);
              return;
            } 
            return;
          } 
        } 
        if (0.0F >= f2 || 1.0F <= f2) {
          this.mMotionLayout.setState(MotionLayout.TransitionState.FINISHED);
          return;
        } 
      } 
    } else {
      this.mLastTouchX = arrayOfFloat.getRawX();
      this.mLastTouchY = arrayOfFloat.getRawY();
      this.mDragStarted = false;
    } 
  }
  
  void processTouchRotateEvent(MotionEvent paramMotionEvent, MotionLayout.MotionTracker paramMotionTracker, int paramInt, MotionScene paramMotionScene) {
    // Byte code:
    //   0: aload_2
    //   1: aload_1
    //   2: invokeinterface addMovement : (Landroid/view/MotionEvent;)V
    //   7: aload_1
    //   8: invokevirtual getAction : ()I
    //   11: istore_3
    //   12: iconst_0
    //   13: istore #18
    //   15: iload_3
    //   16: ifeq -> 1308
    //   19: iload_3
    //   20: iconst_1
    //   21: if_icmpeq -> 706
    //   24: iload_3
    //   25: iconst_2
    //   26: if_icmpeq -> 30
    //   29: return
    //   30: aload_1
    //   31: invokevirtual getRawY : ()F
    //   34: pop
    //   35: aload_1
    //   36: invokevirtual getRawX : ()F
    //   39: pop
    //   40: aload_0
    //   41: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   44: invokevirtual getWidth : ()I
    //   47: i2f
    //   48: fconst_2
    //   49: fdiv
    //   50: fstore #13
    //   52: aload_0
    //   53: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   56: invokevirtual getHeight : ()I
    //   59: i2f
    //   60: fconst_2
    //   61: fdiv
    //   62: fstore #14
    //   64: aload_0
    //   65: getfield mRotationCenterId : I
    //   68: istore_3
    //   69: iload_3
    //   70: iconst_m1
    //   71: if_icmpeq -> 158
    //   74: aload_0
    //   75: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   78: iload_3
    //   79: invokevirtual findViewById : (I)Landroid/view/View;
    //   82: astore #4
    //   84: aload_0
    //   85: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   88: aload_0
    //   89: getfield mTempLoc : [I
    //   92: invokevirtual getLocationOnScreen : ([I)V
    //   95: aload_0
    //   96: getfield mTempLoc : [I
    //   99: iconst_0
    //   100: iaload
    //   101: i2f
    //   102: fstore #11
    //   104: aload #4
    //   106: invokevirtual getLeft : ()I
    //   109: aload #4
    //   111: invokevirtual getRight : ()I
    //   114: iadd
    //   115: i2f
    //   116: fconst_2
    //   117: fdiv
    //   118: fstore #13
    //   120: aload_0
    //   121: getfield mTempLoc : [I
    //   124: iconst_1
    //   125: iaload
    //   126: i2f
    //   127: fstore #12
    //   129: aload #4
    //   131: invokevirtual getTop : ()I
    //   134: aload #4
    //   136: invokevirtual getBottom : ()I
    //   139: iadd
    //   140: i2f
    //   141: fconst_2
    //   142: fdiv
    //   143: fload #12
    //   145: fadd
    //   146: fstore #12
    //   148: fload #11
    //   150: fload #13
    //   152: fadd
    //   153: fstore #11
    //   155: goto -> 284
    //   158: aload_0
    //   159: getfield mTouchAnchorId : I
    //   162: istore_3
    //   163: fload #13
    //   165: fstore #11
    //   167: fload #14
    //   169: fstore #12
    //   171: iload_3
    //   172: iconst_m1
    //   173: if_icmpeq -> 284
    //   176: aload_0
    //   177: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   180: iload_3
    //   181: invokevirtual getMotionController : (I)Landroidx/constraintlayout/motion/widget/MotionController;
    //   184: astore #4
    //   186: aload_0
    //   187: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   190: aload #4
    //   192: invokevirtual getAnimateRelativeTo : ()I
    //   195: invokevirtual findViewById : (I)Landroid/view/View;
    //   198: astore #4
    //   200: aload #4
    //   202: ifnonnull -> 225
    //   205: ldc 'TouchResponse'
    //   207: ldc_w 'could not find view to animate to'
    //   210: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   213: pop
    //   214: fload #13
    //   216: fstore #11
    //   218: fload #14
    //   220: fstore #12
    //   222: goto -> 284
    //   225: aload_0
    //   226: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   229: aload_0
    //   230: getfield mTempLoc : [I
    //   233: invokevirtual getLocationOnScreen : ([I)V
    //   236: aload_0
    //   237: getfield mTempLoc : [I
    //   240: iconst_0
    //   241: iaload
    //   242: i2f
    //   243: aload #4
    //   245: invokevirtual getLeft : ()I
    //   248: aload #4
    //   250: invokevirtual getRight : ()I
    //   253: iadd
    //   254: i2f
    //   255: fconst_2
    //   256: fdiv
    //   257: fadd
    //   258: fstore #11
    //   260: aload_0
    //   261: getfield mTempLoc : [I
    //   264: iconst_1
    //   265: iaload
    //   266: i2f
    //   267: aload #4
    //   269: invokevirtual getTop : ()I
    //   272: aload #4
    //   274: invokevirtual getBottom : ()I
    //   277: iadd
    //   278: i2f
    //   279: fconst_2
    //   280: fdiv
    //   281: fadd
    //   282: fstore #12
    //   284: aload_1
    //   285: invokevirtual getRawX : ()F
    //   288: fstore #15
    //   290: aload_1
    //   291: invokevirtual getRawY : ()F
    //   294: fstore #16
    //   296: aload_1
    //   297: invokevirtual getRawY : ()F
    //   300: fload #12
    //   302: fsub
    //   303: f2d
    //   304: aload_1
    //   305: invokevirtual getRawX : ()F
    //   308: fload #11
    //   310: fsub
    //   311: f2d
    //   312: invokestatic atan2 : (DD)D
    //   315: dstore #5
    //   317: dload #5
    //   319: aload_0
    //   320: getfield mLastTouchY : F
    //   323: fload #12
    //   325: fsub
    //   326: f2d
    //   327: aload_0
    //   328: getfield mLastTouchX : F
    //   331: fload #11
    //   333: fsub
    //   334: f2d
    //   335: invokestatic atan2 : (DD)D
    //   338: dsub
    //   339: ldc2_w 180.0
    //   342: dmul
    //   343: ldc2_w 3.141592653589793
    //   346: ddiv
    //   347: d2f
    //   348: fstore #14
    //   350: fload #14
    //   352: ldc_w 330.0
    //   355: fcmpl
    //   356: ifle -> 370
    //   359: fload #14
    //   361: ldc_w 360.0
    //   364: fsub
    //   365: fstore #13
    //   367: goto -> 391
    //   370: fload #14
    //   372: fstore #13
    //   374: fload #14
    //   376: ldc_w -330.0
    //   379: fcmpg
    //   380: ifge -> 391
    //   383: fload #14
    //   385: ldc_w 360.0
    //   388: fadd
    //   389: fstore #13
    //   391: fload #13
    //   393: invokestatic abs : (F)F
    //   396: f2d
    //   397: ldc2_w 0.01
    //   400: dcmpl
    //   401: ifgt -> 411
    //   404: aload_0
    //   405: getfield mDragStarted : Z
    //   408: ifeq -> 1329
    //   411: aload_0
    //   412: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   415: invokevirtual getProgress : ()F
    //   418: fstore #14
    //   420: aload_0
    //   421: getfield mDragStarted : Z
    //   424: ifne -> 441
    //   427: aload_0
    //   428: iconst_1
    //   429: putfield mDragStarted : Z
    //   432: aload_0
    //   433: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   436: fload #14
    //   438: invokevirtual setProgress : (F)V
    //   441: aload_0
    //   442: getfield mTouchAnchorId : I
    //   445: istore_3
    //   446: iload_3
    //   447: iconst_m1
    //   448: if_icmpeq -> 495
    //   451: aload_0
    //   452: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   455: iload_3
    //   456: fload #14
    //   458: aload_0
    //   459: getfield mTouchAnchorX : F
    //   462: aload_0
    //   463: getfield mTouchAnchorY : F
    //   466: aload_0
    //   467: getfield mAnchorDpDt : [F
    //   470: invokevirtual getAnchorDpDt : (IFFF[F)V
    //   473: aload_0
    //   474: getfield mAnchorDpDt : [F
    //   477: astore #4
    //   479: aload #4
    //   481: iconst_1
    //   482: aload #4
    //   484: iconst_1
    //   485: faload
    //   486: f2d
    //   487: invokestatic toDegrees : (D)D
    //   490: d2f
    //   491: fastore
    //   492: goto -> 504
    //   495: aload_0
    //   496: getfield mAnchorDpDt : [F
    //   499: iconst_1
    //   500: ldc_w 360.0
    //   503: fastore
    //   504: fload #14
    //   506: fload #13
    //   508: aload_0
    //   509: getfield mDragScale : F
    //   512: fmul
    //   513: aload_0
    //   514: getfield mAnchorDpDt : [F
    //   517: iconst_1
    //   518: faload
    //   519: fdiv
    //   520: fadd
    //   521: fconst_1
    //   522: invokestatic min : (FF)F
    //   525: fconst_0
    //   526: invokestatic max : (FF)F
    //   529: fstore #13
    //   531: aload_0
    //   532: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   535: invokevirtual getProgress : ()F
    //   538: fstore #14
    //   540: fload #13
    //   542: fload #14
    //   544: fcmpl
    //   545: ifeq -> 681
    //   548: fload #14
    //   550: fconst_0
    //   551: fcmpl
    //   552: istore_3
    //   553: iload_3
    //   554: ifeq -> 564
    //   557: fload #14
    //   559: fconst_1
    //   560: fcmpl
    //   561: ifne -> 584
    //   564: aload_0
    //   565: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   568: astore #4
    //   570: iload_3
    //   571: ifne -> 577
    //   574: iconst_1
    //   575: istore #18
    //   577: aload #4
    //   579: iload #18
    //   581: invokevirtual endTrigger : (Z)V
    //   584: aload_0
    //   585: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   588: fload #13
    //   590: invokevirtual setProgress : (F)V
    //   593: aload_2
    //   594: sipush #1000
    //   597: invokeinterface computeCurrentVelocity : (I)V
    //   602: aload_2
    //   603: invokeinterface getXVelocity : ()F
    //   608: fstore #13
    //   610: aload_2
    //   611: invokeinterface getYVelocity : ()F
    //   616: f2d
    //   617: dstore #7
    //   619: fload #13
    //   621: f2d
    //   622: dstore #9
    //   624: dload #7
    //   626: dload #9
    //   628: invokestatic hypot : (DD)D
    //   631: dload #7
    //   633: dload #9
    //   635: invokestatic atan2 : (DD)D
    //   638: dload #5
    //   640: dsub
    //   641: invokestatic sin : (D)D
    //   644: dmul
    //   645: fload #15
    //   647: fload #11
    //   649: fsub
    //   650: f2d
    //   651: fload #16
    //   653: fload #12
    //   655: fsub
    //   656: f2d
    //   657: invokestatic hypot : (DD)D
    //   660: ddiv
    //   661: d2f
    //   662: fstore #11
    //   664: aload_0
    //   665: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   668: fload #11
    //   670: f2d
    //   671: invokestatic toDegrees : (D)D
    //   674: d2f
    //   675: putfield mLastVelocity : F
    //   678: goto -> 689
    //   681: aload_0
    //   682: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   685: fconst_0
    //   686: putfield mLastVelocity : F
    //   689: aload_0
    //   690: aload_1
    //   691: invokevirtual getRawX : ()F
    //   694: putfield mLastTouchX : F
    //   697: aload_0
    //   698: aload_1
    //   699: invokevirtual getRawY : ()F
    //   702: putfield mLastTouchY : F
    //   705: return
    //   706: aload_0
    //   707: iconst_0
    //   708: putfield mDragStarted : Z
    //   711: aload_2
    //   712: bipush #16
    //   714: invokeinterface computeCurrentVelocity : (I)V
    //   719: aload_2
    //   720: invokeinterface getXVelocity : ()F
    //   725: fstore #13
    //   727: aload_2
    //   728: invokeinterface getYVelocity : ()F
    //   733: fstore #14
    //   735: aload_0
    //   736: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   739: invokevirtual getProgress : ()F
    //   742: fstore #15
    //   744: aload_0
    //   745: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   748: invokevirtual getWidth : ()I
    //   751: i2f
    //   752: fconst_2
    //   753: fdiv
    //   754: fstore #11
    //   756: aload_0
    //   757: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   760: invokevirtual getHeight : ()I
    //   763: i2f
    //   764: fconst_2
    //   765: fdiv
    //   766: fstore #12
    //   768: aload_0
    //   769: getfield mRotationCenterId : I
    //   772: istore_3
    //   773: iload_3
    //   774: iconst_m1
    //   775: if_icmpeq -> 855
    //   778: aload_0
    //   779: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   782: iload_3
    //   783: invokevirtual findViewById : (I)Landroid/view/View;
    //   786: astore_2
    //   787: aload_0
    //   788: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   791: aload_0
    //   792: getfield mTempLoc : [I
    //   795: invokevirtual getLocationOnScreen : ([I)V
    //   798: aload_0
    //   799: getfield mTempLoc : [I
    //   802: iconst_0
    //   803: iaload
    //   804: i2f
    //   805: aload_2
    //   806: invokevirtual getLeft : ()I
    //   809: aload_2
    //   810: invokevirtual getRight : ()I
    //   813: iadd
    //   814: i2f
    //   815: fconst_2
    //   816: fdiv
    //   817: fadd
    //   818: fstore #11
    //   820: aload_0
    //   821: getfield mTempLoc : [I
    //   824: iconst_1
    //   825: iaload
    //   826: i2f
    //   827: fstore #12
    //   829: aload_2
    //   830: invokevirtual getTop : ()I
    //   833: istore #17
    //   835: aload_2
    //   836: invokevirtual getBottom : ()I
    //   839: istore_3
    //   840: fload #12
    //   842: iload #17
    //   844: iload_3
    //   845: iadd
    //   846: i2f
    //   847: fconst_2
    //   848: fdiv
    //   849: fadd
    //   850: fstore #12
    //   852: goto -> 942
    //   855: aload_0
    //   856: getfield mTouchAnchorId : I
    //   859: istore_3
    //   860: iload_3
    //   861: iconst_m1
    //   862: if_icmpeq -> 942
    //   865: aload_0
    //   866: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   869: iload_3
    //   870: invokevirtual getMotionController : (I)Landroidx/constraintlayout/motion/widget/MotionController;
    //   873: astore_2
    //   874: aload_0
    //   875: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   878: aload_2
    //   879: invokevirtual getAnimateRelativeTo : ()I
    //   882: invokevirtual findViewById : (I)Landroid/view/View;
    //   885: astore_2
    //   886: aload_0
    //   887: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   890: aload_0
    //   891: getfield mTempLoc : [I
    //   894: invokevirtual getLocationOnScreen : ([I)V
    //   897: aload_0
    //   898: getfield mTempLoc : [I
    //   901: iconst_0
    //   902: iaload
    //   903: i2f
    //   904: aload_2
    //   905: invokevirtual getLeft : ()I
    //   908: aload_2
    //   909: invokevirtual getRight : ()I
    //   912: iadd
    //   913: i2f
    //   914: fconst_2
    //   915: fdiv
    //   916: fadd
    //   917: fstore #11
    //   919: aload_0
    //   920: getfield mTempLoc : [I
    //   923: iconst_1
    //   924: iaload
    //   925: i2f
    //   926: fstore #12
    //   928: aload_2
    //   929: invokevirtual getTop : ()I
    //   932: istore #17
    //   934: aload_2
    //   935: invokevirtual getBottom : ()I
    //   938: istore_3
    //   939: goto -> 840
    //   942: aload_1
    //   943: invokevirtual getRawX : ()F
    //   946: fload #11
    //   948: fsub
    //   949: fstore #11
    //   951: aload_1
    //   952: invokevirtual getRawY : ()F
    //   955: fload #12
    //   957: fsub
    //   958: fstore #12
    //   960: fload #12
    //   962: f2d
    //   963: fload #11
    //   965: f2d
    //   966: invokestatic atan2 : (DD)D
    //   969: invokestatic toDegrees : (D)D
    //   972: dstore #5
    //   974: aload_0
    //   975: getfield mTouchAnchorId : I
    //   978: istore_3
    //   979: iload_3
    //   980: iconst_m1
    //   981: if_icmpeq -> 1025
    //   984: aload_0
    //   985: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   988: iload_3
    //   989: fload #15
    //   991: aload_0
    //   992: getfield mTouchAnchorX : F
    //   995: aload_0
    //   996: getfield mTouchAnchorY : F
    //   999: aload_0
    //   1000: getfield mAnchorDpDt : [F
    //   1003: invokevirtual getAnchorDpDt : (IFFF[F)V
    //   1006: aload_0
    //   1007: getfield mAnchorDpDt : [F
    //   1010: astore_1
    //   1011: aload_1
    //   1012: iconst_1
    //   1013: aload_1
    //   1014: iconst_1
    //   1015: faload
    //   1016: f2d
    //   1017: invokestatic toDegrees : (D)D
    //   1020: d2f
    //   1021: fastore
    //   1022: goto -> 1034
    //   1025: aload_0
    //   1026: getfield mAnchorDpDt : [F
    //   1029: iconst_1
    //   1030: ldc_w 360.0
    //   1033: fastore
    //   1034: fload #14
    //   1036: fload #12
    //   1038: fadd
    //   1039: f2d
    //   1040: fload #13
    //   1042: fload #11
    //   1044: fadd
    //   1045: f2d
    //   1046: invokestatic atan2 : (DD)D
    //   1049: invokestatic toDegrees : (D)D
    //   1052: dload #5
    //   1054: dsub
    //   1055: d2f
    //   1056: ldc_w 62.5
    //   1059: fmul
    //   1060: fstore #12
    //   1062: fload #12
    //   1064: invokestatic isNaN : (F)Z
    //   1067: ifne -> 1096
    //   1070: fload #12
    //   1072: ldc_w 3.0
    //   1075: fmul
    //   1076: aload_0
    //   1077: getfield mDragScale : F
    //   1080: fmul
    //   1081: aload_0
    //   1082: getfield mAnchorDpDt : [F
    //   1085: iconst_1
    //   1086: faload
    //   1087: fdiv
    //   1088: fload #15
    //   1090: fadd
    //   1091: fstore #11
    //   1093: goto -> 1100
    //   1096: fload #15
    //   1098: fstore #11
    //   1100: fload #11
    //   1102: fconst_0
    //   1103: fcmpl
    //   1104: ifeq -> 1283
    //   1107: fload #11
    //   1109: fconst_1
    //   1110: fcmpl
    //   1111: ifeq -> 1283
    //   1114: aload_0
    //   1115: getfield mOnTouchUp : I
    //   1118: istore_3
    //   1119: iload_3
    //   1120: iconst_3
    //   1121: if_icmpeq -> 1283
    //   1124: fload #12
    //   1126: aload_0
    //   1127: getfield mDragScale : F
    //   1130: fmul
    //   1131: aload_0
    //   1132: getfield mAnchorDpDt : [F
    //   1135: iconst_1
    //   1136: faload
    //   1137: fdiv
    //   1138: fstore #13
    //   1140: fload #11
    //   1142: f2d
    //   1143: ldc2_w 0.5
    //   1146: dcmpg
    //   1147: ifge -> 1156
    //   1150: fconst_0
    //   1151: fstore #12
    //   1153: goto -> 1159
    //   1156: fconst_1
    //   1157: fstore #12
    //   1159: fload #13
    //   1161: fstore #11
    //   1163: iload_3
    //   1164: bipush #6
    //   1166: if_icmpne -> 1193
    //   1169: fload #13
    //   1171: fstore #11
    //   1173: fload #15
    //   1175: fload #13
    //   1177: fadd
    //   1178: fconst_0
    //   1179: fcmpg
    //   1180: ifge -> 1190
    //   1183: fload #13
    //   1185: invokestatic abs : (F)F
    //   1188: fstore #11
    //   1190: fconst_1
    //   1191: fstore #12
    //   1193: fload #11
    //   1195: fstore #13
    //   1197: fload #12
    //   1199: fstore #14
    //   1201: aload_0
    //   1202: getfield mOnTouchUp : I
    //   1205: bipush #7
    //   1207: if_icmpne -> 1239
    //   1210: fload #11
    //   1212: fstore #12
    //   1214: fload #15
    //   1216: fload #11
    //   1218: fadd
    //   1219: fconst_1
    //   1220: fcmpl
    //   1221: ifle -> 1232
    //   1224: fload #11
    //   1226: invokestatic abs : (F)F
    //   1229: fneg
    //   1230: fstore #12
    //   1232: fconst_0
    //   1233: fstore #14
    //   1235: fload #12
    //   1237: fstore #13
    //   1239: aload_0
    //   1240: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1243: aload_0
    //   1244: getfield mOnTouchUp : I
    //   1247: fload #14
    //   1249: fload #13
    //   1251: ldc_w 3.0
    //   1254: fmul
    //   1255: invokevirtual touchAnimateTo : (IFF)V
    //   1258: fconst_0
    //   1259: fload #15
    //   1261: fcmpl
    //   1262: ifge -> 1272
    //   1265: fconst_1
    //   1266: fload #15
    //   1268: fcmpg
    //   1269: ifgt -> 1329
    //   1272: aload_0
    //   1273: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1276: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1279: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1282: return
    //   1283: fconst_0
    //   1284: fload #11
    //   1286: fcmpl
    //   1287: ifge -> 1297
    //   1290: fconst_1
    //   1291: fload #11
    //   1293: fcmpg
    //   1294: ifgt -> 1329
    //   1297: aload_0
    //   1298: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1301: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1304: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1307: return
    //   1308: aload_0
    //   1309: aload_1
    //   1310: invokevirtual getRawX : ()F
    //   1313: putfield mLastTouchX : F
    //   1316: aload_0
    //   1317: aload_1
    //   1318: invokevirtual getRawY : ()F
    //   1321: putfield mLastTouchY : F
    //   1324: aload_0
    //   1325: iconst_0
    //   1326: putfield mDragStarted : Z
    //   1329: return
  }
  
  void scrollMove(float paramFloat1, float paramFloat2) {
    float f1 = this.mMotionLayout.getProgress();
    if (!this.mDragStarted) {
      this.mDragStarted = true;
      this.mMotionLayout.setProgress(f1);
    } 
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f1, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    float f2 = this.mTouchDirectionX;
    float[] arrayOfFloat = this.mAnchorDpDt;
    if (Math.abs(f2 * arrayOfFloat[0] + this.mTouchDirectionY * arrayOfFloat[1]) < 0.01D) {
      arrayOfFloat = this.mAnchorDpDt;
      arrayOfFloat[0] = 0.01F;
      arrayOfFloat[1] = 0.01F;
    } 
    f2 = this.mTouchDirectionX;
    if (f2 != 0.0F) {
      paramFloat1 = paramFloat1 * f2 / this.mAnchorDpDt[0];
    } else {
      paramFloat1 = paramFloat2 * this.mTouchDirectionY / this.mAnchorDpDt[1];
    } 
    paramFloat1 = Math.max(Math.min(f1 + paramFloat1, 1.0F), 0.0F);
    if (paramFloat1 != this.mMotionLayout.getProgress())
      this.mMotionLayout.setProgress(paramFloat1); 
  }
  
  void scrollUp(float paramFloat1, float paramFloat2) {
    boolean bool = false;
    this.mDragStarted = false;
    float f1 = this.mMotionLayout.getProgress();
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f1, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    float f3 = this.mTouchDirectionX;
    float[] arrayOfFloat = this.mAnchorDpDt;
    float f2 = arrayOfFloat[0];
    float f4 = this.mTouchDirectionY;
    f2 = arrayOfFloat[1];
    f2 = 0.0F;
    if (f3 != 0.0F) {
      paramFloat1 = paramFloat1 * f3 / arrayOfFloat[0];
    } else {
      paramFloat1 = paramFloat2 * f4 / arrayOfFloat[1];
    } 
    paramFloat2 = f1;
    if (!Float.isNaN(paramFloat1))
      paramFloat2 = f1 + paramFloat1 / 3.0F; 
    if (paramFloat2 != 0.0F) {
      boolean bool1;
      if (paramFloat2 != 1.0F) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      int i = this.mOnTouchUp;
      if (i != 3)
        bool = true; 
      if ((bool & bool1) != 0) {
        MotionLayout motionLayout = this.mMotionLayout;
        if (paramFloat2 < 0.5D) {
          paramFloat2 = f2;
        } else {
          paramFloat2 = 1.0F;
        } 
        motionLayout.touchAnimateTo(i, paramFloat2, paramFloat1);
      } 
    } 
  }
  
  public void setAnchorId(int paramInt) {
    this.mTouchAnchorId = paramInt;
  }
  
  void setAutoCompleteMode(int paramInt) {
    this.mAutoCompleteMode = paramInt;
  }
  
  void setDown(float paramFloat1, float paramFloat2) {
    this.mLastTouchX = paramFloat1;
    this.mLastTouchY = paramFloat2;
  }
  
  public void setMaxAcceleration(float paramFloat) {
    this.mMaxAcceleration = paramFloat;
  }
  
  public void setMaxVelocity(float paramFloat) {
    this.mMaxVelocity = paramFloat;
  }
  
  public void setRTL(boolean paramBoolean) {
    if (paramBoolean) {
      float[][] arrayOfFloat1 = TOUCH_DIRECTION;
      arrayOfFloat1[4] = arrayOfFloat1[3];
      arrayOfFloat1[5] = arrayOfFloat1[2];
      arrayOfFloat1 = TOUCH_SIDES;
      arrayOfFloat1[5] = arrayOfFloat1[2];
      arrayOfFloat1[6] = arrayOfFloat1[1];
    } else {
      float[][] arrayOfFloat1 = TOUCH_DIRECTION;
      arrayOfFloat1[4] = arrayOfFloat1[2];
      arrayOfFloat1[5] = arrayOfFloat1[3];
      arrayOfFloat1 = TOUCH_SIDES;
      arrayOfFloat1[5] = arrayOfFloat1[1];
      arrayOfFloat1[6] = arrayOfFloat1[2];
    } 
    float[][] arrayOfFloat = TOUCH_SIDES;
    int i = this.mTouchAnchorSide;
    this.mTouchAnchorX = arrayOfFloat[i][0];
    this.mTouchAnchorY = arrayOfFloat[i][1];
    i = this.mTouchSide;
    arrayOfFloat = TOUCH_DIRECTION;
    if (i >= arrayOfFloat.length)
      return; 
    this.mTouchDirectionX = arrayOfFloat[i][0];
    this.mTouchDirectionY = arrayOfFloat[i][1];
  }
  
  public void setTouchAnchorLocation(float paramFloat1, float paramFloat2) {
    this.mTouchAnchorX = paramFloat1;
    this.mTouchAnchorY = paramFloat2;
  }
  
  public void setTouchUpMode(int paramInt) {
    this.mOnTouchUp = paramInt;
  }
  
  void setUpTouchEvent(float paramFloat1, float paramFloat2) {
    this.mLastTouchX = paramFloat1;
    this.mLastTouchY = paramFloat2;
    this.mDragStarted = false;
  }
  
  void setupTouch() {
    NestedScrollView nestedScrollView;
    int i = this.mTouchAnchorId;
    if (i != -1) {
      View view = this.mMotionLayout.findViewById(i);
      nestedScrollView = (NestedScrollView)view;
      if (view == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("cannot find TouchAnchorId @id/");
        stringBuilder.append(Debug.getName(this.mMotionLayout.getContext(), this.mTouchAnchorId));
        Log.e("TouchResponse", stringBuilder.toString());
        View view1 = view;
      } 
    } else {
      nestedScrollView = null;
    } 
    if (nestedScrollView instanceof NestedScrollView) {
      nestedScrollView = nestedScrollView;
      nestedScrollView.setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              return false;
            }
          });
      nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener(this) {
            public void onScrollChange(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
          });
    } 
  }
  
  public String toString() {
    if (Float.isNaN(this.mTouchDirectionX))
      return "rotation"; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mTouchDirectionX);
    stringBuilder.append(" , ");
    stringBuilder.append(this.mTouchDirectionY);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\motion\widget\TouchResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */