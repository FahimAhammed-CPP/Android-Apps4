package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.TextView;
import androidx.constraintlayout.core.motion.utils.KeyCache;
import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Flow;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.Helper;
import androidx.constraintlayout.core.widgets.HelperWidget;
import androidx.constraintlayout.core.widgets.Placeholder;
import androidx.constraintlayout.core.widgets.VirtualLayout;
import androidx.constraintlayout.motion.utils.StopLogic;
import androidx.constraintlayout.motion.utils.ViewState;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.Constraints;
import androidx.constraintlayout.widget.R;
import androidx.core.view.NestedScrollingParent3;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class MotionLayout extends ConstraintLayout implements NestedScrollingParent3 {
  private static final boolean DEBUG = false;
  
  public static final int DEBUG_SHOW_NONE = 0;
  
  public static final int DEBUG_SHOW_PATH = 2;
  
  public static final int DEBUG_SHOW_PROGRESS = 1;
  
  private static final float EPSILON = 1.0E-5F;
  
  public static boolean IS_IN_EDIT_MODE = false;
  
  static final int MAX_KEY_FRAMES = 50;
  
  static final String TAG = "MotionLayout";
  
  public static final int TOUCH_UP_COMPLETE = 0;
  
  public static final int TOUCH_UP_COMPLETE_TO_END = 2;
  
  public static final int TOUCH_UP_COMPLETE_TO_START = 1;
  
  public static final int TOUCH_UP_DECELERATE = 4;
  
  public static final int TOUCH_UP_DECELERATE_AND_COMPLETE = 5;
  
  public static final int TOUCH_UP_NEVER_TO_END = 7;
  
  public static final int TOUCH_UP_NEVER_TO_START = 6;
  
  public static final int TOUCH_UP_STOP = 3;
  
  public static final int VELOCITY_LAYOUT = 1;
  
  public static final int VELOCITY_POST_LAYOUT = 0;
  
  public static final int VELOCITY_STATIC_LAYOUT = 3;
  
  public static final int VELOCITY_STATIC_POST_LAYOUT = 2;
  
  boolean firstDown = true;
  
  private float lastPos;
  
  private float lastY;
  
  private long mAnimationStartTime = 0L;
  
  private int mBeginState = -1;
  
  private RectF mBoundsCheck = new RectF();
  
  int mCurrentState = -1;
  
  int mDebugPath = 0;
  
  private DecelerateInterpolator mDecelerateLogic = new DecelerateInterpolator();
  
  private ArrayList<MotionHelper> mDecoratorsHelpers = null;
  
  private boolean mDelayedApply = false;
  
  private DesignTool mDesignTool;
  
  DevModeDraw mDevModeDraw;
  
  private int mEndState = -1;
  
  int mEndWrapHeight;
  
  int mEndWrapWidth;
  
  HashMap<View, MotionController> mFrameArrayList = new HashMap<View, MotionController>();
  
  private int mFrames = 0;
  
  int mHeightMeasureMode;
  
  private boolean mInLayout = false;
  
  private boolean mInRotation = false;
  
  boolean mInTransition = false;
  
  boolean mIndirectTransition = false;
  
  private boolean mInteractionEnabled = true;
  
  Interpolator mInterpolator;
  
  private Matrix mInverseMatrix = null;
  
  boolean mIsAnimating = false;
  
  private boolean mKeepAnimating = false;
  
  private KeyCache mKeyCache = new KeyCache();
  
  private long mLastDrawTime = -1L;
  
  private float mLastFps = 0.0F;
  
  private int mLastHeightMeasureSpec = 0;
  
  int mLastLayoutHeight;
  
  int mLastLayoutWidth;
  
  float mLastVelocity = 0.0F;
  
  private int mLastWidthMeasureSpec = 0;
  
  private float mListenerPosition = 0.0F;
  
  private int mListenerState = 0;
  
  protected boolean mMeasureDuringTransition = false;
  
  Model mModel = new Model();
  
  private boolean mNeedsFireTransitionCompleted = false;
  
  int mOldHeight;
  
  int mOldWidth;
  
  private Runnable mOnComplete = null;
  
  private ArrayList<MotionHelper> mOnHideHelpers = null;
  
  private ArrayList<MotionHelper> mOnShowHelpers = null;
  
  float mPostInterpolationPosition;
  
  HashMap<View, ViewState> mPreRotate = new HashMap<View, ViewState>();
  
  private int mPreRotateHeight;
  
  private int mPreRotateWidth;
  
  private int mPreviouseRotation;
  
  Interpolator mProgressInterpolator = null;
  
  private View mRegionView = null;
  
  int mRotatMode = 0;
  
  MotionScene mScene;
  
  private int[] mScheduledTransitionTo = null;
  
  int mScheduledTransitions = 0;
  
  float mScrollTargetDT;
  
  float mScrollTargetDX;
  
  float mScrollTargetDY;
  
  long mScrollTargetTime;
  
  int mStartWrapHeight;
  
  int mStartWrapWidth;
  
  private StateCache mStateCache;
  
  private StopLogic mStopLogic = new StopLogic();
  
  Rect mTempRect = new Rect();
  
  private boolean mTemporalInterpolator = false;
  
  ArrayList<Integer> mTransitionCompleted = new ArrayList<Integer>();
  
  private float mTransitionDuration = 1.0F;
  
  float mTransitionGoalPosition = 0.0F;
  
  private boolean mTransitionInstantly;
  
  float mTransitionLastPosition = 0.0F;
  
  private long mTransitionLastTime;
  
  private TransitionListener mTransitionListener;
  
  private CopyOnWriteArrayList<TransitionListener> mTransitionListeners = null;
  
  float mTransitionPosition = 0.0F;
  
  TransitionState mTransitionState = TransitionState.UNDEFINED;
  
  boolean mUndergoingMotion = false;
  
  int mWidthMeasureMode;
  
  public MotionLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null);
  }
  
  public MotionLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet);
  }
  
  public MotionLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet);
  }
  
  private boolean callTransformedTouchEvent(View paramView, MotionEvent paramMotionEvent, float paramFloat1, float paramFloat2) {
    Matrix matrix = paramView.getMatrix();
    if (matrix.isIdentity()) {
      paramMotionEvent.offsetLocation(paramFloat1, paramFloat2);
      boolean bool1 = paramView.onTouchEvent(paramMotionEvent);
      paramMotionEvent.offsetLocation(-paramFloat1, -paramFloat2);
      return bool1;
    } 
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.offsetLocation(paramFloat1, paramFloat2);
    if (this.mInverseMatrix == null)
      this.mInverseMatrix = new Matrix(); 
    matrix.invert(this.mInverseMatrix);
    paramMotionEvent.transform(this.mInverseMatrix);
    boolean bool = paramView.onTouchEvent(paramMotionEvent);
    paramMotionEvent.recycle();
    return bool;
  }
  
  private void checkStructure() {
    MotionScene motionScene = this.mScene;
    if (motionScene == null) {
      Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
      return;
    } 
    int i = motionScene.getStartId();
    motionScene = this.mScene;
    checkStructure(i, motionScene.getConstraintSet(motionScene.getStartId()));
    SparseIntArray sparseIntArray1 = new SparseIntArray();
    SparseIntArray sparseIntArray2 = new SparseIntArray();
    for (MotionScene.Transition transition : this.mScene.getDefinedTransitions()) {
      if (transition == this.mScene.mCurrentTransition)
        Log.v("MotionLayout", "CHECK: CURRENT"); 
      checkStructure(transition);
      i = transition.getStartConstraintSetId();
      int j = transition.getEndConstraintSetId();
      String str1 = Debug.getName(getContext(), i);
      String str2 = Debug.getName(getContext(), j);
      if (sparseIntArray1.get(i) == j) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: two transitions with the same start and end ");
        stringBuilder.append(str1);
        stringBuilder.append("->");
        stringBuilder.append(str2);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      if (sparseIntArray2.get(j) == i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: you can't have reverse transitions");
        stringBuilder.append(str1);
        stringBuilder.append("->");
        stringBuilder.append(str2);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      sparseIntArray1.put(i, j);
      sparseIntArray2.put(j, i);
      if (this.mScene.getConstraintSet(i) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" no such constraintSetStart ");
        stringBuilder.append(str1);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      if (this.mScene.getConstraintSet(j) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" no such constraintSetEnd ");
        stringBuilder.append(str1);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
    } 
  }
  
  private void checkStructure(int paramInt, ConstraintSet paramConstraintSet) {
    String str = Debug.getName(getContext(), paramInt);
    int j = getChildCount();
    int i = 0;
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      int k = view.getId();
      if (k == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" ALL VIEWS SHOULD HAVE ID's ");
        stringBuilder.append(view.getClass().getName());
        stringBuilder.append(" does not!");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getConstraint(k) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" NO CONSTRAINTS for ");
        stringBuilder.append(Debug.getName(view));
        Log.w("MotionLayout", stringBuilder.toString());
      } 
    } 
    int[] arrayOfInt = paramConstraintSet.getKnownIds();
    for (paramInt = i; paramInt < arrayOfInt.length; paramInt++) {
      i = arrayOfInt[paramInt];
      String str1 = Debug.getName(getContext(), i);
      if (findViewById(arrayOfInt[paramInt]) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" NO View matches id ");
        stringBuilder.append(str1);
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getHeight(i) == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(str1);
        stringBuilder.append(") no LAYOUT_HEIGHT");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getWidth(i) == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(str1);
        stringBuilder.append(") no LAYOUT_HEIGHT");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
    } 
  }
  
  private void checkStructure(MotionScene.Transition paramTransition) {
    if (paramTransition.getStartConstraintSetId() == paramTransition.getEndConstraintSetId())
      Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!"); 
  }
  
  private void computeCurrentPositions() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      MotionController motionController = this.mFrameArrayList.get(view);
      if (motionController != null)
        motionController.setStartCurrentState(view); 
    } 
  }
  
  private void debugPos() {
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getLocation());
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName((View)this));
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName(getContext(), this.mCurrentState));
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName(view));
      stringBuilder.append(view.getLeft());
      stringBuilder.append(" ");
      stringBuilder.append(view.getTop());
      Log.v("MotionLayout", stringBuilder.toString());
    } 
  }
  
  private void evaluateLayout() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionGoalPosition : F
    //   4: aload_0
    //   5: getfield mTransitionLastPosition : F
    //   8: fsub
    //   9: invokestatic signum : (F)F
    //   12: fstore_3
    //   13: aload_0
    //   14: invokevirtual getNanoTime : ()J
    //   17: lstore #7
    //   19: aload_0
    //   20: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   23: astore #9
    //   25: aload #9
    //   27: instanceof androidx/constraintlayout/motion/utils/StopLogic
    //   30: ifne -> 56
    //   33: lload #7
    //   35: aload_0
    //   36: getfield mTransitionLastTime : J
    //   39: lsub
    //   40: l2f
    //   41: fload_3
    //   42: fmul
    //   43: ldc_w 1.0E-9
    //   46: fmul
    //   47: aload_0
    //   48: getfield mTransitionDuration : F
    //   51: fdiv
    //   52: fstore_1
    //   53: goto -> 58
    //   56: fconst_0
    //   57: fstore_1
    //   58: aload_0
    //   59: getfield mTransitionLastPosition : F
    //   62: fload_1
    //   63: fadd
    //   64: fstore_2
    //   65: aload_0
    //   66: getfield mTransitionInstantly : Z
    //   69: ifeq -> 77
    //   72: aload_0
    //   73: getfield mTransitionGoalPosition : F
    //   76: fstore_2
    //   77: iconst_0
    //   78: istore #5
    //   80: fload_3
    //   81: fconst_0
    //   82: fcmpl
    //   83: istore #6
    //   85: iload #6
    //   87: ifle -> 99
    //   90: fload_2
    //   91: aload_0
    //   92: getfield mTransitionGoalPosition : F
    //   95: fcmpl
    //   96: ifge -> 114
    //   99: fload_3
    //   100: fconst_0
    //   101: fcmpg
    //   102: ifgt -> 125
    //   105: fload_2
    //   106: aload_0
    //   107: getfield mTransitionGoalPosition : F
    //   110: fcmpg
    //   111: ifgt -> 125
    //   114: aload_0
    //   115: getfield mTransitionGoalPosition : F
    //   118: fstore_2
    //   119: iconst_1
    //   120: istore #4
    //   122: goto -> 128
    //   125: iconst_0
    //   126: istore #4
    //   128: fload_2
    //   129: fstore_1
    //   130: aload #9
    //   132: ifnull -> 181
    //   135: fload_2
    //   136: fstore_1
    //   137: iload #4
    //   139: ifne -> 181
    //   142: aload_0
    //   143: getfield mTemporalInterpolator : Z
    //   146: ifeq -> 172
    //   149: aload #9
    //   151: lload #7
    //   153: aload_0
    //   154: getfield mAnimationStartTime : J
    //   157: lsub
    //   158: l2f
    //   159: ldc_w 1.0E-9
    //   162: fmul
    //   163: invokeinterface getInterpolation : (F)F
    //   168: fstore_1
    //   169: goto -> 181
    //   172: aload #9
    //   174: fload_2
    //   175: invokeinterface getInterpolation : (F)F
    //   180: fstore_1
    //   181: iload #6
    //   183: ifle -> 195
    //   186: fload_1
    //   187: aload_0
    //   188: getfield mTransitionGoalPosition : F
    //   191: fcmpl
    //   192: ifge -> 214
    //   195: fload_1
    //   196: fstore_2
    //   197: fload_3
    //   198: fconst_0
    //   199: fcmpg
    //   200: ifgt -> 219
    //   203: fload_1
    //   204: fstore_2
    //   205: fload_1
    //   206: aload_0
    //   207: getfield mTransitionGoalPosition : F
    //   210: fcmpg
    //   211: ifgt -> 219
    //   214: aload_0
    //   215: getfield mTransitionGoalPosition : F
    //   218: fstore_2
    //   219: aload_0
    //   220: fload_2
    //   221: putfield mPostInterpolationPosition : F
    //   224: aload_0
    //   225: invokevirtual getChildCount : ()I
    //   228: istore #6
    //   230: aload_0
    //   231: invokevirtual getNanoTime : ()J
    //   234: lstore #7
    //   236: aload_0
    //   237: getfield mProgressInterpolator : Landroid/view/animation/Interpolator;
    //   240: astore #9
    //   242: aload #9
    //   244: ifnonnull -> 254
    //   247: iload #5
    //   249: istore #4
    //   251: goto -> 267
    //   254: aload #9
    //   256: fload_2
    //   257: invokeinterface getInterpolation : (F)F
    //   262: fstore_2
    //   263: iload #5
    //   265: istore #4
    //   267: iload #4
    //   269: iload #6
    //   271: if_icmpge -> 325
    //   274: aload_0
    //   275: iload #4
    //   277: invokevirtual getChildAt : (I)Landroid/view/View;
    //   280: astore #9
    //   282: aload_0
    //   283: getfield mFrameArrayList : Ljava/util/HashMap;
    //   286: aload #9
    //   288: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   291: checkcast androidx/constraintlayout/motion/widget/MotionController
    //   294: astore #10
    //   296: aload #10
    //   298: ifnull -> 316
    //   301: aload #10
    //   303: aload #9
    //   305: fload_2
    //   306: lload #7
    //   308: aload_0
    //   309: getfield mKeyCache : Landroidx/constraintlayout/core/motion/utils/KeyCache;
    //   312: invokevirtual interpolate : (Landroid/view/View;FJLandroidx/constraintlayout/core/motion/utils/KeyCache;)Z
    //   315: pop
    //   316: iload #4
    //   318: iconst_1
    //   319: iadd
    //   320: istore #4
    //   322: goto -> 267
    //   325: aload_0
    //   326: getfield mMeasureDuringTransition : Z
    //   329: ifeq -> 336
    //   332: aload_0
    //   333: invokevirtual requestLayout : ()V
    //   336: return
  }
  
  private void fireTransitionChange() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield mTransitionListeners : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 219
    //   16: aload_2
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 219
    //   23: aload_0
    //   24: getfield mListenerPosition : F
    //   27: aload_0
    //   28: getfield mTransitionPosition : F
    //   31: fcmpl
    //   32: ifeq -> 219
    //   35: aload_0
    //   36: getfield mListenerState : I
    //   39: iconst_m1
    //   40: if_icmpeq -> 121
    //   43: aload_0
    //   44: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull -> 67
    //   52: aload_2
    //   53: aload_0
    //   54: aload_0
    //   55: getfield mBeginState : I
    //   58: aload_0
    //   59: getfield mEndState : I
    //   62: invokeinterface onTransitionStarted : (Landroidx/constraintlayout/motion/widget/MotionLayout;II)V
    //   67: aload_0
    //   68: getfield mTransitionListeners : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   71: astore_2
    //   72: aload_2
    //   73: ifnull -> 116
    //   76: aload_2
    //   77: invokevirtual iterator : ()Ljava/util/Iterator;
    //   80: astore_2
    //   81: aload_2
    //   82: invokeinterface hasNext : ()Z
    //   87: ifeq -> 116
    //   90: aload_2
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/motion/widget/MotionLayout$TransitionListener
    //   99: aload_0
    //   100: aload_0
    //   101: getfield mBeginState : I
    //   104: aload_0
    //   105: getfield mEndState : I
    //   108: invokeinterface onTransitionStarted : (Landroidx/constraintlayout/motion/widget/MotionLayout;II)V
    //   113: goto -> 81
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield mIsAnimating : Z
    //   121: aload_0
    //   122: iconst_m1
    //   123: putfield mListenerState : I
    //   126: aload_0
    //   127: getfield mTransitionPosition : F
    //   130: fstore_1
    //   131: aload_0
    //   132: fload_1
    //   133: putfield mListenerPosition : F
    //   136: aload_0
    //   137: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 161
    //   145: aload_2
    //   146: aload_0
    //   147: aload_0
    //   148: getfield mBeginState : I
    //   151: aload_0
    //   152: getfield mEndState : I
    //   155: fload_1
    //   156: invokeinterface onTransitionChange : (Landroidx/constraintlayout/motion/widget/MotionLayout;IIF)V
    //   161: aload_0
    //   162: getfield mTransitionListeners : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 214
    //   170: aload_2
    //   171: invokevirtual iterator : ()Ljava/util/Iterator;
    //   174: astore_2
    //   175: aload_2
    //   176: invokeinterface hasNext : ()Z
    //   181: ifeq -> 214
    //   184: aload_2
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: checkcast androidx/constraintlayout/motion/widget/MotionLayout$TransitionListener
    //   193: aload_0
    //   194: aload_0
    //   195: getfield mBeginState : I
    //   198: aload_0
    //   199: getfield mEndState : I
    //   202: aload_0
    //   203: getfield mTransitionPosition : F
    //   206: invokeinterface onTransitionChange : (Landroidx/constraintlayout/motion/widget/MotionLayout;IIF)V
    //   211: goto -> 175
    //   214: aload_0
    //   215: iconst_1
    //   216: putfield mIsAnimating : Z
    //   219: return
  }
  
  private void fireTransitionStarted(MotionLayout paramMotionLayout, int paramInt1, int paramInt2) {
    TransitionListener transitionListener = this.mTransitionListener;
    if (transitionListener != null)
      transitionListener.onTransitionStarted(this, paramInt1, paramInt2); 
    CopyOnWriteArrayList<TransitionListener> copyOnWriteArrayList = this.mTransitionListeners;
    if (copyOnWriteArrayList != null) {
      Iterator<TransitionListener> iterator = copyOnWriteArrayList.iterator();
      while (iterator.hasNext())
        ((TransitionListener)iterator.next()).onTransitionStarted(paramMotionLayout, paramInt1, paramInt2); 
    } 
  }
  
  private boolean handlesTouchEvent(float paramFloat1, float paramFloat2, View paramView, MotionEvent paramMotionEvent) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i;
      for (i = viewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = viewGroup.getChildAt(i);
        if (handlesTouchEvent(view.getLeft() + paramFloat1 - paramView.getScrollX(), view.getTop() + paramFloat2 - paramView.getScrollY(), view, paramMotionEvent)) {
          boolean bool1 = true;
          // Byte code: goto -> 93
        } 
      } 
    } 
    boolean bool = false;
    if (!bool) {
      this.mBoundsCheck.set(paramFloat1, paramFloat2, paramView.getRight() + paramFloat1 - paramView.getLeft(), paramView.getBottom() + paramFloat2 - paramView.getTop());
      if ((paramMotionEvent.getAction() != 0 || this.mBoundsCheck.contains(paramMotionEvent.getX(), paramMotionEvent.getY())) && callTransformedTouchEvent(paramView, paramMotionEvent, -paramFloat1, -paramFloat2))
        return true; 
    } 
    return bool;
  }
  
  private void init(AttributeSet paramAttributeSet) {
    IS_IN_EDIT_MODE = isInEditMode();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.MotionLayout);
      int j = typedArray.getIndexCount();
      int i = 0;
      boolean bool;
      for (bool = true; i < j; bool = bool1) {
        boolean bool1;
        int k = typedArray.getIndex(i);
        if (k == R.styleable.MotionLayout_layoutDescription) {
          k = typedArray.getResourceId(k, -1);
          this.mScene = new MotionScene(getContext(), this, k);
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_currentState) {
          this.mCurrentState = typedArray.getResourceId(k, -1);
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_motionProgress) {
          this.mTransitionGoalPosition = typedArray.getFloat(k, 0.0F);
          this.mInTransition = true;
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_applyMotionScene) {
          bool1 = typedArray.getBoolean(k, bool);
        } else if (k == R.styleable.MotionLayout_showPaths) {
          bool1 = bool;
          if (this.mDebugPath == 0) {
            if (typedArray.getBoolean(k, false)) {
              k = 2;
            } else {
              k = 0;
            } 
            this.mDebugPath = k;
            bool1 = bool;
          } 
        } else {
          bool1 = bool;
          if (k == R.styleable.MotionLayout_motionDebug) {
            this.mDebugPath = typedArray.getInt(k, 0);
            bool1 = bool;
          } 
        } 
        i++;
      } 
      typedArray.recycle();
      if (this.mScene == null)
        Log.e("MotionLayout", "WARNING NO app:layoutDescription tag"); 
      if (!bool)
        this.mScene = null; 
    } 
    if (this.mDebugPath != 0)
      checkStructure(); 
    if (this.mCurrentState == -1) {
      MotionScene motionScene = this.mScene;
      if (motionScene != null) {
        this.mCurrentState = motionScene.getStartId();
        this.mBeginState = this.mScene.getStartId();
        this.mEndState = this.mScene.getEndId();
      } 
    } 
  }
  
  private void processTransitionCompleted() {
    if (this.mTransitionListener == null) {
      CopyOnWriteArrayList<TransitionListener> copyOnWriteArrayList = this.mTransitionListeners;
      if (copyOnWriteArrayList == null || copyOnWriteArrayList.isEmpty())
        return; 
    } 
    this.mIsAnimating = false;
    for (Integer integer : this.mTransitionCompleted) {
      TransitionListener transitionListener = this.mTransitionListener;
      if (transitionListener != null)
        transitionListener.onTransitionCompleted(this, integer.intValue()); 
      CopyOnWriteArrayList<TransitionListener> copyOnWriteArrayList = this.mTransitionListeners;
      if (copyOnWriteArrayList != null) {
        Iterator<TransitionListener> iterator = copyOnWriteArrayList.iterator();
        while (iterator.hasNext())
          ((TransitionListener)iterator.next()).onTransitionCompleted(this, integer.intValue()); 
      } 
    } 
    this.mTransitionCompleted.clear();
  }
  
  private void setupMotionViews() {
    int k = getChildCount();
    this.mModel.build();
    boolean bool = true;
    this.mInTransition = true;
    SparseArray sparseArray = new SparseArray();
    byte b2 = 0;
    byte b1 = 0;
    int i;
    for (i = 0; i < k; i++) {
      View view = getChildAt(i);
      sparseArray.put(view.getId(), this.mFrameArrayList.get(view));
    } 
    int m = getWidth();
    int n = getHeight();
    int j = this.mScene.gatPathMotionArc();
    if (j != -1)
      for (i = 0; i < k; i++) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(i));
        if (motionController != null)
          motionController.setPathMotionArc(j); 
      }  
    SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
    int[] arrayOfInt = new int[this.mFrameArrayList.size()];
    j = 0;
    for (i = 0; j < k; i = i1) {
      View view = getChildAt(j);
      MotionController motionController = this.mFrameArrayList.get(view);
      int i1 = i;
      if (motionController.getAnimateRelativeTo() != -1) {
        sparseBooleanArray.put(motionController.getAnimateRelativeTo(), true);
        arrayOfInt[i] = motionController.getAnimateRelativeTo();
        i1 = i + 1;
      } 
      j++;
    } 
    if (this.mDecoratorsHelpers != null) {
      for (j = 0; j < i; j++) {
        MotionController motionController = this.mFrameArrayList.get(findViewById(arrayOfInt[j]));
        if (motionController != null)
          this.mScene.getKeyFrames(motionController); 
      } 
      Iterator<MotionHelper> iterator = this.mDecoratorsHelpers.iterator();
      while (iterator.hasNext())
        ((MotionHelper)iterator.next()).onPreSetup(this, this.mFrameArrayList); 
      for (j = 0; j < i; j++) {
        MotionController motionController = this.mFrameArrayList.get(findViewById(arrayOfInt[j]));
        if (motionController != null)
          motionController.setup(m, n, this.mTransitionDuration, getNanoTime()); 
      } 
    } else {
      for (j = 0; j < i; j++) {
        MotionController motionController = this.mFrameArrayList.get(findViewById(arrayOfInt[j]));
        if (motionController != null) {
          this.mScene.getKeyFrames(motionController);
          motionController.setup(m, n, this.mTransitionDuration, getNanoTime());
        } 
      } 
    } 
    for (i = 0; i < k; i++) {
      View view = getChildAt(i);
      MotionController motionController = this.mFrameArrayList.get(view);
      if (!sparseBooleanArray.get(view.getId()) && motionController != null) {
        this.mScene.getKeyFrames(motionController);
        motionController.setup(m, n, this.mTransitionDuration, getNanoTime());
      } 
    } 
    float f = this.mScene.getStaggered();
    if (f != 0.0F) {
      if (f < 0.0D) {
        i = 1;
      } else {
        i = 0;
      } 
      float f4 = Math.abs(f);
      float f2 = -3.4028235E38F;
      float f3 = Float.MAX_VALUE;
      j = 0;
      float f1 = Float.MAX_VALUE;
      f = -3.4028235E38F;
      while (true) {
        if (j < k) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(j));
          if (!Float.isNaN(motionController.mMotionStagger)) {
            j = bool;
            break;
          } 
          float f5 = motionController.getFinalX();
          float f6 = motionController.getFinalY();
          if (i != 0) {
            f5 = f6 - f5;
          } else {
            f5 = f6 + f5;
          } 
          f1 = Math.min(f1, f5);
          f = Math.max(f, f5);
          j++;
          continue;
        } 
        j = 0;
        break;
      } 
      int i1 = b2;
      if (j != 0) {
        j = 0;
        f1 = f3;
        f = f2;
        while (true) {
          i1 = b1;
          if (j < k) {
            MotionController motionController = this.mFrameArrayList.get(getChildAt(j));
            f2 = f;
            float f5 = f1;
            if (!Float.isNaN(motionController.mMotionStagger)) {
              f5 = Math.min(f1, motionController.mMotionStagger);
              f2 = Math.max(f, motionController.mMotionStagger);
            } 
            j++;
            f = f2;
            f1 = f5;
            continue;
          } 
          break;
        } 
        while (i1 < k) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(i1));
          if (!Float.isNaN(motionController.mMotionStagger)) {
            motionController.mStaggerScale = 1.0F / (1.0F - f4);
            if (i != 0) {
              motionController.mStaggerOffset = f4 - (f - motionController.mMotionStagger) / (f - f1) * f4;
            } else {
              motionController.mStaggerOffset = f4 - (motionController.mMotionStagger - f1) * f4 / (f - f1);
            } 
          } 
          i1++;
        } 
      } else {
        while (i1 < k) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(i1));
          float f5 = motionController.getFinalX();
          f2 = motionController.getFinalY();
          if (i != 0) {
            f5 = f2 - f5;
          } else {
            f5 = f2 + f5;
          } 
          motionController.mStaggerScale = 1.0F / (1.0F - f4);
          motionController.mStaggerOffset = f4 - (f5 - f1) * f4 / (f - f1);
          i1++;
        } 
      } 
    } 
  }
  
  private Rect toRect(ConstraintWidget paramConstraintWidget) {
    this.mTempRect.top = paramConstraintWidget.getY();
    this.mTempRect.left = paramConstraintWidget.getX();
    this.mTempRect.right = paramConstraintWidget.getWidth() + this.mTempRect.left;
    this.mTempRect.bottom = paramConstraintWidget.getHeight() + this.mTempRect.top;
    return this.mTempRect;
  }
  
  private static boolean willJump(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 > 0.0F) {
      float f1 = paramFloat1 / paramFloat3;
      return (paramFloat2 + paramFloat1 * f1 - paramFloat3 * f1 * f1 / 2.0F > 1.0F);
    } 
    float f = -paramFloat1 / paramFloat3;
    return (paramFloat2 + paramFloat1 * f + paramFloat3 * f * f / 2.0F < 0.0F);
  }
  
  public void addTransitionListener(TransitionListener paramTransitionListener) {
    if (this.mTransitionListeners == null)
      this.mTransitionListeners = new CopyOnWriteArrayList<TransitionListener>(); 
    this.mTransitionListeners.add(paramTransitionListener);
  }
  
  void animateTo(float paramFloat) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    float f1 = this.mTransitionLastPosition;
    float f2 = this.mTransitionPosition;
    if (f1 != f2 && this.mTransitionInstantly)
      this.mTransitionLastPosition = f2; 
    f1 = this.mTransitionLastPosition;
    if (f1 == paramFloat)
      return; 
    this.mTemporalInterpolator = false;
    this.mTransitionGoalPosition = paramFloat;
    this.mTransitionDuration = motionScene.getDuration() / 1000.0F;
    setProgress(this.mTransitionGoalPosition);
    this.mInterpolator = null;
    this.mProgressInterpolator = this.mScene.getInterpolator();
    this.mTransitionInstantly = false;
    this.mAnimationStartTime = getNanoTime();
    this.mInTransition = true;
    this.mTransitionPosition = f1;
    this.mTransitionLastPosition = f1;
    invalidate();
  }
  
  public boolean applyViewTransition(int paramInt, MotionController paramMotionController) {
    MotionScene motionScene = this.mScene;
    return (motionScene != null) ? motionScene.applyViewTransition(paramInt, paramMotionController) : false;
  }
  
  public ConstraintSet cloneConstraintSet(int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return null; 
    ConstraintSet constraintSet1 = motionScene.getConstraintSet(paramInt);
    ConstraintSet constraintSet2 = new ConstraintSet();
    constraintSet2.clone(constraintSet1);
    return constraintSet2;
  }
  
  void disableAutoTransition(boolean paramBoolean) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    motionScene.disableAutoTransition(paramBoolean);
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<MotionHelper> arrayList2 = this.mDecoratorsHelpers;
    if (arrayList2 != null) {
      Iterator<MotionHelper> iterator = arrayList2.iterator();
      while (iterator.hasNext())
        ((MotionHelper)iterator.next()).onPreDraw(paramCanvas); 
    } 
    evaluate(false);
    MotionScene motionScene = this.mScene;
    if (motionScene != null && motionScene.mViewTransitionController != null)
      this.mScene.mViewTransitionController.animate(); 
    super.dispatchDraw(paramCanvas);
    if (this.mScene == null)
      return; 
    if ((this.mDebugPath & 0x1) == 1 && !isInEditMode()) {
      this.mFrames++;
      long l1 = getNanoTime();
      long l2 = this.mLastDrawTime;
      if (l2 != -1L) {
        l2 = l1 - l2;
        if (l2 > 200000000L) {
          this.mLastFps = (int)(this.mFrames / (float)l2 * 1.0E-9F * 100.0F) / 100.0F;
          this.mFrames = 0;
          this.mLastDrawTime = l1;
        } 
      } else {
        this.mLastDrawTime = l1;
      } 
      Paint paint = new Paint();
      paint.setTextSize(42.0F);
      float f = (int)(getProgress() * 1000.0F) / 10.0F;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(this.mLastFps);
      stringBuilder1.append(" fps ");
      stringBuilder1.append(Debug.getState(this, this.mBeginState));
      stringBuilder1.append(" -> ");
      String str = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(Debug.getState(this, this.mEndState));
      stringBuilder2.append(" (progress: ");
      stringBuilder2.append(f);
      stringBuilder2.append(" ) state=");
      int i = this.mCurrentState;
      if (i == -1) {
        str = "undefined";
      } else {
        str = Debug.getState(this, i);
      } 
      stringBuilder2.append(str);
      str = stringBuilder2.toString();
      paint.setColor(-16777216);
      paramCanvas.drawText(str, 11.0F, (getHeight() - 29), paint);
      paint.setColor(-7864184);
      paramCanvas.drawText(str, 10.0F, (getHeight() - 30), paint);
    } 
    if (this.mDebugPath > 1) {
      if (this.mDevModeDraw == null)
        this.mDevModeDraw = new DevModeDraw(); 
      this.mDevModeDraw.draw(paramCanvas, this.mFrameArrayList, this.mScene.getDuration(), this.mDebugPath);
    } 
    ArrayList<MotionHelper> arrayList1 = this.mDecoratorsHelpers;
    if (arrayList1 != null) {
      Iterator<MotionHelper> iterator = arrayList1.iterator();
      while (iterator.hasNext())
        ((MotionHelper)iterator.next()).onPostDraw(paramCanvas); 
    } 
  }
  
  public void enableTransition(int paramInt, boolean paramBoolean) {
    MotionScene.Transition transition = getTransition(paramInt);
    if (paramBoolean) {
      transition.setEnabled(true);
      return;
    } 
    if (transition == this.mScene.mCurrentTransition)
      for (MotionScene.Transition transition1 : this.mScene.getTransitionsWithState(this.mCurrentState)) {
        if (transition1.isEnabled()) {
          this.mScene.mCurrentTransition = transition1;
          break;
        } 
      }  
    transition.setEnabled(false);
  }
  
  public void enableViewTransition(int paramInt, boolean paramBoolean) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.enableViewTransition(paramInt, paramBoolean); 
  }
  
  void endTrigger(boolean paramBoolean) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      MotionController motionController = this.mFrameArrayList.get(view);
      if (motionController != null)
        motionController.endTrigger(paramBoolean); 
    } 
  }
  
  void evaluate(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionLastTime : J
    //   4: ldc2_w -1
    //   7: lcmp
    //   8: ifne -> 19
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getNanoTime : ()J
    //   16: putfield mTransitionLastTime : J
    //   19: aload_0
    //   20: getfield mTransitionLastPosition : F
    //   23: fstore_2
    //   24: fload_2
    //   25: fconst_0
    //   26: fcmpl
    //   27: ifle -> 41
    //   30: fload_2
    //   31: fconst_1
    //   32: fcmpg
    //   33: ifge -> 41
    //   36: aload_0
    //   37: iconst_m1
    //   38: putfield mCurrentState : I
    //   41: aload_0
    //   42: getfield mKeepAnimating : Z
    //   45: istore #14
    //   47: iconst_1
    //   48: istore #9
    //   50: iconst_1
    //   51: istore #10
    //   53: iconst_0
    //   54: istore #11
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #14
    //   61: ifne -> 92
    //   64: iload #11
    //   66: istore #7
    //   68: aload_0
    //   69: getfield mInTransition : Z
    //   72: ifeq -> 1149
    //   75: iload_1
    //   76: ifne -> 92
    //   79: iload #11
    //   81: istore #7
    //   83: aload_0
    //   84: getfield mTransitionGoalPosition : F
    //   87: fload_2
    //   88: fcmpl
    //   89: ifeq -> 1149
    //   92: aload_0
    //   93: getfield mTransitionGoalPosition : F
    //   96: fload_2
    //   97: fsub
    //   98: invokestatic signum : (F)F
    //   101: fstore #5
    //   103: aload_0
    //   104: invokevirtual getNanoTime : ()J
    //   107: lstore #15
    //   109: aload_0
    //   110: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   113: astore #17
    //   115: aload #17
    //   117: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   120: ifne -> 147
    //   123: lload #15
    //   125: aload_0
    //   126: getfield mTransitionLastTime : J
    //   129: lsub
    //   130: l2f
    //   131: fload #5
    //   133: fmul
    //   134: ldc_w 1.0E-9
    //   137: fmul
    //   138: aload_0
    //   139: getfield mTransitionDuration : F
    //   142: fdiv
    //   143: fstore_3
    //   144: goto -> 149
    //   147: fconst_0
    //   148: fstore_3
    //   149: aload_0
    //   150: getfield mTransitionLastPosition : F
    //   153: fload_3
    //   154: fadd
    //   155: fstore_2
    //   156: aload_0
    //   157: getfield mTransitionInstantly : Z
    //   160: ifeq -> 168
    //   163: aload_0
    //   164: getfield mTransitionGoalPosition : F
    //   167: fstore_2
    //   168: fload #5
    //   170: fconst_0
    //   171: fcmpl
    //   172: istore #11
    //   174: iload #11
    //   176: ifle -> 188
    //   179: fload_2
    //   180: aload_0
    //   181: getfield mTransitionGoalPosition : F
    //   184: fcmpl
    //   185: ifge -> 204
    //   188: fload #5
    //   190: fconst_0
    //   191: fcmpg
    //   192: ifgt -> 220
    //   195: fload_2
    //   196: aload_0
    //   197: getfield mTransitionGoalPosition : F
    //   200: fcmpg
    //   201: ifgt -> 220
    //   204: aload_0
    //   205: getfield mTransitionGoalPosition : F
    //   208: fstore_2
    //   209: aload_0
    //   210: iconst_0
    //   211: putfield mInTransition : Z
    //   214: iconst_1
    //   215: istore #7
    //   217: goto -> 223
    //   220: iconst_0
    //   221: istore #7
    //   223: aload_0
    //   224: fload_2
    //   225: putfield mTransitionLastPosition : F
    //   228: aload_0
    //   229: fload_2
    //   230: putfield mTransitionPosition : F
    //   233: aload_0
    //   234: lload #15
    //   236: putfield mTransitionLastTime : J
    //   239: aload #17
    //   241: ifnull -> 527
    //   244: iload #7
    //   246: ifne -> 527
    //   249: aload_0
    //   250: getfield mTemporalInterpolator : Z
    //   253: ifeq -> 460
    //   256: aload #17
    //   258: lload #15
    //   260: aload_0
    //   261: getfield mAnimationStartTime : J
    //   264: lsub
    //   265: l2f
    //   266: ldc_w 1.0E-9
    //   269: fmul
    //   270: invokeinterface getInterpolation : (F)F
    //   275: fstore #4
    //   277: aload_0
    //   278: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   281: astore #17
    //   283: aload_0
    //   284: getfield mStopLogic : Landroidx/constraintlayout/motion/utils/StopLogic;
    //   287: astore #18
    //   289: aload #17
    //   291: aload #18
    //   293: if_acmpne -> 316
    //   296: aload #18
    //   298: invokevirtual isStopped : ()Z
    //   301: ifeq -> 310
    //   304: iconst_2
    //   305: istore #7
    //   307: goto -> 319
    //   310: iconst_1
    //   311: istore #7
    //   313: goto -> 319
    //   316: iconst_0
    //   317: istore #7
    //   319: aload_0
    //   320: fload #4
    //   322: putfield mTransitionLastPosition : F
    //   325: aload_0
    //   326: lload #15
    //   328: putfield mTransitionLastTime : J
    //   331: aload_0
    //   332: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   335: astore #17
    //   337: fload #4
    //   339: fstore_3
    //   340: aload #17
    //   342: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   345: ifeq -> 455
    //   348: aload #17
    //   350: checkcast androidx/constraintlayout/motion/widget/MotionInterpolator
    //   353: invokevirtual getVelocity : ()F
    //   356: fstore #6
    //   358: aload_0
    //   359: fload #6
    //   361: putfield mLastVelocity : F
    //   364: fload #6
    //   366: invokestatic abs : (F)F
    //   369: aload_0
    //   370: getfield mTransitionDuration : F
    //   373: fmul
    //   374: ldc 1.0E-5
    //   376: fcmpg
    //   377: ifgt -> 391
    //   380: iload #7
    //   382: iconst_2
    //   383: if_icmpne -> 391
    //   386: aload_0
    //   387: iconst_0
    //   388: putfield mInTransition : Z
    //   391: fload #4
    //   393: fstore_2
    //   394: fload #6
    //   396: fconst_0
    //   397: fcmpl
    //   398: ifle -> 423
    //   401: fload #4
    //   403: fstore_2
    //   404: fload #4
    //   406: fconst_1
    //   407: fcmpl
    //   408: iflt -> 423
    //   411: aload_0
    //   412: fconst_1
    //   413: putfield mTransitionLastPosition : F
    //   416: aload_0
    //   417: iconst_0
    //   418: putfield mInTransition : Z
    //   421: fconst_1
    //   422: fstore_2
    //   423: fload_2
    //   424: fstore_3
    //   425: fload #6
    //   427: fconst_0
    //   428: fcmpg
    //   429: ifge -> 455
    //   432: fload_2
    //   433: fstore_3
    //   434: fload_2
    //   435: fconst_0
    //   436: fcmpg
    //   437: ifgt -> 455
    //   440: aload_0
    //   441: fconst_0
    //   442: putfield mTransitionLastPosition : F
    //   445: aload_0
    //   446: iconst_0
    //   447: putfield mInTransition : Z
    //   450: fconst_0
    //   451: fstore_2
    //   452: goto -> 535
    //   455: fload_3
    //   456: fstore_2
    //   457: goto -> 535
    //   460: aload #17
    //   462: fload_2
    //   463: invokeinterface getInterpolation : (F)F
    //   468: fstore #4
    //   470: aload_0
    //   471: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   474: astore #17
    //   476: aload #17
    //   478: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   481: ifeq -> 499
    //   484: aload_0
    //   485: aload #17
    //   487: checkcast androidx/constraintlayout/motion/widget/MotionInterpolator
    //   490: invokevirtual getVelocity : ()F
    //   493: putfield mLastVelocity : F
    //   496: goto -> 521
    //   499: aload_0
    //   500: aload #17
    //   502: fload_2
    //   503: fload_3
    //   504: fadd
    //   505: invokeinterface getInterpolation : (F)F
    //   510: fload #4
    //   512: fsub
    //   513: fload #5
    //   515: fmul
    //   516: fload_3
    //   517: fdiv
    //   518: putfield mLastVelocity : F
    //   521: fload #4
    //   523: fstore_2
    //   524: goto -> 532
    //   527: aload_0
    //   528: fload_3
    //   529: putfield mLastVelocity : F
    //   532: iconst_0
    //   533: istore #7
    //   535: aload_0
    //   536: getfield mLastVelocity : F
    //   539: invokestatic abs : (F)F
    //   542: ldc 1.0E-5
    //   544: fcmpl
    //   545: ifle -> 555
    //   548: aload_0
    //   549: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.MOVING : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   552: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   555: fload_2
    //   556: fstore_3
    //   557: iload #7
    //   559: iconst_1
    //   560: if_icmpeq -> 642
    //   563: iload #11
    //   565: ifle -> 577
    //   568: fload_2
    //   569: aload_0
    //   570: getfield mTransitionGoalPosition : F
    //   573: fcmpl
    //   574: ifge -> 599
    //   577: fload_2
    //   578: fstore #4
    //   580: fload #5
    //   582: fconst_0
    //   583: fcmpg
    //   584: ifgt -> 610
    //   587: fload_2
    //   588: fstore #4
    //   590: fload_2
    //   591: aload_0
    //   592: getfield mTransitionGoalPosition : F
    //   595: fcmpg
    //   596: ifgt -> 610
    //   599: aload_0
    //   600: getfield mTransitionGoalPosition : F
    //   603: fstore #4
    //   605: aload_0
    //   606: iconst_0
    //   607: putfield mInTransition : Z
    //   610: fload #4
    //   612: fconst_1
    //   613: fcmpl
    //   614: ifge -> 627
    //   617: fload #4
    //   619: fstore_3
    //   620: fload #4
    //   622: fconst_0
    //   623: fcmpg
    //   624: ifgt -> 642
    //   627: aload_0
    //   628: iconst_0
    //   629: putfield mInTransition : Z
    //   632: aload_0
    //   633: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   636: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   639: fload #4
    //   641: fstore_3
    //   642: aload_0
    //   643: invokevirtual getChildCount : ()I
    //   646: istore #12
    //   648: aload_0
    //   649: iconst_0
    //   650: putfield mKeepAnimating : Z
    //   653: aload_0
    //   654: invokevirtual getNanoTime : ()J
    //   657: lstore #15
    //   659: aload_0
    //   660: fload_3
    //   661: putfield mPostInterpolationPosition : F
    //   664: aload_0
    //   665: getfield mProgressInterpolator : Landroid/view/animation/Interpolator;
    //   668: astore #17
    //   670: aload #17
    //   672: ifnonnull -> 680
    //   675: fload_3
    //   676: fstore_2
    //   677: goto -> 689
    //   680: aload #17
    //   682: fload_3
    //   683: invokeinterface getInterpolation : (F)F
    //   688: fstore_2
    //   689: aload_0
    //   690: getfield mProgressInterpolator : Landroid/view/animation/Interpolator;
    //   693: astore #17
    //   695: aload #17
    //   697: ifnull -> 741
    //   700: aload #17
    //   702: fload #5
    //   704: aload_0
    //   705: getfield mTransitionDuration : F
    //   708: fdiv
    //   709: fload_3
    //   710: fadd
    //   711: invokeinterface getInterpolation : (F)F
    //   716: fstore #4
    //   718: aload_0
    //   719: fload #4
    //   721: putfield mLastVelocity : F
    //   724: aload_0
    //   725: fload #4
    //   727: aload_0
    //   728: getfield mProgressInterpolator : Landroid/view/animation/Interpolator;
    //   731: fload_3
    //   732: invokeinterface getInterpolation : (F)F
    //   737: fsub
    //   738: putfield mLastVelocity : F
    //   741: iconst_0
    //   742: istore #7
    //   744: iload #7
    //   746: iload #12
    //   748: if_icmpge -> 812
    //   751: aload_0
    //   752: iload #7
    //   754: invokevirtual getChildAt : (I)Landroid/view/View;
    //   757: astore #17
    //   759: aload_0
    //   760: getfield mFrameArrayList : Ljava/util/HashMap;
    //   763: aload #17
    //   765: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   768: checkcast androidx/constraintlayout/motion/widget/MotionController
    //   771: astore #18
    //   773: aload #18
    //   775: ifnull -> 803
    //   778: aload_0
    //   779: getfield mKeepAnimating : Z
    //   782: istore_1
    //   783: aload_0
    //   784: aload #18
    //   786: aload #17
    //   788: fload_2
    //   789: lload #15
    //   791: aload_0
    //   792: getfield mKeyCache : Landroidx/constraintlayout/core/motion/utils/KeyCache;
    //   795: invokevirtual interpolate : (Landroid/view/View;FJLandroidx/constraintlayout/core/motion/utils/KeyCache;)Z
    //   798: iload_1
    //   799: ior
    //   800: putfield mKeepAnimating : Z
    //   803: iload #7
    //   805: iconst_1
    //   806: iadd
    //   807: istore #7
    //   809: goto -> 744
    //   812: iload #11
    //   814: ifle -> 826
    //   817: fload_3
    //   818: aload_0
    //   819: getfield mTransitionGoalPosition : F
    //   822: fcmpl
    //   823: ifge -> 842
    //   826: fload #5
    //   828: fconst_0
    //   829: fcmpg
    //   830: ifgt -> 848
    //   833: fload_3
    //   834: aload_0
    //   835: getfield mTransitionGoalPosition : F
    //   838: fcmpg
    //   839: ifgt -> 848
    //   842: iconst_1
    //   843: istore #7
    //   845: goto -> 851
    //   848: iconst_0
    //   849: istore #7
    //   851: aload_0
    //   852: getfield mKeepAnimating : Z
    //   855: ifne -> 877
    //   858: aload_0
    //   859: getfield mInTransition : Z
    //   862: ifne -> 877
    //   865: iload #7
    //   867: ifeq -> 877
    //   870: aload_0
    //   871: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   874: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   877: aload_0
    //   878: getfield mMeasureDuringTransition : Z
    //   881: ifeq -> 888
    //   884: aload_0
    //   885: invokevirtual requestLayout : ()V
    //   888: aload_0
    //   889: iload #7
    //   891: iconst_1
    //   892: ixor
    //   893: aload_0
    //   894: getfield mKeepAnimating : Z
    //   897: ior
    //   898: putfield mKeepAnimating : Z
    //   901: iload #8
    //   903: istore #7
    //   905: fload_3
    //   906: fconst_0
    //   907: fcmpg
    //   908: ifgt -> 969
    //   911: aload_0
    //   912: getfield mBeginState : I
    //   915: istore #12
    //   917: iload #8
    //   919: istore #7
    //   921: iload #12
    //   923: iconst_m1
    //   924: if_icmpeq -> 969
    //   927: iload #8
    //   929: istore #7
    //   931: aload_0
    //   932: getfield mCurrentState : I
    //   935: iload #12
    //   937: if_icmpeq -> 969
    //   940: aload_0
    //   941: iload #12
    //   943: putfield mCurrentState : I
    //   946: aload_0
    //   947: getfield mScene : Landroidx/constraintlayout/motion/widget/MotionScene;
    //   950: iload #12
    //   952: invokevirtual getConstraintSet : (I)Landroidx/constraintlayout/widget/ConstraintSet;
    //   955: aload_0
    //   956: invokevirtual applyCustomAttributes : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   959: aload_0
    //   960: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   963: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   966: iconst_1
    //   967: istore #7
    //   969: iload #7
    //   971: istore #8
    //   973: fload_3
    //   974: f2d
    //   975: dconst_1
    //   976: dcmpl
    //   977: iflt -> 1032
    //   980: aload_0
    //   981: getfield mCurrentState : I
    //   984: istore #12
    //   986: aload_0
    //   987: getfield mEndState : I
    //   990: istore #13
    //   992: iload #7
    //   994: istore #8
    //   996: iload #12
    //   998: iload #13
    //   1000: if_icmpeq -> 1032
    //   1003: aload_0
    //   1004: iload #13
    //   1006: putfield mCurrentState : I
    //   1009: aload_0
    //   1010: getfield mScene : Landroidx/constraintlayout/motion/widget/MotionScene;
    //   1013: iload #13
    //   1015: invokevirtual getConstraintSet : (I)Landroidx/constraintlayout/widget/ConstraintSet;
    //   1018: aload_0
    //   1019: invokevirtual applyCustomAttributes : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   1022: aload_0
    //   1023: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1026: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1029: iconst_1
    //   1030: istore #8
    //   1032: aload_0
    //   1033: getfield mKeepAnimating : Z
    //   1036: ifne -> 1083
    //   1039: aload_0
    //   1040: getfield mInTransition : Z
    //   1043: ifeq -> 1049
    //   1046: goto -> 1083
    //   1049: iload #11
    //   1051: ifle -> 1060
    //   1054: fload_3
    //   1055: fconst_1
    //   1056: fcmpl
    //   1057: ifeq -> 1073
    //   1060: fload #5
    //   1062: fconst_0
    //   1063: fcmpg
    //   1064: ifge -> 1087
    //   1067: fload_3
    //   1068: fconst_0
    //   1069: fcmpl
    //   1070: ifne -> 1087
    //   1073: aload_0
    //   1074: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1077: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1080: goto -> 1087
    //   1083: aload_0
    //   1084: invokevirtual invalidate : ()V
    //   1087: iload #8
    //   1089: istore #7
    //   1091: aload_0
    //   1092: getfield mKeepAnimating : Z
    //   1095: ifne -> 1149
    //   1098: iload #8
    //   1100: istore #7
    //   1102: aload_0
    //   1103: getfield mInTransition : Z
    //   1106: ifne -> 1149
    //   1109: iload #11
    //   1111: ifle -> 1120
    //   1114: fload_3
    //   1115: fconst_1
    //   1116: fcmpl
    //   1117: ifeq -> 1141
    //   1120: iload #8
    //   1122: istore #7
    //   1124: fload #5
    //   1126: fconst_0
    //   1127: fcmpg
    //   1128: ifge -> 1149
    //   1131: iload #8
    //   1133: istore #7
    //   1135: fload_3
    //   1136: fconst_0
    //   1137: fcmpl
    //   1138: ifne -> 1149
    //   1141: aload_0
    //   1142: invokevirtual onNewStateAttachHandlers : ()V
    //   1145: iload #8
    //   1147: istore #7
    //   1149: aload_0
    //   1150: getfield mTransitionLastPosition : F
    //   1153: fstore_2
    //   1154: fload_2
    //   1155: fconst_1
    //   1156: fcmpl
    //   1157: iflt -> 1199
    //   1160: aload_0
    //   1161: getfield mCurrentState : I
    //   1164: istore #9
    //   1166: aload_0
    //   1167: getfield mEndState : I
    //   1170: istore #8
    //   1172: iload #9
    //   1174: iload #8
    //   1176: if_icmpeq -> 1186
    //   1179: iload #10
    //   1181: istore #7
    //   1183: goto -> 1186
    //   1186: aload_0
    //   1187: iload #8
    //   1189: putfield mCurrentState : I
    //   1192: iload #7
    //   1194: istore #8
    //   1196: goto -> 1244
    //   1199: iload #7
    //   1201: istore #8
    //   1203: fload_2
    //   1204: fconst_0
    //   1205: fcmpg
    //   1206: ifgt -> 1244
    //   1209: aload_0
    //   1210: getfield mCurrentState : I
    //   1213: istore #10
    //   1215: aload_0
    //   1216: getfield mBeginState : I
    //   1219: istore #8
    //   1221: iload #10
    //   1223: iload #8
    //   1225: if_icmpeq -> 1235
    //   1228: iload #9
    //   1230: istore #7
    //   1232: goto -> 1235
    //   1235: aload_0
    //   1236: iload #8
    //   1238: putfield mCurrentState : I
    //   1241: goto -> 1192
    //   1244: aload_0
    //   1245: aload_0
    //   1246: getfield mNeedsFireTransitionCompleted : Z
    //   1249: iload #8
    //   1251: ior
    //   1252: putfield mNeedsFireTransitionCompleted : Z
    //   1255: iload #8
    //   1257: ifeq -> 1271
    //   1260: aload_0
    //   1261: getfield mInLayout : Z
    //   1264: ifne -> 1271
    //   1267: aload_0
    //   1268: invokevirtual requestLayout : ()V
    //   1271: aload_0
    //   1272: aload_0
    //   1273: getfield mTransitionLastPosition : F
    //   1276: putfield mTransitionPosition : F
    //   1279: return
  }
  
  protected void fireTransitionCompleted() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield mTransitionListeners : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 103
    //   16: aload_3
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 103
    //   23: aload_0
    //   24: getfield mListenerState : I
    //   27: iconst_m1
    //   28: if_icmpne -> 103
    //   31: aload_0
    //   32: aload_0
    //   33: getfield mCurrentState : I
    //   36: putfield mListenerState : I
    //   39: aload_0
    //   40: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifne -> 74
    //   49: aload_0
    //   50: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   53: astore_3
    //   54: aload_3
    //   55: aload_3
    //   56: invokevirtual size : ()I
    //   59: iconst_1
    //   60: isub
    //   61: invokevirtual get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_m1
    //   75: istore_1
    //   76: aload_0
    //   77: getfield mCurrentState : I
    //   80: istore_2
    //   81: iload_1
    //   82: iload_2
    //   83: if_icmpeq -> 103
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpeq -> 103
    //   91: aload_0
    //   92: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   95: iload_2
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: invokespecial processTransitionCompleted : ()V
    //   107: aload_0
    //   108: getfield mOnComplete : Ljava/lang/Runnable;
    //   111: astore_3
    //   112: aload_3
    //   113: ifnull -> 122
    //   116: aload_3
    //   117: invokeinterface run : ()V
    //   122: aload_0
    //   123: getfield mScheduledTransitionTo : [I
    //   126: astore_3
    //   127: aload_3
    //   128: ifnull -> 171
    //   131: aload_0
    //   132: getfield mScheduledTransitions : I
    //   135: ifle -> 171
    //   138: aload_0
    //   139: aload_3
    //   140: iconst_0
    //   141: iaload
    //   142: invokevirtual transitionToState : (I)V
    //   145: aload_0
    //   146: getfield mScheduledTransitionTo : [I
    //   149: astore_3
    //   150: aload_3
    //   151: iconst_1
    //   152: aload_3
    //   153: iconst_0
    //   154: aload_3
    //   155: arraylength
    //   156: iconst_1
    //   157: isub
    //   158: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   161: aload_0
    //   162: aload_0
    //   163: getfield mScheduledTransitions : I
    //   166: iconst_1
    //   167: isub
    //   168: putfield mScheduledTransitions : I
    //   171: return
  }
  
  public void fireTrigger(int paramInt, boolean paramBoolean, float paramFloat) {
    TransitionListener transitionListener = this.mTransitionListener;
    if (transitionListener != null)
      transitionListener.onTransitionTrigger(this, paramInt, paramBoolean, paramFloat); 
    CopyOnWriteArrayList<TransitionListener> copyOnWriteArrayList = this.mTransitionListeners;
    if (copyOnWriteArrayList != null) {
      Iterator<TransitionListener> iterator = copyOnWriteArrayList.iterator();
      while (iterator.hasNext())
        ((TransitionListener)iterator.next()).onTransitionTrigger(this, paramInt, paramBoolean, paramFloat); 
    } 
  }
  
  void getAnchorDpDt(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    String str;
    HashMap<View, MotionController> hashMap = this.mFrameArrayList;
    View view = getViewById(paramInt);
    MotionController motionController = hashMap.get(view);
    if (motionController != null) {
      motionController.getDpDt(paramFloat1, paramFloat2, paramFloat3, paramArrayOffloat);
      paramFloat2 = view.getY();
      this.lastPos = paramFloat1;
      this.lastY = paramFloat2;
      return;
    } 
    if (view == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append(paramInt);
      str = stringBuilder1.toString();
    } else {
      str = view.getContext().getResources().getResourceName(paramInt);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("WARNING could not find view id ");
    stringBuilder.append(str);
    Log.w("MotionLayout", stringBuilder.toString());
  }
  
  public ConstraintSet getConstraintSet(int paramInt) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getConstraintSet(paramInt);
  }
  
  public int[] getConstraintSetIds() {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getConstraintSetIds();
  }
  
  String getConstraintSetNames(int paramInt) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.lookUpConstraintName(paramInt);
  }
  
  public int getCurrentState() {
    return this.mCurrentState;
  }
  
  public void getDebugMode(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = true;
    } 
    this.mDebugPath = bool;
    invalidate();
  }
  
  public ArrayList<MotionScene.Transition> getDefinedTransitions() {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getDefinedTransitions();
  }
  
  public DesignTool getDesignTool() {
    if (this.mDesignTool == null)
      this.mDesignTool = new DesignTool(this); 
    return this.mDesignTool;
  }
  
  public int getEndState() {
    return this.mEndState;
  }
  
  MotionController getMotionController(int paramInt) {
    return this.mFrameArrayList.get(findViewById(paramInt));
  }
  
  protected long getNanoTime() {
    return System.nanoTime();
  }
  
  public float getProgress() {
    return this.mTransitionLastPosition;
  }
  
  public MotionScene getScene() {
    return this.mScene;
  }
  
  public int getStartState() {
    return this.mBeginState;
  }
  
  public float getTargetPosition() {
    return this.mTransitionGoalPosition;
  }
  
  public MotionScene.Transition getTransition(int paramInt) {
    return this.mScene.getTransitionById(paramInt);
  }
  
  public Bundle getTransitionState() {
    if (this.mStateCache == null)
      this.mStateCache = new StateCache(); 
    this.mStateCache.recordState();
    return this.mStateCache.getTransitionState();
  }
  
  public long getTransitionTimeMs() {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      this.mTransitionDuration = motionScene.getDuration() / 1000.0F; 
    return (long)(this.mTransitionDuration * 1000.0F);
  }
  
  public float getVelocity() {
    return this.mLastVelocity;
  }
  
  public void getViewVelocity(View paramView, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, int paramInt) {
    float f1 = this.mLastVelocity;
    float f2 = this.mTransitionLastPosition;
    if (this.mInterpolator != null) {
      f1 = Math.signum(this.mTransitionGoalPosition - f2);
      float f = this.mInterpolator.getInterpolation(this.mTransitionLastPosition + 1.0E-5F);
      f2 = this.mInterpolator.getInterpolation(this.mTransitionLastPosition);
      f1 = f1 * (f - f2) / 1.0E-5F / this.mTransitionDuration;
    } 
    Interpolator interpolator = this.mInterpolator;
    if (interpolator instanceof MotionInterpolator)
      f1 = ((MotionInterpolator)interpolator).getVelocity(); 
    MotionController motionController = this.mFrameArrayList.get(paramView);
    if ((paramInt & 0x1) == 0) {
      motionController.getPostLayoutDvDp(f2, paramView.getWidth(), paramView.getHeight(), paramFloat1, paramFloat2, paramArrayOffloat);
    } else {
      motionController.getDpDt(f2, paramFloat1, paramFloat2, paramArrayOffloat);
    } 
    if (paramInt < 2) {
      paramArrayOffloat[0] = paramArrayOffloat[0] * f1;
      paramArrayOffloat[1] = paramArrayOffloat[1] * f1;
    } 
  }
  
  public boolean isAttachedToWindow() {
    return (Build.VERSION.SDK_INT >= 19) ? super.isAttachedToWindow() : ((getWindowToken() != null));
  }
  
  public boolean isDelayedApplicationOfInitialState() {
    return this.mDelayedApply;
  }
  
  public boolean isInRotation() {
    return this.mInRotation;
  }
  
  public boolean isInteractionEnabled() {
    return this.mInteractionEnabled;
  }
  
  public boolean isViewTransitionEnabled(int paramInt) {
    MotionScene motionScene = this.mScene;
    return (motionScene != null) ? motionScene.isViewTransitionEnabled(paramInt) : false;
  }
  
  public void jumpToState(int paramInt) {
    if (!isAttachedToWindow())
      this.mCurrentState = paramInt; 
    if (this.mBeginState == paramInt) {
      setProgress(0.0F);
      return;
    } 
    if (this.mEndState == paramInt) {
      setProgress(1.0F);
      return;
    } 
    setTransition(paramInt, paramInt);
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0)
      try {
        MotionScene motionScene = new MotionScene(getContext(), this, paramInt);
        this.mScene = motionScene;
        if (this.mCurrentState == -1) {
          this.mCurrentState = motionScene.getStartId();
          this.mBeginState = this.mScene.getStartId();
          this.mEndState = this.mScene.getEndId();
        } 
        if (Build.VERSION.SDK_INT < 19 || isAttachedToWindow()) {
          try {
            if (Build.VERSION.SDK_INT >= 17) {
              Display display = getDisplay();
              if (display == null) {
                paramInt = 0;
              } else {
                paramInt = display.getRotation();
              } 
              this.mPreviouseRotation = paramInt;
            } 
            motionScene = this.mScene;
            if (motionScene != null) {
              ConstraintSet constraintSet = motionScene.getConstraintSet(this.mCurrentState);
              this.mScene.readFallback(this);
              ArrayList<MotionHelper> arrayList = this.mDecoratorsHelpers;
              if (arrayList != null) {
                Iterator<MotionHelper> iterator = arrayList.iterator();
                while (iterator.hasNext())
                  ((MotionHelper)iterator.next()).onFinishedMotionScene(this); 
              } 
              if (constraintSet != null)
                constraintSet.applyTo(this); 
              this.mBeginState = this.mCurrentState;
            } 
            onNewStateAttachHandlers();
            StateCache stateCache = this.mStateCache;
            if (stateCache != null) {
              if (this.mDelayedApply) {
                post(new Runnable() {
                      public void run() {
                        MotionLayout.this.mStateCache.apply();
                      }
                    });
                return;
              } 
              stateCache.apply();
              return;
            } 
            MotionScene motionScene1 = this.mScene;
            if (motionScene1 != null && motionScene1.mCurrentTransition != null && this.mScene.mCurrentTransition.getAutoTransition() == 4) {
              transitionToEnd();
              setState(TransitionState.SETUP);
              setState(TransitionState.MOVING);
              return;
            } 
          } catch (Exception exception) {
            throw new IllegalArgumentException("unable to parse MotionScene file", exception);
          } 
          return;
        } 
        this.mScene = null;
        return;
      } catch (Exception exception) {
        throw new IllegalArgumentException("unable to parse MotionScene file", exception);
      }  
    this.mScene = null;
  }
  
  int lookUpConstraintId(String paramString) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? 0 : motionScene.lookUpConstraintId(paramString);
  }
  
  protected MotionTracker obtainVelocityTracker() {
    return MyTracker.obtain();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (Build.VERSION.SDK_INT >= 17) {
      Display display = getDisplay();
      if (display != null)
        this.mPreviouseRotation = display.getRotation(); 
    } 
    MotionScene motionScene2 = this.mScene;
    if (motionScene2 != null) {
      int i = this.mCurrentState;
      if (i != -1) {
        ConstraintSet constraintSet = motionScene2.getConstraintSet(i);
        this.mScene.readFallback(this);
        ArrayList<MotionHelper> arrayList = this.mDecoratorsHelpers;
        if (arrayList != null) {
          Iterator<MotionHelper> iterator = arrayList.iterator();
          while (iterator.hasNext())
            ((MotionHelper)iterator.next()).onFinishedMotionScene(this); 
        } 
        if (constraintSet != null)
          constraintSet.applyTo(this); 
        this.mBeginState = this.mCurrentState;
      } 
    } 
    onNewStateAttachHandlers();
    StateCache stateCache = this.mStateCache;
    if (stateCache != null) {
      if (this.mDelayedApply) {
        post(new Runnable() {
              public void run() {
                MotionLayout.this.mStateCache.apply();
              }
            });
        return;
      } 
      stateCache.apply();
      return;
    } 
    MotionScene motionScene1 = this.mScene;
    if (motionScene1 != null && motionScene1.mCurrentTransition != null && this.mScene.mCurrentTransition.getAutoTransition() == 4) {
      transitionToEnd();
      setState(TransitionState.SETUP);
      setState(TransitionState.MOVING);
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      if (!this.mInteractionEnabled)
        return false; 
      if (motionScene.mViewTransitionController != null)
        this.mScene.mViewTransitionController.touchEvent(paramMotionEvent); 
      MotionScene.Transition transition = this.mScene.mCurrentTransition;
      if (transition != null && transition.isEnabled()) {
        TouchResponse touchResponse = transition.getTouchResponse();
        if (touchResponse != null) {
          if (paramMotionEvent.getAction() == 0) {
            RectF rectF = touchResponse.getTouchRegion((ViewGroup)this, new RectF());
            if (rectF != null && !rectF.contains(paramMotionEvent.getX(), paramMotionEvent.getY()))
              return false; 
          } 
          int i = touchResponse.getTouchRegionId();
          if (i != -1) {
            View view = this.mRegionView;
            if (view == null || view.getId() != i)
              this.mRegionView = findViewById(i); 
            view = this.mRegionView;
            if (view != null) {
              this.mBoundsCheck.set(view.getLeft(), this.mRegionView.getTop(), this.mRegionView.getRight(), this.mRegionView.getBottom());
              if (this.mBoundsCheck.contains(paramMotionEvent.getX(), paramMotionEvent.getY()) && !handlesTouchEvent(this.mRegionView.getLeft(), this.mRegionView.getTop(), this.mRegionView, paramMotionEvent))
                return onTouchEvent(paramMotionEvent); 
            } 
          } 
        } 
      } 
    } 
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mInLayout = true;
    try {
      if (this.mScene == null) {
        super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } 
      paramInt1 = paramInt3 - paramInt1;
      paramInt2 = paramInt4 - paramInt2;
      if (this.mLastLayoutWidth != paramInt1 || this.mLastLayoutHeight != paramInt2) {
        rebuildScene();
        evaluate(true);
      } 
      this.mLastLayoutWidth = paramInt1;
      this.mLastLayoutHeight = paramInt2;
      this.mOldWidth = paramInt1;
      this.mOldHeight = paramInt2;
      return;
    } finally {
      this.mInLayout = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mScene == null) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int i = this.mLastWidthMeasureSpec;
    int j = 0;
    if (i != paramInt1 || this.mLastHeightMeasureSpec != paramInt2) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.mNeedsFireTransitionCompleted) {
      this.mNeedsFireTransitionCompleted = false;
      onNewStateAttachHandlers();
      processTransitionCompleted();
      i = 1;
    } 
    if (this.mDirtyHierarchy)
      i = 1; 
    this.mLastWidthMeasureSpec = paramInt1;
    this.mLastHeightMeasureSpec = paramInt2;
    int k = this.mScene.getStartId();
    int m = this.mScene.getEndId();
    if ((i != 0 || this.mModel.isNotConfiguredWith(k, m)) && this.mBeginState != -1) {
      super.onMeasure(paramInt1, paramInt2);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(k), this.mScene.getConstraintSet(m));
      this.mModel.reEvaluateState();
      this.mModel.setMeasuredId(k, m);
      paramInt1 = j;
    } else {
      if (i != 0)
        super.onMeasure(paramInt1, paramInt2); 
      paramInt1 = 1;
    } 
    if (this.mMeasureDuringTransition || paramInt1 != 0) {
      paramInt2 = getPaddingTop();
      i = getPaddingBottom();
      paramInt1 = getPaddingLeft();
      j = getPaddingRight();
      paramInt1 = this.mLayoutWidget.getWidth() + paramInt1 + j;
      paramInt2 = this.mLayoutWidget.getHeight() + paramInt2 + i;
      i = this.mWidthMeasureMode;
      if (i == Integer.MIN_VALUE || i == 0) {
        paramInt1 = this.mStartWrapWidth;
        paramInt1 = (int)(paramInt1 + this.mPostInterpolationPosition * (this.mEndWrapWidth - paramInt1));
        requestLayout();
      } 
      i = this.mHeightMeasureMode;
      if (i == Integer.MIN_VALUE || i == 0) {
        paramInt2 = this.mStartWrapHeight;
        paramInt2 = (int)(paramInt2 + this.mPostInterpolationPosition * (this.mEndWrapHeight - paramInt2));
        requestLayout();
      } 
      setMeasuredDimension(paramInt1, paramInt2);
    } 
    evaluateLayout();
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(final View target, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    MotionScene.Transition transition = motionScene.mCurrentTransition;
    if (transition != null) {
      if (!transition.isEnabled())
        return; 
      boolean bool = transition.isEnabled();
      byte b = -1;
      if (bool) {
        TouchResponse touchResponse = transition.getTouchResponse();
        if (touchResponse != null) {
          paramInt3 = touchResponse.getTouchRegionId();
          if (paramInt3 != -1 && target.getId() != paramInt3)
            return; 
        } 
      } 
      if (motionScene.getMoveWhenScrollAtTop()) {
        TouchResponse touchResponse = transition.getTouchResponse();
        paramInt3 = b;
        if (touchResponse != null) {
          paramInt3 = b;
          if ((touchResponse.getFlags() & 0x4) != 0)
            paramInt3 = paramInt2; 
        } 
        float f = this.mTransitionPosition;
        if ((f == 1.0F || f == 0.0F) && target.canScrollVertically(paramInt3))
          return; 
      } 
      if (transition.getTouchResponse() != null && (transition.getTouchResponse().getFlags() & 0x1) != 0) {
        float f4 = motionScene.getProgressDirection(paramInt1, paramInt2);
        float f5 = this.mTransitionLastPosition;
        if ((f5 <= 0.0F && f4 < 0.0F) || (f5 >= 1.0F && f4 > 0.0F)) {
          if (Build.VERSION.SDK_INT >= 21) {
            target.setNestedScrollingEnabled(false);
            target.post(new Runnable(this) {
                  public void run() {
                    target.setNestedScrollingEnabled(true);
                  }
                });
          } 
          return;
        } 
      } 
      float f1 = this.mTransitionPosition;
      long l = getNanoTime();
      float f2 = paramInt1;
      this.mScrollTargetDX = f2;
      float f3 = paramInt2;
      this.mScrollTargetDY = f3;
      this.mScrollTargetDT = (float)((l - this.mScrollTargetTime) * 1.0E-9D);
      this.mScrollTargetTime = l;
      motionScene.processScrollMove(f2, f3);
      if (f1 != this.mTransitionPosition) {
        paramArrayOfint[0] = paramInt1;
        paramArrayOfint[1] = paramInt2;
      } 
      evaluate(false);
      if (paramArrayOfint[0] != 0 || paramArrayOfint[1] != 0)
        this.mUndergoingMotion = true; 
    } 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (this.mUndergoingMotion || paramInt1 != 0 || paramInt2 != 0) {
      paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
      paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    } 
    this.mUndergoingMotion = false;
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.mScrollTargetTime = getNanoTime();
    this.mScrollTargetDT = 0.0F;
    this.mScrollTargetDX = 0.0F;
    this.mScrollTargetDY = 0.0F;
  }
  
  void onNewStateAttachHandlers() {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    if (motionScene.autoTransition(this, this.mCurrentState)) {
      requestLayout();
      return;
    } 
    int i = this.mCurrentState;
    if (i != -1)
      this.mScene.addOnClickListeners(this, i); 
    if (this.mScene.supportTouch())
      this.mScene.setupTouch(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.setRtl(isRtl()); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    MotionScene motionScene = this.mScene;
    return !(motionScene == null || motionScene.mCurrentTransition == null || this.mScene.mCurrentTransition.getTouchResponse() == null || (this.mScene.mCurrentTransition.getTouchResponse().getFlags() & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      float f = this.mScrollTargetDT;
      if (f == 0.0F)
        return; 
      motionScene.processScrollUp(this.mScrollTargetDX / f, this.mScrollTargetDY / f);
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null && this.mInteractionEnabled && motionScene.supportTouch()) {
      MotionScene.Transition transition = this.mScene.mCurrentTransition;
      if (transition != null && !transition.isEnabled())
        return super.onTouchEvent(paramMotionEvent); 
      this.mScene.processTouchEvent(paramMotionEvent, getCurrentState(), this);
      return this.mScene.mCurrentTransition.isTransitionFlag(4) ? this.mScene.mCurrentTransition.getTouchResponse().isDragStarted() : true;
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    if (paramView instanceof MotionHelper) {
      MotionHelper motionHelper = (MotionHelper)paramView;
      if (this.mTransitionListeners == null)
        this.mTransitionListeners = new CopyOnWriteArrayList<TransitionListener>(); 
      this.mTransitionListeners.add(motionHelper);
      if (motionHelper.isUsedOnShow()) {
        if (this.mOnShowHelpers == null)
          this.mOnShowHelpers = new ArrayList<MotionHelper>(); 
        this.mOnShowHelpers.add(motionHelper);
      } 
      if (motionHelper.isUseOnHide()) {
        if (this.mOnHideHelpers == null)
          this.mOnHideHelpers = new ArrayList<MotionHelper>(); 
        this.mOnHideHelpers.add(motionHelper);
      } 
      if (motionHelper.isDecorator()) {
        if (this.mDecoratorsHelpers == null)
          this.mDecoratorsHelpers = new ArrayList<MotionHelper>(); 
        this.mDecoratorsHelpers.add(motionHelper);
      } 
    } 
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    ArrayList<MotionHelper> arrayList = this.mOnShowHelpers;
    if (arrayList != null)
      arrayList.remove(paramView); 
    arrayList = this.mOnHideHelpers;
    if (arrayList != null)
      arrayList.remove(paramView); 
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = null;
  }
  
  @Deprecated
  public void rebuildMotion() {
    Log.e("MotionLayout", "This method is deprecated. Please call rebuildScene() instead.");
    rebuildScene();
  }
  
  public void rebuildScene() {
    this.mModel.reEvaluateState();
    invalidate();
  }
  
  public boolean removeTransitionListener(TransitionListener paramTransitionListener) {
    CopyOnWriteArrayList<TransitionListener> copyOnWriteArrayList = this.mTransitionListeners;
    return (copyOnWriteArrayList == null) ? false : copyOnWriteArrayList.remove(paramTransitionListener);
  }
  
  public void requestLayout() {
    if (!this.mMeasureDuringTransition && this.mCurrentState == -1) {
      MotionScene motionScene = this.mScene;
      if (motionScene != null && motionScene.mCurrentTransition != null) {
        int i = this.mScene.mCurrentTransition.getLayoutDuringTransition();
        if (i == 0)
          return; 
        if (i == 2) {
          int j = getChildCount();
          for (i = 0; i < j; i++) {
            View view = getChildAt(i);
            ((MotionController)this.mFrameArrayList.get(view)).remeasure();
          } 
          return;
        } 
      } 
    } 
    super.requestLayout();
  }
  
  public void rotateTo(int paramInt1, int paramInt2) {
    int i = 1;
    this.mInRotation = true;
    this.mPreRotateWidth = getWidth();
    this.mPreRotateHeight = getHeight();
    int j = getDisplay().getRotation();
    if ((j + 1) % 4 <= (this.mPreviouseRotation + 1) % 4)
      i = 2; 
    this.mRotatMode = i;
    this.mPreviouseRotation = j;
    j = getChildCount();
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      ViewState viewState2 = this.mPreRotate.get(view);
      ViewState viewState1 = viewState2;
      if (viewState2 == null) {
        viewState1 = new ViewState();
        this.mPreRotate.put(view, viewState1);
      } 
      viewState1.getState(view);
    } 
    this.mBeginState = -1;
    this.mEndState = paramInt1;
    this.mScene.setTransition(-1, paramInt1);
    this.mModel.initFrom(this.mLayoutWidget, null, this.mScene.getConstraintSet(this.mEndState));
    this.mTransitionPosition = 0.0F;
    this.mTransitionLastPosition = 0.0F;
    invalidate();
    transitionToEnd(new Runnable() {
          public void run() {
            MotionLayout.access$302(MotionLayout.this, false);
          }
        });
    if (paramInt2 > 0)
      this.mTransitionDuration = paramInt2 / 1000.0F; 
  }
  
  public void scheduleTransitionTo(int paramInt) {
    if (getCurrentState() == -1) {
      transitionToState(paramInt);
      return;
    } 
    int[] arrayOfInt = this.mScheduledTransitionTo;
    if (arrayOfInt == null) {
      this.mScheduledTransitionTo = new int[4];
    } else if (arrayOfInt.length <= this.mScheduledTransitions) {
      this.mScheduledTransitionTo = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
    } 
    arrayOfInt = this.mScheduledTransitionTo;
    int i = this.mScheduledTransitions;
    this.mScheduledTransitions = i + 1;
    arrayOfInt[i] = paramInt;
  }
  
  public void setDebugMode(int paramInt) {
    this.mDebugPath = paramInt;
    invalidate();
  }
  
  public void setDelayedApplicationOfInitialState(boolean paramBoolean) {
    this.mDelayedApply = paramBoolean;
  }
  
  public void setInteractionEnabled(boolean paramBoolean) {
    this.mInteractionEnabled = paramBoolean;
  }
  
  public void setInterpolatedProgress(float paramFloat) {
    if (this.mScene != null) {
      setState(TransitionState.MOVING);
      Interpolator interpolator = this.mScene.getInterpolator();
      if (interpolator != null) {
        setProgress(interpolator.getInterpolation(paramFloat));
        return;
      } 
    } 
    setProgress(paramFloat);
  }
  
  public void setOnHide(float paramFloat) {
    ArrayList<MotionHelper> arrayList = this.mOnHideHelpers;
    if (arrayList != null) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        ((MotionHelper)this.mOnHideHelpers.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setOnShow(float paramFloat) {
    ArrayList<MotionHelper> arrayList = this.mOnShowHelpers;
    if (arrayList != null) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        ((MotionHelper)this.mOnShowHelpers.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setProgress(float paramFloat) {
    int i = paramFloat cmp 0.0F;
    if (i < 0 || paramFloat > 1.0F)
      Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"); 
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setProgress(paramFloat);
      return;
    } 
    if (i <= 0) {
      if (this.mTransitionLastPosition == 1.0F && this.mCurrentState == this.mEndState)
        setState(TransitionState.MOVING); 
      this.mCurrentState = this.mBeginState;
      if (this.mTransitionLastPosition == 0.0F)
        setState(TransitionState.FINISHED); 
    } else if (paramFloat >= 1.0F) {
      if (this.mTransitionLastPosition == 0.0F && this.mCurrentState == this.mBeginState)
        setState(TransitionState.MOVING); 
      this.mCurrentState = this.mEndState;
      if (this.mTransitionLastPosition == 1.0F)
        setState(TransitionState.FINISHED); 
    } else {
      this.mCurrentState = -1;
      setState(TransitionState.MOVING);
    } 
    if (this.mScene == null)
      return; 
    this.mTransitionInstantly = true;
    this.mTransitionGoalPosition = paramFloat;
    this.mTransitionPosition = paramFloat;
    this.mTransitionLastTime = -1L;
    this.mAnimationStartTime = -1L;
    this.mInterpolator = null;
    this.mInTransition = true;
    invalidate();
  }
  
  public void setProgress(float paramFloat1, float paramFloat2) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setProgress(paramFloat1);
      this.mStateCache.setVelocity(paramFloat2);
      return;
    } 
    setProgress(paramFloat1);
    setState(TransitionState.MOVING);
    this.mLastVelocity = paramFloat2;
    float f = 1.0F;
    int i = paramFloat2 cmp 0.0F;
    if (i != 0) {
      if (i <= 0)
        f = 0.0F; 
      animateTo(f);
      return;
    } 
    if (paramFloat1 != 0.0F && paramFloat1 != 1.0F) {
      if (paramFloat1 <= 0.5F)
        f = 0.0F; 
      animateTo(f);
    } 
  }
  
  public void setScene(MotionScene paramMotionScene) {
    this.mScene = paramMotionScene;
    paramMotionScene.setRtl(isRtl());
    rebuildScene();
  }
  
  void setStartState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setStartState(paramInt);
      this.mStateCache.setEndState(paramInt);
      return;
    } 
    this.mCurrentState = paramInt;
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    setState(TransitionState.SETUP);
    this.mCurrentState = paramInt1;
    this.mBeginState = -1;
    this.mEndState = -1;
    if (this.mConstraintLayoutSpec != null) {
      this.mConstraintLayoutSpec.updateConstraints(paramInt1, paramInt2, paramInt3);
      return;
    } 
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.getConstraintSet(paramInt1).applyTo(this); 
  }
  
  void setState(TransitionState paramTransitionState) {
    if (paramTransitionState == TransitionState.FINISHED && this.mCurrentState == -1)
      return; 
    TransitionState transitionState = this.mTransitionState;
    this.mTransitionState = paramTransitionState;
    if (transitionState == TransitionState.MOVING && paramTransitionState == TransitionState.MOVING)
      fireTransitionChange(); 
    int i = null.$SwitchMap$androidx$constraintlayout$motion$widget$MotionLayout$TransitionState[transitionState.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3)
        return; 
      if (paramTransitionState == TransitionState.FINISHED) {
        fireTransitionCompleted();
        return;
      } 
    } else {
      if (paramTransitionState == TransitionState.MOVING)
        fireTransitionChange(); 
      if (paramTransitionState == TransitionState.FINISHED)
        fireTransitionCompleted(); 
    } 
  }
  
  public void setTransition(int paramInt) {
    if (this.mScene != null) {
      MotionScene.Transition transition = getTransition(paramInt);
      this.mBeginState = transition.getStartConstraintSetId();
      this.mEndState = transition.getEndConstraintSetId();
      if (!isAttachedToWindow()) {
        if (this.mStateCache == null)
          this.mStateCache = new StateCache(); 
        this.mStateCache.setStartState(this.mBeginState);
        this.mStateCache.setEndState(this.mEndState);
        return;
      } 
      float f1 = Float.NaN;
      paramInt = this.mCurrentState;
      int i = this.mBeginState;
      float f2 = 0.0F;
      if (paramInt == i) {
        f1 = 0.0F;
      } else if (paramInt == this.mEndState) {
        f1 = 1.0F;
      } 
      this.mScene.setTransition(transition);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
      rebuildScene();
      if (this.mTransitionLastPosition != f1)
        if (f1 == 0.0F) {
          endTrigger(true);
          this.mScene.getConstraintSet(this.mBeginState).applyTo(this);
        } else if (f1 == 1.0F) {
          endTrigger(false);
          this.mScene.getConstraintSet(this.mEndState).applyTo(this);
        }  
      if (!Float.isNaN(f1))
        f2 = f1; 
      this.mTransitionLastPosition = f2;
      if (Float.isNaN(f1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Debug.getLocation());
        stringBuilder.append(" transitionToStart ");
        Log.v("MotionLayout", stringBuilder.toString());
        transitionToStart();
        return;
      } 
      setProgress(f1);
    } 
  }
  
  public void setTransition(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setStartState(paramInt1);
      this.mStateCache.setEndState(paramInt2);
      return;
    } 
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      this.mBeginState = paramInt1;
      this.mEndState = paramInt2;
      motionScene.setTransition(paramInt1, paramInt2);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(paramInt1), this.mScene.getConstraintSet(paramInt2));
      rebuildScene();
      this.mTransitionLastPosition = 0.0F;
      transitionToStart();
    } 
  }
  
  protected void setTransition(MotionScene.Transition paramTransition) {
    long l;
    this.mScene.setTransition(paramTransition);
    setState(TransitionState.SETUP);
    if (this.mCurrentState == this.mScene.getEndId()) {
      this.mTransitionLastPosition = 1.0F;
      this.mTransitionPosition = 1.0F;
      this.mTransitionGoalPosition = 1.0F;
    } else {
      this.mTransitionLastPosition = 0.0F;
      this.mTransitionPosition = 0.0F;
      this.mTransitionGoalPosition = 0.0F;
    } 
    if (paramTransition.isTransitionFlag(1)) {
      l = -1L;
    } else {
      l = getNanoTime();
    } 
    this.mTransitionLastTime = l;
    int i = this.mScene.getStartId();
    int j = this.mScene.getEndId();
    if (i == this.mBeginState && j == this.mEndState)
      return; 
    this.mBeginState = i;
    this.mEndState = j;
    this.mScene.setTransition(i, j);
    this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
    this.mModel.setMeasuredId(this.mBeginState, this.mEndState);
    this.mModel.reEvaluateState();
    rebuildScene();
  }
  
  public void setTransitionDuration(int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null) {
      Log.e("MotionLayout", "MotionScene not defined");
      return;
    } 
    motionScene.setDuration(paramInt);
  }
  
  public void setTransitionListener(TransitionListener paramTransitionListener) {
    this.mTransitionListener = paramTransitionListener;
  }
  
  public void setTransitionState(Bundle paramBundle) {
    if (this.mStateCache == null)
      this.mStateCache = new StateCache(); 
    this.mStateCache.setTransitionState(paramBundle);
    if (isAttachedToWindow())
      this.mStateCache.apply(); 
  }
  
  public String toString() {
    Context context = getContext();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Debug.getName(context, this.mBeginState));
    stringBuilder.append("->");
    stringBuilder.append(Debug.getName(context, this.mEndState));
    stringBuilder.append(" (pos:");
    stringBuilder.append(this.mTransitionLastPosition);
    stringBuilder.append(" Dpos/Dt:");
    stringBuilder.append(this.mLastVelocity);
    return stringBuilder.toString();
  }
  
  public void touchAnimateTo(int paramInt, float paramFloat1, float paramFloat2) {
    if (this.mScene == null)
      return; 
    if (this.mTransitionLastPosition == paramFloat1)
      return; 
    this.mTemporalInterpolator = true;
    this.mAnimationStartTime = getNanoTime();
    this.mTransitionDuration = this.mScene.getDuration() / 1000.0F;
    this.mTransitionGoalPosition = paramFloat1;
    this.mInTransition = true;
    if (paramInt != 0 && paramInt != 1 && paramInt != 2)
      if (paramInt != 4) {
        if (paramInt != 5) {
          if (paramInt != 6 && paramInt != 7) {
            this.mTransitionInstantly = false;
            this.mAnimationStartTime = getNanoTime();
            invalidate();
          } 
        } else {
          if (willJump(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration())) {
            this.mDecelerateLogic.config(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration());
            this.mInterpolator = this.mDecelerateLogic;
          } else {
            this.mStopLogic.config(this.mTransitionLastPosition, paramFloat1, paramFloat2, this.mTransitionDuration, this.mScene.getMaxAcceleration(), this.mScene.getMaxVelocity());
            this.mLastVelocity = 0.0F;
            paramInt = this.mCurrentState;
            this.mTransitionGoalPosition = paramFloat1;
            this.mCurrentState = paramInt;
            this.mInterpolator = (Interpolator)this.mStopLogic;
          } 
          this.mTransitionInstantly = false;
          this.mAnimationStartTime = getNanoTime();
          invalidate();
        } 
      } else {
        this.mDecelerateLogic.config(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration());
        this.mInterpolator = this.mDecelerateLogic;
        this.mTransitionInstantly = false;
        this.mAnimationStartTime = getNanoTime();
        invalidate();
      }  
    if (paramInt == 1 || paramInt == 7) {
      paramFloat1 = 0.0F;
    } else if (paramInt == 2 || paramInt == 6) {
      paramFloat1 = 1.0F;
    } 
    if (this.mScene.getAutoCompleteMode() == 0) {
      this.mStopLogic.config(this.mTransitionLastPosition, paramFloat1, paramFloat2, this.mTransitionDuration, this.mScene.getMaxAcceleration(), this.mScene.getMaxVelocity());
    } else {
      this.mStopLogic.springConfig(this.mTransitionLastPosition, paramFloat1, paramFloat2, this.mScene.getSpringMass(), this.mScene.getSpringStiffiness(), this.mScene.getSpringDamping(), this.mScene.getSpringStopThreshold(), this.mScene.getSpringBoundary());
    } 
    paramInt = this.mCurrentState;
    this.mTransitionGoalPosition = paramFloat1;
    this.mCurrentState = paramInt;
    this.mInterpolator = (Interpolator)this.mStopLogic;
    this.mTransitionInstantly = false;
    this.mAnimationStartTime = getNanoTime();
    invalidate();
  }
  
  public void touchSpringTo(float paramFloat1, float paramFloat2) {
    if (this.mScene == null)
      return; 
    if (this.mTransitionLastPosition == paramFloat1)
      return; 
    this.mTemporalInterpolator = true;
    this.mAnimationStartTime = getNanoTime();
    this.mTransitionDuration = this.mScene.getDuration() / 1000.0F;
    this.mTransitionGoalPosition = paramFloat1;
    this.mInTransition = true;
    this.mStopLogic.springConfig(this.mTransitionLastPosition, paramFloat1, paramFloat2, this.mScene.getSpringMass(), this.mScene.getSpringStiffiness(), this.mScene.getSpringDamping(), this.mScene.getSpringStopThreshold(), this.mScene.getSpringBoundary());
    int i = this.mCurrentState;
    this.mTransitionGoalPosition = paramFloat1;
    this.mCurrentState = i;
    this.mInterpolator = (Interpolator)this.mStopLogic;
    this.mTransitionInstantly = false;
    this.mAnimationStartTime = getNanoTime();
    invalidate();
  }
  
  public void transitionToEnd() {
    animateTo(1.0F);
    this.mOnComplete = null;
  }
  
  public void transitionToEnd(Runnable paramRunnable) {
    animateTo(1.0F);
    this.mOnComplete = paramRunnable;
  }
  
  public void transitionToStart() {
    animateTo(0.0F);
  }
  
  public void transitionToState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setEndState(paramInt);
      return;
    } 
    transitionToState(paramInt, -1, -1);
  }
  
  public void transitionToState(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setEndState(paramInt1);
      return;
    } 
    transitionToState(paramInt1, -1, -1, paramInt2);
  }
  
  public void transitionToState(int paramInt1, int paramInt2, int paramInt3) {
    transitionToState(paramInt1, paramInt2, paramInt3, -1);
  }
  
  public void transitionToState(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    MotionScene motionScene = this.mScene;
    int i = paramInt1;
    if (motionScene != null) {
      i = paramInt1;
      if (motionScene.mStateSet != null) {
        paramInt2 = this.mScene.mStateSet.convertToConstraintSet(this.mCurrentState, paramInt1, paramInt2, paramInt3);
        i = paramInt1;
        if (paramInt2 != -1)
          i = paramInt2; 
      } 
    } 
    paramInt1 = this.mCurrentState;
    if (paramInt1 == i)
      return; 
    if (this.mBeginState == i) {
      animateTo(0.0F);
      if (paramInt4 > 0)
        this.mTransitionDuration = paramInt4 / 1000.0F; 
      return;
    } 
    if (this.mEndState == i) {
      animateTo(1.0F);
      if (paramInt4 > 0)
        this.mTransitionDuration = paramInt4 / 1000.0F; 
      return;
    } 
    this.mEndState = i;
    if (paramInt1 != -1) {
      setTransition(paramInt1, i);
      animateTo(1.0F);
      this.mTransitionLastPosition = 0.0F;
      transitionToEnd();
      if (paramInt4 > 0)
        this.mTransitionDuration = paramInt4 / 1000.0F; 
      return;
    } 
    paramInt3 = 0;
    this.mTemporalInterpolator = false;
    this.mTransitionGoalPosition = 1.0F;
    this.mTransitionPosition = 0.0F;
    this.mTransitionLastPosition = 0.0F;
    this.mTransitionLastTime = getNanoTime();
    this.mAnimationStartTime = getNanoTime();
    this.mTransitionInstantly = false;
    this.mInterpolator = null;
    if (paramInt4 == -1)
      this.mTransitionDuration = this.mScene.getDuration() / 1000.0F; 
    this.mBeginState = -1;
    this.mScene.setTransition(-1, this.mEndState);
    SparseArray sparseArray = new SparseArray();
    if (paramInt4 == 0) {
      this.mTransitionDuration = this.mScene.getDuration() / 1000.0F;
    } else if (paramInt4 > 0) {
      this.mTransitionDuration = paramInt4 / 1000.0F;
    } 
    paramInt4 = getChildCount();
    this.mFrameArrayList.clear();
    for (paramInt1 = 0; paramInt1 < paramInt4; paramInt1++) {
      View view = getChildAt(paramInt1);
      MotionController motionController = new MotionController(view);
      this.mFrameArrayList.put(view, motionController);
      sparseArray.put(view.getId(), this.mFrameArrayList.get(view));
    } 
    this.mInTransition = true;
    this.mModel.initFrom(this.mLayoutWidget, null, this.mScene.getConstraintSet(i));
    rebuildScene();
    this.mModel.build();
    computeCurrentPositions();
    paramInt2 = getWidth();
    i = getHeight();
    if (this.mDecoratorsHelpers != null) {
      for (paramInt1 = 0; paramInt1 < paramInt4; paramInt1++) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
        if (motionController != null)
          this.mScene.getKeyFrames(motionController); 
      } 
      Iterator<MotionHelper> iterator = this.mDecoratorsHelpers.iterator();
      while (iterator.hasNext())
        ((MotionHelper)iterator.next()).onPreSetup(this, this.mFrameArrayList); 
      for (paramInt1 = 0; paramInt1 < paramInt4; paramInt1++) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
        if (motionController != null)
          motionController.setup(paramInt2, i, this.mTransitionDuration, getNanoTime()); 
      } 
    } else {
      for (paramInt1 = 0; paramInt1 < paramInt4; paramInt1++) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
        if (motionController != null) {
          this.mScene.getKeyFrames(motionController);
          motionController.setup(paramInt2, i, this.mTransitionDuration, getNanoTime());
        } 
      } 
    } 
    float f = this.mScene.getStaggered();
    if (f != 0.0F) {
      float f2 = Float.MAX_VALUE;
      float f1 = -3.4028235E38F;
      paramInt1 = 0;
      while (true) {
        paramInt2 = paramInt3;
        if (paramInt1 < paramInt4) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
          float f3 = motionController.getFinalX();
          f3 = motionController.getFinalY() + f3;
          f2 = Math.min(f2, f3);
          f1 = Math.max(f1, f3);
          paramInt1++;
          continue;
        } 
        break;
      } 
      while (paramInt2 < paramInt4) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt2));
        float f3 = motionController.getFinalX();
        float f4 = motionController.getFinalY();
        motionController.mStaggerScale = 1.0F / (1.0F - f);
        motionController.mStaggerOffset = f - (f3 + f4 - f2) * f / (f1 - f2);
        paramInt2++;
      } 
    } 
    this.mTransitionPosition = 0.0F;
    this.mTransitionLastPosition = 0.0F;
    this.mInTransition = true;
    invalidate();
  }
  
  public void updateState() {
    this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
    rebuildScene();
  }
  
  public void updateState(int paramInt, ConstraintSet paramConstraintSet) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.setConstraintSet(paramInt, paramConstraintSet); 
    updateState();
    if (this.mCurrentState == paramInt)
      paramConstraintSet.applyTo(this); 
  }
  
  public void updateStateAnimate(int paramInt1, ConstraintSet paramConstraintSet, int paramInt2) {
    if (this.mScene == null)
      return; 
    if (this.mCurrentState == paramInt1) {
      updateState(R.id.view_transition, getConstraintSet(paramInt1));
      setState(R.id.view_transition, -1, -1);
      updateState(paramInt1, paramConstraintSet);
      MotionScene.Transition transition = new MotionScene.Transition(-1, this.mScene, R.id.view_transition, paramInt1);
      transition.setDuration(paramInt2);
      setTransition(transition);
      transitionToEnd();
    } 
  }
  
  public void viewTransition(int paramInt, View... paramVarArgs) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      motionScene.viewTransition(paramInt, paramVarArgs);
      return;
    } 
    Log.e("MotionLayout", " no motionScene");
  }
  
  class DecelerateInterpolator extends MotionInterpolator {
    float currentP = 0.0F;
    
    float initalV = 0.0F;
    
    float maxA;
    
    public void config(float param1Float1, float param1Float2, float param1Float3) {
      this.initalV = param1Float1;
      this.currentP = param1Float2;
      this.maxA = param1Float3;
    }
    
    public float getInterpolation(float param1Float) {
      float f2 = this.initalV;
      if (f2 > 0.0F) {
        float f6 = this.maxA;
        float f5 = param1Float;
        if (f2 / f6 < param1Float)
          f5 = f2 / f6; 
        MotionLayout.this.mLastVelocity = f2 - f6 * f5;
        param1Float = this.initalV * f5 - this.maxA * f5 * f5 / 2.0F;
        f5 = this.currentP;
        return param1Float + f5;
      } 
      float f4 = -f2;
      float f3 = this.maxA;
      float f1 = param1Float;
      if (f4 / f3 < param1Float)
        f1 = -f2 / f3; 
      MotionLayout.this.mLastVelocity = f2 + f3 * f1;
      param1Float = this.initalV * f1 + this.maxA * f1 * f1 / 2.0F;
      f1 = this.currentP;
      return param1Float + f1;
    }
    
    public float getVelocity() {
      return MotionLayout.this.mLastVelocity;
    }
  }
  
  private class DevModeDraw {
    private static final int DEBUG_PATH_TICKS_PER_MS = 16;
    
    final int DIAMOND_SIZE = 10;
    
    final int GRAPH_COLOR = -13391360;
    
    final int KEYFRAME_COLOR = -2067046;
    
    final int RED_COLOR = -21965;
    
    final int SHADOW_COLOR = 1996488704;
    
    Rect mBounds = new Rect();
    
    DashPathEffect mDashPathEffect;
    
    Paint mFillPaint;
    
    int mKeyFrameCount;
    
    float[] mKeyFramePoints;
    
    Paint mPaint;
    
    Paint mPaintGraph;
    
    Paint mPaintKeyframes;
    
    Path mPath;
    
    int[] mPathMode;
    
    float[] mPoints;
    
    boolean mPresentationMode = false;
    
    private float[] mRectangle;
    
    int mShadowTranslate = 1;
    
    Paint mTextPaint;
    
    public DevModeDraw() {
      Paint paint2 = new Paint();
      this.mPaint = paint2;
      paint2.setAntiAlias(true);
      this.mPaint.setColor(-21965);
      this.mPaint.setStrokeWidth(2.0F);
      this.mPaint.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mPaintKeyframes = paint2;
      paint2.setAntiAlias(true);
      this.mPaintKeyframes.setColor(-2067046);
      this.mPaintKeyframes.setStrokeWidth(2.0F);
      this.mPaintKeyframes.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mPaintGraph = paint2;
      paint2.setAntiAlias(true);
      this.mPaintGraph.setColor(-13391360);
      this.mPaintGraph.setStrokeWidth(2.0F);
      this.mPaintGraph.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mTextPaint = paint2;
      paint2.setAntiAlias(true);
      this.mTextPaint.setColor(-13391360);
      this.mTextPaint.setTextSize((MotionLayout.this.getContext().getResources().getDisplayMetrics()).density * 12.0F);
      this.mRectangle = new float[8];
      Paint paint1 = new Paint();
      this.mFillPaint = paint1;
      paint1.setAntiAlias(true);
      DashPathEffect dashPathEffect = new DashPathEffect(new float[] { 4.0F, 8.0F }, 0.0F);
      this.mDashPathEffect = dashPathEffect;
      this.mPaintGraph.setPathEffect((PathEffect)dashPathEffect);
      this.mKeyFramePoints = new float[100];
      this.mPathMode = new int[50];
      if (this.mPresentationMode) {
        this.mPaint.setStrokeWidth(8.0F);
        this.mFillPaint.setStrokeWidth(8.0F);
        this.mPaintKeyframes.setStrokeWidth(8.0F);
        this.mShadowTranslate = 4;
      } 
    }
    
    private void drawBasicPath(Canvas param1Canvas) {
      param1Canvas.drawLines(this.mPoints, this.mPaint);
    }
    
    private void drawPathAsConfigured(Canvas param1Canvas) {
      int i = 0;
      boolean bool2 = false;
      boolean bool1 = false;
      while (i < this.mKeyFrameCount) {
        int[] arrayOfInt = this.mPathMode;
        if (arrayOfInt[i] == 1)
          bool2 = true; 
        if (arrayOfInt[i] == 0)
          bool1 = true; 
        i++;
      } 
      if (bool2)
        drawPathRelative(param1Canvas); 
      if (bool1)
        drawPathCartesian(param1Canvas); 
    }
    
    private void drawPathCartesian(Canvas param1Canvas) {
      float[] arrayOfFloat = this.mPoints;
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f3 = arrayOfFloat[arrayOfFloat.length - 2];
      float f4 = arrayOfFloat[arrayOfFloat.length - 1];
      param1Canvas.drawLine(Math.min(f1, f3), Math.max(f2, f4), Math.max(f1, f3), Math.max(f2, f4), this.mPaintGraph);
      param1Canvas.drawLine(Math.min(f1, f3), Math.min(f2, f4), Math.min(f1, f3), Math.max(f2, f4), this.mPaintGraph);
    }
    
    private void drawPathCartesianTicks(Canvas param1Canvas, float param1Float1, float param1Float2) {
      float[] arrayOfFloat = this.mPoints;
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f3 = arrayOfFloat[arrayOfFloat.length - 2];
      float f4 = arrayOfFloat[arrayOfFloat.length - 1];
      float f5 = Math.min(f1, f3);
      float f6 = Math.max(f2, f4);
      float f7 = param1Float1 - Math.min(f1, f3);
      float f8 = Math.max(f2, f4) - param1Float2;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("");
      stringBuilder2.append((int)((f7 * 100.0F / Math.abs(f3 - f1)) + 0.5D) / 100.0F);
      String str2 = stringBuilder2.toString();
      getTextBounds(str2, this.mTextPaint);
      param1Canvas.drawText(str2, f7 / 2.0F - (this.mBounds.width() / 2) + f5, param1Float2 - 20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, Math.min(f1, f3), param1Float2, this.mPaintGraph);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append((int)((f8 * 100.0F / Math.abs(f4 - f2)) + 0.5D) / 100.0F);
      String str1 = stringBuilder1.toString();
      getTextBounds(str1, this.mTextPaint);
      param1Canvas.drawText(str1, param1Float1 + 5.0F, f6 - f8 / 2.0F - (this.mBounds.height() / 2), this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float1, Math.max(f2, f4), this.mPaintGraph);
    }
    
    private void drawPathRelative(Canvas param1Canvas) {
      float[] arrayOfFloat = this.mPoints;
      param1Canvas.drawLine(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[arrayOfFloat.length - 2], arrayOfFloat[arrayOfFloat.length - 1], this.mPaintGraph);
    }
    
    private void drawPathRelativeTicks(Canvas param1Canvas, float param1Float1, float param1Float2) {
      float[] arrayOfFloat = this.mPoints;
      float f3 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f4 = arrayOfFloat[arrayOfFloat.length - 2];
      float f5 = arrayOfFloat[arrayOfFloat.length - 1];
      float f1 = (float)Math.hypot((f3 - f4), (f2 - f5));
      f4 -= f3;
      f5 -= f2;
      float f6 = ((param1Float1 - f3) * f4 + (param1Float2 - f2) * f5) / f1 * f1;
      f3 += f4 * f6;
      f2 += f6 * f5;
      Path path = new Path();
      path.moveTo(param1Float1, param1Float2);
      path.lineTo(f3, f2);
      f4 = (float)Math.hypot((f3 - param1Float1), (f2 - param1Float2));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append((int)(f4 * 100.0F / f1) / 100.0F);
      String str = stringBuilder.toString();
      getTextBounds(str, this.mTextPaint);
      param1Canvas.drawTextOnPath(str, path, f4 / 2.0F - (this.mBounds.width() / 2), -20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, f3, f2, this.mPaintGraph);
    }
    
    private void drawPathScreenTicks(Canvas param1Canvas, float param1Float1, float param1Float2, int param1Int1, int param1Int2) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("");
      stringBuilder2.append((int)(((param1Float1 - (param1Int1 / 2)) * 100.0F / (MotionLayout.this.getWidth() - param1Int1)) + 0.5D) / 100.0F);
      String str2 = stringBuilder2.toString();
      getTextBounds(str2, this.mTextPaint);
      param1Canvas.drawText(str2, param1Float1 / 2.0F - (this.mBounds.width() / 2) + 0.0F, param1Float2 - 20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, Math.min(0.0F, 1.0F), param1Float2, this.mPaintGraph);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append((int)(((param1Float2 - (param1Int2 / 2)) * 100.0F / (MotionLayout.this.getHeight() - param1Int2)) + 0.5D) / 100.0F);
      String str1 = stringBuilder1.toString();
      getTextBounds(str1, this.mTextPaint);
      param1Canvas.drawText(str1, param1Float1 + 5.0F, 0.0F - param1Float2 / 2.0F - (this.mBounds.height() / 2), this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float1, Math.max(0.0F, 1.0F), this.mPaintGraph);
    }
    
    private void drawRectangle(Canvas param1Canvas, MotionController param1MotionController) {
      this.mPath.reset();
      for (int i = 0; i <= 50; i++) {
        param1MotionController.buildRect(i / 50, this.mRectangle, 0);
        Path path = this.mPath;
        float[] arrayOfFloat = this.mRectangle;
        path.moveTo(arrayOfFloat[0], arrayOfFloat[1]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[2], arrayOfFloat[3]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[4], arrayOfFloat[5]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[6], arrayOfFloat[7]);
        this.mPath.close();
      } 
      this.mPaint.setColor(1140850688);
      param1Canvas.translate(2.0F, 2.0F);
      param1Canvas.drawPath(this.mPath, this.mPaint);
      param1Canvas.translate(-2.0F, -2.0F);
      this.mPaint.setColor(-65536);
      param1Canvas.drawPath(this.mPath, this.mPaint);
    }
    
    private void drawTicks(Canvas param1Canvas, int param1Int1, int param1Int2, MotionController param1MotionController) {
      boolean bool1;
      boolean bool2;
      if (param1MotionController.mView != null) {
        bool1 = param1MotionController.mView.getWidth();
        bool2 = param1MotionController.mView.getHeight();
      } else {
        bool1 = false;
        bool2 = false;
      } 
      int i;
      for (i = 1; i < param1Int2 - 1; i++) {
        if (param1Int1 != 4 || this.mPathMode[i - 1] != 0) {
          float[] arrayOfFloat1 = this.mKeyFramePoints;
          int j = i * 2;
          float f2 = arrayOfFloat1[j];
          float f1 = arrayOfFloat1[j + 1];
          this.mPath.reset();
          this.mPath.moveTo(f2, f1 + 10.0F);
          this.mPath.lineTo(f2 + 10.0F, f1);
          this.mPath.lineTo(f2, f1 - 10.0F);
          this.mPath.lineTo(f2 - 10.0F, f1);
          this.mPath.close();
          j = i - 1;
          param1MotionController.getKeyFrame(j);
          if (param1Int1 == 4) {
            int[] arrayOfInt = this.mPathMode;
            if (arrayOfInt[j] == 1) {
              drawPathRelativeTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F);
            } else if (arrayOfInt[j] == 0) {
              drawPathCartesianTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F);
            } else if (arrayOfInt[j] == 2) {
              drawPathScreenTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F, bool1, bool2);
            } 
            param1Canvas.drawPath(this.mPath, this.mFillPaint);
          } 
          if (param1Int1 == 2)
            drawPathRelativeTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F); 
          if (param1Int1 == 3)
            drawPathCartesianTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F); 
          if (param1Int1 == 6)
            drawPathScreenTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F, bool1, bool2); 
          param1Canvas.drawPath(this.mPath, this.mFillPaint);
        } 
      } 
      float[] arrayOfFloat = this.mPoints;
      if (arrayOfFloat.length > 1) {
        param1Canvas.drawCircle(arrayOfFloat[0], arrayOfFloat[1], 8.0F, this.mPaintKeyframes);
        arrayOfFloat = this.mPoints;
        param1Canvas.drawCircle(arrayOfFloat[arrayOfFloat.length - 2], arrayOfFloat[arrayOfFloat.length - 1], 8.0F, this.mPaintKeyframes);
      } 
    }
    
    private void drawTranslation(Canvas param1Canvas, float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      param1Canvas.drawRect(param1Float1, param1Float2, param1Float3, param1Float4, this.mPaintGraph);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float3, param1Float4, this.mPaintGraph);
    }
    
    public void draw(Canvas param1Canvas, HashMap<View, MotionController> param1HashMap, int param1Int1, int param1Int2) {
      if (param1HashMap != null) {
        if (param1HashMap.size() == 0)
          return; 
        param1Canvas.save();
        if (!MotionLayout.this.isInEditMode() && (param1Int2 & 0x1) == 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(MotionLayout.this.getContext().getResources().getResourceName(MotionLayout.this.mEndState));
          stringBuilder.append(":");
          stringBuilder.append(MotionLayout.this.getProgress());
          String str = stringBuilder.toString();
          param1Canvas.drawText(str, 10.0F, (MotionLayout.this.getHeight() - 30), this.mTextPaint);
          param1Canvas.drawText(str, 11.0F, (MotionLayout.this.getHeight() - 29), this.mPaint);
        } 
        for (MotionController motionController : param1HashMap.values()) {
          int j = motionController.getDrawPath();
          int i = j;
          if (param1Int2 > 0) {
            i = j;
            if (j == 0)
              i = 1; 
          } 
          if (i == 0)
            continue; 
          this.mKeyFrameCount = motionController.buildKeyFrames(this.mKeyFramePoints, this.mPathMode);
          if (i >= 1) {
            j = param1Int1 / 16;
            float[] arrayOfFloat = this.mPoints;
            if (arrayOfFloat == null || arrayOfFloat.length != j * 2) {
              this.mPoints = new float[j * 2];
              this.mPath = new Path();
            } 
            int k = this.mShadowTranslate;
            param1Canvas.translate(k, k);
            this.mPaint.setColor(1996488704);
            this.mFillPaint.setColor(1996488704);
            this.mPaintKeyframes.setColor(1996488704);
            this.mPaintGraph.setColor(1996488704);
            motionController.buildPath(this.mPoints, j);
            drawAll(param1Canvas, i, this.mKeyFrameCount, motionController);
            this.mPaint.setColor(-21965);
            this.mPaintKeyframes.setColor(-2067046);
            this.mFillPaint.setColor(-2067046);
            this.mPaintGraph.setColor(-13391360);
            j = this.mShadowTranslate;
            param1Canvas.translate(-j, -j);
            drawAll(param1Canvas, i, this.mKeyFrameCount, motionController);
            if (i == 5)
              drawRectangle(param1Canvas, motionController); 
          } 
        } 
        param1Canvas.restore();
      } 
    }
    
    public void drawAll(Canvas param1Canvas, int param1Int1, int param1Int2, MotionController param1MotionController) {
      if (param1Int1 == 4)
        drawPathAsConfigured(param1Canvas); 
      if (param1Int1 == 2)
        drawPathRelative(param1Canvas); 
      if (param1Int1 == 3)
        drawPathCartesian(param1Canvas); 
      drawBasicPath(param1Canvas);
      drawTicks(param1Canvas, param1Int1, param1Int2, param1MotionController);
    }
    
    void getTextBounds(String param1String, Paint param1Paint) {
      param1Paint.getTextBounds(param1String, 0, param1String.length(), this.mBounds);
    }
  }
  
  class Model {
    ConstraintSet mEnd = null;
    
    int mEndId;
    
    ConstraintWidgetContainer mLayoutEnd = new ConstraintWidgetContainer();
    
    ConstraintWidgetContainer mLayoutStart = new ConstraintWidgetContainer();
    
    ConstraintSet mStart = null;
    
    int mStartId;
    
    private void computeStartEndSize(int param1Int1, int param1Int2) {
      int i = MotionLayout.this.getOptimizationLevel();
      if (MotionLayout.this.mCurrentState == MotionLayout.this.getStartState()) {
        int j;
        int k;
        MotionLayout motionLayout = MotionLayout.this;
        ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutEnd;
        ConstraintSet constraintSet2 = this.mEnd;
        if (constraintSet2 == null || constraintSet2.mRotate == 0) {
          j = param1Int1;
        } else {
          j = param1Int2;
        } 
        constraintSet2 = this.mEnd;
        if (constraintSet2 == null || constraintSet2.mRotate == 0) {
          k = param1Int2;
        } else {
          k = param1Int1;
        } 
        motionLayout.resolveSystem(constraintWidgetContainer, i, j, k);
        ConstraintSet constraintSet1 = this.mStart;
        if (constraintSet1 != null) {
          MotionLayout motionLayout1 = MotionLayout.this;
          ConstraintWidgetContainer constraintWidgetContainer1 = this.mLayoutStart;
          if (constraintSet1.mRotate == 0) {
            j = param1Int1;
          } else {
            j = param1Int2;
          } 
          if (this.mStart.mRotate == 0)
            param1Int1 = param1Int2; 
          motionLayout1.resolveSystem(constraintWidgetContainer1, i, j, param1Int1);
          return;
        } 
      } else {
        int j;
        ConstraintSet constraintSet1 = this.mStart;
        if (constraintSet1 != null) {
          int k;
          MotionLayout motionLayout1 = MotionLayout.this;
          ConstraintWidgetContainer constraintWidgetContainer1 = this.mLayoutStart;
          if (constraintSet1.mRotate == 0) {
            j = param1Int1;
          } else {
            j = param1Int2;
          } 
          if (this.mStart.mRotate == 0) {
            k = param1Int2;
          } else {
            k = param1Int1;
          } 
          motionLayout1.resolveSystem(constraintWidgetContainer1, i, j, k);
        } 
        MotionLayout motionLayout = MotionLayout.this;
        ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutEnd;
        ConstraintSet constraintSet2 = this.mEnd;
        if (constraintSet2 == null || constraintSet2.mRotate == 0) {
          j = param1Int1;
        } else {
          j = param1Int2;
        } 
        constraintSet2 = this.mEnd;
        if (constraintSet2 == null || constraintSet2.mRotate == 0)
          param1Int1 = param1Int2; 
        motionLayout.resolveSystem(constraintWidgetContainer, i, j, param1Int1);
      } 
    }
    
    private void debugLayout(String param1String, ConstraintWidgetContainer param1ConstraintWidgetContainer) {
      View view = (View)param1ConstraintWidgetContainer.getCompanionWidget();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(param1String);
      stringBuilder2.append(" ");
      stringBuilder2.append(Debug.getName(view));
      String str = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append("  ========= ");
      stringBuilder1.append(param1ConstraintWidgetContainer);
      Log.v("MotionLayout", stringBuilder1.toString());
      int j = param1ConstraintWidgetContainer.getChildren().size();
      for (int i = 0; i < j; i++) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append("[");
        stringBuilder1.append(i);
        stringBuilder1.append("] ");
        String str3 = stringBuilder1.toString();
        ConstraintWidget constraintWidget = param1ConstraintWidgetContainer.getChildren().get(i);
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append("");
        ConstraintAnchor constraintAnchor = constraintWidget.mTop.mTarget;
        String str2 = "_";
        if (constraintAnchor != null) {
          str1 = "T";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        String str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        if (constraintWidget.mBottom.mTarget != null) {
          str1 = "B";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        if (constraintWidget.mLeft.mTarget != null) {
          str1 = "L";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        str1 = str2;
        if (constraintWidget.mRight.mTarget != null)
          str1 = "R"; 
        stringBuilder4.append(str1);
        String str4 = stringBuilder4.toString();
        View view1 = (View)constraintWidget.getCompanionWidget();
        str2 = Debug.getName(view1);
        str1 = str2;
        if (view1 instanceof TextView) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str2);
          stringBuilder.append("(");
          stringBuilder.append(((TextView)view1).getText());
          stringBuilder.append(")");
          str1 = stringBuilder.toString();
        } 
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str3);
        stringBuilder3.append("  ");
        stringBuilder3.append(str1);
        stringBuilder3.append(" ");
        stringBuilder3.append(constraintWidget);
        stringBuilder3.append(" ");
        stringBuilder3.append(str4);
        Log.v("MotionLayout", stringBuilder3.toString());
      } 
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(" done. ");
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void debugLayoutParam(String param1String, ConstraintLayout.LayoutParams param1LayoutParams) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" ");
      if (param1LayoutParams.startToStart != -1) {
        str2 = "SS";
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      String str2 = stringBuilder2.toString();
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      int i = param1LayoutParams.startToEnd;
      String str3 = "|__";
      if (i != -1) {
        str2 = "|SE";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.endToStart != -1) {
        str2 = "|ES";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.endToEnd != -1) {
        str2 = "|EE";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.leftToLeft != -1) {
        str2 = "|LL";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.leftToRight != -1) {
        str2 = "|LR";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.rightToLeft != -1) {
        str2 = "|RL";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.rightToRight != -1) {
        str2 = "|RR";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.topToTop != -1) {
        str2 = "|TT";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.topToBottom != -1) {
        str2 = "|TB";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.bottomToTop != -1) {
        str2 = "|BT";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      str2 = str3;
      if (param1LayoutParams.bottomToBottom != -1)
        str2 = "|BB"; 
      stringBuilder3.append(str2);
      String str1 = stringBuilder3.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(param1String);
      stringBuilder1.append(str1);
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void debugWidget(String param1String, ConstraintWidget param1ConstraintWidget) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" ");
      ConstraintAnchor constraintAnchor2 = param1ConstraintWidget.mTop.mTarget;
      String str4 = "B";
      String str3 = "__";
      if (constraintAnchor2 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("T");
        if (param1ConstraintWidget.mTop.mTarget.mType == ConstraintAnchor.Type.TOP) {
          str2 = "T";
        } else {
          str2 = "B";
        } 
        stringBuilder.append(str2);
        str2 = stringBuilder.toString();
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      String str2 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      if (param1ConstraintWidget.mBottom.mTarget != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("B");
        str2 = str4;
        if (param1ConstraintWidget.mBottom.mTarget.mType == ConstraintAnchor.Type.TOP)
          str2 = "T"; 
        stringBuilder.append(str2);
        str2 = stringBuilder.toString();
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      str2 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      ConstraintAnchor constraintAnchor1 = param1ConstraintWidget.mLeft.mTarget;
      str4 = "R";
      if (constraintAnchor1 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("L");
        if (param1ConstraintWidget.mLeft.mTarget.mType == ConstraintAnchor.Type.LEFT) {
          str1 = "L";
        } else {
          str1 = "R";
        } 
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } else {
        str1 = "__";
      } 
      stringBuilder2.append(str1);
      String str1 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str1);
      str1 = str3;
      if (param1ConstraintWidget.mRight.mTarget != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("R");
        str1 = str4;
        if (param1ConstraintWidget.mRight.mTarget.mType == ConstraintAnchor.Type.LEFT)
          str1 = "L"; 
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } 
      stringBuilder2.append(str1);
      str1 = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(param1String);
      stringBuilder1.append(str1);
      stringBuilder1.append(" ---  ");
      stringBuilder1.append(param1ConstraintWidget);
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void setupConstraintWidget(ConstraintWidgetContainer param1ConstraintWidgetContainer, ConstraintSet param1ConstraintSet) {
      SparseArray sparseArray = new SparseArray();
      Constraints.LayoutParams layoutParams = new Constraints.LayoutParams(-2, -2);
      sparseArray.clear();
      sparseArray.put(0, param1ConstraintWidgetContainer);
      sparseArray.put(MotionLayout.this.getId(), param1ConstraintWidgetContainer);
      if (param1ConstraintSet != null && param1ConstraintSet.mRotate != 0) {
        MotionLayout motionLayout = MotionLayout.this;
        motionLayout.resolveSystem(this.mLayoutEnd, motionLayout.getOptimizationLevel(), View.MeasureSpec.makeMeasureSpec(MotionLayout.this.getHeight(), 1073741824), View.MeasureSpec.makeMeasureSpec(MotionLayout.this.getWidth(), 1073741824));
      } 
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren()) {
        constraintWidget.setAnimated(true);
        sparseArray.put(((View)constraintWidget.getCompanionWidget()).getId(), constraintWidget);
      } 
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren()) {
        View view = (View)constraintWidget.getCompanionWidget();
        param1ConstraintSet.applyToLayoutParams(view.getId(), (ConstraintLayout.LayoutParams)layoutParams);
        constraintWidget.setWidth(param1ConstraintSet.getWidth(view.getId()));
        constraintWidget.setHeight(param1ConstraintSet.getHeight(view.getId()));
        if (view instanceof ConstraintHelper) {
          param1ConstraintSet.applyToHelper((ConstraintHelper)view, constraintWidget, (ConstraintLayout.LayoutParams)layoutParams, sparseArray);
          if (view instanceof Barrier)
            ((Barrier)view).validateParams(); 
        } 
        if (Build.VERSION.SDK_INT >= 17) {
          layoutParams.resolveLayoutDirection(MotionLayout.this.getLayoutDirection());
        } else {
          layoutParams.resolveLayoutDirection(0);
        } 
        MotionLayout.this.applyConstraintsFromLayoutParams(false, view, constraintWidget, (ConstraintLayout.LayoutParams)layoutParams, sparseArray);
        if (param1ConstraintSet.getVisibilityMode(view.getId()) == 1) {
          constraintWidget.setVisibility(view.getVisibility());
          continue;
        } 
        constraintWidget.setVisibility(param1ConstraintSet.getVisibility(view.getId()));
      } 
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren()) {
        if (constraintWidget instanceof VirtualLayout) {
          ConstraintHelper constraintHelper = (ConstraintHelper)constraintWidget.getCompanionWidget();
          Helper helper = (Helper)constraintWidget;
          constraintHelper.updatePreLayout(param1ConstraintWidgetContainer, helper, sparseArray);
          ((VirtualLayout)helper).captureWidgets();
        } 
      } 
    }
    
    public void build() {
      int j = MotionLayout.this.getChildCount();
      MotionLayout.this.mFrameArrayList.clear();
      SparseArray sparseArray = new SparseArray();
      int[] arrayOfInt = new int[j];
      int i;
      for (i = 0; i < j; i++) {
        View view = MotionLayout.this.getChildAt(i);
        MotionController motionController = new MotionController(view);
        int k = view.getId();
        arrayOfInt[i] = k;
        sparseArray.put(k, motionController);
        MotionLayout.this.mFrameArrayList.put(view, motionController);
      } 
      for (i = 0; i < j; i++) {
        View view = MotionLayout.this.getChildAt(i);
        MotionController motionController = MotionLayout.this.mFrameArrayList.get(view);
        if (motionController != null) {
          if (this.mStart != null) {
            ConstraintWidget constraintWidget = getWidget(this.mLayoutStart, view);
            if (constraintWidget != null) {
              motionController.setStartState(MotionLayout.this.toRect(constraintWidget), this.mStart, MotionLayout.this.getWidth(), MotionLayout.this.getHeight());
            } else if (MotionLayout.this.mDebugPath != 0) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(Debug.getLocation());
              stringBuilder.append("no widget for  ");
              stringBuilder.append(Debug.getName(view));
              stringBuilder.append(" (");
              stringBuilder.append(view.getClass().getName());
              stringBuilder.append(")");
              Log.e("MotionLayout", stringBuilder.toString());
            } 
          } else if (MotionLayout.this.mInRotation) {
            motionController.setStartState(MotionLayout.this.mPreRotate.get(view), view, MotionLayout.this.mRotatMode, MotionLayout.this.mPreRotateWidth, MotionLayout.this.mPreRotateHeight);
          } 
          if (this.mEnd != null) {
            ConstraintWidget constraintWidget = getWidget(this.mLayoutEnd, view);
            if (constraintWidget != null) {
              motionController.setEndState(MotionLayout.this.toRect(constraintWidget), this.mEnd, MotionLayout.this.getWidth(), MotionLayout.this.getHeight());
            } else if (MotionLayout.this.mDebugPath != 0) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(Debug.getLocation());
              stringBuilder.append("no widget for  ");
              stringBuilder.append(Debug.getName(view));
              stringBuilder.append(" (");
              stringBuilder.append(view.getClass().getName());
              stringBuilder.append(")");
              Log.e("MotionLayout", stringBuilder.toString());
            } 
          } 
        } 
      } 
      for (i = 0; i < j; i++) {
        MotionController motionController = (MotionController)sparseArray.get(arrayOfInt[i]);
        int k = motionController.getAnimateRelativeTo();
        if (k != -1)
          motionController.setupRelative((MotionController)sparseArray.get(k)); 
      } 
    }
    
    void copy(ConstraintWidgetContainer param1ConstraintWidgetContainer1, ConstraintWidgetContainer param1ConstraintWidgetContainer2) {
      ArrayList arrayList = param1ConstraintWidgetContainer1.getChildren();
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put(param1ConstraintWidgetContainer1, param1ConstraintWidgetContainer2);
      param1ConstraintWidgetContainer2.getChildren().clear();
      param1ConstraintWidgetContainer2.copy((ConstraintWidget)param1ConstraintWidgetContainer1, hashMap);
      for (ConstraintWidget constraintWidget2 : arrayList) {
        ConstraintWidget constraintWidget1;
        if (constraintWidget2 instanceof Barrier) {
          Barrier barrier = new Barrier();
        } else if (constraintWidget2 instanceof Guideline) {
          Guideline guideline = new Guideline();
        } else if (constraintWidget2 instanceof Flow) {
          Flow flow = new Flow();
        } else if (constraintWidget2 instanceof Placeholder) {
          Placeholder placeholder = new Placeholder();
        } else if (constraintWidget2 instanceof Helper) {
          HelperWidget helperWidget = new HelperWidget();
        } else {
          constraintWidget1 = new ConstraintWidget();
        } 
        param1ConstraintWidgetContainer2.add(constraintWidget1);
        hashMap.put(constraintWidget2, constraintWidget1);
      } 
      for (ConstraintWidget constraintWidget : arrayList)
        ((ConstraintWidget)hashMap.get(constraintWidget)).copy(constraintWidget, hashMap); 
    }
    
    ConstraintWidget getWidget(ConstraintWidgetContainer param1ConstraintWidgetContainer, View param1View) {
      if (param1ConstraintWidgetContainer.getCompanionWidget() == param1View)
        return (ConstraintWidget)param1ConstraintWidgetContainer; 
      ArrayList<ConstraintWidget> arrayList = param1ConstraintWidgetContainer.getChildren();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = arrayList.get(i);
        if (constraintWidget.getCompanionWidget() == param1View)
          return constraintWidget; 
      } 
      return null;
    }
    
    void initFrom(ConstraintWidgetContainer param1ConstraintWidgetContainer, ConstraintSet param1ConstraintSet1, ConstraintSet param1ConstraintSet2) {
      this.mStart = param1ConstraintSet1;
      this.mEnd = param1ConstraintSet2;
      this.mLayoutStart = new ConstraintWidgetContainer();
      this.mLayoutEnd = new ConstraintWidgetContainer();
      this.mLayoutStart.setMeasurer(MotionLayout.this.mLayoutWidget.getMeasurer());
      this.mLayoutEnd.setMeasurer(MotionLayout.this.mLayoutWidget.getMeasurer());
      this.mLayoutStart.removeAllChildren();
      this.mLayoutEnd.removeAllChildren();
      copy(MotionLayout.this.mLayoutWidget, this.mLayoutStart);
      copy(MotionLayout.this.mLayoutWidget, this.mLayoutEnd);
      if (MotionLayout.this.mTransitionLastPosition > 0.5D) {
        if (param1ConstraintSet1 != null)
          setupConstraintWidget(this.mLayoutStart, param1ConstraintSet1); 
        setupConstraintWidget(this.mLayoutEnd, param1ConstraintSet2);
      } else {
        setupConstraintWidget(this.mLayoutEnd, param1ConstraintSet2);
        if (param1ConstraintSet1 != null)
          setupConstraintWidget(this.mLayoutStart, param1ConstraintSet1); 
      } 
      this.mLayoutStart.setRtl(MotionLayout.this.isRtl());
      this.mLayoutStart.updateHierarchy();
      this.mLayoutEnd.setRtl(MotionLayout.this.isRtl());
      this.mLayoutEnd.updateHierarchy();
      ViewGroup.LayoutParams layoutParams = MotionLayout.this.getLayoutParams();
      if (layoutParams != null) {
        if (layoutParams.width == -2) {
          this.mLayoutStart.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
          this.mLayoutEnd.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
        } 
        if (layoutParams.height == -2) {
          this.mLayoutStart.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
          this.mLayoutEnd.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
        } 
      } 
    }
    
    public boolean isNotConfiguredWith(int param1Int1, int param1Int2) {
      return (param1Int1 != this.mStartId || param1Int2 != this.mEndId);
    }
    
    public void measure(int param1Int1, int param1Int2) {
      boolean bool1;
      boolean bool2;
      int i = View.MeasureSpec.getMode(param1Int1);
      int j = View.MeasureSpec.getMode(param1Int2);
      MotionLayout.this.mWidthMeasureMode = i;
      MotionLayout.this.mHeightMeasureMode = j;
      MotionLayout.this.getOptimizationLevel();
      computeStartEndSize(param1Int1, param1Int2);
      if (MotionLayout.this.getParent() instanceof MotionLayout && i == 1073741824 && j == 1073741824) {
        i = 0;
      } else {
        i = 1;
      } 
      if (i != 0) {
        computeStartEndSize(param1Int1, param1Int2);
        MotionLayout.this.mStartWrapWidth = this.mLayoutStart.getWidth();
        MotionLayout.this.mStartWrapHeight = this.mLayoutStart.getHeight();
        MotionLayout.this.mEndWrapWidth = this.mLayoutEnd.getWidth();
        MotionLayout.this.mEndWrapHeight = this.mLayoutEnd.getHeight();
        MotionLayout motionLayout = MotionLayout.this;
        if (motionLayout.mStartWrapWidth != MotionLayout.this.mEndWrapWidth || MotionLayout.this.mStartWrapHeight != MotionLayout.this.mEndWrapHeight) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        motionLayout.mMeasureDuringTransition = bool1;
      } 
      i = MotionLayout.this.mStartWrapWidth;
      j = MotionLayout.this.mStartWrapHeight;
      if (MotionLayout.this.mWidthMeasureMode == Integer.MIN_VALUE || MotionLayout.this.mWidthMeasureMode == 0)
        i = (int)(MotionLayout.this.mStartWrapWidth + MotionLayout.this.mPostInterpolationPosition * (MotionLayout.this.mEndWrapWidth - MotionLayout.this.mStartWrapWidth)); 
      if (MotionLayout.this.mHeightMeasureMode == Integer.MIN_VALUE || MotionLayout.this.mHeightMeasureMode == 0)
        j = (int)(MotionLayout.this.mStartWrapHeight + MotionLayout.this.mPostInterpolationPosition * (MotionLayout.this.mEndWrapHeight - MotionLayout.this.mStartWrapHeight)); 
      if (this.mLayoutStart.isWidthMeasuredTooSmall() || this.mLayoutEnd.isWidthMeasuredTooSmall()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.mLayoutStart.isHeightMeasuredTooSmall() || this.mLayoutEnd.isHeightMeasuredTooSmall()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      MotionLayout.this.resolveMeasuredDimension(param1Int1, param1Int2, i, j, bool1, bool2);
    }
    
    public void reEvaluateState() {
      measure(MotionLayout.this.mLastWidthMeasureSpec, MotionLayout.this.mLastHeightMeasureSpec);
      MotionLayout.this.setupMotionViews();
    }
    
    public void setMeasuredId(int param1Int1, int param1Int2) {
      this.mStartId = param1Int1;
      this.mEndId = param1Int2;
    }
  }
  
  protected static interface MotionTracker {
    void addMovement(MotionEvent param1MotionEvent);
    
    void clear();
    
    void computeCurrentVelocity(int param1Int);
    
    void computeCurrentVelocity(int param1Int, float param1Float);
    
    float getXVelocity();
    
    float getXVelocity(int param1Int);
    
    float getYVelocity();
    
    float getYVelocity(int param1Int);
    
    void recycle();
  }
  
  private static class MyTracker implements MotionTracker {
    private static MyTracker me = new MyTracker();
    
    VelocityTracker tracker;
    
    public static MyTracker obtain() {
      me.tracker = VelocityTracker.obtain();
      return me;
    }
    
    public void addMovement(MotionEvent param1MotionEvent) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.addMovement(param1MotionEvent); 
    }
    
    public void clear() {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    }
    
    public void computeCurrentVelocity(int param1Int) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.computeCurrentVelocity(param1Int); 
    }
    
    public void computeCurrentVelocity(int param1Int, float param1Float) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.computeCurrentVelocity(param1Int, param1Float); 
    }
    
    public float getXVelocity() {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getXVelocity() : 0.0F;
    }
    
    public float getXVelocity(int param1Int) {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getXVelocity(param1Int) : 0.0F;
    }
    
    public float getYVelocity() {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getYVelocity() : 0.0F;
    }
    
    public float getYVelocity(int param1Int) {
      return (this.tracker != null) ? getYVelocity(param1Int) : 0.0F;
    }
    
    public void recycle() {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null) {
        velocityTracker.recycle();
        this.tracker = null;
      } 
    }
  }
  
  class StateCache {
    final String KeyEndState = "motion.EndState";
    
    final String KeyProgress = "motion.progress";
    
    final String KeyStartState = "motion.StartState";
    
    final String KeyVelocity = "motion.velocity";
    
    int endState = -1;
    
    float mProgress = Float.NaN;
    
    float mVelocity = Float.NaN;
    
    int startState = -1;
    
    void apply() {
      int i = this.startState;
      if (i != -1 || this.endState != -1) {
        if (i == -1) {
          MotionLayout.this.transitionToState(this.endState);
        } else {
          int j = this.endState;
          if (j == -1) {
            MotionLayout.this.setState(i, -1, -1);
          } else {
            MotionLayout.this.setTransition(i, j);
          } 
        } 
        MotionLayout.this.setState(MotionLayout.TransitionState.SETUP);
      } 
      if (Float.isNaN(this.mVelocity)) {
        if (Float.isNaN(this.mProgress))
          return; 
        MotionLayout.this.setProgress(this.mProgress);
        return;
      } 
      MotionLayout.this.setProgress(this.mProgress, this.mVelocity);
      this.mProgress = Float.NaN;
      this.mVelocity = Float.NaN;
      this.startState = -1;
      this.endState = -1;
    }
    
    public Bundle getTransitionState() {
      Bundle bundle = new Bundle();
      bundle.putFloat("motion.progress", this.mProgress);
      bundle.putFloat("motion.velocity", this.mVelocity);
      bundle.putInt("motion.StartState", this.startState);
      bundle.putInt("motion.EndState", this.endState);
      return bundle;
    }
    
    public void recordState() {
      this.endState = MotionLayout.this.mEndState;
      this.startState = MotionLayout.this.mBeginState;
      this.mVelocity = MotionLayout.this.getVelocity();
      this.mProgress = MotionLayout.this.getProgress();
    }
    
    public void setEndState(int param1Int) {
      this.endState = param1Int;
    }
    
    public void setProgress(float param1Float) {
      this.mProgress = param1Float;
    }
    
    public void setStartState(int param1Int) {
      this.startState = param1Int;
    }
    
    public void setTransitionState(Bundle param1Bundle) {
      this.mProgress = param1Bundle.getFloat("motion.progress");
      this.mVelocity = param1Bundle.getFloat("motion.velocity");
      this.startState = param1Bundle.getInt("motion.StartState");
      this.endState = param1Bundle.getInt("motion.EndState");
    }
    
    public void setVelocity(float param1Float) {
      this.mVelocity = param1Float;
    }
  }
  
  public static interface TransitionListener {
    void onTransitionChange(MotionLayout param1MotionLayout, int param1Int1, int param1Int2, float param1Float);
    
    void onTransitionCompleted(MotionLayout param1MotionLayout, int param1Int);
    
    void onTransitionStarted(MotionLayout param1MotionLayout, int param1Int1, int param1Int2);
    
    void onTransitionTrigger(MotionLayout param1MotionLayout, int param1Int, boolean param1Boolean, float param1Float);
  }
  
  enum TransitionState {
    FINISHED, MOVING, SETUP, UNDEFINED;
    
    static {
      MOVING = new TransitionState("MOVING", 2);
      FINISHED = new TransitionState("FINISHED", 3);
      $VALUES = $values();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */