package androidx.constraintlayout.motion.utils;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.motion.widget.Debug;
import androidx.constraintlayout.widget.ConstraintAttribute;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class CustomSupport {
  private static final String TAG = "CustomSupport";
  
  private static int clamp(int paramInt) {
    paramInt = (paramInt & paramInt >> 31) - 255;
    return (paramInt & paramInt >> 31) + 255;
  }
  
  public static void setInterpolatedValue(ConstraintAttribute paramConstraintAttribute, View paramView, float[] paramArrayOffloat) {
    Class<?> clazz = paramView.getClass();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("set");
    stringBuilder.append(paramConstraintAttribute.getName());
    String str = stringBuilder.toString();
    try {
      Method method;
      StringBuilder stringBuilder1;
      ColorDrawable colorDrawable;
      int j;
      int k;
      int m;
      int i = null.$SwitchMap$androidx$constraintlayout$widget$ConstraintAttribute$AttributeType[paramConstraintAttribute.getType().ordinal()];
      boolean bool1 = true;
      switch (i) {
        case 7:
          clazz.getMethod(str, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(paramArrayOffloat[0]) });
          return;
        case 6:
          method = clazz.getMethod(str, new Class[] { boolean.class });
          if (paramArrayOffloat[0] > 0.5F) {
            method.invoke(paramView, new Object[] { Boolean.valueOf(bool1) });
            return;
          } 
          break;
        case 5:
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("unable to interpolate strings ");
          stringBuilder1.append(method.getName());
          throw new RuntimeException(stringBuilder1.toString());
        case 4:
          method = clazz.getMethod(str, new Class[] { int.class });
          i = clamp((int)((float)Math.pow(stringBuilder1[0], 0.45454545454545453D) * 255.0F));
          j = clamp((int)((float)Math.pow(stringBuilder1[1], 0.45454545454545453D) * 255.0F));
          k = clamp((int)((float)Math.pow(stringBuilder1[2], 0.45454545454545453D) * 255.0F));
          method.invoke(paramView, new Object[] { Integer.valueOf(i << 16 | clamp((int)(stringBuilder1[3] * 255.0F)) << 24 | j << 8 | k) });
          return;
        case 3:
          method = clazz.getMethod(str, new Class[] { Drawable.class });
          i = clamp((int)((float)Math.pow(stringBuilder1[0], 0.45454545454545453D) * 255.0F));
          j = clamp((int)((float)Math.pow(stringBuilder1[1], 0.45454545454545453D) * 255.0F));
          k = clamp((int)((float)Math.pow(stringBuilder1[2], 0.45454545454545453D) * 255.0F));
          m = clamp((int)(stringBuilder1[3] * 255.0F));
          colorDrawable = new ColorDrawable();
          colorDrawable.setColor(i << 16 | m << 24 | j << 8 | k);
          method.invoke(paramView, new Object[] { colorDrawable });
          return;
        case 2:
          clazz.getMethod(str, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(colorDrawable[0]) });
          return;
        case 1:
          clazz.getMethod(str, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf((int)colorDrawable[0]) });
          return;
        default:
          return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("no method ");
      stringBuilder1.append(str);
      stringBuilder1.append(" on View \"");
      stringBuilder1.append(Debug.getName(paramView));
      stringBuilder1.append("\"");
      Log.e("CustomSupport", stringBuilder1.toString());
      noSuchMethodException.printStackTrace();
      return;
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("cannot access method ");
      stringBuilder1.append(str);
      stringBuilder1.append(" on View \"");
      stringBuilder1.append(Debug.getName(paramView));
      stringBuilder1.append("\"");
      Log.e("CustomSupport", stringBuilder1.toString());
      illegalAccessException.printStackTrace();
      return;
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.printStackTrace();
      return;
    } 
    boolean bool = false;
    invocationTargetException.invoke(paramView, new Object[] { Boolean.valueOf(bool) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\motio\\utils\CustomSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */