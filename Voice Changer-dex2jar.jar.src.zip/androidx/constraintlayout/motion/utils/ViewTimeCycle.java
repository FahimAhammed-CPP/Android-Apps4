package androidx.constraintlayout.motion.utils;

import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.core.motion.utils.CurveFit;
import androidx.constraintlayout.core.motion.utils.KeyCache;
import androidx.constraintlayout.core.motion.utils.TimeCycleSplineSet;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.ConstraintAttribute;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class ViewTimeCycle extends TimeCycleSplineSet {
  private static final String TAG = "ViewTimeCycle";
  
  public static ViewTimeCycle makeCustomSpline(String paramString, SparseArray<ConstraintAttribute> paramSparseArray) {
    return new CustomSet(paramString, paramSparseArray);
  }
  
  public static ViewTimeCycle makeSpline(String paramString, long paramLong) {
    AlphaSet alphaSet;
    PathRotate pathRotate;
    ElevationSet elevationSet;
    RotationSet rotationSet;
    ScaleYset scaleYset;
    ScaleXset scaleXset;
    ProgressSet progressSet;
    TranslationZset translationZset;
    TranslationYset translationYset;
    TranslationXset translationXset;
    RotationYset rotationYset;
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 92909918:
        if (!paramString.equals("alpha"))
          break; 
        b = 11;
        break;
      case 37232917:
        if (!paramString.equals("transitionPathRotate"))
          break; 
        b = 10;
        break;
      case -4379043:
        if (!paramString.equals("elevation"))
          break; 
        b = 9;
        break;
      case -40300674:
        if (!paramString.equals("rotation"))
          break; 
        b = 8;
        break;
      case -908189617:
        if (!paramString.equals("scaleY"))
          break; 
        b = 7;
        break;
      case -908189618:
        if (!paramString.equals("scaleX"))
          break; 
        b = 6;
        break;
      case -1001078227:
        if (!paramString.equals("progress"))
          break; 
        b = 5;
        break;
      case -1225497655:
        if (!paramString.equals("translationZ"))
          break; 
        b = 4;
        break;
      case -1225497656:
        if (!paramString.equals("translationY"))
          break; 
        b = 3;
        break;
      case -1225497657:
        if (!paramString.equals("translationX"))
          break; 
        b = 2;
        break;
      case -1249320805:
        if (!paramString.equals("rotationY"))
          break; 
        b = 1;
        break;
      case -1249320806:
        if (!paramString.equals("rotationX"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        return null;
      case 11:
        alphaSet = new AlphaSet();
        alphaSet.setStartTime(paramLong);
        return alphaSet;
      case 10:
        pathRotate = new PathRotate();
        pathRotate.setStartTime(paramLong);
        return pathRotate;
      case 9:
        elevationSet = new ElevationSet();
        elevationSet.setStartTime(paramLong);
        return elevationSet;
      case 8:
        rotationSet = new RotationSet();
        rotationSet.setStartTime(paramLong);
        return rotationSet;
      case 7:
        scaleYset = new ScaleYset();
        scaleYset.setStartTime(paramLong);
        return scaleYset;
      case 6:
        scaleXset = new ScaleXset();
        scaleXset.setStartTime(paramLong);
        return scaleXset;
      case 5:
        progressSet = new ProgressSet();
        progressSet.setStartTime(paramLong);
        return progressSet;
      case 4:
        translationZset = new TranslationZset();
        translationZset.setStartTime(paramLong);
        return translationZset;
      case 3:
        translationYset = new TranslationYset();
        translationYset.setStartTime(paramLong);
        return translationYset;
      case 2:
        translationXset = new TranslationXset();
        translationXset.setStartTime(paramLong);
        return translationXset;
      case 1:
        rotationYset = new RotationYset();
        rotationYset.setStartTime(paramLong);
        return rotationYset;
      case 0:
        break;
    } 
    RotationXset rotationXset = new RotationXset();
    rotationXset.setStartTime(paramLong);
    return rotationXset;
  }
  
  public float get(float paramFloat, long paramLong, View paramView, KeyCache paramKeyCache) {
    this.mCurveFit.getPos(paramFloat, this.mCache);
    paramFloat = this.mCache[1];
    int i = paramFloat cmp 0.0F;
    if (i == 0) {
      this.mContinue = false;
      return this.mCache[2];
    } 
    if (Float.isNaN(this.last_cycle)) {
      this.last_cycle = paramKeyCache.getFloatValue(paramView, this.mType, 0);
      if (Float.isNaN(this.last_cycle))
        this.last_cycle = 0.0F; 
    } 
    long l = this.last_time;
    this.last_cycle = (float)((this.last_cycle + (paramLong - l) * 1.0E-9D * paramFloat) % 1.0D);
    paramKeyCache.setFloatValue(paramView, this.mType, 0, this.last_cycle);
    this.last_time = paramLong;
    paramFloat = this.mCache[0];
    float f1 = calcWave(this.last_cycle);
    float f2 = this.mCache[2];
    if (paramFloat != 0.0F || i != 0) {
      boolean bool1 = true;
      this.mContinue = bool1;
      return f1 * paramFloat + f2;
    } 
    boolean bool = false;
    this.mContinue = bool;
    return f1 * paramFloat + f2;
  }
  
  public abstract boolean setProperty(View paramView, float paramFloat, long paramLong, KeyCache paramKeyCache);
  
  static class AlphaSet extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setAlpha(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  public static class CustomSet extends ViewTimeCycle {
    String mAttributeName;
    
    float[] mCache;
    
    SparseArray<ConstraintAttribute> mConstraintAttributeList;
    
    float[] mTempValues;
    
    SparseArray<float[]> mWaveProperties = new SparseArray();
    
    public CustomSet(String param1String, SparseArray<ConstraintAttribute> param1SparseArray) {
      this.mAttributeName = param1String.split(",")[1];
      this.mConstraintAttributeList = param1SparseArray;
    }
    
    public void setPoint(int param1Int1, float param1Float1, float param1Float2, int param1Int2, float param1Float3) {
      throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute,...)");
    }
    
    public void setPoint(int param1Int1, ConstraintAttribute param1ConstraintAttribute, float param1Float1, int param1Int2, float param1Float2) {
      this.mConstraintAttributeList.append(param1Int1, param1ConstraintAttribute);
      this.mWaveProperties.append(param1Int1, new float[] { param1Float1, param1Float2 });
      this.mWaveShape = Math.max(this.mWaveShape, param1Int2);
    }
    
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      this.mCurveFit.getPos(param1Float, this.mTempValues);
      float[] arrayOfFloat = this.mTempValues;
      param1Float = arrayOfFloat[arrayOfFloat.length - 2];
      float f1 = arrayOfFloat[arrayOfFloat.length - 1];
      long l = this.last_time;
      if (Float.isNaN(this.last_cycle)) {
        this.last_cycle = param1KeyCache.getFloatValue(param1View, this.mAttributeName, 0);
        if (Float.isNaN(this.last_cycle))
          this.last_cycle = 0.0F; 
      } 
      this.last_cycle = (float)((this.last_cycle + (param1Long - l) * 1.0E-9D * param1Float) % 1.0D);
      this.last_time = param1Long;
      float f2 = calcWave(this.last_cycle);
      this.mContinue = false;
      int i;
      for (i = 0; i < this.mCache.length; i++) {
        boolean bool1;
        boolean bool2 = this.mContinue;
        if (this.mTempValues[i] != 0.0D) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        this.mContinue = bool2 | bool1;
        this.mCache[i] = this.mTempValues[i] * f2 + f1;
      } 
      CustomSupport.setInterpolatedValue((ConstraintAttribute)this.mConstraintAttributeList.valueAt(0), param1View, this.mCache);
      if (param1Float != 0.0F)
        this.mContinue = true; 
      return this.mContinue;
    }
    
    public void setup(int param1Int) {
      int j = this.mConstraintAttributeList.size();
      int k = ((ConstraintAttribute)this.mConstraintAttributeList.valueAt(0)).numberOfInterpolatedValues();
      double[] arrayOfDouble = new double[j];
      int i = k + 2;
      this.mTempValues = new float[i];
      this.mCache = new float[k];
      double[][] arrayOfDouble1 = (double[][])Array.newInstance(double.class, new int[] { j, i });
      i = 0;
      while (i < j) {
        int m = this.mConstraintAttributeList.keyAt(i);
        ConstraintAttribute constraintAttribute = (ConstraintAttribute)this.mConstraintAttributeList.valueAt(i);
        float[] arrayOfFloat = (float[])this.mWaveProperties.valueAt(i);
        arrayOfDouble[i] = m * 0.01D;
        constraintAttribute.getValuesToInterpolate(this.mTempValues);
        m = 0;
        while (true) {
          float[] arrayOfFloat1 = this.mTempValues;
          if (m < arrayOfFloat1.length) {
            arrayOfDouble1[i][m] = arrayOfFloat1[m];
            m++;
            continue;
          } 
          arrayOfDouble1[i][k] = arrayOfFloat[0];
          arrayOfDouble1[i][k + 1] = arrayOfFloat[1];
          i++;
        } 
      } 
      this.mCurveFit = CurveFit.get(param1Int, arrayOfDouble, arrayOfDouble1);
    }
  }
  
  static class ElevationSet extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      if (Build.VERSION.SDK_INT >= 21)
        param1View.setElevation(get(param1Float, param1Long, param1View, param1KeyCache)); 
      return this.mContinue;
    }
  }
  
  public static class PathRotate extends ViewTimeCycle {
    public boolean setPathRotate(View param1View, KeyCache param1KeyCache, float param1Float, long param1Long, double param1Double1, double param1Double2) {
      param1View.setRotation(get(param1Float, param1Long, param1View, param1KeyCache) + (float)Math.toDegrees(Math.atan2(param1Double2, param1Double1)));
      return this.mContinue;
    }
    
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      return this.mContinue;
    }
  }
  
  static class ProgressSet extends ViewTimeCycle {
    boolean mNoMethod = false;
    
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      if (param1View instanceof MotionLayout) {
        ((MotionLayout)param1View).setProgress(get(param1Float, param1Long, param1View, param1KeyCache));
      } else {
        if (this.mNoMethod)
          return false; 
        Method method = null;
        try {
          Method method1 = param1View.getClass().getMethod("setProgress", new Class[] { float.class });
          method = method1;
        } catch (NoSuchMethodException noSuchMethodException) {
          this.mNoMethod = true;
        } 
        if (method != null)
          try {
            method.invoke(param1View, new Object[] { Float.valueOf(get(param1Float, param1Long, param1View, param1KeyCache)) });
          } catch (IllegalAccessException illegalAccessException) {
            Log.e("ViewTimeCycle", "unable to setProgress", illegalAccessException);
          } catch (InvocationTargetException invocationTargetException) {
            Log.e("ViewTimeCycle", "unable to setProgress", invocationTargetException);
          }  
      } 
      return this.mContinue;
    }
  }
  
  static class RotationSet extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setRotation(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class RotationXset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setRotationX(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class RotationYset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setRotationY(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class ScaleXset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setScaleX(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class ScaleYset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setScaleY(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class TranslationXset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setTranslationX(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class TranslationYset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      param1View.setTranslationY(get(param1Float, param1Long, param1View, param1KeyCache));
      return this.mContinue;
    }
  }
  
  static class TranslationZset extends ViewTimeCycle {
    public boolean setProperty(View param1View, float param1Float, long param1Long, KeyCache param1KeyCache) {
      if (Build.VERSION.SDK_INT >= 21)
        param1View.setTranslationZ(get(param1Float, param1Long, param1View, param1KeyCache)); 
      return this.mContinue;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Voice Changer-dex2jar.jar!\androidx\constraintlayout\motio\\utils\ViewTimeCycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */