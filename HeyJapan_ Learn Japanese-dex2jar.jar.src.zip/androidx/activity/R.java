package androidx.activity;

public final class R {
  public static final class attr {
    public static final int alpha = 2130968630;
    
    public static final int font = 2130969118;
    
    public static final int fontProviderAuthority = 2130969120;
    
    public static final int fontProviderCerts = 2130969121;
    
    public static final int fontProviderFetchStrategy = 2130969122;
    
    public static final int fontProviderFetchTimeout = 2130969123;
    
    public static final int fontProviderPackage = 2130969124;
    
    public static final int fontProviderQuery = 2130969125;
    
    public static final int fontStyle = 2130969127;
    
    public static final int fontVariationSettings = 2130969128;
    
    public static final int fontWeight = 2130969129;
    
    public static final int ttcIndex = 2130970012;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131100343;
    
    public static final int notification_icon_bg_color = 2131100344;
    
    public static final int ripple_material_light = 2131100359;
    
    public static final int secondary_text_default_material_light = 2131100361;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131165291;
    
    public static final int compat_button_inset_vertical_material = 2131165292;
    
    public static final int compat_button_padding_horizontal_material = 2131165293;
    
    public static final int compat_button_padding_vertical_material = 2131165294;
    
    public static final int compat_control_corner_material = 2131165295;
    
    public static final int compat_notification_large_icon_max_height = 2131165296;
    
    public static final int compat_notification_large_icon_max_width = 2131165297;
    
    public static final int notification_action_icon_size = 2131165816;
    
    public static final int notification_action_text_size = 2131165817;
    
    public static final int notification_big_circle_margin = 2131165818;
    
    public static final int notification_content_margin_start = 2131165819;
    
    public static final int notification_large_icon_height = 2131165820;
    
    public static final int notification_large_icon_width = 2131165821;
    
    public static final int notification_main_column_padding_top = 2131165822;
    
    public static final int notification_media_narrow_margin = 2131165823;
    
    public static final int notification_right_icon_size = 2131165824;
    
    public static final int notification_right_side_padding_top = 2131165825;
    
    public static final int notification_small_icon_background_padding = 2131165826;
    
    public static final int notification_small_icon_size_as_large = 2131165827;
    
    public static final int notification_subtext_size = 2131165828;
    
    public static final int notification_top_pad = 2131165829;
    
    public static final int notification_top_pad_large_text = 2131165830;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131231663;
    
    public static final int notification_bg = 2131231664;
    
    public static final int notification_bg_low = 2131231665;
    
    public static final int notification_bg_low_normal = 2131231666;
    
    public static final int notification_bg_low_pressed = 2131231667;
    
    public static final int notification_bg_normal = 2131231668;
    
    public static final int notification_bg_normal_pressed = 2131231669;
    
    public static final int notification_icon_background = 2131231670;
    
    public static final int notification_template_icon_bg = 2131231671;
    
    public static final int notification_template_icon_low_bg = 2131231672;
    
    public static final int notification_tile_bg = 2131231673;
    
    public static final int notify_panel_notification_icon_bg = 2131231674;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131361834;
    
    public static final int accessibility_custom_action_0 = 2131361835;
    
    public static final int accessibility_custom_action_1 = 2131361836;
    
    public static final int accessibility_custom_action_10 = 2131361837;
    
    public static final int accessibility_custom_action_11 = 2131361838;
    
    public static final int accessibility_custom_action_12 = 2131361839;
    
    public static final int accessibility_custom_action_13 = 2131361840;
    
    public static final int accessibility_custom_action_14 = 2131361841;
    
    public static final int accessibility_custom_action_15 = 2131361842;
    
    public static final int accessibility_custom_action_16 = 2131361843;
    
    public static final int accessibility_custom_action_17 = 2131361844;
    
    public static final int accessibility_custom_action_18 = 2131361845;
    
    public static final int accessibility_custom_action_19 = 2131361846;
    
    public static final int accessibility_custom_action_2 = 2131361847;
    
    public static final int accessibility_custom_action_20 = 2131361848;
    
    public static final int accessibility_custom_action_21 = 2131361849;
    
    public static final int accessibility_custom_action_22 = 2131361850;
    
    public static final int accessibility_custom_action_23 = 2131361851;
    
    public static final int accessibility_custom_action_24 = 2131361852;
    
    public static final int accessibility_custom_action_25 = 2131361853;
    
    public static final int accessibility_custom_action_26 = 2131361854;
    
    public static final int accessibility_custom_action_27 = 2131361855;
    
    public static final int accessibility_custom_action_28 = 2131361856;
    
    public static final int accessibility_custom_action_29 = 2131361857;
    
    public static final int accessibility_custom_action_3 = 2131361858;
    
    public static final int accessibility_custom_action_30 = 2131361859;
    
    public static final int accessibility_custom_action_31 = 2131361860;
    
    public static final int accessibility_custom_action_4 = 2131361861;
    
    public static final int accessibility_custom_action_5 = 2131361862;
    
    public static final int accessibility_custom_action_6 = 2131361863;
    
    public static final int accessibility_custom_action_7 = 2131361864;
    
    public static final int accessibility_custom_action_8 = 2131361865;
    
    public static final int accessibility_custom_action_9 = 2131361866;
    
    public static final int action_container = 2131361880;
    
    public static final int action_divider = 2131361882;
    
    public static final int action_image = 2131361885;
    
    public static final int action_text = 2131361895;
    
    public static final int actions = 2131361896;
    
    public static final int async = 2131361926;
    
    public static final int blocking = 2131361954;
    
    public static final int chronometer = 2131362195;
    
    public static final int dialog_button = 2131362276;
    
    public static final int forever = 2131362367;
    
    public static final int icon = 2131362419;
    
    public static final int icon_group = 2131362420;
    
    public static final int info = 2131362508;
    
    public static final int italic = 2131362514;
    
    public static final int line1 = 2131362776;
    
    public static final int line3 = 2131362782;
    
    public static final int normal = 2131362979;
    
    public static final int notification_background = 2131362981;
    
    public static final int notification_main_column = 2131362982;
    
    public static final int notification_main_column_container = 2131362983;
    
    public static final int right_icon = 2131363199;
    
    public static final int right_side = 2131363201;
    
    public static final int tag_accessibility_actions = 2131363355;
    
    public static final int tag_accessibility_clickable_spans = 2131363356;
    
    public static final int tag_accessibility_heading = 2131363357;
    
    public static final int tag_accessibility_pane_title = 2131363358;
    
    public static final int tag_screen_reader_focusable = 2131363362;
    
    public static final int tag_transition_group = 2131363364;
    
    public static final int tag_unhandled_key_event_manager = 2131363365;
    
    public static final int tag_unhandled_key_listeners = 2131363366;
    
    public static final int text = 2131363372;
    
    public static final int text2 = 2131363373;
    
    public static final int time = 2131363395;
    
    public static final int title = 2131363397;
    
    public static final int view_tree_lifecycle_owner = 2131363953;
    
    public static final int view_tree_saved_state_registry_owner = 2131363954;
    
    public static final int view_tree_view_model_store_owner = 2131363955;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131427383;
  }
  
  public static final class layout {
    public static final int custom_dialog = 2131558491;
    
    public static final int notification_action = 2131558854;
    
    public static final int notification_action_tombstone = 2131558855;
    
    public static final int notification_template_custom_big = 2131558862;
    
    public static final int notification_template_icon_group = 2131558863;
    
    public static final int notification_template_part_chronometer = 2131558867;
    
    public static final int notification_template_part_time = 2131558868;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131887267;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131952152;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131952153;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131952155;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131952158;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131952160;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952514;
    
    public static final int Widget_Compat_NotificationActionText = 2131952515;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968630, 2130969313 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] FontFamily = new int[] { 2130969120, 2130969121, 2130969122, 2130969123, 2130969124, 2130969125, 2130969126 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969118, 2130969127, 2130969128, 2130969129, 2130970012 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\activity\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */