package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;

public class Placeholder extends VirtualLayout {
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (this.mWidgetsCount > 0) {
      ConstraintWidget constraintWidget = this.mWidgets[0];
      constraintWidget.resetAllConstraints();
      constraintWidget.connect(ConstraintAnchor.Type.LEFT, this, ConstraintAnchor.Type.LEFT);
      constraintWidget.connect(ConstraintAnchor.Type.RIGHT, this, ConstraintAnchor.Type.RIGHT);
      constraintWidget.connect(ConstraintAnchor.Type.TOP, this, ConstraintAnchor.Type.TOP);
      constraintWidget.connect(ConstraintAnchor.Type.BOTTOM, this, ConstraintAnchor.Type.BOTTOM);
    } 
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int k = getPaddingLeft();
    int m = getPaddingRight();
    int i = getPaddingTop();
    int j = getPaddingBottom();
    boolean bool = false;
    k = k + m + 0;
    m = i + j + 0;
    j = k;
    i = m;
    if (this.mWidgetsCount > 0) {
      j = k + this.mWidgets[0].getWidth();
      i = m + this.mWidgets[0].getHeight();
    } 
    j = Math.max(getMinWidth(), j);
    i = Math.max(getMinHeight(), i);
    if (paramInt1 != 1073741824)
      if (paramInt1 == Integer.MIN_VALUE) {
        paramInt2 = Math.min(j, paramInt2);
      } else if (paramInt1 == 0) {
        paramInt2 = j;
      } else {
        paramInt2 = 0;
      }  
    if (paramInt3 != 1073741824)
      if (paramInt3 == Integer.MIN_VALUE) {
        paramInt4 = Math.min(i, paramInt4);
      } else if (paramInt3 == 0) {
        paramInt4 = i;
      } else {
        paramInt4 = 0;
      }  
    setMeasure(paramInt2, paramInt4);
    setWidth(paramInt2);
    setHeight(paramInt4);
    if (this.mWidgetsCount > 0)
      bool = true; 
    needsCallbackFromSolver(bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\widgets\Placeholder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */