package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.HelperWidget;
import java.util.ArrayList;

public class Grouping {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_GROUPING = false;
  
  public static WidgetGroup findDependents(ConstraintWidget paramConstraintWidget, int paramInt, ArrayList<WidgetGroup> paramArrayList, WidgetGroup paramWidgetGroup) {
    int i;
    WidgetGroup widgetGroup;
    if (paramInt == 0) {
      i = paramConstraintWidget.horizontalGroup;
    } else {
      i = paramConstraintWidget.verticalGroup;
    } 
    boolean bool = false;
    if (i != -1 && (paramWidgetGroup == null || i != paramWidgetGroup.id)) {
      int j = 0;
      while (true) {
        widgetGroup = paramWidgetGroup;
        if (j < paramArrayList.size()) {
          widgetGroup = paramArrayList.get(j);
          if (widgetGroup.getId() == i) {
            if (paramWidgetGroup != null) {
              paramWidgetGroup.moveTo(paramInt, widgetGroup);
              paramArrayList.remove(paramWidgetGroup);
            } 
            break;
          } 
          j++;
          continue;
        } 
        break;
      } 
    } else {
      widgetGroup = paramWidgetGroup;
      if (i != -1)
        return paramWidgetGroup; 
    } 
    paramWidgetGroup = widgetGroup;
    if (widgetGroup == null) {
      paramWidgetGroup = widgetGroup;
      if (paramConstraintWidget instanceof HelperWidget) {
        int j = ((HelperWidget)paramConstraintWidget).findGroupInDependents(paramInt);
        paramWidgetGroup = widgetGroup;
        if (j != -1) {
          i = 0;
          while (true) {
            paramWidgetGroup = widgetGroup;
            if (i < paramArrayList.size()) {
              paramWidgetGroup = paramArrayList.get(i);
              if (paramWidgetGroup.getId() == j)
                break; 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      widgetGroup = paramWidgetGroup;
      if (paramWidgetGroup == null)
        widgetGroup = new WidgetGroup(paramInt); 
      paramArrayList.add(widgetGroup);
      paramWidgetGroup = widgetGroup;
    } 
    if (paramWidgetGroup.add(paramConstraintWidget)) {
      if (paramConstraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)paramConstraintWidget;
        ConstraintAnchor constraintAnchor = guideline.getAnchor();
        i = bool;
        if (guideline.getOrientation() == 0)
          i = 1; 
        constraintAnchor.findDependents(i, paramArrayList, paramWidgetGroup);
      } 
      if (paramInt == 0) {
        paramConstraintWidget.horizontalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mLeft.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mRight.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } else {
        paramConstraintWidget.verticalGroup = paramWidgetGroup.getId();
        paramConstraintWidget.mTop.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBaseline.findDependents(paramInt, paramArrayList, paramWidgetGroup);
        paramConstraintWidget.mBottom.findDependents(paramInt, paramArrayList, paramWidgetGroup);
      } 
      paramConstraintWidget.mCenter.findDependents(paramInt, paramArrayList, paramWidgetGroup);
    } 
    return paramWidgetGroup;
  }
  
  private static WidgetGroup findGroup(ArrayList<WidgetGroup> paramArrayList, int paramInt) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      WidgetGroup widgetGroup = paramArrayList.get(i);
      if (paramInt == widgetGroup.id)
        return widgetGroup; 
    } 
    return null;
  }
  
  public static boolean simpleSolvingPass(ConstraintWidgetContainer paramConstraintWidgetContainer, BasicMeasure.Measurer paramMeasurer) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildren : ()Ljava/util/ArrayList;
    //   4: astore #16
    //   6: aload #16
    //   8: invokevirtual size : ()I
    //   11: istore_3
    //   12: iconst_0
    //   13: istore_2
    //   14: iload_2
    //   15: iload_3
    //   16: if_icmpge -> 73
    //   19: aload #16
    //   21: iload_2
    //   22: invokevirtual get : (I)Ljava/lang/Object;
    //   25: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   28: astore #5
    //   30: aload_0
    //   31: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   34: aload_0
    //   35: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   38: aload #5
    //   40: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   43: aload #5
    //   45: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   48: invokestatic validInGroup : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   51: ifne -> 56
    //   54: iconst_0
    //   55: ireturn
    //   56: aload #5
    //   58: instanceof androidx/constraintlayout/core/widgets/Flow
    //   61: ifeq -> 66
    //   64: iconst_0
    //   65: ireturn
    //   66: iload_2
    //   67: iconst_1
    //   68: iadd
    //   69: istore_2
    //   70: goto -> 14
    //   73: aload_0
    //   74: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   77: ifnull -> 98
    //   80: aload_0
    //   81: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   84: astore #5
    //   86: aload #5
    //   88: aload #5
    //   90: getfield grouping : J
    //   93: lconst_1
    //   94: ladd
    //   95: putfield grouping : J
    //   98: iconst_0
    //   99: istore_2
    //   100: aconst_null
    //   101: astore #11
    //   103: aconst_null
    //   104: astore #5
    //   106: aconst_null
    //   107: astore #7
    //   109: aconst_null
    //   110: astore #6
    //   112: aconst_null
    //   113: astore #9
    //   115: aconst_null
    //   116: astore #8
    //   118: iload_2
    //   119: iload_3
    //   120: if_icmpge -> 678
    //   123: aload #16
    //   125: iload_2
    //   126: invokevirtual get : (I)Ljava/lang/Object;
    //   129: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   132: astore #17
    //   134: aload_0
    //   135: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   138: aload_0
    //   139: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   142: aload #17
    //   144: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   147: aload #17
    //   149: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   152: invokestatic validInGroup : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)Z
    //   155: ifne -> 176
    //   158: iconst_0
    //   159: aload #17
    //   161: aload_1
    //   162: aload_0
    //   163: getfield mMeasure : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;
    //   166: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   169: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   172: pop
    //   173: goto -> 176
    //   176: aload #17
    //   178: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   181: istore #4
    //   183: aload #11
    //   185: astore #13
    //   187: aload #7
    //   189: astore #12
    //   191: iload #4
    //   193: ifeq -> 292
    //   196: aload #17
    //   198: checkcast androidx/constraintlayout/core/widgets/Guideline
    //   201: astore #14
    //   203: aload #7
    //   205: astore #10
    //   207: aload #14
    //   209: invokevirtual getOrientation : ()I
    //   212: ifne -> 241
    //   215: aload #7
    //   217: astore #10
    //   219: aload #7
    //   221: ifnonnull -> 233
    //   224: new java/util/ArrayList
    //   227: dup
    //   228: invokespecial <init> : ()V
    //   231: astore #10
    //   233: aload #10
    //   235: aload #14
    //   237: invokevirtual add : (Ljava/lang/Object;)Z
    //   240: pop
    //   241: aload #11
    //   243: astore #13
    //   245: aload #10
    //   247: astore #12
    //   249: aload #14
    //   251: invokevirtual getOrientation : ()I
    //   254: iconst_1
    //   255: if_icmpne -> 292
    //   258: aload #11
    //   260: astore #7
    //   262: aload #11
    //   264: ifnonnull -> 276
    //   267: new java/util/ArrayList
    //   270: dup
    //   271: invokespecial <init> : ()V
    //   274: astore #7
    //   276: aload #7
    //   278: aload #14
    //   280: invokevirtual add : (Ljava/lang/Object;)Z
    //   283: pop
    //   284: aload #10
    //   286: astore #12
    //   288: aload #7
    //   290: astore #13
    //   292: aload #5
    //   294: astore #7
    //   296: aload #6
    //   298: astore #10
    //   300: aload #17
    //   302: instanceof androidx/constraintlayout/core/widgets/HelperWidget
    //   305: ifeq -> 470
    //   308: aload #17
    //   310: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   313: ifeq -> 411
    //   316: aload #17
    //   318: checkcast androidx/constraintlayout/core/widgets/Barrier
    //   321: astore #14
    //   323: aload #5
    //   325: astore #11
    //   327: aload #14
    //   329: invokevirtual getOrientation : ()I
    //   332: ifne -> 361
    //   335: aload #5
    //   337: astore #11
    //   339: aload #5
    //   341: ifnonnull -> 353
    //   344: new java/util/ArrayList
    //   347: dup
    //   348: invokespecial <init> : ()V
    //   351: astore #11
    //   353: aload #11
    //   355: aload #14
    //   357: invokevirtual add : (Ljava/lang/Object;)Z
    //   360: pop
    //   361: aload #11
    //   363: astore #7
    //   365: aload #6
    //   367: astore #10
    //   369: aload #14
    //   371: invokevirtual getOrientation : ()I
    //   374: iconst_1
    //   375: if_icmpne -> 470
    //   378: aload #6
    //   380: astore #10
    //   382: aload #6
    //   384: ifnonnull -> 396
    //   387: new java/util/ArrayList
    //   390: dup
    //   391: invokespecial <init> : ()V
    //   394: astore #10
    //   396: aload #10
    //   398: aload #14
    //   400: invokevirtual add : (Ljava/lang/Object;)Z
    //   403: pop
    //   404: aload #11
    //   406: astore #7
    //   408: goto -> 470
    //   411: aload #17
    //   413: checkcast androidx/constraintlayout/core/widgets/HelperWidget
    //   416: astore #11
    //   418: aload #5
    //   420: astore #7
    //   422: aload #5
    //   424: ifnonnull -> 436
    //   427: new java/util/ArrayList
    //   430: dup
    //   431: invokespecial <init> : ()V
    //   434: astore #7
    //   436: aload #7
    //   438: aload #11
    //   440: invokevirtual add : (Ljava/lang/Object;)Z
    //   443: pop
    //   444: aload #6
    //   446: astore #10
    //   448: aload #6
    //   450: ifnonnull -> 462
    //   453: new java/util/ArrayList
    //   456: dup
    //   457: invokespecial <init> : ()V
    //   460: astore #10
    //   462: aload #10
    //   464: aload #11
    //   466: invokevirtual add : (Ljava/lang/Object;)Z
    //   469: pop
    //   470: aload #9
    //   472: astore #14
    //   474: aload #17
    //   476: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   479: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   482: ifnonnull -> 551
    //   485: aload #9
    //   487: astore #14
    //   489: aload #17
    //   491: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   494: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   497: ifnonnull -> 551
    //   500: aload #9
    //   502: astore #14
    //   504: iload #4
    //   506: ifne -> 551
    //   509: aload #9
    //   511: astore #14
    //   513: aload #17
    //   515: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   518: ifne -> 551
    //   521: aload #9
    //   523: astore #5
    //   525: aload #9
    //   527: ifnonnull -> 539
    //   530: new java/util/ArrayList
    //   533: dup
    //   534: invokespecial <init> : ()V
    //   537: astore #5
    //   539: aload #5
    //   541: aload #17
    //   543: invokevirtual add : (Ljava/lang/Object;)Z
    //   546: pop
    //   547: aload #5
    //   549: astore #14
    //   551: aload #8
    //   553: astore #15
    //   555: aload #17
    //   557: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   560: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   563: ifnonnull -> 647
    //   566: aload #8
    //   568: astore #15
    //   570: aload #17
    //   572: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   575: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   578: ifnonnull -> 647
    //   581: aload #8
    //   583: astore #15
    //   585: aload #17
    //   587: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   590: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   593: ifnonnull -> 647
    //   596: aload #8
    //   598: astore #15
    //   600: iload #4
    //   602: ifne -> 647
    //   605: aload #8
    //   607: astore #15
    //   609: aload #17
    //   611: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   614: ifne -> 647
    //   617: aload #8
    //   619: astore #5
    //   621: aload #8
    //   623: ifnonnull -> 635
    //   626: new java/util/ArrayList
    //   629: dup
    //   630: invokespecial <init> : ()V
    //   633: astore #5
    //   635: aload #5
    //   637: aload #17
    //   639: invokevirtual add : (Ljava/lang/Object;)Z
    //   642: pop
    //   643: aload #5
    //   645: astore #15
    //   647: iload_2
    //   648: iconst_1
    //   649: iadd
    //   650: istore_2
    //   651: aload #13
    //   653: astore #11
    //   655: aload #7
    //   657: astore #5
    //   659: aload #12
    //   661: astore #7
    //   663: aload #10
    //   665: astore #6
    //   667: aload #14
    //   669: astore #9
    //   671: aload #15
    //   673: astore #8
    //   675: goto -> 118
    //   678: new java/util/ArrayList
    //   681: dup
    //   682: invokespecial <init> : ()V
    //   685: astore #10
    //   687: aload #11
    //   689: ifnull -> 727
    //   692: aload #11
    //   694: invokevirtual iterator : ()Ljava/util/Iterator;
    //   697: astore_1
    //   698: aload_1
    //   699: invokeinterface hasNext : ()Z
    //   704: ifeq -> 727
    //   707: aload_1
    //   708: invokeinterface next : ()Ljava/lang/Object;
    //   713: checkcast androidx/constraintlayout/core/widgets/Guideline
    //   716: iconst_0
    //   717: aload #10
    //   719: aconst_null
    //   720: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   723: pop
    //   724: goto -> 698
    //   727: aload #5
    //   729: ifnull -> 789
    //   732: aload #5
    //   734: invokevirtual iterator : ()Ljava/util/Iterator;
    //   737: astore_1
    //   738: aload_1
    //   739: invokeinterface hasNext : ()Z
    //   744: ifeq -> 789
    //   747: aload_1
    //   748: invokeinterface next : ()Ljava/lang/Object;
    //   753: checkcast androidx/constraintlayout/core/widgets/HelperWidget
    //   756: astore #5
    //   758: aload #5
    //   760: iconst_0
    //   761: aload #10
    //   763: aconst_null
    //   764: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   767: astore #11
    //   769: aload #5
    //   771: aload #10
    //   773: iconst_0
    //   774: aload #11
    //   776: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)V
    //   779: aload #11
    //   781: aload #10
    //   783: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   786: goto -> 738
    //   789: aload_0
    //   790: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   793: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   796: astore_1
    //   797: aload_1
    //   798: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   801: ifnull -> 844
    //   804: aload_1
    //   805: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   808: invokevirtual iterator : ()Ljava/util/Iterator;
    //   811: astore_1
    //   812: aload_1
    //   813: invokeinterface hasNext : ()Z
    //   818: ifeq -> 844
    //   821: aload_1
    //   822: invokeinterface next : ()Ljava/lang/Object;
    //   827: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   830: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   833: iconst_0
    //   834: aload #10
    //   836: aconst_null
    //   837: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   840: pop
    //   841: goto -> 812
    //   844: aload_0
    //   845: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   848: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   851: astore_1
    //   852: aload_1
    //   853: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   856: ifnull -> 899
    //   859: aload_1
    //   860: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   863: invokevirtual iterator : ()Ljava/util/Iterator;
    //   866: astore_1
    //   867: aload_1
    //   868: invokeinterface hasNext : ()Z
    //   873: ifeq -> 899
    //   876: aload_1
    //   877: invokeinterface next : ()Ljava/lang/Object;
    //   882: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   885: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   888: iconst_0
    //   889: aload #10
    //   891: aconst_null
    //   892: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   895: pop
    //   896: goto -> 867
    //   899: aload_0
    //   900: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   903: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   906: astore_1
    //   907: aload_1
    //   908: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   911: ifnull -> 954
    //   914: aload_1
    //   915: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   918: invokevirtual iterator : ()Ljava/util/Iterator;
    //   921: astore_1
    //   922: aload_1
    //   923: invokeinterface hasNext : ()Z
    //   928: ifeq -> 954
    //   931: aload_1
    //   932: invokeinterface next : ()Ljava/lang/Object;
    //   937: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   940: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   943: iconst_0
    //   944: aload #10
    //   946: aconst_null
    //   947: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   950: pop
    //   951: goto -> 922
    //   954: aload #9
    //   956: ifnull -> 994
    //   959: aload #9
    //   961: invokevirtual iterator : ()Ljava/util/Iterator;
    //   964: astore_1
    //   965: aload_1
    //   966: invokeinterface hasNext : ()Z
    //   971: ifeq -> 994
    //   974: aload_1
    //   975: invokeinterface next : ()Ljava/lang/Object;
    //   980: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   983: iconst_0
    //   984: aload #10
    //   986: aconst_null
    //   987: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   990: pop
    //   991: goto -> 965
    //   994: aload #7
    //   996: ifnull -> 1034
    //   999: aload #7
    //   1001: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1004: astore_1
    //   1005: aload_1
    //   1006: invokeinterface hasNext : ()Z
    //   1011: ifeq -> 1034
    //   1014: aload_1
    //   1015: invokeinterface next : ()Ljava/lang/Object;
    //   1020: checkcast androidx/constraintlayout/core/widgets/Guideline
    //   1023: iconst_1
    //   1024: aload #10
    //   1026: aconst_null
    //   1027: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1030: pop
    //   1031: goto -> 1005
    //   1034: aload #6
    //   1036: ifnull -> 1096
    //   1039: aload #6
    //   1041: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1044: astore_1
    //   1045: aload_1
    //   1046: invokeinterface hasNext : ()Z
    //   1051: ifeq -> 1096
    //   1054: aload_1
    //   1055: invokeinterface next : ()Ljava/lang/Object;
    //   1060: checkcast androidx/constraintlayout/core/widgets/HelperWidget
    //   1063: astore #5
    //   1065: aload #5
    //   1067: iconst_1
    //   1068: aload #10
    //   1070: aconst_null
    //   1071: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1074: astore #6
    //   1076: aload #5
    //   1078: aload #10
    //   1080: iconst_1
    //   1081: aload #6
    //   1083: invokevirtual addDependents : (Ljava/util/ArrayList;ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)V
    //   1086: aload #6
    //   1088: aload #10
    //   1090: invokevirtual cleanup : (Ljava/util/ArrayList;)V
    //   1093: goto -> 1045
    //   1096: aload_0
    //   1097: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   1100: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1103: astore_1
    //   1104: aload_1
    //   1105: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1108: ifnull -> 1151
    //   1111: aload_1
    //   1112: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1115: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1118: astore_1
    //   1119: aload_1
    //   1120: invokeinterface hasNext : ()Z
    //   1125: ifeq -> 1151
    //   1128: aload_1
    //   1129: invokeinterface next : ()Ljava/lang/Object;
    //   1134: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   1137: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1140: iconst_1
    //   1141: aload #10
    //   1143: aconst_null
    //   1144: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1147: pop
    //   1148: goto -> 1119
    //   1151: aload_0
    //   1152: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   1155: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1158: astore_1
    //   1159: aload_1
    //   1160: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1163: ifnull -> 1206
    //   1166: aload_1
    //   1167: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1170: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1173: astore_1
    //   1174: aload_1
    //   1175: invokeinterface hasNext : ()Z
    //   1180: ifeq -> 1206
    //   1183: aload_1
    //   1184: invokeinterface next : ()Ljava/lang/Object;
    //   1189: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   1192: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1195: iconst_1
    //   1196: aload #10
    //   1198: aconst_null
    //   1199: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1202: pop
    //   1203: goto -> 1174
    //   1206: aload_0
    //   1207: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   1210: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1213: astore_1
    //   1214: aload_1
    //   1215: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1218: ifnull -> 1261
    //   1221: aload_1
    //   1222: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1225: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1228: astore_1
    //   1229: aload_1
    //   1230: invokeinterface hasNext : ()Z
    //   1235: ifeq -> 1261
    //   1238: aload_1
    //   1239: invokeinterface next : ()Ljava/lang/Object;
    //   1244: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   1247: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1250: iconst_1
    //   1251: aload #10
    //   1253: aconst_null
    //   1254: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1257: pop
    //   1258: goto -> 1229
    //   1261: aload_0
    //   1262: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   1265: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1268: astore_1
    //   1269: aload_1
    //   1270: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1273: ifnull -> 1316
    //   1276: aload_1
    //   1277: invokevirtual getDependents : ()Ljava/util/HashSet;
    //   1280: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1283: astore_1
    //   1284: aload_1
    //   1285: invokeinterface hasNext : ()Z
    //   1290: ifeq -> 1316
    //   1293: aload_1
    //   1294: invokeinterface next : ()Ljava/lang/Object;
    //   1299: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   1302: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1305: iconst_1
    //   1306: aload #10
    //   1308: aconst_null
    //   1309: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1312: pop
    //   1313: goto -> 1284
    //   1316: aload #8
    //   1318: ifnull -> 1356
    //   1321: aload #8
    //   1323: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1326: astore_1
    //   1327: aload_1
    //   1328: invokeinterface hasNext : ()Z
    //   1333: ifeq -> 1356
    //   1336: aload_1
    //   1337: invokeinterface next : ()Ljava/lang/Object;
    //   1342: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1345: iconst_1
    //   1346: aload #10
    //   1348: aconst_null
    //   1349: invokestatic findDependents : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;ILjava/util/ArrayList;Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1352: pop
    //   1353: goto -> 1327
    //   1356: iconst_0
    //   1357: istore_2
    //   1358: iload_2
    //   1359: iload_3
    //   1360: if_icmpge -> 1441
    //   1363: aload #16
    //   1365: iload_2
    //   1366: invokevirtual get : (I)Ljava/lang/Object;
    //   1369: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1372: astore #5
    //   1374: aload #5
    //   1376: invokevirtual oppositeDimensionsTied : ()Z
    //   1379: ifeq -> 1434
    //   1382: aload #10
    //   1384: aload #5
    //   1386: getfield horizontalGroup : I
    //   1389: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1392: astore_1
    //   1393: aload #10
    //   1395: aload #5
    //   1397: getfield verticalGroup : I
    //   1400: invokestatic findGroup : (Ljava/util/ArrayList;I)Landroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;
    //   1403: astore #5
    //   1405: aload_1
    //   1406: ifnull -> 1434
    //   1409: aload #5
    //   1411: ifnull -> 1434
    //   1414: aload_1
    //   1415: iconst_0
    //   1416: aload #5
    //   1418: invokevirtual moveTo : (ILandroidx/constraintlayout/core/widgets/analyzer/WidgetGroup;)V
    //   1421: aload #5
    //   1423: iconst_2
    //   1424: invokevirtual setOrientation : (I)V
    //   1427: aload #10
    //   1429: aload_1
    //   1430: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1433: pop
    //   1434: iload_2
    //   1435: iconst_1
    //   1436: iadd
    //   1437: istore_2
    //   1438: goto -> 1358
    //   1441: aload #10
    //   1443: invokevirtual size : ()I
    //   1446: iconst_1
    //   1447: if_icmpgt -> 1452
    //   1450: iconst_0
    //   1451: ireturn
    //   1452: aload_0
    //   1453: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1456: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1459: if_acmpne -> 1564
    //   1462: aload #10
    //   1464: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1467: astore #6
    //   1469: aconst_null
    //   1470: astore_1
    //   1471: iconst_0
    //   1472: istore_2
    //   1473: aload #6
    //   1475: invokeinterface hasNext : ()Z
    //   1480: ifeq -> 1537
    //   1483: aload #6
    //   1485: invokeinterface next : ()Ljava/lang/Object;
    //   1490: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetGroup
    //   1493: astore #5
    //   1495: aload #5
    //   1497: invokevirtual getOrientation : ()I
    //   1500: iconst_1
    //   1501: if_icmpne -> 1507
    //   1504: goto -> 1473
    //   1507: aload #5
    //   1509: iconst_0
    //   1510: invokevirtual setAuthoritative : (Z)V
    //   1513: aload #5
    //   1515: aload_0
    //   1516: invokevirtual getSystem : ()Landroidx/constraintlayout/core/LinearSystem;
    //   1519: iconst_0
    //   1520: invokevirtual measureWrap : (Landroidx/constraintlayout/core/LinearSystem;I)I
    //   1523: istore_3
    //   1524: iload_3
    //   1525: iload_2
    //   1526: if_icmple -> 1473
    //   1529: aload #5
    //   1531: astore_1
    //   1532: iload_3
    //   1533: istore_2
    //   1534: goto -> 1473
    //   1537: aload_1
    //   1538: ifnull -> 1564
    //   1541: aload_0
    //   1542: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1545: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1548: aload_0
    //   1549: iload_2
    //   1550: invokevirtual setWidth : (I)V
    //   1553: aload_1
    //   1554: iconst_1
    //   1555: invokevirtual setAuthoritative : (Z)V
    //   1558: aload_1
    //   1559: astore #5
    //   1561: goto -> 1567
    //   1564: aconst_null
    //   1565: astore #5
    //   1567: aload_0
    //   1568: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1571: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1574: if_acmpne -> 1675
    //   1577: aload #10
    //   1579: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1582: astore #7
    //   1584: aconst_null
    //   1585: astore_1
    //   1586: iconst_0
    //   1587: istore_2
    //   1588: aload #7
    //   1590: invokeinterface hasNext : ()Z
    //   1595: ifeq -> 1651
    //   1598: aload #7
    //   1600: invokeinterface next : ()Ljava/lang/Object;
    //   1605: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetGroup
    //   1608: astore #6
    //   1610: aload #6
    //   1612: invokevirtual getOrientation : ()I
    //   1615: ifne -> 1621
    //   1618: goto -> 1588
    //   1621: aload #6
    //   1623: iconst_0
    //   1624: invokevirtual setAuthoritative : (Z)V
    //   1627: aload #6
    //   1629: aload_0
    //   1630: invokevirtual getSystem : ()Landroidx/constraintlayout/core/LinearSystem;
    //   1633: iconst_1
    //   1634: invokevirtual measureWrap : (Landroidx/constraintlayout/core/LinearSystem;I)I
    //   1637: istore_3
    //   1638: iload_3
    //   1639: iload_2
    //   1640: if_icmple -> 1588
    //   1643: aload #6
    //   1645: astore_1
    //   1646: iload_3
    //   1647: istore_2
    //   1648: goto -> 1588
    //   1651: aload_1
    //   1652: ifnull -> 1675
    //   1655: aload_0
    //   1656: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1659: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1662: aload_0
    //   1663: iload_2
    //   1664: invokevirtual setHeight : (I)V
    //   1667: aload_1
    //   1668: iconst_1
    //   1669: invokevirtual setAuthoritative : (Z)V
    //   1672: goto -> 1677
    //   1675: aconst_null
    //   1676: astore_1
    //   1677: aload #5
    //   1679: ifnonnull -> 1691
    //   1682: aload_1
    //   1683: ifnull -> 1689
    //   1686: goto -> 1691
    //   1689: iconst_0
    //   1690: ireturn
    //   1691: iconst_1
    //   1692: ireturn
  }
  
  public static boolean validInGroup(ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour3, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour4) {
    boolean bool1;
    boolean bool2;
    if (paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.FIXED || paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (paramDimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && paramDimensionBehaviour1 != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.FIXED || paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (paramDimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && paramDimensionBehaviour2 != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    return !bool1 ? (bool2) : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\Grouping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */