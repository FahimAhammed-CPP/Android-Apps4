package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.Cache;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.Grouping;
import androidx.constraintlayout.core.widgets.analyzer.WidgetGroup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintAnchor {
  private static final boolean ALLOW_BINARY = false;
  
  private static final int UNSET_GONE_MARGIN = -2147483648;
  
  private HashSet<ConstraintAnchor> mDependents = null;
  
  private int mFinalValue;
  
  int mGoneMargin = Integer.MIN_VALUE;
  
  private boolean mHasFinalValue;
  
  public int mMargin = 0;
  
  public final ConstraintWidget mOwner;
  
  SolverVariable mSolverVariable;
  
  public ConstraintAnchor mTarget;
  
  public final Type mType;
  
  public ConstraintAnchor(ConstraintWidget paramConstraintWidget, Type paramType) {
    this.mOwner = paramConstraintWidget;
    this.mType = paramType;
  }
  
  private boolean isConnectionToMe(ConstraintWidget paramConstraintWidget, HashSet<ConstraintWidget> paramHashSet) {
    if (paramHashSet.contains(paramConstraintWidget))
      return false; 
    paramHashSet.add(paramConstraintWidget);
    if (paramConstraintWidget == getOwner())
      return true; 
    ArrayList<ConstraintAnchor> arrayList = paramConstraintWidget.getAnchors();
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      ConstraintAnchor constraintAnchor = arrayList.get(i);
      if (constraintAnchor.isSimilarDimensionConnection(this) && constraintAnchor.isConnected() && isConnectionToMe(constraintAnchor.getTarget().getOwner(), paramHashSet))
        return true; 
    } 
    return false;
  }
  
  public boolean connect(ConstraintAnchor paramConstraintAnchor, int paramInt) {
    return connect(paramConstraintAnchor, paramInt, -2147483648, false);
  }
  
  public boolean connect(ConstraintAnchor paramConstraintAnchor, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramConstraintAnchor == null) {
      reset();
      return true;
    } 
    if (!paramBoolean && !isValidConnection(paramConstraintAnchor))
      return false; 
    this.mTarget = paramConstraintAnchor;
    if (paramConstraintAnchor.mDependents == null)
      paramConstraintAnchor.mDependents = new HashSet<ConstraintAnchor>(); 
    HashSet<ConstraintAnchor> hashSet = this.mTarget.mDependents;
    if (hashSet != null)
      hashSet.add(this); 
    this.mMargin = paramInt1;
    this.mGoneMargin = paramInt2;
    return true;
  }
  
  public void copyFrom(ConstraintAnchor paramConstraintAnchor, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    ConstraintAnchor constraintAnchor2 = this.mTarget;
    if (constraintAnchor2 != null) {
      HashSet<ConstraintAnchor> hashSet = constraintAnchor2.mDependents;
      if (hashSet != null)
        hashSet.remove(this); 
    } 
    constraintAnchor2 = paramConstraintAnchor.mTarget;
    if (constraintAnchor2 != null) {
      Type type = constraintAnchor2.getType();
      this.mTarget = ((ConstraintWidget)paramHashMap.get(paramConstraintAnchor.mTarget.mOwner)).getAnchor(type);
    } else {
      this.mTarget = null;
    } 
    ConstraintAnchor constraintAnchor1 = this.mTarget;
    if (constraintAnchor1 != null) {
      if (constraintAnchor1.mDependents == null)
        constraintAnchor1.mDependents = new HashSet<ConstraintAnchor>(); 
      this.mTarget.mDependents.add(this);
    } 
    this.mMargin = paramConstraintAnchor.mMargin;
    this.mGoneMargin = paramConstraintAnchor.mGoneMargin;
  }
  
  public void findDependents(int paramInt, ArrayList<WidgetGroup> paramArrayList, WidgetGroup paramWidgetGroup) {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    if (hashSet != null) {
      Iterator<ConstraintAnchor> iterator = hashSet.iterator();
      while (iterator.hasNext())
        Grouping.findDependents(((ConstraintAnchor)iterator.next()).mOwner, paramInt, paramArrayList, paramWidgetGroup); 
    } 
  }
  
  public HashSet<ConstraintAnchor> getDependents() {
    return this.mDependents;
  }
  
  public int getFinalValue() {
    return !this.mHasFinalValue ? 0 : this.mFinalValue;
  }
  
  public int getMargin() {
    if (this.mOwner.getVisibility() == 8)
      return 0; 
    if (this.mGoneMargin != Integer.MIN_VALUE) {
      ConstraintAnchor constraintAnchor = this.mTarget;
      if (constraintAnchor != null && constraintAnchor.mOwner.getVisibility() == 8)
        return this.mGoneMargin; 
    } 
    return this.mMargin;
  }
  
  public final ConstraintAnchor getOpposite() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
        return this.mOwner.mTop;
      case null:
        return this.mOwner.mBottom;
      case null:
        return this.mOwner.mLeft;
      case null:
        return this.mOwner.mRight;
      case null:
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return null;
  }
  
  public ConstraintWidget getOwner() {
    return this.mOwner;
  }
  
  public SolverVariable getSolverVariable() {
    return this.mSolverVariable;
  }
  
  public ConstraintAnchor getTarget() {
    return this.mTarget;
  }
  
  public Type getType() {
    return this.mType;
  }
  
  public boolean hasCenteredDependents() {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    if (hashSet == null)
      return false; 
    Iterator<ConstraintAnchor> iterator = hashSet.iterator();
    while (iterator.hasNext()) {
      if (((ConstraintAnchor)iterator.next()).getOpposite().isConnected())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDependents() {
    HashSet<ConstraintAnchor> hashSet = this.mDependents;
    boolean bool = false;
    if (hashSet == null)
      return false; 
    if (hashSet.size() > 0)
      bool = true; 
    return bool;
  }
  
  public boolean hasFinalValue() {
    return this.mHasFinalValue;
  }
  
  public boolean isConnected() {
    return (this.mTarget != null);
  }
  
  public boolean isConnectionAllowed(ConstraintWidget paramConstraintWidget) {
    if (isConnectionToMe(paramConstraintWidget, new HashSet<ConstraintWidget>()))
      return false; 
    ConstraintWidget constraintWidget = getOwner().getParent();
    return (constraintWidget == paramConstraintWidget) ? true : ((paramConstraintWidget.getParent() == constraintWidget));
  }
  
  public boolean isConnectionAllowed(ConstraintWidget paramConstraintWidget, ConstraintAnchor paramConstraintAnchor) {
    return isConnectionAllowed(paramConstraintWidget);
  }
  
  public boolean isSideAnchor() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
      case null:
      case null:
      case null:
        return true;
      case null:
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return false;
  }
  
  public boolean isSimilarDimensionConnection(ConstraintAnchor paramConstraintAnchor) {
    boolean bool1;
    Type type1 = paramConstraintAnchor.getType();
    Type type2 = this.mType;
    boolean bool3 = true;
    boolean bool2 = true;
    if (type1 == type2)
      return true; 
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
        return false;
      case null:
      case null:
      case null:
      case null:
        bool1 = bool2;
        if (type1 != Type.TOP) {
          bool1 = bool2;
          if (type1 != Type.BOTTOM) {
            bool1 = bool2;
            if (type1 != Type.CENTER_Y) {
              if (type1 == Type.BASELINE)
                return true; 
              bool1 = false;
            } 
          } 
        } 
        return bool1;
      case null:
      case null:
      case null:
        bool1 = bool3;
        if (type1 != Type.LEFT) {
          bool1 = bool3;
          if (type1 != Type.RIGHT) {
            if (type1 == Type.CENTER_X)
              return true; 
            bool1 = false;
          } 
        } 
        return bool1;
      case null:
        break;
    } 
    return (type1 != Type.BASELINE);
  }
  
  public boolean isValidConnection(ConstraintAnchor paramConstraintAnchor) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: aload_1
    //   9: ifnonnull -> 14
    //   12: iconst_0
    //   13: ireturn
    //   14: aload_1
    //   15: invokevirtual getType : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   18: astore #6
    //   20: aload_0
    //   21: getfield mType : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   24: astore #7
    //   26: aload #6
    //   28: aload #7
    //   30: if_acmpne -> 65
    //   33: aload #7
    //   35: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   38: if_acmpne -> 63
    //   41: aload_1
    //   42: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   45: invokevirtual hasBaseline : ()Z
    //   48: ifeq -> 61
    //   51: aload_0
    //   52: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   55: invokevirtual hasBaseline : ()Z
    //   58: ifne -> 63
    //   61: iconst_0
    //   62: ireturn
    //   63: iconst_1
    //   64: ireturn
    //   65: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$1.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintAnchor$Type : [I
    //   68: aload_0
    //   69: getfield mType : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   72: invokevirtual ordinal : ()I
    //   75: iaload
    //   76: tableswitch default -> 128, 1 -> 285, 2 -> 226, 3 -> 226, 4 -> 167, 5 -> 167, 6 -> 145, 7 -> 143, 8 -> 143, 9 -> 143
    //   128: new java/lang/AssertionError
    //   131: dup
    //   132: aload_0
    //   133: getfield mType : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   136: invokevirtual name : ()Ljava/lang/String;
    //   139: invokespecial <init> : (Ljava/lang/Object;)V
    //   142: athrow
    //   143: iconst_0
    //   144: ireturn
    //   145: aload #6
    //   147: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   150: if_acmpeq -> 165
    //   153: aload #6
    //   155: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   158: if_acmpne -> 163
    //   161: iconst_0
    //   162: ireturn
    //   163: iconst_1
    //   164: ireturn
    //   165: iconst_0
    //   166: ireturn
    //   167: aload #6
    //   169: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   172: if_acmpeq -> 191
    //   175: aload #6
    //   177: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   180: if_acmpne -> 186
    //   183: goto -> 191
    //   186: iconst_0
    //   187: istore_2
    //   188: goto -> 193
    //   191: iconst_1
    //   192: istore_2
    //   193: iload_2
    //   194: istore_3
    //   195: aload_1
    //   196: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   199: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   202: ifeq -> 224
    //   205: iload_2
    //   206: ifne -> 220
    //   209: iload #4
    //   211: istore_2
    //   212: aload #6
    //   214: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   217: if_acmpne -> 222
    //   220: iconst_1
    //   221: istore_2
    //   222: iload_2
    //   223: istore_3
    //   224: iload_3
    //   225: ireturn
    //   226: aload #6
    //   228: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   231: if_acmpeq -> 250
    //   234: aload #6
    //   236: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   239: if_acmpne -> 245
    //   242: goto -> 250
    //   245: iconst_0
    //   246: istore_2
    //   247: goto -> 252
    //   250: iconst_1
    //   251: istore_2
    //   252: iload_2
    //   253: istore_3
    //   254: aload_1
    //   255: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   258: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   261: ifeq -> 283
    //   264: iload_2
    //   265: ifne -> 279
    //   268: iload #5
    //   270: istore_2
    //   271: aload #6
    //   273: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   276: if_acmpne -> 281
    //   279: iconst_1
    //   280: istore_2
    //   281: iload_2
    //   282: istore_3
    //   283: iload_3
    //   284: ireturn
    //   285: iload_3
    //   286: istore_2
    //   287: aload #6
    //   289: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   292: if_acmpeq -> 317
    //   295: iload_3
    //   296: istore_2
    //   297: aload #6
    //   299: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER_X : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   302: if_acmpeq -> 317
    //   305: iload_3
    //   306: istore_2
    //   307: aload #6
    //   309: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.CENTER_Y : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   312: if_acmpeq -> 317
    //   315: iconst_1
    //   316: istore_2
    //   317: iload_2
    //   318: ireturn
  }
  
  public boolean isVerticalAnchor() {
    switch (this.mType) {
      default:
        throw new AssertionError(this.mType.name());
      case null:
      case null:
      case null:
      case null:
      case null:
        return true;
      case null:
      case null:
      case null:
      case null:
        break;
    } 
    return false;
  }
  
  public void reset() {
    ConstraintAnchor constraintAnchor = this.mTarget;
    if (constraintAnchor != null) {
      HashSet<ConstraintAnchor> hashSet = constraintAnchor.mDependents;
      if (hashSet != null) {
        hashSet.remove(this);
        if (this.mTarget.mDependents.size() == 0)
          this.mTarget.mDependents = null; 
      } 
    } 
    this.mDependents = null;
    this.mTarget = null;
    this.mMargin = 0;
    this.mGoneMargin = Integer.MIN_VALUE;
    this.mHasFinalValue = false;
    this.mFinalValue = 0;
  }
  
  public void resetFinalResolution() {
    this.mHasFinalValue = false;
    this.mFinalValue = 0;
  }
  
  public void resetSolverVariable(Cache paramCache) {
    SolverVariable solverVariable = this.mSolverVariable;
    if (solverVariable == null) {
      this.mSolverVariable = new SolverVariable(SolverVariable.Type.UNRESTRICTED, null);
      return;
    } 
    solverVariable.reset();
  }
  
  public void setFinalValue(int paramInt) {
    this.mFinalValue = paramInt;
    this.mHasFinalValue = true;
  }
  
  public void setGoneMargin(int paramInt) {
    if (isConnected())
      this.mGoneMargin = paramInt; 
  }
  
  public void setMargin(int paramInt) {
    if (isConnected())
      this.mMargin = paramInt; 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mOwner.getDebugName());
    stringBuilder.append(":");
    stringBuilder.append(this.mType.toString());
    return stringBuilder.toString();
  }
  
  public enum Type {
    BASELINE, BOTTOM, CENTER, CENTER_X, CENTER_Y, LEFT, NONE, RIGHT, TOP;
    
    static {
      Type type1 = new Type("NONE", 0);
      NONE = type1;
      Type type2 = new Type("LEFT", 1);
      LEFT = type2;
      Type type3 = new Type("TOP", 2);
      TOP = type3;
      Type type4 = new Type("RIGHT", 3);
      RIGHT = type4;
      Type type5 = new Type("BOTTOM", 4);
      BOTTOM = type5;
      Type type6 = new Type("BASELINE", 5);
      BASELINE = type6;
      Type type7 = new Type("CENTER", 6);
      CENTER = type7;
      Type type8 = new Type("CENTER_X", 7);
      CENTER_X = type8;
      Type type9 = new Type("CENTER_Y", 8);
      CENTER_Y = type9;
      $VALUES = new Type[] { type1, type2, type3, type4, type5, type6, type7, type8, type9 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */