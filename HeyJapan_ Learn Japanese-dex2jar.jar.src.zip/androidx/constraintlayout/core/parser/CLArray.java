package androidx.constraintlayout.core.parser;

import java.util.Iterator;

public class CLArray extends CLContainer {
  public CLArray(char[] paramArrayOfchar) {
    super(paramArrayOfchar);
  }
  
  public static CLElement allocate(char[] paramArrayOfchar) {
    return new CLArray(paramArrayOfchar);
  }
  
  protected String toFormattedJSON(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    String str = toJSON();
    if (paramInt2 <= 0 && str.length() + paramInt1 < MAX_LINE) {
      stringBuilder.append(str);
    } else {
      stringBuilder.append("[\n");
      Iterator<CLElement> iterator = this.mElements.iterator();
      boolean bool = true;
      while (iterator.hasNext()) {
        CLElement cLElement = iterator.next();
        if (!bool) {
          stringBuilder.append(",\n");
        } else {
          bool = false;
        } 
        addIndent(stringBuilder, BASE_INDENT + paramInt1);
        stringBuilder.append(cLElement.toFormattedJSON(BASE_INDENT + paramInt1, paramInt2 - 1));
      } 
      stringBuilder.append("\n");
      addIndent(stringBuilder, paramInt1);
      stringBuilder.append("]");
    } 
    return stringBuilder.toString();
  }
  
  protected String toJSON() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(getDebugName());
    stringBuilder1.append("[");
    stringBuilder1 = new StringBuilder(stringBuilder1.toString());
    boolean bool = true;
    for (int i = 0; i < this.mElements.size(); i++) {
      if (!bool) {
        stringBuilder1.append(", ");
      } else {
        bool = false;
      } 
      stringBuilder1.append(((CLElement)this.mElements.get(i)).toJSON());
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(stringBuilder1);
    stringBuilder2.append("]");
    return stringBuilder2.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\parser\CLArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */