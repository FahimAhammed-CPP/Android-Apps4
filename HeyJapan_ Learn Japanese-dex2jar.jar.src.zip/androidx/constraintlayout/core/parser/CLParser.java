package androidx.constraintlayout.core.parser;

import java.io.PrintStream;

public class CLParser {
  static boolean DEBUG = false;
  
  private boolean hasComment = false;
  
  private int lineNumber;
  
  private String mContent;
  
  public CLParser(String paramString) {
    this.mContent = paramString;
  }
  
  private CLElement createElement(CLElement paramCLElement, int paramInt, TYPE paramTYPE, boolean paramBoolean, char[] paramArrayOfchar) {
    CLElement cLElement;
    if (DEBUG) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("CREATE ");
      stringBuilder.append(paramTYPE);
      stringBuilder.append(" at ");
      stringBuilder.append(paramArrayOfchar[paramInt]);
      printStream.println(stringBuilder.toString());
    } 
    switch (paramTYPE) {
      default:
        paramTYPE = null;
        break;
      case null:
        cLElement = CLToken.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLKey.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLNumber.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLString.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLArray.allocate(paramArrayOfchar);
        paramInt++;
        break;
      case null:
        cLElement = CLObject.allocate(paramArrayOfchar);
        paramInt++;
        break;
    } 
    if (cLElement == null)
      return null; 
    cLElement.setLine(this.lineNumber);
    if (paramBoolean)
      cLElement.setStart(paramInt); 
    if (paramCLElement instanceof CLContainer)
      cLElement.setContainer((CLContainer)paramCLElement); 
    return cLElement;
  }
  
  private CLElement getNextJsonElement(int paramInt, char paramChar, CLElement paramCLElement, char[] paramArrayOfchar) throws CLParsingException {
    CLElement cLElement = paramCLElement;
    if (paramChar != '\t') {
      cLElement = paramCLElement;
      if (paramChar != '\n') {
        cLElement = paramCLElement;
        if (paramChar != '\r') {
          cLElement = paramCLElement;
          if (paramChar != ' ') {
            StringBuilder stringBuilder;
            if (paramChar != '"' && paramChar != '\'') {
              if (paramChar != '[') {
                if (paramChar != ']') {
                  if (paramChar != '{') {
                    if (paramChar != '}') {
                      cLElement = paramCLElement;
                      switch (paramChar) {
                        default:
                          if (paramCLElement instanceof CLContainer && !(paramCLElement instanceof CLObject)) {
                            CLElement cLElement1 = createElement(paramCLElement, paramInt, TYPE.TOKEN, true, paramArrayOfchar);
                            paramCLElement = cLElement1;
                            if (paramCLElement.validate(paramChar, paramInt))
                              return cLElement1; 
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("incorrect token <");
                            stringBuilder.append(paramChar);
                            stringBuilder.append("> at line ");
                            stringBuilder.append(this.lineNumber);
                            throw new CLParsingException(stringBuilder.toString(), paramCLElement);
                          } 
                          return createElement(paramCLElement, paramInt, TYPE.KEY, true, (char[])stringBuilder);
                        case '/':
                          paramInt++;
                          cLElement = paramCLElement;
                          if (paramInt < stringBuilder.length) {
                            cLElement = paramCLElement;
                            if (stringBuilder[paramInt] == 47) {
                              this.hasComment = true;
                              return paramCLElement;
                            } 
                          } 
                          break;
                        case '+':
                        case '-':
                        case '.':
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                          return createElement(paramCLElement, paramInt, TYPE.NUMBER, true, (char[])stringBuilder);
                        case ',':
                        case ':':
                          break;
                      } 
                    } else {
                      paramCLElement.setEnd((paramInt - 1));
                      paramCLElement = paramCLElement.getContainer();
                      paramCLElement.setEnd(paramInt);
                      return paramCLElement;
                    } 
                  } else {
                    return createElement(paramCLElement, paramInt, TYPE.OBJECT, true, (char[])stringBuilder);
                  } 
                } else {
                  paramCLElement.setEnd((paramInt - 1));
                  paramCLElement = paramCLElement.getContainer();
                  paramCLElement.setEnd(paramInt);
                  return paramCLElement;
                } 
              } else {
                return createElement(paramCLElement, paramInt, TYPE.ARRAY, true, (char[])stringBuilder);
              } 
            } else {
              if (paramCLElement instanceof CLObject)
                return createElement(paramCLElement, paramInt, TYPE.KEY, true, (char[])stringBuilder); 
              cLElement = createElement(paramCLElement, paramInt, TYPE.STRING, true, (char[])stringBuilder);
            } 
          } 
        } 
      } 
    } 
    return cLElement;
  }
  
  public static CLObject parse(String paramString) throws CLParsingException {
    return (new CLParser(paramString)).parse();
  }
  
  public CLObject parse() throws CLParsingException {
    // Byte code:
    //   0: aload_0
    //   1: getfield mContent : Ljava/lang/String;
    //   4: invokevirtual toCharArray : ()[C
    //   7: astore #12
    //   9: aload #12
    //   11: arraylength
    //   12: istore_3
    //   13: aload_0
    //   14: iconst_1
    //   15: putfield lineNumber : I
    //   18: iconst_0
    //   19: istore_2
    //   20: iload_2
    //   21: iload_3
    //   22: if_icmpge -> 65
    //   25: aload #12
    //   27: iload_2
    //   28: caload
    //   29: istore #4
    //   31: iload #4
    //   33: bipush #123
    //   35: if_icmpne -> 41
    //   38: goto -> 67
    //   41: iload #4
    //   43: bipush #10
    //   45: if_icmpne -> 58
    //   48: aload_0
    //   49: aload_0
    //   50: getfield lineNumber : I
    //   53: iconst_1
    //   54: iadd
    //   55: putfield lineNumber : I
    //   58: iload_2
    //   59: iconst_1
    //   60: iadd
    //   61: istore_2
    //   62: goto -> 20
    //   65: iconst_m1
    //   66: istore_2
    //   67: iload_2
    //   68: iconst_m1
    //   69: if_icmpeq -> 790
    //   72: aload #12
    //   74: invokestatic allocate : ([C)Landroidx/constraintlayout/core/parser/CLObject;
    //   77: astore #11
    //   79: aload #11
    //   81: aload_0
    //   82: getfield lineNumber : I
    //   85: invokevirtual setLine : (I)V
    //   88: aload #11
    //   90: iload_2
    //   91: i2l
    //   92: invokevirtual setStart : (J)V
    //   95: iload_2
    //   96: iconst_1
    //   97: iadd
    //   98: istore_2
    //   99: aload #11
    //   101: astore #9
    //   103: aload #9
    //   105: astore #8
    //   107: iload_2
    //   108: iload_3
    //   109: if_icmpge -> 681
    //   112: aload #12
    //   114: iload_2
    //   115: caload
    //   116: istore_1
    //   117: iload_1
    //   118: bipush #10
    //   120: if_icmpne -> 133
    //   123: aload_0
    //   124: aload_0
    //   125: getfield lineNumber : I
    //   128: iconst_1
    //   129: iadd
    //   130: putfield lineNumber : I
    //   133: aload_0
    //   134: getfield hasComment : Z
    //   137: ifeq -> 155
    //   140: aload #9
    //   142: astore #10
    //   144: iload_1
    //   145: bipush #10
    //   147: if_icmpne -> 670
    //   150: aload_0
    //   151: iconst_0
    //   152: putfield hasComment : Z
    //   155: aload #9
    //   157: ifnonnull -> 167
    //   160: aload #9
    //   162: astore #8
    //   164: goto -> 681
    //   167: aload #9
    //   169: invokevirtual isDone : ()Z
    //   172: ifeq -> 190
    //   175: aload_0
    //   176: iload_2
    //   177: iload_1
    //   178: aload #9
    //   180: aload #12
    //   182: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   185: astore #8
    //   187: goto -> 625
    //   190: aload #9
    //   192: instanceof androidx/constraintlayout/core/parser/CLObject
    //   195: ifeq -> 235
    //   198: iload_1
    //   199: bipush #125
    //   201: if_icmpne -> 220
    //   204: aload #9
    //   206: iload_2
    //   207: iconst_1
    //   208: isub
    //   209: i2l
    //   210: invokevirtual setEnd : (J)V
    //   213: aload #9
    //   215: astore #8
    //   217: goto -> 625
    //   220: aload_0
    //   221: iload_2
    //   222: iload_1
    //   223: aload #9
    //   225: aload #12
    //   227: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   230: astore #8
    //   232: goto -> 625
    //   235: aload #9
    //   237: instanceof androidx/constraintlayout/core/parser/CLArray
    //   240: ifeq -> 280
    //   243: iload_1
    //   244: bipush #93
    //   246: if_icmpne -> 265
    //   249: aload #9
    //   251: iload_2
    //   252: iconst_1
    //   253: isub
    //   254: i2l
    //   255: invokevirtual setEnd : (J)V
    //   258: aload #9
    //   260: astore #8
    //   262: goto -> 625
    //   265: aload_0
    //   266: iload_2
    //   267: iload_1
    //   268: aload #9
    //   270: aload #12
    //   272: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   275: astore #8
    //   277: goto -> 625
    //   280: aload #9
    //   282: instanceof androidx/constraintlayout/core/parser/CLString
    //   285: istore #5
    //   287: iload #5
    //   289: ifeq -> 337
    //   292: aload #9
    //   294: astore #8
    //   296: aload #12
    //   298: aload #9
    //   300: getfield start : J
    //   303: l2i
    //   304: caload
    //   305: iload_1
    //   306: if_icmpne -> 625
    //   309: aload #9
    //   311: aload #9
    //   313: getfield start : J
    //   316: lconst_1
    //   317: ladd
    //   318: invokevirtual setStart : (J)V
    //   321: aload #9
    //   323: iload_2
    //   324: iconst_1
    //   325: isub
    //   326: i2l
    //   327: invokevirtual setEnd : (J)V
    //   330: aload #9
    //   332: astore #8
    //   334: goto -> 625
    //   337: aload #9
    //   339: instanceof androidx/constraintlayout/core/parser/CLToken
    //   342: ifeq -> 427
    //   345: aload #9
    //   347: checkcast androidx/constraintlayout/core/parser/CLToken
    //   350: astore #8
    //   352: aload #8
    //   354: iload_1
    //   355: iload_2
    //   356: i2l
    //   357: invokevirtual validate : (CJ)Z
    //   360: ifeq -> 366
    //   363: goto -> 427
    //   366: new java/lang/StringBuilder
    //   369: dup
    //   370: invokespecial <init> : ()V
    //   373: astore #9
    //   375: aload #9
    //   377: ldc 'parsing incorrect token '
    //   379: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: pop
    //   383: aload #9
    //   385: aload #8
    //   387: invokevirtual content : ()Ljava/lang/String;
    //   390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   393: pop
    //   394: aload #9
    //   396: ldc ' at line '
    //   398: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   401: pop
    //   402: aload #9
    //   404: aload_0
    //   405: getfield lineNumber : I
    //   408: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   411: pop
    //   412: new androidx/constraintlayout/core/parser/CLParsingException
    //   415: dup
    //   416: aload #9
    //   418: invokevirtual toString : ()Ljava/lang/String;
    //   421: aload #8
    //   423: invokespecial <init> : (Ljava/lang/String;Landroidx/constraintlayout/core/parser/CLElement;)V
    //   426: athrow
    //   427: aload #9
    //   429: instanceof androidx/constraintlayout/core/parser/CLKey
    //   432: ifne -> 440
    //   435: iload #5
    //   437: ifeq -> 492
    //   440: aload #12
    //   442: aload #9
    //   444: getfield start : J
    //   447: l2i
    //   448: caload
    //   449: istore #4
    //   451: iload #4
    //   453: bipush #39
    //   455: if_icmpeq -> 465
    //   458: iload #4
    //   460: bipush #34
    //   462: if_icmpne -> 492
    //   465: iload #4
    //   467: iload_1
    //   468: if_icmpne -> 492
    //   471: aload #9
    //   473: aload #9
    //   475: getfield start : J
    //   478: lconst_1
    //   479: ladd
    //   480: invokevirtual setStart : (J)V
    //   483: aload #9
    //   485: iload_2
    //   486: iconst_1
    //   487: isub
    //   488: i2l
    //   489: invokevirtual setEnd : (J)V
    //   492: aload #9
    //   494: astore #8
    //   496: aload #9
    //   498: invokevirtual isDone : ()Z
    //   501: ifne -> 625
    //   504: iload_1
    //   505: bipush #125
    //   507: if_icmpeq -> 556
    //   510: iload_1
    //   511: bipush #93
    //   513: if_icmpeq -> 556
    //   516: iload_1
    //   517: bipush #44
    //   519: if_icmpeq -> 556
    //   522: iload_1
    //   523: bipush #32
    //   525: if_icmpeq -> 556
    //   528: iload_1
    //   529: bipush #9
    //   531: if_icmpeq -> 556
    //   534: iload_1
    //   535: bipush #13
    //   537: if_icmpeq -> 556
    //   540: iload_1
    //   541: bipush #10
    //   543: if_icmpeq -> 556
    //   546: aload #9
    //   548: astore #8
    //   550: iload_1
    //   551: bipush #58
    //   553: if_icmpne -> 625
    //   556: iload_2
    //   557: iconst_1
    //   558: isub
    //   559: i2l
    //   560: lstore #6
    //   562: aload #9
    //   564: lload #6
    //   566: invokevirtual setEnd : (J)V
    //   569: iload_1
    //   570: bipush #125
    //   572: if_icmpeq -> 585
    //   575: aload #9
    //   577: astore #8
    //   579: iload_1
    //   580: bipush #93
    //   582: if_icmpne -> 625
    //   585: aload #9
    //   587: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   590: astore #9
    //   592: aload #9
    //   594: lload #6
    //   596: invokevirtual setEnd : (J)V
    //   599: aload #9
    //   601: astore #8
    //   603: aload #9
    //   605: instanceof androidx/constraintlayout/core/parser/CLKey
    //   608: ifeq -> 625
    //   611: aload #9
    //   613: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   616: astore #8
    //   618: aload #8
    //   620: lload #6
    //   622: invokevirtual setEnd : (J)V
    //   625: aload #8
    //   627: astore #10
    //   629: aload #8
    //   631: invokevirtual isDone : ()Z
    //   634: ifeq -> 670
    //   637: aload #8
    //   639: instanceof androidx/constraintlayout/core/parser/CLKey
    //   642: ifeq -> 663
    //   645: aload #8
    //   647: astore #10
    //   649: aload #8
    //   651: checkcast androidx/constraintlayout/core/parser/CLKey
    //   654: getfield mElements : Ljava/util/ArrayList;
    //   657: invokevirtual size : ()I
    //   660: ifle -> 670
    //   663: aload #8
    //   665: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   668: astore #10
    //   670: iload_2
    //   671: iconst_1
    //   672: iadd
    //   673: istore_2
    //   674: aload #10
    //   676: astore #9
    //   678: goto -> 103
    //   681: aload #8
    //   683: ifnull -> 738
    //   686: aload #8
    //   688: invokevirtual isDone : ()Z
    //   691: ifne -> 738
    //   694: aload #8
    //   696: instanceof androidx/constraintlayout/core/parser/CLString
    //   699: ifeq -> 719
    //   702: aload #8
    //   704: aload #8
    //   706: getfield start : J
    //   709: l2i
    //   710: iconst_1
    //   711: iadd
    //   712: i2l
    //   713: invokevirtual setStart : (J)V
    //   716: goto -> 719
    //   719: aload #8
    //   721: iload_3
    //   722: iconst_1
    //   723: isub
    //   724: i2l
    //   725: invokevirtual setEnd : (J)V
    //   728: aload #8
    //   730: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   733: astore #8
    //   735: goto -> 681
    //   738: getstatic androidx/constraintlayout/core/parser/CLParser.DEBUG : Z
    //   741: ifeq -> 787
    //   744: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   747: astore #8
    //   749: new java/lang/StringBuilder
    //   752: dup
    //   753: invokespecial <init> : ()V
    //   756: astore #9
    //   758: aload #9
    //   760: ldc 'Root: '
    //   762: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   765: pop
    //   766: aload #9
    //   768: aload #11
    //   770: invokevirtual toJSON : ()Ljava/lang/String;
    //   773: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   776: pop
    //   777: aload #8
    //   779: aload #9
    //   781: invokevirtual toString : ()Ljava/lang/String;
    //   784: invokevirtual println : (Ljava/lang/String;)V
    //   787: aload #11
    //   789: areturn
    //   790: new androidx/constraintlayout/core/parser/CLParsingException
    //   793: dup
    //   794: ldc 'invalid json content'
    //   796: aconst_null
    //   797: invokespecial <init> : (Ljava/lang/String;Landroidx/constraintlayout/core/parser/CLElement;)V
    //   800: astore #8
    //   802: goto -> 808
    //   805: aload #8
    //   807: athrow
    //   808: goto -> 805
  }
  
  enum TYPE {
    ARRAY, KEY, NUMBER, OBJECT, STRING, TOKEN, UNKNOWN;
    
    static {
      TYPE tYPE1 = new TYPE("UNKNOWN", 0);
      UNKNOWN = tYPE1;
      TYPE tYPE2 = new TYPE("OBJECT", 1);
      OBJECT = tYPE2;
      TYPE tYPE3 = new TYPE("ARRAY", 2);
      ARRAY = tYPE3;
      TYPE tYPE4 = new TYPE("NUMBER", 3);
      NUMBER = tYPE4;
      TYPE tYPE5 = new TYPE("STRING", 4);
      STRING = tYPE5;
      TYPE tYPE6 = new TYPE("KEY", 5);
      KEY = tYPE6;
      TYPE tYPE7 = new TYPE("TOKEN", 6);
      TOKEN = tYPE7;
      $VALUES = new TYPE[] { tYPE1, tYPE2, tYPE3, tYPE4, tYPE5, tYPE6, tYPE7 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\parser\CLParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */