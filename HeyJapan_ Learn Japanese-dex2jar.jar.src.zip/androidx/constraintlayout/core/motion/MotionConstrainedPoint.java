package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.utils.Easing;
import androidx.constraintlayout.core.motion.utils.Rect;
import androidx.constraintlayout.core.motion.utils.SplineSet;
import androidx.constraintlayout.core.motion.utils.Utils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

class MotionConstrainedPoint implements Comparable<MotionConstrainedPoint> {
  static final int CARTESIAN = 2;
  
  public static final boolean DEBUG = false;
  
  static final int PERPENDICULAR = 1;
  
  public static final String TAG = "MotionPaths";
  
  static String[] names = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  private float alpha = 1.0F;
  
  private boolean applyElevation = false;
  
  private float elevation = 0.0F;
  
  private float height;
  
  private int mAnimateRelativeTo = -1;
  
  LinkedHashMap<String, CustomVariable> mCustomVariable = new LinkedHashMap<String, CustomVariable>();
  
  private int mDrawPath = 0;
  
  private Easing mKeyFrameEasing;
  
  int mMode = 0;
  
  private float mPathRotate = Float.NaN;
  
  private float mPivotX = Float.NaN;
  
  private float mPivotY = Float.NaN;
  
  private float mProgress = Float.NaN;
  
  double[] mTempDelta = new double[18];
  
  double[] mTempValue = new double[18];
  
  int mVisibilityMode = 0;
  
  private float position;
  
  private float rotation = 0.0F;
  
  private float rotationX = 0.0F;
  
  public float rotationY = 0.0F;
  
  private float scaleX = 1.0F;
  
  private float scaleY = 1.0F;
  
  private float translationX = 0.0F;
  
  private float translationY = 0.0F;
  
  private float translationZ = 0.0F;
  
  int visibility;
  
  private float width;
  
  private float x;
  
  private float y;
  
  private boolean diff(float paramFloat1, float paramFloat2) {
    return (Float.isNaN(paramFloat1) || Float.isNaN(paramFloat2)) ? ((Float.isNaN(paramFloat1) != Float.isNaN(paramFloat2))) : ((Math.abs(paramFloat1 - paramFloat2) > 1.0E-6F));
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap, int paramInt) {
    for (String str : paramHashMap.keySet()) {
      StringBuilder stringBuilder;
      SplineSet splineSet = paramHashMap.get(str);
      str.hashCode();
      byte b = -1;
      switch (str.hashCode()) {
        case 803192288:
          if (!str.equals("pathRotate"))
            break; 
          b = 12;
          break;
        case 92909918:
          if (!str.equals("alpha"))
            break; 
          b = 11;
          break;
        case -908189617:
          if (!str.equals("scaleY"))
            break; 
          b = 10;
          break;
        case -908189618:
          if (!str.equals("scaleX"))
            break; 
          b = 9;
          break;
        case -987906985:
          if (!str.equals("pivotY"))
            break; 
          b = 8;
          break;
        case -987906986:
          if (!str.equals("pivotX"))
            break; 
          b = 7;
          break;
        case -1001078227:
          if (!str.equals("progress"))
            break; 
          b = 6;
          break;
        case -1225497655:
          if (!str.equals("translationZ"))
            break; 
          b = 5;
          break;
        case -1225497656:
          if (!str.equals("translationY"))
            break; 
          b = 4;
          break;
        case -1225497657:
          if (!str.equals("translationX"))
            break; 
          b = 3;
          break;
        case -1249320804:
          if (!str.equals("rotationZ"))
            break; 
          b = 2;
          break;
        case -1249320805:
          if (!str.equals("rotationY"))
            break; 
          b = 1;
          break;
        case -1249320806:
          if (!str.equals("rotationX"))
            break; 
          b = 0;
          break;
      } 
      float f1 = 1.0F;
      float f3 = 0.0F;
      float f4 = 0.0F;
      float f5 = 0.0F;
      float f6 = 0.0F;
      float f7 = 0.0F;
      float f8 = 0.0F;
      float f9 = 0.0F;
      float f10 = 0.0F;
      float f11 = 0.0F;
      float f2 = 0.0F;
      switch (b) {
        default:
          if (str.startsWith("CUSTOM")) {
            String str1 = str.split(",")[1];
            if (this.mCustomVariable.containsKey(str1)) {
              CustomVariable customVariable = this.mCustomVariable.get(str1);
              if (splineSet instanceof SplineSet.CustomSpline) {
                ((SplineSet.CustomSpline)splineSet).setPoint(paramInt, customVariable);
                continue;
              } 
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str);
              stringBuilder1.append(" ViewSpline not a CustomSet frame = ");
              stringBuilder1.append(paramInt);
              stringBuilder1.append(", value");
              stringBuilder1.append(customVariable.getValueToInterpolate());
              stringBuilder1.append(splineSet);
              Utils.loge("MotionPaths", stringBuilder1.toString());
            } 
            continue;
          } 
          stringBuilder = new StringBuilder();
          stringBuilder.append("UNKNOWN spline ");
          stringBuilder.append(str);
          Utils.loge("MotionPaths", stringBuilder.toString());
          continue;
        case 12:
          if (Float.isNaN(this.mPathRotate)) {
            f1 = f2;
          } else {
            f1 = this.mPathRotate;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 11:
          if (!Float.isNaN(this.alpha))
            f1 = this.alpha; 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 10:
          if (!Float.isNaN(this.scaleY))
            f1 = this.scaleY; 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 9:
          if (!Float.isNaN(this.scaleX))
            f1 = this.scaleX; 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 8:
          if (Float.isNaN(this.mPivotY)) {
            f1 = f3;
          } else {
            f1 = this.mPivotY;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 7:
          if (Float.isNaN(this.mPivotX)) {
            f1 = f4;
          } else {
            f1 = this.mPivotX;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 6:
          if (Float.isNaN(this.mProgress)) {
            f1 = f5;
          } else {
            f1 = this.mProgress;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 5:
          if (Float.isNaN(this.translationZ)) {
            f1 = f6;
          } else {
            f1 = this.translationZ;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 4:
          if (Float.isNaN(this.translationY)) {
            f1 = f7;
          } else {
            f1 = this.translationY;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 3:
          if (Float.isNaN(this.translationX)) {
            f1 = f8;
          } else {
            f1 = this.translationX;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 2:
          if (Float.isNaN(this.rotation)) {
            f1 = f9;
          } else {
            f1 = this.rotation;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 1:
          if (Float.isNaN(this.rotationY)) {
            f1 = f10;
          } else {
            f1 = this.rotationY;
          } 
          stringBuilder.setPoint(paramInt, f1);
          continue;
        case 0:
          break;
      } 
      if (Float.isNaN(this.rotationX)) {
        f1 = f11;
      } else {
        f1 = this.rotationX;
      } 
      stringBuilder.setPoint(paramInt, f1);
    } 
  }
  
  public void applyParameters(MotionWidget paramMotionWidget) {
    float f;
    this.visibility = paramMotionWidget.getVisibility();
    if (paramMotionWidget.getVisibility() != 4) {
      f = 0.0F;
    } else {
      f = paramMotionWidget.getAlpha();
    } 
    this.alpha = f;
    this.applyElevation = false;
    this.rotation = paramMotionWidget.getRotationZ();
    this.rotationX = paramMotionWidget.getRotationX();
    this.rotationY = paramMotionWidget.getRotationY();
    this.scaleX = paramMotionWidget.getScaleX();
    this.scaleY = paramMotionWidget.getScaleY();
    this.mPivotX = paramMotionWidget.getPivotX();
    this.mPivotY = paramMotionWidget.getPivotY();
    this.translationX = paramMotionWidget.getTranslationX();
    this.translationY = paramMotionWidget.getTranslationY();
    this.translationZ = paramMotionWidget.getTranslationZ();
    for (String str : paramMotionWidget.getCustomAttributeNames()) {
      CustomVariable customVariable = paramMotionWidget.getCustomAttribute(str);
      if (customVariable != null && customVariable.isContinuous())
        this.mCustomVariable.put(str, customVariable); 
    } 
  }
  
  public int compareTo(MotionConstrainedPoint paramMotionConstrainedPoint) {
    return Float.compare(this.position, paramMotionConstrainedPoint.position);
  }
  
  void different(MotionConstrainedPoint paramMotionConstrainedPoint, HashSet<String> paramHashSet) {
    if (diff(this.alpha, paramMotionConstrainedPoint.alpha))
      paramHashSet.add("alpha"); 
    if (diff(this.elevation, paramMotionConstrainedPoint.elevation))
      paramHashSet.add("translationZ"); 
    int i = this.visibility;
    int j = paramMotionConstrainedPoint.visibility;
    if (i != j && this.mVisibilityMode == 0 && (i == 4 || j == 4))
      paramHashSet.add("alpha"); 
    if (diff(this.rotation, paramMotionConstrainedPoint.rotation))
      paramHashSet.add("rotationZ"); 
    if (!Float.isNaN(this.mPathRotate) || !Float.isNaN(paramMotionConstrainedPoint.mPathRotate))
      paramHashSet.add("pathRotate"); 
    if (!Float.isNaN(this.mProgress) || !Float.isNaN(paramMotionConstrainedPoint.mProgress))
      paramHashSet.add("progress"); 
    if (diff(this.rotationX, paramMotionConstrainedPoint.rotationX))
      paramHashSet.add("rotationX"); 
    if (diff(this.rotationY, paramMotionConstrainedPoint.rotationY))
      paramHashSet.add("rotationY"); 
    if (diff(this.mPivotX, paramMotionConstrainedPoint.mPivotX))
      paramHashSet.add("pivotX"); 
    if (diff(this.mPivotY, paramMotionConstrainedPoint.mPivotY))
      paramHashSet.add("pivotY"); 
    if (diff(this.scaleX, paramMotionConstrainedPoint.scaleX))
      paramHashSet.add("scaleX"); 
    if (diff(this.scaleY, paramMotionConstrainedPoint.scaleY))
      paramHashSet.add("scaleY"); 
    if (diff(this.translationX, paramMotionConstrainedPoint.translationX))
      paramHashSet.add("translationX"); 
    if (diff(this.translationY, paramMotionConstrainedPoint.translationY))
      paramHashSet.add("translationY"); 
    if (diff(this.translationZ, paramMotionConstrainedPoint.translationZ))
      paramHashSet.add("translationZ"); 
    if (diff(this.elevation, paramMotionConstrainedPoint.elevation))
      paramHashSet.add("elevation"); 
  }
  
  void different(MotionConstrainedPoint paramMotionConstrainedPoint, boolean[] paramArrayOfboolean, String[] paramArrayOfString) {
    paramArrayOfboolean[0] = paramArrayOfboolean[0] | diff(this.position, paramMotionConstrainedPoint.position);
    paramArrayOfboolean[1] = paramArrayOfboolean[1] | diff(this.x, paramMotionConstrainedPoint.x);
    paramArrayOfboolean[2] = paramArrayOfboolean[2] | diff(this.y, paramMotionConstrainedPoint.y);
    paramArrayOfboolean[3] = paramArrayOfboolean[3] | diff(this.width, paramMotionConstrainedPoint.width);
    boolean bool = paramArrayOfboolean[4];
    paramArrayOfboolean[4] = diff(this.height, paramMotionConstrainedPoint.height) | bool;
  }
  
  void fillStandard(double[] paramArrayOfdouble, int[] paramArrayOfint) {
    float f1 = this.position;
    int i = 0;
    float f2 = this.x;
    float f3 = this.y;
    float f4 = this.width;
    float f5 = this.height;
    float f6 = this.alpha;
    float f7 = this.elevation;
    float f8 = this.rotation;
    float f9 = this.rotationX;
    float f10 = this.rotationY;
    float f11 = this.scaleX;
    float f12 = this.scaleY;
    float f13 = this.mPivotX;
    float f14 = this.mPivotY;
    float f15 = this.translationX;
    float f16 = this.translationY;
    float f17 = this.translationZ;
    float f18 = this.mPathRotate;
    int j;
    for (j = 0; i < paramArrayOfint.length; j = k) {
      int k = j;
      if (paramArrayOfint[i] < 18) {
        k = paramArrayOfint[i];
        (new float[18])[0] = f1;
        (new float[18])[1] = f2;
        (new float[18])[2] = f3;
        (new float[18])[3] = f4;
        (new float[18])[4] = f5;
        (new float[18])[5] = f6;
        (new float[18])[6] = f7;
        (new float[18])[7] = f8;
        (new float[18])[8] = f9;
        (new float[18])[9] = f10;
        (new float[18])[10] = f11;
        (new float[18])[11] = f12;
        (new float[18])[12] = f13;
        (new float[18])[13] = f14;
        (new float[18])[14] = f15;
        (new float[18])[15] = f16;
        (new float[18])[16] = f17;
        (new float[18])[17] = f18;
        paramArrayOfdouble[j] = (new float[18])[k];
        k = j + 1;
      } 
      i++;
    } 
  }
  
  int getCustomData(String paramString, double[] paramArrayOfdouble, int paramInt) {
    CustomVariable customVariable = this.mCustomVariable.get(paramString);
    if (customVariable.numberOfInterpolatedValues() == 1) {
      paramArrayOfdouble[paramInt] = customVariable.getValueToInterpolate();
      return 1;
    } 
    int j = customVariable.numberOfInterpolatedValues();
    float[] arrayOfFloat = new float[j];
    customVariable.getValuesToInterpolate(arrayOfFloat);
    int i = 0;
    while (i < j) {
      paramArrayOfdouble[paramInt] = arrayOfFloat[i];
      i++;
      paramInt++;
    } 
    return j;
  }
  
  int getCustomDataCount(String paramString) {
    return ((CustomVariable)this.mCustomVariable.get(paramString)).numberOfInterpolatedValues();
  }
  
  boolean hasCustomData(String paramString) {
    return this.mCustomVariable.containsKey(paramString);
  }
  
  void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.width = paramFloat3;
    this.height = paramFloat4;
  }
  
  public void setState(MotionWidget paramMotionWidget) {
    setBounds(paramMotionWidget.getX(), paramMotionWidget.getY(), paramMotionWidget.getWidth(), paramMotionWidget.getHeight());
    applyParameters(paramMotionWidget);
  }
  
  public void setState(Rect paramRect, MotionWidget paramMotionWidget, int paramInt, float paramFloat) {
    setBounds(paramRect.left, paramRect.top, paramRect.width(), paramRect.height());
    applyParameters(paramMotionWidget);
    this.mPivotX = Float.NaN;
    this.mPivotY = Float.NaN;
    if (paramInt != 1) {
      if (paramInt != 2)
        return; 
      this.rotation = paramFloat + 90.0F;
      return;
    } 
    this.rotation = paramFloat - 90.0F;
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\motion\MotionConstrainedPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */