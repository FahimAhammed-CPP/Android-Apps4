package androidx.constraintlayout.core.motion.utils;

public interface StopEngine {
  String debug(String paramString, float paramFloat);
  
  float getInterpolation(float paramFloat);
  
  float getVelocity();
  
  float getVelocity(float paramFloat);
  
  boolean isStopped();
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\StopEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */