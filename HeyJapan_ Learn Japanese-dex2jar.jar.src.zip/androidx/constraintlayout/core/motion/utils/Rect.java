package androidx.constraintlayout.core.motion.utils;

public class Rect {
  public int bottom;
  
  public int left;
  
  public int right;
  
  public int top;
  
  public int height() {
    return this.bottom - this.top;
  }
  
  public int width() {
    return this.right - this.left;
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\Rect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */