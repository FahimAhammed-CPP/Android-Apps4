package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.key.MotionKey;
import androidx.constraintlayout.core.motion.key.MotionKeyCycle;
import androidx.constraintlayout.core.motion.key.MotionKeyPosition;
import androidx.constraintlayout.core.motion.key.MotionKeyTimeCycle;
import androidx.constraintlayout.core.motion.key.MotionKeyTrigger;
import androidx.constraintlayout.core.motion.utils.CurveFit;
import androidx.constraintlayout.core.motion.utils.DifferentialInterpolator;
import androidx.constraintlayout.core.motion.utils.Easing;
import androidx.constraintlayout.core.motion.utils.FloatRect;
import androidx.constraintlayout.core.motion.utils.KeyCache;
import androidx.constraintlayout.core.motion.utils.KeyCycleOscillator;
import androidx.constraintlayout.core.motion.utils.KeyFrameArray;
import androidx.constraintlayout.core.motion.utils.Rect;
import androidx.constraintlayout.core.motion.utils.SplineSet;
import androidx.constraintlayout.core.motion.utils.TimeCycleSplineSet;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.core.motion.utils.Utils;
import androidx.constraintlayout.core.motion.utils.VelocityMatrix;
import androidx.constraintlayout.core.motion.utils.ViewState;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class Motion implements TypedValues {
  static final int BOUNCE = 4;
  
  private static final boolean DEBUG = false;
  
  public static final int DRAW_PATH_AS_CONFIGURED = 4;
  
  public static final int DRAW_PATH_BASIC = 1;
  
  public static final int DRAW_PATH_CARTESIAN = 3;
  
  public static final int DRAW_PATH_NONE = 0;
  
  public static final int DRAW_PATH_RECTANGLE = 5;
  
  public static final int DRAW_PATH_RELATIVE = 2;
  
  public static final int DRAW_PATH_SCREEN = 6;
  
  static final int EASE_IN = 1;
  
  static final int EASE_IN_OUT = 0;
  
  static final int EASE_OUT = 2;
  
  private static final boolean FAVOR_FIXED_SIZE_VIEWS = false;
  
  public static final int HORIZONTAL_PATH_X = 2;
  
  public static final int HORIZONTAL_PATH_Y = 3;
  
  private static final int INTERPOLATOR_REFERENCE_ID = -2;
  
  private static final int INTERPOLATOR_UNDEFINED = -3;
  
  static final int LINEAR = 3;
  
  static final int OVERSHOOT = 5;
  
  public static final int PATH_PERCENT = 0;
  
  public static final int PATH_PERPENDICULAR = 1;
  
  public static final int ROTATION_LEFT = 2;
  
  public static final int ROTATION_RIGHT = 1;
  
  private static final int SPLINE_STRING = -1;
  
  private static final String TAG = "MotionController";
  
  public static final int VERTICAL_PATH_X = 4;
  
  public static final int VERTICAL_PATH_Y = 5;
  
  private int MAX_DIMENSION = 4;
  
  String[] attributeTable;
  
  private CurveFit mArcSpline;
  
  private int[] mAttributeInterpolatorCount;
  
  private String[] mAttributeNames;
  
  private HashMap<String, SplineSet> mAttributesMap;
  
  String mConstraintTag;
  
  float mCurrentCenterX;
  
  float mCurrentCenterY;
  
  private int mCurveFitType = -1;
  
  private HashMap<String, KeyCycleOscillator> mCycleMap;
  
  private MotionPaths mEndMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mEndPoint = new MotionConstrainedPoint();
  
  int mId;
  
  private double[] mInterpolateData;
  
  private int[] mInterpolateVariables;
  
  private double[] mInterpolateVelocity;
  
  private ArrayList<MotionKey> mKeyList = new ArrayList<MotionKey>();
  
  private MotionKeyTrigger[] mKeyTriggers;
  
  private ArrayList<MotionPaths> mMotionPaths = new ArrayList<MotionPaths>();
  
  float mMotionStagger = Float.NaN;
  
  private boolean mNoMovement = false;
  
  private int mPathMotionArc = -1;
  
  private DifferentialInterpolator mQuantizeMotionInterpolator = null;
  
  private float mQuantizeMotionPhase = Float.NaN;
  
  private int mQuantizeMotionSteps = -1;
  
  private CurveFit[] mSpline;
  
  float mStaggerOffset = 0.0F;
  
  float mStaggerScale = 1.0F;
  
  private MotionPaths mStartMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mStartPoint = new MotionConstrainedPoint();
  
  Rect mTempRect = new Rect();
  
  private HashMap<String, TimeCycleSplineSet> mTimeCycleAttributesMap;
  
  private int mTransformPivotTarget = -1;
  
  private MotionWidget mTransformPivotView = null;
  
  private float[] mValuesBuff = new float[4];
  
  private float[] mVelocity = new float[1];
  
  MotionWidget mView;
  
  public Motion(MotionWidget paramMotionWidget) {
    setView(paramMotionWidget);
  }
  
  private float getAdjustedPosition(float paramFloat, float[] paramArrayOffloat) {
    float f1;
    float f3 = 0.0F;
    float f4 = 1.0F;
    if (paramArrayOffloat != null) {
      paramArrayOffloat[0] = 1.0F;
      f1 = paramFloat;
    } else {
      float f = this.mStaggerScale;
      f1 = paramFloat;
      if (f != 1.0D) {
        float f6 = this.mStaggerOffset;
        float f5 = paramFloat;
        if (paramFloat < f6)
          f5 = 0.0F; 
        f1 = f5;
        if (f5 > f6) {
          f1 = f5;
          if (f5 < 1.0D)
            f1 = Math.min((f5 - f6) * f, 1.0F); 
        } 
      } 
    } 
    Easing easing = this.mStartMotionPath.mKeyFrameEasing;
    paramFloat = Float.NaN;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    float f2 = f3;
    while (iterator.hasNext()) {
      MotionPaths motionPaths = iterator.next();
      if (motionPaths.mKeyFrameEasing != null) {
        if (motionPaths.time < f1) {
          easing = motionPaths.mKeyFrameEasing;
          f2 = motionPaths.time;
          continue;
        } 
        if (Float.isNaN(paramFloat))
          paramFloat = motionPaths.time; 
      } 
    } 
    f3 = f1;
    if (easing != null) {
      if (Float.isNaN(paramFloat))
        paramFloat = f4; 
      paramFloat -= f2;
      double d = ((f1 - f2) / paramFloat);
      paramFloat = (float)easing.get(d) * paramFloat + f2;
      f3 = paramFloat;
      if (paramArrayOffloat != null) {
        paramArrayOffloat[0] = (float)easing.getDiff(d);
        f3 = paramFloat;
      } 
    } 
    return f3;
  }
  
  private static DifferentialInterpolator getInterpolator(int paramInt1, String paramString, int paramInt2) {
    return (paramInt1 != -1) ? null : new DifferentialInterpolator(Easing.getInterpolator(paramString)) {
        float mX;
        
        public float getInterpolation(float param1Float) {
          this.mX = param1Float;
          return (float)easing.get(param1Float);
        }
        
        public float getVelocity() {
          return (float)easing.getDiff(this.mX);
        }
      };
  }
  
  private float getPreCycleDistance() {
    float[] arrayOfFloat = new float[2];
    float f2 = 1.0F / 99;
    double d1 = 0.0D;
    double d2 = d1;
    float f1 = 0.0F;
    int i;
    for (i = 0; i < 100; i++) {
      float f5 = i * f2;
      double d = f5;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      float f3 = Float.NaN;
      float f4;
      for (f4 = 0.0F; iterator.hasNext(); f4 = f7) {
        MotionPaths motionPaths = iterator.next();
        Easing easing1 = easing;
        float f6 = f3;
        float f7 = f4;
        if (motionPaths.mKeyFrameEasing != null)
          if (motionPaths.time < f5) {
            easing1 = motionPaths.mKeyFrameEasing;
            f7 = motionPaths.time;
            f6 = f3;
          } else {
            easing1 = easing;
            f6 = f3;
            f7 = f4;
            if (Float.isNaN(f3)) {
              f6 = motionPaths.time;
              f7 = f4;
              easing1 = easing;
            } 
          }  
        easing = easing1;
        f3 = f6;
      } 
      if (easing != null) {
        float f = f3;
        if (Float.isNaN(f3))
          f = 1.0F; 
        f3 = f - f4;
        d = ((float)easing.get(((f5 - f4) / f3)) * f3 + f4);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      if (i > 0) {
        d = f1;
        double d3 = arrayOfFloat[1];
        Double.isNaN(d3);
        double d4 = arrayOfFloat[0];
        Double.isNaN(d4);
        d1 = Math.hypot(d2 - d3, d1 - d4);
        Double.isNaN(d);
        f1 = (float)(d + d1);
      } 
      d1 = arrayOfFloat[0];
      d2 = arrayOfFloat[1];
    } 
    return f1;
  }
  
  private void insertKey(MotionPaths paramMotionPaths) {
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    MotionPaths motionPaths = null;
    while (iterator.hasNext()) {
      MotionPaths motionPaths1 = iterator.next();
      if (paramMotionPaths.position == motionPaths1.position)
        motionPaths = motionPaths1; 
    } 
    if (motionPaths != null)
      this.mMotionPaths.remove(motionPaths); 
    int i = Collections.binarySearch((List)this.mMotionPaths, paramMotionPaths);
    if (i == 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" KeyPath position \"");
      stringBuilder.append(paramMotionPaths.position);
      stringBuilder.append("\" outside of range");
      Utils.loge("MotionController", stringBuilder.toString());
    } 
    this.mMotionPaths.add(-i - 1, paramMotionPaths);
  }
  
  private void readView(MotionPaths paramMotionPaths) {
    paramMotionPaths.setBounds(this.mView.getX(), this.mView.getY(), this.mView.getWidth(), this.mView.getHeight());
  }
  
  public void addKey(MotionKey paramMotionKey) {
    this.mKeyList.add(paramMotionKey);
  }
  
  void addKeys(ArrayList<MotionKey> paramArrayList) {
    this.mKeyList.addAll(paramArrayList);
  }
  
  void buildBounds(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = hashMap1.get("translationX"); 
    hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = hashMap1.get("translationY"); 
    HashMap<String, KeyCycleOscillator> hashMap = this.mCycleMap;
    if (hashMap != null)
      KeyCycleOscillator keyCycleOscillator = hashMap.get("translationX"); 
    hashMap = this.mCycleMap;
    if (hashMap != null)
      KeyCycleOscillator keyCycleOscillator = hashMap.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f5 = this.mStaggerScale;
      float f4 = 0.0F;
      float f1 = f3;
      if (f5 != 1.0F) {
        float f7 = this.mStaggerOffset;
        float f6 = f3;
        if (f3 < f7)
          f6 = 0.0F; 
        f1 = f6;
        if (f6 > f7) {
          f1 = f6;
          if (f6 < 1.0D)
            f1 = Math.min((f6 - f7) * f5, 1.0F); 
        } 
      } 
      double d = f1;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      float f2 = Float.NaN;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      f3 = f4;
      while (iterator.hasNext()) {
        MotionPaths motionPaths = iterator.next();
        if (motionPaths.mKeyFrameEasing != null) {
          if (motionPaths.time < f1) {
            easing = motionPaths.mKeyFrameEasing;
            f3 = motionPaths.time;
            continue;
          } 
          if (Float.isNaN(f2))
            f2 = motionPaths.time; 
        } 
      } 
      if (easing != null) {
        f4 = f2;
        if (Float.isNaN(f2))
          f4 = 1.0F; 
        f2 = f4 - f3;
        d = ((float)easing.get(((f1 - f3) / f2)) * f2 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble = this.mInterpolateData;
        if (arrayOfDouble.length > 0)
          curveFit.getPos(d, arrayOfDouble); 
      } 
      this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 2);
    } 
  }
  
  int buildKeyBounds(float[] paramArrayOffloat, int[] paramArrayOfint) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        for (int k = 0; iterator.hasNext(); k++)
          paramArrayOfint[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  public int buildKeyFrames(float[] paramArrayOffloat, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint1 != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        int k;
        for (k = 0; iterator.hasNext(); k++)
          paramArrayOfint1[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      if (paramArrayOfint2 != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        int k;
        for (k = 0; iterator.hasNext(); k++)
          paramArrayOfint2[k] = (int)(((MotionPaths)iterator.next()).position * 100.0F); 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getCenter(arrayOfDouble[i], this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  public void buildPath(float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet1;
    SplineSet splineSet2;
    KeyCycleOscillator keyCycleOscillator1;
    float f = 1.0F / (paramInt - 1);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    KeyCycleOscillator keyCycleOscillator2 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = hashMap1.get("translationX");
    } 
    HashMap<String, SplineSet> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = hashMap2.get("translationY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap3 = this.mCycleMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      keyCycleOscillator1 = hashMap3.get("translationX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap4 = this.mCycleMap;
    if (hashMap4 != null)
      keyCycleOscillator2 = hashMap4.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f4 = this.mStaggerScale;
      float f1 = f3;
      if (f4 != 1.0F) {
        float f6 = this.mStaggerOffset;
        float f5 = f3;
        if (f3 < f6)
          f5 = 0.0F; 
        f1 = f5;
        if (f5 > f6) {
          f1 = f5;
          if (f5 < 1.0D)
            f1 = Math.min((f5 - f6) * f4, 1.0F); 
        } 
      } 
      double d = f1;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      float f2 = Float.NaN;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      for (f3 = 0.0F; iterator.hasNext(); f3 = f5) {
        MotionPaths motionPaths1 = iterator.next();
        Easing easing1 = easing;
        f4 = f2;
        float f5 = f3;
        if (motionPaths1.mKeyFrameEasing != null)
          if (motionPaths1.time < f1) {
            easing1 = motionPaths1.mKeyFrameEasing;
            f5 = motionPaths1.time;
            f4 = f2;
          } else {
            easing1 = easing;
            f4 = f2;
            f5 = f3;
            if (Float.isNaN(f2)) {
              f4 = motionPaths1.time;
              f5 = f3;
              easing1 = easing;
            } 
          }  
        easing = easing1;
        f2 = f4;
      } 
      if (easing != null) {
        f4 = f2;
        if (Float.isNaN(f2))
          f4 = 1.0F; 
        f2 = f4 - f3;
        d = ((float)easing.get(((f1 - f3) / f2)) * f2 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble1 = this.mInterpolateData;
        if (arrayOfDouble1.length > 0)
          curveFit.getPos(d, arrayOfDouble1); 
      } 
      MotionPaths motionPaths = this.mStartMotionPath;
      int[] arrayOfInt = this.mInterpolateVariables;
      double[] arrayOfDouble = this.mInterpolateData;
      int j = i * 2;
      motionPaths.getCenter(d, arrayOfInt, arrayOfDouble, paramArrayOffloat, j);
      if (keyCycleOscillator1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + keyCycleOscillator1.get(f1);
      } else if (splineSet1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + splineSet1.get(f1);
      } 
      if (keyCycleOscillator2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + keyCycleOscillator2.get(f1);
      } else if (splineSet2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + splineSet2.get(f1);
      } 
    } 
  }
  
  public void buildRect(float paramFloat, float[] paramArrayOffloat, int paramInt) {
    paramFloat = getAdjustedPosition(paramFloat, null);
    this.mSpline[0].getPos(paramFloat, this.mInterpolateData);
    this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, paramInt);
  }
  
  void buildRectangles(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    int i;
    for (i = 0; i < paramInt; i++) {
      float f1 = getAdjustedPosition(i * f, null);
      this.mSpline[0].getPos(f1, this.mInterpolateData);
      this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 8);
    } 
  }
  
  void endTrigger(boolean paramBoolean) {}
  
  public int getAnimateRelativeTo() {
    return this.mStartMotionPath.mAnimateRelativeTo;
  }
  
  int getAttributeValues(String paramString, float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet = this.mAttributesMap.get(paramString);
    if (splineSet == null)
      return -1; 
    for (paramInt = 0; paramInt < paramArrayOffloat.length; paramInt++)
      paramArrayOffloat[paramInt] = splineSet.get((paramInt / (paramArrayOffloat.length - 1))); 
    return paramArrayOffloat.length;
  }
  
  public void getCenter(double paramDouble, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    this.mSpline[0].getPos(paramDouble, arrayOfDouble1);
    this.mSpline[0].getSlope(paramDouble, arrayOfDouble2);
    Arrays.fill(paramArrayOffloat2, 0.0F);
    this.mStartMotionPath.getCenter(paramDouble, this.mInterpolateVariables, arrayOfDouble1, paramArrayOffloat1, arrayOfDouble2, paramArrayOffloat2);
  }
  
  public float getCenterX() {
    return this.mCurrentCenterX;
  }
  
  public float getCenterY() {
    return this.mCurrentCenterY;
  }
  
  void getDpDt(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      CurveFit curveFit = arrayOfCurveFit[0];
      double d = paramFloat1;
      curveFit.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        double[] arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          double d1 = arrayOfDouble[i];
          double d2 = paramFloat1;
          Double.isNaN(d2);
          arrayOfDouble[i] = d1 * d2;
          i++;
          continue;
        } 
        curveFit = this.mArcSpline;
        if (curveFit != null) {
          arrayOfDouble = this.mInterpolateData;
          if (arrayOfDouble.length > 0) {
            curveFit.getPos(d, arrayOfDouble);
            this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
            this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
          } 
          return;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        return;
      } 
    } 
    paramFloat1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f1 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f2 = this.mEndMotionPath.width;
    float f3 = this.mStartMotionPath.width;
    float f4 = this.mEndMotionPath.height;
    float f5 = this.mStartMotionPath.height;
    paramArrayOffloat[0] = paramFloat1 * (1.0F - paramFloat2) + (f2 - f3 + paramFloat1) * paramFloat2;
    paramArrayOffloat[1] = f1 * (1.0F - paramFloat3) + (f4 - f5 + f1) * paramFloat3;
  }
  
  public int getDrawPath() {
    int i = this.mStartMotionPath.mDrawPath;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    while (iterator.hasNext())
      i = Math.max(i, ((MotionPaths)iterator.next()).mDrawPath); 
    return Math.max(i, this.mEndMotionPath.mDrawPath);
  }
  
  public float getFinalHeight() {
    return this.mEndMotionPath.height;
  }
  
  public float getFinalWidth() {
    return this.mEndMotionPath.width;
  }
  
  public float getFinalX() {
    return this.mEndMotionPath.x;
  }
  
  public float getFinalY() {
    return this.mEndMotionPath.y;
  }
  
  public int getId(String paramString) {
    return 0;
  }
  
  public MotionPaths getKeyFrame(int paramInt) {
    return this.mMotionPaths.get(paramInt);
  }
  
  public int getKeyFrameInfo(int paramInt, int[] paramArrayOfint) {
    float[] arrayOfFloat = new float[2];
    Iterator<MotionKey> iterator = this.mKeyList.iterator();
    int i = 0;
    int j;
    for (j = 0; iterator.hasNext(); j = k) {
      MotionKey motionKey = iterator.next();
      if (motionKey.mType != paramInt && paramInt == -1)
        continue; 
      paramArrayOfint[j] = 0;
      int k = j + 1;
      paramArrayOfint[k] = motionKey.mType;
      paramArrayOfint[++k] = motionKey.mFramePosition;
      float f = motionKey.mFramePosition / 100.0F;
      CurveFit curveFit = this.mSpline[0];
      double d = f;
      curveFit.getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      paramArrayOfint[++k] = Float.floatToIntBits(arrayOfFloat[0]);
      int m = k + 1;
      paramArrayOfint[m] = Float.floatToIntBits(arrayOfFloat[1]);
      k = m;
      if (motionKey instanceof MotionKeyPosition) {
        MotionKeyPosition motionKeyPosition = (MotionKeyPosition)motionKey;
        k = m + 1;
        paramArrayOfint[k] = motionKeyPosition.mPositionType;
        paramArrayOfint[++k] = Float.floatToIntBits(motionKeyPosition.mPercentX);
        paramArrayOfint[++k] = Float.floatToIntBits(motionKeyPosition.mPercentY);
      } 
      paramArrayOfint[j] = ++k - j;
      i++;
    } 
    return i;
  }
  
  float getKeyFrameParameter(int paramInt, float paramFloat1, float paramFloat2) {
    float f1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f2 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f6 = this.mStartMotionPath.x;
    float f7 = this.mStartMotionPath.width / 2.0F;
    float f4 = this.mStartMotionPath.y;
    float f5 = this.mStartMotionPath.height / 2.0F;
    float f3 = (float)Math.hypot(f1, f2);
    if (f3 < 1.0E-7D)
      return Float.NaN; 
    paramFloat1 -= f6 + f7;
    paramFloat2 -= f4 + f5;
    if ((float)Math.hypot(paramFloat1, paramFloat2) == 0.0F)
      return 0.0F; 
    f4 = paramFloat1 * f1 + paramFloat2 * f2;
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? 0.0F : (paramFloat2 / f2)) : (paramFloat1 / f2)) : (paramFloat2 / f1)) : (paramFloat1 / f1)) : (float)Math.sqrt((f3 * f3 - f4 * f4))) : (f4 / f3);
  }
  
  public int getKeyFramePositions(int[] paramArrayOfint, float[] paramArrayOffloat) {
    Iterator<MotionKey> iterator = this.mKeyList.iterator();
    int i = 0;
    int j = 0;
    while (iterator.hasNext()) {
      MotionKey motionKey = iterator.next();
      paramArrayOfint[i] = motionKey.mFramePosition + motionKey.mType * 1000;
      float f = motionKey.mFramePosition / 100.0F;
      CurveFit curveFit = this.mSpline[0];
      double d = f;
      curveFit.getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
      j += 2;
      i++;
    } 
    return i;
  }
  
  double[] getPos(double paramDouble) {
    this.mSpline[0].getPos(paramDouble, this.mInterpolateData);
    CurveFit curveFit = this.mArcSpline;
    if (curveFit != null) {
      double[] arrayOfDouble = this.mInterpolateData;
      if (arrayOfDouble.length > 0)
        curveFit.getPos(paramDouble, arrayOfDouble); 
    } 
    return this.mInterpolateData;
  }
  
  MotionKeyPosition getPositionKeyframe(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    FloatRect floatRect1 = new FloatRect();
    floatRect1.left = this.mStartMotionPath.x;
    floatRect1.top = this.mStartMotionPath.y;
    floatRect1.right = floatRect1.left + this.mStartMotionPath.width;
    floatRect1.bottom = floatRect1.top + this.mStartMotionPath.height;
    FloatRect floatRect2 = new FloatRect();
    floatRect2.left = this.mEndMotionPath.x;
    floatRect2.top = this.mEndMotionPath.y;
    floatRect2.right = floatRect2.left + this.mEndMotionPath.width;
    floatRect2.bottom = floatRect2.top + this.mEndMotionPath.height;
    for (MotionKey motionKey : this.mKeyList) {
      if (motionKey instanceof MotionKeyPosition) {
        MotionKeyPosition motionKeyPosition = (MotionKeyPosition)motionKey;
        if (motionKeyPosition.intersects(paramInt1, paramInt2, floatRect1, floatRect2, paramFloat1, paramFloat2))
          return motionKeyPosition; 
      } 
    } 
    return null;
  }
  
  void getPostLayoutDvDp(float paramFloat1, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    SplineSet splineSet1;
    double[] arrayOfDouble;
    SplineSet splineSet2;
    SplineSet splineSet3;
    SplineSet splineSet4;
    SplineSet splineSet5;
    KeyCycleOscillator keyCycleOscillator1;
    KeyCycleOscillator keyCycleOscillator2;
    KeyCycleOscillator keyCycleOscillator3;
    KeyCycleOscillator keyCycleOscillator4;
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    HashMap<String, SplineSet> hashMap1 = this.mAttributesMap;
    KeyCycleOscillator keyCycleOscillator5 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = hashMap1.get("translationX");
    } 
    HashMap<String, SplineSet> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = hashMap2.get("translationY");
    } 
    HashMap<String, SplineSet> hashMap3 = this.mAttributesMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      splineSet3 = hashMap3.get("rotationZ");
    } 
    HashMap<String, SplineSet> hashMap4 = this.mAttributesMap;
    if (hashMap4 == null) {
      hashMap4 = null;
    } else {
      splineSet4 = hashMap4.get("scaleX");
    } 
    HashMap<String, SplineSet> hashMap5 = this.mAttributesMap;
    if (hashMap5 == null) {
      hashMap5 = null;
    } else {
      splineSet5 = hashMap5.get("scaleY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap6 = this.mCycleMap;
    if (hashMap6 == null) {
      hashMap6 = null;
    } else {
      keyCycleOscillator1 = hashMap6.get("translationX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap7 = this.mCycleMap;
    if (hashMap7 == null) {
      hashMap7 = null;
    } else {
      keyCycleOscillator2 = hashMap7.get("translationY");
    } 
    HashMap<String, KeyCycleOscillator> hashMap8 = this.mCycleMap;
    if (hashMap8 == null) {
      hashMap8 = null;
    } else {
      keyCycleOscillator3 = hashMap8.get("rotationZ");
    } 
    HashMap<String, KeyCycleOscillator> hashMap9 = this.mCycleMap;
    if (hashMap9 == null) {
      hashMap9 = null;
    } else {
      keyCycleOscillator4 = hashMap9.get("scaleX");
    } 
    HashMap<String, KeyCycleOscillator> hashMap10 = this.mCycleMap;
    if (hashMap10 != null)
      keyCycleOscillator5 = hashMap10.get("scaleY"); 
    VelocityMatrix velocityMatrix = new VelocityMatrix();
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity(splineSet1, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity(keyCycleOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity(keyCycleOscillator1, keyCycleOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity(keyCycleOscillator4, keyCycleOscillator5, paramFloat1);
    CurveFit curveFit = this.mArcSpline;
    if (curveFit != null) {
      arrayOfDouble = this.mInterpolateData;
      if (arrayOfDouble.length > 0) {
        double d = paramFloat1;
        curveFit.getPos(d, arrayOfDouble);
        this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
      } 
      velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
      return;
    } 
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
      CurveFit curveFit1 = this.mSpline[0];
      double d = paramFloat1;
      curveFit1.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          d = arrayOfDouble[i];
          double d1 = paramFloat1;
          Double.isNaN(d1);
          arrayOfDouble[i] = d * d1;
          i++;
          continue;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
        return;
      } 
    } 
    float f1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f2 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f3 = this.mEndMotionPath.width;
    float f4 = this.mStartMotionPath.width;
    float f5 = this.mEndMotionPath.height;
    float f6 = this.mStartMotionPath.height;
    paramArrayOffloat[0] = f1 * (1.0F - paramFloat2) + (f3 - f4 + f1) * paramFloat2;
    paramArrayOffloat[1] = f2 * (1.0F - paramFloat3) + (f5 - f6 + f2) * paramFloat3;
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity((SplineSet)arrayOfDouble, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity(keyCycleOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity(keyCycleOscillator1, keyCycleOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity(keyCycleOscillator4, keyCycleOscillator5, paramFloat1);
    velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
  }
  
  public float getStartHeight() {
    return this.mStartMotionPath.height;
  }
  
  public float getStartWidth() {
    return this.mStartMotionPath.width;
  }
  
  public float getStartX() {
    return this.mStartMotionPath.x;
  }
  
  public float getStartY() {
    return this.mStartMotionPath.y;
  }
  
  public int getTransformPivotTarget() {
    return this.mTransformPivotTarget;
  }
  
  public MotionWidget getView() {
    return this.mView;
  }
  
  public boolean interpolate(MotionWidget paramMotionWidget, float paramFloat, long paramLong, KeyCache paramKeyCache) {
    // Byte code:
    //   0: aload_0
    //   1: fload_2
    //   2: aconst_null
    //   3: invokespecial getAdjustedPosition : (F[F)F
    //   6: fstore #8
    //   8: aload_0
    //   9: getfield mQuantizeMotionSteps : I
    //   12: istore #20
    //   14: fload #8
    //   16: fstore_2
    //   17: iload #20
    //   19: iconst_m1
    //   20: if_icmpeq -> 125
    //   23: fconst_1
    //   24: iload #20
    //   26: i2f
    //   27: fdiv
    //   28: fstore #9
    //   30: fload #8
    //   32: fload #9
    //   34: fdiv
    //   35: f2d
    //   36: invokestatic floor : (D)D
    //   39: d2f
    //   40: fstore #10
    //   42: fload #8
    //   44: fload #9
    //   46: frem
    //   47: fload #9
    //   49: fdiv
    //   50: fstore #8
    //   52: fload #8
    //   54: fstore_2
    //   55: aload_0
    //   56: getfield mQuantizeMotionPhase : F
    //   59: invokestatic isNaN : (F)Z
    //   62: ifne -> 75
    //   65: fload #8
    //   67: aload_0
    //   68: getfield mQuantizeMotionPhase : F
    //   71: fadd
    //   72: fconst_1
    //   73: frem
    //   74: fstore_2
    //   75: aload_0
    //   76: getfield mQuantizeMotionInterpolator : Landroidx/constraintlayout/core/motion/utils/DifferentialInterpolator;
    //   79: astore #5
    //   81: aload #5
    //   83: ifnull -> 98
    //   86: aload #5
    //   88: fload_2
    //   89: invokeinterface getInterpolation : (F)F
    //   94: fstore_2
    //   95: goto -> 114
    //   98: fload_2
    //   99: f2d
    //   100: ldc2_w 0.5
    //   103: dcmpl
    //   104: ifle -> 112
    //   107: fconst_1
    //   108: fstore_2
    //   109: goto -> 114
    //   112: fconst_0
    //   113: fstore_2
    //   114: fload_2
    //   115: fload #9
    //   117: fmul
    //   118: fload #10
    //   120: fload #9
    //   122: fmul
    //   123: fadd
    //   124: fstore_2
    //   125: aload_0
    //   126: getfield mAttributesMap : Ljava/util/HashMap;
    //   129: astore #5
    //   131: aload #5
    //   133: ifnull -> 176
    //   136: aload #5
    //   138: invokevirtual values : ()Ljava/util/Collection;
    //   141: invokeinterface iterator : ()Ljava/util/Iterator;
    //   146: astore #5
    //   148: aload #5
    //   150: invokeinterface hasNext : ()Z
    //   155: ifeq -> 176
    //   158: aload #5
    //   160: invokeinterface next : ()Ljava/lang/Object;
    //   165: checkcast androidx/constraintlayout/core/motion/utils/SplineSet
    //   168: aload_1
    //   169: fload_2
    //   170: invokevirtual setProperty : (Landroidx/constraintlayout/core/motion/utils/TypedValues;F)V
    //   173: goto -> 148
    //   176: aload_0
    //   177: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   180: astore #5
    //   182: aload #5
    //   184: ifnull -> 620
    //   187: aload #5
    //   189: iconst_0
    //   190: aaload
    //   191: astore #5
    //   193: fload_2
    //   194: f2d
    //   195: dstore #6
    //   197: aload #5
    //   199: dload #6
    //   201: aload_0
    //   202: getfield mInterpolateData : [D
    //   205: invokevirtual getPos : (D[D)V
    //   208: aload_0
    //   209: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   212: iconst_0
    //   213: aaload
    //   214: dload #6
    //   216: aload_0
    //   217: getfield mInterpolateVelocity : [D
    //   220: invokevirtual getSlope : (D[D)V
    //   223: aload_0
    //   224: getfield mArcSpline : Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   227: astore #5
    //   229: aload #5
    //   231: ifnull -> 268
    //   234: aload_0
    //   235: getfield mInterpolateData : [D
    //   238: astore #21
    //   240: aload #21
    //   242: arraylength
    //   243: ifle -> 268
    //   246: aload #5
    //   248: dload #6
    //   250: aload #21
    //   252: invokevirtual getPos : (D[D)V
    //   255: aload_0
    //   256: getfield mArcSpline : Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   259: dload #6
    //   261: aload_0
    //   262: getfield mInterpolateVelocity : [D
    //   265: invokevirtual getSlope : (D[D)V
    //   268: aload_0
    //   269: getfield mNoMovement : Z
    //   272: ifne -> 300
    //   275: aload_0
    //   276: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   279: fload_2
    //   280: aload_1
    //   281: aload_0
    //   282: getfield mInterpolateVariables : [I
    //   285: aload_0
    //   286: getfield mInterpolateData : [D
    //   289: aload_0
    //   290: getfield mInterpolateVelocity : [D
    //   293: aconst_null
    //   294: invokevirtual setView : (FLandroidx/constraintlayout/core/motion/MotionWidget;[I[D[D[D)V
    //   297: goto -> 300
    //   300: aload_0
    //   301: getfield mTransformPivotTarget : I
    //   304: iconst_m1
    //   305: if_icmpeq -> 435
    //   308: aload_0
    //   309: getfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   312: ifnonnull -> 330
    //   315: aload_0
    //   316: aload_1
    //   317: invokevirtual getParent : ()Landroidx/constraintlayout/core/motion/MotionWidget;
    //   320: aload_0
    //   321: getfield mTransformPivotTarget : I
    //   324: invokevirtual findViewById : (I)Landroidx/constraintlayout/core/motion/MotionWidget;
    //   327: putfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   330: aload_0
    //   331: getfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   334: astore #5
    //   336: aload #5
    //   338: ifnull -> 435
    //   341: aload #5
    //   343: invokevirtual getTop : ()I
    //   346: aload_0
    //   347: getfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   350: invokevirtual getBottom : ()I
    //   353: iadd
    //   354: i2f
    //   355: fconst_2
    //   356: fdiv
    //   357: fstore #8
    //   359: aload_0
    //   360: getfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   363: invokevirtual getLeft : ()I
    //   366: aload_0
    //   367: getfield mTransformPivotView : Landroidx/constraintlayout/core/motion/MotionWidget;
    //   370: invokevirtual getRight : ()I
    //   373: iadd
    //   374: i2f
    //   375: fconst_2
    //   376: fdiv
    //   377: fstore #9
    //   379: aload_1
    //   380: invokevirtual getRight : ()I
    //   383: aload_1
    //   384: invokevirtual getLeft : ()I
    //   387: isub
    //   388: ifle -> 435
    //   391: aload_1
    //   392: invokevirtual getBottom : ()I
    //   395: aload_1
    //   396: invokevirtual getTop : ()I
    //   399: isub
    //   400: ifle -> 435
    //   403: aload_1
    //   404: invokevirtual getLeft : ()I
    //   407: i2f
    //   408: fstore #10
    //   410: aload_1
    //   411: invokevirtual getTop : ()I
    //   414: i2f
    //   415: fstore #11
    //   417: aload_1
    //   418: fload #9
    //   420: fload #10
    //   422: fsub
    //   423: invokevirtual setPivotX : (F)V
    //   426: aload_1
    //   427: fload #8
    //   429: fload #11
    //   431: fsub
    //   432: invokevirtual setPivotY : (F)V
    //   435: iconst_1
    //   436: istore #20
    //   438: aload_0
    //   439: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   442: astore #5
    //   444: iload #20
    //   446: aload #5
    //   448: arraylength
    //   449: if_icmpge -> 505
    //   452: aload #5
    //   454: iload #20
    //   456: aaload
    //   457: dload #6
    //   459: aload_0
    //   460: getfield mValuesBuff : [F
    //   463: invokevirtual getPos : (D[F)V
    //   466: aload_0
    //   467: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   470: getfield customAttributes : Ljava/util/HashMap;
    //   473: aload_0
    //   474: getfield mAttributeNames : [Ljava/lang/String;
    //   477: iload #20
    //   479: iconst_1
    //   480: isub
    //   481: aaload
    //   482: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   485: checkcast androidx/constraintlayout/core/motion/CustomVariable
    //   488: aload_1
    //   489: aload_0
    //   490: getfield mValuesBuff : [F
    //   493: invokevirtual setInterpolatedValue : (Landroidx/constraintlayout/core/motion/MotionWidget;[F)V
    //   496: iload #20
    //   498: iconst_1
    //   499: iadd
    //   500: istore #20
    //   502: goto -> 438
    //   505: aload_0
    //   506: getfield mStartPoint : Landroidx/constraintlayout/core/motion/MotionConstrainedPoint;
    //   509: getfield mVisibilityMode : I
    //   512: ifne -> 577
    //   515: fload_2
    //   516: fconst_0
    //   517: fcmpg
    //   518: ifgt -> 535
    //   521: aload_1
    //   522: aload_0
    //   523: getfield mStartPoint : Landroidx/constraintlayout/core/motion/MotionConstrainedPoint;
    //   526: getfield visibility : I
    //   529: invokevirtual setVisibility : (I)V
    //   532: goto -> 577
    //   535: fload_2
    //   536: fconst_1
    //   537: fcmpl
    //   538: iflt -> 555
    //   541: aload_1
    //   542: aload_0
    //   543: getfield mEndPoint : Landroidx/constraintlayout/core/motion/MotionConstrainedPoint;
    //   546: getfield visibility : I
    //   549: invokevirtual setVisibility : (I)V
    //   552: goto -> 577
    //   555: aload_0
    //   556: getfield mEndPoint : Landroidx/constraintlayout/core/motion/MotionConstrainedPoint;
    //   559: getfield visibility : I
    //   562: aload_0
    //   563: getfield mStartPoint : Landroidx/constraintlayout/core/motion/MotionConstrainedPoint;
    //   566: getfield visibility : I
    //   569: if_icmpeq -> 577
    //   572: aload_1
    //   573: iconst_4
    //   574: invokevirtual setVisibility : (I)V
    //   577: aload_0
    //   578: getfield mKeyTriggers : [Landroidx/constraintlayout/core/motion/key/MotionKeyTrigger;
    //   581: ifnull -> 802
    //   584: iconst_0
    //   585: istore #20
    //   587: aload_0
    //   588: getfield mKeyTriggers : [Landroidx/constraintlayout/core/motion/key/MotionKeyTrigger;
    //   591: astore #5
    //   593: iload #20
    //   595: aload #5
    //   597: arraylength
    //   598: if_icmpge -> 802
    //   601: aload #5
    //   603: iload #20
    //   605: aaload
    //   606: fload_2
    //   607: aload_1
    //   608: invokevirtual conditionallyFire : (FLandroidx/constraintlayout/core/motion/MotionWidget;)V
    //   611: iload #20
    //   613: iconst_1
    //   614: iadd
    //   615: istore #20
    //   617: goto -> 587
    //   620: aload_0
    //   621: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   624: getfield x : F
    //   627: fstore #17
    //   629: aload_0
    //   630: getfield mEndMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   633: getfield x : F
    //   636: fstore #18
    //   638: aload_0
    //   639: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   642: getfield x : F
    //   645: fstore #19
    //   647: aload_0
    //   648: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   651: getfield y : F
    //   654: fstore #14
    //   656: aload_0
    //   657: getfield mEndMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   660: getfield y : F
    //   663: fstore #15
    //   665: aload_0
    //   666: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   669: getfield y : F
    //   672: fstore #16
    //   674: aload_0
    //   675: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   678: getfield width : F
    //   681: fstore #8
    //   683: aload_0
    //   684: getfield mEndMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   687: getfield width : F
    //   690: fstore #9
    //   692: aload_0
    //   693: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   696: getfield width : F
    //   699: fstore #10
    //   701: aload_0
    //   702: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   705: getfield height : F
    //   708: fstore #11
    //   710: aload_0
    //   711: getfield mEndMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   714: getfield height : F
    //   717: fstore #12
    //   719: aload_0
    //   720: getfield mStartMotionPath : Landroidx/constraintlayout/core/motion/MotionPaths;
    //   723: getfield height : F
    //   726: fstore #13
    //   728: fload #17
    //   730: fload #18
    //   732: fload #19
    //   734: fsub
    //   735: fload_2
    //   736: fmul
    //   737: fadd
    //   738: ldc_w 0.5
    //   741: fadd
    //   742: fstore #17
    //   744: fload #17
    //   746: f2i
    //   747: istore #20
    //   749: fload #14
    //   751: fload #15
    //   753: fload #16
    //   755: fsub
    //   756: fload_2
    //   757: fmul
    //   758: fadd
    //   759: ldc_w 0.5
    //   762: fadd
    //   763: fstore #14
    //   765: aload_1
    //   766: iload #20
    //   768: fload #14
    //   770: f2i
    //   771: fload #17
    //   773: fload #8
    //   775: fload #9
    //   777: fload #10
    //   779: fsub
    //   780: fload_2
    //   781: fmul
    //   782: fadd
    //   783: fadd
    //   784: f2i
    //   785: fload #14
    //   787: fload #11
    //   789: fload #12
    //   791: fload #13
    //   793: fsub
    //   794: fload_2
    //   795: fmul
    //   796: fadd
    //   797: fadd
    //   798: f2i
    //   799: invokevirtual layout : (IIII)V
    //   802: aload_0
    //   803: getfield mCycleMap : Ljava/util/HashMap;
    //   806: astore #5
    //   808: aload #5
    //   810: ifnull -> 896
    //   813: aload #5
    //   815: invokevirtual values : ()Ljava/util/Collection;
    //   818: invokeinterface iterator : ()Ljava/util/Iterator;
    //   823: astore #5
    //   825: aload #5
    //   827: invokeinterface hasNext : ()Z
    //   832: ifeq -> 896
    //   835: aload #5
    //   837: invokeinterface next : ()Ljava/lang/Object;
    //   842: checkcast androidx/constraintlayout/core/motion/utils/KeyCycleOscillator
    //   845: astore #21
    //   847: aload #21
    //   849: instanceof androidx/constraintlayout/core/motion/utils/KeyCycleOscillator$PathRotateSet
    //   852: ifeq -> 886
    //   855: aload #21
    //   857: checkcast androidx/constraintlayout/core/motion/utils/KeyCycleOscillator$PathRotateSet
    //   860: astore #21
    //   862: aload_0
    //   863: getfield mInterpolateVelocity : [D
    //   866: astore #22
    //   868: aload #21
    //   870: aload_1
    //   871: fload_2
    //   872: aload #22
    //   874: iconst_0
    //   875: daload
    //   876: aload #22
    //   878: iconst_1
    //   879: daload
    //   880: invokevirtual setPathRotate : (Landroidx/constraintlayout/core/motion/MotionWidget;FDD)V
    //   883: goto -> 825
    //   886: aload #21
    //   888: aload_1
    //   889: fload_2
    //   890: invokevirtual setProperty : (Landroidx/constraintlayout/core/motion/MotionWidget;F)V
    //   893: goto -> 825
    //   896: iconst_0
    //   897: ireturn
  }
  
  String name() {
    return this.mView.getName();
  }
  
  void positionKeyframe(MotionWidget paramMotionWidget, MotionKeyPosition paramMotionKeyPosition, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    FloatRect floatRect1 = new FloatRect();
    floatRect1.left = this.mStartMotionPath.x;
    floatRect1.top = this.mStartMotionPath.y;
    floatRect1.right = floatRect1.left + this.mStartMotionPath.width;
    floatRect1.bottom = floatRect1.top + this.mStartMotionPath.height;
    FloatRect floatRect2 = new FloatRect();
    floatRect2.left = this.mEndMotionPath.x;
    floatRect2.top = this.mEndMotionPath.y;
    floatRect2.right = floatRect2.left + this.mEndMotionPath.width;
    floatRect2.bottom = floatRect2.top + this.mEndMotionPath.height;
    paramMotionKeyPosition.positionAttributes(paramMotionWidget, floatRect1, floatRect2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
  }
  
  void rotate(Rect paramRect1, Rect paramRect2, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          if (paramInt1 != 4)
            return; 
          paramInt1 = paramRect1.left;
          paramInt3 = paramRect1.right;
          paramRect2.left = paramInt2 - (paramRect1.bottom + paramRect1.top + paramRect1.width()) / 2;
          paramRect2.top = (paramInt1 + paramInt3 - paramRect1.height()) / 2;
          paramRect2.right = paramRect2.left + paramRect1.width();
          paramRect2.bottom = paramRect2.top + paramRect1.height();
          return;
        } 
        paramInt1 = paramRect1.left + paramRect1.right;
        paramInt2 = paramRect1.top;
        paramInt2 = paramRect1.bottom;
        paramRect2.left = paramRect1.height() / 2 + paramRect1.top - paramInt1 / 2;
        paramRect2.top = paramInt3 - (paramInt1 + paramRect1.height()) / 2;
        paramRect2.right = paramRect2.left + paramRect1.width();
        paramRect2.bottom = paramRect2.top + paramRect1.height();
        return;
      } 
      paramInt1 = paramRect1.left;
      paramInt3 = paramRect1.right;
      paramRect2.left = paramInt2 - (paramRect1.top + paramRect1.bottom + paramRect1.width()) / 2;
      paramRect2.top = (paramInt1 + paramInt3 - paramRect1.height()) / 2;
      paramRect2.right = paramRect2.left + paramRect1.width();
      paramRect2.bottom = paramRect2.top + paramRect1.height();
      return;
    } 
    paramInt1 = paramRect1.left;
    paramInt2 = paramRect1.right;
    paramRect2.left = (paramRect1.top + paramRect1.bottom - paramRect1.width()) / 2;
    paramRect2.top = paramInt3 - (paramInt1 + paramInt2 + paramRect1.height()) / 2;
    paramRect2.right = paramRect2.left + paramRect1.width();
    paramRect2.bottom = paramRect2.top + paramRect1.height();
  }
  
  void setBothStates(MotionWidget paramMotionWidget) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    this.mNoMovement = true;
    this.mStartMotionPath.setBounds(paramMotionWidget.getX(), paramMotionWidget.getY(), paramMotionWidget.getWidth(), paramMotionWidget.getHeight());
    this.mEndMotionPath.setBounds(paramMotionWidget.getX(), paramMotionWidget.getY(), paramMotionWidget.getWidth(), paramMotionWidget.getHeight());
    this.mStartPoint.setState(paramMotionWidget);
    this.mEndPoint.setState(paramMotionWidget);
  }
  
  public void setDrawPath(int paramInt) {
    this.mStartMotionPath.mDrawPath = paramInt;
  }
  
  public void setEnd(MotionWidget paramMotionWidget) {
    this.mEndMotionPath.time = 1.0F;
    this.mEndMotionPath.position = 1.0F;
    readView(this.mEndMotionPath);
    this.mEndMotionPath.setBounds(paramMotionWidget.getLeft(), paramMotionWidget.getTop(), paramMotionWidget.getWidth(), paramMotionWidget.getHeight());
    this.mEndMotionPath.applyParameters(paramMotionWidget);
    this.mEndPoint.setState(paramMotionWidget);
  }
  
  public void setPathMotionArc(int paramInt) {
    this.mPathMotionArc = paramInt;
  }
  
  public void setStart(MotionWidget paramMotionWidget) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    this.mStartMotionPath.setBounds(paramMotionWidget.getX(), paramMotionWidget.getY(), paramMotionWidget.getWidth(), paramMotionWidget.getHeight());
    this.mStartMotionPath.applyParameters(paramMotionWidget);
    this.mStartPoint.setState(paramMotionWidget);
  }
  
  public void setStartState(ViewState paramViewState, MotionWidget paramMotionWidget, int paramInt1, int paramInt2, int paramInt3) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    Rect rect = new Rect();
    if (paramInt1 != 1) {
      if (paramInt1 == 2) {
        paramInt2 = paramViewState.left;
        int i = paramViewState.right;
        rect.left = paramInt3 - (paramViewState.top + paramViewState.bottom + paramViewState.width()) / 2;
        rect.top = (paramInt2 + i - paramViewState.height()) / 2;
        rect.right = rect.left + paramViewState.width();
        rect.bottom = rect.top + paramViewState.height();
      } 
    } else {
      paramInt3 = paramViewState.left;
      int i = paramViewState.right;
      rect.left = (paramViewState.top + paramViewState.bottom - paramViewState.width()) / 2;
      rect.top = paramInt2 - (paramInt3 + i + paramViewState.height()) / 2;
      rect.right = rect.left + paramViewState.width();
      rect.bottom = rect.top + paramViewState.height();
    } 
    this.mStartMotionPath.setBounds(rect.left, rect.top, rect.width(), rect.height());
    this.mStartPoint.setState(rect, paramMotionWidget, paramInt1, paramViewState.rotation);
  }
  
  public void setTransformPivotTarget(int paramInt) {
    this.mTransformPivotTarget = paramInt;
    this.mTransformPivotView = null;
  }
  
  public boolean setValue(int paramInt, float paramFloat) {
    return false;
  }
  
  public boolean setValue(int paramInt1, int paramInt2) {
    if (paramInt1 != 509)
      return !(paramInt1 != 704); 
    setPathMotionArc(paramInt2);
    return true;
  }
  
  public boolean setValue(int paramInt, String paramString) {
    if (705 == paramInt) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("TYPE_INTERPOLATOR  ");
      stringBuilder.append(paramString);
      printStream.println(stringBuilder.toString());
      this.mQuantizeMotionInterpolator = getInterpolator(-1, paramString, 0);
    } 
    return false;
  }
  
  public boolean setValue(int paramInt, boolean paramBoolean) {
    return false;
  }
  
  public void setView(MotionWidget paramMotionWidget) {
    this.mView = paramMotionWidget;
  }
  
  public void setup(int paramInt1, int paramInt2, float paramFloat, long paramLong) {
    ArrayList arrayList1;
    Class<double> clazz = double.class;
    new HashSet();
    HashSet hashSet4 = new HashSet();
    HashSet<String> hashSet2 = new HashSet();
    HashSet hashSet3 = new HashSet();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    int i = this.mPathMotionArc;
    if (i != -1)
      this.mStartMotionPath.mPathMotionArc = i; 
    this.mStartPoint.different(this.mEndPoint, hashSet2);
    ArrayList<MotionKey> arrayList = this.mKeyList;
    if (arrayList != null) {
      Iterator<MotionKey> iterator1 = arrayList.iterator();
      arrayList = null;
      while (true) {
        arrayList1 = arrayList;
        if (iterator1.hasNext()) {
          MotionKey motionKey = iterator1.next();
          if (motionKey instanceof MotionKeyPosition) {
            MotionKeyPosition motionKeyPosition = (MotionKeyPosition)motionKey;
            insertKey(new MotionPaths(paramInt1, paramInt2, motionKeyPosition, this.mStartMotionPath, this.mEndMotionPath));
            if (motionKeyPosition.mCurveFit != -1)
              this.mCurveFitType = motionKeyPosition.mCurveFit; 
            continue;
          } 
          if (motionKey instanceof MotionKeyCycle) {
            motionKey.getAttributeNames(hashSet3);
            continue;
          } 
          if (motionKey instanceof MotionKeyTimeCycle) {
            motionKey.getAttributeNames(hashSet4);
            continue;
          } 
          if (motionKey instanceof MotionKeyTrigger) {
            arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList<MotionKey>(); 
            arrayList1.add(motionKey);
            arrayList = arrayList1;
            continue;
          } 
          motionKey.setInterpolation(hashMap);
          motionKey.getAttributeNames(hashSet2);
          continue;
        } 
        break;
      } 
    } else {
      arrayList1 = null;
    } 
    if (arrayList1 != null)
      this.mKeyTriggers = (MotionKeyTrigger[])arrayList1.toArray((Object[])new MotionKeyTrigger[0]); 
    if (!hashSet2.isEmpty()) {
      this.mAttributesMap = new HashMap<String, SplineSet>();
      for (String str : hashSet2) {
        SplineSet splineSet;
        if (str.startsWith("CUSTOM,")) {
          KeyFrameArray.CustomVar customVar = new KeyFrameArray.CustomVar();
          String str1 = str.split(",")[1];
          for (MotionKey motionKey1 : this.mKeyList) {
            if (motionKey1.mCustom == null)
              continue; 
            CustomVariable customVariable = (CustomVariable)motionKey1.mCustom.get(str1);
            if (customVariable != null)
              customVar.append(motionKey1.mFramePosition, customVariable); 
          } 
          splineSet = SplineSet.makeCustomSplineSet(str, customVar);
        } else {
          splineSet = SplineSet.makeSpline(str, paramLong);
        } 
        if (splineSet == null)
          continue; 
        splineSet.setType(str);
        this.mAttributesMap.put(str, splineSet);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (MotionKey motionKey : arrayList) {
          if (motionKey instanceof androidx.constraintlayout.core.motion.key.MotionKeyAttributes)
            motionKey.addValues(this.mAttributesMap); 
        }  
      this.mStartPoint.addValues(this.mAttributesMap, 0);
      this.mEndPoint.addValues(this.mAttributesMap, 100);
      Iterator iterator1 = this.mAttributesMap.keySet().iterator();
      while (true) {
        while (true)
          break; 
        if (motionKey != null)
          motionKey.setup(paramInt1); 
      } 
    } 
    if (!hashSet4.isEmpty()) {
      if (this.mTimeCycleAttributesMap == null)
        this.mTimeCycleAttributesMap = new HashMap<String, TimeCycleSplineSet>(); 
      for (String str : hashSet4) {
        SplineSet splineSet;
        if (this.mTimeCycleAttributesMap.containsKey(str))
          continue; 
        if (str.startsWith("CUSTOM,")) {
          KeyFrameArray.CustomVar customVar = new KeyFrameArray.CustomVar();
          String str1 = str.split(",")[1];
          for (MotionKey motionKey : this.mKeyList) {
            if (motionKey.mCustom == null)
              continue; 
            CustomVariable customVariable = (CustomVariable)motionKey.mCustom.get(str1);
            if (customVariable != null)
              customVar.append(motionKey.mFramePosition, customVariable); 
          } 
          splineSet = SplineSet.makeCustomSplineSet(str, customVar);
        } else {
          splineSet = SplineSet.makeSpline(str, paramLong);
        } 
        if (splineSet == null)
          continue; 
        splineSet.setType(str);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (MotionKey motionKey : arrayList) {
          if (motionKey instanceof MotionKeyTimeCycle)
            ((MotionKeyTimeCycle)motionKey).addTimeValues(this.mTimeCycleAttributesMap); 
        }  
      for (String str : this.mTimeCycleAttributesMap.keySet()) {
        if (hashMap.containsKey(str)) {
          paramInt1 = ((Integer)hashMap.get(str)).intValue();
        } else {
          paramInt1 = 0;
        } 
        ((TimeCycleSplineSet)this.mTimeCycleAttributesMap.get(str)).setup(paramInt1);
      } 
    } 
    int j = this.mMotionPaths.size() + 2;
    MotionPaths[] arrayOfMotionPaths = new MotionPaths[j];
    arrayOfMotionPaths[0] = this.mStartMotionPath;
    arrayOfMotionPaths[j - 1] = this.mEndMotionPath;
    if (this.mMotionPaths.size() > 0 && this.mCurveFitType == MotionKey.UNSET)
      this.mCurveFitType = 0; 
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    for (paramInt1 = 1; iterator.hasNext(); paramInt1++)
      arrayOfMotionPaths[paramInt1] = iterator.next(); 
    HashSet<String> hashSet1 = new HashSet();
    for (String str : this.mEndMotionPath.customAttributes.keySet()) {
      if (this.mStartMotionPath.customAttributes.containsKey(str)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CUSTOM,");
        stringBuilder.append(str);
        if (!hashSet2.contains(stringBuilder.toString()))
          hashSet1.add(str); 
      } 
    } 
    String[] arrayOfString = hashSet1.<String>toArray(new String[0]);
    this.mAttributeNames = arrayOfString;
    this.mAttributeInterpolatorCount = new int[arrayOfString.length];
    paramInt1 = 0;
    while (true) {
      boolean bool;
      arrayOfString = this.mAttributeNames;
      if (paramInt1 < arrayOfString.length) {
        String str = arrayOfString[paramInt1];
        this.mAttributeInterpolatorCount[paramInt1] = 0;
        for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
          if ((arrayOfMotionPaths[paramInt2]).customAttributes.containsKey(str)) {
            CustomVariable customVariable = (arrayOfMotionPaths[paramInt2]).customAttributes.get(str);
            if (customVariable != null) {
              int[] arrayOfInt = this.mAttributeInterpolatorCount;
              arrayOfInt[paramInt1] = arrayOfInt[paramInt1] + customVariable.numberOfInterpolatedValues();
              break;
            } 
          } 
        } 
        paramInt1++;
        continue;
      } 
      if ((arrayOfMotionPaths[0]).mPathMotionArc != -1) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = 18 + this.mAttributeNames.length;
      boolean[] arrayOfBoolean = new boolean[k];
      for (paramInt1 = 1; paramInt1 < j; paramInt1++)
        arrayOfMotionPaths[paramInt1].different(arrayOfMotionPaths[paramInt1 - 1], arrayOfBoolean, this.mAttributeNames, bool); 
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < k; paramInt2 = i) {
        i = paramInt2;
        if (arrayOfBoolean[paramInt1])
          i = paramInt2 + 1; 
        paramInt1++;
      } 
      this.mInterpolateVariables = new int[paramInt2];
      paramInt1 = Math.max(2, paramInt2);
      this.mInterpolateData = new double[paramInt1];
      this.mInterpolateVelocity = new double[paramInt1];
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < k; paramInt2 = i) {
        i = paramInt2;
        if (arrayOfBoolean[paramInt1]) {
          this.mInterpolateVariables[paramInt2] = paramInt1;
          i = paramInt2 + 1;
        } 
        paramInt1++;
      } 
      double[][] arrayOfDouble = (double[][])Array.newInstance(double.class, new int[] { j, this.mInterpolateVariables.length });
      double[] arrayOfDouble1 = new double[j];
      for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
        arrayOfMotionPaths[paramInt1].fillStandard(arrayOfDouble[paramInt1], this.mInterpolateVariables);
        arrayOfDouble1[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
      } 
      paramInt1 = 0;
      while (true) {
        int[] arrayOfInt = this.mInterpolateVariables;
        if (paramInt1 < arrayOfInt.length) {
          if (arrayOfInt[paramInt1] < MotionPaths.names.length) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(MotionPaths.names[this.mInterpolateVariables[paramInt1]]);
            stringBuilder.append(" [");
            String str = stringBuilder.toString();
            for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str);
              stringBuilder1.append(arrayOfDouble[paramInt2][paramInt1]);
              str = stringBuilder1.toString();
            } 
          } 
          paramInt1++;
          continue;
        } 
        this.mSpline = new CurveFit[this.mAttributeNames.length + 1];
        paramInt1 = 0;
        Class<double> clazz1 = clazz;
        while (true) {
          String[] arrayOfString1 = this.mAttributeNames;
          if (paramInt1 < arrayOfString1.length) {
            double[][] arrayOfDouble4 = (double[][])null;
            String str = arrayOfString1[paramInt1];
            arrayOfDouble4 = null;
            double[][] arrayOfDouble2 = arrayOfDouble4;
            paramInt2 = 0;
            i = 0;
            while (paramInt2 < j) {
              double[][] arrayOfDouble5;
              if (arrayOfMotionPaths[paramInt2].hasCustomData(str)) {
                double[] arrayOfDouble6;
                double[][] arrayOfDouble7 = arrayOfDouble4;
                arrayOfDouble4 = arrayOfDouble2;
                if (arrayOfDouble2 == null) {
                  arrayOfDouble6 = new double[j];
                  arrayOfDouble4 = (double[][])Array.newInstance(clazz1, new int[] { j, arrayOfMotionPaths[paramInt2].getCustomDataCount(str) });
                } 
                arrayOfDouble6[i] = (arrayOfMotionPaths[paramInt2]).time;
                arrayOfMotionPaths[paramInt2].getCustomData(str, arrayOfDouble4[i], 0);
                i++;
                arrayOfDouble2 = arrayOfDouble4;
              } else {
                arrayOfDouble5 = arrayOfDouble4;
              } 
              paramInt2++;
              arrayOfDouble4 = arrayOfDouble5;
            } 
            double[] arrayOfDouble3 = Arrays.copyOf((double[])arrayOfDouble4, i);
            arrayOfDouble2 = Arrays.<double[]>copyOf(arrayOfDouble2, i);
            CurveFit[] arrayOfCurveFit = this.mSpline;
            arrayOfCurveFit[++paramInt1] = CurveFit.get(this.mCurveFitType, arrayOfDouble3, arrayOfDouble2);
            continue;
          } 
          this.mSpline[0] = CurveFit.get(this.mCurveFitType, arrayOfDouble1, arrayOfDouble);
          if ((arrayOfMotionPaths[0]).mPathMotionArc != -1) {
            int[] arrayOfInt1 = new int[j];
            double[] arrayOfDouble3 = new double[j];
            double[][] arrayOfDouble2 = (double[][])Array.newInstance(clazz1, new int[] { j, 2 });
            for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
              arrayOfInt1[paramInt1] = (arrayOfMotionPaths[paramInt1]).mPathMotionArc;
              arrayOfDouble3[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
              arrayOfDouble2[paramInt1][0] = (arrayOfMotionPaths[paramInt1]).x;
              arrayOfDouble2[paramInt1][1] = (arrayOfMotionPaths[paramInt1]).y;
            } 
            this.mArcSpline = CurveFit.getArc(arrayOfInt1, arrayOfDouble3, arrayOfDouble2);
          } 
          paramFloat = Float.NaN;
          this.mCycleMap = new HashMap<String, KeyCycleOscillator>();
          if (this.mKeyList != null) {
            for (String str : hashSet3) {
              KeyCycleOscillator keyCycleOscillator = KeyCycleOscillator.makeWidgetCycle(str);
              if (keyCycleOscillator == null)
                continue; 
              float f = paramFloat;
              if (keyCycleOscillator.variesByPath()) {
                f = paramFloat;
                if (Float.isNaN(paramFloat))
                  f = getPreCycleDistance(); 
              } 
              keyCycleOscillator.setType(str);
              this.mCycleMap.put(str, keyCycleOscillator);
              paramFloat = f;
            } 
            for (MotionKey motionKey : this.mKeyList) {
              if (motionKey instanceof MotionKeyCycle)
                ((MotionKeyCycle)motionKey).addCycleValues(this.mCycleMap); 
            } 
            Iterator<KeyCycleOscillator> iterator1 = this.mCycleMap.values().iterator();
            while (iterator1.hasNext())
              ((KeyCycleOscillator)iterator1.next()).setup(paramFloat); 
          } 
          return;
        } 
        break;
      } 
      break;
    } 
  }
  
  public void setupRelative(Motion paramMotion) {
    this.mStartMotionPath.setupRelative(paramMotion, paramMotion.mStartMotionPath);
    this.mEndMotionPath.setupRelative(paramMotion, paramMotion.mEndMotionPath);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" start: x: ");
    stringBuilder.append(this.mStartMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mStartMotionPath.y);
    stringBuilder.append(" end: x: ");
    stringBuilder.append(this.mEndMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mEndMotionPath.y);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\motion\Motion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */