package androidx.constraintlayout.core.motion;

public class CustomAttribute {
  private static final String TAG = "TransitionLayout";
  
  boolean mBooleanValue;
  
  private int mColorValue;
  
  private float mFloatValue;
  
  private int mIntegerValue;
  
  private boolean mMethod = false;
  
  String mName;
  
  private String mStringValue;
  
  private AttributeType mType;
  
  public CustomAttribute(CustomAttribute paramCustomAttribute, Object paramObject) {
    this.mName = paramCustomAttribute.mName;
    this.mType = paramCustomAttribute.mType;
    setValue(paramObject);
  }
  
  public CustomAttribute(String paramString, AttributeType paramAttributeType) {
    this.mName = paramString;
    this.mType = paramAttributeType;
  }
  
  public CustomAttribute(String paramString, AttributeType paramAttributeType, Object paramObject, boolean paramBoolean) {
    this.mName = paramString;
    this.mType = paramAttributeType;
    this.mMethod = paramBoolean;
    setValue(paramObject);
  }
  
  private static int clamp(int paramInt) {
    paramInt = (paramInt & (paramInt >> 31 ^ 0xFFFFFFFF)) - 255;
    return (paramInt & paramInt >> 31) + 255;
  }
  
  public static int hsvToRgb(float paramFloat1, float paramFloat2, float paramFloat3) {
    paramFloat1 *= 6.0F;
    int i = (int)paramFloat1;
    paramFloat1 -= i;
    paramFloat3 *= 255.0F;
    int j = (int)((1.0F - paramFloat2) * paramFloat3 + 0.5F);
    int k = (int)((1.0F - paramFloat1 * paramFloat2) * paramFloat3 + 0.5F);
    int m = (int)((1.0F - (1.0F - paramFloat1) * paramFloat2) * paramFloat3 + 0.5F);
    int n = (int)(paramFloat3 + 0.5F);
    return (i != 0) ? ((i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? 0 : ((n << 16) + (j << 8) + k | 0xFF000000)) : ((m << 16) + (j << 8) + n | 0xFF000000)) : ((j << 16) + (k << 8) + n | 0xFF000000)) : ((j << 16) + (n << 8) + m | 0xFF000000)) : ((k << 16) + (n << 8) + j | 0xFF000000)) : ((n << 16) + (m << 8) + j | 0xFF000000);
  }
  
  public boolean diff(CustomAttribute paramCustomAttribute) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool2 = false;
    boolean bool1 = bool7;
    if (paramCustomAttribute != null) {
      if (this.mType != paramCustomAttribute.mType)
        return false; 
      switch (this.mType) {
        default:
          return false;
        case null:
          bool1 = bool2;
          if (this.mFloatValue == paramCustomAttribute.mFloatValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool3;
          if (this.mFloatValue == paramCustomAttribute.mFloatValue)
            bool1 = true; 
          return bool1;
        case null:
        case null:
          bool1 = bool4;
          if (this.mColorValue == paramCustomAttribute.mColorValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool5;
          if (this.mIntegerValue == paramCustomAttribute.mIntegerValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool6;
          if (this.mBooleanValue == paramCustomAttribute.mBooleanValue)
            bool1 = true; 
          return bool1;
        case null:
        case null:
          break;
      } 
      bool1 = bool7;
      if (this.mIntegerValue == paramCustomAttribute.mIntegerValue)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public AttributeType getType() {
    return this.mType;
  }
  
  public float getValueToInterpolate() {
    switch (this.mType) {
      default:
        return Float.NaN;
      case null:
        return this.mFloatValue;
      case null:
        return this.mFloatValue;
      case null:
        return this.mIntegerValue;
      case null:
      case null:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case null:
        throw new RuntimeException("Cannot interpolate String");
      case null:
        break;
    } 
    return this.mBooleanValue ? 1.0F : 0.0F;
  }
  
  public void getValuesToInterpolate(float[] paramArrayOffloat) {
    float f1;
    float f2;
    float f3;
    int i;
    switch (this.mType) {
      default:
        return;
      case null:
        paramArrayOffloat[0] = this.mFloatValue;
        return;
      case null:
        paramArrayOffloat[0] = this.mFloatValue;
        return;
      case null:
        paramArrayOffloat[0] = this.mIntegerValue;
        return;
      case null:
      case null:
        i = this.mColorValue;
        f1 = (float)Math.pow(((i >> 16 & 0xFF) / 255.0F), 2.2D);
        f2 = (float)Math.pow(((i >> 8 & 0xFF) / 255.0F), 2.2D);
        f3 = (float)Math.pow(((i & 0xFF) / 255.0F), 2.2D);
        paramArrayOffloat[0] = f1;
        paramArrayOffloat[1] = f2;
        paramArrayOffloat[2] = f3;
        paramArrayOffloat[3] = (i >> 24 & 0xFF) / 255.0F;
        return;
      case null:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case null:
        break;
    } 
    if (this.mBooleanValue) {
      f1 = 1.0F;
    } else {
      f1 = 0.0F;
    } 
    paramArrayOffloat[0] = f1;
  }
  
  public boolean isContinuous() {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    return (i != 1 && i != 2 && i != 3);
  }
  
  public int numberOfInterpolatedValues() {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    return (i != 4 && i != 5) ? 1 : 4;
  }
  
  public void setColorValue(int paramInt) {
    this.mColorValue = paramInt;
  }
  
  public void setFloatValue(float paramFloat) {
    this.mFloatValue = paramFloat;
  }
  
  public void setIntValue(int paramInt) {
    this.mIntegerValue = paramInt;
  }
  
  public void setStringValue(String paramString) {
    this.mStringValue = paramString;
  }
  
  public void setValue(Object paramObject) {
    switch (this.mType) {
      default:
        return;
      case null:
        this.mFloatValue = ((Float)paramObject).floatValue();
        return;
      case null:
        this.mFloatValue = ((Float)paramObject).floatValue();
        return;
      case null:
      case null:
        this.mColorValue = ((Integer)paramObject).intValue();
        return;
      case null:
        this.mStringValue = (String)paramObject;
        return;
      case null:
        this.mBooleanValue = ((Boolean)paramObject).booleanValue();
        return;
      case null:
      case null:
        break;
    } 
    this.mIntegerValue = ((Integer)paramObject).intValue();
  }
  
  public void setValue(float[] paramArrayOffloat) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    boolean bool = true;
    switch (i) {
      default:
        return;
      case 8:
        this.mFloatValue = paramArrayOffloat[0];
        return;
      case 7:
        this.mFloatValue = paramArrayOffloat[0];
        return;
      case 4:
      case 5:
        i = hsvToRgb(paramArrayOffloat[0], paramArrayOffloat[1], paramArrayOffloat[2]);
        this.mColorValue = i;
        this.mColorValue = clamp((int)(paramArrayOffloat[3] * 255.0F)) << 24 | i & 0xFFFFFF;
        return;
      case 3:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case 2:
        if (paramArrayOffloat[0] <= 0.5D)
          bool = false; 
        this.mBooleanValue = bool;
        return;
      case 1:
      case 6:
        break;
    } 
    this.mIntegerValue = (int)paramArrayOffloat[0];
  }
  
  public enum AttributeType {
    BOOLEAN_TYPE, COLOR_DRAWABLE_TYPE, COLOR_TYPE, DIMENSION_TYPE, FLOAT_TYPE, INT_TYPE, REFERENCE_TYPE, STRING_TYPE;
    
    static {
      AttributeType attributeType1 = new AttributeType("INT_TYPE", 0);
      INT_TYPE = attributeType1;
      AttributeType attributeType2 = new AttributeType("FLOAT_TYPE", 1);
      FLOAT_TYPE = attributeType2;
      AttributeType attributeType3 = new AttributeType("COLOR_TYPE", 2);
      COLOR_TYPE = attributeType3;
      AttributeType attributeType4 = new AttributeType("COLOR_DRAWABLE_TYPE", 3);
      COLOR_DRAWABLE_TYPE = attributeType4;
      AttributeType attributeType5 = new AttributeType("STRING_TYPE", 4);
      STRING_TYPE = attributeType5;
      AttributeType attributeType6 = new AttributeType("BOOLEAN_TYPE", 5);
      BOOLEAN_TYPE = attributeType6;
      AttributeType attributeType7 = new AttributeType("DIMENSION_TYPE", 6);
      DIMENSION_TYPE = attributeType7;
      AttributeType attributeType8 = new AttributeType("REFERENCE_TYPE", 7);
      REFERENCE_TYPE = attributeType8;
      $VALUES = new AttributeType[] { attributeType1, attributeType2, attributeType3, attributeType4, attributeType5, attributeType6, attributeType7, attributeType8 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\constraintlayout\core\motion\CustomAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */