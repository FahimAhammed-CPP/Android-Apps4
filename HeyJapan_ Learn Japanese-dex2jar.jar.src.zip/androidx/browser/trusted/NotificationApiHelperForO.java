package androidx.browser.trusted;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;

class NotificationApiHelperForO {
  static Notification copyNotificationOntoChannel(Context paramContext, NotificationManager paramNotificationManager, Notification paramNotification, String paramString1, String paramString2) {
    paramNotificationManager.createNotificationChannel(new NotificationChannel(paramString1, paramString2, 3));
    if (paramNotificationManager.getNotificationChannel(paramString1).getImportance() == 0)
      return null; 
    Notification.Builder builder = Notification.Builder.recoverBuilder(paramContext, paramNotification);
    builder.setChannelId(paramString1);
    return builder.build();
  }
  
  static boolean isChannelEnabled(NotificationManager paramNotificationManager, String paramString) {
    NotificationChannel notificationChannel = paramNotificationManager.getNotificationChannel(paramString);
    return (notificationChannel == null || notificationChannel.getImportance() != 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\browser\trusted\NotificationApiHelperForO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */