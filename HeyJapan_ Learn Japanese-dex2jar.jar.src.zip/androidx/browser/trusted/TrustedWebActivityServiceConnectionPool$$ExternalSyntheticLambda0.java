package androidx.browser.trusted;

import android.net.Uri;



/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityServiceConnectionPool$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */