package androidx.browser.browseractions;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.browser.R;
import androidx.core.content.res.ResourcesCompat;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

@Deprecated
class BrowserActionsFallbackMenuAdapter extends BaseAdapter {
  private final Context mContext;
  
  private final List<BrowserActionItem> mMenuItems;
  
  BrowserActionsFallbackMenuAdapter(List<BrowserActionItem> paramList, Context paramContext) {
    this.mMenuItems = paramList;
    this.mContext = paramContext;
  }
  
  public int getCount() {
    return this.mMenuItems.size();
  }
  
  public Object getItem(int paramInt) {
    return this.mMenuItems.get(paramInt);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    final ViewHolderItem viewHolder;
    ViewHolderItem viewHolderItem2;
    final Drawable titleText;
    BrowserActionItem browserActionItem = this.mMenuItems.get(paramInt);
    if (paramView == null) {
      View view = LayoutInflater.from(this.mContext).inflate(R.layout.browser_actions_context_menu_row, null);
      ImageView imageView = (ImageView)view.findViewById(R.id.browser_actions_menu_item_icon);
      TextView textView = (TextView)view.findViewById(R.id.browser_actions_menu_item_text);
      if (imageView != null && textView != null) {
        viewHolderItem1 = new ViewHolderItem(imageView, textView);
        view.setTag(viewHolderItem1);
      } else {
        throw new IllegalStateException("Browser Actions fallback UI does not contain necessary Views.");
      } 
    } else {
      ViewHolderItem viewHolderItem = (ViewHolderItem)viewHolderItem1.getTag();
      viewHolderItem2 = viewHolderItem1;
      viewHolderItem1 = viewHolderItem;
    } 
    String str = browserActionItem.getTitle();
    viewHolderItem1.mText.setText(str);
    if (browserActionItem.getIconId() != 0) {
      drawable = ResourcesCompat.getDrawable(this.mContext.getResources(), browserActionItem.getIconId(), null);
      viewHolderItem1.mIcon.setImageDrawable(drawable);
      return (View)viewHolderItem2;
    } 
    if (browserActionItem.getIconUri() != null) {
      final ListenableFuture<Bitmap> bitmapFuture = BrowserServiceFileProvider.loadBitmap(this.mContext.getContentResolver(), browserActionItem.getIconUri());
      listenableFuture.addListener(new Runnable() {
            public void run() {
              if (!TextUtils.equals(titleText, viewHolder.mText.getText()))
                return; 
              try {
                Bitmap bitmap = (Bitmap)bitmapFuture.get();
              } catch (ExecutionException|InterruptedException executionException) {
                executionException = null;
              } 
              if (executionException != null) {
                viewHolder.mIcon.setVisibility(0);
                viewHolder.mIcon.setImageBitmap((Bitmap)executionException);
                return;
              } 
              viewHolder.mIcon.setVisibility(4);
              viewHolder.mIcon.setImageBitmap(null);
            }
          }new Executor() {
            public void execute(Runnable param1Runnable) {
              param1Runnable.run();
            }
          });
      return (View)viewHolderItem2;
    } 
    viewHolderItem1.mIcon.setImageBitmap(null);
    viewHolderItem1.mIcon.setVisibility(4);
    return (View)viewHolderItem2;
  }
  
  static class ViewHolderItem {
    final ImageView mIcon;
    
    final TextView mText;
    
    ViewHolderItem(ImageView param1ImageView, TextView param1TextView) {
      this.mIcon = param1ImageView;
      this.mText = param1TextView;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\HeyJapan_ Learn Japanese-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsFallbackMenuAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */