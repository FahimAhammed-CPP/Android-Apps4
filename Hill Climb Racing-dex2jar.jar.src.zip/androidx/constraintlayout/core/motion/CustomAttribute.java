package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.utils.Utils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class CustomAttribute {
  private static final String TAG = "TransitionLayout";
  
  boolean mBooleanValue;
  
  private int mColorValue;
  
  private float mFloatValue;
  
  private int mIntegerValue;
  
  private boolean mMethod;
  
  String mName;
  
  private String mStringValue;
  
  private AttributeType mType;
  
  public CustomAttribute(CustomAttribute paramCustomAttribute, Object paramObject) {
    this.mMethod = false;
    this.mName = paramCustomAttribute.mName;
    this.mType = paramCustomAttribute.mType;
    setValue(paramObject);
  }
  
  public CustomAttribute(String paramString, AttributeType paramAttributeType) {
    this.mMethod = false;
    this.mName = paramString;
    this.mType = paramAttributeType;
  }
  
  public CustomAttribute(String paramString, AttributeType paramAttributeType, Object paramObject, boolean paramBoolean) {
    this.mName = paramString;
    this.mType = paramAttributeType;
    this.mMethod = paramBoolean;
    setValue(paramObject);
  }
  
  private static int clamp(int paramInt) {
    paramInt = (paramInt & (paramInt >> 31 ^ 0xFFFFFFFF)) - 255;
    return (paramInt & paramInt >> 31) + 255;
  }
  
  public static HashMap<String, CustomAttribute> extractAttributes(HashMap<String, CustomAttribute> paramHashMap, Object paramObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Class<?> clazz = paramObject.getClass();
    for (String str : paramHashMap.keySet()) {
      CustomAttribute customAttribute = paramHashMap.get(str);
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getMap");
        stringBuilder.append(str);
        hashMap.put(str, new CustomAttribute(customAttribute, clazz.getMethod(stringBuilder.toString(), new Class[0]).invoke(paramObject, new Object[0])));
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.printStackTrace();
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
      } 
    } 
    return (HashMap)hashMap;
  }
  
  public static int hsvToRgb(float paramFloat1, float paramFloat2, float paramFloat3) {
    paramFloat1 *= 6.0F;
    int i = (int)paramFloat1;
    paramFloat1 -= i;
    paramFloat3 *= 255.0F;
    int j = (int)((1.0F - paramFloat2) * paramFloat3 + 0.5F);
    int k = (int)((1.0F - paramFloat1 * paramFloat2) * paramFloat3 + 0.5F);
    int m = (int)((1.0F - (1.0F - paramFloat1) * paramFloat2) * paramFloat3 + 0.5F);
    int n = (int)(paramFloat3 + 0.5F);
    return (i != 0) ? ((i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? 0 : ((n << 16) + (j << 8) + k | 0xFF000000)) : ((m << 16) + (j << 8) + n | 0xFF000000)) : ((j << 16) + (k << 8) + n | 0xFF000000)) : ((j << 16) + (n << 8) + m | 0xFF000000)) : ((k << 16) + (n << 8) + j | 0xFF000000)) : ((n << 16) + (m << 8) + j | 0xFF000000);
  }
  
  public static void setAttributes(Object paramObject, HashMap<String, CustomAttribute> paramHashMap) {
    Class<?> clazz = paramObject.getClass();
    for (String str2 : paramHashMap.keySet()) {
      String str1;
      StringBuilder stringBuilder;
      CustomAttribute customAttribute = paramHashMap.get(str2);
      if (!customAttribute.mMethod) {
        StringBuilder stringBuilder1 = new StringBuilder("set");
        stringBuilder1.append(str2);
        str1 = stringBuilder1.toString();
      } else {
        str1 = str2;
      } 
      try {
        switch (customAttribute.mType) {
          case null:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(customAttribute.mFloatValue) });
          case null:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(customAttribute.mFloatValue) });
          case null:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf(customAttribute.mIntegerValue) });
          case null:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf(customAttribute.mColorValue) });
          case null:
            clazz.getMethod(str1, new Class[] { CharSequence.class }).invoke(paramObject, new Object[] { customAttribute.mStringValue });
          case null:
            clazz.getMethod(str1, new Class[] { boolean.class }).invoke(paramObject, new Object[] { Boolean.valueOf(customAttribute.mBooleanValue) });
          case null:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf(customAttribute.mIntegerValue) });
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        Utils.loge("TransitionLayout", noSuchMethodException.getMessage());
        StringBuilder stringBuilder1 = new StringBuilder(" Custom Attribute \"");
        stringBuilder1.append(str2);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Utils.loge("TransitionLayout", stringBuilder1.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(clazz.getName());
        stringBuilder.append(" must have a method ");
        stringBuilder.append(str1);
        Utils.loge("TransitionLayout", stringBuilder.toString());
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder1 = new StringBuilder(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Utils.loge("TransitionLayout", stringBuilder1.toString());
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder1 = new StringBuilder(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Utils.loge("TransitionLayout", stringBuilder1.toString());
        invocationTargetException.printStackTrace();
      } 
    } 
  }
  
  public void applyCustom(Object paramObject) {
    String str1;
    Class<?> clazz = paramObject.getClass();
    String str2 = this.mName;
    if (!this.mMethod) {
      StringBuilder stringBuilder = new StringBuilder("set");
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } else {
      str1 = str2;
    } 
    try {
      switch (this.mType) {
        case null:
          clazz.getMethod(str1, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(this.mFloatValue) });
          return;
        case null:
          clazz.getMethod(str1, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(this.mFloatValue) });
          return;
        case null:
          clazz.getMethod(str1, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf(this.mColorValue) });
          return;
        case null:
          clazz.getMethod(str1, new Class[] { CharSequence.class }).invoke(paramObject, new Object[] { this.mStringValue });
          return;
        case null:
          clazz.getMethod(str1, new Class[] { boolean.class }).invoke(paramObject, new Object[] { Boolean.valueOf(this.mBooleanValue) });
          return;
        case null:
        case null:
          clazz.getMethod(str1, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf(this.mIntegerValue) });
          return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Utils.loge("TransitionLayout", noSuchMethodException.getMessage());
      StringBuilder stringBuilder = new StringBuilder(" Custom Attribute \"");
      stringBuilder.append(str2);
      stringBuilder.append("\" not found on ");
      stringBuilder.append(clazz.getName());
      Utils.loge("TransitionLayout", stringBuilder.toString());
      stringBuilder = new StringBuilder();
      stringBuilder.append(clazz.getName());
      stringBuilder.append(" must have a method ");
      stringBuilder.append(str1);
      Utils.loge("TransitionLayout", stringBuilder.toString());
      return;
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder(" Custom Attribute \"");
      stringBuilder.append(str2);
      stringBuilder.append("\" not found on ");
      stringBuilder.append(clazz.getName());
      Utils.loge("TransitionLayout", stringBuilder.toString());
      illegalAccessException.printStackTrace();
      return;
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder(" Custom Attribute \"");
      stringBuilder.append(str2);
      stringBuilder.append("\" not found on ");
      stringBuilder.append(clazz.getName());
      Utils.loge("TransitionLayout", stringBuilder.toString());
      invocationTargetException.printStackTrace();
      return;
    } 
  }
  
  public boolean diff(CustomAttribute paramCustomAttribute) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool2 = false;
    boolean bool1 = bool7;
    if (paramCustomAttribute != null) {
      if (this.mType != paramCustomAttribute.mType)
        return false; 
      switch (this.mType) {
        default:
          return false;
        case null:
          bool1 = bool2;
          if (this.mFloatValue == paramCustomAttribute.mFloatValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool3;
          if (this.mFloatValue == paramCustomAttribute.mFloatValue)
            bool1 = true; 
          return bool1;
        case null:
        case null:
          bool1 = bool4;
          if (this.mColorValue == paramCustomAttribute.mColorValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool5;
          if (this.mIntegerValue == paramCustomAttribute.mIntegerValue)
            bool1 = true; 
          return bool1;
        case null:
          bool1 = bool6;
          if (this.mBooleanValue == paramCustomAttribute.mBooleanValue)
            bool1 = true; 
          return bool1;
        case null:
        case null:
          break;
      } 
      bool1 = bool7;
      if (this.mIntegerValue == paramCustomAttribute.mIntegerValue)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public AttributeType getType() {
    return this.mType;
  }
  
  public float getValueToInterpolate() {
    switch (this.mType) {
      default:
        return Float.NaN;
      case null:
        return this.mFloatValue;
      case null:
        return this.mFloatValue;
      case null:
        return this.mIntegerValue;
      case null:
      case null:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case null:
        throw new RuntimeException("Cannot interpolate String");
      case null:
        break;
    } 
    return this.mBooleanValue ? 1.0F : 0.0F;
  }
  
  public void getValuesToInterpolate(float[] paramArrayOffloat) {
    float f1;
    float f2;
    float f3;
    int i;
    switch (this.mType) {
      default:
        return;
      case null:
        paramArrayOffloat[0] = this.mFloatValue;
        return;
      case null:
        paramArrayOffloat[0] = this.mFloatValue;
        return;
      case null:
        paramArrayOffloat[0] = this.mIntegerValue;
        return;
      case null:
      case null:
        i = this.mColorValue;
        f1 = (float)Math.pow(((i >> 16 & 0xFF) / 255.0F), 2.2D);
        f2 = (float)Math.pow(((i >> 8 & 0xFF) / 255.0F), 2.2D);
        f3 = (float)Math.pow(((i & 0xFF) / 255.0F), 2.2D);
        paramArrayOffloat[0] = f1;
        paramArrayOffloat[1] = f2;
        paramArrayOffloat[2] = f3;
        paramArrayOffloat[3] = (i >> 24 & 0xFF) / 255.0F;
        return;
      case null:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case null:
        break;
    } 
    if (this.mBooleanValue) {
      f1 = 1.0F;
    } else {
      f1 = 0.0F;
    } 
    paramArrayOffloat[0] = f1;
  }
  
  public boolean isContinuous() {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    return (i != 1 && i != 2 && i != 3);
  }
  
  public int numberOfInterpolatedValues() {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    return (i != 4 && i != 5) ? 1 : 4;
  }
  
  public void setColorValue(int paramInt) {
    this.mColorValue = paramInt;
  }
  
  public void setFloatValue(float paramFloat) {
    this.mFloatValue = paramFloat;
  }
  
  public void setIntValue(int paramInt) {
    this.mIntegerValue = paramInt;
  }
  
  public void setInterpolatedValue(Object paramObject, float[] paramArrayOffloat) {
    Class<?> clazz = paramObject.getClass();
    StringBuilder stringBuilder = new StringBuilder("set");
    stringBuilder.append(this.mName);
    String str = stringBuilder.toString();
    try {
      StringBuilder stringBuilder1;
      int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
      boolean bool = true;
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 6) {
              if (i != 7) {
                if (i != 8)
                  return; 
                clazz.getMethod(str, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(paramArrayOffloat[0]) });
                return;
              } 
              clazz.getMethod(str, new Class[] { float.class }).invoke(paramObject, new Object[] { Float.valueOf(paramArrayOffloat[0]) });
              return;
            } 
            clazz.getMethod(str, new Class[] { int.class }).invoke(paramObject, new Object[] { Integer.valueOf((int)paramArrayOffloat[0]) });
            return;
          } 
          method = clazz.getMethod(str, new Class[] { int.class });
          i = clamp((int)((float)Math.pow(paramArrayOffloat[0], 0.45454545454545453D) * 255.0F));
          int j = clamp((int)((float)Math.pow(paramArrayOffloat[1], 0.45454545454545453D) * 255.0F));
          int k = clamp((int)((float)Math.pow(paramArrayOffloat[2], 0.45454545454545453D) * 255.0F));
          method.invoke(paramObject, new Object[] { Integer.valueOf(i << 16 | clamp((int)(paramArrayOffloat[3] * 255.0F)) << 24 | j << 8 | k) });
          return;
        } 
        stringBuilder1 = new StringBuilder("unable to interpolate strings ");
        stringBuilder1.append(this.mName);
        throw new RuntimeException(stringBuilder1.toString());
      } 
      Method method = method.getMethod(str, new Class[] { boolean.class });
      if (stringBuilder1[0] <= 0.5F)
        bool = false; 
      method.invoke(paramObject, new Object[] { Boolean.valueOf(bool) });
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder1 = new StringBuilder("no method ");
      stringBuilder1.append(str);
      stringBuilder1.append(" on View \"");
      stringBuilder1.append(paramObject.getClass().getName());
      stringBuilder1.append("\"");
      Utils.loge("TransitionLayout", stringBuilder1.toString());
      noSuchMethodException.printStackTrace();
      return;
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder1 = new StringBuilder("cannot access method ");
      stringBuilder1.append(str);
      stringBuilder1.append(" on View \"");
      stringBuilder1.append(paramObject.getClass().getName());
      stringBuilder1.append("\"");
      Utils.loge("TransitionLayout", stringBuilder1.toString());
      illegalAccessException.printStackTrace();
      return;
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.printStackTrace();
      return;
    } 
  }
  
  public void setStringValue(String paramString) {
    this.mStringValue = paramString;
  }
  
  public void setValue(Object paramObject) {
    switch (this.mType) {
      default:
        return;
      case null:
        this.mFloatValue = ((Float)paramObject).floatValue();
        return;
      case null:
        this.mFloatValue = ((Float)paramObject).floatValue();
        return;
      case null:
      case null:
        this.mColorValue = ((Integer)paramObject).intValue();
        return;
      case null:
        this.mStringValue = (String)paramObject;
        return;
      case null:
        this.mBooleanValue = ((Boolean)paramObject).booleanValue();
        return;
      case null:
      case null:
        break;
    } 
    this.mIntegerValue = ((Integer)paramObject).intValue();
  }
  
  public void setValue(float[] paramArrayOffloat) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$motion$CustomAttribute$AttributeType[this.mType.ordinal()];
    boolean bool = true;
    switch (i) {
      default:
        return;
      case 8:
        this.mFloatValue = paramArrayOffloat[0];
        return;
      case 7:
        this.mFloatValue = paramArrayOffloat[0];
        return;
      case 4:
      case 5:
        i = hsvToRgb(paramArrayOffloat[0], paramArrayOffloat[1], paramArrayOffloat[2]);
        this.mColorValue = i;
        this.mColorValue = clamp((int)(paramArrayOffloat[3] * 255.0F)) << 24 | i & 0xFFFFFF;
        return;
      case 3:
        throw new RuntimeException("Color does not have a single color to interpolate");
      case 2:
        if (paramArrayOffloat[0] <= 0.5D)
          bool = false; 
        this.mBooleanValue = bool;
        return;
      case 1:
      case 6:
        break;
    } 
    this.mIntegerValue = (int)paramArrayOffloat[0];
  }
  
  public enum AttributeType {
    BOOLEAN_TYPE, COLOR_DRAWABLE_TYPE, COLOR_TYPE, DIMENSION_TYPE, FLOAT_TYPE, INT_TYPE, REFERENCE_TYPE, STRING_TYPE;
    
    static {
      AttributeType attributeType1 = new AttributeType("INT_TYPE", 0);
      INT_TYPE = attributeType1;
      AttributeType attributeType2 = new AttributeType("FLOAT_TYPE", 1);
      FLOAT_TYPE = attributeType2;
      AttributeType attributeType3 = new AttributeType("COLOR_TYPE", 2);
      COLOR_TYPE = attributeType3;
      AttributeType attributeType4 = new AttributeType("COLOR_DRAWABLE_TYPE", 3);
      COLOR_DRAWABLE_TYPE = attributeType4;
      AttributeType attributeType5 = new AttributeType("STRING_TYPE", 4);
      STRING_TYPE = attributeType5;
      AttributeType attributeType6 = new AttributeType("BOOLEAN_TYPE", 5);
      BOOLEAN_TYPE = attributeType6;
      AttributeType attributeType7 = new AttributeType("DIMENSION_TYPE", 6);
      DIMENSION_TYPE = attributeType7;
      AttributeType attributeType8 = new AttributeType("REFERENCE_TYPE", 7);
      REFERENCE_TYPE = attributeType8;
      $VALUES = new AttributeType[] { attributeType1, attributeType2, attributeType3, attributeType4, attributeType5, attributeType6, attributeType7, attributeType8 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\motion\CustomAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */