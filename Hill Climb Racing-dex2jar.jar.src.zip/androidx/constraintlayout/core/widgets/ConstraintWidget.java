package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.Cache;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.state.WidgetFrame;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  public static final int WRAP_BEHAVIOR_HORIZONTAL_ONLY = 1;
  
  public static final int WRAP_BEHAVIOR_INCLUDED = 0;
  
  public static final int WRAP_BEHAVIOR_SKIPPED = 3;
  
  public static final int WRAP_BEHAVIOR_VERTICAL_ONLY = 2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  public WidgetFrame frame = new WidgetFrame(this);
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean horizontalSolvingPass = false;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  private int mHeightOverride = -1;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtualLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  private int mWidthOverride = -1;
  
  private int mWrapBehaviorInParent = 0;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public String stringId;
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  private boolean verticalSolvingPass = false;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  private void serializeAnchor(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, float paramFloat1, float paramFloat2) {
    if (paramFloat1 == paramFloat2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramFloat2);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeCircle(StringBuilder paramStringBuilder, ConstraintAnchor paramConstraintAnchor, float paramFloat) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("circle : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeDimensionRatio(StringBuilder paramStringBuilder, String paramString, float paramFloat, int paramInt) {
    if (paramFloat == 0.0F)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  [");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramInt);
    paramStringBuilder.append("");
    paramStringBuilder.append("],\n");
  }
  
  private void serializeSize(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "size", paramInt1, -2.1474836E9F);
    serializeAttribute(paramStringBuilder, "min", paramInt2, 0.0F);
    serializeAttribute(paramStringBuilder, "max", paramInt3, 2.1474836E9F);
    serializeAttribute(paramStringBuilder, "matchMin", paramInt5, 0.0F);
    paramFloat1 = paramInt6;
    serializeAttribute(paramStringBuilder, "matchDef", paramFloat1, 0.0F);
    serializeAttribute(paramStringBuilder, "matchPercent", paramFloat1, 1.0F);
    paramStringBuilder.append("},\n");
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   8: astore #28
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   18: astore #27
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   28: astore #30
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   38: astore #29
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   48: astore #26
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   54: astore #24
    //   56: aload #24
    //   58: ifnull -> 173
    //   61: aload #24
    //   63: ifnull -> 85
    //   66: aload #24
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #11
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   92: astore #24
    //   94: aload #24
    //   96: ifnull -> 118
    //   99: aload #24
    //   101: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: iconst_1
    //   105: aaload
    //   106: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   109: if_acmpne -> 118
    //   112: iconst_1
    //   113: istore #12
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #12
    //   121: aload_0
    //   122: getfield mWrapBehaviorInParent : I
    //   125: istore #4
    //   127: iload #4
    //   129: iconst_1
    //   130: if_icmpeq -> 166
    //   133: iload #4
    //   135: iconst_2
    //   136: if_icmpeq -> 156
    //   139: iload #4
    //   141: iconst_3
    //   142: if_icmpeq -> 173
    //   145: iload #11
    //   147: istore #13
    //   149: iload #12
    //   151: istore #11
    //   153: goto -> 179
    //   156: iload #12
    //   158: istore #11
    //   160: iconst_0
    //   161: istore #13
    //   163: goto -> 179
    //   166: iload #11
    //   168: istore #13
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #13
    //   176: iconst_0
    //   177: istore #11
    //   179: aload_0
    //   180: getfield mVisibility : I
    //   183: bipush #8
    //   185: if_icmpne -> 216
    //   188: aload_0
    //   189: invokevirtual hasDependencies : ()Z
    //   192: ifne -> 216
    //   195: aload_0
    //   196: getfield mIsInBarrier : [Z
    //   199: astore #24
    //   201: aload #24
    //   203: iconst_0
    //   204: baload
    //   205: ifne -> 216
    //   208: aload #24
    //   210: iconst_1
    //   211: baload
    //   212: ifne -> 216
    //   215: return
    //   216: aload_0
    //   217: getfield resolvedHorizontal : Z
    //   220: istore #12
    //   222: iload #12
    //   224: ifne -> 234
    //   227: aload_0
    //   228: getfield resolvedVertical : Z
    //   231: ifeq -> 482
    //   234: iload #12
    //   236: ifeq -> 332
    //   239: aload_1
    //   240: aload #28
    //   242: aload_0
    //   243: getfield mX : I
    //   246: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   249: aload_1
    //   250: aload #27
    //   252: aload_0
    //   253: getfield mX : I
    //   256: aload_0
    //   257: getfield mWidth : I
    //   260: iadd
    //   261: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   264: iload #13
    //   266: ifeq -> 332
    //   269: aload_0
    //   270: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   273: astore #24
    //   275: aload #24
    //   277: ifnull -> 332
    //   280: aload_0
    //   281: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   284: ifeq -> 315
    //   287: aload #24
    //   289: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   292: astore #24
    //   294: aload #24
    //   296: aload_0
    //   297: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   300: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   303: aload #24
    //   305: aload_0
    //   306: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   309: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   312: goto -> 332
    //   315: aload_1
    //   316: aload_1
    //   317: aload #24
    //   319: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   322: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   325: aload #27
    //   327: iconst_0
    //   328: iconst_5
    //   329: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   332: aload_0
    //   333: getfield resolvedVertical : Z
    //   336: ifeq -> 457
    //   339: aload_1
    //   340: aload #30
    //   342: aload_0
    //   343: getfield mY : I
    //   346: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   349: aload_1
    //   350: aload #29
    //   352: aload_0
    //   353: getfield mY : I
    //   356: aload_0
    //   357: getfield mHeight : I
    //   360: iadd
    //   361: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   364: aload_0
    //   365: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   368: invokevirtual hasDependents : ()Z
    //   371: ifeq -> 389
    //   374: aload_1
    //   375: aload #26
    //   377: aload_0
    //   378: getfield mY : I
    //   381: aload_0
    //   382: getfield mBaselineDistance : I
    //   385: iadd
    //   386: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   389: iload #11
    //   391: ifeq -> 457
    //   394: aload_0
    //   395: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   398: astore #24
    //   400: aload #24
    //   402: ifnull -> 457
    //   405: aload_0
    //   406: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   409: ifeq -> 440
    //   412: aload #24
    //   414: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   417: astore #24
    //   419: aload #24
    //   421: aload_0
    //   422: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   425: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   428: aload #24
    //   430: aload_0
    //   431: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   434: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   437: goto -> 457
    //   440: aload_1
    //   441: aload_1
    //   442: aload #24
    //   444: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   447: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   450: aload #29
    //   452: iconst_0
    //   453: iconst_5
    //   454: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   457: aload_0
    //   458: getfield resolvedHorizontal : Z
    //   461: ifeq -> 482
    //   464: aload_0
    //   465: getfield resolvedVertical : Z
    //   468: ifeq -> 482
    //   471: aload_0
    //   472: iconst_0
    //   473: putfield resolvedHorizontal : Z
    //   476: aload_0
    //   477: iconst_0
    //   478: putfield resolvedVertical : Z
    //   481: return
    //   482: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   485: ifnull -> 505
    //   488: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   491: astore #24
    //   493: aload #24
    //   495: aload #24
    //   497: getfield widgets : J
    //   500: lconst_1
    //   501: ladd
    //   502: putfield widgets : J
    //   505: iload_2
    //   506: ifeq -> 780
    //   509: aload_0
    //   510: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   513: astore #24
    //   515: aload #24
    //   517: ifnull -> 780
    //   520: aload_0
    //   521: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   524: ifnull -> 780
    //   527: aload #24
    //   529: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   532: getfield resolved : Z
    //   535: ifeq -> 780
    //   538: aload_0
    //   539: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   542: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   545: getfield resolved : Z
    //   548: ifeq -> 780
    //   551: aload_0
    //   552: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   555: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   558: getfield resolved : Z
    //   561: ifeq -> 780
    //   564: aload_0
    //   565: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   568: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   571: getfield resolved : Z
    //   574: ifeq -> 780
    //   577: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   580: ifnull -> 600
    //   583: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   586: astore #24
    //   588: aload #24
    //   590: aload #24
    //   592: getfield graphSolved : J
    //   595: lconst_1
    //   596: ladd
    //   597: putfield graphSolved : J
    //   600: aload_1
    //   601: aload #28
    //   603: aload_0
    //   604: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   607: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   610: getfield value : I
    //   613: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   616: aload_1
    //   617: aload #27
    //   619: aload_0
    //   620: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   623: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   626: getfield value : I
    //   629: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   632: aload_1
    //   633: aload #30
    //   635: aload_0
    //   636: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   639: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   642: getfield value : I
    //   645: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   648: aload_1
    //   649: aload #29
    //   651: aload_0
    //   652: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   655: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   658: getfield value : I
    //   661: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   664: aload_1
    //   665: aload #26
    //   667: aload_0
    //   668: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   671: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   674: getfield value : I
    //   677: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   680: aload_0
    //   681: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   684: ifnull -> 769
    //   687: iload #13
    //   689: ifeq -> 728
    //   692: aload_0
    //   693: getfield isTerminalWidget : [Z
    //   696: iconst_0
    //   697: baload
    //   698: ifeq -> 728
    //   701: aload_0
    //   702: invokevirtual isInHorizontalChain : ()Z
    //   705: ifne -> 728
    //   708: aload_1
    //   709: aload_1
    //   710: aload_0
    //   711: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   714: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   717: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   720: aload #27
    //   722: iconst_0
    //   723: bipush #8
    //   725: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   728: iload #11
    //   730: ifeq -> 769
    //   733: aload_0
    //   734: getfield isTerminalWidget : [Z
    //   737: iconst_1
    //   738: baload
    //   739: ifeq -> 769
    //   742: aload_0
    //   743: invokevirtual isInVerticalChain : ()Z
    //   746: ifne -> 769
    //   749: aload_1
    //   750: aload_1
    //   751: aload_0
    //   752: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   755: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   758: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   761: aload #29
    //   763: iconst_0
    //   764: bipush #8
    //   766: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   769: aload_0
    //   770: iconst_0
    //   771: putfield resolvedHorizontal : Z
    //   774: aload_0
    //   775: iconst_0
    //   776: putfield resolvedVertical : Z
    //   779: return
    //   780: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   783: ifnull -> 803
    //   786: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   789: astore #24
    //   791: aload #24
    //   793: aload #24
    //   795: getfield linearSolved : J
    //   798: lconst_1
    //   799: ladd
    //   800: putfield linearSolved : J
    //   803: aload_0
    //   804: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   807: ifnull -> 1004
    //   810: aload_0
    //   811: iconst_0
    //   812: invokespecial isChainHead : (I)Z
    //   815: ifeq -> 836
    //   818: aload_0
    //   819: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   822: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   825: aload_0
    //   826: iconst_0
    //   827: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   830: iconst_1
    //   831: istore #12
    //   833: goto -> 842
    //   836: aload_0
    //   837: invokevirtual isInHorizontalChain : ()Z
    //   840: istore #12
    //   842: aload_0
    //   843: iconst_1
    //   844: invokespecial isChainHead : (I)Z
    //   847: ifeq -> 868
    //   850: aload_0
    //   851: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   854: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   857: aload_0
    //   858: iconst_1
    //   859: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   862: iconst_1
    //   863: istore #14
    //   865: goto -> 874
    //   868: aload_0
    //   869: invokevirtual isInVerticalChain : ()Z
    //   872: istore #14
    //   874: iload #12
    //   876: ifne -> 932
    //   879: iload #13
    //   881: ifeq -> 932
    //   884: aload_0
    //   885: getfield mVisibility : I
    //   888: bipush #8
    //   890: if_icmpeq -> 932
    //   893: aload_0
    //   894: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   897: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   900: ifnonnull -> 932
    //   903: aload_0
    //   904: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   907: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   910: ifnonnull -> 932
    //   913: aload_1
    //   914: aload_1
    //   915: aload_0
    //   916: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   919: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   922: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   925: aload #27
    //   927: iconst_0
    //   928: iconst_1
    //   929: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   932: iload #14
    //   934: ifne -> 997
    //   937: iload #11
    //   939: ifeq -> 997
    //   942: aload_0
    //   943: getfield mVisibility : I
    //   946: bipush #8
    //   948: if_icmpeq -> 997
    //   951: aload_0
    //   952: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   955: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   958: ifnonnull -> 997
    //   961: aload_0
    //   962: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   965: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   968: ifnonnull -> 997
    //   971: aload_0
    //   972: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   975: ifnonnull -> 997
    //   978: aload_1
    //   979: aload_1
    //   980: aload_0
    //   981: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   984: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   987: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   990: aload #29
    //   992: iconst_0
    //   993: iconst_1
    //   994: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   997: iload #12
    //   999: istore #15
    //   1001: goto -> 1010
    //   1004: iconst_0
    //   1005: istore #14
    //   1007: iconst_0
    //   1008: istore #15
    //   1010: aload_0
    //   1011: getfield mWidth : I
    //   1014: istore #5
    //   1016: aload_0
    //   1017: getfield mMinWidth : I
    //   1020: istore #6
    //   1022: iload #5
    //   1024: istore #4
    //   1026: iload #5
    //   1028: iload #6
    //   1030: if_icmpge -> 1037
    //   1033: iload #6
    //   1035: istore #4
    //   1037: aload_0
    //   1038: getfield mHeight : I
    //   1041: istore #6
    //   1043: aload_0
    //   1044: getfield mMinHeight : I
    //   1047: istore #7
    //   1049: iload #6
    //   1051: istore #5
    //   1053: iload #6
    //   1055: iload #7
    //   1057: if_icmpge -> 1064
    //   1060: iload #7
    //   1062: istore #5
    //   1064: aload_0
    //   1065: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1068: iconst_0
    //   1069: aaload
    //   1070: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1073: if_acmpeq -> 1082
    //   1076: iconst_1
    //   1077: istore #12
    //   1079: goto -> 1085
    //   1082: iconst_0
    //   1083: istore #12
    //   1085: aload_0
    //   1086: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1089: iconst_1
    //   1090: aaload
    //   1091: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1094: if_acmpeq -> 1103
    //   1097: iconst_1
    //   1098: istore #16
    //   1100: goto -> 1106
    //   1103: iconst_0
    //   1104: istore #16
    //   1106: aload_0
    //   1107: aload_0
    //   1108: getfield mDimensionRatioSide : I
    //   1111: putfield mResolvedDimensionRatioSide : I
    //   1114: aload_0
    //   1115: getfield mDimensionRatio : F
    //   1118: fstore_3
    //   1119: aload_0
    //   1120: fload_3
    //   1121: putfield mResolvedDimensionRatio : F
    //   1124: aload_0
    //   1125: getfield mMatchConstraintDefaultWidth : I
    //   1128: istore #7
    //   1130: aload_0
    //   1131: getfield mMatchConstraintDefaultHeight : I
    //   1134: istore #8
    //   1136: fload_3
    //   1137: fconst_0
    //   1138: fcmpl
    //   1139: ifle -> 1479
    //   1142: aload_0
    //   1143: getfield mVisibility : I
    //   1146: bipush #8
    //   1148: if_icmpeq -> 1479
    //   1151: iload #7
    //   1153: istore #6
    //   1155: aload_0
    //   1156: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1159: iconst_0
    //   1160: aaload
    //   1161: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1164: if_acmpne -> 1179
    //   1167: iload #7
    //   1169: istore #6
    //   1171: iload #7
    //   1173: ifne -> 1179
    //   1176: iconst_3
    //   1177: istore #6
    //   1179: iload #8
    //   1181: istore #7
    //   1183: aload_0
    //   1184: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1187: iconst_1
    //   1188: aaload
    //   1189: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1192: if_acmpne -> 1207
    //   1195: iload #8
    //   1197: istore #7
    //   1199: iload #8
    //   1201: ifne -> 1207
    //   1204: iconst_3
    //   1205: istore #7
    //   1207: aload_0
    //   1208: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1211: iconst_0
    //   1212: aaload
    //   1213: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1216: if_acmpne -> 1262
    //   1219: aload_0
    //   1220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1223: iconst_1
    //   1224: aaload
    //   1225: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1228: if_acmpne -> 1262
    //   1231: iload #6
    //   1233: iconst_3
    //   1234: if_icmpne -> 1262
    //   1237: iload #7
    //   1239: iconst_3
    //   1240: if_icmpne -> 1262
    //   1243: aload_0
    //   1244: iload #13
    //   1246: iload #11
    //   1248: iload #12
    //   1250: iload #16
    //   1252: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1255: iload #5
    //   1257: istore #8
    //   1259: goto -> 1453
    //   1262: aload_0
    //   1263: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1266: iconst_0
    //   1267: aaload
    //   1268: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1271: if_acmpne -> 1350
    //   1274: iload #6
    //   1276: iconst_3
    //   1277: if_icmpne -> 1350
    //   1280: aload_0
    //   1281: iconst_0
    //   1282: putfield mResolvedDimensionRatioSide : I
    //   1285: aload_0
    //   1286: getfield mResolvedDimensionRatio : F
    //   1289: aload_0
    //   1290: getfield mHeight : I
    //   1293: i2f
    //   1294: fmul
    //   1295: f2i
    //   1296: istore #9
    //   1298: aload_0
    //   1299: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1302: iconst_1
    //   1303: aaload
    //   1304: astore #24
    //   1306: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1309: astore #25
    //   1311: iload #5
    //   1313: istore #4
    //   1315: iload #7
    //   1317: istore #8
    //   1319: aload #24
    //   1321: aload #25
    //   1323: if_acmpeq -> 1343
    //   1326: iconst_0
    //   1327: istore #12
    //   1329: iconst_4
    //   1330: istore #7
    //   1332: iload #9
    //   1334: istore #5
    //   1336: iload #8
    //   1338: istore #6
    //   1340: goto -> 1498
    //   1343: iload #9
    //   1345: istore #5
    //   1347: goto -> 1461
    //   1350: iload #5
    //   1352: istore #8
    //   1354: aload_0
    //   1355: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1358: iconst_1
    //   1359: aaload
    //   1360: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1363: if_acmpne -> 1453
    //   1366: iload #5
    //   1368: istore #8
    //   1370: iload #7
    //   1372: iconst_3
    //   1373: if_icmpne -> 1453
    //   1376: aload_0
    //   1377: iconst_1
    //   1378: putfield mResolvedDimensionRatioSide : I
    //   1381: aload_0
    //   1382: getfield mDimensionRatioSide : I
    //   1385: iconst_m1
    //   1386: if_icmpne -> 1399
    //   1389: aload_0
    //   1390: fconst_1
    //   1391: aload_0
    //   1392: getfield mResolvedDimensionRatio : F
    //   1395: fdiv
    //   1396: putfield mResolvedDimensionRatio : F
    //   1399: aload_0
    //   1400: getfield mResolvedDimensionRatio : F
    //   1403: aload_0
    //   1404: getfield mWidth : I
    //   1407: i2f
    //   1408: fmul
    //   1409: f2i
    //   1410: istore #5
    //   1412: iload #5
    //   1414: istore #8
    //   1416: aload_0
    //   1417: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1420: iconst_0
    //   1421: aaload
    //   1422: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1425: if_acmpeq -> 1453
    //   1428: iload #5
    //   1430: istore #8
    //   1432: iload #6
    //   1434: istore #7
    //   1436: iconst_0
    //   1437: istore #12
    //   1439: iconst_4
    //   1440: istore #6
    //   1442: iload #4
    //   1444: istore #5
    //   1446: iload #8
    //   1448: istore #4
    //   1450: goto -> 1498
    //   1453: iload #4
    //   1455: istore #5
    //   1457: iload #8
    //   1459: istore #4
    //   1461: iload #6
    //   1463: istore #8
    //   1465: iload #7
    //   1467: istore #6
    //   1469: iconst_1
    //   1470: istore #12
    //   1472: iload #8
    //   1474: istore #7
    //   1476: goto -> 1498
    //   1479: iload #8
    //   1481: istore #6
    //   1483: iload #4
    //   1485: istore #8
    //   1487: iconst_0
    //   1488: istore #12
    //   1490: iload #5
    //   1492: istore #4
    //   1494: iload #8
    //   1496: istore #5
    //   1498: aload_0
    //   1499: getfield mResolvedMatchConstraintDefault : [I
    //   1502: astore #24
    //   1504: aload #24
    //   1506: iconst_0
    //   1507: iload #7
    //   1509: iastore
    //   1510: aload #24
    //   1512: iconst_1
    //   1513: iload #6
    //   1515: iastore
    //   1516: aload_0
    //   1517: iload #12
    //   1519: putfield mResolvedHasRatio : Z
    //   1522: iload #12
    //   1524: ifeq -> 1550
    //   1527: aload_0
    //   1528: getfield mResolvedDimensionRatioSide : I
    //   1531: istore #8
    //   1533: iload #8
    //   1535: ifeq -> 1544
    //   1538: iload #8
    //   1540: iconst_m1
    //   1541: if_icmpne -> 1550
    //   1544: iconst_1
    //   1545: istore #17
    //   1547: goto -> 1553
    //   1550: iconst_0
    //   1551: istore #17
    //   1553: iload #12
    //   1555: ifeq -> 1582
    //   1558: aload_0
    //   1559: getfield mResolvedDimensionRatioSide : I
    //   1562: istore #8
    //   1564: iload #8
    //   1566: iconst_1
    //   1567: if_icmpeq -> 1576
    //   1570: iload #8
    //   1572: iconst_m1
    //   1573: if_icmpne -> 1582
    //   1576: iconst_1
    //   1577: istore #16
    //   1579: goto -> 1585
    //   1582: iconst_0
    //   1583: istore #16
    //   1585: aload_0
    //   1586: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1589: iconst_0
    //   1590: aaload
    //   1591: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1594: if_acmpne -> 1610
    //   1597: aload_0
    //   1598: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   1601: ifeq -> 1610
    //   1604: iconst_1
    //   1605: istore #18
    //   1607: goto -> 1613
    //   1610: iconst_0
    //   1611: istore #18
    //   1613: iload #18
    //   1615: ifeq -> 1624
    //   1618: iconst_0
    //   1619: istore #5
    //   1621: goto -> 1624
    //   1624: aload_0
    //   1625: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1628: invokevirtual isConnected : ()Z
    //   1631: iconst_1
    //   1632: ixor
    //   1633: istore #20
    //   1635: aload_0
    //   1636: getfield mIsInBarrier : [Z
    //   1639: astore #24
    //   1641: aload #24
    //   1643: iconst_0
    //   1644: baload
    //   1645: istore #22
    //   1647: aload #24
    //   1649: iconst_1
    //   1650: baload
    //   1651: istore #21
    //   1653: aload_0
    //   1654: getfield mHorizontalResolution : I
    //   1657: iconst_2
    //   1658: if_icmpeq -> 1993
    //   1661: aload_0
    //   1662: getfield resolvedHorizontal : Z
    //   1665: ifne -> 1993
    //   1668: iload_2
    //   1669: ifeq -> 1797
    //   1672: aload_0
    //   1673: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1676: astore #24
    //   1678: aload #24
    //   1680: ifnull -> 1797
    //   1683: aload #24
    //   1685: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1688: getfield resolved : Z
    //   1691: ifeq -> 1797
    //   1694: aload_0
    //   1695: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1698: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1701: getfield resolved : Z
    //   1704: ifne -> 1710
    //   1707: goto -> 1797
    //   1710: iload_2
    //   1711: ifeq -> 1993
    //   1714: aload_1
    //   1715: aload #28
    //   1717: aload_0
    //   1718: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1721: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1724: getfield value : I
    //   1727: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1730: aload_1
    //   1731: aload #27
    //   1733: aload_0
    //   1734: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1737: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1740: getfield value : I
    //   1743: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1746: aload_0
    //   1747: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1750: ifnull -> 1993
    //   1753: iload #13
    //   1755: ifeq -> 1993
    //   1758: aload_0
    //   1759: getfield isTerminalWidget : [Z
    //   1762: iconst_0
    //   1763: baload
    //   1764: ifeq -> 1993
    //   1767: aload_0
    //   1768: invokevirtual isInHorizontalChain : ()Z
    //   1771: ifne -> 1993
    //   1774: aload_1
    //   1775: aload_1
    //   1776: aload_0
    //   1777: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1780: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1783: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1786: aload #27
    //   1788: iconst_0
    //   1789: bipush #8
    //   1791: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1794: goto -> 1993
    //   1797: aload_0
    //   1798: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1801: astore #24
    //   1803: aload #24
    //   1805: ifnull -> 1822
    //   1808: aload_1
    //   1809: aload #24
    //   1811: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1814: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1817: astore #24
    //   1819: goto -> 1825
    //   1822: aconst_null
    //   1823: astore #24
    //   1825: aload_0
    //   1826: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1829: astore #25
    //   1831: aload #25
    //   1833: ifnull -> 1850
    //   1836: aload_1
    //   1837: aload #25
    //   1839: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1842: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1845: astore #25
    //   1847: goto -> 1853
    //   1850: aconst_null
    //   1851: astore #25
    //   1853: aload_0
    //   1854: getfield isTerminalWidget : [Z
    //   1857: iconst_0
    //   1858: baload
    //   1859: istore #23
    //   1861: aload_0
    //   1862: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1865: astore #31
    //   1867: aload #31
    //   1869: iconst_0
    //   1870: aaload
    //   1871: astore #32
    //   1873: aload_0
    //   1874: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1877: astore #33
    //   1879: aload_0
    //   1880: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1883: astore #34
    //   1885: aload_0
    //   1886: getfield mX : I
    //   1889: istore #8
    //   1891: aload_0
    //   1892: getfield mMinWidth : I
    //   1895: istore #9
    //   1897: aload_0
    //   1898: getfield mMaxDimension : [I
    //   1901: iconst_0
    //   1902: iaload
    //   1903: istore #10
    //   1905: aload_0
    //   1906: getfield mHorizontalBiasPercent : F
    //   1909: fstore_3
    //   1910: aload #31
    //   1912: iconst_1
    //   1913: aaload
    //   1914: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1917: if_acmpne -> 1926
    //   1920: iconst_1
    //   1921: istore #19
    //   1923: goto -> 1929
    //   1926: iconst_0
    //   1927: istore #19
    //   1929: aload_0
    //   1930: aload_1
    //   1931: iconst_1
    //   1932: iload #13
    //   1934: iload #11
    //   1936: iload #23
    //   1938: aload #25
    //   1940: aload #24
    //   1942: aload #32
    //   1944: iload #18
    //   1946: aload #33
    //   1948: aload #34
    //   1950: iload #8
    //   1952: iload #5
    //   1954: iload #9
    //   1956: iload #10
    //   1958: fload_3
    //   1959: iload #17
    //   1961: iload #19
    //   1963: iload #15
    //   1965: iload #14
    //   1967: iload #22
    //   1969: iload #7
    //   1971: iload #6
    //   1973: aload_0
    //   1974: getfield mMatchConstraintMinWidth : I
    //   1977: aload_0
    //   1978: getfield mMatchConstraintMaxWidth : I
    //   1981: aload_0
    //   1982: getfield mMatchConstraintPercentWidth : F
    //   1985: iload #20
    //   1987: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   1990: goto -> 1993
    //   1993: aload #30
    //   1995: astore #25
    //   1997: aload #29
    //   1999: astore #24
    //   2001: iload #11
    //   2003: istore #18
    //   2005: aload #27
    //   2007: astore #29
    //   2009: iload_2
    //   2010: ifeq -> 2189
    //   2013: aload_0
    //   2014: astore #27
    //   2016: aload #27
    //   2018: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2021: astore #30
    //   2023: aload #30
    //   2025: ifnull -> 2186
    //   2028: aload #30
    //   2030: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2033: getfield resolved : Z
    //   2036: ifeq -> 2186
    //   2039: aload #27
    //   2041: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2044: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2047: getfield resolved : Z
    //   2050: ifeq -> 2186
    //   2053: aload #27
    //   2055: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2058: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2061: getfield value : I
    //   2064: istore #5
    //   2066: aload_1
    //   2067: astore #30
    //   2069: aload #30
    //   2071: aload #25
    //   2073: iload #5
    //   2075: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2078: aload #27
    //   2080: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2083: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2086: getfield value : I
    //   2089: istore #5
    //   2091: aload #24
    //   2093: astore #31
    //   2095: aload #30
    //   2097: aload #31
    //   2099: iload #5
    //   2101: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2104: aload #30
    //   2106: aload #26
    //   2108: aload #27
    //   2110: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2113: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2116: getfield value : I
    //   2119: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2122: aload #27
    //   2124: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2127: astore #32
    //   2129: aload #32
    //   2131: ifnull -> 2180
    //   2134: iload #14
    //   2136: ifne -> 2180
    //   2139: iload #18
    //   2141: ifeq -> 2180
    //   2144: aload #27
    //   2146: getfield isTerminalWidget : [Z
    //   2149: iconst_1
    //   2150: baload
    //   2151: ifeq -> 2177
    //   2154: aload #30
    //   2156: aload #30
    //   2158: aload #32
    //   2160: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2163: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2166: aload #31
    //   2168: iconst_0
    //   2169: bipush #8
    //   2171: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2174: goto -> 2180
    //   2177: goto -> 2180
    //   2180: iconst_0
    //   2181: istore #5
    //   2183: goto -> 2192
    //   2186: goto -> 2189
    //   2189: iconst_1
    //   2190: istore #5
    //   2192: aload_0
    //   2193: astore #30
    //   2195: aload_1
    //   2196: astore #31
    //   2198: aload #26
    //   2200: astore #32
    //   2202: aload #30
    //   2204: getfield mVerticalResolution : I
    //   2207: iconst_2
    //   2208: if_icmpne -> 2217
    //   2211: iconst_0
    //   2212: istore #5
    //   2214: goto -> 2217
    //   2217: iload #5
    //   2219: ifeq -> 2634
    //   2222: aload #30
    //   2224: getfield resolvedVertical : Z
    //   2227: ifne -> 2634
    //   2230: aload #30
    //   2232: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2235: iconst_1
    //   2236: aaload
    //   2237: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2240: if_acmpne -> 2256
    //   2243: aload #30
    //   2245: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   2248: ifeq -> 2256
    //   2251: iconst_1
    //   2252: istore_2
    //   2253: goto -> 2258
    //   2256: iconst_0
    //   2257: istore_2
    //   2258: iload_2
    //   2259: ifeq -> 2265
    //   2262: iconst_0
    //   2263: istore #4
    //   2265: aload #30
    //   2267: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2270: astore #26
    //   2272: aload #26
    //   2274: ifnull -> 2292
    //   2277: aload #31
    //   2279: aload #26
    //   2281: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2284: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2287: astore #26
    //   2289: goto -> 2295
    //   2292: aconst_null
    //   2293: astore #26
    //   2295: aload #30
    //   2297: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2300: astore #27
    //   2302: aload #27
    //   2304: ifnull -> 2322
    //   2307: aload #31
    //   2309: aload #27
    //   2311: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2314: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2317: astore #27
    //   2319: goto -> 2325
    //   2322: aconst_null
    //   2323: astore #27
    //   2325: aload #30
    //   2327: getfield mBaselineDistance : I
    //   2330: ifgt -> 2343
    //   2333: aload #30
    //   2335: getfield mVisibility : I
    //   2338: bipush #8
    //   2340: if_icmpne -> 2480
    //   2343: aload #30
    //   2345: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2348: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2351: ifnull -> 2431
    //   2354: aload #31
    //   2356: aload #32
    //   2358: aload #25
    //   2360: aload_0
    //   2361: invokevirtual getBaselineDistance : ()I
    //   2364: bipush #8
    //   2366: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2369: pop
    //   2370: aload #31
    //   2372: aload #32
    //   2374: aload #31
    //   2376: aload #30
    //   2378: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2381: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2384: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2387: aload #30
    //   2389: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2392: invokevirtual getMargin : ()I
    //   2395: bipush #8
    //   2397: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2400: pop
    //   2401: iload #18
    //   2403: ifeq -> 2425
    //   2406: aload #31
    //   2408: aload #26
    //   2410: aload #31
    //   2412: aload #30
    //   2414: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2417: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2420: iconst_0
    //   2421: iconst_5
    //   2422: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2425: iconst_0
    //   2426: istore #11
    //   2428: goto -> 2484
    //   2431: aload #30
    //   2433: getfield mVisibility : I
    //   2436: bipush #8
    //   2438: if_icmpne -> 2464
    //   2441: aload #31
    //   2443: aload #32
    //   2445: aload #25
    //   2447: aload #30
    //   2449: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2452: invokevirtual getMargin : ()I
    //   2455: bipush #8
    //   2457: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2460: pop
    //   2461: goto -> 2480
    //   2464: aload #31
    //   2466: aload #32
    //   2468: aload #25
    //   2470: aload_0
    //   2471: invokevirtual getBaselineDistance : ()I
    //   2474: bipush #8
    //   2476: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2479: pop
    //   2480: iload #20
    //   2482: istore #11
    //   2484: aload #30
    //   2486: getfield isTerminalWidget : [Z
    //   2489: iconst_1
    //   2490: baload
    //   2491: istore #19
    //   2493: aload #30
    //   2495: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2498: astore #31
    //   2500: aload #31
    //   2502: iconst_1
    //   2503: aaload
    //   2504: astore #32
    //   2506: aload #30
    //   2508: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2511: astore #33
    //   2513: aload #30
    //   2515: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2518: astore #34
    //   2520: aload #30
    //   2522: getfield mY : I
    //   2525: istore #5
    //   2527: aload #30
    //   2529: getfield mMinHeight : I
    //   2532: istore #8
    //   2534: aload #30
    //   2536: getfield mMaxDimension : [I
    //   2539: iconst_1
    //   2540: iaload
    //   2541: istore #9
    //   2543: aload #30
    //   2545: getfield mVerticalBiasPercent : F
    //   2548: fstore_3
    //   2549: aload #31
    //   2551: iconst_0
    //   2552: aaload
    //   2553: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2556: if_acmpne -> 2565
    //   2559: iconst_1
    //   2560: istore #17
    //   2562: goto -> 2568
    //   2565: iconst_0
    //   2566: istore #17
    //   2568: aload_0
    //   2569: aload_1
    //   2570: iconst_0
    //   2571: iload #18
    //   2573: iload #13
    //   2575: iload #19
    //   2577: aload #27
    //   2579: aload #26
    //   2581: aload #32
    //   2583: iload_2
    //   2584: aload #33
    //   2586: aload #34
    //   2588: iload #5
    //   2590: iload #4
    //   2592: iload #8
    //   2594: iload #9
    //   2596: fload_3
    //   2597: iload #16
    //   2599: iload #17
    //   2601: iload #14
    //   2603: iload #15
    //   2605: iload #21
    //   2607: iload #6
    //   2609: iload #7
    //   2611: aload #30
    //   2613: getfield mMatchConstraintMinHeight : I
    //   2616: aload #30
    //   2618: getfield mMatchConstraintMaxHeight : I
    //   2621: aload #30
    //   2623: getfield mMatchConstraintPercentHeight : F
    //   2626: iload #11
    //   2628: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2631: goto -> 2634
    //   2634: iload #12
    //   2636: ifeq -> 2695
    //   2639: aload_0
    //   2640: astore #26
    //   2642: aload #26
    //   2644: getfield mResolvedDimensionRatioSide : I
    //   2647: iconst_1
    //   2648: if_icmpne -> 2673
    //   2651: aload_1
    //   2652: aload #24
    //   2654: aload #25
    //   2656: aload #29
    //   2658: aload #28
    //   2660: aload #26
    //   2662: getfield mResolvedDimensionRatio : F
    //   2665: bipush #8
    //   2667: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2670: goto -> 2695
    //   2673: aload_1
    //   2674: aload #29
    //   2676: aload #28
    //   2678: aload #24
    //   2680: aload #25
    //   2682: aload #26
    //   2684: getfield mResolvedDimensionRatio : F
    //   2687: bipush #8
    //   2689: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2692: goto -> 2695
    //   2695: aload_0
    //   2696: astore #24
    //   2698: aload #24
    //   2700: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2703: invokevirtual isConnected : ()Z
    //   2706: ifeq -> 2748
    //   2709: aload_1
    //   2710: aload #24
    //   2712: aload #24
    //   2714: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2717: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2720: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2723: aload #24
    //   2725: getfield mCircleConstraintAngle : F
    //   2728: ldc_w 90.0
    //   2731: fadd
    //   2732: f2d
    //   2733: invokestatic toRadians : (D)D
    //   2736: d2f
    //   2737: aload #24
    //   2739: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2742: invokevirtual getMargin : ()I
    //   2745: invokevirtual addCenterPoint : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget;FI)V
    //   2748: aload #24
    //   2750: iconst_0
    //   2751: putfield resolvedHorizontal : Z
    //   2754: aload #24
    //   2756: iconst_0
    //   2757: putfield resolvedVertical : Z
    //   2760: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    ConstraintAnchor constraintAnchor;
    if (paramType1 == ConstraintAnchor.Type.CENTER) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.TOP);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.BOTTOM);
        boolean bool = true;
        if ((constraintAnchor1 != null && constraintAnchor1.isConnected()) || (constraintAnchor != null && constraintAnchor.isConnected())) {
          paramInt = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0);
          paramInt = 1;
        } 
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0);
        } 
        if (paramInt != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0);
          return;
        } 
        if (paramInt != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0);
          return;
        } 
        if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0);
          return;
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
          return;
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor2 = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor2, 0);
        constraintAnchor.connect(constraintAnchor2, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
      ConstraintAnchor constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
      if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
        if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
          constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
          if (constraintAnchor1 != null)
            constraintAnchor1.reset(); 
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_Y);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_X);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } 
        constraintAnchor3.connect(constraintAnchor2, paramInt);
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapBehaviorInParent() {
    return this.mWrapBehaviorInParent;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDimensionOverride() {
    return (this.mWidthOverride != -1 || this.mHeightOverride != -1);
  }
  
  public boolean hasResolvedTargets(int paramInt1, int paramInt2) {
    if (paramInt1 == 0) {
      if (this.mLeft.mTarget != null && this.mLeft.mTarget.hasFinalValue() && this.mRight.mTarget != null && this.mRight.mTarget.hasFinalValue())
        return (this.mRight.mTarget.getFinalValue() - this.mRight.getMargin() - this.mLeft.mTarget.getFinalValue() + this.mLeft.getMargin() >= paramInt2); 
    } else if (this.mTop.mTarget != null && this.mTop.mTarget.hasFinalValue() && this.mBottom.mTarget != null && this.mBottom.mTarget.hasFinalValue()) {
      return (this.mBottom.mTarget.getFinalValue() - this.mBottom.getMargin() - this.mTop.mTarget.getFinalValue() + this.mTop.getMargin() >= paramInt2);
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isHorizontalSolvingPassDone() {
    return this.horizontalSolvingPass;
  }
  
  public boolean isInBarrier(int paramInt) {
    return this.mIsInBarrier[paramInt];
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtualLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isVerticalSolvingPassDone() {
    return this.verticalSolvingPass;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void markHorizontalSolvingPassDone() {
    this.horizontalSolvingPass = true;
  }
  
  public void markVerticalSolvingPassDone() {
    this.verticalSolvingPass = true;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    return (dimensionBehaviour1 == DimensionBehaviour.MATCH_CONSTRAINT && dimensionBehaviour2 == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (arrayOfDimensionBehaviour[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = bool2;
      if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt2 = this.mMaxDimension;
    arrayOfInt2[0] = Integer.MAX_VALUE;
    arrayOfInt2[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtualLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
    int[] arrayOfInt1 = this.mResolvedMatchConstraintDefault;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    this.mWidthOverride = -1;
    this.mHeightOverride = -1;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++)
      ((ConstraintAnchor)this.mAnchors.get(i)).reset(); 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resetSolvingPassFlag() {
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
  }
  
  public StringBuilder serialize(StringBuilder paramStringBuilder) {
    paramStringBuilder.append("{\n");
    serializeAnchor(paramStringBuilder, "left", this.mLeft);
    serializeAnchor(paramStringBuilder, "top", this.mTop);
    serializeAnchor(paramStringBuilder, "right", this.mRight);
    serializeAnchor(paramStringBuilder, "bottom", this.mBottom);
    serializeAnchor(paramStringBuilder, "baseline", this.mBaseline);
    serializeAnchor(paramStringBuilder, "centerX", this.mCenterX);
    serializeAnchor(paramStringBuilder, "centerY", this.mCenterY);
    serializeCircle(paramStringBuilder, this.mCenter, this.mCircleConstraintAngle);
    serializeSize(paramStringBuilder, "width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    serializeSize(paramStringBuilder, "height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    paramStringBuilder.append("}\n");
    return paramStringBuilder;
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 267
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 267
    //   14: aload_1
    //   15: invokevirtual length : ()I
    //   18: istore #9
    //   20: aload_1
    //   21: bipush #44
    //   23: invokevirtual indexOf : (I)I
    //   26: istore #10
    //   28: iconst_0
    //   29: istore #8
    //   31: iconst_0
    //   32: istore #6
    //   34: iconst_m1
    //   35: istore #7
    //   37: iload #8
    //   39: istore #5
    //   41: iload #7
    //   43: istore #4
    //   45: iload #10
    //   47: ifle -> 120
    //   50: iload #8
    //   52: istore #5
    //   54: iload #7
    //   56: istore #4
    //   58: iload #10
    //   60: iload #9
    //   62: iconst_1
    //   63: isub
    //   64: if_icmpge -> 120
    //   67: aload_1
    //   68: iconst_0
    //   69: iload #10
    //   71: invokevirtual substring : (II)Ljava/lang/String;
    //   74: astore #11
    //   76: aload #11
    //   78: ldc_w 'W'
    //   81: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   84: ifeq -> 94
    //   87: iload #6
    //   89: istore #4
    //   91: goto -> 114
    //   94: aload #11
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 111
    //   105: iconst_1
    //   106: istore #4
    //   108: goto -> 114
    //   111: iconst_m1
    //   112: istore #4
    //   114: iload #10
    //   116: iconst_1
    //   117: iadd
    //   118: istore #5
    //   120: aload_1
    //   121: bipush #58
    //   123: invokevirtual indexOf : (I)I
    //   126: istore #6
    //   128: iload #6
    //   130: iflt -> 225
    //   133: iload #6
    //   135: iload #9
    //   137: iconst_1
    //   138: isub
    //   139: if_icmpge -> 225
    //   142: aload_1
    //   143: iload #5
    //   145: iload #6
    //   147: invokevirtual substring : (II)Ljava/lang/String;
    //   150: astore #11
    //   152: aload_1
    //   153: iload #6
    //   155: iconst_1
    //   156: iadd
    //   157: invokevirtual substring : (I)Ljava/lang/String;
    //   160: astore_1
    //   161: aload #11
    //   163: invokevirtual length : ()I
    //   166: ifle -> 247
    //   169: aload_1
    //   170: invokevirtual length : ()I
    //   173: ifle -> 247
    //   176: aload #11
    //   178: invokestatic parseFloat : (Ljava/lang/String;)F
    //   181: fstore_2
    //   182: aload_1
    //   183: invokestatic parseFloat : (Ljava/lang/String;)F
    //   186: fstore_3
    //   187: fload_2
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 247
    //   193: fload_3
    //   194: fconst_0
    //   195: fcmpl
    //   196: ifle -> 247
    //   199: iload #4
    //   201: iconst_1
    //   202: if_icmpne -> 215
    //   205: fload_3
    //   206: fload_2
    //   207: fdiv
    //   208: invokestatic abs : (F)F
    //   211: fstore_2
    //   212: goto -> 249
    //   215: fload_2
    //   216: fload_3
    //   217: fdiv
    //   218: invokestatic abs : (F)F
    //   221: fstore_2
    //   222: goto -> 249
    //   225: aload_1
    //   226: iload #5
    //   228: invokevirtual substring : (I)Ljava/lang/String;
    //   231: astore_1
    //   232: aload_1
    //   233: invokevirtual length : ()I
    //   236: ifle -> 247
    //   239: aload_1
    //   240: invokestatic parseFloat : (Ljava/lang/String;)F
    //   243: fstore_2
    //   244: goto -> 249
    //   247: fconst_0
    //   248: fstore_2
    //   249: fload_2
    //   250: fconst_0
    //   251: fcmpl
    //   252: ifle -> 266
    //   255: aload_0
    //   256: fload_2
    //   257: putfield mDimensionRatio : F
    //   260: aload_0
    //   261: iload #4
    //   263: putfield mDimensionRatioSide : I
    //   266: return
    //   267: aload_0
    //   268: fconst_0
    //   269: putfield mDimensionRatio : F
    //   272: return
    //   273: astore_1
    //   274: goto -> 247
    // Exception table:
    //   from	to	target	type
    //   176	187	273	java/lang/NumberFormatException
    //   205	212	273	java/lang/NumberFormatException
    //   215	222	273	java/lang/NumberFormatException
    //   239	244	273	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    if (this.resolvedHorizontal)
      return; 
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    if (this.resolvedVertical)
      return; 
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt3 = this.mMinWidth;
    if (paramInt1 < paramInt3)
      this.mWidth = paramInt3; 
    if (this.mMatchConstraintMaxWidth > 0 && this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mWidth = Math.min(this.mWidth, this.mMatchConstraintMaxWidth); 
    if (this.mMatchConstraintMaxHeight > 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mHeight = Math.min(this.mHeight, this.mMatchConstraintMaxHeight); 
    paramInt3 = this.mWidth;
    if (paramInt1 != paramInt3)
      this.mWidthOverride = paramInt3; 
    paramInt1 = this.mHeight;
    if (paramInt2 != paramInt1)
      this.mHeightOverride = paramInt1; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              return; 
            this.mBaseline.mGoneMargin = paramInt;
            return;
          } 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxWidth = paramInt2;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtualLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxHeight = paramInt2;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapBehaviorInParent(int paramInt) {
    if (paramInt >= 0 && paramInt <= 3)
      this.mWrapBehaviorInParent = paramInt; 
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      int i = this.mMatchConstraintMinWidth;
      if (i > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (i == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #7
    //   69: iload #6
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #7
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #6
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #6
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #7
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #7
    //   137: istore #5
    //   139: iload #7
    //   141: ldc 2147483647
    //   143: if_icmpne -> 157
    //   146: iconst_0
    //   147: istore_3
    //   148: iconst_0
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #6
    //   154: iconst_0
    //   155: istore #5
    //   157: iload #6
    //   159: iload_3
    //   160: isub
    //   161: istore #6
    //   163: iload #5
    //   165: iload #4
    //   167: isub
    //   168: istore #5
    //   170: iload #9
    //   172: ifeq -> 180
    //   175: aload_0
    //   176: iload_3
    //   177: putfield mX : I
    //   180: iload #8
    //   182: ifeq -> 191
    //   185: aload_0
    //   186: iload #4
    //   188: putfield mY : I
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 211
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield mWidth : I
    //   205: aload_0
    //   206: iconst_0
    //   207: putfield mHeight : I
    //   210: return
    //   211: iload #9
    //   213: ifeq -> 273
    //   216: iload #6
    //   218: istore_3
    //   219: aload_0
    //   220: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   223: iconst_0
    //   224: aaload
    //   225: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   228: if_acmpne -> 250
    //   231: aload_0
    //   232: getfield mWidth : I
    //   235: istore #4
    //   237: iload #6
    //   239: istore_3
    //   240: iload #6
    //   242: iload #4
    //   244: if_icmpge -> 250
    //   247: iload #4
    //   249: istore_3
    //   250: aload_0
    //   251: iload_3
    //   252: putfield mWidth : I
    //   255: aload_0
    //   256: getfield mMinWidth : I
    //   259: istore #4
    //   261: iload_3
    //   262: iload #4
    //   264: if_icmpge -> 273
    //   267: aload_0
    //   268: iload #4
    //   270: putfield mWidth : I
    //   273: iload #8
    //   275: ifeq -> 335
    //   278: iload #5
    //   280: istore_3
    //   281: aload_0
    //   282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   285: iconst_1
    //   286: aaload
    //   287: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: if_acmpne -> 312
    //   293: aload_0
    //   294: getfield mHeight : I
    //   297: istore #4
    //   299: iload #5
    //   301: istore_3
    //   302: iload #5
    //   304: iload #4
    //   306: if_icmpge -> 312
    //   309: iload #4
    //   311: istore_3
    //   312: aload_0
    //   313: iload_3
    //   314: putfield mHeight : I
    //   317: aload_0
    //   318: getfield mMinHeight : I
    //   321: istore #4
    //   323: iload_3
    //   324: iload #4
    //   326: if_icmpge -> 335
    //   329: aload_0
    //   330: iload #4
    //   332: putfield mHeight : I
    //   335: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 127
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore_1
    //   56: iload #4
    //   58: istore #5
    //   60: iload #6
    //   62: istore_3
    //   63: aload_1
    //   64: ifnull -> 127
    //   67: iload #4
    //   69: istore #5
    //   71: iload #6
    //   73: istore_3
    //   74: aload_1
    //   75: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   78: getfield resolved : Z
    //   81: ifeq -> 127
    //   84: iload #4
    //   86: istore #5
    //   88: iload #6
    //   90: istore_3
    //   91: aload_0
    //   92: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   95: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   98: getfield resolved : Z
    //   101: ifeq -> 127
    //   104: aload_0
    //   105: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   108: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   111: getfield value : I
    //   114: istore #5
    //   116: aload_0
    //   117: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   120: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   123: getfield value : I
    //   126: istore_3
    //   127: iload #7
    //   129: istore #6
    //   131: iload #8
    //   133: istore #4
    //   135: iload_2
    //   136: ifeq -> 219
    //   139: aload_0
    //   140: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   143: astore_1
    //   144: iload #7
    //   146: istore #6
    //   148: iload #8
    //   150: istore #4
    //   152: aload_1
    //   153: ifnull -> 219
    //   156: iload #7
    //   158: istore #6
    //   160: iload #8
    //   162: istore #4
    //   164: aload_1
    //   165: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   168: getfield resolved : Z
    //   171: ifeq -> 219
    //   174: iload #7
    //   176: istore #6
    //   178: iload #8
    //   180: istore #4
    //   182: aload_0
    //   183: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   186: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   189: getfield resolved : Z
    //   192: ifeq -> 219
    //   195: aload_0
    //   196: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   199: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   202: getfield value : I
    //   205: istore #6
    //   207: aload_0
    //   208: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   211: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   214: getfield value : I
    //   217: istore #4
    //   219: iload_3
    //   220: iload #5
    //   222: isub
    //   223: iflt -> 298
    //   226: iload #4
    //   228: iload #6
    //   230: isub
    //   231: iflt -> 298
    //   234: iload #5
    //   236: ldc_w -2147483648
    //   239: if_icmpeq -> 298
    //   242: iload #5
    //   244: ldc 2147483647
    //   246: if_icmpeq -> 298
    //   249: iload #6
    //   251: ldc_w -2147483648
    //   254: if_icmpeq -> 298
    //   257: iload #6
    //   259: ldc 2147483647
    //   261: if_icmpeq -> 298
    //   264: iload_3
    //   265: ldc_w -2147483648
    //   268: if_icmpeq -> 298
    //   271: iload_3
    //   272: ldc 2147483647
    //   274: if_icmpeq -> 298
    //   277: iload #4
    //   279: ldc_w -2147483648
    //   282: if_icmpeq -> 298
    //   285: iload_3
    //   286: istore #7
    //   288: iload #4
    //   290: istore_3
    //   291: iload #4
    //   293: ldc 2147483647
    //   295: if_icmpne -> 309
    //   298: iconst_0
    //   299: istore #5
    //   301: iconst_0
    //   302: istore_3
    //   303: iconst_0
    //   304: istore #6
    //   306: iconst_0
    //   307: istore #7
    //   309: aload_0
    //   310: iload #5
    //   312: iload #6
    //   314: iload #7
    //   316: iload_3
    //   317: invokevirtual setFrame : (IIII)V
    //   320: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      FIXED = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      WRAP_CONTENT = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      MATCH_CONSTRAINT = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour4;
      $VALUES = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */