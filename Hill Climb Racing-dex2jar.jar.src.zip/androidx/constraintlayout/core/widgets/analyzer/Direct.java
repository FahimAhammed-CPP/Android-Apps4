package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ChainHead;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import java.util.ArrayList;
import java.util.Iterator;

public class Direct {
  private static final boolean APPLY_MATCH_PARENT = false;
  
  private static final boolean DEBUG = false;
  
  private static final boolean EARLY_TERMINATION = true;
  
  private static int hcount;
  
  private static BasicMeasure.Measure measure = new BasicMeasure.Measure();
  
  private static int vcount;
  
  static {
    hcount = 0;
    vcount = 0;
  }
  
  private static boolean canMeasure(int paramInt, ConstraintWidget paramConstraintWidget) {
    boolean bool1;
    ConstraintWidgetContainer constraintWidgetContainer;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = paramConstraintWidget.getHorizontalDimensionBehaviour();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = paramConstraintWidget.getVerticalDimensionBehaviour();
    if (paramConstraintWidget.getParent() != null) {
      constraintWidgetContainer = (ConstraintWidgetContainer)paramConstraintWidget.getParent();
    } else {
      constraintWidgetContainer = null;
    } 
    if (constraintWidgetContainer != null) {
      constraintWidgetContainer.getHorizontalDimensionBehaviour();
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
    } 
    if (constraintWidgetContainer != null) {
      constraintWidgetContainer.getVerticalDimensionBehaviour();
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
    } 
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.FIXED;
    boolean bool3 = false;
    if (dimensionBehaviour2 == dimensionBehaviour1 || paramConstraintWidget.isResolvedHorizontally() || dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultWidth == 0 && paramConstraintWidget.mDimensionRatio == 0.0F && paramConstraintWidget.hasDanglingDimension(0)) || (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultWidth == 1 && paramConstraintWidget.hasResolvedTargets(0, paramConstraintWidget.getWidth()))) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.FIXED || paramConstraintWidget.isResolvedVertically() || dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || (dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultHeight == 0 && paramConstraintWidget.mDimensionRatio == 0.0F && paramConstraintWidget.hasDanglingDimension(1)) || (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && paramConstraintWidget.mMatchConstraintDefaultHeight == 1 && paramConstraintWidget.hasResolvedTargets(1, paramConstraintWidget.getHeight()))) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramConstraintWidget.mDimensionRatio > 0.0F && (paramInt != 0 || bool1))
      return true; 
    boolean bool2 = bool3;
    if (paramInt != 0) {
      bool2 = bool3;
      if (bool1)
        bool2 = true; 
    } 
    return bool2;
  }
  
  private static void horizontalSolvingPass(int paramInt, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, boolean paramBoolean) {
    if (paramConstraintWidget.isHorizontalSolvingPassDone())
      return; 
    hcount++;
    if (!(paramConstraintWidget instanceof ConstraintWidgetContainer) && paramConstraintWidget.isMeasureRequested()) {
      int k = paramInt + 1;
      if (canMeasure(k, paramConstraintWidget))
        ConstraintWidgetContainer.measure(k, paramConstraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
    } 
    constraintAnchor2 = paramConstraintWidget.getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor1 = paramConstraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT);
    int j = constraintAnchor2.getFinalValue();
    int i = constraintAnchor1.getFinalValue();
    if (constraintAnchor2.getDependents() != null && constraintAnchor2.hasFinalValue())
      for (ConstraintAnchor constraintAnchor : constraintAnchor2.getDependents()) {
        ConstraintWidget constraintWidget = constraintAnchor.mOwner;
        int k = paramInt + 1;
        boolean bool = canMeasure(k, constraintWidget);
        if (constraintWidget.isMeasureRequested() && bool)
          ConstraintWidgetContainer.measure(k, constraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
        if (constraintWidget.getHorizontalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || bool) {
          if (constraintWidget.isMeasureRequested())
            continue; 
          if (constraintAnchor == constraintWidget.mLeft && constraintWidget.mRight.mTarget == null) {
            int m = constraintWidget.mLeft.getMargin() + j;
            constraintWidget.setFinalHorizontal(m, constraintWidget.getWidth() + m);
            horizontalSolvingPass(k, constraintWidget, paramMeasurer, paramBoolean);
            continue;
          } 
          if (constraintAnchor == constraintWidget.mRight && constraintWidget.mLeft.mTarget == null) {
            int m = j - constraintWidget.mRight.getMargin();
            constraintWidget.setFinalHorizontal(m - constraintWidget.getWidth(), m);
            horizontalSolvingPass(k, constraintWidget, paramMeasurer, paramBoolean);
            continue;
          } 
          if (constraintAnchor == constraintWidget.mLeft && constraintWidget.mRight.mTarget != null && constraintWidget.mRight.mTarget.hasFinalValue() && !constraintWidget.isInHorizontalChain())
            solveHorizontalCenterConstraints(k, paramMeasurer, constraintWidget, paramBoolean); 
          continue;
        } 
        if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintMaxWidth >= 0 && constraintWidget.mMatchConstraintMinWidth >= 0 && (constraintWidget.getVisibility() == 8 || (constraintWidget.mMatchConstraintDefaultWidth == 0 && constraintWidget.getDimensionRatio() == 0.0F)) && !constraintWidget.isInHorizontalChain() && !constraintWidget.isInVirtualLayout()) {
          boolean bool1;
          if ((constraintAnchor == constraintWidget.mLeft && constraintWidget.mRight.mTarget != null && constraintWidget.mRight.mTarget.hasFinalValue()) || (constraintAnchor == constraintWidget.mRight && constraintWidget.mLeft.mTarget != null && constraintWidget.mLeft.mTarget.hasFinalValue())) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (bool1 && !constraintWidget.isInHorizontalChain())
            solveHorizontalMatchConstraint(k, paramConstraintWidget, paramMeasurer, constraintWidget, paramBoolean); 
        } 
      }  
    if (paramConstraintWidget instanceof Guideline)
      return; 
    if (constraintAnchor1.getDependents() != null && constraintAnchor1.hasFinalValue())
      for (ConstraintAnchor constraintAnchor2 : constraintAnchor1.getDependents()) {
        int k;
        ConstraintWidget constraintWidget = constraintAnchor2.mOwner;
        j = paramInt + 1;
        boolean bool = canMeasure(j, constraintWidget);
        if (constraintWidget.isMeasureRequested() && bool)
          ConstraintWidgetContainer.measure(j, constraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
        if ((constraintAnchor2 == constraintWidget.mLeft && constraintWidget.mRight.mTarget != null && constraintWidget.mRight.mTarget.hasFinalValue()) || (constraintAnchor2 == constraintWidget.mRight && constraintWidget.mLeft.mTarget != null && constraintWidget.mLeft.mTarget.hasFinalValue())) {
          k = 1;
        } else {
          k = 0;
        } 
        if (constraintWidget.getHorizontalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || bool) {
          if (constraintWidget.isMeasureRequested())
            continue; 
          if (constraintAnchor2 == constraintWidget.mLeft && constraintWidget.mRight.mTarget == null) {
            k = constraintWidget.mLeft.getMargin() + i;
            constraintWidget.setFinalHorizontal(k, constraintWidget.getWidth() + k);
            horizontalSolvingPass(j, constraintWidget, paramMeasurer, paramBoolean);
            continue;
          } 
          if (constraintAnchor2 == constraintWidget.mRight && constraintWidget.mLeft.mTarget == null) {
            k = i - constraintWidget.mRight.getMargin();
            constraintWidget.setFinalHorizontal(k - constraintWidget.getWidth(), k);
            horizontalSolvingPass(j, constraintWidget, paramMeasurer, paramBoolean);
            continue;
          } 
          if (k != 0 && !constraintWidget.isInHorizontalChain())
            solveHorizontalCenterConstraints(j, paramMeasurer, constraintWidget, paramBoolean); 
          continue;
        } 
        if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintMaxWidth >= 0 && constraintWidget.mMatchConstraintMinWidth >= 0 && (constraintWidget.getVisibility() == 8 || (constraintWidget.mMatchConstraintDefaultWidth == 0 && constraintWidget.getDimensionRatio() == 0.0F)) && !constraintWidget.isInHorizontalChain() && !constraintWidget.isInVirtualLayout() && k != 0 && !constraintWidget.isInHorizontalChain())
          solveHorizontalMatchConstraint(j, paramConstraintWidget, paramMeasurer, constraintWidget, paramBoolean); 
      }  
    paramConstraintWidget.markHorizontalSolvingPassDone();
  }
  
  public static String ls(int paramInt) {
    StringBuilder stringBuilder1 = new StringBuilder();
    for (int i = 0; i < paramInt; i++)
      stringBuilder1.append("  "); 
    StringBuilder stringBuilder2 = new StringBuilder("+-(");
    stringBuilder2.append(paramInt);
    stringBuilder2.append(") ");
    stringBuilder1.append(stringBuilder2.toString());
    return stringBuilder1.toString();
  }
  
  private static void solveBarrier(int paramInt1, Barrier paramBarrier, BasicMeasure.Measurer paramMeasurer, int paramInt2, boolean paramBoolean) {
    if (paramBarrier.allSolved()) {
      if (paramInt2 == 0) {
        horizontalSolvingPass(paramInt1 + 1, (ConstraintWidget)paramBarrier, paramMeasurer, paramBoolean);
        return;
      } 
      verticalSolvingPass(paramInt1 + 1, (ConstraintWidget)paramBarrier, paramMeasurer);
    } 
  }
  
  public static boolean solveChain(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean3)
      return false; 
    if (paramInt1 == 0) {
      if (!paramConstraintWidgetContainer.isResolvedHorizontally())
        return false; 
    } else if (!paramConstraintWidgetContainer.isResolvedVertically()) {
      return false;
    } 
    paramBoolean3 = paramConstraintWidgetContainer.isRtl();
    ConstraintWidget constraintWidget1 = paramChainHead.getFirst();
    ConstraintWidget constraintWidget2 = paramChainHead.getLast();
    ConstraintWidget constraintWidget3 = paramChainHead.getFirstVisibleWidget();
    ConstraintWidget constraintWidget4 = paramChainHead.getLastVisibleWidget();
    ConstraintWidget constraintWidget5 = paramChainHead.getHead();
    ConstraintAnchor constraintAnchor1 = constraintWidget1.mListAnchors[paramInt2];
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget2.mListAnchors;
    int i = paramInt2 + 1;
    ConstraintAnchor constraintAnchor2 = arrayOfConstraintAnchor[i];
    if (constraintAnchor1.mTarget != null) {
      if (constraintAnchor2.mTarget == null)
        return false; 
      if (constraintAnchor1.mTarget.hasFinalValue()) {
        if (!constraintAnchor2.mTarget.hasFinalValue())
          return false; 
        if (constraintWidget3 != null) {
          Object object;
          if (constraintWidget4 == null)
            return false; 
          int m = constraintAnchor1.mTarget.getFinalValue() + constraintWidget3.mListAnchors[paramInt2].getMargin();
          int n = constraintAnchor2.mTarget.getFinalValue() - constraintWidget4.mListAnchors[i].getMargin();
          int i1 = n - m;
          if (i1 <= 0)
            return false; 
          BasicMeasure.Measure measure = new BasicMeasure.Measure();
          ConstraintWidget constraintWidget7 = constraintWidget1;
          int j = 0;
          byte b1 = 0;
          byte b2 = 0;
          int k = 0;
          ConstraintWidget constraintWidget6 = constraintWidget1;
          while (true) {
            ConstraintWidget constraintWidget = null;
            if (!j) {
              if (!canMeasure(1, constraintWidget7))
                return false; 
              if (constraintWidget7.mListDimensionBehaviors[paramInt1] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
                return false; 
              if (constraintWidget7.isMeasureRequested())
                ConstraintWidgetContainer.measure(1, constraintWidget7, paramConstraintWidgetContainer.getMeasurer(), measure, BasicMeasure.Measure.SELF_DIMENSIONS); 
              int i4 = constraintWidget7.mListAnchors[paramInt2].getMargin();
              if (paramInt1 == 0) {
                i3 = constraintWidget7.getWidth();
              } else {
                i3 = constraintWidget7.getHeight();
              } 
              k = k + i4 + i3 + constraintWidget7.mListAnchors[i].getMargin();
              int i3 = object + 1;
              i2 = b1;
              if (constraintWidget7.getVisibility() != 8)
                i2 = b1 + 1; 
              ConstraintAnchor constraintAnchor = (constraintWidget7.mListAnchors[i]).mTarget;
              constraintWidget1 = constraintWidget;
              if (constraintAnchor != null) {
                ConstraintWidget constraintWidget8 = constraintAnchor.mOwner;
                constraintWidget1 = constraintWidget;
                if ((constraintWidget8.mListAnchors[paramInt2]).mTarget != null)
                  if ((constraintWidget8.mListAnchors[paramInt2]).mTarget.mOwner != constraintWidget7) {
                    constraintWidget1 = constraintWidget;
                  } else {
                    constraintWidget1 = constraintWidget8;
                  }  
              } 
              if (constraintWidget1 != null) {
                constraintWidget7 = constraintWidget1;
              } else {
                j = 1;
              } 
              continue;
            } 
            if (b1 == 0)
              return false; 
            if (b1 != i2)
              return false; 
            if (i1 < k)
              return false; 
            int i2 = i1 - k;
            if (paramBoolean1) {
              j = i2 / (b1 + 1);
            } else {
              j = i2;
              if (paramBoolean2) {
                j = i2;
                if (b1 > 2)
                  j = i2 / b1 - 1; 
              } 
            } 
            if (b1 == 1) {
              float f;
              if (paramInt1 == 0) {
                f = constraintWidget5.getHorizontalBiasPercent();
              } else {
                f = constraintWidget5.getVerticalBiasPercent();
              } 
              paramInt2 = (int)(m + 0.5F + j * f);
              if (paramInt1 == 0) {
                constraintWidget3.setFinalHorizontal(paramInt2, constraintWidget3.getWidth() + paramInt2);
              } else {
                constraintWidget3.setFinalVertical(paramInt2, constraintWidget3.getHeight() + paramInt2);
              } 
              horizontalSolvingPass(1, constraintWidget3, paramConstraintWidgetContainer.getMeasurer(), paramBoolean3);
              return true;
            } 
            if (paramBoolean1) {
              i2 = m + j;
              b1 = 0;
              constraintWidget1 = constraintWidget6;
              while (true)
                constraintWidget1 = constraintWidget6; 
            } else if (paramBoolean2) {
              if (b1 == 2) {
                if (paramInt1 == 0) {
                  constraintWidget3.setFinalHorizontal(m, constraintWidget3.getWidth() + m);
                  constraintWidget4.setFinalHorizontal(n - constraintWidget4.getWidth(), n);
                  horizontalSolvingPass(1, constraintWidget3, paramConstraintWidgetContainer.getMeasurer(), paramBoolean3);
                  horizontalSolvingPass(1, constraintWidget4, paramConstraintWidgetContainer.getMeasurer(), paramBoolean3);
                  return true;
                } 
                constraintWidget3.setFinalVertical(m, constraintWidget3.getHeight() + m);
                constraintWidget4.setFinalVertical(n - constraintWidget4.getHeight(), n);
                verticalSolvingPass(1, constraintWidget3, paramConstraintWidgetContainer.getMeasurer());
                verticalSolvingPass(1, constraintWidget4, paramConstraintWidgetContainer.getMeasurer());
                return true;
              } 
              return false;
            } 
            return true;
            b1 = b2;
            object = SYNTHETIC_LOCAL_VARIABLE_13;
          } 
        } 
      } 
    } 
    return false;
  }
  
  private static void solveHorizontalCenterConstraints(int paramInt, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget, boolean paramBoolean) {
    float f = paramConstraintWidget.getHorizontalBiasPercent();
    int i = paramConstraintWidget.mLeft.mTarget.getFinalValue();
    int j = paramConstraintWidget.mRight.mTarget.getFinalValue();
    int m = paramConstraintWidget.mLeft.getMargin();
    int k = paramConstraintWidget.mRight.getMargin();
    if (i == j) {
      f = 0.5F;
    } else {
      i = m + i;
      j -= k;
    } 
    m = paramConstraintWidget.getWidth();
    k = j - i - m;
    if (i > j)
      k = i - j - m; 
    if (k > 0) {
      f = f * k + 0.5F;
    } else {
      f *= k;
    } 
    int n = (int)f + i;
    k = n + m;
    if (i > j)
      k = n - m; 
    paramConstraintWidget.setFinalHorizontal(n, k);
    horizontalSolvingPass(paramInt + 1, paramConstraintWidget, paramMeasurer, paramBoolean);
  }
  
  private static void solveHorizontalMatchConstraint(int paramInt, ConstraintWidget paramConstraintWidget1, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget2, boolean paramBoolean) {
    float f = paramConstraintWidget2.getHorizontalBiasPercent();
    int i = paramConstraintWidget2.mLeft.mTarget.getFinalValue() + paramConstraintWidget2.mLeft.getMargin();
    int j = paramConstraintWidget2.mRight.mTarget.getFinalValue() - paramConstraintWidget2.mRight.getMargin();
    if (j >= i) {
      int m = paramConstraintWidget2.getWidth();
      int k = m;
      if (paramConstraintWidget2.getVisibility() != 8) {
        if (paramConstraintWidget2.mMatchConstraintDefaultWidth == 2) {
          if (paramConstraintWidget1 instanceof ConstraintWidgetContainer) {
            k = paramConstraintWidget1.getWidth();
          } else {
            k = paramConstraintWidget1.getParent().getWidth();
          } 
          k = (int)(paramConstraintWidget2.getHorizontalBiasPercent() * 0.5F * k);
        } else {
          k = m;
          if (paramConstraintWidget2.mMatchConstraintDefaultWidth == 0)
            k = j - i; 
        } 
        m = Math.max(paramConstraintWidget2.mMatchConstraintMinWidth, k);
        k = m;
        if (paramConstraintWidget2.mMatchConstraintMaxWidth > 0)
          k = Math.min(paramConstraintWidget2.mMatchConstraintMaxWidth, m); 
      } 
      m = i + (int)(f * (j - i - k) + 0.5F);
      paramConstraintWidget2.setFinalHorizontal(m, k + m);
      horizontalSolvingPass(paramInt + 1, paramConstraintWidget2, paramMeasurer, paramBoolean);
    } 
  }
  
  private static void solveVerticalCenterConstraints(int paramInt, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget) {
    float f = paramConstraintWidget.getVerticalBiasPercent();
    int i = paramConstraintWidget.mTop.mTarget.getFinalValue();
    int j = paramConstraintWidget.mBottom.mTarget.getFinalValue();
    int m = paramConstraintWidget.mTop.getMargin();
    int k = paramConstraintWidget.mBottom.getMargin();
    if (i == j) {
      f = 0.5F;
    } else {
      i = m + i;
      j -= k;
    } 
    int n = paramConstraintWidget.getHeight();
    k = j - i - n;
    if (i > j)
      k = i - j - n; 
    if (k > 0) {
      f = f * k + 0.5F;
    } else {
      f *= k;
    } 
    int i1 = (int)f;
    k = i + i1;
    m = k + n;
    if (i > j) {
      k = i - i1;
      m = k - n;
    } 
    paramConstraintWidget.setFinalVertical(k, m);
    verticalSolvingPass(paramInt + 1, paramConstraintWidget, paramMeasurer);
  }
  
  private static void solveVerticalMatchConstraint(int paramInt, ConstraintWidget paramConstraintWidget1, BasicMeasure.Measurer paramMeasurer, ConstraintWidget paramConstraintWidget2) {
    float f = paramConstraintWidget2.getVerticalBiasPercent();
    int i = paramConstraintWidget2.mTop.mTarget.getFinalValue() + paramConstraintWidget2.mTop.getMargin();
    int j = paramConstraintWidget2.mBottom.mTarget.getFinalValue() - paramConstraintWidget2.mBottom.getMargin();
    if (j >= i) {
      int m = paramConstraintWidget2.getHeight();
      int k = m;
      if (paramConstraintWidget2.getVisibility() != 8) {
        if (paramConstraintWidget2.mMatchConstraintDefaultHeight == 2) {
          if (paramConstraintWidget1 instanceof ConstraintWidgetContainer) {
            k = paramConstraintWidget1.getHeight();
          } else {
            k = paramConstraintWidget1.getParent().getHeight();
          } 
          k = (int)(f * 0.5F * k);
        } else {
          k = m;
          if (paramConstraintWidget2.mMatchConstraintDefaultHeight == 0)
            k = j - i; 
        } 
        m = Math.max(paramConstraintWidget2.mMatchConstraintMinHeight, k);
        k = m;
        if (paramConstraintWidget2.mMatchConstraintMaxHeight > 0)
          k = Math.min(paramConstraintWidget2.mMatchConstraintMaxHeight, m); 
      } 
      m = i + (int)(f * (j - i - k) + 0.5F);
      paramConstraintWidget2.setFinalVertical(m, k + m);
      verticalSolvingPass(paramInt + 1, paramConstraintWidget2, paramMeasurer);
    } 
  }
  
  public static void solvingPass(ConstraintWidgetContainer paramConstraintWidgetContainer, BasicMeasure.Measurer paramMeasurer) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = paramConstraintWidgetContainer.getHorizontalDimensionBehaviour();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramConstraintWidgetContainer.getVerticalDimensionBehaviour();
    hcount = 0;
    vcount = 0;
    paramConstraintWidgetContainer.resetFinalResolution();
    ArrayList<ConstraintWidget> arrayList = paramConstraintWidgetContainer.getChildren();
    int k = arrayList.size();
    int i;
    for (i = 0; i < k; i++)
      ((ConstraintWidget)arrayList.get(i)).resetFinalResolution(); 
    boolean bool1 = paramConstraintWidgetContainer.isRtl();
    if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.FIXED) {
      paramConstraintWidgetContainer.setFinalHorizontal(0, paramConstraintWidgetContainer.getWidth());
    } else {
      paramConstraintWidgetContainer.setFinalLeft(0);
    } 
    int j = 0;
    boolean bool = false;
    for (i = 0; j < k; i = m) {
      boolean bool2;
      int m;
      Guideline guideline;
      ConstraintWidget constraintWidget = arrayList.get(j);
      if (constraintWidget instanceof Guideline) {
        guideline = (Guideline)constraintWidget;
        bool2 = bool;
        m = i;
        if (guideline.getOrientation() == 1) {
          if (guideline.getRelativeBegin() != -1) {
            guideline.setFinalValue(guideline.getRelativeBegin());
          } else if (guideline.getRelativeEnd() != -1 && paramConstraintWidgetContainer.isResolvedHorizontally()) {
            guideline.setFinalValue(paramConstraintWidgetContainer.getWidth() - guideline.getRelativeEnd());
          } else if (paramConstraintWidgetContainer.isResolvedHorizontally()) {
            guideline.setFinalValue((int)(guideline.getRelativePercent() * paramConstraintWidgetContainer.getWidth() + 0.5F));
          } 
          bool2 = true;
          m = i;
        } 
      } else {
        bool2 = bool;
        m = i;
        if (guideline instanceof Barrier) {
          bool2 = bool;
          m = i;
          if (((Barrier)guideline).getOrientation() == 0) {
            m = 1;
            bool2 = bool;
          } 
        } 
      } 
      j++;
      bool = bool2;
    } 
    if (bool)
      for (j = 0; j < k; j++) {
        ConstraintWidget constraintWidget = arrayList.get(j);
        if (constraintWidget instanceof Guideline) {
          Guideline guideline = (Guideline)constraintWidget;
          if (guideline.getOrientation() == 1)
            horizontalSolvingPass(0, (ConstraintWidget)guideline, paramMeasurer, bool1); 
        } 
      }  
    horizontalSolvingPass(0, (ConstraintWidget)paramConstraintWidgetContainer, paramMeasurer, bool1);
    if (i != 0)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = arrayList.get(i);
        if (constraintWidget instanceof Barrier) {
          Barrier barrier = (Barrier)constraintWidget;
          if (barrier.getOrientation() == 0)
            solveBarrier(0, barrier, paramMeasurer, 0, bool1); 
        } 
      }  
    if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.FIXED) {
      paramConstraintWidgetContainer.setFinalVertical(0, paramConstraintWidgetContainer.getHeight());
    } else {
      paramConstraintWidgetContainer.setFinalTop(0);
    } 
    j = 0;
    bool = false;
    for (i = 0; j < k; i = m) {
      boolean bool2;
      int m;
      Guideline guideline;
      ConstraintWidget constraintWidget = arrayList.get(j);
      if (constraintWidget instanceof Guideline) {
        guideline = (Guideline)constraintWidget;
        bool2 = bool;
        m = i;
        if (guideline.getOrientation() == 0) {
          if (guideline.getRelativeBegin() != -1) {
            guideline.setFinalValue(guideline.getRelativeBegin());
          } else if (guideline.getRelativeEnd() != -1 && paramConstraintWidgetContainer.isResolvedVertically()) {
            guideline.setFinalValue(paramConstraintWidgetContainer.getHeight() - guideline.getRelativeEnd());
          } else if (paramConstraintWidgetContainer.isResolvedVertically()) {
            guideline.setFinalValue((int)(guideline.getRelativePercent() * paramConstraintWidgetContainer.getHeight() + 0.5F));
          } 
          bool2 = true;
          m = i;
        } 
      } else {
        bool2 = bool;
        m = i;
        if (guideline instanceof Barrier) {
          bool2 = bool;
          m = i;
          if (((Barrier)guideline).getOrientation() == 1) {
            m = 1;
            bool2 = bool;
          } 
        } 
      } 
      j++;
      bool = bool2;
    } 
    if (bool)
      for (j = 0; j < k; j++) {
        ConstraintWidget constraintWidget = arrayList.get(j);
        if (constraintWidget instanceof Guideline) {
          Guideline guideline = (Guideline)constraintWidget;
          if (guideline.getOrientation() == 0)
            verticalSolvingPass(1, (ConstraintWidget)guideline, paramMeasurer); 
        } 
      }  
    verticalSolvingPass(0, (ConstraintWidget)paramConstraintWidgetContainer, paramMeasurer);
    if (i != 0)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = arrayList.get(i);
        if (constraintWidget instanceof Barrier) {
          Barrier barrier = (Barrier)constraintWidget;
          if (barrier.getOrientation() == 1)
            solveBarrier(0, barrier, paramMeasurer, 1, bool1); 
        } 
      }  
    for (i = 0; i < k; i++) {
      ConstraintWidget constraintWidget = arrayList.get(i);
      if (constraintWidget.isMeasureRequested() && canMeasure(0, constraintWidget)) {
        ConstraintWidgetContainer.measure(0, constraintWidget, paramMeasurer, measure, BasicMeasure.Measure.SELF_DIMENSIONS);
        if (constraintWidget instanceof Guideline) {
          if (((Guideline)constraintWidget).getOrientation() == 0) {
            verticalSolvingPass(0, constraintWidget, paramMeasurer);
          } else {
            horizontalSolvingPass(0, constraintWidget, paramMeasurer, bool1);
          } 
        } else {
          horizontalSolvingPass(0, constraintWidget, paramMeasurer, bool1);
          verticalSolvingPass(0, constraintWidget, paramMeasurer);
        } 
      } 
    } 
  }
  
  private static void verticalSolvingPass(int paramInt, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer) {
    if (paramConstraintWidget.isVerticalSolvingPassDone())
      return; 
    vcount++;
    if (!(paramConstraintWidget instanceof ConstraintWidgetContainer) && paramConstraintWidget.isMeasureRequested()) {
      int k = paramInt + 1;
      if (canMeasure(k, paramConstraintWidget))
        ConstraintWidgetContainer.measure(k, paramConstraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
    } 
    constraintAnchor2 = paramConstraintWidget.getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor1 = paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM);
    int j = constraintAnchor2.getFinalValue();
    int i = constraintAnchor1.getFinalValue();
    if (constraintAnchor2.getDependents() != null && constraintAnchor2.hasFinalValue())
      for (ConstraintAnchor constraintAnchor : constraintAnchor2.getDependents()) {
        ConstraintWidget constraintWidget = constraintAnchor.mOwner;
        int k = paramInt + 1;
        boolean bool = canMeasure(k, constraintWidget);
        if (constraintWidget.isMeasureRequested() && bool)
          ConstraintWidgetContainer.measure(k, constraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
        if (constraintWidget.getVerticalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || bool) {
          if (constraintWidget.isMeasureRequested())
            continue; 
          if (constraintAnchor == constraintWidget.mTop && constraintWidget.mBottom.mTarget == null) {
            int m = constraintWidget.mTop.getMargin() + j;
            constraintWidget.setFinalVertical(m, constraintWidget.getHeight() + m);
            verticalSolvingPass(k, constraintWidget, paramMeasurer);
            continue;
          } 
          if (constraintAnchor == constraintWidget.mBottom && constraintWidget.mBottom.mTarget == null) {
            int m = j - constraintWidget.mBottom.getMargin();
            constraintWidget.setFinalVertical(m - constraintWidget.getHeight(), m);
            verticalSolvingPass(k, constraintWidget, paramMeasurer);
            continue;
          } 
          if (constraintAnchor == constraintWidget.mTop && constraintWidget.mBottom.mTarget != null && constraintWidget.mBottom.mTarget.hasFinalValue())
            solveVerticalCenterConstraints(k, paramMeasurer, constraintWidget); 
          continue;
        } 
        if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintMaxHeight >= 0 && constraintWidget.mMatchConstraintMinHeight >= 0 && (constraintWidget.getVisibility() == 8 || (constraintWidget.mMatchConstraintDefaultHeight == 0 && constraintWidget.getDimensionRatio() == 0.0F)) && !constraintWidget.isInVerticalChain() && !constraintWidget.isInVirtualLayout()) {
          boolean bool1;
          if ((constraintAnchor == constraintWidget.mTop && constraintWidget.mBottom.mTarget != null && constraintWidget.mBottom.mTarget.hasFinalValue()) || (constraintAnchor == constraintWidget.mBottom && constraintWidget.mTop.mTarget != null && constraintWidget.mTop.mTarget.hasFinalValue())) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (bool1 && !constraintWidget.isInVerticalChain())
            solveVerticalMatchConstraint(k, paramConstraintWidget, paramMeasurer, constraintWidget); 
        } 
      }  
    if (paramConstraintWidget instanceof Guideline)
      return; 
    if (constraintAnchor1.getDependents() != null && constraintAnchor1.hasFinalValue())
      for (ConstraintAnchor constraintAnchor2 : constraintAnchor1.getDependents()) {
        int k;
        ConstraintWidget constraintWidget = constraintAnchor2.mOwner;
        j = paramInt + 1;
        boolean bool = canMeasure(j, constraintWidget);
        if (constraintWidget.isMeasureRequested() && bool)
          ConstraintWidgetContainer.measure(j, constraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
        if ((constraintAnchor2 == constraintWidget.mTop && constraintWidget.mBottom.mTarget != null && constraintWidget.mBottom.mTarget.hasFinalValue()) || (constraintAnchor2 == constraintWidget.mBottom && constraintWidget.mTop.mTarget != null && constraintWidget.mTop.mTarget.hasFinalValue())) {
          k = 1;
        } else {
          k = 0;
        } 
        if (constraintWidget.getVerticalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || bool) {
          if (constraintWidget.isMeasureRequested())
            continue; 
          if (constraintAnchor2 == constraintWidget.mTop && constraintWidget.mBottom.mTarget == null) {
            k = constraintWidget.mTop.getMargin() + i;
            constraintWidget.setFinalVertical(k, constraintWidget.getHeight() + k);
            verticalSolvingPass(j, constraintWidget, paramMeasurer);
            continue;
          } 
          if (constraintAnchor2 == constraintWidget.mBottom && constraintWidget.mTop.mTarget == null) {
            k = i - constraintWidget.mBottom.getMargin();
            constraintWidget.setFinalVertical(k - constraintWidget.getHeight(), k);
            verticalSolvingPass(j, constraintWidget, paramMeasurer);
            continue;
          } 
          if (k != 0 && !constraintWidget.isInVerticalChain())
            solveVerticalCenterConstraints(j, paramMeasurer, constraintWidget); 
          continue;
        } 
        if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintMaxHeight >= 0 && constraintWidget.mMatchConstraintMinHeight >= 0 && (constraintWidget.getVisibility() == 8 || (constraintWidget.mMatchConstraintDefaultHeight == 0 && constraintWidget.getDimensionRatio() == 0.0F)) && !constraintWidget.isInVerticalChain() && !constraintWidget.isInVirtualLayout() && k != 0 && !constraintWidget.isInVerticalChain())
          solveVerticalMatchConstraint(j, paramConstraintWidget, paramMeasurer, constraintWidget); 
      }  
    constraintAnchor1 = paramConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE);
    if (constraintAnchor1.getDependents() != null && constraintAnchor1.hasFinalValue()) {
      int k = constraintAnchor1.getFinalValue();
      Iterator<ConstraintAnchor> iterator = constraintAnchor1.getDependents().iterator();
      while (true) {
        if (iterator.hasNext()) {
          constraintAnchor2 = iterator.next();
          ConstraintWidget constraintWidget = constraintAnchor2.mOwner;
          i = paramInt + 1;
          boolean bool = canMeasure(i, constraintWidget);
          if (constraintWidget.isMeasureRequested() && bool)
            ConstraintWidgetContainer.measure(i, constraintWidget, paramMeasurer, new BasicMeasure.Measure(), BasicMeasure.Measure.SELF_DIMENSIONS); 
          if ((constraintWidget.getVerticalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || bool) && !constraintWidget.isMeasureRequested() && constraintAnchor2 == constraintWidget.mBaseline) {
            constraintWidget.setFinalBaseline(constraintAnchor2.getMargin() + k);
            try {
              verticalSolvingPass(i, constraintWidget, paramMeasurer);
            } finally {}
          } 
          continue;
        } 
        paramConstraintWidget.markVerticalSolvingPassDone();
        return;
      } 
    } 
    paramConstraintWidget.markVerticalSolvingPassDone();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\Direct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */