package androidx.constraintlayout.core.widgets.analyzer;

public interface Dependency {
  void update(Dependency paramDependency);
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\Dependency.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */