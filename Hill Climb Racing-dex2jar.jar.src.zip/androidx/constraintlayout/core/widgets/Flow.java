package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;
import java.util.HashMap;

public class Flow extends VirtualLayout {
  public static final int HORIZONTAL_ALIGN_CENTER = 2;
  
  public static final int HORIZONTAL_ALIGN_END = 1;
  
  public static final int HORIZONTAL_ALIGN_START = 0;
  
  public static final int VERTICAL_ALIGN_BASELINE = 3;
  
  public static final int VERTICAL_ALIGN_BOTTOM = 1;
  
  public static final int VERTICAL_ALIGN_CENTER = 2;
  
  public static final int VERTICAL_ALIGN_TOP = 0;
  
  public static final int WRAP_ALIGNED = 2;
  
  public static final int WRAP_CHAIN = 1;
  
  public static final int WRAP_NONE = 0;
  
  private ConstraintWidget[] mAlignedBiggestElementsInCols = null;
  
  private ConstraintWidget[] mAlignedBiggestElementsInRows = null;
  
  private int[] mAlignedDimensions = null;
  
  private ArrayList<WidgetsList> mChainList = new ArrayList<WidgetsList>();
  
  private ConstraintWidget[] mDisplayedWidgets;
  
  private int mDisplayedWidgetsCount = 0;
  
  private float mFirstHorizontalBias = 0.5F;
  
  private int mFirstHorizontalStyle = -1;
  
  private float mFirstVerticalBias = 0.5F;
  
  private int mFirstVerticalStyle = -1;
  
  private int mHorizontalAlign = 2;
  
  private float mHorizontalBias = 0.5F;
  
  private int mHorizontalGap = 0;
  
  private int mHorizontalStyle = -1;
  
  private float mLastHorizontalBias = 0.5F;
  
  private int mLastHorizontalStyle = -1;
  
  private float mLastVerticalBias = 0.5F;
  
  private int mLastVerticalStyle = -1;
  
  private int mMaxElementsWrap = -1;
  
  private int mOrientation = 0;
  
  private int mVerticalAlign = 2;
  
  private float mVerticalBias = 0.5F;
  
  private int mVerticalGap = 0;
  
  private int mVerticalStyle = -1;
  
  private int mWrapMode = 0;
  
  private void createAlignedConstraints(boolean paramBoolean) {
    if (this.mAlignedDimensions != null && this.mAlignedBiggestElementsInCols != null) {
      ConstraintWidget constraintWidget;
      if (this.mAlignedBiggestElementsInRows == null)
        return; 
      int i;
      for (i = 0; i < this.mDisplayedWidgetsCount; i++)
        this.mDisplayedWidgets[i].resetAnchors(); 
      int[] arrayOfInt = this.mAlignedDimensions;
      int j = arrayOfInt[0];
      int k = arrayOfInt[1];
      float f = this.mHorizontalBias;
      arrayOfInt = null;
      i = 0;
      while (i < j) {
        int m;
        ConstraintWidget constraintWidget1;
        if (paramBoolean) {
          m = j - i - 1;
          f = 1.0F - this.mHorizontalBias;
        } else {
          m = i;
        } 
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[m];
        int[] arrayOfInt1 = arrayOfInt;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            arrayOfInt1 = arrayOfInt;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, this.mLeft, getPaddingLeft());
              constraintWidget2.setHorizontalChainStyle(this.mHorizontalStyle);
              constraintWidget2.setHorizontalBiasPercent(f);
            } 
            if (i == j - 1)
              constraintWidget2.connect(constraintWidget2.mRight, this.mRight, getPaddingRight()); 
            if (i > 0 && arrayOfInt != null) {
              constraintWidget2.connect(constraintWidget2.mLeft, ((ConstraintWidget)arrayOfInt).mRight, this.mHorizontalGap);
              arrayOfInt.connect(((ConstraintWidget)arrayOfInt).mRight, constraintWidget2.mLeft, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      i = 0;
      while (i < k) {
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInRows[i];
        ConstraintWidget constraintWidget1 = constraintWidget;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            constraintWidget1 = constraintWidget;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mTop, this.mTop, getPaddingTop());
              constraintWidget2.setVerticalChainStyle(this.mVerticalStyle);
              constraintWidget2.setVerticalBiasPercent(this.mVerticalBias);
            } 
            if (i == k - 1)
              constraintWidget2.connect(constraintWidget2.mBottom, this.mBottom, getPaddingBottom()); 
            if (i > 0 && constraintWidget != null) {
              constraintWidget2.connect(constraintWidget2.mTop, constraintWidget.mBottom, this.mVerticalGap);
              constraintWidget.connect(constraintWidget.mBottom, constraintWidget2.mTop, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      for (i = 0; i < j; i++) {
        int m;
        for (m = 0; m < k; m++) {
          int n = m * j + i;
          if (this.mOrientation == 1)
            n = i * k + m; 
          ConstraintWidget[] arrayOfConstraintWidget = this.mDisplayedWidgets;
          if (n < arrayOfConstraintWidget.length) {
            ConstraintWidget constraintWidget1 = arrayOfConstraintWidget[n];
            if (constraintWidget1 != null && constraintWidget1.getVisibility() != 8) {
              ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[i];
              ConstraintWidget constraintWidget3 = this.mAlignedBiggestElementsInRows[m];
              if (constraintWidget1 != constraintWidget2) {
                constraintWidget1.connect(constraintWidget1.mLeft, constraintWidget2.mLeft, 0);
                constraintWidget1.connect(constraintWidget1.mRight, constraintWidget2.mRight, 0);
              } 
              if (constraintWidget1 != constraintWidget3) {
                constraintWidget1.connect(constraintWidget1.mTop, constraintWidget3.mTop, 0);
                constraintWidget1.connect(constraintWidget1.mBottom, constraintWidget3.mBottom, 0);
              } 
            } 
          } 
        } 
      } 
    } 
  }
  
  private final int getWidgetHeight(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentHeight * paramInt);
        if (paramInt != paramConstraintWidget.getHeight()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, paramConstraintWidget.getHorizontalDimensionBehaviour(), paramConstraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, paramInt);
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 1)
        return paramConstraintWidget.getHeight(); 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 3)
        return (int)(paramConstraintWidget.getWidth() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getHeight();
  }
  
  private final int getWidgetWidth(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentWidth * paramInt);
        if (paramInt != paramConstraintWidget.getWidth()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, paramInt, paramConstraintWidget.getVerticalDimensionBehaviour(), paramConstraintWidget.getHeight());
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 1)
        return paramConstraintWidget.getWidth(); 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 3)
        return (int)(paramConstraintWidget.getHeight() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getWidth();
  }
  
  private void measureAligned(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 126
    //   4: aload_0
    //   5: getfield mMaxElementsWrap : I
    //   8: istore #6
    //   10: iload #6
    //   12: istore #8
    //   14: iload #6
    //   16: ifgt -> 116
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #9
    //   25: iconst_0
    //   26: istore #7
    //   28: iload #6
    //   30: istore #8
    //   32: iload #9
    //   34: iload_2
    //   35: if_icmpge -> 116
    //   38: iload #7
    //   40: istore #8
    //   42: iload #9
    //   44: ifle -> 56
    //   47: iload #7
    //   49: aload_0
    //   50: getfield mHorizontalGap : I
    //   53: iadd
    //   54: istore #8
    //   56: aload_1
    //   57: iload #9
    //   59: aaload
    //   60: astore #13
    //   62: aload #13
    //   64: ifnonnull -> 74
    //   67: iload #8
    //   69: istore #7
    //   71: goto -> 107
    //   74: iload #8
    //   76: aload_0
    //   77: aload #13
    //   79: iload #4
    //   81: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   84: iadd
    //   85: istore #7
    //   87: iload #7
    //   89: iload #4
    //   91: if_icmple -> 101
    //   94: iload #6
    //   96: istore #8
    //   98: goto -> 116
    //   101: iload #6
    //   103: iconst_1
    //   104: iadd
    //   105: istore #6
    //   107: iload #9
    //   109: iconst_1
    //   110: iadd
    //   111: istore #9
    //   113: goto -> 28
    //   116: iload #8
    //   118: istore #7
    //   120: iconst_0
    //   121: istore #6
    //   123: goto -> 245
    //   126: aload_0
    //   127: getfield mMaxElementsWrap : I
    //   130: istore #6
    //   132: iload #6
    //   134: istore #8
    //   136: iload #6
    //   138: ifgt -> 238
    //   141: iconst_0
    //   142: istore #6
    //   144: iconst_0
    //   145: istore #9
    //   147: iconst_0
    //   148: istore #7
    //   150: iload #6
    //   152: istore #8
    //   154: iload #9
    //   156: iload_2
    //   157: if_icmpge -> 238
    //   160: iload #7
    //   162: istore #8
    //   164: iload #9
    //   166: ifle -> 178
    //   169: iload #7
    //   171: aload_0
    //   172: getfield mVerticalGap : I
    //   175: iadd
    //   176: istore #8
    //   178: aload_1
    //   179: iload #9
    //   181: aaload
    //   182: astore #13
    //   184: aload #13
    //   186: ifnonnull -> 196
    //   189: iload #8
    //   191: istore #7
    //   193: goto -> 229
    //   196: iload #8
    //   198: aload_0
    //   199: aload #13
    //   201: iload #4
    //   203: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   206: iadd
    //   207: istore #7
    //   209: iload #7
    //   211: iload #4
    //   213: if_icmple -> 223
    //   216: iload #6
    //   218: istore #8
    //   220: goto -> 238
    //   223: iload #6
    //   225: iconst_1
    //   226: iadd
    //   227: istore #6
    //   229: iload #9
    //   231: iconst_1
    //   232: iadd
    //   233: istore #9
    //   235: goto -> 150
    //   238: iconst_0
    //   239: istore #7
    //   241: iload #8
    //   243: istore #6
    //   245: aload_0
    //   246: getfield mAlignedDimensions : [I
    //   249: ifnonnull -> 259
    //   252: aload_0
    //   253: iconst_2
    //   254: newarray int
    //   256: putfield mAlignedDimensions : [I
    //   259: iload #6
    //   261: ifne -> 277
    //   264: iload #6
    //   266: istore #11
    //   268: iload #7
    //   270: istore #9
    //   272: iload_3
    //   273: iconst_1
    //   274: if_icmpeq -> 294
    //   277: iload #7
    //   279: ifne -> 308
    //   282: iload_3
    //   283: ifne -> 308
    //   286: iload #7
    //   288: istore #9
    //   290: iload #6
    //   292: istore #11
    //   294: iconst_1
    //   295: istore #12
    //   297: iload #11
    //   299: istore #6
    //   301: iload #9
    //   303: istore #7
    //   305: goto -> 311
    //   308: iconst_0
    //   309: istore #12
    //   311: iload #12
    //   313: ifne -> 844
    //   316: iload_3
    //   317: ifne -> 336
    //   320: iload_2
    //   321: i2f
    //   322: iload #7
    //   324: i2f
    //   325: fdiv
    //   326: f2d
    //   327: invokestatic ceil : (D)D
    //   330: d2i
    //   331: istore #6
    //   333: goto -> 349
    //   336: iload_2
    //   337: i2f
    //   338: iload #6
    //   340: i2f
    //   341: fdiv
    //   342: f2d
    //   343: invokestatic ceil : (D)D
    //   346: d2i
    //   347: istore #7
    //   349: aload_0
    //   350: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   353: astore #13
    //   355: aload #13
    //   357: ifnull -> 380
    //   360: aload #13
    //   362: arraylength
    //   363: iload #7
    //   365: if_icmpge -> 371
    //   368: goto -> 380
    //   371: aload #13
    //   373: aconst_null
    //   374: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   377: goto -> 389
    //   380: aload_0
    //   381: iload #7
    //   383: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   386: putfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   389: aload_0
    //   390: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   393: astore #13
    //   395: aload #13
    //   397: ifnull -> 420
    //   400: aload #13
    //   402: arraylength
    //   403: iload #6
    //   405: if_icmpge -> 411
    //   408: goto -> 420
    //   411: aload #13
    //   413: aconst_null
    //   414: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   417: goto -> 429
    //   420: aload_0
    //   421: iload #6
    //   423: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   426: putfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   429: iconst_0
    //   430: istore #8
    //   432: iload #8
    //   434: iload #7
    //   436: if_icmpge -> 602
    //   439: iconst_0
    //   440: istore #9
    //   442: iload #9
    //   444: iload #6
    //   446: if_icmpge -> 593
    //   449: iload #9
    //   451: iload #7
    //   453: imul
    //   454: iload #8
    //   456: iadd
    //   457: istore #10
    //   459: iload_3
    //   460: iconst_1
    //   461: if_icmpne -> 474
    //   464: iload #8
    //   466: iload #6
    //   468: imul
    //   469: iload #9
    //   471: iadd
    //   472: istore #10
    //   474: iload #10
    //   476: aload_1
    //   477: arraylength
    //   478: if_icmplt -> 484
    //   481: goto -> 584
    //   484: aload_1
    //   485: iload #10
    //   487: aaload
    //   488: astore #13
    //   490: aload #13
    //   492: ifnonnull -> 498
    //   495: goto -> 584
    //   498: aload_0
    //   499: aload #13
    //   501: iload #4
    //   503: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   506: istore #10
    //   508: aload_0
    //   509: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   512: iload #8
    //   514: aaload
    //   515: astore #14
    //   517: aload #14
    //   519: ifnull -> 532
    //   522: aload #14
    //   524: invokevirtual getWidth : ()I
    //   527: iload #10
    //   529: if_icmpge -> 541
    //   532: aload_0
    //   533: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   536: iload #8
    //   538: aload #13
    //   540: aastore
    //   541: aload_0
    //   542: aload #13
    //   544: iload #4
    //   546: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   549: istore #10
    //   551: aload_0
    //   552: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   555: iload #9
    //   557: aaload
    //   558: astore #14
    //   560: aload #14
    //   562: ifnull -> 575
    //   565: aload #14
    //   567: invokevirtual getHeight : ()I
    //   570: iload #10
    //   572: if_icmpge -> 584
    //   575: aload_0
    //   576: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   579: iload #9
    //   581: aload #13
    //   583: aastore
    //   584: iload #9
    //   586: iconst_1
    //   587: iadd
    //   588: istore #9
    //   590: goto -> 442
    //   593: iload #8
    //   595: iconst_1
    //   596: iadd
    //   597: istore #8
    //   599: goto -> 432
    //   602: iconst_0
    //   603: istore #9
    //   605: iconst_0
    //   606: istore #8
    //   608: iload #9
    //   610: iload #7
    //   612: if_icmpge -> 677
    //   615: aload_0
    //   616: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   619: iload #9
    //   621: aaload
    //   622: astore #13
    //   624: iload #8
    //   626: istore #10
    //   628: aload #13
    //   630: ifnull -> 664
    //   633: iload #8
    //   635: istore #10
    //   637: iload #9
    //   639: ifle -> 651
    //   642: iload #8
    //   644: aload_0
    //   645: getfield mHorizontalGap : I
    //   648: iadd
    //   649: istore #10
    //   651: iload #10
    //   653: aload_0
    //   654: aload #13
    //   656: iload #4
    //   658: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   661: iadd
    //   662: istore #10
    //   664: iload #9
    //   666: iconst_1
    //   667: iadd
    //   668: istore #9
    //   670: iload #10
    //   672: istore #8
    //   674: goto -> 608
    //   677: iconst_0
    //   678: istore #9
    //   680: iconst_0
    //   681: istore #10
    //   683: iload #9
    //   685: iload #6
    //   687: if_icmpge -> 752
    //   690: aload_0
    //   691: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   694: iload #9
    //   696: aaload
    //   697: astore #13
    //   699: iload #10
    //   701: istore #11
    //   703: aload #13
    //   705: ifnull -> 739
    //   708: iload #10
    //   710: istore #11
    //   712: iload #9
    //   714: ifle -> 726
    //   717: iload #10
    //   719: aload_0
    //   720: getfield mVerticalGap : I
    //   723: iadd
    //   724: istore #11
    //   726: iload #11
    //   728: aload_0
    //   729: aload #13
    //   731: iload #4
    //   733: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   736: iadd
    //   737: istore #11
    //   739: iload #9
    //   741: iconst_1
    //   742: iadd
    //   743: istore #9
    //   745: iload #11
    //   747: istore #10
    //   749: goto -> 683
    //   752: aload #5
    //   754: iconst_0
    //   755: iload #8
    //   757: iastore
    //   758: aload #5
    //   760: iconst_1
    //   761: iload #10
    //   763: iastore
    //   764: iload_3
    //   765: ifne -> 806
    //   768: iload #6
    //   770: istore #11
    //   772: iload #7
    //   774: istore #9
    //   776: iload #8
    //   778: iload #4
    //   780: if_icmple -> 294
    //   783: iload #6
    //   785: istore #11
    //   787: iload #7
    //   789: istore #9
    //   791: iload #7
    //   793: iconst_1
    //   794: if_icmple -> 294
    //   797: iload #7
    //   799: iconst_1
    //   800: isub
    //   801: istore #7
    //   803: goto -> 311
    //   806: iload #6
    //   808: istore #11
    //   810: iload #7
    //   812: istore #9
    //   814: iload #10
    //   816: iload #4
    //   818: if_icmple -> 294
    //   821: iload #6
    //   823: istore #11
    //   825: iload #7
    //   827: istore #9
    //   829: iload #6
    //   831: iconst_1
    //   832: if_icmple -> 294
    //   835: iload #6
    //   837: iconst_1
    //   838: isub
    //   839: istore #6
    //   841: goto -> 311
    //   844: aload_0
    //   845: getfield mAlignedDimensions : [I
    //   848: astore_1
    //   849: aload_1
    //   850: iconst_0
    //   851: iload #7
    //   853: iastore
    //   854: aload_1
    //   855: iconst_1
    //   856: iload #6
    //   858: iastore
    //   859: return
  }
  
  private void measureChainWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    ConstraintWidget constraintWidget;
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      Object object;
      boolean bool = false;
      int i3 = 0;
      int i4 = 0;
      while (true) {
        Object object1 = object;
        if (i4 < paramInt1) {
          boolean bool1;
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i4];
          int i5 = getWidgetWidth(constraintWidget, paramInt3);
          object1 = object;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = object + 1; 
          if ((i3 == paramInt3 || this.mHorizontalGap + i3 + i5 > paramInt3) && widgetsList.biggest != null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          boolean bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (i4 > 0) {
              int i6 = this.mMaxElementsWrap;
              bool2 = bool1;
              if (i6 > 0) {
                bool2 = bool1;
                if (i4 % i6 == 0)
                  bool2 = true; 
              } 
            } 
          } 
          if (bool2) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i4);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i4 > 0) {
              i3 += this.mHorizontalGap + i5;
              continue;
            } 
          } 
          i3 = i5;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i4++;
        object = SYNTHETIC_LOCAL_VARIABLE_7;
      } 
    } else {
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      while (true) {
        i = i3;
        if (i5 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i5];
          int i7 = getWidgetHeight(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i4 == paramInt3 || this.mVerticalGap + i4 + i7 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i6 = i3;
          if (i3 == 0) {
            i6 = i3;
            if (i5 > 0) {
              int i8 = this.mMaxElementsWrap;
              i6 = i3;
              if (i8 > 0) {
                i6 = i3;
                if (i5 % i8 == 0)
                  i6 = 1; 
              } 
            } 
          } 
          if (i6 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i5);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i5 > 0) {
              i4 += this.mVerticalGap + i7;
              continue;
            } 
          } 
          i4 = i7;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add(constraintWidget);
        i5++;
        i3 = i;
      } 
    } 
    int i2 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int n = getPaddingRight();
    int m = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (i > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i2; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int i = 0;
    int i1 = 0;
    paramInt1 = 0;
    while (paramInt1 < i2) {
      int i3;
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i2 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i3 = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i3 = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, n, i3, paramInt3);
        k = Math.max(i1, widgetsList1.getWidth());
        m = i + widgetsList1.getHeight();
        i = m;
        if (paramInt1 > 0)
          i = m + this.mVerticalGap; 
        constraintAnchor4 = constraintAnchor;
        i1 = 0;
        m = i3;
        i3 = k;
        k = i1;
      } else {
        n = paramInt1;
        if (n < i2 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(n + 1)).biggest.mLeft;
          i3 = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i3 = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, i3, m, paramInt3);
        j = i1 + widgetsList1.getWidth();
        i1 = Math.max(i, widgetsList1.getHeight());
        i = j;
        if (n > 0)
          i = j + this.mHorizontalGap; 
        j = i1;
        n = i3;
        constraintAnchor1 = constraintAnchor;
        i1 = 0;
        i3 = i;
        i = j;
        j = i1;
      } 
      paramInt1++;
      i1 = i3;
    } 
    paramArrayOfint[0] = i1;
    paramArrayOfint[1] = i;
  }
  
  private void measureNoWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    WidgetsList widgetsList;
    if (paramInt1 == 0)
      return; 
    if (this.mChainList.size() == 0) {
      widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
      this.mChainList.add(widgetsList);
    } else {
      widgetsList = this.mChainList.get(0);
      widgetsList.clear();
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      ConstraintAnchor constraintAnchor3 = this.mRight;
      ConstraintAnchor constraintAnchor4 = this.mBottom;
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getPaddingRight();
      int m = getPaddingBottom();
      widgetsList.setup(paramInt2, constraintAnchor1, constraintAnchor2, constraintAnchor3, constraintAnchor4, i, j, k, m, paramInt3);
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++)
      widgetsList.add(paramArrayOfConstraintWidget[paramInt2]); 
    paramArrayOfint[0] = widgetsList.getWidth();
    paramArrayOfint[1] = widgetsList.getHeight();
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (getParent() != null && ((ConstraintWidgetContainer)getParent()).isRtl()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    int i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          createAlignedConstraints(paramBoolean); 
      } else {
        int j = this.mChainList.size();
        for (i = 0; i < j; i++) {
          boolean bool;
          WidgetsList widgetsList = this.mChainList.get(i);
          if (i == j - 1) {
            bool = true;
          } else {
            bool = false;
          } 
          widgetsList.createConstraints(paramBoolean, i, bool);
        } 
      } 
    } else if (this.mChainList.size() > 0) {
      ((WidgetsList)this.mChainList.get(0)).createConstraints(paramBoolean, 0, true);
    } 
    needsCallbackFromSolver(false);
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mHorizontalStyle = ((Flow)paramConstraintWidget).mHorizontalStyle;
    this.mVerticalStyle = ((Flow)paramConstraintWidget).mVerticalStyle;
    this.mFirstHorizontalStyle = ((Flow)paramConstraintWidget).mFirstHorizontalStyle;
    this.mFirstVerticalStyle = ((Flow)paramConstraintWidget).mFirstVerticalStyle;
    this.mLastHorizontalStyle = ((Flow)paramConstraintWidget).mLastHorizontalStyle;
    this.mLastVerticalStyle = ((Flow)paramConstraintWidget).mLastVerticalStyle;
    this.mHorizontalBias = ((Flow)paramConstraintWidget).mHorizontalBias;
    this.mVerticalBias = ((Flow)paramConstraintWidget).mVerticalBias;
    this.mFirstHorizontalBias = ((Flow)paramConstraintWidget).mFirstHorizontalBias;
    this.mFirstVerticalBias = ((Flow)paramConstraintWidget).mFirstVerticalBias;
    this.mLastHorizontalBias = ((Flow)paramConstraintWidget).mLastHorizontalBias;
    this.mLastVerticalBias = ((Flow)paramConstraintWidget).mLastVerticalBias;
    this.mHorizontalGap = ((Flow)paramConstraintWidget).mHorizontalGap;
    this.mVerticalGap = ((Flow)paramConstraintWidget).mVerticalGap;
    this.mHorizontalAlign = ((Flow)paramConstraintWidget).mHorizontalAlign;
    this.mVerticalAlign = ((Flow)paramConstraintWidget).mVerticalAlign;
    this.mWrapMode = ((Flow)paramConstraintWidget).mWrapMode;
    this.mMaxElementsWrap = ((Flow)paramConstraintWidget).mMaxElementsWrap;
    this.mOrientation = ((Flow)paramConstraintWidget).mOrientation;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mWidgetsCount > 0 && !measureChildren()) {
      setMeasure(0, 0);
      needsCallbackFromSolver(false);
      return;
    } 
    int i1 = getPaddingLeft();
    int i2 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int[] arrayOfInt = new int[2];
    int j = paramInt2 - i1 - i2;
    int i = this.mOrientation;
    if (i == 1)
      j = paramInt4 - m - n; 
    if (i == 0) {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } else {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } 
    ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
    int k = 0;
    for (i = 0; k < this.mWidgetsCount; i = i3) {
      int i3 = i;
      if (this.mWidgets[k].getVisibility() == 8)
        i3 = i + 1; 
      k++;
    } 
    k = this.mWidgetsCount;
    if (i > 0) {
      arrayOfConstraintWidget = new ConstraintWidget[this.mWidgetsCount - i];
      k = 0;
      for (i = 0; k < this.mWidgetsCount; i = i3) {
        ConstraintWidget constraintWidget = this.mWidgets[k];
        int i3 = i;
        if (constraintWidget.getVisibility() != 8) {
          arrayOfConstraintWidget[i] = constraintWidget;
          i3 = i + 1;
        } 
        k++;
      } 
      k = i;
    } 
    this.mDisplayedWidgets = arrayOfConstraintWidget;
    this.mDisplayedWidgetsCount = k;
    i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          measureAligned(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt); 
      } else {
        measureChainWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
      } 
    } else {
      measureNoWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
    } 
    boolean bool = true;
    j = arrayOfInt[0] + i1 + i2;
    i = arrayOfInt[1] + m + n;
    if (paramInt1 == 1073741824) {
      paramInt1 = paramInt2;
    } else if (paramInt1 == Integer.MIN_VALUE) {
      paramInt1 = Math.min(j, paramInt2);
    } else if (paramInt1 == 0) {
      paramInt1 = j;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt3 == 1073741824) {
      paramInt2 = paramInt4;
    } else if (paramInt3 == Integer.MIN_VALUE) {
      paramInt2 = Math.min(i, paramInt4);
    } else if (paramInt3 == 0) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    setMeasure(paramInt1, paramInt2);
    setWidth(paramInt1);
    setHeight(paramInt2);
    if (this.mWidgetsCount <= 0)
      bool = false; 
    needsCallbackFromSolver(bool);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.mFirstHorizontalBias = paramFloat;
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.mFirstHorizontalStyle = paramInt;
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.mFirstVerticalBias = paramFloat;
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.mFirstVerticalStyle = paramInt;
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.mHorizontalAlign = paramInt;
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.mHorizontalBias = paramFloat;
  }
  
  public void setHorizontalGap(int paramInt) {
    this.mHorizontalGap = paramInt;
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.mHorizontalStyle = paramInt;
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.mLastHorizontalBias = paramFloat;
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.mLastHorizontalStyle = paramInt;
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.mLastVerticalBias = paramFloat;
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.mLastVerticalStyle = paramInt;
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.mMaxElementsWrap = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setVerticalAlign(int paramInt) {
    this.mVerticalAlign = paramInt;
  }
  
  public void setVerticalBias(float paramFloat) {
    this.mVerticalBias = paramFloat;
  }
  
  public void setVerticalGap(int paramInt) {
    this.mVerticalGap = paramInt;
  }
  
  public void setVerticalStyle(int paramInt) {
    this.mVerticalStyle = paramInt;
  }
  
  public void setWrapMode(int paramInt) {
    this.mWrapMode = paramInt;
  }
  
  private class WidgetsList {
    private ConstraintWidget biggest = null;
    
    int biggestDimension = 0;
    
    private ConstraintAnchor mBottom;
    
    private int mCount = 0;
    
    private int mHeight = 0;
    
    private ConstraintAnchor mLeft;
    
    private int mMax = 0;
    
    private int mNbMatchConstraintsWidgets = 0;
    
    private int mOrientation;
    
    private int mPaddingBottom = 0;
    
    private int mPaddingLeft = 0;
    
    private int mPaddingRight = 0;
    
    private int mPaddingTop = 0;
    
    private ConstraintAnchor mRight;
    
    private int mStartIndex = 0;
    
    private ConstraintAnchor mTop;
    
    private int mWidth = 0;
    
    public WidgetsList(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = Flow.this.getPaddingLeft();
      this.mPaddingTop = Flow.this.getPaddingTop();
      this.mPaddingRight = Flow.this.getPaddingRight();
      this.mPaddingBottom = Flow.this.getPaddingBottom();
      this.mMax = param1Int2;
    }
    
    private void recomputeDimensions() {
      this.mWidth = 0;
      this.mHeight = 0;
      this.biggest = null;
      this.biggestDimension = 0;
      int j = this.mCount;
      for (int i = 0; i < j; i++) {
        if (this.mStartIndex + i >= Flow.this.mDisplayedWidgetsCount)
          return; 
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + i];
        if (this.mOrientation == 0) {
          int m = constraintWidget.getWidth();
          int k = Flow.this.mHorizontalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mWidth += m + k;
          k = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          if (this.biggest == null || this.biggestDimension < k) {
            this.biggest = constraintWidget;
            this.biggestDimension = k;
            this.mHeight = k;
          } 
        } else {
          int m = Flow.this.getWidgetWidth(constraintWidget, this.mMax);
          int n = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          int k = Flow.this.mVerticalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mHeight += n + k;
          if (this.biggest == null || this.biggestDimension < m) {
            this.biggest = constraintWidget;
            this.biggestDimension = m;
            this.mWidth = m;
          } 
        } 
      } 
    }
    
    public void add(ConstraintWidget param1ConstraintWidget) {
      int i = this.mOrientation;
      int j = 0;
      int k = 0;
      if (i == 0) {
        i = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        j = Flow.this.mHorizontalGap;
        if (param1ConstraintWidget.getVisibility() == 8)
          j = k; 
        this.mWidth += i + j;
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (this.biggest == null || this.biggestDimension < i) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = i;
          this.mHeight = i;
        } 
      } else {
        int m = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        k = Flow.this.mVerticalGap;
        if (param1ConstraintWidget.getVisibility() != 8)
          j = k; 
        this.mHeight += i + j;
        if (this.biggest == null || this.biggestDimension < m) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = m;
          this.mWidth = m;
        } 
      } 
      this.mCount++;
    }
    
    public void clear() {
      this.biggestDimension = 0;
      this.biggest = null;
      this.mWidth = 0;
      this.mHeight = 0;
      this.mStartIndex = 0;
      this.mCount = 0;
      this.mNbMatchConstraintsWidgets = 0;
    }
    
    public void createConstraints(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mCount : I
      //   4: istore #13
      //   6: iconst_0
      //   7: istore #6
      //   9: iload #6
      //   11: iload #13
      //   13: if_icmpge -> 72
      //   16: aload_0
      //   17: getfield mStartIndex : I
      //   20: iload #6
      //   22: iadd
      //   23: aload_0
      //   24: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   27: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   30: if_icmplt -> 36
      //   33: goto -> 72
      //   36: aload_0
      //   37: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   40: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   43: aload_0
      //   44: getfield mStartIndex : I
      //   47: iload #6
      //   49: iadd
      //   50: aaload
      //   51: astore #14
      //   53: aload #14
      //   55: ifnull -> 63
      //   58: aload #14
      //   60: invokevirtual resetAnchors : ()V
      //   63: iload #6
      //   65: iconst_1
      //   66: iadd
      //   67: istore #6
      //   69: goto -> 9
      //   72: iload #13
      //   74: ifeq -> 1737
      //   77: aload_0
      //   78: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   81: ifnonnull -> 85
      //   84: return
      //   85: iload_3
      //   86: ifeq -> 99
      //   89: iload_2
      //   90: ifne -> 99
      //   93: iconst_1
      //   94: istore #9
      //   96: goto -> 102
      //   99: iconst_0
      //   100: istore #9
      //   102: iconst_0
      //   103: istore #6
      //   105: iconst_m1
      //   106: istore #7
      //   108: iconst_m1
      //   109: istore #8
      //   111: iload #6
      //   113: iload #13
      //   115: if_icmpge -> 226
      //   118: iload_1
      //   119: ifeq -> 134
      //   122: iload #13
      //   124: iconst_1
      //   125: isub
      //   126: iload #6
      //   128: isub
      //   129: istore #12
      //   131: goto -> 138
      //   134: iload #6
      //   136: istore #12
      //   138: aload_0
      //   139: getfield mStartIndex : I
      //   142: iload #12
      //   144: iadd
      //   145: aload_0
      //   146: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   149: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   152: if_icmplt -> 158
      //   155: goto -> 226
      //   158: iload #7
      //   160: istore #10
      //   162: iload #8
      //   164: istore #11
      //   166: aload_0
      //   167: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   170: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   173: aload_0
      //   174: getfield mStartIndex : I
      //   177: iload #12
      //   179: iadd
      //   180: aaload
      //   181: invokevirtual getVisibility : ()I
      //   184: ifne -> 209
      //   187: iload #7
      //   189: istore #8
      //   191: iload #7
      //   193: iconst_m1
      //   194: if_icmpne -> 201
      //   197: iload #6
      //   199: istore #8
      //   201: iload #6
      //   203: istore #11
      //   205: iload #8
      //   207: istore #10
      //   209: iload #6
      //   211: iconst_1
      //   212: iadd
      //   213: istore #6
      //   215: iload #10
      //   217: istore #7
      //   219: iload #11
      //   221: istore #8
      //   223: goto -> 111
      //   226: aload_0
      //   227: getfield mOrientation : I
      //   230: istore #6
      //   232: aconst_null
      //   233: astore #14
      //   235: aconst_null
      //   236: astore #15
      //   238: iload #6
      //   240: ifne -> 1021
      //   243: aload_0
      //   244: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   247: astore #16
      //   249: aload #16
      //   251: aload_0
      //   252: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   255: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   258: invokevirtual setVerticalChainStyle : (I)V
      //   261: aload_0
      //   262: getfield mPaddingTop : I
      //   265: istore #10
      //   267: iload #10
      //   269: istore #6
      //   271: iload_2
      //   272: ifle -> 287
      //   275: iload #10
      //   277: aload_0
      //   278: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   281: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   284: iadd
      //   285: istore #6
      //   287: aload #16
      //   289: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   292: aload_0
      //   293: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   296: iload #6
      //   298: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   301: pop
      //   302: iload_3
      //   303: ifeq -> 323
      //   306: aload #16
      //   308: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   311: aload_0
      //   312: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   315: aload_0
      //   316: getfield mPaddingBottom : I
      //   319: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   322: pop
      //   323: iload_2
      //   324: ifle -> 347
      //   327: aload_0
      //   328: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   331: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   334: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   337: aload #16
      //   339: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   342: iconst_0
      //   343: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   346: pop
      //   347: aload_0
      //   348: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   351: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   354: iconst_3
      //   355: if_icmpne -> 447
      //   358: aload #16
      //   360: invokevirtual hasBaseline : ()Z
      //   363: ifne -> 447
      //   366: iconst_0
      //   367: istore_2
      //   368: iload_2
      //   369: iload #13
      //   371: if_icmpge -> 447
      //   374: iload_1
      //   375: ifeq -> 389
      //   378: iload #13
      //   380: iconst_1
      //   381: isub
      //   382: iload_2
      //   383: isub
      //   384: istore #6
      //   386: goto -> 392
      //   389: iload_2
      //   390: istore #6
      //   392: aload_0
      //   393: getfield mStartIndex : I
      //   396: iload #6
      //   398: iadd
      //   399: aload_0
      //   400: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   403: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   406: if_icmplt -> 412
      //   409: goto -> 447
      //   412: aload_0
      //   413: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   416: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   419: aload_0
      //   420: getfield mStartIndex : I
      //   423: iload #6
      //   425: iadd
      //   426: aaload
      //   427: astore #14
      //   429: aload #14
      //   431: invokevirtual hasBaseline : ()Z
      //   434: ifeq -> 440
      //   437: goto -> 451
      //   440: iload_2
      //   441: iconst_1
      //   442: iadd
      //   443: istore_2
      //   444: goto -> 368
      //   447: aload #16
      //   449: astore #14
      //   451: iconst_0
      //   452: istore #6
      //   454: iload #6
      //   456: iload #13
      //   458: if_icmpge -> 1737
      //   461: iload_1
      //   462: ifeq -> 476
      //   465: iload #13
      //   467: iconst_1
      //   468: isub
      //   469: iload #6
      //   471: isub
      //   472: istore_2
      //   473: goto -> 479
      //   476: iload #6
      //   478: istore_2
      //   479: aload_0
      //   480: getfield mStartIndex : I
      //   483: iload_2
      //   484: iadd
      //   485: aload_0
      //   486: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   489: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   492: if_icmplt -> 496
      //   495: return
      //   496: aload_0
      //   497: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   500: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   503: aload_0
      //   504: getfield mStartIndex : I
      //   507: iload_2
      //   508: iadd
      //   509: aaload
      //   510: astore #17
      //   512: iload #6
      //   514: ifne -> 535
      //   517: aload #17
      //   519: aload #17
      //   521: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   524: aload_0
      //   525: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   528: aload_0
      //   529: getfield mPaddingLeft : I
      //   532: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   535: iload_2
      //   536: ifne -> 713
      //   539: aload_0
      //   540: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   543: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   546: istore #10
      //   548: aload_0
      //   549: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   552: invokestatic access$900 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   555: fstore #5
      //   557: fload #5
      //   559: fstore #4
      //   561: iload_1
      //   562: ifeq -> 571
      //   565: fconst_1
      //   566: fload #5
      //   568: fsub
      //   569: fstore #4
      //   571: aload_0
      //   572: getfield mStartIndex : I
      //   575: ifne -> 635
      //   578: aload_0
      //   579: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   582: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   585: iconst_m1
      //   586: if_icmpeq -> 635
      //   589: aload_0
      //   590: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   593: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   596: istore_2
      //   597: iload_1
      //   598: ifeq -> 619
      //   601: aload_0
      //   602: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   605: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   608: fstore #4
      //   610: fconst_1
      //   611: fload #4
      //   613: fsub
      //   614: fstore #4
      //   616: goto -> 628
      //   619: aload_0
      //   620: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   623: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   626: fstore #4
      //   628: fload #4
      //   630: fstore #5
      //   632: goto -> 700
      //   635: iload #10
      //   637: istore_2
      //   638: fload #4
      //   640: fstore #5
      //   642: iload_3
      //   643: ifeq -> 700
      //   646: iload #10
      //   648: istore_2
      //   649: fload #4
      //   651: fstore #5
      //   653: aload_0
      //   654: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   657: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   660: iconst_m1
      //   661: if_icmpeq -> 700
      //   664: aload_0
      //   665: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   668: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   671: istore_2
      //   672: iload_1
      //   673: ifeq -> 688
      //   676: aload_0
      //   677: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   680: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   683: fstore #4
      //   685: goto -> 610
      //   688: aload_0
      //   689: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   692: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   695: fstore #4
      //   697: goto -> 628
      //   700: aload #17
      //   702: iload_2
      //   703: invokevirtual setHorizontalChainStyle : (I)V
      //   706: aload #17
      //   708: fload #5
      //   710: invokevirtual setHorizontalBiasPercent : (F)V
      //   713: iload #6
      //   715: iload #13
      //   717: iconst_1
      //   718: isub
      //   719: if_icmpne -> 740
      //   722: aload #17
      //   724: aload #17
      //   726: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   729: aload_0
      //   730: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   733: aload_0
      //   734: getfield mPaddingRight : I
      //   737: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   740: aload #15
      //   742: ifnull -> 821
      //   745: aload #17
      //   747: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   750: aload #15
      //   752: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   755: aload_0
      //   756: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   759: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   762: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   765: pop
      //   766: iload #6
      //   768: iload #7
      //   770: if_icmpne -> 785
      //   773: aload #17
      //   775: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   778: aload_0
      //   779: getfield mPaddingLeft : I
      //   782: invokevirtual setGoneMargin : (I)V
      //   785: aload #15
      //   787: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   790: aload #17
      //   792: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   795: iconst_0
      //   796: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   799: pop
      //   800: iload #6
      //   802: iload #8
      //   804: iconst_1
      //   805: iadd
      //   806: if_icmpne -> 821
      //   809: aload #15
      //   811: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   814: aload_0
      //   815: getfield mPaddingRight : I
      //   818: invokevirtual setGoneMargin : (I)V
      //   821: aload #17
      //   823: aload #16
      //   825: if_acmpeq -> 1008
      //   828: aload_0
      //   829: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   832: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   835: iconst_3
      //   836: if_icmpne -> 880
      //   839: aload #14
      //   841: invokevirtual hasBaseline : ()Z
      //   844: ifeq -> 880
      //   847: aload #17
      //   849: aload #14
      //   851: if_acmpeq -> 880
      //   854: aload #17
      //   856: invokevirtual hasBaseline : ()Z
      //   859: ifeq -> 880
      //   862: aload #17
      //   864: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   867: aload #14
      //   869: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   872: iconst_0
      //   873: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   876: pop
      //   877: goto -> 1008
      //   880: aload_0
      //   881: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   884: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   887: istore_2
      //   888: iload_2
      //   889: ifeq -> 990
      //   892: iload_2
      //   893: iconst_1
      //   894: if_icmpeq -> 972
      //   897: iload #9
      //   899: ifeq -> 939
      //   902: aload #17
      //   904: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   907: aload_0
      //   908: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   911: aload_0
      //   912: getfield mPaddingTop : I
      //   915: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   918: pop
      //   919: aload #17
      //   921: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   924: aload_0
      //   925: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   928: aload_0
      //   929: getfield mPaddingBottom : I
      //   932: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   935: pop
      //   936: goto -> 1008
      //   939: aload #17
      //   941: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   944: aload #16
      //   946: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   949: iconst_0
      //   950: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   953: pop
      //   954: aload #17
      //   956: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   959: aload #16
      //   961: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   964: iconst_0
      //   965: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   968: pop
      //   969: goto -> 1008
      //   972: aload #17
      //   974: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   977: aload #16
      //   979: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   982: iconst_0
      //   983: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   986: pop
      //   987: goto -> 1008
      //   990: aload #17
      //   992: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   995: aload #16
      //   997: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1000: iconst_0
      //   1001: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1004: pop
      //   1005: goto -> 1008
      //   1008: iload #6
      //   1010: iconst_1
      //   1011: iadd
      //   1012: istore #6
      //   1014: aload #17
      //   1016: astore #15
      //   1018: goto -> 454
      //   1021: aload_0
      //   1022: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1025: astore #16
      //   1027: aload #16
      //   1029: aload_0
      //   1030: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1033: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1036: invokevirtual setHorizontalChainStyle : (I)V
      //   1039: aload_0
      //   1040: getfield mPaddingLeft : I
      //   1043: istore #10
      //   1045: iload #10
      //   1047: istore #6
      //   1049: iload_2
      //   1050: ifle -> 1065
      //   1053: iload #10
      //   1055: aload_0
      //   1056: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1059: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1062: iadd
      //   1063: istore #6
      //   1065: iload_1
      //   1066: ifeq -> 1132
      //   1069: aload #16
      //   1071: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1074: aload_0
      //   1075: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1078: iload #6
      //   1080: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1083: pop
      //   1084: iload_3
      //   1085: ifeq -> 1105
      //   1088: aload #16
      //   1090: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1093: aload_0
      //   1094: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1097: aload_0
      //   1098: getfield mPaddingRight : I
      //   1101: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1104: pop
      //   1105: iload_2
      //   1106: ifle -> 1192
      //   1109: aload_0
      //   1110: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1113: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1116: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1119: aload #16
      //   1121: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1124: iconst_0
      //   1125: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1128: pop
      //   1129: goto -> 1192
      //   1132: aload #16
      //   1134: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1137: aload_0
      //   1138: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1141: iload #6
      //   1143: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1146: pop
      //   1147: iload_3
      //   1148: ifeq -> 1168
      //   1151: aload #16
      //   1153: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1156: aload_0
      //   1157: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1160: aload_0
      //   1161: getfield mPaddingRight : I
      //   1164: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1167: pop
      //   1168: iload_2
      //   1169: ifle -> 1192
      //   1172: aload_0
      //   1173: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1176: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1179: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1182: aload #16
      //   1184: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1187: iconst_0
      //   1188: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1191: pop
      //   1192: iconst_0
      //   1193: istore #6
      //   1195: iload #6
      //   1197: iload #13
      //   1199: if_icmpge -> 1737
      //   1202: aload_0
      //   1203: getfield mStartIndex : I
      //   1206: iload #6
      //   1208: iadd
      //   1209: aload_0
      //   1210: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1213: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1216: if_icmplt -> 1220
      //   1219: return
      //   1220: aload_0
      //   1221: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1224: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1227: aload_0
      //   1228: getfield mStartIndex : I
      //   1231: iload #6
      //   1233: iadd
      //   1234: aaload
      //   1235: astore #15
      //   1237: iload #6
      //   1239: ifne -> 1375
      //   1242: aload #15
      //   1244: aload #15
      //   1246: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1249: aload_0
      //   1250: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1253: aload_0
      //   1254: getfield mPaddingTop : I
      //   1257: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1260: aload_0
      //   1261: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1264: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1267: istore #10
      //   1269: aload_0
      //   1270: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1273: invokestatic access$1400 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1276: fstore #5
      //   1278: aload_0
      //   1279: getfield mStartIndex : I
      //   1282: ifne -> 1316
      //   1285: aload_0
      //   1286: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1289: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1292: iconst_m1
      //   1293: if_icmpeq -> 1316
      //   1296: aload_0
      //   1297: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1300: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1303: istore_2
      //   1304: aload_0
      //   1305: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1308: invokestatic access$1600 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1311: fstore #4
      //   1313: goto -> 1362
      //   1316: iload #10
      //   1318: istore_2
      //   1319: fload #5
      //   1321: fstore #4
      //   1323: iload_3
      //   1324: ifeq -> 1362
      //   1327: iload #10
      //   1329: istore_2
      //   1330: fload #5
      //   1332: fstore #4
      //   1334: aload_0
      //   1335: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1338: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1341: iconst_m1
      //   1342: if_icmpeq -> 1362
      //   1345: aload_0
      //   1346: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1349: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1352: istore_2
      //   1353: aload_0
      //   1354: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1357: invokestatic access$1800 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1360: fstore #4
      //   1362: aload #15
      //   1364: iload_2
      //   1365: invokevirtual setVerticalChainStyle : (I)V
      //   1368: aload #15
      //   1370: fload #4
      //   1372: invokevirtual setVerticalBiasPercent : (F)V
      //   1375: iload #6
      //   1377: iload #13
      //   1379: iconst_1
      //   1380: isub
      //   1381: if_icmpne -> 1402
      //   1384: aload #15
      //   1386: aload #15
      //   1388: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1391: aload_0
      //   1392: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1395: aload_0
      //   1396: getfield mPaddingBottom : I
      //   1399: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1402: aload #14
      //   1404: ifnull -> 1483
      //   1407: aload #15
      //   1409: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1412: aload #14
      //   1414: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1417: aload_0
      //   1418: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1421: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1424: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1427: pop
      //   1428: iload #6
      //   1430: iload #7
      //   1432: if_icmpne -> 1447
      //   1435: aload #15
      //   1437: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1440: aload_0
      //   1441: getfield mPaddingTop : I
      //   1444: invokevirtual setGoneMargin : (I)V
      //   1447: aload #14
      //   1449: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1452: aload #15
      //   1454: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1457: iconst_0
      //   1458: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1461: pop
      //   1462: iload #6
      //   1464: iload #8
      //   1466: iconst_1
      //   1467: iadd
      //   1468: if_icmpne -> 1483
      //   1471: aload #14
      //   1473: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1476: aload_0
      //   1477: getfield mPaddingBottom : I
      //   1480: invokevirtual setGoneMargin : (I)V
      //   1483: aload #15
      //   1485: aload #16
      //   1487: if_acmpeq -> 1724
      //   1490: iload_1
      //   1491: ifeq -> 1588
      //   1494: aload_0
      //   1495: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1498: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1501: istore_2
      //   1502: iload_2
      //   1503: ifeq -> 1570
      //   1506: iload_2
      //   1507: iconst_1
      //   1508: if_icmpeq -> 1552
      //   1511: iload_2
      //   1512: iconst_2
      //   1513: if_icmpeq -> 1519
      //   1516: goto -> 1724
      //   1519: aload #15
      //   1521: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1524: aload #16
      //   1526: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1529: iconst_0
      //   1530: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1533: pop
      //   1534: aload #15
      //   1536: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1539: aload #16
      //   1541: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1544: iconst_0
      //   1545: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1548: pop
      //   1549: goto -> 1724
      //   1552: aload #15
      //   1554: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1557: aload #16
      //   1559: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1562: iconst_0
      //   1563: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1566: pop
      //   1567: goto -> 1724
      //   1570: aload #15
      //   1572: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1575: aload #16
      //   1577: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1580: iconst_0
      //   1581: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1584: pop
      //   1585: goto -> 1724
      //   1588: aload_0
      //   1589: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1592: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1595: istore_2
      //   1596: iload_2
      //   1597: ifeq -> 1706
      //   1600: iload_2
      //   1601: iconst_1
      //   1602: if_icmpeq -> 1688
      //   1605: iload_2
      //   1606: iconst_2
      //   1607: if_icmpeq -> 1613
      //   1610: goto -> 1724
      //   1613: iload #9
      //   1615: ifeq -> 1655
      //   1618: aload #15
      //   1620: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1623: aload_0
      //   1624: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1627: aload_0
      //   1628: getfield mPaddingLeft : I
      //   1631: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1634: pop
      //   1635: aload #15
      //   1637: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1640: aload_0
      //   1641: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1644: aload_0
      //   1645: getfield mPaddingRight : I
      //   1648: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1651: pop
      //   1652: goto -> 1724
      //   1655: aload #15
      //   1657: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1660: aload #16
      //   1662: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1665: iconst_0
      //   1666: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1669: pop
      //   1670: aload #15
      //   1672: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1675: aload #16
      //   1677: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1680: iconst_0
      //   1681: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1684: pop
      //   1685: goto -> 1724
      //   1688: aload #15
      //   1690: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1693: aload #16
      //   1695: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1698: iconst_0
      //   1699: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1702: pop
      //   1703: goto -> 1724
      //   1706: aload #15
      //   1708: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1711: aload #16
      //   1713: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1716: iconst_0
      //   1717: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1720: pop
      //   1721: goto -> 1724
      //   1724: iload #6
      //   1726: iconst_1
      //   1727: iadd
      //   1728: istore #6
      //   1730: aload #15
      //   1732: astore #14
      //   1734: goto -> 1195
      //   1737: return
    }
    
    public int getHeight() {
      return (this.mOrientation == 1) ? (this.mHeight - Flow.this.mVerticalGap) : this.mHeight;
    }
    
    public int getWidth() {
      return (this.mOrientation == 0) ? (this.mWidth - Flow.this.mHorizontalGap) : this.mWidth;
    }
    
    public void measureMatchConstraints(int param1Int) {
      int j = this.mNbMatchConstraintsWidgets;
      if (j == 0)
        return; 
      int i = this.mCount;
      j = param1Int / j;
      for (param1Int = 0; param1Int < i && this.mStartIndex + param1Int < Flow.this.mDisplayedWidgetsCount; param1Int++) {
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + param1Int];
        if (this.mOrientation == 0) {
          if (constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultWidth == 0)
            Flow.this.measure(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, j, constraintWidget.getVerticalDimensionBehaviour(), constraintWidget.getHeight()); 
        } else if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultHeight == 0) {
          Flow.this.measure(constraintWidget, constraintWidget.getHorizontalDimensionBehaviour(), constraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, j);
        } 
      } 
      recomputeDimensions();
    }
    
    public void setStartIndex(int param1Int) {
      this.mStartIndex = param1Int;
    }
    
    public void setup(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = param1Int2;
      this.mPaddingTop = param1Int3;
      this.mPaddingRight = param1Int4;
      this.mPaddingBottom = param1Int5;
      this.mMax = param1Int6;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\widgets\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */