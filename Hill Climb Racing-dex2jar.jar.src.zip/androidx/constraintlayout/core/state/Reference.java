package androidx.constraintlayout.core.state;

import androidx.constraintlayout.core.state.helpers.Facade;
import androidx.constraintlayout.core.widgets.ConstraintWidget;

public interface Reference {
  void apply();
  
  ConstraintWidget getConstraintWidget();
  
  Facade getFacade();
  
  Object getKey();
  
  void setConstraintWidget(ConstraintWidget paramConstraintWidget);
  
  void setKey(Object paramObject);
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\state\Reference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */