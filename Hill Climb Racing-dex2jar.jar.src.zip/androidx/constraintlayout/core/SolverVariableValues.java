package androidx.constraintlayout.core;

import java.io.PrintStream;
import java.util.Arrays;

public class SolverVariableValues implements ArrayRow.ArrayRowVariables {
  private static final boolean DEBUG = false;
  
  private static final boolean HASH = true;
  
  private static float epsilon = 0.001F;
  
  private int HASH_SIZE = 16;
  
  private final int NONE = -1;
  
  private int SIZE = 16;
  
  int head = -1;
  
  int[] keys = new int[16];
  
  protected final Cache mCache;
  
  int mCount = 0;
  
  private final ArrayRow mRow;
  
  int[] next = new int[16];
  
  int[] nextKeys = new int[16];
  
  int[] previous = new int[16];
  
  float[] values = new float[16];
  
  int[] variables = new int[16];
  
  SolverVariableValues(ArrayRow paramArrayRow, Cache paramCache) {
    this.mRow = paramArrayRow;
    this.mCache = paramCache;
    clear();
  }
  
  private void addToHashMap(SolverVariable paramSolverVariable, int paramInt) {
    int k = paramSolverVariable.id % this.HASH_SIZE;
    int[] arrayOfInt = this.keys;
    int j = arrayOfInt[k];
    int i = j;
    if (j == -1) {
      arrayOfInt[k] = paramInt;
    } else {
      while (true) {
        arrayOfInt = this.nextKeys;
        j = arrayOfInt[i];
        if (j != -1) {
          i = j;
          continue;
        } 
        arrayOfInt[i] = paramInt;
        this.nextKeys[paramInt] = -1;
        return;
      } 
    } 
    this.nextKeys[paramInt] = -1;
  }
  
  private void addVariable(int paramInt, SolverVariable paramSolverVariable, float paramFloat) {
    this.variables[paramInt] = paramSolverVariable.id;
    this.values[paramInt] = paramFloat;
    this.previous[paramInt] = -1;
    this.next[paramInt] = -1;
    paramSolverVariable.addToRow(this.mRow);
    paramSolverVariable.usageInRowCount++;
    this.mCount++;
  }
  
  private void displayHash() {
    for (int i = 0; i < this.HASH_SIZE; i++) {
      if (this.keys[i] != -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(hashCode());
        stringBuilder.append(" hash [");
        stringBuilder.append(i);
        stringBuilder.append("] => ");
        String str = stringBuilder.toString();
        int j = this.keys[i];
        for (boolean bool = false; !bool; bool = true) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(str);
          stringBuilder1.append(" ");
          stringBuilder1.append(this.variables[j]);
          str = stringBuilder1.toString();
          int k = this.nextKeys[j];
          if (k != -1) {
            j = k;
            continue;
          } 
        } 
        System.out.println(str);
      } 
    } 
  }
  
  private int findEmptySlot() {
    for (int i = 0; i < this.SIZE; i++) {
      if (this.variables[i] == -1)
        return i; 
    } 
    return -1;
  }
  
  private void increaseSize() {
    int j = this.SIZE * 2;
    this.variables = Arrays.copyOf(this.variables, j);
    this.values = Arrays.copyOf(this.values, j);
    this.previous = Arrays.copyOf(this.previous, j);
    this.next = Arrays.copyOf(this.next, j);
    this.nextKeys = Arrays.copyOf(this.nextKeys, j);
    for (int i = this.SIZE; i < j; i++) {
      this.variables[i] = -1;
      this.nextKeys[i] = -1;
    } 
    this.SIZE = j;
  }
  
  private void insertVariable(int paramInt, SolverVariable paramSolverVariable, float paramFloat) {
    int i = findEmptySlot();
    addVariable(i, paramSolverVariable, paramFloat);
    if (paramInt != -1) {
      this.previous[i] = paramInt;
      int[] arrayOfInt = this.next;
      arrayOfInt[i] = arrayOfInt[paramInt];
      arrayOfInt[paramInt] = i;
    } else {
      this.previous[i] = -1;
      if (this.mCount > 0) {
        this.next[i] = this.head;
        this.head = i;
      } else {
        this.next[i] = -1;
      } 
    } 
    paramInt = this.next[i];
    if (paramInt != -1)
      this.previous[paramInt] = i; 
    addToHashMap(paramSolverVariable, i);
  }
  
  private void removeFromHashMap(SolverVariable paramSolverVariable) {
    int[] arrayOfInt;
    int m = paramSolverVariable.id % this.HASH_SIZE;
    int j = this.keys[m];
    if (j == -1)
      return; 
    int k = paramSolverVariable.id;
    int i = j;
    if (this.variables[j] == k) {
      arrayOfInt = this.keys;
      int[] arrayOfInt1 = this.nextKeys;
      arrayOfInt[m] = arrayOfInt1[j];
      arrayOfInt1[j] = -1;
      return;
    } 
    while (true) {
      arrayOfInt = this.nextKeys;
      j = arrayOfInt[i];
      if (j != -1 && this.variables[j] != k) {
        i = j;
        continue;
      } 
      break;
    } 
    if (j != -1 && this.variables[j] == k) {
      arrayOfInt[i] = arrayOfInt[j];
      arrayOfInt[j] = -1;
    } 
  }
  
  public void add(SolverVariable paramSolverVariable, float paramFloat, boolean paramBoolean) {
    float f = epsilon;
    if (paramFloat > -f && paramFloat < f)
      return; 
    int i = indexOf(paramSolverVariable);
    if (i == -1) {
      put(paramSolverVariable, paramFloat);
      return;
    } 
    float[] arrayOfFloat = this.values;
    paramFloat = arrayOfFloat[i] + paramFloat;
    arrayOfFloat[i] = paramFloat;
    f = epsilon;
    if (paramFloat > -f && paramFloat < f) {
      arrayOfFloat[i] = 0.0F;
      remove(paramSolverVariable, paramBoolean);
    } 
  }
  
  public void clear() {
    int j = this.mCount;
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable = getVariable(i);
      if (solverVariable != null)
        solverVariable.removeFromRow(this.mRow); 
    } 
    for (i = 0; i < this.SIZE; i++) {
      this.variables[i] = -1;
      this.nextKeys[i] = -1;
    } 
    for (i = 0; i < this.HASH_SIZE; i++)
      this.keys[i] = -1; 
    this.mCount = 0;
    this.head = -1;
  }
  
  public boolean contains(SolverVariable paramSolverVariable) {
    return (indexOf(paramSolverVariable) != -1);
  }
  
  public void display() {
    int j = this.mCount;
    System.out.print("{ ");
    for (int i = 0; i < j; i++) {
      SolverVariable solverVariable = getVariable(i);
      if (solverVariable != null) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(solverVariable);
        stringBuilder.append(" = ");
        stringBuilder.append(getVariableValue(i));
        stringBuilder.append(" ");
        printStream.print(stringBuilder.toString());
      } 
    } 
    System.out.println(" }");
  }
  
  public void divideByAmount(float paramFloat) {
    int k = this.mCount;
    int j = this.head;
    for (int i = 0; i < k; i++) {
      float[] arrayOfFloat = this.values;
      arrayOfFloat[j] = arrayOfFloat[j] / paramFloat;
      j = this.next[j];
      if (j == -1)
        return; 
    } 
  }
  
  public float get(SolverVariable paramSolverVariable) {
    int i = indexOf(paramSolverVariable);
    return (i != -1) ? this.values[i] : 0.0F;
  }
  
  public int getCurrentSize() {
    return this.mCount;
  }
  
  public SolverVariable getVariable(int paramInt) {
    int k = this.mCount;
    if (k == 0)
      return null; 
    int j = this.head;
    for (int i = 0; i < k; i++) {
      if (i == paramInt && j != -1)
        return this.mCache.mIndexedVariables[this.variables[j]]; 
      j = this.next[j];
      if (j == -1)
        return null; 
    } 
    return null;
  }
  
  public float getVariableValue(int paramInt) {
    int k = this.mCount;
    int j = this.head;
    for (int i = 0; i < k; i++) {
      if (i == paramInt)
        return this.values[j]; 
      j = this.next[j];
      if (j == -1)
        break; 
    } 
    return 0.0F;
  }
  
  public int indexOf(SolverVariable paramSolverVariable) {
    if (this.mCount != 0) {
      if (paramSolverVariable == null)
        return -1; 
      int k = paramSolverVariable.id;
      int i = this.HASH_SIZE;
      int j = this.keys[k % i];
      if (j == -1)
        return -1; 
      i = j;
      if (this.variables[j] == k)
        return j; 
      while (true) {
        i = this.nextKeys[i];
        if (i != -1 && this.variables[i] != k)
          continue; 
        break;
      } 
      if (i == -1)
        return -1; 
      if (this.variables[i] == k)
        return i; 
    } 
    return -1;
  }
  
  public void invert() {
    int k = this.mCount;
    int j = this.head;
    for (int i = 0; i < k; i++) {
      float[] arrayOfFloat = this.values;
      arrayOfFloat[j] = arrayOfFloat[j] * -1.0F;
      j = this.next[j];
      if (j == -1)
        return; 
    } 
  }
  
  public void put(SolverVariable paramSolverVariable, float paramFloat) {
    int m;
    float f = epsilon;
    if (paramFloat > -f && paramFloat < f) {
      remove(paramSolverVariable, true);
      return;
    } 
    int i = this.mCount;
    int k = 0;
    if (i == 0) {
      addVariable(0, paramSolverVariable, paramFloat);
      addToHashMap(paramSolverVariable, 0);
      this.head = 0;
      return;
    } 
    i = indexOf(paramSolverVariable);
    if (i != -1) {
      this.values[i] = paramFloat;
      return;
    } 
    if (this.mCount + 1 >= this.SIZE)
      increaseSize(); 
    int n = this.mCount;
    i = this.head;
    int j = -1;
    while (true) {
      m = j;
      if (k < n) {
        if (this.variables[i] == paramSolverVariable.id) {
          this.values[i] = paramFloat;
          return;
        } 
        if (this.variables[i] < paramSolverVariable.id)
          j = i; 
        i = this.next[i];
        if (i == -1) {
          m = j;
          break;
        } 
        k++;
        continue;
      } 
      break;
    } 
    insertVariable(m, paramSolverVariable, paramFloat);
  }
  
  public float remove(SolverVariable paramSolverVariable, boolean paramBoolean) {
    int i = indexOf(paramSolverVariable);
    if (i == -1)
      return 0.0F; 
    removeFromHashMap(paramSolverVariable);
    float f = this.values[i];
    if (this.head == i)
      this.head = this.next[i]; 
    this.variables[i] = -1;
    int[] arrayOfInt = this.previous;
    int j = arrayOfInt[i];
    if (j != -1) {
      int[] arrayOfInt1 = this.next;
      arrayOfInt1[j] = arrayOfInt1[i];
    } 
    j = this.next[i];
    if (j != -1)
      arrayOfInt[j] = arrayOfInt[i]; 
    this.mCount--;
    paramSolverVariable.usageInRowCount--;
    if (paramBoolean)
      paramSolverVariable.removeFromRow(this.mRow); 
    return f;
  }
  
  public int sizeInBytes() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(hashCode());
    stringBuilder1.append(" { ");
    String str = stringBuilder1.toString();
    int j = this.mCount;
    for (int i = 0; i < j; i++) {
      SolverVariable solverVariable = getVariable(i);
      if (solverVariable != null) {
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str);
        stringBuilder4.append(solverVariable);
        stringBuilder4.append(" = ");
        stringBuilder4.append(getVariableValue(i));
        stringBuilder4.append(" ");
        str = stringBuilder4.toString();
        int k = indexOf(solverVariable);
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append("[p: ");
        str = stringBuilder3.toString();
        if (this.previous[k] != -1) {
          stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str);
          stringBuilder3.append(this.mCache.mIndexedVariables[this.variables[this.previous[k]]]);
          str = stringBuilder3.toString();
        } else {
          stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str);
          stringBuilder3.append("none");
          str = stringBuilder3.toString();
        } 
        stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(", n: ");
        str = stringBuilder3.toString();
        if (this.next[k] != -1) {
          stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str);
          stringBuilder3.append(this.mCache.mIndexedVariables[this.variables[this.next[k]]]);
          str = stringBuilder3.toString();
        } else {
          stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str);
          stringBuilder3.append("none");
          str = stringBuilder3.toString();
        } 
        stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append("]");
        str = stringBuilder3.toString();
      } 
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append(" }");
    return stringBuilder2.toString();
  }
  
  public float use(ArrayRow paramArrayRow, boolean paramBoolean) {
    float f = get(paramArrayRow.variable);
    remove(paramArrayRow.variable, paramBoolean);
    SolverVariableValues solverVariableValues = (SolverVariableValues)paramArrayRow.variables;
    int k = solverVariableValues.getCurrentSize();
    int i = solverVariableValues.head;
    int j = 0;
    i = 0;
    while (j < k) {
      int m = j;
      if (solverVariableValues.variables[i] != -1) {
        float f1 = solverVariableValues.values[i];
        add(this.mCache.mIndexedVariables[solverVariableValues.variables[i]], f1 * f, paramBoolean);
        m = j + 1;
      } 
      i++;
      j = m;
    } 
    return f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\SolverVariableValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */