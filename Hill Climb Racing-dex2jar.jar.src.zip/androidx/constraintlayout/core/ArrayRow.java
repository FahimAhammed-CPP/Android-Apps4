package androidx.constraintlayout.core;

import java.util.ArrayList;

public class ArrayRow implements LinearSystem.Row {
  private static final boolean DEBUG = false;
  
  private static final boolean FULL_NEW_CHECK = false;
  
  float constantValue = 0.0F;
  
  boolean isSimpleDefinition = false;
  
  boolean used = false;
  
  SolverVariable variable = null;
  
  public ArrayRowVariables variables;
  
  ArrayList<SolverVariable> variablesToUpdate = new ArrayList<SolverVariable>();
  
  public ArrayRow() {}
  
  public ArrayRow(Cache paramCache) {
    this.variables = new ArrayLinkedVariables(this, paramCache);
  }
  
  private boolean isNew(SolverVariable paramSolverVariable, LinearSystem paramLinearSystem) {
    return (paramSolverVariable.usageInRowCount <= 1);
  }
  
  private SolverVariable pickPivotInVariables(boolean[] paramArrayOfboolean, SolverVariable paramSolverVariable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   4: invokeinterface getCurrentSize : ()I
    //   9: istore #7
    //   11: aconst_null
    //   12: astore #8
    //   14: iconst_0
    //   15: istore #6
    //   17: fconst_0
    //   18: fstore_3
    //   19: iload #6
    //   21: iload #7
    //   23: if_icmpge -> 167
    //   26: aload_0
    //   27: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   30: iload #6
    //   32: invokeinterface getVariableValue : (I)F
    //   37: fstore #5
    //   39: aload #8
    //   41: astore #9
    //   43: fload_3
    //   44: fstore #4
    //   46: fload #5
    //   48: fconst_0
    //   49: fcmpg
    //   50: ifge -> 151
    //   53: aload_0
    //   54: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   57: iload #6
    //   59: invokeinterface getVariable : (I)Landroidx/constraintlayout/core/SolverVariable;
    //   64: astore #10
    //   66: aload_1
    //   67: ifnull -> 87
    //   70: aload #8
    //   72: astore #9
    //   74: fload_3
    //   75: fstore #4
    //   77: aload_1
    //   78: aload #10
    //   80: getfield id : I
    //   83: baload
    //   84: ifne -> 151
    //   87: aload #8
    //   89: astore #9
    //   91: fload_3
    //   92: fstore #4
    //   94: aload #10
    //   96: aload_2
    //   97: if_acmpeq -> 151
    //   100: aload #10
    //   102: getfield mType : Landroidx/constraintlayout/core/SolverVariable$Type;
    //   105: getstatic androidx/constraintlayout/core/SolverVariable$Type.SLACK : Landroidx/constraintlayout/core/SolverVariable$Type;
    //   108: if_acmpeq -> 129
    //   111: aload #8
    //   113: astore #9
    //   115: fload_3
    //   116: fstore #4
    //   118: aload #10
    //   120: getfield mType : Landroidx/constraintlayout/core/SolverVariable$Type;
    //   123: getstatic androidx/constraintlayout/core/SolverVariable$Type.ERROR : Landroidx/constraintlayout/core/SolverVariable$Type;
    //   126: if_acmpne -> 151
    //   129: aload #8
    //   131: astore #9
    //   133: fload_3
    //   134: fstore #4
    //   136: fload #5
    //   138: fload_3
    //   139: fcmpg
    //   140: ifge -> 151
    //   143: fload #5
    //   145: fstore #4
    //   147: aload #10
    //   149: astore #9
    //   151: iload #6
    //   153: iconst_1
    //   154: iadd
    //   155: istore #6
    //   157: aload #9
    //   159: astore #8
    //   161: fload #4
    //   163: fstore_3
    //   164: goto -> 19
    //   167: aload #8
    //   169: areturn
  }
  
  public ArrayRow addError(LinearSystem paramLinearSystem, int paramInt) {
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, "ep"), 1.0F);
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, "em"), -1.0F);
    return this;
  }
  
  public void addError(SolverVariable paramSolverVariable) {
    int i = paramSolverVariable.strength;
    float f = 1.0F;
    if (i != 1)
      if (paramSolverVariable.strength == 2) {
        f = 1000.0F;
      } else if (paramSolverVariable.strength == 3) {
        f = 1000000.0F;
      } else if (paramSolverVariable.strength == 4) {
        f = 1.0E9F;
      } else if (paramSolverVariable.strength == 5) {
        f = 1.0E12F;
      }  
    this.variables.put(paramSolverVariable, f);
  }
  
  ArrayRow addSingleError(SolverVariable paramSolverVariable, int paramInt) {
    this.variables.put(paramSolverVariable, paramInt);
    return this;
  }
  
  boolean chooseSubject(LinearSystem paramLinearSystem) {
    boolean bool;
    SolverVariable solverVariable = chooseSubjectInVariables(paramLinearSystem);
    if (solverVariable == null) {
      bool = true;
    } else {
      pivot(solverVariable);
      bool = false;
    } 
    if (this.variables.getCurrentSize() == 0)
      this.isSimpleDefinition = true; 
    return bool;
  }
  
  SolverVariable chooseSubjectInVariables(LinearSystem paramLinearSystem) {
    int j = this.variables.getCurrentSize();
    SolverVariable solverVariable2 = null;
    SolverVariable solverVariable1 = null;
    int i = 0;
    boolean bool2 = false;
    boolean bool1 = false;
    float f2 = 0.0F;
    float f1;
    for (f1 = 0.0F;; f1 = f4) {
      float f3;
      float f4;
      boolean bool3;
      boolean bool4;
      SolverVariable solverVariable3;
      SolverVariable solverVariable4;
      if (i < j) {
        float f = this.variables.getVariableValue(i);
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.mType == SolverVariable.Type.UNRESTRICTED) {
          if (solverVariable2 == null) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else if (f2 > f) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else {
            SolverVariable solverVariable5 = solverVariable2;
            SolverVariable solverVariable6 = solverVariable1;
            bool3 = bool2;
            boolean bool = bool1;
            float f5 = f2;
            float f6 = f1;
            if (!bool2) {
              solverVariable5 = solverVariable2;
              solverVariable6 = solverVariable1;
              bool3 = bool2;
              bool = bool1;
              f5 = f2;
              f6 = f1;
              if (isNew(solverVariable, paramLinearSystem)) {
                bool3 = true;
                solverVariable5 = solverVariable;
                solverVariable6 = solverVariable1;
                bool = bool1;
                f5 = f;
                f6 = f1;
              } 
            } 
            i++;
            solverVariable2 = solverVariable5;
            solverVariable1 = solverVariable6;
            bool2 = bool3;
            bool1 = bool;
            f2 = f5;
            f1 = f6;
          } 
          solverVariable3 = solverVariable;
          solverVariable4 = solverVariable1;
          bool4 = bool1;
          f3 = f;
          f4 = f1;
        } else {
          solverVariable3 = solverVariable2;
          solverVariable4 = solverVariable1;
          bool3 = bool2;
          bool4 = bool1;
          f3 = f2;
          f4 = f1;
          if (solverVariable2 == null) {
            solverVariable3 = solverVariable2;
            solverVariable4 = solverVariable1;
            bool3 = bool2;
            bool4 = bool1;
            f3 = f2;
            f4 = f1;
            if (f < 0.0F) {
              if (solverVariable1 == null) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else if (f1 > f) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else {
                solverVariable3 = solverVariable2;
                solverVariable4 = solverVariable1;
                bool3 = bool2;
                bool4 = bool1;
                f3 = f2;
                f4 = f1;
                if (!bool1) {
                  solverVariable3 = solverVariable2;
                  solverVariable4 = solverVariable1;
                  bool3 = bool2;
                  bool4 = bool1;
                  f3 = f2;
                  f4 = f1;
                  if (isNew(solverVariable, paramLinearSystem)) {
                    bool4 = true;
                    f4 = f;
                    f3 = f2;
                    bool3 = bool2;
                    solverVariable4 = solverVariable;
                    solverVariable3 = solverVariable2;
                  } 
                } 
                i++;
                solverVariable2 = solverVariable3;
                solverVariable1 = solverVariable4;
                bool2 = bool3;
                bool1 = bool4;
                f2 = f3;
                f1 = f4;
              } 
              bool4 = bool3;
              solverVariable3 = solverVariable2;
              solverVariable4 = solverVariable;
              bool3 = bool2;
              f3 = f2;
              f4 = f;
            } 
          } 
        } 
      } else {
        break;
      } 
      i++;
      solverVariable2 = solverVariable3;
      solverVariable1 = solverVariable4;
      bool2 = bool3;
      bool1 = bool4;
      f2 = f3;
    } 
    return (solverVariable2 != null) ? solverVariable2 : solverVariable1;
  }
  
  public void clear() {
    this.variables.clear();
    this.variable = null;
    this.constantValue = 0.0F;
  }
  
  ArrayRow createRowCentering(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, float paramFloat, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, int paramInt2) {
    if (paramSolverVariable2 == paramSolverVariable3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable2, -2.0F);
      return this;
    } 
    if (paramFloat == 0.5F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0) {
        this.constantValue = (-paramInt1 + paramInt2);
        return this;
      } 
    } else {
      if (paramFloat <= 0.0F) {
        this.variables.put(paramSolverVariable1, -1.0F);
        this.variables.put(paramSolverVariable2, 1.0F);
        this.constantValue = paramInt1;
        return this;
      } 
      if (paramFloat >= 1.0F) {
        this.variables.put(paramSolverVariable4, -1.0F);
        this.variables.put(paramSolverVariable3, 1.0F);
        this.constantValue = -paramInt2;
        return this;
      } 
      ArrayRowVariables arrayRowVariables = this.variables;
      float f = 1.0F - paramFloat;
      arrayRowVariables.put(paramSolverVariable1, f * 1.0F);
      this.variables.put(paramSolverVariable2, f * -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F * paramFloat);
      this.variables.put(paramSolverVariable4, 1.0F * paramFloat);
      if (paramInt1 > 0 || paramInt2 > 0)
        this.constantValue = -paramInt1 * f + paramInt2 * paramFloat; 
    } 
    return this;
  }
  
  ArrayRow createRowDefinition(SolverVariable paramSolverVariable, int paramInt) {
    this.variable = paramSolverVariable;
    float f = paramInt;
    paramSolverVariable.computedValue = f;
    this.constantValue = f;
    this.isSimpleDefinition = true;
    return this;
  }
  
  ArrayRow createRowDimensionPercent(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, paramFloat);
    return this;
  }
  
  public ArrayRow createRowDimensionRatio(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, 1.0F);
    this.variables.put(paramSolverVariable3, paramFloat);
    this.variables.put(paramSolverVariable4, -paramFloat);
    return this;
  }
  
  public ArrayRow createRowEqualDimension(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, int paramInt1, SolverVariable paramSolverVariable2, int paramInt2, SolverVariable paramSolverVariable3, int paramInt3, SolverVariable paramSolverVariable4, int paramInt4) {
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.constantValue = (-paramInt1 - paramInt2 + paramInt3 + paramInt4);
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.constantValue = (-paramInt1 - paramInt2) + paramInt3 * paramFloat1 + paramInt4 * paramFloat1;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEqualMatchDimensions(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4) {
    this.constantValue = 0.0F;
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    if (paramFloat1 == 0.0F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      return this;
    } 
    if (paramFloat3 == 0.0F) {
      this.variables.put(paramSolverVariable3, 1.0F);
      this.variables.put(paramSolverVariable4, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable, int paramInt) {
    if (paramInt < 0) {
      this.constantValue = (paramInt * -1);
      this.variables.put(paramSolverVariable, 1.0F);
      return this;
    } 
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable, -1.0F);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, int paramInt, SolverVariable paramSolverVariable2) {
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable1, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, -1.0F);
    return this;
  }
  
  public ArrayRow createRowLowerThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, 1.0F);
    return this;
  }
  
  public ArrayRow createRowWithAngle(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable3, 0.5F);
    this.variables.put(paramSolverVariable4, 0.5F);
    this.variables.put(paramSolverVariable1, -0.5F);
    this.variables.put(paramSolverVariable2, -0.5F);
    this.constantValue = -paramFloat;
    return this;
  }
  
  void ensurePositiveConstant() {
    float f = this.constantValue;
    if (f < 0.0F) {
      this.constantValue = f * -1.0F;
      this.variables.invert();
    } 
  }
  
  public SolverVariable getKey() {
    return this.variable;
  }
  
  public SolverVariable getPivotCandidate(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    return pickPivotInVariables(paramArrayOfboolean, null);
  }
  
  boolean hasKeyVariable() {
    SolverVariable solverVariable = this.variable;
    return (solverVariable != null && (solverVariable.mType == SolverVariable.Type.UNRESTRICTED || this.constantValue >= 0.0F));
  }
  
  boolean hasVariable(SolverVariable paramSolverVariable) {
    return this.variables.contains(paramSolverVariable);
  }
  
  public void initFromRow(LinearSystem.Row paramRow) {
    if (paramRow instanceof ArrayRow) {
      paramRow = paramRow;
      this.variable = null;
      this.variables.clear();
      for (int i = 0; i < ((ArrayRow)paramRow).variables.getCurrentSize(); i++) {
        SolverVariable solverVariable = ((ArrayRow)paramRow).variables.getVariable(i);
        float f = ((ArrayRow)paramRow).variables.getVariableValue(i);
        this.variables.add(solverVariable, f, true);
      } 
    } 
  }
  
  public boolean isEmpty() {
    return (this.variable == null && this.constantValue == 0.0F && this.variables.getCurrentSize() == 0);
  }
  
  public SolverVariable pickPivot(SolverVariable paramSolverVariable) {
    return pickPivotInVariables(null, paramSolverVariable);
  }
  
  void pivot(SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.variable;
    if (solverVariable != null) {
      this.variables.put(solverVariable, -1.0F);
      this.variable.definitionId = -1;
      this.variable = null;
    } 
    float f = this.variables.remove(paramSolverVariable, true) * -1.0F;
    this.variable = paramSolverVariable;
    if (f == 1.0F)
      return; 
    this.constantValue /= f;
    this.variables.divideByAmount(f);
  }
  
  public void reset() {
    this.variable = null;
    this.variables.clear();
    this.constantValue = 0.0F;
    this.isSimpleDefinition = false;
  }
  
  int sizeInBytes() {
    byte b;
    if (this.variable != null) {
      b = 4;
    } else {
      b = 0;
    } 
    return b + 4 + 4 + this.variables.sizeInBytes();
  }
  
  String toReadableString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield variable : Landroidx/constraintlayout/core/SolverVariable;
    //   4: ifnonnull -> 14
    //   7: ldc '0'
    //   9: astore #6
    //   11: goto -> 42
    //   14: new java/lang/StringBuilder
    //   17: dup
    //   18: ldc ''
    //   20: invokespecial <init> : (Ljava/lang/String;)V
    //   23: astore #6
    //   25: aload #6
    //   27: aload_0
    //   28: getfield variable : Landroidx/constraintlayout/core/SolverVariable;
    //   31: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   34: pop
    //   35: aload #6
    //   37: invokevirtual toString : ()Ljava/lang/String;
    //   40: astore #6
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore #7
    //   51: aload #7
    //   53: aload #6
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: pop
    //   59: aload #7
    //   61: ldc ' = '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload #7
    //   69: invokevirtual toString : ()Ljava/lang/String;
    //   72: astore #6
    //   74: aload_0
    //   75: getfield constantValue : F
    //   78: fstore_1
    //   79: iconst_0
    //   80: istore #4
    //   82: fload_1
    //   83: fconst_0
    //   84: fcmpl
    //   85: ifeq -> 127
    //   88: new java/lang/StringBuilder
    //   91: dup
    //   92: invokespecial <init> : ()V
    //   95: astore #7
    //   97: aload #7
    //   99: aload #6
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: pop
    //   105: aload #7
    //   107: aload_0
    //   108: getfield constantValue : F
    //   111: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   114: pop
    //   115: aload #7
    //   117: invokevirtual toString : ()Ljava/lang/String;
    //   120: astore #6
    //   122: iconst_1
    //   123: istore_3
    //   124: goto -> 129
    //   127: iconst_0
    //   128: istore_3
    //   129: aload_0
    //   130: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   133: invokeinterface getCurrentSize : ()I
    //   138: istore #5
    //   140: iload #4
    //   142: iload #5
    //   144: if_icmpge -> 426
    //   147: aload_0
    //   148: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   151: iload #4
    //   153: invokeinterface getVariable : (I)Landroidx/constraintlayout/core/SolverVariable;
    //   158: astore #7
    //   160: aload #7
    //   162: ifnonnull -> 168
    //   165: goto -> 417
    //   168: aload_0
    //   169: getfield variables : Landroidx/constraintlayout/core/ArrayRow$ArrayRowVariables;
    //   172: iload #4
    //   174: invokeinterface getVariableValue : (I)F
    //   179: fstore_2
    //   180: fload_2
    //   181: fconst_0
    //   182: fcmpl
    //   183: ifne -> 189
    //   186: goto -> 417
    //   189: aload #7
    //   191: invokevirtual toString : ()Ljava/lang/String;
    //   194: astore #8
    //   196: iload_3
    //   197: ifne -> 247
    //   200: aload #6
    //   202: astore #7
    //   204: fload_2
    //   205: fstore_1
    //   206: fload_2
    //   207: fconst_0
    //   208: fcmpg
    //   209: ifge -> 327
    //   212: new java/lang/StringBuilder
    //   215: dup
    //   216: invokespecial <init> : ()V
    //   219: astore #7
    //   221: aload #7
    //   223: aload #6
    //   225: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload #7
    //   231: ldc '- '
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload #7
    //   239: invokevirtual toString : ()Ljava/lang/String;
    //   242: astore #7
    //   244: goto -> 322
    //   247: fload_2
    //   248: fconst_0
    //   249: fcmpl
    //   250: ifle -> 290
    //   253: new java/lang/StringBuilder
    //   256: dup
    //   257: invokespecial <init> : ()V
    //   260: astore #7
    //   262: aload #7
    //   264: aload #6
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: pop
    //   270: aload #7
    //   272: ldc ' + '
    //   274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: pop
    //   278: aload #7
    //   280: invokevirtual toString : ()Ljava/lang/String;
    //   283: astore #7
    //   285: fload_2
    //   286: fstore_1
    //   287: goto -> 327
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: astore #7
    //   299: aload #7
    //   301: aload #6
    //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: pop
    //   307: aload #7
    //   309: ldc ' - '
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: pop
    //   315: aload #7
    //   317: invokevirtual toString : ()Ljava/lang/String;
    //   320: astore #7
    //   322: fload_2
    //   323: ldc -1.0
    //   325: fmul
    //   326: fstore_1
    //   327: fload_1
    //   328: fconst_1
    //   329: fcmpl
    //   330: ifne -> 368
    //   333: new java/lang/StringBuilder
    //   336: dup
    //   337: invokespecial <init> : ()V
    //   340: astore #6
    //   342: aload #6
    //   344: aload #7
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: aload #6
    //   352: aload #8
    //   354: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: pop
    //   358: aload #6
    //   360: invokevirtual toString : ()Ljava/lang/String;
    //   363: astore #6
    //   365: goto -> 415
    //   368: new java/lang/StringBuilder
    //   371: dup
    //   372: invokespecial <init> : ()V
    //   375: astore #6
    //   377: aload #6
    //   379: aload #7
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload #6
    //   387: fload_1
    //   388: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: aload #6
    //   394: ldc ' '
    //   396: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   399: pop
    //   400: aload #6
    //   402: aload #8
    //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   407: pop
    //   408: aload #6
    //   410: invokevirtual toString : ()Ljava/lang/String;
    //   413: astore #6
    //   415: iconst_1
    //   416: istore_3
    //   417: iload #4
    //   419: iconst_1
    //   420: iadd
    //   421: istore #4
    //   423: goto -> 140
    //   426: aload #6
    //   428: astore #7
    //   430: iload_3
    //   431: ifne -> 466
    //   434: new java/lang/StringBuilder
    //   437: dup
    //   438: invokespecial <init> : ()V
    //   441: astore #7
    //   443: aload #7
    //   445: aload #6
    //   447: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload #7
    //   453: ldc '0.0'
    //   455: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   458: pop
    //   459: aload #7
    //   461: invokevirtual toString : ()Ljava/lang/String;
    //   464: astore #7
    //   466: aload #7
    //   468: areturn
  }
  
  public String toString() {
    return toReadableString();
  }
  
  public void updateFromFinalVariable(LinearSystem paramLinearSystem, SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (paramSolverVariable != null) {
      if (!paramSolverVariable.isFinalValue)
        return; 
      float f = this.variables.get(paramSolverVariable);
      this.constantValue += paramSolverVariable.computedValue * f;
      this.variables.remove(paramSolverVariable, paramBoolean);
      if (paramBoolean)
        paramSolverVariable.removeFromRow(this); 
      if (LinearSystem.SIMPLIFY_SYNONYMS && this.variables.getCurrentSize() == 0) {
        this.isSimpleDefinition = true;
        paramLinearSystem.hasSimpleDefinition = true;
      } 
    } 
  }
  
  public void updateFromRow(LinearSystem paramLinearSystem, ArrayRow paramArrayRow, boolean paramBoolean) {
    float f = this.variables.use(paramArrayRow, paramBoolean);
    this.constantValue += paramArrayRow.constantValue * f;
    if (paramBoolean)
      paramArrayRow.variable.removeFromRow(this); 
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variable != null && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public void updateFromSynonymVariable(LinearSystem paramLinearSystem, SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (paramSolverVariable != null) {
      if (!paramSolverVariable.isSynonym)
        return; 
      float f = this.variables.get(paramSolverVariable);
      this.constantValue += paramSolverVariable.synonymDelta * f;
      this.variables.remove(paramSolverVariable, paramBoolean);
      if (paramBoolean)
        paramSolverVariable.removeFromRow(this); 
      this.variables.add(paramLinearSystem.mCache.mIndexedVariables[paramSolverVariable.synonym], f, paramBoolean);
      if (LinearSystem.SIMPLIFY_SYNONYMS && this.variables.getCurrentSize() == 0) {
        this.isSimpleDefinition = true;
        paramLinearSystem.hasSimpleDefinition = true;
      } 
    } 
  }
  
  public void updateFromSystem(LinearSystem paramLinearSystem) {
    if (paramLinearSystem.mRows.length == 0)
      return; 
    for (boolean bool = false; !bool; bool = true) {
      int j = this.variables.getCurrentSize();
      int i;
      for (i = 0; i < j; i++) {
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.definitionId != -1 || solverVariable.isFinalValue || solverVariable.isSynonym)
          this.variablesToUpdate.add(solverVariable); 
      } 
      j = this.variablesToUpdate.size();
      if (j > 0) {
        for (i = 0; i < j; i++) {
          SolverVariable solverVariable = this.variablesToUpdate.get(i);
          if (solverVariable.isFinalValue) {
            updateFromFinalVariable(paramLinearSystem, solverVariable, true);
          } else if (solverVariable.isSynonym) {
            updateFromSynonymVariable(paramLinearSystem, solverVariable, true);
          } else {
            updateFromRow(paramLinearSystem, paramLinearSystem.mRows[solverVariable.definitionId], true);
          } 
        } 
        this.variablesToUpdate.clear();
        continue;
      } 
    } 
    if (LinearSystem.SIMPLIFY_SYNONYMS && this.variable != null && this.variables.getCurrentSize() == 0) {
      this.isSimpleDefinition = true;
      paramLinearSystem.hasSimpleDefinition = true;
    } 
  }
  
  public static interface ArrayRowVariables {
    void add(SolverVariable param1SolverVariable, float param1Float, boolean param1Boolean);
    
    void clear();
    
    boolean contains(SolverVariable param1SolverVariable);
    
    void display();
    
    void divideByAmount(float param1Float);
    
    float get(SolverVariable param1SolverVariable);
    
    int getCurrentSize();
    
    SolverVariable getVariable(int param1Int);
    
    float getVariableValue(int param1Int);
    
    int indexOf(SolverVariable param1SolverVariable);
    
    void invert();
    
    void put(SolverVariable param1SolverVariable, float param1Float);
    
    float remove(SolverVariable param1SolverVariable, boolean param1Boolean);
    
    int sizeInBytes();
    
    float use(ArrayRow param1ArrayRow, boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\ArrayRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */