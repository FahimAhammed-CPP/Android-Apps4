package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import androidx.constraintlayout.core.motion.utils.CurveFit;
import androidx.constraintlayout.core.motion.utils.Easing;
import androidx.constraintlayout.core.motion.utils.KeyCache;
import androidx.constraintlayout.core.motion.utils.KeyCycleOscillator;
import androidx.constraintlayout.core.motion.utils.SplineSet;
import androidx.constraintlayout.core.motion.utils.VelocityMatrix;
import androidx.constraintlayout.motion.utils.ViewOscillator;
import androidx.constraintlayout.motion.utils.ViewSpline;
import androidx.constraintlayout.motion.utils.ViewState;
import androidx.constraintlayout.motion.utils.ViewTimeCycle;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class MotionController {
  static final int BOUNCE = 4;
  
  private static final boolean DEBUG = false;
  
  public static final int DRAW_PATH_AS_CONFIGURED = 4;
  
  public static final int DRAW_PATH_BASIC = 1;
  
  public static final int DRAW_PATH_CARTESIAN = 3;
  
  public static final int DRAW_PATH_NONE = 0;
  
  public static final int DRAW_PATH_RECTANGLE = 5;
  
  public static final int DRAW_PATH_RELATIVE = 2;
  
  public static final int DRAW_PATH_SCREEN = 6;
  
  static final int EASE_IN = 1;
  
  static final int EASE_IN_OUT = 0;
  
  static final int EASE_OUT = 2;
  
  private static final boolean FAVOR_FIXED_SIZE_VIEWS = false;
  
  public static final int HORIZONTAL_PATH_X = 2;
  
  public static final int HORIZONTAL_PATH_Y = 3;
  
  private static final int INTERPOLATOR_REFERENCE_ID = -2;
  
  private static final int INTERPOLATOR_UNDEFINED = -3;
  
  static final int LINEAR = 3;
  
  static final int OVERSHOOT = 5;
  
  public static final int PATH_PERCENT = 0;
  
  public static final int PATH_PERPENDICULAR = 1;
  
  public static final int ROTATION_LEFT = 2;
  
  public static final int ROTATION_RIGHT = 1;
  
  private static final int SPLINE_STRING = -1;
  
  private static final String TAG = "MotionController";
  
  public static final int VERTICAL_PATH_X = 4;
  
  public static final int VERTICAL_PATH_Y = 5;
  
  private int MAX_DIMENSION = 4;
  
  String[] attributeTable;
  
  private CurveFit mArcSpline;
  
  private int[] mAttributeInterpolatorCount;
  
  private String[] mAttributeNames;
  
  private HashMap<String, ViewSpline> mAttributesMap;
  
  String mConstraintTag;
  
  float mCurrentCenterX;
  
  float mCurrentCenterY;
  
  private int mCurveFitType = -1;
  
  private HashMap<String, ViewOscillator> mCycleMap;
  
  private MotionPaths mEndMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mEndPoint = new MotionConstrainedPoint();
  
  int mId;
  
  private double[] mInterpolateData;
  
  private int[] mInterpolateVariables;
  
  private double[] mInterpolateVelocity;
  
  private ArrayList<Key> mKeyList = new ArrayList<Key>();
  
  private KeyTrigger[] mKeyTriggers;
  
  private ArrayList<MotionPaths> mMotionPaths = new ArrayList<MotionPaths>();
  
  float mMotionStagger = Float.NaN;
  
  private boolean mNoMovement = false;
  
  private int mPathMotionArc = Key.UNSET;
  
  private Interpolator mQuantizeMotionInterpolator = null;
  
  private float mQuantizeMotionPhase = Float.NaN;
  
  private int mQuantizeMotionSteps = Key.UNSET;
  
  private CurveFit[] mSpline;
  
  float mStaggerOffset = 0.0F;
  
  float mStaggerScale = 1.0F;
  
  private MotionPaths mStartMotionPath = new MotionPaths();
  
  private MotionConstrainedPoint mStartPoint = new MotionConstrainedPoint();
  
  Rect mTempRect = new Rect();
  
  private HashMap<String, ViewTimeCycle> mTimeCycleAttributesMap;
  
  private int mTransformPivotTarget = Key.UNSET;
  
  private View mTransformPivotView = null;
  
  private float[] mValuesBuff = new float[4];
  
  private float[] mVelocity = new float[1];
  
  View mView;
  
  MotionController(View paramView) {
    setView(paramView);
  }
  
  private float getAdjustedPosition(float paramFloat, float[] paramArrayOffloat) {
    float f1;
    float f3 = 0.0F;
    float f4 = 1.0F;
    if (paramArrayOffloat != null) {
      paramArrayOffloat[0] = 1.0F;
      f1 = paramFloat;
    } else {
      float f = this.mStaggerScale;
      f1 = paramFloat;
      if (f != 1.0D) {
        float f6 = this.mStaggerOffset;
        float f5 = paramFloat;
        if (paramFloat < f6)
          f5 = 0.0F; 
        f1 = f5;
        if (f5 > f6) {
          f1 = f5;
          if (f5 < 1.0D)
            f1 = Math.min((f5 - f6) * f, 1.0F); 
        } 
      } 
    } 
    Easing easing = this.mStartMotionPath.mKeyFrameEasing;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    paramFloat = Float.NaN;
    float f2 = f3;
    while (iterator.hasNext()) {
      MotionPaths motionPaths = iterator.next();
      if (motionPaths.mKeyFrameEasing != null) {
        if (motionPaths.time < f1) {
          easing = motionPaths.mKeyFrameEasing;
          f2 = motionPaths.time;
          continue;
        } 
        if (Float.isNaN(paramFloat))
          paramFloat = motionPaths.time; 
      } 
    } 
    f3 = f1;
    if (easing != null) {
      if (Float.isNaN(paramFloat))
        paramFloat = f4; 
      paramFloat -= f2;
      double d = ((f1 - f2) / paramFloat);
      paramFloat = (float)easing.get(d) * paramFloat + f2;
      f3 = paramFloat;
      if (paramArrayOffloat != null) {
        paramArrayOffloat[0] = (float)easing.getDiff(d);
        f3 = paramFloat;
      } 
    } 
    return f3;
  }
  
  private static Interpolator getInterpolator(Context paramContext, int paramInt1, String paramString, int paramInt2) {
    return (Interpolator)((paramInt1 != -2) ? ((paramInt1 != -1) ? ((paramInt1 != 0) ? ((paramInt1 != 1) ? ((paramInt1 != 2) ? ((paramInt1 != 4) ? ((paramInt1 != 5) ? null : new OvershootInterpolator()) : new BounceInterpolator()) : new DecelerateInterpolator()) : new AccelerateInterpolator()) : new AccelerateDecelerateInterpolator()) : new Interpolator(Easing.getInterpolator(paramString)) {
        public float getInterpolation(float param1Float) {
          return (float)easing.get(param1Float);
        }
      }) : AnimationUtils.loadInterpolator(paramContext, paramInt2));
  }
  
  private float getPreCycleDistance() {
    float[] arrayOfFloat = new float[2];
    float f2 = 1.0F / 99;
    double d1 = 0.0D;
    double d2 = d1;
    float f1 = 0.0F;
    int i;
    for (i = 0; i < 100; i++) {
      float f5 = i * f2;
      double d = f5;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      float f3 = Float.NaN;
      float f4;
      for (f4 = 0.0F; iterator.hasNext(); f4 = f7) {
        MotionPaths motionPaths = iterator.next();
        Easing easing1 = easing;
        float f6 = f3;
        float f7 = f4;
        if (motionPaths.mKeyFrameEasing != null)
          if (motionPaths.time < f5) {
            easing1 = motionPaths.mKeyFrameEasing;
            f7 = motionPaths.time;
            f6 = f3;
          } else {
            easing1 = easing;
            f6 = f3;
            f7 = f4;
            if (Float.isNaN(f3)) {
              f6 = motionPaths.time;
              f7 = f4;
              easing1 = easing;
            } 
          }  
        easing = easing1;
        f3 = f6;
      } 
      if (easing != null) {
        float f = f3;
        if (Float.isNaN(f3))
          f = 1.0F; 
        f3 = f - f4;
        d = ((float)easing.get(((f5 - f4) / f3)) * f3 + f4);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      if (i > 0) {
        d = f1;
        double d3 = arrayOfFloat[1];
        Double.isNaN(d3);
        double d4 = arrayOfFloat[0];
        Double.isNaN(d4);
        d1 = Math.hypot(d2 - d3, d1 - d4);
        Double.isNaN(d);
        f1 = (float)(d + d1);
      } 
      d1 = arrayOfFloat[0];
      d2 = arrayOfFloat[1];
    } 
    return f1;
  }
  
  private void insertKey(MotionPaths paramMotionPaths) {
    int i = Collections.binarySearch((List)this.mMotionPaths, paramMotionPaths);
    if (i == 0) {
      StringBuilder stringBuilder = new StringBuilder(" KeyPath position \"");
      stringBuilder.append(paramMotionPaths.position);
      stringBuilder.append("\" outside of range");
      Log.e("MotionController", stringBuilder.toString());
    } 
    this.mMotionPaths.add(-i - 1, paramMotionPaths);
  }
  
  private void readView(MotionPaths paramMotionPaths) {
    paramMotionPaths.setBounds((int)this.mView.getX(), (int)this.mView.getY(), this.mView.getWidth(), this.mView.getHeight());
  }
  
  public void addKey(Key paramKey) {
    this.mKeyList.add(paramKey);
  }
  
  void addKeys(ArrayList<Key> paramArrayList) {
    this.mKeyList.addAll(paramArrayList);
  }
  
  void buildBounds(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    HashMap<String, ViewSpline> hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = (SplineSet)hashMap1.get("translationX"); 
    hashMap1 = this.mAttributesMap;
    if (hashMap1 != null)
      SplineSet splineSet = (SplineSet)hashMap1.get("translationY"); 
    HashMap<String, ViewOscillator> hashMap = this.mCycleMap;
    if (hashMap != null)
      ViewOscillator viewOscillator = hashMap.get("translationX"); 
    hashMap = this.mCycleMap;
    if (hashMap != null)
      ViewOscillator viewOscillator = hashMap.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f5 = this.mStaggerScale;
      float f4 = 0.0F;
      float f1 = f3;
      if (f5 != 1.0F) {
        float f7 = this.mStaggerOffset;
        float f6 = f3;
        if (f3 < f7)
          f6 = 0.0F; 
        f1 = f6;
        if (f6 > f7) {
          f1 = f6;
          if (f6 < 1.0D)
            f1 = Math.min((f6 - f7) * f5, 1.0F); 
        } 
      } 
      double d = f1;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      float f2 = Float.NaN;
      f3 = f4;
      while (iterator.hasNext()) {
        MotionPaths motionPaths = iterator.next();
        if (motionPaths.mKeyFrameEasing != null) {
          if (motionPaths.time < f1) {
            easing = motionPaths.mKeyFrameEasing;
            f3 = motionPaths.time;
            continue;
          } 
          if (Float.isNaN(f2))
            f2 = motionPaths.time; 
        } 
      } 
      if (easing != null) {
        f4 = f2;
        if (Float.isNaN(f2))
          f4 = 1.0F; 
        f2 = f4 - f3;
        d = ((float)easing.get(((f1 - f3) / f2)) * f2 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble = this.mInterpolateData;
        if (arrayOfDouble.length > 0)
          curveFit.getPos(d, arrayOfDouble); 
      } 
      this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 2);
    } 
  }
  
  int buildKeyBounds(float[] paramArrayOffloat, int[] paramArrayOfint) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        for (int k = 0; iterator.hasNext(); k++)
          paramArrayOfint[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getBounds(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  int buildKeyFrames(float[] paramArrayOffloat, int[] paramArrayOfint) {
    if (paramArrayOffloat != null) {
      double[] arrayOfDouble = this.mSpline[0].getTimePoints();
      if (paramArrayOfint != null) {
        Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
        for (int k = 0; iterator.hasNext(); k++)
          paramArrayOfint[k] = ((MotionPaths)iterator.next()).mMode; 
      } 
      int i = 0;
      int j = 0;
      while (i < arrayOfDouble.length) {
        this.mSpline[0].getPos(arrayOfDouble[i], this.mInterpolateData);
        this.mStartMotionPath.getCenter(arrayOfDouble[i], this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
        j += 2;
        i++;
      } 
      return j / 2;
    } 
    return 0;
  }
  
  void buildPath(float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet1;
    SplineSet splineSet2;
    ViewOscillator viewOscillator1;
    float f = 1.0F / (paramInt - 1);
    HashMap<String, ViewSpline> hashMap1 = this.mAttributesMap;
    ViewOscillator viewOscillator2 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = (SplineSet)hashMap1.get("translationX");
    } 
    HashMap<String, ViewSpline> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = (SplineSet)hashMap2.get("translationY");
    } 
    HashMap<String, ViewOscillator> hashMap3 = this.mCycleMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      viewOscillator1 = hashMap3.get("translationX");
    } 
    HashMap<String, ViewOscillator> hashMap4 = this.mCycleMap;
    if (hashMap4 != null)
      viewOscillator2 = hashMap4.get("translationY"); 
    int i;
    for (i = 0; i < paramInt; i++) {
      float f3 = i * f;
      float f5 = this.mStaggerScale;
      float f4 = 0.0F;
      float f1 = f3;
      if (f5 != 1.0F) {
        float f7 = this.mStaggerOffset;
        float f6 = f3;
        if (f3 < f7)
          f6 = 0.0F; 
        f1 = f6;
        if (f6 > f7) {
          f1 = f6;
          if (f6 < 1.0D)
            f1 = Math.min((f6 - f7) * f5, 1.0F); 
        } 
      } 
      double d = f1;
      Easing easing = this.mStartMotionPath.mKeyFrameEasing;
      Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
      float f2 = Float.NaN;
      f3 = f4;
      while (iterator.hasNext()) {
        MotionPaths motionPaths1 = iterator.next();
        f4 = f3;
        Easing easing1 = easing;
        f5 = f2;
        if (motionPaths1.mKeyFrameEasing != null)
          if (motionPaths1.time < f1) {
            easing1 = motionPaths1.mKeyFrameEasing;
            f4 = motionPaths1.time;
            f5 = f2;
          } else {
            f4 = f3;
            easing1 = easing;
            f5 = f2;
            if (Float.isNaN(f2)) {
              f5 = motionPaths1.time;
              easing1 = easing;
              f4 = f3;
            } 
          }  
        f3 = f4;
        easing = easing1;
        f2 = f5;
      } 
      if (easing != null) {
        f4 = f2;
        if (Float.isNaN(f2))
          f4 = 1.0F; 
        f2 = f4 - f3;
        d = ((float)easing.get(((f1 - f3) / f2)) * f2 + f3);
      } 
      this.mSpline[0].getPos(d, this.mInterpolateData);
      CurveFit curveFit = this.mArcSpline;
      if (curveFit != null) {
        double[] arrayOfDouble1 = this.mInterpolateData;
        if (arrayOfDouble1.length > 0)
          curveFit.getPos(d, arrayOfDouble1); 
      } 
      MotionPaths motionPaths = this.mStartMotionPath;
      int[] arrayOfInt = this.mInterpolateVariables;
      double[] arrayOfDouble = this.mInterpolateData;
      int j = i * 2;
      motionPaths.getCenter(d, arrayOfInt, arrayOfDouble, paramArrayOffloat, j);
      if (viewOscillator1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + viewOscillator1.get(f1);
      } else if (splineSet1 != null) {
        paramArrayOffloat[j] = paramArrayOffloat[j] + splineSet1.get(f1);
      } 
      if (viewOscillator2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + viewOscillator2.get(f1);
      } else if (splineSet2 != null) {
        paramArrayOffloat[++j] = paramArrayOffloat[j] + splineSet2.get(f1);
      } 
    } 
  }
  
  void buildRect(float paramFloat, float[] paramArrayOffloat, int paramInt) {
    paramFloat = getAdjustedPosition(paramFloat, null);
    this.mSpline[0].getPos(paramFloat, this.mInterpolateData);
    this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, paramInt);
  }
  
  void buildRectangles(float[] paramArrayOffloat, int paramInt) {
    float f = 1.0F / (paramInt - 1);
    int i;
    for (i = 0; i < paramInt; i++) {
      float f1 = getAdjustedPosition(i * f, null);
      this.mSpline[0].getPos(f1, this.mInterpolateData);
      this.mStartMotionPath.getRect(this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, i * 8);
    } 
  }
  
  void endTrigger(boolean paramBoolean) {
    if ("button".equals(Debug.getName(this.mView)) && this.mKeyTriggers != null) {
      int i = 0;
      while (true) {
        KeyTrigger[] arrayOfKeyTrigger = this.mKeyTriggers;
        if (i < arrayOfKeyTrigger.length) {
          float f;
          KeyTrigger keyTrigger = arrayOfKeyTrigger[i];
          if (paramBoolean) {
            f = -100.0F;
          } else {
            f = 100.0F;
          } 
          keyTrigger.conditionallyFire(f, this.mView);
          i++;
          continue;
        } 
        break;
      } 
    } 
  }
  
  public int getAnimateRelativeTo() {
    return this.mStartMotionPath.mAnimateRelativeTo;
  }
  
  int getAttributeValues(String paramString, float[] paramArrayOffloat, int paramInt) {
    SplineSet splineSet = (SplineSet)this.mAttributesMap.get(paramString);
    if (splineSet == null)
      return -1; 
    for (paramInt = 0; paramInt < paramArrayOffloat.length; paramInt++)
      paramArrayOffloat[paramInt] = splineSet.get((paramInt / (paramArrayOffloat.length - 1))); 
    return paramArrayOffloat.length;
  }
  
  public void getCenter(double paramDouble, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = new double[4];
    this.mSpline[0].getPos(paramDouble, arrayOfDouble1);
    this.mSpline[0].getSlope(paramDouble, arrayOfDouble2);
    Arrays.fill(paramArrayOffloat2, 0.0F);
    this.mStartMotionPath.getCenter(paramDouble, this.mInterpolateVariables, arrayOfDouble1, paramArrayOffloat1, arrayOfDouble2, paramArrayOffloat2);
  }
  
  public float getCenterX() {
    return this.mCurrentCenterX;
  }
  
  public float getCenterY() {
    return this.mCurrentCenterY;
  }
  
  void getDpDt(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      CurveFit curveFit = arrayOfCurveFit[0];
      double d = paramFloat1;
      curveFit.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        double[] arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          double d1 = arrayOfDouble[i];
          double d2 = paramFloat1;
          Double.isNaN(d2);
          arrayOfDouble[i] = d1 * d2;
          i++;
          continue;
        } 
        curveFit = this.mArcSpline;
        if (curveFit != null) {
          arrayOfDouble = this.mInterpolateData;
          if (arrayOfDouble.length > 0) {
            curveFit.getPos(d, arrayOfDouble);
            this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
            this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
          } 
          return;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        return;
      } 
    } 
    paramFloat1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f1 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f2 = this.mEndMotionPath.width;
    float f3 = this.mStartMotionPath.width;
    float f4 = this.mEndMotionPath.height;
    float f5 = this.mStartMotionPath.height;
    paramArrayOffloat[0] = paramFloat1 * (1.0F - paramFloat2) + (f2 - f3 + paramFloat1) * paramFloat2;
    paramArrayOffloat[1] = f1 * (1.0F - paramFloat3) + (f4 - f5 + f1) * paramFloat3;
  }
  
  public int getDrawPath() {
    int i = this.mStartMotionPath.mDrawPath;
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    while (iterator.hasNext())
      i = Math.max(i, ((MotionPaths)iterator.next()).mDrawPath); 
    return Math.max(i, this.mEndMotionPath.mDrawPath);
  }
  
  public float getFinalHeight() {
    return this.mEndMotionPath.height;
  }
  
  public float getFinalWidth() {
    return this.mEndMotionPath.width;
  }
  
  public float getFinalX() {
    return this.mEndMotionPath.x;
  }
  
  public float getFinalY() {
    return this.mEndMotionPath.y;
  }
  
  MotionPaths getKeyFrame(int paramInt) {
    return this.mMotionPaths.get(paramInt);
  }
  
  public int getKeyFrameInfo(int paramInt, int[] paramArrayOfint) {
    float[] arrayOfFloat = new float[2];
    Iterator<Key> iterator = this.mKeyList.iterator();
    int i = 0;
    int j;
    for (j = 0; iterator.hasNext(); j = k) {
      Key key = iterator.next();
      if (key.mType != paramInt && paramInt == -1)
        continue; 
      paramArrayOfint[j] = 0;
      int k = j + 1;
      paramArrayOfint[k] = key.mType;
      paramArrayOfint[++k] = key.mFramePosition;
      float f = key.mFramePosition / 100.0F;
      CurveFit curveFit = this.mSpline[0];
      double d = f;
      curveFit.getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, arrayOfFloat, 0);
      paramArrayOfint[++k] = Float.floatToIntBits(arrayOfFloat[0]);
      int m = k + 1;
      paramArrayOfint[m] = Float.floatToIntBits(arrayOfFloat[1]);
      k = m;
      if (key instanceof KeyPosition) {
        key = key;
        k = m + 1;
        paramArrayOfint[k] = ((KeyPosition)key).mPositionType;
        paramArrayOfint[++k] = Float.floatToIntBits(((KeyPosition)key).mPercentX);
        paramArrayOfint[++k] = Float.floatToIntBits(((KeyPosition)key).mPercentY);
      } 
      paramArrayOfint[j] = ++k - j;
      i++;
    } 
    return i;
  }
  
  float getKeyFrameParameter(int paramInt, float paramFloat1, float paramFloat2) {
    float f1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f2 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f6 = this.mStartMotionPath.x;
    float f7 = this.mStartMotionPath.width / 2.0F;
    float f4 = this.mStartMotionPath.y;
    float f5 = this.mStartMotionPath.height / 2.0F;
    float f3 = (float)Math.hypot(f1, f2);
    if (f3 < 1.0E-7D)
      return Float.NaN; 
    paramFloat1 -= f6 + f7;
    paramFloat2 -= f4 + f5;
    if ((float)Math.hypot(paramFloat1, paramFloat2) == 0.0F)
      return 0.0F; 
    f4 = paramFloat1 * f1 + paramFloat2 * f2;
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? 0.0F : (paramFloat2 / f2)) : (paramFloat1 / f2)) : (paramFloat2 / f1)) : (paramFloat1 / f1)) : (float)Math.sqrt((f3 * f3 - f4 * f4))) : (f4 / f3);
  }
  
  public int getKeyFramePositions(int[] paramArrayOfint, float[] paramArrayOffloat) {
    Iterator<Key> iterator = this.mKeyList.iterator();
    int i = 0;
    int j = 0;
    while (iterator.hasNext()) {
      Key key = iterator.next();
      paramArrayOfint[i] = key.mFramePosition + key.mType * 1000;
      float f = key.mFramePosition / 100.0F;
      CurveFit curveFit = this.mSpline[0];
      double d = f;
      curveFit.getPos(d, this.mInterpolateData);
      this.mStartMotionPath.getCenter(d, this.mInterpolateVariables, this.mInterpolateData, paramArrayOffloat, j);
      j += 2;
      i++;
    } 
    return i;
  }
  
  double[] getPos(double paramDouble) {
    this.mSpline[0].getPos(paramDouble, this.mInterpolateData);
    CurveFit curveFit = this.mArcSpline;
    if (curveFit != null) {
      double[] arrayOfDouble = this.mInterpolateData;
      if (arrayOfDouble.length > 0)
        curveFit.getPos(paramDouble, arrayOfDouble); 
    } 
    return this.mInterpolateData;
  }
  
  KeyPositionBase getPositionKeyframe(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
    RectF rectF1 = new RectF();
    rectF1.left = this.mStartMotionPath.x;
    rectF1.top = this.mStartMotionPath.y;
    rectF1.right = rectF1.left + this.mStartMotionPath.width;
    rectF1.bottom = rectF1.top + this.mStartMotionPath.height;
    RectF rectF2 = new RectF();
    rectF2.left = this.mEndMotionPath.x;
    rectF2.top = this.mEndMotionPath.y;
    rectF2.right = rectF2.left + this.mEndMotionPath.width;
    rectF2.bottom = rectF2.top + this.mEndMotionPath.height;
    for (Key key : this.mKeyList) {
      if (key instanceof KeyPositionBase) {
        key = key;
        if (key.intersects(paramInt1, paramInt2, rectF1, rectF2, paramFloat1, paramFloat2))
          return (KeyPositionBase)key; 
      } 
    } 
    return null;
  }
  
  void getPostLayoutDvDp(float paramFloat1, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    SplineSet splineSet1;
    double[] arrayOfDouble;
    SplineSet splineSet2;
    SplineSet splineSet3;
    SplineSet splineSet4;
    SplineSet splineSet5;
    ViewOscillator viewOscillator1;
    ViewOscillator viewOscillator2;
    ViewOscillator viewOscillator3;
    ViewOscillator viewOscillator4;
    paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
    HashMap<String, ViewSpline> hashMap1 = this.mAttributesMap;
    ViewOscillator viewOscillator5 = null;
    if (hashMap1 == null) {
      hashMap1 = null;
    } else {
      splineSet1 = (SplineSet)hashMap1.get("translationX");
    } 
    HashMap<String, ViewSpline> hashMap2 = this.mAttributesMap;
    if (hashMap2 == null) {
      hashMap2 = null;
    } else {
      splineSet2 = (SplineSet)hashMap2.get("translationY");
    } 
    HashMap<String, ViewSpline> hashMap3 = this.mAttributesMap;
    if (hashMap3 == null) {
      hashMap3 = null;
    } else {
      splineSet3 = (SplineSet)hashMap3.get("rotation");
    } 
    HashMap<String, ViewSpline> hashMap4 = this.mAttributesMap;
    if (hashMap4 == null) {
      hashMap4 = null;
    } else {
      splineSet4 = (SplineSet)hashMap4.get("scaleX");
    } 
    HashMap<String, ViewSpline> hashMap5 = this.mAttributesMap;
    if (hashMap5 == null) {
      hashMap5 = null;
    } else {
      splineSet5 = (SplineSet)hashMap5.get("scaleY");
    } 
    HashMap<String, ViewOscillator> hashMap6 = this.mCycleMap;
    if (hashMap6 == null) {
      hashMap6 = null;
    } else {
      viewOscillator1 = hashMap6.get("translationX");
    } 
    HashMap<String, ViewOscillator> hashMap7 = this.mCycleMap;
    if (hashMap7 == null) {
      hashMap7 = null;
    } else {
      viewOscillator2 = hashMap7.get("translationY");
    } 
    HashMap<String, ViewOscillator> hashMap8 = this.mCycleMap;
    if (hashMap8 == null) {
      hashMap8 = null;
    } else {
      viewOscillator3 = hashMap8.get("rotation");
    } 
    HashMap<String, ViewOscillator> hashMap9 = this.mCycleMap;
    if (hashMap9 == null) {
      hashMap9 = null;
    } else {
      viewOscillator4 = hashMap9.get("scaleX");
    } 
    HashMap<String, ViewOscillator> hashMap10 = this.mCycleMap;
    if (hashMap10 != null)
      viewOscillator5 = hashMap10.get("scaleY"); 
    VelocityMatrix velocityMatrix = new VelocityMatrix();
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity(splineSet1, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity((KeyCycleOscillator)viewOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity((KeyCycleOscillator)viewOscillator1, (KeyCycleOscillator)viewOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity((KeyCycleOscillator)viewOscillator4, (KeyCycleOscillator)viewOscillator5, paramFloat1);
    CurveFit curveFit = this.mArcSpline;
    if (curveFit != null) {
      arrayOfDouble = this.mInterpolateData;
      if (arrayOfDouble.length > 0) {
        double d = paramFloat1;
        curveFit.getPos(d, arrayOfDouble);
        this.mArcSpline.getSlope(d, this.mInterpolateVelocity);
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, this.mInterpolateVelocity, this.mInterpolateData);
      } 
      velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
      return;
    } 
    CurveFit[] arrayOfCurveFit = this.mSpline;
    int i = 0;
    if (arrayOfCurveFit != null) {
      paramFloat1 = getAdjustedPosition(paramFloat1, this.mVelocity);
      CurveFit curveFit1 = this.mSpline[0];
      double d = paramFloat1;
      curveFit1.getSlope(d, this.mInterpolateVelocity);
      this.mSpline[0].getPos(d, this.mInterpolateData);
      paramFloat1 = this.mVelocity[0];
      while (true) {
        arrayOfDouble = this.mInterpolateVelocity;
        if (i < arrayOfDouble.length) {
          d = arrayOfDouble[i];
          double d1 = paramFloat1;
          Double.isNaN(d1);
          arrayOfDouble[i] = d * d1;
          i++;
          continue;
        } 
        this.mStartMotionPath.setDpDt(paramFloat2, paramFloat3, paramArrayOffloat, this.mInterpolateVariables, arrayOfDouble, this.mInterpolateData);
        velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
        return;
      } 
    } 
    float f1 = this.mEndMotionPath.x - this.mStartMotionPath.x;
    float f2 = this.mEndMotionPath.y - this.mStartMotionPath.y;
    float f3 = this.mEndMotionPath.width;
    float f4 = this.mStartMotionPath.width;
    float f5 = this.mEndMotionPath.height;
    float f6 = this.mStartMotionPath.height;
    paramArrayOffloat[0] = f1 * (1.0F - paramFloat2) + (f3 - f4 + f1) * paramFloat2;
    paramArrayOffloat[1] = f2 * (1.0F - paramFloat3) + (f5 - f6 + f2) * paramFloat3;
    velocityMatrix.clear();
    velocityMatrix.setRotationVelocity(splineSet3, paramFloat1);
    velocityMatrix.setTranslationVelocity((SplineSet)arrayOfDouble, splineSet2, paramFloat1);
    velocityMatrix.setScaleVelocity(splineSet4, splineSet5, paramFloat1);
    velocityMatrix.setRotationVelocity((KeyCycleOscillator)viewOscillator3, paramFloat1);
    velocityMatrix.setTranslationVelocity((KeyCycleOscillator)viewOscillator1, (KeyCycleOscillator)viewOscillator2, paramFloat1);
    velocityMatrix.setScaleVelocity((KeyCycleOscillator)viewOscillator4, (KeyCycleOscillator)viewOscillator5, paramFloat1);
    velocityMatrix.applyTransform(paramFloat2, paramFloat3, paramInt1, paramInt2, paramArrayOffloat);
  }
  
  public float getStartHeight() {
    return this.mStartMotionPath.height;
  }
  
  public float getStartWidth() {
    return this.mStartMotionPath.width;
  }
  
  public float getStartX() {
    return this.mStartMotionPath.x;
  }
  
  public float getStartY() {
    return this.mStartMotionPath.y;
  }
  
  public int getTransformPivotTarget() {
    return this.mTransformPivotTarget;
  }
  
  public View getView() {
    return this.mView;
  }
  
  boolean interpolate(View paramView, float paramFloat, long paramLong, KeyCache paramKeyCache) {
    // Byte code:
    //   0: aload_0
    //   1: fload_2
    //   2: aconst_null
    //   3: invokespecial getAdjustedPosition : (F[F)F
    //   6: fstore #8
    //   8: fload #8
    //   10: fstore_2
    //   11: aload_0
    //   12: getfield mQuantizeMotionSteps : I
    //   15: getstatic androidx/constraintlayout/motion/widget/Key.UNSET : I
    //   18: if_icmpeq -> 125
    //   21: fconst_1
    //   22: aload_0
    //   23: getfield mQuantizeMotionSteps : I
    //   26: i2f
    //   27: fdiv
    //   28: fstore #9
    //   30: fload #8
    //   32: fload #9
    //   34: fdiv
    //   35: f2d
    //   36: invokestatic floor : (D)D
    //   39: d2f
    //   40: fstore #10
    //   42: fload #8
    //   44: fload #9
    //   46: frem
    //   47: fload #9
    //   49: fdiv
    //   50: fstore #8
    //   52: fload #8
    //   54: fstore_2
    //   55: aload_0
    //   56: getfield mQuantizeMotionPhase : F
    //   59: invokestatic isNaN : (F)Z
    //   62: ifne -> 75
    //   65: fload #8
    //   67: aload_0
    //   68: getfield mQuantizeMotionPhase : F
    //   71: fadd
    //   72: fconst_1
    //   73: frem
    //   74: fstore_2
    //   75: aload_0
    //   76: getfield mQuantizeMotionInterpolator : Landroid/view/animation/Interpolator;
    //   79: astore #26
    //   81: aload #26
    //   83: ifnull -> 98
    //   86: aload #26
    //   88: fload_2
    //   89: invokeinterface getInterpolation : (F)F
    //   94: fstore_2
    //   95: goto -> 114
    //   98: fload_2
    //   99: f2d
    //   100: ldc2_w 0.5
    //   103: dcmpl
    //   104: ifle -> 112
    //   107: fconst_1
    //   108: fstore_2
    //   109: goto -> 114
    //   112: fconst_0
    //   113: fstore_2
    //   114: fload_2
    //   115: fload #9
    //   117: fmul
    //   118: fload #10
    //   120: fload #9
    //   122: fmul
    //   123: fadd
    //   124: fstore_2
    //   125: aload_0
    //   126: getfield mAttributesMap : Ljava/util/HashMap;
    //   129: astore #26
    //   131: aload #26
    //   133: ifnull -> 176
    //   136: aload #26
    //   138: invokevirtual values : ()Ljava/util/Collection;
    //   141: invokeinterface iterator : ()Ljava/util/Iterator;
    //   146: astore #26
    //   148: aload #26
    //   150: invokeinterface hasNext : ()Z
    //   155: ifeq -> 176
    //   158: aload #26
    //   160: invokeinterface next : ()Ljava/lang/Object;
    //   165: checkcast androidx/constraintlayout/motion/utils/ViewSpline
    //   168: aload_1
    //   169: fload_2
    //   170: invokevirtual setProperty : (Landroid/view/View;F)V
    //   173: goto -> 148
    //   176: aload_0
    //   177: getfield mTimeCycleAttributesMap : Ljava/util/HashMap;
    //   180: astore #26
    //   182: aload #26
    //   184: ifnull -> 266
    //   187: aload #26
    //   189: invokevirtual values : ()Ljava/util/Collection;
    //   192: invokeinterface iterator : ()Ljava/util/Iterator;
    //   197: astore #27
    //   199: aconst_null
    //   200: astore #26
    //   202: iconst_0
    //   203: istore #24
    //   205: aload #27
    //   207: invokeinterface hasNext : ()Z
    //   212: ifeq -> 263
    //   215: aload #27
    //   217: invokeinterface next : ()Ljava/lang/Object;
    //   222: checkcast androidx/constraintlayout/motion/utils/ViewTimeCycle
    //   225: astore #28
    //   227: aload #28
    //   229: instanceof androidx/constraintlayout/motion/utils/ViewTimeCycle$PathRotate
    //   232: ifeq -> 245
    //   235: aload #28
    //   237: checkcast androidx/constraintlayout/motion/utils/ViewTimeCycle$PathRotate
    //   240: astore #26
    //   242: goto -> 205
    //   245: iload #24
    //   247: aload #28
    //   249: aload_1
    //   250: fload_2
    //   251: lload_3
    //   252: aload #5
    //   254: invokevirtual setProperty : (Landroid/view/View;FJLandroidx/constraintlayout/core/motion/utils/KeyCache;)Z
    //   257: ior
    //   258: istore #24
    //   260: goto -> 205
    //   263: goto -> 272
    //   266: aconst_null
    //   267: astore #26
    //   269: iconst_0
    //   270: istore #24
    //   272: aload_0
    //   273: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   276: astore #27
    //   278: aload #27
    //   280: ifnull -> 853
    //   283: aload #27
    //   285: iconst_0
    //   286: aaload
    //   287: astore #27
    //   289: fload_2
    //   290: f2d
    //   291: dstore #6
    //   293: aload #27
    //   295: dload #6
    //   297: aload_0
    //   298: getfield mInterpolateData : [D
    //   301: invokevirtual getPos : (D[D)V
    //   304: aload_0
    //   305: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   308: iconst_0
    //   309: aaload
    //   310: dload #6
    //   312: aload_0
    //   313: getfield mInterpolateVelocity : [D
    //   316: invokevirtual getSlope : (D[D)V
    //   319: aload_0
    //   320: getfield mArcSpline : Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   323: astore #27
    //   325: aload #27
    //   327: ifnull -> 364
    //   330: aload_0
    //   331: getfield mInterpolateData : [D
    //   334: astore #28
    //   336: aload #28
    //   338: arraylength
    //   339: ifle -> 364
    //   342: aload #27
    //   344: dload #6
    //   346: aload #28
    //   348: invokevirtual getPos : (D[D)V
    //   351: aload_0
    //   352: getfield mArcSpline : Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   355: dload #6
    //   357: aload_0
    //   358: getfield mInterpolateVelocity : [D
    //   361: invokevirtual getSlope : (D[D)V
    //   364: aload_0
    //   365: getfield mNoMovement : Z
    //   368: ifne -> 396
    //   371: aload_0
    //   372: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   375: fload_2
    //   376: aload_1
    //   377: aload_0
    //   378: getfield mInterpolateVariables : [I
    //   381: aload_0
    //   382: getfield mInterpolateData : [D
    //   385: aload_0
    //   386: getfield mInterpolateVelocity : [D
    //   389: aconst_null
    //   390: invokevirtual setView : (FLandroid/view/View;[I[D[D[D)V
    //   393: goto -> 396
    //   396: aload_0
    //   397: getfield mTransformPivotTarget : I
    //   400: getstatic androidx/constraintlayout/motion/widget/Key.UNSET : I
    //   403: if_icmpeq -> 536
    //   406: aload_0
    //   407: getfield mTransformPivotView : Landroid/view/View;
    //   410: ifnonnull -> 431
    //   413: aload_0
    //   414: aload_1
    //   415: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   418: checkcast android/view/View
    //   421: aload_0
    //   422: getfield mTransformPivotTarget : I
    //   425: invokevirtual findViewById : (I)Landroid/view/View;
    //   428: putfield mTransformPivotView : Landroid/view/View;
    //   431: aload_0
    //   432: getfield mTransformPivotView : Landroid/view/View;
    //   435: astore #27
    //   437: aload #27
    //   439: ifnull -> 536
    //   442: aload #27
    //   444: invokevirtual getTop : ()I
    //   447: aload_0
    //   448: getfield mTransformPivotView : Landroid/view/View;
    //   451: invokevirtual getBottom : ()I
    //   454: iadd
    //   455: i2f
    //   456: fconst_2
    //   457: fdiv
    //   458: fstore #8
    //   460: aload_0
    //   461: getfield mTransformPivotView : Landroid/view/View;
    //   464: invokevirtual getLeft : ()I
    //   467: aload_0
    //   468: getfield mTransformPivotView : Landroid/view/View;
    //   471: invokevirtual getRight : ()I
    //   474: iadd
    //   475: i2f
    //   476: fconst_2
    //   477: fdiv
    //   478: fstore #9
    //   480: aload_1
    //   481: invokevirtual getRight : ()I
    //   484: aload_1
    //   485: invokevirtual getLeft : ()I
    //   488: isub
    //   489: ifle -> 536
    //   492: aload_1
    //   493: invokevirtual getBottom : ()I
    //   496: aload_1
    //   497: invokevirtual getTop : ()I
    //   500: isub
    //   501: ifle -> 536
    //   504: aload_1
    //   505: invokevirtual getLeft : ()I
    //   508: i2f
    //   509: fstore #10
    //   511: aload_1
    //   512: invokevirtual getTop : ()I
    //   515: i2f
    //   516: fstore #11
    //   518: aload_1
    //   519: fload #9
    //   521: fload #10
    //   523: fsub
    //   524: invokevirtual setPivotX : (F)V
    //   527: aload_1
    //   528: fload #8
    //   530: fload #11
    //   532: fsub
    //   533: invokevirtual setPivotY : (F)V
    //   536: aload_0
    //   537: getfield mAttributesMap : Ljava/util/HashMap;
    //   540: astore #27
    //   542: aload #27
    //   544: ifnull -> 623
    //   547: aload #27
    //   549: invokevirtual values : ()Ljava/util/Collection;
    //   552: invokeinterface iterator : ()Ljava/util/Iterator;
    //   557: astore #27
    //   559: aload #27
    //   561: invokeinterface hasNext : ()Z
    //   566: ifeq -> 623
    //   569: aload #27
    //   571: invokeinterface next : ()Ljava/lang/Object;
    //   576: checkcast androidx/constraintlayout/core/motion/utils/SplineSet
    //   579: astore #28
    //   581: aload #28
    //   583: instanceof androidx/constraintlayout/motion/utils/ViewSpline$PathRotate
    //   586: ifeq -> 559
    //   589: aload_0
    //   590: getfield mInterpolateVelocity : [D
    //   593: astore #29
    //   595: aload #29
    //   597: arraylength
    //   598: iconst_1
    //   599: if_icmple -> 559
    //   602: aload #28
    //   604: checkcast androidx/constraintlayout/motion/utils/ViewSpline$PathRotate
    //   607: aload_1
    //   608: fload_2
    //   609: aload #29
    //   611: iconst_0
    //   612: daload
    //   613: aload #29
    //   615: iconst_1
    //   616: daload
    //   617: invokevirtual setPathRotate : (Landroid/view/View;FDD)V
    //   620: goto -> 559
    //   623: aload #26
    //   625: ifnull -> 660
    //   628: aload_0
    //   629: getfield mInterpolateVelocity : [D
    //   632: astore #27
    //   634: iload #24
    //   636: aload #26
    //   638: aload_1
    //   639: aload #5
    //   641: fload_2
    //   642: lload_3
    //   643: aload #27
    //   645: iconst_0
    //   646: daload
    //   647: aload #27
    //   649: iconst_1
    //   650: daload
    //   651: invokevirtual setPathRotate : (Landroid/view/View;Landroidx/constraintlayout/core/motion/utils/KeyCache;FJDD)Z
    //   654: ior
    //   655: istore #24
    //   657: goto -> 660
    //   660: iconst_1
    //   661: istore #20
    //   663: aload_0
    //   664: getfield mSpline : [Landroidx/constraintlayout/core/motion/utils/CurveFit;
    //   667: astore #5
    //   669: iload #20
    //   671: aload #5
    //   673: arraylength
    //   674: if_icmpge -> 730
    //   677: aload #5
    //   679: iload #20
    //   681: aaload
    //   682: dload #6
    //   684: aload_0
    //   685: getfield mValuesBuff : [F
    //   688: invokevirtual getPos : (D[F)V
    //   691: aload_0
    //   692: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   695: getfield attributes : Ljava/util/LinkedHashMap;
    //   698: aload_0
    //   699: getfield mAttributeNames : [Ljava/lang/String;
    //   702: iload #20
    //   704: iconst_1
    //   705: isub
    //   706: aaload
    //   707: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   710: checkcast androidx/constraintlayout/widget/ConstraintAttribute
    //   713: aload_1
    //   714: aload_0
    //   715: getfield mValuesBuff : [F
    //   718: invokevirtual setInterpolatedValue : (Landroid/view/View;[F)V
    //   721: iload #20
    //   723: iconst_1
    //   724: iadd
    //   725: istore #20
    //   727: goto -> 663
    //   730: aload_0
    //   731: getfield mStartPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   734: getfield mVisibilityMode : I
    //   737: ifne -> 802
    //   740: fload_2
    //   741: fconst_0
    //   742: fcmpg
    //   743: ifgt -> 760
    //   746: aload_1
    //   747: aload_0
    //   748: getfield mStartPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   751: getfield visibility : I
    //   754: invokevirtual setVisibility : (I)V
    //   757: goto -> 802
    //   760: fload_2
    //   761: fconst_1
    //   762: fcmpl
    //   763: iflt -> 780
    //   766: aload_1
    //   767: aload_0
    //   768: getfield mEndPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   771: getfield visibility : I
    //   774: invokevirtual setVisibility : (I)V
    //   777: goto -> 802
    //   780: aload_0
    //   781: getfield mEndPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   784: getfield visibility : I
    //   787: aload_0
    //   788: getfield mStartPoint : Landroidx/constraintlayout/motion/widget/MotionConstrainedPoint;
    //   791: getfield visibility : I
    //   794: if_icmpeq -> 802
    //   797: aload_1
    //   798: iconst_0
    //   799: invokevirtual setVisibility : (I)V
    //   802: iload #24
    //   804: istore #25
    //   806: aload_0
    //   807: getfield mKeyTriggers : [Landroidx/constraintlayout/motion/widget/KeyTrigger;
    //   810: ifnull -> 1113
    //   813: iconst_0
    //   814: istore #20
    //   816: aload_0
    //   817: getfield mKeyTriggers : [Landroidx/constraintlayout/motion/widget/KeyTrigger;
    //   820: astore #5
    //   822: iload #24
    //   824: istore #25
    //   826: iload #20
    //   828: aload #5
    //   830: arraylength
    //   831: if_icmpge -> 1113
    //   834: aload #5
    //   836: iload #20
    //   838: aaload
    //   839: fload_2
    //   840: aload_1
    //   841: invokevirtual conditionallyFire : (FLandroid/view/View;)V
    //   844: iload #20
    //   846: iconst_1
    //   847: iadd
    //   848: istore #20
    //   850: goto -> 816
    //   853: aload_0
    //   854: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   857: getfield x : F
    //   860: fstore #17
    //   862: aload_0
    //   863: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   866: getfield x : F
    //   869: fstore #18
    //   871: aload_0
    //   872: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   875: getfield x : F
    //   878: fstore #19
    //   880: aload_0
    //   881: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   884: getfield y : F
    //   887: fstore #14
    //   889: aload_0
    //   890: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   893: getfield y : F
    //   896: fstore #15
    //   898: aload_0
    //   899: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   902: getfield y : F
    //   905: fstore #16
    //   907: aload_0
    //   908: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   911: getfield width : F
    //   914: fstore #8
    //   916: aload_0
    //   917: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   920: getfield width : F
    //   923: fstore #9
    //   925: aload_0
    //   926: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   929: getfield width : F
    //   932: fstore #10
    //   934: aload_0
    //   935: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   938: getfield height : F
    //   941: fstore #11
    //   943: aload_0
    //   944: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   947: getfield height : F
    //   950: fstore #12
    //   952: aload_0
    //   953: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   956: getfield height : F
    //   959: fstore #13
    //   961: fload #17
    //   963: fload #18
    //   965: fload #19
    //   967: fsub
    //   968: fload_2
    //   969: fmul
    //   970: fadd
    //   971: ldc_w 0.5
    //   974: fadd
    //   975: fstore #17
    //   977: fload #17
    //   979: f2i
    //   980: istore #20
    //   982: fload #14
    //   984: fload #15
    //   986: fload #16
    //   988: fsub
    //   989: fload_2
    //   990: fmul
    //   991: fadd
    //   992: ldc_w 0.5
    //   995: fadd
    //   996: fstore #14
    //   998: fload #14
    //   1000: f2i
    //   1001: istore #21
    //   1003: fload #17
    //   1005: fload #8
    //   1007: fload #9
    //   1009: fload #10
    //   1011: fsub
    //   1012: fload_2
    //   1013: fmul
    //   1014: fadd
    //   1015: fadd
    //   1016: f2i
    //   1017: istore #22
    //   1019: fload #14
    //   1021: fload #11
    //   1023: fload #12
    //   1025: fload #13
    //   1027: fsub
    //   1028: fload_2
    //   1029: fmul
    //   1030: fadd
    //   1031: fadd
    //   1032: f2i
    //   1033: istore #23
    //   1035: aload_0
    //   1036: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   1039: getfield width : F
    //   1042: aload_0
    //   1043: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   1046: getfield width : F
    //   1049: fcmpl
    //   1050: ifne -> 1071
    //   1053: aload_0
    //   1054: getfield mEndMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   1057: getfield height : F
    //   1060: aload_0
    //   1061: getfield mStartMotionPath : Landroidx/constraintlayout/motion/widget/MotionPaths;
    //   1064: getfield height : F
    //   1067: fcmpl
    //   1068: ifeq -> 1097
    //   1071: aload_1
    //   1072: iload #22
    //   1074: iload #20
    //   1076: isub
    //   1077: ldc_w 1073741824
    //   1080: invokestatic makeMeasureSpec : (II)I
    //   1083: iload #23
    //   1085: iload #21
    //   1087: isub
    //   1088: ldc_w 1073741824
    //   1091: invokestatic makeMeasureSpec : (II)I
    //   1094: invokevirtual measure : (II)V
    //   1097: aload_1
    //   1098: iload #20
    //   1100: iload #21
    //   1102: iload #22
    //   1104: iload #23
    //   1106: invokevirtual layout : (IIII)V
    //   1109: iload #24
    //   1111: istore #25
    //   1113: aload_0
    //   1114: getfield mCycleMap : Ljava/util/HashMap;
    //   1117: astore #5
    //   1119: aload #5
    //   1121: ifnull -> 1207
    //   1124: aload #5
    //   1126: invokevirtual values : ()Ljava/util/Collection;
    //   1129: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1134: astore #5
    //   1136: aload #5
    //   1138: invokeinterface hasNext : ()Z
    //   1143: ifeq -> 1207
    //   1146: aload #5
    //   1148: invokeinterface next : ()Ljava/lang/Object;
    //   1153: checkcast androidx/constraintlayout/motion/utils/ViewOscillator
    //   1156: astore #26
    //   1158: aload #26
    //   1160: instanceof androidx/constraintlayout/motion/utils/ViewOscillator$PathRotateSet
    //   1163: ifeq -> 1197
    //   1166: aload #26
    //   1168: checkcast androidx/constraintlayout/motion/utils/ViewOscillator$PathRotateSet
    //   1171: astore #26
    //   1173: aload_0
    //   1174: getfield mInterpolateVelocity : [D
    //   1177: astore #27
    //   1179: aload #26
    //   1181: aload_1
    //   1182: fload_2
    //   1183: aload #27
    //   1185: iconst_0
    //   1186: daload
    //   1187: aload #27
    //   1189: iconst_1
    //   1190: daload
    //   1191: invokevirtual setPathRotate : (Landroid/view/View;FDD)V
    //   1194: goto -> 1136
    //   1197: aload #26
    //   1199: aload_1
    //   1200: fload_2
    //   1201: invokevirtual setProperty : (Landroid/view/View;F)V
    //   1204: goto -> 1136
    //   1207: iload #25
    //   1209: ireturn
  }
  
  String name() {
    return this.mView.getContext().getResources().getResourceEntryName(this.mView.getId());
  }
  
  void positionKeyframe(View paramView, KeyPositionBase paramKeyPositionBase, float paramFloat1, float paramFloat2, String[] paramArrayOfString, float[] paramArrayOffloat) {
    RectF rectF1 = new RectF();
    rectF1.left = this.mStartMotionPath.x;
    rectF1.top = this.mStartMotionPath.y;
    rectF1.right = rectF1.left + this.mStartMotionPath.width;
    rectF1.bottom = rectF1.top + this.mStartMotionPath.height;
    RectF rectF2 = new RectF();
    rectF2.left = this.mEndMotionPath.x;
    rectF2.top = this.mEndMotionPath.y;
    rectF2.right = rectF2.left + this.mEndMotionPath.width;
    rectF2.bottom = rectF2.top + this.mEndMotionPath.height;
    paramKeyPositionBase.positionAttributes(paramView, rectF1, rectF2, paramFloat1, paramFloat2, paramArrayOfString, paramArrayOffloat);
  }
  
  void rotate(Rect paramRect1, Rect paramRect2, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          if (paramInt1 != 4)
            return; 
          paramInt1 = paramRect1.left;
          paramInt3 = paramRect1.right;
          paramRect2.left = paramInt2 - (paramRect1.bottom + paramRect1.top + paramRect1.width()) / 2;
          paramRect2.top = (paramInt1 + paramInt3 - paramRect1.height()) / 2;
          paramRect2.right = paramRect2.left + paramRect1.width();
          paramRect2.bottom = paramRect2.top + paramRect1.height();
          return;
        } 
        paramInt1 = paramRect1.left + paramRect1.right;
        paramInt2 = paramRect1.top;
        paramInt2 = paramRect1.bottom;
        paramRect2.left = paramRect1.height() / 2 + paramRect1.top - paramInt1 / 2;
        paramRect2.top = paramInt3 - (paramInt1 + paramRect1.height()) / 2;
        paramRect2.right = paramRect2.left + paramRect1.width();
        paramRect2.bottom = paramRect2.top + paramRect1.height();
        return;
      } 
      paramInt1 = paramRect1.left;
      paramInt3 = paramRect1.right;
      paramRect2.left = paramInt2 - (paramRect1.top + paramRect1.bottom + paramRect1.width()) / 2;
      paramRect2.top = (paramInt1 + paramInt3 - paramRect1.height()) / 2;
      paramRect2.right = paramRect2.left + paramRect1.width();
      paramRect2.bottom = paramRect2.top + paramRect1.height();
      return;
    } 
    paramInt1 = paramRect1.left;
    paramInt2 = paramRect1.right;
    paramRect2.left = (paramRect1.top + paramRect1.bottom - paramRect1.width()) / 2;
    paramRect2.top = paramInt3 - (paramInt1 + paramInt2 + paramRect1.height()) / 2;
    paramRect2.right = paramRect2.left + paramRect1.width();
    paramRect2.bottom = paramRect2.top + paramRect1.height();
  }
  
  void setBothStates(View paramView) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    this.mNoMovement = true;
    this.mStartMotionPath.setBounds(paramView.getX(), paramView.getY(), paramView.getWidth(), paramView.getHeight());
    this.mEndMotionPath.setBounds(paramView.getX(), paramView.getY(), paramView.getWidth(), paramView.getHeight());
    this.mStartPoint.setState(paramView);
    this.mEndPoint.setState(paramView);
  }
  
  public void setDrawPath(int paramInt) {
    this.mStartMotionPath.mDrawPath = paramInt;
  }
  
  void setEndState(Rect paramRect, ConstraintSet paramConstraintSet, int paramInt1, int paramInt2) {
    int i = paramConstraintSet.mRotate;
    Rect rect = paramRect;
    if (i != 0) {
      rotate(paramRect, this.mTempRect, i, paramInt1, paramInt2);
      rect = this.mTempRect;
    } 
    this.mEndMotionPath.time = 1.0F;
    this.mEndMotionPath.position = 1.0F;
    readView(this.mEndMotionPath);
    this.mEndMotionPath.setBounds(rect.left, rect.top, rect.width(), rect.height());
    this.mEndMotionPath.applyParameters(paramConstraintSet.getParameters(this.mId));
    this.mEndPoint.setState(rect, paramConstraintSet, i, this.mId);
  }
  
  public void setPathMotionArc(int paramInt) {
    this.mPathMotionArc = paramInt;
  }
  
  void setStartCurrentState(View paramView) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    this.mStartMotionPath.setBounds(paramView.getX(), paramView.getY(), paramView.getWidth(), paramView.getHeight());
    this.mStartPoint.setState(paramView);
  }
  
  void setStartState(Rect paramRect, ConstraintSet paramConstraintSet, int paramInt1, int paramInt2) {
    int i = paramConstraintSet.mRotate;
    if (i != 0)
      rotate(paramRect, this.mTempRect, i, paramInt1, paramInt2); 
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    readView(this.mStartMotionPath);
    this.mStartMotionPath.setBounds(paramRect.left, paramRect.top, paramRect.width(), paramRect.height());
    ConstraintSet.Constraint constraint = paramConstraintSet.getParameters(this.mId);
    this.mStartMotionPath.applyParameters(constraint);
    this.mMotionStagger = constraint.motion.mMotionStagger;
    this.mStartPoint.setState(paramRect, paramConstraintSet, i, this.mId);
    this.mTransformPivotTarget = constraint.transform.transformPivotTarget;
    this.mQuantizeMotionSteps = constraint.motion.mQuantizeMotionSteps;
    this.mQuantizeMotionPhase = constraint.motion.mQuantizeMotionPhase;
    this.mQuantizeMotionInterpolator = getInterpolator(this.mView.getContext(), constraint.motion.mQuantizeInterpolatorType, constraint.motion.mQuantizeInterpolatorString, constraint.motion.mQuantizeInterpolatorID);
  }
  
  public void setStartState(ViewState paramViewState, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    this.mStartMotionPath.time = 0.0F;
    this.mStartMotionPath.position = 0.0F;
    Rect rect = new Rect();
    if (paramInt1 != 1) {
      if (paramInt1 == 2) {
        paramInt2 = paramViewState.left;
        int i = paramViewState.right;
        rect.left = paramInt3 - (paramViewState.top + paramViewState.bottom + paramViewState.width()) / 2;
        rect.top = (paramInt2 + i - paramViewState.height()) / 2;
        rect.right = rect.left + paramViewState.width();
        rect.bottom = rect.top + paramViewState.height();
      } 
    } else {
      paramInt3 = paramViewState.left;
      int i = paramViewState.right;
      rect.left = (paramViewState.top + paramViewState.bottom - paramViewState.width()) / 2;
      rect.top = paramInt2 - (paramInt3 + i + paramViewState.height()) / 2;
      rect.right = rect.left + paramViewState.width();
      rect.bottom = rect.top + paramViewState.height();
    } 
    this.mStartMotionPath.setBounds(rect.left, rect.top, rect.width(), rect.height());
    this.mStartPoint.setState(rect, paramView, paramInt1, paramViewState.rotation);
  }
  
  public void setTransformPivotTarget(int paramInt) {
    this.mTransformPivotTarget = paramInt;
    this.mTransformPivotView = null;
  }
  
  public void setView(View paramView) {
    this.mView = paramView;
    this.mId = paramView.getId();
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.LayoutParams)
      this.mConstraintTag = ((ConstraintLayout.LayoutParams)layoutParams).getConstraintTag(); 
  }
  
  public void setup(int paramInt1, int paramInt2, float paramFloat, long paramLong) {
    ArrayList arrayList1;
    new HashSet();
    HashSet<String> hashSet4 = new HashSet();
    HashSet<String> hashSet2 = new HashSet();
    HashSet<String> hashSet3 = new HashSet();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (this.mPathMotionArc != Key.UNSET)
      this.mStartMotionPath.mPathMotionArc = this.mPathMotionArc; 
    this.mStartPoint.different(this.mEndPoint, hashSet2);
    ArrayList<Key> arrayList = this.mKeyList;
    if (arrayList != null) {
      Iterator<Key> iterator1 = arrayList.iterator();
      arrayList = null;
      while (true) {
        arrayList1 = arrayList;
        if (iterator1.hasNext()) {
          Key key = iterator1.next();
          if (key instanceof KeyPosition) {
            KeyPosition keyPosition = (KeyPosition)key;
            insertKey(new MotionPaths(paramInt1, paramInt2, keyPosition, this.mStartMotionPath, this.mEndMotionPath));
            if (keyPosition.mCurveFit != Key.UNSET)
              this.mCurveFitType = keyPosition.mCurveFit; 
            continue;
          } 
          if (key instanceof KeyCycle) {
            key.getAttributeNames(hashSet3);
            continue;
          } 
          if (key instanceof KeyTimeCycle) {
            key.getAttributeNames(hashSet4);
            continue;
          } 
          if (key instanceof KeyTrigger) {
            arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList<Key>(); 
            arrayList1.add(key);
            arrayList = arrayList1;
            continue;
          } 
          key.setInterpolation((HashMap)hashMap);
          key.getAttributeNames(hashSet2);
          continue;
        } 
        break;
      } 
    } else {
      arrayList1 = null;
    } 
    if (arrayList1 != null)
      this.mKeyTriggers = (KeyTrigger[])arrayList1.toArray((Object[])new KeyTrigger[0]); 
    if (!hashSet2.isEmpty()) {
      this.mAttributesMap = new HashMap<String, ViewSpline>();
      for (String str : hashSet2) {
        ViewSpline viewSpline;
        if (str.startsWith("CUSTOM,")) {
          SparseArray sparseArray = new SparseArray();
          String str1 = str.split(",")[1];
          for (Key key1 : this.mKeyList) {
            if (key1.mCustomConstraints == null)
              continue; 
            ConstraintAttribute constraintAttribute = key1.mCustomConstraints.get(str1);
            if (constraintAttribute != null)
              sparseArray.append(key1.mFramePosition, constraintAttribute); 
          } 
          viewSpline = ViewSpline.makeCustomSpline(str, sparseArray);
        } else {
          viewSpline = ViewSpline.makeSpline(str);
        } 
        if (viewSpline == null)
          continue; 
        viewSpline.setType(str);
        this.mAttributesMap.put(str, viewSpline);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (Key key : arrayList) {
          if (key instanceof KeyAttributes)
            key.addValues(this.mAttributesMap); 
        }  
      this.mStartPoint.addValues(this.mAttributesMap, 0);
      this.mEndPoint.addValues(this.mAttributesMap, 100);
      Iterator iterator1 = this.mAttributesMap.keySet().iterator();
      while (true) {
        while (true)
          break; 
        if (key != null)
          key.setup(paramInt1); 
      } 
    } 
    if (!hashSet4.isEmpty()) {
      if (this.mTimeCycleAttributesMap == null)
        this.mTimeCycleAttributesMap = new HashMap<String, ViewTimeCycle>(); 
      for (String str : hashSet4) {
        ViewTimeCycle viewTimeCycle;
        if (this.mTimeCycleAttributesMap.containsKey(str))
          continue; 
        if (str.startsWith("CUSTOM,")) {
          SparseArray sparseArray = new SparseArray();
          String str1 = str.split(",")[1];
          for (Key key : this.mKeyList) {
            if (key.mCustomConstraints == null)
              continue; 
            ConstraintAttribute constraintAttribute = key.mCustomConstraints.get(str1);
            if (constraintAttribute != null)
              sparseArray.append(key.mFramePosition, constraintAttribute); 
          } 
          viewTimeCycle = ViewTimeCycle.makeCustomSpline(str, sparseArray);
        } else {
          viewTimeCycle = ViewTimeCycle.makeSpline(str, paramLong);
        } 
        if (viewTimeCycle == null)
          continue; 
        viewTimeCycle.setType(str);
        this.mTimeCycleAttributesMap.put(str, viewTimeCycle);
      } 
      arrayList = this.mKeyList;
      if (arrayList != null)
        for (Key key : arrayList) {
          if (key instanceof KeyTimeCycle)
            ((KeyTimeCycle)key).addTimeValues(this.mTimeCycleAttributesMap); 
        }  
      for (String str : this.mTimeCycleAttributesMap.keySet()) {
        if (hashMap.containsKey(str)) {
          paramInt1 = ((Integer)hashMap.get(str)).intValue();
        } else {
          paramInt1 = 0;
        } 
        ((ViewTimeCycle)this.mTimeCycleAttributesMap.get(str)).setup(paramInt1);
      } 
    } 
    int i = this.mMotionPaths.size() + 2;
    MotionPaths[] arrayOfMotionPaths = new MotionPaths[i];
    arrayOfMotionPaths[0] = this.mStartMotionPath;
    arrayOfMotionPaths[i - 1] = this.mEndMotionPath;
    if (this.mMotionPaths.size() > 0 && this.mCurveFitType == -1)
      this.mCurveFitType = 0; 
    Iterator<MotionPaths> iterator = this.mMotionPaths.iterator();
    for (paramInt1 = 1; iterator.hasNext(); paramInt1++)
      arrayOfMotionPaths[paramInt1] = iterator.next(); 
    HashSet<String> hashSet1 = new HashSet();
    for (String str : this.mEndMotionPath.attributes.keySet()) {
      if (this.mStartMotionPath.attributes.containsKey(str)) {
        StringBuilder stringBuilder = new StringBuilder("CUSTOM,");
        stringBuilder.append(str);
        if (!hashSet2.contains(stringBuilder.toString()))
          hashSet1.add(str); 
      } 
    } 
    String[] arrayOfString = hashSet1.<String>toArray(new String[0]);
    this.mAttributeNames = arrayOfString;
    this.mAttributeInterpolatorCount = new int[arrayOfString.length];
    paramInt1 = 0;
    while (true) {
      boolean bool;
      arrayOfString = this.mAttributeNames;
      if (paramInt1 < arrayOfString.length) {
        String str = arrayOfString[paramInt1];
        this.mAttributeInterpolatorCount[paramInt1] = 0;
        for (paramInt2 = 0; paramInt2 < i; paramInt2++) {
          if ((arrayOfMotionPaths[paramInt2]).attributes.containsKey(str)) {
            ConstraintAttribute constraintAttribute = (arrayOfMotionPaths[paramInt2]).attributes.get(str);
            if (constraintAttribute != null) {
              int[] arrayOfInt = this.mAttributeInterpolatorCount;
              arrayOfInt[paramInt1] = arrayOfInt[paramInt1] + constraintAttribute.numberOfInterpolatedValues();
              break;
            } 
          } 
        } 
        paramInt1++;
        continue;
      } 
      if ((arrayOfMotionPaths[0]).mPathMotionArc != Key.UNSET) {
        bool = true;
      } else {
        bool = false;
      } 
      int j = 18 + this.mAttributeNames.length;
      boolean[] arrayOfBoolean = new boolean[j];
      for (paramInt1 = 1; paramInt1 < i; paramInt1++)
        arrayOfMotionPaths[paramInt1].different(arrayOfMotionPaths[paramInt1 - 1], arrayOfBoolean, this.mAttributeNames, bool); 
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < j; paramInt2 = k) {
        int k = paramInt2;
        if (arrayOfBoolean[paramInt1])
          k = paramInt2 + 1; 
        paramInt1++;
      } 
      this.mInterpolateVariables = new int[paramInt2];
      paramInt1 = Math.max(2, paramInt2);
      this.mInterpolateData = new double[paramInt1];
      this.mInterpolateVelocity = new double[paramInt1];
      paramInt1 = 1;
      for (paramInt2 = 0; paramInt1 < j; paramInt2 = k) {
        int k = paramInt2;
        if (arrayOfBoolean[paramInt1]) {
          this.mInterpolateVariables[paramInt2] = paramInt1;
          k = paramInt2 + 1;
        } 
        paramInt1++;
      } 
      paramInt1 = this.mInterpolateVariables.length;
      double[][] arrayOfDouble = (double[][])Array.newInstance(double.class, new int[] { i, paramInt1 });
      double[] arrayOfDouble1 = new double[i];
      for (paramInt1 = 0; paramInt1 < i; paramInt1++) {
        arrayOfMotionPaths[paramInt1].fillStandard(arrayOfDouble[paramInt1], this.mInterpolateVariables);
        arrayOfDouble1[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
      } 
      paramInt1 = 0;
      while (true) {
        int[] arrayOfInt = this.mInterpolateVariables;
        if (paramInt1 < arrayOfInt.length) {
          if (arrayOfInt[paramInt1] < MotionPaths.names.length) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(MotionPaths.names[this.mInterpolateVariables[paramInt1]]);
            stringBuilder.append(" [");
            String str = stringBuilder.toString();
            for (paramInt2 = 0; paramInt2 < i; paramInt2++) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str);
              stringBuilder1.append(arrayOfDouble[paramInt2][paramInt1]);
              str = stringBuilder1.toString();
            } 
          } 
          paramInt1++;
          continue;
        } 
        this.mSpline = new CurveFit[this.mAttributeNames.length + 1];
        paramInt1 = 0;
        while (true) {
          String[] arrayOfString1 = this.mAttributeNames;
          if (paramInt1 < arrayOfString1.length) {
            String str = arrayOfString1[paramInt1];
            paramInt2 = 0;
            arrayList1 = null;
            int k = 0;
            arrayOfString1 = null;
            while (paramInt2 < i) {
              double[][] arrayOfDouble4;
              double[] arrayOfDouble5;
              ArrayList arrayList2 = arrayList1;
              j = k;
              String[] arrayOfString2 = arrayOfString1;
              if (arrayOfMotionPaths[paramInt2].hasCustomData(str)) {
                double[] arrayOfDouble6;
                arrayOfString2 = arrayOfString1;
                if (arrayOfString1 == null) {
                  arrayOfDouble6 = new double[i];
                  j = arrayOfMotionPaths[paramInt2].getCustomDataCount(str);
                  arrayOfDouble4 = (double[][])Array.newInstance(double.class, new int[] { i, j });
                } 
                arrayOfDouble6[k] = (arrayOfMotionPaths[paramInt2]).time;
                arrayOfMotionPaths[paramInt2].getCustomData(str, arrayOfDouble4[k], 0);
                j = k + 1;
                arrayOfDouble5 = arrayOfDouble6;
              } 
              paramInt2++;
              arrayOfDouble3 = arrayOfDouble5;
              k = j;
              arrayOfDouble2 = arrayOfDouble4;
            } 
            double[] arrayOfDouble3 = Arrays.copyOf(arrayOfDouble3, k);
            double[][] arrayOfDouble2 = Arrays.<double[]>copyOf(arrayOfDouble2, k);
            CurveFit[] arrayOfCurveFit = this.mSpline;
            arrayOfCurveFit[++paramInt1] = CurveFit.get(this.mCurveFitType, arrayOfDouble3, arrayOfDouble2);
            continue;
          } 
          this.mSpline[0] = CurveFit.get(this.mCurveFitType, arrayOfDouble1, arrayOfDouble);
          if ((arrayOfMotionPaths[0]).mPathMotionArc != Key.UNSET) {
            int[] arrayOfInt1 = new int[i];
            double[] arrayOfDouble2 = new double[i];
            double[][] arrayOfDouble3 = (double[][])Array.newInstance(double.class, new int[] { i, 2 });
            for (paramInt1 = 0; paramInt1 < i; paramInt1++) {
              arrayOfInt1[paramInt1] = (arrayOfMotionPaths[paramInt1]).mPathMotionArc;
              arrayOfDouble2[paramInt1] = (arrayOfMotionPaths[paramInt1]).time;
              arrayOfDouble3[paramInt1][0] = (arrayOfMotionPaths[paramInt1]).x;
              arrayOfDouble3[paramInt1][1] = (arrayOfMotionPaths[paramInt1]).y;
            } 
            this.mArcSpline = CurveFit.getArc(arrayOfInt1, arrayOfDouble2, arrayOfDouble3);
          } 
          this.mCycleMap = new HashMap<String, ViewOscillator>();
          if (this.mKeyList != null) {
            null = hashSet3.iterator();
            for (paramFloat = Float.NaN; null.hasNext(); paramFloat = f) {
              String str = null.next();
              ViewOscillator viewOscillator = ViewOscillator.makeSpline(str);
              if (viewOscillator == null)
                continue; 
              float f = paramFloat;
              if (viewOscillator.variesByPath()) {
                f = paramFloat;
                if (Float.isNaN(paramFloat))
                  f = getPreCycleDistance(); 
              } 
              viewOscillator.setType(str);
              this.mCycleMap.put(str, viewOscillator);
            } 
            for (Key key : this.mKeyList) {
              if (key instanceof KeyCycle)
                ((KeyCycle)key).addCycleValues(this.mCycleMap); 
            } 
            Iterator<ViewOscillator> iterator1 = this.mCycleMap.values().iterator();
            while (iterator1.hasNext())
              ((ViewOscillator)iterator1.next()).setup(paramFloat); 
          } 
          return;
        } 
        break;
      } 
      break;
    } 
  }
  
  public void setupRelative(MotionController paramMotionController) {
    this.mStartMotionPath.setupRelative(paramMotionController, paramMotionController.mStartMotionPath);
    this.mEndMotionPath.setupRelative(paramMotionController, paramMotionController.mEndMotionPath);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(" start: x: ");
    stringBuilder.append(this.mStartMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mStartMotionPath.y);
    stringBuilder.append(" end: x: ");
    stringBuilder.append(this.mEndMotionPath.x);
    stringBuilder.append(" y: ");
    stringBuilder.append(this.mEndMotionPath.y);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */