package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Layout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.appcompat.R;
import androidx.constraintlayout.motion.widget.Debug;
import androidx.constraintlayout.motion.widget.FloatLayout;
import androidx.constraintlayout.widget.R;

public class MotionLabel extends View implements FloatLayout {
  private static final int MONOSPACE = 3;
  
  private static final int SANS = 1;
  
  private static final int SERIF = 2;
  
  static String TAG = "MotionLabel";
  
  private boolean mAutoSize = false;
  
  private int mAutoSizeTextType = 0;
  
  float mBackgroundPanX = Float.NaN;
  
  float mBackgroundPanY = Float.NaN;
  
  private float mBaseTextSize = Float.NaN;
  
  private float mDeltaLeft;
  
  private float mFloatHeight;
  
  private float mFloatWidth;
  
  private String mFontFamily;
  
  private int mGravity = 8388659;
  
  private Layout mLayout;
  
  boolean mNotBuilt = true;
  
  Matrix mOutlinePositionMatrix;
  
  private int mPaddingBottom = 1;
  
  private int mPaddingLeft = 1;
  
  private int mPaddingRight = 1;
  
  private int mPaddingTop = 1;
  
  TextPaint mPaint = new TextPaint();
  
  Path mPath = new Path();
  
  RectF mRect;
  
  float mRotate = Float.NaN;
  
  private float mRound = Float.NaN;
  
  private float mRoundPercent = 0.0F;
  
  private int mStyleIndex;
  
  Paint mTempPaint;
  
  Rect mTempRect;
  
  private String mText = "Hello World";
  
  private Drawable mTextBackground;
  
  private Bitmap mTextBackgroundBitmap;
  
  private Rect mTextBounds = new Rect();
  
  private int mTextFillColor = 65535;
  
  private int mTextOutlineColor = 65535;
  
  private float mTextOutlineThickness = 0.0F;
  
  private float mTextPanX = 0.0F;
  
  private float mTextPanY = 0.0F;
  
  private BitmapShader mTextShader;
  
  private Matrix mTextShaderMatrix;
  
  private float mTextSize = 48.0F;
  
  private int mTextureEffect = 0;
  
  private float mTextureHeight = Float.NaN;
  
  private float mTextureWidth = Float.NaN;
  
  private CharSequence mTransformed;
  
  private int mTypefaceIndex;
  
  private boolean mUseOutline = false;
  
  ViewOutlineProvider mViewOutlineProvider;
  
  float mZoom = Float.NaN;
  
  Paint paintCache = new Paint();
  
  float paintTextSize;
  
  public MotionLabel(Context paramContext) {
    super(paramContext);
    init(paramContext, (AttributeSet)null);
  }
  
  public MotionLabel(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramContext, paramAttributeSet);
  }
  
  public MotionLabel(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext, paramAttributeSet);
  }
  
  private void adjustTexture(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (this.mTextShaderMatrix == null)
      return; 
    this.mFloatWidth = paramFloat3 - paramFloat1;
    this.mFloatHeight = paramFloat4 - paramFloat2;
    updateShaderMatrix();
  }
  
  private float getHorizontalOffset() {
    float f1;
    float f2;
    if (Float.isNaN(this.mBaseTextSize)) {
      f1 = 1.0F;
    } else {
      f1 = this.mTextSize / this.mBaseTextSize;
    } 
    TextPaint textPaint = this.mPaint;
    String str = this.mText;
    float f3 = textPaint.measureText(str, 0, str.length());
    if (Float.isNaN(this.mFloatWidth)) {
      f2 = getMeasuredWidth();
    } else {
      f2 = this.mFloatWidth;
    } 
    return (f2 - getPaddingLeft() - getPaddingRight() - f1 * f3) * (this.mTextPanX + 1.0F) / 2.0F;
  }
  
  private float getVerticalOffset() {
    float f1;
    float f2;
    if (Float.isNaN(this.mBaseTextSize)) {
      f1 = 1.0F;
    } else {
      f1 = this.mTextSize / this.mBaseTextSize;
    } 
    Paint.FontMetrics fontMetrics = this.mPaint.getFontMetrics();
    if (Float.isNaN(this.mFloatHeight)) {
      f2 = getMeasuredHeight();
    } else {
      f2 = this.mFloatHeight;
    } 
    return (f2 - getPaddingTop() - getPaddingBottom() - (fontMetrics.descent - fontMetrics.ascent) * f1) * (1.0F - this.mTextPanY) / 2.0F - f1 * fontMetrics.ascent;
  }
  
  private void init(Context paramContext, AttributeSet paramAttributeSet) {
    setUpTheme(paramContext, paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.MotionLabel);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.MotionLabel_android_text) {
          setText(typedArray.getText(k));
        } else if (k == R.styleable.MotionLabel_android_fontFamily) {
          this.mFontFamily = typedArray.getString(k);
        } else if (k == R.styleable.MotionLabel_scaleFromTextSize) {
          this.mBaseTextSize = typedArray.getDimensionPixelSize(k, (int)this.mBaseTextSize);
        } else if (k == R.styleable.MotionLabel_android_textSize) {
          this.mTextSize = typedArray.getDimensionPixelSize(k, (int)this.mTextSize);
        } else if (k == R.styleable.MotionLabel_android_textStyle) {
          this.mStyleIndex = typedArray.getInt(k, this.mStyleIndex);
        } else if (k == R.styleable.MotionLabel_android_typeface) {
          this.mTypefaceIndex = typedArray.getInt(k, this.mTypefaceIndex);
        } else if (k == R.styleable.MotionLabel_android_textColor) {
          this.mTextFillColor = typedArray.getColor(k, this.mTextFillColor);
        } else if (k == R.styleable.MotionLabel_borderRound) {
          this.mRound = typedArray.getDimension(k, this.mRound);
          if (Build.VERSION.SDK_INT >= 21)
            setRound(this.mRound); 
        } else if (k == R.styleable.MotionLabel_borderRoundPercent) {
          this.mRoundPercent = typedArray.getFloat(k, this.mRoundPercent);
          if (Build.VERSION.SDK_INT >= 21)
            setRoundPercent(this.mRoundPercent); 
        } else if (k == R.styleable.MotionLabel_android_gravity) {
          setGravity(typedArray.getInt(k, -1));
        } else if (k == R.styleable.MotionLabel_android_autoSizeTextType) {
          this.mAutoSizeTextType = typedArray.getInt(k, 0);
        } else if (k == R.styleable.MotionLabel_textOutlineColor) {
          this.mTextOutlineColor = typedArray.getInt(k, this.mTextOutlineColor);
          this.mUseOutline = true;
        } else if (k == R.styleable.MotionLabel_textOutlineThickness) {
          this.mTextOutlineThickness = typedArray.getDimension(k, this.mTextOutlineThickness);
          this.mUseOutline = true;
        } else if (k == R.styleable.MotionLabel_textBackground) {
          this.mTextBackground = typedArray.getDrawable(k);
          this.mUseOutline = true;
        } else if (k == R.styleable.MotionLabel_textBackgroundPanX) {
          this.mBackgroundPanX = typedArray.getFloat(k, this.mBackgroundPanX);
        } else if (k == R.styleable.MotionLabel_textBackgroundPanY) {
          this.mBackgroundPanY = typedArray.getFloat(k, this.mBackgroundPanY);
        } else if (k == R.styleable.MotionLabel_textPanX) {
          this.mTextPanX = typedArray.getFloat(k, this.mTextPanX);
        } else if (k == R.styleable.MotionLabel_textPanY) {
          this.mTextPanY = typedArray.getFloat(k, this.mTextPanY);
        } else if (k == R.styleable.MotionLabel_textBackgroundRotate) {
          this.mRotate = typedArray.getFloat(k, this.mRotate);
        } else if (k == R.styleable.MotionLabel_textBackgroundZoom) {
          this.mZoom = typedArray.getFloat(k, this.mZoom);
        } else if (k == R.styleable.MotionLabel_textureHeight) {
          this.mTextureHeight = typedArray.getDimension(k, this.mTextureHeight);
        } else if (k == R.styleable.MotionLabel_textureWidth) {
          this.mTextureWidth = typedArray.getDimension(k, this.mTextureWidth);
        } else if (k == R.styleable.MotionLabel_textureEffect) {
          this.mTextureEffect = typedArray.getInt(k, this.mTextureEffect);
        } 
      } 
      typedArray.recycle();
    } 
    setupTexture();
    setupPath();
  }
  
  private void setTypefaceFromAttrs(String paramString, int paramInt1, int paramInt2) {
    Typeface typeface;
    TextPaint textPaint;
    if (paramString != null) {
      Typeface typeface1 = Typeface.create(paramString, paramInt2);
      typeface = typeface1;
      if (typeface1 != null) {
        setTypeface(typeface1);
        return;
      } 
    } else {
      paramString = null;
    } 
    boolean bool = true;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 == 3)
          typeface = Typeface.MONOSPACE; 
      } else {
        typeface = Typeface.SERIF;
      } 
    } else {
      typeface = Typeface.SANS_SERIF;
    } 
    float f = 0.0F;
    if (paramInt2 > 0) {
      if (typeface == null) {
        typeface = Typeface.defaultFromStyle(paramInt2);
      } else {
        typeface = Typeface.create(typeface, paramInt2);
      } 
      setTypeface(typeface);
      if (typeface != null) {
        paramInt1 = typeface.getStyle();
      } else {
        paramInt1 = 0;
      } 
      paramInt1 = (paramInt1 ^ 0xFFFFFFFF) & paramInt2;
      textPaint = this.mPaint;
      if ((paramInt1 & 0x1) == 0)
        bool = false; 
      textPaint.setFakeBoldText(bool);
      textPaint = this.mPaint;
      if ((paramInt1 & 0x2) != 0)
        f = -0.25F; 
      textPaint.setTextSkewX(f);
      return;
    } 
    this.mPaint.setFakeBoldText(false);
    this.mPaint.setTextSkewX(0.0F);
    setTypeface((Typeface)textPaint);
  }
  
  private void setUpTheme(Context paramContext, AttributeSet paramAttributeSet) {
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(R.attr.colorPrimary, typedValue, true);
    TextPaint textPaint = this.mPaint;
    int i = typedValue.data;
    this.mTextFillColor = i;
    textPaint.setColor(i);
  }
  
  private void setupTexture() {
    if (this.mTextBackground != null) {
      this.mTextShaderMatrix = new Matrix();
      int j = this.mTextBackground.getIntrinsicWidth();
      int m = this.mTextBackground.getIntrinsicHeight();
      int k = 128;
      int i = j;
      if (j <= 0) {
        j = getWidth();
        i = j;
        if (j == 0)
          if (Float.isNaN(this.mTextureWidth)) {
            i = 128;
          } else {
            i = (int)this.mTextureWidth;
          }  
      } 
      j = m;
      if (m <= 0) {
        m = getHeight();
        j = m;
        if (m == 0)
          if (Float.isNaN(this.mTextureHeight)) {
            j = k;
          } else {
            j = (int)this.mTextureHeight;
          }  
      } 
      m = i;
      k = j;
      if (this.mTextureEffect != 0) {
        m = i / 2;
        k = j / 2;
      } 
      this.mTextBackgroundBitmap = Bitmap.createBitmap(m, k, Bitmap.Config.ARGB_8888);
      Canvas canvas = new Canvas(this.mTextBackgroundBitmap);
      this.mTextBackground.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
      this.mTextBackground.setFilterBitmap(true);
      this.mTextBackground.draw(canvas);
      if (this.mTextureEffect != 0)
        this.mTextBackgroundBitmap = blur(this.mTextBackgroundBitmap, 4); 
      this.mTextShader = new BitmapShader(this.mTextBackgroundBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    } 
  }
  
  private void updateShaderMatrix() {
    float f1;
    float f2;
    float f4;
    float f5;
    boolean bool = Float.isNaN(this.mBackgroundPanX);
    float f3 = 0.0F;
    if (bool) {
      f1 = 0.0F;
    } else {
      f1 = this.mBackgroundPanX;
    } 
    if (Float.isNaN(this.mBackgroundPanY)) {
      f2 = 0.0F;
    } else {
      f2 = this.mBackgroundPanY;
    } 
    if (Float.isNaN(this.mZoom)) {
      f6 = 1.0F;
    } else {
      f6 = this.mZoom;
    } 
    if (!Float.isNaN(this.mRotate))
      f3 = this.mRotate; 
    this.mTextShaderMatrix.reset();
    float f9 = this.mTextBackgroundBitmap.getWidth();
    float f8 = this.mTextBackgroundBitmap.getHeight();
    if (Float.isNaN(this.mTextureWidth)) {
      f4 = this.mFloatWidth;
    } else {
      f4 = this.mTextureWidth;
    } 
    if (Float.isNaN(this.mTextureHeight)) {
      f5 = this.mFloatHeight;
    } else {
      f5 = this.mTextureHeight;
    } 
    if (f9 * f5 < f8 * f4) {
      f7 = f4 / f9;
    } else {
      f7 = f5 / f8;
    } 
    f6 *= f7;
    this.mTextShaderMatrix.postScale(f6, f6);
    f9 *= f6;
    float f7 = f4 - f9;
    f8 = f6 * f8;
    float f6 = f5 - f8;
    if (!Float.isNaN(this.mTextureHeight))
      f6 = this.mTextureHeight / 2.0F; 
    if (!Float.isNaN(this.mTextureWidth))
      f7 = this.mTextureWidth / 2.0F; 
    this.mTextShaderMatrix.postTranslate((f1 * f7 + f4 - f9) * 0.5F, (f2 * f6 + f5 - f8) * 0.5F);
    this.mTextShaderMatrix.postRotate(f3, f4 / 2.0F, f5 / 2.0F);
    this.mTextShader.setLocalMatrix(this.mTextShaderMatrix);
  }
  
  Bitmap blur(Bitmap paramBitmap, int paramInt) {
    System.nanoTime();
    int j = paramBitmap.getWidth();
    int i = paramBitmap.getHeight();
    int k = j / 2;
    j = i / 2;
    paramBitmap = Bitmap.createScaledBitmap(paramBitmap, k, j, true);
    for (i = 0; i < paramInt && k >= 32; i++) {
      if (j < 32)
        return paramBitmap; 
      k /= 2;
      j /= 2;
      paramBitmap = Bitmap.createScaledBitmap(paramBitmap, k, j, true);
    } 
    return paramBitmap;
  }
  
  void buildShape(float paramFloat) {
    if (!this.mUseOutline && paramFloat == 1.0F)
      return; 
    this.mPath.reset();
    String str = this.mText;
    int i = str.length();
    this.mPaint.getTextBounds(str, 0, i, this.mTextBounds);
    this.mPaint.getTextPath(str, 0, i, 0.0F, 0.0F, this.mPath);
    if (paramFloat != 1.0F) {
      str = TAG;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Debug.getLoc());
      stringBuilder.append(" scale ");
      stringBuilder.append(paramFloat);
      Log.v(str, stringBuilder.toString());
      Matrix matrix = new Matrix();
      matrix.postScale(paramFloat, paramFloat);
      this.mPath.transform(matrix);
    } 
    Rect rect = this.mTextBounds;
    rect.right--;
    rect = this.mTextBounds;
    rect.left++;
    rect = this.mTextBounds;
    rect.bottom++;
    rect = this.mTextBounds;
    rect.top--;
    RectF rectF = new RectF();
    rectF.bottom = getHeight();
    rectF.right = getWidth();
    this.mNotBuilt = false;
  }
  
  public float getRound() {
    return this.mRound;
  }
  
  public float getRoundPercent() {
    return this.mRoundPercent;
  }
  
  public float getScaleFromTextSize() {
    return this.mBaseTextSize;
  }
  
  public float getTextBackgroundPanX() {
    return this.mBackgroundPanX;
  }
  
  public float getTextBackgroundPanY() {
    return this.mBackgroundPanY;
  }
  
  public float getTextBackgroundRotate() {
    return this.mRotate;
  }
  
  public float getTextBackgroundZoom() {
    return this.mZoom;
  }
  
  public int getTextOutlineColor() {
    return this.mTextOutlineColor;
  }
  
  public float getTextPanX() {
    return this.mTextPanX;
  }
  
  public float getTextPanY() {
    return this.mTextPanY;
  }
  
  public float getTextureHeight() {
    return this.mTextureHeight;
  }
  
  public float getTextureWidth() {
    return this.mTextureWidth;
  }
  
  public Typeface getTypeface() {
    return this.mPaint.getTypeface();
  }
  
  public void layout(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    int i = (int)(paramFloat1 + 0.5F);
    this.mDeltaLeft = paramFloat1 - i;
    int j = (int)(paramFloat3 + 0.5F);
    int k = j - i;
    int m = (int)(paramFloat4 + 0.5F);
    int n = (int)(0.5F + paramFloat2);
    int i1 = m - n;
    float f2 = paramFloat3 - paramFloat1;
    this.mFloatWidth = f2;
    float f1 = paramFloat4 - paramFloat2;
    this.mFloatHeight = f1;
    adjustTexture(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    if (getMeasuredHeight() != i1 || getMeasuredWidth() != k) {
      measure(View.MeasureSpec.makeMeasureSpec(k, 1073741824), View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
      super.layout(i, n, j, m);
    } else {
      super.layout(i, n, j, m);
    } 
    if (this.mAutoSize) {
      if (this.mTempRect == null) {
        this.mTempPaint = new Paint();
        this.mTempRect = new Rect();
        this.mTempPaint.set((Paint)this.mPaint);
        this.paintTextSize = this.mTempPaint.getTextSize();
      } 
      this.mFloatWidth = f2;
      this.mFloatHeight = f1;
      Paint paint = this.mTempPaint;
      String str = this.mText;
      paint.getTextBounds(str, 0, str.length(), this.mTempRect);
      i = this.mTempRect.width();
      paramFloat1 = this.mTempRect.height() * 1.3F;
      paramFloat2 = f2 - this.mPaddingRight - this.mPaddingLeft;
      paramFloat3 = f1 - this.mPaddingBottom - this.mPaddingTop;
      paramFloat4 = i;
      if (paramFloat4 * paramFloat3 > paramFloat1 * paramFloat2) {
        this.mPaint.setTextSize(this.paintTextSize * paramFloat2 / paramFloat4);
      } else {
        this.mPaint.setTextSize(this.paintTextSize * paramFloat3 / paramFloat1);
      } 
      if (this.mUseOutline || !Float.isNaN(this.mBaseTextSize)) {
        if (Float.isNaN(this.mBaseTextSize)) {
          paramFloat1 = 1.0F;
        } else {
          paramFloat1 = this.mTextSize / this.mBaseTextSize;
        } 
        buildShape(paramFloat1);
      } 
    } 
  }
  
  public void layout(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f1;
    super.layout(paramInt1, paramInt2, paramInt3, paramInt4);
    boolean bool = Float.isNaN(this.mBaseTextSize);
    if (bool) {
      f1 = 1.0F;
    } else {
      f1 = this.mTextSize / this.mBaseTextSize;
    } 
    this.mFloatWidth = (paramInt3 - paramInt1);
    this.mFloatHeight = (paramInt4 - paramInt2);
    float f2 = f1;
    if (this.mAutoSize) {
      if (this.mTempRect == null) {
        this.mTempPaint = new Paint();
        this.mTempRect = new Rect();
        this.mTempPaint.set((Paint)this.mPaint);
        this.paintTextSize = this.mTempPaint.getTextSize();
      } 
      Paint paint = this.mTempPaint;
      String str = this.mText;
      paint.getTextBounds(str, 0, str.length(), this.mTempRect);
      int i = this.mTempRect.width();
      int j = (int)(this.mTempRect.height() * 1.3F);
      f2 = this.mFloatWidth - this.mPaddingRight - this.mPaddingLeft;
      float f = this.mFloatHeight - this.mPaddingBottom - this.mPaddingTop;
      if (bool) {
        float f3 = i;
        float f4 = j;
        if (f3 * f > f4 * f2) {
          this.mPaint.setTextSize(this.paintTextSize * f2 / f3);
          f2 = f1;
        } else {
          this.mPaint.setTextSize(this.paintTextSize * f / f4);
          f2 = f1;
        } 
      } else {
        f1 = i;
        float f3 = j;
        if (f1 * f > f3 * f2) {
          f2 /= f1;
        } else {
          f2 = f / f3;
        } 
      } 
    } 
    if (this.mUseOutline || !bool) {
      adjustTexture(paramInt1, paramInt2, paramInt3, paramInt4);
      buildShape(f2);
    } 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (Float.isNaN(this.mBaseTextSize)) {
      f1 = 1.0F;
    } else {
      f1 = this.mTextSize / this.mBaseTextSize;
    } 
    super.onDraw(paramCanvas);
    if (!this.mUseOutline && f1 == 1.0F) {
      f1 = this.mPaddingLeft;
      float f3 = getHorizontalOffset();
      float f4 = this.mPaddingTop;
      float f5 = getVerticalOffset();
      paramCanvas.drawText(this.mText, this.mDeltaLeft + f1 + f3, f4 + f5, (Paint)this.mPaint);
      return;
    } 
    if (this.mNotBuilt)
      buildShape(f1); 
    if (this.mOutlinePositionMatrix == null)
      this.mOutlinePositionMatrix = new Matrix(); 
    if (this.mUseOutline) {
      this.paintCache.set((Paint)this.mPaint);
      this.mOutlinePositionMatrix.reset();
      float f3 = this.mPaddingLeft + getHorizontalOffset();
      float f4 = this.mPaddingTop + getVerticalOffset();
      this.mOutlinePositionMatrix.postTranslate(f3, f4);
      this.mOutlinePositionMatrix.preScale(f1, f1);
      this.mPath.transform(this.mOutlinePositionMatrix);
      if (this.mTextShader != null) {
        this.mPaint.setFilterBitmap(true);
        this.mPaint.setShader((Shader)this.mTextShader);
      } else {
        this.mPaint.setColor(this.mTextFillColor);
      } 
      this.mPaint.setStyle(Paint.Style.FILL);
      this.mPaint.setStrokeWidth(this.mTextOutlineThickness);
      paramCanvas.drawPath(this.mPath, (Paint)this.mPaint);
      if (this.mTextShader != null)
        this.mPaint.setShader(null); 
      this.mPaint.setColor(this.mTextOutlineColor);
      this.mPaint.setStyle(Paint.Style.STROKE);
      this.mPaint.setStrokeWidth(this.mTextOutlineThickness);
      paramCanvas.drawPath(this.mPath, (Paint)this.mPaint);
      this.mOutlinePositionMatrix.reset();
      this.mOutlinePositionMatrix.postTranslate(-f3, -f4);
      this.mPath.transform(this.mOutlinePositionMatrix);
      this.mPaint.set(this.paintCache);
      return;
    } 
    float f1 = this.mPaddingLeft + getHorizontalOffset();
    float f2 = this.mPaddingTop + getVerticalOffset();
    this.mOutlinePositionMatrix.reset();
    this.mOutlinePositionMatrix.preTranslate(f1, f2);
    this.mPath.transform(this.mOutlinePositionMatrix);
    this.mPaint.setColor(this.mTextFillColor);
    this.mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    this.mPaint.setStrokeWidth(this.mTextOutlineThickness);
    paramCanvas.drawPath(this.mPath, (Paint)this.mPaint);
    this.mOutlinePositionMatrix.reset();
    this.mOutlinePositionMatrix.preTranslate(-f1, -f2);
    this.mPath.transform(this.mOutlinePositionMatrix);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt2);
    this.mAutoSize = false;
    this.mPaddingLeft = getPaddingLeft();
    this.mPaddingRight = getPaddingRight();
    this.mPaddingTop = getPaddingTop();
    this.mPaddingBottom = getPaddingBottom();
    if (i != 1073741824 || k != 1073741824) {
      TextPaint textPaint = this.mPaint;
      String str = this.mText;
      textPaint.getTextBounds(str, 0, str.length(), this.mTextBounds);
      if (i != 1073741824)
        paramInt1 = (int)(this.mTextBounds.width() + 0.99999F); 
      int m = paramInt1 + this.mPaddingLeft + this.mPaddingRight;
      paramInt2 = m;
      i = j;
      if (k != 1073741824) {
        paramInt2 = (int)(this.mPaint.getFontMetricsInt(null) + 0.99999F);
        paramInt1 = paramInt2;
        if (k == Integer.MIN_VALUE)
          paramInt1 = Math.min(j, paramInt2); 
        i = this.mPaddingTop + this.mPaddingBottom + paramInt1;
        paramInt2 = m;
      } 
    } else {
      paramInt2 = paramInt1;
      i = j;
      if (this.mAutoSizeTextType != 0) {
        this.mAutoSize = true;
        paramInt2 = paramInt1;
        i = j;
      } 
    } 
    setMeasuredDimension(paramInt2, i);
  }
  
  public void setGravity(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: istore_2
    //   2: iload_1
    //   3: ldc_w 8388615
    //   6: iand
    //   7: ifne -> 16
    //   10: iload_1
    //   11: ldc_w 8388611
    //   14: ior
    //   15: istore_2
    //   16: iload_2
    //   17: istore_1
    //   18: iload_2
    //   19: bipush #112
    //   21: iand
    //   22: ifne -> 30
    //   25: iload_2
    //   26: bipush #48
    //   28: ior
    //   29: istore_1
    //   30: iload_1
    //   31: aload_0
    //   32: getfield mGravity : I
    //   35: if_icmpeq -> 42
    //   38: aload_0
    //   39: invokevirtual invalidate : ()V
    //   42: aload_0
    //   43: iload_1
    //   44: putfield mGravity : I
    //   47: iload_1
    //   48: bipush #112
    //   50: iand
    //   51: istore_2
    //   52: iload_2
    //   53: bipush #48
    //   55: if_icmpeq -> 80
    //   58: iload_2
    //   59: bipush #80
    //   61: if_icmpeq -> 72
    //   64: aload_0
    //   65: fconst_0
    //   66: putfield mTextPanY : F
    //   69: goto -> 87
    //   72: aload_0
    //   73: fconst_1
    //   74: putfield mTextPanY : F
    //   77: goto -> 87
    //   80: aload_0
    //   81: ldc_w -1.0
    //   84: putfield mTextPanY : F
    //   87: iload_1
    //   88: ldc_w 8388615
    //   91: iand
    //   92: istore_1
    //   93: iload_1
    //   94: iconst_3
    //   95: if_icmpeq -> 129
    //   98: iload_1
    //   99: iconst_5
    //   100: if_icmpeq -> 123
    //   103: iload_1
    //   104: ldc_w 8388611
    //   107: if_icmpeq -> 129
    //   110: iload_1
    //   111: ldc_w 8388613
    //   114: if_icmpeq -> 123
    //   117: aload_0
    //   118: fconst_0
    //   119: putfield mTextPanX : F
    //   122: return
    //   123: aload_0
    //   124: fconst_1
    //   125: putfield mTextPanX : F
    //   128: return
    //   129: aload_0
    //   130: ldc_w -1.0
    //   133: putfield mTextPanX : F
    //   136: return
  }
  
  public void setRound(float paramFloat) {
    boolean bool;
    if (Float.isNaN(paramFloat)) {
      this.mRound = paramFloat;
      paramFloat = this.mRoundPercent;
      this.mRoundPercent = -1.0F;
      setRoundPercent(paramFloat);
      return;
    } 
    if (this.mRound != paramFloat) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mRound = paramFloat;
    if (paramFloat != 0.0F) {
      if (this.mPath == null)
        this.mPath = new Path(); 
      if (this.mRect == null)
        this.mRect = new RectF(); 
      if (Build.VERSION.SDK_INT >= 21) {
        if (this.mViewOutlineProvider == null) {
          ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
              public void getOutline(View param1View, Outline param1Outline) {
                param1Outline.setRoundRect(0, 0, MotionLabel.this.getWidth(), MotionLabel.this.getHeight(), MotionLabel.this.mRound);
              }
            };
          this.mViewOutlineProvider = viewOutlineProvider;
          setOutlineProvider(viewOutlineProvider);
        } 
        setClipToOutline(true);
      } 
      int i = getWidth();
      int j = getHeight();
      this.mRect.set(0.0F, 0.0F, i, j);
      this.mPath.reset();
      Path path = this.mPath;
      RectF rectF = this.mRect;
      paramFloat = this.mRound;
      path.addRoundRect(rectF, paramFloat, paramFloat, Path.Direction.CW);
    } else if (Build.VERSION.SDK_INT >= 21) {
      setClipToOutline(false);
    } 
    if (bool && Build.VERSION.SDK_INT >= 21)
      invalidateOutline(); 
  }
  
  public void setRoundPercent(float paramFloat) {
    boolean bool;
    if (this.mRoundPercent != paramFloat) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mRoundPercent = paramFloat;
    if (paramFloat != 0.0F) {
      if (this.mPath == null)
        this.mPath = new Path(); 
      if (this.mRect == null)
        this.mRect = new RectF(); 
      if (Build.VERSION.SDK_INT >= 21) {
        if (this.mViewOutlineProvider == null) {
          ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
              public void getOutline(View param1View, Outline param1Outline) {
                int i = MotionLabel.this.getWidth();
                int j = MotionLabel.this.getHeight();
                param1Outline.setRoundRect(0, 0, i, j, Math.min(i, j) * MotionLabel.this.mRoundPercent / 2.0F);
              }
            };
          this.mViewOutlineProvider = viewOutlineProvider;
          setOutlineProvider(viewOutlineProvider);
        } 
        setClipToOutline(true);
      } 
      int i = getWidth();
      int j = getHeight();
      paramFloat = Math.min(i, j) * this.mRoundPercent / 2.0F;
      this.mRect.set(0.0F, 0.0F, i, j);
      this.mPath.reset();
      this.mPath.addRoundRect(this.mRect, paramFloat, paramFloat, Path.Direction.CW);
    } else if (Build.VERSION.SDK_INT >= 21) {
      setClipToOutline(false);
    } 
    if (bool && Build.VERSION.SDK_INT >= 21)
      invalidateOutline(); 
  }
  
  public void setScaleFromTextSize(float paramFloat) {
    this.mBaseTextSize = paramFloat;
  }
  
  public void setText(CharSequence paramCharSequence) {
    this.mText = paramCharSequence.toString();
    invalidate();
  }
  
  public void setTextBackgroundPanX(float paramFloat) {
    this.mBackgroundPanX = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTextBackgroundPanY(float paramFloat) {
    this.mBackgroundPanY = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTextBackgroundRotate(float paramFloat) {
    this.mRotate = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTextBackgroundZoom(float paramFloat) {
    this.mZoom = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTextFillColor(int paramInt) {
    this.mTextFillColor = paramInt;
    invalidate();
  }
  
  public void setTextOutlineColor(int paramInt) {
    this.mTextOutlineColor = paramInt;
    this.mUseOutline = true;
    invalidate();
  }
  
  public void setTextOutlineThickness(float paramFloat) {
    this.mTextOutlineThickness = paramFloat;
    this.mUseOutline = true;
    if (Float.isNaN(paramFloat)) {
      this.mTextOutlineThickness = 1.0F;
      this.mUseOutline = false;
    } 
    invalidate();
  }
  
  public void setTextPanX(float paramFloat) {
    this.mTextPanX = paramFloat;
    invalidate();
  }
  
  public void setTextPanY(float paramFloat) {
    this.mTextPanY = paramFloat;
    invalidate();
  }
  
  public void setTextSize(float paramFloat) {
    this.mTextSize = paramFloat;
    String str = TAG;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Debug.getLoc());
    stringBuilder.append("  ");
    stringBuilder.append(paramFloat);
    stringBuilder.append(" / ");
    stringBuilder.append(this.mBaseTextSize);
    Log.v(str, stringBuilder.toString());
    TextPaint textPaint = this.mPaint;
    if (!Float.isNaN(this.mBaseTextSize))
      paramFloat = this.mBaseTextSize; 
    textPaint.setTextSize(paramFloat);
    if (Float.isNaN(this.mBaseTextSize)) {
      paramFloat = 1.0F;
    } else {
      paramFloat = this.mTextSize / this.mBaseTextSize;
    } 
    buildShape(paramFloat);
    requestLayout();
    invalidate();
  }
  
  public void setTextureHeight(float paramFloat) {
    this.mTextureHeight = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTextureWidth(float paramFloat) {
    this.mTextureWidth = paramFloat;
    updateShaderMatrix();
    invalidate();
  }
  
  public void setTypeface(Typeface paramTypeface) {
    if (this.mPaint.getTypeface() != paramTypeface) {
      this.mPaint.setTypeface(paramTypeface);
      if (this.mLayout != null) {
        this.mLayout = null;
        requestLayout();
        invalidate();
      } 
    } 
  }
  
  void setupPath() {
    this.mPaddingLeft = getPaddingLeft();
    this.mPaddingRight = getPaddingRight();
    this.mPaddingTop = getPaddingTop();
    this.mPaddingBottom = getPaddingBottom();
    setTypefaceFromAttrs(this.mFontFamily, this.mTypefaceIndex, this.mStyleIndex);
    this.mPaint.setColor(this.mTextFillColor);
    this.mPaint.setStrokeWidth(this.mTextOutlineThickness);
    this.mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    this.mPaint.setFlags(128);
    setTextSize(this.mTextSize);
    this.mPaint.setAntiAlias(true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayou\\utils\widget\MotionLabel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */