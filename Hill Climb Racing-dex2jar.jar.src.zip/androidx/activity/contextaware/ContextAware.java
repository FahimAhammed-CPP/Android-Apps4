package androidx.activity.contextaware;

import android.content.Context;

public interface ContextAware {
  void addOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener);
  
  Context peekAvailableContext();
  
  void removeOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener);
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\activity\contextaware\ContextAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */