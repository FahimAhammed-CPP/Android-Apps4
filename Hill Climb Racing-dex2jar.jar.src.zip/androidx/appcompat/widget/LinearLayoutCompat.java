package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.appcompat.R;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
  private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
  
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    ViewCompat.saveAttributeDataForStyleable((View)this, paramContext, R.styleable.LinearLayoutCompat, paramAttributeSet, tintTypedArray.getWrappedTypeArray(), paramInt, 0);
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = tintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(tintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    this.mShowDividers = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = tintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    tintTypedArray.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int k = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          layoutParams.width = k;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int k = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          layoutParams.height = k;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - layoutParams.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  int getLocationOffset(View paramView) {
    return 0;
  }
  
  int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  protected boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.mShowDividers & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = ViewUtils.isLayoutRtl((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.mGravity;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt2 = GravityCompat.getAbsoluteGravity(0x800007 & paramInt2, ViewCompat.getLayoutDirection((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b1 + b2 * i;
      View view = getVirtualChildAt(i2);
      if (view == null) {
        paramInt2 += measureNullChild(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool2 && layoutParams.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = layoutParams.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - layoutParams.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = layoutParams.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        int i3 = paramInt2;
        if (hasDividerBeforeChildAt(i2))
          i3 = paramInt2 + this.mDividerWidth; 
        paramInt2 = layoutParams.leftMargin + i3;
        setChildFrame(view, paramInt2 + getLocationOffset(view), paramInt1, i5, i6);
        paramInt1 = layoutParams.rightMargin;
        i3 = getNextLocationOffset(view);
        i += getChildrenSkipCount(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } 
      i++;
    } 
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = layoutParams.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + layoutParams.leftMargin;
            paramInt4 = layoutParams.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i3, i2);
          paramInt3 = layoutParams.bottomMargin;
          i3 = getNextLocationOffset(view);
          paramInt4 = paramInt2 + getChildrenSkipCount(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #21
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #20
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #27
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #25
    //   63: aload #27
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #27
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #27
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #27
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #25
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #25
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #25
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #25
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #23
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #24
    //   115: iload #21
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #13
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #9
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 849
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   173: astore #26
    //   175: aload #26
    //   177: ifnonnull -> 198
    //   180: aload_0
    //   181: aload_0
    //   182: getfield mTotalLength : I
    //   185: aload_0
    //   186: iload #8
    //   188: invokevirtual measureNullChild : (I)I
    //   191: iadd
    //   192: putfield mTotalLength : I
    //   195: goto -> 840
    //   198: aload #26
    //   200: invokevirtual getVisibility : ()I
    //   203: bipush #8
    //   205: if_icmpne -> 224
    //   208: iload #8
    //   210: aload_0
    //   211: aload #26
    //   213: iload #8
    //   215: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   218: iadd
    //   219: istore #8
    //   221: goto -> 195
    //   224: aload_0
    //   225: iload #8
    //   227: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   230: ifeq -> 246
    //   233: aload_0
    //   234: aload_0
    //   235: getfield mTotalLength : I
    //   238: aload_0
    //   239: getfield mDividerWidth : I
    //   242: iadd
    //   243: putfield mTotalLength : I
    //   246: aload #26
    //   248: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   251: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   254: astore #28
    //   256: fload_3
    //   257: aload #28
    //   259: getfield weight : F
    //   262: fadd
    //   263: fstore_3
    //   264: iload #21
    //   266: ldc 1073741824
    //   268: if_icmpne -> 380
    //   271: aload #28
    //   273: getfield width : I
    //   276: ifne -> 380
    //   279: aload #28
    //   281: getfield weight : F
    //   284: fconst_0
    //   285: fcmpl
    //   286: ifle -> 380
    //   289: iload #15
    //   291: ifeq -> 317
    //   294: aload_0
    //   295: aload_0
    //   296: getfield mTotalLength : I
    //   299: aload #28
    //   301: getfield leftMargin : I
    //   304: aload #28
    //   306: getfield rightMargin : I
    //   309: iadd
    //   310: iadd
    //   311: putfield mTotalLength : I
    //   314: goto -> 346
    //   317: aload_0
    //   318: getfield mTotalLength : I
    //   321: istore #14
    //   323: aload_0
    //   324: iload #14
    //   326: aload #28
    //   328: getfield leftMargin : I
    //   331: iload #14
    //   333: iadd
    //   334: aload #28
    //   336: getfield rightMargin : I
    //   339: iadd
    //   340: invokestatic max : (II)I
    //   343: putfield mTotalLength : I
    //   346: iload #23
    //   348: ifeq -> 374
    //   351: iconst_0
    //   352: iconst_0
    //   353: invokestatic makeMeasureSpec : (II)I
    //   356: istore #14
    //   358: aload #26
    //   360: iload #14
    //   362: iload #14
    //   364: invokevirtual measure : (II)V
    //   367: iload #7
    //   369: istore #14
    //   371: goto -> 564
    //   374: iconst_1
    //   375: istore #12
    //   377: goto -> 568
    //   380: aload #28
    //   382: getfield width : I
    //   385: ifne -> 411
    //   388: aload #28
    //   390: getfield weight : F
    //   393: fconst_0
    //   394: fcmpl
    //   395: ifle -> 411
    //   398: aload #28
    //   400: bipush #-2
    //   402: putfield width : I
    //   405: iconst_0
    //   406: istore #14
    //   408: goto -> 416
    //   411: ldc_w -2147483648
    //   414: istore #14
    //   416: fload_3
    //   417: fconst_0
    //   418: fcmpl
    //   419: ifne -> 431
    //   422: aload_0
    //   423: getfield mTotalLength : I
    //   426: istore #17
    //   428: goto -> 434
    //   431: iconst_0
    //   432: istore #17
    //   434: aload_0
    //   435: aload #26
    //   437: iload #8
    //   439: iload_1
    //   440: iload #17
    //   442: iload_2
    //   443: iconst_0
    //   444: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   447: iload #14
    //   449: ldc_w -2147483648
    //   452: if_icmpeq -> 462
    //   455: aload #28
    //   457: iload #14
    //   459: putfield width : I
    //   462: aload #26
    //   464: invokevirtual getMeasuredWidth : ()I
    //   467: istore #17
    //   469: iload #15
    //   471: ifeq -> 507
    //   474: aload_0
    //   475: aload_0
    //   476: getfield mTotalLength : I
    //   479: aload #28
    //   481: getfield leftMargin : I
    //   484: iload #17
    //   486: iadd
    //   487: aload #28
    //   489: getfield rightMargin : I
    //   492: iadd
    //   493: aload_0
    //   494: aload #26
    //   496: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   499: iadd
    //   500: iadd
    //   501: putfield mTotalLength : I
    //   504: goto -> 546
    //   507: aload_0
    //   508: getfield mTotalLength : I
    //   511: istore #14
    //   513: aload_0
    //   514: iload #14
    //   516: iload #14
    //   518: iload #17
    //   520: iadd
    //   521: aload #28
    //   523: getfield leftMargin : I
    //   526: iadd
    //   527: aload #28
    //   529: getfield rightMargin : I
    //   532: iadd
    //   533: aload_0
    //   534: aload #26
    //   536: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   539: iadd
    //   540: invokestatic max : (II)I
    //   543: putfield mTotalLength : I
    //   546: iload #7
    //   548: istore #14
    //   550: iload #24
    //   552: ifeq -> 564
    //   555: iload #17
    //   557: iload #7
    //   559: invokestatic max : (II)I
    //   562: istore #14
    //   564: iload #14
    //   566: istore #7
    //   568: iload #8
    //   570: istore #18
    //   572: iload #20
    //   574: ldc 1073741824
    //   576: if_icmpeq -> 597
    //   579: aload #28
    //   581: getfield height : I
    //   584: iconst_m1
    //   585: if_icmpne -> 597
    //   588: iconst_1
    //   589: istore #8
    //   591: iconst_1
    //   592: istore #10
    //   594: goto -> 600
    //   597: iconst_0
    //   598: istore #8
    //   600: aload #28
    //   602: getfield topMargin : I
    //   605: aload #28
    //   607: getfield bottomMargin : I
    //   610: iadd
    //   611: istore #14
    //   613: aload #26
    //   615: invokevirtual getMeasuredHeight : ()I
    //   618: iload #14
    //   620: iadd
    //   621: istore #17
    //   623: iload #9
    //   625: aload #26
    //   627: invokevirtual getMeasuredState : ()I
    //   630: invokestatic combineMeasuredStates : (II)I
    //   633: istore #19
    //   635: iload #23
    //   637: ifeq -> 724
    //   640: aload #26
    //   642: invokevirtual getBaseline : ()I
    //   645: istore #22
    //   647: iload #22
    //   649: iconst_m1
    //   650: if_icmpeq -> 724
    //   653: aload #28
    //   655: getfield gravity : I
    //   658: ifge -> 670
    //   661: aload_0
    //   662: getfield mGravity : I
    //   665: istore #9
    //   667: goto -> 677
    //   670: aload #28
    //   672: getfield gravity : I
    //   675: istore #9
    //   677: iload #9
    //   679: bipush #112
    //   681: iand
    //   682: iconst_4
    //   683: ishr
    //   684: bipush #-2
    //   686: iand
    //   687: iconst_1
    //   688: ishr
    //   689: istore #9
    //   691: aload #27
    //   693: iload #9
    //   695: aload #27
    //   697: iload #9
    //   699: iaload
    //   700: iload #22
    //   702: invokestatic max : (II)I
    //   705: iastore
    //   706: aload #25
    //   708: iload #9
    //   710: aload #25
    //   712: iload #9
    //   714: iaload
    //   715: iload #17
    //   717: iload #22
    //   719: isub
    //   720: invokestatic max : (II)I
    //   723: iastore
    //   724: iload #13
    //   726: iload #17
    //   728: invokestatic max : (II)I
    //   731: istore #13
    //   733: iload #5
    //   735: ifeq -> 753
    //   738: aload #28
    //   740: getfield height : I
    //   743: iconst_m1
    //   744: if_icmpne -> 753
    //   747: iconst_1
    //   748: istore #5
    //   750: goto -> 756
    //   753: iconst_0
    //   754: istore #5
    //   756: aload #28
    //   758: getfield weight : F
    //   761: fconst_0
    //   762: fcmpl
    //   763: ifle -> 790
    //   766: iload #8
    //   768: ifeq -> 774
    //   771: goto -> 778
    //   774: iload #17
    //   776: istore #14
    //   778: iload #11
    //   780: iload #14
    //   782: invokestatic max : (II)I
    //   785: istore #8
    //   787: goto -> 815
    //   790: iload #8
    //   792: ifeq -> 798
    //   795: goto -> 802
    //   798: iload #17
    //   800: istore #14
    //   802: iload #6
    //   804: iload #14
    //   806: invokestatic max : (II)I
    //   809: istore #6
    //   811: iload #11
    //   813: istore #8
    //   815: aload_0
    //   816: aload #26
    //   818: iload #18
    //   820: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   823: iload #18
    //   825: iadd
    //   826: istore #14
    //   828: iload #19
    //   830: istore #9
    //   832: iload #8
    //   834: istore #11
    //   836: iload #14
    //   838: istore #8
    //   840: iload #8
    //   842: iconst_1
    //   843: iadd
    //   844: istore #8
    //   846: goto -> 160
    //   849: aload_0
    //   850: getfield mTotalLength : I
    //   853: ifle -> 878
    //   856: aload_0
    //   857: iload #16
    //   859: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   862: ifeq -> 878
    //   865: aload_0
    //   866: aload_0
    //   867: getfield mTotalLength : I
    //   870: aload_0
    //   871: getfield mDividerWidth : I
    //   874: iadd
    //   875: putfield mTotalLength : I
    //   878: aload #27
    //   880: iconst_1
    //   881: iaload
    //   882: istore #8
    //   884: iload #8
    //   886: iconst_m1
    //   887: if_icmpne -> 924
    //   890: aload #27
    //   892: iconst_0
    //   893: iaload
    //   894: iconst_m1
    //   895: if_icmpne -> 924
    //   898: aload #27
    //   900: iconst_2
    //   901: iaload
    //   902: iconst_m1
    //   903: if_icmpne -> 924
    //   906: aload #27
    //   908: iconst_3
    //   909: iaload
    //   910: iconst_m1
    //   911: if_icmpeq -> 917
    //   914: goto -> 924
    //   917: iload #13
    //   919: istore #8
    //   921: goto -> 980
    //   924: iload #13
    //   926: aload #27
    //   928: iconst_3
    //   929: iaload
    //   930: aload #27
    //   932: iconst_0
    //   933: iaload
    //   934: iload #8
    //   936: aload #27
    //   938: iconst_2
    //   939: iaload
    //   940: invokestatic max : (II)I
    //   943: invokestatic max : (II)I
    //   946: invokestatic max : (II)I
    //   949: aload #25
    //   951: iconst_3
    //   952: iaload
    //   953: aload #25
    //   955: iconst_0
    //   956: iaload
    //   957: aload #25
    //   959: iconst_1
    //   960: iaload
    //   961: aload #25
    //   963: iconst_2
    //   964: iaload
    //   965: invokestatic max : (II)I
    //   968: invokestatic max : (II)I
    //   971: invokestatic max : (II)I
    //   974: iadd
    //   975: invokestatic max : (II)I
    //   978: istore #8
    //   980: iload #9
    //   982: istore #13
    //   984: iload #8
    //   986: istore #14
    //   988: iload #24
    //   990: ifeq -> 1182
    //   993: iload #21
    //   995: ldc_w -2147483648
    //   998: if_icmpeq -> 1010
    //   1001: iload #8
    //   1003: istore #14
    //   1005: iload #21
    //   1007: ifne -> 1182
    //   1010: aload_0
    //   1011: iconst_0
    //   1012: putfield mTotalLength : I
    //   1015: iconst_0
    //   1016: istore #9
    //   1018: iload #8
    //   1020: istore #14
    //   1022: iload #9
    //   1024: iload #16
    //   1026: if_icmpge -> 1182
    //   1029: aload_0
    //   1030: iload #9
    //   1032: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1035: astore #26
    //   1037: aload #26
    //   1039: ifnonnull -> 1060
    //   1042: aload_0
    //   1043: aload_0
    //   1044: getfield mTotalLength : I
    //   1047: aload_0
    //   1048: iload #9
    //   1050: invokevirtual measureNullChild : (I)I
    //   1053: iadd
    //   1054: putfield mTotalLength : I
    //   1057: goto -> 1083
    //   1060: aload #26
    //   1062: invokevirtual getVisibility : ()I
    //   1065: bipush #8
    //   1067: if_icmpne -> 1086
    //   1070: iload #9
    //   1072: aload_0
    //   1073: aload #26
    //   1075: iload #9
    //   1077: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1080: iadd
    //   1081: istore #9
    //   1083: goto -> 1173
    //   1086: aload #26
    //   1088: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1091: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1094: astore #28
    //   1096: iload #15
    //   1098: ifeq -> 1134
    //   1101: aload_0
    //   1102: aload_0
    //   1103: getfield mTotalLength : I
    //   1106: aload #28
    //   1108: getfield leftMargin : I
    //   1111: iload #7
    //   1113: iadd
    //   1114: aload #28
    //   1116: getfield rightMargin : I
    //   1119: iadd
    //   1120: aload_0
    //   1121: aload #26
    //   1123: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1126: iadd
    //   1127: iadd
    //   1128: putfield mTotalLength : I
    //   1131: goto -> 1083
    //   1134: aload_0
    //   1135: getfield mTotalLength : I
    //   1138: istore #14
    //   1140: aload_0
    //   1141: iload #14
    //   1143: iload #14
    //   1145: iload #7
    //   1147: iadd
    //   1148: aload #28
    //   1150: getfield leftMargin : I
    //   1153: iadd
    //   1154: aload #28
    //   1156: getfield rightMargin : I
    //   1159: iadd
    //   1160: aload_0
    //   1161: aload #26
    //   1163: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1166: iadd
    //   1167: invokestatic max : (II)I
    //   1170: putfield mTotalLength : I
    //   1173: iload #9
    //   1175: iconst_1
    //   1176: iadd
    //   1177: istore #9
    //   1179: goto -> 1018
    //   1182: aload_0
    //   1183: getfield mTotalLength : I
    //   1186: aload_0
    //   1187: invokevirtual getPaddingLeft : ()I
    //   1190: aload_0
    //   1191: invokevirtual getPaddingRight : ()I
    //   1194: iadd
    //   1195: iadd
    //   1196: istore #8
    //   1198: aload_0
    //   1199: iload #8
    //   1201: putfield mTotalLength : I
    //   1204: iload #8
    //   1206: aload_0
    //   1207: invokevirtual getSuggestedMinimumWidth : ()I
    //   1210: invokestatic max : (II)I
    //   1213: iload_1
    //   1214: iconst_0
    //   1215: invokestatic resolveSizeAndState : (III)I
    //   1218: istore #18
    //   1220: ldc_w 16777215
    //   1223: iload #18
    //   1225: iand
    //   1226: aload_0
    //   1227: getfield mTotalLength : I
    //   1230: isub
    //   1231: istore #17
    //   1233: iload #12
    //   1235: ifne -> 1371
    //   1238: iload #17
    //   1240: ifeq -> 1252
    //   1243: fload_3
    //   1244: fconst_0
    //   1245: fcmpl
    //   1246: ifle -> 1252
    //   1249: goto -> 1371
    //   1252: iload #6
    //   1254: iload #11
    //   1256: invokestatic max : (II)I
    //   1259: istore #9
    //   1261: iload #24
    //   1263: ifeq -> 1356
    //   1266: iload #21
    //   1268: ldc 1073741824
    //   1270: if_icmpeq -> 1356
    //   1273: iconst_0
    //   1274: istore #6
    //   1276: iload #6
    //   1278: iload #16
    //   1280: if_icmpge -> 1356
    //   1283: aload_0
    //   1284: iload #6
    //   1286: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1289: astore #25
    //   1291: aload #25
    //   1293: ifnull -> 1347
    //   1296: aload #25
    //   1298: invokevirtual getVisibility : ()I
    //   1301: bipush #8
    //   1303: if_icmpne -> 1309
    //   1306: goto -> 1347
    //   1309: aload #25
    //   1311: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1314: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1317: getfield weight : F
    //   1320: fconst_0
    //   1321: fcmpl
    //   1322: ifle -> 1347
    //   1325: aload #25
    //   1327: iload #7
    //   1329: ldc 1073741824
    //   1331: invokestatic makeMeasureSpec : (II)I
    //   1334: aload #25
    //   1336: invokevirtual getMeasuredHeight : ()I
    //   1339: ldc 1073741824
    //   1341: invokestatic makeMeasureSpec : (II)I
    //   1344: invokevirtual measure : (II)V
    //   1347: iload #6
    //   1349: iconst_1
    //   1350: iadd
    //   1351: istore #6
    //   1353: goto -> 1276
    //   1356: iload #16
    //   1358: istore #8
    //   1360: iload #14
    //   1362: istore #7
    //   1364: iload #9
    //   1366: istore #6
    //   1368: goto -> 2116
    //   1371: aload_0
    //   1372: getfield mWeightSum : F
    //   1375: fstore #4
    //   1377: fload #4
    //   1379: fconst_0
    //   1380: fcmpl
    //   1381: ifle -> 1387
    //   1384: fload #4
    //   1386: fstore_3
    //   1387: aload #27
    //   1389: iconst_3
    //   1390: iconst_m1
    //   1391: iastore
    //   1392: aload #27
    //   1394: iconst_2
    //   1395: iconst_m1
    //   1396: iastore
    //   1397: aload #27
    //   1399: iconst_1
    //   1400: iconst_m1
    //   1401: iastore
    //   1402: aload #27
    //   1404: iconst_0
    //   1405: iconst_m1
    //   1406: iastore
    //   1407: aload #25
    //   1409: iconst_3
    //   1410: iconst_m1
    //   1411: iastore
    //   1412: aload #25
    //   1414: iconst_2
    //   1415: iconst_m1
    //   1416: iastore
    //   1417: aload #25
    //   1419: iconst_1
    //   1420: iconst_m1
    //   1421: iastore
    //   1422: aload #25
    //   1424: iconst_0
    //   1425: iconst_m1
    //   1426: iastore
    //   1427: aload_0
    //   1428: iconst_0
    //   1429: putfield mTotalLength : I
    //   1432: iload #13
    //   1434: istore #9
    //   1436: iconst_m1
    //   1437: istore #11
    //   1439: iconst_0
    //   1440: istore #13
    //   1442: iload #5
    //   1444: istore #8
    //   1446: iload #16
    //   1448: istore #7
    //   1450: iload #9
    //   1452: istore #5
    //   1454: iload #6
    //   1456: istore #9
    //   1458: iload #17
    //   1460: istore #6
    //   1462: iload #13
    //   1464: iload #7
    //   1466: if_icmpge -> 1976
    //   1469: aload_0
    //   1470: iload #13
    //   1472: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1475: astore #26
    //   1477: aload #26
    //   1479: ifnull -> 1967
    //   1482: aload #26
    //   1484: invokevirtual getVisibility : ()I
    //   1487: bipush #8
    //   1489: if_icmpne -> 1495
    //   1492: goto -> 1967
    //   1495: aload #26
    //   1497: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1500: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1503: astore #28
    //   1505: aload #28
    //   1507: getfield weight : F
    //   1510: fstore #4
    //   1512: fload #4
    //   1514: fconst_0
    //   1515: fcmpl
    //   1516: ifle -> 1679
    //   1519: iload #6
    //   1521: i2f
    //   1522: fload #4
    //   1524: fmul
    //   1525: fload_3
    //   1526: fdiv
    //   1527: f2i
    //   1528: istore #14
    //   1530: iload_2
    //   1531: aload_0
    //   1532: invokevirtual getPaddingTop : ()I
    //   1535: aload_0
    //   1536: invokevirtual getPaddingBottom : ()I
    //   1539: iadd
    //   1540: aload #28
    //   1542: getfield topMargin : I
    //   1545: iadd
    //   1546: aload #28
    //   1548: getfield bottomMargin : I
    //   1551: iadd
    //   1552: aload #28
    //   1554: getfield height : I
    //   1557: invokestatic getChildMeasureSpec : (III)I
    //   1560: istore #17
    //   1562: aload #28
    //   1564: getfield width : I
    //   1567: ifne -> 1612
    //   1570: iload #21
    //   1572: ldc 1073741824
    //   1574: if_icmpeq -> 1580
    //   1577: goto -> 1612
    //   1580: iload #14
    //   1582: ifle -> 1592
    //   1585: iload #14
    //   1587: istore #12
    //   1589: goto -> 1595
    //   1592: iconst_0
    //   1593: istore #12
    //   1595: aload #26
    //   1597: iload #12
    //   1599: ldc 1073741824
    //   1601: invokestatic makeMeasureSpec : (II)I
    //   1604: iload #17
    //   1606: invokevirtual measure : (II)V
    //   1609: goto -> 1648
    //   1612: aload #26
    //   1614: invokevirtual getMeasuredWidth : ()I
    //   1617: iload #14
    //   1619: iadd
    //   1620: istore #16
    //   1622: iload #16
    //   1624: istore #12
    //   1626: iload #16
    //   1628: ifge -> 1634
    //   1631: iconst_0
    //   1632: istore #12
    //   1634: aload #26
    //   1636: iload #12
    //   1638: ldc 1073741824
    //   1640: invokestatic makeMeasureSpec : (II)I
    //   1643: iload #17
    //   1645: invokevirtual measure : (II)V
    //   1648: iload #5
    //   1650: aload #26
    //   1652: invokevirtual getMeasuredState : ()I
    //   1655: ldc_w -16777216
    //   1658: iand
    //   1659: invokestatic combineMeasuredStates : (II)I
    //   1662: istore #5
    //   1664: fload_3
    //   1665: fload #4
    //   1667: fsub
    //   1668: fstore_3
    //   1669: iload #6
    //   1671: iload #14
    //   1673: isub
    //   1674: istore #6
    //   1676: goto -> 1679
    //   1679: iload #15
    //   1681: ifeq -> 1720
    //   1684: aload_0
    //   1685: aload_0
    //   1686: getfield mTotalLength : I
    //   1689: aload #26
    //   1691: invokevirtual getMeasuredWidth : ()I
    //   1694: aload #28
    //   1696: getfield leftMargin : I
    //   1699: iadd
    //   1700: aload #28
    //   1702: getfield rightMargin : I
    //   1705: iadd
    //   1706: aload_0
    //   1707: aload #26
    //   1709: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1712: iadd
    //   1713: iadd
    //   1714: putfield mTotalLength : I
    //   1717: goto -> 1762
    //   1720: aload_0
    //   1721: getfield mTotalLength : I
    //   1724: istore #12
    //   1726: aload_0
    //   1727: iload #12
    //   1729: aload #26
    //   1731: invokevirtual getMeasuredWidth : ()I
    //   1734: iload #12
    //   1736: iadd
    //   1737: aload #28
    //   1739: getfield leftMargin : I
    //   1742: iadd
    //   1743: aload #28
    //   1745: getfield rightMargin : I
    //   1748: iadd
    //   1749: aload_0
    //   1750: aload #26
    //   1752: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1755: iadd
    //   1756: invokestatic max : (II)I
    //   1759: putfield mTotalLength : I
    //   1762: iload #20
    //   1764: ldc 1073741824
    //   1766: if_icmpeq -> 1784
    //   1769: aload #28
    //   1771: getfield height : I
    //   1774: iconst_m1
    //   1775: if_icmpne -> 1784
    //   1778: iconst_1
    //   1779: istore #12
    //   1781: goto -> 1787
    //   1784: iconst_0
    //   1785: istore #12
    //   1787: aload #28
    //   1789: getfield topMargin : I
    //   1792: aload #28
    //   1794: getfield bottomMargin : I
    //   1797: iadd
    //   1798: istore #17
    //   1800: aload #26
    //   1802: invokevirtual getMeasuredHeight : ()I
    //   1805: iload #17
    //   1807: iadd
    //   1808: istore #16
    //   1810: iload #11
    //   1812: iload #16
    //   1814: invokestatic max : (II)I
    //   1817: istore #14
    //   1819: iload #12
    //   1821: ifeq -> 1831
    //   1824: iload #17
    //   1826: istore #11
    //   1828: goto -> 1835
    //   1831: iload #16
    //   1833: istore #11
    //   1835: iload #9
    //   1837: iload #11
    //   1839: invokestatic max : (II)I
    //   1842: istore #11
    //   1844: iload #8
    //   1846: ifeq -> 1864
    //   1849: aload #28
    //   1851: getfield height : I
    //   1854: iconst_m1
    //   1855: if_icmpne -> 1864
    //   1858: iconst_1
    //   1859: istore #8
    //   1861: goto -> 1867
    //   1864: iconst_0
    //   1865: istore #8
    //   1867: iload #23
    //   1869: ifeq -> 1956
    //   1872: aload #26
    //   1874: invokevirtual getBaseline : ()I
    //   1877: istore #12
    //   1879: iload #12
    //   1881: iconst_m1
    //   1882: if_icmpeq -> 1956
    //   1885: aload #28
    //   1887: getfield gravity : I
    //   1890: ifge -> 1902
    //   1893: aload_0
    //   1894: getfield mGravity : I
    //   1897: istore #9
    //   1899: goto -> 1909
    //   1902: aload #28
    //   1904: getfield gravity : I
    //   1907: istore #9
    //   1909: iload #9
    //   1911: bipush #112
    //   1913: iand
    //   1914: iconst_4
    //   1915: ishr
    //   1916: bipush #-2
    //   1918: iand
    //   1919: iconst_1
    //   1920: ishr
    //   1921: istore #9
    //   1923: aload #27
    //   1925: iload #9
    //   1927: aload #27
    //   1929: iload #9
    //   1931: iaload
    //   1932: iload #12
    //   1934: invokestatic max : (II)I
    //   1937: iastore
    //   1938: aload #25
    //   1940: iload #9
    //   1942: aload #25
    //   1944: iload #9
    //   1946: iaload
    //   1947: iload #16
    //   1949: iload #12
    //   1951: isub
    //   1952: invokestatic max : (II)I
    //   1955: iastore
    //   1956: iload #11
    //   1958: istore #9
    //   1960: iload #14
    //   1962: istore #11
    //   1964: goto -> 1967
    //   1967: iload #13
    //   1969: iconst_1
    //   1970: iadd
    //   1971: istore #13
    //   1973: goto -> 1462
    //   1976: aload_0
    //   1977: aload_0
    //   1978: getfield mTotalLength : I
    //   1981: aload_0
    //   1982: invokevirtual getPaddingLeft : ()I
    //   1985: aload_0
    //   1986: invokevirtual getPaddingRight : ()I
    //   1989: iadd
    //   1990: iadd
    //   1991: putfield mTotalLength : I
    //   1994: aload #27
    //   1996: iconst_1
    //   1997: iaload
    //   1998: istore #6
    //   2000: iload #6
    //   2002: iconst_m1
    //   2003: if_icmpne -> 2040
    //   2006: aload #27
    //   2008: iconst_0
    //   2009: iaload
    //   2010: iconst_m1
    //   2011: if_icmpne -> 2040
    //   2014: aload #27
    //   2016: iconst_2
    //   2017: iaload
    //   2018: iconst_m1
    //   2019: if_icmpne -> 2040
    //   2022: aload #27
    //   2024: iconst_3
    //   2025: iaload
    //   2026: iconst_m1
    //   2027: if_icmpeq -> 2033
    //   2030: goto -> 2040
    //   2033: iload #11
    //   2035: istore #6
    //   2037: goto -> 2096
    //   2040: iload #11
    //   2042: aload #27
    //   2044: iconst_3
    //   2045: iaload
    //   2046: aload #27
    //   2048: iconst_0
    //   2049: iaload
    //   2050: iload #6
    //   2052: aload #27
    //   2054: iconst_2
    //   2055: iaload
    //   2056: invokestatic max : (II)I
    //   2059: invokestatic max : (II)I
    //   2062: invokestatic max : (II)I
    //   2065: aload #25
    //   2067: iconst_3
    //   2068: iaload
    //   2069: aload #25
    //   2071: iconst_0
    //   2072: iaload
    //   2073: aload #25
    //   2075: iconst_1
    //   2076: iaload
    //   2077: aload #25
    //   2079: iconst_2
    //   2080: iaload
    //   2081: invokestatic max : (II)I
    //   2084: invokestatic max : (II)I
    //   2087: invokestatic max : (II)I
    //   2090: iadd
    //   2091: invokestatic max : (II)I
    //   2094: istore #6
    //   2096: iload #5
    //   2098: istore #13
    //   2100: iload #8
    //   2102: istore #5
    //   2104: iload #7
    //   2106: istore #8
    //   2108: iload #6
    //   2110: istore #7
    //   2112: iload #9
    //   2114: istore #6
    //   2116: iload #5
    //   2118: ifne -> 2131
    //   2121: iload #20
    //   2123: ldc 1073741824
    //   2125: if_icmpeq -> 2131
    //   2128: goto -> 2135
    //   2131: iload #7
    //   2133: istore #6
    //   2135: aload_0
    //   2136: iload #18
    //   2138: iload #13
    //   2140: ldc_w -16777216
    //   2143: iand
    //   2144: ior
    //   2145: iload #6
    //   2147: aload_0
    //   2148: invokevirtual getPaddingTop : ()I
    //   2151: aload_0
    //   2152: invokevirtual getPaddingBottom : ()I
    //   2155: iadd
    //   2156: iadd
    //   2157: aload_0
    //   2158: invokevirtual getSuggestedMinimumHeight : ()I
    //   2161: invokestatic max : (II)I
    //   2164: iload_2
    //   2165: iload #13
    //   2167: bipush #16
    //   2169: ishl
    //   2170: invokestatic resolveSizeAndState : (III)I
    //   2173: invokevirtual setMeasuredDimension : (II)V
    //   2176: iload #10
    //   2178: ifeq -> 2188
    //   2181: aload_0
    //   2182: iload #8
    //   2184: iload_1
    //   2185: invokespecial forceUniformHeight : (II)V
    //   2188: return
  }
  
  int measureNullChild(int paramInt) {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i2 = getVirtualChildCount();
    int i7 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i8 = this.mBaselineAlignedChildIndex;
    boolean bool1 = this.mUseLargestChild;
    float f = 0.0F;
    int i = 0;
    int i4 = 0;
    int n = 0;
    int j = 0;
    int m = 0;
    int i1 = 0;
    int i3 = 0;
    int k = 1;
    boolean bool = false;
    while (i1 < i2) {
      View view = getVirtualChildAt(i1);
      if (view == null) {
        this.mTotalLength += measureNullChild(i1);
      } else if (view.getVisibility() == 8) {
        i1 += getChildrenSkipCount(view, i1);
      } else {
        if (hasDividerBeforeChildAt(i1))
          this.mTotalLength += this.mDividerHeight; 
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        f += layoutParams.weight;
        if (i5 == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0F) {
          i3 = this.mTotalLength;
          this.mTotalLength = Math.max(i3, layoutParams.topMargin + i3 + layoutParams.bottomMargin);
          i3 = 1;
        } else {
          if (layoutParams.height == 0 && layoutParams.weight > 0.0F) {
            layoutParams.height = -2;
            i10 = 0;
          } else {
            i10 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i11 = this.mTotalLength;
          } else {
            i11 = 0;
          } 
          measureChildBeforeLayout(view, i1, paramInt1, 0, paramInt2, i11);
          if (i10 != Integer.MIN_VALUE)
            layoutParams.height = i10; 
          int i10 = view.getMeasuredHeight();
          int i11 = this.mTotalLength;
          this.mTotalLength = Math.max(i11, i11 + i10 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          if (bool1)
            n = Math.max(i10, n); 
        } 
        int i9 = i1;
        if (i8 >= 0 && i8 == i9 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i9 >= i8 || layoutParams.weight <= 0.0F) {
          if (i7 != 1073741824 && layoutParams.width == -1) {
            i1 = 1;
            bool = true;
          } else {
            i1 = 0;
          } 
          int i10 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i11 = view.getMeasuredWidth() + i10;
          i4 = Math.max(i4, i11);
          int i12 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && layoutParams.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (layoutParams.weight > 0.0F) {
            if (i1 == 0)
              i10 = i11; 
            j = Math.max(j, i10);
            k = m;
          } else {
            if (i1 == 0)
              i10 = i11; 
            k = Math.max(m, i10);
          } 
          i1 = getChildrenSkipCount(view, i9);
          m = k;
          i10 = i12;
          i1 += i9;
          k = i;
          i = i10;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i2))
      this.mTotalLength += this.mDividerHeight; 
    if (bool1 && (i5 == Integer.MIN_VALUE || i5 == 0)) {
      this.mTotalLength = 0;
      for (i1 = 0; i1 < i2; i1++) {
        View view = getVirtualChildAt(i1);
        if (view == null) {
          this.mTotalLength += measureNullChild(i1);
        } else if (view.getVisibility() == 8) {
          i1 += getChildrenSkipCount(view, i1);
        } else {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          int i9 = this.mTotalLength;
          this.mTotalLength = Math.max(i9, i9 + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
        } 
      } 
    } 
    i1 = this.mTotalLength + getPaddingTop() + getPaddingBottom();
    this.mTotalLength = i1;
    int i6 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i6) - this.mTotalLength;
    if (i3 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      j = i1;
      i1 = 0;
      n = i4;
      while (i1 < i2) {
        View view = getVirtualChildAt(i1);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i4 = (int)(j * f1 / f);
            int i10 = getPaddingLeft();
            int i11 = getPaddingRight();
            int i12 = layoutParams.leftMargin;
            i8 = layoutParams.rightMargin;
            int i13 = layoutParams.width;
            i3 = j - i4;
            i10 = getChildMeasureSpec(paramInt1, i10 + i11 + i12 + i8, i13);
            if (layoutParams.height != 0 || i5 != 1073741824) {
              i4 = view.getMeasuredHeight() + i4;
              j = i4;
              if (i4 < 0)
                j = 0; 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i4 > 0) {
                j = i4;
              } else {
                j = 0;
              } 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i3;
          } 
          i4 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i9 = view.getMeasuredWidth() + i4;
          i3 = Math.max(n, i9);
          if (i7 != 1073741824 && layoutParams.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (n != 0) {
            n = i4;
          } else {
            n = i9;
          } 
          m = Math.max(m, n);
          if (k != 0 && layoutParams.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.mTotalLength;
          this.mTotalLength = Math.max(n, view.getMeasuredHeight() + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          n = i3;
        } 
        i1++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool1 && i5 != 1073741824)
        for (j = 0; j < i2; j++) {
          View view = getVirtualChildAt(j);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      n = i4;
    } 
    if (k != 0 || i7 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i6);
    if (bool)
      forceUniformWidth(i2, paramInt2); 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
      return;
    } 
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
      return;
    } 
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface DividerMode {}
  
  public static class LayoutParams extends LinearLayout.LayoutParams {
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2, param1Float);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface OrientationMode {}
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */