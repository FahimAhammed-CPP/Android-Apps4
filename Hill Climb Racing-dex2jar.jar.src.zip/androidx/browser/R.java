package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2131099720;
    
    public static final int browser_actions_divider_color = 2131099721;
    
    public static final int browser_actions_text_color = 2131099722;
    
    public static final int browser_actions_title_color = 2131099723;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131165311;
    
    public static final int browser_actions_context_menu_min_padding = 2131165312;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131361982;
    
    public static final int browser_actions_menu_item_icon = 2131361983;
    
    public static final int browser_actions_menu_item_text = 2131361984;
    
    public static final int browser_actions_menu_items = 2131361985;
    
    public static final int browser_actions_menu_view = 2131361986;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131558454;
    
    public static final int browser_actions_context_menu_row = 2131558455;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131886217;
    
    public static final int fallback_menu_item_copy_link = 2131886238;
    
    public static final int fallback_menu_item_open_in_browser = 2131886239;
    
    public static final int fallback_menu_item_share_link = 2131886240;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132082691;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */