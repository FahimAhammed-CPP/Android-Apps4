package com.chartboost.sdk;

import android.app.Activity;
import android.app.NativeActivity;
import android.os.Bundle;
import com.chartboost.sdk.Model.CBError;

public abstract class ChartboostNativeActivity extends NativeActivity implements ChartboostDelegate {
  private Chartboost a;
  
  public void didCacheInterstitial(String paramString) {}
  
  public void didCacheMoreApps() {}
  
  public void didClickInterstitial(String paramString) {}
  
  public void didClickMoreApps() {}
  
  public void didCloseInterstitial(String paramString) {}
  
  public void didCloseMoreApps() {}
  
  public void didDismissInterstitial(String paramString) {}
  
  public void didDismissMoreApps() {}
  
  public void didFailToLoadInterstitial(String paramString, CBError.CBImpressionError paramCBImpressionError) {}
  
  public void didFailToLoadMoreApps(CBError.CBImpressionError paramCBImpressionError) {}
  
  public void didFailToRecordClick(String paramString, CBError.CBClickError paramCBClickError) {}
  
  public void didShowInterstitial(String paramString) {}
  
  public void didShowMoreApps() {}
  
  protected abstract String getChartboostAppID();
  
  protected abstract String getChartboostAppSignature();
  
  public void onBackPressed() {
    if (this.a.onBackPressed())
      return; 
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.a = Chartboost.sharedChartboost();
    CBPreferences.getInstance().setImpressionsUseActivities(true);
    String str1 = getChartboostAppID();
    String str2 = getChartboostAppSignature();
    this.a.onCreate((Activity)this, str1, str2, this);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.a.onDestroy((Activity)this);
  }
  
  protected void onStart() {
    super.onStart();
    this.a.onStart((Activity)this);
    this.a.startSession();
  }
  
  protected void onStop() {
    super.onStop();
    this.a.onStop((Activity)this);
  }
  
  public boolean shouldDisplayInterstitial(String paramString) {
    return true;
  }
  
  public boolean shouldDisplayLoadingViewForMoreApps() {
    return true;
  }
  
  public boolean shouldDisplayMoreApps() {
    return true;
  }
  
  public boolean shouldPauseClickForConfirmation(Chartboost.CBAgeGateConfirmation paramCBAgeGateConfirmation) {
    return false;
  }
  
  public boolean shouldRequestInterstitial(String paramString) {
    return true;
  }
  
  public boolean shouldRequestInterstitialsInFirstSession() {
    return true;
  }
  
  public boolean shouldRequestMoreApps() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\ChartboostNativeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */