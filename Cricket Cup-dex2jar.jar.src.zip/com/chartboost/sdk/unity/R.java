package com.chartboost.sdk.unity;

public final class R {
  public static final class attr {
    public static final int adSize = 2130771968;
    
    public static final int adSizes = 2130771969;
    
    public static final int adUnitId = 2130771970;
    
    public static final int cameraBearing = 2130771972;
    
    public static final int cameraTargetLat = 2130771973;
    
    public static final int cameraTargetLng = 2130771974;
    
    public static final int cameraTilt = 2130771975;
    
    public static final int cameraZoom = 2130771976;
    
    public static final int mapType = 2130771971;
    
    public static final int uiCompass = 2130771977;
    
    public static final int uiRotateGestures = 2130771978;
    
    public static final int uiScrollGestures = 2130771979;
    
    public static final int uiTiltGestures = 2130771980;
    
    public static final int uiZoomControls = 2130771981;
    
    public static final int uiZoomGestures = 2130771982;
    
    public static final int useViewLifecycle = 2130771983;
    
    public static final int zOrderOnTop = 2130771984;
  }
  
  public static final class color {
    public static final int common_action_bar_splitter = 2131034121;
    
    public static final int common_signin_btn_dark_text_default = 2131034112;
    
    public static final int common_signin_btn_dark_text_disabled = 2131034114;
    
    public static final int common_signin_btn_dark_text_focused = 2131034115;
    
    public static final int common_signin_btn_dark_text_pressed = 2131034113;
    
    public static final int common_signin_btn_default_background = 2131034120;
    
    public static final int common_signin_btn_light_text_default = 2131034116;
    
    public static final int common_signin_btn_light_text_disabled = 2131034118;
    
    public static final int common_signin_btn_light_text_focused = 2131034119;
    
    public static final int common_signin_btn_light_text_pressed = 2131034117;
    
    public static final int common_signin_btn_text_dark = 2131034122;
    
    public static final int common_signin_btn_text_light = 2131034123;
  }
  
  public static final class drawable {
    public static final int app_icon = 2130837504;
    
    public static final int common_signin_btn_icon_dark = 2130837505;
    
    public static final int common_signin_btn_icon_disabled_dark = 2130837506;
    
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837507;
    
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837508;
    
    public static final int common_signin_btn_icon_disabled_light = 2130837509;
    
    public static final int common_signin_btn_icon_focus_dark = 2130837510;
    
    public static final int common_signin_btn_icon_focus_light = 2130837511;
    
    public static final int common_signin_btn_icon_light = 2130837512;
    
    public static final int common_signin_btn_icon_normal_dark = 2130837513;
    
    public static final int common_signin_btn_icon_normal_light = 2130837514;
    
    public static final int common_signin_btn_icon_pressed_dark = 2130837515;
    
    public static final int common_signin_btn_icon_pressed_light = 2130837516;
    
    public static final int common_signin_btn_text_dark = 2130837517;
    
    public static final int common_signin_btn_text_disabled_dark = 2130837518;
    
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837519;
    
    public static final int common_signin_btn_text_disabled_focus_light = 2130837520;
    
    public static final int common_signin_btn_text_disabled_light = 2130837521;
    
    public static final int common_signin_btn_text_focus_dark = 2130837522;
    
    public static final int common_signin_btn_text_focus_light = 2130837523;
    
    public static final int common_signin_btn_text_light = 2130837524;
    
    public static final int common_signin_btn_text_normal_dark = 2130837525;
    
    public static final int common_signin_btn_text_normal_light = 2130837526;
    
    public static final int common_signin_btn_text_pressed_dark = 2130837527;
    
    public static final int common_signin_btn_text_pressed_light = 2130837528;
    
    public static final int ic_plusone_medium_off_client = 2130837529;
    
    public static final int ic_plusone_small_off_client = 2130837530;
    
    public static final int ic_plusone_standard_off_client = 2130837531;
    
    public static final int ic_plusone_tall_off_client = 2130837532;
    
    public static final int unityads_background_button_pause = 2130837533;
    
    public static final int unityads_icon_play = 2130837534;
    
    public static final int unityads_icon_speaker_base = 2130837535;
    
    public static final int unityads_icon_speaker_triangle = 2130837536;
    
    public static final int unityads_icon_speaker_waves = 2130837537;
  }
  
  public static final class id {
    public static final int hybrid = 2131165184;
    
    public static final int none = 2131165185;
    
    public static final int normal = 2131165186;
    
    public static final int satellite = 2131165187;
    
    public static final int terrain = 2131165188;
    
    public static final int unityAdsAudioToggleView = 2131165199;
    
    public static final int unityAdsMuteButtonSpeakerWaves = 2131165189;
    
    public static final int unityAdsMuteButtonSpeakerX = 2131165190;
    
    public static final int unityAdsPauseButton = 2131165191;
    
    public static final int unityAdsVideoBufferingText = 2131165194;
    
    public static final int unityAdsVideoCountDown = 2131165195;
    
    public static final int unityAdsVideoSkipText = 2131165193;
    
    public static final int unityAdsVideoTimeLeftPrefix = 2131165196;
    
    public static final int unityAdsVideoTimeLeftSuffix = 2131165198;
    
    public static final int unityAdsVideoTimeLeftText = 2131165197;
    
    public static final int unityAdsVideoView = 2131165192;
  }
  
  public static final class integer {
    public static final int google_play_services_version = 2131099648;
  }
  
  public static final class layout {
    public static final int unityads_button_audio_toggle = 2130903040;
    
    public static final int unityads_button_pause = 2130903041;
    
    public static final int unityads_view_video_paused = 2130903042;
    
    public static final int unityads_view_video_play = 2130903043;
  }
  
  public static final class string {
    public static final int app_name = 2130968613;
    
    public static final int auth_client_needs_enabling_title = 2130968607;
    
    public static final int auth_client_needs_installation_title = 2130968608;
    
    public static final int auth_client_needs_update_title = 2130968609;
    
    public static final int auth_client_play_services_err_notification_msg = 2130968610;
    
    public static final int auth_client_requested_by_msg = 2130968611;
    
    public static final int auth_client_using_bad_version_title = 2130968606;
    
    public static final int common_google_play_services_enable_button = 2130968592;
    
    public static final int common_google_play_services_enable_text = 2130968591;
    
    public static final int common_google_play_services_enable_title = 2130968590;
    
    public static final int common_google_play_services_install_button = 2130968589;
    
    public static final int common_google_play_services_install_text_phone = 2130968587;
    
    public static final int common_google_play_services_install_text_tablet = 2130968588;
    
    public static final int common_google_play_services_install_title = 2130968586;
    
    public static final int common_google_play_services_invalid_account_text = 2130968598;
    
    public static final int common_google_play_services_invalid_account_title = 2130968597;
    
    public static final int common_google_play_services_network_error_text = 2130968596;
    
    public static final int common_google_play_services_network_error_title = 2130968595;
    
    public static final int common_google_play_services_unknown_issue = 2130968599;
    
    public static final int common_google_play_services_unsupported_date_text = 2130968602;
    
    public static final int common_google_play_services_unsupported_text = 2130968601;
    
    public static final int common_google_play_services_unsupported_title = 2130968600;
    
    public static final int common_google_play_services_update_button = 2130968603;
    
    public static final int common_google_play_services_update_text = 2130968594;
    
    public static final int common_google_play_services_update_title = 2130968593;
    
    public static final int common_signin_button_text = 2130968604;
    
    public static final int common_signin_button_text_long = 2130968605;
    
    public static final int location_client_powered_by_google = 2130968612;
    
    public static final int unityads_buffering_text = 2130968579;
    
    public static final int unityads_default_video_length_text = 2130968585;
    
    public static final int unityads_lib_name = 2130968576;
    
    public static final int unityads_mute_character = 2130968578;
    
    public static final int unityads_skip_video_prefix = 2130968582;
    
    public static final int unityads_skip_video_suffix = 2130968583;
    
    public static final int unityads_skip_video_text = 2130968584;
    
    public static final int unityads_tap_to_continue = 2130968577;
    
    public static final int unityads_video_end_prefix = 2130968580;
    
    public static final int unityads_video_end_suffix = 2130968581;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130771968, 2130771969, 2130771970 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] MapAttrs = new int[] { 
        2130771971, 2130771972, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 
        2130771981, 2130771982, 2130771983, 2130771984 };
    
    public static final int MapAttrs_cameraBearing = 1;
    
    public static final int MapAttrs_cameraTargetLat = 2;
    
    public static final int MapAttrs_cameraTargetLng = 3;
    
    public static final int MapAttrs_cameraTilt = 4;
    
    public static final int MapAttrs_cameraZoom = 5;
    
    public static final int MapAttrs_mapType = 0;
    
    public static final int MapAttrs_uiCompass = 6;
    
    public static final int MapAttrs_uiRotateGestures = 7;
    
    public static final int MapAttrs_uiScrollGestures = 8;
    
    public static final int MapAttrs_uiTiltGestures = 9;
    
    public static final int MapAttrs_uiZoomControls = 10;
    
    public static final int MapAttrs_uiZoomGestures = 11;
    
    public static final int MapAttrs_useViewLifecycle = 12;
    
    public static final int MapAttrs_zOrderOnTop = 13;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sd\\unity\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */