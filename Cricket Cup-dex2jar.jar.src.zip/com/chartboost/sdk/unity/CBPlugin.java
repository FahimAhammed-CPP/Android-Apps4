package com.chartboost.sdk.unity;

import android.app.Activity;
import android.util.Log;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.ChartboostDelegate;
import com.chartboost.sdk.Libraries.CBOrientation;
import com.chartboost.sdk.Model.CBError;
import com.unity3d.player.UnityPlayer;
import org.json.JSONException;
import org.json.JSONObject;

public class CBPlugin implements ChartboostDelegate {
  private static final String TAG = "CBPlugin";
  
  private static CBPlugin _instance;
  
  public Activity _activity;
  
  private Chartboost _chartboost;
  
  private void UnitySendMessage(String paramString1, String paramString2, String paramString3) {
    try {
      UnityPlayer.UnitySendMessage(paramString1, paramString2, paramString3);
      return;
    } catch (Exception exception) {
      Log.i("Chartboost", "UnitySendMessage error: " + exception.getMessage());
      Log.i("Chartboost", "UnitySendMessage: " + paramString1 + ", " + paramString2 + ", " + paramString3);
      return;
    } 
  }
  
  private Activity getActivity() {
    return (this._activity != null) ? this._activity : UnityPlayer.currentActivity;
  }
  
  public static Object instance() {
    if (_instance == null)
      _instance = new CBPlugin(); 
    return _instance;
  }
  
  public void cacheInterstitial(final String location) {
    if (this._chartboost == null)
      return; 
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (location != null && location.length() > 0) {
              CBPlugin.this._chartboost.cacheInterstitial(location);
              return;
            } 
            CBPlugin.this._chartboost.cacheInterstitial();
          }
        });
  }
  
  public void cacheMoreApps() {
    if (this._chartboost == null)
      return; 
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            CBPlugin.this._chartboost.cacheMoreApps();
          }
        });
  }
  
  public void destroy() {
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (CBPlugin.this._chartboost == null)
              return; 
            CBPlugin.this._chartboost.onStop(UnityPlayer.currentActivity);
            CBPlugin.this._chartboost.onDestroy(UnityPlayer.currentActivity);
          }
        });
  }
  
  public void didCacheInterstitial(String paramString) {
    UnitySendMessage("ChartBoostManager", "didCacheInterstitial", paramString);
  }
  
  public void didCacheMoreApps() {
    UnitySendMessage("ChartBoostManager", "didCacheMoreApps", "");
  }
  
  public void didClickInterstitial(String paramString) {
    UnitySendMessage("ChartBoostManager", "didClickInterstitial", paramString);
  }
  
  public void didClickMoreApps() {
    UnitySendMessage("ChartBoostManager", "didClickMoreApps", "");
  }
  
  public void didCloseInterstitial(String paramString) {
    UnitySendMessage("ChartBoostManager", "didCloseInterstitial", paramString);
  }
  
  public void didCloseMoreApps() {
    UnitySendMessage("ChartBoostManager", "didCloseMoreApps", "");
  }
  
  public void didDismissInterstitial(String paramString) {
    UnitySendMessage("ChartBoostManager", "didDismissInterstitial", paramString);
  }
  
  public void didDismissMoreApps() {
    UnitySendMessage("ChartBoostManager", "didDismissMoreApps", "");
  }
  
  public void didFailToLoadInterstitial(String paramString, CBError.CBImpressionError paramCBImpressionError) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("location", paramString);
      jSONObject.put("errorCode", paramCBImpressionError.ordinal());
    } catch (JSONException jSONException) {
      Log.d("CBPlugin", "didFailtoLoadInterestial", (Throwable)jSONException);
    } 
    UnitySendMessage("ChartBoostManager", "didFailToLoadInterstitial", jSONObject.toString());
  }
  
  public void didFailToLoadMoreApps(CBError.CBImpressionError paramCBImpressionError) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("errorCode", paramCBImpressionError.ordinal());
    } catch (JSONException jSONException) {
      Log.d("CBPlugin", "didFailtoLoadInterestial", (Throwable)jSONException);
    } 
    UnitySendMessage("ChartBoostManager", "didFailToLoadMoreApps", jSONObject.toString());
  }
  
  public void didFailToRecordClick(String paramString, CBError.CBClickError paramCBClickError) {}
  
  public void didShowInterstitial(String paramString) {
    UnitySendMessage("ChartBoostManager", "didShowInterstitial", paramString);
  }
  
  public void didShowMoreApps() {
    UnitySendMessage("ChartBoostManager", "didShowMoreApps", "");
  }
  
  public void forceOrientation(final String orientation) {
    if (this._chartboost == null)
      return; 
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            CBPreferences cBPreferences = CBPlugin.this._chartboost.getPreferences();
            if (orientation == null) {
              cBPreferences.setOrientation(CBOrientation.UNSPECIFIED);
              return;
            } 
            if (orientation.equals("LandscapeLeft")) {
              cBPreferences.setOrientation(CBOrientation.LANDSCAPE_LEFT);
              return;
            } 
            if (orientation.equals("LandscapeRight")) {
              cBPreferences.setOrientation(CBOrientation.LANDSCAPE_RIGHT);
              return;
            } 
            if (orientation.equals("Portrait")) {
              cBPreferences.setOrientation(CBOrientation.PORTRAIT);
              return;
            } 
            if (orientation.equals("PortraitUpsideDown")) {
              cBPreferences.setOrientation(CBOrientation.PORTRAIT_REVERSE);
              return;
            } 
          }
        });
  }
  
  public boolean hasCachedInterstitial(String paramString) {
    return (this._chartboost == null) ? false : ((paramString != null && paramString.length() > 0) ? this._chartboost.hasCachedInterstitial(paramString) : this._chartboost.hasCachedInterstitial());
  }
  
  public boolean hasCachedMoreApps() {
    return (this._chartboost == null) ? false : this._chartboost.hasCachedMoreApps();
  }
  
  public void init(final String appId, final String appSignature) {
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            CBPlugin.this._chartboost = Chartboost.sharedChartboost();
            CBPreferences cBPreferences = CBPlugin.this._chartboost.getPreferences();
            cBPreferences.setImpressionsUseActivities(false);
            cBPreferences.setUserAgentSuffix("-Unity");
            CBPlugin.this._chartboost.onCreate(UnityPlayer.currentActivity, appId, appSignature, CBPlugin.this);
            CBPlugin.this._chartboost.onStart(UnityPlayer.currentActivity);
            CBPlugin.this._chartboost.startSession();
          }
        });
  }
  
  public boolean onBackPressed() {
    if (this._chartboost == null)
      return false; 
    CBPreferences cBPreferences = this._chartboost.getPreferences();
    boolean bool1 = cBPreferences.getIgnoreErrors();
    cBPreferences.setIgnoreErrors(true);
    boolean bool = false;
    if (Chartboost.sharedChartboost().onBackPressed())
      bool = true; 
    cBPreferences.setIgnoreErrors(bool1);
    return bool;
  }
  
  public void pause(final boolean pause) {
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (CBPlugin.this._chartboost == null)
              return; 
            if (pause) {
              CBPlugin.this._chartboost.onStop(UnityPlayer.currentActivity);
              return;
            } 
            CBPlugin.this._chartboost.onStart(UnityPlayer.currentActivity);
            CBPlugin.this._chartboost.startSession();
          }
        });
  }
  
  public boolean shouldDisplayInterstitial(String paramString) {
    return true;
  }
  
  public boolean shouldDisplayLoadingViewForMoreApps() {
    return false;
  }
  
  public boolean shouldDisplayMoreApps() {
    return true;
  }
  
  public boolean shouldPauseClickForConfirmation(Chartboost.CBAgeGateConfirmation paramCBAgeGateConfirmation) {
    return false;
  }
  
  public boolean shouldRequestInterstitial(String paramString) {
    return true;
  }
  
  public boolean shouldRequestInterstitialsInFirstSession() {
    return true;
  }
  
  public boolean shouldRequestMoreApps() {
    return true;
  }
  
  public void showInterstitial(final String location) {
    if (this._chartboost == null)
      return; 
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (location != null && location.length() > 0) {
              CBPlugin.this._chartboost.showInterstitial(location);
              return;
            } 
            CBPlugin.this._chartboost.showInterstitial();
          }
        });
  }
  
  public void showMoreApps() {
    if (this._chartboost == null)
      return; 
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            CBPlugin.this._chartboost.showMoreApps();
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sd\\unity\CBPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */