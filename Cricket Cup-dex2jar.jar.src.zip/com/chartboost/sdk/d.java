package com.chartboost.sdk;

import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.impl.i;
import com.chartboost.sdk.impl.j;
import org.json.JSONObject;

final class d {
  private static d a = null;
  
  private i b = new i("https://www.chartboost.com", null);
  
  private static d a() {
    if (a == null)
      a = new d(); 
    return a;
  }
  
  protected static void a(Chartboost.CBAPIResponseCallback paramCBAPIResponseCallback) {
    j j = new j("api/more");
    j.a("format", "data");
    a().a(j, paramCBAPIResponseCallback);
  }
  
  private void a(j paramj, Chartboost.CBAPIResponseCallback paramCBAPIResponseCallback) {
    paramj.a(Chartboost.sharedChartboost().e());
    this.b.a(paramj, new i.b(this, paramCBAPIResponseCallback) {
          public void a(j param1j, CBError param1CBError) {
            if (this.a != null)
              this.a.onFailure(param1CBError.b()); 
          }
          
          public void a(JSONObject param1JSONObject, j param1j) {
            if (this.a != null)
              this.a.onSuccess(param1JSONObject); 
          }
        });
  }
  
  protected static void a(String paramString, int paramInt, Chartboost.CBAPIResponseCallback paramCBAPIResponseCallback) {
    j j1 = new j("api/get_batch");
    j1.a("raw", Integer.valueOf(1));
    j1.a("cache", Integer.valueOf(1));
    if (paramString != null)
      j1.a("location", paramString); 
    int j = paramInt;
    if (paramInt > 10)
      j = 10; 
    j1.a("amount", Integer.valueOf(j));
    a().a(j1, paramCBAPIResponseCallback);
  }
  
  protected static void a(String paramString, Chartboost.CBAPIResponseCallback paramCBAPIResponseCallback) {
    j j = new j("api/get");
    j.a("raw", Integer.valueOf(1));
    j.a("cache", Integer.valueOf(1));
    if (paramString != null)
      j.a("location", paramString); 
    a().a(j, paramCBAPIResponseCallback);
  }
  
  protected static void b(String paramString, Chartboost.CBAPIResponseCallback paramCBAPIResponseCallback) {
    j j = new j("api/show");
    j.a("ad_id", paramString);
    a().a(j, paramCBAPIResponseCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */