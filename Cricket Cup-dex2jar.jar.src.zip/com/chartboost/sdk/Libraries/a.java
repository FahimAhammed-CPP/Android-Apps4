package com.chartboost.sdk.Libraries;

import com.chartboost.sdk.CBPreferences;

public final class a {
  public static String a(CBPreferences paramCBPreferences) {
    return "Chartboost-Android-SDK" + paramCBPreferences.getUserAgentSuffix() + " " + "4.0.1";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */