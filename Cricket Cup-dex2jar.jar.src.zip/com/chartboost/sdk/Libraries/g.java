package com.chartboost.sdk.Libraries;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import com.chartboost.sdk.c;
import com.chartboost.sdk.impl.n;
import java.io.File;
import org.json.JSONObject;

public final class g {
  private a a;
  
  private c b;
  
  private float c = 1.0F;
  
  private n.b d = new n.b(this) {
      public void a(g.a param1a, Bundle param1Bundle) {
        g.a(this.a, param1a);
        g.a(this.a).a(this.a);
      }
    };
  
  public g(c paramc) {
    this.b = paramc;
  }
  
  public int a() {
    return this.a.d() * a.a(this.a);
  }
  
  public void a(String paramString) {
    Bundle bundle = new Bundle();
    a(this.b.g(), paramString, bundle);
  }
  
  public void a(JSONObject paramJSONObject, String paramString, Bundle paramBundle) {
    paramJSONObject = paramJSONObject.optJSONObject(paramString);
    if (paramJSONObject != null) {
      Bundle bundle;
      this.b.a();
      paramString = paramJSONObject.optString("url");
      String str = paramJSONObject.optString("checksum");
      this.c = (float)paramJSONObject.optDouble("scale", 1.0D);
      if (paramBundle == null) {
        bundle = new Bundle();
      } else {
        bundle = paramBundle;
      } 
      n.a().a(paramString, str, this.d, null, bundle);
      return;
    } 
    this.b.a(null);
  }
  
  public int b() {
    return this.a.e() * a.a(this.a);
  }
  
  public void c() {
    if (this.a != null)
      this.a.c(); 
  }
  
  public boolean d() {
    return (this.a != null);
  }
  
  public Bitmap e() {
    return (this.a != null) ? this.a.a() : null;
  }
  
  public float f() {
    return this.c;
  }
  
  public static class a {
    private int a;
    
    private String b;
    
    private File c;
    
    private Bitmap d;
    
    private int e = -1;
    
    private int f = -1;
    
    public a(String param1String, File param1File) {
      this.c = param1File;
      this.b = param1String;
      this.d = null;
      this.a = 1;
    }
    
    private void f() {
      if (this.d != null) {
        this.e = this.d.getWidth();
        this.f = this.d.getHeight();
        return;
      } 
      try {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(this.c.getAbsolutePath(), options);
        this.e = options.outWidth;
        this.f = options.outHeight;
        return;
      } catch (Exception exception) {
        CBLogging.b("MemoryBitmap", "Error decoding file size", exception);
        return;
      } 
    }
    
    public Bitmap a() {
      if (this.d == null)
        b(); 
      return this.d;
    }
    
    public void b() {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #7
      //   6: aload_0
      //   7: getfield d : Landroid/graphics/Bitmap;
      //   10: ifnull -> 14
      //   13: return
      //   14: ldc 'MemoryBitmap'
      //   16: new java/lang/StringBuilder
      //   19: dup
      //   20: invokespecial <init> : ()V
      //   23: ldc 'Loading image ''
      //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   28: aload_0
      //   29: getfield b : Ljava/lang/String;
      //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   35: ldc '' from cache'
      //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   40: invokevirtual toString : ()Ljava/lang/String;
      //   43: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
      //   46: new java/io/BufferedInputStream
      //   49: dup
      //   50: new java/io/FileInputStream
      //   53: dup
      //   54: aload_0
      //   55: getfield c : Ljava/io/File;
      //   58: invokespecial <init> : (Ljava/io/File;)V
      //   61: invokespecial <init> : (Ljava/io/InputStream;)V
      //   64: astore #6
      //   66: aload #7
      //   68: astore #5
      //   70: aload #6
      //   72: astore #4
      //   74: aload_0
      //   75: getfield c : Ljava/io/File;
      //   78: invokevirtual length : ()J
      //   81: lstore_2
      //   82: lload_2
      //   83: ldc2_w 2147483647
      //   86: lcmp
      //   87: ifle -> 163
      //   90: aload #6
      //   92: astore #4
      //   94: aload #6
      //   96: invokevirtual close : ()V
      //   99: aload #7
      //   101: astore #5
      //   103: aload #6
      //   105: astore #4
      //   107: new java/io/IOException
      //   110: dup
      //   111: ldc 'Cannot read files larger than 2147483647 bytes'
      //   113: invokespecial <init> : (Ljava/lang/String;)V
      //   116: athrow
      //   117: astore #7
      //   119: aload #6
      //   121: astore #4
      //   123: ldc 'MemoryBitmap'
      //   125: ldc 'IO Exception while decoding bitmap'
      //   127: aload #7
      //   129: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   132: aload #5
      //   134: astore #4
      //   136: aload #6
      //   138: ifnull -> 150
      //   141: aload #6
      //   143: invokevirtual close : ()V
      //   146: aload #5
      //   148: astore #4
      //   150: aload #4
      //   152: ifnonnull -> 286
      //   155: ldc 'MemoryBitmap'
      //   157: ldc 'decode() - bitmap not found'
      //   159: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
      //   162: return
      //   163: lload_2
      //   164: l2i
      //   165: istore_1
      //   166: aload #7
      //   168: astore #5
      //   170: aload #6
      //   172: astore #4
      //   174: iload_1
      //   175: newarray byte
      //   177: astore #7
      //   179: aload #7
      //   181: astore #5
      //   183: aload #6
      //   185: astore #4
      //   187: aload #6
      //   189: aload #7
      //   191: iconst_0
      //   192: iload_1
      //   193: invokevirtual read : ([BII)I
      //   196: pop
      //   197: aload #7
      //   199: astore #4
      //   201: aload #6
      //   203: ifnull -> 150
      //   206: aload #6
      //   208: invokevirtual close : ()V
      //   211: aload #7
      //   213: astore #4
      //   215: goto -> 150
      //   218: astore #4
      //   220: ldc 'MemoryBitmap'
      //   222: ldc 'IO Exception while closing the stream '
      //   224: aload #4
      //   226: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   229: aload #7
      //   231: astore #4
      //   233: goto -> 150
      //   236: astore #4
      //   238: ldc 'MemoryBitmap'
      //   240: ldc 'IO Exception while closing the stream '
      //   242: aload #4
      //   244: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   247: aload #5
      //   249: astore #4
      //   251: goto -> 150
      //   254: astore #5
      //   256: aconst_null
      //   257: astore #4
      //   259: aload #4
      //   261: ifnull -> 269
      //   264: aload #4
      //   266: invokevirtual close : ()V
      //   269: aload #5
      //   271: athrow
      //   272: astore #4
      //   274: ldc 'MemoryBitmap'
      //   276: ldc 'IO Exception while closing the stream '
      //   278: aload #4
      //   280: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   283: goto -> 269
      //   286: new android/graphics/BitmapFactory$Options
      //   289: dup
      //   290: invokespecial <init> : ()V
      //   293: astore #5
      //   295: aload #5
      //   297: iconst_1
      //   298: putfield inJustDecodeBounds : Z
      //   301: aload #4
      //   303: iconst_0
      //   304: aload #4
      //   306: arraylength
      //   307: aload #5
      //   309: invokestatic decodeByteArray : ([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
      //   312: pop
      //   313: new android/graphics/BitmapFactory$Options
      //   316: dup
      //   317: invokespecial <init> : ()V
      //   320: astore #5
      //   322: aload #5
      //   324: iconst_0
      //   325: putfield inJustDecodeBounds : Z
      //   328: aload #5
      //   330: iconst_0
      //   331: putfield inDither : Z
      //   334: aload #5
      //   336: iconst_1
      //   337: putfield inPurgeable : Z
      //   340: aload #5
      //   342: iconst_1
      //   343: putfield inInputShareable : Z
      //   346: aload #5
      //   348: ldc 32768
      //   350: newarray byte
      //   352: putfield inTempStorage : [B
      //   355: aload #5
      //   357: iconst_1
      //   358: putfield inSampleSize : I
      //   361: aload #5
      //   363: getfield inSampleSize : I
      //   366: bipush #32
      //   368: if_icmpge -> 386
      //   371: aload_0
      //   372: aload #4
      //   374: iconst_0
      //   375: aload #4
      //   377: arraylength
      //   378: aload #5
      //   380: invokestatic decodeByteArray : ([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
      //   383: putfield d : Landroid/graphics/Bitmap;
      //   386: aload_0
      //   387: aload #5
      //   389: getfield inSampleSize : I
      //   392: putfield a : I
      //   395: return
      //   396: astore #6
      //   398: ldc 'MemoryBitmap'
      //   400: ldc 'OutOfMemoryError suppressed - trying larger sample size'
      //   402: aload #6
      //   404: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   407: aload #5
      //   409: aload #5
      //   411: getfield inSampleSize : I
      //   414: iconst_2
      //   415: imul
      //   416: putfield inSampleSize : I
      //   419: goto -> 361
      //   422: astore #4
      //   424: ldc 'MemoryBitmap'
      //   426: ldc 'Exception raised decoding bitmap'
      //   428: aload #4
      //   430: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   433: goto -> 386
      //   436: astore #4
      //   438: goto -> 99
      //   441: astore #5
      //   443: goto -> 259
      //   446: astore #7
      //   448: aconst_null
      //   449: astore #6
      //   451: goto -> 119
      // Exception table:
      //   from	to	target	type
      //   46	66	446	java/io/IOException
      //   46	66	254	finally
      //   74	82	117	java/io/IOException
      //   74	82	441	finally
      //   94	99	436	java/io/IOException
      //   94	99	441	finally
      //   107	117	117	java/io/IOException
      //   107	117	441	finally
      //   123	132	441	finally
      //   141	146	236	java/io/IOException
      //   174	179	117	java/io/IOException
      //   174	179	441	finally
      //   187	197	117	java/io/IOException
      //   187	197	441	finally
      //   206	211	218	java/io/IOException
      //   264	269	272	java/io/IOException
      //   371	386	396	java/lang/OutOfMemoryError
      //   371	386	422	java/lang/Exception
    }
    
    public void c() {
      try {
        if (this.d != null && !this.d.isRecycled())
          this.d.recycle(); 
      } catch (Exception exception) {}
      this.d = null;
    }
    
    public int d() {
      if (this.d != null)
        return this.d.getWidth(); 
      if (this.e >= 0)
        return this.e; 
      f();
      return this.e;
    }
    
    public int e() {
      if (this.d != null)
        return this.d.getHeight(); 
      if (this.f >= 0)
        return this.f; 
      f();
      return this.f;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */