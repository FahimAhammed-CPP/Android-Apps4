package com.chartboost.sdk.Libraries;

import java.math.BigInteger;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class f {
  private static j a = new j();
  
  private static i b = new i();
  
  private static f c = new f();
  
  private static b d = new b();
  
  private static h e = new h();
  
  public static a a() {
    return b;
  }
  
  public static a a(a... paramVarArgs) {
    return new k(paramVarArgs);
  }
  
  public static a a(g... paramVarArgs) {
    return new d(paramVarArgs);
  }
  
  public static g a(String paramString, a parama) {
    return new g(paramString, parama);
  }
  
  public static abstract class a {
    private String a = null;
    
    public abstract String a();
    
    public abstract boolean a(Object param1Object);
    
    public boolean a(Object param1Object, StringBuilder param1StringBuilder) {
      boolean bool = a(param1Object);
      if (!bool) {
        if (this.a != null) {
          param1Object = this.a;
        } else {
          param1Object = a();
        } 
        param1StringBuilder.append((String)param1Object);
      } 
      return bool;
    }
  }
  
  private static class b extends a {
    private b() {}
    
    public String a() {
      return "object must be a boolean.";
    }
    
    public boolean a(Object param1Object) {
      return (Boolean.class.isInstance(param1Object) || boolean.class.isInstance(param1Object));
    }
  }
  
  public static abstract class c extends a {}
  
  private static class d extends a {
    protected f.g[] a;
    
    protected String b = null;
    
    public d(f.g[] param1ArrayOfg) {
      this.a = param1ArrayOfg;
    }
    
    public String a() {
      if (this.b != null)
        return this.b; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must contain the following key-value schema: {\n");
      for (int i = 0; i < this.a.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(f.g.a(this.a[i]));
        stringBuilder.append(": [");
        stringBuilder.append(f.g.b(this.a[i]).a());
        stringBuilder.append("]>");
        if (i < this.a.length - 1)
          stringBuilder.append(",\n"); 
      } 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      if (param1Object instanceof Map) {
        param1Object = param1Object;
        for (Map.Entry entry : param1Object.entrySet()) {
          if (!(entry.getKey() instanceof String)) {
            this.b = "key '" + entry.getKey().toString() + "' is not a string";
            return false;
          } 
        } 
        if (this.a != null && this.a.length >= 1)
          for (int i = 0; i < this.a.length; i++) {
            String str = f.g.a(this.a[i]);
            f.a a1 = f.g.b(this.a[i]);
            if (!param1Object.containsKey(str)) {
              if (!a1.a(null)) {
                this.b = "no key for required mapping '" + str + "' : <" + a1.a() + ">";
                return false;
              } 
            } else if (!a1.a(param1Object.get(str))) {
              this.b = "key '" + str + "' fails to match: <" + a1.a() + ">";
              return false;
            } 
          }  
        return true;
      } 
      if (param1Object instanceof JSONObject) {
        param1Object = param1Object;
        if (this.a != null && this.a.length >= 1)
          for (int i = 0; i < this.a.length; i++) {
            String str = f.g.a(this.a[i]);
            f.a a1 = f.g.b(this.a[i]);
            try {
              if (!a1.a(param1Object.get(str))) {
                this.b = "key '" + str + "' fails to match: <" + a1.a() + ">";
                return false;
              } 
            } catch (JSONException jSONException) {
              if (!a1.a(null)) {
                this.b = "no key for required mapping '" + str + "' : <" + a1.a() + ">";
                return false;
              } 
            } 
          }  
        return true;
      } 
      return false;
    }
  }
  
  private static class e extends a {
    private Class<?> a;
    
    public e(Class<?> param1Class) {
      this.a = param1Class;
    }
    
    public String a() {
      return "object must be an instance of " + this.a.getName() + ".";
    }
    
    public boolean a(Object param1Object) {
      return this.a.isInstance(param1Object);
    }
  }
  
  private static class f extends a {
    private f() {}
    
    public String a() {
      return "object must be a number w/o decimals (int, long, short, or byte).";
    }
    
    public boolean a(Object param1Object) {
      return (Integer.class.isInstance(param1Object) || Long.class.isInstance(param1Object) || Short.class.isInstance(param1Object) || Byte.class.isInstance(param1Object) || BigInteger.class.isInstance(param1Object) || int.class.isInstance(param1Object) || long.class.isInstance(param1Object) || short.class.isInstance(param1Object) || byte.class.isInstance(param1Object));
    }
  }
  
  public static class g {
    private String a;
    
    private f.a b;
    
    public g(String param1String, f.a param1a) {
      this.a = param1String;
      this.b = param1a;
    }
  }
  
  private static class h extends a {
    private h() {}
    
    public String a() {
      return "object must be null.";
    }
    
    public boolean a(Object param1Object) {
      return (param1Object == null || param1Object == JSONObject.NULL);
    }
  }
  
  private static class i extends a {
    private i() {}
    
    public String a() {
      return "object must be a number (primitive type or derived from Number).";
    }
    
    public boolean a(Object param1Object) {
      return (param1Object instanceof Number || int.class.isInstance(param1Object) || long.class.isInstance(param1Object) || short.class.isInstance(param1Object) || float.class.isInstance(param1Object) || double.class.isInstance(param1Object) || byte.class.isInstance(param1Object));
    }
  }
  
  private static class j extends e {
    public j() {
      super(String.class);
    }
  }
  
  private static class k extends a {
    protected String a = null;
    
    private f.a[] b;
    
    public k(f.a[] param1ArrayOfa) {
      this.b = param1ArrayOfa;
    }
    
    public String a() {
      if (this.a != null)
        return this.a; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must match ALL of the following: ");
      for (int i = 0; i < this.b.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(this.b[i].a());
        stringBuilder.append(">");
        if (i < this.b.length - 1)
          stringBuilder.append(", "); 
      } 
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      for (int i = 0; i < this.b.length; i++) {
        if (!this.b[i].a(param1Object)) {
          this.a = "object failed to match: <" + this.b[i].a() + ">";
          return false;
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */