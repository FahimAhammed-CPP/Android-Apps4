package com.chartboost.sdk.Libraries;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import com.chartboost.sdk.Chartboost;
import java.util.Map;
import javax.security.auth.x500.X500Principal;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;

public final class CBUtility {
  private static Boolean a = null;
  
  private static final X500Principal b = new X500Principal("CN=Android Debug,O=Android,C=US");
  
  public static int a(int paramInt, Context paramContext) {
    return Math.round(paramInt * b(paramContext));
  }
  
  public static SharedPreferences a() {
    Chartboost chartboost = Chartboost.sharedChartboost();
    if (chartboost.getContext() == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before modifying or accessing preferences."); 
    return chartboost.getContext().getSharedPreferences("cbPrefs", 0);
  }
  
  public static String a(Map<String, Object> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 7
    //   4: ldc ''
    //   6: areturn
    //   7: new java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore_2
    //   15: aload_0
    //   16: invokeinterface keySet : ()Ljava/util/Set;
    //   21: invokeinterface isEmpty : ()Z
    //   26: ifne -> 36
    //   29: aload_2
    //   30: ldc '?'
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: pop
    //   36: aload_0
    //   37: invokeinterface keySet : ()Ljava/util/Set;
    //   42: invokeinterface iterator : ()Ljava/util/Iterator;
    //   47: astore_3
    //   48: aload_3
    //   49: invokeinterface hasNext : ()Z
    //   54: ifeq -> 164
    //   57: aload_3
    //   58: invokeinterface next : ()Ljava/lang/Object;
    //   63: checkcast java/lang/String
    //   66: astore_1
    //   67: aload_2
    //   68: invokevirtual length : ()I
    //   71: iconst_1
    //   72: if_icmple -> 82
    //   75: aload_2
    //   76: ldc '&'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload_0
    //   83: aload_1
    //   84: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: astore #4
    //   94: aload_1
    //   95: ifnull -> 152
    //   98: aload_1
    //   99: ldc 'UTF-8'
    //   101: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   104: astore_1
    //   105: aload_2
    //   106: aload_1
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: pop
    //   111: aload_2
    //   112: ldc '='
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: aload #4
    //   120: ifnull -> 158
    //   123: aload #4
    //   125: ldc 'UTF-8'
    //   127: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   130: astore_1
    //   131: aload_2
    //   132: aload_1
    //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   136: pop
    //   137: goto -> 48
    //   140: astore_0
    //   141: new java/lang/RuntimeException
    //   144: dup
    //   145: ldc 'This method requires UTF-8 encoding support'
    //   147: aload_0
    //   148: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   151: athrow
    //   152: ldc ''
    //   154: astore_1
    //   155: goto -> 105
    //   158: ldc ''
    //   160: astore_1
    //   161: goto -> 131
    //   164: aload_2
    //   165: invokevirtual toString : ()Ljava/lang/String;
    //   168: areturn
    // Exception table:
    //   from	to	target	type
    //   98	105	140	java/io/UnsupportedEncodingException
    //   105	118	140	java/io/UnsupportedEncodingException
    //   123	131	140	java/io/UnsupportedEncodingException
    //   131	137	140	java/io/UnsupportedEncodingException
  }
  
  public static void a(HttpEntity paramHttpEntity) {
    try {
      paramHttpEntity.consumeContent();
      return;
    } catch (Exception exception) {
      CBLogging.b("CBUtility", "Exception raised calling entity.consumeContent()", exception);
      return;
    } 
  }
  
  public static void a(HttpResponse paramHttpResponse) {
    if (paramHttpResponse != null)
      try {
        if (paramHttpResponse.getEntity() != null)
          a(paramHttpResponse.getEntity()); 
        return;
      } catch (Exception exception) {
        CBLogging.b("CBUtility", "Exception raised calling consumeQuietly over http response", exception);
        return;
      }  
  }
  
  public static boolean a(Context paramContext) {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   3: ifnonnull -> 99
    //   6: aload_0
    //   7: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   10: aload_0
    //   11: invokevirtual getPackageName : ()Ljava/lang/String;
    //   14: bipush #64
    //   16: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   19: getfield signatures : [Landroid/content/pm/Signature;
    //   22: astore #4
    //   24: iconst_0
    //   25: istore_1
    //   26: iconst_0
    //   27: istore_2
    //   28: iload_1
    //   29: aload #4
    //   31: arraylength
    //   32: if_icmpge -> 130
    //   35: ldc 'X.509'
    //   37: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
    //   40: new java/io/ByteArrayInputStream
    //   43: dup
    //   44: aload #4
    //   46: iload_1
    //   47: aaload
    //   48: invokevirtual toByteArray : ()[B
    //   51: invokespecial <init> : ([B)V
    //   54: invokevirtual generateCertificate : (Ljava/io/InputStream;)Ljava/security/cert/Certificate;
    //   57: checkcast java/security/cert/X509Certificate
    //   60: invokevirtual getSubjectX500Principal : ()Ljavax/security/auth/x500/X500Principal;
    //   63: getstatic com/chartboost/sdk/Libraries/CBUtility.b : Ljavax/security/auth/x500/X500Principal;
    //   66: invokevirtual equals : (Ljava/lang/Object;)Z
    //   69: istore_3
    //   70: iload_3
    //   71: istore_2
    //   72: iload_2
    //   73: ifeq -> 106
    //   76: aload_0
    //   77: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   80: getfield flags : I
    //   83: iconst_2
    //   84: iand
    //   85: ifeq -> 113
    //   88: iconst_1
    //   89: istore_1
    //   90: iload_2
    //   91: iload_1
    //   92: ior
    //   93: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   96: putstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   99: getstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   102: invokevirtual booleanValue : ()Z
    //   105: ireturn
    //   106: iload_1
    //   107: iconst_1
    //   108: iadd
    //   109: istore_1
    //   110: goto -> 28
    //   113: iconst_0
    //   114: istore_1
    //   115: goto -> 90
    //   118: astore #4
    //   120: iconst_0
    //   121: istore_2
    //   122: goto -> 76
    //   125: astore #4
    //   127: goto -> 76
    //   130: goto -> 76
    // Exception table:
    //   from	to	target	type
    //   6	24	118	java/lang/Exception
    //   28	70	125	java/lang/Exception
  }
  
  public static float b(int paramInt, Context paramContext) {
    return paramInt * b(paramContext);
  }
  
  public static float b(Context paramContext) {
    return (paramContext.getResources().getDisplayMetrics()).density;
  }
  
  public static boolean b() {
    return (Looper.myLooper() == Looper.getMainLooper());
  }
  
  public static CBOrientation c(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'window'
    //   4: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   7: checkcast android/view/WindowManager
    //   10: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   15: astore #4
    //   17: aload_0
    //   18: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   21: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   24: getfield orientation : I
    //   27: istore_2
    //   28: aload #4
    //   30: invokevirtual getRotation : ()I
    //   33: istore_3
    //   34: aload #4
    //   36: invokevirtual getWidth : ()I
    //   39: aload #4
    //   41: invokevirtual getHeight : ()I
    //   44: if_icmpne -> 104
    //   47: iconst_3
    //   48: istore_1
    //   49: iload_1
    //   50: iconst_1
    //   51: if_icmpne -> 127
    //   54: iconst_1
    //   55: istore_1
    //   56: iload_1
    //   57: istore_2
    //   58: iload_3
    //   59: ifeq -> 69
    //   62: iload_3
    //   63: iconst_2
    //   64: if_icmpne -> 162
    //   67: iload_1
    //   68: istore_2
    //   69: iload_2
    //   70: ifeq -> 188
    //   73: iload_3
    //   74: tableswitch default -> 100, 1 -> 176, 2 -> 180, 3 -> 184
    //   100: getstatic com/chartboost/sdk/Libraries/CBOrientation.PORTRAIT : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   103: areturn
    //   104: aload #4
    //   106: invokevirtual getWidth : ()I
    //   109: aload #4
    //   111: invokevirtual getHeight : ()I
    //   114: if_icmpge -> 122
    //   117: iconst_1
    //   118: istore_1
    //   119: goto -> 49
    //   122: iconst_2
    //   123: istore_1
    //   124: goto -> 49
    //   127: iload_1
    //   128: iconst_2
    //   129: if_icmpne -> 137
    //   132: iconst_0
    //   133: istore_1
    //   134: goto -> 56
    //   137: iload_1
    //   138: iconst_3
    //   139: if_icmpne -> 232
    //   142: iload_2
    //   143: iconst_1
    //   144: if_icmpne -> 152
    //   147: iconst_1
    //   148: istore_1
    //   149: goto -> 56
    //   152: iload_2
    //   153: iconst_2
    //   154: if_icmpne -> 232
    //   157: iconst_0
    //   158: istore_1
    //   159: goto -> 56
    //   162: iload_1
    //   163: ifne -> 171
    //   166: iconst_1
    //   167: istore_2
    //   168: goto -> 69
    //   171: iconst_0
    //   172: istore_2
    //   173: goto -> 69
    //   176: getstatic com/chartboost/sdk/Libraries/CBOrientation.LANDSCAPE_LEFT : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   179: areturn
    //   180: getstatic com/chartboost/sdk/Libraries/CBOrientation.PORTRAIT_REVERSE : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   183: areturn
    //   184: getstatic com/chartboost/sdk/Libraries/CBOrientation.LANDSCAPE_RIGHT : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   187: areturn
    //   188: iload_3
    //   189: tableswitch default -> 216, 1 -> 220, 2 -> 224, 3 -> 228
    //   216: getstatic com/chartboost/sdk/Libraries/CBOrientation.LANDSCAPE : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   219: areturn
    //   220: getstatic com/chartboost/sdk/Libraries/CBOrientation.PORTRAIT_LEFT : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   223: areturn
    //   224: getstatic com/chartboost/sdk/Libraries/CBOrientation.LANDSCAPE_REVERSE : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   227: areturn
    //   228: getstatic com/chartboost/sdk/Libraries/CBOrientation.PORTRAIT_RIGHT : Lcom/chartboost/sdk/Libraries/CBOrientation;
    //   231: areturn
    //   232: iconst_1
    //   233: istore_1
    //   234: goto -> 56
  }
  
  public static void throwProguardError(Exception paramException) {
    if (paramException instanceof NoSuchMethodException)
      throw new IllegalStateException("Chartboost library error! Have you used proguard on your application? Make sure to add the line '-keep class com.chartboost.sdk.** { *; }' to your proguard config file."); 
    throw new RuntimeException(paramException);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\CBUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */