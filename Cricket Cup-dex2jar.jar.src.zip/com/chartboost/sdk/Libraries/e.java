package com.chartboost.sdk.Libraries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class e {
  public static a a(String paramString, Object paramObject) {
    return new a(paramString, paramObject);
  }
  
  public static List<?> a(JSONArray paramJSONArray) {
    if (paramJSONArray == null)
      return null; 
    ArrayList<Object<String, Object>> arrayList = new ArrayList();
    for (int i = 0;; i++) {
      if (i < paramJSONArray.length()) {
        try {
          Object<String, Object> object = (Object<String, Object>)paramJSONArray.get(i);
          if (object instanceof JSONObject) {
            object = (Object<String, Object>)a((JSONObject)object);
          } else if (object instanceof JSONArray) {
            object = (Object)a((JSONArray)object);
          } else {
            boolean bool = object.equals(JSONObject.NULL);
            if (bool)
              object = null; 
          } 
          arrayList.add(object);
        } catch (Exception exception) {}
      } else {
        return arrayList;
      } 
    } 
  }
  
  public static Map<String, Object> a(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return null; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<String> iterator = paramJSONObject.keys();
    while (true) {
      if (iterator.hasNext()) {
        try {
          String str = iterator.next();
          Object<String, Object> object = (Object<String, Object>)paramJSONObject.get(str);
          if (object instanceof JSONObject) {
            object = (Object<String, Object>)a((JSONObject)object);
          } else if (object instanceof JSONArray) {
            object = (Object)a((JSONArray)object);
          } else {
            boolean bool = object.equals(JSONObject.NULL);
            if (bool)
              object = null; 
          } 
          hashMap.put(str, object);
        } catch (Exception exception) {}
        continue;
      } 
      return (Map)hashMap;
    } 
  }
  
  public static JSONArray a(List<?> paramList) {
    if (paramList == null)
      return null; 
    JSONArray jSONArray = new JSONArray();
    for (int i = 0;; i++) {
      if (i < paramList.size()) {
        try {
          Object object1;
          Object object2 = paramList.get(i);
          if (object2 instanceof Map) {
            object1 = a((Map<?, ?>)object2);
          } else if (object2 instanceof List) {
            object1 = a((List)object2);
          } else {
            object1 = object2;
            if (object2 == null)
              object1 = JSONObject.NULL; 
          } 
          jSONArray.put(object1);
        } catch (Exception exception) {}
      } else {
        return jSONArray;
      } 
    } 
  }
  
  public static JSONObject a(Map<?, ?> paramMap) {
    if (paramMap == null)
      return null; 
    JSONObject jSONObject = new JSONObject();
    Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
    while (true) {
      if (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        String str = entry.getKey().toString();
        Object object = entry.getValue();
        try {
          Object object1;
          if (object instanceof Map) {
            object1 = a((Map<?, ?>)object);
          } else if (object instanceof List) {
            object1 = a((List)object);
          } else {
            object1 = object;
            if (object == null)
              object1 = JSONObject.NULL; 
          } 
          jSONObject.put(str, object1);
        } catch (Exception exception) {}
        continue;
      } 
      return jSONObject;
    } 
  }
  
  public static JSONObject a(a... paramVarArgs) {
    JSONObject jSONObject = new JSONObject();
    for (int i = 0; i < paramVarArgs.length; i++) {
      try {
        jSONObject.put(a.a(paramVarArgs[i]), a.b(paramVarArgs[i]));
      } catch (JSONException jSONException) {
        CBLogging.b("CBJSON", "Error creating JSONObject-based dictionary", (Throwable)jSONException);
      } 
    } 
    return jSONObject;
  }
  
  public static class a {
    private String a;
    
    private Object b;
    
    public a(String param1String, Object param1Object) {
      this.a = param1String;
      this.b = param1Object;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */