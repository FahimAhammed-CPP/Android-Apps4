package com.chartboost.sdk.Model;

public final class CBError {
  private a a;
  
  private String b;
  
  private boolean c;
  
  public CBError(a parama, String paramString) {
    this.a = parama;
    this.b = paramString;
    this.c = true;
  }
  
  public String a() {
    return this.b;
  }
  
  public CBImpressionError b() {
    switch (null.a[this.a.ordinal()]) {
      default:
        return CBImpressionError.NETWORK_FAILURE;
      case 1:
      case 2:
        return CBImpressionError.INTERNAL;
      case 3:
        break;
    } 
    return CBImpressionError.INTERNET_UNAVAILABLE;
  }
  
  public enum CBClickError {
    AGE_GATE_FAILURE, INTERNAL, NO_HOST_ACTIVITY, URI_INVALID, URI_UNRECOGNIZED;
    
    static {
      INTERNAL = new CBClickError("INTERNAL", 4);
      a = new CBClickError[] { URI_INVALID, URI_UNRECOGNIZED, AGE_GATE_FAILURE, NO_HOST_ACTIVITY, INTERNAL };
    }
  }
  
  public enum CBImpressionError {
    INTERNAL, FIRST_SESSION_INTERSTITIALS_DISABLED, IMPRESSION_ALREADY_VISIBLE, INTERNET_UNAVAILABLE, NETWORK_FAILURE, NO_AD_FOUND, NO_HOST_ACTIVITY, SESSION_NOT_STARTED, TOO_MANY_CONNECTIONS, WRONG_ORIENTATION;
    
    static {
      IMPRESSION_ALREADY_VISIBLE = new CBImpressionError("IMPRESSION_ALREADY_VISIBLE", 8);
      NO_HOST_ACTIVITY = new CBImpressionError("NO_HOST_ACTIVITY", 9);
      a = new CBImpressionError[] { INTERNAL, INTERNET_UNAVAILABLE, TOO_MANY_CONNECTIONS, WRONG_ORIENTATION, FIRST_SESSION_INTERSTITIALS_DISABLED, NETWORK_FAILURE, NO_AD_FOUND, SESSION_NOT_STARTED, IMPRESSION_ALREADY_VISIBLE, NO_HOST_ACTIVITY };
    }
  }
  
  public enum a {
    a, b, c, d, e, f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Model\CBError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */