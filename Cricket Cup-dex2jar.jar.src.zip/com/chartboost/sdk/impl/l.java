package com.chartboost.sdk.impl;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Libraries.CBUtility;

public class l {
  private static boolean a = false;
  
  public static boolean a() {
    try {
      Context context = Chartboost.sharedChartboost().getContext();
      if (a && CBUtility.a(context))
        return false; 
      ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
      if (connectivityManager != null) {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null) {
          boolean bool = networkInfo.isConnectedOrConnecting();
          if (bool)
            return true; 
        } 
      } 
      return false;
    } catch (Exception exception) {
      return true;
    } 
  }
  
  public static int b() {
    try {
      ConnectivityManager connectivityManager = (ConnectivityManager)Chartboost.sharedChartboost().getContext().getSystemService("connectivity");
      if (connectivityManager != null) {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
          int i = networkInfo.getType();
          return (i == 1) ? 1 : 2;
        } 
        return 0;
      } 
      return -1;
    } catch (Exception exception) {
      return -1;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */