package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;

public final class p extends View {
  private boolean a = false;
  
  public p(Context paramContext) {
    super(paramContext);
    setFocusable(false);
    setBackgroundColor(-1442840576);
  }
  
  public void a() {
    if (!this.a) {
      o.a(this);
      this.a = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */