package com.chartboost.sdk.impl;

import java.io.Serializable;

public class bb implements Serializable {
  public boolean equals(Object paramObject) {
    return paramObject instanceof bb;
  }
  
  public int hashCode() {
    return 0;
  }
  
  public String toString() {
    return "MaxKey";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */