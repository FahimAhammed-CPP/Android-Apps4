package com.chartboost.sdk.impl;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Libraries.CBLogging;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.scheme.SocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

public final class k {
  private static ExecutorService a = null;
  
  private static ThreadFactory b = null;
  
  private static HttpClient c = null;
  
  public static ExecutorService a() {
    if (b == null)
      b = new ThreadFactory() {
          private final AtomicInteger a = new AtomicInteger(1);
          
          public Thread newThread(Runnable param1Runnable) {
            return new Thread(param1Runnable, "Chartboost Thread #" + this.a.getAndIncrement());
          }
        }; 
    if (a == null)
      a = Executors.newFixedThreadPool(5, b); 
    return a;
  }
  
  private static String b(Application paramApplication, String paramString) {
    try {
      String str = (paramApplication.getPackageManager().getPackageInfo(paramApplication.getPackageName(), 0)).versionName;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramApplication.getPackageName());
      stringBuilder.append("/");
      stringBuilder.append(str);
      stringBuilder.append(" (");
      stringBuilder.append("Linux; U; Android ");
      stringBuilder.append(Build.VERSION.RELEASE);
      stringBuilder.append("; ");
      stringBuilder.append(Locale.getDefault());
      stringBuilder.append("; ");
      stringBuilder.append(Build.PRODUCT);
      stringBuilder.append(")");
      if (paramString != null) {
        stringBuilder.append(" ");
        stringBuilder.append(paramString);
      } 
      return stringBuilder.toString();
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new RuntimeException(nameNotFoundException);
    } 
  }
  
  protected static HttpClient b() {
    if (c != null)
      return c; 
    try {
      Application application = (Application)Chartboost.sharedChartboost().getContext().getApplicationContext();
      c = (HttpClient)new DefaultHttpClient(CBPreferences.getInstance(), application) {
          protected SocketFactory a() {
            try {
              Class<?> clazz = Class.forName("android.net.SSLSessionCache");
              Object object = clazz.getConstructor(new Class[] { Context.class }).newInstance(new Object[] { this.b });
              return (SocketFactory)Class.forName("android.net.SSLCertificateSocketFactory").getMethod("getHttpSocketFactory", new Class[] { int.class, clazz }).invoke(null, new Object[] { Integer.valueOf(this.a.getTimeout()), object });
            } catch (Exception exception) {
              CBLogging.b("CBAsync:HttpClientProvider", "Unable to use android.net.SSLCertificateSocketFactory to get a SSL session caching socket factory, falling back to a non-caching socket factory", exception);
              return (SocketFactory)SSLSocketFactory.getSocketFactory();
            } 
          }
          
          protected ClientConnectionManager createClientConnectionManager() {
            SchemeRegistry schemeRegistry = new SchemeRegistry();
            schemeRegistry.register(new Scheme("http", (SocketFactory)PlainSocketFactory.getSocketFactory(), 80));
            schemeRegistry.register(new Scheme("https", a(), 443));
            HttpParams httpParams = getParams();
            HttpConnectionParams.setConnectionTimeout(httpParams, this.a.getTimeout());
            HttpConnectionParams.setSoTimeout(httpParams, this.a.getTimeout());
            HttpProtocolParams.setUserAgent(httpParams, k.a(this.b, HttpProtocolParams.getUserAgent(httpParams)));
            return (ClientConnectionManager)new ThreadSafeClientConnManager(httpParams, schemeRegistry);
          }
        };
      return c;
    } catch (Exception exception) {
      CBLogging.b("CBAsync", "Exception raised getting a Chartboost HTTPClient on which to run any network request", exception);
      try {
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        ClientConnectionManager clientConnectionManager = defaultHttpClient.getConnectionManager();
        HttpParams httpParams = defaultHttpClient.getParams();
        c = (HttpClient)new DefaultHttpClient((ClientConnectionManager)new ThreadSafeClientConnManager(httpParams, clientConnectionManager.getSchemeRegistry()), httpParams);
        return c;
      } catch (Exception exception1) {
        CBLogging.b("CBAsync", "Exception raised creating a simple HTTP client", exception);
        c = (HttpClient)new DefaultHttpClient();
        return c;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */