package com.chartboost.sdk.impl;

import java.io.Serializable;
import java.util.Arrays;

public class ay implements Serializable {
  final byte a;
  
  final byte[] b;
  
  public byte a() {
    return this.a;
  }
  
  public byte[] b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (!(paramObject instanceof ay))
        return false; 
      paramObject = paramObject;
      if (this.a != ((ay)paramObject).a)
        return false; 
      if (!Arrays.equals(this.b, ((ay)paramObject).b))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    byte b1 = this.a;
    if (this.b != null) {
      int i = Arrays.hashCode(this.b);
      return i + b1 * 31;
    } 
    byte b = 0;
    return b + b1 * 31;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */