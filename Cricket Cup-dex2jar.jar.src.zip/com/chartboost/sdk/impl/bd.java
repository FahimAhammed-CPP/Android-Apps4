package com.chartboost.sdk.impl;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

public class bd implements Serializable, Comparable<bd> {
  static final Logger a;
  
  private static AtomicInteger f;
  
  private static final int g;
  
  final int b;
  
  final int c;
  
  final int d;
  
  boolean e;
  
  static {
    // Byte code:
    //   0: ldc 'org.bson.ObjectId'
    //   2: invokestatic getLogger : (Ljava/lang/String;)Ljava/util/logging/Logger;
    //   5: putstatic com/chartboost/sdk/impl/bd.a : Ljava/util/logging/Logger;
    //   8: new java/util/concurrent/atomic/AtomicInteger
    //   11: dup
    //   12: new java/util/Random
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: invokevirtual nextInt : ()I
    //   22: invokespecial <init> : (I)V
    //   25: putstatic com/chartboost/sdk/impl/bd.f : Ljava/util/concurrent/atomic/AtomicInteger;
    //   28: new java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore_3
    //   36: invokestatic getNetworkInterfaces : ()Ljava/util/Enumeration;
    //   39: astore #4
    //   41: aload #4
    //   43: invokeinterface hasMoreElements : ()Z
    //   48: ifeq -> 257
    //   51: aload_3
    //   52: aload #4
    //   54: invokeinterface nextElement : ()Ljava/lang/Object;
    //   59: checkcast java/net/NetworkInterface
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: goto -> 41
    //   72: astore_3
    //   73: getstatic com/chartboost/sdk/impl/bd.a : Ljava/util/logging/Logger;
    //   76: getstatic java/util/logging/Level.WARNING : Ljava/util/logging/Level;
    //   79: aload_3
    //   80: invokevirtual getMessage : ()Ljava/lang/String;
    //   83: aload_3
    //   84: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   87: new java/util/Random
    //   90: dup
    //   91: invokespecial <init> : ()V
    //   94: invokevirtual nextInt : ()I
    //   97: bipush #16
    //   99: ishl
    //   100: istore_0
    //   101: getstatic com/chartboost/sdk/impl/bd.a : Ljava/util/logging/Logger;
    //   104: new java/lang/StringBuilder
    //   107: dup
    //   108: invokespecial <init> : ()V
    //   111: ldc 'machine piece post: '
    //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: iload_0
    //   117: invokestatic toHexString : (I)Ljava/lang/String;
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: invokevirtual toString : ()Ljava/lang/String;
    //   126: invokevirtual fine : (Ljava/lang/String;)V
    //   129: new java/util/Random
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: invokevirtual nextInt : ()I
    //   139: istore_2
    //   140: ldc com/chartboost/sdk/impl/bd
    //   142: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   145: astore_3
    //   146: aload_3
    //   147: ifnull -> 273
    //   150: aload_3
    //   151: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   154: istore_1
    //   155: new java/lang/StringBuilder
    //   158: dup
    //   159: invokespecial <init> : ()V
    //   162: astore_3
    //   163: aload_3
    //   164: iload_2
    //   165: invokestatic toHexString : (I)Ljava/lang/String;
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: aload_3
    //   173: iload_1
    //   174: invokestatic toHexString : (I)Ljava/lang/String;
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: pop
    //   181: aload_3
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokevirtual hashCode : ()I
    //   188: ldc 65535
    //   190: iand
    //   191: istore_1
    //   192: getstatic com/chartboost/sdk/impl/bd.a : Ljava/util/logging/Logger;
    //   195: new java/lang/StringBuilder
    //   198: dup
    //   199: invokespecial <init> : ()V
    //   202: ldc 'process piece: '
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: iload_1
    //   208: invokestatic toHexString : (I)Ljava/lang/String;
    //   211: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: invokevirtual toString : ()Ljava/lang/String;
    //   217: invokevirtual fine : (Ljava/lang/String;)V
    //   220: iload_1
    //   221: iload_0
    //   222: ior
    //   223: putstatic com/chartboost/sdk/impl/bd.g : I
    //   226: getstatic com/chartboost/sdk/impl/bd.a : Ljava/util/logging/Logger;
    //   229: new java/lang/StringBuilder
    //   232: dup
    //   233: invokespecial <init> : ()V
    //   236: ldc 'machine : '
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: getstatic com/chartboost/sdk/impl/bd.g : I
    //   244: invokestatic toHexString : (I)Ljava/lang/String;
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: invokevirtual toString : ()Ljava/lang/String;
    //   253: invokevirtual fine : (Ljava/lang/String;)V
    //   256: return
    //   257: aload_3
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: invokevirtual hashCode : ()I
    //   264: istore_0
    //   265: iload_0
    //   266: bipush #16
    //   268: ishl
    //   269: istore_0
    //   270: goto -> 101
    //   273: iconst_0
    //   274: istore_1
    //   275: goto -> 155
    //   278: astore_3
    //   279: new java/lang/RuntimeException
    //   282: dup
    //   283: aload_3
    //   284: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   287: athrow
    // Exception table:
    //   from	to	target	type
    //   28	41	72	java/lang/Throwable
    //   28	41	278	java/lang/Exception
    //   41	69	72	java/lang/Throwable
    //   41	69	278	java/lang/Exception
    //   73	101	278	java/lang/Exception
    //   101	146	278	java/lang/Exception
    //   150	155	278	java/lang/Exception
    //   155	256	278	java/lang/Exception
    //   257	265	72	java/lang/Throwable
    //   257	265	278	java/lang/Exception
  }
  
  public bd() {
    this.b = (int)(System.currentTimeMillis() / 1000L);
    this.c = g;
    this.d = f.getAndIncrement();
    this.e = true;
  }
  
  public bd(int paramInt1, int paramInt2, int paramInt3) {
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
    this.e = false;
  }
  
  public bd(String paramString) {
    this(paramString, false);
  }
  
  public bd(String paramString, boolean paramBoolean) {
    if (!a(paramString))
      throw new IllegalArgumentException("invalid ObjectId [" + paramString + "]"); 
    String str = paramString;
    if (paramBoolean)
      str = b(paramString); 
    byte[] arrayOfByte = new byte[12];
    for (int i = 0; i < arrayOfByte.length; i++)
      arrayOfByte[i] = (byte)Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16); 
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
    this.b = byteBuffer.getInt();
    this.c = byteBuffer.getInt();
    this.d = byteBuffer.getInt();
    this.e = false;
  }
  
  public static bd a(Object paramObject) {
    if (paramObject == null)
      return null; 
    if (paramObject instanceof bd)
      return (bd)paramObject; 
    if (paramObject instanceof String) {
      paramObject = paramObject.toString();
      if (a((String)paramObject))
        return new bd((String)paramObject); 
    } 
    return null;
  }
  
  static String a(String paramString, int paramInt) {
    return paramString.substring(paramInt * 2, paramInt * 2 + 2);
  }
  
  public static boolean a(String paramString) {
    if (paramString != null) {
      int i = paramString.length();
      if (i == 24) {
        int j = 0;
        while (j < i) {
          char c = paramString.charAt(j);
          if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')) {
            j++;
            continue;
          } 
          return false;
        } 
        return true;
      } 
    } 
    return false;
  }
  
  public static String b(String paramString) {
    if (!a(paramString))
      throw new IllegalArgumentException("invalid object id: " + paramString); 
    StringBuilder stringBuilder = new StringBuilder(24);
    int i;
    for (i = 7; i >= 0; i--)
      stringBuilder.append(a(paramString, i)); 
    for (i = 11; i >= 8; i--)
      stringBuilder.append(a(paramString, i)); 
    return stringBuilder.toString();
  }
  
  int a(int paramInt1, int paramInt2) {
    long l = (paramInt1 & 0xFFFFFFFFL) - (paramInt2 & 0xFFFFFFFFL);
    return (l < -2147483648L) ? Integer.MIN_VALUE : ((l > 2147483647L) ? Integer.MAX_VALUE : (int)l);
  }
  
  public int a(bd parambd) {
    if (parambd == null)
      return -1; 
    int j = a(this.b, parambd.b);
    int i = j;
    if (j == 0) {
      j = a(this.c, parambd.c);
      i = j;
      if (j == 0)
        return a(this.d, parambd.d); 
    } 
    return i;
  }
  
  public String a() {
    byte[] arrayOfByte = b();
    StringBuilder stringBuilder = new StringBuilder(24);
    for (int i = 0; i < arrayOfByte.length; i++) {
      String str = Integer.toHexString(arrayOfByte[i] & 0xFF);
      if (str.length() == 1)
        stringBuilder.append("0"); 
      stringBuilder.append(str);
    } 
    return stringBuilder.toString();
  }
  
  public byte[] b() {
    byte[] arrayOfByte = new byte[12];
    ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
    byteBuffer.putInt(this.b);
    byteBuffer.putInt(this.c);
    byteBuffer.putInt(this.d);
    return arrayOfByte;
  }
  
  public int c() {
    return this.b;
  }
  
  public int d() {
    return this.c;
  }
  
  public int e() {
    return this.d;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      paramObject = a(paramObject);
      if (paramObject == null)
        return false; 
      if (this.b != ((bd)paramObject).b || this.c != ((bd)paramObject).c || this.d != ((bd)paramObject).d)
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    return this.b + this.c * 111 + this.d * 17;
  }
  
  public String toString() {
    return a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */