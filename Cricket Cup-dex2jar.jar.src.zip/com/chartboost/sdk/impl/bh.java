package com.chartboost.sdk.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

class bh {
  private static final ConcurrentMap<Class<?>, List<Class<?>>> a = bk.c();
  
  public static <T> List<Class<?>> a(Class<T> paramClass) {
    ConcurrentMap<Class<?>, List<Class<?>>> concurrentMap = a();
    while (true) {
      List<Class<?>> list = concurrentMap.get(paramClass);
      if (list != null)
        return list; 
      concurrentMap.putIfAbsent(paramClass, b(paramClass));
    } 
  }
  
  private static ConcurrentMap<Class<?>, List<Class<?>>> a() {
    return a;
  }
  
  private static <T> void a(Class<T> paramClass, List<Class<?>> paramList) {
    if (paramClass != null && paramClass != Object.class) {
      Class[] arrayOfClass = paramClass.getInterfaces();
      for (int i = arrayOfClass.length - 1; i >= 0; i--)
        a(arrayOfClass[i], paramList); 
      a(paramClass.getSuperclass(), paramList);
      if (!paramList.contains(paramClass)) {
        paramList.add(paramClass);
        return;
      } 
    } 
  }
  
  private static List<Class<?>> b(Class<?> paramClass) {
    ArrayList<Class<Object>> arrayList = new ArrayList();
    arrayList.add(Object.class);
    a(paramClass, arrayList);
    Collections.reverse(arrayList);
    return Collections.unmodifiableList(new ArrayList<Class<?>>(arrayList));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */