package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.database.DataSetObserver;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import java.util.ArrayList;
import java.util.List;

public final class r {
  private ScrollView a;
  
  private HorizontalScrollView b;
  
  private ViewGroup c;
  
  private LinearLayout d;
  
  private BaseAdapter e;
  
  private List<List<View>> f;
  
  private List<List<View>> g;
  
  private List<Integer> h;
  
  private int i;
  
  private DataSetObserver j = new DataSetObserver(this) {
      public void onChanged() {
        int j = r.a(this.a).getChildCount();
        int i;
        for (i = 0; i < j; i++) {
          List list = r.c(this.a).get(((Integer)r.b(this.a).get(i)).intValue());
          List<View> list1 = r.d(this.a).get(((Integer)r.b(this.a).get(i)).intValue());
          View view = r.a(this.a).getChildAt(i);
          list.remove(view);
          list1.add(view);
        } 
        r.b(this.a).clear();
        r.a(this.a).removeAllViews();
        j = r.e(this.a).getCount();
        for (i = 0; i < j; i++) {
          LinearLayout.LayoutParams layoutParams;
          int k = r.e(this.a).getItemViewType(i);
          List<View> list1 = r.c(this.a).get(k);
          List<View> list2 = r.d(this.a).get(k);
          r.b(this.a).add(Integer.valueOf(k));
          View view1 = null;
          if (!list2.isEmpty()) {
            view1 = list2.get(0);
            list2.remove(0);
          } 
          View view2 = r.e(this.a).getView(i, view1, (ViewGroup)r.a(this.a));
          list1.add(view2);
          if (r.f(this.a) == 0) {
            layoutParams = new LinearLayout.LayoutParams(-2, -1);
          } else {
            layoutParams = new LinearLayout.LayoutParams(-1, -2);
          } 
          if (i < j - 1)
            layoutParams.setMargins(0, 0, 0, 1); 
          r.a(this.a).addView(view2, (ViewGroup.LayoutParams)layoutParams);
        } 
        r.a(this.a).requestLayout();
      }
    };
  
  public r(Context paramContext, int paramInt) {
    this.d = new LinearLayout(paramContext);
    this.i = paramInt;
    this.d.setOrientation(paramInt);
    if (paramInt == 0) {
      this.c = (ViewGroup)a(paramContext);
    } else {
      this.c = (ViewGroup)b(paramContext);
    } 
    this.c.addView((View)this.d);
    this.f = new ArrayList<List<View>>();
    this.g = new ArrayList<List<View>>();
    this.h = new ArrayList<Integer>();
    this.d.setOnTouchListener(new View.OnTouchListener(this) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            try {
              param1View = ((Activity)r.a(this.a).getContext()).getCurrentFocus();
              if (param1View != null)
                ((InputMethodManager)r.a(this.a).getContext().getSystemService("input_method")).hideSoftInputFromWindow(param1View.getApplicationWindowToken(), 0); 
              return false;
            } catch (Exception exception) {
              return false;
            } 
          }
        });
  }
  
  private HorizontalScrollView a(Context paramContext) {
    if (this.b == null) {
      this.b = new HorizontalScrollView(paramContext);
      this.b.setFillViewport(true);
    } 
    return this.b;
  }
  
  private ScrollView b(Context paramContext) {
    if (this.a == null) {
      this.a = new ScrollView(paramContext);
      this.a.setFillViewport(true);
    } 
    return this.a;
  }
  
  private Context d() {
    return this.d.getContext();
  }
  
  public ViewGroup a() {
    return this.c;
  }
  
  public void a(int paramInt) {
    if (paramInt != this.i) {
      this.i = paramInt;
      this.d.setOrientation(paramInt);
      this.c.removeView((View)this.d);
      if (paramInt == 0) {
        this.c = (ViewGroup)a(d());
      } else {
        this.c = (ViewGroup)b(d());
      } 
      this.c.addView((View)this.d);
    } 
  }
  
  public void a(BaseAdapter paramBaseAdapter) {
    if (this.e != null)
      this.e.unregisterDataSetObserver(this.j); 
    this.e = paramBaseAdapter;
    this.e.registerDataSetObserver(this.j);
    this.d.removeAllViews();
    this.f.clear();
    this.g.clear();
    for (int i = 0; i < this.e.getViewTypeCount(); i++) {
      this.f.add(new ArrayList<View>());
      this.g.add(new ArrayList<View>());
    } 
    this.h.clear();
    this.e.notifyDataSetChanged();
  }
  
  public LinearLayout b() {
    return this.d;
  }
  
  public void c() {
    if (this.c == this.a && this.a != null) {
      this.a.fullScroll(130);
      return;
    } 
    if (this.c == this.b && this.b != null) {
      this.b.fullScroll(66);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */