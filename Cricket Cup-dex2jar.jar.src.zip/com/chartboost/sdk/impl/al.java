package com.chartboost.sdk.impl;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class al {
  private static boolean a;
  
  private static boolean b;
  
  static final Logger f = Logger.getLogger("org.bson.BSON");
  
  static bi<List<as>> g;
  
  static bi<List<as>> h;
  
  protected static Charset i;
  
  static ThreadLocal<an> j;
  
  static ThreadLocal<am> k;
  
  static {
    a = false;
    b = false;
    g = new bi<List<as>>();
    h = new bi<List<as>>();
    i = Charset.forName("UTF-8");
    j = new ThreadLocal<an>() {
        protected an a() {
          return new aq();
        }
      };
    k = new ThreadLocal<am>() {
        protected am a() {
          return new ap();
        }
      };
  }
  
  public static Object a(Object paramObject) {
    if (!a())
      return paramObject; 
    Object object = paramObject;
    if (g.a() != 0) {
      object = paramObject;
      if (paramObject != null) {
        List list = g.a(paramObject.getClass());
        object = paramObject;
        if (list != null) {
          Iterator<as> iterator = list.iterator();
          while (true) {
            object = paramObject;
            if (iterator.hasNext()) {
              paramObject = ((as)iterator.next()).a(paramObject);
              continue;
            } 
            return object;
          } 
        } 
      } 
    } 
    return object;
  }
  
  public static String a(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    a[] arrayOfA = a.values();
    int k = arrayOfA.length;
    int j = 0;
    int i = paramInt;
    paramInt = j;
    while (paramInt < k) {
      a a = arrayOfA[paramInt];
      j = i;
      if ((a.j & i) > 0) {
        stringBuilder.append(a.k);
        j = i - a.j;
      } 
      paramInt++;
      i = j;
    } 
    if (i > 0)
      throw new IllegalArgumentException("some flags could not be recognized."); 
    return stringBuilder.toString();
  }
  
  private static boolean a() {
    return (a || b);
  }
  
  private enum a {
    a(128, 'c', "Pattern.CANON_EQ"),
    b(1, 'd', "Pattern.UNIX_LINES"),
    c(256, 'g', null),
    d(2, 'i', null),
    e(8, 'm', null),
    f(32, 's', "Pattern.DOTALL"),
    g(16, 't', "Pattern.LITERAL"),
    h(64, 'u', "Pattern.UNICODE_CASE"),
    i(4, 'x', null);
    
    private static final Map<Character, a> m = new HashMap<Character, a>();
    
    public final int j;
    
    public final char k;
    
    public final String l;
    
    static {
      a[] arrayOfA = values();
      int j = arrayOfA.length;
      while (i < j) {
        a a1 = arrayOfA[i];
        m.put(Character.valueOf(a1.k), a1);
        i++;
      } 
    }
    
    a(int param1Int1, char param1Char, String param1String1) {
      this.j = param1Int1;
      this.k = param1Char;
      this.l = param1String1;
    }
    
    static {
      int i = 0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */