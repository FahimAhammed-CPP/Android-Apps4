package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.b;
import com.chartboost.sdk.Libraries.c;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.f;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class j {
  private String a;
  
  private JSONObject b;
  
  private Map<String, Object> c;
  
  private Map<String, Object> d;
  
  private String e;
  
  private boolean f = false;
  
  private f.a g = null;
  
  public j(String paramString) {
    this.a = paramString;
    this.e = "POST";
  }
  
  public static j a(JSONObject paramJSONObject) {
    try {
      j j1 = new j(paramJSONObject.getString("path"));
      j1.e = paramJSONObject.getString("method");
      j1.c = e.a(paramJSONObject.optJSONObject("query"));
      j1.b = paramJSONObject.optJSONObject("body");
      j1.d = e.a(paramJSONObject.optJSONObject("headers"));
      j1.f = paramJSONObject.getBoolean("ensureDelivery");
      return j1;
    } catch (Exception exception) {
      CBLogging.d("CBAPIRequest", "Unable to deserialize failed request", exception);
      return null;
    } 
  }
  
  private void b(Context paramContext) {
    int m = 0;
    int k = 0;
    try {
      if (paramContext instanceof Activity) {
        Activity activity = (Activity)paramContext;
        Rect rect = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        if (Build.VERSION.SDK_INT < 9)
          rect.top = 0; 
        i = rect.width();
        try {
          k = rect.height();
          m = k;
          k = i;
          i = m;
          display = ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay();
          m = display.getWidth();
        } catch (Exception null) {}
      } else {
        i = 0;
        display = ((WindowManager)display.getSystemService("window")).getDefaultDisplay();
        m = display.getWidth();
      } 
    } catch (Exception exception) {
      i = 0;
    } 
    CBLogging.c("CBAPIRequest", "Exception getting activity size", exception);
    k = i;
    int i = m;
    Display display = ((WindowManager)display.getSystemService("window")).getDefaultDisplay();
    m = display.getWidth();
  }
  
  public void a() {
    a("identity", c.b());
    c.a a1 = c.c();
    if (a1.b())
      a("tracking", Integer.valueOf(a1.a())); 
  }
  
  public void a(Context paramContext) {
    a("app", CBPreferences.getInstance().getAppID());
    if ("sdk".equals(Build.PRODUCT)) {
      a("model", "Android Simulator");
    } else {
      a("model", Build.MODEL);
    } 
    a("device_type", Build.MANUFACTURER + " " + Build.MODEL);
    a("os", "Android " + Build.VERSION.RELEASE);
    a("country", Locale.getDefault().getCountry());
    a("language", Locale.getDefault().getLanguage());
    a("sdk", "4.0.1");
    a("timestamp", String.valueOf(Long.valueOf((new Date()).getTime() / 1000L).intValue()));
    a("session", Integer.valueOf(CBUtility.a().getInt("cbPrefSessionCount", 0)));
    int i = l.b();
    if (i != -1)
      a("reachability", Integer.valueOf(i)); 
    b(paramContext);
    a("scale", "" + (paramContext.getResources().getDisplayMetrics()).density);
    try {
      String str = paramContext.getPackageName();
      a("bundle", (paramContext.getPackageManager().getPackageInfo(str, 128)).versionName);
      a("bundle_id", str);
      return;
    } catch (Exception exception) {
      CBLogging.b("CBAPIRequest", "Exception raised getting package mager object", exception);
      return;
    } 
  }
  
  public void a(String paramString, Object paramObject) {
    if (this.b == null)
      this.b = new JSONObject(); 
    try {
      this.b.put(paramString, paramObject);
      return;
    } catch (JSONException jSONException) {
      CBLogging.b("CBAPIRequest", "Error adding body argument", (Throwable)jSONException);
      return;
    } 
  }
  
  public void a(String paramString1, String paramString2) {
    if (this.d == null)
      this.d = new HashMap<String, Object>(); 
    this.d.put(paramString1, paramString2);
  }
  
  public void a(JSONObject paramJSONObject, String paramString) {
    if (paramJSONObject != null)
      try {
        if (paramJSONObject.getString(paramString) != null)
          a(paramString, paramJSONObject.optString(paramString)); 
        return;
      } catch (JSONException jSONException) {
        return;
      }  
  }
  
  public void a(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void a(f.g... paramVarArgs) {
    this.g = f.a(paramVarArgs);
  }
  
  public String b() {
    StringBuilder stringBuilder = new StringBuilder();
    if (this.a.startsWith("/")) {
      String str1 = "";
      return stringBuilder.append(str1).append(this.a).append(CBUtility.a(this.c)).toString();
    } 
    String str = "/";
    return stringBuilder.append(str).append(this.a).append(CBUtility.a(this.c)).toString();
  }
  
  public void b(String paramString1, String paramString2) {
    paramString2 = b.b(b.a(String.format(Locale.US, "%s %s\n%s\n%s", new Object[] { this.e, b(), paramString2, c() }).getBytes()));
    a("X-Chartboost-App", paramString1);
    a("X-Chartboost-Signature", paramString2);
  }
  
  public String c() {
    return this.b.toString();
  }
  
  public JSONObject d() {
    return this.b;
  }
  
  public Map<String, Object> e() {
    return this.d;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public f.a g() {
    return this.g;
  }
  
  public JSONObject h() {
    return e.a(new e.a[] { e.a("path", this.a), e.a("method", this.e), e.a("query", e.a(this.c)), e.a("body", this.b), e.a("headers", e.a(this.d)), e.a("ensureDelivery", Boolean.valueOf(this.f)) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */