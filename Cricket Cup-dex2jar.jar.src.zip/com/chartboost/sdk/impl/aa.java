package com.chartboost.sdk.impl;

public class aa {
  final Object a;
  
  final String b;
  
  public Object a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null || getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if ((this.a != null) ? !this.a.equals(((aa)paramObject).a) : (((aa)paramObject).a != null))
        return false; 
      if ((this.b != null) ? !this.b.equals(((aa)paramObject).b) : (((aa)paramObject).b != null))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    byte b;
    int i = 0;
    if (this.a != null) {
      b = this.a.hashCode();
    } else {
      b = 0;
    } 
    if (this.b != null)
      i = this.b.hashCode(); 
    return b * 31 + i;
  }
  
  public String toString() {
    return "{ \"$ref\" : \"" + this.b + "\", \"$id\" : \"" + this.a + "\" }";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */