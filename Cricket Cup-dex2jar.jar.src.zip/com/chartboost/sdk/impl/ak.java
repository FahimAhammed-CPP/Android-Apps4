package com.chartboost.sdk.impl;

import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;

public class ak extends Writer implements Serializable {
  private final StringBuilder a = new StringBuilder();
  
  public ak() {}
  
  public ak(int paramInt) {}
  
  public Writer append(char paramChar) {
    this.a.append(paramChar);
    return this;
  }
  
  public Writer append(CharSequence paramCharSequence) {
    this.a.append(paramCharSequence);
    return this;
  }
  
  public Writer append(CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    this.a.append(paramCharSequence, paramInt1, paramInt2);
    return this;
  }
  
  public void close() {}
  
  public void flush() {}
  
  public String toString() {
    return this.a.toString();
  }
  
  public void write(String paramString) {
    if (paramString != null)
      this.a.append(paramString); 
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    if (paramArrayOfchar != null)
      this.a.append(paramArrayOfchar, paramInt1, paramInt2); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */