package com.chartboost.sdk.impl;

import java.util.List;
import java.util.Map;

public class bi<T> {
  private final Map<Class<?>, T> a = bk.c();
  
  private final Map<Class<?>, T> b = bj.a(new a());
  
  public static <T> List<Class<?>> a(Class<T> paramClass) {
    return bh.a(paramClass);
  }
  
  public int a() {
    return this.a.size();
  }
  
  public T a(Class<?> paramClass, T paramT) {
    try {
      paramClass = (Class<?>)this.a.put(paramClass, paramT);
      return (T)paramClass;
    } finally {
      this.b.clear();
    } 
  }
  
  public T a(Object paramObject) {
    return this.b.get(paramObject);
  }
  
  private final class a implements bl<Class<?>, T> {
    private a(bi this$0) {}
    
    public T a(Class<?> param1Class) {
      for (Class<?> clazz : bi.a(param1Class)) {
        clazz = (Class<?>)bi.a(this.a).get(clazz);
        if (clazz != null)
          return (T)clazz; 
      } 
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */