package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import org.json.JSONObject;

public class h extends b implements g.b {
  private WebView b;
  
  public h(Context paramContext) {
    super(paramContext);
    this.b = new WebView(paramContext);
    addView((View)this.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    this.b.setBackgroundColor(0);
    this.b.setWebViewClient(new WebViewClient(this) {
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            if (param1String == null)
              return false; 
            if (param1String.contains("chartboost") && param1String.contains("click") && this.a.a != null)
              this.a.a.onClick((View)this.a); 
            return true;
          }
        });
  }
  
  public int a() {
    return CBUtility.a(100, getContext());
  }
  
  public void a(JSONObject paramJSONObject, int paramInt) {
    String str = paramJSONObject.optString("html");
    if (str != null)
      try {
        this.b.loadDataWithBaseURL("file:///android_res/", str, "text/html", "UTF-8", null);
        return;
      } catch (Exception exception) {
        CBLogging.b("CBNativeMoreAppsWebViewCell", "Exception raised loading data into webview", exception);
        return;
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */