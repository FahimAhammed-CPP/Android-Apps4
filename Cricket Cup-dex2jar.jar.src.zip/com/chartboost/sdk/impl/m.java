package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Model.CBError;
import java.net.URI;
import java.net.URISyntaxException;

public final class m {
  private static m c;
  
  private a a;
  
  private com.chartboost.sdk.Model.a b;
  
  private m(a parama) {
    this.a = parama;
  }
  
  public static m a(a parama) {
    if (c == null)
      c = new m(parama); 
    return c;
  }
  
  private void a(String paramString, Context paramContext) {
    this.b.c = com.chartboost.sdk.Model.a.b.g;
    Context context = paramContext;
    if (paramContext == null)
      context = Chartboost.sharedChartboost().getContext(); 
    if (context == null) {
      if (this.a != null)
        this.a.a(this.b, false, paramString, CBError.CBClickError.NO_HOST_ACTIVITY); 
      return;
    } 
    try {
      Intent intent = new Intent("android.intent.action.VIEW");
      if (!(context instanceof Activity))
        intent.addFlags(268435456); 
      intent.setData(Uri.parse(paramString));
      context.startActivity(intent);
      String str = paramString;
    } catch (Exception exception) {}
    if (this.a != null) {
      this.a.a(this.b, true, (String)exception, null);
      return;
    } 
  }
  
  public void a(com.chartboost.sdk.Model.a parama, String paramString, Activity paramActivity) {
    String str;
    this.b = parama;
    try {
      URI uRI = new URI(paramString);
      str = uRI.getScheme();
      if (str == null) {
        if (this.a != null)
          this.a.a(parama, false, paramString, CBError.CBClickError.URI_INVALID); 
        return;
      } 
    } catch (URISyntaxException uRISyntaxException) {
      if (this.a != null) {
        this.a.a(parama, false, paramString, CBError.CBClickError.URI_INVALID);
        return;
      } 
      return;
    } 
    if (!str.equals("http") && !str.equals("https")) {
      a(paramString, (Context)uRISyntaxException);
      return;
    } 
    Runnable runnable = new Runnable(this, paramString, (Activity)uRISyntaxException) {
        public void a(String param1String) {
          Runnable runnable = new Runnable(this, param1String) {
              public void run() {
                m.a(this.b.c, this.a, (Context)this.b.b);
              }
            };
          if (this.b != null) {
            this.b.runOnUiThread(runnable);
            return;
          } 
          (new Handler()).post(runnable);
        }
        
        public void run() {
          // Byte code:
          //   0: aload_0
          //   1: getfield a : Ljava/lang/String;
          //   4: astore_1
          //   5: aload_1
          //   6: astore_2
          //   7: invokestatic a : ()Z
          //   10: ifeq -> 150
          //   13: aconst_null
          //   14: astore_3
          //   15: aconst_null
          //   16: astore #4
          //   18: aload_3
          //   19: astore_2
          //   20: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
          //   23: astore #5
          //   25: aload_3
          //   26: astore_2
          //   27: new java/net/URL
          //   30: dup
          //   31: aload_0
          //   32: getfield a : Ljava/lang/String;
          //   35: invokespecial <init> : (Ljava/lang/String;)V
          //   38: invokevirtual openConnection : ()Ljava/net/URLConnection;
          //   41: checkcast java/net/HttpURLConnection
          //   44: astore_3
          //   45: aload_3
          //   46: iconst_0
          //   47: invokevirtual setInstanceFollowRedirects : (Z)V
          //   50: aload_3
          //   51: aload #5
          //   53: invokevirtual getTimeout : ()I
          //   56: invokevirtual setConnectTimeout : (I)V
          //   59: aload_3
          //   60: aload #5
          //   62: invokevirtual getTimeout : ()I
          //   65: invokevirtual setReadTimeout : (I)V
          //   68: aload_3
          //   69: ldc 'Location'
          //   71: invokevirtual getHeaderField : (Ljava/lang/String;)Ljava/lang/String;
          //   74: astore_2
          //   75: aload_2
          //   76: ifnull -> 81
          //   79: aload_2
          //   80: astore_1
          //   81: aload_1
          //   82: astore_2
          //   83: aload_3
          //   84: ifnull -> 150
          //   87: aload_3
          //   88: invokevirtual disconnect : ()V
          //   91: aload_0
          //   92: aload_1
          //   93: invokevirtual a : (Ljava/lang/String;)V
          //   96: return
          //   97: astore_2
          //   98: aload #4
          //   100: astore_3
          //   101: aload_2
          //   102: astore #4
          //   104: aload_3
          //   105: astore_2
          //   106: ldc 'CBURLOpener'
          //   108: ldc 'Exception raised while opening a HTTP Conection'
          //   110: aload #4
          //   112: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
          //   115: aload_1
          //   116: astore_2
          //   117: aload_3
          //   118: ifnull -> 150
          //   121: aload_3
          //   122: invokevirtual disconnect : ()V
          //   125: goto -> 91
          //   128: astore_1
          //   129: aload_2
          //   130: ifnull -> 137
          //   133: aload_2
          //   134: invokevirtual disconnect : ()V
          //   137: aload_1
          //   138: athrow
          //   139: astore_1
          //   140: aload_3
          //   141: astore_2
          //   142: goto -> 129
          //   145: astore #4
          //   147: goto -> 104
          //   150: aload_2
          //   151: astore_1
          //   152: goto -> 91
          // Exception table:
          //   from	to	target	type
          //   20	25	97	java/lang/Exception
          //   20	25	128	finally
          //   27	45	97	java/lang/Exception
          //   27	45	128	finally
          //   45	75	145	java/lang/Exception
          //   45	75	139	finally
          //   106	115	128	finally
        }
      };
    k.a().execute(runnable);
  }
  
  public static interface a {
    void a(com.chartboost.sdk.Model.a param1a, boolean param1Boolean, String param1String, CBError.CBClickError param1CBClickError);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */