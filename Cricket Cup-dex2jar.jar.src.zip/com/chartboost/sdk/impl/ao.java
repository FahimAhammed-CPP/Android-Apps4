package com.chartboost.sdk.impl;

import java.util.Set;

public interface ao {
  Object a(String paramString);
  
  Object a(String paramString, Object paramObject);
  
  boolean b(String paramString);
  
  Set<String> keySet();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */