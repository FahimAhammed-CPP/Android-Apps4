package com.google.android.gms.common.data;

import android.content.ContentValues;
import android.database.AbstractWindowedCursor;
import android.database.CharArrayBuffer;
import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataHolder implements SafeParcelable {
  public static final DataHolderCreator CREATOR = new DataHolderCreator();
  
  private static final Builder nS = new Builder(new String[0], null) {
      public DataHolder.Builder withRow(ContentValues param1ContentValues) {
        throw new UnsupportedOperationException("Cannot add data to empty builder");
      }
      
      public DataHolder.Builder withRow(HashMap<String, Object> param1HashMap) {
        throw new UnsupportedOperationException("Cannot add data to empty builder");
      }
    };
  
  private final int kg;
  
  private final int mC;
  
  boolean mClosed = false;
  
  private final String[] nK;
  
  Bundle nL;
  
  private final CursorWindow[] nM;
  
  private final Bundle nN;
  
  int[] nO;
  
  int nP;
  
  private Object nQ;
  
  private boolean nR = true;
  
  DataHolder(int paramInt1, String[] paramArrayOfString, CursorWindow[] paramArrayOfCursorWindow, int paramInt2, Bundle paramBundle) {
    this.kg = paramInt1;
    this.nK = paramArrayOfString;
    this.nM = paramArrayOfCursorWindow;
    this.mC = paramInt2;
    this.nN = paramBundle;
  }
  
  public DataHolder(AbstractWindowedCursor paramAbstractWindowedCursor, int paramInt, Bundle paramBundle) {
    this(paramAbstractWindowedCursor.getColumnNames(), a(paramAbstractWindowedCursor), paramInt, paramBundle);
  }
  
  private DataHolder(Builder paramBuilder, int paramInt, Bundle paramBundle) {
    this(Builder.a(paramBuilder), a(paramBuilder, -1), paramInt, paramBundle);
  }
  
  private DataHolder(Builder paramBuilder, int paramInt1, Bundle paramBundle, int paramInt2) {
    this(Builder.a(paramBuilder), a(paramBuilder, paramInt2), paramInt1, paramBundle);
  }
  
  public DataHolder(String[] paramArrayOfString, CursorWindow[] paramArrayOfCursorWindow, int paramInt, Bundle paramBundle) {
    this.kg = 1;
    this.nK = (String[])eg.f(paramArrayOfString);
    this.nM = (CursorWindow[])eg.f(paramArrayOfCursorWindow);
    this.mC = paramInt;
    this.nN = paramBundle;
    validateContents();
  }
  
  private static CursorWindow[] a(AbstractWindowedCursor paramAbstractWindowedCursor) {
    ArrayList<CursorWindow> arrayList = new ArrayList();
    try {
      int i;
      int j = paramAbstractWindowedCursor.getCount();
      CursorWindow cursorWindow = paramAbstractWindowedCursor.getWindow();
      if (cursorWindow != null && cursorWindow.getStartPosition() == 0) {
        cursorWindow.acquireReference();
        paramAbstractWindowedCursor.setWindow(null);
        arrayList.add(cursorWindow);
        i = cursorWindow.getNumRows();
      } else {
        i = 0;
      } 
      while (true) {
        if (i < j && paramAbstractWindowedCursor.moveToPosition(i)) {
          cursorWindow = paramAbstractWindowedCursor.getWindow();
          if (cursorWindow != null) {
            cursorWindow.acquireReference();
            paramAbstractWindowedCursor.setWindow(null);
          } else {
            cursorWindow = new CursorWindow(false);
            cursorWindow.setStartPosition(i);
            paramAbstractWindowedCursor.fillWindow(i, cursorWindow);
          } 
          i = cursorWindow.getNumRows();
          if (i != 0) {
            arrayList.add(cursorWindow);
            i = cursorWindow.getStartPosition();
            int k = cursorWindow.getNumRows();
            i = k + i;
            continue;
          } 
        } 
        return arrayList.<CursorWindow>toArray(new CursorWindow[arrayList.size()]);
      } 
    } finally {
      paramAbstractWindowedCursor.close();
    } 
  }
  
  private static CursorWindow[] a(Builder paramBuilder, int paramInt) {
    List<Map> list;
    boolean bool = false;
    if ((Builder.a(paramBuilder)).length == 0)
      return new CursorWindow[0]; 
    if (paramInt < 0 || paramInt >= Builder.b(paramBuilder).size()) {
      list = Builder.b(paramBuilder);
    } else {
      list = Builder.b(paramBuilder).subList(0, paramInt);
    } 
    int j = list.size();
    CursorWindow cursorWindow = new CursorWindow(false);
    ArrayList<CursorWindow> arrayList = new ArrayList();
    arrayList.add(cursorWindow);
    cursorWindow.setNumColumns((Builder.a(paramBuilder)).length);
    paramInt = 0;
    int i = 0;
    label62: while (true) {
      if (paramInt < j) {
        try {
          if (!cursorWindow.allocRow()) {
            Log.d("DataHolder", "Allocating additional cursor window for large data set (row " + paramInt + ")");
            cursorWindow = new CursorWindow(false);
            cursorWindow.setStartPosition(paramInt);
            cursorWindow.setNumColumns((Builder.a(paramBuilder)).length);
            arrayList.add(cursorWindow);
            if (!cursorWindow.allocRow()) {
              Log.e("DataHolder", "Unable to allocate row to hold data.");
              arrayList.remove(cursorWindow);
              return arrayList.<CursorWindow>toArray(new CursorWindow[arrayList.size()]);
            } 
            i = 0;
          } 
          Map map = list.get(paramInt);
          boolean bool1 = true;
          for (int k = 0;; k++) {
            if (k < (Builder.a(paramBuilder)).length && bool1) {
              String str = Builder.a(paramBuilder)[k];
              Object object = map.get(str);
              if (object == null) {
                bool1 = cursorWindow.putNull(i, k);
              } else if (object instanceof String) {
                bool1 = cursorWindow.putString((String)object, i, k);
              } else if (object instanceof Long) {
                bool1 = cursorWindow.putLong(((Long)object).longValue(), i, k);
              } else if (object instanceof Integer) {
                bool1 = cursorWindow.putLong(((Integer)object).intValue(), i, k);
              } else if (object instanceof Boolean) {
                long l;
                if (((Boolean)object).booleanValue()) {
                  l = 1L;
                } else {
                  l = 0L;
                } 
                bool1 = cursorWindow.putLong(l, i, k);
              } else if (object instanceof byte[]) {
                bool1 = cursorWindow.putBlob((byte[])object, i, k);
              } else {
                throw new IllegalArgumentException("Unsupported object for column " + str + ": " + object);
              } 
            } else {
              if (!bool1) {
                Log.d("DataHolder", "Couldn't populate window data for row " + paramInt + " - allocating new window.");
                cursorWindow.freeLastRow();
                cursorWindow = new CursorWindow(false);
                cursorWindow.setNumColumns((Builder.a(paramBuilder)).length);
                arrayList.add(cursorWindow);
                i = paramInt - 1;
                paramInt = 0;
              } else {
                k = i + 1;
                i = paramInt;
                paramInt = k;
              } 
              k = i + 1;
              i = paramInt;
              paramInt = k;
              continue label62;
            } 
          } 
        } catch (RuntimeException runtimeException) {
          i = arrayList.size();
          for (paramInt = bool; paramInt < i; paramInt++)
            ((CursorWindow)arrayList.get(paramInt)).close(); 
          throw runtimeException;
        } 
        break;
      } 
      return arrayList.<CursorWindow>toArray(new CursorWindow[arrayList.size()]);
    } 
  }
  
  private void b(String paramString, int paramInt) {
    if (this.nL == null || !this.nL.containsKey(paramString))
      throw new IllegalArgumentException("No such column: " + paramString); 
    if (isClosed())
      throw new IllegalArgumentException("Buffer is closed."); 
    if (paramInt < 0 || paramInt >= this.nP)
      throw new CursorIndexOutOfBoundsException(paramInt, this.nP); 
  }
  
  public static Builder builder(String[] paramArrayOfString) {
    return new Builder(paramArrayOfString, null);
  }
  
  public static Builder builder(String[] paramArrayOfString, String paramString) {
    eg.f(paramString);
    return new Builder(paramArrayOfString, paramString);
  }
  
  public static DataHolder empty(int paramInt) {
    return empty(paramInt, null);
  }
  
  public static DataHolder empty(int paramInt, Bundle paramBundle) {
    return new DataHolder(nS, paramInt, paramBundle);
  }
  
  public int C(int paramInt) {
    boolean bool;
    int i = 0;
    if (paramInt >= 0 && paramInt < this.nP) {
      bool = true;
    } else {
      bool = false;
    } 
    eg.p(bool);
    while (true) {
      int j = i;
      if (i < this.nO.length)
        if (paramInt < this.nO[i]) {
          j = i - 1;
        } else {
          i++;
          continue;
        }  
      paramInt = j;
      if (j == this.nO.length)
        paramInt = j - 1; 
      return paramInt;
    } 
  }
  
  String[] bv() {
    return this.nK;
  }
  
  CursorWindow[] bw() {
    return this.nM;
  }
  
  public void c(Object paramObject) {
    this.nQ = paramObject;
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mClosed : Z
    //   6: ifne -> 41
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield mClosed : Z
    //   14: iconst_0
    //   15: istore_1
    //   16: iload_1
    //   17: aload_0
    //   18: getfield nM : [Landroid/database/CursorWindow;
    //   21: arraylength
    //   22: if_icmpge -> 41
    //   25: aload_0
    //   26: getfield nM : [Landroid/database/CursorWindow;
    //   29: iload_1
    //   30: aaload
    //   31: invokevirtual close : ()V
    //   34: iload_1
    //   35: iconst_1
    //   36: iadd
    //   37: istore_1
    //   38: goto -> 16
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_2
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_2
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	44	finally
    //   16	34	44	finally
    //   41	43	44	finally
    //   45	47	44	finally
  }
  
  public void copyToBuffer(String paramString, int paramInt1, int paramInt2, CharArrayBuffer paramCharArrayBuffer) {
    b(paramString, paramInt1);
    this.nM[paramInt2].copyStringToBuffer(paramInt1, this.nL.getInt(paramString), paramCharArrayBuffer);
  }
  
  public int describeContents() {
    return 0;
  }
  
  protected void finalize() throws Throwable {
    try {
      if (this.nR && this.nM.length > 0 && !isClosed()) {
        String str;
        if (this.nQ == null) {
          str = "internal object: " + toString();
        } else {
          str = this.nQ.toString();
        } 
        Log.e("DataBuffer", "Internal data leak within a DataBuffer object detected!  Be sure to explicitly call close() on all DataBuffer extending objects when you are done with them. (" + str + ")");
        close();
      } 
      return;
    } finally {
      super.finalize();
    } 
  }
  
  public boolean getBoolean(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return (Long.valueOf(this.nM[paramInt2].getLong(paramInt1, this.nL.getInt(paramString))).longValue() == 1L);
  }
  
  public byte[] getByteArray(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return this.nM[paramInt2].getBlob(paramInt1, this.nL.getInt(paramString));
  }
  
  public int getCount() {
    return this.nP;
  }
  
  public int getInteger(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return this.nM[paramInt2].getInt(paramInt1, this.nL.getInt(paramString));
  }
  
  public long getLong(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return this.nM[paramInt2].getLong(paramInt1, this.nL.getInt(paramString));
  }
  
  public Bundle getMetadata() {
    return this.nN;
  }
  
  public int getStatusCode() {
    return this.mC;
  }
  
  public String getString(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return this.nM[paramInt2].getString(paramInt1, this.nL.getInt(paramString));
  }
  
  int getVersionCode() {
    return this.kg;
  }
  
  public boolean hasColumn(String paramString) {
    return this.nL.containsKey(paramString);
  }
  
  public boolean hasNull(String paramString, int paramInt1, int paramInt2) {
    b(paramString, paramInt1);
    return this.nM[paramInt2].isNull(paramInt1, this.nL.getInt(paramString));
  }
  
  public boolean isClosed() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mClosed : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	11	finally
    //   12	14	11	finally
  }
  
  public Uri parseUri(String paramString, int paramInt1, int paramInt2) {
    paramString = getString(paramString, paramInt1, paramInt2);
    return (paramString == null) ? null : Uri.parse(paramString);
  }
  
  public void validateContents() {
    int j = 0;
    this.nL = new Bundle();
    int i;
    for (i = 0; i < this.nK.length; i++)
      this.nL.putInt(this.nK[i], i); 
    this.nO = new int[this.nM.length];
    int k = 0;
    i = j;
    j = k;
    while (i < this.nM.length) {
      this.nO[i] = j;
      k = this.nM[i].getStartPosition();
      j += this.nM[i].getNumRows() - j - k;
      i++;
    } 
    this.nP = j;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    DataHolderCreator.a(this, paramParcel, paramInt);
  }
  
  public static class Builder {
    private final String[] nK;
    
    private final ArrayList<HashMap<String, Object>> nT;
    
    private final String nU;
    
    private final HashMap<Object, Integer> nV;
    
    private boolean nW;
    
    private String nX;
    
    private Builder(String[] param1ArrayOfString, String param1String) {
      this.nK = (String[])eg.f(param1ArrayOfString);
      this.nT = new ArrayList<HashMap<String, Object>>();
      this.nU = param1String;
      this.nV = new HashMap<Object, Integer>();
      this.nW = false;
      this.nX = null;
    }
    
    private void a(HashMap<String, Object> param1HashMap) {
      param1HashMap = (HashMap<String, Object>)param1HashMap.get(this.nU);
      if (param1HashMap == null)
        return; 
      Integer integer = this.nV.remove(param1HashMap);
      if (integer != null)
        this.nT.remove(integer.intValue()); 
      this.nV.put(param1HashMap, Integer.valueOf(this.nT.size()));
    }
    
    private void bx() {
      if (this.nU != null) {
        this.nV.clear();
        int j = this.nT.size();
        for (int i = 0; i < j; i++) {
          Object object = ((HashMap)this.nT.get(i)).get(this.nU);
          if (object != null)
            this.nV.put(object, Integer.valueOf(i)); 
        } 
      } 
    }
    
    public DataHolder build(int param1Int) {
      return new DataHolder(this, param1Int, null);
    }
    
    public DataHolder build(int param1Int, Bundle param1Bundle) {
      return new DataHolder(this, param1Int, param1Bundle, -1);
    }
    
    public DataHolder build(int param1Int1, Bundle param1Bundle, int param1Int2) {
      return new DataHolder(this, param1Int1, param1Bundle, param1Int2);
    }
    
    public int getCount() {
      return this.nT.size();
    }
    
    public Builder removeRowsWithValue(String param1String, Object param1Object) {
      for (int i = this.nT.size() - 1; i >= 0; i--) {
        if (ee.equal(((HashMap)this.nT.get(i)).get(param1String), param1Object))
          this.nT.remove(i); 
      } 
      return this;
    }
    
    public Builder sort(String param1String) {
      ds.d(param1String);
      if (this.nW && param1String.equals(this.nX))
        return this; 
      Collections.sort(this.nT, new DataHolder.a(param1String));
      bx();
      this.nW = true;
      this.nX = param1String;
      return this;
    }
    
    public Builder withRow(ContentValues param1ContentValues) {
      ds.d(param1ContentValues);
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>(param1ContentValues.size());
      for (Map.Entry entry : param1ContentValues.valueSet())
        hashMap.put(entry.getKey(), entry.getValue()); 
      return withRow((HashMap)hashMap);
    }
    
    public Builder withRow(HashMap<String, Object> param1HashMap) {
      ds.d(param1HashMap);
      if (this.nU != null)
        a(param1HashMap); 
      this.nT.add(param1HashMap);
      this.nW = false;
      return this;
    }
  }
  
  private static final class a implements Comparator<HashMap<String, Object>> {
    private final String nY;
    
    a(String param1String) {
      this.nY = (String)eg.f(param1String);
    }
    
    public int a(HashMap<String, Object> param1HashMap1, HashMap<String, Object> param1HashMap2) {
      Object object1 = eg.f(param1HashMap1.get(this.nY));
      Object object2 = eg.f(param1HashMap2.get(this.nY));
      if (object1.equals(object2))
        return 0; 
      if (object1 instanceof Boolean)
        return ((Boolean)object1).compareTo((Boolean)object2); 
      if (object1 instanceof Long)
        return ((Long)object1).compareTo((Long)object2); 
      if (object1 instanceof Integer)
        return ((Integer)object1).compareTo((Integer)object2); 
      if (object1 instanceof String)
        return ((String)object1).compareTo((String)object2); 
      throw new IllegalArgumentException("Unknown type for lValue " + object1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\data\DataHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */