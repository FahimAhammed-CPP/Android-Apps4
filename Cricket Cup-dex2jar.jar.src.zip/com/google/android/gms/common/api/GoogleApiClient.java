package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.dx;
import com.google.android.gms.internal.eg;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public final class GoogleApiClient {
  private final Object mV = new Object();
  
  private final a nc = new a(this) {
      public void b(GoogleApiClient.b param1b) {
        synchronized (GoogleApiClient.c(this.nq)) {
          this.nq.nn.remove(param1b);
          return;
        } 
      }
    };
  
  private final dx ne;
  
  final Queue<b<?>> nf = new LinkedList<b<?>>();
  
  private ConnectionResult ng;
  
  private int nh;
  
  private int ni = 4;
  
  private int nj;
  
  private final Bundle nk = new Bundle();
  
  private final Map<Api.b<?>, Api.a> nl = new HashMap<Api.b<?>, Api.a>();
  
  private boolean nm;
  
  final Set<b> nn = new HashSet<b>();
  
  final ConnectionCallbacks no = new ConnectionCallbacks(this) {
      public void onConnected(Bundle param1Bundle) {
        synchronized (GoogleApiClient.c(this.nq)) {
          if (GoogleApiClient.d(this.nq) == 1) {
            if (param1Bundle != null)
              GoogleApiClient.e(this.nq).putAll(param1Bundle); 
            GoogleApiClient.f(this.nq);
          } 
          return;
        } 
      }
      
      public void onConnectionSuspended(int param1Int) {
        synchronized (GoogleApiClient.c(this.nq)) {
          GoogleApiClient.a(this.nq, param1Int);
          if (param1Int == 2)
            this.nq.connect(); 
          return;
        } 
      }
    };
  
  private final dx.b np = new dx.b(this) {
      public Bundle aU() {
        return null;
      }
      
      public boolean bp() {
        return GoogleApiClient.g(this.nq);
      }
      
      public boolean isConnected() {
        return this.nq.isConnected();
      }
    };
  
  private GoogleApiClient(Context paramContext, dt paramdt, Map<Api, ApiOptions> paramMap, Set<ConnectionCallbacks> paramSet, Set<OnConnectionFailedListener> paramSet1) {
    this.ne = new dx(paramContext, this.np);
    for (ConnectionCallbacks connectionCallbacks : paramSet)
      this.ne.registerConnectionCallbacks(connectionCallbacks); 
    for (OnConnectionFailedListener onConnectionFailedListener : paramSet1)
      this.ne.registerConnectionFailedListener(onConnectionFailedListener); 
    for (Api api : paramMap.keySet()) {
      Api.b<?> b1 = api.bj();
      ApiOptions apiOptions = paramMap.get(api);
      this.nl.put(b1, (Api.a)b1.b(paramContext, paramdt, apiOptions, this.no, new OnConnectionFailedListener(this, b1) {
              public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
                synchronized (GoogleApiClient.c(this.nq)) {
                  if (GoogleApiClient.h(this.nq) == null || this.nr.getPriority() < GoogleApiClient.i(this.nq)) {
                    GoogleApiClient.a(this.nq, param1ConnectionResult);
                    GoogleApiClient.b(this.nq, this.nr.getPriority());
                  } 
                  GoogleApiClient.f(this.nq);
                  return;
                } 
              }
            }));
    } 
  }
  
  private void A(int paramInt) {
    synchronized (this.mV) {
      if (this.ni != 3) {
        boolean bool = isConnected();
        this.ni = 3;
        if (paramInt == -1)
          this.nf.clear(); 
        for (b b1 : this.nn) {
          boolean bool1 = b1 instanceof Releasable;
          if (bool1)
            try {
              ((Releasable)b1).release();
            } catch (Exception exception) {
              Log.w("GoogleApiClient", "Unable to release " + b1, exception);
            }  
        } 
        this.nn.clear();
        this.nm = false;
        for (Api.a a1 : this.nl.values()) {
          if (a1.isConnected())
            a1.disconnect(); 
        } 
        this.nm = true;
        this.ni = 4;
        if (bool) {
          if (paramInt != -1)
            this.ne.J(paramInt); 
          this.nm = false;
        } 
      } 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_4} */
  }
  
  private <A extends Api.a> void a(b<A> paramb) {
    synchronized (this.mV) {
      boolean bool;
      eg.a(isConnected(), "GoogleApiClient is not connected yet.");
      if (paramb.bj() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      eg.a(bool, "This task can not be executed or enqueued (it's probably a Batch or malformed)");
      if (paramb instanceof Releasable) {
        this.nn.add(paramb);
        paramb.a(this.nc);
      } 
      paramb.b(a(paramb.bj()));
      return;
    } 
  }
  
  private void bn() {
    synchronized (this.mV) {
      this.nj--;
      if (this.nj == 0)
        if (this.ng != null) {
          A(3);
          this.ne.a(this.ng);
          this.nm = false;
        } else {
          Bundle bundle;
          this.ni = 2;
          bo();
          if (this.nk.isEmpty()) {
            bundle = null;
          } else {
            bundle = this.nk;
          } 
          this.ne.b(bundle);
        }  
      return;
    } 
  }
  
  private void bo() {
    eg.a(isConnected(), "GoogleApiClient is not connected yet.");
    synchronized (this.mV) {
      while (!this.nf.isEmpty())
        a((b<Api.a>)this.nf.remove()); 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
  }
  
  public <C extends Api.a> C a(Api.b<C> paramb) {
    Api.a a1 = this.nl.get(paramb);
    eg.b(a1, "Appropriate Api was not requested.");
    return (C)a1;
  }
  
  public <A extends Api.a, T extends a.a<? extends Result, A>> T a(T paramT) {
    synchronized (this.mV) {
      if (isConnected()) {
        b(paramT);
        return paramT;
      } 
      this.nf.add((b<?>)paramT);
      return paramT;
    } 
  }
  
  public <A extends Api.a, T extends a.a<? extends Result, A>> T b(T paramT) {
    eg.a(isConnected(), "GoogleApiClient is not connected yet.");
    bo();
    a((b<Api.a>)paramT);
    return paramT;
  }
  
  public void connect() {
    synchronized (this.mV) {
      if (isConnected() || isConnecting())
        return; 
      this.nm = true;
      this.ng = null;
      this.ni = 1;
      this.nk.clear();
      this.nj = this.nl.size();
      Iterator<Api.a> iterator = this.nl.values().iterator();
      while (iterator.hasNext())
        ((Api.a)iterator.next()).connect(); 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
  }
  
  public void disconnect() {
    A(-1);
  }
  
  public boolean isConnected() {
    synchronized (this.mV) {
      if (this.ni == 2)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public boolean isConnecting() {
    boolean bool = true;
    synchronized (this.mV) {
      if (this.ni != 1)
        bool = false; 
      return bool;
    } 
  }
  
  public boolean isConnectionCallbacksRegistered(ConnectionCallbacks paramConnectionCallbacks) {
    return this.ne.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener paramOnConnectionFailedListener) {
    return this.ne.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  public void reconnect() {
    disconnect();
    connect();
  }
  
  public void registerConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks) {
    this.ne.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.ne.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void unregisterConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks) {
    this.ne.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void unregisterConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.ne.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public static interface ApiOptions {}
  
  public static final class Builder {
    private String jG;
    
    private final Context mContext;
    
    private final Set<String> ns = new HashSet<String>();
    
    private int nt;
    
    private View nu;
    
    private String nv;
    
    private final Map<Api, GoogleApiClient.ApiOptions> nw = new HashMap<Api, GoogleApiClient.ApiOptions>();
    
    private final Set<GoogleApiClient.ConnectionCallbacks> nx = new HashSet<GoogleApiClient.ConnectionCallbacks>();
    
    private final Set<GoogleApiClient.OnConnectionFailedListener> ny = new HashSet<GoogleApiClient.OnConnectionFailedListener>();
    
    public Builder(Context param1Context) {
      this.mContext = param1Context;
      this.nv = param1Context.getPackageName();
    }
    
    public Builder(Context param1Context, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this(param1Context);
      eg.b(param1ConnectionCallbacks, "Must provide a connected listener");
      this.nx.add(param1ConnectionCallbacks);
      eg.b(param1OnConnectionFailedListener, "Must provide a connection failed listener");
      this.ny.add(param1OnConnectionFailedListener);
    }
    
    public Builder addApi(Api param1Api) {
      return addApi(param1Api, null);
    }
    
    public Builder addApi(Api param1Api, GoogleApiClient.ApiOptions param1ApiOptions) {
      this.nw.put(param1Api, param1ApiOptions);
      List<Scope> list = param1Api.bk();
      int j = list.size();
      for (int i = 0; i < j; i++)
        this.ns.add(((Scope)list.get(i)).br()); 
      return this;
    }
    
    public Builder addConnectionCallbacks(GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks) {
      this.nx.add(param1ConnectionCallbacks);
      return this;
    }
    
    public Builder addOnConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this.ny.add(param1OnConnectionFailedListener);
      return this;
    }
    
    public Builder addScope(Scope param1Scope) {
      this.ns.add(param1Scope.br());
      return this;
    }
    
    public dt bq() {
      return new dt(this.jG, this.ns, this.nt, this.nu, this.nv);
    }
    
    public GoogleApiClient build() {
      return new GoogleApiClient(this.mContext, bq(), this.nw, this.nx, this.ny);
    }
    
    public Builder setAccountName(String param1String) {
      this.jG = param1String;
      return this;
    }
    
    public Builder setGravityForPopups(int param1Int) {
      this.nt = param1Int;
      return this;
    }
    
    public Builder setViewForPopups(View param1View) {
      this.nu = param1View;
      return this;
    }
    
    public Builder useDefaultAccount() {
      return setAccountName("<<default account>>");
    }
  }
  
  public static interface ConnectionCallbacks {
    public static final int CAUSE_NETWORK_LOST = 2;
    
    public static final int CAUSE_SERVICE_DISCONNECTED = 1;
    
    void onConnected(Bundle param1Bundle);
    
    void onConnectionSuspended(int param1Int);
  }
  
  public static interface OnConnectionFailedListener extends GooglePlayServicesClient.OnConnectionFailedListener {}
  
  public static interface a {
    void b(GoogleApiClient.b param1b);
  }
  
  public static interface b<A extends Api.a> {
    void a(GoogleApiClient.a param1a);
    
    void b(A param1A);
    
    Api.b<A> bj();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\GoogleApiClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */