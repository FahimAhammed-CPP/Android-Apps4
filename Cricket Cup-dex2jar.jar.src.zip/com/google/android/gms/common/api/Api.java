package com.google.android.gms.common.api;

import android.content.Context;
import com.google.android.gms.internal.dt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Api {
  private final b<?> mS;
  
  private final ArrayList<Scope> mT;
  
  public Api(b<?> paramb, Scope... paramVarArgs) {
    this.mS = paramb;
    this.mT = new ArrayList<Scope>(Arrays.asList(paramVarArgs));
  }
  
  public b<?> bj() {
    return this.mS;
  }
  
  public List<Scope> bk() {
    return this.mT;
  }
  
  public static interface a {
    void connect();
    
    void disconnect();
    
    boolean isConnected();
  }
  
  public static interface b<T extends a> {
    T b(Context param1Context, dt param1dt, GoogleApiClient.ApiOptions param1ApiOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener);
    
    int getPriority();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\Api.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */