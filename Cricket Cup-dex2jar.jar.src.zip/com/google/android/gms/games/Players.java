package com.google.android.gms.games;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;

public interface Players {
  public static final String EXTRA_PLAYER_SEARCH_RESULTS = "player_search_results";
  
  Player getCurrentPlayer(GoogleApiClient paramGoogleApiClient);
  
  String getCurrentPlayerId(GoogleApiClient paramGoogleApiClient);
  
  Intent getPlayerSearchIntent(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<LoadPlayersResult> loadInvitablePlayers(GoogleApiClient paramGoogleApiClient, int paramInt, boolean paramBoolean);
  
  PendingResult<LoadPlayersResult> loadMoreInvitablePlayers(GoogleApiClient paramGoogleApiClient, int paramInt);
  
  PendingResult<LoadPlayersResult> loadMoreRecentlyPlayedWithPlayers(GoogleApiClient paramGoogleApiClient, int paramInt);
  
  PendingResult<LoadPlayersResult> loadPlayer(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<LoadPlayersResult> loadRecentlyPlayedWithPlayers(GoogleApiClient paramGoogleApiClient, int paramInt, boolean paramBoolean);
  
  public static interface LoadPlayersResult extends Releasable, Result {
    PlayerBuffer getPlayers();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\Players.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */