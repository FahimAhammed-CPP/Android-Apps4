package com.google.android.gms.games.leaderboard;

import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.gc;
import com.google.android.gms.internal.ge;

public final class f implements LeaderboardVariant {
  private final int vV;
  
  private final int vW;
  
  private final boolean vX;
  
  private final long vY;
  
  private final String vZ;
  
  private final long wa;
  
  private final String wb;
  
  private final String wc;
  
  private final long wd;
  
  private final String we;
  
  private final String wf;
  
  private final String wg;
  
  public f(LeaderboardVariant paramLeaderboardVariant) {
    this.vV = paramLeaderboardVariant.getTimeSpan();
    this.vW = paramLeaderboardVariant.getCollection();
    this.vX = paramLeaderboardVariant.hasPlayerInfo();
    this.vY = paramLeaderboardVariant.getRawPlayerScore();
    this.vZ = paramLeaderboardVariant.getDisplayPlayerScore();
    this.wa = paramLeaderboardVariant.getPlayerRank();
    this.wb = paramLeaderboardVariant.getDisplayPlayerRank();
    this.wc = paramLeaderboardVariant.getPlayerScoreTag();
    this.wd = paramLeaderboardVariant.getNumScores();
    this.we = paramLeaderboardVariant.dt();
    this.wf = paramLeaderboardVariant.du();
    this.wg = paramLeaderboardVariant.dv();
  }
  
  static int a(LeaderboardVariant paramLeaderboardVariant) {
    return ee.hashCode(new Object[] { 
          Integer.valueOf(paramLeaderboardVariant.getTimeSpan()), Integer.valueOf(paramLeaderboardVariant.getCollection()), Boolean.valueOf(paramLeaderboardVariant.hasPlayerInfo()), Long.valueOf(paramLeaderboardVariant.getRawPlayerScore()), paramLeaderboardVariant.getDisplayPlayerScore(), Long.valueOf(paramLeaderboardVariant.getPlayerRank()), paramLeaderboardVariant.getDisplayPlayerRank(), Long.valueOf(paramLeaderboardVariant.getNumScores()), paramLeaderboardVariant.dt(), paramLeaderboardVariant.dv(), 
          paramLeaderboardVariant.du() });
  }
  
  static boolean a(LeaderboardVariant paramLeaderboardVariant, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof LeaderboardVariant))
      return false; 
    boolean bool1 = bool2;
    if (paramLeaderboardVariant != paramObject) {
      paramObject = paramObject;
      if (ee.equal(Integer.valueOf(paramObject.getTimeSpan()), Integer.valueOf(paramLeaderboardVariant.getTimeSpan())) && ee.equal(Integer.valueOf(paramObject.getCollection()), Integer.valueOf(paramLeaderboardVariant.getCollection())) && ee.equal(Boolean.valueOf(paramObject.hasPlayerInfo()), Boolean.valueOf(paramLeaderboardVariant.hasPlayerInfo())) && ee.equal(Long.valueOf(paramObject.getRawPlayerScore()), Long.valueOf(paramLeaderboardVariant.getRawPlayerScore())) && ee.equal(paramObject.getDisplayPlayerScore(), paramLeaderboardVariant.getDisplayPlayerScore()) && ee.equal(Long.valueOf(paramObject.getPlayerRank()), Long.valueOf(paramLeaderboardVariant.getPlayerRank())) && ee.equal(paramObject.getDisplayPlayerRank(), paramLeaderboardVariant.getDisplayPlayerRank()) && ee.equal(Long.valueOf(paramObject.getNumScores()), Long.valueOf(paramLeaderboardVariant.getNumScores())) && ee.equal(paramObject.dt(), paramLeaderboardVariant.dt()) && ee.equal(paramObject.dv(), paramLeaderboardVariant.dv())) {
        bool1 = bool2;
        return !ee.equal(paramObject.du(), paramLeaderboardVariant.du()) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(LeaderboardVariant paramLeaderboardVariant) {
    ee.a a = ee.e(paramLeaderboardVariant).a("TimeSpan", ge.aG(paramLeaderboardVariant.getTimeSpan())).a("Collection", gc.aG(paramLeaderboardVariant.getCollection()));
    if (paramLeaderboardVariant.hasPlayerInfo()) {
      Long long_ = Long.valueOf(paramLeaderboardVariant.getRawPlayerScore());
    } else {
      str = "none";
    } 
    a = a.a("RawPlayerScore", str);
    if (paramLeaderboardVariant.hasPlayerInfo()) {
      str = paramLeaderboardVariant.getDisplayPlayerScore();
    } else {
      str = "none";
    } 
    a = a.a("DisplayPlayerScore", str);
    if (paramLeaderboardVariant.hasPlayerInfo()) {
      Long long_ = Long.valueOf(paramLeaderboardVariant.getPlayerRank());
    } else {
      str = "none";
    } 
    a = a.a("PlayerRank", str);
    if (paramLeaderboardVariant.hasPlayerInfo()) {
      str = paramLeaderboardVariant.getDisplayPlayerRank();
      return a.a("DisplayPlayerRank", str).a("NumScores", Long.valueOf(paramLeaderboardVariant.getNumScores())).a("TopPageNextToken", paramLeaderboardVariant.dt()).a("WindowPageNextToken", paramLeaderboardVariant.dv()).a("WindowPagePrevToken", paramLeaderboardVariant.du()).toString();
    } 
    String str = "none";
    return a.a("DisplayPlayerRank", str).a("NumScores", Long.valueOf(paramLeaderboardVariant.getNumScores())).a("TopPageNextToken", paramLeaderboardVariant.dt()).a("WindowPageNextToken", paramLeaderboardVariant.dv()).a("WindowPagePrevToken", paramLeaderboardVariant.du()).toString();
  }
  
  public String dt() {
    return this.we;
  }
  
  public String du() {
    return this.wf;
  }
  
  public String dv() {
    return this.wg;
  }
  
  public LeaderboardVariant dw() {
    return this;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public int getCollection() {
    return this.vW;
  }
  
  public String getDisplayPlayerRank() {
    return this.wb;
  }
  
  public String getDisplayPlayerScore() {
    return this.vZ;
  }
  
  public long getNumScores() {
    return this.wd;
  }
  
  public long getPlayerRank() {
    return this.wa;
  }
  
  public String getPlayerScoreTag() {
    return this.wc;
  }
  
  public long getRawPlayerScore() {
    return this.vY;
  }
  
  public int getTimeSpan() {
    return this.vV;
  }
  
  public boolean hasPlayerInfo() {
    return this.vX;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */