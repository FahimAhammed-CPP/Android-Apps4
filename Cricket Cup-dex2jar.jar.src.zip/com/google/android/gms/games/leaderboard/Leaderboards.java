package com.google.android.gms.games.leaderboard;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;

public interface Leaderboards {
  Intent getAllLeaderboardsIntent(GoogleApiClient paramGoogleApiClient);
  
  Intent getLeaderboardIntent(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<LoadPlayerScoreResult> loadCurrentPlayerLeaderboardScore(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt1, int paramInt2);
  
  PendingResult<LeaderboardMetadataResult> loadLeaderboardMetadata(GoogleApiClient paramGoogleApiClient, String paramString, boolean paramBoolean);
  
  PendingResult<LeaderboardMetadataResult> loadLeaderboardMetadata(GoogleApiClient paramGoogleApiClient, boolean paramBoolean);
  
  PendingResult<LoadScoresResult> loadMoreScores(GoogleApiClient paramGoogleApiClient, LeaderboardScoreBuffer paramLeaderboardScoreBuffer, int paramInt1, int paramInt2);
  
  PendingResult<LoadScoresResult> loadPlayerCenteredScores(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  PendingResult<LoadScoresResult> loadPlayerCenteredScores(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  PendingResult<LoadScoresResult> loadTopScores(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  PendingResult<LoadScoresResult> loadTopScores(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  void submitScore(GoogleApiClient paramGoogleApiClient, String paramString, long paramLong);
  
  void submitScore(GoogleApiClient paramGoogleApiClient, String paramString1, long paramLong, String paramString2);
  
  PendingResult<SubmitScoreResult> submitScoreImmediate(GoogleApiClient paramGoogleApiClient, String paramString, long paramLong);
  
  PendingResult<SubmitScoreResult> submitScoreImmediate(GoogleApiClient paramGoogleApiClient, String paramString1, long paramLong, String paramString2);
  
  public static interface LeaderboardMetadataResult extends Releasable, Result {
    LeaderboardBuffer getLeaderboards();
  }
  
  public static interface LoadPlayerScoreResult extends Result {
    LeaderboardScore getScore();
  }
  
  public static interface LoadScoresResult extends Releasable, Result {
    Leaderboard getLeaderboard();
    
    LeaderboardScoreBuffer getScores();
  }
  
  public static interface SubmitScoreResult extends Releasable, Result {
    ScoreSubmissionData getScoreData();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\Leaderboards.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */