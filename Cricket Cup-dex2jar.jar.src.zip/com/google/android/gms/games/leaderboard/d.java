package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.fc;

public final class d implements LeaderboardScore {
  private final long vK;
  
  private final String vL;
  
  private final String vM;
  
  private final long vN;
  
  private final long vO;
  
  private final String vP;
  
  private final Uri vQ;
  
  private final Uri vR;
  
  private final PlayerEntity vS;
  
  private final String vT;
  
  public d(LeaderboardScore paramLeaderboardScore) {
    PlayerEntity playerEntity;
    this.vK = paramLeaderboardScore.getRank();
    this.vL = (String)eg.f(paramLeaderboardScore.getDisplayRank());
    this.vM = (String)eg.f(paramLeaderboardScore.getDisplayScore());
    this.vN = paramLeaderboardScore.getRawScore();
    this.vO = paramLeaderboardScore.getTimestampMillis();
    this.vP = paramLeaderboardScore.getScoreHolderDisplayName();
    this.vQ = paramLeaderboardScore.getScoreHolderIconImageUri();
    this.vR = paramLeaderboardScore.getScoreHolderHiResImageUri();
    Player player = paramLeaderboardScore.getScoreHolder();
    if (player == null) {
      player = null;
    } else {
      playerEntity = (PlayerEntity)player.freeze();
    } 
    this.vS = playerEntity;
    this.vT = paramLeaderboardScore.getScoreTag();
  }
  
  static int a(LeaderboardScore paramLeaderboardScore) {
    return ee.hashCode(new Object[] { Long.valueOf(paramLeaderboardScore.getRank()), paramLeaderboardScore.getDisplayRank(), Long.valueOf(paramLeaderboardScore.getRawScore()), paramLeaderboardScore.getDisplayScore(), Long.valueOf(paramLeaderboardScore.getTimestampMillis()), paramLeaderboardScore.getScoreHolderDisplayName(), paramLeaderboardScore.getScoreHolderIconImageUri(), paramLeaderboardScore.getScoreHolderHiResImageUri(), paramLeaderboardScore.getScoreHolder() });
  }
  
  static boolean a(LeaderboardScore paramLeaderboardScore, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof LeaderboardScore))
      return false; 
    boolean bool1 = bool2;
    if (paramLeaderboardScore != paramObject) {
      paramObject = paramObject;
      if (ee.equal(Long.valueOf(paramObject.getRank()), Long.valueOf(paramLeaderboardScore.getRank())) && ee.equal(paramObject.getDisplayRank(), paramLeaderboardScore.getDisplayRank()) && ee.equal(Long.valueOf(paramObject.getRawScore()), Long.valueOf(paramLeaderboardScore.getRawScore())) && ee.equal(paramObject.getDisplayScore(), paramLeaderboardScore.getDisplayScore()) && ee.equal(Long.valueOf(paramObject.getTimestampMillis()), Long.valueOf(paramLeaderboardScore.getTimestampMillis())) && ee.equal(paramObject.getScoreHolderDisplayName(), paramLeaderboardScore.getScoreHolderDisplayName()) && ee.equal(paramObject.getScoreHolderIconImageUri(), paramLeaderboardScore.getScoreHolderIconImageUri()) && ee.equal(paramObject.getScoreHolderHiResImageUri(), paramLeaderboardScore.getScoreHolderHiResImageUri()) && ee.equal(paramObject.getScoreHolder(), paramLeaderboardScore.getScoreHolder())) {
        bool1 = bool2;
        return !ee.equal(paramObject.getScoreTag(), paramLeaderboardScore.getScoreTag()) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(LeaderboardScore paramLeaderboardScore) {
    ee.a a = ee.e(paramLeaderboardScore).a("Rank", Long.valueOf(paramLeaderboardScore.getRank())).a("DisplayRank", paramLeaderboardScore.getDisplayRank()).a("Score", Long.valueOf(paramLeaderboardScore.getRawScore())).a("DisplayScore", paramLeaderboardScore.getDisplayScore()).a("Timestamp", Long.valueOf(paramLeaderboardScore.getTimestampMillis())).a("DisplayName", paramLeaderboardScore.getScoreHolderDisplayName()).a("IconImageUri", paramLeaderboardScore.getScoreHolderIconImageUri()).a("HiResImageUri", paramLeaderboardScore.getScoreHolderHiResImageUri());
    if (paramLeaderboardScore.getScoreHolder() == null) {
      Object object = null;
      return a.a("Player", object).a("ScoreTag", paramLeaderboardScore.getScoreTag()).toString();
    } 
    Player player = paramLeaderboardScore.getScoreHolder();
    return a.a("Player", player).a("ScoreTag", paramLeaderboardScore.getScoreTag()).toString();
  }
  
  public LeaderboardScore ds() {
    return this;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public String getDisplayRank() {
    return this.vL;
  }
  
  public void getDisplayRank(CharArrayBuffer paramCharArrayBuffer) {
    fc.b(this.vL, paramCharArrayBuffer);
  }
  
  public String getDisplayScore() {
    return this.vM;
  }
  
  public void getDisplayScore(CharArrayBuffer paramCharArrayBuffer) {
    fc.b(this.vM, paramCharArrayBuffer);
  }
  
  public long getRank() {
    return this.vK;
  }
  
  public long getRawScore() {
    return this.vN;
  }
  
  public Player getScoreHolder() {
    return (Player)this.vS;
  }
  
  public String getScoreHolderDisplayName() {
    return (this.vS == null) ? this.vP : this.vS.getDisplayName();
  }
  
  public void getScoreHolderDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    if (this.vS == null) {
      fc.b(this.vP, paramCharArrayBuffer);
      return;
    } 
    this.vS.getDisplayName(paramCharArrayBuffer);
  }
  
  public Uri getScoreHolderHiResImageUri() {
    return (this.vS == null) ? this.vR : this.vS.getHiResImageUri();
  }
  
  public Uri getScoreHolderIconImageUri() {
    return (this.vS == null) ? this.vQ : this.vS.getIconImageUri();
  }
  
  public String getScoreTag() {
    return this.vT;
  }
  
  public long getTimestampMillis() {
    return this.vO;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */