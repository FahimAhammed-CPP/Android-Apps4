package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.games.Player;

public interface LeaderboardScore extends Freezable<LeaderboardScore> {
  public static final int LEADERBOARD_RANK_UNKNOWN = -1;
  
  String getDisplayRank();
  
  void getDisplayRank(CharArrayBuffer paramCharArrayBuffer);
  
  String getDisplayScore();
  
  void getDisplayScore(CharArrayBuffer paramCharArrayBuffer);
  
  long getRank();
  
  long getRawScore();
  
  Player getScoreHolder();
  
  String getScoreHolderDisplayName();
  
  void getScoreHolderDisplayName(CharArrayBuffer paramCharArrayBuffer);
  
  Uri getScoreHolderHiResImageUri();
  
  Uri getScoreHolderIconImageUri();
  
  String getScoreTag();
  
  long getTimestampMillis();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\LeaderboardScore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */