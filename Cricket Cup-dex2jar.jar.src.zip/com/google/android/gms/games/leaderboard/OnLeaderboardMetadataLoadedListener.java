package com.google.android.gms.games.leaderboard;

@Deprecated
public interface OnLeaderboardMetadataLoadedListener {
  void onLeaderboardMetadataLoaded(int paramInt, LeaderboardBuffer paramLeaderboardBuffer);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\OnLeaderboardMetadataLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */