package com.google.android.gms.games.leaderboard;

import android.os.Bundle;

public final class c {
  private final Bundle vJ;
  
  public c(Bundle paramBundle) {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    this.vJ = bundle;
  }
  
  public Bundle dr() {
    return this.vJ;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */