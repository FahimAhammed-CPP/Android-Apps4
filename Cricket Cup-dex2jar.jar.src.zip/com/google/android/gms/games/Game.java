package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcelable;
import com.google.android.gms.common.data.Freezable;

public interface Game extends Parcelable, Freezable<Game> {
  int getAchievementTotalCount();
  
  String getApplicationId();
  
  String getDescription();
  
  void getDescription(CharArrayBuffer paramCharArrayBuffer);
  
  String getDeveloperName();
  
  void getDeveloperName(CharArrayBuffer paramCharArrayBuffer);
  
  String getDisplayName();
  
  void getDisplayName(CharArrayBuffer paramCharArrayBuffer);
  
  Uri getFeaturedImageUri();
  
  int getGameplayAclStatus();
  
  Uri getHiResImageUri();
  
  Uri getIconImageUri();
  
  String getInstancePackageName();
  
  int getLeaderboardCount();
  
  String getPrimaryCategory();
  
  String getSecondaryCategory();
  
  boolean isInstanceInstalled();
  
  boolean isPlayEnabledGame();
  
  boolean isRealTimeMultiplayerEnabled();
  
  boolean isTurnBasedMultiplayerEnabled();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\Game.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */