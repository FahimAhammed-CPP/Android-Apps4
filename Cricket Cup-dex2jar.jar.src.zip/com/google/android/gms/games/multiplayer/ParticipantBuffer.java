package com.google.android.gms.games.multiplayer;

import com.google.android.gms.common.data.DataBuffer;

public final class ParticipantBuffer extends DataBuffer<Participant> {
  public Participant get(int paramInt) {
    return new d(this.nE, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\ParticipantBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */