package com.google.android.gms.games.multiplayer;

import android.os.Parcel;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.b;
import com.google.android.gms.games.Game;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;

public final class b extends b implements Invitation {
  private final Game vG;
  
  private final ArrayList<Participant> wn;
  
  private final d wq;
  
  b(DataHolder paramDataHolder, int paramInt1, int paramInt2) {
    super(paramDataHolder, paramInt1);
    d d1;
    this.vG = (Game)new com.google.android.gms.games.b(paramDataHolder, paramInt1);
    this.wn = new ArrayList<Participant>(paramInt2);
    String str = getString("external_inviter_id");
    paramInt1 = 0;
    paramDataHolder = null;
    while (paramInt1 < paramInt2) {
      d d2 = new d(this.nE, this.nG + paramInt1);
      if (d2.getParticipantId().equals(str))
        d1 = d2; 
      this.wn.add(d2);
      paramInt1++;
    } 
    this.wq = (d)eg.b(d1, "Must have a valid inviter!");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return InvitationEntity.a(this, paramObject);
  }
  
  public Invitation freeze() {
    return new InvitationEntity(this);
  }
  
  public int getAvailableAutoMatchSlots() {
    return !getBoolean("has_automatch_criteria") ? 0 : getInteger("automatch_max_players");
  }
  
  public long getCreationTimestamp() {
    return Math.max(getLong("creation_timestamp"), getLong("last_modified_timestamp"));
  }
  
  public Game getGame() {
    return this.vG;
  }
  
  public String getInvitationId() {
    return getString("external_invitation_id");
  }
  
  public int getInvitationType() {
    return getInteger("type");
  }
  
  public Participant getInviter() {
    return this.wq;
  }
  
  public ArrayList<Participant> getParticipants() {
    return this.wn;
  }
  
  public int getVariant() {
    return getInteger("variant");
  }
  
  public int hashCode() {
    return InvitationEntity.a(this);
  }
  
  public String toString() {
    return InvitationEntity.b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ((InvitationEntity)freeze()).writeToParcel(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */