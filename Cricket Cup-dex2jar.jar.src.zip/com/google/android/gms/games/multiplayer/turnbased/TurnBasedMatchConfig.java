package com.google.android.gms.games.multiplayer.turnbased;

import android.os.Bundle;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;

public final class TurnBasedMatchConfig {
  private final String[] wG;
  
  private final Bundle wH;
  
  private final int wT;
  
  private final int wo;
  
  private TurnBasedMatchConfig(Builder paramBuilder) {
    this.wo = paramBuilder.wo;
    this.wT = paramBuilder.wT;
    this.wH = paramBuilder.wH;
    int i = paramBuilder.wK.size();
    this.wG = paramBuilder.wK.<String>toArray(new String[i]);
  }
  
  public static Builder builder() {
    return new Builder();
  }
  
  public static Bundle createAutoMatchCriteria(int paramInt1, int paramInt2, long paramLong) {
    Bundle bundle = new Bundle();
    bundle.putInt("min_automatch_players", paramInt1);
    bundle.putInt("max_automatch_players", paramInt2);
    bundle.putLong("exclusive_bit_mask", paramLong);
    return bundle;
  }
  
  public Bundle getAutoMatchCriteria() {
    return this.wH;
  }
  
  public String[] getInvitedPlayerIds() {
    return this.wG;
  }
  
  public int getMinPlayers() {
    return this.wT;
  }
  
  public int getVariant() {
    return this.wo;
  }
  
  public static final class Builder {
    Bundle wH = null;
    
    ArrayList<String> wK = new ArrayList<String>();
    
    int wT = 2;
    
    int wo = -1;
    
    private Builder() {}
    
    public Builder addInvitedPlayer(String param1String) {
      eg.f(param1String);
      this.wK.add(param1String);
      return this;
    }
    
    public Builder addInvitedPlayers(ArrayList<String> param1ArrayList) {
      eg.f(param1ArrayList);
      this.wK.addAll(param1ArrayList);
      return this;
    }
    
    public TurnBasedMatchConfig build() {
      return new TurnBasedMatchConfig(this);
    }
    
    public Builder setAutoMatchCriteria(Bundle param1Bundle) {
      this.wH = param1Bundle;
      return this;
    }
    
    public Builder setMinPlayers(int param1Int) {
      this.wT = param1Int;
      return this;
    }
    
    public Builder setVariant(int param1Int) {
      if (param1Int == -1 || param1Int > 0) {
        boolean bool1 = true;
        eg.b(bool1, "Variant must be a positive integer or TurnBasedMatch.MATCH_VARIANT_ANY");
        this.wo = param1Int;
        return this;
      } 
      boolean bool = false;
      eg.b(bool, "Variant must be a positive integer or TurnBasedMatch.MATCH_VARIANT_ANY");
      this.wo = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\turnbased\TurnBasedMatchConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */