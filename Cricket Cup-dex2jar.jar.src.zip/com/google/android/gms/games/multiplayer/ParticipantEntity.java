package com.google.android.gms.games.multiplayer;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.fc;
import com.google.android.gms.internal.fm;

public final class ParticipantEntity extends fm implements Participant {
  public static final Parcelable.Creator<ParticipantEntity> CREATOR = new a();
  
  private final int kg;
  
  private final String qa;
  
  private final Uri sL;
  
  private final Uri sM;
  
  private final String up;
  
  private final int wr;
  
  private final String ws;
  
  private final boolean wt;
  
  private final PlayerEntity wu;
  
  private final int wv;
  
  private final ParticipantResult ww;
  
  ParticipantEntity(int paramInt1, String paramString1, String paramString2, Uri paramUri1, Uri paramUri2, int paramInt2, String paramString3, boolean paramBoolean, PlayerEntity paramPlayerEntity, int paramInt3, ParticipantResult paramParticipantResult) {
    this.kg = paramInt1;
    this.up = paramString1;
    this.qa = paramString2;
    this.sL = paramUri1;
    this.sM = paramUri2;
    this.wr = paramInt2;
    this.ws = paramString3;
    this.wt = paramBoolean;
    this.wu = paramPlayerEntity;
    this.wv = paramInt3;
    this.ww = paramParticipantResult;
  }
  
  public ParticipantEntity(Participant paramParticipant) {
    PlayerEntity playerEntity;
    this.kg = 2;
    this.up = paramParticipant.getParticipantId();
    this.qa = paramParticipant.getDisplayName();
    this.sL = paramParticipant.getIconImageUri();
    this.sM = paramParticipant.getHiResImageUri();
    this.wr = paramParticipant.getStatus();
    this.ws = paramParticipant.dy();
    this.wt = paramParticipant.isConnectedToRoom();
    Player player = paramParticipant.getPlayer();
    if (player == null) {
      player = null;
    } else {
      playerEntity = new PlayerEntity(player);
    } 
    this.wu = playerEntity;
    this.wv = paramParticipant.getCapabilities();
    this.ww = paramParticipant.getResult();
  }
  
  static int a(Participant paramParticipant) {
    return ee.hashCode(new Object[] { paramParticipant.getPlayer(), Integer.valueOf(paramParticipant.getStatus()), paramParticipant.dy(), Boolean.valueOf(paramParticipant.isConnectedToRoom()), paramParticipant.getDisplayName(), paramParticipant.getIconImageUri(), paramParticipant.getHiResImageUri(), Integer.valueOf(paramParticipant.getCapabilities()), paramParticipant.getResult() });
  }
  
  static boolean a(Participant paramParticipant, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof Participant))
      return false; 
    boolean bool1 = bool2;
    if (paramParticipant != paramObject) {
      paramObject = paramObject;
      if (ee.equal(paramObject.getPlayer(), paramParticipant.getPlayer()) && ee.equal(Integer.valueOf(paramObject.getStatus()), Integer.valueOf(paramParticipant.getStatus())) && ee.equal(paramObject.dy(), paramParticipant.dy()) && ee.equal(Boolean.valueOf(paramObject.isConnectedToRoom()), Boolean.valueOf(paramParticipant.isConnectedToRoom())) && ee.equal(paramObject.getDisplayName(), paramParticipant.getDisplayName()) && ee.equal(paramObject.getIconImageUri(), paramParticipant.getIconImageUri()) && ee.equal(paramObject.getHiResImageUri(), paramParticipant.getHiResImageUri()) && ee.equal(Integer.valueOf(paramObject.getCapabilities()), Integer.valueOf(paramParticipant.getCapabilities()))) {
        bool1 = bool2;
        return !ee.equal(paramObject.getResult(), paramParticipant.getResult()) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(Participant paramParticipant) {
    return ee.e(paramParticipant).a("Player", paramParticipant.getPlayer()).a("Status", Integer.valueOf(paramParticipant.getStatus())).a("ClientAddress", paramParticipant.dy()).a("ConnectedToRoom", Boolean.valueOf(paramParticipant.isConnectedToRoom())).a("DisplayName", paramParticipant.getDisplayName()).a("IconImage", paramParticipant.getIconImageUri()).a("HiResImage", paramParticipant.getHiResImageUri()).a("Capabilities", Integer.valueOf(paramParticipant.getCapabilities())).a("Result", paramParticipant.getResult()).toString();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String dy() {
    return this.ws;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public Participant freeze() {
    return this;
  }
  
  public int getCapabilities() {
    return this.wv;
  }
  
  public String getDisplayName() {
    return (this.wu == null) ? this.qa : this.wu.getDisplayName();
  }
  
  public void getDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    if (this.wu == null) {
      fc.b(this.qa, paramCharArrayBuffer);
      return;
    } 
    this.wu.getDisplayName(paramCharArrayBuffer);
  }
  
  public Uri getHiResImageUri() {
    return (this.wu == null) ? this.sM : this.wu.getHiResImageUri();
  }
  
  public Uri getIconImageUri() {
    return (this.wu == null) ? this.sL : this.wu.getIconImageUri();
  }
  
  public String getParticipantId() {
    return this.up;
  }
  
  public Player getPlayer() {
    return (Player)this.wu;
  }
  
  public ParticipantResult getResult() {
    return this.ww;
  }
  
  public int getStatus() {
    return this.wr;
  }
  
  public int getVersionCode() {
    return this.kg;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isConnectedToRoom() {
    return this.wt;
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool1;
    String str1;
    String str2 = null;
    boolean bool2 = false;
    if (!bN()) {
      c.a(this, paramParcel, paramInt);
      return;
    } 
    paramParcel.writeString(this.up);
    paramParcel.writeString(this.qa);
    if (this.sL == null) {
      str1 = null;
    } else {
      str1 = this.sL.toString();
    } 
    paramParcel.writeString(str1);
    if (this.sM == null) {
      str1 = str2;
    } else {
      str1 = this.sM.toString();
    } 
    paramParcel.writeString(str1);
    paramParcel.writeInt(this.wr);
    paramParcel.writeString(this.ws);
    if (this.wt) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    paramParcel.writeInt(bool1);
    if (this.wu == null) {
      bool1 = bool2;
    } else {
      bool1 = true;
    } 
    paramParcel.writeInt(bool1);
    if (this.wu != null) {
      this.wu.writeToParcel(paramParcel, paramInt);
      return;
    } 
  }
  
  static final class a extends c {
    public ParticipantEntity ab(Parcel param1Parcel) {
      boolean bool2;
      Uri uri1;
      Uri uri2;
      boolean bool1 = true;
      if (ParticipantEntity.b(ParticipantEntity.da()) || ParticipantEntity.ad(ParticipantEntity.class.getCanonicalName()))
        return super.ab(param1Parcel); 
      String str3 = param1Parcel.readString();
      String str4 = param1Parcel.readString();
      String str1 = param1Parcel.readString();
      if (str1 == null) {
        str1 = null;
      } else {
        uri1 = Uri.parse(str1);
      } 
      String str2 = param1Parcel.readString();
      if (str2 == null) {
        str2 = null;
      } else {
        uri2 = Uri.parse(str2);
      } 
      int i = param1Parcel.readInt();
      String str5 = param1Parcel.readString();
      if (param1Parcel.readInt() > 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (param1Parcel.readInt() <= 0)
        bool1 = false; 
      if (bool1) {
        PlayerEntity playerEntity = (PlayerEntity)PlayerEntity.CREATOR.createFromParcel(param1Parcel);
        return new ParticipantEntity(2, str3, str4, uri1, uri2, i, str5, bool2, playerEntity, 7, null);
      } 
      param1Parcel = null;
      return new ParticipantEntity(2, str3, str4, uri1, uri2, i, str5, bool2, (PlayerEntity)param1Parcel, 7, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\ParticipantEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */