package com.google.android.gms.games.multiplayer.realtime;

import android.os.Bundle;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;
import java.util.Arrays;

public final class RoomConfig {
  private final String uf;
  
  private final RoomUpdateListener wD;
  
  private final RoomStatusUpdateListener wE;
  
  private final RealTimeMessageReceivedListener wF;
  
  private final String[] wG;
  
  private final Bundle wH;
  
  private final boolean wI;
  
  private final int wo;
  
  private RoomConfig(Builder paramBuilder) {
    this.wD = paramBuilder.wD;
    this.wE = paramBuilder.wE;
    this.wF = paramBuilder.wF;
    this.uf = paramBuilder.wJ;
    this.wo = paramBuilder.wo;
    this.wH = paramBuilder.wH;
    this.wI = paramBuilder.wI;
    int i = paramBuilder.wK.size();
    this.wG = paramBuilder.wK.<String>toArray(new String[i]);
    if (this.wF == null)
      eg.a(this.wI, "Must either enable sockets OR specify a message listener"); 
  }
  
  public static Builder builder(RoomUpdateListener paramRoomUpdateListener) {
    return new Builder(paramRoomUpdateListener);
  }
  
  public static Bundle createAutoMatchCriteria(int paramInt1, int paramInt2, long paramLong) {
    Bundle bundle = new Bundle();
    bundle.putInt("min_automatch_players", paramInt1);
    bundle.putInt("max_automatch_players", paramInt2);
    bundle.putLong("exclusive_bit_mask", paramLong);
    return bundle;
  }
  
  public Bundle getAutoMatchCriteria() {
    return this.wH;
  }
  
  public String getInvitationId() {
    return this.uf;
  }
  
  public String[] getInvitedPlayerIds() {
    return this.wG;
  }
  
  public RealTimeMessageReceivedListener getMessageReceivedListener() {
    return this.wF;
  }
  
  public RoomStatusUpdateListener getRoomStatusUpdateListener() {
    return this.wE;
  }
  
  public RoomUpdateListener getRoomUpdateListener() {
    return this.wD;
  }
  
  public int getVariant() {
    return this.wo;
  }
  
  public boolean isSocketEnabled() {
    return this.wI;
  }
  
  public static final class Builder {
    final RoomUpdateListener wD;
    
    RoomStatusUpdateListener wE;
    
    RealTimeMessageReceivedListener wF;
    
    Bundle wH;
    
    boolean wI = false;
    
    String wJ = null;
    
    ArrayList<String> wK = new ArrayList<String>();
    
    int wo = -1;
    
    private Builder(RoomUpdateListener param1RoomUpdateListener) {
      this.wD = (RoomUpdateListener)eg.b(param1RoomUpdateListener, "Must provide a RoomUpdateListener");
    }
    
    public Builder addPlayersToInvite(ArrayList<String> param1ArrayList) {
      eg.f(param1ArrayList);
      this.wK.addAll(param1ArrayList);
      return this;
    }
    
    public Builder addPlayersToInvite(String... param1VarArgs) {
      eg.f(param1VarArgs);
      this.wK.addAll(Arrays.asList(param1VarArgs));
      return this;
    }
    
    public RoomConfig build() {
      return new RoomConfig(this);
    }
    
    public Builder setAutoMatchCriteria(Bundle param1Bundle) {
      this.wH = param1Bundle;
      return this;
    }
    
    public Builder setInvitationIdToAccept(String param1String) {
      eg.f(param1String);
      this.wJ = param1String;
      return this;
    }
    
    public Builder setMessageReceivedListener(RealTimeMessageReceivedListener param1RealTimeMessageReceivedListener) {
      this.wF = param1RealTimeMessageReceivedListener;
      return this;
    }
    
    public Builder setRoomStatusUpdateListener(RoomStatusUpdateListener param1RoomStatusUpdateListener) {
      this.wE = param1RoomStatusUpdateListener;
      return this;
    }
    
    public Builder setSocketCommunicationEnabled(boolean param1Boolean) {
      this.wI = param1Boolean;
      return this;
    }
    
    public Builder setVariant(int param1Int) {
      if (param1Int == -1 || param1Int > 0) {
        boolean bool1 = true;
        eg.b(bool1, "Variant must be a positive integer or Room.ROOM_VARIANT_ANY");
        this.wo = param1Int;
        return this;
      } 
      boolean bool = false;
      eg.b(bool, "Variant must be a positive integer or Room.ROOM_VARIANT_ANY");
      this.wo = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\realtime\RoomConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */