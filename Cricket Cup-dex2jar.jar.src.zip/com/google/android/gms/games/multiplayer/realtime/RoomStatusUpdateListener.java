package com.google.android.gms.games.multiplayer.realtime;

import java.util.List;

public interface RoomStatusUpdateListener {
  void onConnectedToRoom(Room paramRoom);
  
  void onDisconnectedFromRoom(Room paramRoom);
  
  void onP2PConnected(String paramString);
  
  void onP2PDisconnected(String paramString);
  
  void onPeerDeclined(Room paramRoom, List<String> paramList);
  
  void onPeerInvitedToRoom(Room paramRoom, List<String> paramList);
  
  void onPeerJoined(Room paramRoom, List<String> paramList);
  
  void onPeerLeft(Room paramRoom, List<String> paramList);
  
  void onPeersConnected(Room paramRoom, List<String> paramList);
  
  void onPeersDisconnected(Room paramRoom, List<String> paramList);
  
  void onRoomAutoMatching(Room paramRoom);
  
  void onRoomConnecting(Room paramRoom);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\realtime\RoomStatusUpdateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */