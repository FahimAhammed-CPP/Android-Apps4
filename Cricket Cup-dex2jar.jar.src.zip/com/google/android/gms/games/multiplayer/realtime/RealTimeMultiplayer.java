package com.google.android.gms.games.multiplayer.realtime;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import java.util.List;

public interface RealTimeMultiplayer {
  public static final int REAL_TIME_MESSAGE_FAILED = -1;
  
  void create(GoogleApiClient paramGoogleApiClient, RoomConfig paramRoomConfig);
  
  void declineInvitation(GoogleApiClient paramGoogleApiClient, String paramString);
  
  void dismissInvitation(GoogleApiClient paramGoogleApiClient, String paramString);
  
  Intent getSelectOpponentsIntent(GoogleApiClient paramGoogleApiClient, int paramInt1, int paramInt2);
  
  Intent getSelectOpponentsIntent(GoogleApiClient paramGoogleApiClient, int paramInt1, int paramInt2, boolean paramBoolean);
  
  RealTimeSocket getSocketForParticipant(GoogleApiClient paramGoogleApiClient, String paramString1, String paramString2);
  
  Intent getWaitingRoomIntent(GoogleApiClient paramGoogleApiClient, Room paramRoom, int paramInt);
  
  void join(GoogleApiClient paramGoogleApiClient, RoomConfig paramRoomConfig);
  
  void leave(GoogleApiClient paramGoogleApiClient, RoomUpdateListener paramRoomUpdateListener, String paramString);
  
  int sendReliableMessage(GoogleApiClient paramGoogleApiClient, ReliableMessageSentCallback paramReliableMessageSentCallback, byte[] paramArrayOfbyte, String paramString1, String paramString2);
  
  int sendUnreliableMessage(GoogleApiClient paramGoogleApiClient, byte[] paramArrayOfbyte, String paramString1, String paramString2);
  
  int sendUnreliableMessage(GoogleApiClient paramGoogleApiClient, byte[] paramArrayOfbyte, String paramString, List<String> paramList);
  
  int sendUnreliableMessageToAll(GoogleApiClient paramGoogleApiClient, byte[] paramArrayOfbyte, String paramString);
  
  public static interface ReliableMessageSentCallback {
    void onRealTimeMessageSent(int param1Int1, int param1Int2, String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\realtime\RealTimeMultiplayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */