package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.fc;
import com.google.android.gms.internal.fm;

public final class PlayerEntity extends fm implements Player {
  public static final Parcelable.Creator<PlayerEntity> CREATOR = new a();
  
  private final int kg;
  
  private final String qa;
  
  private final Uri sL;
  
  private final Uri sM;
  
  private final String tC;
  
  private final long tD;
  
  private final int tE;
  
  private final long tF;
  
  PlayerEntity(int paramInt1, String paramString1, String paramString2, Uri paramUri1, Uri paramUri2, long paramLong1, int paramInt2, long paramLong2) {
    this.kg = paramInt1;
    this.tC = paramString1;
    this.qa = paramString2;
    this.sL = paramUri1;
    this.sM = paramUri2;
    this.tD = paramLong1;
    this.tE = paramInt2;
    this.tF = paramLong2;
  }
  
  public PlayerEntity(Player paramPlayer) {
    boolean bool;
    this.kg = 3;
    this.tC = paramPlayer.getPlayerId();
    this.qa = paramPlayer.getDisplayName();
    this.sL = paramPlayer.getIconImageUri();
    this.sM = paramPlayer.getHiResImageUri();
    this.tD = paramPlayer.getRetrievedTimestamp();
    this.tE = paramPlayer.db();
    this.tF = paramPlayer.getLastPlayedWithTimestamp();
    ds.d(this.tC);
    ds.d(this.qa);
    if (this.tD > 0L) {
      bool = true;
    } else {
      bool = false;
    } 
    ds.p(bool);
  }
  
  static int a(Player paramPlayer) {
    return ee.hashCode(new Object[] { paramPlayer.getPlayerId(), paramPlayer.getDisplayName(), paramPlayer.getIconImageUri(), paramPlayer.getHiResImageUri(), Long.valueOf(paramPlayer.getRetrievedTimestamp()) });
  }
  
  static boolean a(Player paramPlayer, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof Player))
      return false; 
    boolean bool1 = bool2;
    if (paramPlayer != paramObject) {
      paramObject = paramObject;
      if (ee.equal(paramObject.getPlayerId(), paramPlayer.getPlayerId()) && ee.equal(paramObject.getDisplayName(), paramPlayer.getDisplayName()) && ee.equal(paramObject.getIconImageUri(), paramPlayer.getIconImageUri()) && ee.equal(paramObject.getHiResImageUri(), paramPlayer.getHiResImageUri())) {
        bool1 = bool2;
        return !ee.equal(Long.valueOf(paramObject.getRetrievedTimestamp()), Long.valueOf(paramPlayer.getRetrievedTimestamp())) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(Player paramPlayer) {
    return ee.e(paramPlayer).a("PlayerId", paramPlayer.getPlayerId()).a("DisplayName", paramPlayer.getDisplayName()).a("IconImageUri", paramPlayer.getIconImageUri()).a("HiResImageUri", paramPlayer.getHiResImageUri()).a("RetrievedTimestamp", Long.valueOf(paramPlayer.getRetrievedTimestamp())).toString();
  }
  
  public int db() {
    return this.tE;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public Player freeze() {
    return this;
  }
  
  public String getDisplayName() {
    return this.qa;
  }
  
  public void getDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    fc.b(this.qa, paramCharArrayBuffer);
  }
  
  public Uri getHiResImageUri() {
    return this.sM;
  }
  
  public Uri getIconImageUri() {
    return this.sL;
  }
  
  public long getLastPlayedWithTimestamp() {
    return this.tF;
  }
  
  public String getPlayerId() {
    return this.tC;
  }
  
  public long getRetrievedTimestamp() {
    return this.tD;
  }
  
  public int getVersionCode() {
    return this.kg;
  }
  
  public boolean hasHiResImage() {
    return (getHiResImageUri() != null);
  }
  
  public boolean hasIconImage() {
    return (getIconImageUri() != null);
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    String str1;
    String str2 = null;
    if (!bN()) {
      c.a(this, paramParcel, paramInt);
      return;
    } 
    paramParcel.writeString(this.tC);
    paramParcel.writeString(this.qa);
    if (this.sL == null) {
      str1 = null;
    } else {
      str1 = this.sL.toString();
    } 
    paramParcel.writeString(str1);
    if (this.sM == null) {
      str1 = str2;
    } else {
      str1 = this.sM.toString();
    } 
    paramParcel.writeString(str1);
    paramParcel.writeLong(this.tD);
  }
  
  static final class a extends c {
    public PlayerEntity Z(Parcel param1Parcel) {
      Uri uri1;
      Uri uri2 = null;
      if (PlayerEntity.b(PlayerEntity.da()) || PlayerEntity.ad(PlayerEntity.class.getCanonicalName()))
        return super.Z(param1Parcel); 
      String str2 = param1Parcel.readString();
      String str3 = param1Parcel.readString();
      String str1 = param1Parcel.readString();
      String str4 = param1Parcel.readString();
      if (str1 == null) {
        str1 = null;
      } else {
        uri1 = Uri.parse(str1);
      } 
      if (str4 != null)
        uri2 = Uri.parse(str4); 
      return new PlayerEntity(3, str2, str3, uri1, uri2, param1Parcel.readLong(), -1, -1L);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\PlayerEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */