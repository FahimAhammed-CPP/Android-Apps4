package com.google.android.gms.games;

public final class GamesStatusCodes {
  public static final int STATUS_ACHIEVEMENT_NOT_INCREMENTAL = 3002;
  
  public static final int STATUS_ACHIEVEMENT_UNKNOWN = 3001;
  
  public static final int STATUS_ACHIEVEMENT_UNLOCKED = 3003;
  
  public static final int STATUS_ACHIEVEMENT_UNLOCK_FAILURE = 3000;
  
  public static final int STATUS_APP_MISCONFIGURED = 8;
  
  public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
  
  public static final int STATUS_GAME_NOT_FOUND = 9;
  
  public static final int STATUS_INTERNAL_ERROR = 1;
  
  public static final int STATUS_INTERRUPTED = 14;
  
  public static final int STATUS_INVALID_REAL_TIME_ROOM_ID = 7002;
  
  public static final int STATUS_LICENSE_CHECK_FAILED = 7;
  
  public static final int STATUS_MATCH_ERROR_ALREADY_REMATCHED = 6505;
  
  public static final int STATUS_MATCH_ERROR_INACTIVE_MATCH = 6501;
  
  public static final int STATUS_MATCH_ERROR_INVALID_MATCH_RESULTS = 6504;
  
  public static final int STATUS_MATCH_ERROR_INVALID_MATCH_STATE = 6502;
  
  public static final int STATUS_MATCH_ERROR_INVALID_PARTICIPANT_STATE = 6500;
  
  public static final int STATUS_MATCH_ERROR_LOCALLY_MODIFIED = 6507;
  
  public static final int STATUS_MATCH_ERROR_OUT_OF_DATE_VERSION = 6503;
  
  public static final int STATUS_MATCH_NOT_FOUND = 6506;
  
  public static final int STATUS_MULTIPLAYER_DISABLED = 6003;
  
  public static final int STATUS_MULTIPLAYER_ERROR_CREATION_NOT_ALLOWED = 6000;
  
  public static final int STATUS_MULTIPLAYER_ERROR_INVALID_MULTIPLAYER_TYPE = 6002;
  
  public static final int STATUS_MULTIPLAYER_ERROR_INVALID_OPERATION = 6004;
  
  public static final int STATUS_MULTIPLAYER_ERROR_NOT_TRUSTED_TESTER = 6001;
  
  public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
  
  public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
  
  public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
  
  public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
  
  public static final int STATUS_OK = 0;
  
  public static final int STATUS_OPERATION_IN_FLIGHT = 7007;
  
  public static final int STATUS_PARTICIPANT_NOT_CONNECTED = 7003;
  
  public static final int STATUS_REAL_TIME_CONNECTION_FAILED = 7000;
  
  public static final int STATUS_REAL_TIME_INACTIVE_ROOM = 7005;
  
  public static final int STATUS_REAL_TIME_MESSAGE_SEND_FAILED = 7001;
  
  public static final int STATUS_REAL_TIME_ROOM_NOT_JOINED = 7004;
  
  public static final int STATUS_TIMEOUT = 15;
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\GamesStatusCodes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */