package com.google.android.gms.games.achievement;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.b;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.d;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.ee;

public final class a extends b implements Achievement {
  a(DataHolder paramDataHolder, int paramInt) {
    super(paramDataHolder, paramInt);
  }
  
  public String getAchievementId() {
    return getString("external_achievement_id");
  }
  
  public int getCurrentSteps() {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    return getInteger("current_steps");
  }
  
  public String getDescription() {
    return getString("description");
  }
  
  public void getDescription(CharArrayBuffer paramCharArrayBuffer) {
    a("description", paramCharArrayBuffer);
  }
  
  public String getFormattedCurrentSteps() {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    return getString("formatted_current_steps");
  }
  
  public void getFormattedCurrentSteps(CharArrayBuffer paramCharArrayBuffer) {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    a("formatted_current_steps", paramCharArrayBuffer);
  }
  
  public String getFormattedTotalSteps() {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    return getString("formatted_total_steps");
  }
  
  public void getFormattedTotalSteps(CharArrayBuffer paramCharArrayBuffer) {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    a("formatted_total_steps", paramCharArrayBuffer);
  }
  
  public long getLastUpdatedTimestamp() {
    return getLong("last_updated_timestamp");
  }
  
  public String getName() {
    return getString("name");
  }
  
  public void getName(CharArrayBuffer paramCharArrayBuffer) {
    a("name", paramCharArrayBuffer);
  }
  
  public Player getPlayer() {
    return (Player)new d(this.nE, this.nG);
  }
  
  public Uri getRevealedImageUri() {
    return L("revealed_icon_image_uri");
  }
  
  public int getState() {
    return getInteger("state");
  }
  
  public int getTotalSteps() {
    boolean bool = true;
    if (getType() != 1)
      bool = false; 
    ds.p(bool);
    return getInteger("total_steps");
  }
  
  public int getType() {
    return getInteger("type");
  }
  
  public Uri getUnlockedImageUri() {
    return L("unlocked_icon_image_uri");
  }
  
  public String toString() {
    ee.a a1 = ee.e(this).a("id", getAchievementId()).a("name", getName()).a("state", Integer.valueOf(getState())).a("type", Integer.valueOf(getType()));
    if (getType() == 1)
      a1.a("steps", getCurrentSteps() + "/" + getTotalSteps()); 
    return a1.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\achievement\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */