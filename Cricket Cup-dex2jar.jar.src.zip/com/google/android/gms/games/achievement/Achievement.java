package com.google.android.gms.games.achievement;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.games.Player;

public interface Achievement {
  public static final int STATE_HIDDEN = 2;
  
  public static final int STATE_REVEALED = 1;
  
  public static final int STATE_UNLOCKED = 0;
  
  public static final int TYPE_INCREMENTAL = 1;
  
  public static final int TYPE_STANDARD = 0;
  
  String getAchievementId();
  
  int getCurrentSteps();
  
  String getDescription();
  
  void getDescription(CharArrayBuffer paramCharArrayBuffer);
  
  String getFormattedCurrentSteps();
  
  void getFormattedCurrentSteps(CharArrayBuffer paramCharArrayBuffer);
  
  String getFormattedTotalSteps();
  
  void getFormattedTotalSteps(CharArrayBuffer paramCharArrayBuffer);
  
  long getLastUpdatedTimestamp();
  
  String getName();
  
  void getName(CharArrayBuffer paramCharArrayBuffer);
  
  Player getPlayer();
  
  Uri getRevealedImageUri();
  
  int getState();
  
  int getTotalSteps();
  
  int getType();
  
  Uri getUnlockedImageUri();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\achievement\Achievement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */