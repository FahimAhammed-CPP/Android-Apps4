package com.google.android.gms.games.achievement;

@Deprecated
public interface OnAchievementUpdatedListener {
  void onAchievementUpdated(int paramInt, String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\achievement\OnAchievementUpdatedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */