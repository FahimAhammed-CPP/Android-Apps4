package com.google.android.gms.games;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.multiplayer.Invitations;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMultiplayer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.fl;
import com.google.android.gms.internal.fs;
import com.google.android.gms.internal.ft;
import com.google.android.gms.internal.fu;
import com.google.android.gms.internal.fv;
import com.google.android.gms.internal.fw;
import com.google.android.gms.internal.fx;
import com.google.android.gms.internal.fy;
import com.google.android.gms.internal.fz;
import com.google.android.gms.internal.ga;
import com.google.android.gms.internal.gb;
import com.google.android.gms.internal.gg;

public final class Games {
  public static final Api API;
  
  public static final Achievements Achievements;
  
  public static final GamesMetadata GamesMetadata;
  
  public static final Invitations Invitations;
  
  public static final Leaderboards Leaderboards;
  
  public static final Notifications Notifications;
  
  public static final Players Players;
  
  public static final RealTimeMultiplayer RealTimeMultiplayer;
  
  public static final Scope SCOPE_GAMES;
  
  public static final TurnBasedMultiplayer TurnBasedMultiplayer;
  
  static final Api.b<fl> jO = new Api.b<fl>() {
      public fl e(Context param1Context, dt param1dt, GoogleApiClient.ApiOptions param1ApiOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        Games.GamesOptions gamesOptions = new Games.GamesOptions();
        if (param1ApiOptions != null) {
          eg.b(param1ApiOptions instanceof Games.GamesOptions, "Must provide valid GamesOptions!");
          param1ApiOptions = param1ApiOptions;
          return new fl(param1Context, param1dt.bJ(), param1dt.bF(), param1ConnectionCallbacks, param1OnConnectionFailedListener, param1dt.bI(), param1dt.bG(), param1dt.bK(), ((Games.GamesOptions)param1ApiOptions).ta, ((Games.GamesOptions)param1ApiOptions).tb, ((Games.GamesOptions)param1ApiOptions).tc, ((Games.GamesOptions)param1ApiOptions).td);
        } 
        param1ApiOptions = gamesOptions;
        return new fl(param1Context, param1dt.bJ(), param1dt.bF(), param1ConnectionCallbacks, param1OnConnectionFailedListener, param1dt.bI(), param1dt.bG(), param1dt.bK(), ((Games.GamesOptions)param1ApiOptions).ta, ((Games.GamesOptions)param1ApiOptions).tb, ((Games.GamesOptions)param1ApiOptions).tc, ((Games.GamesOptions)param1ApiOptions).td);
      }
      
      public int getPriority() {
        return 1;
      }
    };
  
  public static final Scope sW;
  
  public static final Api sX;
  
  public static final Multiplayer sY;
  
  public static final gg sZ;
  
  static {
    SCOPE_GAMES = new Scope("https://www.googleapis.com/auth/games");
    API = new Api(jO, new Scope[] { SCOPE_GAMES });
    sW = new Scope("https://www.googleapis.com/auth/games.firstparty");
    sX = new Api(jO, new Scope[] { sW });
    GamesMetadata = (GamesMetadata)new fu();
    Achievements = (Achievements)new fs();
    Leaderboards = (Leaderboards)new fw();
    Invitations = (Invitations)new fv();
    TurnBasedMultiplayer = (TurnBasedMultiplayer)new gb();
    RealTimeMultiplayer = (RealTimeMultiplayer)new ga();
    sY = (Multiplayer)new fx();
    Players = (Players)new fz();
    Notifications = (Notifications)new fy();
    sZ = (gg)new ft();
  }
  
  public static String getAppId(GoogleApiClient paramGoogleApiClient) {
    return j(paramGoogleApiClient).getAppId();
  }
  
  public static String getCurrentAccountName(GoogleApiClient paramGoogleApiClient) {
    return j(paramGoogleApiClient).getCurrentAccountName();
  }
  
  public static int getSdkVariant(GoogleApiClient paramGoogleApiClient) {
    return j(paramGoogleApiClient).dd();
  }
  
  public static Intent getSettingsIntent(GoogleApiClient paramGoogleApiClient) {
    return j(paramGoogleApiClient).getSettingsIntent();
  }
  
  public static fl j(GoogleApiClient paramGoogleApiClient) {
    boolean bool2 = true;
    if (paramGoogleApiClient != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    eg.b(bool1, "GoogleApiClient parameter is required.");
    eg.a(paramGoogleApiClient.isConnected(), "GoogleApiClient must be connected.");
    fl fl = (fl)paramGoogleApiClient.a(jO);
    if (fl != null) {
      bool1 = bool2;
      eg.a(bool1, "GoogleApiClient is not configured to use the Games Api. Pass Games.API into GoogleApiClient.Builder#addApi() to use this feature.");
      return fl;
    } 
    boolean bool1 = false;
    eg.a(bool1, "GoogleApiClient is not configured to use the Games Api. Pass Games.API into GoogleApiClient.Builder#addApi() to use this feature.");
    return fl;
  }
  
  public static void setGravityForPopups(GoogleApiClient paramGoogleApiClient, int paramInt) {
    j(paramGoogleApiClient).setGravityForPopups(paramInt);
  }
  
  public static void setViewForPopups(GoogleApiClient paramGoogleApiClient, View paramView) {
    eg.f(paramView);
    j(paramGoogleApiClient).setViewForPopups(paramView);
  }
  
  public static PendingResult<Status> signOut(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<Status>)paramGoogleApiClient.b(new b() {
          protected void a(fl param1fl) {
            param1fl.b((com.google.android.gms.common.api.a.c)this);
          }
        });
  }
  
  public static final class GamesOptions implements GoogleApiClient.ApiOptions {
    final boolean ta = false;
    
    final boolean tb = true;
    
    final int tc = 17;
    
    final int td = 4368;
    
    private GamesOptions() {}
    
    private GamesOptions(Builder param1Builder) {}
    
    public static Builder builder() {
      return new Builder();
    }
    
    public static final class Builder {
      boolean ta = false;
      
      boolean tb = true;
      
      int tc = 17;
      
      int td = 4368;
      
      private Builder() {}
      
      public Games.GamesOptions build() {
        return new Games.GamesOptions(this);
      }
      
      public Builder setSdkVariant(int param2Int) {
        this.td = param2Int;
        return this;
      }
      
      public Builder setShowConnectingPopup(boolean param2Boolean) {
        this.tb = param2Boolean;
        this.tc = 17;
        return this;
      }
      
      public Builder setShowConnectingPopup(boolean param2Boolean, int param2Int) {
        this.tb = param2Boolean;
        this.tc = param2Int;
        return this;
      }
    }
  }
  
  public static final class Builder {
    boolean ta = false;
    
    boolean tb = true;
    
    int tc = 17;
    
    int td = 4368;
    
    private Builder() {}
    
    public Games.GamesOptions build() {
      return new Games.GamesOptions(this);
    }
    
    public Builder setSdkVariant(int param1Int) {
      this.td = param1Int;
      return this;
    }
    
    public Builder setShowConnectingPopup(boolean param1Boolean) {
      this.tb = param1Boolean;
      this.tc = 17;
      return this;
    }
    
    public Builder setShowConnectingPopup(boolean param1Boolean, int param1Int) {
      this.tb = param1Boolean;
      this.tc = param1Int;
      return this;
    }
  }
  
  public static abstract class a<R extends Result> extends com.google.android.gms.common.api.a.a<R, fl> implements PendingResult<R> {
    public a() {
      super(Games.jO);
    }
  }
  
  private static abstract class b extends a<Status> {
    private b() {}
    
    public Status g(Status param1Status) {
      return param1Status;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\Games.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */