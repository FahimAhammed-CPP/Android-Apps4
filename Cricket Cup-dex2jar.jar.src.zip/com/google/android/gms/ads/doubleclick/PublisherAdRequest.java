package com.google.android.gms.ads.doubleclick;

import android.content.Context;
import android.location.Location;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.internal.af;
import java.util.Date;
import java.util.Set;

public final class PublisherAdRequest {
  public static final String DEVICE_ID_EMULATOR = af.DEVICE_ID_EMULATOR;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  public static final int GENDER_FEMALE = 2;
  
  public static final int GENDER_MALE = 1;
  
  public static final int GENDER_UNKNOWN = 0;
  
  private final af dW;
  
  private PublisherAdRequest(Builder paramBuilder) {
    this.dW = new af(Builder.a(paramBuilder));
  }
  
  public Date getBirthday() {
    return this.dW.getBirthday();
  }
  
  public int getGender() {
    return this.dW.getGender();
  }
  
  public Set<String> getKeywords() {
    return this.dW.getKeywords();
  }
  
  public Location getLocation() {
    return this.dW.getLocation();
  }
  
  public boolean getManualImpressionsEnabled() {
    return this.dW.getManualImpressionsEnabled();
  }
  
  public <T extends NetworkExtras> T getNetworkExtras(Class<T> paramClass) {
    return (T)this.dW.getNetworkExtras(paramClass);
  }
  
  public String getPublisherProvidedId() {
    return this.dW.getPublisherProvidedId();
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.dW.isTestDevice(paramContext);
  }
  
  af v() {
    return this.dW;
  }
  
  public static final class Builder {
    private final af.a dX = new af.a();
    
    public Builder addKeyword(String param1String) {
      this.dX.g(param1String);
      return this;
    }
    
    public Builder addNetworkExtras(NetworkExtras param1NetworkExtras) {
      this.dX.a(param1NetworkExtras);
      return this;
    }
    
    public Builder addTestDevice(String param1String) {
      this.dX.h(param1String);
      return this;
    }
    
    public PublisherAdRequest build() {
      return new PublisherAdRequest(this);
    }
    
    public Builder setBirthday(Date param1Date) {
      this.dX.a(param1Date);
      return this;
    }
    
    public Builder setGender(int param1Int) {
      this.dX.d(param1Int);
      return this;
    }
    
    public Builder setLocation(Location param1Location) {
      this.dX.a(param1Location);
      return this;
    }
    
    public Builder setManualImpressionsEnabled(boolean param1Boolean) {
      this.dX.d(param1Boolean);
      return this;
    }
    
    public Builder setPublisherProvidedId(String param1String) {
      this.dX.i(param1String);
      return this;
    }
    
    public Builder tagForChildDirectedTreatment(boolean param1Boolean) {
      this.dX.e(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\doubleclick\PublisherAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */