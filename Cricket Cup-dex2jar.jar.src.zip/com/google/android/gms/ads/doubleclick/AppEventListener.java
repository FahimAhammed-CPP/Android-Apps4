package com.google.android.gms.ads.doubleclick;

public interface AppEventListener {
  void onAppEvent(String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\doubleclick\AppEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */