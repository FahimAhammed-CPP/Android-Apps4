package com.google.android.gms.ads.search;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.internal.af;

public final class SearchAdRequest {
  public static final int BORDER_TYPE_DASHED = 1;
  
  public static final int BORDER_TYPE_DOTTED = 2;
  
  public static final int BORDER_TYPE_NONE = 0;
  
  public static final int BORDER_TYPE_SOLID = 3;
  
  public static final int CALL_BUTTON_COLOR_DARK = 2;
  
  public static final int CALL_BUTTON_COLOR_LIGHT = 0;
  
  public static final int CALL_BUTTON_COLOR_MEDIUM = 1;
  
  public static final String DEVICE_ID_EMULATOR = af.DEVICE_ID_EMULATOR;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  private final af dW;
  
  private final int jj;
  
  private final int jk;
  
  private final int jl;
  
  private final int jm;
  
  private final int jn;
  
  private final int jo;
  
  private final int jp;
  
  private final int jq;
  
  private final String jr;
  
  private final int js;
  
  private final String jt;
  
  private final int ju;
  
  private final int jv;
  
  private final String jw;
  
  private SearchAdRequest(Builder paramBuilder) {
    this.jj = Builder.a(paramBuilder);
    this.jk = Builder.b(paramBuilder);
    this.jl = Builder.c(paramBuilder);
    this.jm = Builder.d(paramBuilder);
    this.jn = Builder.e(paramBuilder);
    this.jo = Builder.f(paramBuilder);
    this.jp = Builder.g(paramBuilder);
    this.jq = Builder.h(paramBuilder);
    this.jr = Builder.i(paramBuilder);
    this.js = Builder.j(paramBuilder);
    this.jt = Builder.k(paramBuilder);
    this.ju = Builder.l(paramBuilder);
    this.jv = Builder.m(paramBuilder);
    this.jw = Builder.n(paramBuilder);
    this.dW = new af(Builder.o(paramBuilder), this);
  }
  
  public int getAnchorTextColor() {
    return this.jj;
  }
  
  public int getBackgroundColor() {
    return this.jk;
  }
  
  public int getBackgroundGradientBottom() {
    return this.jl;
  }
  
  public int getBackgroundGradientTop() {
    return this.jm;
  }
  
  public int getBorderColor() {
    return this.jn;
  }
  
  public int getBorderThickness() {
    return this.jo;
  }
  
  public int getBorderType() {
    return this.jp;
  }
  
  public int getCallButtonColor() {
    return this.jq;
  }
  
  public String getCustomChannels() {
    return this.jr;
  }
  
  public int getDescriptionTextColor() {
    return this.js;
  }
  
  public String getFontFace() {
    return this.jt;
  }
  
  public int getHeaderTextColor() {
    return this.ju;
  }
  
  public int getHeaderTextSize() {
    return this.jv;
  }
  
  public Location getLocation() {
    return this.dW.getLocation();
  }
  
  public <T extends NetworkExtras> T getNetworkExtras(Class<T> paramClass) {
    return (T)this.dW.getNetworkExtras(paramClass);
  }
  
  public String getQuery() {
    return this.jw;
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.dW.isTestDevice(paramContext);
  }
  
  af v() {
    return this.dW;
  }
  
  public static final class Builder {
    private final af.a dX = new af.a();
    
    private int jj;
    
    private int jk;
    
    private int jl;
    
    private int jm;
    
    private int jn;
    
    private int jo;
    
    private int jp = 0;
    
    private int jq;
    
    private String jr;
    
    private int js;
    
    private String jt;
    
    private int ju;
    
    private int jv;
    
    private String jw;
    
    public Builder addNetworkExtras(NetworkExtras param1NetworkExtras) {
      this.dX.a(param1NetworkExtras);
      return this;
    }
    
    public Builder addTestDevice(String param1String) {
      this.dX.h(param1String);
      return this;
    }
    
    public SearchAdRequest build() {
      return new SearchAdRequest(this);
    }
    
    public Builder setAnchorTextColor(int param1Int) {
      this.jj = param1Int;
      return this;
    }
    
    public Builder setBackgroundColor(int param1Int) {
      this.jk = param1Int;
      this.jl = Color.argb(0, 0, 0, 0);
      this.jm = Color.argb(0, 0, 0, 0);
      return this;
    }
    
    public Builder setBackgroundGradient(int param1Int1, int param1Int2) {
      this.jk = Color.argb(0, 0, 0, 0);
      this.jl = param1Int2;
      this.jm = param1Int1;
      return this;
    }
    
    public Builder setBorderColor(int param1Int) {
      this.jn = param1Int;
      return this;
    }
    
    public Builder setBorderThickness(int param1Int) {
      this.jo = param1Int;
      return this;
    }
    
    public Builder setBorderType(int param1Int) {
      this.jp = param1Int;
      return this;
    }
    
    public Builder setCallButtonColor(int param1Int) {
      this.jq = param1Int;
      return this;
    }
    
    public Builder setCustomChannels(String param1String) {
      this.jr = param1String;
      return this;
    }
    
    public Builder setDescriptionTextColor(int param1Int) {
      this.js = param1Int;
      return this;
    }
    
    public Builder setFontFace(String param1String) {
      this.jt = param1String;
      return this;
    }
    
    public Builder setHeaderTextColor(int param1Int) {
      this.ju = param1Int;
      return this;
    }
    
    public Builder setHeaderTextSize(int param1Int) {
      this.jv = param1Int;
      return this;
    }
    
    public Builder setLocation(Location param1Location) {
      this.dX.a(param1Location);
      return this;
    }
    
    public Builder setQuery(String param1String) {
      this.jw = param1String;
      return this;
    }
    
    public Builder tagForChildDirectedTreatment(boolean param1Boolean) {
      this.dX.e(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\search\SearchAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */