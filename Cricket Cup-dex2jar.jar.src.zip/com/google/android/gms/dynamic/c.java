package com.google.android.gms.dynamic;

import android.os.IBinder;
import java.lang.reflect.Field;

public final class c<T> extends b.a {
  private final T sE;
  
  private c(T paramT) {
    this.sE = paramT;
  }
  
  public static <T> T b(b paramb) {
    if (paramb instanceof c)
      return ((c)paramb).sE; 
    IBinder iBinder = paramb.asBinder();
    Field[] arrayOfField = iBinder.getClass().getDeclaredFields();
    if (arrayOfField.length == 1) {
      Field field = arrayOfField[0];
      if (!field.isAccessible()) {
        field.setAccessible(true);
        try {
          return (T)field.get(iBinder);
        } catch (NullPointerException nullPointerException) {
          throw new IllegalArgumentException("Binder object is null.", nullPointerException);
        } catch (IllegalArgumentException illegalArgumentException) {
          throw new IllegalArgumentException("remoteBinder is the wrong class.", illegalArgumentException);
        } catch (IllegalAccessException illegalAccessException) {
          throw new IllegalArgumentException("Could not access the field in remoteBinder.", illegalAccessException);
        } 
      } 
      throw new IllegalArgumentException("The concrete class implementing IObjectWrapper must have exactly one declared *private* field for the wrapped object. Preferably, this is an instance of the ObjectWrapper<T> class.");
    } 
    throw new IllegalArgumentException("The concrete class implementing IObjectWrapper must have exactly *one* declared private field for the wrapped object.  Preferably, this is an instance of the ObjectWrapper<T> class.");
  }
  
  public static <T> b h(T paramT) {
    return new c<T>(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\dynamic\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */