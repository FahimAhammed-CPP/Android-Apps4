package com.google.android.gms.appstate;

import android.content.Context;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dc;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.eg;

public final class AppStateManager {
  public static final Api API;
  
  public static final Scope SCOPE_APP_STATE;
  
  static final Api.b<dc> jO = new Api.b<dc>() {
      public dc a(Context param1Context, dt param1dt, GoogleApiClient.ApiOptions param1ApiOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        return new dc(param1Context, param1ConnectionCallbacks, param1OnConnectionFailedListener, param1dt.bF(), (String[])param1dt.bH().toArray((Object[])new String[0]));
      }
      
      public int getPriority() {
        return Integer.MAX_VALUE;
      }
    };
  
  static {
    SCOPE_APP_STATE = new Scope("https://www.googleapis.com/auth/appstate");
    API = new Api(jO, new Scope[] { SCOPE_APP_STATE });
  }
  
  public static dc a(GoogleApiClient paramGoogleApiClient) {
    boolean bool2 = true;
    if (paramGoogleApiClient != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    eg.b(bool1, "GoogleApiClient parameter is required.");
    eg.a(paramGoogleApiClient.isConnected(), "GoogleApiClient must be connected.");
    dc dc = (dc)paramGoogleApiClient.a(jO);
    if (dc != null) {
      bool1 = bool2;
      eg.a(bool1, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
      return dc;
    } 
    boolean bool1 = false;
    eg.a(bool1, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
    return dc;
  }
  
  private static StateResult b(Status paramStatus) {
    return new StateResult(paramStatus) {
        public AppStateManager.StateConflictResult getConflictResult() {
          return null;
        }
        
        public AppStateManager.StateLoadedResult getLoadedResult() {
          return null;
        }
        
        public Status getStatus() {
          return this.jP;
        }
      };
  }
  
  public static PendingResult<StateDeletedResult> delete(GoogleApiClient paramGoogleApiClient, int paramInt) {
    return (PendingResult<StateDeletedResult>)paramGoogleApiClient.b(new b(paramInt) {
          protected void a(dc param1dc) {
            param1dc.a((com.google.android.gms.common.api.a.c)this, this.jQ);
          }
          
          public AppStateManager.StateDeletedResult d(Status param1Status) {
            return new AppStateManager.StateDeletedResult(this, param1Status) {
                public int getStateKey() {
                  return this.jS.jQ;
                }
                
                public Status getStatus() {
                  return this.jP;
                }
              };
          }
        });
  }
  
  public static int getMaxNumKeys(GoogleApiClient paramGoogleApiClient) {
    return a(paramGoogleApiClient).getMaxNumKeys();
  }
  
  public static int getMaxStateSize(GoogleApiClient paramGoogleApiClient) {
    return a(paramGoogleApiClient).getMaxStateSize();
  }
  
  public static PendingResult<StateListResult> list(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<StateListResult>)paramGoogleApiClient.a(new c() {
          protected void a(dc param1dc) {
            param1dc.a((com.google.android.gms.common.api.a.c)this);
          }
        });
  }
  
  public static PendingResult<StateResult> load(GoogleApiClient paramGoogleApiClient, int paramInt) {
    return (PendingResult<StateResult>)paramGoogleApiClient.a(new e(paramInt) {
          protected void a(dc param1dc) {
            param1dc.b((com.google.android.gms.common.api.a.c)this, this.jQ);
          }
        });
  }
  
  public static PendingResult<StateResult> resolve(GoogleApiClient paramGoogleApiClient, int paramInt, String paramString, byte[] paramArrayOfbyte) {
    return (PendingResult<StateResult>)paramGoogleApiClient.b(new e(paramInt, paramString, paramArrayOfbyte) {
          protected void a(dc param1dc) {
            param1dc.a((com.google.android.gms.common.api.a.c)this, this.jQ, this.jT, this.jU);
          }
        });
  }
  
  public static PendingResult<Status> signOut(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<Status>)paramGoogleApiClient.b(new d() {
          protected void a(dc param1dc) {
            param1dc.b((com.google.android.gms.common.api.a.c)this);
          }
        });
  }
  
  public static void update(GoogleApiClient paramGoogleApiClient, int paramInt, byte[] paramArrayOfbyte) {
    paramGoogleApiClient.b(new e(paramInt, paramArrayOfbyte) {
          protected void a(dc param1dc) {
            param1dc.a(null, this.jQ, this.jR);
          }
        });
  }
  
  public static PendingResult<StateResult> updateImmediate(GoogleApiClient paramGoogleApiClient, int paramInt, byte[] paramArrayOfbyte) {
    return (PendingResult<StateResult>)paramGoogleApiClient.b(new e(paramInt, paramArrayOfbyte) {
          protected void a(dc param1dc) {
            param1dc.a((com.google.android.gms.common.api.a.c)this, this.jQ, this.jR);
          }
        });
  }
  
  public static interface StateConflictResult extends Result {
    byte[] getLocalData();
    
    String getResolvedVersion();
    
    byte[] getServerData();
    
    int getStateKey();
  }
  
  public static interface StateDeletedResult extends Result {
    int getStateKey();
  }
  
  public static interface StateListResult extends Result {
    AppStateBuffer getStateBuffer();
  }
  
  public static interface StateLoadedResult extends Result {
    byte[] getLocalData();
    
    int getStateKey();
  }
  
  public static interface StateResult extends Result {
    AppStateManager.StateConflictResult getConflictResult();
    
    AppStateManager.StateLoadedResult getLoadedResult();
  }
  
  public static abstract class a<R extends Result> extends com.google.android.gms.common.api.a.a<R, dc> implements PendingResult<R> {
    public a() {
      super(AppStateManager.jO);
    }
  }
  
  private static abstract class b extends a<StateDeletedResult> {
    private b() {}
  }
  
  private static abstract class c extends a<StateListResult> {
    private c() {}
    
    public AppStateManager.StateListResult f(Status param1Status) {
      return new AppStateManager.StateListResult(this, param1Status) {
          public AppStateBuffer getStateBuffer() {
            return new AppStateBuffer(null);
          }
          
          public Status getStatus() {
            return this.jP;
          }
        };
    }
  }
  
  class null implements StateListResult {
    null(AppStateManager this$0, Status param1Status) {}
    
    public AppStateBuffer getStateBuffer() {
      return new AppStateBuffer(null);
    }
    
    public Status getStatus() {
      return this.jP;
    }
  }
  
  private static abstract class d extends a<Status> {
    private d() {}
    
    public Status g(Status param1Status) {
      return param1Status;
    }
  }
  
  private static abstract class e extends a<StateResult> {
    private e() {}
    
    public AppStateManager.StateResult h(Status param1Status) {
      return AppStateManager.c(param1Status);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\appstate\AppStateManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */