package com.google.android.gms.appstate;

import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dc;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.eg;

@Deprecated
public final class AppStateClient implements GooglePlayServicesClient {
  public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
  
  public static final int STATUS_DEVELOPER_ERROR = 7;
  
  public static final int STATUS_INTERNAL_ERROR = 1;
  
  public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
  
  public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
  
  public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
  
  public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
  
  public static final int STATUS_OK = 0;
  
  public static final int STATUS_STATE_KEY_LIMIT_EXCEEDED = 2003;
  
  public static final int STATUS_STATE_KEY_NOT_FOUND = 2002;
  
  public static final int STATUS_WRITE_OUT_OF_DATE_VERSION = 2000;
  
  public static final int STATUS_WRITE_SIZE_EXCEEDED = 2001;
  
  private final dc jx;
  
  private AppStateClient(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString, String[] paramArrayOfString) {
    this.jx = new dc(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, paramString, paramArrayOfString);
  }
  
  @Deprecated
  public void connect() {
    this.jx.connect();
  }
  
  @Deprecated
  public void deleteState(OnStateDeletedListener paramOnStateDeletedListener, int paramInt) {
    this.jx.a(new com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult>(this, paramOnStateDeletedListener) {
          public void a(AppStateManager.StateDeletedResult param1StateDeletedResult) {
            this.jy.onStateDeleted(param1StateDeletedResult.getStatus().getStatusCode(), param1StateDeletedResult.getStateKey());
          }
        }paramInt);
  }
  
  @Deprecated
  public void disconnect() {
    this.jx.disconnect();
  }
  
  @Deprecated
  public int getMaxNumKeys() {
    return this.jx.getMaxNumKeys();
  }
  
  @Deprecated
  public int getMaxStateSize() {
    return this.jx.getMaxStateSize();
  }
  
  @Deprecated
  public boolean isConnected() {
    return this.jx.isConnected();
  }
  
  @Deprecated
  public boolean isConnecting() {
    return this.jx.isConnecting();
  }
  
  @Deprecated
  public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    return this.jx.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  @Deprecated
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    return this.jx.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  @Deprecated
  public void listStates(OnStateListLoadedListener paramOnStateListLoadedListener) {
    this.jx.a(new com.google.android.gms.common.api.a.c<AppStateManager.StateListResult>(this, paramOnStateListLoadedListener) {
          public void a(AppStateManager.StateListResult param1StateListResult) {
            this.jA.onStateListLoaded(param1StateListResult.getStatus().getStatusCode(), param1StateListResult.getStateBuffer());
          }
        });
  }
  
  @Deprecated
  public void loadState(OnStateLoadedListener paramOnStateLoadedListener, int paramInt) {
    this.jx.b(new a(paramOnStateLoadedListener), paramInt);
  }
  
  @Deprecated
  public void reconnect() {
    this.jx.disconnect();
    this.jx.connect();
  }
  
  @Deprecated
  public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.jx.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  @Deprecated
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.jx.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  @Deprecated
  public void resolveState(OnStateLoadedListener paramOnStateLoadedListener, int paramInt, String paramString, byte[] paramArrayOfbyte) {
    this.jx.a(new a(paramOnStateLoadedListener), paramInt, paramString, paramArrayOfbyte);
  }
  
  @Deprecated
  public void signOut() {
    this.jx.b(new com.google.android.gms.common.api.a.c<Status>(this) {
          public void a(Status param1Status) {}
        });
  }
  
  @Deprecated
  public void signOut(OnSignOutCompleteListener paramOnSignOutCompleteListener) {
    eg.b(paramOnSignOutCompleteListener, "Must provide a valid listener");
    this.jx.b(new com.google.android.gms.common.api.a.c<Status>(this, paramOnSignOutCompleteListener) {
          public void a(Status param1Status) {
            this.jB.onSignOutComplete();
          }
        });
  }
  
  @Deprecated
  public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.jx.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  @Deprecated
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.jx.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  @Deprecated
  public void updateState(int paramInt, byte[] paramArrayOfbyte) {
    this.jx.a(new a(null), paramInt, paramArrayOfbyte);
  }
  
  @Deprecated
  public void updateStateImmediate(OnStateLoadedListener paramOnStateLoadedListener, int paramInt, byte[] paramArrayOfbyte) {
    eg.b(paramOnStateLoadedListener, "Must provide a valid listener");
    this.jx.a(new a(paramOnStateLoadedListener), paramInt, paramArrayOfbyte);
  }
  
  @Deprecated
  public static final class Builder {
    private static final String[] jC = new String[] { "https://www.googleapis.com/auth/appstate" };
    
    private GooglePlayServicesClient.ConnectionCallbacks jD;
    
    private GooglePlayServicesClient.OnConnectionFailedListener jE;
    
    private String[] jF;
    
    private String jG;
    
    private Context mContext;
    
    public Builder(Context param1Context, GooglePlayServicesClient.ConnectionCallbacks param1ConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this.mContext = param1Context;
      this.jD = param1ConnectionCallbacks;
      this.jE = param1OnConnectionFailedListener;
      this.jF = jC;
      this.jG = "<<default account>>";
    }
    
    public AppStateClient create() {
      return new AppStateClient(this.mContext, this.jD, this.jE, this.jG, this.jF);
    }
    
    public Builder setAccountName(String param1String) {
      this.jG = (String)eg.f(param1String);
      return this;
    }
    
    public Builder setScopes(String... param1VarArgs) {
      this.jF = param1VarArgs;
      return this;
    }
  }
  
  private static final class a implements com.google.android.gms.common.api.a.c<AppStateManager.StateResult> {
    private final OnStateLoadedListener jH;
    
    a(OnStateLoadedListener param1OnStateLoadedListener) {
      this.jH = param1OnStateLoadedListener;
    }
    
    public void a(AppStateManager.StateResult param1StateResult) {
      AppStateManager.StateConflictResult stateConflictResult;
      if (this.jH == null)
        return; 
      if (param1StateResult.getStatus().getStatusCode() == 2000) {
        stateConflictResult = param1StateResult.getConflictResult();
        ds.d(stateConflictResult);
        this.jH.onStateConflict(stateConflictResult.getStateKey(), stateConflictResult.getResolvedVersion(), stateConflictResult.getLocalData(), stateConflictResult.getServerData());
        return;
      } 
      AppStateManager.StateLoadedResult stateLoadedResult = stateConflictResult.getLoadedResult();
      ds.d(stateLoadedResult);
      this.jH.onStateLoaded(stateLoadedResult.getStatus().getStatusCode(), stateLoadedResult.getStateKey(), stateLoadedResult.getLocalData());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\appstate\AppStateClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */