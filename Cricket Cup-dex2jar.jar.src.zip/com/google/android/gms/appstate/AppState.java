package com.google.android.gms.appstate;

import com.google.android.gms.common.data.Freezable;

public interface AppState extends Freezable<AppState> {
  byte[] getConflictData();
  
  String getConflictVersion();
  
  int getKey();
  
  byte[] getLocalData();
  
  String getLocalVersion();
  
  boolean hasConflict();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\appstate\AppState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */