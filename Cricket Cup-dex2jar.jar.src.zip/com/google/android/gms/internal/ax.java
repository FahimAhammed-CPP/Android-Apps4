package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.android.gms.dynamic.c;

public final class ax implements ay.a {
  private final bb ed;
  
  private final v eq;
  
  private final String fR;
  
  private final long fS;
  
  private final at fT;
  
  private final x fU;
  
  private final cu fV;
  
  private bc fW;
  
  private int fX;
  
  private final Object fx;
  
  private final Context mContext;
  
  public ax(Context paramContext, String paramString, bb parambb, au paramau, at paramat, v paramv, x paramx, cu paramcu) {
    long l;
    this.fx = new Object();
    this.fX = -2;
    this.mContext = paramContext;
    this.fR = paramString;
    this.ed = parambb;
    if (paramau.fJ != -1L) {
      l = paramau.fJ;
    } else {
      l = 10000L;
    } 
    this.fS = l;
    this.fT = paramat;
    this.eq = paramv;
    this.fU = paramx;
    this.fV = paramcu;
  }
  
  private bc V() {
    ct.t("Instantiating mediation adapter: " + this.fR);
    try {
      return this.ed.l(this.fR);
    } catch (RemoteException remoteException) {
      ct.a("Could not instantiate mediation adapter: " + this.fR, (Throwable)remoteException);
      return null;
    } 
  }
  
  private void a(long paramLong1, long paramLong2, long paramLong3, long paramLong4) {
    while (true) {
      if (this.fX != -2)
        return; 
      b(paramLong1, paramLong2, paramLong3, paramLong4);
    } 
  }
  
  private void a(aw paramaw) {
    try {
      if (this.fV.iL < 4100000) {
        if (this.fU.eG) {
          this.fW.a(c.h(this.mContext), this.eq, this.fT.fH, paramaw);
          return;
        } 
        this.fW.a(c.h(this.mContext), this.fU, this.eq, this.fT.fH, paramaw);
        return;
      } 
    } catch (RemoteException remoteException) {
      ct.b("Could not request ad from mediation adapter.", (Throwable)remoteException);
      f(5);
      return;
    } 
    if (this.fU.eG) {
      this.fW.a(c.h(this.mContext), this.eq, this.fT.fH, this.fT.adJson, (bd)remoteException);
      return;
    } 
    this.fW.a(c.h(this.mContext), this.fU, this.eq, this.fT.fH, this.fT.adJson, (bd)remoteException);
  }
  
  private void b(long paramLong1, long paramLong2, long paramLong3, long paramLong4) {
    long l = SystemClock.elapsedRealtime();
    paramLong1 = paramLong2 - l - paramLong1;
    paramLong2 = paramLong4 - l - paramLong3;
    if (paramLong1 <= 0L || paramLong2 <= 0L) {
      ct.t("Timed out waiting for adapter.");
      this.fX = 3;
      return;
    } 
    try {
      this.fx.wait(Math.min(paramLong1, paramLong2));
      return;
    } catch (InterruptedException interruptedException) {
      this.fX = -1;
      return;
    } 
  }
  
  public ay b(long paramLong1, long paramLong2) {
    synchronized (this.fx) {
      long l = SystemClock.elapsedRealtime();
      aw aw = new aw();
      cs.iI.post(new Runnable(this, aw) {
            public void run() {
              synchronized (ax.a(this.fZ)) {
                if (ax.b(this.fZ) != -2)
                  return; 
                ax.a(this.fZ, ax.c(this.fZ));
                if (ax.d(this.fZ) == null) {
                  this.fZ.f(4);
                  return;
                } 
              } 
              this.fY.a(this.fZ);
              ax.a(this.fZ, this.fY);
              /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
            }
          });
      a(l, this.fS, paramLong1, paramLong2);
      return new ay(this.fT, this.fW, this.fR, aw, this.fX);
    } 
  }
  
  public void cancel() {
    synchronized (this.fx) {
      if (this.fW != null)
        this.fW.destroy(); 
      this.fX = -1;
      this.fx.notify();
      return;
    } 
  }
  
  public void f(int paramInt) {
    synchronized (this.fx) {
      this.fX = paramInt;
      this.fx.notify();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */