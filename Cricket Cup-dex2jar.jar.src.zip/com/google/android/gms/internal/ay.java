package com.google.android.gms.internal;

public final class ay {
  public final int ga;
  
  public final at gb;
  
  public final bc gc;
  
  public final String gd;
  
  public final aw ge;
  
  public ay(int paramInt) {
    this(null, null, null, null, paramInt);
  }
  
  public ay(at paramat, bc parambc, String paramString, aw paramaw, int paramInt) {
    this.gb = paramat;
    this.gc = parambc;
    this.gd = paramString;
    this.ge = paramaw;
    this.ga = paramInt;
  }
  
  public static interface a {
    void f(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */