package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface bb extends IInterface {
  bc l(String paramString) throws RemoteException;
  
  public static abstract class a extends Binder implements bb {
    public a() {
      attachInterface(this, "com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
    }
    
    public static bb i(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
      return (iInterface != null && iInterface instanceof bb) ? (bb)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
      bc bc = l(param1Parcel1.readString());
      param1Parcel2.writeNoException();
      if (bc != null) {
        IBinder iBinder = bc.asBinder();
        param1Parcel2.writeStrongBinder(iBinder);
        return true;
      } 
      bc = null;
      param1Parcel2.writeStrongBinder((IBinder)bc);
      return true;
    }
    
    private static class a implements bb {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public bc l(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
          parcel1.writeString(param2String);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return bc.a.j(parcel2.readStrongBinder());
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements bb {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public bc l(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IAdapterCreator");
        parcel1.writeString(param1String);
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return bc.a.j(parcel2.readStrongBinder());
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */