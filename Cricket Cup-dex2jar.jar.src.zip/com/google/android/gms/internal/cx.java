package com.google.android.gms.internal;

import android.net.Uri;
import android.net.UrlQuerySanitizer;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.Map;

public class cx extends WebViewClient {
  private al fm;
  
  private final Object fx = new Object();
  
  protected final cw gv;
  
  private final HashMap<String, an> iU = new HashMap<String, an>();
  
  private q iV;
  
  private bn iW;
  
  private a iX;
  
  private boolean iY = false;
  
  private boolean iZ;
  
  private bq ja;
  
  public cx(cw paramcw, boolean paramBoolean) {
    this.gv = paramcw;
    this.iZ = paramBoolean;
  }
  
  private void a(bm parambm) {
    bk.a(this.gv.getContext(), parambm);
  }
  
  private static boolean b(Uri paramUri) {
    String str = paramUri.getScheme();
    return ("http".equalsIgnoreCase(str) || "https".equalsIgnoreCase(str));
  }
  
  private void c(Uri paramUri) {
    str = paramUri.getPath();
    an an = this.iU.get(str);
    if (an != null) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      UrlQuerySanitizer urlQuerySanitizer = new UrlQuerySanitizer();
      urlQuerySanitizer.setAllowUnregisteredParamaters(true);
      urlQuerySanitizer.setUnregisteredParameterValueSanitizer(UrlQuerySanitizer.getAllButNulLegal());
      urlQuerySanitizer.parseUrl(paramUri.toString());
      for (UrlQuerySanitizer.ParameterValuePair parameterValuePair : urlQuerySanitizer.getParameterList())
        hashMap.put(parameterValuePair.mParameter, parameterValuePair.mValue); 
      if (ct.n(2)) {
        ct.u("Received GMSG: " + str);
        for (String str : hashMap.keySet())
          ct.u("  " + str + ": " + (String)hashMap.get(str)); 
      } 
      an.a(this.gv, (Map)hashMap);
      return;
    } 
    ct.v("No GMSG handler found for GMSG: " + paramUri);
  }
  
  public final void Y() {
    synchronized (this.fx) {
      this.iY = false;
      this.iZ = true;
      bk bk = this.gv.aB();
      if (bk != null)
        if (!cs.ay()) {
          cs.iI.post(new Runnable(this, bk) {
                public void run() {
                  this.jb.Y();
                }
              });
        } else {
          bk.Y();
        }  
      return;
    } 
  }
  
  public final void a(bj parambj) {
    q q1;
    bn bn1 = null;
    boolean bool = this.gv.aF();
    if (bool && !(this.gv.y()).eG) {
      q1 = null;
    } else {
      q1 = this.iV;
    } 
    if (!bool)
      bn1 = this.iW; 
    a(new bm(parambj, q1, bn1, this.ja, this.gv.aE()));
  }
  
  public final void a(a parama) {
    this.iX = parama;
  }
  
  public void a(q paramq, bn parambn, al paramal, bq parambq, boolean paramBoolean) {
    a("/appEvent", new ak(paramal));
    a("/canOpenURLs", am.fn);
    a("/click", am.fo);
    a("/close", am.fp);
    a("/customClose", am.fq);
    a("/httpTrack", am.fr);
    a("/log", am.fs);
    a("/open", am.ft);
    a("/touch", am.fu);
    a("/video", am.fv);
    this.iV = paramq;
    this.iW = parambn;
    this.fm = paramal;
    this.ja = parambq;
    m(paramBoolean);
  }
  
  public final void a(String paramString, an paraman) {
    this.iU.put(paramString, paraman);
  }
  
  public final void a(boolean paramBoolean, int paramInt) {
    q q1;
    if (this.gv.aF() && !(this.gv.y()).eG) {
      q1 = null;
    } else {
      q1 = this.iV;
    } 
    a(new bm(q1, this.iW, this.ja, this.gv, paramBoolean, paramInt, this.gv.aE()));
  }
  
  public final void a(boolean paramBoolean, int paramInt, String paramString) {
    q q1;
    bn bn1 = null;
    boolean bool = this.gv.aF();
    if (bool && !(this.gv.y()).eG) {
      q1 = null;
    } else {
      q1 = this.iV;
    } 
    if (!bool)
      bn1 = this.iW; 
    a(new bm(q1, bn1, this.fm, this.ja, this.gv, paramBoolean, paramInt, paramString, this.gv.aE()));
  }
  
  public final void a(boolean paramBoolean, int paramInt, String paramString1, String paramString2) {
    q q1;
    bn bn1 = null;
    boolean bool = this.gv.aF();
    if (bool && !(this.gv.y()).eG) {
      q1 = null;
    } else {
      q1 = this.iV;
    } 
    if (!bool)
      bn1 = this.iW; 
    a(new bm(q1, bn1, this.fm, this.ja, this.gv, paramBoolean, paramInt, paramString1, paramString2, this.gv.aE()));
  }
  
  public boolean aJ() {
    synchronized (this.fx) {
      return this.iZ;
    } 
  }
  
  public final void m(boolean paramBoolean) {
    this.iY = paramBoolean;
  }
  
  public final void onPageFinished(WebView paramWebView, String paramString) {
    if (this.iX != null) {
      this.iX.a(this.gv);
      this.iX = null;
    } 
  }
  
  public final void reset() {
    synchronized (this.fx) {
      this.iU.clear();
      this.iV = null;
      this.iW = null;
      this.iX = null;
      this.fm = null;
      this.iY = false;
      this.iZ = false;
      this.ja = null;
      return;
    } 
  }
  
  public final boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    ct.u("AdWebView shouldOverrideUrlLoading: " + paramString);
    Uri uri = Uri.parse(paramString);
    if ("gmsg".equalsIgnoreCase(uri.getScheme()) && "mobileads.google.com".equalsIgnoreCase(uri.getHost())) {
      c(uri);
      return true;
    } 
    if (this.iY && paramWebView == this.gv && b(uri))
      return super.shouldOverrideUrlLoading(paramWebView, paramString); 
    if (!this.gv.willNotDraw()) {
      try {
        h h = this.gv.aD();
        Uri uri1 = uri;
        if (h != null) {
          uri1 = uri;
          if (h.a(uri))
            uri1 = h.a(uri, this.gv.getContext()); 
        } 
        a(new bj("android.intent.action.VIEW", uri1.toString(), null, null, null, null, null));
      } catch (i i) {
        ct.v("Unable to append parameter to URL: " + paramString);
        Uri uri1 = uri;
      } 
      return true;
    } 
    ct.v("AdWebView unable to handle URL: " + paramString);
    return true;
  }
  
  public static interface a {
    void a(cw param1cw);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */