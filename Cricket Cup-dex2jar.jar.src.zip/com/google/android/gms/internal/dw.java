package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.data.DataHolder;
import java.util.ArrayList;

public abstract class dw<T extends IInterface> implements GooglePlayServicesClient, Api.a, dx.b {
  public static final String[] pk = new String[] { "service_esmobile", "service_googleme" };
  
  private final String[] jF;
  
  private final Context mContext;
  
  final Handler mHandler;
  
  private final dx ne;
  
  private T pe;
  
  private final ArrayList<b<?>> pf = new ArrayList<b<?>>();
  
  private f pg;
  
  boolean ph = false;
  
  boolean pi = false;
  
  private final Object pj = new Object();
  
  protected dw(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String... paramVarArgs) {
    this(paramContext, new c(paramConnectionCallbacks), new g(paramOnConnectionFailedListener), paramVarArgs);
  }
  
  protected dw(Context paramContext, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String... paramVarArgs) {
    this.mContext = eg.<Context>f(paramContext);
    this.ne = new dx(paramContext, this, null);
    this.mHandler = new a(this, paramContext.getMainLooper());
    a(paramVarArgs);
    this.jF = paramVarArgs;
    registerConnectionCallbacks(eg.<GoogleApiClient.ConnectionCallbacks>f(paramConnectionCallbacks));
    registerConnectionFailedListener(eg.<GoogleApiClient.OnConnectionFailedListener>f(paramOnConnectionFailedListener));
  }
  
  public void I(int paramInt) {
    this.mHandler.sendMessage(this.mHandler.obtainMessage(4, Integer.valueOf(paramInt)));
  }
  
  protected void a(int paramInt, IBinder paramIBinder, Bundle paramBundle) {
    this.mHandler.sendMessage(this.mHandler.obtainMessage(1, new h(this, paramInt, paramIBinder, paramBundle)));
  }
  
  public final void a(b<?> paramb) {
    synchronized (this.pf) {
      this.pf.add(paramb);
      this.mHandler.sendMessage(this.mHandler.obtainMessage(2, paramb));
      return;
    } 
  }
  
  protected abstract void a(ec paramec, e parame) throws RemoteException;
  
  protected void a(String... paramVarArgs) {}
  
  public Bundle aU() {
    return null;
  }
  
  protected abstract String am();
  
  protected abstract String an();
  
  public final String[] bO() {
    return this.jF;
  }
  
  protected final void bP() {
    if (!isConnected())
      throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called."); 
  }
  
  protected final T bQ() {
    bP();
    return this.pe;
  }
  
  public boolean bp() {
    return this.ph;
  }
  
  public void connect() {
    this.ph = true;
    synchronized (this.pj) {
      this.pi = true;
      int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.mContext);
      if (i != 0) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(i)));
        return;
      } 
    } 
    if (this.pg != null) {
      Log.e("GmsClient", "Calling connect() while still connected, missing disconnect().");
      this.pe = null;
      dy.s(this.mContext).b(am(), this.pg);
    } 
    this.pg = new f(this);
    if (!dy.s(this.mContext).a(am(), this.pg)) {
      Log.e("GmsClient", "unable to connect to service: " + am());
      this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(9)));
      return;
    } 
  }
  
  public void disconnect() {
    this.ph = false;
    synchronized (this.pj) {
      this.pi = false;
      null = (Object<b<?>>)this.pf;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object<InnerObjectType{ObjectType{com/google/android/gms/internal/dw<GenericType{T}>}.Lcom/google/android/gms/internal/dw$b;<Wildcard{?}>}>}, name=null} */
      try {
        int j = this.pf.size();
        for (int i = 0; i < j; i++)
          ((b)this.pf.get(i)).bS(); 
        this.pf.clear();
        this.pe = null;
        if (this.pg != null) {
          dy.s(this.mContext).b(am(), this.pg);
          this.pg = null;
          this.ne.J(-1);
        } 
        return;
      } finally {
        Exception exception;
      } 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    throw SYNTHETIC_LOCAL_VARIABLE_4;
  }
  
  public final Context getContext() {
    return this.mContext;
  }
  
  public boolean isConnected() {
    return (this.pe != null);
  }
  
  public boolean isConnecting() {
    synchronized (this.pj) {
      return this.pi;
    } 
  }
  
  public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    return this.ne.isConnectionCallbacksRegistered(new c(paramConnectionCallbacks));
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    return this.ne.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  protected abstract T p(IBinder paramIBinder);
  
  public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.ne.registerConnectionCallbacks(new c(paramConnectionCallbacks));
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.ne.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.ne.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.ne.registerConnectionFailedListener((GooglePlayServicesClient.OnConnectionFailedListener)paramOnConnectionFailedListener);
  }
  
  public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.ne.unregisterConnectionCallbacks(new c(paramConnectionCallbacks));
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.ne.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  protected final void w(IBinder paramIBinder) {
    try {
      a(ec.a.y(paramIBinder), new e(this));
      return;
    } catch (RemoteException remoteException) {
      Log.w("GmsClient", "service died");
      return;
    } 
  }
  
  final class a extends Handler {
    public a(dw this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      dw.b b;
      if (param1Message.what == 1 && !this.pl.isConnecting()) {
        null = (dw.b)param1Message.obj;
        null.aL();
        null.unregister();
        return;
      } 
      synchronized (dw.b(this.pl)) {
        this.pl.pi = false;
        if (((Message)null).what == 3) {
          dw.a(this.pl).a(new ConnectionResult(((Integer)((Message)null).obj).intValue(), null));
          return;
        } 
      } 
      if (param1Message.what == 4) {
        dw.a(this.pl).J(((Integer)param1Message.obj).intValue());
        return;
      } 
      if (param1Message.what == 2 && !this.pl.isConnected()) {
        b = (dw.b)param1Message.obj;
        b.aL();
        b.unregister();
        return;
      } 
      if (((Message)b).what == 2 || ((Message)b).what == 1) {
        ((dw.b)((Message)b).obj).bR();
        return;
      } 
      Log.wtf("GmsClient", "Don't know how to handle this message.");
    }
  }
  
  protected abstract class b<TListener> {
    private TListener mListener;
    
    private boolean pm;
    
    public b(dw this$0, TListener param1TListener) {
      this.mListener = param1TListener;
      this.pm = false;
    }
    
    protected abstract void aL();
    
    protected abstract void b(TListener param1TListener);
    
    public void bR() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mListener : Ljava/lang/Object;
      //   6: astore_1
      //   7: aload_0
      //   8: getfield pm : Z
      //   11: ifeq -> 44
      //   14: ldc 'GmsClient'
      //   16: new java/lang/StringBuilder
      //   19: dup
      //   20: invokespecial <init> : ()V
      //   23: ldc 'Callback proxy '
      //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   28: aload_0
      //   29: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   32: ldc ' being reused. This is not safe.'
      //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   37: invokevirtual toString : ()Ljava/lang/String;
      //   40: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
      //   43: pop
      //   44: aload_0
      //   45: monitorexit
      //   46: aload_1
      //   47: ifnull -> 81
      //   50: aload_0
      //   51: aload_1
      //   52: invokevirtual b : (Ljava/lang/Object;)V
      //   55: aload_0
      //   56: monitorenter
      //   57: aload_0
      //   58: iconst_1
      //   59: putfield pm : Z
      //   62: aload_0
      //   63: monitorexit
      //   64: aload_0
      //   65: invokevirtual unregister : ()V
      //   68: return
      //   69: astore_1
      //   70: aload_0
      //   71: monitorexit
      //   72: aload_1
      //   73: athrow
      //   74: astore_1
      //   75: aload_0
      //   76: invokevirtual aL : ()V
      //   79: aload_1
      //   80: athrow
      //   81: aload_0
      //   82: invokevirtual aL : ()V
      //   85: goto -> 55
      //   88: astore_1
      //   89: aload_0
      //   90: monitorexit
      //   91: aload_1
      //   92: athrow
      // Exception table:
      //   from	to	target	type
      //   2	44	69	finally
      //   44	46	69	finally
      //   50	55	74	java/lang/RuntimeException
      //   57	64	88	finally
      //   70	72	69	finally
      //   89	91	88	finally
    }
    
    public void bS() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aconst_null
      //   4: putfield mListener : Ljava/lang/Object;
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	10	finally
      //   11	13	10	finally
    }
    
    public void unregister() {
      bS();
      synchronized (dw.c(this.pl)) {
        dw.c(this.pl).remove(this);
        return;
      } 
    }
  }
  
  public static final class c implements GoogleApiClient.ConnectionCallbacks {
    private final GooglePlayServicesClient.ConnectionCallbacks pn;
    
    public c(GooglePlayServicesClient.ConnectionCallbacks param1ConnectionCallbacks) {
      this.pn = param1ConnectionCallbacks;
    }
    
    public boolean equals(Object param1Object) {
      return (param1Object instanceof c) ? this.pn.equals(((c)param1Object).pn) : this.pn.equals(param1Object);
    }
    
    public void onConnected(Bundle param1Bundle) {
      this.pn.onConnected(param1Bundle);
    }
    
    public void onConnectionSuspended(int param1Int) {
      this.pn.onDisconnected();
    }
  }
  
  public abstract class d<TListener> extends b<TListener> {
    private final DataHolder nE;
    
    public d(dw this$0, TListener param1TListener, DataHolder param1DataHolder) {
      super(this$0, param1TListener);
      this.nE = param1DataHolder;
    }
    
    protected abstract void a(TListener param1TListener, DataHolder param1DataHolder);
    
    protected void aL() {
      if (this.nE != null)
        this.nE.close(); 
    }
    
    protected final void b(TListener param1TListener) {
      a(param1TListener, this.nE);
    }
  }
  
  public static final class e extends eb.a {
    private dw po;
    
    public e(dw param1dw) {
      this.po = param1dw;
    }
    
    public void b(int param1Int, IBinder param1IBinder, Bundle param1Bundle) {
      eg.b("onPostInitComplete can be called only once per call to getServiceFromBroker", this.po);
      this.po.a(param1Int, param1IBinder, param1Bundle);
      this.po = null;
    }
  }
  
  final class f implements ServiceConnection {
    f(dw this$0) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.pl.w(param1IBinder);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      dw.a(this.pl, (IInterface)null);
      dw.a(this.pl).J(1);
    }
  }
  
  public static final class g implements GoogleApiClient.OnConnectionFailedListener {
    private final GooglePlayServicesClient.OnConnectionFailedListener pp;
    
    public g(GooglePlayServicesClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this.pp = param1OnConnectionFailedListener;
    }
    
    public boolean equals(Object param1Object) {
      return (param1Object instanceof g) ? this.pp.equals(((g)param1Object).pp) : this.pp.equals(param1Object);
    }
    
    public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
      this.pp.onConnectionFailed(param1ConnectionResult);
    }
  }
  
  protected final class h extends b<Boolean> {
    public final Bundle pq;
    
    public final IBinder pr;
    
    public final int statusCode;
    
    public h(dw this$0, int param1Int, IBinder param1IBinder, Bundle param1Bundle) {
      super(this$0, Boolean.valueOf(true));
      this.statusCode = param1Int;
      this.pr = param1IBinder;
      this.pq = param1Bundle;
    }
    
    protected void aL() {}
    
    protected void b(Boolean param1Boolean) {
      if (param1Boolean == null)
        return; 
      switch (this.statusCode) {
        default:
          if (this.pq != null) {
            pendingIntent = (PendingIntent)this.pq.getParcelable("pendingIntent");
          } else {
            break;
          } 
          if (dw.e(this.pl) != null) {
            dy.s(dw.f(this.pl)).b(this.pl.am(), dw.e(this.pl));
            dw.a(this.pl, (dw.f)null);
          } 
          dw.a(this.pl, (IInterface)null);
          dw.a(this.pl).a(new ConnectionResult(this.statusCode, pendingIntent));
          return;
        case 0:
          try {
            String str = this.pr.getInterfaceDescriptor();
            if (this.pl.an().equals(str)) {
              dw.a(this.pl, this.pl.p(this.pr));
              if (dw.d(this.pl) != null) {
                dw.a(this.pl).bT();
                return;
              } 
            } 
          } catch (RemoteException remoteException) {}
          dy.s(dw.f(this.pl)).b(this.pl.am(), dw.e(this.pl));
          dw.a(this.pl, (dw.f)null);
          dw.a(this.pl, (IInterface)null);
          dw.a(this.pl).a(new ConnectionResult(8, null));
          return;
        case 10:
          throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
      } 
      PendingIntent pendingIntent = null;
      if (dw.e(this.pl) != null) {
        dy.s(dw.f(this.pl)).b(this.pl.am(), dw.e(this.pl));
        dw.a(this.pl, (dw.f)null);
      } 
      dw.a(this.pl, (IInterface)null);
      dw.a(this.pl).a(new ConnectionResult(this.statusCode, pendingIntent));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */