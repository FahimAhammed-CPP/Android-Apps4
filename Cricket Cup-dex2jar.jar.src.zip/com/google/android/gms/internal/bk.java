package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

public final class bk extends bs.a {
  private boolean gA = false;
  
  private boolean gB = false;
  
  private RelativeLayout gC;
  
  private final Activity gs;
  
  private bm gt;
  
  private bo gu;
  
  private cw gv;
  
  private b gw;
  
  private bp gx;
  
  private FrameLayout gy;
  
  private WebChromeClient.CustomViewCallback gz;
  
  public bk(Activity paramActivity) {
    this.gs = paramActivity;
  }
  
  private void Z() {
    if (this.gs.isFinishing() && !this.gB) {
      this.gB = true;
      if (this.gs.isFinishing()) {
        if (this.gv != null) {
          this.gv.az();
          this.gC.removeView((View)this.gv);
          if (this.gw != null) {
            this.gv.l(false);
            this.gw.gF.addView((View)this.gv, this.gw.index, this.gw.gE);
          } 
        } 
        if (this.gt != null && this.gt.gI != null) {
          this.gt.gI.A();
          return;
        } 
      } 
    } 
  }
  
  private static RelativeLayout.LayoutParams a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(paramInt3, paramInt4);
    layoutParams.setMargins(paramInt1, paramInt2, 0, 0);
    layoutParams.addRule(10);
    layoutParams.addRule(9);
    return layoutParams;
  }
  
  public static void a(Context paramContext, bm parambm) {
    Intent intent = new Intent();
    intent.setClassName(paramContext, "com.google.android.gms.ads.AdActivity");
    intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", parambm.ej.iM);
    bm.a(intent, parambm);
    intent.addFlags(524288);
    paramContext.startActivity(intent);
  }
  
  private void h(boolean paramBoolean) throws a {
    this.gs.requestWindowFeature(1);
    Window window = this.gs.getWindow();
    window.setFlags(1024, 1024);
    setRequestedOrientation(this.gt.orientation);
    if (Build.VERSION.SDK_INT >= 11) {
      ct.r("Enabling hardware acceleration on the AdActivity window.");
      cp.a(window);
    } 
    this.gC = new RelativeLayout((Context)this.gs);
    this.gC.setBackgroundColor(-16777216);
    this.gs.setContentView((View)this.gC);
    boolean bool = this.gt.gJ.aC().aJ();
    if (paramBoolean) {
      this.gv = cw.a((Context)this.gs, this.gt.gJ.y(), true, bool, (h)null, this.gt.ej);
      this.gv.aC().a(null, null, this.gt.gK, this.gt.gO, true);
      this.gv.aC().a(new cx.a(this) {
            public void a(cw param1cw) {
              param1cw.aA();
            }
          });
      if (this.gt.go != null) {
        this.gv.loadUrl(this.gt.go);
      } else if (this.gt.gN != null) {
        this.gv.loadDataWithBaseURL(this.gt.gL, this.gt.gN, "text/html", "UTF-8", null);
      } else {
        throw new a("No URL or HTML to display in ad overlay.");
      } 
    } else {
      this.gv = this.gt.gJ;
      this.gv.setContext((Context)this.gs);
    } 
    this.gv.a(this);
    this.gC.addView((View)this.gv, -1, -1);
    if (!paramBoolean)
      this.gv.aA(); 
    f(bool);
  }
  
  public bo W() {
    return this.gu;
  }
  
  public void X() {
    if (this.gt != null)
      setRequestedOrientation(this.gt.orientation); 
    if (this.gy != null) {
      this.gs.setContentView((View)this.gC);
      this.gy.removeAllViews();
      this.gy = null;
    } 
    if (this.gz != null) {
      this.gz.onCustomViewHidden();
      this.gz = null;
    } 
  }
  
  public void Y() {
    this.gC.removeView((View)this.gx);
    f(true);
  }
  
  public void a(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
    this.gy = new FrameLayout((Context)this.gs);
    this.gy.setBackgroundColor(-16777216);
    this.gy.addView(paramView, -1, -1);
    this.gs.setContentView((View)this.gy);
    this.gz = paramCustomViewCallback;
  }
  
  public void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.gu != null)
      this.gu.setLayoutParams((ViewGroup.LayoutParams)a(paramInt1, paramInt2, paramInt3, paramInt4)); 
  }
  
  public void c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.gu == null) {
      this.gu = new bo((Context)this.gs, this.gv);
      this.gC.addView((View)this.gu, 0, (ViewGroup.LayoutParams)a(paramInt1, paramInt2, paramInt3, paramInt4));
      this.gv.aC().m(false);
    } 
  }
  
  public void close() {
    this.gs.finish();
  }
  
  public void f(boolean paramBoolean) {
    byte b1;
    if (paramBoolean) {
      b1 = 50;
    } else {
      b1 = 32;
    } 
    this.gx = new bp(this.gs, b1);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(10);
    if (paramBoolean) {
      b1 = 11;
    } else {
      b1 = 9;
    } 
    layoutParams.addRule(b1);
    this.gx.g(this.gt.gM);
    this.gC.addView((View)this.gx, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public void g(boolean paramBoolean) {
    if (this.gx != null)
      this.gx.g(paramBoolean); 
  }
  
  public void onCreate(Bundle paramBundle) {
    boolean bool = false;
    if (paramBundle != null)
      bool = paramBundle.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false); 
    this.gA = bool;
    try {
      this.gt = bm.a(this.gs.getIntent());
      if (this.gt == null)
        throw new a("Could not get info for ad overlay."); 
    } catch (a a1) {
      ct.v(a1.getMessage());
      this.gs.finish();
      return;
    } 
    if (a1 == null) {
      if (this.gt.gI != null)
        this.gt.gI.B(); 
      if (this.gt.gP != 1 && this.gt.gH != null)
        this.gt.gH.w(); 
    } 
    switch (this.gt.gP) {
      case 1:
        h(false);
        return;
      case 2:
        this.gw = new b(this.gt.gJ);
        h(false);
        return;
      case 3:
        h(true);
        return;
      case 4:
        if (this.gA) {
          this.gs.finish();
          return;
        } 
        if (!bh.a((Context)this.gs, this.gt.gG, this.gt.gO)) {
          this.gs.finish();
          return;
        } 
        return;
    } 
    throw new a("Could not determine ad overlay type.");
  }
  
  public void onDestroy() {
    if (this.gu != null)
      this.gu.destroy(); 
    if (this.gv != null)
      this.gC.removeView((View)this.gv); 
    Z();
  }
  
  public void onPause() {
    if (this.gu != null)
      this.gu.pause(); 
    X();
    if (this.gv != null && (!this.gs.isFinishing() || this.gw == null))
      co.a(this.gv); 
    Z();
  }
  
  public void onRestart() {}
  
  public void onResume() {
    if (this.gt != null && this.gt.gP == 4)
      if (this.gA) {
        this.gs.finish();
      } else {
        this.gA = true;
      }  
    if (this.gv != null)
      co.b(this.gv); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    paramBundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.gA);
  }
  
  public void onStart() {}
  
  public void onStop() {
    Z();
  }
  
  public void setRequestedOrientation(int paramInt) {
    this.gs.setRequestedOrientation(paramInt);
  }
  
  private static final class a extends Exception {
    public a(String param1String) {
      super(param1String);
    }
  }
  
  private static final class b {
    public final ViewGroup.LayoutParams gE;
    
    public final ViewGroup gF;
    
    public final int index;
    
    public b(cw param1cw) throws bk.a {
      this.gE = param1cw.getLayoutParams();
      ViewParent viewParent = param1cw.getParent();
      if (viewParent instanceof ViewGroup) {
        this.gF = (ViewGroup)viewParent;
        this.index = this.gF.indexOfChild((View)param1cw);
        this.gF.removeView((View)param1cw);
        param1cw.l(true);
        return;
      } 
      throw new bk.a("Could not get the parent of the WebView for an overlay.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */