package com.google.android.gms.internal;

import android.os.Parcel;
import android.view.View;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class dt {
  private final View nu;
  
  private final a oX;
  
  public dt(String paramString1, Collection<String> paramCollection, int paramInt, View paramView, String paramString2) {
    this.oX = new a(paramString1, paramCollection, paramInt, paramString2);
    this.nu = paramView;
  }
  
  public String bF() {
    return this.oX.bF();
  }
  
  public int bG() {
    return this.oX.bG();
  }
  
  public List<String> bH() {
    return this.oX.bH();
  }
  
  public String[] bI() {
    return this.oX.bH().<String>toArray(new String[0]);
  }
  
  public String bJ() {
    return this.oX.bJ();
  }
  
  public View bK() {
    return this.nu;
  }
  
  public String getAccountName() {
    return this.oX.getAccountName();
  }
  
  public static final class a implements SafeParcelable {
    public static final ef CREATOR = new ef();
    
    private final String jG;
    
    private final int kg;
    
    private final int nt;
    
    private final String nv;
    
    private final List<String> oY = new ArrayList<String>();
    
    a(int param1Int1, String param1String1, List<String> param1List, int param1Int2, String param1String2) {
      this.kg = param1Int1;
      this.jG = param1String1;
      this.oY.addAll(param1List);
      this.nt = param1Int2;
      this.nv = param1String2;
    }
    
    public a(String param1String1, Collection<String> param1Collection, int param1Int, String param1String2) {
      this(3, param1String1, new ArrayList<String>(param1Collection), param1Int, param1String2);
    }
    
    public String bF() {
      return (this.jG != null) ? this.jG : "<<default account>>";
    }
    
    public int bG() {
      return this.nt;
    }
    
    public List<String> bH() {
      return new ArrayList<String>(this.oY);
    }
    
    public String bJ() {
      return this.nv;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String getAccountName() {
      return this.jG;
    }
    
    public int getVersionCode() {
      return this.kg;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      ef.a(this, param1Parcel, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */