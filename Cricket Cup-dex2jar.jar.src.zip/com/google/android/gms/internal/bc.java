package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;

public interface bc extends IInterface {
  void a(b paramb, v paramv, String paramString, bd parambd) throws RemoteException;
  
  void a(b paramb, v paramv, String paramString1, String paramString2, bd parambd) throws RemoteException;
  
  void a(b paramb, x paramx, v paramv, String paramString, bd parambd) throws RemoteException;
  
  void a(b paramb, x paramx, v paramv, String paramString1, String paramString2, bd parambd) throws RemoteException;
  
  void destroy() throws RemoteException;
  
  b getView() throws RemoteException;
  
  void showInterstitial() throws RemoteException;
  
  public static abstract class a extends Binder implements bc {
    public a() {
      attachInterface(this, "com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
    }
    
    public static bc j(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
      return (iInterface != null && iInterface instanceof bc) ? (bc)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      x x1;
      IBinder iBinder;
      b b1;
      b b3;
      v v2 = null;
      x x2 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          b3 = b.a.E(param1Parcel1.readStrongBinder());
          if (param1Parcel1.readInt() != 0) {
            x2 = x.CREATOR.b(param1Parcel1);
          } else {
            x2 = null;
          } 
          if (param1Parcel1.readInt() != 0) {
            v2 = v.CREATOR.a(param1Parcel1);
            a(b3, x2, v2, param1Parcel1.readString(), bd.a.k(param1Parcel1.readStrongBinder()));
            param1Parcel2.writeNoException();
            return true;
          } 
          v2 = null;
          a(b3, x2, v2, param1Parcel1.readString(), bd.a.k(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          b2 = getView();
          param1Parcel2.writeNoException();
          x1 = x2;
          if (b2 != null)
            iBinder = b2.asBinder(); 
          param1Parcel2.writeStrongBinder(iBinder);
          return true;
        case 3:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          b3 = b.a.E(iBinder.readStrongBinder());
          b1 = b2;
          if (iBinder.readInt() != 0)
            v1 = v.CREATOR.a((Parcel)iBinder); 
          a(b3, v1, iBinder.readString(), bd.a.k(iBinder.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 4:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          showInterstitial();
          param1Parcel2.writeNoException();
          return true;
        case 5:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          destroy();
          param1Parcel2.writeNoException();
          return true;
        case 6:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          b3 = b.a.E(iBinder.readStrongBinder());
          if (iBinder.readInt() != 0) {
            x x = x.CREATOR.b((Parcel)iBinder);
          } else {
            v1 = null;
          } 
          if (iBinder.readInt() != 0) {
            v v = v.CREATOR.a((Parcel)iBinder);
            a(b3, (x)v1, v, iBinder.readString(), iBinder.readString(), bd.a.k(iBinder.readStrongBinder()));
            param1Parcel2.writeNoException();
            return true;
          } 
          b2 = null;
          a(b3, (x)v1, (v)b2, iBinder.readString(), iBinder.readString(), bd.a.k(iBinder.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 7:
          break;
      } 
      iBinder.enforceInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
      b b2 = b.a.E(iBinder.readStrongBinder());
      if (iBinder.readInt() != 0) {
        v1 = v.CREATOR.a((Parcel)iBinder);
        a(b2, v1, iBinder.readString(), iBinder.readString(), bd.a.k(iBinder.readStrongBinder()));
        param1Parcel2.writeNoException();
        return true;
      } 
      v v1 = null;
      a(b2, v1, iBinder.readString(), iBinder.readString(), bd.a.k(iBinder.readStrongBinder()));
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements bc {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void a(b param2b, v param2v, String param2String, bd param2bd) throws RemoteException {
        b b1 = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          if (param2b != null) {
            iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          if (param2v != null) {
            parcel1.writeInt(1);
            param2v.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeString(param2String);
          param2b = b1;
          if (param2bd != null)
            iBinder = param2bd.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.dU.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(b param2b, v param2v, String param2String1, String param2String2, bd param2bd) throws RemoteException {
        b b1 = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          if (param2b != null) {
            iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          if (param2v != null) {
            parcel1.writeInt(1);
            param2v.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          param2b = b1;
          if (param2bd != null)
            iBinder = param2bd.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.dU.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(b param2b, x param2x, v param2v, String param2String, bd param2bd) throws RemoteException {
        b b1 = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          if (param2b != null) {
            iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          if (param2x != null) {
            parcel1.writeInt(1);
            param2x.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2v != null) {
            parcel1.writeInt(1);
            param2v.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeString(param2String);
          param2b = b1;
          if (param2bd != null)
            iBinder = param2bd.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(b param2b, x param2x, v param2v, String param2String1, String param2String2, bd param2bd) throws RemoteException {
        b b1 = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          if (param2b != null) {
            iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          if (param2x != null) {
            parcel1.writeInt(1);
            param2x.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2v != null) {
            parcel1.writeInt(1);
            param2v.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          param2b = b1;
          if (param2bd != null)
            iBinder = param2bd.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.dU.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void destroy() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          this.dU.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public b getView() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          this.dU.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return b.a.E(parcel2.readStrongBinder());
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void showInterstitial() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
          this.dU.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements bc {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void a(b param1b, v param1v, String param1String, bd param1bd) throws RemoteException {
      b b1 = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        if (param1b != null) {
          iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        if (param1v != null) {
          parcel1.writeInt(1);
          param1v.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeString(param1String);
        param1b = b1;
        if (param1bd != null)
          iBinder = param1bd.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.dU.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(b param1b, v param1v, String param1String1, String param1String2, bd param1bd) throws RemoteException {
      b b1 = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        if (param1b != null) {
          iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        if (param1v != null) {
          parcel1.writeInt(1);
          param1v.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        param1b = b1;
        if (param1bd != null)
          iBinder = param1bd.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.dU.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(b param1b, x param1x, v param1v, String param1String, bd param1bd) throws RemoteException {
      b b1 = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        if (param1b != null) {
          iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        if (param1x != null) {
          parcel1.writeInt(1);
          param1x.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1v != null) {
          parcel1.writeInt(1);
          param1v.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeString(param1String);
        param1b = b1;
        if (param1bd != null)
          iBinder = param1bd.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(b param1b, x param1x, v param1v, String param1String1, String param1String2, bd param1bd) throws RemoteException {
      b b1 = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        if (param1b != null) {
          iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        if (param1x != null) {
          parcel1.writeInt(1);
          param1x.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1v != null) {
          parcel1.writeInt(1);
          param1v.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        param1b = b1;
        if (param1bd != null)
          iBinder = param1bd.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.dU.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void destroy() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        this.dU.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public b getView() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        this.dU.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return b.a.E(parcel2.readStrongBinder());
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void showInterstitial() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
        this.dU.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */