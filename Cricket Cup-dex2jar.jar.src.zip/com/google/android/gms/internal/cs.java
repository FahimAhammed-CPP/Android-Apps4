package com.google.android.gms.internal;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public final class cs {
  public static final Handler iI = new Handler(Looper.getMainLooper());
  
  public static int a(Context paramContext, int paramInt) {
    return a(paramContext.getResources().getDisplayMetrics(), paramInt);
  }
  
  public static int a(DisplayMetrics paramDisplayMetrics, int paramInt) {
    return (int)TypedValue.applyDimension(1, paramInt, paramDisplayMetrics);
  }
  
  public static void a(ViewGroup paramViewGroup, x paramx, String paramString) {
    a(paramViewGroup, paramx, paramString, -16777216, -1);
  }
  
  private static void a(ViewGroup paramViewGroup, x paramx, String paramString, int paramInt1, int paramInt2) {
    if (paramViewGroup.getChildCount() != 0)
      return; 
    Context context = paramViewGroup.getContext();
    TextView textView = new TextView(context);
    textView.setGravity(17);
    textView.setText(paramString);
    textView.setTextColor(paramInt1);
    textView.setBackgroundColor(paramInt2);
    FrameLayout frameLayout = new FrameLayout(context);
    frameLayout.setBackgroundColor(paramInt1);
    paramInt1 = a(context, 3);
    frameLayout.addView((View)textView, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(paramx.widthPixels - paramInt1, paramx.heightPixels - paramInt1, 17));
    paramViewGroup.addView((View)frameLayout, paramx.widthPixels, paramx.heightPixels);
  }
  
  public static void a(ViewGroup paramViewGroup, x paramx, String paramString1, String paramString2) {
    ct.v(paramString2);
    a(paramViewGroup, paramx, paramString1, -65536, -16777216);
  }
  
  public static boolean ax() {
    return Build.DEVICE.startsWith("generic");
  }
  
  public static boolean ay() {
    return (Looper.myLooper() == Looper.getMainLooper());
  }
  
  public static String l(Context paramContext) {
    String str = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
    if (str == null || ax())
      str = "emulator"; 
    return q(str);
  }
  
  public static String q(String paramString) {
    int i = 0;
    while (i < 2) {
      try {
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(paramString.getBytes());
        return String.format(Locale.US, "%032X", new Object[] { new BigInteger(1, messageDigest.digest()) });
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        i++;
      } 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */