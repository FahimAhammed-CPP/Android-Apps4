package com.google.android.gms.internal;

import java.util.Map;

public interface an {
  void a(cw paramcw, Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */