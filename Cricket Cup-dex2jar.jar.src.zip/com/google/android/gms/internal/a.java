package com.google.android.gms.internal;

import android.util.Base64;

class a implements j {
  public String a(byte[] paramArrayOfbyte, boolean paramBoolean) {
    if (paramBoolean) {
      byte b1 = 11;
      return Base64.encodeToString(paramArrayOfbyte, b1);
    } 
    byte b = 2;
    return Base64.encodeToString(paramArrayOfbyte, b);
  }
  
  public byte[] a(String paramString, boolean paramBoolean) throws IllegalArgumentException {
    if (paramBoolean) {
      byte b1 = 11;
      return Base64.decode(paramString, b1);
    } 
    byte b = 2;
    return Base64.decode(paramString, b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */