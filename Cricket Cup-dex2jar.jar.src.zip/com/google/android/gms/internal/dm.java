package com.google.android.gms.internal;

import java.io.IOException;

public interface dm {
  void a(String paramString1, String paramString2, long paramLong, String paramString3) throws IOException;
  
  long aR();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */