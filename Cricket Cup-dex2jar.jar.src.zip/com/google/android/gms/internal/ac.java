package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;

public interface ac extends IInterface {
  void H() throws RemoteException;
  
  void a(ab paramab) throws RemoteException;
  
  void a(ae paramae) throws RemoteException;
  
  void a(x paramx) throws RemoteException;
  
  boolean a(v paramv) throws RemoteException;
  
  void destroy() throws RemoteException;
  
  boolean isReady() throws RemoteException;
  
  void pause() throws RemoteException;
  
  void resume() throws RemoteException;
  
  void showInterstitial() throws RemoteException;
  
  void stopLoading() throws RemoteException;
  
  b x() throws RemoteException;
  
  x y() throws RemoteException;
  
  public static abstract class a extends Binder implements ac {
    public a() {
      attachInterface(this, "com.google.android.gms.ads.internal.client.IAdManager");
    }
    
    public static ac f(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      return (iInterface != null && iInterface instanceof ac) ? (ac)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      IBinder iBinder;
      x x1;
      boolean bool1;
      b b1;
      x x2;
      b b2 = null;
      v v2 = null;
      Parcel parcel = null;
      boolean bool = false;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.client.IAdManager");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          b2 = x();
          param1Parcel2.writeNoException();
          param1Parcel1 = parcel;
          if (b2 != null)
            iBinder = b2.asBinder(); 
          param1Parcel2.writeStrongBinder(iBinder);
          return true;
        case 2:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          destroy();
          param1Parcel2.writeNoException();
          return true;
        case 3:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          bool1 = isReady();
          param1Parcel2.writeNoException();
          if (bool1) {
            param1Int1 = 1;
            param1Parcel2.writeInt(param1Int1);
            return true;
          } 
          param1Int1 = 0;
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 4:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          b1 = b2;
          if (iBinder.readInt() != 0)
            v1 = v.CREATOR.a((Parcel)iBinder); 
          bool1 = a(v1);
          param1Parcel2.writeNoException();
          param1Int1 = bool;
          if (bool1)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 5:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          pause();
          param1Parcel2.writeNoException();
          return true;
        case 6:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          resume();
          param1Parcel2.writeNoException();
          return true;
        case 7:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          a(ab.a.e(iBinder.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 8:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          a(ae.a.h(iBinder.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 9:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          showInterstitial();
          param1Parcel2.writeNoException();
          return true;
        case 10:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          stopLoading();
          param1Parcel2.writeNoException();
          return true;
        case 11:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          H();
          param1Parcel2.writeNoException();
          return true;
        case 12:
          iBinder.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
          x1 = y();
          param1Parcel2.writeNoException();
          if (x1 != null) {
            param1Parcel2.writeInt(1);
            x1.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        case 13:
          break;
      } 
      x1.enforceInterface("com.google.android.gms.ads.internal.client.IAdManager");
      v v1 = v2;
      if (x1.readInt() != 0)
        x2 = x.CREATOR.b((Parcel)x1); 
      a(x2);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements ac {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void H() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(11, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(ab param2ab) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          if (param2ab != null) {
            IBinder iBinder = param2ab.asBinder();
          } else {
            param2ab = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ab);
          this.dU.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(ae param2ae) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          if (param2ae != null) {
            IBinder iBinder = param2ae.asBinder();
          } else {
            param2ae = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ae);
          this.dU.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(x param2x) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          if (param2x != null) {
            parcel1.writeInt(1);
            param2x.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(13, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean a(v param2v) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          if (param2v != null) {
            parcel1.writeInt(1);
            param2v.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i == 0)
            bool = false; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void destroy() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isReady() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void pause() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void resume() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void showInterstitial() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void stopLoading() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(10, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public b x() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return b.a.E(parcel2.readStrongBinder());
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public x y() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
          this.dU.transact(12, parcel1, parcel2, 0);
          parcel2.readException();
          if (parcel2.readInt() != 0)
            return x.CREATOR.b(parcel2); 
          return null;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements ac {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void H() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(11, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(ab param1ab) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        if (param1ab != null) {
          IBinder iBinder = param1ab.asBinder();
        } else {
          param1ab = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ab);
        this.dU.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(ae param1ae) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        if (param1ae != null) {
          IBinder iBinder = param1ae.asBinder();
        } else {
          param1ae = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ae);
        this.dU.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(x param1x) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        if (param1x != null) {
          parcel1.writeInt(1);
          param1x.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(13, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean a(v param1v) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        if (param1v != null) {
          parcel1.writeInt(1);
          param1v.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void destroy() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isReady() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void pause() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void resume() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void showInterstitial() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void stopLoading() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(10, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public b x() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return b.a.E(parcel2.readStrongBinder());
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public x y() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManager");
        this.dU.transact(12, parcel1, parcel2, 0);
        parcel2.readException();
        if (parcel2.readInt() != 0)
          return x.CREATOR.b(parcel2); 
        return null;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */