package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.data.DataHolder;

public interface dd extends IInterface {
  void a(int paramInt, DataHolder paramDataHolder) throws RemoteException;
  
  void a(DataHolder paramDataHolder) throws RemoteException;
  
  void onSignOutComplete() throws RemoteException;
  
  void onStateDeleted(int paramInt1, int paramInt2) throws RemoteException;
  
  void p(int paramInt) throws RemoteException;
  
  public static abstract class a extends Binder implements dd {
    public a() {
      attachInterface(this, "com.google.android.gms.appstate.internal.IAppStateCallbacks");
    }
    
    public static dd s(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
      return (iInterface != null && iInterface instanceof dd) ? (dd)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      DataHolder dataHolder2 = null;
      DataHolder dataHolder1 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          return true;
        case 5001:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          param1Int1 = param1Parcel1.readInt();
          if (param1Parcel1.readInt() != 0)
            dataHolder1 = DataHolder.CREATOR.createFromParcel(param1Parcel1); 
          a(param1Int1, dataHolder1);
          param1Parcel2.writeNoException();
          return true;
        case 5002:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          dataHolder1 = dataHolder2;
          if (param1Parcel1.readInt() != 0)
            dataHolder1 = DataHolder.CREATOR.createFromParcel(param1Parcel1); 
          a(dataHolder1);
          param1Parcel2.writeNoException();
          return true;
        case 5003:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          onStateDeleted(param1Parcel1.readInt(), param1Parcel1.readInt());
          param1Parcel2.writeNoException();
          return true;
        case 5004:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          onSignOutComplete();
          param1Parcel2.writeNoException();
          return true;
        case 5005:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateCallbacks");
      p(param1Parcel1.readInt());
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements dd {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void a(int param2Int, DataHolder param2DataHolder) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          parcel1.writeInt(param2Int);
          if (param2DataHolder != null) {
            parcel1.writeInt(1);
            param2DataHolder.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(5001, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(DataHolder param2DataHolder) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          if (param2DataHolder != null) {
            parcel1.writeInt(1);
            param2DataHolder.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(5002, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void onSignOutComplete() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          this.dU.transact(5004, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onStateDeleted(int param2Int1, int param2Int2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          this.dU.transact(5003, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void p(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
          parcel1.writeInt(param2Int);
          this.dU.transact(5005, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements dd {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void a(int param1Int, DataHolder param1DataHolder) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
        parcel1.writeInt(param1Int);
        if (param1DataHolder != null) {
          parcel1.writeInt(1);
          param1DataHolder.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(5001, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(DataHolder param1DataHolder) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
        if (param1DataHolder != null) {
          parcel1.writeInt(1);
          param1DataHolder.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(5002, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void onSignOutComplete() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
        this.dU.transact(5004, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onStateDeleted(int param1Int1, int param1Int2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        this.dU.transact(5003, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void p(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateCallbacks");
        parcel1.writeInt(param1Int);
        this.dU.transact(5005, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */