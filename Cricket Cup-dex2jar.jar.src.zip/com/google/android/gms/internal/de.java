package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface de extends IInterface {
  void a(dd paramdd) throws RemoteException;
  
  void a(dd paramdd, int paramInt) throws RemoteException;
  
  void a(dd paramdd, int paramInt, String paramString, byte[] paramArrayOfbyte) throws RemoteException;
  
  void a(dd paramdd, int paramInt, byte[] paramArrayOfbyte) throws RemoteException;
  
  void b(dd paramdd) throws RemoteException;
  
  void b(dd paramdd, int paramInt) throws RemoteException;
  
  void c(dd paramdd) throws RemoteException;
  
  int getMaxNumKeys() throws RemoteException;
  
  int getMaxStateSize() throws RemoteException;
  
  public static abstract class a extends Binder implements de {
    public static de t(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.appstate.internal.IAppStateService");
      return (iInterface != null && iInterface instanceof de) ? (de)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.appstate.internal.IAppStateService");
          return true;
        case 5001:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          param1Int1 = getMaxStateSize();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 5002:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          param1Int1 = getMaxNumKeys();
          param1Parcel2.writeNoException();
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 5003:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          a(dd.a.s(param1Parcel1.readStrongBinder()), param1Parcel1.readInt(), param1Parcel1.createByteArray());
          param1Parcel2.writeNoException();
          return true;
        case 5004:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          a(dd.a.s(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
          param1Parcel2.writeNoException();
          return true;
        case 5005:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          a(dd.a.s(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 5006:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          a(dd.a.s(param1Parcel1.readStrongBinder()), param1Parcel1.readInt(), param1Parcel1.readString(), param1Parcel1.createByteArray());
          param1Parcel2.writeNoException();
          return true;
        case 5007:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          b(dd.a.s(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
          param1Parcel2.writeNoException();
          return true;
        case 5008:
          param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
          b(dd.a.s(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 5009:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.appstate.internal.IAppStateService");
      c(dd.a.s(param1Parcel1.readStrongBinder()));
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements de {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void a(dd param2dd) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          this.dU.transact(5005, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(dd param2dd, int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          parcel1.writeInt(param2Int);
          this.dU.transact(5004, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(dd param2dd, int param2Int, String param2String, byte[] param2ArrayOfbyte) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          parcel1.writeInt(param2Int);
          parcel1.writeString(param2String);
          parcel1.writeByteArray(param2ArrayOfbyte);
          this.dU.transact(5006, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(dd param2dd, int param2Int, byte[] param2ArrayOfbyte) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          parcel1.writeInt(param2Int);
          parcel1.writeByteArray(param2ArrayOfbyte);
          this.dU.transact(5003, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void b(dd param2dd) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          this.dU.transact(5008, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void b(dd param2dd, int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          parcel1.writeInt(param2Int);
          this.dU.transact(5007, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void c(dd param2dd) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          if (param2dd != null) {
            IBinder iBinder = param2dd.asBinder();
          } else {
            param2dd = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2dd);
          this.dU.transact(5009, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getMaxNumKeys() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          this.dU.transact(5002, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public int getMaxStateSize() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
          this.dU.transact(5001, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readInt();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements de {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void a(dd param1dd) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        this.dU.transact(5005, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(dd param1dd, int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        parcel1.writeInt(param1Int);
        this.dU.transact(5004, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(dd param1dd, int param1Int, String param1String, byte[] param1ArrayOfbyte) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        parcel1.writeInt(param1Int);
        parcel1.writeString(param1String);
        parcel1.writeByteArray(param1ArrayOfbyte);
        this.dU.transact(5006, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(dd param1dd, int param1Int, byte[] param1ArrayOfbyte) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        parcel1.writeInt(param1Int);
        parcel1.writeByteArray(param1ArrayOfbyte);
        this.dU.transact(5003, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void b(dd param1dd) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        this.dU.transact(5008, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void b(dd param1dd, int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        parcel1.writeInt(param1Int);
        this.dU.transact(5007, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void c(dd param1dd) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        if (param1dd != null) {
          IBinder iBinder = param1dd.asBinder();
        } else {
          param1dd = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1dd);
        this.dU.transact(5009, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getMaxNumKeys() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        this.dU.transact(5002, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public int getMaxStateSize() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.appstate.internal.IAppStateService");
        this.dU.transact(5001, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readInt();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\de.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */