package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;

public interface ad extends IInterface {
  IBinder a(b paramb, x paramx, String paramString, bb parambb, int paramInt) throws RemoteException;
  
  public static abstract class a extends Binder implements ad {
    public static ad g(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManagerCreator");
      return (iInterface != null && iInterface instanceof ad) ? (ad)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.client.IAdManagerCreator");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdManagerCreator");
      b b = b.a.E(param1Parcel1.readStrongBinder());
      if (param1Parcel1.readInt() != 0) {
        x x1 = x.CREATOR.b(param1Parcel1);
        iBinder = a(b, x1, param1Parcel1.readString(), bb.a.i(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
        param1Parcel2.writeNoException();
        param1Parcel2.writeStrongBinder(iBinder);
        return true;
      } 
      x x = null;
      IBinder iBinder = a(b, x, iBinder.readString(), bb.a.i(iBinder.readStrongBinder()), iBinder.readInt());
      param1Parcel2.writeNoException();
      param1Parcel2.writeStrongBinder(iBinder);
      return true;
    }
    
    private static class a implements ad {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public IBinder a(b param2b, x param2x, String param2String, bb param2bb, int param2Int) throws RemoteException {
        b b1 = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManagerCreator");
          if (param2b != null) {
            iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          if (param2x != null) {
            parcel1.writeInt(1);
            param2x.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeString(param2String);
          param2b = b1;
          if (param2bb != null)
            iBinder = param2bb.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          parcel1.writeInt(param2Int);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          IBinder iBinder = parcel2.readStrongBinder();
          return iBinder;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
    }
  }
  
  private static class a implements ad {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public IBinder a(b param1b, x param1x, String param1String, bb param1bb, int param1Int) throws RemoteException {
      b b1 = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManagerCreator");
        if (param1b != null) {
          iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        if (param1x != null) {
          parcel1.writeInt(1);
          param1x.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeString(param1String);
        param1b = b1;
        if (param1bb != null)
          iBinder = param1bb.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        parcel1.writeInt(param1Int);
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        IBinder iBinder = parcel2.readStrongBinder();
        return iBinder;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */