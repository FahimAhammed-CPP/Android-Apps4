package com.google.android.gms.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.CharBuffer;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class co {
  private static final Object hC = new Object();
  
  private static boolean iD = true;
  
  private static String iE;
  
  private static boolean iF = false;
  
  public static String a(Readable paramReadable) throws IOException {
    StringBuilder stringBuilder = new StringBuilder();
    CharBuffer charBuffer = CharBuffer.allocate(2048);
    while (true) {
      int i = paramReadable.read(charBuffer);
      if (i != -1) {
        charBuffer.flip();
        stringBuilder.append(charBuffer, 0, i);
        continue;
      } 
      return stringBuilder.toString();
    } 
  }
  
  private static JSONArray a(Collection<?> paramCollection) throws JSONException {
    JSONArray jSONArray = new JSONArray();
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext())
      a(jSONArray, iterator.next()); 
    return jSONArray;
  }
  
  private static JSONArray a(Object[] paramArrayOfObject) throws JSONException {
    JSONArray jSONArray = new JSONArray();
    int j = paramArrayOfObject.length;
    for (int i = 0; i < j; i++)
      a(jSONArray, paramArrayOfObject[i]); 
    return jSONArray;
  }
  
  private static JSONObject a(Bundle paramBundle) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    for (String str : paramBundle.keySet())
      a(jSONObject, str, paramBundle.get(str)); 
    return jSONObject;
  }
  
  public static void a(Context paramContext, String paramString, WebSettings paramWebSettings) {
    paramWebSettings.setUserAgentString(b(paramContext, paramString));
  }
  
  public static void a(Context paramContext, String paramString, List<String> paramList) {
    Iterator<String> iterator = paramList.iterator();
    while (iterator.hasNext())
      (new cr(paramContext, paramString, iterator.next())).start(); 
  }
  
  public static void a(Context paramContext, String paramString, boolean paramBoolean, HttpURLConnection paramHttpURLConnection) {
    paramHttpURLConnection.setConnectTimeout(60000);
    paramHttpURLConnection.setInstanceFollowRedirects(paramBoolean);
    paramHttpURLConnection.setReadTimeout(60000);
    paramHttpURLConnection.setRequestProperty("User-Agent", b(paramContext, paramString));
    paramHttpURLConnection.setUseCaches(false);
  }
  
  public static void a(WebView paramWebView) {
    if (Build.VERSION.SDK_INT >= 11)
      cp.a(paramWebView); 
  }
  
  private static void a(JSONArray paramJSONArray, Object paramObject) throws JSONException {
    if (paramObject instanceof Bundle) {
      paramJSONArray.put(a((Bundle)paramObject));
      return;
    } 
    if (paramObject instanceof Map) {
      paramJSONArray.put(m((Map<String, ?>)paramObject));
      return;
    } 
    if (paramObject instanceof Collection) {
      paramJSONArray.put(a((Collection)paramObject));
      return;
    } 
    if (paramObject instanceof Object[]) {
      paramJSONArray.put(a((Object[])paramObject));
      return;
    } 
    paramJSONArray.put(paramObject);
  }
  
  private static void a(JSONObject paramJSONObject, String paramString, Object paramObject) throws JSONException {
    if (paramObject instanceof Bundle) {
      paramJSONObject.put(paramString, a((Bundle)paramObject));
      return;
    } 
    if (paramObject instanceof Map) {
      paramJSONObject.put(paramString, m((Map<String, ?>)paramObject));
      return;
    } 
    if (paramObject instanceof Collection) {
      if (paramString == null)
        paramString = "null"; 
      paramJSONObject.put(paramString, a((Collection)paramObject));
      return;
    } 
    if (paramObject instanceof Object[]) {
      paramJSONObject.put(paramString, a(Arrays.asList((Object[])paramObject)));
      return;
    } 
    paramJSONObject.put(paramString, paramObject);
  }
  
  public static boolean a(PackageManager paramPackageManager, String paramString1, String paramString2) {
    return (paramPackageManager.checkPermission(paramString2, paramString1) == 0);
  }
  
  public static boolean a(ClassLoader paramClassLoader, Class<?> paramClass, String paramString) {
    try {
      return paramClass.isAssignableFrom(Class.forName(paramString, false, paramClassLoader));
    } catch (Throwable throwable) {
      return false;
    } 
  }
  
  public static boolean at() {
    return iD;
  }
  
  public static int au() {
    return (Build.VERSION.SDK_INT >= 9) ? 6 : 0;
  }
  
  public static int av() {
    return (Build.VERSION.SDK_INT >= 9) ? 7 : 1;
  }
  
  private static String b(Context paramContext, String paramString) {
    synchronized (hC) {
      if (iE != null) {
        str = iE;
        return str;
      } 
      if (Build.VERSION.SDK_INT >= 17) {
        iE = cq.getDefaultUserAgent((Context)str);
        iE += " (Mobile; " + paramString + ")";
        str = iE;
        return str;
      } 
    } 
    if (!cs.ay()) {
      cs.iI.post(new Runnable(paramContext) {
            public void run() {
              synchronized (co.aw()) {
                co.p(co.k(this.hF));
                co.aw().notifyAll();
                return;
              } 
            }
          });
      while (true) {
        str = iE;
        if (str == null) {
          try {
            hC.wait();
          } catch (InterruptedException interruptedException) {
            String str1 = iE;
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
            return str1;
          } 
          continue;
        } 
        iE += " (Mobile; " + paramString + ")";
        str = iE;
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
        return str;
      } 
    } 
    iE = j((Context)str);
    iE += " (Mobile; " + paramString + ")";
    String str = iE;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return str;
  }
  
  public static void b(WebView paramWebView) {
    if (Build.VERSION.SDK_INT >= 11)
      cp.b(paramWebView); 
  }
  
  public static boolean h(Context paramContext) {
    boolean bool;
    Intent intent = new Intent();
    intent.setClassName(paramContext, "com.google.android.gms.ads.AdActivity");
    ResolveInfo resolveInfo = paramContext.getPackageManager().resolveActivity(intent, 65536);
    if (resolveInfo == null || resolveInfo.activityInfo == null) {
      ct.v("Could not find com.google.android.gms.ads.AdActivity, please make sure it is declared in AndroidManifest.xml.");
      return false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x10) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "keyboard" }));
      bool = false;
    } else {
      bool = true;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x20) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "keyboardHidden" }));
      bool = false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x80) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "orientation" }));
      bool = false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x100) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "screenLayout" }));
      bool = false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x200) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "uiMode" }));
      bool = false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x400) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "screenSize" }));
      bool = false;
    } 
    if ((resolveInfo.activityInfo.configChanges & 0x800) == 0) {
      ct.v(String.format("com.google.android.gms.ads.AdActivity requires the android:configChanges value to contain \"%s\".", new Object[] { "smallestScreenSize" }));
      return false;
    } 
    return bool;
  }
  
  public static void i(Context paramContext) {
    if (iF)
      return; 
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.USER_PRESENT");
    intentFilter.addAction("android.intent.action.SCREEN_OFF");
    paramContext.getApplicationContext().registerReceiver(new a(), intentFilter);
    iF = true;
  }
  
  private static String j(Context paramContext) {
    return (new WebView(paramContext)).getSettings().getUserAgentString();
  }
  
  public static JSONObject m(Map<String, ?> paramMap) throws JSONException {
    JSONObject jSONObject;
    try {
      jSONObject = new JSONObject();
      for (String str : paramMap.keySet())
        a(jSONObject, str, paramMap.get(str)); 
    } catch (ClassCastException classCastException) {
      throw new JSONException("Could not convert map to JSON: " + classCastException.getMessage());
    } 
    return jSONObject;
  }
  
  public static String o(String paramString) {
    return Uri.parse(paramString).buildUpon().query(null).build().toString();
  }
  
  private static final class a extends BroadcastReceiver {
    private a() {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if ("android.intent.action.USER_PRESENT".equals(param1Intent.getAction())) {
        co.k(true);
        return;
      } 
      if ("android.intent.action.SCREEN_OFF".equals(param1Intent.getAction())) {
        co.k(false);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\co.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */