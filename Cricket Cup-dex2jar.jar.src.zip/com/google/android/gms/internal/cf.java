package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.text.TextUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONException;

public final class cf {
  private static final SimpleDateFormat hJ = new SimpleDateFormat("yyyyMMdd");
  
  public static cb a(Context paramContext, bz parambz, String paramString) {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: aload_2
    //   5: invokespecial <init> : (Ljava/lang/String;)V
    //   8: astore #14
    //   10: aload #14
    //   12: ldc 'ad_base_url'
    //   14: aconst_null
    //   15: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   18: astore_2
    //   19: aload #14
    //   21: ldc 'ad_url'
    //   23: aconst_null
    //   24: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   27: astore #10
    //   29: aload #14
    //   31: ldc 'ad_size'
    //   33: aconst_null
    //   34: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   37: astore #13
    //   39: aload #14
    //   41: ldc 'ad_html'
    //   43: aconst_null
    //   44: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   47: astore #9
    //   49: aload #14
    //   51: ldc 'interstitial_timeout'
    //   53: invokevirtual has : (Ljava/lang/String;)Z
    //   56: ifeq -> 578
    //   59: aload #14
    //   61: ldc 'interstitial_timeout'
    //   63: invokevirtual getDouble : (Ljava/lang/String;)D
    //   66: ldc2_w 1000.0
    //   69: dmul
    //   70: d2l
    //   71: lstore #5
    //   73: aload #14
    //   75: ldc 'orientation'
    //   77: aconst_null
    //   78: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   81: astore #11
    //   83: iconst_m1
    //   84: istore_3
    //   85: ldc 'portrait'
    //   87: aload #11
    //   89: invokevirtual equals : (Ljava/lang/Object;)Z
    //   92: ifeq -> 128
    //   95: invokestatic av : ()I
    //   98: istore_3
    //   99: aload #9
    //   101: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   104: ifne -> 145
    //   107: aload_2
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifeq -> 572
    //   114: ldc 'Could not parse the mediation config: Missing required ad_base_url field'
    //   116: invokestatic v : (Ljava/lang/String;)V
    //   119: new com/google/android/gms/internal/cb
    //   122: dup
    //   123: iconst_0
    //   124: invokespecial <init> : (I)V
    //   127: areturn
    //   128: ldc 'landscape'
    //   130: aload #11
    //   132: invokevirtual equals : (Ljava/lang/Object;)Z
    //   135: ifeq -> 99
    //   138: invokestatic au : ()I
    //   141: istore_3
    //   142: goto -> 99
    //   145: aload #10
    //   147: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   150: ifne -> 252
    //   153: aload_0
    //   154: aload_1
    //   155: getfield ej : Lcom/google/android/gms/internal/cu;
    //   158: getfield iJ : Ljava/lang/String;
    //   161: aload #10
    //   163: invokestatic a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/internal/cb;
    //   166: astore #10
    //   168: aload #10
    //   170: getfield gL : Ljava/lang/String;
    //   173: astore_2
    //   174: aload #10
    //   176: getfield hw : Ljava/lang/String;
    //   179: astore #9
    //   181: aload #14
    //   183: ldc 'click_urls'
    //   185: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   188: astore #11
    //   190: aload #10
    //   192: ifnonnull -> 303
    //   195: aconst_null
    //   196: astore_0
    //   197: aload #11
    //   199: ifnull -> 566
    //   202: aload_0
    //   203: astore_1
    //   204: aload_0
    //   205: ifnonnull -> 586
    //   208: new java/util/LinkedList
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore_1
    //   216: goto -> 586
    //   219: iload #4
    //   221: aload #11
    //   223: invokevirtual length : ()I
    //   226: if_icmpge -> 592
    //   229: aload_1
    //   230: aload #11
    //   232: iload #4
    //   234: invokevirtual getString : (I)Ljava/lang/String;
    //   237: invokeinterface add : (Ljava/lang/Object;)Z
    //   242: pop
    //   243: iload #4
    //   245: iconst_1
    //   246: iadd
    //   247: istore #4
    //   249: goto -> 219
    //   252: ldc 'Could not parse the mediation config: Missing required ad_html or ad_url field.'
    //   254: invokestatic v : (Ljava/lang/String;)V
    //   257: new com/google/android/gms/internal/cb
    //   260: dup
    //   261: iconst_0
    //   262: invokespecial <init> : (I)V
    //   265: astore_0
    //   266: aload_0
    //   267: areturn
    //   268: astore_0
    //   269: new java/lang/StringBuilder
    //   272: dup
    //   273: invokespecial <init> : ()V
    //   276: ldc 'Could not parse the mediation config: '
    //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   281: aload_0
    //   282: invokevirtual getMessage : ()Ljava/lang/String;
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: invokevirtual toString : ()Ljava/lang/String;
    //   291: invokestatic v : (Ljava/lang/String;)V
    //   294: new com/google/android/gms/internal/cb
    //   297: dup
    //   298: iconst_0
    //   299: invokespecial <init> : (I)V
    //   302: areturn
    //   303: aload #10
    //   305: getfield fK : Ljava/util/List;
    //   308: astore_0
    //   309: goto -> 197
    //   312: aload #14
    //   314: ldc 'impression_urls'
    //   316: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   319: astore #12
    //   321: aload #10
    //   323: ifnonnull -> 383
    //   326: aconst_null
    //   327: astore_0
    //   328: aload #12
    //   330: ifnull -> 560
    //   333: aload_0
    //   334: astore_1
    //   335: aload_0
    //   336: ifnonnull -> 598
    //   339: new java/util/LinkedList
    //   342: dup
    //   343: invokespecial <init> : ()V
    //   346: astore_1
    //   347: goto -> 598
    //   350: iload #4
    //   352: aload #12
    //   354: invokevirtual length : ()I
    //   357: if_icmpge -> 604
    //   360: aload_1
    //   361: aload #12
    //   363: iload #4
    //   365: invokevirtual getString : (I)Ljava/lang/String;
    //   368: invokeinterface add : (Ljava/lang/Object;)Z
    //   373: pop
    //   374: iload #4
    //   376: iconst_1
    //   377: iadd
    //   378: istore #4
    //   380: goto -> 350
    //   383: aload #10
    //   385: getfield fL : Ljava/util/List;
    //   388: astore_0
    //   389: goto -> 328
    //   392: aload #14
    //   394: ldc 'manual_impression_urls'
    //   396: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   399: astore #14
    //   401: aload #10
    //   403: ifnonnull -> 463
    //   406: aconst_null
    //   407: astore_0
    //   408: aload #14
    //   410: ifnull -> 557
    //   413: aload_0
    //   414: astore_1
    //   415: aload_0
    //   416: ifnonnull -> 610
    //   419: new java/util/LinkedList
    //   422: dup
    //   423: invokespecial <init> : ()V
    //   426: astore_1
    //   427: goto -> 610
    //   430: iload #4
    //   432: aload #14
    //   434: invokevirtual length : ()I
    //   437: if_icmpge -> 616
    //   440: aload_1
    //   441: aload #14
    //   443: iload #4
    //   445: invokevirtual getString : (I)Ljava/lang/String;
    //   448: invokeinterface add : (Ljava/lang/Object;)Z
    //   453: pop
    //   454: iload #4
    //   456: iconst_1
    //   457: iadd
    //   458: istore #4
    //   460: goto -> 430
    //   463: aload #10
    //   465: getfield hA : Ljava/util/List;
    //   468: astore_0
    //   469: goto -> 408
    //   472: lload #5
    //   474: lstore #7
    //   476: iload_3
    //   477: istore #4
    //   479: aload #10
    //   481: ifnull -> 526
    //   484: aload #10
    //   486: getfield orientation : I
    //   489: iconst_m1
    //   490: if_icmpeq -> 499
    //   493: aload #10
    //   495: getfield orientation : I
    //   498: istore_3
    //   499: lload #5
    //   501: lstore #7
    //   503: iload_3
    //   504: istore #4
    //   506: aload #10
    //   508: getfield hx : J
    //   511: lconst_0
    //   512: lcmp
    //   513: ifle -> 526
    //   516: aload #10
    //   518: getfield hx : J
    //   521: lstore #7
    //   523: iload_3
    //   524: istore #4
    //   526: new com/google/android/gms/internal/cb
    //   529: dup
    //   530: aload_2
    //   531: aload #9
    //   533: aload #11
    //   535: aload #12
    //   537: lload #7
    //   539: iconst_0
    //   540: ldc2_w -1
    //   543: aload_0
    //   544: ldc2_w -1
    //   547: iload #4
    //   549: aload #13
    //   551: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;JZJLjava/util/List;JILjava/lang/String;)V
    //   554: astore_0
    //   555: aload_0
    //   556: areturn
    //   557: goto -> 472
    //   560: aload_0
    //   561: astore #12
    //   563: goto -> 392
    //   566: aload_0
    //   567: astore #11
    //   569: goto -> 312
    //   572: aconst_null
    //   573: astore #10
    //   575: goto -> 181
    //   578: ldc2_w -1
    //   581: lstore #5
    //   583: goto -> 73
    //   586: iconst_0
    //   587: istore #4
    //   589: goto -> 219
    //   592: aload_1
    //   593: astore #11
    //   595: goto -> 312
    //   598: iconst_0
    //   599: istore #4
    //   601: goto -> 350
    //   604: aload_1
    //   605: astore #12
    //   607: goto -> 392
    //   610: iconst_0
    //   611: istore #4
    //   613: goto -> 430
    //   616: aload_1
    //   617: astore_0
    //   618: goto -> 472
    // Exception table:
    //   from	to	target	type
    //   0	73	268	org/json/JSONException
    //   73	83	268	org/json/JSONException
    //   85	99	268	org/json/JSONException
    //   99	128	268	org/json/JSONException
    //   128	142	268	org/json/JSONException
    //   145	181	268	org/json/JSONException
    //   181	190	268	org/json/JSONException
    //   208	216	268	org/json/JSONException
    //   219	243	268	org/json/JSONException
    //   252	266	268	org/json/JSONException
    //   303	309	268	org/json/JSONException
    //   312	321	268	org/json/JSONException
    //   339	347	268	org/json/JSONException
    //   350	374	268	org/json/JSONException
    //   383	389	268	org/json/JSONException
    //   392	401	268	org/json/JSONException
    //   419	427	268	org/json/JSONException
    //   430	454	268	org/json/JSONException
    //   463	469	268	org/json/JSONException
    //   484	499	268	org/json/JSONException
    //   506	523	268	org/json/JSONException
    //   526	555	268	org/json/JSONException
  }
  
  public static String a(bz parambz, ci paramci, Location paramLocation) {
    try {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      if (parambz.hq != null)
        hashMap.put("ad_pos", parambz.hq); 
      a((HashMap)hashMap, parambz.hr);
      hashMap.put("format", parambz.em.eF);
      if (parambz.em.width == -1)
        hashMap.put("smart_w", "full"); 
      if (parambz.em.height == -2)
        hashMap.put("smart_h", "auto"); 
      if (parambz.em.eH != null) {
        StringBuilder stringBuilder = new StringBuilder();
        for (x x : parambz.em.eH) {
          int i;
          if (stringBuilder.length() != 0)
            stringBuilder.append("|"); 
          if (x.width == -1) {
            i = (int)(x.widthPixels / paramci.ip);
          } else {
            i = x.width;
          } 
          stringBuilder.append(i);
          stringBuilder.append("x");
          if (x.height == -2) {
            i = (int)(x.heightPixels / paramci.ip);
          } else {
            i = x.height;
          } 
          stringBuilder.append(i);
        } 
        hashMap.put("sz", stringBuilder);
      } 
      hashMap.put("slotname", parambz.adUnitId);
      hashMap.put("pn", parambz.applicationInfo.packageName);
      if (parambz.hs != null)
        hashMap.put("vc", Integer.valueOf(parambz.hs.versionCode)); 
      hashMap.put("ms", parambz.ht);
      hashMap.put("seq_num", parambz.hu);
      hashMap.put("session_id", parambz.hv);
      hashMap.put("js", parambz.ej.iJ);
      a((HashMap)hashMap, paramci);
      if (parambz.hr.versionCode >= 2 && parambz.hr.eE != null)
        a((HashMap)hashMap, parambz.hr.eE); 
      if (ct.n(2)) {
        String str = co.m((Map)hashMap).toString(2);
        ct.u("Ad Request JSON: " + str);
      } 
      return co.m((Map)hashMap).toString();
    } catch (JSONException jSONException) {
      ct.v("Problem serializing ad request to JSON: " + jSONException.getMessage());
      return null;
    } 
  }
  
  private static void a(HashMap<String, Object> paramHashMap, Location paramLocation) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    float f = paramLocation.getAccuracy();
    long l1 = paramLocation.getTime();
    long l2 = (long)(paramLocation.getLatitude() * 1.0E7D);
    long l3 = (long)(paramLocation.getLongitude() * 1.0E7D);
    hashMap.put("radius", Float.valueOf(f * 1000.0F));
    hashMap.put("lat", Long.valueOf(l2));
    hashMap.put("long", Long.valueOf(l3));
    hashMap.put("time", Long.valueOf(l1 * 1000L));
    paramHashMap.put("uule", hashMap);
  }
  
  private static void a(HashMap<String, Object> paramHashMap, ai paramai) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_1
    //   3: getfield eZ : I
    //   6: invokestatic alpha : (I)I
    //   9: ifeq -> 27
    //   12: aload_0
    //   13: ldc_w 'acolor'
    //   16: aload_1
    //   17: getfield eZ : I
    //   20: invokestatic m : (I)Ljava/lang/String;
    //   23: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   26: pop
    //   27: aload_1
    //   28: getfield backgroundColor : I
    //   31: invokestatic alpha : (I)I
    //   34: ifeq -> 52
    //   37: aload_0
    //   38: ldc_w 'bgcolor'
    //   41: aload_1
    //   42: getfield backgroundColor : I
    //   45: invokestatic m : (I)Ljava/lang/String;
    //   48: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   51: pop
    //   52: aload_1
    //   53: getfield fa : I
    //   56: invokestatic alpha : (I)I
    //   59: ifeq -> 102
    //   62: aload_1
    //   63: getfield fb : I
    //   66: invokestatic alpha : (I)I
    //   69: ifeq -> 102
    //   72: aload_0
    //   73: ldc_w 'gradientto'
    //   76: aload_1
    //   77: getfield fa : I
    //   80: invokestatic m : (I)Ljava/lang/String;
    //   83: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   86: pop
    //   87: aload_0
    //   88: ldc_w 'gradientfrom'
    //   91: aload_1
    //   92: getfield fb : I
    //   95: invokestatic m : (I)Ljava/lang/String;
    //   98: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   101: pop
    //   102: aload_1
    //   103: getfield fc : I
    //   106: invokestatic alpha : (I)I
    //   109: ifeq -> 127
    //   112: aload_0
    //   113: ldc_w 'bcolor'
    //   116: aload_1
    //   117: getfield fc : I
    //   120: invokestatic m : (I)Ljava/lang/String;
    //   123: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   126: pop
    //   127: aload_0
    //   128: ldc_w 'bthick'
    //   131: aload_1
    //   132: getfield fd : I
    //   135: invokestatic toString : (I)Ljava/lang/String;
    //   138: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   141: pop
    //   142: aload_1
    //   143: getfield fe : I
    //   146: tableswitch default -> 176, 0 -> 358, 1 -> 365, 2 -> 372, 3 -> 379
    //   176: aconst_null
    //   177: astore_2
    //   178: aload_2
    //   179: ifnull -> 191
    //   182: aload_0
    //   183: ldc_w 'btype'
    //   186: aload_2
    //   187: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   190: pop
    //   191: aload_1
    //   192: getfield ff : I
    //   195: tableswitch default -> 220, 0 -> 393, 1 -> 400, 2 -> 386
    //   220: aload_3
    //   221: astore_2
    //   222: aload_2
    //   223: ifnull -> 235
    //   226: aload_0
    //   227: ldc_w 'callbuttoncolor'
    //   230: aload_2
    //   231: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   234: pop
    //   235: aload_1
    //   236: getfield fg : Ljava/lang/String;
    //   239: ifnull -> 254
    //   242: aload_0
    //   243: ldc_w 'channel'
    //   246: aload_1
    //   247: getfield fg : Ljava/lang/String;
    //   250: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   253: pop
    //   254: aload_1
    //   255: getfield fh : I
    //   258: invokestatic alpha : (I)I
    //   261: ifeq -> 279
    //   264: aload_0
    //   265: ldc_w 'dcolor'
    //   268: aload_1
    //   269: getfield fh : I
    //   272: invokestatic m : (I)Ljava/lang/String;
    //   275: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   278: pop
    //   279: aload_1
    //   280: getfield fi : Ljava/lang/String;
    //   283: ifnull -> 298
    //   286: aload_0
    //   287: ldc_w 'font'
    //   290: aload_1
    //   291: getfield fi : Ljava/lang/String;
    //   294: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   297: pop
    //   298: aload_1
    //   299: getfield fj : I
    //   302: invokestatic alpha : (I)I
    //   305: ifeq -> 323
    //   308: aload_0
    //   309: ldc_w 'hcolor'
    //   312: aload_1
    //   313: getfield fj : I
    //   316: invokestatic m : (I)Ljava/lang/String;
    //   319: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   322: pop
    //   323: aload_0
    //   324: ldc_w 'headersize'
    //   327: aload_1
    //   328: getfield fk : I
    //   331: invokestatic toString : (I)Ljava/lang/String;
    //   334: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   337: pop
    //   338: aload_1
    //   339: getfield fl : Ljava/lang/String;
    //   342: ifnull -> 357
    //   345: aload_0
    //   346: ldc_w 'q'
    //   349: aload_1
    //   350: getfield fl : Ljava/lang/String;
    //   353: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   356: pop
    //   357: return
    //   358: ldc_w 'none'
    //   361: astore_2
    //   362: goto -> 178
    //   365: ldc_w 'dashed'
    //   368: astore_2
    //   369: goto -> 178
    //   372: ldc_w 'dotted'
    //   375: astore_2
    //   376: goto -> 178
    //   379: ldc_w 'solid'
    //   382: astore_2
    //   383: goto -> 178
    //   386: ldc_w 'dark'
    //   389: astore_2
    //   390: goto -> 222
    //   393: ldc_w 'light'
    //   396: astore_2
    //   397: goto -> 222
    //   400: ldc_w 'medium'
    //   403: astore_2
    //   404: goto -> 222
  }
  
  private static void a(HashMap<String, Object> paramHashMap, ci paramci) {
    paramHashMap.put("am", Integer.valueOf(paramci.hZ));
    paramHashMap.put("cog", j(paramci.ia));
    paramHashMap.put("coh", j(paramci.ib));
    if (!TextUtils.isEmpty(paramci.ic))
      paramHashMap.put("carrier", paramci.ic); 
    paramHashMap.put("gl", paramci.id);
    if (paramci.ie)
      paramHashMap.put("simulator", Integer.valueOf(1)); 
    paramHashMap.put("ma", j(paramci.if));
    paramHashMap.put("sp", j(paramci.ig));
    paramHashMap.put("hl", paramci.ih);
    if (!TextUtils.isEmpty(paramci.ii))
      paramHashMap.put("mv", paramci.ii); 
    paramHashMap.put("muv", Integer.valueOf(paramci.ij));
    if (paramci.ik != -2)
      paramHashMap.put("cnt", Integer.valueOf(paramci.ik)); 
    paramHashMap.put("gnt", Integer.valueOf(paramci.il));
    paramHashMap.put("pt", Integer.valueOf(paramci.im));
    paramHashMap.put("rm", Integer.valueOf(paramci.in));
    paramHashMap.put("riv", Integer.valueOf(paramci.io));
    paramHashMap.put("u_sd", Float.valueOf(paramci.ip));
    paramHashMap.put("sh", Integer.valueOf(paramci.ir));
    paramHashMap.put("sw", Integer.valueOf(paramci.iq));
  }
  
  private static void a(HashMap<String, Object> paramHashMap, v paramv) {
    String str = cl.as();
    if (str != null)
      paramHashMap.put("abf", str); 
    if (paramv.ex != -1L)
      paramHashMap.put("cust_age", hJ.format(new Date(paramv.ex))); 
    if (paramv.extras != null)
      paramHashMap.put("extras", paramv.extras); 
    if (paramv.ey != -1)
      paramHashMap.put("cust_gender", Integer.valueOf(paramv.ey)); 
    if (paramv.ez != null)
      paramHashMap.put("kw", paramv.ez); 
    if (paramv.tagForChildDirectedTreatment != -1)
      paramHashMap.put("tag_for_child_directed_treatment", Integer.valueOf(paramv.tagForChildDirectedTreatment)); 
    if (paramv.eA)
      paramHashMap.put("adtest", "on"); 
    if (paramv.versionCode >= 2) {
      if (paramv.eB)
        paramHashMap.put("d_imp_hdr", Integer.valueOf(1)); 
      if (!TextUtils.isEmpty(paramv.eC))
        paramHashMap.put("ppid", paramv.eC); 
      if (paramv.eD != null)
        a(paramHashMap, paramv.eD); 
    } 
  }
  
  private static Integer j(boolean paramBoolean) {
    if (paramBoolean) {
      boolean bool1 = true;
      return Integer.valueOf(bool1);
    } 
    boolean bool = false;
    return Integer.valueOf(bool);
  }
  
  private static String m(int paramInt) {
    return String.format(Locale.US, "#%06x", new Object[] { Integer.valueOf(0xFFFFFF & paramInt) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */