package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebSettings;

public final class cq {
  public static void a(Context paramContext, WebSettings paramWebSettings) {
    cp.a(paramContext, paramWebSettings);
    paramWebSettings.setMediaPlaybackRequiresUserGesture(false);
  }
  
  public static String getDefaultUserAgent(Context paramContext) {
    return WebSettings.getDefaultUserAgent(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */