package com.google.android.gms.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.net.Uri;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;

public final class cw extends WebView implements DownloadListener {
  private x fU;
  
  private final cu fV;
  
  private final Object fx = new Object();
  
  private final h he;
  
  private final cx iN;
  
  private final a iO;
  
  private bk iP;
  
  private boolean iQ;
  
  private boolean iR;
  
  private cw(a parama, x paramx, boolean paramBoolean1, boolean paramBoolean2, h paramh, cu paramcu) {
    super((Context)parama);
    this.iO = parama;
    this.fU = paramx;
    this.iQ = paramBoolean1;
    this.he = paramh;
    this.fV = paramcu;
    setBackgroundColor(0);
    WebSettings webSettings = getSettings();
    webSettings.setJavaScriptEnabled(true);
    webSettings.setSavePassword(false);
    webSettings.setSupportMultipleWindows(true);
    webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
    co.a((Context)parama, paramcu.iJ, webSettings);
    if (Build.VERSION.SDK_INT >= 17) {
      cq.a(getContext(), webSettings);
    } else if (Build.VERSION.SDK_INT >= 11) {
      cp.a(getContext(), webSettings);
    } 
    setDownloadListener(this);
    if (Build.VERSION.SDK_INT >= 11) {
      this.iN = new cz(this, paramBoolean2);
    } else {
      this.iN = new cx(this, paramBoolean2);
    } 
    setWebViewClient(this.iN);
    if (Build.VERSION.SDK_INT >= 14) {
      setWebChromeClient(new da(this));
    } else if (Build.VERSION.SDK_INT >= 11) {
      setWebChromeClient(new cy(this));
    } 
    aG();
  }
  
  public static cw a(Context paramContext, x paramx, boolean paramBoolean1, boolean paramBoolean2, h paramh, cu paramcu) {
    return new cw(new a(paramContext), paramx, paramBoolean1, paramBoolean2, paramh, paramcu);
  }
  
  private void aG() {
    synchronized (this.fx) {
      if (this.iQ || this.fU.eG) {
        if (Build.VERSION.SDK_INT < 14) {
          ct.r("Disabling hardware acceleration on an overlay.");
          aH();
        } else {
          ct.r("Enabling hardware acceleration on an overlay.");
          aI();
        } 
      } else if (Build.VERSION.SDK_INT < 18) {
        ct.r("Disabling hardware acceleration on an AdView.");
        aH();
      } else {
        ct.r("Enabling hardware acceleration on an AdView.");
        aI();
      } 
      return;
    } 
  }
  
  private void aH() {
    synchronized (this.fx) {
      if (!this.iR && Build.VERSION.SDK_INT >= 11)
        cp.c((View)this); 
      this.iR = true;
      return;
    } 
  }
  
  private void aI() {
    synchronized (this.fx) {
      if (this.iR && Build.VERSION.SDK_INT >= 11)
        cp.d((View)this); 
      this.iR = false;
      return;
    } 
  }
  
  public void a(Context paramContext, x paramx) {
    synchronized (this.fx) {
      this.iO.setBaseContext(paramContext);
      this.iP = null;
      this.fU = paramx;
      this.iQ = false;
      co.b(this);
      loadUrl("about:blank");
      this.iN.reset();
      return;
    } 
  }
  
  public void a(bk parambk) {
    synchronized (this.fx) {
      this.iP = parambk;
      return;
    } 
  }
  
  public void a(x paramx) {
    synchronized (this.fx) {
      this.fU = paramx;
      requestLayout();
      return;
    } 
  }
  
  public void a(String paramString, Map<String, ?> paramMap) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("javascript:AFMA_ReceiveMessage('");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    if (paramMap != null)
      try {
        paramString = co.m(paramMap).toString();
        stringBuilder.append(",");
        stringBuilder.append(paramString);
        stringBuilder.append(");");
        ct.u("Dispatching AFMA event: " + stringBuilder);
        loadUrl(stringBuilder.toString());
        return;
      } catch (JSONException jSONException) {
        ct.v("Could not convert AFMA event parameters to JSON.");
        return;
      }  
    stringBuilder.append(");");
    ct.u("Dispatching AFMA event: " + stringBuilder);
    loadUrl(stringBuilder.toString());
  }
  
  public void aA() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(1);
    hashMap.put("version", this.fV.iJ);
    a("onshow", (Map)hashMap);
  }
  
  public bk aB() {
    synchronized (this.fx) {
      return this.iP;
    } 
  }
  
  public cx aC() {
    return this.iN;
  }
  
  public h aD() {
    return this.he;
  }
  
  public cu aE() {
    return this.fV;
  }
  
  public boolean aF() {
    synchronized (this.fx) {
      return this.iQ;
    } 
  }
  
  public void az() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(1);
    hashMap.put("version", this.fV.iJ);
    a("onhide", (Map)hashMap);
  }
  
  public void l(boolean paramBoolean) {
    synchronized (this.fx) {
      this.iQ = paramBoolean;
      aG();
      return;
    } 
  }
  
  public void onDownloadStart(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong) {
    try {
      Intent intent = new Intent("android.intent.action.VIEW");
      intent.setDataAndType(Uri.parse(paramString1), paramString4);
      getContext().startActivity(intent);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      ct.r("Couldn't find an Activity to view url/mimetype: " + paramString1 + " / " + paramString4);
      return;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: ldc_w 2147483647
    //   3: istore #4
    //   5: aload_0
    //   6: getfield fx : Ljava/lang/Object;
    //   9: astore #8
    //   11: aload #8
    //   13: monitorenter
    //   14: aload_0
    //   15: invokevirtual isInEditMode : ()Z
    //   18: ifne -> 28
    //   21: aload_0
    //   22: getfield iQ : Z
    //   25: ifeq -> 38
    //   28: aload_0
    //   29: iload_1
    //   30: iload_2
    //   31: invokespecial onMeasure : (II)V
    //   34: aload #8
    //   36: monitorexit
    //   37: return
    //   38: iload_1
    //   39: invokestatic getMode : (I)I
    //   42: istore #7
    //   44: iload_1
    //   45: invokestatic getSize : (I)I
    //   48: istore_3
    //   49: iload_2
    //   50: invokestatic getMode : (I)I
    //   53: istore #6
    //   55: iload_2
    //   56: invokestatic getSize : (I)I
    //   59: istore #5
    //   61: iload #7
    //   63: ldc_w -2147483648
    //   66: if_icmpeq -> 248
    //   69: iload #7
    //   71: ldc_w 1073741824
    //   74: if_icmpne -> 241
    //   77: goto -> 248
    //   80: aload_0
    //   81: getfield fU : Lcom/google/android/gms/internal/x;
    //   84: getfield widthPixels : I
    //   87: iload_1
    //   88: if_icmpgt -> 102
    //   91: aload_0
    //   92: getfield fU : Lcom/google/android/gms/internal/x;
    //   95: getfield heightPixels : I
    //   98: iload_2
    //   99: if_icmple -> 206
    //   102: new java/lang/StringBuilder
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: ldc_w 'Not enough space to show ad. Needs '
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: aload_0
    //   116: getfield fU : Lcom/google/android/gms/internal/x;
    //   119: getfield widthPixels : I
    //   122: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   125: ldc_w 'x'
    //   128: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   131: aload_0
    //   132: getfield fU : Lcom/google/android/gms/internal/x;
    //   135: getfield heightPixels : I
    //   138: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   141: ldc_w ' pixels, but only has '
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: iload_3
    //   148: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   151: ldc_w 'x'
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: iload #5
    //   159: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   162: ldc_w ' pixels.'
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: invokevirtual toString : ()Ljava/lang/String;
    //   171: invokestatic v : (Ljava/lang/String;)V
    //   174: aload_0
    //   175: invokevirtual getVisibility : ()I
    //   178: bipush #8
    //   180: if_icmpeq -> 188
    //   183: aload_0
    //   184: iconst_4
    //   185: invokevirtual setVisibility : (I)V
    //   188: aload_0
    //   189: iconst_0
    //   190: iconst_0
    //   191: invokevirtual setMeasuredDimension : (II)V
    //   194: aload #8
    //   196: monitorexit
    //   197: return
    //   198: astore #9
    //   200: aload #8
    //   202: monitorexit
    //   203: aload #9
    //   205: athrow
    //   206: aload_0
    //   207: invokevirtual getVisibility : ()I
    //   210: bipush #8
    //   212: if_icmpeq -> 220
    //   215: aload_0
    //   216: iconst_0
    //   217: invokevirtual setVisibility : (I)V
    //   220: aload_0
    //   221: aload_0
    //   222: getfield fU : Lcom/google/android/gms/internal/x;
    //   225: getfield widthPixels : I
    //   228: aload_0
    //   229: getfield fU : Lcom/google/android/gms/internal/x;
    //   232: getfield heightPixels : I
    //   235: invokevirtual setMeasuredDimension : (II)V
    //   238: goto -> 194
    //   241: ldc_w 2147483647
    //   244: istore_1
    //   245: goto -> 250
    //   248: iload_3
    //   249: istore_1
    //   250: iload #6
    //   252: ldc_w -2147483648
    //   255: if_icmpeq -> 269
    //   258: iload #4
    //   260: istore_2
    //   261: iload #6
    //   263: ldc_w 1073741824
    //   266: if_icmpne -> 80
    //   269: iload #5
    //   271: istore_2
    //   272: goto -> 80
    // Exception table:
    //   from	to	target	type
    //   14	28	198	finally
    //   28	37	198	finally
    //   38	61	198	finally
    //   80	102	198	finally
    //   102	188	198	finally
    //   188	194	198	finally
    //   194	197	198	finally
    //   200	203	198	finally
    //   206	220	198	finally
    //   220	238	198	finally
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.he != null)
      this.he.a(paramMotionEvent); 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setContext(Context paramContext) {
    this.iO.setBaseContext(paramContext);
  }
  
  public x y() {
    synchronized (this.fx) {
      return this.fU;
    } 
  }
  
  private static class a extends MutableContextWrapper {
    private Activity iS;
    
    private Context iT;
    
    public a(Context param1Context) {
      super(param1Context);
      setBaseContext(param1Context);
    }
    
    public void setBaseContext(Context param1Context) {
      this.iT = param1Context.getApplicationContext();
      if (param1Context instanceof Activity) {
        Activity activity = (Activity)param1Context;
      } else {
        param1Context = null;
      } 
      this.iS = (Activity)param1Context;
      super.setBaseContext(this.iT);
    }
    
    public void startActivity(Intent param1Intent) {
      if (this.iS != null) {
        this.iS.startActivity(param1Intent);
        return;
      } 
      param1Intent.setFlags(268435456);
      this.iT.startActivity(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */