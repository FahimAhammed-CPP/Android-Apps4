package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import java.util.Iterator;

public final class as {
  private final bb ed;
  
  private ax fA;
  
  private final bz fw;
  
  private final Object fx = new Object();
  
  private final au fy;
  
  private boolean fz = false;
  
  private final Context mContext;
  
  public as(Context paramContext, bz parambz, bb parambb, au paramau) {
    this.mContext = paramContext;
    this.fw = parambz;
    this.ed = parambb;
    this.fy = paramau;
  }
  
  public ay a(long paramLong1, long paramLong2) {
    ct.r("Starting mediation.");
    Iterator<at> iterator = this.fy.fI.iterator();
    while (iterator.hasNext()) {
      at at = iterator.next();
      ct.t("Trying mediation network: " + at.fD);
      for (String str : at.fE) {
        synchronized (this.fx) {
          if (this.fz)
            return new ay(-1); 
          this.fA = new ax(this.mContext, str, this.ed, this.fy, at, this.fw.hr, this.fw.em, this.fw.ej);
          null = this.fA.b(paramLong1, paramLong2);
          if (((ay)null).ga == 0) {
            ct.r("Adapter succeeded.");
            return (ay)null;
          } 
        } 
        if (((ay)SYNTHETIC_LOCAL_VARIABLE_5).gc != null)
          cs.iI.post(new Runnable(this, (ay)SYNTHETIC_LOCAL_VARIABLE_5) {
                public void run() {
                  try {
                    this.fB.gc.destroy();
                    return;
                  } catch (RemoteException remoteException) {
                    ct.b("Could not destroy mediation adapter.", (Throwable)remoteException);
                    return;
                  } 
                }
              }); 
      } 
    } 
    return new ay(1);
  }
  
  public void cancel() {
    synchronized (this.fx) {
      this.fz = true;
      if (this.fA != null)
        this.fA.cancel(); 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */