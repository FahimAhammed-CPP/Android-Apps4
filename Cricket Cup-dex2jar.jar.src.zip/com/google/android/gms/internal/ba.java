package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.NetworkExtras;
import java.util.Map;

public final class ba extends bb.a {
  private Map<Class<? extends NetworkExtras>, NetworkExtras> gf;
  
  private <NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> bc m(String paramString) throws RemoteException {
    try {
      Class<?> clazz = Class.forName(paramString, false, ba.class.getClassLoader());
      if (!MediationAdapter.class.isAssignableFrom(clazz)) {
        ct.v("Could not instantiate mediation adapter: " + paramString + ".");
        throw new RemoteException();
      } 
    } catch (Throwable throwable) {
      ct.v("Could not instantiate mediation adapter: " + paramString + ". " + throwable.getMessage());
      throw new RemoteException();
    } 
    MediationAdapter<NetworkExtras, MediationServerParameters> mediationAdapter = throwable.newInstance();
    return new be<NetworkExtras, MediationServerParameters>(mediationAdapter, (NetworkExtras)this.gf.get(mediationAdapter.getAdditionalParametersType()));
  }
  
  public void c(Map<Class<? extends NetworkExtras>, NetworkExtras> paramMap) {
    this.gf = paramMap;
  }
  
  public bc l(String paramString) throws RemoteException {
    return m(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */