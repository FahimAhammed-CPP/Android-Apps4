package com.google.android.gms.internal;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public abstract class dv implements SafeParcelable {
  private static final Object pa = new Object();
  
  private static ClassLoader pb = null;
  
  private static Integer pc = null;
  
  private boolean pd = false;
  
  protected static boolean P(String paramString) {
    ClassLoader classLoader = bL();
    if (classLoader == null)
      return true; 
    try {
      return a(classLoader.loadClass(paramString));
    } catch (Exception exception) {
      return false;
    } 
  }
  
  private static boolean a(Class<?> paramClass) {
    try {
      return "SAFE_PARCELABLE_NULL_STRING".equals(paramClass.getField("NULL").get(null));
    } catch (NoSuchFieldException noSuchFieldException) {
      return false;
    } catch (IllegalAccessException illegalAccessException) {
      return false;
    } 
  }
  
  protected static ClassLoader bL() {
    synchronized (pa) {
      return pb;
    } 
  }
  
  protected static Integer bM() {
    synchronized (pa) {
      return pc;
    } 
  }
  
  protected boolean bN() {
    return this.pd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */