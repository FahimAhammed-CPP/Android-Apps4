package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import java.util.Locale;

public final class ci {
  public final int hZ;
  
  public final boolean ia;
  
  public final boolean ib;
  
  public final String ic;
  
  public final String id;
  
  public final boolean ie;
  
  public final boolean if;
  
  public final boolean ig;
  
  public final String ih;
  
  public final String ii;
  
  public final int ij;
  
  public final int ik;
  
  public final int il;
  
  public final int im;
  
  public final int in;
  
  public final int io;
  
  public final float ip;
  
  public final int iq;
  
  public final int ir;
  
  public ci(Context paramContext) {
    boolean bool1;
    AudioManager audioManager = (AudioManager)paramContext.getSystemService("audio");
    ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    Locale locale = Locale.getDefault();
    PackageManager packageManager = paramContext.getPackageManager();
    TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    this.hZ = audioManager.getMode();
    if (a(packageManager, "geo:0,0?q=donuts") != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.ia = bool1;
    if (a(packageManager, "http://www.google.com") != null) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    this.ib = bool1;
    this.ic = telephonyManager.getNetworkOperator();
    this.id = locale.getCountry();
    this.ie = cs.ax();
    this.if = audioManager.isMusicActive();
    this.ig = audioManager.isSpeakerphoneOn();
    this.ih = locale.getLanguage();
    this.ii = a(packageManager);
    this.ij = audioManager.getStreamVolume(3);
    this.ik = a(paramContext, connectivityManager, packageManager);
    this.il = telephonyManager.getNetworkType();
    this.im = telephonyManager.getPhoneType();
    this.in = audioManager.getRingerMode();
    this.io = audioManager.getStreamVolume(2);
    this.ip = displayMetrics.density;
    this.iq = displayMetrics.widthPixels;
    this.ir = displayMetrics.heightPixels;
  }
  
  private static int a(Context paramContext, ConnectivityManager paramConnectivityManager, PackageManager paramPackageManager) {
    int i = -2;
    if (co.a(paramPackageManager, paramContext.getPackageName(), "android.permission.ACCESS_NETWORK_STATE")) {
      NetworkInfo networkInfo = paramConnectivityManager.getActiveNetworkInfo();
      if (networkInfo != null)
        return networkInfo.getType(); 
    } else {
      return i;
    } 
    return -1;
  }
  
  private static ResolveInfo a(PackageManager paramPackageManager, String paramString) {
    return paramPackageManager.resolveActivity(new Intent("android.intent.action.VIEW", Uri.parse(paramString)), 65536);
  }
  
  private static String a(PackageManager paramPackageManager) {
    ResolveInfo resolveInfo = a(paramPackageManager, "market://details?id=com.google.android.gms.ads");
    if (resolveInfo != null) {
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      if (activityInfo != null)
        try {
          PackageInfo packageInfo = paramPackageManager.getPackageInfo(activityInfo.packageName, 0);
          if (packageInfo != null)
            return packageInfo.versionCode + "." + activityInfo.packageName; 
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          return null;
        }  
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ci.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */