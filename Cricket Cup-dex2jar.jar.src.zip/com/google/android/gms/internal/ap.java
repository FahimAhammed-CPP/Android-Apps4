package com.google.android.gms.internal;

import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import java.util.Map;

public final class ap implements an {
  private static int a(DisplayMetrics paramDisplayMetrics, Map<String, String> paramMap, String paramString, int paramInt) {
    String str = paramMap.get(paramString);
    int i = paramInt;
    if (str != null)
      try {
        return cs.a(paramDisplayMetrics, Integer.parseInt(str));
      } catch (NumberFormatException numberFormatException) {
        ct.v("Could not parse " + paramString + " in a video GMSG: " + str);
        return paramInt;
      }  
    return i;
  }
  
  public void a(cw paramcw, Map<String, String> paramMap) {
    DisplayMetrics displayMetrics;
    String str = paramMap.get("action");
    if (str == null) {
      ct.v("Action missing from video GMSG.");
      return;
    } 
    bk bk = paramcw.aB();
    if (bk == null) {
      ct.v("Could not get ad overlay for a video GMSG.");
      return;
    } 
    boolean bool1 = "new".equalsIgnoreCase(str);
    boolean bool2 = "position".equalsIgnoreCase(str);
    if (bool1 || bool2) {
      displayMetrics = paramcw.getContext().getResources().getDisplayMetrics();
      int i = a(displayMetrics, paramMap, "x", 0);
      int j = a(displayMetrics, paramMap, "y", 0);
      int k = a(displayMetrics, paramMap, "w", -1);
      int m = a(displayMetrics, paramMap, "h", -1);
      if (bool1 && bk.W() == null) {
        bk.c(i, j, k, m);
        return;
      } 
      bk.b(i, j, k, m);
      return;
    } 
    bo bo = bk.W();
    if (bo == null) {
      bo.a((cw)displayMetrics, "no_video_view", (String)null);
      return;
    } 
    if ("click".equalsIgnoreCase(str)) {
      displayMetrics = displayMetrics.getContext().getResources().getDisplayMetrics();
      int i = a(displayMetrics, paramMap, "x", 0);
      int j = a(displayMetrics, paramMap, "y", 0);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 0, i, j, 0);
      bo.b(motionEvent);
      motionEvent.recycle();
      return;
    } 
    if ("controls".equalsIgnoreCase(str)) {
      String str1 = paramMap.get("enabled");
      if (str1 == null) {
        ct.v("Enabled parameter missing from controls video GMSG.");
        return;
      } 
      bo.i(Boolean.parseBoolean(str1));
      return;
    } 
    if ("currentTime".equalsIgnoreCase(str)) {
      String str1 = paramMap.get("time");
      if (str1 == null) {
        ct.v("Time parameter missing from currentTime video GMSG.");
        return;
      } 
      try {
        bo.seekTo((int)(Float.parseFloat(str1) * 1000.0F));
        return;
      } catch (NumberFormatException numberFormatException) {
        ct.v("Could not parse time parameter from currentTime video GMSG: " + str1);
        return;
      } 
    } 
    if ("hide".equalsIgnoreCase(str)) {
      bo.setVisibility(4);
      return;
    } 
    if ("load".equalsIgnoreCase(str)) {
      bo.af();
      return;
    } 
    if ("pause".equalsIgnoreCase(str)) {
      bo.pause();
      return;
    } 
    if ("play".equalsIgnoreCase(str)) {
      bo.play();
      return;
    } 
    if ("show".equalsIgnoreCase(str)) {
      bo.setVisibility(0);
      return;
    } 
    if ("src".equalsIgnoreCase(str)) {
      bo.n((String)numberFormatException.get("src"));
      return;
    } 
    ct.v("Unknown video action: " + str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */