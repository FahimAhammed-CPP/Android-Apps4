package com.google.android.gms.internal;

import android.os.Process;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class cn {
  private static final ThreadPoolExecutor iA;
  
  private static final ThreadFactory iz = new ThreadFactory() {
      private final AtomicInteger iC = new AtomicInteger(1);
      
      public Thread newThread(Runnable param1Runnable) {
        return new Thread(param1Runnable, "AdWorker #" + this.iC.getAndIncrement());
      }
    };
  
  static {
    iA = new ThreadPoolExecutor(0, 10, 65L, TimeUnit.SECONDS, new SynchronousQueue<Runnable>(true), iz);
  }
  
  public static void execute(Runnable paramRunnable) {
    try {
      iA.execute(new Runnable(paramRunnable) {
            public void run() {
              Process.setThreadPriority(10);
              this.iB.run();
            }
          });
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      ct.b("Too many background threads already running. Aborting task.", rejectedExecutionException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */