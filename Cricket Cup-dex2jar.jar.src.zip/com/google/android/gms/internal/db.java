package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;

public abstract class db extends dd.a {
  public void a(int paramInt, DataHolder paramDataHolder) {}
  
  public void a(DataHolder paramDataHolder) {}
  
  public void onSignOutComplete() {}
  
  public void onStateDeleted(int paramInt1, int paramInt2) {}
  
  public void p(int paramInt) {}
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\db.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */