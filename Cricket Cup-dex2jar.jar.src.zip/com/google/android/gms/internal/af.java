package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class af {
  public static final String DEVICE_ID_EMULATOR = cs.q("emulator");
  
  private final Date d;
  
  private final int eL;
  
  private final Location eM;
  
  private final boolean eN;
  
  private final Map<Class<? extends NetworkExtras>, NetworkExtras> eO;
  
  private final String eP;
  
  private final SearchAdRequest eQ;
  
  private final int eR;
  
  private final Set<String> eS;
  
  private final Set<String> f;
  
  public af(a parama) {
    this(parama, null);
  }
  
  public af(a parama, SearchAdRequest paramSearchAdRequest) {
    this.d = a.a(parama);
    this.eL = a.b(parama);
    this.f = Collections.unmodifiableSet(a.c(parama));
    this.eM = a.d(parama);
    this.eN = a.e(parama);
    this.eO = Collections.unmodifiableMap(a.f(parama));
    this.eP = a.g(parama);
    this.eQ = paramSearchAdRequest;
    this.eR = a.h(parama);
    this.eS = Collections.unmodifiableSet(a.i(parama));
  }
  
  public SearchAdRequest Q() {
    return this.eQ;
  }
  
  public Map<Class<? extends NetworkExtras>, NetworkExtras> R() {
    return this.eO;
  }
  
  public int S() {
    return this.eR;
  }
  
  public Date getBirthday() {
    return this.d;
  }
  
  public int getGender() {
    return this.eL;
  }
  
  public Set<String> getKeywords() {
    return this.f;
  }
  
  public Location getLocation() {
    return this.eM;
  }
  
  public boolean getManualImpressionsEnabled() {
    return this.eN;
  }
  
  public <T extends NetworkExtras> T getNetworkExtras(Class<T> paramClass) {
    return (T)this.eO.get(paramClass);
  }
  
  public String getPublisherProvidedId() {
    return this.eP;
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.eS.contains(cs.l(paramContext));
  }
  
  public static final class a {
    private Date d;
    
    private int eL = -1;
    
    private Location eM;
    
    private boolean eN = false;
    
    private String eP;
    
    private int eR = -1;
    
    private final HashSet<String> eT = new HashSet<String>();
    
    private final HashMap<Class<? extends NetworkExtras>, NetworkExtras> eU = new HashMap<Class<? extends NetworkExtras>, NetworkExtras>();
    
    private final HashSet<String> eV = new HashSet<String>();
    
    public void a(Location param1Location) {
      this.eM = param1Location;
    }
    
    public void a(NetworkExtras param1NetworkExtras) {
      this.eU.put(param1NetworkExtras.getClass(), param1NetworkExtras);
    }
    
    public void a(Date param1Date) {
      this.d = param1Date;
    }
    
    public void d(int param1Int) {
      this.eL = param1Int;
    }
    
    public void d(boolean param1Boolean) {
      this.eN = param1Boolean;
    }
    
    public void e(boolean param1Boolean) {
      boolean bool;
      if (param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      this.eR = bool;
    }
    
    public void g(String param1String) {
      this.eT.add(param1String);
    }
    
    public void h(String param1String) {
      this.eV.add(param1String);
    }
    
    public void i(String param1String) {
      this.eP = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */