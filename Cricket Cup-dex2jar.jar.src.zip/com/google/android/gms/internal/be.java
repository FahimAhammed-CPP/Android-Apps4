package com.google.android.gms.internal;

import android.app.Activity;
import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.admob.AdMobServerParameters;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONObject;

public final class be<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> extends bc.a {
  private final MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> gg;
  
  private final NETWORK_EXTRAS gh;
  
  public be(MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> paramMediationAdapter, NETWORK_EXTRAS paramNETWORK_EXTRAS) {
    this.gg = paramMediationAdapter;
    this.gh = paramNETWORK_EXTRAS;
  }
  
  private SERVER_PARAMETERS a(String paramString1, int paramInt, String paramString2) throws RemoteException {
    HashMap<Object, Object> hashMap;
    if (paramString1 != null) {
      try {
        JSONObject jSONObject = new JSONObject(paramString1);
        hashMap = new HashMap<Object, Object>(jSONObject.length());
        Iterator<String> iterator = jSONObject.keys();
        while (iterator.hasNext()) {
          String str = iterator.next();
          hashMap.put(str, jSONObject.getString(str));
        } 
      } catch (Throwable throwable) {
        ct.b("Could not get MediationServerParameters.", throwable);
        throw new RemoteException();
      } 
    } else {
      hashMap = new HashMap<Object, Object>(0);
    } 
    Class<MediationServerParameters> clazz = this.gg.getServerParametersType();
    MediationServerParameters mediationServerParameters = null;
    if (clazz != null) {
      mediationServerParameters = clazz.newInstance();
      mediationServerParameters.load(hashMap);
    } 
    if (mediationServerParameters instanceof AdMobServerParameters) {
      AdMobServerParameters adMobServerParameters = (AdMobServerParameters)mediationServerParameters;
      adMobServerParameters.adJson = paramString2;
      adMobServerParameters.tagForChildDirectedTreatment = paramInt;
      return (SERVER_PARAMETERS)mediationServerParameters;
    } 
    return (SERVER_PARAMETERS)mediationServerParameters;
  }
  
  public void a(b paramb, v paramv, String paramString, bd parambd) throws RemoteException {
    a(paramb, paramv, paramString, (String)null, parambd);
  }
  
  public void a(b paramb, v paramv, String paramString1, String paramString2, bd parambd) throws RemoteException {
    if (!(this.gg instanceof MediationInterstitialAdapter)) {
      ct.v("MediationAdapter is not a MediationInterstitialAdapter: " + this.gg.getClass().getCanonicalName());
      throw new RemoteException();
    } 
    ct.r("Requesting interstitial ad from adapter.");
    try {
      ((MediationInterstitialAdapter)this.gg).requestInterstitialAd(new bf<NetworkExtras, MediationServerParameters>(parambd), (Activity)c.b(paramb), (MediationServerParameters)a(paramString1, paramv.tagForChildDirectedTreatment, paramString2), bg.e(paramv), (NetworkExtras)this.gh);
      return;
    } catch (Throwable throwable) {
      ct.b("Could not request interstitial ad from adapter.", throwable);
      throw new RemoteException();
    } 
  }
  
  public void a(b paramb, x paramx, v paramv, String paramString, bd parambd) throws RemoteException {
    a(paramb, paramx, paramv, paramString, null, parambd);
  }
  
  public void a(b paramb, x paramx, v paramv, String paramString1, String paramString2, bd parambd) throws RemoteException {
    if (!(this.gg instanceof MediationBannerAdapter)) {
      ct.v("MediationAdapter is not a MediationBannerAdapter: " + this.gg.getClass().getCanonicalName());
      throw new RemoteException();
    } 
    ct.r("Requesting banner ad from adapter.");
    try {
      ((MediationBannerAdapter)this.gg).requestBannerAd(new bf<NetworkExtras, MediationServerParameters>(parambd), (Activity)c.b(paramb), (MediationServerParameters)a(paramString1, paramv.tagForChildDirectedTreatment, paramString2), bg.b(paramx), bg.e(paramv), (NetworkExtras)this.gh);
      return;
    } catch (Throwable throwable) {
      ct.b("Could not request banner ad from adapter.", throwable);
      throw new RemoteException();
    } 
  }
  
  public void destroy() throws RemoteException {
    try {
      this.gg.destroy();
      return;
    } catch (Throwable throwable) {
      ct.b("Could not destroy adapter.", throwable);
      throw new RemoteException();
    } 
  }
  
  public b getView() throws RemoteException {
    if (!(this.gg instanceof MediationBannerAdapter)) {
      ct.v("MediationAdapter is not a MediationBannerAdapter: " + this.gg.getClass().getCanonicalName());
      throw new RemoteException();
    } 
    try {
      return c.h(((MediationBannerAdapter)this.gg).getBannerView());
    } catch (Throwable throwable) {
      ct.b("Could not get banner view from adapter.", throwable);
      throw new RemoteException();
    } 
  }
  
  public void showInterstitial() throws RemoteException {
    if (!(this.gg instanceof MediationInterstitialAdapter)) {
      ct.v("MediationAdapter is not a MediationInterstitialAdapter: " + this.gg.getClass().getCanonicalName());
      throw new RemoteException();
    } 
    ct.r("Showing interstitial from adapter.");
    try {
      ((MediationInterstitialAdapter)this.gg).showInterstitial();
      return;
    } catch (Throwable throwable) {
      ct.b("Could not show interstitial from adapter.", throwable);
      throw new RemoteException();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\be.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */