package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.dynamic.e;

public final class br extends e<bt> {
  private static final br ha = new br();
  
  private br() {
    super("com.google.android.gms.ads.AdOverlayCreatorImpl");
  }
  
  public static bs a(Activity paramActivity) {
    try {
      if (b(paramActivity)) {
        ct.r("Using AdOverlay from the client jar.");
        return new bk(paramActivity);
      } 
      return ha.c(paramActivity);
    } catch (a a) {
      ct.v(a.getMessage());
      return null;
    } 
  }
  
  private static boolean b(Activity paramActivity) throws a {
    Intent intent = paramActivity.getIntent();
    if (!intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar"))
      throw new a("Ad overlay requires the useClientJar flag in intent extras."); 
    return intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
  }
  
  private bs c(Activity paramActivity) {
    try {
      b b = c.h(paramActivity);
      return bs.a.m(((bt)t((Context)paramActivity)).a(b));
    } catch (RemoteException remoteException) {
      ct.b("Could not create remote AdOverlay.", (Throwable)remoteException);
      return null;
    } catch (com.google.android.gms.dynamic.e.a a) {
      ct.b("Could not create remote AdOverlay.", (Throwable)a);
      return null;
    } 
  }
  
  protected bt l(IBinder paramIBinder) {
    return bt.a.n(paramIBinder);
  }
  
  private static final class a extends Exception {
    public a(String param1String) {
      super(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\br.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */