package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.api.GoogleApiClient;
import java.util.ArrayList;

public final class dx {
  private final Handler mHandler;
  
  private final b ps;
  
  private ArrayList<GoogleApiClient.ConnectionCallbacks> pt;
  
  final ArrayList<GoogleApiClient.ConnectionCallbacks> pu = new ArrayList<GoogleApiClient.ConnectionCallbacks>();
  
  private boolean pv = false;
  
  private ArrayList<GooglePlayServicesClient.OnConnectionFailedListener> pw;
  
  private boolean px = false;
  
  public dx(Context paramContext, b paramb) {
    this(paramContext, paramb, null);
  }
  
  dx(Context paramContext, b paramb, Handler paramHandler) {
    Handler handler = paramHandler;
    if (paramHandler == null)
      handler = new a(this, Looper.getMainLooper()); 
    this.pt = new ArrayList<GoogleApiClient.ConnectionCallbacks>();
    this.pw = new ArrayList<GooglePlayServicesClient.OnConnectionFailedListener>();
    this.ps = paramb;
    this.mHandler = handler;
  }
  
  public void J(int paramInt) {
    this.mHandler.removeMessages(1);
    synchronized (this.pt) {
      this.pv = true;
      ArrayList<GoogleApiClient.ConnectionCallbacks> arrayList = this.pt;
      int j = arrayList.size();
      for (int i = 0;; i++) {
        if (i >= j || !this.ps.bp()) {
          this.pv = false;
          return;
        } 
        if (this.pt.contains(arrayList.get(i)))
          ((GoogleApiClient.ConnectionCallbacks)arrayList.get(i)).onConnectionSuspended(paramInt); 
      } 
    } 
  }
  
  public void a(ConnectionResult paramConnectionResult) {
    this.mHandler.removeMessages(1);
    synchronized (this.pw) {
      this.px = true;
      ArrayList<GooglePlayServicesClient.OnConnectionFailedListener> arrayList = this.pw;
      int j = arrayList.size();
      for (int i = 0;; i++) {
        if (i < j) {
          if (!this.ps.bp())
            return; 
          if (this.pw.contains(arrayList.get(i)))
            ((GooglePlayServicesClient.OnConnectionFailedListener)arrayList.get(i)).onConnectionFailed(paramConnectionResult); 
        } else {
          this.px = false;
          return;
        } 
      } 
    } 
  }
  
  public void b(Bundle paramBundle) {
    boolean bool = true;
    synchronized (this.pt) {
      boolean bool1;
      if (!this.pv) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      eg.p(bool1);
      this.mHandler.removeMessages(1);
      this.pv = true;
      if (this.pu.size() == 0) {
        bool1 = bool;
      } else {
        bool1 = false;
      } 
      eg.p(bool1);
      ArrayList<GoogleApiClient.ConnectionCallbacks> arrayList = this.pt;
      int j = arrayList.size();
      for (int i = 0;; i++) {
        if (i >= j || !this.ps.bp() || !this.ps.isConnected()) {
          this.pu.clear();
          this.pv = false;
          return;
        } 
        this.pu.size();
        if (!this.pu.contains(arrayList.get(i)))
          ((GoogleApiClient.ConnectionCallbacks)arrayList.get(i)).onConnected(paramBundle); 
      } 
    } 
  }
  
  protected void bT() {
    synchronized (this.pt) {
      b(this.ps.aU());
      return;
    } 
  }
  
  public boolean isConnectionCallbacksRegistered(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    eg.f(paramConnectionCallbacks);
    synchronized (this.pt) {
      return this.pt.contains(paramConnectionCallbacks);
    } 
  }
  
  public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    eg.f(paramOnConnectionFailedListener);
    synchronized (this.pw) {
      return this.pw.contains(paramOnConnectionFailedListener);
    } 
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    eg.f(paramConnectionCallbacks);
    synchronized (this.pt) {
      if (this.pt.contains(paramConnectionCallbacks)) {
        Log.w("GmsClientEvents", "registerConnectionCallbacks(): listener " + paramConnectionCallbacks + " is already registered");
      } else {
        if (this.pv)
          this.pt = new ArrayList<GoogleApiClient.ConnectionCallbacks>(this.pt); 
        this.pt.add(paramConnectionCallbacks);
      } 
      if (this.ps.isConnected())
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, paramConnectionCallbacks)); 
      return;
    } 
  }
  
  public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    eg.f(paramOnConnectionFailedListener);
    synchronized (this.pw) {
      if (this.pw.contains(paramOnConnectionFailedListener)) {
        Log.w("GmsClientEvents", "registerConnectionFailedListener(): listener " + paramOnConnectionFailedListener + " is already registered");
      } else {
        if (this.px)
          this.pw = new ArrayList<GooglePlayServicesClient.OnConnectionFailedListener>(this.pw); 
        this.pw.add(paramOnConnectionFailedListener);
      } 
      return;
    } 
  }
  
  public void unregisterConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    eg.f(paramConnectionCallbacks);
    synchronized (this.pt) {
      if (this.pt != null) {
        if (this.pv)
          this.pt = new ArrayList<GoogleApiClient.ConnectionCallbacks>(this.pt); 
        if (!this.pt.remove(paramConnectionCallbacks)) {
          Log.w("GmsClientEvents", "unregisterConnectionCallbacks(): listener " + paramConnectionCallbacks + " not found");
        } else if (this.pv && !this.pu.contains(paramConnectionCallbacks)) {
          this.pu.add(paramConnectionCallbacks);
        } 
      } 
      return;
    } 
  }
  
  public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    eg.f(paramOnConnectionFailedListener);
    synchronized (this.pw) {
      if (this.pw != null) {
        if (this.px)
          this.pw = new ArrayList<GooglePlayServicesClient.OnConnectionFailedListener>(this.pw); 
        if (!this.pw.remove(paramOnConnectionFailedListener))
          Log.w("GmsClientEvents", "unregisterConnectionFailedListener(): listener " + paramOnConnectionFailedListener + " not found"); 
      } 
      return;
    } 
  }
  
  final class a extends Handler {
    public a(dx this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what == 1)
        synchronized (dx.a(this.py)) {
          if (dx.b(this.py).bp() && dx.b(this.py).isConnected() && dx.a(this.py).contains(param1Message.obj)) {
            Bundle bundle = dx.b(this.py).aU();
            ((GoogleApiClient.ConnectionCallbacks)param1Message.obj).onConnected(bundle);
          } 
          return;
        }  
      Log.wtf("GmsClientEvents", "Don't know how to handle this message.");
    }
  }
  
  public static interface b {
    Bundle aU();
    
    boolean bp();
    
    boolean isConnected();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */