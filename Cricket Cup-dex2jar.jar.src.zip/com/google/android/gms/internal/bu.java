package com.google.android.gms.internal;

import android.content.Context;

public final class bu {
  public static cm a(Context paramContext, bz.a parama, h paramh, cw paramcw, bb parambb, a parama1) {
    bv bv = new bv(paramContext, parama, paramh, paramcw, parambb, parama1);
    bv.start();
    return bv;
  }
  
  public static interface a {
    void a(cj param1cj);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */