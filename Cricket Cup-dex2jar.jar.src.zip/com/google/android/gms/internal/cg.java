package com.google.android.gms.internal;

import java.util.Map;

public final class cg {
  private final Object fx = new Object();
  
  private cw gv;
  
  private String hK;
  
  private String hL;
  
  public final an hM = new an(this) {
      public void a(cw param1cw, Map<String, String> param1Map) {
        synchronized (cg.a(this.hO)) {
          String str2 = param1Map.get("type");
          String str1 = param1Map.get("errors");
          ct.v("Invalid " + str2 + " request error: " + str1);
          cg.a(this.hO, 1);
          cg.a(this.hO).notify();
          return;
        } 
      }
    };
  
  public final an hN = new an(this) {
      public void a(cw param1cw, Map<String, String> param1Map) {
        synchronized (cg.a(this.hO)) {
          String str2 = param1Map.get("url");
          if (str2 == null) {
            ct.v("URL missing in loadAdUrl GMSG.");
            return;
          } 
          String str1 = str2;
          if (str2.contains("%40mediation_adapters%40")) {
            str1 = str2.replaceAll("%40mediation_adapters%40", cl.b(param1cw.getContext(), param1Map.get("check_adapters"), cg.b(this.hO)));
            ct.u("Ad request URL modified to " + str1);
          } 
          cg.a(this.hO, str1);
          cg.a(this.hO).notify();
          return;
        } 
      }
    };
  
  private int hm = -2;
  
  public cg(String paramString) {
    this.hK = paramString;
  }
  
  public String ap() {
    synchronized (this.fx) {
      while (this.hL == null) {
        int i = this.hm;
        if (i == -2)
          try {
            this.fx.wait();
          } catch (InterruptedException interruptedException) {
            ct.v("Ad request service was interrupted.");
            return null;
          }  
      } 
      return this.hL;
    } 
  }
  
  public void b(cw paramcw) {
    synchronized (this.fx) {
      this.gv = paramcw;
      return;
    } 
  }
  
  public int getErrorCode() {
    synchronized (this.fx) {
      return this.hm;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */