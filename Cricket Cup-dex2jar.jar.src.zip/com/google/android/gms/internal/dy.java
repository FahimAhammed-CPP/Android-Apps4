package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public final class dy implements Handler.Callback {
  private static dy pA;
  
  private static final Object pz = new Object();
  
  private final Context iT;
  
  private final Handler mHandler;
  
  private final HashMap<String, a> pB;
  
  private dy(Context paramContext) {
    this.mHandler = new Handler(paramContext.getMainLooper(), this);
    this.pB = new HashMap<String, a>();
    this.iT = paramContext.getApplicationContext();
  }
  
  public static dy s(Context paramContext) {
    synchronized (pz) {
      if (pA == null)
        pA = new dy(paramContext.getApplicationContext()); 
      return pA;
    } 
  }
  
  public boolean a(String paramString, dw<?>.f paramf) {
    a a2;
    Intent intent1;
    Intent intent2;
    a a3;
    synchronized (this.pB) {
      a a;
      a3 = this.pB.get(paramString);
      if (a3 == null) {
        a3 = new a(this, paramString);
        a3.a(paramf);
        intent2 = (new Intent(paramString)).setPackage("com.google.android.gms");
        a3.q(this.iT.bindService(intent2, a3.bU(), 129));
        this.pB.put(paramString, a3);
        a = a3;
        return a.isBound();
      } 
      this.mHandler.removeMessages(0, a3);
      if (a3.c((dw<?>.f)intent2))
        throw new IllegalStateException("Trying to bind a GmsServiceConnection that was already connected before.  startServiceAction=" + a); 
    } 
    a3.a((dw<?>.f)intent2);
    switch (a3.getState()) {
      case 1:
        intent2.onServiceConnected(a3.getComponentName(), a3.getBinder());
        a2 = a3;
        bool = a2.isBound();
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_5} */
        return bool;
      case 2:
        intent1 = (new Intent((String)a2)).setPackage("com.google.android.gms");
        a3.q(this.iT.bindService(intent1, a3.bU(), 129));
        a1 = a3;
        bool = a1.isBound();
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_5} */
        return bool;
    } 
    a a1 = a3;
    boolean bool = a1.isBound();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_5} */
    return bool;
  }
  
  public void b(String paramString, dw<?>.f paramf) {
    a a;
    synchronized (this.pB) {
      a = this.pB.get(paramString);
      if (a == null)
        throw new IllegalStateException("Nonexistent connection status for service action: " + paramString); 
    } 
    if (!a.c(paramf))
      throw new IllegalStateException("Trying to unbind a GmsServiceConnection  that was not bound before.  startServiceAction=" + paramString); 
    a.b(paramf);
    if (a.bW()) {
      Message message = this.mHandler.obtainMessage(0, a);
      this.mHandler.sendMessageDelayed(message, 5000L);
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  public boolean handleMessage(Message paramMessage) {
    switch (paramMessage.what) {
      default:
        return false;
      case 0:
        break;
    } 
    null = (a)paramMessage.obj;
    synchronized (this.pB) {
      if (null.bW()) {
        this.iT.unbindService(null.bU());
        this.pB.remove(null.bV());
      } 
      return true;
    } 
  }
  
  final class a {
    private int mState;
    
    private final String pC;
    
    private final a pD;
    
    private final HashSet<dw<?>.f> pE;
    
    private boolean pF;
    
    private IBinder pG;
    
    private ComponentName pH;
    
    public a(dy this$0, String param1String) {
      this.pC = param1String;
      this.pD = new a(this);
      this.pE = new HashSet<dw<?>.f>();
      this.mState = 0;
    }
    
    public void a(dw<?>.f param1f) {
      this.pE.add(param1f);
    }
    
    public void b(dw<?>.f param1f) {
      this.pE.remove(param1f);
    }
    
    public a bU() {
      return this.pD;
    }
    
    public String bV() {
      return this.pC;
    }
    
    public boolean bW() {
      return this.pE.isEmpty();
    }
    
    public boolean c(dw<?>.f param1f) {
      return this.pE.contains(param1f);
    }
    
    public IBinder getBinder() {
      return this.pG;
    }
    
    public ComponentName getComponentName() {
      return this.pH;
    }
    
    public int getState() {
      return this.mState;
    }
    
    public boolean isBound() {
      return this.pF;
    }
    
    public void q(boolean param1Boolean) {
      this.pF = param1Boolean;
    }
    
    public class a implements ServiceConnection {
      public a(dy.a this$0) {}
      
      public void onServiceConnected(ComponentName param2ComponentName, IBinder param2IBinder) {
        synchronized (dy.a(this.pJ.pI)) {
          dy.a.a(this.pJ, param2IBinder);
          dy.a.a(this.pJ, param2ComponentName);
          Iterator<dw.f> iterator = dy.a.a(this.pJ).iterator();
          while (iterator.hasNext())
            ((dw.f)iterator.next()).onServiceConnected(param2ComponentName, param2IBinder); 
        } 
        dy.a.a(this.pJ, 1);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
      }
      
      public void onServiceDisconnected(ComponentName param2ComponentName) {
        synchronized (dy.a(this.pJ.pI)) {
          dy.a.a(this.pJ, (IBinder)null);
          dy.a.a(this.pJ, param2ComponentName);
          Iterator<dw.f> iterator = dy.a.a(this.pJ).iterator();
          while (iterator.hasNext())
            ((dw.f)iterator.next()).onServiceDisconnected(param2ComponentName); 
        } 
        dy.a.a(this.pJ, 2);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
      }
    }
  }
  
  public class a implements ServiceConnection {
    public a(dy this$0) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      synchronized (dy.a(this.pJ.pI)) {
        dy.a.a(this.pJ, param1IBinder);
        dy.a.a(this.pJ, param1ComponentName);
        Iterator<dw.f> iterator = dy.a.a(this.pJ).iterator();
        while (iterator.hasNext())
          ((dw.f)iterator.next()).onServiceConnected(param1ComponentName, param1IBinder); 
      } 
      dy.a.a(this.pJ, 1);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      synchronized (dy.a(this.pJ.pI)) {
        dy.a.a(this.pJ, (IBinder)null);
        dy.a.a(this.pJ, param1ComponentName);
        Iterator<dw.f> iterator = dy.a.a(this.pJ).iterator();
        while (iterator.hasNext())
          ((dw.f)iterator.next()).onServiceDisconnected(param1ComponentName); 
      } 
      dy.a.a(this.pJ, 2);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */