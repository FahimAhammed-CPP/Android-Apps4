package com.google.android.gms.internal;

import java.util.Map;

public final class ao implements an {
  private static boolean a(Map<String, String> paramMap) {
    return "1".equals(paramMap.get("custom_close"));
  }
  
  private static int b(Map<String, String> paramMap) {
    String str = paramMap.get("o");
    if (str != null) {
      if ("p".equalsIgnoreCase(str))
        return co.av(); 
      if ("l".equalsIgnoreCase(str))
        return co.au(); 
    } 
    return -1;
  }
  
  public void a(cw paramcw, Map<String, String> paramMap) {
    String str = paramMap.get("a");
    if (str == null) {
      ct.v("Action missing from an open GMSG.");
      return;
    } 
    cx cx = paramcw.aC();
    if ("expand".equalsIgnoreCase(str)) {
      if (paramcw.aF()) {
        ct.v("Cannot expand WebView that is already expanded.");
        return;
      } 
      cx.a(a(paramMap), b(paramMap));
      return;
    } 
    if ("webapp".equalsIgnoreCase(str)) {
      String str1 = paramMap.get("u");
      if (str1 != null) {
        cx.a(a(paramMap), b(paramMap), str1);
        return;
      } 
      cx.a(a(paramMap), b(paramMap), paramMap.get("html"), paramMap.get("baseurl"));
      return;
    } 
    cx.a(new bj(paramMap.get("i"), paramMap.get("u"), paramMap.get("m"), paramMap.get("p"), paramMap.get("c"), paramMap.get("f"), paramMap.get("e")));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */