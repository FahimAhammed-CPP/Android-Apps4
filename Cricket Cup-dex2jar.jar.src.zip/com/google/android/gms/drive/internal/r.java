package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.Contents;

public class r implements Parcelable.Creator<OnContentsResponse> {
  static void a(OnContentsResponse paramOnContentsResponse, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramOnContentsResponse.kg);
    b.a(paramParcel, 2, (Parcelable)paramOnContentsResponse.qK, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public OnContentsResponse G(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    Contents contents = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          contents = (Contents)a.a(paramParcel, k, Contents.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnContentsResponse(i, contents);
  }
  
  public OnContentsResponse[] ag(int paramInt) {
    return new OnContentsResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */