package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

public class a extends p.a {
  public void a(OnContentsResponse paramOnContentsResponse) throws RemoteException {}
  
  public void a(OnDownloadProgressResponse paramOnDownloadProgressResponse) throws RemoteException {}
  
  public void a(OnDriveIdResponse paramOnDriveIdResponse) throws RemoteException {}
  
  public void a(OnListEntriesResponse paramOnListEntriesResponse) throws RemoteException {}
  
  public void a(OnMetadataResponse paramOnMetadataResponse) throws RemoteException {}
  
  public void m(Status paramStatus) throws RemoteException {}
  
  public void onSuccess() throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */