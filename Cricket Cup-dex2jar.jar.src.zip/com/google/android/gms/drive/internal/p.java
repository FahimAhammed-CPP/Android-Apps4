package com.google.android.gms.drive.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

public interface p extends IInterface {
  void a(OnContentsResponse paramOnContentsResponse) throws RemoteException;
  
  void a(OnDownloadProgressResponse paramOnDownloadProgressResponse) throws RemoteException;
  
  void a(OnDriveIdResponse paramOnDriveIdResponse) throws RemoteException;
  
  void a(OnListEntriesResponse paramOnListEntriesResponse) throws RemoteException;
  
  void a(OnMetadataResponse paramOnMetadataResponse) throws RemoteException;
  
  void m(Status paramStatus) throws RemoteException;
  
  void onSuccess() throws RemoteException;
  
  public static abstract class a extends Binder implements p {
    public a() {
      attachInterface(this, "com.google.android.gms.drive.internal.IDriveServiceCallbacks");
    }
    
    public static p D(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
      return (iInterface != null && iInterface instanceof p) ? (p)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      OnListEntriesResponse onListEntriesResponse1;
      OnDriveIdResponse onDriveIdResponse1;
      OnMetadataResponse onMetadataResponse1;
      OnContentsResponse onContentsResponse1;
      Status status;
      OnDownloadProgressResponse onDownloadProgressResponse2 = null;
      OnListEntriesResponse onListEntriesResponse2 = null;
      OnDriveIdResponse onDriveIdResponse2 = null;
      OnMetadataResponse onMetadataResponse2 = null;
      OnContentsResponse onContentsResponse2 = null;
      OnDownloadProgressResponse onDownloadProgressResponse1 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param1Parcel1.readInt() != 0)
            onDownloadProgressResponse1 = (OnDownloadProgressResponse)OnDownloadProgressResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onDownloadProgressResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onDownloadProgressResponse1 = onDownloadProgressResponse2;
          if (param1Parcel1.readInt() != 0)
            onListEntriesResponse1 = (OnListEntriesResponse)OnListEntriesResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onListEntriesResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onListEntriesResponse1 = onListEntriesResponse2;
          if (param1Parcel1.readInt() != 0)
            onDriveIdResponse1 = (OnDriveIdResponse)OnDriveIdResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onDriveIdResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onDriveIdResponse1 = onDriveIdResponse2;
          if (param1Parcel1.readInt() != 0)
            onMetadataResponse1 = (OnMetadataResponse)OnMetadataResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onMetadataResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onMetadataResponse1 = onMetadataResponse2;
          if (param1Parcel1.readInt() != 0)
            onContentsResponse1 = (OnContentsResponse)OnContentsResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onContentsResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onContentsResponse1 = onContentsResponse2;
          if (param1Parcel1.readInt() != 0)
            status = Status.CREATOR.createFromParcel(param1Parcel1); 
          m(status);
          param1Parcel2.writeNoException();
          return true;
        case 7:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
      onSuccess();
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements p {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void a(OnContentsResponse param2OnContentsResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnContentsResponse != null) {
            parcel1.writeInt(1);
            param2OnContentsResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDownloadProgressResponse param2OnDownloadProgressResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDownloadProgressResponse != null) {
            parcel1.writeInt(1);
            param2OnDownloadProgressResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDriveIdResponse param2OnDriveIdResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDriveIdResponse != null) {
            parcel1.writeInt(1);
            param2OnDriveIdResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnListEntriesResponse param2OnListEntriesResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnListEntriesResponse != null) {
            parcel1.writeInt(1);
            param2OnListEntriesResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnMetadataResponse param2OnMetadataResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnMetadataResponse != null) {
            parcel1.writeInt(1);
            param2OnMetadataResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void m(Status param2Status) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2Status != null) {
            parcel1.writeInt(1);
            param2Status.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onSuccess() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          this.dU.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements p {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void a(OnContentsResponse param1OnContentsResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnContentsResponse != null) {
          parcel1.writeInt(1);
          param1OnContentsResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDownloadProgressResponse param1OnDownloadProgressResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDownloadProgressResponse != null) {
          parcel1.writeInt(1);
          param1OnDownloadProgressResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDriveIdResponse param1OnDriveIdResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDriveIdResponse != null) {
          parcel1.writeInt(1);
          param1OnDriveIdResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnListEntriesResponse param1OnListEntriesResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnListEntriesResponse != null) {
          parcel1.writeInt(1);
          param1OnListEntriesResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnMetadataResponse param1OnMetadataResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnMetadataResponse != null) {
          parcel1.writeInt(1);
          param1OnMetadataResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void m(Status param1Status) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1Status != null) {
          parcel1.writeInt(1);
          param1Status.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onSuccess() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        this.dU.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */