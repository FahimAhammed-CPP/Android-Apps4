package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class f implements Parcelable.Creator<CreateFolderRequest> {
  static void a(CreateFolderRequest paramCreateFolderRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramCreateFolderRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramCreateFolderRequest.ra, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramCreateFolderRequest.qZ, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public CreateFolderRequest E(Parcel paramParcel) {
    MetadataBundle metadataBundle = null;
    int j = a.n(paramParcel);
    int i = 0;
    DriveId driveId = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
        case 3:
          metadataBundle = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new CreateFolderRequest(i, driveId, metadataBundle);
  }
  
  public CreateFolderRequest[] ae(int paramInt) {
    return new CreateFolderRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */