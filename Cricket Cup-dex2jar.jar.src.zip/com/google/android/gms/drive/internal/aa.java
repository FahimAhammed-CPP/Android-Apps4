package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class aa implements Parcelable.Creator<UpdateMetadataRequest> {
  static void a(UpdateMetadataRequest paramUpdateMetadataRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramUpdateMetadataRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramUpdateMetadataRequest.rr, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramUpdateMetadataRequest.rB, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public UpdateMetadataRequest O(Parcel paramParcel) {
    MetadataBundle metadataBundle = null;
    int j = a.n(paramParcel);
    int i = 0;
    DriveId driveId = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
        case 3:
          metadataBundle = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new UpdateMetadataRequest(i, driveId, metadataBundle);
  }
  
  public UpdateMetadataRequest[] ao(int paramInt) {
    return new UpdateMetadataRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */