package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Query;

public class QueryRequest implements SafeParcelable {
  public static final Parcelable.Creator<QueryRequest> CREATOR = new y();
  
  final int kg;
  
  final Query rA;
  
  QueryRequest(int paramInt, Query paramQuery) {
    this.kg = paramInt;
    this.rA = paramQuery;
  }
  
  public QueryRequest(Query paramQuery) {
    this(1, paramQuery);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    y.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\QueryRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */