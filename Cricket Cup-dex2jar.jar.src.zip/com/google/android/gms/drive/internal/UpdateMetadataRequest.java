package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class UpdateMetadataRequest implements SafeParcelable {
  public static final Parcelable.Creator<UpdateMetadataRequest> CREATOR = new aa();
  
  final int kg;
  
  final MetadataBundle rB;
  
  final DriveId rr;
  
  UpdateMetadataRequest(int paramInt, DriveId paramDriveId, MetadataBundle paramMetadataBundle) {
    this.kg = paramInt;
    this.rr = paramDriveId;
    this.rB = paramMetadataBundle;
  }
  
  public UpdateMetadataRequest(DriveId paramDriveId, MetadataBundle paramMetadataBundle) {
    this(1, paramDriveId, paramMetadataBundle);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    aa.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\UpdateMetadataRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */