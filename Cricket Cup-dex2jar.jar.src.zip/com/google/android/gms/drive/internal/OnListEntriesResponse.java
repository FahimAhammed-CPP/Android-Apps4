package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnListEntriesResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnListEntriesResponse> CREATOR = new u();
  
  final int kg;
  
  final DataHolder rz;
  
  OnListEntriesResponse(int paramInt, DataHolder paramDataHolder) {
    this.kg = paramInt;
    this.rz = paramDataHolder;
  }
  
  public DataHolder cT() {
    return this.rz;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    u.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\OnListEntriesResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */