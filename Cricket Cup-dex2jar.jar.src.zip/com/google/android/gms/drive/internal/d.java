package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class d implements Parcelable.Creator<CreateFileIntentSenderRequest> {
  static void a(CreateFileIntentSenderRequest paramCreateFileIntentSenderRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramCreateFileIntentSenderRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramCreateFileIntentSenderRequest.qZ, paramInt, false);
    b.c(paramParcel, 3, paramCreateFileIntentSenderRequest.qE);
    b.a(paramParcel, 4, paramCreateFileIntentSenderRequest.qL, false);
    b.a(paramParcel, 5, (Parcelable)paramCreateFileIntentSenderRequest.qM, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public CreateFileIntentSenderRequest C(Parcel paramParcel) {
    int i = 0;
    DriveId driveId = null;
    int k = a.n(paramParcel);
    String str = null;
    MetadataBundle metadataBundle = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.m(paramParcel);
      switch (a.M(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          metadataBundle = (MetadataBundle)a.a(paramParcel, m, MetadataBundle.CREATOR);
          break;
        case 3:
          i = a.g(paramParcel, m);
          break;
        case 4:
          str = a.m(paramParcel, m);
          break;
        case 5:
          driveId = (DriveId)a.a(paramParcel, m, DriveId.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new CreateFileIntentSenderRequest(j, metadataBundle, i, str, driveId);
  }
  
  public CreateFileIntentSenderRequest[] ac(int paramInt) {
    return new CreateFileIntentSenderRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */