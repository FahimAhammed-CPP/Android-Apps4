package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;

public interface DriveResource {
  DriveId getDriveId();
  
  PendingResult<MetadataResult> getMetadata(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<MetadataResult> updateMetadata(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet);
  
  public static interface MetadataResult extends Result {
    Metadata getMetadata();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\DriveResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */