package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.query.Query;

public interface DriveApi {
  PendingResult<Status> discardContents(GoogleApiClient paramGoogleApiClient, Contents paramContents);
  
  PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient paramGoogleApiClient, String paramString);
  
  DriveFile getFile(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId);
  
  DriveFolder getFolder(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId);
  
  DriveFolder getRootFolder(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<ContentsResult> newContents(GoogleApiClient paramGoogleApiClient);
  
  CreateFileActivityBuilder newCreateFileActivityBuilder();
  
  OpenFileActivityBuilder newOpenFileActivityBuilder();
  
  PendingResult<MetadataBufferResult> query(GoogleApiClient paramGoogleApiClient, Query paramQuery);
  
  PendingResult<Status> requestSync(GoogleApiClient paramGoogleApiClient);
  
  public static interface ContentsResult extends Result {
    Contents getContents();
  }
  
  public static interface DriveIdResult extends Result {
    DriveId getDriveId();
  }
  
  public static interface IntentSenderResult extends Result {
    IntentSender getIntentSender();
  }
  
  public static interface MetadataBufferResult extends Result {
    MetadataBuffer getMetadataBuffer();
  }
  
  public static interface OnSyncFinishCallback {
    void onSyncFinish(Status param1Status);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\DriveApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */