package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.b;

public class a implements Parcelable.Creator<Contents> {
  static void a(Contents paramContents, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramContents.kg);
    b.a(paramParcel, 2, (Parcelable)paramContents.om, paramInt, false);
    b.c(paramParcel, 3, paramContents.qE);
    b.c(paramParcel, 4, paramContents.qF);
    b.a(paramParcel, 5, (Parcelable)paramContents.qG, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public Contents[] Y(int paramInt) {
    return new Contents[paramInt];
  }
  
  public Contents y(Parcel paramParcel) {
    DriveId driveId = null;
    int i = 0;
    int m = com.google.android.gms.common.internal.safeparcel.a.n(paramParcel);
    int j = 0;
    ParcelFileDescriptor parcelFileDescriptor = null;
    int k = 0;
    while (paramParcel.dataPosition() < m) {
      int n = com.google.android.gms.common.internal.safeparcel.a.m(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.M(n)) {
        case 1:
          k = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 2:
          parcelFileDescriptor = (ParcelFileDescriptor)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, n, ParcelFileDescriptor.CREATOR);
          break;
        case 3:
          j = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 4:
          i = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 5:
          driveId = (DriveId)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, n, DriveId.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new com.google.android.gms.common.internal.safeparcel.a.a("Overread allowed size end=" + m, paramParcel); 
    return new Contents(k, parcelFileDescriptor, j, i, driveId);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */