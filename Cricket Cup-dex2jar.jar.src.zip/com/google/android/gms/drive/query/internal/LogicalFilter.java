package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;
import java.util.ArrayList;
import java.util.List;

public class LogicalFilter implements SafeParcelable, Filter {
  public static final Parcelable.Creator<LogicalFilter> CREATOR = new f();
  
  final int kg;
  
  private List<Filter> rQ;
  
  final Operator rR;
  
  final List<FilterHolder> sb;
  
  LogicalFilter(int paramInt, Operator paramOperator, List<FilterHolder> paramList) {
    this.kg = paramInt;
    this.rR = paramOperator;
    this.sb = paramList;
  }
  
  public LogicalFilter(Operator paramOperator, Filter paramFilter, Filter... paramVarArgs) {
    this.kg = 1;
    this.rR = paramOperator;
    this.sb = new ArrayList<FilterHolder>(paramVarArgs.length + 1);
    this.sb.add(new FilterHolder(paramFilter));
    this.rQ = new ArrayList<Filter>(paramVarArgs.length + 1);
    this.rQ.add(paramFilter);
    int j = paramVarArgs.length;
    int i;
    for (i = 0; i < j; i++) {
      Filter filter = paramVarArgs[i];
      this.sb.add(new FilterHolder(filter));
      this.rQ.add(filter);
    } 
  }
  
  public LogicalFilter(Operator paramOperator, List<Filter> paramList) {
    this.kg = 1;
    this.rR = paramOperator;
    this.rQ = paramList;
    this.sb = new ArrayList<FilterHolder>(paramList.size());
    for (Filter filter : paramList)
      this.sb.add(new FilterHolder(filter)); 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    f.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\LogicalFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */