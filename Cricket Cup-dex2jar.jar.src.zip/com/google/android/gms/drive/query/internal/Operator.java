package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class Operator implements SafeParcelable {
  public static final Parcelable.Creator<Operator> CREATOR = new h();
  
  public static final Operator sd = new Operator("=");
  
  public static final Operator se = new Operator("<");
  
  public static final Operator sf = new Operator("<=");
  
  public static final Operator sg = new Operator(">");
  
  public static final Operator sh = new Operator(">=");
  
  public static final Operator si = new Operator("and");
  
  public static final Operator sj = new Operator("or");
  
  public static final Operator sk = new Operator("not");
  
  public static final Operator sl = new Operator("contains");
  
  final int kg;
  
  final String mTag;
  
  Operator(int paramInt, String paramString) {
    this.kg = paramInt;
    this.mTag = paramString;
  }
  
  private Operator(String paramString) {
    this(1, paramString);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.mTag == null)
        return !(((Operator)paramObject).mTag != null); 
      if (!this.mTag.equals(((Operator)paramObject).mTag))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    if (this.mTag == null) {
      byte b = 0;
      return b + 31;
    } 
    int i = this.mTag.hashCode();
    return i + 31;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    h.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\Operator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */