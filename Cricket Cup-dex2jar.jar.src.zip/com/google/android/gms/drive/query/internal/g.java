package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class g implements Parcelable.Creator<NotFilter> {
  static void a(NotFilter paramNotFilter, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1000, paramNotFilter.kg);
    b.a(paramParcel, 1, (Parcelable)paramNotFilter.sc, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public NotFilter W(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    FilterHolder filterHolder;
    for (filterHolder = null; paramParcel.dataPosition() < j; filterHolder = (FilterHolder)a.a(paramParcel, k, FilterHolder.CREATOR)) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        default:
          a.b(paramParcel, k);
          continue;
        case 1000:
          i = a.g(paramParcel, k);
          continue;
        case 1:
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new NotFilter(i, filterHolder);
  }
  
  public NotFilter[] aw(int paramInt) {
    return new NotFilter[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */