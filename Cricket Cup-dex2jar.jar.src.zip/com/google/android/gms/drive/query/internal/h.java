package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class h implements Parcelable.Creator<Operator> {
  static void a(Operator paramOperator, Parcel paramParcel, int paramInt) {
    paramInt = b.o(paramParcel);
    b.c(paramParcel, 1000, paramOperator.kg);
    b.a(paramParcel, 1, paramOperator.mTag, false);
    b.D(paramParcel, paramInt);
  }
  
  public Operator X(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    String str;
    for (str = null; paramParcel.dataPosition() < j; str = a.m(paramParcel, k)) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        default:
          a.b(paramParcel, k);
          continue;
        case 1000:
          i = a.g(paramParcel, k);
          continue;
        case 1:
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new Operator(i, str);
  }
  
  public Operator[] ax(int paramInt) {
    return new Operator[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */