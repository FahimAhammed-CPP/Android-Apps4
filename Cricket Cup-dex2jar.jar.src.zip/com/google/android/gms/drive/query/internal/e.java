package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class e implements Parcelable.Creator<InFilter> {
  static void a(InFilter paramInFilter, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1000, paramInFilter.kg);
    b.a(paramParcel, 1, (Parcelable)paramInFilter.rS, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public InFilter U(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    MetadataBundle metadataBundle;
    for (metadataBundle = null; paramParcel.dataPosition() < j; metadataBundle = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR)) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        default:
          a.b(paramParcel, k);
          continue;
        case 1000:
          i = a.g(paramParcel, k);
          continue;
        case 1:
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new InFilter(i, metadataBundle);
  }
  
  public InFilter[] au(int paramInt) {
    return new InFilter[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */