package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class MetadataBundle implements SafeParcelable {
  public static final Parcelable.Creator<MetadataBundle> CREATOR = new d();
  
  final int kg;
  
  final Bundle rF;
  
  MetadataBundle(int paramInt, Bundle paramBundle) {
    this.kg = paramInt;
    this.rF = (Bundle)eg.f(paramBundle);
    this.rF.setClassLoader(getClass().getClassLoader());
    ArrayList<String> arrayList = new ArrayList();
    for (String str : this.rF.keySet()) {
      if (c.ac(str) == null) {
        arrayList.add(str);
        Log.w("MetadataBundle", "Ignored unknown metadata field in bundle: " + str);
      } 
    } 
    for (String str : arrayList)
      this.rF.remove(str); 
  }
  
  private MetadataBundle(Bundle paramBundle) {
    this(1, paramBundle);
  }
  
  public static <T> MetadataBundle a(MetadataField<T> paramMetadataField, T paramT) {
    MetadataBundle metadataBundle = cX();
    metadataBundle.b(paramMetadataField, paramT);
    return metadataBundle;
  }
  
  public static MetadataBundle a(MetadataBundle paramMetadataBundle) {
    return new MetadataBundle(new Bundle(paramMetadataBundle.rF));
  }
  
  public static MetadataBundle cX() {
    return new MetadataBundle(new Bundle());
  }
  
  public <T> T a(MetadataField<T> paramMetadataField) {
    return (T)paramMetadataField.d(this.rF);
  }
  
  public <T> void b(MetadataField<T> paramMetadataField, T paramT) {
    if (c.ac(paramMetadataField.getName()) == null)
      throw new IllegalArgumentException("Unregistered field: " + paramMetadataField.getName()); 
    paramMetadataField.a(paramT, this.rF);
  }
  
  public Set<MetadataField<?>> cY() {
    HashSet<MetadataField<?>> hashSet = new HashSet();
    Iterator<String> iterator = this.rF.keySet().iterator();
    while (iterator.hasNext())
      hashSet.add(c.ac(iterator.next())); 
    return hashSet;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof MetadataBundle))
      return false; 
    paramObject = paramObject;
    Set set = this.rF.keySet();
    if (!set.equals(((MetadataBundle)paramObject).rF.keySet()))
      return false; 
    for (String str : set) {
      if (!ee.equal(this.rF.get(str), ((MetadataBundle)paramObject).rF.get(str)))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    Iterator<String> iterator = this.rF.keySet().iterator();
    int i;
    for (i = 1; iterator.hasNext(); i = this.rF.get(str).hashCode() + i * 31)
      String str = iterator.next(); 
    return i;
  }
  
  public String toString() {
    return "MetadataBundle [values=" + this.rF + "]";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\metadata\internal\MetadataBundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */