package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;

public class a extends MetadataField<Boolean> {
  public a(String paramString) {
    super(paramString);
  }
  
  protected void a(Bundle paramBundle, Boolean paramBoolean) {
    paramBundle.putBoolean(getName(), paramBoolean.booleanValue());
  }
  
  protected Boolean e(DataHolder paramDataHolder, int paramInt1, int paramInt2) {
    return Boolean.valueOf(paramDataHolder.getBoolean(getName(), paramInt1, paramInt2));
  }
  
  protected Boolean g(Bundle paramBundle) {
    return Boolean.valueOf(paramBundle.getBoolean(getName()));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\metadata\internal\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */