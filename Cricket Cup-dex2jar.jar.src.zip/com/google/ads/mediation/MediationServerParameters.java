package com.google.ads.mediation;

import com.google.android.gms.internal.ct;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public abstract class MediationServerParameters {
  protected void a() {}
  
  public void load(Map<String, String> paramMap) throws MappingException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Field field : getClass().getFields()) {
      Parameter parameter = field.<Parameter>getAnnotation(Parameter.class);
      if (parameter != null)
        hashMap.put(parameter.name(), field); 
    } 
    if (hashMap.isEmpty())
      ct.v("No server options fields detected. To suppress this message either add a field with the @Parameter annotation, or override the load() method."); 
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      Field field = (Field)hashMap.remove(entry.getKey());
      if (field != null) {
        try {
          field.set(this, entry.getValue());
        } catch (IllegalAccessException illegalAccessException) {
          ct.v("Server option \"" + (String)entry.getKey() + "\" could not be set: Illegal Access");
        } catch (IllegalArgumentException illegalArgumentException) {
          ct.v("Server option \"" + (String)entry.getKey() + "\" could not be set: Bad Type");
        } 
        continue;
      } 
      ct.r("Unexpected server option: " + (String)entry.getKey() + " = \"" + (String)entry.getValue() + "\"");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    for (Field field : hashMap.values()) {
      if (((Parameter)field.<Parameter>getAnnotation(Parameter.class)).required()) {
        ct.v("Required server option missing: " + ((Parameter)field.<Parameter>getAnnotation(Parameter.class)).name());
        if (stringBuilder.length() > 0)
          stringBuilder.append(", "); 
        stringBuilder.append(((Parameter)field.<Parameter>getAnnotation(Parameter.class)).name());
      } 
    } 
    if (stringBuilder.length() > 0)
      throw new MappingException("Required server option(s) missing: " + stringBuilder.toString()); 
    a();
  }
  
  public static final class MappingException extends Exception {
    public MappingException(String param1String) {
      super(param1String);
    }
  }
  
  @Retention(RetentionPolicy.RUNTIME)
  @Target({ElementType.FIELD})
  protected static @interface Parameter {
    String name();
    
    boolean required() default true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\MediationServerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */