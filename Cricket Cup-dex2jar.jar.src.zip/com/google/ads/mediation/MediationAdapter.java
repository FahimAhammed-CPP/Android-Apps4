package com.google.ads.mediation;

@Deprecated
public interface MediationAdapter<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS extends MediationServerParameters> {
  void destroy();
  
  Class<ADDITIONAL_PARAMETERS> getAdditionalParametersType();
  
  Class<SERVER_PARAMETERS> getServerParametersType();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\MediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */