package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.google.android.gms.internal.ct;

public final class CustomEventAdapter implements MediationBannerAdapter<CustomEventExtras, CustomEventServerParameters>, MediationInterstitialAdapter<CustomEventExtras, CustomEventServerParameters> {
  private View m;
  
  private CustomEventBanner n;
  
  private CustomEventInterstitial o;
  
  private static <T> T a(String paramString) {
    try {
      return (T)Class.forName(paramString).newInstance();
    } catch (Throwable throwable) {
      ct.v("Could not instantiate custom event adapter: " + paramString + ". " + throwable.getMessage());
      return null;
    } 
  }
  
  private void a(View paramView) {
    this.m = paramView;
  }
  
  public void destroy() {
    if (this.n != null)
      this.n.destroy(); 
    if (this.o != null)
      this.o.destroy(); 
  }
  
  public Class<CustomEventExtras> getAdditionalParametersType() {
    return CustomEventExtras.class;
  }
  
  public View getBannerView() {
    return this.m;
  }
  
  public Class<CustomEventServerParameters> getServerParametersType() {
    return CustomEventServerParameters.class;
  }
  
  public void requestBannerAd(MediationBannerListener paramMediationBannerListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.n = a(paramCustomEventServerParameters.className);
    if (this.n == null) {
      paramMediationBannerListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.n.requestBannerAd(new a(this, paramMediationBannerListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramAdSize, paramMediationAdRequest, object);
  }
  
  public void requestInterstitialAd(MediationInterstitialListener paramMediationInterstitialListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.o = a(paramCustomEventServerParameters.className);
    if (this.o == null) {
      paramMediationInterstitialListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.o.requestInterstitialAd(new b(this, this, paramMediationInterstitialListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramMediationAdRequest, object);
  }
  
  public void showInterstitial() {
    this.o.showInterstitial();
  }
  
  private static final class a implements CustomEventBannerListener {
    private final MediationBannerListener k;
    
    private final CustomEventAdapter p;
    
    public a(CustomEventAdapter param1CustomEventAdapter, MediationBannerListener param1MediationBannerListener) {
      this.p = param1CustomEventAdapter;
      this.k = param1MediationBannerListener;
    }
    
    public void onClick() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.k.onClick(this.p);
    }
    
    public void onDismissScreen() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.k.onDismissScreen(this.p);
    }
    
    public void onFailedToReceiveAd() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.k.onFailedToReceiveAd(this.p, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.k.onLeaveApplication(this.p);
    }
    
    public void onPresentScreen() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.k.onPresentScreen(this.p);
    }
    
    public void onReceivedAd(View param1View) {
      ct.r("Custom event adapter called onReceivedAd.");
      CustomEventAdapter.a(this.p, param1View);
      this.k.onReceivedAd(this.p);
    }
  }
  
  private class b implements CustomEventInterstitialListener {
    private final MediationInterstitialListener l;
    
    private final CustomEventAdapter p;
    
    public b(CustomEventAdapter this$0, CustomEventAdapter param1CustomEventAdapter1, MediationInterstitialListener param1MediationInterstitialListener) {
      this.p = param1CustomEventAdapter1;
      this.l = param1MediationInterstitialListener;
    }
    
    public void onDismissScreen() {
      ct.r("Custom event adapter called onDismissScreen.");
      this.l.onDismissScreen(this.p);
    }
    
    public void onFailedToReceiveAd() {
      ct.r("Custom event adapter called onFailedToReceiveAd.");
      this.l.onFailedToReceiveAd(this.p, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication() {
      ct.r("Custom event adapter called onLeaveApplication.");
      this.l.onLeaveApplication(this.p);
    }
    
    public void onPresentScreen() {
      ct.r("Custom event adapter called onPresentScreen.");
      this.l.onPresentScreen(this.p);
    }
    
    public void onReceivedAd() {
      ct.r("Custom event adapter called onReceivedAd.");
      this.l.onReceivedAd(this.q);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */