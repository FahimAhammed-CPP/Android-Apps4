package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.MediationServerParameters.Parameter;

public final class AdMobServerParameters extends MediationServerParameters {
  public String adJson;
  
  @Parameter(name = "pubid")
  public String adUnitId;
  
  @Parameter(name = "mad_hac", required = false)
  public String allowHouseAds = null;
  
  public int tagForChildDirectedTreatment = -1;
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\admob\AdMobServerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */