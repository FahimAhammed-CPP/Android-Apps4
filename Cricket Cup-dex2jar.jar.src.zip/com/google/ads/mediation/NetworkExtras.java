package com.google.ads.mediation;

import com.google.android.gms.ads.mediation.NetworkExtras;

@Deprecated
public interface NetworkExtras extends NetworkExtras {}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\NetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */