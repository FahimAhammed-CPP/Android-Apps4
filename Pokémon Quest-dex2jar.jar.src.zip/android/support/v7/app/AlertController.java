package android.support.v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.appcompat.R;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import java.lang.ref.WeakReference;

class AlertController {
  ListAdapter mAdapter;
  
  private int mAlertDialogLayout;
  
  private final View.OnClickListener mButtonHandler = new View.OnClickListener() {
      public void onClick(View param1View) {
        Message message;
        if (param1View == AlertController.this.mButtonPositive && AlertController.this.mButtonPositiveMessage != null) {
          message = Message.obtain(AlertController.this.mButtonPositiveMessage);
        } else if (message == AlertController.this.mButtonNegative && AlertController.this.mButtonNegativeMessage != null) {
          message = Message.obtain(AlertController.this.mButtonNegativeMessage);
        } else if (message == AlertController.this.mButtonNeutral && AlertController.this.mButtonNeutralMessage != null) {
          message = Message.obtain(AlertController.this.mButtonNeutralMessage);
        } else {
          message = null;
        } 
        if (message != null)
          message.sendToTarget(); 
        AlertController.this.mHandler.obtainMessage(1, AlertController.this.mDialog).sendToTarget();
      }
    };
  
  Button mButtonNegative;
  
  Message mButtonNegativeMessage;
  
  private CharSequence mButtonNegativeText;
  
  Button mButtonNeutral;
  
  Message mButtonNeutralMessage;
  
  private CharSequence mButtonNeutralText;
  
  private int mButtonPanelLayoutHint = 0;
  
  private int mButtonPanelSideLayout;
  
  Button mButtonPositive;
  
  Message mButtonPositiveMessage;
  
  private CharSequence mButtonPositiveText;
  
  int mCheckedItem = -1;
  
  private final Context mContext;
  
  private View mCustomTitleView;
  
  final AppCompatDialog mDialog;
  
  Handler mHandler;
  
  private Drawable mIcon;
  
  private int mIconId = 0;
  
  private ImageView mIconView;
  
  int mListItemLayout;
  
  int mListLayout;
  
  ListView mListView;
  
  private CharSequence mMessage;
  
  private TextView mMessageView;
  
  int mMultiChoiceItemLayout;
  
  NestedScrollView mScrollView;
  
  private boolean mShowTitle;
  
  int mSingleChoiceItemLayout;
  
  private CharSequence mTitle;
  
  private TextView mTitleView;
  
  private View mView;
  
  private int mViewLayoutResId;
  
  private int mViewSpacingBottom;
  
  private int mViewSpacingLeft;
  
  private int mViewSpacingRight;
  
  private boolean mViewSpacingSpecified = false;
  
  private int mViewSpacingTop;
  
  private final Window mWindow;
  
  public AlertController(Context paramContext, AppCompatDialog paramAppCompatDialog, Window paramWindow) {
    this.mContext = paramContext;
    this.mDialog = paramAppCompatDialog;
    this.mWindow = paramWindow;
    this.mHandler = new ButtonHandler((DialogInterface)paramAppCompatDialog);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, R.styleable.AlertDialog, R.attr.alertDialogStyle, 0);
    this.mAlertDialogLayout = typedArray.getResourceId(R.styleable.AlertDialog_android_layout, 0);
    this.mButtonPanelSideLayout = typedArray.getResourceId(R.styleable.AlertDialog_buttonPanelSideLayout, 0);
    this.mListLayout = typedArray.getResourceId(R.styleable.AlertDialog_listLayout, 0);
    this.mMultiChoiceItemLayout = typedArray.getResourceId(R.styleable.AlertDialog_multiChoiceItemLayout, 0);
    this.mSingleChoiceItemLayout = typedArray.getResourceId(R.styleable.AlertDialog_singleChoiceItemLayout, 0);
    this.mListItemLayout = typedArray.getResourceId(R.styleable.AlertDialog_listItemLayout, 0);
    this.mShowTitle = typedArray.getBoolean(R.styleable.AlertDialog_showTitle, true);
    typedArray.recycle();
    paramAppCompatDialog.supportRequestWindowFeature(1);
  }
  
  static boolean canTextInput(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      int j = i - 1;
      i = j;
      if (canTextInput(viewGroup.getChildAt(j)))
        return true; 
    } 
    return false;
  }
  
  private void centerButton(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  static void manageScrollIndicators(View paramView1, View paramView2, View paramView3) {
    boolean bool = false;
    if (paramView2 != null) {
      byte b;
      if (ViewCompat.canScrollVertically(paramView1, -1)) {
        b = 0;
      } else {
        b = 4;
      } 
      paramView2.setVisibility(b);
    } 
    if (paramView3 != null) {
      byte b;
      if (ViewCompat.canScrollVertically(paramView1, 1)) {
        b = bool;
      } else {
        b = 4;
      } 
      paramView3.setVisibility(b);
    } 
  }
  
  @Nullable
  private ViewGroup resolvePanel(@Nullable View paramView1, @Nullable View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  private int selectContentView() {
    int i = this.mButtonPanelSideLayout;
    return (i == 0) ? this.mAlertDialogLayout : ((this.mButtonPanelLayoutHint == 1) ? i : this.mAlertDialogLayout);
  }
  
  private void setScrollIndicators(ViewGroup paramViewGroup, final View top, int paramInt1, int paramInt2) {
    View view2 = this.mWindow.findViewById(R.id.scrollIndicatorUp);
    final View bottom = this.mWindow.findViewById(R.id.scrollIndicatorDown);
    if (Build.VERSION.SDK_INT >= 23) {
      ViewCompat.setScrollIndicators(top, paramInt1, paramInt2);
      if (view2 != null)
        paramViewGroup.removeView(view2); 
      if (view1 != null) {
        paramViewGroup.removeView(view1);
        return;
      } 
    } else {
      View view = null;
      top = view2;
      if (view2 != null) {
        top = view2;
        if ((paramInt1 & 0x1) == 0) {
          paramViewGroup.removeView(view2);
          top = null;
        } 
      } 
      if (view1 != null && (paramInt1 & 0x2) == 0) {
        paramViewGroup.removeView(view1);
        view1 = view;
      } 
      if (top != null || view1 != null) {
        if (this.mMessage != null) {
          this.mScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
                public void onScrollChange(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
                  AlertController.manageScrollIndicators((View)param1NestedScrollView, top, bottom);
                }
              });
          this.mScrollView.post(new Runnable() {
                public void run() {
                  AlertController.manageScrollIndicators((View)AlertController.this.mScrollView, top, bottom);
                }
              });
          return;
        } 
        ListView listView = this.mListView;
        if (listView != null) {
          listView.setOnScrollListener(new AbsListView.OnScrollListener() {
                public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {
                  AlertController.manageScrollIndicators((View)param1AbsListView, top, bottom);
                }
                
                public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {}
              });
          this.mListView.post(new Runnable() {
                public void run() {
                  AlertController.manageScrollIndicators((View)AlertController.this.mListView, top, bottom);
                }
              });
          return;
        } 
        if (top != null)
          paramViewGroup.removeView(top); 
        if (view1 != null)
          paramViewGroup.removeView(view1); 
      } 
    } 
  }
  
  private void setupButtons(ViewGroup paramViewGroup) {
    int i;
    this.mButtonPositive = (Button)paramViewGroup.findViewById(16908313);
    this.mButtonPositive.setOnClickListener(this.mButtonHandler);
    boolean bool1 = TextUtils.isEmpty(this.mButtonPositiveText);
    boolean bool = true;
    if (bool1) {
      this.mButtonPositive.setVisibility(8);
      i = 0;
    } else {
      this.mButtonPositive.setText(this.mButtonPositiveText);
      this.mButtonPositive.setVisibility(0);
      i = 1;
    } 
    this.mButtonNegative = (Button)paramViewGroup.findViewById(16908314);
    this.mButtonNegative.setOnClickListener(this.mButtonHandler);
    if (TextUtils.isEmpty(this.mButtonNegativeText)) {
      this.mButtonNegative.setVisibility(8);
    } else {
      this.mButtonNegative.setText(this.mButtonNegativeText);
      this.mButtonNegative.setVisibility(0);
      i |= 0x2;
    } 
    this.mButtonNeutral = (Button)paramViewGroup.findViewById(16908315);
    this.mButtonNeutral.setOnClickListener(this.mButtonHandler);
    if (TextUtils.isEmpty(this.mButtonNeutralText)) {
      this.mButtonNeutral.setVisibility(8);
    } else {
      this.mButtonNeutral.setText(this.mButtonNeutralText);
      this.mButtonNeutral.setVisibility(0);
      i |= 0x4;
    } 
    if (shouldCenterSingleButton(this.mContext))
      if (i == 1) {
        centerButton(this.mButtonPositive);
      } else if (i == 2) {
        centerButton(this.mButtonNegative);
      } else if (i == 4) {
        centerButton(this.mButtonNeutral);
      }  
    if (i != 0) {
      i = bool;
    } else {
      i = 0;
    } 
    if (i == 0)
      paramViewGroup.setVisibility(8); 
  }
  
  private void setupContent(ViewGroup paramViewGroup) {
    this.mScrollView = (NestedScrollView)this.mWindow.findViewById(R.id.scrollView);
    this.mScrollView.setFocusable(false);
    this.mScrollView.setNestedScrollingEnabled(false);
    this.mMessageView = (TextView)paramViewGroup.findViewById(16908299);
    TextView textView = this.mMessageView;
    if (textView == null)
      return; 
    CharSequence charSequence = this.mMessage;
    if (charSequence != null) {
      textView.setText(charSequence);
      return;
    } 
    textView.setVisibility(8);
    this.mScrollView.removeView((View)this.mMessageView);
    if (this.mListView != null) {
      paramViewGroup = (ViewGroup)this.mScrollView.getParent();
      int i = paramViewGroup.indexOfChild((View)this.mScrollView);
      paramViewGroup.removeViewAt(i);
      paramViewGroup.addView((View)this.mListView, i, new ViewGroup.LayoutParams(-1, -1));
      return;
    } 
    paramViewGroup.setVisibility(8);
  }
  
  private void setupCustomContent(ViewGroup paramViewGroup) {
    View view = this.mView;
    boolean bool = false;
    if (view == null)
      if (this.mViewLayoutResId != 0) {
        view = LayoutInflater.from(this.mContext).inflate(this.mViewLayoutResId, paramViewGroup, false);
      } else {
        view = null;
      }  
    if (view != null)
      bool = true; 
    if (!bool || !canTextInput(view))
      this.mWindow.setFlags(131072, 131072); 
    if (bool) {
      FrameLayout frameLayout = (FrameLayout)this.mWindow.findViewById(R.id.custom);
      frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
      if (this.mViewSpacingSpecified)
        frameLayout.setPadding(this.mViewSpacingLeft, this.mViewSpacingTop, this.mViewSpacingRight, this.mViewSpacingBottom); 
      if (this.mListView != null) {
        ((LinearLayout.LayoutParams)paramViewGroup.getLayoutParams()).weight = 0.0F;
        return;
      } 
    } else {
      paramViewGroup.setVisibility(8);
    } 
  }
  
  private void setupTitle(ViewGroup paramViewGroup) {
    Drawable drawable;
    if (this.mCustomTitleView != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(this.mCustomTitleView, 0, layoutParams);
      this.mWindow.findViewById(R.id.title_template).setVisibility(8);
      return;
    } 
    this.mIconView = (ImageView)this.mWindow.findViewById(16908294);
    if ((TextUtils.isEmpty(this.mTitle) ^ true) != 0 && this.mShowTitle) {
      this.mTitleView = (TextView)this.mWindow.findViewById(R.id.alertTitle);
      this.mTitleView.setText(this.mTitle);
      int i = this.mIconId;
      if (i != 0) {
        this.mIconView.setImageResource(i);
        return;
      } 
      drawable = this.mIcon;
      if (drawable != null) {
        this.mIconView.setImageDrawable(drawable);
        return;
      } 
      this.mTitleView.setPadding(this.mIconView.getPaddingLeft(), this.mIconView.getPaddingTop(), this.mIconView.getPaddingRight(), this.mIconView.getPaddingBottom());
      this.mIconView.setVisibility(8);
      return;
    } 
    this.mWindow.findViewById(R.id.title_template).setVisibility(8);
    this.mIconView.setVisibility(8);
    drawable.setVisibility(8);
  }
  
  private void setupView() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mWindow : Landroid/view/Window;
    //   4: getstatic android/support/v7/appcompat/R$id.parentPanel : I
    //   7: invokevirtual findViewById : (I)Landroid/view/View;
    //   10: astore #6
    //   12: aload #6
    //   14: getstatic android/support/v7/appcompat/R$id.topPanel : I
    //   17: invokevirtual findViewById : (I)Landroid/view/View;
    //   20: astore #8
    //   22: aload #6
    //   24: getstatic android/support/v7/appcompat/R$id.contentPanel : I
    //   27: invokevirtual findViewById : (I)Landroid/view/View;
    //   30: astore #7
    //   32: aload #6
    //   34: getstatic android/support/v7/appcompat/R$id.buttonPanel : I
    //   37: invokevirtual findViewById : (I)Landroid/view/View;
    //   40: astore #5
    //   42: aload #6
    //   44: getstatic android/support/v7/appcompat/R$id.customPanel : I
    //   47: invokevirtual findViewById : (I)Landroid/view/View;
    //   50: checkcast android/view/ViewGroup
    //   53: astore #6
    //   55: aload_0
    //   56: aload #6
    //   58: invokespecial setupCustomContent : (Landroid/view/ViewGroup;)V
    //   61: aload #6
    //   63: getstatic android/support/v7/appcompat/R$id.topPanel : I
    //   66: invokevirtual findViewById : (I)Landroid/view/View;
    //   69: astore #11
    //   71: aload #6
    //   73: getstatic android/support/v7/appcompat/R$id.contentPanel : I
    //   76: invokevirtual findViewById : (I)Landroid/view/View;
    //   79: astore #10
    //   81: aload #6
    //   83: getstatic android/support/v7/appcompat/R$id.buttonPanel : I
    //   86: invokevirtual findViewById : (I)Landroid/view/View;
    //   89: astore #9
    //   91: aload_0
    //   92: aload #11
    //   94: aload #8
    //   96: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   99: astore #8
    //   101: aload_0
    //   102: aload #10
    //   104: aload #7
    //   106: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   109: astore #7
    //   111: aload_0
    //   112: aload #9
    //   114: aload #5
    //   116: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   119: astore #5
    //   121: aload_0
    //   122: aload #7
    //   124: invokespecial setupContent : (Landroid/view/ViewGroup;)V
    //   127: aload_0
    //   128: aload #5
    //   130: invokespecial setupButtons : (Landroid/view/ViewGroup;)V
    //   133: aload_0
    //   134: aload #8
    //   136: invokespecial setupTitle : (Landroid/view/ViewGroup;)V
    //   139: iconst_0
    //   140: istore_2
    //   141: aload #6
    //   143: ifnull -> 161
    //   146: aload #6
    //   148: invokevirtual getVisibility : ()I
    //   151: bipush #8
    //   153: if_icmpeq -> 161
    //   156: iconst_1
    //   157: istore_1
    //   158: goto -> 163
    //   161: iconst_0
    //   162: istore_1
    //   163: aload #8
    //   165: ifnull -> 183
    //   168: aload #8
    //   170: invokevirtual getVisibility : ()I
    //   173: bipush #8
    //   175: if_icmpeq -> 183
    //   178: iconst_1
    //   179: istore_3
    //   180: goto -> 185
    //   183: iconst_0
    //   184: istore_3
    //   185: aload #5
    //   187: ifnull -> 206
    //   190: aload #5
    //   192: invokevirtual getVisibility : ()I
    //   195: bipush #8
    //   197: if_icmpeq -> 206
    //   200: iconst_1
    //   201: istore #4
    //   203: goto -> 209
    //   206: iconst_0
    //   207: istore #4
    //   209: iload #4
    //   211: ifne -> 240
    //   214: aload #7
    //   216: ifnull -> 240
    //   219: aload #7
    //   221: getstatic android/support/v7/appcompat/R$id.textSpacerNoButtons : I
    //   224: invokevirtual findViewById : (I)Landroid/view/View;
    //   227: astore #5
    //   229: aload #5
    //   231: ifnull -> 240
    //   234: aload #5
    //   236: iconst_0
    //   237: invokevirtual setVisibility : (I)V
    //   240: iload_3
    //   241: ifeq -> 318
    //   244: aload_0
    //   245: getfield mScrollView : Landroid/support/v4/widget/NestedScrollView;
    //   248: astore #5
    //   250: aload #5
    //   252: ifnull -> 261
    //   255: aload #5
    //   257: iconst_1
    //   258: invokevirtual setClipToPadding : (Z)V
    //   261: aconst_null
    //   262: astore #6
    //   264: aload_0
    //   265: getfield mMessage : Ljava/lang/CharSequence;
    //   268: ifnonnull -> 286
    //   271: aload_0
    //   272: getfield mListView : Landroid/widget/ListView;
    //   275: ifnonnull -> 286
    //   278: aload #6
    //   280: astore #5
    //   282: iload_1
    //   283: ifeq -> 304
    //   286: aload #6
    //   288: astore #5
    //   290: iload_1
    //   291: ifne -> 304
    //   294: aload #8
    //   296: getstatic android/support/v7/appcompat/R$id.titleDividerNoCustom : I
    //   299: invokevirtual findViewById : (I)Landroid/view/View;
    //   302: astore #5
    //   304: aload #5
    //   306: ifnull -> 344
    //   309: aload #5
    //   311: iconst_0
    //   312: invokevirtual setVisibility : (I)V
    //   315: goto -> 344
    //   318: aload #7
    //   320: ifnull -> 344
    //   323: aload #7
    //   325: getstatic android/support/v7/appcompat/R$id.textSpacerNoTitle : I
    //   328: invokevirtual findViewById : (I)Landroid/view/View;
    //   331: astore #5
    //   333: aload #5
    //   335: ifnull -> 344
    //   338: aload #5
    //   340: iconst_0
    //   341: invokevirtual setVisibility : (I)V
    //   344: aload_0
    //   345: getfield mListView : Landroid/widget/ListView;
    //   348: astore #5
    //   350: aload #5
    //   352: instanceof android/support/v7/app/AlertController$RecycleListView
    //   355: ifeq -> 369
    //   358: aload #5
    //   360: checkcast android/support/v7/app/AlertController$RecycleListView
    //   363: iload_3
    //   364: iload #4
    //   366: invokevirtual setHasDecor : (ZZ)V
    //   369: iload_1
    //   370: ifne -> 419
    //   373: aload_0
    //   374: getfield mListView : Landroid/widget/ListView;
    //   377: astore #5
    //   379: aload #5
    //   381: ifnull -> 387
    //   384: goto -> 393
    //   387: aload_0
    //   388: getfield mScrollView : Landroid/support/v4/widget/NestedScrollView;
    //   391: astore #5
    //   393: aload #5
    //   395: ifnull -> 419
    //   398: iload_2
    //   399: istore_1
    //   400: iload #4
    //   402: ifeq -> 407
    //   405: iconst_2
    //   406: istore_1
    //   407: aload_0
    //   408: aload #7
    //   410: aload #5
    //   412: iload_3
    //   413: iload_1
    //   414: ior
    //   415: iconst_3
    //   416: invokespecial setScrollIndicators : (Landroid/view/ViewGroup;Landroid/view/View;II)V
    //   419: aload_0
    //   420: getfield mListView : Landroid/widget/ListView;
    //   423: astore #5
    //   425: aload #5
    //   427: ifnull -> 471
    //   430: aload_0
    //   431: getfield mAdapter : Landroid/widget/ListAdapter;
    //   434: astore #6
    //   436: aload #6
    //   438: ifnull -> 471
    //   441: aload #5
    //   443: aload #6
    //   445: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   448: aload_0
    //   449: getfield mCheckedItem : I
    //   452: istore_1
    //   453: iload_1
    //   454: iconst_m1
    //   455: if_icmple -> 471
    //   458: aload #5
    //   460: iload_1
    //   461: iconst_1
    //   462: invokevirtual setItemChecked : (IZ)V
    //   465: aload #5
    //   467: iload_1
    //   468: invokevirtual setSelection : (I)V
    //   471: return
  }
  
  private static boolean shouldCenterSingleButton(Context paramContext) {
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
    return (typedValue.data != 0);
  }
  
  public Button getButton(int paramInt) {
    return (paramInt != -3) ? ((paramInt != -2) ? ((paramInt != -1) ? null : this.mButtonPositive) : this.mButtonNegative) : this.mButtonNeutral;
  }
  
  public int getIconAttributeResId(int paramInt) {
    TypedValue typedValue = new TypedValue();
    this.mContext.getTheme().resolveAttribute(paramInt, typedValue, true);
    return typedValue.resourceId;
  }
  
  public ListView getListView() {
    return this.mListView;
  }
  
  public void installContent() {
    int i = selectContentView();
    this.mDialog.setContentView(i);
    setupView();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    NestedScrollView nestedScrollView = this.mScrollView;
    return (nestedScrollView != null && nestedScrollView.executeKeyEvent(paramKeyEvent));
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    NestedScrollView nestedScrollView = this.mScrollView;
    return (nestedScrollView != null && nestedScrollView.executeKeyEvent(paramKeyEvent));
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage) {
    Message message = paramMessage;
    if (paramMessage == null) {
      message = paramMessage;
      if (paramOnClickListener != null)
        message = this.mHandler.obtainMessage(paramInt, paramOnClickListener); 
    } 
    if (paramInt != -3) {
      if (paramInt != -2) {
        if (paramInt == -1) {
          this.mButtonPositiveText = paramCharSequence;
          this.mButtonPositiveMessage = message;
          return;
        } 
        throw new IllegalArgumentException("Button does not exist");
      } 
      this.mButtonNegativeText = paramCharSequence;
      this.mButtonNegativeMessage = message;
      return;
    } 
    this.mButtonNeutralText = paramCharSequence;
    this.mButtonNeutralMessage = message;
  }
  
  public void setButtonPanelLayoutHint(int paramInt) {
    this.mButtonPanelLayoutHint = paramInt;
  }
  
  public void setCustomTitle(View paramView) {
    this.mCustomTitleView = paramView;
  }
  
  public void setIcon(int paramInt) {
    this.mIcon = null;
    this.mIconId = paramInt;
    ImageView imageView = this.mIconView;
    if (imageView != null) {
      if (paramInt != 0) {
        imageView.setVisibility(0);
        this.mIconView.setImageResource(this.mIconId);
        return;
      } 
      imageView.setVisibility(8);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mIcon = paramDrawable;
    this.mIconId = 0;
    ImageView imageView = this.mIconView;
    if (imageView != null) {
      if (paramDrawable != null) {
        imageView.setVisibility(0);
        this.mIconView.setImageDrawable(paramDrawable);
        return;
      } 
      imageView.setVisibility(8);
    } 
  }
  
  public void setMessage(CharSequence paramCharSequence) {
    this.mMessage = paramCharSequence;
    TextView textView = this.mMessageView;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mTitle = paramCharSequence;
    TextView textView = this.mTitleView;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public void setView(int paramInt) {
    this.mView = null;
    this.mViewLayoutResId = paramInt;
    this.mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView) {
    this.mView = paramView;
    this.mViewLayoutResId = 0;
    this.mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mView = paramView;
    this.mViewLayoutResId = 0;
    this.mViewSpacingSpecified = true;
    this.mViewSpacingLeft = paramInt1;
    this.mViewSpacingTop = paramInt2;
    this.mViewSpacingRight = paramInt3;
    this.mViewSpacingBottom = paramInt4;
  }
  
  public static class AlertParams {
    public ListAdapter mAdapter;
    
    public boolean mCancelable;
    
    public int mCheckedItem = -1;
    
    public boolean[] mCheckedItems;
    
    public final Context mContext;
    
    public Cursor mCursor;
    
    public View mCustomTitleView;
    
    public boolean mForceInverseBackground;
    
    public Drawable mIcon;
    
    public int mIconAttrId = 0;
    
    public int mIconId = 0;
    
    public final LayoutInflater mInflater;
    
    public String mIsCheckedColumn;
    
    public boolean mIsMultiChoice;
    
    public boolean mIsSingleChoice;
    
    public CharSequence[] mItems;
    
    public String mLabelColumn;
    
    public CharSequence mMessage;
    
    public DialogInterface.OnClickListener mNegativeButtonListener;
    
    public CharSequence mNegativeButtonText;
    
    public DialogInterface.OnClickListener mNeutralButtonListener;
    
    public CharSequence mNeutralButtonText;
    
    public DialogInterface.OnCancelListener mOnCancelListener;
    
    public DialogInterface.OnMultiChoiceClickListener mOnCheckboxClickListener;
    
    public DialogInterface.OnClickListener mOnClickListener;
    
    public DialogInterface.OnDismissListener mOnDismissListener;
    
    public AdapterView.OnItemSelectedListener mOnItemSelectedListener;
    
    public DialogInterface.OnKeyListener mOnKeyListener;
    
    public OnPrepareListViewListener mOnPrepareListViewListener;
    
    public DialogInterface.OnClickListener mPositiveButtonListener;
    
    public CharSequence mPositiveButtonText;
    
    public boolean mRecycleOnMeasure = true;
    
    public CharSequence mTitle;
    
    public View mView;
    
    public int mViewLayoutResId;
    
    public int mViewSpacingBottom;
    
    public int mViewSpacingLeft;
    
    public int mViewSpacingRight;
    
    public boolean mViewSpacingSpecified = false;
    
    public int mViewSpacingTop;
    
    public AlertParams(Context param1Context) {
      this.mContext = param1Context;
      this.mCancelable = true;
      this.mInflater = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
    
    private void createListView(final AlertController dialog) {
      ArrayAdapter<CharSequence> arrayAdapter;
      final AlertController.RecycleListView listView = (AlertController.RecycleListView)this.mInflater.inflate(dialog.mListLayout, null);
      if (this.mIsMultiChoice) {
        Cursor cursor = this.mCursor;
        if (cursor == null) {
          arrayAdapter = new ArrayAdapter<CharSequence>(this.mContext, dialog.mMultiChoiceItemLayout, 16908308, this.mItems) {
              public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
                param2View = super.getView(param2Int, param2View, param2ViewGroup);
                if (AlertController.AlertParams.this.mCheckedItems != null && AlertController.AlertParams.this.mCheckedItems[param2Int])
                  listView.setItemChecked(param2Int, true); 
                return param2View;
              }
            };
        } else {
          CursorAdapter cursorAdapter = new CursorAdapter(this.mContext, (Cursor)arrayAdapter, false) {
              private final int mIsCheckedIndex;
              
              private final int mLabelIndex;
              
              public void bindView(View param2View, Context param2Context, Cursor param2Cursor) {
                ((CheckedTextView)param2View.findViewById(16908308)).setText(param2Cursor.getString(this.mLabelIndex));
                AlertController.RecycleListView recycleListView = listView;
                int i = param2Cursor.getPosition();
                int j = param2Cursor.getInt(this.mIsCheckedIndex);
                boolean bool = true;
                if (j != 1)
                  bool = false; 
                recycleListView.setItemChecked(i, bool);
              }
              
              public View newView(Context param2Context, Cursor param2Cursor, ViewGroup param2ViewGroup) {
                return AlertController.AlertParams.this.mInflater.inflate(dialog.mMultiChoiceItemLayout, param2ViewGroup, false);
              }
            };
        } 
      } else {
        int i;
        if (this.mIsSingleChoice) {
          i = dialog.mSingleChoiceItemLayout;
        } else {
          i = dialog.mListItemLayout;
        } 
        Cursor cursor = this.mCursor;
        if (cursor != null) {
          SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this.mContext, i, cursor, new String[] { this.mLabelColumn }, new int[] { 16908308 });
        } else {
          ListAdapter listAdapter = this.mAdapter;
          if (listAdapter == null)
            arrayAdapter = new AlertController.CheckedItemAdapter(this.mContext, i, 16908308, this.mItems); 
        } 
      } 
      OnPrepareListViewListener onPrepareListViewListener = this.mOnPrepareListViewListener;
      if (onPrepareListViewListener != null)
        onPrepareListViewListener.onPrepareListView(recycleListView); 
      dialog.mAdapter = (ListAdapter)arrayAdapter;
      dialog.mCheckedItem = this.mCheckedItem;
      if (this.mOnClickListener != null) {
        recycleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
              public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
                AlertController.AlertParams.this.mOnClickListener.onClick((DialogInterface)dialog.mDialog, param2Int);
                if (!AlertController.AlertParams.this.mIsSingleChoice)
                  dialog.mDialog.dismiss(); 
              }
            });
      } else if (this.mOnCheckboxClickListener != null) {
        recycleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
              public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
                if (AlertController.AlertParams.this.mCheckedItems != null)
                  AlertController.AlertParams.this.mCheckedItems[param2Int] = listView.isItemChecked(param2Int); 
                AlertController.AlertParams.this.mOnCheckboxClickListener.onClick((DialogInterface)dialog.mDialog, param2Int, listView.isItemChecked(param2Int));
              }
            });
      } 
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.mOnItemSelectedListener;
      if (onItemSelectedListener != null)
        recycleListView.setOnItemSelectedListener(onItemSelectedListener); 
      if (this.mIsSingleChoice) {
        recycleListView.setChoiceMode(1);
      } else if (this.mIsMultiChoice) {
        recycleListView.setChoiceMode(2);
      } 
      dialog.mListView = recycleListView;
    }
    
    public void apply(AlertController param1AlertController) {
      View view2 = this.mCustomTitleView;
      if (view2 != null) {
        param1AlertController.setCustomTitle(view2);
      } else {
        CharSequence charSequence1 = this.mTitle;
        if (charSequence1 != null)
          param1AlertController.setTitle(charSequence1); 
        Drawable drawable = this.mIcon;
        if (drawable != null)
          param1AlertController.setIcon(drawable); 
        int j = this.mIconId;
        if (j != 0)
          param1AlertController.setIcon(j); 
        j = this.mIconAttrId;
        if (j != 0)
          param1AlertController.setIcon(param1AlertController.getIconAttributeResId(j)); 
      } 
      CharSequence charSequence = this.mMessage;
      if (charSequence != null)
        param1AlertController.setMessage(charSequence); 
      charSequence = this.mPositiveButtonText;
      if (charSequence != null)
        param1AlertController.setButton(-1, charSequence, this.mPositiveButtonListener, null); 
      charSequence = this.mNegativeButtonText;
      if (charSequence != null)
        param1AlertController.setButton(-2, charSequence, this.mNegativeButtonListener, null); 
      charSequence = this.mNeutralButtonText;
      if (charSequence != null)
        param1AlertController.setButton(-3, charSequence, this.mNeutralButtonListener, null); 
      if (this.mItems != null || this.mCursor != null || this.mAdapter != null)
        createListView(param1AlertController); 
      View view1 = this.mView;
      if (view1 != null) {
        if (this.mViewSpacingSpecified) {
          param1AlertController.setView(view1, this.mViewSpacingLeft, this.mViewSpacingTop, this.mViewSpacingRight, this.mViewSpacingBottom);
          return;
        } 
        param1AlertController.setView(view1);
        return;
      } 
      int i = this.mViewLayoutResId;
      if (i != 0)
        param1AlertController.setView(i); 
    }
    
    public static interface OnPrepareListViewListener {
      void onPrepareListView(ListView param2ListView);
    }
  }
  
  class null extends ArrayAdapter<CharSequence> {
    null(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      param1View = super.getView(param1Int, param1View, param1ViewGroup);
      if (this.this$0.mCheckedItems != null && this.this$0.mCheckedItems[param1Int])
        listView.setItemChecked(param1Int, true); 
      return param1View;
    }
  }
  
  class null extends CursorAdapter {
    private final int mIsCheckedIndex;
    
    private final int mLabelIndex;
    
    null(Context param1Context, Cursor param1Cursor, boolean param1Boolean) {
      super(param1Context, param1Cursor, param1Boolean);
      Cursor cursor = getCursor();
      this.mLabelIndex = cursor.getColumnIndexOrThrow(this.this$0.mLabelColumn);
      this.mIsCheckedIndex = cursor.getColumnIndexOrThrow(this.this$0.mIsCheckedColumn);
    }
    
    public void bindView(View param1View, Context param1Context, Cursor param1Cursor) {
      ((CheckedTextView)param1View.findViewById(16908308)).setText(param1Cursor.getString(this.mLabelIndex));
      AlertController.RecycleListView recycleListView = listView;
      int i = param1Cursor.getPosition();
      int j = param1Cursor.getInt(this.mIsCheckedIndex);
      boolean bool = true;
      if (j != 1)
        bool = false; 
      recycleListView.setItemChecked(i, bool);
    }
    
    public View newView(Context param1Context, Cursor param1Cursor, ViewGroup param1ViewGroup) {
      return this.this$0.mInflater.inflate(dialog.mMultiChoiceItemLayout, param1ViewGroup, false);
    }
  }
  
  class null implements AdapterView.OnItemClickListener {
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.this$0.mOnClickListener.onClick((DialogInterface)dialog.mDialog, param1Int);
      if (!this.this$0.mIsSingleChoice)
        dialog.mDialog.dismiss(); 
    }
  }
  
  class null implements AdapterView.OnItemClickListener {
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (this.this$0.mCheckedItems != null)
        this.this$0.mCheckedItems[param1Int] = listView.isItemChecked(param1Int); 
      this.this$0.mOnCheckboxClickListener.onClick((DialogInterface)dialog.mDialog, param1Int, listView.isItemChecked(param1Int));
    }
  }
  
  public static interface OnPrepareListViewListener {
    void onPrepareListView(ListView param1ListView);
  }
  
  private static final class ButtonHandler extends Handler {
    private static final int MSG_DISMISS_DIALOG = 1;
    
    private WeakReference<DialogInterface> mDialog;
    
    public ButtonHandler(DialogInterface param1DialogInterface) {
      this.mDialog = new WeakReference<DialogInterface>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != -3 && i != -2 && i != -1) {
        if (i != 1)
          return; 
        ((DialogInterface)param1Message.obj).dismiss();
        return;
      } 
      ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.mDialog.get(), param1Message.what);
    }
  }
  
  private static class CheckedItemAdapter extends ArrayAdapter<CharSequence> {
    public CheckedItemAdapter(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public boolean hasStableIds() {
      return true;
    }
  }
  
  public static class RecycleListView extends ListView {
    private final int mPaddingBottomNoButtons;
    
    private final int mPaddingTopNoTitle;
    
    public RecycleListView(Context param1Context) {
      this(param1Context, (AttributeSet)null);
    }
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.RecycleListView);
      this.mPaddingBottomNoButtons = typedArray.getDimensionPixelOffset(R.styleable.RecycleListView_paddingBottomNoButtons, -1);
      this.mPaddingTopNoTitle = typedArray.getDimensionPixelOffset(R.styleable.RecycleListView_paddingTopNoTitle, -1);
    }
    
    public void setHasDecor(boolean param1Boolean1, boolean param1Boolean2) {
      if (!param1Boolean2 || !param1Boolean1) {
        int i;
        int j;
        int k = getPaddingLeft();
        if (param1Boolean1) {
          i = getPaddingTop();
        } else {
          i = this.mPaddingTopNoTitle;
        } 
        int m = getPaddingRight();
        if (param1Boolean2) {
          j = getPaddingBottom();
        } else {
          j = this.mPaddingBottomNoButtons;
        } 
        setPadding(k, i, m, j);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */