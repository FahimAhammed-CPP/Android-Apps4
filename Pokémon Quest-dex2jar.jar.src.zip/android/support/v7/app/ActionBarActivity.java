package android.support.v7.app;

@Deprecated
public class ActionBarActivity extends AppCompatActivity {}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\app\ActionBarActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */