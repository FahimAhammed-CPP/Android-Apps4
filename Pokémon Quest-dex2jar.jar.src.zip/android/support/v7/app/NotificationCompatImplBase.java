package android.support.v7.app;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationCompatBase;
import android.support.v7.appcompat.R;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

@TargetApi(9)
@RequiresApi(9)
class NotificationCompatImplBase {
  private static final int MAX_ACTION_BUTTONS = 3;
  
  static final int MAX_MEDIA_BUTTONS = 5;
  
  static final int MAX_MEDIA_BUTTONS_IN_COMPACT = 3;
  
  public static RemoteViews applyStandardTemplate(Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, int paramInt2, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   4: astore #16
    //   6: new android/widget/RemoteViews
    //   9: dup
    //   10: aload_0
    //   11: invokevirtual getPackageName : ()Ljava/lang/String;
    //   14: iload #13
    //   16: invokespecial <init> : (Ljava/lang/String;I)V
    //   19: astore #17
    //   21: iload #11
    //   23: iconst_m1
    //   24: if_icmpge -> 33
    //   27: iconst_1
    //   28: istore #11
    //   30: goto -> 36
    //   33: iconst_0
    //   34: istore #11
    //   36: getstatic android/os/Build$VERSION.SDK_INT : I
    //   39: bipush #16
    //   41: if_icmplt -> 112
    //   44: getstatic android/os/Build$VERSION.SDK_INT : I
    //   47: bipush #21
    //   49: if_icmpge -> 112
    //   52: iload #11
    //   54: ifeq -> 86
    //   57: aload #17
    //   59: getstatic android/support/v7/appcompat/R$id.notification_background : I
    //   62: ldc 'setBackgroundResource'
    //   64: getstatic android/support/v7/appcompat/R$drawable.notification_bg_low : I
    //   67: invokevirtual setInt : (ILjava/lang/String;I)V
    //   70: aload #17
    //   72: getstatic android/support/v7/appcompat/R$id.icon : I
    //   75: ldc 'setBackgroundResource'
    //   77: getstatic android/support/v7/appcompat/R$drawable.notification_template_icon_low_bg : I
    //   80: invokevirtual setInt : (ILjava/lang/String;I)V
    //   83: goto -> 112
    //   86: aload #17
    //   88: getstatic android/support/v7/appcompat/R$id.notification_background : I
    //   91: ldc 'setBackgroundResource'
    //   93: getstatic android/support/v7/appcompat/R$drawable.notification_bg : I
    //   96: invokevirtual setInt : (ILjava/lang/String;I)V
    //   99: aload #17
    //   101: getstatic android/support/v7/appcompat/R$id.icon : I
    //   104: ldc 'setBackgroundResource'
    //   106: getstatic android/support/v7/appcompat/R$drawable.notification_template_icon_bg : I
    //   109: invokevirtual setInt : (ILjava/lang/String;I)V
    //   112: aload #6
    //   114: ifnull -> 247
    //   117: getstatic android/os/Build$VERSION.SDK_INT : I
    //   120: bipush #16
    //   122: if_icmplt -> 147
    //   125: aload #17
    //   127: getstatic android/support/v7/appcompat/R$id.icon : I
    //   130: iconst_0
    //   131: invokevirtual setViewVisibility : (II)V
    //   134: aload #17
    //   136: getstatic android/support/v7/appcompat/R$id.icon : I
    //   139: aload #6
    //   141: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
    //   144: goto -> 157
    //   147: aload #17
    //   149: getstatic android/support/v7/appcompat/R$id.icon : I
    //   152: bipush #8
    //   154: invokevirtual setViewVisibility : (II)V
    //   157: iload #5
    //   159: ifeq -> 330
    //   162: aload #16
    //   164: getstatic android/support/v7/appcompat/R$dimen.notification_right_icon_size : I
    //   167: invokevirtual getDimensionPixelSize : (I)I
    //   170: istore #11
    //   172: aload #16
    //   174: getstatic android/support/v7/appcompat/R$dimen.notification_small_icon_background_padding : I
    //   177: invokevirtual getDimensionPixelSize : (I)I
    //   180: istore #13
    //   182: getstatic android/os/Build$VERSION.SDK_INT : I
    //   185: bipush #21
    //   187: if_icmplt -> 220
    //   190: aload_0
    //   191: iload #5
    //   193: iload #11
    //   195: iload #11
    //   197: iload #13
    //   199: iconst_2
    //   200: imul
    //   201: isub
    //   202: iload #12
    //   204: invokestatic createIconWithBackground : (Landroid/content/Context;IIII)Landroid/graphics/Bitmap;
    //   207: astore_0
    //   208: aload #17
    //   210: getstatic android/support/v7/appcompat/R$id.right_icon : I
    //   213: aload_0
    //   214: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
    //   217: goto -> 235
    //   220: aload #17
    //   222: getstatic android/support/v7/appcompat/R$id.right_icon : I
    //   225: aload_0
    //   226: iload #5
    //   228: iconst_m1
    //   229: invokestatic createColoredBitmap : (Landroid/content/Context;II)Landroid/graphics/Bitmap;
    //   232: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
    //   235: aload #17
    //   237: getstatic android/support/v7/appcompat/R$id.right_icon : I
    //   240: iconst_0
    //   241: invokevirtual setViewVisibility : (II)V
    //   244: goto -> 330
    //   247: iload #5
    //   249: ifeq -> 330
    //   252: aload #17
    //   254: getstatic android/support/v7/appcompat/R$id.icon : I
    //   257: iconst_0
    //   258: invokevirtual setViewVisibility : (II)V
    //   261: getstatic android/os/Build$VERSION.SDK_INT : I
    //   264: bipush #21
    //   266: if_icmplt -> 315
    //   269: aload_0
    //   270: iload #5
    //   272: aload #16
    //   274: getstatic android/support/v7/appcompat/R$dimen.notification_large_icon_width : I
    //   277: invokevirtual getDimensionPixelSize : (I)I
    //   280: aload #16
    //   282: getstatic android/support/v7/appcompat/R$dimen.notification_big_circle_margin : I
    //   285: invokevirtual getDimensionPixelSize : (I)I
    //   288: isub
    //   289: aload #16
    //   291: getstatic android/support/v7/appcompat/R$dimen.notification_small_icon_size_as_large : I
    //   294: invokevirtual getDimensionPixelSize : (I)I
    //   297: iload #12
    //   299: invokestatic createIconWithBackground : (Landroid/content/Context;IIII)Landroid/graphics/Bitmap;
    //   302: astore_0
    //   303: aload #17
    //   305: getstatic android/support/v7/appcompat/R$id.icon : I
    //   308: aload_0
    //   309: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
    //   312: goto -> 330
    //   315: aload #17
    //   317: getstatic android/support/v7/appcompat/R$id.icon : I
    //   320: aload_0
    //   321: iload #5
    //   323: iconst_m1
    //   324: invokestatic createColoredBitmap : (Landroid/content/Context;II)Landroid/graphics/Bitmap;
    //   327: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
    //   330: aload_1
    //   331: ifnull -> 343
    //   334: aload #17
    //   336: getstatic android/support/v7/appcompat/R$id.title : I
    //   339: aload_1
    //   340: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   343: aload_2
    //   344: ifnull -> 362
    //   347: aload #17
    //   349: getstatic android/support/v7/appcompat/R$id.text : I
    //   352: aload_2
    //   353: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   356: iconst_1
    //   357: istore #5
    //   359: goto -> 365
    //   362: iconst_0
    //   363: istore #5
    //   365: getstatic android/os/Build$VERSION.SDK_INT : I
    //   368: bipush #21
    //   370: if_icmpge -> 384
    //   373: aload #6
    //   375: ifnull -> 384
    //   378: iconst_1
    //   379: istore #11
    //   381: goto -> 387
    //   384: iconst_0
    //   385: istore #11
    //   387: aload_3
    //   388: ifnull -> 418
    //   391: aload #17
    //   393: getstatic android/support/v7/appcompat/R$id.info : I
    //   396: aload_3
    //   397: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   400: aload #17
    //   402: getstatic android/support/v7/appcompat/R$id.info : I
    //   405: iconst_0
    //   406: invokevirtual setViewVisibility : (II)V
    //   409: iconst_1
    //   410: istore #4
    //   412: iconst_1
    //   413: istore #5
    //   415: goto -> 500
    //   418: iload #4
    //   420: ifle -> 486
    //   423: iload #4
    //   425: aload #16
    //   427: getstatic android/support/v7/appcompat/R$integer.status_bar_notification_info_maxnum : I
    //   430: invokevirtual getInteger : (I)I
    //   433: if_icmple -> 455
    //   436: aload #17
    //   438: getstatic android/support/v7/appcompat/R$id.info : I
    //   441: aload #16
    //   443: getstatic android/support/v7/appcompat/R$string.status_bar_notification_info_overflow : I
    //   446: invokevirtual getString : (I)Ljava/lang/String;
    //   449: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   452: goto -> 474
    //   455: invokestatic getIntegerInstance : ()Ljava/text/NumberFormat;
    //   458: astore_0
    //   459: aload #17
    //   461: getstatic android/support/v7/appcompat/R$id.info : I
    //   464: aload_0
    //   465: iload #4
    //   467: i2l
    //   468: invokevirtual format : (J)Ljava/lang/String;
    //   471: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   474: aload #17
    //   476: getstatic android/support/v7/appcompat/R$id.info : I
    //   479: iconst_0
    //   480: invokevirtual setViewVisibility : (II)V
    //   483: goto -> 409
    //   486: aload #17
    //   488: getstatic android/support/v7/appcompat/R$id.info : I
    //   491: bipush #8
    //   493: invokevirtual setViewVisibility : (II)V
    //   496: iload #11
    //   498: istore #4
    //   500: aload #7
    //   502: ifnull -> 564
    //   505: getstatic android/os/Build$VERSION.SDK_INT : I
    //   508: bipush #16
    //   510: if_icmplt -> 564
    //   513: aload #17
    //   515: getstatic android/support/v7/appcompat/R$id.text : I
    //   518: aload #7
    //   520: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   523: aload_2
    //   524: ifnull -> 551
    //   527: aload #17
    //   529: getstatic android/support/v7/appcompat/R$id.text2 : I
    //   532: aload_2
    //   533: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
    //   536: aload #17
    //   538: getstatic android/support/v7/appcompat/R$id.text2 : I
    //   541: iconst_0
    //   542: invokevirtual setViewVisibility : (II)V
    //   545: iconst_1
    //   546: istore #11
    //   548: goto -> 567
    //   551: aload #17
    //   553: getstatic android/support/v7/appcompat/R$id.text2 : I
    //   556: bipush #8
    //   558: invokevirtual setViewVisibility : (II)V
    //   561: goto -> 564
    //   564: iconst_0
    //   565: istore #11
    //   567: bipush #8
    //   569: istore #12
    //   571: iload #11
    //   573: ifeq -> 623
    //   576: getstatic android/os/Build$VERSION.SDK_INT : I
    //   579: bipush #16
    //   581: if_icmplt -> 623
    //   584: iload #14
    //   586: ifeq -> 611
    //   589: aload #16
    //   591: getstatic android/support/v7/appcompat/R$dimen.notification_subtext_size : I
    //   594: invokevirtual getDimensionPixelSize : (I)I
    //   597: i2f
    //   598: fstore #15
    //   600: aload #17
    //   602: getstatic android/support/v7/appcompat/R$id.text : I
    //   605: iconst_0
    //   606: fload #15
    //   608: invokevirtual setTextViewTextSize : (IIF)V
    //   611: aload #17
    //   613: getstatic android/support/v7/appcompat/R$id.line1 : I
    //   616: iconst_0
    //   617: iconst_0
    //   618: iconst_0
    //   619: iconst_0
    //   620: invokevirtual setViewPadding : (IIIII)V
    //   623: lload #9
    //   625: lconst_0
    //   626: lcmp
    //   627: ifeq -> 720
    //   630: iload #8
    //   632: ifeq -> 693
    //   635: getstatic android/os/Build$VERSION.SDK_INT : I
    //   638: bipush #16
    //   640: if_icmplt -> 693
    //   643: aload #17
    //   645: getstatic android/support/v7/appcompat/R$id.chronometer : I
    //   648: iconst_0
    //   649: invokevirtual setViewVisibility : (II)V
    //   652: aload #17
    //   654: getstatic android/support/v7/appcompat/R$id.chronometer : I
    //   657: ldc 'setBase'
    //   659: invokestatic elapsedRealtime : ()J
    //   662: invokestatic currentTimeMillis : ()J
    //   665: lsub
    //   666: lload #9
    //   668: ladd
    //   669: invokevirtual setLong : (ILjava/lang/String;J)V
    //   672: getstatic android/support/v7/appcompat/R$id.chronometer : I
    //   675: istore #11
    //   677: iconst_1
    //   678: istore #4
    //   680: aload #17
    //   682: iload #11
    //   684: ldc 'setStarted'
    //   686: iconst_1
    //   687: invokevirtual setBoolean : (ILjava/lang/String;Z)V
    //   690: goto -> 720
    //   693: iconst_1
    //   694: istore #4
    //   696: aload #17
    //   698: getstatic android/support/v7/appcompat/R$id.time : I
    //   701: iconst_0
    //   702: invokevirtual setViewVisibility : (II)V
    //   705: aload #17
    //   707: getstatic android/support/v7/appcompat/R$id.time : I
    //   710: ldc 'setTime'
    //   712: lload #9
    //   714: invokevirtual setLong : (ILjava/lang/String;J)V
    //   717: goto -> 720
    //   720: getstatic android/support/v7/appcompat/R$id.right_side : I
    //   723: istore #11
    //   725: iload #4
    //   727: ifeq -> 736
    //   730: iconst_0
    //   731: istore #4
    //   733: goto -> 740
    //   736: bipush #8
    //   738: istore #4
    //   740: aload #17
    //   742: iload #11
    //   744: iload #4
    //   746: invokevirtual setViewVisibility : (II)V
    //   749: getstatic android/support/v7/appcompat/R$id.line3 : I
    //   752: istore #11
    //   754: iload #12
    //   756: istore #4
    //   758: iload #5
    //   760: ifeq -> 766
    //   763: iconst_0
    //   764: istore #4
    //   766: aload #17
    //   768: iload #11
    //   770: iload #4
    //   772: invokevirtual setViewVisibility : (II)V
    //   775: aload #17
    //   777: areturn
  }
  
  public static RemoteViews applyStandardTemplateWithActions(Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, int paramInt2, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean2, ArrayList<NotificationCompat.Action> paramArrayList) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: aload_3
    //   4: iload #4
    //   6: iload #5
    //   8: aload #6
    //   10: aload #7
    //   12: iload #8
    //   14: lload #9
    //   16: iload #11
    //   18: iload #12
    //   20: iload #13
    //   22: iload #14
    //   24: invokestatic applyStandardTemplate : (Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;IILandroid/graphics/Bitmap;Ljava/lang/CharSequence;ZJIIIZ)Landroid/widget/RemoteViews;
    //   27: astore_1
    //   28: aload_1
    //   29: getstatic android/support/v7/appcompat/R$id.actions : I
    //   32: invokevirtual removeAllViews : (I)V
    //   35: iconst_0
    //   36: istore #11
    //   38: aload #15
    //   40: ifnull -> 116
    //   43: aload #15
    //   45: invokevirtual size : ()I
    //   48: istore #5
    //   50: iload #5
    //   52: ifle -> 116
    //   55: iload #5
    //   57: istore #4
    //   59: iload #5
    //   61: iconst_3
    //   62: if_icmple -> 68
    //   65: iconst_3
    //   66: istore #4
    //   68: iconst_0
    //   69: istore #5
    //   71: iload #5
    //   73: iload #4
    //   75: if_icmpge -> 110
    //   78: aload_0
    //   79: aload #15
    //   81: iload #5
    //   83: invokevirtual get : (I)Ljava/lang/Object;
    //   86: checkcast android/support/v4/app/NotificationCompat$Action
    //   89: invokestatic generateActionButton : (Landroid/content/Context;Landroid/support/v4/app/NotificationCompat$Action;)Landroid/widget/RemoteViews;
    //   92: astore_2
    //   93: aload_1
    //   94: getstatic android/support/v7/appcompat/R$id.actions : I
    //   97: aload_2
    //   98: invokevirtual addView : (ILandroid/widget/RemoteViews;)V
    //   101: iload #5
    //   103: iconst_1
    //   104: iadd
    //   105: istore #5
    //   107: goto -> 71
    //   110: iconst_1
    //   111: istore #4
    //   113: goto -> 119
    //   116: iconst_0
    //   117: istore #4
    //   119: iload #4
    //   121: ifeq -> 131
    //   124: iload #11
    //   126: istore #4
    //   128: goto -> 135
    //   131: bipush #8
    //   133: istore #4
    //   135: aload_1
    //   136: getstatic android/support/v7/appcompat/R$id.actions : I
    //   139: iload #4
    //   141: invokevirtual setViewVisibility : (II)V
    //   144: aload_1
    //   145: getstatic android/support/v7/appcompat/R$id.action_divider : I
    //   148: iload #4
    //   150: invokevirtual setViewVisibility : (II)V
    //   153: aload_1
    //   154: areturn
  }
  
  public static void buildIntoRemoteViews(Context paramContext, RemoteViews paramRemoteViews1, RemoteViews paramRemoteViews2) {
    hideNormalContent(paramRemoteViews1);
    paramRemoteViews1.removeAllViews(R.id.notification_main_column);
    paramRemoteViews1.addView(R.id.notification_main_column, paramRemoteViews2.clone());
    paramRemoteViews1.setViewVisibility(R.id.notification_main_column, 0);
    if (Build.VERSION.SDK_INT >= 21)
      paramRemoteViews1.setViewPadding(R.id.notification_main_column_container, 0, calculateTopPadding(paramContext), 0, 0); 
  }
  
  public static int calculateTopPadding(Context paramContext) {
    int i = paramContext.getResources().getDimensionPixelSize(R.dimen.notification_top_pad);
    int j = paramContext.getResources().getDimensionPixelSize(R.dimen.notification_top_pad_large_text);
    float f = (constrain((paramContext.getResources().getConfiguration()).fontScale, 1.0F, 1.3F) - 1.0F) / 0.29999995F;
    return Math.round((1.0F - f) * i + f * j);
  }
  
  public static float constrain(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 < paramFloat2)
      return paramFloat2; 
    paramFloat2 = paramFloat1;
    if (paramFloat1 > paramFloat3)
      paramFloat2 = paramFloat3; 
    return paramFloat2;
  }
  
  private static Bitmap createColoredBitmap(Context paramContext, int paramInt1, int paramInt2) {
    return createColoredBitmap(paramContext, paramInt1, paramInt2, 0);
  }
  
  private static Bitmap createColoredBitmap(Context paramContext, int paramInt1, int paramInt2, int paramInt3) {
    Drawable drawable = paramContext.getResources().getDrawable(paramInt1);
    if (paramInt3 == 0) {
      paramInt1 = drawable.getIntrinsicWidth();
    } else {
      paramInt1 = paramInt3;
    } 
    int i = paramInt3;
    if (paramInt3 == 0)
      i = drawable.getIntrinsicHeight(); 
    Bitmap bitmap = Bitmap.createBitmap(paramInt1, i, Bitmap.Config.ARGB_8888);
    drawable.setBounds(0, 0, paramInt1, i);
    if (paramInt2 != 0)
      drawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(paramInt2, PorterDuff.Mode.SRC_IN)); 
    drawable.draw(new Canvas(bitmap));
    return bitmap;
  }
  
  public static Bitmap createIconWithBackground(Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int j = R.drawable.notification_icon_background;
    int i = paramInt4;
    if (paramInt4 == 0)
      i = 0; 
    Bitmap bitmap = createColoredBitmap(paramContext, j, i, paramInt2);
    Canvas canvas = new Canvas(bitmap);
    Drawable drawable = paramContext.getResources().getDrawable(paramInt1).mutate();
    drawable.setFilterBitmap(true);
    paramInt1 = (paramInt2 - paramInt3) / 2;
    paramInt2 = paramInt3 + paramInt1;
    drawable.setBounds(paramInt1, paramInt1, paramInt2, paramInt2);
    drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
    drawable.draw(canvas);
    return bitmap;
  }
  
  private static RemoteViews generateActionButton(Context paramContext, NotificationCompat.Action paramAction) {
    boolean bool;
    int i;
    if (paramAction.actionIntent == null) {
      bool = true;
    } else {
      bool = false;
    } 
    String str = paramContext.getPackageName();
    if (bool) {
      i = getActionTombstoneLayoutResource();
    } else {
      i = getActionLayoutResource();
    } 
    RemoteViews remoteViews = new RemoteViews(str, i);
    remoteViews.setImageViewBitmap(R.id.action_image, createColoredBitmap(paramContext, paramAction.getIcon(), paramContext.getResources().getColor(R.color.notification_action_color_filter)));
    remoteViews.setTextViewText(R.id.action_text, paramAction.title);
    if (!bool)
      remoteViews.setOnClickPendingIntent(R.id.action_container, paramAction.actionIntent); 
    if (Build.VERSION.SDK_INT >= 15)
      remoteViews.setContentDescription(R.id.action_container, paramAction.title); 
    return remoteViews;
  }
  
  @TargetApi(11)
  @RequiresApi(11)
  private static <T extends NotificationCompatBase.Action> RemoteViews generateContentViewMedia(Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt2, List<T> paramList, int[] paramArrayOfint, boolean paramBoolean2, PendingIntent paramPendingIntent, boolean paramBoolean3) {
    if (paramBoolean3) {
      i = R.layout.notification_template_media_custom;
    } else {
      i = R.layout.notification_template_media;
    } 
    RemoteViews remoteViews = applyStandardTemplate(paramContext, paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt1, 0, paramBitmap, paramCharSequence4, paramBoolean1, paramLong, paramInt2, 0, i, true);
    int i = paramList.size();
    if (paramArrayOfint == null) {
      paramInt1 = 0;
    } else {
      paramInt1 = Math.min(paramArrayOfint.length, 3);
    } 
    remoteViews.removeAllViews(R.id.media_actions);
    if (paramInt1 > 0) {
      paramInt2 = 0;
      while (paramInt2 < paramInt1) {
        if (paramInt2 < i) {
          RemoteViews remoteViews1 = generateMediaActionButton(paramContext, (NotificationCompatBase.Action)paramList.get(paramArrayOfint[paramInt2]));
          remoteViews.addView(R.id.media_actions, remoteViews1);
          paramInt2++;
          continue;
        } 
        throw new IllegalArgumentException(String.format("setShowActionsInCompactView: action %d out of bounds (max %d)", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(i - 1) }));
      } 
    } 
    if (paramBoolean2) {
      remoteViews.setViewVisibility(R.id.end_padder, 8);
      remoteViews.setViewVisibility(R.id.cancel_action, 0);
      remoteViews.setOnClickPendingIntent(R.id.cancel_action, paramPendingIntent);
      remoteViews.setInt(R.id.cancel_action, "setAlpha", paramContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
      return remoteViews;
    } 
    remoteViews.setViewVisibility(R.id.end_padder, 0);
    remoteViews.setViewVisibility(R.id.cancel_action, 8);
    return remoteViews;
  }
  
  @TargetApi(11)
  @RequiresApi(11)
  private static RemoteViews generateMediaActionButton(Context paramContext, NotificationCompatBase.Action paramAction) {
    boolean bool;
    if (paramAction.getActionIntent() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    RemoteViews remoteViews = new RemoteViews(paramContext.getPackageName(), R.layout.notification_media_action);
    remoteViews.setImageViewResource(R.id.action0, paramAction.getIcon());
    if (!bool)
      remoteViews.setOnClickPendingIntent(R.id.action0, paramAction.getActionIntent()); 
    if (Build.VERSION.SDK_INT >= 15)
      remoteViews.setContentDescription(R.id.action0, paramAction.getTitle()); 
    return remoteViews;
  }
  
  @TargetApi(11)
  @RequiresApi(11)
  public static <T extends NotificationCompatBase.Action> RemoteViews generateMediaBigView(Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt2, int paramInt3, List<T> paramList, boolean paramBoolean2, PendingIntent paramPendingIntent, boolean paramBoolean3) {
    int i = Math.min(paramList.size(), 5);
    RemoteViews remoteViews = applyStandardTemplate(paramContext, paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt1, 0, paramBitmap, paramCharSequence4, paramBoolean1, paramLong, paramInt2, paramInt3, getBigMediaLayoutResource(paramBoolean3, i), false);
    remoteViews.removeAllViews(R.id.media_actions);
    if (i > 0)
      for (paramInt1 = 0; paramInt1 < i; paramInt1++) {
        RemoteViews remoteViews1 = generateMediaActionButton(paramContext, (NotificationCompatBase.Action)paramList.get(paramInt1));
        remoteViews.addView(R.id.media_actions, remoteViews1);
      }  
    if (paramBoolean2) {
      remoteViews.setViewVisibility(R.id.cancel_action, 0);
      remoteViews.setInt(R.id.cancel_action, "setAlpha", paramContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
      remoteViews.setOnClickPendingIntent(R.id.cancel_action, paramPendingIntent);
      return remoteViews;
    } 
    remoteViews.setViewVisibility(R.id.cancel_action, 8);
    return remoteViews;
  }
  
  private static int getActionLayoutResource() {
    return R.layout.notification_action;
  }
  
  private static int getActionTombstoneLayoutResource() {
    return R.layout.notification_action_tombstone;
  }
  
  @TargetApi(11)
  @RequiresApi(11)
  private static int getBigMediaLayoutResource(boolean paramBoolean, int paramInt) {
    return (paramInt <= 3) ? (paramBoolean ? R.layout.notification_template_big_media_narrow_custom : R.layout.notification_template_big_media_narrow) : (paramBoolean ? R.layout.notification_template_big_media_custom : R.layout.notification_template_big_media);
  }
  
  private static void hideNormalContent(RemoteViews paramRemoteViews) {
    paramRemoteViews.setViewVisibility(R.id.title, 8);
    paramRemoteViews.setViewVisibility(R.id.text2, 8);
    paramRemoteViews.setViewVisibility(R.id.text, 8);
  }
  
  @TargetApi(11)
  @RequiresApi(11)
  public static <T extends NotificationCompatBase.Action> RemoteViews overrideContentViewMedia(NotificationBuilderWithBuilderAccessor paramNotificationBuilderWithBuilderAccessor, Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt2, List<T> paramList, int[] paramArrayOfint, boolean paramBoolean2, PendingIntent paramPendingIntent, boolean paramBoolean3) {
    RemoteViews remoteViews = generateContentViewMedia(paramContext, paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt1, paramBitmap, paramCharSequence4, paramBoolean1, paramLong, paramInt2, paramList, paramArrayOfint, paramBoolean2, paramPendingIntent, paramBoolean3);
    paramNotificationBuilderWithBuilderAccessor.getBuilder().setContent(remoteViews);
    if (paramBoolean2)
      paramNotificationBuilderWithBuilderAccessor.getBuilder().setOngoing(true); 
    return remoteViews;
  }
  
  @TargetApi(16)
  @RequiresApi(16)
  public static <T extends NotificationCompatBase.Action> void overrideMediaBigContentView(Notification paramNotification, Context paramContext, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt1, Bitmap paramBitmap, CharSequence paramCharSequence4, boolean paramBoolean1, long paramLong, int paramInt2, int paramInt3, List<T> paramList, boolean paramBoolean2, PendingIntent paramPendingIntent, boolean paramBoolean3) {
    paramNotification.bigContentView = generateMediaBigView(paramContext, paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt1, paramBitmap, paramCharSequence4, paramBoolean1, paramLong, paramInt2, paramInt3, paramList, paramBoolean2, paramPendingIntent, paramBoolean3);
    if (paramBoolean2)
      paramNotification.flags |= 0x2; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\app\NotificationCompatImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */