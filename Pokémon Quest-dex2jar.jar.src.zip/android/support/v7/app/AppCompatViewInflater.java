package android.support.v7.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.view.ContextThemeWrapper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InflateException;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

class AppCompatViewInflater {
  private static final String LOG_TAG = "AppCompatViewInflater";
  
  private static final String[] sClassPrefixList;
  
  private static final Map<String, Constructor<? extends View>> sConstructorMap;
  
  private static final Class<?>[] sConstructorSignature = new Class[] { Context.class, AttributeSet.class };
  
  private static final int[] sOnClickAttrs = new int[] { 16843375 };
  
  private final Object[] mConstructorArgs = new Object[2];
  
  static {
    sClassPrefixList = new String[] { "android.widget.", "android.view.", "android.webkit." };
    sConstructorMap = (Map<String, Constructor<? extends View>>)new ArrayMap();
  }
  
  private void checkOnClickListener(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (Build.VERSION.SDK_INT >= 15 && !ViewCompat.hasOnClickListeners(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, sOnClickAttrs);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new DeclaredOnClickListener(paramView, str)); 
      typedArray.recycle();
    } 
  }
  
  private View createView(Context paramContext, String paramString1, String paramString2) throws ClassNotFoundException, InflateException {
    Constructor constructor1 = sConstructorMap.get(paramString1);
    Constructor<? extends View> constructor = constructor1;
    if (constructor1 == null)
      try {
        String str;
        ClassLoader classLoader = paramContext.getClassLoader();
        if (paramString2 != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          str = stringBuilder.toString();
        } else {
          str = paramString1;
        } 
        constructor = classLoader.loadClass(str).<View>asSubclass(View.class).getConstructor(sConstructorSignature);
        sConstructorMap.put(paramString1, constructor);
        constructor.setAccessible(true);
        return constructor.newInstance(this.mConstructorArgs);
      } catch (Exception exception) {
        return null;
      }  
    constructor.setAccessible(true);
    return constructor.newInstance(this.mConstructorArgs);
  }
  
  private View createViewFromTag(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    String str = paramString;
    if (paramString.equals("view"))
      str = paramAttributeSet.getAttributeValue(null, "class"); 
    try {
      Object[] arrayOfObject1;
      this.mConstructorArgs[0] = paramContext;
      this.mConstructorArgs[1] = paramAttributeSet;
      if (-1 == str.indexOf('.')) {
        int i;
        for (i = 0; i < sClassPrefixList.length; i++) {
          View view = createView(paramContext, str, sClassPrefixList[i]);
          if (view != null)
            return view; 
        } 
        return null;
      } 
      return createView((Context)arrayOfObject1, str, null);
    } catch (Exception exception) {
      return null;
    } finally {
      Object[] arrayOfObject = this.mConstructorArgs;
      arrayOfObject[0] = null;
      arrayOfObject[1] = null;
    } 
  }
  
  private static Context themifyContext(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.View, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(R.styleable.View_android_theme, 0);
    } else {
      i = 0;
    } 
    int j = i;
    if (paramBoolean2) {
      j = i;
      if (!i) {
        i = typedArray.getResourceId(R.styleable.View_theme, 0);
        j = i;
        if (i != 0) {
          Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
          j = i;
        } 
      } 
    } 
    typedArray.recycle();
    Context context = paramContext;
    if (j != 0) {
      if (paramContext instanceof ContextThemeWrapper) {
        context = paramContext;
        return (Context)((((ContextThemeWrapper)paramContext).getThemeResId() != j) ? new ContextThemeWrapper(paramContext, j) : context);
      } 
    } else {
      return context;
    } 
    return (Context)new ContextThemeWrapper(paramContext, j);
  }
  
  public final View createView(View paramView, String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: iload #5
    //   2: ifeq -> 18
    //   5: aload_1
    //   6: ifnull -> 18
    //   9: aload_1
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: astore #10
    //   15: goto -> 21
    //   18: aload_3
    //   19: astore #10
    //   21: iload #6
    //   23: ifne -> 34
    //   26: aload #10
    //   28: astore_1
    //   29: iload #7
    //   31: ifeq -> 46
    //   34: aload #10
    //   36: aload #4
    //   38: iload #6
    //   40: iload #7
    //   42: invokestatic themifyContext : (Landroid/content/Context;Landroid/util/AttributeSet;ZZ)Landroid/content/Context;
    //   45: astore_1
    //   46: aload_1
    //   47: astore #10
    //   49: iload #8
    //   51: ifeq -> 60
    //   54: aload_1
    //   55: invokestatic wrap : (Landroid/content/Context;)Landroid/content/Context;
    //   58: astore #10
    //   60: aconst_null
    //   61: astore_1
    //   62: iconst_m1
    //   63: istore #9
    //   65: aload_2
    //   66: invokevirtual hashCode : ()I
    //   69: lookupswitch default -> 184, -1946472170 -> 373, -1455429095 -> 357, -1346021293 -> 341, -938935918 -> 326, -937446323 -> 311, -658531749 -> 295, -339785223 -> 280, 776382189 -> 264, 1125864064 -> 249, 1413872058 -> 233, 1601505219 -> 217, 1666676343 -> 202, 2001146706 -> 187
    //   184: goto -> 386
    //   187: aload_2
    //   188: ldc 'Button'
    //   190: invokevirtual equals : (Ljava/lang/Object;)Z
    //   193: ifeq -> 386
    //   196: iconst_2
    //   197: istore #9
    //   199: goto -> 386
    //   202: aload_2
    //   203: ldc 'EditText'
    //   205: invokevirtual equals : (Ljava/lang/Object;)Z
    //   208: ifeq -> 386
    //   211: iconst_3
    //   212: istore #9
    //   214: goto -> 386
    //   217: aload_2
    //   218: ldc 'CheckBox'
    //   220: invokevirtual equals : (Ljava/lang/Object;)Z
    //   223: ifeq -> 386
    //   226: bipush #6
    //   228: istore #9
    //   230: goto -> 386
    //   233: aload_2
    //   234: ldc 'AutoCompleteTextView'
    //   236: invokevirtual equals : (Ljava/lang/Object;)Z
    //   239: ifeq -> 386
    //   242: bipush #9
    //   244: istore #9
    //   246: goto -> 386
    //   249: aload_2
    //   250: ldc 'ImageView'
    //   252: invokevirtual equals : (Ljava/lang/Object;)Z
    //   255: ifeq -> 386
    //   258: iconst_1
    //   259: istore #9
    //   261: goto -> 386
    //   264: aload_2
    //   265: ldc 'RadioButton'
    //   267: invokevirtual equals : (Ljava/lang/Object;)Z
    //   270: ifeq -> 386
    //   273: bipush #7
    //   275: istore #9
    //   277: goto -> 386
    //   280: aload_2
    //   281: ldc 'Spinner'
    //   283: invokevirtual equals : (Ljava/lang/Object;)Z
    //   286: ifeq -> 386
    //   289: iconst_4
    //   290: istore #9
    //   292: goto -> 386
    //   295: aload_2
    //   296: ldc 'SeekBar'
    //   298: invokevirtual equals : (Ljava/lang/Object;)Z
    //   301: ifeq -> 386
    //   304: bipush #12
    //   306: istore #9
    //   308: goto -> 386
    //   311: aload_2
    //   312: ldc 'ImageButton'
    //   314: invokevirtual equals : (Ljava/lang/Object;)Z
    //   317: ifeq -> 386
    //   320: iconst_5
    //   321: istore #9
    //   323: goto -> 386
    //   326: aload_2
    //   327: ldc 'TextView'
    //   329: invokevirtual equals : (Ljava/lang/Object;)Z
    //   332: ifeq -> 386
    //   335: iconst_0
    //   336: istore #9
    //   338: goto -> 386
    //   341: aload_2
    //   342: ldc 'MultiAutoCompleteTextView'
    //   344: invokevirtual equals : (Ljava/lang/Object;)Z
    //   347: ifeq -> 386
    //   350: bipush #10
    //   352: istore #9
    //   354: goto -> 386
    //   357: aload_2
    //   358: ldc 'CheckedTextView'
    //   360: invokevirtual equals : (Ljava/lang/Object;)Z
    //   363: ifeq -> 386
    //   366: bipush #8
    //   368: istore #9
    //   370: goto -> 386
    //   373: aload_2
    //   374: ldc 'RatingBar'
    //   376: invokevirtual equals : (Ljava/lang/Object;)Z
    //   379: ifeq -> 386
    //   382: bipush #11
    //   384: istore #9
    //   386: iload #9
    //   388: tableswitch default -> 456, 0 -> 639, 1 -> 624, 2 -> 609, 3 -> 594, 4 -> 579, 5 -> 564, 6 -> 549, 7 -> 534, 8 -> 519, 9 -> 504, 10 -> 489, 11 -> 474, 12 -> 459
    //   456: goto -> 651
    //   459: new android/support/v7/widget/AppCompatSeekBar
    //   462: dup
    //   463: aload #10
    //   465: aload #4
    //   467: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   470: astore_1
    //   471: goto -> 651
    //   474: new android/support/v7/widget/AppCompatRatingBar
    //   477: dup
    //   478: aload #10
    //   480: aload #4
    //   482: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   485: astore_1
    //   486: goto -> 651
    //   489: new android/support/v7/widget/AppCompatMultiAutoCompleteTextView
    //   492: dup
    //   493: aload #10
    //   495: aload #4
    //   497: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   500: astore_1
    //   501: goto -> 651
    //   504: new android/support/v7/widget/AppCompatAutoCompleteTextView
    //   507: dup
    //   508: aload #10
    //   510: aload #4
    //   512: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   515: astore_1
    //   516: goto -> 651
    //   519: new android/support/v7/widget/AppCompatCheckedTextView
    //   522: dup
    //   523: aload #10
    //   525: aload #4
    //   527: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   530: astore_1
    //   531: goto -> 651
    //   534: new android/support/v7/widget/AppCompatRadioButton
    //   537: dup
    //   538: aload #10
    //   540: aload #4
    //   542: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   545: astore_1
    //   546: goto -> 651
    //   549: new android/support/v7/widget/AppCompatCheckBox
    //   552: dup
    //   553: aload #10
    //   555: aload #4
    //   557: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   560: astore_1
    //   561: goto -> 651
    //   564: new android/support/v7/widget/AppCompatImageButton
    //   567: dup
    //   568: aload #10
    //   570: aload #4
    //   572: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   575: astore_1
    //   576: goto -> 651
    //   579: new android/support/v7/widget/AppCompatSpinner
    //   582: dup
    //   583: aload #10
    //   585: aload #4
    //   587: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   590: astore_1
    //   591: goto -> 651
    //   594: new android/support/v7/widget/AppCompatEditText
    //   597: dup
    //   598: aload #10
    //   600: aload #4
    //   602: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   605: astore_1
    //   606: goto -> 651
    //   609: new android/support/v7/widget/AppCompatButton
    //   612: dup
    //   613: aload #10
    //   615: aload #4
    //   617: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   620: astore_1
    //   621: goto -> 651
    //   624: new android/support/v7/widget/AppCompatImageView
    //   627: dup
    //   628: aload #10
    //   630: aload #4
    //   632: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   635: astore_1
    //   636: goto -> 651
    //   639: new android/support/v7/widget/AppCompatTextView
    //   642: dup
    //   643: aload #10
    //   645: aload #4
    //   647: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   650: astore_1
    //   651: aload_1
    //   652: astore #11
    //   654: aload_1
    //   655: ifnonnull -> 678
    //   658: aload_1
    //   659: astore #11
    //   661: aload_3
    //   662: aload #10
    //   664: if_acmpeq -> 678
    //   667: aload_0
    //   668: aload #10
    //   670: aload_2
    //   671: aload #4
    //   673: invokespecial createViewFromTag : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   676: astore #11
    //   678: aload #11
    //   680: ifnull -> 691
    //   683: aload_0
    //   684: aload #11
    //   686: aload #4
    //   688: invokespecial checkOnClickListener : (Landroid/view/View;Landroid/util/AttributeSet;)V
    //   691: aload #11
    //   693: areturn
  }
  
  private static class DeclaredOnClickListener implements View.OnClickListener {
    private final View mHostView;
    
    private final String mMethodName;
    
    private Context mResolvedContext;
    
    private Method mResolvedMethod;
    
    public DeclaredOnClickListener(@NonNull View param1View, @NonNull String param1String) {
      this.mHostView = param1View;
      this.mMethodName = param1String;
    }
    
    @NonNull
    private void resolveMethod(@Nullable Context param1Context, @NonNull String param1String) {
      while (true) {
        String str;
        if (param1Context != null) {
          try {
            if (!param1Context.isRestricted()) {
              Method method = param1Context.getClass().getMethod(this.mMethodName, new Class[] { View.class });
              if (method != null) {
                this.mResolvedMethod = method;
                this.mResolvedContext = param1Context;
                return;
              } 
            } 
          } catch (NoSuchMethodException noSuchMethodException) {}
          if (param1Context instanceof ContextWrapper) {
            param1Context = ((ContextWrapper)param1Context).getBaseContext();
            continue;
          } 
          param1Context = null;
          continue;
        } 
        int i = this.mHostView.getId();
        if (i == -1) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with id '");
          stringBuilder1.append(this.mHostView.getContext().getResources().getResourceEntryName(i));
          stringBuilder1.append("'");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not find method ");
        stringBuilder.append(this.mMethodName);
        stringBuilder.append("(View) in a parent or ancestor Context for android:onClick ");
        stringBuilder.append("attribute defined on view ");
        stringBuilder.append(this.mHostView.getClass());
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    }
    
    public void onClick(@NonNull View param1View) {
      if (this.mResolvedMethod == null)
        resolveMethod(this.mHostView.getContext(), this.mMethodName); 
      try {
        this.mResolvedMethod.invoke(this.mResolvedContext, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException("Could not execute method for android:onClick", invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\app\AppCompatViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */