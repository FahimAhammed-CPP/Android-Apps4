package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.ConfigurationHelper;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.widget.LinearLayout;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ButtonBarLayout extends LinearLayout {
  private static final int ALLOW_STACKING_MIN_HEIGHT_DP = 320;
  
  private static final int PEEK_BUTTON_DP = 16;
  
  private boolean mAllowStacking;
  
  private int mLastWidthSize;
  
  public ButtonBarLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    boolean bool;
    this.mLastWidthSize = -1;
    if (ConfigurationHelper.getScreenHeightDp(getResources()) >= 320) {
      bool = true;
    } else {
      bool = false;
    } 
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ButtonBarLayout);
    this.mAllowStacking = typedArray.getBoolean(R.styleable.ButtonBarLayout_allowStacking, bool);
    typedArray.recycle();
  }
  
  private int getNextVisibleChildIndex(int paramInt) {
    int i = getChildCount();
    while (paramInt < i) {
      if (getChildAt(paramInt).getVisibility() == 0)
        return paramInt; 
      paramInt++;
    } 
    return -1;
  }
  
  private boolean isStacked() {
    return (getOrientation() == 1);
  }
  
  private void setStacked(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getSize : (I)I
    //   4: istore #7
    //   6: aload_0
    //   7: getfield mAllowStacking : Z
    //   10: istore #9
    //   12: iconst_0
    //   13: istore #6
    //   15: iload #9
    //   17: ifeq -> 47
    //   20: iload #7
    //   22: aload_0
    //   23: getfield mLastWidthSize : I
    //   26: if_icmple -> 41
    //   29: aload_0
    //   30: invokespecial isStacked : ()Z
    //   33: ifeq -> 41
    //   36: aload_0
    //   37: iconst_0
    //   38: invokespecial setStacked : (Z)V
    //   41: aload_0
    //   42: iload #7
    //   44: putfield mLastWidthSize : I
    //   47: aload_0
    //   48: invokespecial isStacked : ()Z
    //   51: ifne -> 77
    //   54: iload_1
    //   55: invokestatic getMode : (I)I
    //   58: ldc 1073741824
    //   60: if_icmpne -> 77
    //   63: iload #7
    //   65: ldc -2147483648
    //   67: invokestatic makeMeasureSpec : (II)I
    //   70: istore #4
    //   72: iconst_1
    //   73: istore_3
    //   74: goto -> 82
    //   77: iload_1
    //   78: istore #4
    //   80: iconst_0
    //   81: istore_3
    //   82: aload_0
    //   83: iload #4
    //   85: iload_2
    //   86: invokespecial onMeasure : (II)V
    //   89: iload_3
    //   90: istore #4
    //   92: aload_0
    //   93: getfield mAllowStacking : Z
    //   96: ifeq -> 219
    //   99: iload_3
    //   100: istore #4
    //   102: aload_0
    //   103: invokespecial isStacked : ()Z
    //   106: ifne -> 219
    //   109: getstatic android/os/Build$VERSION.SDK_INT : I
    //   112: bipush #11
    //   114: if_icmplt -> 141
    //   117: aload_0
    //   118: invokestatic getMeasuredWidthAndState : (Landroid/view/View;)I
    //   121: ldc -16777216
    //   123: iand
    //   124: ldc 16777216
    //   126: if_icmpne -> 135
    //   129: iconst_1
    //   130: istore #5
    //   132: goto -> 203
    //   135: iconst_0
    //   136: istore #5
    //   138: goto -> 203
    //   141: aload_0
    //   142: invokevirtual getChildCount : ()I
    //   145: istore #8
    //   147: iconst_0
    //   148: istore #4
    //   150: iconst_0
    //   151: istore #5
    //   153: iload #4
    //   155: iload #8
    //   157: if_icmpge -> 183
    //   160: iload #5
    //   162: aload_0
    //   163: iload #4
    //   165: invokevirtual getChildAt : (I)Landroid/view/View;
    //   168: invokevirtual getMeasuredWidth : ()I
    //   171: iadd
    //   172: istore #5
    //   174: iload #4
    //   176: iconst_1
    //   177: iadd
    //   178: istore #4
    //   180: goto -> 153
    //   183: iload #5
    //   185: aload_0
    //   186: invokevirtual getPaddingLeft : ()I
    //   189: iadd
    //   190: aload_0
    //   191: invokevirtual getPaddingRight : ()I
    //   194: iadd
    //   195: iload #7
    //   197: if_icmple -> 135
    //   200: goto -> 129
    //   203: iload_3
    //   204: istore #4
    //   206: iload #5
    //   208: ifeq -> 219
    //   211: aload_0
    //   212: iconst_1
    //   213: invokespecial setStacked : (Z)V
    //   216: iconst_1
    //   217: istore #4
    //   219: iload #4
    //   221: ifeq -> 230
    //   224: aload_0
    //   225: iload_1
    //   226: iload_2
    //   227: invokespecial onMeasure : (II)V
    //   230: aload_0
    //   231: iconst_0
    //   232: invokespecial getNextVisibleChildIndex : (I)I
    //   235: istore_2
    //   236: iload #6
    //   238: istore_1
    //   239: iload_2
    //   240: iflt -> 345
    //   243: aload_0
    //   244: iload_2
    //   245: invokevirtual getChildAt : (I)Landroid/view/View;
    //   248: astore #10
    //   250: aload #10
    //   252: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   255: checkcast android/widget/LinearLayout$LayoutParams
    //   258: astore #11
    //   260: aload_0
    //   261: invokevirtual getPaddingTop : ()I
    //   264: aload #10
    //   266: invokevirtual getMeasuredHeight : ()I
    //   269: iadd
    //   270: aload #11
    //   272: getfield topMargin : I
    //   275: iadd
    //   276: aload #11
    //   278: getfield bottomMargin : I
    //   281: iadd
    //   282: iconst_0
    //   283: iadd
    //   284: istore_1
    //   285: aload_0
    //   286: invokespecial isStacked : ()Z
    //   289: ifeq -> 338
    //   292: aload_0
    //   293: iload_2
    //   294: iconst_1
    //   295: iadd
    //   296: invokespecial getNextVisibleChildIndex : (I)I
    //   299: istore_2
    //   300: iload_2
    //   301: iflt -> 335
    //   304: iload_1
    //   305: i2f
    //   306: aload_0
    //   307: iload_2
    //   308: invokevirtual getChildAt : (I)Landroid/view/View;
    //   311: invokevirtual getPaddingTop : ()I
    //   314: i2f
    //   315: aload_0
    //   316: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   319: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   322: getfield density : F
    //   325: ldc 16.0
    //   327: fmul
    //   328: fadd
    //   329: fadd
    //   330: f2i
    //   331: istore_1
    //   332: goto -> 345
    //   335: goto -> 345
    //   338: iload_1
    //   339: aload_0
    //   340: invokevirtual getPaddingBottom : ()I
    //   343: iadd
    //   344: istore_1
    //   345: aload_0
    //   346: invokestatic getMinimumHeight : (Landroid/view/View;)I
    //   349: iload_1
    //   350: if_icmpeq -> 358
    //   353: aload_0
    //   354: iload_1
    //   355: invokevirtual setMinimumHeight : (I)V
    //   358: return
  }
  
  public void setAllowStacking(boolean paramBoolean) {
    if (this.mAllowStacking != paramBoolean) {
      this.mAllowStacking = paramBoolean;
      if (!this.mAllowStacking && getOrientation() == 1)
        setStacked(false); 
      requestLayout();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\widget\ButtonBarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */