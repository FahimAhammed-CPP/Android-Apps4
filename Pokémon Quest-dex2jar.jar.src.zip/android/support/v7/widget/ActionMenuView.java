package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.annotation.StyleRes;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuView;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class ActionMenuView extends LinearLayoutCompat implements MenuBuilder.ItemInvoker, MenuView {
  static final int GENERATED_ITEM_PADDING = 4;
  
  static final int MIN_CELL_SIZE = 56;
  
  private static final String TAG = "ActionMenuView";
  
  private MenuPresenter.Callback mActionMenuPresenterCallback;
  
  private boolean mFormatItems;
  
  private int mFormatItemsWidth;
  
  private int mGeneratedItemPadding;
  
  private MenuBuilder mMenu;
  
  MenuBuilder.Callback mMenuBuilderCallback;
  
  private int mMinCellSize;
  
  OnMenuItemClickListener mOnMenuItemClickListener;
  
  private Context mPopupContext;
  
  private int mPopupTheme;
  
  private ActionMenuPresenter mPresenter;
  
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mMinCellSize = (int)(56.0F * f);
    this.mGeneratedItemPadding = (int)(f * 4.0F);
    this.mPopupContext = paramContext;
    this.mPopupTheme = 0;
  }
  
  static int measureChildForCells(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool = true;
    if (actionMenuItemView != null && actionMenuItemView.hasText()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int k = paramView.getMeasuredWidth();
      int j = k / paramInt1;
      paramInt2 = j;
      if (k % paramInt1 != 0)
        paramInt2 = j + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    if (layoutParams.isOverflowButton || paramInt3 == 0)
      bool = false; 
    layoutParams.expandable = bool;
    layoutParams.cellsUsed = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore #10
    //   6: iload_1
    //   7: invokestatic getSize : (I)I
    //   10: istore_1
    //   11: iload_2
    //   12: invokestatic getSize : (I)I
    //   15: istore #7
    //   17: aload_0
    //   18: invokevirtual getPaddingLeft : ()I
    //   21: istore #5
    //   23: aload_0
    //   24: invokevirtual getPaddingRight : ()I
    //   27: istore #6
    //   29: aload_0
    //   30: invokevirtual getPaddingTop : ()I
    //   33: aload_0
    //   34: invokevirtual getPaddingBottom : ()I
    //   37: iadd
    //   38: istore #13
    //   40: iload_2
    //   41: iload #13
    //   43: bipush #-2
    //   45: invokestatic getChildMeasureSpec : (III)I
    //   48: istore #17
    //   50: iload_1
    //   51: iload #5
    //   53: iload #6
    //   55: iadd
    //   56: isub
    //   57: istore #15
    //   59: aload_0
    //   60: getfield mMinCellSize : I
    //   63: istore_2
    //   64: iload #15
    //   66: iload_2
    //   67: idiv
    //   68: istore_1
    //   69: iload_1
    //   70: ifne -> 81
    //   73: aload_0
    //   74: iload #15
    //   76: iconst_0
    //   77: invokevirtual setMeasuredDimension : (II)V
    //   80: return
    //   81: iload_2
    //   82: iload #15
    //   84: iload_2
    //   85: irem
    //   86: iload_1
    //   87: idiv
    //   88: iadd
    //   89: istore #18
    //   91: aload_0
    //   92: invokevirtual getChildCount : ()I
    //   95: istore #19
    //   97: iconst_0
    //   98: istore #5
    //   100: iconst_0
    //   101: istore #6
    //   103: iconst_0
    //   104: istore #8
    //   106: iconst_0
    //   107: istore #12
    //   109: iconst_0
    //   110: istore #11
    //   112: iconst_0
    //   113: istore #9
    //   115: lconst_0
    //   116: lstore #20
    //   118: iload #5
    //   120: iload #19
    //   122: if_icmpge -> 375
    //   125: aload_0
    //   126: iload #5
    //   128: invokevirtual getChildAt : (I)Landroid/view/View;
    //   131: astore #29
    //   133: aload #29
    //   135: invokevirtual getVisibility : ()I
    //   138: bipush #8
    //   140: if_icmpne -> 149
    //   143: iload #9
    //   145: istore_2
    //   146: goto -> 363
    //   149: aload #29
    //   151: instanceof android/support/v7/view/menu/ActionMenuItemView
    //   154: istore #28
    //   156: iload #12
    //   158: iconst_1
    //   159: iadd
    //   160: istore #12
    //   162: iload #28
    //   164: ifeq -> 184
    //   167: aload_0
    //   168: getfield mGeneratedItemPadding : I
    //   171: istore_2
    //   172: aload #29
    //   174: iload_2
    //   175: iconst_0
    //   176: iload_2
    //   177: iconst_0
    //   178: invokevirtual setPadding : (IIII)V
    //   181: goto -> 184
    //   184: aload #29
    //   186: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   189: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   192: astore #30
    //   194: aload #30
    //   196: iconst_0
    //   197: putfield expanded : Z
    //   200: aload #30
    //   202: iconst_0
    //   203: putfield extraPixels : I
    //   206: aload #30
    //   208: iconst_0
    //   209: putfield cellsUsed : I
    //   212: aload #30
    //   214: iconst_0
    //   215: putfield expandable : Z
    //   218: aload #30
    //   220: iconst_0
    //   221: putfield leftMargin : I
    //   224: aload #30
    //   226: iconst_0
    //   227: putfield rightMargin : I
    //   230: iload #28
    //   232: ifeq -> 252
    //   235: aload #29
    //   237: checkcast android/support/v7/view/menu/ActionMenuItemView
    //   240: invokevirtual hasText : ()Z
    //   243: ifeq -> 252
    //   246: iconst_1
    //   247: istore #28
    //   249: goto -> 255
    //   252: iconst_0
    //   253: istore #28
    //   255: aload #30
    //   257: iload #28
    //   259: putfield preventEdgeOffset : Z
    //   262: aload #30
    //   264: getfield isOverflowButton : Z
    //   267: ifeq -> 275
    //   270: iconst_1
    //   271: istore_2
    //   272: goto -> 277
    //   275: iload_1
    //   276: istore_2
    //   277: aload #29
    //   279: iload #18
    //   281: iload_2
    //   282: iload #17
    //   284: iload #13
    //   286: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   289: istore #14
    //   291: iload #11
    //   293: iload #14
    //   295: invokestatic max : (II)I
    //   298: istore #11
    //   300: iload #9
    //   302: istore_2
    //   303: aload #30
    //   305: getfield expandable : Z
    //   308: ifeq -> 316
    //   311: iload #9
    //   313: iconst_1
    //   314: iadd
    //   315: istore_2
    //   316: aload #30
    //   318: getfield isOverflowButton : Z
    //   321: ifeq -> 327
    //   324: iconst_1
    //   325: istore #8
    //   327: iload_1
    //   328: iload #14
    //   330: isub
    //   331: istore_1
    //   332: iload #6
    //   334: aload #29
    //   336: invokevirtual getMeasuredHeight : ()I
    //   339: invokestatic max : (II)I
    //   342: istore #6
    //   344: iload #14
    //   346: iconst_1
    //   347: if_icmpne -> 363
    //   350: lload #20
    //   352: iconst_1
    //   353: iload #5
    //   355: ishl
    //   356: i2l
    //   357: lor
    //   358: lstore #20
    //   360: goto -> 363
    //   363: iload #5
    //   365: iconst_1
    //   366: iadd
    //   367: istore #5
    //   369: iload_2
    //   370: istore #9
    //   372: goto -> 118
    //   375: iload #8
    //   377: ifeq -> 392
    //   380: iload #12
    //   382: iconst_2
    //   383: if_icmpne -> 392
    //   386: iconst_1
    //   387: istore #13
    //   389: goto -> 395
    //   392: iconst_0
    //   393: istore #13
    //   395: iconst_0
    //   396: istore #5
    //   398: iload_1
    //   399: istore #14
    //   401: iload #15
    //   403: istore_2
    //   404: iload #10
    //   406: istore_1
    //   407: iload #9
    //   409: ifle -> 734
    //   412: iload #14
    //   414: ifle -> 734
    //   417: ldc 2147483647
    //   419: istore #15
    //   421: iconst_0
    //   422: istore #16
    //   424: iconst_0
    //   425: istore #10
    //   427: lconst_0
    //   428: lstore #24
    //   430: iload #16
    //   432: iload #19
    //   434: if_icmpge -> 539
    //   437: aload_0
    //   438: iload #16
    //   440: invokevirtual getChildAt : (I)Landroid/view/View;
    //   443: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   446: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   449: astore #29
    //   451: aload #29
    //   453: getfield expandable : Z
    //   456: ifne -> 466
    //   459: lload #24
    //   461: lstore #22
    //   463: goto -> 526
    //   466: aload #29
    //   468: getfield cellsUsed : I
    //   471: iload #15
    //   473: if_icmpge -> 496
    //   476: aload #29
    //   478: getfield cellsUsed : I
    //   481: istore #15
    //   483: iconst_1
    //   484: iload #16
    //   486: ishl
    //   487: i2l
    //   488: lstore #22
    //   490: iconst_1
    //   491: istore #10
    //   493: goto -> 526
    //   496: aload #29
    //   498: getfield cellsUsed : I
    //   501: iload #15
    //   503: if_icmpne -> 459
    //   506: iconst_1
    //   507: iload #16
    //   509: ishl
    //   510: i2l
    //   511: lstore #22
    //   513: iload #10
    //   515: iconst_1
    //   516: iadd
    //   517: istore #10
    //   519: lload #24
    //   521: lload #22
    //   523: lor
    //   524: lstore #22
    //   526: iload #16
    //   528: iconst_1
    //   529: iadd
    //   530: istore #16
    //   532: lload #22
    //   534: lstore #24
    //   536: goto -> 430
    //   539: iload #5
    //   541: istore #16
    //   543: iload #6
    //   545: istore #5
    //   547: lload #20
    //   549: lload #24
    //   551: lor
    //   552: lstore #20
    //   554: iload #10
    //   556: iload #14
    //   558: if_icmple -> 570
    //   561: iload_1
    //   562: istore #6
    //   564: iload #16
    //   566: istore_1
    //   567: goto -> 748
    //   570: iload #15
    //   572: iconst_1
    //   573: iadd
    //   574: istore #6
    //   576: iconst_0
    //   577: istore #10
    //   579: iload #10
    //   581: iload #19
    //   583: if_icmpge -> 724
    //   586: aload_0
    //   587: iload #10
    //   589: invokevirtual getChildAt : (I)Landroid/view/View;
    //   592: astore #29
    //   594: aload #29
    //   596: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   599: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   602: astore #30
    //   604: iconst_1
    //   605: iload #10
    //   607: ishl
    //   608: i2l
    //   609: lstore #26
    //   611: lload #24
    //   613: lload #26
    //   615: land
    //   616: lconst_0
    //   617: lcmp
    //   618: ifne -> 649
    //   621: lload #20
    //   623: lstore #22
    //   625: aload #30
    //   627: getfield cellsUsed : I
    //   630: iload #6
    //   632: if_icmpne -> 642
    //   635: lload #20
    //   637: lload #26
    //   639: lor
    //   640: lstore #22
    //   642: lload #22
    //   644: lstore #20
    //   646: goto -> 715
    //   649: iload #13
    //   651: ifeq -> 691
    //   654: aload #30
    //   656: getfield preventEdgeOffset : Z
    //   659: ifeq -> 691
    //   662: iload #14
    //   664: iconst_1
    //   665: if_icmpne -> 691
    //   668: aload_0
    //   669: getfield mGeneratedItemPadding : I
    //   672: istore #15
    //   674: aload #29
    //   676: iload #15
    //   678: iload #18
    //   680: iadd
    //   681: iconst_0
    //   682: iload #15
    //   684: iconst_0
    //   685: invokevirtual setPadding : (IIII)V
    //   688: goto -> 691
    //   691: aload #30
    //   693: aload #30
    //   695: getfield cellsUsed : I
    //   698: iconst_1
    //   699: iadd
    //   700: putfield cellsUsed : I
    //   703: aload #30
    //   705: iconst_1
    //   706: putfield expanded : Z
    //   709: iload #14
    //   711: iconst_1
    //   712: isub
    //   713: istore #14
    //   715: iload #10
    //   717: iconst_1
    //   718: iadd
    //   719: istore #10
    //   721: goto -> 579
    //   724: iload #5
    //   726: istore #6
    //   728: iconst_1
    //   729: istore #5
    //   731: goto -> 407
    //   734: iload_1
    //   735: istore #9
    //   737: iload #5
    //   739: istore_1
    //   740: iload #6
    //   742: istore #5
    //   744: iload #9
    //   746: istore #6
    //   748: iload #8
    //   750: ifne -> 765
    //   753: iload #12
    //   755: iconst_1
    //   756: if_icmpne -> 765
    //   759: iconst_1
    //   760: istore #8
    //   762: goto -> 768
    //   765: iconst_0
    //   766: istore #8
    //   768: iload #14
    //   770: ifle -> 1118
    //   773: lload #20
    //   775: lconst_0
    //   776: lcmp
    //   777: ifeq -> 1118
    //   780: iload #14
    //   782: iload #12
    //   784: iconst_1
    //   785: isub
    //   786: if_icmplt -> 800
    //   789: iload #8
    //   791: ifne -> 800
    //   794: iload #11
    //   796: iconst_1
    //   797: if_icmple -> 1118
    //   800: lload #20
    //   802: invokestatic bitCount : (J)I
    //   805: i2f
    //   806: fstore #4
    //   808: iload #8
    //   810: ifne -> 906
    //   813: lload #20
    //   815: lconst_1
    //   816: land
    //   817: lconst_0
    //   818: lcmp
    //   819: ifeq -> 851
    //   822: fload #4
    //   824: fstore_3
    //   825: aload_0
    //   826: iconst_0
    //   827: invokevirtual getChildAt : (I)Landroid/view/View;
    //   830: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   833: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   836: getfield preventEdgeOffset : Z
    //   839: ifne -> 854
    //   842: fload #4
    //   844: ldc 0.5
    //   846: fsub
    //   847: fstore_3
    //   848: goto -> 854
    //   851: fload #4
    //   853: fstore_3
    //   854: iload #19
    //   856: iconst_1
    //   857: isub
    //   858: istore #8
    //   860: fload_3
    //   861: fstore #4
    //   863: lload #20
    //   865: iconst_1
    //   866: iload #8
    //   868: ishl
    //   869: i2l
    //   870: land
    //   871: lconst_0
    //   872: lcmp
    //   873: ifeq -> 906
    //   876: fload_3
    //   877: fstore #4
    //   879: aload_0
    //   880: iload #8
    //   882: invokevirtual getChildAt : (I)Landroid/view/View;
    //   885: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   888: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   891: getfield preventEdgeOffset : Z
    //   894: ifne -> 906
    //   897: fload_3
    //   898: ldc 0.5
    //   900: fsub
    //   901: fstore #4
    //   903: goto -> 906
    //   906: fload #4
    //   908: fconst_0
    //   909: fcmpl
    //   910: ifle -> 928
    //   913: iload #14
    //   915: iload #18
    //   917: imul
    //   918: i2f
    //   919: fload #4
    //   921: fdiv
    //   922: f2i
    //   923: istore #8
    //   925: goto -> 931
    //   928: iconst_0
    //   929: istore #8
    //   931: iconst_0
    //   932: istore #9
    //   934: iload #9
    //   936: iload #19
    //   938: if_icmpge -> 1115
    //   941: lload #20
    //   943: iconst_1
    //   944: iload #9
    //   946: ishl
    //   947: i2l
    //   948: land
    //   949: lconst_0
    //   950: lcmp
    //   951: ifne -> 960
    //   954: iload_1
    //   955: istore #10
    //   957: goto -> 1103
    //   960: aload_0
    //   961: iload #9
    //   963: invokevirtual getChildAt : (I)Landroid/view/View;
    //   966: astore #29
    //   968: aload #29
    //   970: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   973: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   976: astore #30
    //   978: aload #29
    //   980: instanceof android/support/v7/view/menu/ActionMenuItemView
    //   983: ifeq -> 1028
    //   986: aload #30
    //   988: iload #8
    //   990: putfield extraPixels : I
    //   993: aload #30
    //   995: iconst_1
    //   996: putfield expanded : Z
    //   999: iload #9
    //   1001: ifne -> 1025
    //   1004: aload #30
    //   1006: getfield preventEdgeOffset : Z
    //   1009: ifne -> 1025
    //   1012: aload #30
    //   1014: iload #8
    //   1016: ineg
    //   1017: iconst_2
    //   1018: idiv
    //   1019: putfield leftMargin : I
    //   1022: goto -> 1025
    //   1025: goto -> 1059
    //   1028: aload #30
    //   1030: getfield isOverflowButton : Z
    //   1033: ifeq -> 1065
    //   1036: aload #30
    //   1038: iload #8
    //   1040: putfield extraPixels : I
    //   1043: aload #30
    //   1045: iconst_1
    //   1046: putfield expanded : Z
    //   1049: aload #30
    //   1051: iload #8
    //   1053: ineg
    //   1054: iconst_2
    //   1055: idiv
    //   1056: putfield rightMargin : I
    //   1059: iconst_1
    //   1060: istore #10
    //   1062: goto -> 1103
    //   1065: iload #9
    //   1067: ifeq -> 1079
    //   1070: aload #30
    //   1072: iload #8
    //   1074: iconst_2
    //   1075: idiv
    //   1076: putfield leftMargin : I
    //   1079: iload_1
    //   1080: istore #10
    //   1082: iload #9
    //   1084: iload #19
    //   1086: iconst_1
    //   1087: isub
    //   1088: if_icmpeq -> 1103
    //   1091: aload #30
    //   1093: iload #8
    //   1095: iconst_2
    //   1096: idiv
    //   1097: putfield rightMargin : I
    //   1100: iload_1
    //   1101: istore #10
    //   1103: iload #9
    //   1105: iconst_1
    //   1106: iadd
    //   1107: istore #9
    //   1109: iload #10
    //   1111: istore_1
    //   1112: goto -> 934
    //   1115: goto -> 1118
    //   1118: iconst_0
    //   1119: istore #8
    //   1121: iload_1
    //   1122: ifeq -> 1195
    //   1125: iload #8
    //   1127: istore_1
    //   1128: iload_1
    //   1129: iload #19
    //   1131: if_icmpge -> 1195
    //   1134: aload_0
    //   1135: iload_1
    //   1136: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1139: astore #29
    //   1141: aload #29
    //   1143: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1146: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   1149: astore #30
    //   1151: aload #30
    //   1153: getfield expanded : Z
    //   1156: ifne -> 1162
    //   1159: goto -> 1188
    //   1162: aload #29
    //   1164: aload #30
    //   1166: getfield cellsUsed : I
    //   1169: iload #18
    //   1171: imul
    //   1172: aload #30
    //   1174: getfield extraPixels : I
    //   1177: iadd
    //   1178: ldc 1073741824
    //   1180: invokestatic makeMeasureSpec : (II)I
    //   1183: iload #17
    //   1185: invokevirtual measure : (II)V
    //   1188: iload_1
    //   1189: iconst_1
    //   1190: iadd
    //   1191: istore_1
    //   1192: goto -> 1128
    //   1195: iload #6
    //   1197: ldc 1073741824
    //   1199: if_icmpeq -> 1205
    //   1202: goto -> 1209
    //   1205: iload #7
    //   1207: istore #5
    //   1209: aload_0
    //   1210: iload_2
    //   1211: iload #5
    //   1213: invokevirtual setMeasuredDimension : (II)V
    //   1216: return
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams != null && paramLayoutParams instanceof LayoutParams);
  }
  
  public void dismissPopupMenus() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null)
      actionMenuPresenter.dismissPopupMenus(); 
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    LayoutParams layoutParams = new LayoutParams(-2, -2);
    layoutParams.gravity = 16;
    return layoutParams;
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      LayoutParams layoutParams;
      if (paramLayoutParams instanceof LayoutParams) {
        layoutParams = new LayoutParams((LayoutParams)paramLayoutParams);
      } else {
        layoutParams = new LayoutParams((ViewGroup.LayoutParams)layoutParams);
      } 
      if (layoutParams.gravity <= 0)
        layoutParams.gravity = 16; 
      return layoutParams;
    } 
    return generateDefaultLayoutParams();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public LayoutParams generateOverflowButtonLayoutParams() {
    LayoutParams layoutParams = generateDefaultLayoutParams();
    layoutParams.isOverflowButton = true;
    return layoutParams;
  }
  
  public Menu getMenu() {
    if (this.mMenu == null) {
      Context context = getContext();
      this.mMenu = new MenuBuilder(context);
      this.mMenu.setCallback(new MenuBuilderCallback());
      this.mPresenter = new ActionMenuPresenter(context);
      this.mPresenter.setReserveOverflow(true);
      ActionMenuPresenter actionMenuPresenter = this.mPresenter;
      MenuPresenter.Callback callback = this.mActionMenuPresenterCallback;
      if (callback == null)
        callback = new ActionMenuPresenterCallback(); 
      actionMenuPresenter.setCallback(callback);
      this.mMenu.addMenuPresenter((MenuPresenter)this.mPresenter, this.mPopupContext);
      this.mPresenter.setMenuView(this);
    } 
    return (Menu)this.mMenu;
  }
  
  @Nullable
  public Drawable getOverflowIcon() {
    getMenu();
    return this.mPresenter.getOverflowIcon();
  }
  
  public int getPopupTheme() {
    return this.mPopupTheme;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int getWindowAnimations() {
    return 0;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof ActionMenuChildView)
        i = false | ((ActionMenuChildView)view1).needsDividerAfter(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof ActionMenuChildView)
        bool = i | ((ActionMenuChildView)view2).needsDividerBefore(); 
    } 
    return bool;
  }
  
  public boolean hideOverflowMenu() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.hideOverflowMenu());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void initialize(MenuBuilder paramMenuBuilder) {
    this.mMenu = paramMenuBuilder;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl) {
    return this.mMenu.performItemAction((MenuItem)paramMenuItemImpl, 0);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean isOverflowMenuShowPending() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowPending());
  }
  
  public boolean isOverflowMenuShowing() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowing());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null) {
      actionMenuPresenter.updateMenuView(false);
      if (this.mPresenter.isOverflowMenuShowing()) {
        this.mPresenter.hideOverflowMenu();
        this.mPresenter.showOverflowMenu();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.mFormatItems) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int k = getChildCount();
    int j = (paramInt4 - paramInt2) / 2;
    int m = getDividerWidth();
    int n = paramInt3 - paramInt1;
    paramInt1 = getPaddingRight();
    paramInt2 = getPaddingLeft();
    paramBoolean = ViewUtils.isLayoutRtl((View)this);
    paramInt1 = n - paramInt1 - paramInt2;
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < k) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isOverflowButton) {
          int i2;
          int i1 = view.getMeasuredWidth();
          paramInt4 = i1;
          if (hasSupportDividerBeforeChildAt(paramInt2))
            paramInt4 = i1 + m; 
          int i3 = view.getMeasuredHeight();
          if (paramBoolean) {
            i2 = getPaddingLeft() + layoutParams.leftMargin;
            i1 = i2 + paramInt4;
          } else {
            i1 = getWidth() - getPaddingRight() - layoutParams.rightMargin;
            i2 = i1 - paramInt4;
          } 
          int i4 = j - i3 / 2;
          view.layout(i2, i4, i1, i3 + i4);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
          hasSupportDividerBeforeChildAt(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (k == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = n / 2 - paramInt1 / 2;
      paramInt4 = j - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = 0;
    paramInt3 = 0;
    int i = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = paramInt3;
      while (paramInt1 < k) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= layoutParams.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            paramInt4 = view.getMeasuredHeight();
            int i1 = j - paramInt4 / 2;
            view.layout(paramInt2 - paramInt3, i1, paramInt2, paramInt4 + i1);
            paramInt3 = paramInt2 - paramInt3 + layoutParams.leftMargin + i;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = paramInt4;
      while (paramInt1 < k) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += layoutParams.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            paramInt4 = view.getMeasuredHeight();
            int i1 = j - paramInt4 / 2;
            view.layout(paramInt2, i1, paramInt2 + paramInt3, paramInt4 + i1);
            paramInt3 = paramInt2 + paramInt3 + layoutParams.rightMargin + i;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    boolean bool1 = this.mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mFormatItems = bool;
    if (bool1 != this.mFormatItems)
      this.mFormatItemsWidth = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.mFormatItems) {
      MenuBuilder menuBuilder = this.mMenu;
      if (menuBuilder != null && i != this.mFormatItemsWidth) {
        this.mFormatItemsWidth = i;
        menuBuilder.onItemsChanged(true);
      } 
    } 
    int j = getChildCount();
    if (this.mFormatItems && j > 0) {
      onMeasureExactFormat(paramInt1, paramInt2);
      return;
    } 
    for (i = 0; i < j; i++) {
      LayoutParams layoutParams = (LayoutParams)getChildAt(i).getLayoutParams();
      layoutParams.rightMargin = 0;
      layoutParams.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public MenuBuilder peekMenu() {
    return this.mMenu;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mPresenter.setExpandedActionViewsExclusive(paramBoolean);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setMenuCallbacks(MenuPresenter.Callback paramCallback, MenuBuilder.Callback paramCallback1) {
    this.mActionMenuPresenterCallback = paramCallback;
    this.mMenuBuilderCallback = paramCallback1;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.mOnMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void setOverflowIcon(@Nullable Drawable paramDrawable) {
    getMenu();
    this.mPresenter.setOverflowIcon(paramDrawable);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setOverflowReserved(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
  }
  
  public void setPopupTheme(@StyleRes int paramInt) {
    if (this.mPopupTheme != paramInt) {
      this.mPopupTheme = paramInt;
      if (paramInt == 0) {
        this.mPopupContext = getContext();
        return;
      } 
      this.mPopupContext = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter) {
    this.mPresenter = paramActionMenuPresenter;
    this.mPresenter.setMenuView(this);
  }
  
  public boolean showOverflowMenu() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.showOverflowMenu());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static interface ActionMenuChildView {
    boolean needsDividerAfter();
    
    boolean needsDividerBefore();
  }
  
  private class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      return false;
    }
  }
  
  public static class LayoutParams extends LinearLayoutCompat.LayoutParams {
    @ExportedProperty
    public int cellsUsed;
    
    @ExportedProperty
    public boolean expandable;
    
    boolean expanded;
    
    @ExportedProperty
    public int extraPixels;
    
    @ExportedProperty
    public boolean isOverflowButton;
    
    @ExportedProperty
    public boolean preventEdgeOffset;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = false;
    }
    
    LayoutParams(int param1Int1, int param1Int2, boolean param1Boolean) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = param1Boolean;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super((ViewGroup.LayoutParams)param1LayoutParams);
      this.isOverflowButton = param1LayoutParams.isOverflowButton;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
  
  private class MenuBuilderCallback implements MenuBuilder.Callback {
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return (ActionMenuView.this.mOnMenuItemClickListener != null && ActionMenuView.this.mOnMenuItemClickListener.onMenuItemClick(param1MenuItem));
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (ActionMenuView.this.mMenuBuilderCallback != null)
        ActionMenuView.this.mMenuBuilderCallback.onMenuModeChange(param1MenuBuilder); 
    }
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */