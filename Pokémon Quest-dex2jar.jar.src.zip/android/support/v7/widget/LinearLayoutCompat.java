package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RestrictTo;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = tintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(tintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    this.mShowDividers = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = tintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    tintTypedArray.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int k = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          layoutParams.width = k;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int k = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          layoutParams.height = k;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - layoutParams.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  int getLocationOffset(View paramView) {
    return 0;
  }
  
  int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  protected boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.mShowDividers & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = ViewUtils.isLayoutRtl((View)this);
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2;
    int m = getPaddingBottom();
    int n = getPaddingBottom();
    int i = getVirtualChildCount();
    paramInt4 = this.mGravity;
    paramInt2 = paramInt4 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt4 = GravityCompat.getAbsoluteGravity(0x800007 & paramInt4, ViewCompat.getLayoutDirection((View)this));
    if (paramInt4 != 1) {
      if (paramInt4 != 5) {
        paramInt1 = getPaddingLeft();
      } else {
        paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = i - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    paramInt4 = 0;
    paramInt3 = j;
    while (paramInt4 < i) {
      int i1 = b1 + b2 * paramInt4;
      View view = getVirtualChildAt(i1);
      if (view == null) {
        paramInt1 += measureNullChild(i1);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool2 && layoutParams.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = layoutParams.gravity;
        int i2 = i4;
        if (i4 < 0)
          i2 = paramInt2; 
        i2 &= 0x70;
        if (i2 != 16) {
          if (i2 != 48) {
            if (i2 != 80) {
              i2 = paramInt3;
            } else {
              i4 = k - m - i6 - layoutParams.bottomMargin;
              i2 = i4;
              if (i3 != -1) {
                i2 = view.getMeasuredHeight();
                i2 = i4 - arrayOfInt2[2] - i2 - i3;
              } 
            } 
          } else {
            i2 = layoutParams.topMargin + paramInt3;
            if (i3 != -1)
              i2 += arrayOfInt1[1] - i3; 
          } 
        } else {
          i2 = (k - j - n - i6) / 2 + paramInt3 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        int i3 = paramInt1;
        if (hasDividerBeforeChildAt(i1))
          i3 = paramInt1 + this.mDividerWidth; 
        paramInt1 = layoutParams.leftMargin + i3;
        setChildFrame(view, paramInt1 + getLocationOffset(view), i2, i5, i6);
        i2 = layoutParams.rightMargin;
        i3 = getNextLocationOffset(view);
        paramInt4 += getChildrenSkipCount(view, i1);
        paramInt1 += i5 + i2 + i3;
      } 
      paramInt4++;
    } 
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = layoutParams.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + layoutParams.leftMargin;
            paramInt4 = layoutParams.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i3, i2);
          paramInt3 = layoutParams.bottomMargin;
          i3 = getNextLocationOffset(view);
          paramInt4 = paramInt2 + getChildrenSkipCount(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #19
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #21
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #20
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #29
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #25
    //   63: aload #29
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #29
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #29
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #29
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #25
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #25
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #25
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #25
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #23
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #24
    //   115: iload #21
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: iconst_0
    //   132: istore #8
    //   134: ldc_w -2147483648
    //   137: istore #7
    //   139: fconst_0
    //   140: fstore_3
    //   141: iconst_0
    //   142: istore #11
    //   144: iconst_0
    //   145: istore #6
    //   147: iconst_0
    //   148: istore #10
    //   150: iconst_0
    //   151: istore #13
    //   153: iconst_0
    //   154: istore #12
    //   156: iconst_1
    //   157: istore #5
    //   159: iconst_0
    //   160: istore #9
    //   162: iload #8
    //   164: iload #19
    //   166: if_icmpge -> 856
    //   169: aload_0
    //   170: iload #8
    //   172: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   175: astore #27
    //   177: aload #27
    //   179: ifnonnull -> 200
    //   182: aload_0
    //   183: aload_0
    //   184: getfield mTotalLength : I
    //   187: aload_0
    //   188: iload #8
    //   190: invokevirtual measureNullChild : (I)I
    //   193: iadd
    //   194: putfield mTotalLength : I
    //   197: goto -> 847
    //   200: aload #27
    //   202: invokevirtual getVisibility : ()I
    //   205: bipush #8
    //   207: if_icmpne -> 226
    //   210: iload #8
    //   212: aload_0
    //   213: aload #27
    //   215: iload #8
    //   217: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   220: iadd
    //   221: istore #8
    //   223: goto -> 197
    //   226: aload_0
    //   227: iload #8
    //   229: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   232: ifeq -> 248
    //   235: aload_0
    //   236: aload_0
    //   237: getfield mTotalLength : I
    //   240: aload_0
    //   241: getfield mDividerWidth : I
    //   244: iadd
    //   245: putfield mTotalLength : I
    //   248: aload #27
    //   250: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   253: checkcast android/support/v7/widget/LinearLayoutCompat$LayoutParams
    //   256: astore #26
    //   258: fload_3
    //   259: aload #26
    //   261: getfield weight : F
    //   264: fadd
    //   265: fstore_3
    //   266: iload #21
    //   268: ldc 1073741824
    //   270: if_icmpne -> 382
    //   273: aload #26
    //   275: getfield width : I
    //   278: ifne -> 382
    //   281: aload #26
    //   283: getfield weight : F
    //   286: fconst_0
    //   287: fcmpl
    //   288: ifle -> 382
    //   291: iload #15
    //   293: ifeq -> 319
    //   296: aload_0
    //   297: aload_0
    //   298: getfield mTotalLength : I
    //   301: aload #26
    //   303: getfield leftMargin : I
    //   306: aload #26
    //   308: getfield rightMargin : I
    //   311: iadd
    //   312: iadd
    //   313: putfield mTotalLength : I
    //   316: goto -> 348
    //   319: aload_0
    //   320: getfield mTotalLength : I
    //   323: istore #14
    //   325: aload_0
    //   326: iload #14
    //   328: aload #26
    //   330: getfield leftMargin : I
    //   333: iload #14
    //   335: iadd
    //   336: aload #26
    //   338: getfield rightMargin : I
    //   341: iadd
    //   342: invokestatic max : (II)I
    //   345: putfield mTotalLength : I
    //   348: iload #23
    //   350: ifeq -> 376
    //   353: iconst_0
    //   354: iconst_0
    //   355: invokestatic makeMeasureSpec : (II)I
    //   358: istore #14
    //   360: aload #27
    //   362: iload #14
    //   364: iload #14
    //   366: invokevirtual measure : (II)V
    //   369: iload #7
    //   371: istore #14
    //   373: goto -> 570
    //   376: iconst_1
    //   377: istore #13
    //   379: goto -> 574
    //   382: aload #26
    //   384: getfield width : I
    //   387: ifne -> 413
    //   390: aload #26
    //   392: getfield weight : F
    //   395: fconst_0
    //   396: fcmpl
    //   397: ifle -> 413
    //   400: aload #26
    //   402: bipush #-2
    //   404: putfield width : I
    //   407: iconst_0
    //   408: istore #14
    //   410: goto -> 418
    //   413: ldc_w -2147483648
    //   416: istore #14
    //   418: fload_3
    //   419: fconst_0
    //   420: fcmpl
    //   421: ifne -> 433
    //   424: aload_0
    //   425: getfield mTotalLength : I
    //   428: istore #16
    //   430: goto -> 436
    //   433: iconst_0
    //   434: istore #16
    //   436: aload #26
    //   438: astore #28
    //   440: aload_0
    //   441: aload #27
    //   443: iload #8
    //   445: iload_1
    //   446: iload #16
    //   448: iload_2
    //   449: iconst_0
    //   450: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   453: iload #14
    //   455: ldc_w -2147483648
    //   458: if_icmpeq -> 468
    //   461: aload #28
    //   463: iload #14
    //   465: putfield width : I
    //   468: aload #27
    //   470: invokevirtual getMeasuredWidth : ()I
    //   473: istore #16
    //   475: iload #15
    //   477: ifeq -> 513
    //   480: aload_0
    //   481: aload_0
    //   482: getfield mTotalLength : I
    //   485: aload #28
    //   487: getfield leftMargin : I
    //   490: iload #16
    //   492: iadd
    //   493: aload #28
    //   495: getfield rightMargin : I
    //   498: iadd
    //   499: aload_0
    //   500: aload #27
    //   502: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   505: iadd
    //   506: iadd
    //   507: putfield mTotalLength : I
    //   510: goto -> 552
    //   513: aload_0
    //   514: getfield mTotalLength : I
    //   517: istore #14
    //   519: aload_0
    //   520: iload #14
    //   522: iload #14
    //   524: iload #16
    //   526: iadd
    //   527: aload #28
    //   529: getfield leftMargin : I
    //   532: iadd
    //   533: aload #28
    //   535: getfield rightMargin : I
    //   538: iadd
    //   539: aload_0
    //   540: aload #27
    //   542: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   545: iadd
    //   546: invokestatic max : (II)I
    //   549: putfield mTotalLength : I
    //   552: iload #7
    //   554: istore #14
    //   556: iload #24
    //   558: ifeq -> 570
    //   561: iload #16
    //   563: iload #7
    //   565: invokestatic max : (II)I
    //   568: istore #14
    //   570: iload #14
    //   572: istore #7
    //   574: iload #8
    //   576: istore #17
    //   578: iload #20
    //   580: ldc 1073741824
    //   582: if_icmpeq -> 603
    //   585: aload #26
    //   587: getfield height : I
    //   590: iconst_m1
    //   591: if_icmpne -> 603
    //   594: iconst_1
    //   595: istore #8
    //   597: iconst_1
    //   598: istore #9
    //   600: goto -> 606
    //   603: iconst_0
    //   604: istore #8
    //   606: aload #26
    //   608: getfield topMargin : I
    //   611: aload #26
    //   613: getfield bottomMargin : I
    //   616: iadd
    //   617: istore #14
    //   619: aload #27
    //   621: invokevirtual getMeasuredHeight : ()I
    //   624: iload #14
    //   626: iadd
    //   627: istore #16
    //   629: iload #12
    //   631: aload #27
    //   633: invokestatic getMeasuredState : (Landroid/view/View;)I
    //   636: invokestatic combineMeasuredStates : (II)I
    //   639: istore #18
    //   641: iload #23
    //   643: ifeq -> 730
    //   646: aload #27
    //   648: invokevirtual getBaseline : ()I
    //   651: istore #22
    //   653: iload #22
    //   655: iconst_m1
    //   656: if_icmpeq -> 730
    //   659: aload #26
    //   661: getfield gravity : I
    //   664: ifge -> 676
    //   667: aload_0
    //   668: getfield mGravity : I
    //   671: istore #12
    //   673: goto -> 683
    //   676: aload #26
    //   678: getfield gravity : I
    //   681: istore #12
    //   683: iload #12
    //   685: bipush #112
    //   687: iand
    //   688: iconst_4
    //   689: ishr
    //   690: bipush #-2
    //   692: iand
    //   693: iconst_1
    //   694: ishr
    //   695: istore #12
    //   697: aload #29
    //   699: iload #12
    //   701: aload #29
    //   703: iload #12
    //   705: iaload
    //   706: iload #22
    //   708: invokestatic max : (II)I
    //   711: iastore
    //   712: aload #25
    //   714: iload #12
    //   716: aload #25
    //   718: iload #12
    //   720: iaload
    //   721: iload #16
    //   723: iload #22
    //   725: isub
    //   726: invokestatic max : (II)I
    //   729: iastore
    //   730: iload #11
    //   732: iload #16
    //   734: invokestatic max : (II)I
    //   737: istore #11
    //   739: iload #5
    //   741: ifeq -> 759
    //   744: aload #26
    //   746: getfield height : I
    //   749: iconst_m1
    //   750: if_icmpne -> 759
    //   753: iconst_1
    //   754: istore #5
    //   756: goto -> 762
    //   759: iconst_0
    //   760: istore #5
    //   762: aload #26
    //   764: getfield weight : F
    //   767: fconst_0
    //   768: fcmpl
    //   769: ifle -> 796
    //   772: iload #8
    //   774: ifeq -> 780
    //   777: goto -> 784
    //   780: iload #16
    //   782: istore #14
    //   784: iload #10
    //   786: iload #14
    //   788: invokestatic max : (II)I
    //   791: istore #8
    //   793: goto -> 818
    //   796: iload #8
    //   798: ifeq -> 805
    //   801: iload #14
    //   803: istore #16
    //   805: iload #6
    //   807: iload #16
    //   809: invokestatic max : (II)I
    //   812: istore #6
    //   814: iload #10
    //   816: istore #8
    //   818: aload_0
    //   819: aload #27
    //   821: iload #17
    //   823: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   826: istore #10
    //   828: iload #10
    //   830: iload #17
    //   832: iadd
    //   833: istore #14
    //   835: iload #18
    //   837: istore #12
    //   839: iload #8
    //   841: istore #10
    //   843: iload #14
    //   845: istore #8
    //   847: iload #8
    //   849: iconst_1
    //   850: iadd
    //   851: istore #8
    //   853: goto -> 162
    //   856: aload_0
    //   857: getfield mTotalLength : I
    //   860: ifle -> 885
    //   863: aload_0
    //   864: iload #19
    //   866: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   869: ifeq -> 885
    //   872: aload_0
    //   873: aload_0
    //   874: getfield mTotalLength : I
    //   877: aload_0
    //   878: getfield mDividerWidth : I
    //   881: iadd
    //   882: putfield mTotalLength : I
    //   885: aload #29
    //   887: iconst_1
    //   888: iaload
    //   889: iconst_m1
    //   890: if_icmpne -> 921
    //   893: aload #29
    //   895: iconst_0
    //   896: iaload
    //   897: iconst_m1
    //   898: if_icmpne -> 921
    //   901: aload #29
    //   903: iconst_2
    //   904: iaload
    //   905: iconst_m1
    //   906: if_icmpne -> 921
    //   909: iload #11
    //   911: istore #8
    //   913: aload #29
    //   915: iconst_3
    //   916: iaload
    //   917: iconst_m1
    //   918: if_icmpeq -> 979
    //   921: iload #11
    //   923: aload #29
    //   925: iconst_3
    //   926: iaload
    //   927: aload #29
    //   929: iconst_0
    //   930: iaload
    //   931: aload #29
    //   933: iconst_1
    //   934: iaload
    //   935: aload #29
    //   937: iconst_2
    //   938: iaload
    //   939: invokestatic max : (II)I
    //   942: invokestatic max : (II)I
    //   945: invokestatic max : (II)I
    //   948: aload #25
    //   950: iconst_3
    //   951: iaload
    //   952: aload #25
    //   954: iconst_0
    //   955: iaload
    //   956: aload #25
    //   958: iconst_1
    //   959: iaload
    //   960: aload #25
    //   962: iconst_2
    //   963: iaload
    //   964: invokestatic max : (II)I
    //   967: invokestatic max : (II)I
    //   970: invokestatic max : (II)I
    //   973: iadd
    //   974: invokestatic max : (II)I
    //   977: istore #8
    //   979: iload #24
    //   981: ifeq -> 1165
    //   984: iload #21
    //   986: ldc_w -2147483648
    //   989: if_icmpeq -> 997
    //   992: iload #21
    //   994: ifne -> 1165
    //   997: aload_0
    //   998: iconst_0
    //   999: putfield mTotalLength : I
    //   1002: iconst_0
    //   1003: istore #11
    //   1005: iload #11
    //   1007: iload #19
    //   1009: if_icmpge -> 1165
    //   1012: aload_0
    //   1013: iload #11
    //   1015: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1018: astore #26
    //   1020: aload #26
    //   1022: ifnonnull -> 1043
    //   1025: aload_0
    //   1026: aload_0
    //   1027: getfield mTotalLength : I
    //   1030: aload_0
    //   1031: iload #11
    //   1033: invokevirtual measureNullChild : (I)I
    //   1036: iadd
    //   1037: putfield mTotalLength : I
    //   1040: goto -> 1156
    //   1043: aload #26
    //   1045: invokevirtual getVisibility : ()I
    //   1048: bipush #8
    //   1050: if_icmpne -> 1069
    //   1053: iload #11
    //   1055: aload_0
    //   1056: aload #26
    //   1058: iload #11
    //   1060: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1063: iadd
    //   1064: istore #11
    //   1066: goto -> 1156
    //   1069: aload #26
    //   1071: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1074: checkcast android/support/v7/widget/LinearLayoutCompat$LayoutParams
    //   1077: astore #27
    //   1079: iload #15
    //   1081: ifeq -> 1117
    //   1084: aload_0
    //   1085: aload_0
    //   1086: getfield mTotalLength : I
    //   1089: aload #27
    //   1091: getfield leftMargin : I
    //   1094: iload #7
    //   1096: iadd
    //   1097: aload #27
    //   1099: getfield rightMargin : I
    //   1102: iadd
    //   1103: aload_0
    //   1104: aload #26
    //   1106: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1109: iadd
    //   1110: iadd
    //   1111: putfield mTotalLength : I
    //   1114: goto -> 1156
    //   1117: aload_0
    //   1118: getfield mTotalLength : I
    //   1121: istore #14
    //   1123: aload_0
    //   1124: iload #14
    //   1126: iload #14
    //   1128: iload #7
    //   1130: iadd
    //   1131: aload #27
    //   1133: getfield leftMargin : I
    //   1136: iadd
    //   1137: aload #27
    //   1139: getfield rightMargin : I
    //   1142: iadd
    //   1143: aload_0
    //   1144: aload #26
    //   1146: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1149: iadd
    //   1150: invokestatic max : (II)I
    //   1153: putfield mTotalLength : I
    //   1156: iload #11
    //   1158: iconst_1
    //   1159: iadd
    //   1160: istore #11
    //   1162: goto -> 1005
    //   1165: aload_0
    //   1166: aload_0
    //   1167: getfield mTotalLength : I
    //   1170: aload_0
    //   1171: invokevirtual getPaddingLeft : ()I
    //   1174: aload_0
    //   1175: invokevirtual getPaddingRight : ()I
    //   1178: iadd
    //   1179: iadd
    //   1180: putfield mTotalLength : I
    //   1183: aload_0
    //   1184: getfield mTotalLength : I
    //   1187: aload_0
    //   1188: invokevirtual getSuggestedMinimumWidth : ()I
    //   1191: invokestatic max : (II)I
    //   1194: iload_1
    //   1195: iconst_0
    //   1196: invokestatic resolveSizeAndState : (III)I
    //   1199: istore #17
    //   1201: ldc_w 16777215
    //   1204: iload #17
    //   1206: iand
    //   1207: aload_0
    //   1208: getfield mTotalLength : I
    //   1211: isub
    //   1212: istore #11
    //   1214: iload #13
    //   1216: ifne -> 1352
    //   1219: iload #11
    //   1221: ifeq -> 1233
    //   1224: fload_3
    //   1225: fconst_0
    //   1226: fcmpl
    //   1227: ifle -> 1233
    //   1230: goto -> 1352
    //   1233: iload #6
    //   1235: iload #10
    //   1237: invokestatic max : (II)I
    //   1240: istore #10
    //   1242: iload #24
    //   1244: ifeq -> 1337
    //   1247: iload #21
    //   1249: ldc 1073741824
    //   1251: if_icmpeq -> 1337
    //   1254: iconst_0
    //   1255: istore #6
    //   1257: iload #6
    //   1259: iload #19
    //   1261: if_icmpge -> 1337
    //   1264: aload_0
    //   1265: iload #6
    //   1267: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1270: astore #25
    //   1272: aload #25
    //   1274: ifnull -> 1328
    //   1277: aload #25
    //   1279: invokevirtual getVisibility : ()I
    //   1282: bipush #8
    //   1284: if_icmpne -> 1290
    //   1287: goto -> 1328
    //   1290: aload #25
    //   1292: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1295: checkcast android/support/v7/widget/LinearLayoutCompat$LayoutParams
    //   1298: getfield weight : F
    //   1301: fconst_0
    //   1302: fcmpl
    //   1303: ifle -> 1328
    //   1306: aload #25
    //   1308: iload #7
    //   1310: ldc 1073741824
    //   1312: invokestatic makeMeasureSpec : (II)I
    //   1315: aload #25
    //   1317: invokevirtual getMeasuredHeight : ()I
    //   1320: ldc 1073741824
    //   1322: invokestatic makeMeasureSpec : (II)I
    //   1325: invokevirtual measure : (II)V
    //   1328: iload #6
    //   1330: iconst_1
    //   1331: iadd
    //   1332: istore #6
    //   1334: goto -> 1257
    //   1337: iload #8
    //   1339: istore #6
    //   1341: iload #10
    //   1343: istore #7
    //   1345: iload #5
    //   1347: istore #8
    //   1349: goto -> 2093
    //   1352: aload_0
    //   1353: getfield mWeightSum : F
    //   1356: fstore #4
    //   1358: fload #4
    //   1360: fconst_0
    //   1361: fcmpl
    //   1362: ifle -> 1371
    //   1365: fload #4
    //   1367: fstore_3
    //   1368: goto -> 1371
    //   1371: aload #29
    //   1373: iconst_3
    //   1374: iconst_m1
    //   1375: iastore
    //   1376: aload #29
    //   1378: iconst_2
    //   1379: iconst_m1
    //   1380: iastore
    //   1381: aload #29
    //   1383: iconst_1
    //   1384: iconst_m1
    //   1385: iastore
    //   1386: aload #29
    //   1388: iconst_0
    //   1389: iconst_m1
    //   1390: iastore
    //   1391: aload #25
    //   1393: iconst_3
    //   1394: iconst_m1
    //   1395: iastore
    //   1396: aload #25
    //   1398: iconst_2
    //   1399: iconst_m1
    //   1400: iastore
    //   1401: aload #25
    //   1403: iconst_1
    //   1404: iconst_m1
    //   1405: iastore
    //   1406: aload #25
    //   1408: iconst_0
    //   1409: iconst_m1
    //   1410: iastore
    //   1411: aload_0
    //   1412: iconst_0
    //   1413: putfield mTotalLength : I
    //   1416: iconst_m1
    //   1417: istore #10
    //   1419: iconst_0
    //   1420: istore #13
    //   1422: iload #5
    //   1424: istore #7
    //   1426: iload #12
    //   1428: istore #5
    //   1430: iload #6
    //   1432: istore #8
    //   1434: iload #11
    //   1436: istore #6
    //   1438: iload #13
    //   1440: istore #12
    //   1442: iload #12
    //   1444: iload #19
    //   1446: if_icmpge -> 1959
    //   1449: aload_0
    //   1450: iload #12
    //   1452: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1455: astore #26
    //   1457: aload #26
    //   1459: ifnull -> 1950
    //   1462: aload #26
    //   1464: invokevirtual getVisibility : ()I
    //   1467: bipush #8
    //   1469: if_icmpne -> 1475
    //   1472: goto -> 1950
    //   1475: aload #26
    //   1477: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1480: checkcast android/support/v7/widget/LinearLayoutCompat$LayoutParams
    //   1483: astore #27
    //   1485: aload #27
    //   1487: getfield weight : F
    //   1490: fstore #4
    //   1492: fload #4
    //   1494: fconst_0
    //   1495: fcmpl
    //   1496: ifle -> 1659
    //   1499: iload #6
    //   1501: i2f
    //   1502: fload #4
    //   1504: fmul
    //   1505: fload_3
    //   1506: fdiv
    //   1507: f2i
    //   1508: istore #13
    //   1510: iload_2
    //   1511: aload_0
    //   1512: invokevirtual getPaddingTop : ()I
    //   1515: aload_0
    //   1516: invokevirtual getPaddingBottom : ()I
    //   1519: iadd
    //   1520: aload #27
    //   1522: getfield topMargin : I
    //   1525: iadd
    //   1526: aload #27
    //   1528: getfield bottomMargin : I
    //   1531: iadd
    //   1532: aload #27
    //   1534: getfield height : I
    //   1537: invokestatic getChildMeasureSpec : (III)I
    //   1540: istore #16
    //   1542: aload #27
    //   1544: getfield width : I
    //   1547: ifne -> 1592
    //   1550: iload #21
    //   1552: ldc 1073741824
    //   1554: if_icmpeq -> 1560
    //   1557: goto -> 1592
    //   1560: iload #13
    //   1562: ifle -> 1572
    //   1565: iload #13
    //   1567: istore #11
    //   1569: goto -> 1575
    //   1572: iconst_0
    //   1573: istore #11
    //   1575: aload #26
    //   1577: iload #11
    //   1579: ldc 1073741824
    //   1581: invokestatic makeMeasureSpec : (II)I
    //   1584: iload #16
    //   1586: invokevirtual measure : (II)V
    //   1589: goto -> 1628
    //   1592: aload #26
    //   1594: invokevirtual getMeasuredWidth : ()I
    //   1597: iload #13
    //   1599: iadd
    //   1600: istore #14
    //   1602: iload #14
    //   1604: istore #11
    //   1606: iload #14
    //   1608: ifge -> 1614
    //   1611: iconst_0
    //   1612: istore #11
    //   1614: aload #26
    //   1616: iload #11
    //   1618: ldc 1073741824
    //   1620: invokestatic makeMeasureSpec : (II)I
    //   1623: iload #16
    //   1625: invokevirtual measure : (II)V
    //   1628: iload #5
    //   1630: aload #26
    //   1632: invokestatic getMeasuredState : (Landroid/view/View;)I
    //   1635: ldc_w -16777216
    //   1638: iand
    //   1639: invokestatic combineMeasuredStates : (II)I
    //   1642: istore #5
    //   1644: fload_3
    //   1645: fload #4
    //   1647: fsub
    //   1648: fstore_3
    //   1649: iload #6
    //   1651: iload #13
    //   1653: isub
    //   1654: istore #6
    //   1656: goto -> 1659
    //   1659: iload #15
    //   1661: ifeq -> 1700
    //   1664: aload_0
    //   1665: aload_0
    //   1666: getfield mTotalLength : I
    //   1669: aload #26
    //   1671: invokevirtual getMeasuredWidth : ()I
    //   1674: aload #27
    //   1676: getfield leftMargin : I
    //   1679: iadd
    //   1680: aload #27
    //   1682: getfield rightMargin : I
    //   1685: iadd
    //   1686: aload_0
    //   1687: aload #26
    //   1689: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1692: iadd
    //   1693: iadd
    //   1694: putfield mTotalLength : I
    //   1697: goto -> 1742
    //   1700: aload_0
    //   1701: getfield mTotalLength : I
    //   1704: istore #11
    //   1706: aload_0
    //   1707: iload #11
    //   1709: aload #26
    //   1711: invokevirtual getMeasuredWidth : ()I
    //   1714: iload #11
    //   1716: iadd
    //   1717: aload #27
    //   1719: getfield leftMargin : I
    //   1722: iadd
    //   1723: aload #27
    //   1725: getfield rightMargin : I
    //   1728: iadd
    //   1729: aload_0
    //   1730: aload #26
    //   1732: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1735: iadd
    //   1736: invokestatic max : (II)I
    //   1739: putfield mTotalLength : I
    //   1742: iload #20
    //   1744: ldc 1073741824
    //   1746: if_icmpeq -> 1764
    //   1749: aload #27
    //   1751: getfield height : I
    //   1754: iconst_m1
    //   1755: if_icmpne -> 1764
    //   1758: iconst_1
    //   1759: istore #11
    //   1761: goto -> 1767
    //   1764: iconst_0
    //   1765: istore #11
    //   1767: aload #27
    //   1769: getfield topMargin : I
    //   1772: aload #27
    //   1774: getfield bottomMargin : I
    //   1777: iadd
    //   1778: istore #16
    //   1780: aload #26
    //   1782: invokevirtual getMeasuredHeight : ()I
    //   1785: iload #16
    //   1787: iadd
    //   1788: istore #14
    //   1790: iload #10
    //   1792: iload #14
    //   1794: invokestatic max : (II)I
    //   1797: istore #13
    //   1799: iload #11
    //   1801: ifeq -> 1811
    //   1804: iload #16
    //   1806: istore #10
    //   1808: goto -> 1815
    //   1811: iload #14
    //   1813: istore #10
    //   1815: iload #8
    //   1817: iload #10
    //   1819: invokestatic max : (II)I
    //   1822: istore #10
    //   1824: iload #7
    //   1826: ifeq -> 1844
    //   1829: aload #27
    //   1831: getfield height : I
    //   1834: iconst_m1
    //   1835: if_icmpne -> 1844
    //   1838: iconst_1
    //   1839: istore #7
    //   1841: goto -> 1847
    //   1844: iconst_0
    //   1845: istore #7
    //   1847: iload #23
    //   1849: ifeq -> 1939
    //   1852: aload #26
    //   1854: invokevirtual getBaseline : ()I
    //   1857: istore #11
    //   1859: iload #11
    //   1861: iconst_m1
    //   1862: if_icmpeq -> 1939
    //   1865: aload #27
    //   1867: getfield gravity : I
    //   1870: ifge -> 1882
    //   1873: aload_0
    //   1874: getfield mGravity : I
    //   1877: istore #8
    //   1879: goto -> 1889
    //   1882: aload #27
    //   1884: getfield gravity : I
    //   1887: istore #8
    //   1889: iload #8
    //   1891: bipush #112
    //   1893: iand
    //   1894: iconst_4
    //   1895: ishr
    //   1896: bipush #-2
    //   1898: iand
    //   1899: iconst_1
    //   1900: ishr
    //   1901: istore #8
    //   1903: aload #29
    //   1905: iload #8
    //   1907: aload #29
    //   1909: iload #8
    //   1911: iaload
    //   1912: iload #11
    //   1914: invokestatic max : (II)I
    //   1917: iastore
    //   1918: aload #25
    //   1920: iload #8
    //   1922: aload #25
    //   1924: iload #8
    //   1926: iaload
    //   1927: iload #14
    //   1929: iload #11
    //   1931: isub
    //   1932: invokestatic max : (II)I
    //   1935: iastore
    //   1936: goto -> 1939
    //   1939: iload #10
    //   1941: istore #8
    //   1943: iload #13
    //   1945: istore #10
    //   1947: goto -> 1950
    //   1950: iload #12
    //   1952: iconst_1
    //   1953: iadd
    //   1954: istore #12
    //   1956: goto -> 1442
    //   1959: aload_0
    //   1960: aload_0
    //   1961: getfield mTotalLength : I
    //   1964: aload_0
    //   1965: invokevirtual getPaddingLeft : ()I
    //   1968: aload_0
    //   1969: invokevirtual getPaddingRight : ()I
    //   1972: iadd
    //   1973: iadd
    //   1974: putfield mTotalLength : I
    //   1977: aload #29
    //   1979: iconst_1
    //   1980: iaload
    //   1981: iconst_m1
    //   1982: if_icmpne -> 2019
    //   1985: aload #29
    //   1987: iconst_0
    //   1988: iaload
    //   1989: iconst_m1
    //   1990: if_icmpne -> 2019
    //   1993: aload #29
    //   1995: iconst_2
    //   1996: iaload
    //   1997: iconst_m1
    //   1998: if_icmpne -> 2019
    //   2001: aload #29
    //   2003: iconst_3
    //   2004: iaload
    //   2005: iconst_m1
    //   2006: if_icmpeq -> 2012
    //   2009: goto -> 2019
    //   2012: iload #10
    //   2014: istore #6
    //   2016: goto -> 2077
    //   2019: iload #10
    //   2021: aload #29
    //   2023: iconst_3
    //   2024: iaload
    //   2025: aload #29
    //   2027: iconst_0
    //   2028: iaload
    //   2029: aload #29
    //   2031: iconst_1
    //   2032: iaload
    //   2033: aload #29
    //   2035: iconst_2
    //   2036: iaload
    //   2037: invokestatic max : (II)I
    //   2040: invokestatic max : (II)I
    //   2043: invokestatic max : (II)I
    //   2046: aload #25
    //   2048: iconst_3
    //   2049: iaload
    //   2050: aload #25
    //   2052: iconst_0
    //   2053: iaload
    //   2054: aload #25
    //   2056: iconst_1
    //   2057: iaload
    //   2058: aload #25
    //   2060: iconst_2
    //   2061: iaload
    //   2062: invokestatic max : (II)I
    //   2065: invokestatic max : (II)I
    //   2068: invokestatic max : (II)I
    //   2071: iadd
    //   2072: invokestatic max : (II)I
    //   2075: istore #6
    //   2077: iload #8
    //   2079: istore #10
    //   2081: iload #7
    //   2083: istore #8
    //   2085: iload #5
    //   2087: istore #12
    //   2089: iload #10
    //   2091: istore #7
    //   2093: iload #6
    //   2095: istore #5
    //   2097: iload #8
    //   2099: ifne -> 2117
    //   2102: iload #6
    //   2104: istore #5
    //   2106: iload #20
    //   2108: ldc 1073741824
    //   2110: if_icmpeq -> 2117
    //   2113: iload #7
    //   2115: istore #5
    //   2117: aload_0
    //   2118: iload #17
    //   2120: ldc_w -16777216
    //   2123: iload #12
    //   2125: iand
    //   2126: ior
    //   2127: iload #5
    //   2129: aload_0
    //   2130: invokevirtual getPaddingTop : ()I
    //   2133: aload_0
    //   2134: invokevirtual getPaddingBottom : ()I
    //   2137: iadd
    //   2138: iadd
    //   2139: aload_0
    //   2140: invokevirtual getSuggestedMinimumHeight : ()I
    //   2143: invokestatic max : (II)I
    //   2146: iload_2
    //   2147: iload #12
    //   2149: bipush #16
    //   2151: ishl
    //   2152: invokestatic resolveSizeAndState : (III)I
    //   2155: invokevirtual setMeasuredDimension : (II)V
    //   2158: iload #9
    //   2160: ifeq -> 2170
    //   2163: aload_0
    //   2164: iload #19
    //   2166: iload_1
    //   2167: invokespecial forceUniformHeight : (II)V
    //   2170: return
  }
  
  int measureNullChild(int paramInt) {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2) {
    int n = 0;
    this.mTotalLength = 0;
    int i3 = getVirtualChildCount();
    int i8 = View.MeasureSpec.getMode(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    int i9 = this.mBaselineAlignedChildIndex;
    boolean bool1 = this.mUseLargestChild;
    float f = 0.0F;
    int i = 0;
    int i1 = Integer.MIN_VALUE;
    int i4 = 0;
    int i2 = 0;
    int i5 = 0;
    int m = 1;
    boolean bool = false;
    int j = 0;
    while (true) {
      int i10;
      if (i2 < i3) {
        View view = getVirtualChildAt(i2);
        if (view == null) {
          this.mTotalLength += measureNullChild(i2);
        } else if (view.getVisibility() == 8) {
          i2 += getChildrenSkipCount(view, i2);
        } else {
          int i11;
          if (hasDividerBeforeChildAt(i2))
            this.mTotalLength += this.mDividerHeight; 
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f += layoutParams.weight;
          if (k == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0F) {
            i5 = this.mTotalLength;
            this.mTotalLength = Math.max(i5, layoutParams.topMargin + i5 + layoutParams.bottomMargin);
            i5 = 1;
          } else {
            if (layoutParams.height == 0 && layoutParams.weight > 0.0F) {
              layoutParams.height = -2;
              i11 = 0;
            } else {
              i11 = Integer.MIN_VALUE;
            } 
            if (f == 0.0F) {
              i13 = this.mTotalLength;
            } else {
              i13 = 0;
            } 
            LayoutParams layoutParams1 = layoutParams;
            measureChildBeforeLayout(view, i2, paramInt1, 0, paramInt2, i13);
            if (i11 != Integer.MIN_VALUE)
              layoutParams1.height = i11; 
            i11 = view.getMeasuredHeight();
            int i13 = this.mTotalLength;
            this.mTotalLength = Math.max(i13, i13 + i11 + layoutParams1.topMargin + layoutParams1.bottomMargin + getNextLocationOffset(view));
            if (bool1)
              i1 = Math.max(i11, i1); 
          } 
          int i12 = i2;
          if (i9 >= 0 && i9 == i12 + 1)
            this.mBaselineChildTop = this.mTotalLength; 
          if (i12 >= i9 || layoutParams.weight <= 0.0F) {
            if (i8 != 1073741824 && layoutParams.width == -1) {
              i2 = 1;
              bool = true;
            } else {
              i2 = 0;
            } 
            i11 = layoutParams.leftMargin + layoutParams.rightMargin;
            int i13 = view.getMeasuredWidth() + i11;
            int i14 = Math.max(i, i13);
            n = ViewUtils.combineMeasuredStates(n, ViewCompat.getMeasuredState(view));
            if (m && layoutParams.width == -1) {
              i = 1;
            } else {
              i = 0;
            } 
            if (layoutParams.weight > 0.0F) {
              if (i2 == 0)
                i11 = i13; 
              m = Math.max(i4, i11);
            } else {
              m = i4;
              if (i2 != 0)
                i13 = i11; 
              j = Math.max(j, i13);
            } 
            i11 = getChildrenSkipCount(view, i12);
            i2 = i14;
            i4 = m;
            i11 += i12;
            m = i;
            i = i2;
          } else {
            throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
          } 
          i2 = i11 + 1;
        } 
        i10 = i2;
      } else {
        break;
      } 
      i2 = i10 + 1;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i3))
      this.mTotalLength += this.mDividerHeight; 
    int i6 = i3;
    if (bool1) {
      i2 = k;
      if (i2 == Integer.MIN_VALUE || i2 == 0) {
        this.mTotalLength = 0;
        for (i2 = 0; i2 < i6; i2++) {
          View view = getVirtualChildAt(i2);
          if (view == null) {
            this.mTotalLength += measureNullChild(i2);
          } else if (view.getVisibility() == 8) {
            i2 += getChildrenSkipCount(view, i2);
          } else {
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            i3 = this.mTotalLength;
            this.mTotalLength = Math.max(i3, i3 + i1 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          } 
        } 
      } 
    } 
    this.mTotalLength += getPaddingTop() + getPaddingBottom();
    int i7 = ViewCompat.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumHeight()), paramInt2, 0);
    i2 = (0xFFFFFF & i7) - this.mTotalLength;
    if (i5 != 0 || (i2 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      i3 = 0;
      i1 = i;
      i = i2;
      i2 = k;
      k = i1;
      while (i3 < i6) {
        View view = getVirtualChildAt(i3);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i4 = (int)(i * f1 / f);
            i1 = getPaddingLeft();
            i5 = getPaddingRight();
            f -= f1;
            int i10 = getChildMeasureSpec(paramInt1, i1 + i5 + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width);
            if (layoutParams.height != 0 || i2 != 1073741824) {
              i5 = view.getMeasuredHeight() + i4;
              i1 = i5;
              if (i5 < 0)
                i1 = 0; 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
            } else {
              if (i4 > 0) {
                i1 = i4;
              } else {
                i1 = 0;
              } 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
            } 
            n = ViewUtils.combineMeasuredStates(n, ViewCompat.getMeasuredState(view) & 0xFFFFFF00);
            i -= i4;
          } 
          i5 = layoutParams.leftMargin + layoutParams.rightMargin;
          i1 = view.getMeasuredWidth() + i5;
          i4 = Math.max(k, i1);
          if (i8 != 1073741824 && layoutParams.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          if (k != 0)
            i1 = i5; 
          k = Math.max(j, i1);
          if (m != 0 && layoutParams.width == -1) {
            j = 1;
          } else {
            j = 0;
          } 
          m = this.mTotalLength;
          this.mTotalLength = Math.max(m, view.getMeasuredHeight() + m + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          m = j;
          j = k;
          k = i4;
        } 
        i3++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      i = j;
    } else {
      i2 = Math.max(j, i4);
      if (bool1 && k != 1073741824)
        for (j = 0; j < i6; j++) {
          View view = getVirtualChildAt(j);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i1, 1073741824)); 
        }  
      k = i;
      i = i2;
    } 
    if (m != 0 || i8 == 1073741824)
      i = k; 
    setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, n), i7);
    if (bool)
      forceUniformWidth(i6, paramInt2); 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
      return;
    } 
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (Build.VERSION.SDK_INT >= 14) {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(LinearLayoutCompat.class.getName());
    } 
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    if (Build.VERSION.SDK_INT >= 14) {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(LinearLayoutCompat.class.getName());
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
      return;
    } 
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface DividerMode {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int gravity = -1;
    
    public float weight;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.weight = 0.0F;
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2);
      this.weight = param1Float;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.LinearLayoutCompat_Layout);
      this.weight = typedArray.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
      this.gravity = typedArray.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
      typedArray.recycle();
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.weight = param1LayoutParams.weight;
      this.gravity = param1LayoutParams.gravity;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface OrientationMode {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */