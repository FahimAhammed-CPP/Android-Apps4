package android.support.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.widget.MenuItemHoverListener;
import android.support.v7.widget.MenuPopupWindow;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

final class CascadingMenuPopup extends MenuPopup implements MenuPresenter, View.OnKeyListener, PopupWindow.OnDismissListener {
  static final int HORIZ_POSITION_LEFT = 0;
  
  static final int HORIZ_POSITION_RIGHT = 1;
  
  static final int SUBMENU_TIMEOUT_MS = 200;
  
  private View mAnchorView;
  
  private final Context mContext;
  
  private int mDropDownGravity = 0;
  
  private boolean mForceShowIcon;
  
  private final ViewTreeObserver.OnGlobalLayoutListener mGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
      public void onGlobalLayout() {
        if (CascadingMenuPopup.this.isShowing() && CascadingMenuPopup.this.mShowingMenus.size() > 0 && !((CascadingMenuPopup.CascadingMenuInfo)CascadingMenuPopup.this.mShowingMenus.get(0)).window.isModal()) {
          View view = CascadingMenuPopup.this.mShownAnchorView;
          if (view == null || !view.isShown()) {
            CascadingMenuPopup.this.dismiss();
            return;
          } 
          Iterator<CascadingMenuPopup.CascadingMenuInfo> iterator = CascadingMenuPopup.this.mShowingMenus.iterator();
          while (iterator.hasNext())
            ((CascadingMenuPopup.CascadingMenuInfo)iterator.next()).window.show(); 
        } 
      }
    };
  
  private boolean mHasXOffset;
  
  private boolean mHasYOffset;
  
  private int mLastPosition;
  
  private final MenuItemHoverListener mMenuItemHoverListener = new MenuItemHoverListener() {
      public void onItemHoverEnter(@NonNull MenuBuilder param1MenuBuilder, @NonNull MenuItem param1MenuItem) {
        // Byte code:
        //   0: aload_0
        //   1: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   4: getfield mSubMenuHoverHandler : Landroid/os/Handler;
        //   7: astore #8
        //   9: aconst_null
        //   10: astore #7
        //   12: aload #8
        //   14: aconst_null
        //   15: invokevirtual removeCallbacksAndMessages : (Ljava/lang/Object;)V
        //   18: aload_0
        //   19: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   22: getfield mShowingMenus : Ljava/util/List;
        //   25: invokeinterface size : ()I
        //   30: istore #4
        //   32: iconst_0
        //   33: istore_3
        //   34: iload_3
        //   35: iload #4
        //   37: if_icmpge -> 73
        //   40: aload_1
        //   41: aload_0
        //   42: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   45: getfield mShowingMenus : Ljava/util/List;
        //   48: iload_3
        //   49: invokeinterface get : (I)Ljava/lang/Object;
        //   54: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
        //   57: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
        //   60: if_acmpne -> 66
        //   63: goto -> 75
        //   66: iload_3
        //   67: iconst_1
        //   68: iadd
        //   69: istore_3
        //   70: goto -> 34
        //   73: iconst_m1
        //   74: istore_3
        //   75: iload_3
        //   76: iconst_m1
        //   77: if_icmpne -> 81
        //   80: return
        //   81: iload_3
        //   82: iconst_1
        //   83: iadd
        //   84: istore_3
        //   85: iload_3
        //   86: aload_0
        //   87: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   90: getfield mShowingMenus : Ljava/util/List;
        //   93: invokeinterface size : ()I
        //   98: if_icmpge -> 119
        //   101: aload_0
        //   102: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   105: getfield mShowingMenus : Ljava/util/List;
        //   108: iload_3
        //   109: invokeinterface get : (I)Ljava/lang/Object;
        //   114: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
        //   117: astore #7
        //   119: new android/support/v7/view/menu/CascadingMenuPopup$2$1
        //   122: dup
        //   123: aload_0
        //   124: aload #7
        //   126: aload_2
        //   127: aload_1
        //   128: invokespecial <init> : (Landroid/support/v7/view/menu/CascadingMenuPopup$2;Landroid/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo;Landroid/view/MenuItem;Landroid/support/v7/view/menu/MenuBuilder;)V
        //   131: astore_2
        //   132: invokestatic uptimeMillis : ()J
        //   135: lstore #5
        //   137: aload_0
        //   138: getfield this$0 : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   141: getfield mSubMenuHoverHandler : Landroid/os/Handler;
        //   144: aload_2
        //   145: aload_1
        //   146: lload #5
        //   148: ldc2_w 200
        //   151: ladd
        //   152: invokevirtual postAtTime : (Ljava/lang/Runnable;Ljava/lang/Object;J)Z
        //   155: pop
        //   156: return
      }
      
      public void onItemHoverExit(@NonNull MenuBuilder param1MenuBuilder, @NonNull MenuItem param1MenuItem) {
        CascadingMenuPopup.this.mSubMenuHoverHandler.removeCallbacksAndMessages(param1MenuBuilder);
      }
    };
  
  private final int mMenuMaxWidth;
  
  private PopupWindow.OnDismissListener mOnDismissListener;
  
  private final boolean mOverflowOnly;
  
  private final List<MenuBuilder> mPendingMenus = new LinkedList<MenuBuilder>();
  
  private final int mPopupStyleAttr;
  
  private final int mPopupStyleRes;
  
  private MenuPresenter.Callback mPresenterCallback;
  
  private int mRawDropDownGravity = 0;
  
  boolean mShouldCloseImmediately;
  
  private boolean mShowTitle;
  
  final List<CascadingMenuInfo> mShowingMenus = new ArrayList<CascadingMenuInfo>();
  
  View mShownAnchorView;
  
  final Handler mSubMenuHoverHandler;
  
  private ViewTreeObserver mTreeObserver;
  
  private int mXOffset;
  
  private int mYOffset;
  
  public CascadingMenuPopup(@NonNull Context paramContext, @NonNull View paramView, @AttrRes int paramInt1, @StyleRes int paramInt2, boolean paramBoolean) {
    this.mContext = paramContext;
    this.mAnchorView = paramView;
    this.mPopupStyleAttr = paramInt1;
    this.mPopupStyleRes = paramInt2;
    this.mOverflowOnly = paramBoolean;
    this.mForceShowIcon = false;
    this.mLastPosition = getInitialMenuPosition();
    Resources resources = paramContext.getResources();
    this.mMenuMaxWidth = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    this.mSubMenuHoverHandler = new Handler();
  }
  
  private MenuPopupWindow createPopupWindow() {
    MenuPopupWindow menuPopupWindow = new MenuPopupWindow(this.mContext, null, this.mPopupStyleAttr, this.mPopupStyleRes);
    menuPopupWindow.setHoverListener(this.mMenuItemHoverListener);
    menuPopupWindow.setOnItemClickListener(this);
    menuPopupWindow.setOnDismissListener(this);
    menuPopupWindow.setAnchorView(this.mAnchorView);
    menuPopupWindow.setDropDownGravity(this.mDropDownGravity);
    menuPopupWindow.setModal(true);
    return menuPopupWindow;
  }
  
  private int findIndexOfAddedMenu(@NonNull MenuBuilder paramMenuBuilder) {
    int j = this.mShowingMenus.size();
    for (int i = 0; i < j; i++) {
      if (paramMenuBuilder == ((CascadingMenuInfo)this.mShowingMenus.get(i)).menu)
        return i; 
    } 
    return -1;
  }
  
  private MenuItem findMenuItemForSubmenu(@NonNull MenuBuilder paramMenuBuilder1, @NonNull MenuBuilder paramMenuBuilder2) {
    int j = paramMenuBuilder1.size();
    for (int i = 0; i < j; i++) {
      MenuItem menuItem = paramMenuBuilder1.getItem(i);
      if (menuItem.hasSubMenu() && paramMenuBuilder2 == menuItem.getSubMenu())
        return menuItem; 
    } 
    return null;
  }
  
  @Nullable
  private View findParentViewForSubmenu(@NonNull CascadingMenuInfo paramCascadingMenuInfo, @NonNull MenuBuilder paramMenuBuilder) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
    //   5: aload_2
    //   6: invokespecial findMenuItemForSubmenu : (Landroid/support/v7/view/menu/MenuBuilder;Landroid/support/v7/view/menu/MenuBuilder;)Landroid/view/MenuItem;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnonnull -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: aload_1
    //   17: invokevirtual getListView : ()Landroid/widget/ListView;
    //   20: astore #7
    //   22: aload #7
    //   24: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
    //   27: astore_1
    //   28: aload_1
    //   29: instanceof android/widget/HeaderViewListAdapter
    //   32: istore #6
    //   34: iconst_0
    //   35: istore_3
    //   36: iload #6
    //   38: ifeq -> 63
    //   41: aload_1
    //   42: checkcast android/widget/HeaderViewListAdapter
    //   45: astore_1
    //   46: aload_1
    //   47: invokevirtual getHeadersCount : ()I
    //   50: istore #4
    //   52: aload_1
    //   53: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
    //   56: checkcast android/support/v7/view/menu/MenuAdapter
    //   59: astore_1
    //   60: goto -> 71
    //   63: aload_1
    //   64: checkcast android/support/v7/view/menu/MenuAdapter
    //   67: astore_1
    //   68: iconst_0
    //   69: istore #4
    //   71: aload_1
    //   72: invokevirtual getCount : ()I
    //   75: istore #5
    //   77: iload_3
    //   78: iload #5
    //   80: if_icmpge -> 102
    //   83: aload_2
    //   84: aload_1
    //   85: iload_3
    //   86: invokevirtual getItem : (I)Landroid/support/v7/view/menu/MenuItemImpl;
    //   89: if_acmpne -> 95
    //   92: goto -> 104
    //   95: iload_3
    //   96: iconst_1
    //   97: iadd
    //   98: istore_3
    //   99: goto -> 77
    //   102: iconst_m1
    //   103: istore_3
    //   104: iload_3
    //   105: iconst_m1
    //   106: if_icmpne -> 111
    //   109: aconst_null
    //   110: areturn
    //   111: iload_3
    //   112: iload #4
    //   114: iadd
    //   115: aload #7
    //   117: invokevirtual getFirstVisiblePosition : ()I
    //   120: isub
    //   121: istore_3
    //   122: iload_3
    //   123: iflt -> 144
    //   126: iload_3
    //   127: aload #7
    //   129: invokevirtual getChildCount : ()I
    //   132: if_icmplt -> 137
    //   135: aconst_null
    //   136: areturn
    //   137: aload #7
    //   139: iload_3
    //   140: invokevirtual getChildAt : (I)Landroid/view/View;
    //   143: areturn
    //   144: aconst_null
    //   145: areturn
  }
  
  private int getInitialMenuPosition() {
    int i = ViewCompat.getLayoutDirection(this.mAnchorView);
    boolean bool = true;
    if (i == 1)
      bool = false; 
    return bool;
  }
  
  private int getNextMenuPosition(int paramInt) {
    List<CascadingMenuInfo> list = this.mShowingMenus;
    ListView listView = ((CascadingMenuInfo)list.get(list.size() - 1)).getListView();
    int[] arrayOfInt = new int[2];
    listView.getLocationOnScreen(arrayOfInt);
    Rect rect = new Rect();
    this.mShownAnchorView.getWindowVisibleDisplayFrame(rect);
    return (this.mLastPosition == 1) ? ((arrayOfInt[0] + listView.getWidth() + paramInt > rect.right) ? 0 : 1) : ((arrayOfInt[0] - paramInt < 0) ? 1 : 0);
  }
  
  private void showMenu(@NonNull MenuBuilder paramMenuBuilder) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mContext : Landroid/content/Context;
    //   4: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   7: astore #10
    //   9: new android/support/v7/view/menu/MenuAdapter
    //   12: dup
    //   13: aload_1
    //   14: aload #10
    //   16: aload_0
    //   17: getfield mOverflowOnly : Z
    //   20: invokespecial <init> : (Landroid/support/v7/view/menu/MenuBuilder;Landroid/view/LayoutInflater;Z)V
    //   23: astore #7
    //   25: aload_0
    //   26: invokevirtual isShowing : ()Z
    //   29: ifne -> 48
    //   32: aload_0
    //   33: getfield mForceShowIcon : Z
    //   36: ifeq -> 48
    //   39: aload #7
    //   41: iconst_1
    //   42: invokevirtual setForceShowIcon : (Z)V
    //   45: goto -> 64
    //   48: aload_0
    //   49: invokevirtual isShowing : ()Z
    //   52: ifeq -> 64
    //   55: aload #7
    //   57: aload_1
    //   58: invokestatic shouldPreserveIconSpacing : (Landroid/support/v7/view/menu/MenuBuilder;)Z
    //   61: invokevirtual setForceShowIcon : (Z)V
    //   64: aload #7
    //   66: aconst_null
    //   67: aload_0
    //   68: getfield mContext : Landroid/content/Context;
    //   71: aload_0
    //   72: getfield mMenuMaxWidth : I
    //   75: invokestatic measureIndividualMenuWidth : (Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I
    //   78: istore_2
    //   79: aload_0
    //   80: invokespecial createPopupWindow : ()Landroid/support/v7/widget/MenuPopupWindow;
    //   83: astore #9
    //   85: aload #9
    //   87: aload #7
    //   89: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   92: aload #9
    //   94: iload_2
    //   95: invokevirtual setContentWidth : (I)V
    //   98: aload #9
    //   100: aload_0
    //   101: getfield mDropDownGravity : I
    //   104: invokevirtual setDropDownGravity : (I)V
    //   107: aload_0
    //   108: getfield mShowingMenus : Ljava/util/List;
    //   111: invokeinterface size : ()I
    //   116: ifle -> 158
    //   119: aload_0
    //   120: getfield mShowingMenus : Ljava/util/List;
    //   123: astore #7
    //   125: aload #7
    //   127: aload #7
    //   129: invokeinterface size : ()I
    //   134: iconst_1
    //   135: isub
    //   136: invokeinterface get : (I)Ljava/lang/Object;
    //   141: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
    //   144: astore #7
    //   146: aload_0
    //   147: aload #7
    //   149: aload_1
    //   150: invokespecial findParentViewForSubmenu : (Landroid/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo;Landroid/support/v7/view/menu/MenuBuilder;)Landroid/view/View;
    //   153: astore #8
    //   155: goto -> 165
    //   158: aconst_null
    //   159: astore #7
    //   161: aload #7
    //   163: astore #8
    //   165: aload #8
    //   167: ifnull -> 319
    //   170: aload #9
    //   172: iconst_0
    //   173: invokevirtual setTouchModal : (Z)V
    //   176: aload #9
    //   178: aconst_null
    //   179: invokevirtual setEnterTransition : (Ljava/lang/Object;)V
    //   182: aload_0
    //   183: iload_2
    //   184: invokespecial getNextMenuPosition : (I)I
    //   187: istore #4
    //   189: iload #4
    //   191: iconst_1
    //   192: if_icmpne -> 200
    //   195: iconst_1
    //   196: istore_3
    //   197: goto -> 202
    //   200: iconst_0
    //   201: istore_3
    //   202: aload_0
    //   203: iload #4
    //   205: putfield mLastPosition : I
    //   208: iconst_2
    //   209: newarray int
    //   211: astore #11
    //   213: aload #8
    //   215: aload #11
    //   217: invokevirtual getLocationInWindow : ([I)V
    //   220: aload #7
    //   222: getfield window : Landroid/support/v7/widget/MenuPopupWindow;
    //   225: invokevirtual getHorizontalOffset : ()I
    //   228: aload #11
    //   230: iconst_0
    //   231: iaload
    //   232: iadd
    //   233: istore #6
    //   235: aload #7
    //   237: getfield window : Landroid/support/v7/widget/MenuPopupWindow;
    //   240: invokevirtual getVerticalOffset : ()I
    //   243: istore #4
    //   245: aload #11
    //   247: iconst_1
    //   248: iaload
    //   249: istore #5
    //   251: aload_0
    //   252: getfield mDropDownGravity : I
    //   255: iconst_5
    //   256: iand
    //   257: iconst_5
    //   258: if_icmpne -> 277
    //   261: iload_3
    //   262: ifeq -> 268
    //   265: goto -> 287
    //   268: aload #8
    //   270: invokevirtual getWidth : ()I
    //   273: istore_2
    //   274: goto -> 295
    //   277: iload_3
    //   278: ifeq -> 295
    //   281: aload #8
    //   283: invokevirtual getWidth : ()I
    //   286: istore_2
    //   287: iload #6
    //   289: iload_2
    //   290: iadd
    //   291: istore_2
    //   292: goto -> 300
    //   295: iload #6
    //   297: iload_2
    //   298: isub
    //   299: istore_2
    //   300: aload #9
    //   302: iload_2
    //   303: invokevirtual setHorizontalOffset : (I)V
    //   306: aload #9
    //   308: iload #4
    //   310: iload #5
    //   312: iadd
    //   313: invokevirtual setVerticalOffset : (I)V
    //   316: goto -> 360
    //   319: aload_0
    //   320: getfield mHasXOffset : Z
    //   323: ifeq -> 335
    //   326: aload #9
    //   328: aload_0
    //   329: getfield mXOffset : I
    //   332: invokevirtual setHorizontalOffset : (I)V
    //   335: aload_0
    //   336: getfield mHasYOffset : Z
    //   339: ifeq -> 351
    //   342: aload #9
    //   344: aload_0
    //   345: getfield mYOffset : I
    //   348: invokevirtual setVerticalOffset : (I)V
    //   351: aload #9
    //   353: aload_0
    //   354: invokevirtual getEpicenterBounds : ()Landroid/graphics/Rect;
    //   357: invokevirtual setEpicenterBounds : (Landroid/graphics/Rect;)V
    //   360: new android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
    //   363: dup
    //   364: aload #9
    //   366: aload_1
    //   367: aload_0
    //   368: getfield mLastPosition : I
    //   371: invokespecial <init> : (Landroid/support/v7/widget/MenuPopupWindow;Landroid/support/v7/view/menu/MenuBuilder;I)V
    //   374: astore #8
    //   376: aload_0
    //   377: getfield mShowingMenus : Ljava/util/List;
    //   380: aload #8
    //   382: invokeinterface add : (Ljava/lang/Object;)Z
    //   387: pop
    //   388: aload #9
    //   390: invokevirtual show : ()V
    //   393: aload #7
    //   395: ifnonnull -> 477
    //   398: aload_0
    //   399: getfield mShowTitle : Z
    //   402: ifeq -> 477
    //   405: aload_1
    //   406: invokevirtual getHeaderTitle : ()Ljava/lang/CharSequence;
    //   409: ifnull -> 477
    //   412: aload #9
    //   414: invokevirtual getListView : ()Landroid/widget/ListView;
    //   417: astore #7
    //   419: aload #10
    //   421: getstatic android/support/v7/appcompat/R$layout.abc_popup_menu_header_item_layout : I
    //   424: aload #7
    //   426: iconst_0
    //   427: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   430: checkcast android/widget/FrameLayout
    //   433: astore #8
    //   435: aload #8
    //   437: ldc_w 16908310
    //   440: invokevirtual findViewById : (I)Landroid/view/View;
    //   443: checkcast android/widget/TextView
    //   446: astore #10
    //   448: aload #8
    //   450: iconst_0
    //   451: invokevirtual setEnabled : (Z)V
    //   454: aload #10
    //   456: aload_1
    //   457: invokevirtual getHeaderTitle : ()Ljava/lang/CharSequence;
    //   460: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   463: aload #7
    //   465: aload #8
    //   467: aconst_null
    //   468: iconst_0
    //   469: invokevirtual addHeaderView : (Landroid/view/View;Ljava/lang/Object;Z)V
    //   472: aload #9
    //   474: invokevirtual show : ()V
    //   477: return
  }
  
  public void addMenu(MenuBuilder paramMenuBuilder) {
    paramMenuBuilder.addMenuPresenter(this, this.mContext);
    if (isShowing()) {
      showMenu(paramMenuBuilder);
      return;
    } 
    this.mPendingMenus.add(paramMenuBuilder);
  }
  
  protected boolean closeMenuOnSubMenuOpened() {
    return false;
  }
  
  public void dismiss() {
    int i = this.mShowingMenus.size();
    if (i > 0) {
      CascadingMenuInfo[] arrayOfCascadingMenuInfo = this.mShowingMenus.<CascadingMenuInfo>toArray(new CascadingMenuInfo[i]);
      while (--i >= 0) {
        CascadingMenuInfo cascadingMenuInfo = arrayOfCascadingMenuInfo[i];
        if (cascadingMenuInfo.window.isShowing())
          cascadingMenuInfo.window.dismiss(); 
        i--;
      } 
    } 
  }
  
  public boolean flagActionItems() {
    return false;
  }
  
  public ListView getListView() {
    if (this.mShowingMenus.isEmpty())
      return null; 
    List<CascadingMenuInfo> list = this.mShowingMenus;
    return ((CascadingMenuInfo)list.get(list.size() - 1)).getListView();
  }
  
  public boolean isShowing() {
    int i = this.mShowingMenus.size();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (((CascadingMenuInfo)this.mShowingMenus.get(0)).window.isShowing())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    int i = findIndexOfAddedMenu(paramMenuBuilder);
    if (i < 0)
      return; 
    int j = i + 1;
    if (j < this.mShowingMenus.size())
      ((CascadingMenuInfo)this.mShowingMenus.get(j)).menu.close(false); 
    CascadingMenuInfo cascadingMenuInfo = this.mShowingMenus.remove(i);
    cascadingMenuInfo.menu.removeMenuPresenter(this);
    if (this.mShouldCloseImmediately) {
      cascadingMenuInfo.window.setExitTransition(null);
      cascadingMenuInfo.window.setAnimationStyle(0);
    } 
    cascadingMenuInfo.window.dismiss();
    i = this.mShowingMenus.size();
    if (i > 0) {
      this.mLastPosition = ((CascadingMenuInfo)this.mShowingMenus.get(i - 1)).position;
    } else {
      this.mLastPosition = getInitialMenuPosition();
    } 
    if (i == 0) {
      dismiss();
      MenuPresenter.Callback callback = this.mPresenterCallback;
      if (callback != null)
        callback.onCloseMenu(paramMenuBuilder, true); 
      ViewTreeObserver viewTreeObserver = this.mTreeObserver;
      if (viewTreeObserver != null) {
        if (viewTreeObserver.isAlive())
          this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener); 
        this.mTreeObserver = null;
      } 
      this.mOnDismissListener.onDismiss();
      return;
    } 
    if (paramBoolean)
      ((CascadingMenuInfo)this.mShowingMenus.get(0)).menu.close(false); 
  }
  
  public void onDismiss() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mShowingMenus : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_1
    //   12: iload_1
    //   13: iload_2
    //   14: if_icmpge -> 51
    //   17: aload_0
    //   18: getfield mShowingMenus : Ljava/util/List;
    //   21: iload_1
    //   22: invokeinterface get : (I)Ljava/lang/Object;
    //   27: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
    //   30: astore_3
    //   31: aload_3
    //   32: getfield window : Landroid/support/v7/widget/MenuPopupWindow;
    //   35: invokevirtual isShowing : ()Z
    //   38: ifne -> 44
    //   41: goto -> 53
    //   44: iload_1
    //   45: iconst_1
    //   46: iadd
    //   47: istore_1
    //   48: goto -> 12
    //   51: aconst_null
    //   52: astore_3
    //   53: aload_3
    //   54: ifnull -> 65
    //   57: aload_3
    //   58: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
    //   61: iconst_0
    //   62: invokevirtual close : (Z)V
    //   65: return
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {}
  
  public Parcelable onSaveInstanceState() {
    return null;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    for (CascadingMenuInfo cascadingMenuInfo : this.mShowingMenus) {
      if (paramSubMenuBuilder == cascadingMenuInfo.menu) {
        cascadingMenuInfo.getListView().requestFocus();
        return true;
      } 
    } 
    if (paramSubMenuBuilder.hasVisibleItems()) {
      addMenu(paramSubMenuBuilder);
      MenuPresenter.Callback callback = this.mPresenterCallback;
      if (callback != null)
        callback.onOpenSubMenu(paramSubMenuBuilder); 
      return true;
    } 
    return false;
  }
  
  public void setAnchorView(@NonNull View paramView) {
    if (this.mAnchorView != paramView) {
      this.mAnchorView = paramView;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(this.mRawDropDownGravity, ViewCompat.getLayoutDirection(this.mAnchorView));
    } 
  }
  
  public void setCallback(MenuPresenter.Callback paramCallback) {
    this.mPresenterCallback = paramCallback;
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.mForceShowIcon = paramBoolean;
  }
  
  public void setGravity(int paramInt) {
    if (this.mRawDropDownGravity != paramInt) {
      this.mRawDropDownGravity = paramInt;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(this.mAnchorView));
    } 
  }
  
  public void setHorizontalOffset(int paramInt) {
    this.mHasXOffset = true;
    this.mXOffset = paramInt;
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.mOnDismissListener = paramOnDismissListener;
  }
  
  public void setShowTitle(boolean paramBoolean) {
    this.mShowTitle = paramBoolean;
  }
  
  public void setVerticalOffset(int paramInt) {
    this.mHasYOffset = true;
    this.mYOffset = paramInt;
  }
  
  public void show() {
    if (isShowing())
      return; 
    Iterator<MenuBuilder> iterator = this.mPendingMenus.iterator();
    while (iterator.hasNext())
      showMenu(iterator.next()); 
    this.mPendingMenus.clear();
    this.mShownAnchorView = this.mAnchorView;
    if (this.mShownAnchorView != null) {
      boolean bool;
      if (this.mTreeObserver == null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mTreeObserver = this.mShownAnchorView.getViewTreeObserver();
      if (bool)
        this.mTreeObserver.addOnGlobalLayoutListener(this.mGlobalLayoutListener); 
    } 
  }
  
  public void updateMenuView(boolean paramBoolean) {
    Iterator<CascadingMenuInfo> iterator = this.mShowingMenus.iterator();
    while (iterator.hasNext())
      toMenuAdapter(((CascadingMenuInfo)iterator.next()).getListView().getAdapter()).notifyDataSetChanged(); 
  }
  
  private static class CascadingMenuInfo {
    public final MenuBuilder menu;
    
    public final int position;
    
    public final MenuPopupWindow window;
    
    public CascadingMenuInfo(@NonNull MenuPopupWindow param1MenuPopupWindow, @NonNull MenuBuilder param1MenuBuilder, int param1Int) {
      this.window = param1MenuPopupWindow;
      this.menu = param1MenuBuilder;
      this.position = param1Int;
    }
    
    public ListView getListView() {
      return this.window.getListView();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface HorizPosition {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\view\menu\CascadingMenuPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */