package android.support.v7.transition;

import android.support.annotation.RestrictTo;
import android.view.ViewGroup;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ActionBarTransition {
  private static final boolean TRANSITIONS_ENABLED = false;
  
  private static final int TRANSITION_DURATION = 120;
  
  public static void beginDelayedTransition(ViewGroup paramViewGroup) {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v7\transition\ActionBarTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */