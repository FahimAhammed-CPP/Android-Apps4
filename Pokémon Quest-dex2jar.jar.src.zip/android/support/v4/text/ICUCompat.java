package android.support.v4.text;

import android.os.Build;

public class ICUCompat {
  private static final ICUCompatImpl IMPL = new ICUCompatImplBase();
  
  public static String addLikelySubtags(String paramString) {
    return IMPL.addLikelySubtags(paramString);
  }
  
  public static String getScript(String paramString) {
    return IMPL.getScript(paramString);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new ICUCompatImplIcs();
      return;
    } 
  }
  
  static interface ICUCompatImpl {
    String addLikelySubtags(String param1String);
    
    String getScript(String param1String);
  }
  
  static class ICUCompatImplBase implements ICUCompatImpl {
    public String addLikelySubtags(String param1String) {
      return param1String;
    }
    
    public String getScript(String param1String) {
      return null;
    }
  }
  
  static class ICUCompatImplIcs implements ICUCompatImpl {
    public String addLikelySubtags(String param1String) {
      return ICUCompatIcs.addLikelySubtags(param1String);
    }
    
    public String getScript(String param1String) {
      return ICUCompatIcs.getScript(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\text\ICUCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */