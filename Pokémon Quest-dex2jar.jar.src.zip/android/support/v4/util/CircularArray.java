package android.support.v4.util;

public class CircularArray<E> {
  private int mCapacityBitmask;
  
  private E[] mElements;
  
  private int mHead;
  
  private int mTail;
  
  public CircularArray() {
    this(8);
  }
  
  public CircularArray(int paramInt) {
    if (paramInt > 0) {
      int i = paramInt;
      if (Integer.bitCount(paramInt) != 1)
        i = 1 << Integer.highestOneBit(paramInt) + 1; 
      this.mCapacityBitmask = i - 1;
      this.mElements = (E[])new Object[i];
      return;
    } 
    throw new IllegalArgumentException("capacity must be positive");
  }
  
  private void doubleCapacity() {
    E[] arrayOfE = this.mElements;
    int i = arrayOfE.length;
    int j = this.mHead;
    int k = i - j;
    int m = i << 1;
    if (m >= 0) {
      Object[] arrayOfObject = new Object[m];
      System.arraycopy(arrayOfE, j, arrayOfObject, 0, k);
      System.arraycopy(this.mElements, 0, arrayOfObject, k, this.mHead);
      this.mElements = (E[])arrayOfObject;
      this.mHead = 0;
      this.mTail = i;
      this.mCapacityBitmask = m - 1;
      return;
    } 
    throw new RuntimeException("Too big");
  }
  
  public final void addFirst(E paramE) {
    this.mHead = this.mHead - 1 & this.mCapacityBitmask;
    E[] arrayOfE = this.mElements;
    int i = this.mHead;
    arrayOfE[i] = paramE;
    if (i == this.mTail)
      doubleCapacity(); 
  }
  
  public final void addLast(E paramE) {
    E[] arrayOfE = this.mElements;
    int i = this.mTail;
    arrayOfE[i] = paramE;
    this.mTail = this.mCapacityBitmask & i + 1;
    if (this.mTail == this.mHead)
      doubleCapacity(); 
  }
  
  public final E get(int paramInt) {
    if (paramInt >= 0 && paramInt < size()) {
      int i = this.mHead;
      int j = this.mCapacityBitmask;
      return this.mElements[j & i + paramInt];
    } 
    throw new ArrayIndexOutOfBoundsException();
  }
  
  public final E getFirst() {
    int i = this.mHead;
    if (i != this.mTail)
      return this.mElements[i]; 
    throw new ArrayIndexOutOfBoundsException();
  }
  
  public final E getLast() {
    int i = this.mHead;
    int j = this.mTail;
    if (i != j)
      return this.mElements[j - 1 & this.mCapacityBitmask]; 
    throw new ArrayIndexOutOfBoundsException();
  }
  
  public final boolean isEmpty() {
    return (this.mHead == this.mTail);
  }
  
  public final E popFirst() {
    int i = this.mHead;
    if (i != this.mTail) {
      E[] arrayOfE = this.mElements;
      E e = arrayOfE[i];
      arrayOfE[i] = null;
      this.mHead = i + 1 & this.mCapacityBitmask;
      return e;
    } 
    throw new ArrayIndexOutOfBoundsException();
  }
  
  public final E popLast() {
    int i = this.mHead;
    int j = this.mTail;
    if (i != j) {
      i = this.mCapacityBitmask & j - 1;
      E[] arrayOfE = this.mElements;
      E e = arrayOfE[i];
      arrayOfE[i] = null;
      this.mTail = i;
      return e;
    } 
    throw new ArrayIndexOutOfBoundsException();
  }
  
  public final int size() {
    return this.mTail - this.mHead & this.mCapacityBitmask;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v\\util\CircularArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */