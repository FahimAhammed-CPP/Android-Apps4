package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;
import android.os.Build;

public class DrawableCompat {
  static final DrawableImpl IMPL = new BaseDrawableImpl();
  
  public static boolean isAutoMirrored(Drawable paramDrawable) {
    return IMPL.isAutoMirrored(paramDrawable);
  }
  
  public static void jumpToCurrentState(Drawable paramDrawable) {
    IMPL.jumpToCurrentState(paramDrawable);
  }
  
  public static void setAutoMirrored(Drawable paramDrawable, boolean paramBoolean) {
    IMPL.setAutoMirrored(paramDrawable, paramBoolean);
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      IMPL = new KitKatDrawableImpl();
      return;
    } 
    if (i >= 11) {
      IMPL = new HoneycombDrawableImpl();
      return;
    } 
  }
  
  static class BaseDrawableImpl implements DrawableImpl {
    public boolean isAutoMirrored(Drawable param1Drawable) {
      return false;
    }
    
    public void jumpToCurrentState(Drawable param1Drawable) {}
    
    public void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean) {}
  }
  
  static interface DrawableImpl {
    boolean isAutoMirrored(Drawable param1Drawable);
    
    void jumpToCurrentState(Drawable param1Drawable);
    
    void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean);
  }
  
  static class HoneycombDrawableImpl extends BaseDrawableImpl {
    public void jumpToCurrentState(Drawable param1Drawable) {
      DrawableCompatHoneycomb.jumpToCurrentState(param1Drawable);
    }
  }
  
  static class KitKatDrawableImpl extends HoneycombDrawableImpl {
    public boolean isAutoMirrored(Drawable param1Drawable) {
      return DrawableCompatKitKat.isAutoMirrored(param1Drawable);
    }
    
    public void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean) {
      DrawableCompatKitKat.setAutoMirrored(param1Drawable, param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\graphics\drawable\DrawableCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */