package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

final class FragmentManagerImpl extends FragmentManager {
  static final Interpolator ACCELERATE_CUBIC;
  
  static final Interpolator ACCELERATE_QUINT;
  
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT;
  
  static final boolean HONEYCOMB;
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  ArrayList<Fragment> mActive;
  
  FragmentActivity mActivity;
  
  ArrayList<Fragment> mAdded;
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<Integer> mAvailIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  boolean mNeedMenuInvalidate;
  
  String mNoTransactionsBecause;
  
  Fragment mParent;
  
  ArrayList<Runnable> mPendingActions;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  Runnable[] mTmpActions;
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 11) {
      bool = true;
    } else {
      bool = false;
    } 
    HONEYCOMB = bool;
    DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = (Interpolator)new AccelerateInterpolator(2.5F);
    ACCELERATE_CUBIC = (Interpolator)new AccelerateInterpolator(1.5F);
  }
  
  private void checkStateLoss() {
    if (!this.mStateSaved) {
      if (this.mNoTransactionsBecause == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.mNoTransactionsBecause);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  static Animation makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return (Animation)alphaAnimation;
  }
  
  static Animation makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return (Animation)animationSet;
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentActivity fragmentActivity = this.mActivity;
    if (fragmentActivity != null) {
      try {
        fragmentActivity.dump("  ", (FileDescriptor)null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
    reportBackStackChanged();
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (this.mAdded == null)
      this.mAdded = new ArrayList<Fragment>(); 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    makeActive(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.mAdded.contains(paramFragment)) {
        this.mAdded.add(paramFragment);
        paramFragment.mAdded = true;
        paramFragment.mRemoving = false;
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        if (paramBoolean) {
          moveToState(paramFragment);
          return;
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 111
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 22
    //   19: goto -> 111
    //   22: aload_0
    //   23: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   26: aload_0
    //   27: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: iconst_1
    //   34: isub
    //   35: invokevirtual remove : (I)Ljava/lang/Object;
    //   38: checkcast java/lang/Integer
    //   41: invokevirtual intValue : ()I
    //   44: istore_2
    //   45: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   48: ifeq -> 97
    //   51: new java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial <init> : ()V
    //   58: astore_3
    //   59: aload_3
    //   60: ldc_w 'Adding back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload_3
    //   68: iload_2
    //   69: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload_3
    //   74: ldc_w ' with '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_3
    //   82: aload_1
    //   83: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: ldc 'FragmentManager'
    //   89: aload_3
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   96: pop
    //   97: aload_0
    //   98: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   101: iload_2
    //   102: aload_1
    //   103: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: aload_0
    //   108: monitorexit
    //   109: iload_2
    //   110: ireturn
    //   111: aload_0
    //   112: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   115: ifnonnull -> 129
    //   118: aload_0
    //   119: new java/util/ArrayList
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   129: aload_0
    //   130: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   133: invokevirtual size : ()I
    //   136: istore_2
    //   137: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   140: ifeq -> 189
    //   143: new java/lang/StringBuilder
    //   146: dup
    //   147: invokespecial <init> : ()V
    //   150: astore_3
    //   151: aload_3
    //   152: ldc_w 'Setting back stack index '
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload_3
    //   160: iload_2
    //   161: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload_3
    //   166: ldc_w ' to '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_3
    //   174: aload_1
    //   175: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: ldc 'FragmentManager'
    //   181: aload_3
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   188: pop
    //   189: aload_0
    //   190: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   193: aload_1
    //   194: invokevirtual add : (Ljava/lang/Object;)Z
    //   197: pop
    //   198: aload_0
    //   199: monitorexit
    //   200: iload_2
    //   201: ireturn
    //   202: astore_1
    //   203: aload_0
    //   204: monitorexit
    //   205: aload_1
    //   206: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	202	finally
    //   22	97	202	finally
    //   97	109	202	finally
    //   111	129	202	finally
    //   129	189	202	finally
    //   189	200	202	finally
    //   203	205	202	finally
  }
  
  public void attachActivity(FragmentActivity paramFragmentActivity, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mActivity == null) {
      this.mActivity = paramFragmentActivity;
      this.mContainer = paramFragmentContainer;
      this.mParent = paramFragment;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        if (this.mAdded == null)
          this.mAdded = new ArrayList<Fragment>(); 
        if (!this.mAdded.contains(paramFragment)) {
          if (DEBUG) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("add from attach: ");
            stringBuilder1.append(paramFragment);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          moveToState(paramFragment, this.mCurState, paramInt1, paramInt2, false);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  public void detachFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (this.mAdded != null) {
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("remove from detach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.mAdded.remove(paramFragment);
        } 
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        moveToState(paramFragment, 1, paramInt1, paramInt2, false);
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    moveToState(2, false);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    if (this.mAdded != null)
      for (int i = 0; i < this.mAdded.size(); i++) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null)
          fragment.performConfigurationChanged(paramConfiguration); 
      }  
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mAdded != null)
      for (int i = 0; i < this.mAdded.size(); i++) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
          return true; 
      }  
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    moveToState(1, false);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool;
    ArrayList<Fragment> arrayList3 = this.mAdded;
    byte b = 0;
    ArrayList<Fragment> arrayList2 = null;
    ArrayList<Fragment> arrayList1 = null;
    if (arrayList3 != null) {
      int i = 0;
      boolean bool1 = false;
      while (true) {
        arrayList2 = arrayList1;
        bool = bool1;
        if (i < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(i);
          arrayList2 = arrayList1;
          bool = bool1;
          if (fragment != null) {
            arrayList2 = arrayList1;
            bool = bool1;
            if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
              arrayList2 = arrayList1;
              if (arrayList1 == null)
                arrayList2 = new ArrayList(); 
              arrayList2.add(fragment);
              bool = true;
            } 
          } 
          i++;
          arrayList1 = arrayList2;
          bool1 = bool;
          continue;
        } 
        break;
      } 
    } else {
      bool = false;
    } 
    if (this.mCreatedMenus != null)
      for (int i = b; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList2 == null || !arrayList2.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList2;
    return bool;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    moveToState(0, false);
    this.mActivity = null;
    this.mContainer = null;
    this.mParent = null;
  }
  
  public void dispatchDestroyView() {
    moveToState(1, false);
  }
  
  public void dispatchLowMemory() {
    if (this.mAdded != null)
      for (int i = 0; i < this.mAdded.size(); i++) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null)
          fragment.performLowMemory(); 
      }  
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mAdded != null)
      for (int i = 0; i < this.mAdded.size(); i++) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
          return true; 
      }  
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mAdded != null)
      for (int i = 0; i < this.mAdded.size(); i++) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null)
          fragment.performOptionsMenuClosed(paramMenu); 
      }  
  }
  
  public void dispatchPause() {
    moveToState(4, false);
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    boolean bool;
    ArrayList<Fragment> arrayList = this.mAdded;
    int i = 0;
    if (arrayList != null) {
      boolean bool1 = false;
      while (true) {
        bool = bool1;
        if (i < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(i);
          bool = bool1;
          if (fragment != null) {
            bool = bool1;
            if (fragment.performPrepareOptionsMenu(paramMenu))
              bool = true; 
          } 
          i++;
          bool1 = bool;
          continue;
        } 
        break;
      } 
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void dispatchReallyStop() {
    moveToState(2, false);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    moveToState(5, false);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    moveToState(4, false);
  }
  
  public void dispatchStop() {
    this.mStateSaved = true;
    moveToState(3, false);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield mActive : Ljava/util/ArrayList;
    //   36: astore #9
    //   38: iconst_0
    //   39: istore #6
    //   41: aload #9
    //   43: ifnull -> 168
    //   46: aload #9
    //   48: invokevirtual size : ()I
    //   51: istore #7
    //   53: iload #7
    //   55: ifle -> 168
    //   58: aload_3
    //   59: aload_1
    //   60: invokevirtual print : (Ljava/lang/String;)V
    //   63: aload_3
    //   64: ldc_w 'Active Fragments in '
    //   67: invokevirtual print : (Ljava/lang/String;)V
    //   70: aload_3
    //   71: aload_0
    //   72: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   75: invokestatic toHexString : (I)Ljava/lang/String;
    //   78: invokevirtual print : (Ljava/lang/String;)V
    //   81: aload_3
    //   82: ldc_w ':'
    //   85: invokevirtual println : (Ljava/lang/String;)V
    //   88: iconst_0
    //   89: istore #5
    //   91: iload #5
    //   93: iload #7
    //   95: if_icmpge -> 168
    //   98: aload_0
    //   99: getfield mActive : Ljava/util/ArrayList;
    //   102: iload #5
    //   104: invokevirtual get : (I)Ljava/lang/Object;
    //   107: checkcast android/support/v4/app/Fragment
    //   110: astore #9
    //   112: aload_3
    //   113: aload_1
    //   114: invokevirtual print : (Ljava/lang/String;)V
    //   117: aload_3
    //   118: ldc_w '  #'
    //   121: invokevirtual print : (Ljava/lang/String;)V
    //   124: aload_3
    //   125: iload #5
    //   127: invokevirtual print : (I)V
    //   130: aload_3
    //   131: ldc_w ': '
    //   134: invokevirtual print : (Ljava/lang/String;)V
    //   137: aload_3
    //   138: aload #9
    //   140: invokevirtual println : (Ljava/lang/Object;)V
    //   143: aload #9
    //   145: ifnull -> 159
    //   148: aload #9
    //   150: aload #8
    //   152: aload_2
    //   153: aload_3
    //   154: aload #4
    //   156: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   159: iload #5
    //   161: iconst_1
    //   162: iadd
    //   163: istore #5
    //   165: goto -> 91
    //   168: aload_0
    //   169: getfield mAdded : Ljava/util/ArrayList;
    //   172: astore #9
    //   174: aload #9
    //   176: ifnull -> 270
    //   179: aload #9
    //   181: invokevirtual size : ()I
    //   184: istore #7
    //   186: iload #7
    //   188: ifle -> 270
    //   191: aload_3
    //   192: aload_1
    //   193: invokevirtual print : (Ljava/lang/String;)V
    //   196: aload_3
    //   197: ldc_w 'Added Fragments:'
    //   200: invokevirtual println : (Ljava/lang/String;)V
    //   203: iconst_0
    //   204: istore #5
    //   206: iload #5
    //   208: iload #7
    //   210: if_icmpge -> 270
    //   213: aload_0
    //   214: getfield mAdded : Ljava/util/ArrayList;
    //   217: iload #5
    //   219: invokevirtual get : (I)Ljava/lang/Object;
    //   222: checkcast android/support/v4/app/Fragment
    //   225: astore #9
    //   227: aload_3
    //   228: aload_1
    //   229: invokevirtual print : (Ljava/lang/String;)V
    //   232: aload_3
    //   233: ldc_w '  #'
    //   236: invokevirtual print : (Ljava/lang/String;)V
    //   239: aload_3
    //   240: iload #5
    //   242: invokevirtual print : (I)V
    //   245: aload_3
    //   246: ldc_w ': '
    //   249: invokevirtual print : (Ljava/lang/String;)V
    //   252: aload_3
    //   253: aload #9
    //   255: invokevirtual toString : ()Ljava/lang/String;
    //   258: invokevirtual println : (Ljava/lang/String;)V
    //   261: iload #5
    //   263: iconst_1
    //   264: iadd
    //   265: istore #5
    //   267: goto -> 206
    //   270: aload_0
    //   271: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   274: astore #9
    //   276: aload #9
    //   278: ifnull -> 372
    //   281: aload #9
    //   283: invokevirtual size : ()I
    //   286: istore #7
    //   288: iload #7
    //   290: ifle -> 372
    //   293: aload_3
    //   294: aload_1
    //   295: invokevirtual print : (Ljava/lang/String;)V
    //   298: aload_3
    //   299: ldc_w 'Fragments Created Menus:'
    //   302: invokevirtual println : (Ljava/lang/String;)V
    //   305: iconst_0
    //   306: istore #5
    //   308: iload #5
    //   310: iload #7
    //   312: if_icmpge -> 372
    //   315: aload_0
    //   316: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   319: iload #5
    //   321: invokevirtual get : (I)Ljava/lang/Object;
    //   324: checkcast android/support/v4/app/Fragment
    //   327: astore #9
    //   329: aload_3
    //   330: aload_1
    //   331: invokevirtual print : (Ljava/lang/String;)V
    //   334: aload_3
    //   335: ldc_w '  #'
    //   338: invokevirtual print : (Ljava/lang/String;)V
    //   341: aload_3
    //   342: iload #5
    //   344: invokevirtual print : (I)V
    //   347: aload_3
    //   348: ldc_w ': '
    //   351: invokevirtual print : (Ljava/lang/String;)V
    //   354: aload_3
    //   355: aload #9
    //   357: invokevirtual toString : ()Ljava/lang/String;
    //   360: invokevirtual println : (Ljava/lang/String;)V
    //   363: iload #5
    //   365: iconst_1
    //   366: iadd
    //   367: istore #5
    //   369: goto -> 308
    //   372: aload_0
    //   373: getfield mBackStack : Ljava/util/ArrayList;
    //   376: astore #9
    //   378: aload #9
    //   380: ifnull -> 485
    //   383: aload #9
    //   385: invokevirtual size : ()I
    //   388: istore #7
    //   390: iload #7
    //   392: ifle -> 485
    //   395: aload_3
    //   396: aload_1
    //   397: invokevirtual print : (Ljava/lang/String;)V
    //   400: aload_3
    //   401: ldc_w 'Back Stack:'
    //   404: invokevirtual println : (Ljava/lang/String;)V
    //   407: iconst_0
    //   408: istore #5
    //   410: iload #5
    //   412: iload #7
    //   414: if_icmpge -> 485
    //   417: aload_0
    //   418: getfield mBackStack : Ljava/util/ArrayList;
    //   421: iload #5
    //   423: invokevirtual get : (I)Ljava/lang/Object;
    //   426: checkcast android/support/v4/app/BackStackRecord
    //   429: astore #9
    //   431: aload_3
    //   432: aload_1
    //   433: invokevirtual print : (Ljava/lang/String;)V
    //   436: aload_3
    //   437: ldc_w '  #'
    //   440: invokevirtual print : (Ljava/lang/String;)V
    //   443: aload_3
    //   444: iload #5
    //   446: invokevirtual print : (I)V
    //   449: aload_3
    //   450: ldc_w ': '
    //   453: invokevirtual print : (Ljava/lang/String;)V
    //   456: aload_3
    //   457: aload #9
    //   459: invokevirtual toString : ()Ljava/lang/String;
    //   462: invokevirtual println : (Ljava/lang/String;)V
    //   465: aload #9
    //   467: aload #8
    //   469: aload_2
    //   470: aload_3
    //   471: aload #4
    //   473: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   476: iload #5
    //   478: iconst_1
    //   479: iadd
    //   480: istore #5
    //   482: goto -> 410
    //   485: aload_0
    //   486: monitorenter
    //   487: aload_0
    //   488: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   491: ifnull -> 582
    //   494: aload_0
    //   495: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   498: invokevirtual size : ()I
    //   501: istore #7
    //   503: iload #7
    //   505: ifle -> 582
    //   508: aload_3
    //   509: aload_1
    //   510: invokevirtual print : (Ljava/lang/String;)V
    //   513: aload_3
    //   514: ldc_w 'Back Stack Indices:'
    //   517: invokevirtual println : (Ljava/lang/String;)V
    //   520: iconst_0
    //   521: istore #5
    //   523: iload #5
    //   525: iload #7
    //   527: if_icmpge -> 582
    //   530: aload_0
    //   531: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   534: iload #5
    //   536: invokevirtual get : (I)Ljava/lang/Object;
    //   539: checkcast android/support/v4/app/BackStackRecord
    //   542: astore_2
    //   543: aload_3
    //   544: aload_1
    //   545: invokevirtual print : (Ljava/lang/String;)V
    //   548: aload_3
    //   549: ldc_w '  #'
    //   552: invokevirtual print : (Ljava/lang/String;)V
    //   555: aload_3
    //   556: iload #5
    //   558: invokevirtual print : (I)V
    //   561: aload_3
    //   562: ldc_w ': '
    //   565: invokevirtual print : (Ljava/lang/String;)V
    //   568: aload_3
    //   569: aload_2
    //   570: invokevirtual println : (Ljava/lang/Object;)V
    //   573: iload #5
    //   575: iconst_1
    //   576: iadd
    //   577: istore #5
    //   579: goto -> 523
    //   582: aload_0
    //   583: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   586: ifnull -> 625
    //   589: aload_0
    //   590: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   593: invokevirtual size : ()I
    //   596: ifle -> 625
    //   599: aload_3
    //   600: aload_1
    //   601: invokevirtual print : (Ljava/lang/String;)V
    //   604: aload_3
    //   605: ldc_w 'mAvailBackStackIndices: '
    //   608: invokevirtual print : (Ljava/lang/String;)V
    //   611: aload_3
    //   612: aload_0
    //   613: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   616: invokevirtual toArray : ()[Ljava/lang/Object;
    //   619: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   622: invokevirtual println : (Ljava/lang/String;)V
    //   625: aload_0
    //   626: monitorexit
    //   627: aload_0
    //   628: getfield mPendingActions : Ljava/util/ArrayList;
    //   631: astore_2
    //   632: aload_2
    //   633: ifnull -> 722
    //   636: aload_2
    //   637: invokevirtual size : ()I
    //   640: istore #7
    //   642: iload #7
    //   644: ifle -> 722
    //   647: aload_3
    //   648: aload_1
    //   649: invokevirtual print : (Ljava/lang/String;)V
    //   652: aload_3
    //   653: ldc_w 'Pending Actions:'
    //   656: invokevirtual println : (Ljava/lang/String;)V
    //   659: iload #6
    //   661: istore #5
    //   663: iload #5
    //   665: iload #7
    //   667: if_icmpge -> 722
    //   670: aload_0
    //   671: getfield mPendingActions : Ljava/util/ArrayList;
    //   674: iload #5
    //   676: invokevirtual get : (I)Ljava/lang/Object;
    //   679: checkcast java/lang/Runnable
    //   682: astore_2
    //   683: aload_3
    //   684: aload_1
    //   685: invokevirtual print : (Ljava/lang/String;)V
    //   688: aload_3
    //   689: ldc_w '  #'
    //   692: invokevirtual print : (Ljava/lang/String;)V
    //   695: aload_3
    //   696: iload #5
    //   698: invokevirtual print : (I)V
    //   701: aload_3
    //   702: ldc_w ': '
    //   705: invokevirtual print : (Ljava/lang/String;)V
    //   708: aload_3
    //   709: aload_2
    //   710: invokevirtual println : (Ljava/lang/Object;)V
    //   713: iload #5
    //   715: iconst_1
    //   716: iadd
    //   717: istore #5
    //   719: goto -> 663
    //   722: aload_3
    //   723: aload_1
    //   724: invokevirtual print : (Ljava/lang/String;)V
    //   727: aload_3
    //   728: ldc_w 'FragmentManager misc state:'
    //   731: invokevirtual println : (Ljava/lang/String;)V
    //   734: aload_3
    //   735: aload_1
    //   736: invokevirtual print : (Ljava/lang/String;)V
    //   739: aload_3
    //   740: ldc_w '  mActivity='
    //   743: invokevirtual print : (Ljava/lang/String;)V
    //   746: aload_3
    //   747: aload_0
    //   748: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   751: invokevirtual println : (Ljava/lang/Object;)V
    //   754: aload_3
    //   755: aload_1
    //   756: invokevirtual print : (Ljava/lang/String;)V
    //   759: aload_3
    //   760: ldc_w '  mContainer='
    //   763: invokevirtual print : (Ljava/lang/String;)V
    //   766: aload_3
    //   767: aload_0
    //   768: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   771: invokevirtual println : (Ljava/lang/Object;)V
    //   774: aload_0
    //   775: getfield mParent : Landroid/support/v4/app/Fragment;
    //   778: ifnull -> 801
    //   781: aload_3
    //   782: aload_1
    //   783: invokevirtual print : (Ljava/lang/String;)V
    //   786: aload_3
    //   787: ldc_w '  mParent='
    //   790: invokevirtual print : (Ljava/lang/String;)V
    //   793: aload_3
    //   794: aload_0
    //   795: getfield mParent : Landroid/support/v4/app/Fragment;
    //   798: invokevirtual println : (Ljava/lang/Object;)V
    //   801: aload_3
    //   802: aload_1
    //   803: invokevirtual print : (Ljava/lang/String;)V
    //   806: aload_3
    //   807: ldc_w '  mCurState='
    //   810: invokevirtual print : (Ljava/lang/String;)V
    //   813: aload_3
    //   814: aload_0
    //   815: getfield mCurState : I
    //   818: invokevirtual print : (I)V
    //   821: aload_3
    //   822: ldc_w ' mStateSaved='
    //   825: invokevirtual print : (Ljava/lang/String;)V
    //   828: aload_3
    //   829: aload_0
    //   830: getfield mStateSaved : Z
    //   833: invokevirtual print : (Z)V
    //   836: aload_3
    //   837: ldc_w ' mDestroyed='
    //   840: invokevirtual print : (Ljava/lang/String;)V
    //   843: aload_3
    //   844: aload_0
    //   845: getfield mDestroyed : Z
    //   848: invokevirtual println : (Z)V
    //   851: aload_0
    //   852: getfield mNeedMenuInvalidate : Z
    //   855: ifeq -> 878
    //   858: aload_3
    //   859: aload_1
    //   860: invokevirtual print : (Ljava/lang/String;)V
    //   863: aload_3
    //   864: ldc_w '  mNeedMenuInvalidate='
    //   867: invokevirtual print : (Ljava/lang/String;)V
    //   870: aload_3
    //   871: aload_0
    //   872: getfield mNeedMenuInvalidate : Z
    //   875: invokevirtual println : (Z)V
    //   878: aload_0
    //   879: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   882: ifnull -> 905
    //   885: aload_3
    //   886: aload_1
    //   887: invokevirtual print : (Ljava/lang/String;)V
    //   890: aload_3
    //   891: ldc_w '  mNoTransactionsBecause='
    //   894: invokevirtual print : (Ljava/lang/String;)V
    //   897: aload_3
    //   898: aload_0
    //   899: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   902: invokevirtual println : (Ljava/lang/String;)V
    //   905: aload_0
    //   906: getfield mAvailIndices : Ljava/util/ArrayList;
    //   909: astore_2
    //   910: aload_2
    //   911: ifnull -> 947
    //   914: aload_2
    //   915: invokevirtual size : ()I
    //   918: ifle -> 947
    //   921: aload_3
    //   922: aload_1
    //   923: invokevirtual print : (Ljava/lang/String;)V
    //   926: aload_3
    //   927: ldc_w '  mAvailIndices: '
    //   930: invokevirtual print : (Ljava/lang/String;)V
    //   933: aload_3
    //   934: aload_0
    //   935: getfield mAvailIndices : Ljava/util/ArrayList;
    //   938: invokevirtual toArray : ()[Ljava/lang/Object;
    //   941: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   944: invokevirtual println : (Ljava/lang/String;)V
    //   947: return
    //   948: astore_1
    //   949: aload_0
    //   950: monitorexit
    //   951: aload_1
    //   952: athrow
    // Exception table:
    //   from	to	target	type
    //   487	503	948	finally
    //   508	520	948	finally
    //   530	573	948	finally
    //   582	625	948	finally
    //   625	627	948	finally
    //   949	951	948	finally
  }
  
  public void enqueueAction(Runnable paramRunnable, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 94
    //   17: aload_0
    //   18: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   21: ifnull -> 94
    //   24: aload_0
    //   25: getfield mPendingActions : Ljava/util/ArrayList;
    //   28: ifnonnull -> 42
    //   31: aload_0
    //   32: new java/util/ArrayList
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: putfield mPendingActions : Ljava/util/ArrayList;
    //   42: aload_0
    //   43: getfield mPendingActions : Ljava/util/ArrayList;
    //   46: aload_1
    //   47: invokevirtual add : (Ljava/lang/Object;)Z
    //   50: pop
    //   51: aload_0
    //   52: getfield mPendingActions : Ljava/util/ArrayList;
    //   55: invokevirtual size : ()I
    //   58: iconst_1
    //   59: if_icmpne -> 91
    //   62: aload_0
    //   63: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   66: getfield mHandler : Landroid/os/Handler;
    //   69: aload_0
    //   70: getfield mExecCommit : Ljava/lang/Runnable;
    //   73: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   76: aload_0
    //   77: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   80: getfield mHandler : Landroid/os/Handler;
    //   83: aload_0
    //   84: getfield mExecCommit : Ljava/lang/Runnable;
    //   87: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   90: pop
    //   91: aload_0
    //   92: monitorexit
    //   93: return
    //   94: new java/lang/IllegalStateException
    //   97: dup
    //   98: ldc_w 'Activity has been destroyed'
    //   101: invokespecial <init> : (Ljava/lang/String;)V
    //   104: athrow
    //   105: astore_1
    //   106: aload_0
    //   107: monitorexit
    //   108: aload_1
    //   109: athrow
    // Exception table:
    //   from	to	target	type
    //   10	42	105	finally
    //   42	91	105	finally
    //   91	93	105	finally
    //   94	105	105	finally
    //   106	108	105	finally
  }
  
  public boolean execPendingActions() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mExecutingActions : Z
    //   4: ifne -> 271
    //   7: invokestatic myLooper : ()Landroid/os/Looper;
    //   10: aload_0
    //   11: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   14: getfield mHandler : Landroid/os/Handler;
    //   17: invokevirtual getLooper : ()Landroid/os/Looper;
    //   20: if_acmpne -> 260
    //   23: iconst_0
    //   24: istore #4
    //   26: aload_0
    //   27: monitorenter
    //   28: aload_0
    //   29: getfield mPendingActions : Ljava/util/ArrayList;
    //   32: ifnull -> 163
    //   35: aload_0
    //   36: getfield mPendingActions : Ljava/util/ArrayList;
    //   39: invokevirtual size : ()I
    //   42: ifne -> 48
    //   45: goto -> 163
    //   48: aload_0
    //   49: getfield mPendingActions : Ljava/util/ArrayList;
    //   52: invokevirtual size : ()I
    //   55: istore_2
    //   56: aload_0
    //   57: getfield mTmpActions : [Ljava/lang/Runnable;
    //   60: ifnull -> 72
    //   63: aload_0
    //   64: getfield mTmpActions : [Ljava/lang/Runnable;
    //   67: arraylength
    //   68: iload_2
    //   69: if_icmpge -> 80
    //   72: aload_0
    //   73: iload_2
    //   74: anewarray java/lang/Runnable
    //   77: putfield mTmpActions : [Ljava/lang/Runnable;
    //   80: aload_0
    //   81: getfield mPendingActions : Ljava/util/ArrayList;
    //   84: aload_0
    //   85: getfield mTmpActions : [Ljava/lang/Runnable;
    //   88: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   91: pop
    //   92: aload_0
    //   93: getfield mPendingActions : Ljava/util/ArrayList;
    //   96: invokevirtual clear : ()V
    //   99: aload_0
    //   100: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   103: getfield mHandler : Landroid/os/Handler;
    //   106: aload_0
    //   107: getfield mExecCommit : Ljava/lang/Runnable;
    //   110: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   113: aload_0
    //   114: monitorexit
    //   115: aload_0
    //   116: iconst_1
    //   117: putfield mExecutingActions : Z
    //   120: iconst_0
    //   121: istore_1
    //   122: iload_1
    //   123: iload_2
    //   124: if_icmpge -> 152
    //   127: aload_0
    //   128: getfield mTmpActions : [Ljava/lang/Runnable;
    //   131: iload_1
    //   132: aaload
    //   133: invokeinterface run : ()V
    //   138: aload_0
    //   139: getfield mTmpActions : [Ljava/lang/Runnable;
    //   142: iload_1
    //   143: aconst_null
    //   144: aastore
    //   145: iload_1
    //   146: iconst_1
    //   147: iadd
    //   148: istore_1
    //   149: goto -> 122
    //   152: aload_0
    //   153: iconst_0
    //   154: putfield mExecutingActions : Z
    //   157: iconst_1
    //   158: istore #4
    //   160: goto -> 26
    //   163: aload_0
    //   164: monitorexit
    //   165: aload_0
    //   166: getfield mHavePendingDeferredStart : Z
    //   169: ifeq -> 250
    //   172: iconst_0
    //   173: istore_1
    //   174: iconst_0
    //   175: istore_2
    //   176: iload_1
    //   177: aload_0
    //   178: getfield mActive : Ljava/util/ArrayList;
    //   181: invokevirtual size : ()I
    //   184: if_icmpge -> 237
    //   187: aload_0
    //   188: getfield mActive : Ljava/util/ArrayList;
    //   191: iload_1
    //   192: invokevirtual get : (I)Ljava/lang/Object;
    //   195: checkcast android/support/v4/app/Fragment
    //   198: astore #5
    //   200: iload_2
    //   201: istore_3
    //   202: aload #5
    //   204: ifnull -> 228
    //   207: iload_2
    //   208: istore_3
    //   209: aload #5
    //   211: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   214: ifnull -> 228
    //   217: iload_2
    //   218: aload #5
    //   220: getfield mLoaderManager : Landroid/support/v4/app/LoaderManagerImpl;
    //   223: invokevirtual hasRunningLoaders : ()Z
    //   226: ior
    //   227: istore_3
    //   228: iload_1
    //   229: iconst_1
    //   230: iadd
    //   231: istore_1
    //   232: iload_3
    //   233: istore_2
    //   234: goto -> 176
    //   237: iload_2
    //   238: ifne -> 250
    //   241: aload_0
    //   242: iconst_0
    //   243: putfield mHavePendingDeferredStart : Z
    //   246: aload_0
    //   247: invokevirtual startPendingDeferredFragments : ()V
    //   250: iload #4
    //   252: ireturn
    //   253: astore #5
    //   255: aload_0
    //   256: monitorexit
    //   257: aload #5
    //   259: athrow
    //   260: new java/lang/IllegalStateException
    //   263: dup
    //   264: ldc_w 'Must be called from main thread of process'
    //   267: invokespecial <init> : (Ljava/lang/String;)V
    //   270: athrow
    //   271: new java/lang/IllegalStateException
    //   274: dup
    //   275: ldc_w 'Recursive entry to executePendingTransactions'
    //   278: invokespecial <init> : (Ljava/lang/String;)V
    //   281: athrow
    // Exception table:
    //   from	to	target	type
    //   28	45	253	finally
    //   48	72	253	finally
    //   72	80	253	finally
    //   80	115	253	finally
    //   163	165	253	finally
    //   255	257	253	finally
  }
  
  public boolean executePendingTransactions() {
    return execPendingActions();
  }
  
  public Fragment findFragmentById(int paramInt) {
    ArrayList<Fragment> arrayList = this.mAdded;
    if (arrayList != null)
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && fragment.mFragmentId == paramInt)
          return fragment; 
      }  
    arrayList = this.mActive;
    if (arrayList != null)
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mActive.get(i);
        if (fragment != null && fragment.mFragmentId == paramInt)
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    ArrayList<Fragment> arrayList = this.mAdded;
    if (arrayList != null && paramString != null)
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    arrayList = this.mActive;
    if (arrayList != null && paramString != null)
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mActive.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    ArrayList<Fragment> arrayList = this.mActive;
    if (arrayList != null && paramString != null)
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mActive.get(i);
        if (fragment != null) {
          fragment = fragment.findFragmentByWho(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 68
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore_2
    //   44: aload_2
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload_2
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: ldc 'FragmentManager'
    //   60: aload_2
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   67: pop
    //   68: aload_0
    //   69: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   72: iload_1
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: invokevirtual add : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: astore_2
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_2
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	83	finally
    //   30	68	83	finally
    //   68	82	83	finally
    //   84	86	83	finally
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    if (i >= this.mActive.size()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(i);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    Fragment fragment = this.mActive.get(i);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(i);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public List<Fragment> getFragments() {
    return this.mActive;
  }
  
  public void hideFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      if (paramFragment.mView != null) {
        Animation animation = loadAnimation(paramFragment, paramInt1, false, paramInt2);
        if (animation != null)
          paramFragment.mView.startAnimation(animation); 
        paramFragment.mView.setVisibility(8);
      } 
      if (paramFragment.mAdded && paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.onHiddenChanged(true);
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  Animation loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, paramFragment.mNextAnim);
    if (animation != null)
      return animation; 
    if (paramFragment.mNextAnim != 0) {
      Animation animation1 = AnimationUtils.loadAnimation((Context)this.mActivity, paramFragment.mNextAnim);
      if (animation1 != null)
        return animation1; 
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mActivity.getWindow() != null)
            paramInt1 = (this.mActivity.getWindow().getAttributes()).windowAnimations; 
        } 
        break;
      case 6:
        return makeFadeAnimation((Context)this.mActivity, 1.0F, 0.0F);
      case 5:
        return makeFadeAnimation((Context)this.mActivity, 0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation((Context)this.mActivity, 0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        return makeOpenCloseAnimation((Context)this.mActivity, 1.125F, 1.0F, 0.0F, 1.0F);
    } 
    if (paramInt1 == 0);
    return null;
  }
  
  void makeActive(Fragment paramFragment) {
    if (paramFragment.mIndex >= 0)
      return; 
    ArrayList<Integer> arrayList = this.mAvailIndices;
    if (arrayList == null || arrayList.size() <= 0) {
      if (this.mActive == null)
        this.mActive = new ArrayList<Fragment>(); 
      paramFragment.setIndex(this.mActive.size(), this.mParent);
      this.mActive.add(paramFragment);
    } else {
      arrayList = this.mAvailIndices;
      paramFragment.setIndex(((Integer)arrayList.remove(arrayList.size() - 1)).intValue(), this.mParent);
      this.mActive.set(paramFragment.mIndex, paramFragment);
    } 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.mActive.set(paramFragment.mIndex, null);
    if (this.mAvailIndices == null)
      this.mAvailIndices = new ArrayList<Integer>(); 
    this.mAvailIndices.add(Integer.valueOf(paramFragment.mIndex));
    this.mActivity.invalidateSupportFragment(paramFragment.mWho);
    paramFragment.initState();
  }
  
  void moveToState(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (this.mActivity != null || paramInt1 == 0) {
      if (!paramBoolean && this.mCurState == paramInt1)
        return; 
      this.mCurState = paramInt1;
      if (this.mActive != null) {
        int i = 0;
        boolean bool;
        for (bool = false; i < this.mActive.size(); bool = bool1) {
          Fragment fragment = this.mActive.get(i);
          boolean bool1 = bool;
          if (fragment != null) {
            moveToState(fragment, paramInt1, paramInt2, paramInt3, false);
            bool1 = bool;
            if (fragment.mLoaderManager != null)
              bool1 = bool | fragment.mLoaderManager.hasRunningLoaders(); 
          } 
          i++;
        } 
        if (!bool)
          startPendingDeferredFragments(); 
        if (this.mNeedMenuInvalidate) {
          FragmentActivity fragmentActivity = this.mActivity;
          if (fragmentActivity != null && this.mCurState == 5) {
            fragmentActivity.supportInvalidateOptionsMenu();
            this.mNeedMenuInvalidate = false;
          } 
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    moveToState(paramInt, 0, 0, paramBoolean);
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #8
    //   6: iconst_1
    //   7: istore #7
    //   9: iload #8
    //   11: ifeq -> 27
    //   14: aload_1
    //   15: getfield mDetached : Z
    //   18: ifeq -> 24
    //   21: goto -> 27
    //   24: goto -> 41
    //   27: iload_2
    //   28: istore #6
    //   30: iload #6
    //   32: istore_2
    //   33: iload #6
    //   35: iconst_1
    //   36: if_icmple -> 41
    //   39: iconst_1
    //   40: istore_2
    //   41: iload_2
    //   42: istore #6
    //   44: aload_1
    //   45: getfield mRemoving : Z
    //   48: ifeq -> 68
    //   51: iload_2
    //   52: istore #6
    //   54: iload_2
    //   55: aload_1
    //   56: getfield mState : I
    //   59: if_icmple -> 68
    //   62: aload_1
    //   63: getfield mState : I
    //   66: istore #6
    //   68: aload_1
    //   69: getfield mDeferStart : Z
    //   72: ifeq -> 94
    //   75: aload_1
    //   76: getfield mState : I
    //   79: iconst_4
    //   80: if_icmpge -> 94
    //   83: iload #6
    //   85: iconst_3
    //   86: if_icmple -> 94
    //   89: iconst_3
    //   90: istore_2
    //   91: goto -> 97
    //   94: iload #6
    //   96: istore_2
    //   97: aload_1
    //   98: getfield mState : I
    //   101: iload_2
    //   102: if_icmpge -> 1090
    //   105: aload_1
    //   106: getfield mFromLayout : Z
    //   109: ifeq -> 120
    //   112: aload_1
    //   113: getfield mInLayout : Z
    //   116: ifne -> 120
    //   119: return
    //   120: aload_1
    //   121: getfield mAnimatingAway : Landroid/view/View;
    //   124: ifnull -> 147
    //   127: aload_1
    //   128: aconst_null
    //   129: putfield mAnimatingAway : Landroid/view/View;
    //   132: aload_0
    //   133: aload_1
    //   134: aload_1
    //   135: getfield mStateAfterAnimating : I
    //   138: iconst_0
    //   139: iconst_0
    //   140: iconst_1
    //   141: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   144: goto -> 147
    //   147: aload_1
    //   148: getfield mState : I
    //   151: istore #6
    //   153: iload #6
    //   155: ifeq -> 202
    //   158: iload #6
    //   160: iconst_1
    //   161: if_icmpeq -> 196
    //   164: iload #6
    //   166: iconst_2
    //   167: if_icmpeq -> 193
    //   170: iload #6
    //   172: iconst_3
    //   173: if_icmpeq -> 193
    //   176: iload #6
    //   178: iconst_4
    //   179: if_icmpeq -> 188
    //   182: iload_2
    //   183: istore #6
    //   185: goto -> 1718
    //   188: iload_2
    //   189: istore_3
    //   190: goto -> 968
    //   193: goto -> 913
    //   196: iload_2
    //   197: istore #6
    //   199: goto -> 551
    //   202: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   205: ifeq -> 247
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore #9
    //   217: aload #9
    //   219: ldc_w 'moveto CREATED: '
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload #9
    //   228: aload_1
    //   229: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: ldc 'FragmentManager'
    //   235: aload #9
    //   237: invokevirtual toString : ()Ljava/lang/String;
    //   240: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   243: pop
    //   244: goto -> 247
    //   247: aload_1
    //   248: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   251: ifnull -> 348
    //   254: aload_1
    //   255: aload_1
    //   256: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   259: ldc 'android:view_state'
    //   261: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   264: putfield mSavedViewState : Landroid/util/SparseArray;
    //   267: aload_1
    //   268: aload_0
    //   269: aload_1
    //   270: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   273: ldc 'android:target_state'
    //   275: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    //   278: putfield mTarget : Landroid/support/v4/app/Fragment;
    //   281: aload_1
    //   282: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   285: ifnull -> 305
    //   288: aload_1
    //   289: aload_1
    //   290: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   293: ldc 'android:target_req_state'
    //   295: iconst_0
    //   296: invokevirtual getInt : (Ljava/lang/String;I)I
    //   299: putfield mTargetRequestCode : I
    //   302: goto -> 305
    //   305: aload_1
    //   306: aload_1
    //   307: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   310: ldc 'android:user_visible_hint'
    //   312: iconst_1
    //   313: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   316: putfield mUserVisibleHint : Z
    //   319: iload_2
    //   320: istore #6
    //   322: aload_1
    //   323: getfield mUserVisibleHint : Z
    //   326: ifne -> 351
    //   329: aload_1
    //   330: iconst_1
    //   331: putfield mDeferStart : Z
    //   334: iload_2
    //   335: istore #6
    //   337: iload_2
    //   338: iconst_3
    //   339: if_icmple -> 351
    //   342: iconst_3
    //   343: istore #6
    //   345: goto -> 351
    //   348: iload_2
    //   349: istore #6
    //   351: aload_0
    //   352: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   355: astore #9
    //   357: aload_1
    //   358: aload #9
    //   360: putfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   363: aload_0
    //   364: getfield mParent : Landroid/support/v4/app/Fragment;
    //   367: astore #10
    //   369: aload_1
    //   370: aload #10
    //   372: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   375: aload #10
    //   377: ifnull -> 390
    //   380: aload #10
    //   382: getfield mChildFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   385: astore #9
    //   387: goto -> 397
    //   390: aload #9
    //   392: getfield mFragments : Landroid/support/v4/app/FragmentManagerImpl;
    //   395: astore #9
    //   397: aload_1
    //   398: aload #9
    //   400: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   403: aload_1
    //   404: iconst_0
    //   405: putfield mCalled : Z
    //   408: aload_1
    //   409: aload_0
    //   410: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   413: invokevirtual onAttach : (Landroid/app/Activity;)V
    //   416: aload_1
    //   417: getfield mCalled : Z
    //   420: ifeq -> 1043
    //   423: aload_1
    //   424: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   427: ifnonnull -> 438
    //   430: aload_0
    //   431: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   434: aload_1
    //   435: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   438: aload_1
    //   439: getfield mRetaining : Z
    //   442: ifne -> 453
    //   445: aload_1
    //   446: aload_1
    //   447: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   450: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   453: aload_1
    //   454: iconst_0
    //   455: putfield mRetaining : Z
    //   458: iload #6
    //   460: istore_2
    //   461: aload_1
    //   462: getfield mFromLayout : Z
    //   465: ifeq -> 196
    //   468: aload_1
    //   469: aload_1
    //   470: aload_1
    //   471: aload_1
    //   472: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   475: invokevirtual getLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   478: aconst_null
    //   479: aload_1
    //   480: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   483: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   486: putfield mView : Landroid/view/View;
    //   489: aload_1
    //   490: getfield mView : Landroid/view/View;
    //   493: ifnull -> 546
    //   496: aload_1
    //   497: aload_1
    //   498: getfield mView : Landroid/view/View;
    //   501: putfield mInnerView : Landroid/view/View;
    //   504: aload_1
    //   505: aload_1
    //   506: getfield mView : Landroid/view/View;
    //   509: invokestatic wrap : (Landroid/view/View;)Landroid/view/ViewGroup;
    //   512: putfield mView : Landroid/view/View;
    //   515: aload_1
    //   516: getfield mHidden : Z
    //   519: ifeq -> 531
    //   522: aload_1
    //   523: getfield mView : Landroid/view/View;
    //   526: bipush #8
    //   528: invokevirtual setVisibility : (I)V
    //   531: aload_1
    //   532: aload_1
    //   533: getfield mView : Landroid/view/View;
    //   536: aload_1
    //   537: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   540: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   543: goto -> 551
    //   546: aload_1
    //   547: aconst_null
    //   548: putfield mInnerView : Landroid/view/View;
    //   551: iload #6
    //   553: istore_2
    //   554: iload #6
    //   556: iconst_1
    //   557: if_icmple -> 913
    //   560: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   563: ifeq -> 602
    //   566: new java/lang/StringBuilder
    //   569: dup
    //   570: invokespecial <init> : ()V
    //   573: astore #9
    //   575: aload #9
    //   577: ldc_w 'moveto ACTIVITY_CREATED: '
    //   580: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   583: pop
    //   584: aload #9
    //   586: aload_1
    //   587: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   590: pop
    //   591: ldc 'FragmentManager'
    //   593: aload #9
    //   595: invokevirtual toString : ()Ljava/lang/String;
    //   598: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   601: pop
    //   602: aload_1
    //   603: getfield mFromLayout : Z
    //   606: ifne -> 882
    //   609: aload_1
    //   610: getfield mContainerId : I
    //   613: ifeq -> 750
    //   616: aload_0
    //   617: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   620: aload_1
    //   621: getfield mContainerId : I
    //   624: invokeinterface findViewById : (I)Landroid/view/View;
    //   629: checkcast android/view/ViewGroup
    //   632: astore #10
    //   634: aload #10
    //   636: astore #9
    //   638: aload #10
    //   640: ifnonnull -> 753
    //   643: aload #10
    //   645: astore #9
    //   647: aload_1
    //   648: getfield mRestored : Z
    //   651: ifne -> 753
    //   654: new java/lang/StringBuilder
    //   657: dup
    //   658: invokespecial <init> : ()V
    //   661: astore #9
    //   663: aload #9
    //   665: ldc_w 'No view found for id 0x'
    //   668: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   671: pop
    //   672: aload #9
    //   674: aload_1
    //   675: getfield mContainerId : I
    //   678: invokestatic toHexString : (I)Ljava/lang/String;
    //   681: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   684: pop
    //   685: aload #9
    //   687: ldc_w ' ('
    //   690: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   693: pop
    //   694: aload #9
    //   696: aload_1
    //   697: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   700: aload_1
    //   701: getfield mContainerId : I
    //   704: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   707: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   710: pop
    //   711: aload #9
    //   713: ldc_w ') for fragment '
    //   716: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   719: pop
    //   720: aload #9
    //   722: aload_1
    //   723: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   726: pop
    //   727: aload_0
    //   728: new java/lang/IllegalArgumentException
    //   731: dup
    //   732: aload #9
    //   734: invokevirtual toString : ()Ljava/lang/String;
    //   737: invokespecial <init> : (Ljava/lang/String;)V
    //   740: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   743: aload #10
    //   745: astore #9
    //   747: goto -> 753
    //   750: aconst_null
    //   751: astore #9
    //   753: aload_1
    //   754: aload #9
    //   756: putfield mContainer : Landroid/view/ViewGroup;
    //   759: aload_1
    //   760: aload_1
    //   761: aload_1
    //   762: aload_1
    //   763: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   766: invokevirtual getLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   769: aload #9
    //   771: aload_1
    //   772: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   775: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   778: putfield mView : Landroid/view/View;
    //   781: aload_1
    //   782: getfield mView : Landroid/view/View;
    //   785: ifnull -> 877
    //   788: aload_1
    //   789: aload_1
    //   790: getfield mView : Landroid/view/View;
    //   793: putfield mInnerView : Landroid/view/View;
    //   796: aload_1
    //   797: aload_1
    //   798: getfield mView : Landroid/view/View;
    //   801: invokestatic wrap : (Landroid/view/View;)Landroid/view/ViewGroup;
    //   804: putfield mView : Landroid/view/View;
    //   807: aload #9
    //   809: ifnull -> 846
    //   812: aload_0
    //   813: aload_1
    //   814: iload_3
    //   815: iconst_1
    //   816: iload #4
    //   818: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    //   821: astore #10
    //   823: aload #10
    //   825: ifnull -> 837
    //   828: aload_1
    //   829: getfield mView : Landroid/view/View;
    //   832: aload #10
    //   834: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   837: aload #9
    //   839: aload_1
    //   840: getfield mView : Landroid/view/View;
    //   843: invokevirtual addView : (Landroid/view/View;)V
    //   846: aload_1
    //   847: getfield mHidden : Z
    //   850: ifeq -> 862
    //   853: aload_1
    //   854: getfield mView : Landroid/view/View;
    //   857: bipush #8
    //   859: invokevirtual setVisibility : (I)V
    //   862: aload_1
    //   863: aload_1
    //   864: getfield mView : Landroid/view/View;
    //   867: aload_1
    //   868: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   871: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   874: goto -> 882
    //   877: aload_1
    //   878: aconst_null
    //   879: putfield mInnerView : Landroid/view/View;
    //   882: aload_1
    //   883: aload_1
    //   884: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   887: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   890: aload_1
    //   891: getfield mView : Landroid/view/View;
    //   894: ifnull -> 905
    //   897: aload_1
    //   898: aload_1
    //   899: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   902: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   905: aload_1
    //   906: aconst_null
    //   907: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   910: iload #6
    //   912: istore_2
    //   913: iload_2
    //   914: istore_3
    //   915: iload_2
    //   916: iconst_3
    //   917: if_icmple -> 968
    //   920: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   923: ifeq -> 962
    //   926: new java/lang/StringBuilder
    //   929: dup
    //   930: invokespecial <init> : ()V
    //   933: astore #9
    //   935: aload #9
    //   937: ldc_w 'moveto STARTED: '
    //   940: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   943: pop
    //   944: aload #9
    //   946: aload_1
    //   947: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   950: pop
    //   951: ldc 'FragmentManager'
    //   953: aload #9
    //   955: invokevirtual toString : ()Ljava/lang/String;
    //   958: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   961: pop
    //   962: aload_1
    //   963: invokevirtual performStart : ()V
    //   966: iload_2
    //   967: istore_3
    //   968: iload_3
    //   969: istore #6
    //   971: iload_3
    //   972: iconst_4
    //   973: if_icmple -> 1718
    //   976: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   979: ifeq -> 1018
    //   982: new java/lang/StringBuilder
    //   985: dup
    //   986: invokespecial <init> : ()V
    //   989: astore #9
    //   991: aload #9
    //   993: ldc_w 'moveto RESUMED: '
    //   996: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   999: pop
    //   1000: aload #9
    //   1002: aload_1
    //   1003: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: ldc 'FragmentManager'
    //   1009: aload #9
    //   1011: invokevirtual toString : ()Ljava/lang/String;
    //   1014: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1017: pop
    //   1018: aload_1
    //   1019: iconst_1
    //   1020: putfield mResumed : Z
    //   1023: aload_1
    //   1024: invokevirtual performResume : ()V
    //   1027: aload_1
    //   1028: aconst_null
    //   1029: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1032: aload_1
    //   1033: aconst_null
    //   1034: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1037: iload_3
    //   1038: istore #6
    //   1040: goto -> 1718
    //   1043: new java/lang/StringBuilder
    //   1046: dup
    //   1047: invokespecial <init> : ()V
    //   1050: astore #9
    //   1052: aload #9
    //   1054: ldc_w 'Fragment '
    //   1057: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1060: pop
    //   1061: aload #9
    //   1063: aload_1
    //   1064: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1067: pop
    //   1068: aload #9
    //   1070: ldc_w ' did not call through to super.onAttach()'
    //   1073: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1076: pop
    //   1077: new android/support/v4/app/SuperNotCalledException
    //   1080: dup
    //   1081: aload #9
    //   1083: invokevirtual toString : ()Ljava/lang/String;
    //   1086: invokespecial <init> : (Ljava/lang/String;)V
    //   1089: athrow
    //   1090: iload_2
    //   1091: istore #6
    //   1093: aload_1
    //   1094: getfield mState : I
    //   1097: iload_2
    //   1098: if_icmple -> 1718
    //   1101: aload_1
    //   1102: getfield mState : I
    //   1105: istore #6
    //   1107: iload #6
    //   1109: iconst_1
    //   1110: if_icmpeq -> 1493
    //   1113: iload #6
    //   1115: iconst_2
    //   1116: if_icmpeq -> 1301
    //   1119: iload #6
    //   1121: iconst_3
    //   1122: if_icmpeq -> 1250
    //   1125: iload #6
    //   1127: iconst_4
    //   1128: if_icmpeq -> 1199
    //   1131: iload #6
    //   1133: iconst_5
    //   1134: if_icmpeq -> 1143
    //   1137: iload_2
    //   1138: istore #6
    //   1140: goto -> 1718
    //   1143: iload_2
    //   1144: iconst_5
    //   1145: if_icmpge -> 1199
    //   1148: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1151: ifeq -> 1190
    //   1154: new java/lang/StringBuilder
    //   1157: dup
    //   1158: invokespecial <init> : ()V
    //   1161: astore #9
    //   1163: aload #9
    //   1165: ldc_w 'movefrom RESUMED: '
    //   1168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1171: pop
    //   1172: aload #9
    //   1174: aload_1
    //   1175: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1178: pop
    //   1179: ldc 'FragmentManager'
    //   1181: aload #9
    //   1183: invokevirtual toString : ()Ljava/lang/String;
    //   1186: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1189: pop
    //   1190: aload_1
    //   1191: invokevirtual performPause : ()V
    //   1194: aload_1
    //   1195: iconst_0
    //   1196: putfield mResumed : Z
    //   1199: iload_2
    //   1200: iconst_4
    //   1201: if_icmpge -> 1250
    //   1204: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1207: ifeq -> 1246
    //   1210: new java/lang/StringBuilder
    //   1213: dup
    //   1214: invokespecial <init> : ()V
    //   1217: astore #9
    //   1219: aload #9
    //   1221: ldc_w 'movefrom STARTED: '
    //   1224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1227: pop
    //   1228: aload #9
    //   1230: aload_1
    //   1231: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1234: pop
    //   1235: ldc 'FragmentManager'
    //   1237: aload #9
    //   1239: invokevirtual toString : ()Ljava/lang/String;
    //   1242: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1245: pop
    //   1246: aload_1
    //   1247: invokevirtual performStop : ()V
    //   1250: iload_2
    //   1251: iconst_3
    //   1252: if_icmpge -> 1301
    //   1255: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1258: ifeq -> 1297
    //   1261: new java/lang/StringBuilder
    //   1264: dup
    //   1265: invokespecial <init> : ()V
    //   1268: astore #9
    //   1270: aload #9
    //   1272: ldc_w 'movefrom STOPPED: '
    //   1275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1278: pop
    //   1279: aload #9
    //   1281: aload_1
    //   1282: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1285: pop
    //   1286: ldc 'FragmentManager'
    //   1288: aload #9
    //   1290: invokevirtual toString : ()Ljava/lang/String;
    //   1293: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1296: pop
    //   1297: aload_1
    //   1298: invokevirtual performReallyStop : ()V
    //   1301: iload_2
    //   1302: iconst_2
    //   1303: if_icmpge -> 1493
    //   1306: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1309: ifeq -> 1348
    //   1312: new java/lang/StringBuilder
    //   1315: dup
    //   1316: invokespecial <init> : ()V
    //   1319: astore #9
    //   1321: aload #9
    //   1323: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1326: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1329: pop
    //   1330: aload #9
    //   1332: aload_1
    //   1333: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1336: pop
    //   1337: ldc 'FragmentManager'
    //   1339: aload #9
    //   1341: invokevirtual toString : ()Ljava/lang/String;
    //   1344: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1347: pop
    //   1348: aload_1
    //   1349: getfield mView : Landroid/view/View;
    //   1352: ifnull -> 1377
    //   1355: aload_0
    //   1356: getfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   1359: invokevirtual isFinishing : ()Z
    //   1362: ifne -> 1377
    //   1365: aload_1
    //   1366: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1369: ifnonnull -> 1377
    //   1372: aload_0
    //   1373: aload_1
    //   1374: invokevirtual saveFragmentViewState : (Landroid/support/v4/app/Fragment;)V
    //   1377: aload_1
    //   1378: invokevirtual performDestroyView : ()V
    //   1381: aload_1
    //   1382: getfield mView : Landroid/view/View;
    //   1385: ifnull -> 1478
    //   1388: aload_1
    //   1389: getfield mContainer : Landroid/view/ViewGroup;
    //   1392: ifnull -> 1478
    //   1395: aload_0
    //   1396: getfield mCurState : I
    //   1399: ifle -> 1423
    //   1402: aload_0
    //   1403: getfield mDestroyed : Z
    //   1406: ifne -> 1423
    //   1409: aload_0
    //   1410: aload_1
    //   1411: iload_3
    //   1412: iconst_0
    //   1413: iload #4
    //   1415: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    //   1418: astore #9
    //   1420: goto -> 1426
    //   1423: aconst_null
    //   1424: astore #9
    //   1426: aload #9
    //   1428: ifnull -> 1467
    //   1431: aload_1
    //   1432: aload_1
    //   1433: getfield mView : Landroid/view/View;
    //   1436: putfield mAnimatingAway : Landroid/view/View;
    //   1439: aload_1
    //   1440: iload_2
    //   1441: putfield mStateAfterAnimating : I
    //   1444: aload #9
    //   1446: new android/support/v4/app/FragmentManagerImpl$5
    //   1449: dup
    //   1450: aload_0
    //   1451: aload_1
    //   1452: invokespecial <init> : (Landroid/support/v4/app/FragmentManagerImpl;Landroid/support/v4/app/Fragment;)V
    //   1455: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   1458: aload_1
    //   1459: getfield mView : Landroid/view/View;
    //   1462: aload #9
    //   1464: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   1467: aload_1
    //   1468: getfield mContainer : Landroid/view/ViewGroup;
    //   1471: aload_1
    //   1472: getfield mView : Landroid/view/View;
    //   1475: invokevirtual removeView : (Landroid/view/View;)V
    //   1478: aload_1
    //   1479: aconst_null
    //   1480: putfield mContainer : Landroid/view/ViewGroup;
    //   1483: aload_1
    //   1484: aconst_null
    //   1485: putfield mView : Landroid/view/View;
    //   1488: aload_1
    //   1489: aconst_null
    //   1490: putfield mInnerView : Landroid/view/View;
    //   1493: iload_2
    //   1494: istore #6
    //   1496: iload_2
    //   1497: iconst_1
    //   1498: if_icmpge -> 1718
    //   1501: aload_0
    //   1502: getfield mDestroyed : Z
    //   1505: ifeq -> 1531
    //   1508: aload_1
    //   1509: getfield mAnimatingAway : Landroid/view/View;
    //   1512: ifnull -> 1531
    //   1515: aload_1
    //   1516: getfield mAnimatingAway : Landroid/view/View;
    //   1519: astore #9
    //   1521: aload_1
    //   1522: aconst_null
    //   1523: putfield mAnimatingAway : Landroid/view/View;
    //   1526: aload #9
    //   1528: invokevirtual clearAnimation : ()V
    //   1531: aload_1
    //   1532: getfield mAnimatingAway : Landroid/view/View;
    //   1535: ifnull -> 1550
    //   1538: aload_1
    //   1539: iload_2
    //   1540: putfield mStateAfterAnimating : I
    //   1543: iload #7
    //   1545: istore #6
    //   1547: goto -> 1718
    //   1550: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1553: ifeq -> 1592
    //   1556: new java/lang/StringBuilder
    //   1559: dup
    //   1560: invokespecial <init> : ()V
    //   1563: astore #9
    //   1565: aload #9
    //   1567: ldc_w 'movefrom CREATED: '
    //   1570: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1573: pop
    //   1574: aload #9
    //   1576: aload_1
    //   1577: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1580: pop
    //   1581: ldc 'FragmentManager'
    //   1583: aload #9
    //   1585: invokevirtual toString : ()Ljava/lang/String;
    //   1588: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1591: pop
    //   1592: aload_1
    //   1593: getfield mRetaining : Z
    //   1596: ifne -> 1603
    //   1599: aload_1
    //   1600: invokevirtual performDestroy : ()V
    //   1603: aload_1
    //   1604: iconst_0
    //   1605: putfield mCalled : Z
    //   1608: aload_1
    //   1609: invokevirtual onDetach : ()V
    //   1612: aload_1
    //   1613: getfield mCalled : Z
    //   1616: ifeq -> 1671
    //   1619: iload_2
    //   1620: istore #6
    //   1622: iload #5
    //   1624: ifne -> 1718
    //   1627: aload_1
    //   1628: getfield mRetaining : Z
    //   1631: ifne -> 1645
    //   1634: aload_0
    //   1635: aload_1
    //   1636: invokevirtual makeInactive : (Landroid/support/v4/app/Fragment;)V
    //   1639: iload_2
    //   1640: istore #6
    //   1642: goto -> 1718
    //   1645: aload_1
    //   1646: aconst_null
    //   1647: putfield mActivity : Landroid/support/v4/app/FragmentActivity;
    //   1650: aload_1
    //   1651: aconst_null
    //   1652: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   1655: aload_1
    //   1656: aconst_null
    //   1657: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   1660: aload_1
    //   1661: aconst_null
    //   1662: putfield mChildFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   1665: iload_2
    //   1666: istore #6
    //   1668: goto -> 1718
    //   1671: new java/lang/StringBuilder
    //   1674: dup
    //   1675: invokespecial <init> : ()V
    //   1678: astore #9
    //   1680: aload #9
    //   1682: ldc_w 'Fragment '
    //   1685: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1688: pop
    //   1689: aload #9
    //   1691: aload_1
    //   1692: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1695: pop
    //   1696: aload #9
    //   1698: ldc_w ' did not call through to super.onDetach()'
    //   1701: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1704: pop
    //   1705: new android/support/v4/app/SuperNotCalledException
    //   1708: dup
    //   1709: aload #9
    //   1711: invokevirtual toString : ()Ljava/lang/String;
    //   1714: invokespecial <init> : (Ljava/lang/String;)V
    //   1717: athrow
    //   1718: aload_1
    //   1719: iload #6
    //   1721: putfield mState : I
    //   1724: return
  }
  
  public void noteStateNotSaved() {
    this.mStateSaved = false;
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      moveToState(paramFragment, this.mCurState, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new Runnable() {
          public void run() {
            FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
            fragmentManagerImpl.popBackStackState(fragmentManagerImpl.mActivity.mHandler, null, -1, 0);
          }
        }false);
  }
  
  public void popBackStack(final int id, final int flags) {
    if (id >= 0) {
      enqueueAction(new Runnable() {
            public void run() {
              FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
              fragmentManagerImpl.popBackStackState(fragmentManagerImpl.mActivity.mHandler, null, id, flags);
            }
          }false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(id);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(final String name, final int flags) {
    enqueueAction(new Runnable() {
          public void run() {
            FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
            fragmentManagerImpl.popBackStackState(fragmentManagerImpl.mActivity.mHandler, name, -1, flags);
          }
        }false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    executePendingTransactions();
    return popBackStackState(this.mActivity.mHandler, null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    executePendingTransactions();
    if (paramInt1 >= 0)
      return popBackStackState(this.mActivity.mHandler, null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    executePendingTransactions();
    return popBackStackState(this.mActivity.mHandler, paramString, -1, paramInt);
  }
  
  boolean popBackStackState(Handler paramHandler, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull -> 11
    //   9: iconst_0
    //   10: ireturn
    //   11: aload_2
    //   12: ifnonnull -> 60
    //   15: iload_3
    //   16: ifge -> 60
    //   19: iload #4
    //   21: iconst_1
    //   22: iand
    //   23: ifne -> 60
    //   26: aload_1
    //   27: invokevirtual size : ()I
    //   30: iconst_1
    //   31: isub
    //   32: istore_3
    //   33: iload_3
    //   34: ifge -> 39
    //   37: iconst_0
    //   38: ireturn
    //   39: aload_0
    //   40: getfield mBackStack : Ljava/util/ArrayList;
    //   43: iload_3
    //   44: invokevirtual remove : (I)Ljava/lang/Object;
    //   47: checkcast android/support/v4/app/BackStackRecord
    //   50: iconst_1
    //   51: invokevirtual popFromBackStack : (Z)V
    //   54: aload_0
    //   55: invokevirtual reportBackStackChanged : ()V
    //   58: iconst_1
    //   59: ireturn
    //   60: aload_2
    //   61: ifnonnull -> 77
    //   64: iload_3
    //   65: iflt -> 71
    //   68: goto -> 77
    //   71: iconst_m1
    //   72: istore #6
    //   74: goto -> 240
    //   77: aload_0
    //   78: getfield mBackStack : Ljava/util/ArrayList;
    //   81: invokevirtual size : ()I
    //   84: iconst_1
    //   85: isub
    //   86: istore #5
    //   88: iload #5
    //   90: iflt -> 148
    //   93: aload_0
    //   94: getfield mBackStack : Ljava/util/ArrayList;
    //   97: iload #5
    //   99: invokevirtual get : (I)Ljava/lang/Object;
    //   102: checkcast android/support/v4/app/BackStackRecord
    //   105: astore_1
    //   106: aload_2
    //   107: ifnull -> 124
    //   110: aload_2
    //   111: aload_1
    //   112: invokevirtual getName : ()Ljava/lang/String;
    //   115: invokevirtual equals : (Ljava/lang/Object;)Z
    //   118: ifeq -> 124
    //   121: goto -> 148
    //   124: iload_3
    //   125: iflt -> 139
    //   128: iload_3
    //   129: aload_1
    //   130: getfield mIndex : I
    //   133: if_icmpne -> 139
    //   136: goto -> 148
    //   139: iload #5
    //   141: iconst_1
    //   142: isub
    //   143: istore #5
    //   145: goto -> 88
    //   148: iload #5
    //   150: ifge -> 155
    //   153: iconst_0
    //   154: ireturn
    //   155: iload #5
    //   157: istore #6
    //   159: iload #4
    //   161: iconst_1
    //   162: iand
    //   163: ifeq -> 240
    //   166: iload #5
    //   168: iconst_1
    //   169: isub
    //   170: istore #4
    //   172: iload #4
    //   174: istore #6
    //   176: iload #4
    //   178: iflt -> 240
    //   181: aload_0
    //   182: getfield mBackStack : Ljava/util/ArrayList;
    //   185: iload #4
    //   187: invokevirtual get : (I)Ljava/lang/Object;
    //   190: checkcast android/support/v4/app/BackStackRecord
    //   193: astore_1
    //   194: aload_2
    //   195: ifnull -> 213
    //   198: iload #4
    //   200: istore #5
    //   202: aload_2
    //   203: aload_1
    //   204: invokevirtual getName : ()Ljava/lang/String;
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifne -> 166
    //   213: iload #4
    //   215: istore #6
    //   217: iload_3
    //   218: iflt -> 240
    //   221: iload #4
    //   223: istore #6
    //   225: iload_3
    //   226: aload_1
    //   227: getfield mIndex : I
    //   230: if_icmpne -> 240
    //   233: iload #4
    //   235: istore #5
    //   237: goto -> 166
    //   240: iload #6
    //   242: aload_0
    //   243: getfield mBackStack : Ljava/util/ArrayList;
    //   246: invokevirtual size : ()I
    //   249: iconst_1
    //   250: isub
    //   251: if_icmpne -> 256
    //   254: iconst_0
    //   255: ireturn
    //   256: new java/util/ArrayList
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: astore_1
    //   264: aload_0
    //   265: getfield mBackStack : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: iconst_1
    //   272: isub
    //   273: istore_3
    //   274: iload_3
    //   275: iload #6
    //   277: if_icmple -> 300
    //   280: aload_1
    //   281: aload_0
    //   282: getfield mBackStack : Ljava/util/ArrayList;
    //   285: iload_3
    //   286: invokevirtual remove : (I)Ljava/lang/Object;
    //   289: invokevirtual add : (Ljava/lang/Object;)Z
    //   292: pop
    //   293: iload_3
    //   294: iconst_1
    //   295: isub
    //   296: istore_3
    //   297: goto -> 274
    //   300: aload_1
    //   301: invokevirtual size : ()I
    //   304: iconst_1
    //   305: isub
    //   306: istore #4
    //   308: iconst_0
    //   309: istore_3
    //   310: iload_3
    //   311: iload #4
    //   313: if_icmpgt -> 395
    //   316: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   319: ifeq -> 358
    //   322: new java/lang/StringBuilder
    //   325: dup
    //   326: invokespecial <init> : ()V
    //   329: astore_2
    //   330: aload_2
    //   331: ldc_w 'Popping back stack state: '
    //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   337: pop
    //   338: aload_2
    //   339: aload_1
    //   340: iload_3
    //   341: invokevirtual get : (I)Ljava/lang/Object;
    //   344: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   347: pop
    //   348: ldc 'FragmentManager'
    //   350: aload_2
    //   351: invokevirtual toString : ()Ljava/lang/String;
    //   354: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   357: pop
    //   358: aload_1
    //   359: iload_3
    //   360: invokevirtual get : (I)Ljava/lang/Object;
    //   363: checkcast android/support/v4/app/BackStackRecord
    //   366: astore_2
    //   367: iload_3
    //   368: iload #4
    //   370: if_icmpne -> 379
    //   373: iconst_1
    //   374: istore #7
    //   376: goto -> 382
    //   379: iconst_0
    //   380: istore #7
    //   382: aload_2
    //   383: iload #7
    //   385: invokevirtual popFromBackStack : (Z)V
    //   388: iload_3
    //   389: iconst_1
    //   390: iadd
    //   391: istore_3
    //   392: goto -> 310
    //   395: aload_0
    //   396: invokevirtual reportBackStackChanged : ()V
    //   399: iconst_1
    //   400: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void removeFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int i = paramFragment.isInBackStack() ^ true;
    if (!paramFragment.mDetached || i != 0) {
      ArrayList<Fragment> arrayList = this.mAdded;
      if (arrayList != null)
        arrayList.remove(paramFragment); 
      if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.mAdded = false;
      paramFragment.mRemoving = true;
      if (i != 0) {
        i = 0;
      } else {
        i = 1;
      } 
      moveToState(paramFragment, i, paramInt1, paramInt2, false);
    } 
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<FragmentManager.OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, ArrayList<Fragment> paramArrayList) {
    if (paramParcelable == null)
      return; 
    paramParcelable = paramParcelable;
    if (((FragmentManagerState)paramParcelable).mActive == null)
      return; 
    if (paramArrayList != null)
      for (int j = 0; j < paramArrayList.size(); j++) {
        Fragment fragment = paramArrayList.get(j);
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: re-attaching retained ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        FragmentState fragmentState = ((FragmentManagerState)paramParcelable).mActive[fragment.mIndex];
        fragmentState.mInstance = fragment;
        fragment.mSavedViewState = null;
        fragment.mBackStackNesting = 0;
        fragment.mInLayout = false;
        fragment.mAdded = false;
        fragment.mTarget = null;
        if (fragmentState.mSavedFragmentState != null) {
          fragmentState.mSavedFragmentState.setClassLoader(this.mActivity.getClassLoader());
          fragment.mSavedViewState = fragmentState.mSavedFragmentState.getSparseParcelableArray("android:view_state");
        } 
      }  
    this.mActive = new ArrayList<Fragment>(((FragmentManagerState)paramParcelable).mActive.length);
    ArrayList<Integer> arrayList = this.mAvailIndices;
    if (arrayList != null)
      arrayList.clear(); 
    int i;
    for (i = 0; i < ((FragmentManagerState)paramParcelable).mActive.length; i++) {
      FragmentState fragmentState = ((FragmentManagerState)paramParcelable).mActive[i];
      if (fragmentState != null) {
        Fragment fragment = fragmentState.instantiate(this.mActivity, this.mParent);
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: active #");
          stringBuilder.append(i);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mActive.add(fragment);
        fragmentState.mInstance = null;
      } else {
        this.mActive.add(null);
        if (this.mAvailIndices == null)
          this.mAvailIndices = new ArrayList<Integer>(); 
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: avail #");
          stringBuilder.append(i);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mAvailIndices.add(Integer.valueOf(i));
      } 
    } 
    if (paramArrayList != null)
      for (i = 0; i < paramArrayList.size(); i++) {
        Fragment fragment = paramArrayList.get(i);
        if (fragment.mTargetIndex >= 0)
          if (fragment.mTargetIndex < this.mActive.size()) {
            fragment.mTarget = this.mActive.get(fragment.mTargetIndex);
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Re-attaching retained fragment ");
            stringBuilder.append(fragment);
            stringBuilder.append(" target no longer exists: ");
            stringBuilder.append(fragment.mTargetIndex);
            Log.w("FragmentManager", stringBuilder.toString());
            fragment.mTarget = null;
          }  
      }  
    if (((FragmentManagerState)paramParcelable).mAdded != null) {
      this.mAdded = new ArrayList<Fragment>(((FragmentManagerState)paramParcelable).mAdded.length);
      i = 0;
      while (i < ((FragmentManagerState)paramParcelable).mAdded.length) {
        Fragment fragment = this.mActive.get(((FragmentManagerState)paramParcelable).mAdded[i]);
        if (fragment == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("No instantiated fragment for index #");
          stringBuilder.append(((FragmentManagerState)paramParcelable).mAdded[i]);
          throwException(new IllegalStateException(stringBuilder.toString()));
        } 
        fragment.mAdded = true;
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: added #");
          stringBuilder.append(i);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (!this.mAdded.contains(fragment)) {
          this.mAdded.add(fragment);
          i++;
          continue;
        } 
        throw new IllegalStateException("Already added!");
      } 
    } else {
      this.mAdded = null;
    } 
    if (((FragmentManagerState)paramParcelable).mBackStack != null) {
      this.mBackStack = new ArrayList<BackStackRecord>(((FragmentManagerState)paramParcelable).mBackStack.length);
      for (i = 0; i < ((FragmentManagerState)paramParcelable).mBackStack.length; i++) {
        BackStackRecord backStackRecord = ((FragmentManagerState)paramParcelable).mBackStack[i].instantiate(this);
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: back stack #");
          stringBuilder.append(i);
          stringBuilder.append(" (index ");
          stringBuilder.append(backStackRecord.mIndex);
          stringBuilder.append("): ");
          stringBuilder.append(backStackRecord);
          Log.v("FragmentManager", stringBuilder.toString());
          backStackRecord.dump("  ", new PrintWriter((Writer)new LogWriter("FragmentManager")), false);
        } 
        this.mBackStack.add(backStackRecord);
        if (backStackRecord.mIndex >= 0)
          setBackStackIndex(backStackRecord.mIndex, backStackRecord); 
      } 
    } else {
      this.mBackStack = null;
    } 
  }
  
  ArrayList<Fragment> retainNonConfig() {
    ArrayList<Fragment> arrayList3 = this.mActive;
    ArrayList<Fragment> arrayList2 = null;
    ArrayList<Fragment> arrayList1 = null;
    if (arrayList3 != null) {
      int i = 0;
      while (true) {
        arrayList2 = arrayList1;
        if (i < this.mActive.size()) {
          Fragment fragment = this.mActive.get(i);
          arrayList3 = arrayList1;
          if (fragment != null) {
            arrayList3 = arrayList1;
            if (fragment.mRetainInstance) {
              byte b;
              arrayList2 = arrayList1;
              if (arrayList1 == null)
                arrayList2 = new ArrayList<Fragment>(); 
              arrayList2.add(fragment);
              fragment.mRetaining = true;
              if (fragment.mTarget != null) {
                b = fragment.mTarget.mIndex;
              } else {
                b = -1;
              } 
              fragment.mTargetIndex = b;
              arrayList3 = arrayList2;
              if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("retainNonConfig: keeping retained ");
                stringBuilder.append(fragment);
                Log.v("FragmentManager", stringBuilder.toString());
                arrayList3 = arrayList2;
              } 
            } 
          } 
          i++;
          arrayList1 = arrayList3;
          continue;
        } 
        break;
      } 
    } 
    return arrayList2;
  }
  
  Parcelable saveAllState() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual execPendingActions : ()Z
    //   4: pop
    //   5: getstatic android/support/v4/app/FragmentManagerImpl.HONEYCOMB : Z
    //   8: ifeq -> 16
    //   11: aload_0
    //   12: iconst_1
    //   13: putfield mStateSaved : Z
    //   16: aload_0
    //   17: getfield mActive : Ljava/util/ArrayList;
    //   20: astore #5
    //   22: aconst_null
    //   23: astore #7
    //   25: aload #5
    //   27: ifnull -> 824
    //   30: aload #5
    //   32: invokevirtual size : ()I
    //   35: ifgt -> 40
    //   38: aconst_null
    //   39: areturn
    //   40: aload_0
    //   41: getfield mActive : Ljava/util/ArrayList;
    //   44: invokevirtual size : ()I
    //   47: istore #4
    //   49: iload #4
    //   51: anewarray android/support/v4/app/FragmentState
    //   54: astore #8
    //   56: iconst_0
    //   57: istore_3
    //   58: iconst_0
    //   59: istore_1
    //   60: iconst_0
    //   61: istore_2
    //   62: iload_1
    //   63: iload #4
    //   65: if_icmpge -> 425
    //   68: aload_0
    //   69: getfield mActive : Ljava/util/ArrayList;
    //   72: iload_1
    //   73: invokevirtual get : (I)Ljava/lang/Object;
    //   76: checkcast android/support/v4/app/Fragment
    //   79: astore #5
    //   81: aload #5
    //   83: ifnull -> 418
    //   86: aload #5
    //   88: getfield mIndex : I
    //   91: ifge -> 156
    //   94: new java/lang/StringBuilder
    //   97: dup
    //   98: invokespecial <init> : ()V
    //   101: astore #6
    //   103: aload #6
    //   105: ldc_w 'Failure saving state: active '
    //   108: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: pop
    //   112: aload #6
    //   114: aload #5
    //   116: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: aload #6
    //   122: ldc_w ' has cleared index: '
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload #6
    //   131: aload #5
    //   133: getfield mIndex : I
    //   136: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: aload_0
    //   141: new java/lang/IllegalStateException
    //   144: dup
    //   145: aload #6
    //   147: invokevirtual toString : ()Ljava/lang/String;
    //   150: invokespecial <init> : (Ljava/lang/String;)V
    //   153: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   156: new android/support/v4/app/FragmentState
    //   159: dup
    //   160: aload #5
    //   162: invokespecial <init> : (Landroid/support/v4/app/Fragment;)V
    //   165: astore #6
    //   167: aload #8
    //   169: iload_1
    //   170: aload #6
    //   172: aastore
    //   173: aload #5
    //   175: getfield mState : I
    //   178: ifle -> 343
    //   181: aload #6
    //   183: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   186: ifnonnull -> 343
    //   189: aload #6
    //   191: aload_0
    //   192: aload #5
    //   194: invokevirtual saveFragmentBasicState : (Landroid/support/v4/app/Fragment;)Landroid/os/Bundle;
    //   197: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   200: aload #5
    //   202: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   205: ifnull -> 353
    //   208: aload #5
    //   210: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   213: getfield mIndex : I
    //   216: ifge -> 281
    //   219: new java/lang/StringBuilder
    //   222: dup
    //   223: invokespecial <init> : ()V
    //   226: astore #9
    //   228: aload #9
    //   230: ldc_w 'Failure saving state: '
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload #9
    //   239: aload #5
    //   241: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   244: pop
    //   245: aload #9
    //   247: ldc_w ' has target not in fragment manager: '
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload #9
    //   256: aload #5
    //   258: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   261: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   264: pop
    //   265: aload_0
    //   266: new java/lang/IllegalStateException
    //   269: dup
    //   270: aload #9
    //   272: invokevirtual toString : ()Ljava/lang/String;
    //   275: invokespecial <init> : (Ljava/lang/String;)V
    //   278: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   281: aload #6
    //   283: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   286: ifnonnull -> 301
    //   289: aload #6
    //   291: new android/os/Bundle
    //   294: dup
    //   295: invokespecial <init> : ()V
    //   298: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   301: aload_0
    //   302: aload #6
    //   304: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   307: ldc 'android:target_state'
    //   309: aload #5
    //   311: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   314: invokevirtual putFragment : (Landroid/os/Bundle;Ljava/lang/String;Landroid/support/v4/app/Fragment;)V
    //   317: aload #5
    //   319: getfield mTargetRequestCode : I
    //   322: ifeq -> 353
    //   325: aload #6
    //   327: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   330: ldc 'android:target_req_state'
    //   332: aload #5
    //   334: getfield mTargetRequestCode : I
    //   337: invokevirtual putInt : (Ljava/lang/String;I)V
    //   340: goto -> 353
    //   343: aload #6
    //   345: aload #5
    //   347: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   350: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   353: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   356: ifeq -> 416
    //   359: new java/lang/StringBuilder
    //   362: dup
    //   363: invokespecial <init> : ()V
    //   366: astore #9
    //   368: aload #9
    //   370: ldc_w 'Saved state of '
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #9
    //   379: aload #5
    //   381: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload #9
    //   387: ldc_w ': '
    //   390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   393: pop
    //   394: aload #9
    //   396: aload #6
    //   398: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   401: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   404: pop
    //   405: ldc 'FragmentManager'
    //   407: aload #9
    //   409: invokevirtual toString : ()Ljava/lang/String;
    //   412: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   415: pop
    //   416: iconst_1
    //   417: istore_2
    //   418: iload_1
    //   419: iconst_1
    //   420: iadd
    //   421: istore_1
    //   422: goto -> 62
    //   425: iload_2
    //   426: ifne -> 446
    //   429: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   432: ifeq -> 444
    //   435: ldc 'FragmentManager'
    //   437: ldc_w 'saveAllState: no fragments!'
    //   440: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   443: pop
    //   444: aconst_null
    //   445: areturn
    //   446: aload_0
    //   447: getfield mAdded : Ljava/util/ArrayList;
    //   450: astore #5
    //   452: aload #5
    //   454: ifnull -> 647
    //   457: aload #5
    //   459: invokevirtual size : ()I
    //   462: istore_2
    //   463: iload_2
    //   464: ifle -> 647
    //   467: iload_2
    //   468: newarray int
    //   470: astore #6
    //   472: iconst_0
    //   473: istore_1
    //   474: aload #6
    //   476: astore #5
    //   478: iload_1
    //   479: iload_2
    //   480: if_icmpge -> 650
    //   483: aload #6
    //   485: iload_1
    //   486: aload_0
    //   487: getfield mAdded : Ljava/util/ArrayList;
    //   490: iload_1
    //   491: invokevirtual get : (I)Ljava/lang/Object;
    //   494: checkcast android/support/v4/app/Fragment
    //   497: getfield mIndex : I
    //   500: iastore
    //   501: aload #6
    //   503: iload_1
    //   504: iaload
    //   505: ifge -> 575
    //   508: new java/lang/StringBuilder
    //   511: dup
    //   512: invokespecial <init> : ()V
    //   515: astore #5
    //   517: aload #5
    //   519: ldc_w 'Failure saving state: active '
    //   522: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   525: pop
    //   526: aload #5
    //   528: aload_0
    //   529: getfield mAdded : Ljava/util/ArrayList;
    //   532: iload_1
    //   533: invokevirtual get : (I)Ljava/lang/Object;
    //   536: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   539: pop
    //   540: aload #5
    //   542: ldc_w ' has cleared index: '
    //   545: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   548: pop
    //   549: aload #5
    //   551: aload #6
    //   553: iload_1
    //   554: iaload
    //   555: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   558: pop
    //   559: aload_0
    //   560: new java/lang/IllegalStateException
    //   563: dup
    //   564: aload #5
    //   566: invokevirtual toString : ()Ljava/lang/String;
    //   569: invokespecial <init> : (Ljava/lang/String;)V
    //   572: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   575: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   578: ifeq -> 640
    //   581: new java/lang/StringBuilder
    //   584: dup
    //   585: invokespecial <init> : ()V
    //   588: astore #5
    //   590: aload #5
    //   592: ldc_w 'saveAllState: adding fragment #'
    //   595: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   598: pop
    //   599: aload #5
    //   601: iload_1
    //   602: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   605: pop
    //   606: aload #5
    //   608: ldc_w ': '
    //   611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   614: pop
    //   615: aload #5
    //   617: aload_0
    //   618: getfield mAdded : Ljava/util/ArrayList;
    //   621: iload_1
    //   622: invokevirtual get : (I)Ljava/lang/Object;
    //   625: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   628: pop
    //   629: ldc 'FragmentManager'
    //   631: aload #5
    //   633: invokevirtual toString : ()Ljava/lang/String;
    //   636: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   639: pop
    //   640: iload_1
    //   641: iconst_1
    //   642: iadd
    //   643: istore_1
    //   644: goto -> 474
    //   647: aconst_null
    //   648: astore #5
    //   650: aload_0
    //   651: getfield mBackStack : Ljava/util/ArrayList;
    //   654: astore #9
    //   656: aload #7
    //   658: astore #6
    //   660: aload #9
    //   662: ifnull -> 791
    //   665: aload #9
    //   667: invokevirtual size : ()I
    //   670: istore_2
    //   671: aload #7
    //   673: astore #6
    //   675: iload_2
    //   676: ifle -> 791
    //   679: iload_2
    //   680: anewarray android/support/v4/app/BackStackState
    //   683: astore #7
    //   685: iload_3
    //   686: istore_1
    //   687: aload #7
    //   689: astore #6
    //   691: iload_1
    //   692: iload_2
    //   693: if_icmpge -> 791
    //   696: aload #7
    //   698: iload_1
    //   699: new android/support/v4/app/BackStackState
    //   702: dup
    //   703: aload_0
    //   704: aload_0
    //   705: getfield mBackStack : Ljava/util/ArrayList;
    //   708: iload_1
    //   709: invokevirtual get : (I)Ljava/lang/Object;
    //   712: checkcast android/support/v4/app/BackStackRecord
    //   715: invokespecial <init> : (Landroid/support/v4/app/FragmentManagerImpl;Landroid/support/v4/app/BackStackRecord;)V
    //   718: aastore
    //   719: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   722: ifeq -> 784
    //   725: new java/lang/StringBuilder
    //   728: dup
    //   729: invokespecial <init> : ()V
    //   732: astore #6
    //   734: aload #6
    //   736: ldc_w 'saveAllState: adding back stack #'
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #6
    //   745: iload_1
    //   746: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #6
    //   752: ldc_w ': '
    //   755: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   758: pop
    //   759: aload #6
    //   761: aload_0
    //   762: getfield mBackStack : Ljava/util/ArrayList;
    //   765: iload_1
    //   766: invokevirtual get : (I)Ljava/lang/Object;
    //   769: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   772: pop
    //   773: ldc 'FragmentManager'
    //   775: aload #6
    //   777: invokevirtual toString : ()Ljava/lang/String;
    //   780: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   783: pop
    //   784: iload_1
    //   785: iconst_1
    //   786: iadd
    //   787: istore_1
    //   788: goto -> 687
    //   791: new android/support/v4/app/FragmentManagerState
    //   794: dup
    //   795: invokespecial <init> : ()V
    //   798: astore #7
    //   800: aload #7
    //   802: aload #8
    //   804: putfield mActive : [Landroid/support/v4/app/FragmentState;
    //   807: aload #7
    //   809: aload #5
    //   811: putfield mAdded : [I
    //   814: aload #7
    //   816: aload #6
    //   818: putfield mBackStack : [Landroid/support/v4/app/BackStackState;
    //   821: aload #7
    //   823: areturn
    //   824: aconst_null
    //   825: areturn
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    if (!this.mStateBundle.isEmpty()) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } else {
      bundle2 = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    Bundle bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    int i = paramFragment.mState;
    Fragment.SavedState savedState2 = null;
    Fragment.SavedState savedState1 = savedState2;
    if (i > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.mStateArray;
    if (sparseArray == null) {
      this.mStateArray = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
    if (this.mStateArray.size() > 0) {
      paramFragment.mSavedViewState = this.mStateArray;
      this.mStateArray = null;
    } 
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 109
    //   38: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 96
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #5
    //   53: aload #5
    //   55: ldc_w 'Setting back stack index '
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #5
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: ldc_w ' to '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc 'FragmentManager'
    //   87: aload #5
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   100: iload_1
    //   101: aload_2
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: goto -> 269
    //   109: iload_3
    //   110: iload_1
    //   111: if_icmpge -> 202
    //   114: aload_0
    //   115: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   118: aconst_null
    //   119: invokevirtual add : (Ljava/lang/Object;)Z
    //   122: pop
    //   123: aload_0
    //   124: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   127: ifnonnull -> 141
    //   130: aload_0
    //   131: new java/util/ArrayList
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   141: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   144: ifeq -> 183
    //   147: new java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: astore #5
    //   156: aload #5
    //   158: ldc_w 'Adding available back stack index '
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload #5
    //   167: iload_3
    //   168: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: ldc 'FragmentManager'
    //   174: aload #5
    //   176: invokevirtual toString : ()Ljava/lang/String;
    //   179: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   182: pop
    //   183: aload_0
    //   184: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   187: iload_3
    //   188: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   191: invokevirtual add : (Ljava/lang/Object;)Z
    //   194: pop
    //   195: iload_3
    //   196: iconst_1
    //   197: iadd
    //   198: istore_3
    //   199: goto -> 109
    //   202: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   205: ifeq -> 260
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore #5
    //   217: aload #5
    //   219: ldc_w 'Adding back stack index '
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload #5
    //   228: iload_1
    //   229: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #5
    //   235: ldc_w ' with '
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload #5
    //   244: aload_2
    //   245: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   248: pop
    //   249: ldc 'FragmentManager'
    //   251: aload #5
    //   253: invokevirtual toString : ()Ljava/lang/String;
    //   256: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   259: pop
    //   260: aload_0
    //   261: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   264: aload_2
    //   265: invokevirtual add : (Ljava/lang/Object;)Z
    //   268: pop
    //   269: aload_0
    //   270: monitorexit
    //   271: return
    //   272: astore_2
    //   273: aload_0
    //   274: monitorexit
    //   275: aload_2
    //   276: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	272	finally
    //   20	29	272	finally
    //   38	96	272	finally
    //   96	106	272	finally
    //   114	141	272	finally
    //   141	183	272	finally
    //   183	195	272	finally
    //   202	260	272	finally
    //   260	269	272	finally
    //   269	271	272	finally
    //   273	275	272	finally
  }
  
  public void showFragment(Fragment paramFragment, int paramInt1, int paramInt2) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      if (paramFragment.mView != null) {
        Animation animation = loadAnimation(paramFragment, paramInt1, true, paramInt2);
        if (animation != null)
          paramFragment.mView.startAnimation(animation); 
        paramFragment.mView.setVisibility(0);
      } 
      if (paramFragment.mAdded && paramFragment.mHasMenu && paramFragment.mMenuVisible)
        this.mNeedMenuInvalidate = true; 
      paramFragment.onHiddenChanged(false);
    } 
  }
  
  void startPendingDeferredFragments() {
    if (this.mActive == null)
      return; 
    for (int i = 0; i < this.mActive.size(); i++) {
      Fragment fragment = this.mActive.get(i);
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      DebugUtils.buildShortClassTag(fragment, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.mActivity, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */