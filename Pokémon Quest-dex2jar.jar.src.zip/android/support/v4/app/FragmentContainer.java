package android.support.v4.app;

import android.view.View;

interface FragmentContainer {
  View findViewById(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\app\FragmentContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */