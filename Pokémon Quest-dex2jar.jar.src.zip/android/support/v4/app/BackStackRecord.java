package android.support.v4.app;

import android.support.v4.util.LogWriter;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

final class BackStackRecord extends FragmentTransaction implements FragmentManager.BackStackEntry, Runnable {
  static final int OP_ADD = 1;
  
  static final int OP_ATTACH = 7;
  
  static final int OP_DETACH = 6;
  
  static final int OP_HIDE = 4;
  
  static final int OP_NULL = 0;
  
  static final int OP_REMOVE = 3;
  
  static final int OP_REPLACE = 2;
  
  static final int OP_SHOW = 5;
  
  static final String TAG = "FragmentManager";
  
  boolean mAddToBackStack;
  
  boolean mAllowAddToBackStack = true;
  
  int mBreadCrumbShortTitleRes;
  
  CharSequence mBreadCrumbShortTitleText;
  
  int mBreadCrumbTitleRes;
  
  CharSequence mBreadCrumbTitleText;
  
  boolean mCommitted;
  
  int mEnterAnim;
  
  int mExitAnim;
  
  Op mHead;
  
  int mIndex = -1;
  
  final FragmentManagerImpl mManager;
  
  String mName;
  
  int mNumOp;
  
  int mPopEnterAnim;
  
  int mPopExitAnim;
  
  Op mTail;
  
  int mTransition;
  
  int mTransitionStyle;
  
  public BackStackRecord(FragmentManagerImpl paramFragmentManagerImpl) {
    this.mManager = paramFragmentManagerImpl;
  }
  
  private void doAddOp(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    paramFragment.mFragmentManager = this.mManager;
    if (paramString != null)
      if (paramFragment.mTag == null || paramString.equals(paramFragment.mTag)) {
        paramFragment.mTag = paramString;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Can't change tag of fragment ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(": was ");
        stringBuilder.append(paramFragment.mTag);
        stringBuilder.append(" now ");
        stringBuilder.append(paramString);
        throw new IllegalStateException(stringBuilder.toString());
      }  
    if (paramInt1 != 0)
      if (paramFragment.mFragmentId == 0 || paramFragment.mFragmentId == paramInt1) {
        paramFragment.mFragmentId = paramInt1;
        paramFragment.mContainerId = paramInt1;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Can't change container ID of fragment ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(": was ");
        stringBuilder.append(paramFragment.mFragmentId);
        stringBuilder.append(" now ");
        stringBuilder.append(paramInt1);
        throw new IllegalStateException(stringBuilder.toString());
      }  
    Op op = new Op();
    op.cmd = paramInt2;
    op.fragment = paramFragment;
    addOp(op);
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment) {
    doAddOp(paramInt, paramFragment, null, 1);
    return this;
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment, String paramString) {
    doAddOp(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public FragmentTransaction add(Fragment paramFragment, String paramString) {
    doAddOp(0, paramFragment, paramString, 1);
    return this;
  }
  
  void addOp(Op paramOp) {
    if (this.mHead == null) {
      this.mTail = paramOp;
      this.mHead = paramOp;
    } else {
      Op op = this.mTail;
      paramOp.prev = op;
      op.next = paramOp;
      this.mTail = paramOp;
    } 
    paramOp.enterAnim = this.mEnterAnim;
    paramOp.exitAnim = this.mExitAnim;
    paramOp.popEnterAnim = this.mPopEnterAnim;
    paramOp.popExitAnim = this.mPopExitAnim;
    this.mNumOp++;
  }
  
  public FragmentTransaction addToBackStack(String paramString) {
    if (this.mAllowAddToBackStack) {
      this.mAddToBackStack = true;
      this.mName = paramString;
      return this;
    } 
    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
  }
  
  public FragmentTransaction attach(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 7;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  void bumpBackStackNesting(int paramInt) {
    if (!this.mAddToBackStack)
      return; 
    if (FragmentManagerImpl.DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    for (Op op = this.mHead; op != null; op = op.next) {
      if (op.fragment != null) {
        Fragment fragment = op.fragment;
        fragment.mBackStackNesting += paramInt;
        if (FragmentManagerImpl.DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(op.fragment);
          stringBuilder.append(" to ");
          stringBuilder.append(op.fragment.mBackStackNesting);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
      if (op.removed != null)
        for (int i = op.removed.size() - 1; i >= 0; i--) {
          Fragment fragment = op.removed.get(i);
          fragment.mBackStackNesting += paramInt;
          if (FragmentManagerImpl.DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Bump nesting of ");
            stringBuilder.append(fragment);
            stringBuilder.append(" to ");
            stringBuilder.append(fragment.mBackStackNesting);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        }  
    } 
  }
  
  public int commit() {
    return commitInternal(false);
  }
  
  public int commitAllowingStateLoss() {
    return commitInternal(true);
  }
  
  int commitInternal(boolean paramBoolean) {
    if (!this.mCommitted) {
      if (FragmentManagerImpl.DEBUG) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        dump("  ", null, new PrintWriter((Writer)new LogWriter("FragmentManager")), null);
      } 
      this.mCommitted = true;
      if (this.mAddToBackStack) {
        this.mIndex = this.mManager.allocBackStackIndex(this);
      } else {
        this.mIndex = -1;
      } 
      this.mManager.enqueueAction(this, paramBoolean);
      return this.mIndex;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public FragmentTransaction detach(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 6;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public FragmentTransaction disallowAddToBackStack() {
    if (!this.mAddToBackStack) {
      this.mAllowAddToBackStack = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    dump(paramString, paramPrintWriter, true);
  }
  
  public void dump(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.mName);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.mIndex);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.mCommitted);
      if (this.mTransition != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.mTransition));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.mTransitionStyle));
      } 
      if (this.mEnterAnim != 0 || this.mExitAnim != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.mEnterAnim));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.mExitAnim));
      } 
      if (this.mPopEnterAnim != 0 || this.mPopExitAnim != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.mPopEnterAnim));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.mPopExitAnim));
      } 
      if (this.mBreadCrumbTitleRes != 0 || this.mBreadCrumbTitleText != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.mBreadCrumbTitleRes));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.mBreadCrumbTitleText);
      } 
      if (this.mBreadCrumbShortTitleRes != 0 || this.mBreadCrumbShortTitleText != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.mBreadCrumbShortTitleRes));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.mBreadCrumbShortTitleText);
      } 
    } 
    if (this.mHead != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("    ");
      String str = stringBuilder.toString();
      Op op = this.mHead;
      int i;
      for (i = 0; op != null; i++) {
        String str1;
        switch (op.cmd) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(op.cmd);
            str1 = stringBuilder.toString();
            break;
          case 7:
            str1 = "ATTACH";
            break;
          case 6:
            str1 = "DETACH";
            break;
          case 5:
            str1 = "SHOW";
            break;
          case 4:
            str1 = "HIDE";
            break;
          case 3:
            str1 = "REMOVE";
            break;
          case 2:
            str1 = "REPLACE";
            break;
          case 1:
            str1 = "ADD";
            break;
          case 0:
            str1 = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str1);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(op.fragment);
        if (paramBoolean) {
          if (op.enterAnim != 0 || op.exitAnim != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(op.enterAnim));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(op.exitAnim));
          } 
          if (op.popEnterAnim != 0 || op.popExitAnim != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(op.popEnterAnim));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(op.popExitAnim));
          } 
        } 
        if (op.removed != null && op.removed.size() > 0) {
          int j;
          for (j = 0; j < op.removed.size(); j++) {
            paramPrintWriter.print(str);
            if (op.removed.size() == 1) {
              paramPrintWriter.print("Removed: ");
            } else {
              if (j == 0)
                paramPrintWriter.println("Removed:"); 
              paramPrintWriter.print(str);
              paramPrintWriter.print("  #");
              paramPrintWriter.print(j);
              paramPrintWriter.print(": ");
            } 
            paramPrintWriter.println(op.removed.get(j));
          } 
        } 
        op = op.next;
      } 
    } 
  }
  
  public CharSequence getBreadCrumbShortTitle() {
    return (this.mBreadCrumbShortTitleRes != 0) ? this.mManager.mActivity.getText(this.mBreadCrumbShortTitleRes) : this.mBreadCrumbShortTitleText;
  }
  
  public int getBreadCrumbShortTitleRes() {
    return this.mBreadCrumbShortTitleRes;
  }
  
  public CharSequence getBreadCrumbTitle() {
    return (this.mBreadCrumbTitleRes != 0) ? this.mManager.mActivity.getText(this.mBreadCrumbTitleRes) : this.mBreadCrumbTitleText;
  }
  
  public int getBreadCrumbTitleRes() {
    return this.mBreadCrumbTitleRes;
  }
  
  public int getId() {
    return this.mIndex;
  }
  
  public String getName() {
    return this.mName;
  }
  
  public int getTransition() {
    return this.mTransition;
  }
  
  public int getTransitionStyle() {
    return this.mTransitionStyle;
  }
  
  public FragmentTransaction hide(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 4;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public boolean isAddToBackStackAllowed() {
    return this.mAllowAddToBackStack;
  }
  
  public boolean isEmpty() {
    return (this.mNumOp == 0);
  }
  
  public void popFromBackStack(boolean paramBoolean) {
    if (FragmentManagerImpl.DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("popFromBackStack: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
      dump("  ", null, new PrintWriter((Writer)new LogWriter("FragmentManager")), null);
    } 
    bumpBackStackNesting(-1);
    for (Op op = this.mTail; op != null; op = op.prev) {
      StringBuilder stringBuilder;
      Fragment fragment;
      switch (op.cmd) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(op.cmd);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 7:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.detachFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          break;
        case 6:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.attachFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          break;
        case 5:
          fragment = op.fragment;
          fragment.mNextAnim = op.popExitAnim;
          this.mManager.hideFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          break;
        case 4:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.showFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          break;
        case 3:
          fragment = op.fragment;
          fragment.mNextAnim = op.popEnterAnim;
          this.mManager.addFragment(fragment, false);
          break;
        case 2:
          fragment = op.fragment;
          if (fragment != null) {
            fragment.mNextAnim = op.popExitAnim;
            this.mManager.removeFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          } 
          if (op.removed != null)
            for (int j = 0; j < op.removed.size(); j++) {
              fragment = op.removed.get(j);
              fragment.mNextAnim = op.popEnterAnim;
              this.mManager.addFragment(fragment, false);
            }  
          break;
        case 1:
          fragment = op.fragment;
          fragment.mNextAnim = op.popExitAnim;
          this.mManager.removeFragment(fragment, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
          break;
      } 
    } 
    if (paramBoolean) {
      FragmentManagerImpl fragmentManagerImpl = this.mManager;
      fragmentManagerImpl.moveToState(fragmentManagerImpl.mCurState, FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle, true);
    } 
    int i = this.mIndex;
    if (i >= 0) {
      this.mManager.freeBackStackIndex(i);
      this.mIndex = -1;
    } 
  }
  
  public FragmentTransaction remove(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 3;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment) {
    return replace(paramInt, paramFragment, null);
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt != 0) {
      doAddOp(paramInt, paramFragment, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public void run() {
    if (FragmentManagerImpl.DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!this.mAddToBackStack || this.mIndex >= 0) {
      bumpBackStackNesting(1);
      for (Op op = this.mHead; op != null; op = op.next) {
        StringBuilder stringBuilder;
        Fragment fragment1;
        Fragment fragment2;
        switch (op.cmd) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown cmd: ");
            stringBuilder.append(op.cmd);
            throw new IllegalArgumentException(stringBuilder.toString());
          case 7:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.enterAnim;
            this.mManager.attachFragment(fragment1, this.mTransition, this.mTransitionStyle);
            break;
          case 6:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.exitAnim;
            this.mManager.detachFragment(fragment1, this.mTransition, this.mTransitionStyle);
            break;
          case 5:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.enterAnim;
            this.mManager.showFragment(fragment1, this.mTransition, this.mTransitionStyle);
            break;
          case 4:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.exitAnim;
            this.mManager.hideFragment(fragment1, this.mTransition, this.mTransitionStyle);
            break;
          case 3:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.exitAnim;
            this.mManager.removeFragment(fragment1, this.mTransition, this.mTransitionStyle);
            break;
          case 2:
            fragment1 = op.fragment;
            fragment2 = fragment1;
          case 1:
            fragment1 = op.fragment;
            fragment1.mNextAnim = op.enterAnim;
            this.mManager.addFragment(fragment1, false);
            break;
        } 
        continue;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mManager;
      fragmentManagerImpl.moveToState(fragmentManagerImpl.mCurState, this.mTransition, this.mTransitionStyle, true);
      if (this.mAddToBackStack)
        this.mManager.addBackStackState(this); 
      return;
    } 
    throw new IllegalStateException("addToBackStack() called after commit()");
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(int paramInt) {
    this.mBreadCrumbShortTitleRes = paramInt;
    this.mBreadCrumbShortTitleText = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(CharSequence paramCharSequence) {
    this.mBreadCrumbShortTitleRes = 0;
    this.mBreadCrumbShortTitleText = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(int paramInt) {
    this.mBreadCrumbTitleRes = paramInt;
    this.mBreadCrumbTitleText = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(CharSequence paramCharSequence) {
    this.mBreadCrumbTitleRes = 0;
    this.mBreadCrumbTitleText = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2) {
    return setCustomAnimations(paramInt1, paramInt2, 0, 0);
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mEnterAnim = paramInt1;
    this.mExitAnim = paramInt2;
    this.mPopEnterAnim = paramInt3;
    this.mPopExitAnim = paramInt4;
    return this;
  }
  
  public FragmentTransaction setTransition(int paramInt) {
    this.mTransition = paramInt;
    return this;
  }
  
  public FragmentTransaction setTransitionStyle(int paramInt) {
    this.mTransitionStyle = paramInt;
    return this;
  }
  
  public FragmentTransaction show(Fragment paramFragment) {
    Op op = new Op();
    op.cmd = 5;
    op.fragment = paramFragment;
    addOp(op);
    return this;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.mIndex >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.mIndex);
    } 
    if (this.mName != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.mName);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class Op {
    int cmd;
    
    int enterAnim;
    
    int exitAnim;
    
    Fragment fragment;
    
    Op next;
    
    int popEnterAnim;
    
    int popExitAnim;
    
    Op prev;
    
    ArrayList<Fragment> removed;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\app\BackStackRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */