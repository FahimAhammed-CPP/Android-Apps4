package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.util.SimpleArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FragmentActivity extends Activity {
  static final String FRAGMENTS_TAG = "android:support:fragments";
  
  private static final int HONEYCOMB = 11;
  
  static final int MSG_REALLY_STOPPED = 1;
  
  static final int MSG_RESUME_PENDING = 2;
  
  private static final String TAG = "FragmentActivity";
  
  SimpleArrayMap<String, LoaderManagerImpl> mAllLoaderManagers;
  
  boolean mCheckedForLoaderManager;
  
  final FragmentContainer mContainer = new FragmentContainer() {
      public View findViewById(int param1Int) {
        return FragmentActivity.this.findViewById(param1Int);
      }
    };
  
  boolean mCreated;
  
  final FragmentManagerImpl mFragments = new FragmentManagerImpl();
  
  final Handler mHandler = new Handler() {
      public void handleMessage(Message param1Message) {
        int i = param1Message.what;
        if (i != 1) {
          if (i != 2) {
            super.handleMessage(param1Message);
            return;
          } 
          FragmentActivity.this.onResumeFragments();
          FragmentActivity.this.mFragments.execPendingActions();
          return;
        } 
        if (FragmentActivity.this.mStopped)
          FragmentActivity.this.doReallyStop(false); 
      }
    };
  
  LoaderManagerImpl mLoaderManager;
  
  boolean mLoadersStarted;
  
  boolean mOptionsMenuInvalidated;
  
  boolean mReallyStopped;
  
  boolean mResumed;
  
  boolean mRetaining;
  
  boolean mStopped;
  
  private void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, View paramView) {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
      return;
    } 
    paramPrintWriter.println(viewToString(paramView));
    if (!(paramView instanceof ViewGroup))
      return; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int j = viewGroup.getChildCount();
    if (j <= 0)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    paramString = stringBuilder.toString();
    int i;
    for (i = 0; i < j; i++)
      dumpViewHierarchy(paramString, paramPrintWriter, viewGroup.getChildAt(i)); 
  }
  
  private static String viewToString(View paramView) {
    String str1;
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(paramView.getClass().getName());
    stringBuilder.append('{');
    stringBuilder.append(Integer.toHexString(System.identityHashCode(paramView)));
    stringBuilder.append(' ');
    int i = paramView.getVisibility();
    byte b4 = 86;
    byte b2 = 46;
    if (i != 0) {
      if (i != 4) {
        if (i != 8) {
          stringBuilder.append('.');
        } else {
          stringBuilder.append('G');
        } 
      } else {
        stringBuilder.append('I');
      } 
    } else {
      stringBuilder.append('V');
    } 
    boolean bool = paramView.isFocusable();
    byte b3 = 70;
    if (bool) {
      b1 = 70;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.isEnabled()) {
      b1 = 69;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.willNotDraw()) {
      b1 = 46;
    } else {
      b1 = 68;
    } 
    stringBuilder.append(b1);
    if (paramView.isHorizontalScrollBarEnabled()) {
      b1 = 72;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.isVerticalScrollBarEnabled()) {
      b1 = b4;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.isClickable()) {
      b1 = 67;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.isLongClickable()) {
      b1 = 76;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    stringBuilder.append(' ');
    if (paramView.isFocused()) {
      b1 = b3;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    if (paramView.isSelected()) {
      b1 = 83;
    } else {
      b1 = 46;
    } 
    stringBuilder.append(b1);
    byte b1 = b2;
    if (paramView.isPressed())
      b1 = 80; 
    stringBuilder.append(b1);
    stringBuilder.append(' ');
    stringBuilder.append(paramView.getLeft());
    stringBuilder.append(',');
    stringBuilder.append(paramView.getTop());
    stringBuilder.append('-');
    stringBuilder.append(paramView.getRight());
    stringBuilder.append(',');
    stringBuilder.append(paramView.getBottom());
    i = paramView.getId();
    if (i != -1) {
      stringBuilder.append(" #");
      stringBuilder.append(Integer.toHexString(i));
      Resources resources = paramView.getResources();
      if (i != 0 && resources != null) {
        int j = 0xFF000000 & i;
        if (j != 16777216) {
          if (j != 2130706432) {
            try {
              String str4 = resources.getResourcePackageName(i);
              String str5 = resources.getResourceTypeName(i);
              str2 = resources.getResourceEntryName(i);
              stringBuilder.append(" ");
              stringBuilder.append(str4);
              stringBuilder.append(":");
              stringBuilder.append(str5);
              stringBuilder.append("/");
              stringBuilder.append(str2);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            stringBuilder.append("}");
            return stringBuilder.toString();
          } 
          str1 = "app";
        } else {
          str1 = "android";
        } 
      } else {
        stringBuilder.append("}");
        return stringBuilder.toString();
      } 
    } else {
      stringBuilder.append("}");
      return stringBuilder.toString();
    } 
    String str3 = str2.getResourceTypeName(i);
    String str2 = str2.getResourceEntryName(i);
    stringBuilder.append(" ");
    stringBuilder.append(str1);
    stringBuilder.append(":");
    stringBuilder.append(str3);
    stringBuilder.append("/");
    stringBuilder.append(str2);
  }
  
  void doReallyStop(boolean paramBoolean) {
    if (!this.mReallyStopped) {
      this.mReallyStopped = true;
      this.mRetaining = paramBoolean;
      this.mHandler.removeMessages(1);
      onReallyStop();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    int i = Build.VERSION.SDK_INT;
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("  ");
    String str = stringBuilder2.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.mCreated);
    paramPrintWriter.print("mResumed=");
    paramPrintWriter.print(this.mResumed);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.mStopped);
    paramPrintWriter.print(" mReallyStopped=");
    paramPrintWriter.println(this.mReallyStopped);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mLoadersStarted=");
    paramPrintWriter.println(this.mLoadersStarted);
    if (this.mLoaderManager != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Loader Manager ");
      paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this.mLoaderManager)));
      paramPrintWriter.println(":");
      LoaderManagerImpl loaderManagerImpl = this.mLoaderManager;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("  ");
      loaderManagerImpl.dump(stringBuilder.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    } 
    this.mFragments.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("View Hierarchy:");
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append("  ");
    dumpViewHierarchy(stringBuilder1.toString(), paramPrintWriter, getWindow().getDecorView());
  }
  
  public Object getLastCustomNonConfigurationInstance() {
    NonConfigurationInstances nonConfigurationInstances = (NonConfigurationInstances)getLastNonConfigurationInstance();
    return (nonConfigurationInstances != null) ? nonConfigurationInstances.custom : null;
  }
  
  LoaderManagerImpl getLoaderManager(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    if (this.mAllLoaderManagers == null)
      this.mAllLoaderManagers = new SimpleArrayMap(); 
    LoaderManagerImpl loaderManagerImpl = (LoaderManagerImpl)this.mAllLoaderManagers.get(paramString);
    if (loaderManagerImpl == null) {
      if (paramBoolean2) {
        loaderManagerImpl = new LoaderManagerImpl(paramString, this, paramBoolean1);
        this.mAllLoaderManagers.put(paramString, loaderManagerImpl);
        return loaderManagerImpl;
      } 
    } else {
      loaderManagerImpl.updateActivity(this);
    } 
    return loaderManagerImpl;
  }
  
  public FragmentManager getSupportFragmentManager() {
    return this.mFragments;
  }
  
  public LoaderManager getSupportLoaderManager() {
    LoaderManagerImpl loaderManagerImpl = this.mLoaderManager;
    if (loaderManagerImpl != null)
      return loaderManagerImpl; 
    this.mCheckedForLoaderManager = true;
    this.mLoaderManager = getLoaderManager("(root)", this.mLoadersStarted, true);
    return this.mLoaderManager;
  }
  
  void invalidateSupportFragment(String paramString) {
    SimpleArrayMap<String, LoaderManagerImpl> simpleArrayMap = this.mAllLoaderManagers;
    if (simpleArrayMap != null) {
      LoaderManagerImpl loaderManagerImpl = (LoaderManagerImpl)simpleArrayMap.get(paramString);
      if (loaderManagerImpl != null && !loaderManagerImpl.mRetaining) {
        loaderManagerImpl.doDestroy();
        this.mAllLoaderManagers.remove(paramString);
      } 
    } 
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    this.mFragments.noteStateNotSaved();
    int i = paramInt1 >> 16;
    if (i != 0) {
      if (this.mFragments.mActive == null || --i < 0 || i >= this.mFragments.mActive.size()) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result fragment index out of range: 0x");
        stringBuilder.append(Integer.toHexString(paramInt1));
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      Fragment fragment = this.mFragments.mActive.get(i);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for index: 0x");
        stringBuilder.append(Integer.toHexString(paramInt1));
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(paramInt1 & 0xFFFF, paramInt2, (Intent)stringBuilder);
      return;
    } 
    super.onActivityResult(paramInt1, paramInt2, (Intent)stringBuilder);
  }
  
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onBackPressed() {
    if (!this.mFragments.popBackStackImmediate())
      finish(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.mFragments.dispatchConfigurationChanged(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    FragmentManagerImpl fragmentManagerImpl = this.mFragments;
    FragmentContainer fragmentContainer = this.mContainer;
    Bundle bundle = null;
    fragmentManagerImpl.attachActivity(this, fragmentContainer, null);
    if (getLayoutInflater().getFactory() == null)
      getLayoutInflater().setFactory((LayoutInflater.Factory)this); 
    super.onCreate(paramBundle);
    NonConfigurationInstances nonConfigurationInstances = (NonConfigurationInstances)getLastNonConfigurationInstance();
    if (nonConfigurationInstances != null)
      this.mAllLoaderManagers = nonConfigurationInstances.loaders; 
    if (paramBundle != null) {
      ArrayList<Fragment> arrayList;
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      FragmentManagerImpl fragmentManagerImpl1 = this.mFragments;
      paramBundle = bundle;
      if (nonConfigurationInstances != null)
        arrayList = nonConfigurationInstances.fragments; 
      fragmentManagerImpl1.restoreAllState(parcelable, arrayList);
    } 
    this.mFragments.dispatchCreate();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      boolean bool1 = super.onCreatePanelMenu(paramInt, paramMenu);
      boolean bool2 = this.mFragments.dispatchCreateOptionsMenu(paramMenu, getMenuInflater());
      return (Build.VERSION.SDK_INT >= 11) ? (bool1 | bool2) : true;
    } 
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return super.onCreateView(paramString, paramContext, paramAttributeSet); 
    Context context = null;
    String str2 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    int i = typedArray.getResourceId(1, -1);
    str2 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass((Context)this, str1))
      return super.onCreateView(paramString, paramContext, paramAttributeSet); 
    paramContext = context;
    if (i != -1)
      fragment2 = this.mFragments.findFragmentById(i); 
    Fragment fragment1 = fragment2;
    if (fragment2 == null) {
      fragment1 = fragment2;
      if (str2 != null)
        fragment1 = this.mFragments.findFragmentByTag(str2); 
    } 
    Fragment fragment2 = fragment1;
    if (fragment1 == null)
      fragment2 = this.mFragments.findFragmentById(0); 
    if (FragmentManagerImpl.DEBUG) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("onCreateView: id=0x");
      stringBuilder1.append(Integer.toHexString(i));
      stringBuilder1.append(" fname=");
      stringBuilder1.append(str1);
      stringBuilder1.append(" existing=");
      stringBuilder1.append(fragment2);
      Log.v("FragmentActivity", stringBuilder1.toString());
    } 
    if (fragment2 == null) {
      boolean bool;
      fragment2 = Fragment.instantiate((Context)this, str1);
      fragment2.mFromLayout = true;
      if (i != 0) {
        bool = i;
      } else {
        bool = false;
      } 
      fragment2.mFragmentId = bool;
      fragment2.mContainerId = 0;
      fragment2.mTag = str2;
      fragment2.mInLayout = true;
      fragment2.mFragmentManager = this.mFragments;
      fragment2.onInflate(this, paramAttributeSet, fragment2.mSavedFragmentState);
      this.mFragments.addFragment(fragment2, true);
    } else if (!fragment2.mInLayout) {
      fragment2.mInLayout = true;
      if (!fragment2.mRetaining)
        fragment2.onInflate(this, paramAttributeSet, fragment2.mSavedFragmentState); 
      this.mFragments.moveToState(fragment2);
    } else {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramAttributeSet.getPositionDescription());
      stringBuilder1.append(": Duplicate id 0x");
      stringBuilder1.append(Integer.toHexString(i));
      stringBuilder1.append(", tag ");
      stringBuilder1.append(str2);
      stringBuilder1.append(", or parent id 0x");
      stringBuilder1.append(Integer.toHexString(0));
      stringBuilder1.append(" with another fragment for ");
      stringBuilder1.append(str1);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    if (fragment2.mView != null) {
      if (i != 0)
        fragment2.mView.setId(i); 
      if (fragment2.mView.getTag() == null)
        fragment2.mView.setTag(str2); 
      return fragment2.mView;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(str1);
    stringBuilder.append(" did not create a view.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected void onDestroy() {
    super.onDestroy();
    doReallyStop(false);
    this.mFragments.dispatchDestroy();
    LoaderManagerImpl loaderManagerImpl = this.mLoaderManager;
    if (loaderManagerImpl != null)
      loaderManagerImpl.doDestroy(); 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 5 && paramInt == 4 && paramKeyEvent.getRepeatCount() == 0) {
      onBackPressed();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.mFragments.dispatchLowMemory();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.mFragments.dispatchContextItemSelected(paramMenuItem)) : this.mFragments.dispatchOptionsItemSelected(paramMenuItem));
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.mFragments.noteStateNotSaved();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.mFragments.dispatchOptionsMenuClosed(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.mResumed = false;
    if (this.mHandler.hasMessages(2)) {
      this.mHandler.removeMessages(2);
      onResumeFragments();
    } 
    this.mFragments.dispatchPause();
  }
  
  protected void onPostResume() {
    super.onPostResume();
    this.mHandler.removeMessages(2);
    onResumeFragments();
    this.mFragments.execPendingActions();
  }
  
  protected boolean onPrepareOptionsPanel(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0 && paramMenu != null) {
      if (this.mOptionsMenuInvalidated) {
        this.mOptionsMenuInvalidated = false;
        paramMenu.clear();
        onCreatePanelMenu(paramInt, paramMenu);
      } 
      return onPrepareOptionsPanel(paramView, paramMenu) | this.mFragments.dispatchPrepareOptionsMenu(paramMenu);
    } 
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  void onReallyStop() {
    if (this.mLoadersStarted) {
      this.mLoadersStarted = false;
      LoaderManagerImpl loaderManagerImpl = this.mLoaderManager;
      if (loaderManagerImpl != null)
        if (!this.mRetaining) {
          loaderManagerImpl.doStop();
        } else {
          loaderManagerImpl.doRetain();
        }  
    } 
    this.mFragments.dispatchReallyStop();
  }
  
  protected void onResume() {
    super.onResume();
    this.mHandler.sendEmptyMessage(2);
    this.mResumed = true;
    this.mFragments.execPendingActions();
  }
  
  protected void onResumeFragments() {
    this.mFragments.dispatchResume();
  }
  
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    if (this.mStopped)
      doReallyStop(true); 
    Object object = onRetainCustomNonConfigurationInstance();
    ArrayList<Fragment> arrayList = this.mFragments.retainNonConfig();
    SimpleArrayMap<String, LoaderManagerImpl> simpleArrayMap = this.mAllLoaderManagers;
    int i = 0;
    int j = 0;
    if (simpleArrayMap != null) {
      int k = simpleArrayMap.size();
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[k];
      for (i = k - 1; i >= 0; i--)
        arrayOfLoaderManagerImpl[i] = (LoaderManagerImpl)this.mAllLoaderManagers.valueAt(i); 
      i = 0;
      while (j < k) {
        LoaderManagerImpl loaderManagerImpl = arrayOfLoaderManagerImpl[j];
        if (loaderManagerImpl.mRetaining) {
          i = 1;
        } else {
          loaderManagerImpl.doDestroy();
          this.mAllLoaderManagers.remove(loaderManagerImpl.mWho);
        } 
        j++;
      } 
    } 
    if (arrayList == null && i == 0 && object == null)
      return null; 
    NonConfigurationInstances nonConfigurationInstances = new NonConfigurationInstances();
    nonConfigurationInstances.activity = null;
    nonConfigurationInstances.custom = object;
    nonConfigurationInstances.children = null;
    nonConfigurationInstances.fragments = arrayList;
    nonConfigurationInstances.loaders = this.mAllLoaderManagers;
    return nonConfigurationInstances;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    Parcelable parcelable = this.mFragments.saveAllState();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  protected void onStart() {
    super.onStart();
    byte b = 0;
    this.mStopped = false;
    this.mReallyStopped = false;
    this.mHandler.removeMessages(1);
    if (!this.mCreated) {
      this.mCreated = true;
      this.mFragments.dispatchActivityCreated();
    } 
    this.mFragments.noteStateNotSaved();
    this.mFragments.execPendingActions();
    if (!this.mLoadersStarted) {
      this.mLoadersStarted = true;
      LoaderManagerImpl loaderManagerImpl = this.mLoaderManager;
      if (loaderManagerImpl != null) {
        loaderManagerImpl.doStart();
      } else if (!this.mCheckedForLoaderManager) {
        this.mLoaderManager = getLoaderManager("(root)", this.mLoadersStarted, false);
        loaderManagerImpl = this.mLoaderManager;
        if (loaderManagerImpl != null && !loaderManagerImpl.mStarted)
          this.mLoaderManager.doStart(); 
      } 
      this.mCheckedForLoaderManager = true;
    } 
    this.mFragments.dispatchStart();
    SimpleArrayMap<String, LoaderManagerImpl> simpleArrayMap = this.mAllLoaderManagers;
    if (simpleArrayMap != null) {
      int j;
      int k = simpleArrayMap.size();
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[k];
      int i = k - 1;
      while (true) {
        j = b;
        if (i >= 0) {
          arrayOfLoaderManagerImpl[i] = (LoaderManagerImpl)this.mAllLoaderManagers.valueAt(i);
          i--;
          continue;
        } 
        break;
      } 
      while (j < k) {
        LoaderManagerImpl loaderManagerImpl = arrayOfLoaderManagerImpl[j];
        loaderManagerImpl.finishRetain();
        loaderManagerImpl.doReportStart();
        j++;
      } 
    } 
  }
  
  protected void onStop() {
    super.onStop();
    this.mStopped = true;
    this.mHandler.sendEmptyMessage(1);
    this.mFragments.dispatchStop();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (paramInt == -1 || (0xFFFF0000 & paramInt) == 0) {
      super.startActivityForResult(paramIntent, paramInt);
      return;
    } 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt) {
    if (paramInt == -1) {
      super.startActivityForResult(paramIntent, -1);
      return;
    } 
    if ((0xFFFF0000 & paramInt) == 0) {
      super.startActivityForResult(paramIntent, (paramFragment.mIndex + 1 << 16) + (paramInt & 0xFFFF));
      return;
    } 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  public void supportInvalidateOptionsMenu() {
    if (Build.VERSION.SDK_INT >= 11) {
      ActivityCompatHoneycomb.invalidateOptionsMenu(this);
      return;
    } 
    this.mOptionsMenuInvalidated = true;
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static final class NonConfigurationInstances {
    Object activity;
    
    SimpleArrayMap<String, Object> children;
    
    Object custom;
    
    ArrayList<Fragment> fragments;
    
    SimpleArrayMap<String, LoaderManagerImpl> loaders;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\app\FragmentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */