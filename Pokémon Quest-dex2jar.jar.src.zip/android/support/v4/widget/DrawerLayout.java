package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.KeyEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewGroupCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  private static final boolean ALLOW_EDGE_LOCK = false;
  
  private static final boolean CHILDREN_DISALLOW_INTERCEPT = true;
  
  private static final int DEFAULT_SCRIM_COLOR = -1728053248;
  
  private static final int[] LAYOUT_ATTRS = new int[] { 16842931 };
  
  public static final int LOCK_MODE_LOCKED_CLOSED = 1;
  
  public static final int LOCK_MODE_LOCKED_OPEN = 2;
  
  public static final int LOCK_MODE_UNLOCKED = 0;
  
  private static final int MIN_DRAWER_MARGIN = 64;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  private static final int PEEK_DELAY = 160;
  
  public static final int STATE_DRAGGING = 1;
  
  public static final int STATE_IDLE = 0;
  
  public static final int STATE_SETTLING = 2;
  
  private static final String TAG = "DrawerLayout";
  
  private static final float TOUCH_SLOP_SENSITIVITY = 1.0F;
  
  private final ChildAccessibilityDelegate mChildAccessibilityDelegate = new ChildAccessibilityDelegate();
  
  private boolean mChildrenCanceledTouch;
  
  private boolean mDisallowInterceptRequested;
  
  private int mDrawerState;
  
  private boolean mFirstLayout = true;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private final ViewDragCallback mLeftCallback;
  
  private final ViewDragHelper mLeftDragger;
  
  private DrawerListener mListener;
  
  private int mLockModeLeft;
  
  private int mLockModeRight;
  
  private int mMinDrawerMargin;
  
  private final ViewDragCallback mRightCallback;
  
  private final ViewDragHelper mRightDragger;
  
  private int mScrimColor = -1728053248;
  
  private float mScrimOpacity;
  
  private Paint mScrimPaint = new Paint();
  
  private Drawable mShadowLeft;
  
  private Drawable mShadowRight;
  
  private CharSequence mTitleLeft;
  
  private CharSequence mTitleRight;
  
  public DrawerLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    float f = (getResources().getDisplayMetrics()).density;
    this.mMinDrawerMargin = (int)(64.0F * f + 0.5F);
    f *= 400.0F;
    this.mLeftCallback = new ViewDragCallback(3);
    this.mRightCallback = new ViewDragCallback(5);
    this.mLeftDragger = ViewDragHelper.create(this, 1.0F, this.mLeftCallback);
    this.mLeftDragger.setEdgeTrackingEnabled(1);
    this.mLeftDragger.setMinVelocity(f);
    this.mLeftCallback.setDragger(this.mLeftDragger);
    this.mRightDragger = ViewDragHelper.create(this, 1.0F, this.mRightCallback);
    this.mRightDragger.setEdgeTrackingEnabled(2);
    this.mRightDragger.setMinVelocity(f);
    this.mRightCallback.setDragger(this.mRightDragger);
    setFocusableInTouchMode(true);
    ViewCompat.setImportantForAccessibility((View)this, 1);
    ViewCompat.setAccessibilityDelegate((View)this, new AccessibilityDelegate());
    ViewGroupCompat.setMotionEventSplittingEnabled(this, false);
  }
  
  private View findVisibleDrawer() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (isDrawerView(view) && isDrawerVisible(view))
        return view; 
    } 
    return null;
  }
  
  static String gravityToString(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  private static boolean hasOpaqueBackground(View paramView) {
    Drawable drawable = paramView.getBackground();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (drawable != null) {
      bool1 = bool2;
      if (drawable.getOpacity() == -1)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private boolean hasPeekingDrawer() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      if (((LayoutParams)getChildAt(i).getLayoutParams()).isPeeking)
        return true; 
    } 
    return false;
  }
  
  private boolean hasVisibleDrawer() {
    return (findVisibleDrawer() != null);
  }
  
  private static boolean includeChildForAccessibilitiy(View paramView) {
    return (ViewCompat.getImportantForAccessibility(paramView) != 4 && ViewCompat.getImportantForAccessibility(paramView) != 2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (paramInt > 0 || (paramInt < 0 && getChildCount() > 0)) {
      ViewCompat.setImportantForAccessibility(paramView, 4);
      ViewCompat.setAccessibilityDelegate(paramView, this.mChildAccessibilityDelegate);
    } else {
      ViewCompat.setImportantForAccessibility(paramView, 1);
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  void cancelChildViewTouch() {
    if (!this.mChildrenCanceledTouch) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        getChildAt(i).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.mChildrenCanceledTouch = true;
    } 
  }
  
  boolean checkDrawerViewAbsoluteGravity(View paramView, int paramInt) {
    return ((getDrawerViewAbsoluteGravity(paramView) & paramInt) == paramInt);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void closeDrawer(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    if (view != null) {
      closeDrawer(view);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(gravityToString(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void closeDrawer(View paramView) {
    LayoutParams layoutParams;
    if (isDrawerView(paramView)) {
      if (this.mFirstLayout) {
        layoutParams = (LayoutParams)paramView.getLayoutParams();
        layoutParams.onScreen = 0.0F;
        layoutParams.knownOpen = false;
      } else if (checkDrawerViewAbsoluteGravity((View)layoutParams, 3)) {
        this.mLeftDragger.smoothSlideViewTo((View)layoutParams, -layoutParams.getWidth(), layoutParams.getTop());
      } else {
        this.mRightDragger.smoothSlideViewTo((View)layoutParams, getWidth(), layoutParams.getTop());
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(layoutParams);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void closeDrawers() {
    closeDrawers(false);
  }
  
  void closeDrawers(boolean paramBoolean) {
    int j;
    int m = getChildCount();
    int i = 0;
    int k = 0;
    while (i < m) {
      int n;
      View view = getChildAt(i);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      int i1 = k;
      if (isDrawerView(view))
        if (paramBoolean && !layoutParams.isPeeking) {
          i1 = k;
        } else {
          int i2;
          i1 = view.getWidth();
          if (checkDrawerViewAbsoluteGravity(view, 3)) {
            i2 = this.mLeftDragger.smoothSlideViewTo(view, -i1, view.getTop());
          } else {
            i2 = this.mRightDragger.smoothSlideViewTo(view, getWidth(), view.getTop());
          } 
          n = k | i2;
          layoutParams.isPeeking = false;
        }  
      i++;
      j = n;
    } 
    this.mLeftCallback.removeCallbacks();
    this.mRightCallback.removeCallbacks();
    if (j != 0)
      invalidate(); 
  }
  
  public void computeScroll() {
    int j = getChildCount();
    float f = 0.0F;
    for (int i = 0; i < j; i++)
      f = Math.max(f, ((LayoutParams)getChildAt(i).getLayoutParams()).onScreen); 
    this.mScrimOpacity = f;
    if ((this.mLeftDragger.continueSettling(true) | this.mRightDragger.continueSettling(true)) != 0)
      ViewCompat.postInvalidateOnAnimation((View)this); 
  }
  
  void dispatchOnDrawerClosed(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (layoutParams.knownOpen) {
      layoutParams.knownOpen = false;
      DrawerListener drawerListener = this.mListener;
      if (drawerListener != null)
        drawerListener.onDrawerClosed(paramView); 
      View view = getChildAt(0);
      if (view != null)
        ViewCompat.setImportantForAccessibility(view, 1); 
      ViewCompat.setImportantForAccessibility(paramView, 4);
      if (hasWindowFocus()) {
        paramView = getRootView();
        if (paramView != null)
          paramView.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  void dispatchOnDrawerOpened(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (!layoutParams.knownOpen) {
      layoutParams.knownOpen = true;
      DrawerListener drawerListener = this.mListener;
      if (drawerListener != null)
        drawerListener.onDrawerOpened(paramView); 
      View view = getChildAt(0);
      if (view != null)
        ViewCompat.setImportantForAccessibility(view, 4); 
      ViewCompat.setImportantForAccessibility(paramView, 1);
      sendAccessibilityEvent(32);
      paramView.requestFocus();
    } 
  }
  
  void dispatchOnDrawerSlide(View paramView, float paramFloat) {
    DrawerListener drawerListener = this.mListener;
    if (drawerListener != null)
      drawerListener.onDrawerSlide(paramView, paramFloat); 
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int m = getHeight();
    boolean bool1 = isContentView(paramView);
    int i = getWidth();
    int k = paramCanvas.save();
    int j = 0;
    if (bool1) {
      int i1 = getChildCount();
      int n = 0;
      j = 0;
      while (n < i1) {
        View view = getChildAt(n);
        int i2 = j;
        int i3 = i;
        if (view != paramView) {
          i2 = j;
          i3 = i;
          if (view.getVisibility() == 0) {
            i2 = j;
            i3 = i;
            if (hasOpaqueBackground(view)) {
              i2 = j;
              i3 = i;
              if (isDrawerView(view))
                if (view.getHeight() < m) {
                  i2 = j;
                  i3 = i;
                } else if (checkDrawerViewAbsoluteGravity(view, 3)) {
                  int i4 = view.getRight();
                  i2 = j;
                  i3 = i;
                  if (i4 > j) {
                    i2 = i4;
                    i3 = i;
                  } 
                } else {
                  int i4 = view.getLeft();
                  i2 = j;
                  i3 = i;
                  if (i4 < i) {
                    i3 = i4;
                    i2 = j;
                  } 
                }  
            } 
          } 
        } 
        n++;
        j = i2;
        i = i3;
      } 
      paramCanvas.clipRect(j, 0, i, getHeight());
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(k);
    float f = this.mScrimOpacity;
    if (f > 0.0F && bool1) {
      int n = this.mScrimColor;
      int i1 = (int)(((0xFF000000 & n) >>> 24) * f);
      this.mScrimPaint.setColor(n & 0xFFFFFF | i1 << 24);
      paramCanvas.drawRect(j, 0.0F, i, getHeight(), this.mScrimPaint);
      return bool2;
    } 
    if (this.mShadowLeft != null && checkDrawerViewAbsoluteGravity(paramView, 3)) {
      i = this.mShadowLeft.getIntrinsicWidth();
      j = paramView.getRight();
      int n = this.mLeftDragger.getEdgeSize();
      f = Math.max(0.0F, Math.min(j / n, 1.0F));
      this.mShadowLeft.setBounds(j, paramView.getTop(), i + j, paramView.getBottom());
      this.mShadowLeft.setAlpha((int)(f * 255.0F));
      this.mShadowLeft.draw(paramCanvas);
      return bool2;
    } 
    if (this.mShadowRight != null && checkDrawerViewAbsoluteGravity(paramView, 5)) {
      i = this.mShadowRight.getIntrinsicWidth();
      j = paramView.getLeft();
      int n = getWidth();
      int i1 = this.mRightDragger.getEdgeSize();
      f = Math.max(0.0F, Math.min((n - j) / i1, 1.0F));
      this.mShadowRight.setBounds(j - i, paramView.getTop(), j, paramView.getBottom());
      this.mShadowRight.setAlpha((int)(f * 255.0F));
      this.mShadowRight.draw(paramCanvas);
    } 
    return bool2;
  }
  
  View findDrawerWithGravity(int paramInt) {
    int i = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    int j = getChildCount();
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      if ((getDrawerViewAbsoluteGravity(view) & 0x7) == (i & 0x7))
        return view; 
    } 
    return null;
  }
  
  View findOpenDrawer() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (((LayoutParams)view.getLayoutParams()).knownOpen)
        return view; 
    } 
    return null;
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new LayoutParams(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof LayoutParams) ? new LayoutParams((LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams)));
  }
  
  public int getDrawerLockMode(int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    return (paramInt == 3) ? this.mLockModeLeft : ((paramInt == 5) ? this.mLockModeRight : 0);
  }
  
  public int getDrawerLockMode(View paramView) {
    int i = getDrawerViewAbsoluteGravity(paramView);
    return (i == 3) ? this.mLockModeLeft : ((i == 5) ? this.mLockModeRight : 0);
  }
  
  @Nullable
  public CharSequence getDrawerTitle(int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    return (paramInt == 3) ? this.mTitleLeft : ((paramInt == 5) ? this.mTitleRight : null);
  }
  
  int getDrawerViewAbsoluteGravity(View paramView) {
    return GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection((View)this));
  }
  
  float getDrawerViewOffset(View paramView) {
    return ((LayoutParams)paramView.getLayoutParams()).onScreen;
  }
  
  boolean isContentView(View paramView) {
    return (((LayoutParams)paramView.getLayoutParams()).gravity == 0);
  }
  
  public boolean isDrawerOpen(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    return (view != null) ? isDrawerOpen(view) : false;
  }
  
  public boolean isDrawerOpen(View paramView) {
    if (isDrawerView(paramView))
      return ((LayoutParams)paramView.getLayoutParams()).knownOpen; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  boolean isDrawerView(View paramView) {
    return ((GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection(paramView)) & 0x7) != 0);
  }
  
  public boolean isDrawerVisible(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    return (view != null) ? isDrawerVisible(view) : false;
  }
  
  public boolean isDrawerVisible(View paramView) {
    if (isDrawerView(paramView))
      return (((LayoutParams)paramView.getLayoutParams()).onScreen > 0.0F); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void moveDrawerToOffset(View paramView, float paramFloat) {
    float f1 = getDrawerViewOffset(paramView);
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    i = (int)(f2 * paramFloat) - i;
    if (!checkDrawerViewAbsoluteGravity(paramView, 3))
      i = -i; 
    paramView.offsetLeftAndRight(i);
    setDrawerViewOffset(paramView, paramFloat);
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic getActionMasked : (Landroid/view/MotionEvent;)I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   10: aload_1
    //   11: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   14: istore #7
    //   16: aload_0
    //   17: getfield mRightDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   20: aload_1
    //   21: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   24: istore #8
    //   26: iconst_1
    //   27: istore #6
    //   29: iload #4
    //   31: ifeq -> 104
    //   34: iload #4
    //   36: iconst_1
    //   37: if_icmpeq -> 83
    //   40: iload #4
    //   42: iconst_2
    //   43: if_icmpeq -> 55
    //   46: iload #4
    //   48: iconst_3
    //   49: if_icmpeq -> 83
    //   52: goto -> 98
    //   55: aload_0
    //   56: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   59: iconst_3
    //   60: invokevirtual checkTouchSlop : (I)Z
    //   63: ifeq -> 98
    //   66: aload_0
    //   67: getfield mLeftCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   70: invokevirtual removeCallbacks : ()V
    //   73: aload_0
    //   74: getfield mRightCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   77: invokevirtual removeCallbacks : ()V
    //   80: goto -> 98
    //   83: aload_0
    //   84: iconst_1
    //   85: invokevirtual closeDrawers : (Z)V
    //   88: aload_0
    //   89: iconst_0
    //   90: putfield mDisallowInterceptRequested : Z
    //   93: aload_0
    //   94: iconst_0
    //   95: putfield mChildrenCanceledTouch : Z
    //   98: iconst_0
    //   99: istore #4
    //   101: goto -> 170
    //   104: aload_1
    //   105: invokevirtual getX : ()F
    //   108: fstore_2
    //   109: aload_1
    //   110: invokevirtual getY : ()F
    //   113: fstore_3
    //   114: aload_0
    //   115: fload_2
    //   116: putfield mInitialMotionX : F
    //   119: aload_0
    //   120: fload_3
    //   121: putfield mInitialMotionY : F
    //   124: aload_0
    //   125: getfield mScrimOpacity : F
    //   128: fconst_0
    //   129: fcmpl
    //   130: ifle -> 157
    //   133: aload_0
    //   134: aload_0
    //   135: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   138: fload_2
    //   139: f2i
    //   140: fload_3
    //   141: f2i
    //   142: invokevirtual findTopChildUnder : (II)Landroid/view/View;
    //   145: invokevirtual isContentView : (Landroid/view/View;)Z
    //   148: ifeq -> 157
    //   151: iconst_1
    //   152: istore #4
    //   154: goto -> 160
    //   157: iconst_0
    //   158: istore #4
    //   160: aload_0
    //   161: iconst_0
    //   162: putfield mDisallowInterceptRequested : Z
    //   165: aload_0
    //   166: iconst_0
    //   167: putfield mChildrenCanceledTouch : Z
    //   170: iload #6
    //   172: istore #5
    //   174: iload #7
    //   176: iload #8
    //   178: ior
    //   179: ifne -> 214
    //   182: iload #6
    //   184: istore #5
    //   186: iload #4
    //   188: ifne -> 214
    //   191: iload #6
    //   193: istore #5
    //   195: aload_0
    //   196: invokespecial hasPeekingDrawer : ()Z
    //   199: ifne -> 214
    //   202: aload_0
    //   203: getfield mChildrenCanceledTouch : Z
    //   206: ifeq -> 211
    //   209: iconst_1
    //   210: ireturn
    //   211: iconst_0
    //   212: istore #5
    //   214: iload #5
    //   216: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && hasVisibleDrawer()) {
      KeyEventCompat.startTracking(paramKeyEvent);
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      view = findVisibleDrawer();
      if (view != null && getDrawerLockMode(view) == 0)
        closeDrawers(); 
      return (view != null);
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mInLayout = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (paramInt3 = 0; paramInt3 < j; paramInt3++) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (isContentView(view)) {
          view.layout(layoutParams.leftMargin, layoutParams.topMargin, layoutParams.leftMargin + view.getMeasuredWidth(), layoutParams.topMargin + view.getMeasuredHeight());
        } else {
          float f;
          int k;
          boolean bool;
          int m = view.getMeasuredWidth();
          int n = view.getMeasuredHeight();
          if (checkDrawerViewAbsoluteGravity(view, 3)) {
            paramInt1 = -m;
            f = m;
            k = paramInt1 + (int)(layoutParams.onScreen * f);
            f = (m + k) / f;
          } else {
            f = m;
            k = i - (int)(layoutParams.onScreen * f);
            f = (i - k) / f;
          } 
          if (f != layoutParams.onScreen) {
            bool = true;
          } else {
            bool = false;
          } 
          paramInt1 = layoutParams.gravity & 0x70;
          if (paramInt1 != 16) {
            if (paramInt1 != 80) {
              view.layout(k, layoutParams.topMargin, m + k, layoutParams.topMargin + n);
            } else {
              paramInt1 = paramInt4 - paramInt2;
              view.layout(k, paramInt1 - layoutParams.bottomMargin - view.getMeasuredHeight(), m + k, paramInt1 - layoutParams.bottomMargin);
            } 
          } else {
            int i2 = paramInt4 - paramInt2;
            int i1 = (i2 - n) / 2;
            if (i1 < layoutParams.topMargin) {
              paramInt1 = layoutParams.topMargin;
            } else {
              paramInt1 = i1;
              if (i1 + n > i2 - layoutParams.bottomMargin)
                paramInt1 = i2 - layoutParams.bottomMargin - n; 
            } 
            view.layout(k, paramInt1, m + k, n + paramInt1);
          } 
          if (bool)
            setDrawerViewOffset(view, f); 
          if (layoutParams.onScreen > 0.0F) {
            paramInt1 = 0;
          } else {
            paramInt1 = 4;
          } 
          if (view.getVisibility() != paramInt1)
            view.setVisibility(paramInt1); 
        } 
      } 
    } 
    this.mInLayout = false;
    this.mFirstLayout = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore #8
    //   6: iload_2
    //   7: invokestatic getMode : (I)I
    //   10: istore #7
    //   12: iload_1
    //   13: invokestatic getSize : (I)I
    //   16: istore_3
    //   17: iload_2
    //   18: invokestatic getSize : (I)I
    //   21: istore #6
    //   23: iload #8
    //   25: ldc_w 1073741824
    //   28: if_icmpne -> 46
    //   31: iload_3
    //   32: istore #4
    //   34: iload #6
    //   36: istore #5
    //   38: iload #7
    //   40: ldc_w 1073741824
    //   43: if_icmpeq -> 111
    //   46: aload_0
    //   47: invokevirtual isInEditMode : ()Z
    //   50: ifeq -> 455
    //   53: iload #8
    //   55: ldc_w -2147483648
    //   58: if_icmpne -> 64
    //   61: goto -> 73
    //   64: iload #8
    //   66: ifne -> 73
    //   69: sipush #300
    //   72: istore_3
    //   73: iload #7
    //   75: ldc_w -2147483648
    //   78: if_icmpne -> 91
    //   81: iload_3
    //   82: istore #4
    //   84: iload #6
    //   86: istore #5
    //   88: goto -> 111
    //   91: iload_3
    //   92: istore #4
    //   94: iload #6
    //   96: istore #5
    //   98: iload #7
    //   100: ifne -> 111
    //   103: sipush #300
    //   106: istore #5
    //   108: iload_3
    //   109: istore #4
    //   111: aload_0
    //   112: iload #4
    //   114: iload #5
    //   116: invokevirtual setMeasuredDimension : (II)V
    //   119: aload_0
    //   120: invokevirtual getChildCount : ()I
    //   123: istore #6
    //   125: iconst_0
    //   126: istore_3
    //   127: iload_3
    //   128: iload #6
    //   130: if_icmpge -> 454
    //   133: aload_0
    //   134: iload_3
    //   135: invokevirtual getChildAt : (I)Landroid/view/View;
    //   138: astore #9
    //   140: aload #9
    //   142: invokevirtual getVisibility : ()I
    //   145: bipush #8
    //   147: if_icmpne -> 153
    //   150: goto -> 297
    //   153: aload #9
    //   155: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   158: checkcast android/support/v4/widget/DrawerLayout$LayoutParams
    //   161: astore #10
    //   163: aload_0
    //   164: aload #9
    //   166: invokevirtual isContentView : (Landroid/view/View;)Z
    //   169: ifeq -> 220
    //   172: aload #9
    //   174: iload #4
    //   176: aload #10
    //   178: getfield leftMargin : I
    //   181: isub
    //   182: aload #10
    //   184: getfield rightMargin : I
    //   187: isub
    //   188: ldc_w 1073741824
    //   191: invokestatic makeMeasureSpec : (II)I
    //   194: iload #5
    //   196: aload #10
    //   198: getfield topMargin : I
    //   201: isub
    //   202: aload #10
    //   204: getfield bottomMargin : I
    //   207: isub
    //   208: ldc_w 1073741824
    //   211: invokestatic makeMeasureSpec : (II)I
    //   214: invokevirtual measure : (II)V
    //   217: goto -> 297
    //   220: aload_0
    //   221: aload #9
    //   223: invokevirtual isDrawerView : (Landroid/view/View;)Z
    //   226: ifeq -> 381
    //   229: aload_0
    //   230: aload #9
    //   232: invokevirtual getDrawerViewAbsoluteGravity : (Landroid/view/View;)I
    //   235: bipush #7
    //   237: iand
    //   238: istore #7
    //   240: iconst_0
    //   241: iload #7
    //   243: iand
    //   244: ifne -> 304
    //   247: aload #9
    //   249: iload_1
    //   250: aload_0
    //   251: getfield mMinDrawerMargin : I
    //   254: aload #10
    //   256: getfield leftMargin : I
    //   259: iadd
    //   260: aload #10
    //   262: getfield rightMargin : I
    //   265: iadd
    //   266: aload #10
    //   268: getfield width : I
    //   271: invokestatic getChildMeasureSpec : (III)I
    //   274: iload_2
    //   275: aload #10
    //   277: getfield topMargin : I
    //   280: aload #10
    //   282: getfield bottomMargin : I
    //   285: iadd
    //   286: aload #10
    //   288: getfield height : I
    //   291: invokestatic getChildMeasureSpec : (III)I
    //   294: invokevirtual measure : (II)V
    //   297: iload_3
    //   298: iconst_1
    //   299: iadd
    //   300: istore_3
    //   301: goto -> 127
    //   304: new java/lang/StringBuilder
    //   307: dup
    //   308: invokespecial <init> : ()V
    //   311: astore #9
    //   313: aload #9
    //   315: ldc_w 'Child drawer has absolute gravity '
    //   318: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: pop
    //   322: aload #9
    //   324: iload #7
    //   326: invokestatic gravityToString : (I)Ljava/lang/String;
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: pop
    //   333: aload #9
    //   335: ldc_w ' but this '
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload #9
    //   344: ldc 'DrawerLayout'
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: aload #9
    //   352: ldc_w ' already has a '
    //   355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   358: pop
    //   359: aload #9
    //   361: ldc_w 'drawer view along that edge'
    //   364: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: pop
    //   368: new java/lang/IllegalStateException
    //   371: dup
    //   372: aload #9
    //   374: invokevirtual toString : ()Ljava/lang/String;
    //   377: invokespecial <init> : (Ljava/lang/String;)V
    //   380: athrow
    //   381: new java/lang/StringBuilder
    //   384: dup
    //   385: invokespecial <init> : ()V
    //   388: astore #10
    //   390: aload #10
    //   392: ldc_w 'Child '
    //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   398: pop
    //   399: aload #10
    //   401: aload #9
    //   403: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   406: pop
    //   407: aload #10
    //   409: ldc_w ' at index '
    //   412: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   415: pop
    //   416: aload #10
    //   418: iload_3
    //   419: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   422: pop
    //   423: aload #10
    //   425: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, '
    //   428: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   431: pop
    //   432: aload #10
    //   434: ldc_w 'Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   437: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   440: pop
    //   441: new java/lang/IllegalStateException
    //   444: dup
    //   445: aload #10
    //   447: invokevirtual toString : ()Ljava/lang/String;
    //   450: invokespecial <init> : (Ljava/lang/String;)V
    //   453: athrow
    //   454: return
    //   455: new java/lang/IllegalArgumentException
    //   458: dup
    //   459: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   462: invokespecial <init> : (Ljava/lang/String;)V
    //   465: athrow
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.openDrawerGravity != 0) {
      View view = findDrawerWithGravity(savedState.openDrawerGravity);
      if (view != null)
        openDrawer(view); 
    } 
    setDrawerLockMode(savedState.lockModeLeft, 3);
    setDrawerLockMode(savedState.lockModeRight, 5);
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (isDrawerView(view)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.knownOpen) {
          savedState.openDrawerGravity = layoutParams.gravity;
          break;
        } 
      } 
    } 
    savedState.lockModeLeft = this.mLockModeLeft;
    savedState.lockModeRight = this.mLockModeRight;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    this.mLeftDragger.processTouchEvent(paramMotionEvent);
    this.mRightDragger.processTouchEvent(paramMotionEvent);
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i != 0) {
      if (i != 1) {
        if (i != 3)
          return true; 
        closeDrawers(true);
        this.mDisallowInterceptRequested = false;
        this.mChildrenCanceledTouch = false;
        return true;
      } 
      float f2 = paramMotionEvent.getX();
      float f1 = paramMotionEvent.getY();
      view = this.mLeftDragger.findTopChildUnder((int)f2, (int)f1);
      if (view != null && isContentView(view)) {
        f2 -= this.mInitialMotionX;
        f1 -= this.mInitialMotionY;
        i = this.mLeftDragger.getTouchSlop();
        if (f2 * f2 + f1 * f1 < (i * i)) {
          view = findOpenDrawer();
          if (view == null || getDrawerLockMode(view) == 2) {
            boolean bool2 = true;
            closeDrawers(bool2);
            this.mDisallowInterceptRequested = false;
            return true;
          } 
          boolean bool1 = false;
          closeDrawers(bool1);
          this.mDisallowInterceptRequested = false;
          return true;
        } 
      } 
    } else {
      float f1 = view.getX();
      float f2 = view.getY();
      this.mInitialMotionX = f1;
      this.mInitialMotionY = f2;
      this.mDisallowInterceptRequested = false;
      this.mChildrenCanceledTouch = false;
      return true;
    } 
    boolean bool = true;
    closeDrawers(bool);
    this.mDisallowInterceptRequested = false;
    return true;
  }
  
  public void openDrawer(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    if (view != null) {
      openDrawer(view);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(gravityToString(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void openDrawer(View paramView) {
    LayoutParams layoutParams;
    if (isDrawerView(paramView)) {
      if (this.mFirstLayout) {
        layoutParams = (LayoutParams)paramView.getLayoutParams();
        layoutParams.onScreen = 1.0F;
        layoutParams.knownOpen = true;
      } else if (checkDrawerViewAbsoluteGravity((View)layoutParams, 3)) {
        this.mLeftDragger.smoothSlideViewTo((View)layoutParams, 0, layoutParams.getTop());
      } else {
        this.mRightDragger.smoothSlideViewTo((View)layoutParams, getWidth() - layoutParams.getWidth(), layoutParams.getTop());
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(layoutParams);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    this.mDisallowInterceptRequested = paramBoolean;
    if (paramBoolean)
      closeDrawers(true); 
  }
  
  public void requestLayout() {
    if (!this.mInLayout)
      super.requestLayout(); 
  }
  
  public void setDrawerListener(DrawerListener paramDrawerListener) {
    this.mListener = paramDrawerListener;
  }
  
  public void setDrawerLockMode(int paramInt) {
    setDrawerLockMode(paramInt, 3);
    setDrawerLockMode(paramInt, 5);
  }
  
  public void setDrawerLockMode(int paramInt1, int paramInt2) {
    paramInt2 = GravityCompat.getAbsoluteGravity(paramInt2, ViewCompat.getLayoutDirection((View)this));
    if (paramInt2 == 3) {
      this.mLockModeLeft = paramInt1;
    } else if (paramInt2 == 5) {
      this.mLockModeRight = paramInt1;
    } 
    if (paramInt1 != 0) {
      ViewDragHelper viewDragHelper;
      if (paramInt2 == 3) {
        viewDragHelper = this.mLeftDragger;
      } else {
        viewDragHelper = this.mRightDragger;
      } 
      viewDragHelper.cancel();
    } 
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return; 
      View view = findDrawerWithGravity(paramInt2);
      if (view != null) {
        openDrawer(view);
        return;
      } 
    } else {
      View view = findDrawerWithGravity(paramInt2);
      if (view != null)
        closeDrawer(view); 
    } 
  }
  
  public void setDrawerLockMode(int paramInt, View paramView) {
    if (isDrawerView(paramView)) {
      setDrawerLockMode(paramInt, ((LayoutParams)paramView.getLayoutParams()).gravity);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a ");
    stringBuilder.append("drawer with appropriate layout_gravity");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDrawerShadow(int paramInt1, int paramInt2) {
    setDrawerShadow(getResources().getDrawable(paramInt1), paramInt2);
  }
  
  public void setDrawerShadow(Drawable paramDrawable, int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    if ((paramInt & 0x3) == 3) {
      this.mShadowLeft = paramDrawable;
      invalidate();
    } 
    if ((paramInt & 0x5) == 5) {
      this.mShadowRight = paramDrawable;
      invalidate();
    } 
  }
  
  public void setDrawerTitle(int paramInt, CharSequence paramCharSequence) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    if (paramInt == 3) {
      this.mTitleLeft = paramCharSequence;
      return;
    } 
    if (paramInt == 5)
      this.mTitleRight = paramCharSequence; 
  }
  
  void setDrawerViewOffset(View paramView, float paramFloat) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat == layoutParams.onScreen)
      return; 
    layoutParams.onScreen = paramFloat;
    dispatchOnDrawerSlide(paramView, paramFloat);
  }
  
  public void setScrimColor(int paramInt) {
    this.mScrimColor = paramInt;
    invalidate();
  }
  
  void updateDrawerState(int paramInt1, int paramInt2, View paramView) {
    int i = this.mLeftDragger.getViewDragState();
    int j = this.mRightDragger.getViewDragState();
    byte b = 2;
    if (i == 1 || j == 1) {
      paramInt1 = 1;
    } else {
      paramInt1 = b;
      if (i != 2)
        if (j == 2) {
          paramInt1 = b;
        } else {
          paramInt1 = 0;
        }  
    } 
    if (paramView != null && paramInt2 == 0) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      if (layoutParams.onScreen == 0.0F) {
        dispatchOnDrawerClosed(paramView);
      } else if (layoutParams.onScreen == 1.0F) {
        dispatchOnDrawerOpened(paramView);
      } 
    } 
    if (paramInt1 != this.mDrawerState) {
      this.mDrawerState = paramInt1;
      DrawerListener drawerListener = this.mListener;
      if (drawerListener != null)
        drawerListener.onDrawerStateChanged(paramInt1); 
    } 
  }
  
  class AccessibilityDelegate extends AccessibilityDelegateCompat {
    private final Rect mTmpRect = new Rect();
    
    private void addChildrenForAccessibility(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat, ViewGroup param1ViewGroup) {
      int j = param1ViewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = param1ViewGroup.getChildAt(i);
        if (DrawerLayout.includeChildForAccessibilitiy(view))
          param1AccessibilityNodeInfoCompat.addChild(view); 
      } 
    }
    
    private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat1, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat2) {
      Rect rect = this.mTmpRect;
      param1AccessibilityNodeInfoCompat2.getBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat2.getBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setVisibleToUser(param1AccessibilityNodeInfoCompat2.isVisibleToUser());
      param1AccessibilityNodeInfoCompat1.setPackageName(param1AccessibilityNodeInfoCompat2.getPackageName());
      param1AccessibilityNodeInfoCompat1.setClassName(param1AccessibilityNodeInfoCompat2.getClassName());
      param1AccessibilityNodeInfoCompat1.setContentDescription(param1AccessibilityNodeInfoCompat2.getContentDescription());
      param1AccessibilityNodeInfoCompat1.setEnabled(param1AccessibilityNodeInfoCompat2.isEnabled());
      param1AccessibilityNodeInfoCompat1.setClickable(param1AccessibilityNodeInfoCompat2.isClickable());
      param1AccessibilityNodeInfoCompat1.setFocusable(param1AccessibilityNodeInfoCompat2.isFocusable());
      param1AccessibilityNodeInfoCompat1.setFocused(param1AccessibilityNodeInfoCompat2.isFocused());
      param1AccessibilityNodeInfoCompat1.setAccessibilityFocused(param1AccessibilityNodeInfoCompat2.isAccessibilityFocused());
      param1AccessibilityNodeInfoCompat1.setSelected(param1AccessibilityNodeInfoCompat2.isSelected());
      param1AccessibilityNodeInfoCompat1.setLongClickable(param1AccessibilityNodeInfoCompat2.isLongClickable());
      param1AccessibilityNodeInfoCompat1.addAction(param1AccessibilityNodeInfoCompat2.getActions());
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      List<CharSequence> list;
      CharSequence charSequence;
      if (param1AccessibilityEvent.getEventType() == 32) {
        list = param1AccessibilityEvent.getText();
        View view = DrawerLayout.this.findVisibleDrawer();
        if (view != null) {
          int i = DrawerLayout.this.getDrawerViewAbsoluteGravity(view);
          charSequence = DrawerLayout.this.getDrawerTitle(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.dispatchPopulateAccessibilityEvent((View)list, (AccessibilityEvent)charSequence);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(param1AccessibilityNodeInfoCompat);
      super.onInitializeAccessibilityNodeInfo(param1View, accessibilityNodeInfoCompat);
      param1AccessibilityNodeInfoCompat.setClassName(DrawerLayout.class.getName());
      param1AccessibilityNodeInfoCompat.setSource(param1View);
      ViewParent viewParent = ViewCompat.getParentForAccessibility(param1View);
      if (viewParent instanceof View)
        param1AccessibilityNodeInfoCompat.setParent((View)viewParent); 
      copyNodeInfoNoChildren(param1AccessibilityNodeInfoCompat, accessibilityNodeInfoCompat);
      accessibilityNodeInfoCompat.recycle();
      addChildrenForAccessibility(param1AccessibilityNodeInfoCompat, (ViewGroup)param1View);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return DrawerLayout.includeChildForAccessibilitiy(param1View) ? super.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  final class ChildAccessibilityDelegate extends AccessibilityDelegateCompat {
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      if (!DrawerLayout.includeChildForAccessibilitiy(param1View))
        param1AccessibilityNodeInfoCompat.setParent(null); 
    }
  }
  
  public static interface DrawerListener {
    void onDrawerClosed(View param1View);
    
    void onDrawerOpened(View param1View);
    
    void onDrawerSlide(View param1View, float param1Float);
    
    void onDrawerStateChanged(int param1Int);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({3L, 5L, 8388611L, 8388613L})
  private static @interface EdgeGravity {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int gravity = 0;
    
    boolean isPeeking;
    
    boolean knownOpen;
    
    float onScreen;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, int param1Int3) {
      this(param1Int1, param1Int2);
      this.gravity = param1Int3;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.LAYOUT_ATTRS);
      this.gravity = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.gravity = param1LayoutParams.gravity;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({0L, 1L, 2L})
  private static @interface LockMode {}
  
  protected static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public DrawerLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new DrawerLayout.SavedState(param2Parcel);
        }
        
        public DrawerLayout.SavedState[] newArray(int param2Int) {
          return new DrawerLayout.SavedState[param2Int];
        }
      };
    
    int lockModeLeft = 0;
    
    int lockModeRight = 0;
    
    int openDrawerGravity = 0;
    
    public SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.openDrawerGravity = param1Parcel.readInt();
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.openDrawerGravity);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public DrawerLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new DrawerLayout.SavedState(param1Parcel);
    }
    
    public DrawerLayout.SavedState[] newArray(int param1Int) {
      return new DrawerLayout.SavedState[param1Int];
    }
  }
  
  public static abstract class SimpleDrawerListener implements DrawerListener {
    public void onDrawerClosed(View param1View) {}
    
    public void onDrawerOpened(View param1View) {}
    
    public void onDrawerSlide(View param1View, float param1Float) {}
    
    public void onDrawerStateChanged(int param1Int) {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({0L, 1L, 2L})
  private static @interface State {}
  
  private class ViewDragCallback extends ViewDragHelper.Callback {
    private final int mAbsGravity;
    
    private ViewDragHelper mDragger;
    
    private final Runnable mPeekRunnable = new Runnable() {
        public void run() {
          DrawerLayout.ViewDragCallback.this.peekDrawer();
        }
      };
    
    public ViewDragCallback(int param1Int) {
      this.mAbsGravity = param1Int;
    }
    
    private void closeOtherDrawer() {
      int i = this.mAbsGravity;
      byte b = 3;
      if (i == 3)
        b = 5; 
      View view = DrawerLayout.this.findDrawerWithGravity(b);
      if (view != null)
        DrawerLayout.this.closeDrawer(view); 
    }
    
    private void peekDrawer() {
      View view;
      int k = this.mDragger.getEdgeSize();
      int i = this.mAbsGravity;
      int j = 0;
      if (i == 3) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        view = DrawerLayout.this.findDrawerWithGravity(3);
        if (view != null)
          j = -view.getWidth(); 
        j += k;
      } else {
        view = DrawerLayout.this.findDrawerWithGravity(5);
        j = DrawerLayout.this.getWidth() - k;
      } 
      if (view != null && ((i != 0 && view.getLeft() < j) || (i == 0 && view.getLeft() > j)) && DrawerLayout.this.getDrawerLockMode(view) == 0) {
        DrawerLayout.LayoutParams layoutParams = (DrawerLayout.LayoutParams)view.getLayoutParams();
        this.mDragger.smoothSlideViewTo(view, j, view.getTop());
        layoutParams.isPeeking = true;
        DrawerLayout.this.invalidate();
        closeOtherDrawer();
        DrawerLayout.this.cancelChildViewTouch();
      } 
    }
    
    public int clampViewPositionHorizontal(View param1View, int param1Int1, int param1Int2) {
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = DrawerLayout.this.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    public int clampViewPositionVertical(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int getViewHorizontalDragRange(View param1View) {
      return param1View.getWidth();
    }
    
    public void onEdgeDragStarted(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = DrawerLayout.this.findDrawerWithGravity(3);
      } else {
        view = DrawerLayout.this.findDrawerWithGravity(5);
      } 
      if (view != null && DrawerLayout.this.getDrawerLockMode(view) == 0)
        this.mDragger.captureChildView(view, param1Int2); 
    }
    
    public boolean onEdgeLock(int param1Int) {
      return false;
    }
    
    public void onEdgeTouched(int param1Int1, int param1Int2) {
      DrawerLayout.this.postDelayed(this.mPeekRunnable, 160L);
    }
    
    public void onViewCaptured(View param1View, int param1Int) {
      ((DrawerLayout.LayoutParams)param1View.getLayoutParams()).isPeeking = false;
      closeOtherDrawer();
    }
    
    public void onViewDragStateChanged(int param1Int) {
      DrawerLayout.this.updateDrawerState(this.mAbsGravity, param1Int, this.mDragger.getCapturedView());
    }
    
    public void onViewPositionChanged(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f;
      param1Int2 = param1View.getWidth();
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, 3)) {
        f = (param1Int1 + param1Int2);
      } else {
        f = (DrawerLayout.this.getWidth() - param1Int1);
      } 
      f /= param1Int2;
      DrawerLayout.this.setDrawerViewOffset(param1View, f);
      if (f == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      DrawerLayout.this.invalidate();
    }
    
    public void onViewReleased(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield this$0 : Landroid/support/v4/widget/DrawerLayout;
      //   4: aload_1
      //   5: invokevirtual getDrawerViewOffset : (Landroid/view/View;)F
      //   8: fstore_3
      //   9: aload_1
      //   10: invokevirtual getWidth : ()I
      //   13: istore #6
      //   15: aload_0
      //   16: getfield this$0 : Landroid/support/v4/widget/DrawerLayout;
      //   19: aload_1
      //   20: iconst_3
      //   21: invokevirtual checkDrawerViewAbsoluteGravity : (Landroid/view/View;I)Z
      //   24: ifeq -> 63
      //   27: fload_2
      //   28: fconst_0
      //   29: fcmpl
      //   30: ifgt -> 57
      //   33: fload_2
      //   34: fconst_0
      //   35: fcmpl
      //   36: ifne -> 49
      //   39: fload_3
      //   40: ldc 0.5
      //   42: fcmpl
      //   43: ifle -> 49
      //   46: goto -> 57
      //   49: iload #6
      //   51: ineg
      //   52: istore #4
      //   54: goto -> 106
      //   57: iconst_0
      //   58: istore #4
      //   60: goto -> 106
      //   63: aload_0
      //   64: getfield this$0 : Landroid/support/v4/widget/DrawerLayout;
      //   67: invokevirtual getWidth : ()I
      //   70: istore #5
      //   72: fload_2
      //   73: fconst_0
      //   74: fcmpg
      //   75: iflt -> 99
      //   78: iload #5
      //   80: istore #4
      //   82: fload_2
      //   83: fconst_0
      //   84: fcmpl
      //   85: ifne -> 106
      //   88: iload #5
      //   90: istore #4
      //   92: fload_3
      //   93: ldc 0.5
      //   95: fcmpl
      //   96: ifle -> 106
      //   99: iload #5
      //   101: iload #6
      //   103: isub
      //   104: istore #4
      //   106: aload_0
      //   107: getfield mDragger : Landroid/support/v4/widget/ViewDragHelper;
      //   110: iload #4
      //   112: aload_1
      //   113: invokevirtual getTop : ()I
      //   116: invokevirtual settleCapturedViewAt : (II)Z
      //   119: pop
      //   120: aload_0
      //   121: getfield this$0 : Landroid/support/v4/widget/DrawerLayout;
      //   124: invokevirtual invalidate : ()V
      //   127: return
    }
    
    public void removeCallbacks() {
      DrawerLayout.this.removeCallbacks(this.mPeekRunnable);
    }
    
    public void setDragger(ViewDragHelper param1ViewDragHelper) {
      this.mDragger = param1ViewDragHelper;
    }
    
    public boolean tryCaptureView(View param1View, int param1Int) {
      return (DrawerLayout.this.isDrawerView(param1View) && DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, this.mAbsGravity) && DrawerLayout.this.getDrawerLockMode(param1View) == 0);
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$1.peekDrawer();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */