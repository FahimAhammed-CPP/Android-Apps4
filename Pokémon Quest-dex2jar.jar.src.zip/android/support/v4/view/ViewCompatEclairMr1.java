package android.support.v4.view;

import android.view.View;

class ViewCompatEclairMr1 {
  public static boolean isOpaque(View paramView) {
    return paramView.isOpaque();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\view\ViewCompatEclairMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */