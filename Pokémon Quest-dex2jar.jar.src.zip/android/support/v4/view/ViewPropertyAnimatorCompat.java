package android.support.v4.view;

import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public class ViewPropertyAnimatorCompat {
  static final ViewPropertyAnimatorCompatImpl IMPL = new BaseViewPropertyAnimatorCompatImpl();
  
  private static final String TAG = "ViewAnimatorCompat";
  
  private WeakReference<View> mView;
  
  ViewPropertyAnimatorCompat(View paramView) {
    this.mView = new WeakReference<View>(paramView);
  }
  
  public ViewPropertyAnimatorCompat alpha(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.alpha(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat alphaBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.alphaBy(view, paramFloat); 
    return this;
  }
  
  public void cancel() {
    View view = this.mView.get();
    if (view != null)
      IMPL.cancel(view); 
  }
  
  public long getDuration() {
    View view = this.mView.get();
    return (view != null) ? IMPL.getDuration(view) : 0L;
  }
  
  public Interpolator getInterpolator() {
    View view = this.mView.get();
    return (view != null) ? IMPL.getInterpolator(view) : null;
  }
  
  public long getStartDelay() {
    View view = this.mView.get();
    return (view != null) ? IMPL.getStartDelay(view) : 0L;
  }
  
  public ViewPropertyAnimatorCompat rotation(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotation(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat rotationBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotationBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat rotationX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotationX(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat rotationXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotationXBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat rotationY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotationY(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat rotationYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.rotationYBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat scaleX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.scaleX(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat scaleXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.scaleXBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat scaleY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.scaleY(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat scaleYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.scaleYBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat setDuration(long paramLong) {
    View view = this.mView.get();
    if (view != null)
      IMPL.setDuration(view, paramLong); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat setInterpolator(Interpolator paramInterpolator) {
    View view = this.mView.get();
    if (view != null)
      IMPL.setInterpolator(view, paramInterpolator); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat setListener(ViewPropertyAnimatorListener paramViewPropertyAnimatorListener) {
    View view = this.mView.get();
    if (view != null)
      IMPL.setListener(view, paramViewPropertyAnimatorListener); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat setStartDelay(long paramLong) {
    View view = this.mView.get();
    if (view != null)
      IMPL.setStartDelay(view, paramLong); 
    return this;
  }
  
  public void start() {
    View view = this.mView.get();
    if (view != null)
      IMPL.start(view); 
  }
  
  public ViewPropertyAnimatorCompat translationX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.translationX(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat translationXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.translationXBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat translationY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.translationY(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat translationYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.translationYBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat withEndAction(Runnable paramRunnable) {
    View view = this.mView.get();
    if (view != null)
      IMPL.withEndAction(view, paramRunnable); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat withLayer() {
    View view = this.mView.get();
    if (view != null)
      IMPL.withLayer(view); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat withStartAction(Runnable paramRunnable) {
    View view = this.mView.get();
    if (view != null)
      IMPL.withStartAction(view, paramRunnable); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat x(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.x(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat xBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.xBy(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat y(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.y(view, paramFloat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompat yBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      IMPL.yBy(view, paramFloat); 
    return this;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 18) {
      IMPL = new JBMr2ViewPropertyAnimatorCompatImpl();
      return;
    } 
    if (i >= 16) {
      IMPL = new JBViewPropertyAnimatorCompatImpl();
      return;
    } 
    if (i >= 14) {
      IMPL = new ICSViewPropertyAnimatorCompatImpl();
      return;
    } 
  }
  
  static class BaseViewPropertyAnimatorCompatImpl implements ViewPropertyAnimatorCompatImpl {
    public void alpha(View param1View, float param1Float) {}
    
    public void alphaBy(View param1View, float param1Float) {}
    
    public void cancel(View param1View) {}
    
    public long getDuration(View param1View) {
      return 0L;
    }
    
    public Interpolator getInterpolator(View param1View) {
      return null;
    }
    
    public long getStartDelay(View param1View) {
      return 0L;
    }
    
    public void rotation(View param1View, float param1Float) {}
    
    public void rotationBy(View param1View, float param1Float) {}
    
    public void rotationX(View param1View, float param1Float) {}
    
    public void rotationXBy(View param1View, float param1Float) {}
    
    public void rotationY(View param1View, float param1Float) {}
    
    public void rotationYBy(View param1View, float param1Float) {}
    
    public void scaleX(View param1View, float param1Float) {}
    
    public void scaleXBy(View param1View, float param1Float) {}
    
    public void scaleY(View param1View, float param1Float) {}
    
    public void scaleYBy(View param1View, float param1Float) {}
    
    public void setDuration(View param1View, long param1Long) {}
    
    public void setInterpolator(View param1View, Interpolator param1Interpolator) {}
    
    public void setListener(View param1View, ViewPropertyAnimatorListener param1ViewPropertyAnimatorListener) {}
    
    public void setStartDelay(View param1View, long param1Long) {}
    
    public void start(View param1View) {}
    
    public void translationX(View param1View, float param1Float) {}
    
    public void translationXBy(View param1View, float param1Float) {}
    
    public void translationY(View param1View, float param1Float) {}
    
    public void translationYBy(View param1View, float param1Float) {}
    
    public void withEndAction(View param1View, Runnable param1Runnable) {
      param1Runnable.run();
    }
    
    public void withLayer(View param1View) {}
    
    public void withStartAction(View param1View, Runnable param1Runnable) {
      param1Runnable.run();
    }
    
    public void x(View param1View, float param1Float) {}
    
    public void xBy(View param1View, float param1Float) {}
    
    public void y(View param1View, float param1Float) {}
    
    public void yBy(View param1View, float param1Float) {}
  }
  
  static class ICSViewPropertyAnimatorCompatImpl extends BaseViewPropertyAnimatorCompatImpl {
    public void alpha(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.alpha(param1View, param1Float);
    }
    
    public void alphaBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.alphaBy(param1View, param1Float);
    }
    
    public void cancel(View param1View) {
      ViewPropertyAnimatorCompatICS.cancel(param1View);
    }
    
    public long getDuration(View param1View) {
      return ViewPropertyAnimatorCompatICS.getDuration(param1View);
    }
    
    public long getStartDelay(View param1View) {
      return ViewPropertyAnimatorCompatICS.getStartDelay(param1View);
    }
    
    public void rotation(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotation(param1View, param1Float);
    }
    
    public void rotationBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotationBy(param1View, param1Float);
    }
    
    public void rotationX(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotationX(param1View, param1Float);
    }
    
    public void rotationXBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotationXBy(param1View, param1Float);
    }
    
    public void rotationY(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotationY(param1View, param1Float);
    }
    
    public void rotationYBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.rotationYBy(param1View, param1Float);
    }
    
    public void scaleX(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.scaleX(param1View, param1Float);
    }
    
    public void scaleXBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.scaleXBy(param1View, param1Float);
    }
    
    public void scaleY(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.scaleY(param1View, param1Float);
    }
    
    public void scaleYBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.scaleYBy(param1View, param1Float);
    }
    
    public void setDuration(View param1View, long param1Long) {
      ViewPropertyAnimatorCompatICS.setDuration(param1View, param1Long);
    }
    
    public void setInterpolator(View param1View, Interpolator param1Interpolator) {
      ViewPropertyAnimatorCompatICS.setInterpolator(param1View, param1Interpolator);
    }
    
    public void setListener(View param1View, ViewPropertyAnimatorListener param1ViewPropertyAnimatorListener) {
      ViewPropertyAnimatorCompatICS.setListener(param1View, param1ViewPropertyAnimatorListener);
    }
    
    public void setStartDelay(View param1View, long param1Long) {
      ViewPropertyAnimatorCompatICS.setStartDelay(param1View, param1Long);
    }
    
    public void start(View param1View) {
      ViewPropertyAnimatorCompatICS.start(param1View);
    }
    
    public void translationX(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.translationX(param1View, param1Float);
    }
    
    public void translationXBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.translationXBy(param1View, param1Float);
    }
    
    public void translationY(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.translationY(param1View, param1Float);
    }
    
    public void translationYBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.translationYBy(param1View, param1Float);
    }
    
    public void withEndAction(View param1View, final Runnable runnable) {
      setListener(param1View, new ViewPropertyAnimatorListener() {
            public void onAnimationCancel(View param2View) {}
            
            public void onAnimationEnd(View param2View) {
              runnable.run();
              ViewPropertyAnimatorCompat.ICSViewPropertyAnimatorCompatImpl.this.setListener(param2View, null);
            }
            
            public void onAnimationStart(View param2View) {}
          });
    }
    
    public void withLayer(View param1View) {
      setListener(param1View, new ViewPropertyAnimatorListener() {
            public void onAnimationCancel(View param2View) {}
            
            public void onAnimationEnd(View param2View) {
              ViewCompat.setLayerType(param2View, currentLayerType, null);
              ViewPropertyAnimatorCompat.ICSViewPropertyAnimatorCompatImpl.this.setListener(param2View, null);
            }
            
            public void onAnimationStart(View param2View) {
              ViewCompat.setLayerType(param2View, 2, null);
            }
          });
    }
    
    public void withStartAction(View param1View, final Runnable runnable) {
      setListener(param1View, new ViewPropertyAnimatorListener() {
            public void onAnimationCancel(View param2View) {}
            
            public void onAnimationEnd(View param2View) {}
            
            public void onAnimationStart(View param2View) {
              runnable.run();
              ViewPropertyAnimatorCompat.ICSViewPropertyAnimatorCompatImpl.this.setListener(param2View, null);
            }
          });
    }
    
    public void x(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.x(param1View, param1Float);
    }
    
    public void xBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.xBy(param1View, param1Float);
    }
    
    public void y(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.y(param1View, param1Float);
    }
    
    public void yBy(View param1View, float param1Float) {
      ViewPropertyAnimatorCompatICS.yBy(param1View, param1Float);
    }
  }
  
  class null implements ViewPropertyAnimatorListener {
    public void onAnimationCancel(View param1View) {}
    
    public void onAnimationEnd(View param1View) {
      runnable.run();
      this.this$0.setListener(param1View, null);
    }
    
    public void onAnimationStart(View param1View) {}
  }
  
  class null implements ViewPropertyAnimatorListener {
    public void onAnimationCancel(View param1View) {}
    
    public void onAnimationEnd(View param1View) {}
    
    public void onAnimationStart(View param1View) {
      runnable.run();
      this.this$0.setListener(param1View, null);
    }
  }
  
  class null implements ViewPropertyAnimatorListener {
    public void onAnimationCancel(View param1View) {}
    
    public void onAnimationEnd(View param1View) {
      ViewCompat.setLayerType(param1View, currentLayerType, null);
      this.this$0.setListener(param1View, null);
    }
    
    public void onAnimationStart(View param1View) {
      ViewCompat.setLayerType(param1View, 2, null);
    }
  }
  
  static class JBMr2ViewPropertyAnimatorCompatImpl extends JBViewPropertyAnimatorCompatImpl {
    public Interpolator getInterpolator(View param1View) {
      return ViewPropertyAnimatorCompatJellybeanMr2.getInterpolator(param1View);
    }
  }
  
  static class JBViewPropertyAnimatorCompatImpl extends ICSViewPropertyAnimatorCompatImpl {
    public void withEndAction(View param1View, Runnable param1Runnable) {
      ViewPropertyAnimatorCompatJB.withEndAction(param1View, param1Runnable);
    }
    
    public void withLayer(View param1View) {
      ViewPropertyAnimatorCompatJB.withLayer(param1View);
    }
    
    public void withStartAction(View param1View, Runnable param1Runnable) {
      ViewPropertyAnimatorCompatJB.withStartAction(param1View, param1Runnable);
    }
  }
  
  static interface ViewPropertyAnimatorCompatImpl {
    void alpha(View param1View, float param1Float);
    
    void alphaBy(View param1View, float param1Float);
    
    void cancel(View param1View);
    
    long getDuration(View param1View);
    
    Interpolator getInterpolator(View param1View);
    
    long getStartDelay(View param1View);
    
    void rotation(View param1View, float param1Float);
    
    void rotationBy(View param1View, float param1Float);
    
    void rotationX(View param1View, float param1Float);
    
    void rotationXBy(View param1View, float param1Float);
    
    void rotationY(View param1View, float param1Float);
    
    void rotationYBy(View param1View, float param1Float);
    
    void scaleX(View param1View, float param1Float);
    
    void scaleXBy(View param1View, float param1Float);
    
    void scaleY(View param1View, float param1Float);
    
    void scaleYBy(View param1View, float param1Float);
    
    void setDuration(View param1View, long param1Long);
    
    void setInterpolator(View param1View, Interpolator param1Interpolator);
    
    void setListener(View param1View, ViewPropertyAnimatorListener param1ViewPropertyAnimatorListener);
    
    void setStartDelay(View param1View, long param1Long);
    
    void start(View param1View);
    
    void translationX(View param1View, float param1Float);
    
    void translationXBy(View param1View, float param1Float);
    
    void translationY(View param1View, float param1Float);
    
    void translationYBy(View param1View, float param1Float);
    
    void withEndAction(View param1View, Runnable param1Runnable);
    
    void withLayer(View param1View);
    
    void withStartAction(View param1View, Runnable param1Runnable);
    
    void x(View param1View, float param1Float);
    
    void xBy(View param1View, float param1Float);
    
    void y(View param1View, float param1Float);
    
    void yBy(View param1View, float param1Float);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\view\ViewPropertyAnimatorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */