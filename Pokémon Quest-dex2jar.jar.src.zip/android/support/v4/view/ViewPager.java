package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityRecordCompat;
import android.support.v4.widget.EdgeEffectCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ViewPager extends ViewGroup {
  private static final int CLOSE_ENOUGH = 2;
  
  private static final Comparator<ItemInfo> COMPARATOR;
  
  private static final boolean DEBUG = false;
  
  private static final int DEFAULT_GUTTER_SIZE = 16;
  
  private static final int DEFAULT_OFFSCREEN_PAGES = 1;
  
  private static final int DRAW_ORDER_DEFAULT = 0;
  
  private static final int DRAW_ORDER_FORWARD = 1;
  
  private static final int DRAW_ORDER_REVERSE = 2;
  
  private static final int INVALID_POINTER = -1;
  
  private static final int[] LAYOUT_ATTRS = new int[] { 16842931 };
  
  private static final int MAX_SETTLE_DURATION = 600;
  
  private static final int MIN_DISTANCE_FOR_FLING = 25;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  public static final int SCROLL_STATE_DRAGGING = 1;
  
  public static final int SCROLL_STATE_IDLE = 0;
  
  public static final int SCROLL_STATE_SETTLING = 2;
  
  private static final String TAG = "ViewPager";
  
  private static final boolean USE_CACHE = false;
  
  private static final Interpolator sInterpolator;
  
  private static final ViewPositionComparator sPositionComparator;
  
  private int mActivePointerId = -1;
  
  private PagerAdapter mAdapter;
  
  private OnAdapterChangeListener mAdapterChangeListener;
  
  private int mBottomPageBounds;
  
  private boolean mCalledSuper;
  
  private int mChildHeightMeasureSpec;
  
  private int mChildWidthMeasureSpec;
  
  private int mCloseEnough;
  
  private int mCurItem;
  
  private int mDecorChildCount;
  
  private int mDefaultGutterSize;
  
  private int mDrawingOrder;
  
  private ArrayList<View> mDrawingOrderedChildren;
  
  private final Runnable mEndScrollRunnable = new Runnable() {
      public void run() {
        ViewPager.this.setScrollState(0);
        ViewPager.this.populate();
      }
    };
  
  private int mExpectedAdapterCount;
  
  private long mFakeDragBeginTime;
  
  private boolean mFakeDragging;
  
  private boolean mFirstLayout = true;
  
  private float mFirstOffset = -3.4028235E38F;
  
  private int mFlingDistance;
  
  private int mGutterSize;
  
  private boolean mIgnoreGutter;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private OnPageChangeListener mInternalPageChangeListener;
  
  private boolean mIsBeingDragged;
  
  private boolean mIsUnableToDrag;
  
  private final ArrayList<ItemInfo> mItems = new ArrayList<ItemInfo>();
  
  private float mLastMotionX;
  
  private float mLastMotionY;
  
  private float mLastOffset = Float.MAX_VALUE;
  
  private EdgeEffectCompat mLeftEdge;
  
  private Drawable mMarginDrawable;
  
  private int mMaximumVelocity;
  
  private int mMinimumVelocity;
  
  private boolean mNeedCalculatePageOffsets = false;
  
  private PagerObserver mObserver;
  
  private int mOffscreenPageLimit = 1;
  
  private OnPageChangeListener mOnPageChangeListener;
  
  private int mPageMargin;
  
  private PageTransformer mPageTransformer;
  
  private boolean mPopulatePending;
  
  private Parcelable mRestoredAdapterState = null;
  
  private ClassLoader mRestoredClassLoader = null;
  
  private int mRestoredCurItem = -1;
  
  private EdgeEffectCompat mRightEdge;
  
  private int mScrollState = 0;
  
  private Scroller mScroller;
  
  private boolean mScrollingCacheEnabled;
  
  private Method mSetChildrenDrawingOrderEnabled;
  
  private final ItemInfo mTempItem = new ItemInfo();
  
  private final Rect mTempRect = new Rect();
  
  private int mTopPageBounds;
  
  private int mTouchSlop;
  
  private VelocityTracker mVelocityTracker;
  
  static {
    COMPARATOR = new Comparator<ItemInfo>() {
        public int compare(ViewPager.ItemInfo param1ItemInfo1, ViewPager.ItemInfo param1ItemInfo2) {
          return param1ItemInfo1.position - param1ItemInfo2.position;
        }
      };
    sInterpolator = new Interpolator() {
        public float getInterpolation(float param1Float) {
          param1Float--;
          return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
        }
      };
    sPositionComparator = new ViewPositionComparator();
  }
  
  public ViewPager(Context paramContext) {
    super(paramContext);
    initViewPager();
  }
  
  public ViewPager(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initViewPager();
  }
  
  private void calculatePageOffsets(ItemInfo paramItemInfo1, int paramInt, ItemInfo paramItemInfo2) {
    float f2;
    int m = this.mAdapter.getCount();
    int i = getClientWidth();
    if (i > 0) {
      f2 = this.mPageMargin / i;
    } else {
      f2 = 0.0F;
    } 
    if (paramItemInfo2 != null) {
      i = paramItemInfo2.position;
      if (i < paramItemInfo1.position) {
        f1 = paramItemInfo2.offset + paramItemInfo2.widthFactor + f2;
        i++;
        int n = 0;
        while (i <= paramItemInfo1.position && n < this.mItems.size()) {
          float f;
          int i1;
          paramItemInfo2 = this.mItems.get(n);
          while (true) {
            i1 = i;
            f = f1;
            if (i > paramItemInfo2.position) {
              i1 = i;
              f = f1;
              if (n < this.mItems.size() - 1) {
                paramItemInfo2 = this.mItems.get(++n);
                continue;
              } 
            } 
            break;
          } 
          while (i1 < paramItemInfo2.position) {
            f += this.mAdapter.getPageWidth(i1) + f2;
            i1++;
          } 
          paramItemInfo2.offset = f;
          f1 = f + paramItemInfo2.widthFactor + f2;
          i = i1 + 1;
        } 
      } else if (i > paramItemInfo1.position) {
        int n = this.mItems.size() - 1;
        f1 = paramItemInfo2.offset;
        while (--i >= paramItemInfo1.position && n >= 0) {
          float f;
          int i1;
          paramItemInfo2 = this.mItems.get(n);
          while (true) {
            i1 = i;
            f = f1;
            if (i < paramItemInfo2.position) {
              i1 = i;
              f = f1;
              if (n > 0) {
                paramItemInfo2 = this.mItems.get(--n);
                continue;
              } 
            } 
            break;
          } 
          while (i1 > paramItemInfo2.position) {
            f -= this.mAdapter.getPageWidth(i1) + f2;
            i1--;
          } 
          f1 = f - paramItemInfo2.widthFactor + f2;
          paramItemInfo2.offset = f1;
          i = i1 - 1;
        } 
      } 
    } 
    int k = this.mItems.size();
    float f3 = paramItemInfo1.offset;
    i = paramItemInfo1.position - 1;
    if (paramItemInfo1.position == 0) {
      f1 = paramItemInfo1.offset;
    } else {
      f1 = -3.4028235E38F;
    } 
    this.mFirstOffset = f1;
    int j = paramItemInfo1.position;
    if (j == --m) {
      f1 = paramItemInfo1.offset + paramItemInfo1.widthFactor - 1.0F;
    } else {
      f1 = Float.MAX_VALUE;
    } 
    this.mLastOffset = f1;
    j = paramInt - 1;
    float f1 = f3;
    while (j >= 0) {
      paramItemInfo2 = this.mItems.get(j);
      while (i > paramItemInfo2.position) {
        f1 -= this.mAdapter.getPageWidth(i) + f2;
        i--;
      } 
      f1 -= paramItemInfo2.widthFactor + f2;
      paramItemInfo2.offset = f1;
      if (paramItemInfo2.position == 0)
        this.mFirstOffset = f1; 
      j--;
      i--;
    } 
    f1 = paramItemInfo1.offset + paramItemInfo1.widthFactor + f2;
    j = paramItemInfo1.position + 1;
    i = paramInt + 1;
    for (paramInt = j; i < k; paramInt++) {
      paramItemInfo1 = this.mItems.get(i);
      while (paramInt < paramItemInfo1.position) {
        f1 += this.mAdapter.getPageWidth(paramInt) + f2;
        paramInt++;
      } 
      if (paramItemInfo1.position == m)
        this.mLastOffset = paramItemInfo1.widthFactor + f1 - 1.0F; 
      paramItemInfo1.offset = f1;
      f1 += paramItemInfo1.widthFactor + f2;
      i++;
    } 
    this.mNeedCalculatePageOffsets = false;
  }
  
  private void completeScroll(boolean paramBoolean) {
    if (this.mScrollState == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      setScrollingCacheEnabled(false);
      this.mScroller.abortAnimation();
      int k = getScrollX();
      int m = getScrollY();
      int n = this.mScroller.getCurrX();
      int i1 = this.mScroller.getCurrY();
      if (k != n || m != i1)
        scrollTo(n, i1); 
    } 
    this.mPopulatePending = false;
    byte b = 0;
    int j = i;
    for (int i = b; i < this.mItems.size(); i++) {
      ItemInfo itemInfo = this.mItems.get(i);
      if (itemInfo.scrolling) {
        itemInfo.scrolling = false;
        j = 1;
      } 
    } 
    if (j != 0) {
      if (paramBoolean) {
        ViewCompat.postOnAnimation((View)this, this.mEndScrollRunnable);
        return;
      } 
      this.mEndScrollRunnable.run();
    } 
  }
  
  private int determineTargetPage(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    if (Math.abs(paramInt3) > this.mFlingDistance && Math.abs(paramInt2) > this.mMinimumVelocity) {
      if (paramInt2 <= 0)
        paramInt1++; 
    } else {
      float f;
      if (paramInt1 >= this.mCurItem) {
        f = 0.4F;
      } else {
        f = 0.6F;
      } 
      paramInt1 = (int)(paramInt1 + paramFloat + f);
    } 
    paramInt2 = paramInt1;
    if (this.mItems.size() > 0) {
      ItemInfo itemInfo1 = this.mItems.get(0);
      ArrayList<ItemInfo> arrayList = this.mItems;
      ItemInfo itemInfo2 = arrayList.get(arrayList.size() - 1);
      paramInt2 = Math.max(itemInfo1.position, Math.min(paramInt1, itemInfo2.position));
    } 
    return paramInt2;
  }
  
  private void enableLayers(boolean paramBoolean) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewCompat.setLayerType(getChildAt(i), bool, null);
    } 
  }
  
  private void endDrag() {
    this.mIsBeingDragged = false;
    this.mIsUnableToDrag = false;
    VelocityTracker velocityTracker = this.mVelocityTracker;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.mVelocityTracker = null;
    } 
  }
  
  private Rect getChildRectInPagerCoordinates(Rect paramRect, View paramView) {
    Rect rect = paramRect;
    if (paramRect == null)
      rect = new Rect(); 
    if (paramView == null) {
      rect.set(0, 0, 0, 0);
      return rect;
    } 
    rect.left = paramView.getLeft();
    rect.right = paramView.getRight();
    rect.top = paramView.getTop();
    rect.bottom = paramView.getBottom();
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof ViewGroup && viewParent != this) {
      ViewGroup viewGroup = (ViewGroup)viewParent;
      rect.left += viewGroup.getLeft();
      rect.right += viewGroup.getRight();
      rect.top += viewGroup.getTop();
      rect.bottom += viewGroup.getBottom();
      ViewParent viewParent1 = viewGroup.getParent();
    } 
    return rect;
  }
  
  private int getClientWidth() {
    return getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
  }
  
  private ItemInfo infoForCurrentScrollPosition() {
    float f1;
    float f2;
    int i = getClientWidth();
    if (i > 0) {
      f1 = getScrollX() / i;
    } else {
      f1 = 0.0F;
    } 
    if (i > 0) {
      f2 = this.mPageMargin / i;
    } else {
      f2 = 0.0F;
    } 
    ItemInfo itemInfo = null;
    i = 0;
    boolean bool = true;
    int j = -1;
    float f3 = 0.0F;
    float f4 = 0.0F;
    while (i < this.mItems.size()) {
      ItemInfo itemInfo2 = this.mItems.get(i);
      int k = i;
      ItemInfo itemInfo1 = itemInfo2;
      if (!bool) {
        int m = itemInfo2.position;
        j++;
        k = i;
        itemInfo1 = itemInfo2;
        if (m != j) {
          itemInfo1 = this.mTempItem;
          itemInfo1.offset = f3 + f4 + f2;
          itemInfo1.position = j;
          itemInfo1.widthFactor = this.mAdapter.getPageWidth(itemInfo1.position);
          k = i - 1;
        } 
      } 
      f3 = itemInfo1.offset;
      f4 = itemInfo1.widthFactor;
      if (bool || f1 >= f3) {
        if (f1 >= f4 + f3 + f2) {
          if (k == this.mItems.size() - 1)
            return itemInfo1; 
          j = itemInfo1.position;
          f4 = itemInfo1.widthFactor;
          i = k + 1;
          bool = false;
          itemInfo = itemInfo1;
          continue;
        } 
        return itemInfo1;
      } 
      return itemInfo;
    } 
    return itemInfo;
  }
  
  private boolean isGutterDrag(float paramFloat1, float paramFloat2) {
    return ((paramFloat1 < this.mGutterSize && paramFloat2 > 0.0F) || (paramFloat1 > (getWidth() - this.mGutterSize) && paramFloat2 < 0.0F));
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = MotionEventCompat.getActionIndex(paramMotionEvent);
    if (MotionEventCompat.getPointerId(paramMotionEvent, i) == this.mActivePointerId) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.mLastMotionX = MotionEventCompat.getX(paramMotionEvent, i);
      this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, i);
      VelocityTracker velocityTracker = this.mVelocityTracker;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  private boolean pageScrolled(int paramInt) {
    if (this.mItems.size() == 0) {
      this.mCalledSuper = false;
      onPageScrolled(0, 0.0F, 0);
      if (this.mCalledSuper)
        return false; 
      throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    } 
    ItemInfo itemInfo = infoForCurrentScrollPosition();
    int j = getClientWidth();
    int k = this.mPageMargin;
    float f2 = k;
    float f1 = j;
    f2 /= f1;
    int i = itemInfo.position;
    f1 = (paramInt / f1 - itemInfo.offset) / (itemInfo.widthFactor + f2);
    paramInt = (int)((j + k) * f1);
    this.mCalledSuper = false;
    onPageScrolled(i, f1, paramInt);
    if (this.mCalledSuper)
      return true; 
    throw new IllegalStateException("onPageScrolled did not call superclass implementation");
  }
  
  private boolean performDrag(float paramFloat) {
    float f1 = this.mLastMotionX;
    this.mLastMotionX = paramFloat;
    float f2 = getScrollX() + f1 - paramFloat;
    float f3 = getClientWidth();
    paramFloat = this.mFirstOffset * f3;
    f1 = this.mLastOffset * f3;
    ArrayList<ItemInfo> arrayList1 = this.mItems;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool = false;
    ItemInfo itemInfo1 = arrayList1.get(0);
    ArrayList<ItemInfo> arrayList2 = this.mItems;
    int i = arrayList2.size();
    boolean bool1 = true;
    ItemInfo itemInfo2 = arrayList2.get(i - 1);
    if (itemInfo1.position != 0) {
      paramFloat = itemInfo1.offset * f3;
      i = 0;
    } else {
      i = 1;
    } 
    if (itemInfo2.position != this.mAdapter.getCount() - 1) {
      f1 = itemInfo2.offset * f3;
      bool1 = false;
    } 
    if (f2 < paramFloat) {
      if (i != 0)
        bool = this.mLeftEdge.onPull(Math.abs(paramFloat - f2) / f3); 
    } else {
      bool = bool3;
      paramFloat = f2;
      if (f2 > f1) {
        bool = bool2;
        if (bool1)
          bool = this.mRightEdge.onPull(Math.abs(f2 - f1) / f3); 
        paramFloat = f1;
      } 
    } 
    f1 = this.mLastMotionX;
    i = (int)paramFloat;
    this.mLastMotionX = f1 + paramFloat - i;
    scrollTo(i, getScrollY());
    pageScrolled(i);
    return bool;
  }
  
  private void recomputeScrollPosition(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt2 > 0 && !this.mItems.isEmpty()) {
      int i = getPaddingLeft();
      int j = getPaddingRight();
      int k = getPaddingLeft();
      int m = getPaddingRight();
      paramInt2 = (int)(getScrollX() / (paramInt2 - k - m + paramInt4) * (paramInt1 - i - j + paramInt3));
      scrollTo(paramInt2, getScrollY());
      if (!this.mScroller.isFinished()) {
        paramInt3 = this.mScroller.getDuration();
        paramInt4 = this.mScroller.timePassed();
        ItemInfo itemInfo = infoForPosition(this.mCurItem);
        this.mScroller.startScroll(paramInt2, 0, (int)(itemInfo.offset * paramInt1), 0, paramInt3 - paramInt4);
        return;
      } 
    } else {
      float f;
      ItemInfo itemInfo = infoForPosition(this.mCurItem);
      if (itemInfo != null) {
        f = Math.min(itemInfo.offset, this.mLastOffset);
      } else {
        f = 0.0F;
      } 
      paramInt1 = (int)(f * (paramInt1 - getPaddingLeft() - getPaddingRight()));
      if (paramInt1 != getScrollX()) {
        completeScroll(false);
        scrollTo(paramInt1, getScrollY());
      } 
    } 
  }
  
  private void removeNonDecorViews() {
    for (int i = 0; i < getChildCount(); i = j + 1) {
      int j = i;
      if (!((LayoutParams)getChildAt(i).getLayoutParams()).isDecor) {
        removeViewAt(i);
        j = i - 1;
      } 
    } 
  }
  
  private void requestParentDisallowInterceptTouchEvent(boolean paramBoolean) {
    ViewParent viewParent = getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(paramBoolean); 
  }
  
  private void scrollToItem(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2) {
    boolean bool;
    ItemInfo itemInfo = infoForPosition(paramInt1);
    if (itemInfo != null) {
      bool = (int)(getClientWidth() * Math.max(this.mFirstOffset, Math.min(itemInfo.offset, this.mLastOffset)));
    } else {
      bool = false;
    } 
    if (paramBoolean1) {
      smoothScrollTo(bool, 0, paramInt2);
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListener;
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(paramInt1); 
      } 
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
        if (onPageChangeListener != null) {
          onPageChangeListener.onPageSelected(paramInt1);
          return;
        } 
      } 
    } else {
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListener;
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(paramInt1); 
      } 
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(paramInt1); 
      } 
      completeScroll(false);
      scrollTo(bool, 0);
      pageScrolled(bool);
    } 
  }
  
  private void setScrollState(int paramInt) {
    if (this.mScrollState == paramInt)
      return; 
    this.mScrollState = paramInt;
    if (this.mPageTransformer != null) {
      boolean bool;
      if (paramInt != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      enableLayers(bool);
    } 
    OnPageChangeListener onPageChangeListener = this.mOnPageChangeListener;
    if (onPageChangeListener != null)
      onPageChangeListener.onPageScrollStateChanged(paramInt); 
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean) {
    if (this.mScrollingCacheEnabled != paramBoolean)
      this.mScrollingCacheEnabled = paramBoolean; 
  }
  
  private void sortChildDrawingOrder() {
    if (this.mDrawingOrder != 0) {
      ArrayList<View> arrayList = this.mDrawingOrderedChildren;
      if (arrayList == null) {
        this.mDrawingOrderedChildren = new ArrayList<View>();
      } else {
        arrayList.clear();
      } 
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        View view = getChildAt(i);
        this.mDrawingOrderedChildren.add(view);
      } 
      Collections.sort(this.mDrawingOrderedChildren, sPositionComparator);
    } 
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    int i = paramArrayList.size();
    int j = getDescendantFocusability();
    if (j != 393216) {
      int k;
      for (k = 0; k < getChildCount(); k++) {
        View view = getChildAt(k);
        if (view.getVisibility() == 0) {
          ItemInfo itemInfo = infoForChild(view);
          if (itemInfo != null && itemInfo.position == this.mCurItem)
            view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        } 
      } 
    } 
    if (j != 262144 || i == paramArrayList.size()) {
      if (!isFocusable())
        return; 
      if ((paramInt2 & 0x1) == 1 && isInTouchMode() && !isFocusableInTouchMode())
        return; 
      if (paramArrayList != null)
        paramArrayList.add(this); 
    } 
  }
  
  ItemInfo addNewItem(int paramInt1, int paramInt2) {
    ItemInfo itemInfo = new ItemInfo();
    itemInfo.position = paramInt1;
    itemInfo.object = this.mAdapter.instantiateItem(this, paramInt1);
    itemInfo.widthFactor = this.mAdapter.getPageWidth(paramInt1);
    if (paramInt2 < 0 || paramInt2 >= this.mItems.size()) {
      this.mItems.add(itemInfo);
      return itemInfo;
    } 
    this.mItems.add(paramInt2, itemInfo);
    return itemInfo;
  }
  
  public void addTouchables(ArrayList<View> paramArrayList) {
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = infoForChild(view);
        if (itemInfo != null && itemInfo.position == this.mCurItem)
          view.addTouchables(paramArrayList); 
      } 
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    ViewGroup.LayoutParams layoutParams = paramLayoutParams;
    if (!checkLayoutParams(paramLayoutParams))
      layoutParams = generateLayoutParams(paramLayoutParams); 
    paramLayoutParams = layoutParams;
    ((LayoutParams)paramLayoutParams).isDecor |= paramView instanceof Decor;
    if (this.mInLayout) {
      if (paramLayoutParams == null || !((LayoutParams)paramLayoutParams).isDecor) {
        ((LayoutParams)paramLayoutParams).needsMeasure = true;
        addViewInLayout(paramView, paramInt, layoutParams);
        return;
      } 
      throw new IllegalStateException("Cannot add pager decor view during layout");
    } 
    super.addView(paramView, paramInt, layoutParams);
  }
  
  public boolean arrowScroll(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual findFocus : ()Landroid/view/View;
    //   4: astore #7
    //   6: iconst_0
    //   7: istore #4
    //   9: aconst_null
    //   10: astore #6
    //   12: aload #7
    //   14: aload_0
    //   15: if_acmpne -> 25
    //   18: aload #6
    //   20: astore #5
    //   22: goto -> 198
    //   25: aload #7
    //   27: ifnull -> 194
    //   30: aload #7
    //   32: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   35: astore #5
    //   37: aload #5
    //   39: instanceof android/view/ViewGroup
    //   42: ifeq -> 68
    //   45: aload #5
    //   47: aload_0
    //   48: if_acmpne -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 70
    //   56: aload #5
    //   58: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   63: astore #5
    //   65: goto -> 37
    //   68: iconst_0
    //   69: istore_2
    //   70: iload_2
    //   71: ifne -> 194
    //   74: new java/lang/StringBuilder
    //   77: dup
    //   78: invokespecial <init> : ()V
    //   81: astore #8
    //   83: aload #8
    //   85: aload #7
    //   87: invokevirtual getClass : ()Ljava/lang/Class;
    //   90: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: pop
    //   97: aload #7
    //   99: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   102: astore #5
    //   104: aload #5
    //   106: instanceof android/view/ViewGroup
    //   109: ifeq -> 147
    //   112: aload #8
    //   114: ldc_w ' => '
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: aload #8
    //   123: aload #5
    //   125: invokevirtual getClass : ()Ljava/lang/Class;
    //   128: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   131: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: pop
    //   135: aload #5
    //   137: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   142: astore #5
    //   144: goto -> 104
    //   147: new java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: astore #5
    //   156: aload #5
    //   158: ldc_w 'arrowScroll tried to find focus based on non-child current focused view '
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload #5
    //   167: aload #8
    //   169: invokevirtual toString : ()Ljava/lang/String;
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: pop
    //   176: ldc 'ViewPager'
    //   178: aload #5
    //   180: invokevirtual toString : ()Ljava/lang/String;
    //   183: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   186: pop
    //   187: aload #6
    //   189: astore #5
    //   191: goto -> 198
    //   194: aload #7
    //   196: astore #5
    //   198: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   201: aload_0
    //   202: aload #5
    //   204: iload_1
    //   205: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   208: astore #6
    //   210: aload #6
    //   212: ifnull -> 348
    //   215: aload #6
    //   217: aload #5
    //   219: if_acmpeq -> 348
    //   222: iload_1
    //   223: bipush #17
    //   225: if_icmpne -> 285
    //   228: aload_0
    //   229: aload_0
    //   230: getfield mTempRect : Landroid/graphics/Rect;
    //   233: aload #6
    //   235: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   238: getfield left : I
    //   241: istore_2
    //   242: aload_0
    //   243: aload_0
    //   244: getfield mTempRect : Landroid/graphics/Rect;
    //   247: aload #5
    //   249: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   252: getfield left : I
    //   255: istore_3
    //   256: aload #5
    //   258: ifnull -> 275
    //   261: iload_2
    //   262: iload_3
    //   263: if_icmplt -> 275
    //   266: aload_0
    //   267: invokevirtual pageLeft : ()Z
    //   270: istore #4
    //   272: goto -> 282
    //   275: aload #6
    //   277: invokevirtual requestFocus : ()Z
    //   280: istore #4
    //   282: goto -> 388
    //   285: iload_1
    //   286: bipush #66
    //   288: if_icmpne -> 388
    //   291: aload_0
    //   292: aload_0
    //   293: getfield mTempRect : Landroid/graphics/Rect;
    //   296: aload #6
    //   298: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   301: getfield left : I
    //   304: istore_2
    //   305: aload_0
    //   306: aload_0
    //   307: getfield mTempRect : Landroid/graphics/Rect;
    //   310: aload #5
    //   312: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   315: getfield left : I
    //   318: istore_3
    //   319: aload #5
    //   321: ifnull -> 338
    //   324: iload_2
    //   325: iload_3
    //   326: if_icmpgt -> 338
    //   329: aload_0
    //   330: invokevirtual pageRight : ()Z
    //   333: istore #4
    //   335: goto -> 282
    //   338: aload #6
    //   340: invokevirtual requestFocus : ()Z
    //   343: istore #4
    //   345: goto -> 282
    //   348: iload_1
    //   349: bipush #17
    //   351: if_icmpeq -> 382
    //   354: iload_1
    //   355: iconst_1
    //   356: if_icmpne -> 362
    //   359: goto -> 382
    //   362: iload_1
    //   363: bipush #66
    //   365: if_icmpeq -> 373
    //   368: iload_1
    //   369: iconst_2
    //   370: if_icmpne -> 388
    //   373: aload_0
    //   374: invokevirtual pageRight : ()Z
    //   377: istore #4
    //   379: goto -> 388
    //   382: aload_0
    //   383: invokevirtual pageLeft : ()Z
    //   386: istore #4
    //   388: iload #4
    //   390: ifeq -> 401
    //   393: aload_0
    //   394: iload_1
    //   395: invokestatic getContantForFocusDirection : (I)I
    //   398: invokevirtual playSoundEffect : (I)V
    //   401: iload #4
    //   403: ireturn
  }
  
  public boolean beginFakeDrag() {
    if (this.mIsBeingDragged)
      return false; 
    this.mFakeDragging = true;
    setScrollState(1);
    this.mLastMotionX = 0.0F;
    this.mInitialMotionX = 0.0F;
    VelocityTracker velocityTracker = this.mVelocityTracker;
    if (velocityTracker == null) {
      this.mVelocityTracker = VelocityTracker.obtain();
    } else {
      velocityTracker.clear();
    } 
    long l = SystemClock.uptimeMillis();
    MotionEvent motionEvent = MotionEvent.obtain(l, l, 0, 0.0F, 0.0F, 0);
    this.mVelocityTracker.addMovement(motionEvent);
    motionEvent.recycle();
    this.mFakeDragBeginTime = l;
    return true;
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = paramView.getScrollX();
      int k = paramView.getScrollY();
      int i;
      for (i = viewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = viewGroup.getChildAt(i);
        int m = paramInt2 + j;
        if (m >= view.getLeft() && m < view.getRight()) {
          int n = paramInt3 + k;
          if (n >= view.getTop() && n < view.getBottom() && canScroll(view, true, paramInt1, m - view.getLeft(), n - view.getTop()))
            return true; 
        } 
      } 
    } 
    return (paramBoolean && ViewCompat.canScrollHorizontally(paramView, -paramInt1));
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    PagerAdapter pagerAdapter = this.mAdapter;
    boolean bool2 = false;
    boolean bool1 = false;
    if (pagerAdapter == null)
      return false; 
    int i = getClientWidth();
    int j = getScrollX();
    if (paramInt < 0) {
      if (j > (int)(i * this.mFirstOffset))
        bool1 = true; 
      return bool1;
    } 
    bool1 = bool2;
    if (paramInt > 0) {
      bool1 = bool2;
      if (j < (int)(i * this.mLastOffset))
        bool1 = true; 
    } 
    return bool1;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    if (!this.mScroller.isFinished() && this.mScroller.computeScrollOffset()) {
      int i = getScrollX();
      int j = getScrollY();
      int k = this.mScroller.getCurrX();
      int m = this.mScroller.getCurrY();
      if (i != k || j != m) {
        scrollTo(k, m);
        if (!pageScrolled(k)) {
          this.mScroller.abortAnimation();
          scrollTo(0, m);
        } 
      } 
      ViewCompat.postInvalidateOnAnimation((View)this);
      return;
    } 
    completeScroll(true);
  }
  
  void dataSetChanged() {
    Object object1;
    int i;
    Object object2;
    int k;
    int i2 = this.mAdapter.getCount();
    this.mExpectedAdapterCount = i2;
    if (this.mItems.size() < this.mOffscreenPageLimit * 2 + 1 && this.mItems.size() < i2) {
      j = 1;
    } else {
      j = 0;
    } 
    int m = this.mCurItem;
    int i1 = j;
    int j = m;
    int n = 0;
    m = 0;
    while (n < this.mItems.size()) {
      ItemInfo itemInfo = this.mItems.get(n);
      int i6 = this.mAdapter.getItemPosition(itemInfo.object);
      if (i6 == -1) {
        int i7 = n;
        Object object3 = object2;
        Object object4 = object1;
        continue;
      } 
      if (i6 == -2) {
        byte b;
        this.mItems.remove(n);
        int i7 = n - 1;
        Object object = object2;
        if (object2 == null) {
          this.mAdapter.startUpdate(this);
          b = 1;
        } 
        this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
        n = i7;
        k = b;
        if (this.mCurItem == itemInfo.position) {
          i = Math.max(0, Math.min(this.mCurItem, i2 - 1));
          k = b;
          n = i7;
        } 
      } else {
        int i7 = n;
        int i8 = k;
        int i9 = i;
        if (itemInfo.position != i6) {
          if (itemInfo.position == this.mCurItem)
            i = i6; 
          itemInfo.position = i6;
        } else {
          continue;
        } 
      } 
      i1 = 1;
      int i3 = n;
      int i4 = k;
      int i5 = i;
      continue;
      n = SYNTHETIC_LOCAL_VARIABLE_4 + 1;
      object2 = SYNTHETIC_LOCAL_VARIABLE_5;
      object1 = SYNTHETIC_LOCAL_VARIABLE_7;
    } 
    if (k)
      this.mAdapter.finishUpdate(this); 
    Collections.sort(this.mItems, COMPARATOR);
    if (i1 != 0) {
      n = getChildCount();
      for (k = 0; k < n; k++) {
        LayoutParams layoutParams = (LayoutParams)getChildAt(k).getLayoutParams();
        if (!layoutParams.isDecor)
          layoutParams.widthFactor = 0.0F; 
      } 
      setCurrentItemInternal(i, false, true);
      requestLayout();
    } 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || executeKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 4096)
      return super.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent); 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = infoForChild(view);
        if (itemInfo != null && itemInfo.position == this.mCurItem && view.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))
          return true; 
      } 
    } 
    return false;
  }
  
  float distanceInfluenceForSnapDuration(float paramFloat) {
    double d = (paramFloat - 0.5F);
    Double.isNaN(d);
    return (float)Math.sin((float)(d * 0.4712389167638204D));
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: invokestatic getOverScrollMode : (Landroid/view/View;)I
    //   9: istore #4
    //   11: iconst_0
    //   12: istore_3
    //   13: iconst_0
    //   14: istore_2
    //   15: iload #4
    //   17: ifeq -> 66
    //   20: iload #4
    //   22: iconst_1
    //   23: if_icmpne -> 49
    //   26: aload_0
    //   27: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   30: astore #8
    //   32: aload #8
    //   34: ifnull -> 49
    //   37: aload #8
    //   39: invokevirtual getCount : ()I
    //   42: iconst_1
    //   43: if_icmple -> 49
    //   46: goto -> 66
    //   49: aload_0
    //   50: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   53: invokevirtual finish : ()V
    //   56: aload_0
    //   57: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   60: invokevirtual finish : ()V
    //   63: goto -> 256
    //   66: aload_0
    //   67: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   70: invokevirtual isFinished : ()Z
    //   73: ifne -> 155
    //   76: aload_1
    //   77: invokevirtual save : ()I
    //   80: istore_3
    //   81: aload_0
    //   82: invokevirtual getHeight : ()I
    //   85: aload_0
    //   86: invokevirtual getPaddingTop : ()I
    //   89: isub
    //   90: aload_0
    //   91: invokevirtual getPaddingBottom : ()I
    //   94: isub
    //   95: istore_2
    //   96: aload_0
    //   97: invokevirtual getWidth : ()I
    //   100: istore #4
    //   102: aload_1
    //   103: ldc_w 270.0
    //   106: invokevirtual rotate : (F)V
    //   109: aload_1
    //   110: iload_2
    //   111: ineg
    //   112: aload_0
    //   113: invokevirtual getPaddingTop : ()I
    //   116: iadd
    //   117: i2f
    //   118: aload_0
    //   119: getfield mFirstOffset : F
    //   122: iload #4
    //   124: i2f
    //   125: fmul
    //   126: invokevirtual translate : (FF)V
    //   129: aload_0
    //   130: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   133: iload_2
    //   134: iload #4
    //   136: invokevirtual setSize : (II)V
    //   139: iconst_0
    //   140: aload_0
    //   141: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   144: aload_1
    //   145: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   148: ior
    //   149: istore_2
    //   150: aload_1
    //   151: iload_3
    //   152: invokevirtual restoreToCount : (I)V
    //   155: iload_2
    //   156: istore_3
    //   157: aload_0
    //   158: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   161: invokevirtual isFinished : ()Z
    //   164: ifne -> 256
    //   167: aload_1
    //   168: invokevirtual save : ()I
    //   171: istore #4
    //   173: aload_0
    //   174: invokevirtual getWidth : ()I
    //   177: istore_3
    //   178: aload_0
    //   179: invokevirtual getHeight : ()I
    //   182: istore #5
    //   184: aload_0
    //   185: invokevirtual getPaddingTop : ()I
    //   188: istore #6
    //   190: aload_0
    //   191: invokevirtual getPaddingBottom : ()I
    //   194: istore #7
    //   196: aload_1
    //   197: ldc_w 90.0
    //   200: invokevirtual rotate : (F)V
    //   203: aload_1
    //   204: aload_0
    //   205: invokevirtual getPaddingTop : ()I
    //   208: ineg
    //   209: i2f
    //   210: aload_0
    //   211: getfield mLastOffset : F
    //   214: fconst_1
    //   215: fadd
    //   216: fneg
    //   217: iload_3
    //   218: i2f
    //   219: fmul
    //   220: invokevirtual translate : (FF)V
    //   223: aload_0
    //   224: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   227: iload #5
    //   229: iload #6
    //   231: isub
    //   232: iload #7
    //   234: isub
    //   235: iload_3
    //   236: invokevirtual setSize : (II)V
    //   239: iload_2
    //   240: aload_0
    //   241: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   244: aload_1
    //   245: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   248: ior
    //   249: istore_3
    //   250: aload_1
    //   251: iload #4
    //   253: invokevirtual restoreToCount : (I)V
    //   256: iload_3
    //   257: ifeq -> 264
    //   260: aload_0
    //   261: invokestatic postInvalidateOnAnimation : (Landroid/view/View;)V
    //   264: return
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.mMarginDrawable;
    if (drawable != null && drawable.isStateful())
      drawable.setState(getDrawableState()); 
  }
  
  public void endFakeDrag() {
    if (this.mFakeDragging) {
      VelocityTracker velocityTracker = this.mVelocityTracker;
      velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
      int i = (int)VelocityTrackerCompat.getXVelocity(velocityTracker, this.mActivePointerId);
      this.mPopulatePending = true;
      int j = getClientWidth();
      int k = getScrollX();
      ItemInfo itemInfo = infoForCurrentScrollPosition();
      setCurrentItemInternal(determineTargetPage(itemInfo.position, (k / j - itemInfo.offset) / itemInfo.widthFactor, i, (int)(this.mLastMotionX - this.mInitialMotionX)), true, true, i);
      endDrag();
      this.mFakeDragging = false;
      return;
    } 
    throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
  }
  
  public boolean executeKeyEvent(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 0) {
      int i = paramKeyEvent.getKeyCode();
      if (i != 21) {
        if (i != 22) {
          if (i == 61 && Build.VERSION.SDK_INT >= 11) {
            if (KeyEventCompat.hasNoModifiers(paramKeyEvent))
              return arrowScroll(2); 
            if (KeyEventCompat.hasModifiers(paramKeyEvent, 1))
              return arrowScroll(1); 
          } 
        } else {
          return arrowScroll(66);
        } 
      } else {
        return arrowScroll(17);
      } 
    } 
    return false;
  }
  
  public void fakeDragBy(float paramFloat) {
    if (this.mFakeDragging) {
      this.mLastMotionX += paramFloat;
      float f2 = getScrollX() - paramFloat;
      float f3 = getClientWidth();
      paramFloat = this.mFirstOffset * f3;
      float f1 = this.mLastOffset * f3;
      ItemInfo itemInfo1 = this.mItems.get(0);
      ArrayList<ItemInfo> arrayList = this.mItems;
      ItemInfo itemInfo2 = arrayList.get(arrayList.size() - 1);
      if (itemInfo1.position != 0)
        paramFloat = itemInfo1.offset * f3; 
      if (itemInfo2.position != this.mAdapter.getCount() - 1)
        f1 = itemInfo2.offset * f3; 
      if (f2 >= paramFloat) {
        paramFloat = f2;
        if (f2 > f1)
          paramFloat = f1; 
      } 
      f1 = this.mLastMotionX;
      int i = (int)paramFloat;
      this.mLastMotionX = f1 + paramFloat - i;
      scrollTo(i, getScrollY());
      pageScrolled(i);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(this.mFakeDragBeginTime, l, 2, this.mLastMotionX, 0.0F, 0);
      this.mVelocityTracker.addMovement(motionEvent);
      motionEvent.recycle();
      return;
    } 
    throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return generateDefaultLayoutParams();
  }
  
  public PagerAdapter getAdapter() {
    return this.mAdapter;
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (this.mDrawingOrder == 2)
      i = paramInt1 - 1 - paramInt2; 
    return ((LayoutParams)((View)this.mDrawingOrderedChildren.get(i)).getLayoutParams()).childIndex;
  }
  
  public int getCurrentItem() {
    return this.mCurItem;
  }
  
  public int getOffscreenPageLimit() {
    return this.mOffscreenPageLimit;
  }
  
  public int getPageMargin() {
    return this.mPageMargin;
  }
  
  ItemInfo infoForAnyChild(View paramView) {
    while (true) {
      ViewParent viewParent = paramView.getParent();
      if (viewParent != this) {
        if (viewParent != null) {
          if (!(viewParent instanceof View))
            return null; 
          paramView = (View)viewParent;
          continue;
        } 
        continue;
      } 
      return infoForChild(paramView);
    } 
  }
  
  ItemInfo infoForChild(View paramView) {
    for (int i = 0; i < this.mItems.size(); i++) {
      ItemInfo itemInfo = this.mItems.get(i);
      if (this.mAdapter.isViewFromObject(paramView, itemInfo.object))
        return itemInfo; 
    } 
    return null;
  }
  
  ItemInfo infoForPosition(int paramInt) {
    for (int i = 0; i < this.mItems.size(); i++) {
      ItemInfo itemInfo = this.mItems.get(i);
      if (itemInfo.position == paramInt)
        return itemInfo; 
    } 
    return null;
  }
  
  void initViewPager() {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context context = getContext();
    this.mScroller = new Scroller(context, sInterpolator);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
    float f = (context.getResources().getDisplayMetrics()).density;
    this.mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop(viewConfiguration);
    this.mMinimumVelocity = (int)(400.0F * f);
    this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
    this.mLeftEdge = new EdgeEffectCompat(context);
    this.mRightEdge = new EdgeEffectCompat(context);
    this.mFlingDistance = (int)(25.0F * f);
    this.mCloseEnough = (int)(2.0F * f);
    this.mDefaultGutterSize = (int)(f * 16.0F);
    ViewCompat.setAccessibilityDelegate((View)this, new MyAccessibilityDelegate());
    if (ViewCompat.getImportantForAccessibility((View)this) == 0)
      ViewCompat.setImportantForAccessibility((View)this, 1); 
  }
  
  public boolean isFakeDragging() {
    return this.mFakeDragging;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.mEndScrollRunnable);
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mPageMargin > 0 && this.mMarginDrawable != null && this.mItems.size() > 0 && this.mAdapter != null) {
      int k = getScrollX();
      int m = getWidth();
      float f1 = this.mPageMargin;
      float f3 = m;
      float f2 = f1 / f3;
      ArrayList<ItemInfo> arrayList = this.mItems;
      int j = 0;
      ItemInfo itemInfo = arrayList.get(0);
      f1 = itemInfo.offset;
      int n = this.mItems.size();
      int i = itemInfo.position;
      int i1 = ((ItemInfo)this.mItems.get(n - 1)).position;
      while (i < i1) {
        float f;
        ItemInfo itemInfo1;
        while (i > itemInfo.position && j < n) {
          ArrayList<ItemInfo> arrayList1 = this.mItems;
          itemInfo1 = arrayList1.get(++j);
        } 
        if (i == itemInfo1.position) {
          f = (itemInfo1.offset + itemInfo1.widthFactor) * f3;
          f1 = itemInfo1.offset + itemInfo1.widthFactor + f2;
        } else {
          float f4 = this.mAdapter.getPageWidth(i);
          f = f1 + f4 + f2;
          f4 = (f1 + f4) * f3;
          f1 = f;
          f = f4;
        } 
        int i2 = this.mPageMargin;
        if (i2 + f > k) {
          this.mMarginDrawable.setBounds((int)f, this.mTopPageBounds, (int)(i2 + f + 0.5F), this.mBottomPageBounds);
          this.mMarginDrawable.draw(paramCanvas);
        } 
        if (f > (k + m))
          return; 
        i++;
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    VelocityTracker velocityTracker;
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i == 3 || i == 1) {
      this.mIsBeingDragged = false;
      this.mIsUnableToDrag = false;
      this.mActivePointerId = -1;
      velocityTracker = this.mVelocityTracker;
      if (velocityTracker != null) {
        velocityTracker.recycle();
        this.mVelocityTracker = null;
      } 
      return false;
    } 
    if (i != 0) {
      if (this.mIsBeingDragged)
        return true; 
      if (this.mIsUnableToDrag)
        return false; 
    } 
    if (i != 0) {
      if (i != 2) {
        if (i == 6)
          onSecondaryPointerUp((MotionEvent)velocityTracker); 
      } else {
        i = this.mActivePointerId;
        if (i != -1) {
          i = MotionEventCompat.findPointerIndex((MotionEvent)velocityTracker, i);
          float f2 = MotionEventCompat.getX((MotionEvent)velocityTracker, i);
          float f1 = f2 - this.mLastMotionX;
          float f4 = Math.abs(f1);
          float f3 = MotionEventCompat.getY((MotionEvent)velocityTracker, i);
          float f5 = Math.abs(f3 - this.mInitialMotionY);
          if (f1 != 0.0F && !isGutterDrag(this.mLastMotionX, f1) && canScroll((View)this, false, (int)f1, (int)f2, (int)f3)) {
            this.mLastMotionX = f2;
            this.mLastMotionY = f3;
            this.mIsUnableToDrag = true;
            return false;
          } 
          if (f4 > this.mTouchSlop && f4 * 0.5F > f5) {
            this.mIsBeingDragged = true;
            requestParentDisallowInterceptTouchEvent(true);
            setScrollState(1);
            if (f1 > 0.0F) {
              f1 = this.mInitialMotionX + this.mTouchSlop;
            } else {
              f1 = this.mInitialMotionX - this.mTouchSlop;
            } 
            this.mLastMotionX = f1;
            this.mLastMotionY = f3;
            setScrollingCacheEnabled(true);
          } else if (f5 > this.mTouchSlop) {
            this.mIsUnableToDrag = true;
          } 
          if (this.mIsBeingDragged && performDrag(f2))
            ViewCompat.postInvalidateOnAnimation((View)this); 
        } 
      } 
    } else {
      float f = velocityTracker.getX();
      this.mInitialMotionX = f;
      this.mLastMotionX = f;
      f = velocityTracker.getY();
      this.mInitialMotionY = f;
      this.mLastMotionY = f;
      this.mActivePointerId = MotionEventCompat.getPointerId((MotionEvent)velocityTracker, 0);
      this.mIsUnableToDrag = false;
      this.mScroller.computeScrollOffset();
      if (this.mScrollState == 2 && Math.abs(this.mScroller.getFinalX() - this.mScroller.getCurrX()) > this.mCloseEnough) {
        this.mScroller.abortAnimation();
        this.mPopulatePending = false;
        populate();
        this.mIsBeingDragged = true;
        requestParentDisallowInterceptTouchEvent(true);
        setScrollState(1);
      } else {
        completeScroll(false);
        this.mIsBeingDragged = false;
      } 
    } 
    if (this.mVelocityTracker == null)
      this.mVelocityTracker = VelocityTracker.obtain(); 
    this.mVelocityTracker.addMovement((MotionEvent)velocityTracker);
    return this.mIsBeingDragged;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int m = getChildCount();
    int n = paramInt3 - paramInt1;
    int i1 = paramInt4 - paramInt2;
    paramInt2 = getPaddingLeft();
    paramInt1 = getPaddingTop();
    int i = getPaddingRight();
    paramInt4 = getPaddingBottom();
    int i2 = getScrollX();
    int j = 0;
    int k = 0;
    while (k < m) {
      View view = getChildAt(k);
      int i3 = paramInt2;
      int i6 = i;
      int i5 = paramInt1;
      int i4 = paramInt4;
      paramInt3 = j;
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i3 = paramInt2;
        i6 = i;
        i5 = paramInt1;
        i4 = paramInt4;
        paramInt3 = j;
        if (layoutParams.isDecor) {
          paramInt3 = layoutParams.gravity & 0x7;
          i4 = layoutParams.gravity & 0x70;
          if (paramInt3 != 1) {
            if (paramInt3 != 3) {
              if (paramInt3 != 5) {
                paramInt3 = paramInt2;
                i3 = paramInt2;
              } else {
                paramInt3 = n - i - view.getMeasuredWidth();
                i += view.getMeasuredWidth();
                i3 = paramInt2;
              } 
            } else {
              i3 = view.getMeasuredWidth();
              paramInt3 = paramInt2;
              i3 += paramInt2;
            } 
          } else {
            paramInt3 = Math.max((n - view.getMeasuredWidth()) / 2, paramInt2);
            i3 = paramInt2;
          } 
          if (i4 != 16) {
            if (i4 != 48) {
              if (i4 != 80) {
                paramInt2 = paramInt1;
              } else {
                paramInt2 = i1 - paramInt4 - view.getMeasuredHeight();
                paramInt4 += view.getMeasuredHeight();
              } 
            } else {
              i4 = view.getMeasuredHeight();
              paramInt2 = paramInt1;
              paramInt1 = i4 + paramInt1;
            } 
          } else {
            paramInt2 = Math.max((i1 - view.getMeasuredHeight()) / 2, paramInt1);
          } 
          paramInt3 += i2;
          view.layout(paramInt3, paramInt2, view.getMeasuredWidth() + paramInt3, paramInt2 + view.getMeasuredHeight());
          paramInt3 = j + 1;
          i4 = paramInt4;
          i5 = paramInt1;
          i6 = i;
        } 
      } 
      k++;
      paramInt2 = i3;
      i = i6;
      paramInt1 = i5;
      paramInt4 = i4;
      j = paramInt3;
    } 
    for (paramInt3 = 0; paramInt3 < m; paramInt3++) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (!layoutParams.isDecor) {
          ItemInfo itemInfo = infoForChild(view);
          if (itemInfo != null) {
            float f = (n - paramInt2 - i);
            int i3 = (int)(itemInfo.offset * f) + paramInt2;
            if (layoutParams.needsMeasure) {
              layoutParams.needsMeasure = false;
              view.measure(View.MeasureSpec.makeMeasureSpec((int)(f * layoutParams.widthFactor), 1073741824), View.MeasureSpec.makeMeasureSpec(i1 - paramInt1 - paramInt4, 1073741824));
            } 
            view.layout(i3, paramInt1, view.getMeasuredWidth() + i3, view.getMeasuredHeight() + paramInt1);
          } 
        } 
      } 
    } 
    this.mTopPageBounds = paramInt1;
    this.mBottomPageBounds = i1 - paramInt4;
    this.mDecorChildCount = j;
    if (this.mFirstLayout)
      scrollToItem(this.mCurItem, false, 0, false); 
    this.mFirstLayout = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: iload_1
    //   3: invokestatic getDefaultSize : (II)I
    //   6: iconst_0
    //   7: iload_2
    //   8: invokestatic getDefaultSize : (II)I
    //   11: invokevirtual setMeasuredDimension : (II)V
    //   14: aload_0
    //   15: invokevirtual getMeasuredWidth : ()I
    //   18: istore_1
    //   19: aload_0
    //   20: iload_1
    //   21: bipush #10
    //   23: idiv
    //   24: aload_0
    //   25: getfield mDefaultGutterSize : I
    //   28: invokestatic min : (II)I
    //   31: putfield mGutterSize : I
    //   34: aload_0
    //   35: invokevirtual getPaddingLeft : ()I
    //   38: istore_3
    //   39: aload_0
    //   40: invokevirtual getPaddingRight : ()I
    //   43: istore #4
    //   45: aload_0
    //   46: invokevirtual getMeasuredHeight : ()I
    //   49: istore_2
    //   50: aload_0
    //   51: invokevirtual getPaddingTop : ()I
    //   54: istore #5
    //   56: aload_0
    //   57: invokevirtual getPaddingBottom : ()I
    //   60: istore #6
    //   62: aload_0
    //   63: invokevirtual getChildCount : ()I
    //   66: istore #11
    //   68: iload_2
    //   69: iload #5
    //   71: isub
    //   72: iload #6
    //   74: isub
    //   75: istore_2
    //   76: iload_1
    //   77: iload_3
    //   78: isub
    //   79: iload #4
    //   81: isub
    //   82: istore_1
    //   83: iconst_0
    //   84: istore #5
    //   86: iconst_1
    //   87: istore #8
    //   89: ldc_w 1073741824
    //   92: istore #10
    //   94: iload #5
    //   96: iload #11
    //   98: if_icmpge -> 434
    //   101: aload_0
    //   102: iload #5
    //   104: invokevirtual getChildAt : (I)Landroid/view/View;
    //   107: astore #12
    //   109: iload_1
    //   110: istore_3
    //   111: iload_2
    //   112: istore #4
    //   114: aload #12
    //   116: invokevirtual getVisibility : ()I
    //   119: bipush #8
    //   121: if_icmpeq -> 420
    //   124: aload #12
    //   126: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   129: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   132: astore #13
    //   134: iload_1
    //   135: istore_3
    //   136: iload_2
    //   137: istore #4
    //   139: aload #13
    //   141: ifnull -> 420
    //   144: iload_1
    //   145: istore_3
    //   146: iload_2
    //   147: istore #4
    //   149: aload #13
    //   151: getfield isDecor : Z
    //   154: ifeq -> 420
    //   157: aload #13
    //   159: getfield gravity : I
    //   162: bipush #7
    //   164: iand
    //   165: istore_3
    //   166: aload #13
    //   168: getfield gravity : I
    //   171: bipush #112
    //   173: iand
    //   174: istore #4
    //   176: iload #4
    //   178: bipush #48
    //   180: if_icmpeq -> 199
    //   183: iload #4
    //   185: bipush #80
    //   187: if_icmpne -> 193
    //   190: goto -> 199
    //   193: iconst_0
    //   194: istore #7
    //   196: goto -> 202
    //   199: iconst_1
    //   200: istore #7
    //   202: iload #8
    //   204: istore #6
    //   206: iload_3
    //   207: iconst_3
    //   208: if_icmpeq -> 226
    //   211: iload_3
    //   212: iconst_5
    //   213: if_icmpne -> 223
    //   216: iload #8
    //   218: istore #6
    //   220: goto -> 226
    //   223: iconst_0
    //   224: istore #6
    //   226: ldc_w -2147483648
    //   229: istore_3
    //   230: iload #7
    //   232: ifeq -> 243
    //   235: ldc_w 1073741824
    //   238: istore #4
    //   240: goto -> 265
    //   243: iload_3
    //   244: istore #4
    //   246: iload #6
    //   248: ifeq -> 265
    //   251: ldc_w 1073741824
    //   254: istore #8
    //   256: iload_3
    //   257: istore #4
    //   259: iload #8
    //   261: istore_3
    //   262: goto -> 269
    //   265: ldc_w -2147483648
    //   268: istore_3
    //   269: aload #13
    //   271: getfield width : I
    //   274: bipush #-2
    //   276: if_icmpeq -> 313
    //   279: aload #13
    //   281: getfield width : I
    //   284: iconst_m1
    //   285: if_icmpeq -> 298
    //   288: aload #13
    //   290: getfield width : I
    //   293: istore #4
    //   295: goto -> 301
    //   298: iload_1
    //   299: istore #4
    //   301: ldc_w 1073741824
    //   304: istore #8
    //   306: iload #4
    //   308: istore #9
    //   310: goto -> 320
    //   313: iload_1
    //   314: istore #9
    //   316: iload #4
    //   318: istore #8
    //   320: aload #13
    //   322: getfield height : I
    //   325: bipush #-2
    //   327: if_icmpeq -> 353
    //   330: aload #13
    //   332: getfield height : I
    //   335: iconst_m1
    //   336: if_icmpeq -> 348
    //   339: aload #13
    //   341: getfield height : I
    //   344: istore_3
    //   345: goto -> 362
    //   348: iload_2
    //   349: istore_3
    //   350: goto -> 362
    //   353: iload_2
    //   354: istore #4
    //   356: iload_3
    //   357: istore #10
    //   359: iload #4
    //   361: istore_3
    //   362: aload #12
    //   364: iload #9
    //   366: iload #8
    //   368: invokestatic makeMeasureSpec : (II)I
    //   371: iload_3
    //   372: iload #10
    //   374: invokestatic makeMeasureSpec : (II)I
    //   377: invokevirtual measure : (II)V
    //   380: iload #7
    //   382: ifeq -> 399
    //   385: iload_2
    //   386: aload #12
    //   388: invokevirtual getMeasuredHeight : ()I
    //   391: isub
    //   392: istore #4
    //   394: iload_1
    //   395: istore_3
    //   396: goto -> 420
    //   399: iload_1
    //   400: istore_3
    //   401: iload_2
    //   402: istore #4
    //   404: iload #6
    //   406: ifeq -> 420
    //   409: iload_1
    //   410: aload #12
    //   412: invokevirtual getMeasuredWidth : ()I
    //   415: isub
    //   416: istore_3
    //   417: iload_2
    //   418: istore #4
    //   420: iload #5
    //   422: iconst_1
    //   423: iadd
    //   424: istore #5
    //   426: iload_3
    //   427: istore_1
    //   428: iload #4
    //   430: istore_2
    //   431: goto -> 86
    //   434: aload_0
    //   435: iload_1
    //   436: ldc_w 1073741824
    //   439: invokestatic makeMeasureSpec : (II)I
    //   442: putfield mChildWidthMeasureSpec : I
    //   445: aload_0
    //   446: iload_2
    //   447: ldc_w 1073741824
    //   450: invokestatic makeMeasureSpec : (II)I
    //   453: putfield mChildHeightMeasureSpec : I
    //   456: aload_0
    //   457: iconst_1
    //   458: putfield mInLayout : Z
    //   461: aload_0
    //   462: invokevirtual populate : ()V
    //   465: iconst_0
    //   466: istore_2
    //   467: aload_0
    //   468: iconst_0
    //   469: putfield mInLayout : Z
    //   472: aload_0
    //   473: invokevirtual getChildCount : ()I
    //   476: istore_3
    //   477: iload_2
    //   478: iload_3
    //   479: if_icmpge -> 553
    //   482: aload_0
    //   483: iload_2
    //   484: invokevirtual getChildAt : (I)Landroid/view/View;
    //   487: astore #12
    //   489: aload #12
    //   491: invokevirtual getVisibility : ()I
    //   494: bipush #8
    //   496: if_icmpeq -> 546
    //   499: aload #12
    //   501: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   504: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   507: astore #13
    //   509: aload #13
    //   511: ifnull -> 522
    //   514: aload #13
    //   516: getfield isDecor : Z
    //   519: ifne -> 546
    //   522: aload #12
    //   524: iload_1
    //   525: i2f
    //   526: aload #13
    //   528: getfield widthFactor : F
    //   531: fmul
    //   532: f2i
    //   533: ldc_w 1073741824
    //   536: invokestatic makeMeasureSpec : (II)I
    //   539: aload_0
    //   540: getfield mChildHeightMeasureSpec : I
    //   543: invokevirtual measure : (II)V
    //   546: iload_2
    //   547: iconst_1
    //   548: iadd
    //   549: istore_2
    //   550: goto -> 477
    //   553: return
  }
  
  protected void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {
    int i = this.mDecorChildCount;
    boolean bool = false;
    if (i > 0) {
      int m = getScrollX();
      i = getPaddingLeft();
      int j = getPaddingRight();
      int n = getWidth();
      int i1 = getChildCount();
      int k;
      for (k = 0; k < i1; k++) {
        View view = getChildAt(k);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isDecor) {
          int i2 = layoutParams.gravity & 0x7;
          if (i2 != 1) {
            if (i2 != 3) {
              if (i2 != 5) {
                int i3 = i;
                i2 = i;
                i = i3;
              } else {
                i2 = n - j - view.getMeasuredWidth();
                j += view.getMeasuredWidth();
              } 
            } else {
              int i3 = view.getWidth() + i;
              i2 = i;
              i = i3;
            } 
          } else {
            i2 = Math.max((n - view.getMeasuredWidth()) / 2, i);
          } 
          i2 = i2 + m - view.getLeft();
          if (i2 != 0)
            view.offsetLeftAndRight(i2); 
        } 
      } 
    } 
    OnPageChangeListener onPageChangeListener = this.mOnPageChangeListener;
    if (onPageChangeListener != null)
      onPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2); 
    onPageChangeListener = this.mInternalPageChangeListener;
    if (onPageChangeListener != null)
      onPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2); 
    if (this.mPageTransformer != null) {
      paramInt2 = getScrollX();
      i = getChildCount();
      for (paramInt1 = bool; paramInt1 < i; paramInt1++) {
        View view = getChildAt(paramInt1);
        if (!((LayoutParams)view.getLayoutParams()).isDecor) {
          paramFloat = (view.getLeft() - paramInt2) / getClientWidth();
          this.mPageTransformer.transformPage(view, paramFloat);
        } 
      } 
    } 
    this.mCalledSuper = true;
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    byte b;
    int i = getChildCount();
    int j = -1;
    if ((paramInt & 0x2) != 0) {
      j = i;
      i = 0;
      b = 1;
    } else {
      i--;
      b = -1;
    } 
    while (i != j) {
      View view = getChildAt(i);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = infoForChild(view);
        if (itemInfo != null && itemInfo.position == this.mCurItem && view.requestFocus(paramInt, paramRect))
          return true; 
      } 
      i += b;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    PagerAdapter pagerAdapter = this.mAdapter;
    if (pagerAdapter != null) {
      pagerAdapter.restoreState(savedState.adapterState, savedState.loader);
      setCurrentItemInternal(savedState.position, false, true);
      return;
    } 
    this.mRestoredCurItem = savedState.position;
    this.mRestoredAdapterState = savedState.adapterState;
    this.mRestoredClassLoader = savedState.loader;
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.position = this.mCurItem;
    PagerAdapter pagerAdapter = this.mAdapter;
    if (pagerAdapter != null)
      savedState.adapterState = pagerAdapter.saveState(); 
    return (Parcelable)savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3) {
      paramInt2 = this.mPageMargin;
      recomputeScrollPosition(paramInt1, paramInt3, paramInt2, paramInt2);
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mFakeDragging : Z
    //   4: ifeq -> 9
    //   7: iconst_1
    //   8: ireturn
    //   9: aload_1
    //   10: invokevirtual getAction : ()I
    //   13: istore #7
    //   15: iconst_0
    //   16: istore #6
    //   18: iload #7
    //   20: ifne -> 32
    //   23: aload_1
    //   24: invokevirtual getEdgeFlags : ()I
    //   27: ifeq -> 32
    //   30: iconst_0
    //   31: ireturn
    //   32: aload_0
    //   33: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   36: astore #11
    //   38: aload #11
    //   40: ifnull -> 632
    //   43: aload #11
    //   45: invokevirtual getCount : ()I
    //   48: ifne -> 53
    //   51: iconst_0
    //   52: ireturn
    //   53: aload_0
    //   54: getfield mVelocityTracker : Landroid/view/VelocityTracker;
    //   57: ifnonnull -> 67
    //   60: aload_0
    //   61: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   64: putfield mVelocityTracker : Landroid/view/VelocityTracker;
    //   67: aload_0
    //   68: getfield mVelocityTracker : Landroid/view/VelocityTracker;
    //   71: aload_1
    //   72: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   75: aload_1
    //   76: invokevirtual getAction : ()I
    //   79: sipush #255
    //   82: iand
    //   83: istore #7
    //   85: iload #7
    //   87: ifeq -> 566
    //   90: iload #7
    //   92: iconst_1
    //   93: if_icmpeq -> 412
    //   96: iload #7
    //   98: iconst_2
    //   99: if_icmpeq -> 225
    //   102: iload #7
    //   104: iconst_3
    //   105: if_icmpeq -> 177
    //   108: iload #7
    //   110: iconst_5
    //   111: if_icmpeq -> 148
    //   114: iload #7
    //   116: bipush #6
    //   118: if_icmpeq -> 124
    //   121: goto -> 621
    //   124: aload_0
    //   125: aload_1
    //   126: invokespecial onSecondaryPointerUp : (Landroid/view/MotionEvent;)V
    //   129: aload_0
    //   130: aload_1
    //   131: aload_1
    //   132: aload_0
    //   133: getfield mActivePointerId : I
    //   136: invokestatic findPointerIndex : (Landroid/view/MotionEvent;I)I
    //   139: invokestatic getX : (Landroid/view/MotionEvent;I)F
    //   142: putfield mLastMotionX : F
    //   145: goto -> 621
    //   148: aload_1
    //   149: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
    //   152: istore #7
    //   154: aload_0
    //   155: aload_1
    //   156: iload #7
    //   158: invokestatic getX : (Landroid/view/MotionEvent;I)F
    //   161: putfield mLastMotionX : F
    //   164: aload_0
    //   165: aload_1
    //   166: iload #7
    //   168: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
    //   171: putfield mActivePointerId : I
    //   174: goto -> 621
    //   177: aload_0
    //   178: getfield mIsBeingDragged : Z
    //   181: ifeq -> 621
    //   184: aload_0
    //   185: aload_0
    //   186: getfield mCurItem : I
    //   189: iconst_1
    //   190: iconst_0
    //   191: iconst_0
    //   192: invokespecial scrollToItem : (IZIZ)V
    //   195: aload_0
    //   196: iconst_m1
    //   197: putfield mActivePointerId : I
    //   200: aload_0
    //   201: invokespecial endDrag : ()V
    //   204: aload_0
    //   205: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   208: invokevirtual onRelease : ()Z
    //   211: istore #10
    //   213: aload_0
    //   214: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   217: invokevirtual onRelease : ()Z
    //   220: istore #9
    //   222: goto -> 556
    //   225: aload_0
    //   226: getfield mIsBeingDragged : Z
    //   229: ifne -> 382
    //   232: aload_1
    //   233: aload_0
    //   234: getfield mActivePointerId : I
    //   237: invokestatic findPointerIndex : (Landroid/view/MotionEvent;I)I
    //   240: istore #7
    //   242: aload_1
    //   243: iload #7
    //   245: invokestatic getX : (Landroid/view/MotionEvent;I)F
    //   248: fstore_2
    //   249: fload_2
    //   250: aload_0
    //   251: getfield mLastMotionX : F
    //   254: fsub
    //   255: invokestatic abs : (F)F
    //   258: fstore #4
    //   260: aload_1
    //   261: iload #7
    //   263: invokestatic getY : (Landroid/view/MotionEvent;I)F
    //   266: fstore_3
    //   267: fload_3
    //   268: aload_0
    //   269: getfield mLastMotionY : F
    //   272: fsub
    //   273: invokestatic abs : (F)F
    //   276: fstore #5
    //   278: fload #4
    //   280: aload_0
    //   281: getfield mTouchSlop : I
    //   284: i2f
    //   285: fcmpl
    //   286: ifle -> 382
    //   289: fload #4
    //   291: fload #5
    //   293: fcmpl
    //   294: ifle -> 382
    //   297: aload_0
    //   298: iconst_1
    //   299: putfield mIsBeingDragged : Z
    //   302: aload_0
    //   303: iconst_1
    //   304: invokespecial requestParentDisallowInterceptTouchEvent : (Z)V
    //   307: aload_0
    //   308: getfield mInitialMotionX : F
    //   311: fstore #4
    //   313: fload_2
    //   314: fload #4
    //   316: fsub
    //   317: fconst_0
    //   318: fcmpl
    //   319: ifle -> 334
    //   322: fload #4
    //   324: aload_0
    //   325: getfield mTouchSlop : I
    //   328: i2f
    //   329: fadd
    //   330: fstore_2
    //   331: goto -> 343
    //   334: fload #4
    //   336: aload_0
    //   337: getfield mTouchSlop : I
    //   340: i2f
    //   341: fsub
    //   342: fstore_2
    //   343: aload_0
    //   344: fload_2
    //   345: putfield mLastMotionX : F
    //   348: aload_0
    //   349: fload_3
    //   350: putfield mLastMotionY : F
    //   353: aload_0
    //   354: iconst_1
    //   355: invokespecial setScrollState : (I)V
    //   358: aload_0
    //   359: iconst_1
    //   360: invokespecial setScrollingCacheEnabled : (Z)V
    //   363: aload_0
    //   364: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   367: astore #11
    //   369: aload #11
    //   371: ifnull -> 382
    //   374: aload #11
    //   376: iconst_1
    //   377: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   382: aload_0
    //   383: getfield mIsBeingDragged : Z
    //   386: ifeq -> 621
    //   389: iconst_0
    //   390: aload_0
    //   391: aload_1
    //   392: aload_1
    //   393: aload_0
    //   394: getfield mActivePointerId : I
    //   397: invokestatic findPointerIndex : (Landroid/view/MotionEvent;I)I
    //   400: invokestatic getX : (Landroid/view/MotionEvent;I)F
    //   403: invokespecial performDrag : (F)Z
    //   406: ior
    //   407: istore #6
    //   409: goto -> 621
    //   412: aload_0
    //   413: getfield mIsBeingDragged : Z
    //   416: ifeq -> 621
    //   419: aload_0
    //   420: getfield mVelocityTracker : Landroid/view/VelocityTracker;
    //   423: astore #11
    //   425: aload #11
    //   427: sipush #1000
    //   430: aload_0
    //   431: getfield mMaximumVelocity : I
    //   434: i2f
    //   435: invokevirtual computeCurrentVelocity : (IF)V
    //   438: aload #11
    //   440: aload_0
    //   441: getfield mActivePointerId : I
    //   444: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
    //   447: f2i
    //   448: istore #6
    //   450: aload_0
    //   451: iconst_1
    //   452: putfield mPopulatePending : Z
    //   455: aload_0
    //   456: invokespecial getClientWidth : ()I
    //   459: istore #7
    //   461: aload_0
    //   462: invokevirtual getScrollX : ()I
    //   465: istore #8
    //   467: aload_0
    //   468: invokespecial infoForCurrentScrollPosition : ()Landroid/support/v4/view/ViewPager$ItemInfo;
    //   471: astore #11
    //   473: aload_0
    //   474: aload_0
    //   475: aload #11
    //   477: getfield position : I
    //   480: iload #8
    //   482: i2f
    //   483: iload #7
    //   485: i2f
    //   486: fdiv
    //   487: aload #11
    //   489: getfield offset : F
    //   492: fsub
    //   493: aload #11
    //   495: getfield widthFactor : F
    //   498: fdiv
    //   499: iload #6
    //   501: aload_1
    //   502: aload_1
    //   503: aload_0
    //   504: getfield mActivePointerId : I
    //   507: invokestatic findPointerIndex : (Landroid/view/MotionEvent;I)I
    //   510: invokestatic getX : (Landroid/view/MotionEvent;I)F
    //   513: aload_0
    //   514: getfield mInitialMotionX : F
    //   517: fsub
    //   518: f2i
    //   519: invokespecial determineTargetPage : (IFII)I
    //   522: iconst_1
    //   523: iconst_1
    //   524: iload #6
    //   526: invokevirtual setCurrentItemInternal : (IZZI)V
    //   529: aload_0
    //   530: iconst_m1
    //   531: putfield mActivePointerId : I
    //   534: aload_0
    //   535: invokespecial endDrag : ()V
    //   538: aload_0
    //   539: getfield mLeftEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   542: invokevirtual onRelease : ()Z
    //   545: istore #10
    //   547: aload_0
    //   548: getfield mRightEdge : Landroid/support/v4/widget/EdgeEffectCompat;
    //   551: invokevirtual onRelease : ()Z
    //   554: istore #9
    //   556: iload #10
    //   558: iload #9
    //   560: ior
    //   561: istore #6
    //   563: goto -> 621
    //   566: aload_0
    //   567: getfield mScroller : Landroid/widget/Scroller;
    //   570: invokevirtual abortAnimation : ()V
    //   573: aload_0
    //   574: iconst_0
    //   575: putfield mPopulatePending : Z
    //   578: aload_0
    //   579: invokevirtual populate : ()V
    //   582: aload_1
    //   583: invokevirtual getX : ()F
    //   586: fstore_2
    //   587: aload_0
    //   588: fload_2
    //   589: putfield mInitialMotionX : F
    //   592: aload_0
    //   593: fload_2
    //   594: putfield mLastMotionX : F
    //   597: aload_1
    //   598: invokevirtual getY : ()F
    //   601: fstore_2
    //   602: aload_0
    //   603: fload_2
    //   604: putfield mInitialMotionY : F
    //   607: aload_0
    //   608: fload_2
    //   609: putfield mLastMotionY : F
    //   612: aload_0
    //   613: aload_1
    //   614: iconst_0
    //   615: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
    //   618: putfield mActivePointerId : I
    //   621: iload #6
    //   623: ifeq -> 630
    //   626: aload_0
    //   627: invokestatic postInvalidateOnAnimation : (Landroid/view/View;)V
    //   630: iconst_1
    //   631: ireturn
    //   632: iconst_0
    //   633: ireturn
  }
  
  boolean pageLeft() {
    int i = this.mCurItem;
    if (i > 0) {
      setCurrentItem(i - 1, true);
      return true;
    } 
    return false;
  }
  
  boolean pageRight() {
    PagerAdapter pagerAdapter = this.mAdapter;
    if (pagerAdapter != null && this.mCurItem < pagerAdapter.getCount() - 1) {
      setCurrentItem(this.mCurItem + 1, true);
      return true;
    } 
    return false;
  }
  
  void populate() {
    populate(this.mCurItem);
  }
  
  void populate(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mCurItem : I
    //   4: istore #5
    //   6: iload #5
    //   8: iload_1
    //   9: if_icmpeq -> 51
    //   12: iload #5
    //   14: iload_1
    //   15: if_icmpge -> 25
    //   18: bipush #66
    //   20: istore #5
    //   22: goto -> 29
    //   25: bipush #17
    //   27: istore #5
    //   29: aload_0
    //   30: aload_0
    //   31: getfield mCurItem : I
    //   34: invokevirtual infoForPosition : (I)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   37: astore #15
    //   39: aload_0
    //   40: iload_1
    //   41: putfield mCurItem : I
    //   44: iload #5
    //   46: istore #8
    //   48: goto -> 57
    //   51: iconst_2
    //   52: istore #8
    //   54: aconst_null
    //   55: astore #15
    //   57: aload_0
    //   58: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   61: ifnonnull -> 69
    //   64: aload_0
    //   65: invokespecial sortChildDrawingOrder : ()V
    //   68: return
    //   69: aload_0
    //   70: getfield mPopulatePending : Z
    //   73: ifeq -> 81
    //   76: aload_0
    //   77: invokespecial sortChildDrawingOrder : ()V
    //   80: return
    //   81: aload_0
    //   82: invokevirtual getWindowToken : ()Landroid/os/IBinder;
    //   85: ifnonnull -> 89
    //   88: return
    //   89: aload_0
    //   90: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   93: aload_0
    //   94: invokevirtual startUpdate : (Landroid/view/ViewGroup;)V
    //   97: aload_0
    //   98: getfield mOffscreenPageLimit : I
    //   101: istore_1
    //   102: iconst_0
    //   103: aload_0
    //   104: getfield mCurItem : I
    //   107: iload_1
    //   108: isub
    //   109: invokestatic max : (II)I
    //   112: istore #12
    //   114: aload_0
    //   115: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   118: invokevirtual getCount : ()I
    //   121: istore #10
    //   123: iload #10
    //   125: iconst_1
    //   126: isub
    //   127: aload_0
    //   128: getfield mCurItem : I
    //   131: iload_1
    //   132: iadd
    //   133: invokestatic min : (II)I
    //   136: istore #11
    //   138: iload #10
    //   140: aload_0
    //   141: getfield mExpectedAdapterCount : I
    //   144: if_icmpne -> 1263
    //   147: iconst_0
    //   148: istore_1
    //   149: iload_1
    //   150: aload_0
    //   151: getfield mItems : Ljava/util/ArrayList;
    //   154: invokevirtual size : ()I
    //   157: if_icmpge -> 207
    //   160: aload_0
    //   161: getfield mItems : Ljava/util/ArrayList;
    //   164: iload_1
    //   165: invokevirtual get : (I)Ljava/lang/Object;
    //   168: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   171: astore #14
    //   173: aload #14
    //   175: getfield position : I
    //   178: aload_0
    //   179: getfield mCurItem : I
    //   182: if_icmplt -> 200
    //   185: aload #14
    //   187: getfield position : I
    //   190: aload_0
    //   191: getfield mCurItem : I
    //   194: if_icmpne -> 207
    //   197: goto -> 210
    //   200: iload_1
    //   201: iconst_1
    //   202: iadd
    //   203: istore_1
    //   204: goto -> 149
    //   207: aconst_null
    //   208: astore #14
    //   210: aload #14
    //   212: astore #16
    //   214: aload #14
    //   216: ifnonnull -> 239
    //   219: aload #14
    //   221: astore #16
    //   223: iload #10
    //   225: ifle -> 239
    //   228: aload_0
    //   229: aload_0
    //   230: getfield mCurItem : I
    //   233: iload_1
    //   234: invokevirtual addNewItem : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   237: astore #16
    //   239: aload #16
    //   241: ifnull -> 1005
    //   244: iload_1
    //   245: iconst_1
    //   246: isub
    //   247: istore #5
    //   249: iload #5
    //   251: iflt -> 271
    //   254: aload_0
    //   255: getfield mItems : Ljava/util/ArrayList;
    //   258: iload #5
    //   260: invokevirtual get : (I)Ljava/lang/Object;
    //   263: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   266: astore #14
    //   268: goto -> 274
    //   271: aconst_null
    //   272: astore #14
    //   274: aload_0
    //   275: invokespecial getClientWidth : ()I
    //   278: istore #13
    //   280: iload #13
    //   282: ifgt -> 291
    //   285: fconst_0
    //   286: fstore #4
    //   288: goto -> 312
    //   291: aload #16
    //   293: getfield widthFactor : F
    //   296: fstore_2
    //   297: aload_0
    //   298: invokevirtual getPaddingLeft : ()I
    //   301: i2f
    //   302: iload #13
    //   304: i2f
    //   305: fdiv
    //   306: fconst_2
    //   307: fload_2
    //   308: fsub
    //   309: fadd
    //   310: fstore #4
    //   312: aload_0
    //   313: getfield mCurItem : I
    //   316: iconst_1
    //   317: isub
    //   318: istore #9
    //   320: fconst_0
    //   321: fstore_3
    //   322: iload #9
    //   324: iflt -> 619
    //   327: fload_3
    //   328: fload #4
    //   330: fcmpl
    //   331: iflt -> 461
    //   334: iload #9
    //   336: iload #12
    //   338: if_icmpge -> 461
    //   341: aload #14
    //   343: ifnonnull -> 349
    //   346: goto -> 619
    //   349: fload_3
    //   350: fstore_2
    //   351: iload_1
    //   352: istore #7
    //   354: aload #14
    //   356: astore #17
    //   358: iload #5
    //   360: istore #6
    //   362: iload #9
    //   364: aload #14
    //   366: getfield position : I
    //   369: if_icmpne -> 597
    //   372: fload_3
    //   373: fstore_2
    //   374: iload_1
    //   375: istore #7
    //   377: aload #14
    //   379: astore #17
    //   381: iload #5
    //   383: istore #6
    //   385: aload #14
    //   387: getfield scrolling : Z
    //   390: ifne -> 597
    //   393: aload_0
    //   394: getfield mItems : Ljava/util/ArrayList;
    //   397: iload #5
    //   399: invokevirtual remove : (I)Ljava/lang/Object;
    //   402: pop
    //   403: aload_0
    //   404: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   407: aload_0
    //   408: iload #9
    //   410: aload #14
    //   412: getfield object : Ljava/lang/Object;
    //   415: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   418: iload #5
    //   420: iconst_1
    //   421: isub
    //   422: istore #5
    //   424: iload_1
    //   425: iconst_1
    //   426: isub
    //   427: istore_1
    //   428: fload_3
    //   429: fstore_2
    //   430: iload_1
    //   431: istore #6
    //   433: iload #5
    //   435: istore #7
    //   437: iload #5
    //   439: iflt -> 576
    //   442: aload_0
    //   443: getfield mItems : Ljava/util/ArrayList;
    //   446: iload #5
    //   448: invokevirtual get : (I)Ljava/lang/Object;
    //   451: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   454: astore #14
    //   456: fload_3
    //   457: fstore_2
    //   458: goto -> 586
    //   461: aload #14
    //   463: ifnull -> 523
    //   466: iload #9
    //   468: aload #14
    //   470: getfield position : I
    //   473: if_icmpne -> 523
    //   476: fload_3
    //   477: aload #14
    //   479: getfield widthFactor : F
    //   482: fadd
    //   483: fstore_3
    //   484: iload #5
    //   486: iconst_1
    //   487: isub
    //   488: istore #5
    //   490: fload_3
    //   491: fstore_2
    //   492: iload_1
    //   493: istore #6
    //   495: iload #5
    //   497: istore #7
    //   499: iload #5
    //   501: iflt -> 576
    //   504: aload_0
    //   505: getfield mItems : Ljava/util/ArrayList;
    //   508: iload #5
    //   510: invokevirtual get : (I)Ljava/lang/Object;
    //   513: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   516: astore #14
    //   518: fload_3
    //   519: fstore_2
    //   520: goto -> 586
    //   523: fload_3
    //   524: aload_0
    //   525: iload #9
    //   527: iload #5
    //   529: iconst_1
    //   530: iadd
    //   531: invokevirtual addNewItem : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   534: getfield widthFactor : F
    //   537: fadd
    //   538: fstore_3
    //   539: iload_1
    //   540: iconst_1
    //   541: iadd
    //   542: istore_1
    //   543: fload_3
    //   544: fstore_2
    //   545: iload_1
    //   546: istore #6
    //   548: iload #5
    //   550: istore #7
    //   552: iload #5
    //   554: iflt -> 576
    //   557: aload_0
    //   558: getfield mItems : Ljava/util/ArrayList;
    //   561: iload #5
    //   563: invokevirtual get : (I)Ljava/lang/Object;
    //   566: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   569: astore #14
    //   571: fload_3
    //   572: fstore_2
    //   573: goto -> 586
    //   576: aconst_null
    //   577: astore #14
    //   579: iload #7
    //   581: istore #5
    //   583: iload #6
    //   585: istore_1
    //   586: iload #5
    //   588: istore #6
    //   590: aload #14
    //   592: astore #17
    //   594: iload_1
    //   595: istore #7
    //   597: iload #9
    //   599: iconst_1
    //   600: isub
    //   601: istore #9
    //   603: fload_2
    //   604: fstore_3
    //   605: iload #7
    //   607: istore_1
    //   608: aload #17
    //   610: astore #14
    //   612: iload #6
    //   614: istore #5
    //   616: goto -> 322
    //   619: aload #16
    //   621: getfield widthFactor : F
    //   624: fstore_3
    //   625: iload_1
    //   626: iconst_1
    //   627: iadd
    //   628: istore #6
    //   630: fload_3
    //   631: fconst_2
    //   632: fcmpg
    //   633: ifge -> 996
    //   636: iload #6
    //   638: aload_0
    //   639: getfield mItems : Ljava/util/ArrayList;
    //   642: invokevirtual size : ()I
    //   645: if_icmpge -> 665
    //   648: aload_0
    //   649: getfield mItems : Ljava/util/ArrayList;
    //   652: iload #6
    //   654: invokevirtual get : (I)Ljava/lang/Object;
    //   657: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   660: astore #14
    //   662: goto -> 668
    //   665: aconst_null
    //   666: astore #14
    //   668: iload #13
    //   670: ifgt -> 679
    //   673: fconst_0
    //   674: fstore #4
    //   676: goto -> 692
    //   679: aload_0
    //   680: invokevirtual getPaddingRight : ()I
    //   683: i2f
    //   684: iload #13
    //   686: i2f
    //   687: fdiv
    //   688: fconst_2
    //   689: fadd
    //   690: fstore #4
    //   692: aload_0
    //   693: getfield mCurItem : I
    //   696: istore #5
    //   698: aload #14
    //   700: astore #17
    //   702: iload #5
    //   704: iconst_1
    //   705: iadd
    //   706: istore #7
    //   708: iload #7
    //   710: iload #10
    //   712: if_icmpge -> 996
    //   715: fload_3
    //   716: fload #4
    //   718: fcmpl
    //   719: iflt -> 847
    //   722: iload #7
    //   724: iload #11
    //   726: if_icmple -> 847
    //   729: aload #17
    //   731: ifnonnull -> 737
    //   734: goto -> 996
    //   737: fload_3
    //   738: fstore_2
    //   739: iload #6
    //   741: istore #5
    //   743: aload #17
    //   745: astore #14
    //   747: iload #7
    //   749: aload #17
    //   751: getfield position : I
    //   754: if_icmpne -> 979
    //   757: fload_3
    //   758: fstore_2
    //   759: iload #6
    //   761: istore #5
    //   763: aload #17
    //   765: astore #14
    //   767: aload #17
    //   769: getfield scrolling : Z
    //   772: ifne -> 979
    //   775: aload_0
    //   776: getfield mItems : Ljava/util/ArrayList;
    //   779: iload #6
    //   781: invokevirtual remove : (I)Ljava/lang/Object;
    //   784: pop
    //   785: aload_0
    //   786: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   789: aload_0
    //   790: iload #7
    //   792: aload #17
    //   794: getfield object : Ljava/lang/Object;
    //   797: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   800: fload_3
    //   801: fstore_2
    //   802: iload #6
    //   804: istore #5
    //   806: iload #6
    //   808: aload_0
    //   809: getfield mItems : Ljava/util/ArrayList;
    //   812: invokevirtual size : ()I
    //   815: if_icmpge -> 841
    //   818: aload_0
    //   819: getfield mItems : Ljava/util/ArrayList;
    //   822: iload #6
    //   824: invokevirtual get : (I)Ljava/lang/Object;
    //   827: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   830: astore #14
    //   832: fload_3
    //   833: fstore_2
    //   834: iload #6
    //   836: istore #5
    //   838: goto -> 979
    //   841: aconst_null
    //   842: astore #14
    //   844: goto -> 979
    //   847: aload #17
    //   849: ifnull -> 917
    //   852: iload #7
    //   854: aload #17
    //   856: getfield position : I
    //   859: if_icmpne -> 917
    //   862: fload_3
    //   863: aload #17
    //   865: getfield widthFactor : F
    //   868: fadd
    //   869: fstore_3
    //   870: iload #6
    //   872: iconst_1
    //   873: iadd
    //   874: istore #6
    //   876: fload_3
    //   877: fstore_2
    //   878: iload #6
    //   880: istore #5
    //   882: iload #6
    //   884: aload_0
    //   885: getfield mItems : Ljava/util/ArrayList;
    //   888: invokevirtual size : ()I
    //   891: if_icmpge -> 841
    //   894: aload_0
    //   895: getfield mItems : Ljava/util/ArrayList;
    //   898: iload #6
    //   900: invokevirtual get : (I)Ljava/lang/Object;
    //   903: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   906: astore #14
    //   908: fload_3
    //   909: fstore_2
    //   910: iload #6
    //   912: istore #5
    //   914: goto -> 979
    //   917: aload_0
    //   918: iload #7
    //   920: iload #6
    //   922: invokevirtual addNewItem : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   925: astore #14
    //   927: iload #6
    //   929: iconst_1
    //   930: iadd
    //   931: istore #6
    //   933: fload_3
    //   934: aload #14
    //   936: getfield widthFactor : F
    //   939: fadd
    //   940: fstore_3
    //   941: fload_3
    //   942: fstore_2
    //   943: iload #6
    //   945: istore #5
    //   947: iload #6
    //   949: aload_0
    //   950: getfield mItems : Ljava/util/ArrayList;
    //   953: invokevirtual size : ()I
    //   956: if_icmpge -> 841
    //   959: aload_0
    //   960: getfield mItems : Ljava/util/ArrayList;
    //   963: iload #6
    //   965: invokevirtual get : (I)Ljava/lang/Object;
    //   968: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   971: astore #14
    //   973: iload #6
    //   975: istore #5
    //   977: fload_3
    //   978: fstore_2
    //   979: fload_2
    //   980: fstore_3
    //   981: iload #5
    //   983: istore #6
    //   985: aload #14
    //   987: astore #17
    //   989: iload #7
    //   991: istore #5
    //   993: goto -> 702
    //   996: aload_0
    //   997: aload #16
    //   999: iload_1
    //   1000: aload #15
    //   1002: invokespecial calculatePageOffsets : (Landroid/support/v4/view/ViewPager$ItemInfo;ILandroid/support/v4/view/ViewPager$ItemInfo;)V
    //   1005: aload_0
    //   1006: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   1009: astore #15
    //   1011: aload_0
    //   1012: getfield mCurItem : I
    //   1015: istore_1
    //   1016: aload #16
    //   1018: ifnull -> 1031
    //   1021: aload #16
    //   1023: getfield object : Ljava/lang/Object;
    //   1026: astore #14
    //   1028: goto -> 1034
    //   1031: aconst_null
    //   1032: astore #14
    //   1034: aload #15
    //   1036: aload_0
    //   1037: iload_1
    //   1038: aload #14
    //   1040: invokevirtual setPrimaryItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   1043: aload_0
    //   1044: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   1047: aload_0
    //   1048: invokevirtual finishUpdate : (Landroid/view/ViewGroup;)V
    //   1051: aload_0
    //   1052: invokevirtual getChildCount : ()I
    //   1055: istore #5
    //   1057: iconst_0
    //   1058: istore_1
    //   1059: iload_1
    //   1060: iload #5
    //   1062: if_icmpge -> 1149
    //   1065: aload_0
    //   1066: iload_1
    //   1067: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1070: astore #15
    //   1072: aload #15
    //   1074: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1077: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   1080: astore #14
    //   1082: aload #14
    //   1084: iload_1
    //   1085: putfield childIndex : I
    //   1088: aload #14
    //   1090: getfield isDecor : Z
    //   1093: ifne -> 1142
    //   1096: aload #14
    //   1098: getfield widthFactor : F
    //   1101: fconst_0
    //   1102: fcmpl
    //   1103: ifne -> 1142
    //   1106: aload_0
    //   1107: aload #15
    //   1109: invokevirtual infoForChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   1112: astore #15
    //   1114: aload #15
    //   1116: ifnull -> 1142
    //   1119: aload #14
    //   1121: aload #15
    //   1123: getfield widthFactor : F
    //   1126: putfield widthFactor : F
    //   1129: aload #14
    //   1131: aload #15
    //   1133: getfield position : I
    //   1136: putfield position : I
    //   1139: goto -> 1142
    //   1142: iload_1
    //   1143: iconst_1
    //   1144: iadd
    //   1145: istore_1
    //   1146: goto -> 1059
    //   1149: aload_0
    //   1150: invokespecial sortChildDrawingOrder : ()V
    //   1153: aload_0
    //   1154: invokevirtual hasFocus : ()Z
    //   1157: ifeq -> 1262
    //   1160: aload_0
    //   1161: invokevirtual findFocus : ()Landroid/view/View;
    //   1164: astore #14
    //   1166: aload #14
    //   1168: ifnull -> 1182
    //   1171: aload_0
    //   1172: aload #14
    //   1174: invokevirtual infoForAnyChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   1177: astore #14
    //   1179: goto -> 1185
    //   1182: aconst_null
    //   1183: astore #14
    //   1185: aload #14
    //   1187: ifnull -> 1202
    //   1190: aload #14
    //   1192: getfield position : I
    //   1195: aload_0
    //   1196: getfield mCurItem : I
    //   1199: if_icmpeq -> 1262
    //   1202: iconst_0
    //   1203: istore_1
    //   1204: iload_1
    //   1205: aload_0
    //   1206: invokevirtual getChildCount : ()I
    //   1209: if_icmpge -> 1262
    //   1212: aload_0
    //   1213: iload_1
    //   1214: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1217: astore #14
    //   1219: aload_0
    //   1220: aload #14
    //   1222: invokevirtual infoForChild : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   1225: astore #15
    //   1227: aload #15
    //   1229: ifnull -> 1255
    //   1232: aload #15
    //   1234: getfield position : I
    //   1237: aload_0
    //   1238: getfield mCurItem : I
    //   1241: if_icmpne -> 1255
    //   1244: aload #14
    //   1246: iload #8
    //   1248: invokevirtual requestFocus : (I)Z
    //   1251: ifeq -> 1255
    //   1254: return
    //   1255: iload_1
    //   1256: iconst_1
    //   1257: iadd
    //   1258: istore_1
    //   1259: goto -> 1204
    //   1262: return
    //   1263: aload_0
    //   1264: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1267: aload_0
    //   1268: invokevirtual getId : ()I
    //   1271: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1274: astore #14
    //   1276: goto -> 1288
    //   1279: aload_0
    //   1280: invokevirtual getId : ()I
    //   1283: invokestatic toHexString : (I)Ljava/lang/String;
    //   1286: astore #14
    //   1288: new java/lang/StringBuilder
    //   1291: dup
    //   1292: invokespecial <init> : ()V
    //   1295: astore #15
    //   1297: aload #15
    //   1299: ldc_w 'The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: '
    //   1302: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1305: pop
    //   1306: aload #15
    //   1308: aload_0
    //   1309: getfield mExpectedAdapterCount : I
    //   1312: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1315: pop
    //   1316: aload #15
    //   1318: ldc_w ', found: '
    //   1321: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1324: pop
    //   1325: aload #15
    //   1327: iload #10
    //   1329: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1332: pop
    //   1333: aload #15
    //   1335: ldc_w ' Pager id: '
    //   1338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1341: pop
    //   1342: aload #15
    //   1344: aload #14
    //   1346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1349: pop
    //   1350: aload #15
    //   1352: ldc_w ' Pager class: '
    //   1355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1358: pop
    //   1359: aload #15
    //   1361: aload_0
    //   1362: invokevirtual getClass : ()Ljava/lang/Class;
    //   1365: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1368: pop
    //   1369: aload #15
    //   1371: ldc_w ' Problematic adapter: '
    //   1374: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1377: pop
    //   1378: aload #15
    //   1380: aload_0
    //   1381: getfield mAdapter : Landroid/support/v4/view/PagerAdapter;
    //   1384: invokevirtual getClass : ()Ljava/lang/Class;
    //   1387: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1390: pop
    //   1391: new java/lang/IllegalStateException
    //   1394: dup
    //   1395: aload #15
    //   1397: invokevirtual toString : ()Ljava/lang/String;
    //   1400: invokespecial <init> : (Ljava/lang/String;)V
    //   1403: athrow
    //   1404: astore #14
    //   1406: goto -> 1279
    // Exception table:
    //   from	to	target	type
    //   1263	1276	1404	android/content/res/Resources$NotFoundException
  }
  
  public void removeView(View paramView) {
    if (this.mInLayout) {
      removeViewInLayout(paramView);
      return;
    } 
    super.removeView(paramView);
  }
  
  public void setAdapter(PagerAdapter paramPagerAdapter) {
    PagerAdapter pagerAdapter = this.mAdapter;
    if (pagerAdapter != null) {
      pagerAdapter.unregisterDataSetObserver(this.mObserver);
      this.mAdapter.startUpdate(this);
      for (int i = 0; i < this.mItems.size(); i++) {
        ItemInfo itemInfo = this.mItems.get(i);
        this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
      } 
      this.mAdapter.finishUpdate(this);
      this.mItems.clear();
      removeNonDecorViews();
      this.mCurItem = 0;
      scrollTo(0, 0);
    } 
    pagerAdapter = this.mAdapter;
    this.mAdapter = paramPagerAdapter;
    this.mExpectedAdapterCount = 0;
    if (this.mAdapter != null) {
      if (this.mObserver == null)
        this.mObserver = new PagerObserver(); 
      this.mAdapter.registerDataSetObserver(this.mObserver);
      this.mPopulatePending = false;
      boolean bool = this.mFirstLayout;
      this.mFirstLayout = true;
      this.mExpectedAdapterCount = this.mAdapter.getCount();
      if (this.mRestoredCurItem >= 0) {
        this.mAdapter.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
        setCurrentItemInternal(this.mRestoredCurItem, false, true);
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = null;
        this.mRestoredClassLoader = null;
      } else if (!bool) {
        populate();
      } else {
        requestLayout();
      } 
    } 
    OnAdapterChangeListener onAdapterChangeListener = this.mAdapterChangeListener;
    if (onAdapterChangeListener != null && pagerAdapter != paramPagerAdapter)
      onAdapterChangeListener.onAdapterChanged(pagerAdapter, paramPagerAdapter); 
  }
  
  void setChildrenDrawingOrderEnabledCompat(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 7) {
      if (this.mSetChildrenDrawingOrderEnabled == null)
        try {
          this.mSetChildrenDrawingOrderEnabled = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[] { boolean.class });
        } catch (NoSuchMethodException noSuchMethodException) {
          Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", noSuchMethodException);
        }  
      try {
        this.mSetChildrenDrawingOrderEnabled.invoke(this, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      } catch (Exception exception) {
        Log.e("ViewPager", "Error changing children drawing order", exception);
      } 
    } 
  }
  
  public void setCurrentItem(int paramInt) {
    this.mPopulatePending = false;
    setCurrentItemInternal(paramInt, this.mFirstLayout ^ true, false);
  }
  
  public void setCurrentItem(int paramInt, boolean paramBoolean) {
    this.mPopulatePending = false;
    setCurrentItemInternal(paramInt, paramBoolean, false);
  }
  
  void setCurrentItemInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    setCurrentItemInternal(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  void setCurrentItemInternal(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    int i;
    PagerAdapter pagerAdapter = this.mAdapter;
    if (pagerAdapter == null || pagerAdapter.getCount() <= 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (!paramBoolean2 && this.mCurItem == paramInt1 && this.mItems.size() != 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    paramBoolean2 = true;
    if (paramInt1 < 0) {
      i = 0;
    } else {
      i = paramInt1;
      if (paramInt1 >= this.mAdapter.getCount())
        i = this.mAdapter.getCount() - 1; 
    } 
    paramInt1 = this.mOffscreenPageLimit;
    int j = this.mCurItem;
    if (i > j + paramInt1 || i < j - paramInt1)
      for (paramInt1 = 0; paramInt1 < this.mItems.size(); paramInt1++)
        ((ItemInfo)this.mItems.get(paramInt1)).scrolling = true;  
    if (this.mCurItem == i)
      paramBoolean2 = false; 
    if (this.mFirstLayout) {
      this.mCurItem = i;
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListener;
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(i); 
      } 
      if (paramBoolean2) {
        OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(i); 
      } 
      requestLayout();
      return;
    } 
    populate(i);
    scrollToItem(i, paramBoolean1, paramInt2, paramBoolean2);
  }
  
  OnPageChangeListener setInternalPageChangeListener(OnPageChangeListener paramOnPageChangeListener) {
    OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
    this.mInternalPageChangeListener = paramOnPageChangeListener;
    return onPageChangeListener;
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    int i = paramInt;
    if (paramInt < 1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Requested offscreen page limit ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" too small; defaulting to ");
      stringBuilder.append(1);
      Log.w("ViewPager", stringBuilder.toString());
      i = 1;
    } 
    if (i != this.mOffscreenPageLimit) {
      this.mOffscreenPageLimit = i;
      populate();
    } 
  }
  
  void setOnAdapterChangeListener(OnAdapterChangeListener paramOnAdapterChangeListener) {
    this.mAdapterChangeListener = paramOnAdapterChangeListener;
  }
  
  public void setOnPageChangeListener(OnPageChangeListener paramOnPageChangeListener) {
    this.mOnPageChangeListener = paramOnPageChangeListener;
  }
  
  public void setPageMargin(int paramInt) {
    int i = this.mPageMargin;
    this.mPageMargin = paramInt;
    int j = getWidth();
    recomputeScrollPosition(j, j, paramInt, i);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt) {
    setPageMarginDrawable(getContext().getResources().getDrawable(paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable) {
    boolean bool;
    this.mMarginDrawable = paramDrawable;
    if (paramDrawable != null)
      refreshDrawableState(); 
    if (paramDrawable == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
  }
  
  public void setPageTransformer(boolean paramBoolean, PageTransformer paramPageTransformer) {
    if (Build.VERSION.SDK_INT >= 11) {
      boolean bool1;
      boolean bool2;
      boolean bool3;
      byte b = 1;
      if (paramPageTransformer != null) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (this.mPageTransformer != null) {
        bool3 = true;
      } else {
        bool3 = false;
      } 
      if (bool2 != bool3) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.mPageTransformer = paramPageTransformer;
      setChildrenDrawingOrderEnabledCompat(bool2);
      if (bool2) {
        if (paramBoolean)
          b = 2; 
        this.mDrawingOrder = b;
      } else {
        this.mDrawingOrder = 0;
      } 
      if (bool1)
        populate(); 
    } 
  }
  
  void smoothScrollTo(int paramInt1, int paramInt2) {
    smoothScrollTo(paramInt1, paramInt2, 0);
  }
  
  void smoothScrollTo(int paramInt1, int paramInt2, int paramInt3) {
    if (getChildCount() == 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    int i = getScrollX();
    int j = getScrollY();
    int k = paramInt1 - i;
    paramInt2 -= j;
    if (k == 0 && paramInt2 == 0) {
      completeScroll(false);
      populate();
      setScrollState(0);
      return;
    } 
    setScrollingCacheEnabled(true);
    setScrollState(2);
    paramInt1 = getClientWidth();
    int m = paramInt1 / 2;
    float f2 = Math.abs(k);
    float f1 = paramInt1;
    float f3 = Math.min(1.0F, f2 * 1.0F / f1);
    f2 = m;
    f3 = distanceInfluenceForSnapDuration(f3);
    paramInt1 = Math.abs(paramInt3);
    if (paramInt1 > 0) {
      paramInt1 = Math.round(Math.abs((f2 + f3 * f2) / paramInt1) * 1000.0F) * 4;
    } else {
      f2 = this.mAdapter.getPageWidth(this.mCurItem);
      paramInt1 = (int)((Math.abs(k) / (f1 * f2 + this.mPageMargin) + 1.0F) * 100.0F);
    } 
    paramInt1 = Math.min(paramInt1, 600);
    this.mScroller.startScroll(i, j, k, paramInt2, paramInt1);
    ViewCompat.postInvalidateOnAnimation((View)this);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mMarginDrawable);
  }
  
  static interface Decor {}
  
  static class ItemInfo {
    Object object;
    
    float offset;
    
    int position;
    
    boolean scrolling;
    
    float widthFactor;
  }
  
  public static class LayoutParams extends ViewGroup.LayoutParams {
    int childIndex;
    
    public int gravity;
    
    public boolean isDecor;
    
    boolean needsMeasure;
    
    int position;
    
    float widthFactor = 0.0F;
    
    public LayoutParams() {
      super(-1, -1);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ViewPager.LAYOUT_ATTRS);
      this.gravity = typedArray.getInteger(0, 48);
      typedArray.recycle();
    }
  }
  
  class MyAccessibilityDelegate extends AccessibilityDelegateCompat {
    private boolean canScroll() {
      return (ViewPager.this.mAdapter != null && ViewPager.this.mAdapter.getCount() > 1);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ViewPager.class.getName());
      AccessibilityRecordCompat accessibilityRecordCompat = AccessibilityRecordCompat.obtain();
      accessibilityRecordCompat.setScrollable(canScroll());
      if (param1AccessibilityEvent.getEventType() == 4096 && ViewPager.this.mAdapter != null) {
        accessibilityRecordCompat.setItemCount(ViewPager.this.mAdapter.getCount());
        accessibilityRecordCompat.setFromIndex(ViewPager.this.mCurItem);
        accessibilityRecordCompat.setToIndex(ViewPager.this.mCurItem);
      } 
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      param1AccessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
      param1AccessibilityNodeInfoCompat.setScrollable(canScroll());
      if (ViewPager.this.canScrollHorizontally(1))
        param1AccessibilityNodeInfoCompat.addAction(4096); 
      if (ViewPager.this.canScrollHorizontally(-1))
        param1AccessibilityNodeInfoCompat.addAction(8192); 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        if (ViewPager.this.canScrollHorizontally(-1)) {
          ViewPager viewPager = ViewPager.this;
          viewPager.setCurrentItem(viewPager.mCurItem - 1);
          return true;
        } 
        return false;
      } 
      if (ViewPager.this.canScrollHorizontally(1)) {
        ViewPager viewPager = ViewPager.this;
        viewPager.setCurrentItem(viewPager.mCurItem + 1);
        return true;
      } 
      return false;
    }
  }
  
  static interface OnAdapterChangeListener {
    void onAdapterChanged(PagerAdapter param1PagerAdapter1, PagerAdapter param1PagerAdapter2);
  }
  
  public static interface OnPageChangeListener {
    void onPageScrollStateChanged(int param1Int);
    
    void onPageScrolled(int param1Int1, float param1Float, int param1Int2);
    
    void onPageSelected(int param1Int);
  }
  
  public static interface PageTransformer {
    void transformPage(View param1View, float param1Float);
  }
  
  private class PagerObserver extends DataSetObserver {
    private PagerObserver() {}
    
    public void onChanged() {
      ViewPager.this.dataSetChanged();
    }
    
    public void onInvalidated() {
      ViewPager.this.dataSetChanged();
    }
  }
  
  public static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks<SavedState>() {
          public ViewPager.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
            return new ViewPager.SavedState(param2Parcel, param2ClassLoader);
          }
          
          public ViewPager.SavedState[] newArray(int param2Int) {
            return new ViewPager.SavedState[param2Int];
          }
        });
    
    Parcelable adapterState;
    
    ClassLoader loader;
    
    int position;
    
    SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel);
      ClassLoader classLoader = param1ClassLoader;
      if (param1ClassLoader == null)
        classLoader = getClass().getClassLoader(); 
      this.position = param1Parcel.readInt();
      this.adapterState = param1Parcel.readParcelable(classLoader);
      this.loader = classLoader;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FragmentPager.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" position=");
      stringBuilder.append(this.position);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.position);
      param1Parcel.writeParcelable(this.adapterState, param1Int);
    }
  }
  
  static final class null implements ParcelableCompatCreatorCallbacks<SavedState> {
    public ViewPager.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public ViewPager.SavedState[] newArray(int param1Int) {
      return new ViewPager.SavedState[param1Int];
    }
  }
  
  public static class SimpleOnPageChangeListener implements OnPageChangeListener {
    public void onPageScrollStateChanged(int param1Int) {}
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {}
    
    public void onPageSelected(int param1Int) {}
  }
  
  static class ViewPositionComparator implements Comparator<View> {
    public int compare(View param1View1, View param1View2) {
      ViewPager.LayoutParams layoutParams1 = (ViewPager.LayoutParams)param1View1.getLayoutParams();
      ViewPager.LayoutParams layoutParams2 = (ViewPager.LayoutParams)param1View2.getLayoutParams();
      return (layoutParams1.isDecor != layoutParams2.isDecor) ? (layoutParams1.isDecor ? 1 : -1) : (layoutParams1.position - layoutParams2.position);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\android\support\v4\view\ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */