package com.deploygate.service;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IDeployGateSdkService extends IInterface {
  void init(IDeployGateSdkServiceCallback paramIDeployGateSdkServiceCallback, String paramString, Bundle paramBundle) throws RemoteException;
  
  void sendEvent(String paramString1, String paramString2, Bundle paramBundle) throws RemoteException;
  
  public static abstract class Stub extends Binder implements IDeployGateSdkService {
    private static final String DESCRIPTOR = "com.deploygate.service.IDeployGateSdkService";
    
    static final int TRANSACTION_init = 1;
    
    static final int TRANSACTION_sendEvent = 2;
    
    public Stub() {
      attachInterface(this, "com.deploygate.service.IDeployGateSdkService");
    }
    
    public static IDeployGateSdkService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.deploygate.service.IDeployGateSdkService");
      return (iInterface != null && iInterface instanceof IDeployGateSdkService) ? (IDeployGateSdkService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      Bundle bundle1;
      String str2 = null;
      Bundle bundle2 = null;
      if (param1Int1 != 1) {
        if (param1Int1 != 2) {
          if (param1Int1 != 1598968902)
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
          param1Parcel2.writeString("com.deploygate.service.IDeployGateSdkService");
          return true;
        } 
        param1Parcel1.enforceInterface("com.deploygate.service.IDeployGateSdkService");
        str2 = param1Parcel1.readString();
        String str = param1Parcel1.readString();
        if (param1Parcel1.readInt() != 0)
          bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
        sendEvent(str2, str, bundle2);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("com.deploygate.service.IDeployGateSdkService");
      IDeployGateSdkServiceCallback iDeployGateSdkServiceCallback = IDeployGateSdkServiceCallback.Stub.asInterface(param1Parcel1.readStrongBinder());
      String str3 = param1Parcel1.readString();
      String str1 = str2;
      if (param1Parcel1.readInt() != 0)
        bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
      init(iDeployGateSdkServiceCallback, str3, bundle1);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class Proxy implements IDeployGateSdkService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return "com.deploygate.service.IDeployGateSdkService";
      }
      
      public void init(IDeployGateSdkServiceCallback param2IDeployGateSdkServiceCallback, String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.deploygate.service.IDeployGateSdkService");
          if (param2IDeployGateSdkServiceCallback != null) {
            IBinder iBinder = param2IDeployGateSdkServiceCallback.asBinder();
          } else {
            param2IDeployGateSdkServiceCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2IDeployGateSdkServiceCallback);
          parcel1.writeString(param2String);
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void sendEvent(String param2String1, String param2String2, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.deploygate.service.IDeployGateSdkService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          if (param2Bundle != null) {
            parcel1.writeInt(1);
            param2Bundle.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IDeployGateSdkService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return "com.deploygate.service.IDeployGateSdkService";
    }
    
    public void init(IDeployGateSdkServiceCallback param1IDeployGateSdkServiceCallback, String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.deploygate.service.IDeployGateSdkService");
        if (param1IDeployGateSdkServiceCallback != null) {
          IBinder iBinder = param1IDeployGateSdkServiceCallback.asBinder();
        } else {
          param1IDeployGateSdkServiceCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1IDeployGateSdkServiceCallback);
        parcel1.writeString(param1String);
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void sendEvent(String param1String1, String param1String2, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.deploygate.service.IDeployGateSdkService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        if (param1Bundle != null) {
          parcel1.writeInt(1);
          param1Bundle.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\deploygate\service\IDeployGateSdkService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */