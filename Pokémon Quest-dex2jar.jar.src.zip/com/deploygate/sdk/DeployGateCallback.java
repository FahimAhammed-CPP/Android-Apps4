package com.deploygate.sdk;

public interface DeployGateCallback {
  void onInitialized(boolean paramBoolean);
  
  void onStatusChanged(boolean paramBoolean1, boolean paramBoolean2, String paramString, boolean paramBoolean3);
  
  void onUpdateAvailable(int paramInt1, String paramString, int paramInt2);
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\deploygate\sdk\DeployGateCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */