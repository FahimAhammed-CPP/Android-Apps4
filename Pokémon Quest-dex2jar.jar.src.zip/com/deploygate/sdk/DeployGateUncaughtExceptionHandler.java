package com.deploygate.sdk;

import android.util.Log;

class DeployGateUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
  private static final String TAG = "DGExceptionHandler";
  
  private final Thread.UncaughtExceptionHandler mParentHandler;
  
  public DeployGateUncaughtExceptionHandler(Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) {
    this.mParentHandler = paramUncaughtExceptionHandler;
  }
  
  private void sendExceptionToService(Throwable paramThrowable) {
    DeployGate deployGate = DeployGate.getInstance();
    if (deployGate != null)
      deployGate.sendCrashReport(paramThrowable); 
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    Log.v("DGExceptionHandler", "DeployGate caught an exception, trying to send to the service");
    try {
      sendExceptionToService(paramThrowable);
      Thread.UncaughtExceptionHandler uncaughtExceptionHandler = this.mParentHandler;
      if (uncaughtExceptionHandler != null) {
        uncaughtExceptionHandler.uncaughtException(paramThread, paramThrowable);
        return;
      } 
    } catch (Throwable throwable) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("failed to send exception:");
      stringBuilder.append(throwable.getMessage());
      Log.e("DGExceptionHandler", stringBuilder.toString(), throwable);
      Thread.UncaughtExceptionHandler uncaughtExceptionHandler = this.mParentHandler;
      if (uncaughtExceptionHandler != null) {
        uncaughtExceptionHandler.uncaughtException(paramThread, paramThrowable);
        return;
      } 
    } finally {
      Exception exception;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\deploygate\sdk\DeployGateUncaughtExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */