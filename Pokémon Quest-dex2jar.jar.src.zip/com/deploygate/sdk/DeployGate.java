package com.deploygate.sdk;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.deploygate.service.IDeployGateSdkService;
import com.deploygate.service.IDeployGateSdkServiceCallback;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;

public class DeployGate {
  private static final String ACTION_DEPLOYGATE_STARTED = "com.deploygate.action.ServiceStarted";
  
  private static final String[] DEPLOYGATE_FINGERPRINTS = new String[] { "2f97f647645cb762bf5fc1445599a954e6ad76e7", "c1f285f69cc02a397135ed182aa79af53d5d20a1", "234eff4a1600a7aa78bf68adfbb15786e886ae1a" };
  
  private static final String DEPLOYGATE_PACKAGE = "com.deploygate";
  
  private static final int SDK_VERSION = 4;
  
  private static final String TAG = "DeployGate";
  
  private static DeployGate sInstance;
  
  private boolean mAppIsAuthorized;
  
  private boolean mAppIsManaged;
  
  private boolean mAppIsStopRequested;
  
  private boolean mAppUpdateAvailable;
  
  private String mAppUpdateMessage;
  
  private int mAppUpdateRevision;
  
  private int mAppUpdateVersionCode;
  
  private String mAppUpdateVersionName;
  
  private final Context mApplicationContext;
  
  private String mAuthor;
  
  private final HashSet<DeployGateCallback> mCallbacks;
  
  private int mCurrentRevision;
  
  private int mDeployGateVersionCode;
  
  private String mDistributionId;
  
  private String mDistributionTitle;
  
  private String mDistributionUserName;
  
  private String mExpectedAuthor;
  
  private final Handler mHandler = new Handler();
  
  private CountDownLatch mInitializedLatch;
  
  private boolean mIsDeployGateAvailable;
  
  private Thread mLogcatThread;
  
  private LogCatTransportWorker mLogcatWorker;
  
  private String mLoginUsername;
  
  private final IDeployGateSdkServiceCallback mRemoteCallback = (IDeployGateSdkServiceCallback)new IDeployGateSdkServiceCallback.Stub() {
      private void onInitialized(final boolean isManaged, final boolean isAuthorized, final String loginUsername, String param1String2, final boolean isStopped, String param1String3, int param1Int1, String param1String4, String param1String5, int param1Int2) throws RemoteException {
        Log.v("DeployGate", "DeployGate service initialized");
        DeployGate.access$202(DeployGate.this, isManaged);
        DeployGate.access$302(DeployGate.this, isAuthorized);
        DeployGate.access$402(DeployGate.this, isStopped);
        DeployGate.access$502(DeployGate.this, loginUsername);
        DeployGate.access$602(DeployGate.this, param1String2);
        DeployGate.access$702(DeployGate.this, param1String3);
        DeployGate.access$802(DeployGate.this, param1Int2);
        DeployGate.access$902(DeployGate.this, param1Int1);
        DeployGate.access$1002(DeployGate.this, param1String4);
        DeployGate.access$1102(DeployGate.this, param1String5);
        DeployGate.this.mHandler.post(new Runnable() {
              public void run() {
                for (DeployGateCallback deployGateCallback : DeployGate.this.mCallbacks) {
                  deployGateCallback.onInitialized(true);
                  deployGateCallback.onStatusChanged(isManaged, isAuthorized, loginUsername, isStopped);
                } 
              }
            });
        DeployGate.access$1402(DeployGate.this, true);
        DeployGate.this.mInitializedLatch.countDown();
      }
      
      private void onUpdateArrived(final int serial, final String versionName, final int versionCode, String param1String2) throws RemoteException {
        DeployGate.access$1602(DeployGate.this, true);
        DeployGate.access$1702(DeployGate.this, serial);
        DeployGate.access$1802(DeployGate.this, versionName);
        DeployGate.access$1902(DeployGate.this, versionCode);
        DeployGate.access$2002(DeployGate.this, param1String2);
        DeployGate.this.mHandler.post(new Runnable() {
              public void run() {
                Iterator<DeployGateCallback> iterator = DeployGate.this.mCallbacks.iterator();
                while (iterator.hasNext())
                  ((DeployGateCallback)iterator.next()).onUpdateAvailable(serial, versionName, versionCode); 
              }
            });
      }
      
      public void onEvent(String param1String, Bundle param1Bundle) throws RemoteException {
        if ("init".equals(param1String)) {
          onInitialized(param1Bundle.getBoolean("isManaged", false), param1Bundle.getBoolean("isAuthorized", false), param1Bundle.getString("loginUsername"), param1Bundle.getString("distributionUserName"), param1Bundle.getBoolean("isStopRequested", false), param1Bundle.getString("author"), param1Bundle.getInt("currentRevision", 0), param1Bundle.getString("currentDistributionId"), param1Bundle.getString("currentDistributionTitle"), param1Bundle.getInt("deploygateVersionCode", 0));
          return;
        } 
        if ("update".equals(param1String)) {
          onUpdateArrived(param1Bundle.getInt("serial"), param1Bundle.getString("versionName"), param1Bundle.getInt("versionCode"), param1Bundle.getString("serialMessage"));
          return;
        } 
        if ("oneshotLogcat".equals(param1String)) {
          DeployGate.this.onOneshotLogcat();
          return;
        } 
        if ("enableLogcat".equals(param1String)) {
          DeployGate.this.onEnableLogcat(true);
          return;
        } 
        if ("disableLogcat".equals(param1String))
          DeployGate.this.onEnableLogcat(false); 
      }
    };
  
  private IDeployGateSdkService mRemoteService;
  
  private DeployGate(Context paramContext, String paramString, DeployGateCallback paramDeployGateCallback) {
    this.mApplicationContext = paramContext;
    this.mCallbacks = new HashSet<DeployGateCallback>();
    this.mExpectedAuthor = paramString;
    prepareBroadcastReceiver();
    if (paramDeployGateCallback != null)
      this.mCallbacks.add(paramDeployGateCallback); 
    this.mInitializedLatch = new CountDownLatch(1);
    initService(true);
  }
  
  private void bindToService(final boolean isBoot) {
    Intent intent = new Intent(IDeployGateSdkService.class.getName());
    intent.setPackage("com.deploygate");
    this.mApplicationContext.bindService(intent, new ServiceConnection() {
          public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
            Log.v("DeployGate", "DeployGate service connected");
            DeployGate.access$2302(DeployGate.this, IDeployGateSdkService.Stub.asInterface(param1IBinder));
            DeployGate.this.requestServiceInit(isBoot);
          }
          
          public void onServiceDisconnected(ComponentName param1ComponentName) {
            Log.v("DeployGate", "DeployGate service disconneced");
            DeployGate.access$2302(DeployGate.this, null);
          }
        }1);
  }
  
  public static void composeComment() {
    composeComment(null);
  }
  
  public static void composeComment(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null) {
      if (deployGate.mDistributionId == null)
        return; 
      Bundle bundle = new Bundle();
      bundle.putString("comment", paramString);
      sInstance.invokeAction("composeComment", bundle);
    } 
  }
  
  public static String getAuthorUsername() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mAuthor;
    } 
    return null;
  }
  
  public static int getCurrentRevision() {
    DeployGate deployGate = sInstance;
    return (deployGate != null) ? deployGate.mCurrentRevision : 0;
  }
  
  private String getDeployGatePackageSignature() {
    try {
      PackageInfo packageInfo = this.mApplicationContext.getPackageManager().getPackageInfo("com.deploygate", 64);
      if (packageInfo != null && packageInfo.signatures != null) {
        if (packageInfo.signatures.length == 0)
          return null; 
        try {
          MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
          Signature[] arrayOfSignature = packageInfo.signatures;
          int i = 0;
          byte[] arrayOfByte = messageDigest.digest(arrayOfSignature[0].toByteArray());
          StringBuilder stringBuilder = new StringBuilder(40);
          while (i < arrayOfByte.length) {
            stringBuilder.append(Integer.toString((arrayOfByte[i] & 0xFF) + 256, 16).substring(1));
            i++;
          } 
          return stringBuilder.toString();
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
          Log.e("DeployGate", "SHA1 is not supported on this platform?", noSuchAlgorithmException);
        } 
      } 
      return null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return null;
    } 
  }
  
  public static int getDeployGateVersionCode() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? 0 : deployGate.mDeployGateVersionCode;
  }
  
  public static String getDistributionId() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? null : (TextUtils.isEmpty(deployGate.mDistributionId) ? null : sInstance.mDistributionId);
  }
  
  public static String getDistributionTitle() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? null : (TextUtils.isEmpty(deployGate.mDistributionTitle) ? null : sInstance.mDistributionTitle);
  }
  
  public static String getDistributionUrl() {
    DeployGate deployGate = sInstance;
    if (deployGate == null)
      return null; 
    if (TextUtils.isEmpty(deployGate.mDistributionId))
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://deploygate.com/distributions/");
    stringBuilder.append(sInstance.mDistributionId);
    return stringBuilder.toString();
  }
  
  public static String getDistributionUserName() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? null : deployGate.mDistributionUserName;
  }
  
  static DeployGate getInstance() {
    return sInstance;
  }
  
  public static String getLoginUsername() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mLoginUsername;
    } 
    return null;
  }
  
  public static String getUpdateMessage() {
    DeployGate deployGate = sInstance;
    return (deployGate == null || deployGate.mDeployGateVersionCode < 39) ? null : deployGate.mAppUpdateMessage;
  }
  
  private boolean initService(boolean paramBoolean) {
    if (isDeployGateAvailable()) {
      Log.v("DeployGate", "DeployGate installation detected. Initializing.");
      bindToService(paramBoolean);
      return true;
    } 
    Log.v("DeployGate", "DeployGate is not available on this device.");
    this.mInitializedLatch.countDown();
    this.mIsDeployGateAvailable = false;
    callbackDeployGateUnavailable();
    return false;
  }
  
  public static void install(Application paramApplication) {
    install(paramApplication, (String)null);
  }
  
  public static void install(Application paramApplication, DeployGateCallback paramDeployGateCallback) {
    install(paramApplication, (String)null, paramDeployGateCallback);
  }
  
  public static void install(Application paramApplication, DeployGateCallback paramDeployGateCallback, boolean paramBoolean) {
    install(paramApplication, null, paramDeployGateCallback, paramBoolean);
  }
  
  public static void install(Application paramApplication, String paramString) {
    install(paramApplication, paramString, (DeployGateCallback)null);
  }
  
  public static void install(Application paramApplication, String paramString, DeployGateCallback paramDeployGateCallback) {
    install(paramApplication, paramString, paramDeployGateCallback, false);
  }
  
  public static void install(Application paramApplication, String paramString, DeployGateCallback paramDeployGateCallback, boolean paramBoolean) {
    if (sInstance != null) {
      Log.w("DeployGate", "DeployGate.install was already called. Ignoring.");
      return;
    } 
    if (!paramBoolean && !isDebuggable(paramApplication.getApplicationContext()))
      return; 
    Thread.setDefaultUncaughtExceptionHandler(new DeployGateUncaughtExceptionHandler(Thread.getDefaultUncaughtExceptionHandler()));
    sInstance = new DeployGate(paramApplication.getApplicationContext(), paramString, paramDeployGateCallback);
  }
  
  public static void installUpdate() {
    DeployGate deployGate = sInstance;
    if (deployGate == null)
      return; 
    deployGate.invokeAction("installUpdate", null);
  }
  
  private void invokeAction(String paramString, Bundle paramBundle) {
    IDeployGateSdkService iDeployGateSdkService = this.mRemoteService;
    if (iDeployGateSdkService == null)
      return; 
    try {
      iDeployGateSdkService.sendEvent(this.mApplicationContext.getPackageName(), paramString, paramBundle);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("failed to invoke ");
      stringBuilder.append(paramString);
      stringBuilder.append(" action: ");
      stringBuilder.append(remoteException.getMessage());
      Log.w("DeployGate", stringBuilder.toString());
      return;
    } 
  }
  
  public static boolean isAuthorized() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mAppIsAuthorized;
    } 
    return false;
  }
  
  private static boolean isDebuggable(Context paramContext) {
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramContext.getPackageName(), 0);
      return ((applicationInfo.flags & 0x2) == 2);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return false;
    } 
  }
  
  private boolean isDeployGateAvailable() {
    String str = getDeployGatePackageSignature();
    if (str == null)
      return false; 
    String[] arrayOfString = DEPLOYGATE_FINGERPRINTS;
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfString[i].equals(str))
        return true; 
    } 
    return false;
  }
  
  public static boolean isDeployGateAvaliable() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mIsDeployGateAvailable;
    } 
    return false;
  }
  
  public static boolean isInitialized() {
    DeployGate deployGate = sInstance;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (deployGate != null) {
      bool1 = bool2;
      if (deployGate.mInitializedLatch.getCount() == 0L)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public static boolean isManaged() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mAppIsManaged;
    } 
    return false;
  }
  
  private static boolean isStopRequested() {
    if (sInstance != null) {
      waitForInitialized();
      return sInstance.mAppIsStopRequested;
    } 
    return false;
  }
  
  public static void logDebug(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.sendLog("debug", paramString); 
  }
  
  public static void logError(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.sendLog("error", paramString); 
  }
  
  public static void logInfo(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.sendLog("info", paramString); 
  }
  
  public static void logVerbose(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.sendLog("verbose", paramString); 
  }
  
  public static void logWarn(String paramString) {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.sendLog("warn", paramString); 
  }
  
  private void onEnableLogcat(boolean paramBoolean) {
    if (this.mRemoteService == null)
      return; 
    if (paramBoolean) {
      Thread thread = this.mLogcatThread;
      if (thread == null || !thread.isAlive()) {
        this.mLogcatWorker = new LogCatTransportWorker(this.mApplicationContext.getPackageName(), this.mRemoteService, false);
        this.mLogcatThread = new Thread(this.mLogcatWorker);
        this.mLogcatThread.start();
        return;
      } 
    } else {
      Thread thread = this.mLogcatThread;
      if (thread != null && thread.isAlive()) {
        this.mLogcatWorker.stop();
        this.mLogcatThread.interrupt();
      } 
    } 
  }
  
  private void onOneshotLogcat() {
    Thread thread = this.mLogcatThread;
    if (thread == null || !thread.isAlive()) {
      this.mLogcatWorker = new LogCatTransportWorker(this.mApplicationContext.getPackageName(), this.mRemoteService, true);
      this.mLogcatThread = new Thread(this.mLogcatWorker);
      this.mLogcatThread.start();
    } 
  }
  
  public static void openComments() {
    DeployGate deployGate = sInstance;
    if (deployGate != null) {
      if (deployGate.mDistributionId == null)
        return; 
      deployGate.invokeAction("openComments", null);
    } 
  }
  
  private void prepareBroadcastReceiver() {
    IntentFilter intentFilter = new IntentFilter("com.deploygate.action.ServiceStarted");
    this.mApplicationContext.registerReceiver(new BroadcastReceiver() {
          public void onReceive(Context param1Context, Intent param1Intent) {
            if (param1Intent == null)
              return; 
            if (DeployGate.this.isDeployGateAvailable())
              DeployGate.this.bindToService(false); 
          }
        },  intentFilter);
  }
  
  public static void refresh() {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.refreshInternal(); 
  }
  
  private void refreshInternal() {
    if (this.mInitializedLatch.getCount() == 0L) {
      this.mInitializedLatch = new CountDownLatch(1);
      if (this.mRemoteService == null) {
        initService(false);
        return;
      } 
      requestServiceInit(false);
    } 
  }
  
  public static void registerCallback(DeployGateCallback paramDeployGateCallback, boolean paramBoolean) {
    DeployGate deployGate = sInstance;
    if (deployGate == null)
      return; 
    if (paramDeployGateCallback == null)
      return; 
    deployGate.registerCallbackInternal(paramDeployGateCallback, paramBoolean);
  }
  
  private void registerCallbackInternal(DeployGateCallback paramDeployGateCallback, boolean paramBoolean) {
    this.mCallbacks.add(paramDeployGateCallback);
    if (paramBoolean)
      refresh(); 
  }
  
  public static void requestLogCat() {
    DeployGate deployGate = sInstance;
    if (deployGate != null)
      deployGate.onOneshotLogcat(); 
  }
  
  private void requestServiceInit(boolean paramBoolean) {
    Bundle bundle = new Bundle();
    bundle.putBoolean("isBoot", paramBoolean);
    bundle.putBoolean("canLogCat", canLogCat());
    bundle.putString("expectedAuthor", this.mExpectedAuthor);
    bundle.putInt("sdkVersion", 4);
    try {
      this.mRemoteService.init(this.mRemoteCallback, this.mApplicationContext.getPackageName(), bundle);
      return;
    } catch (RemoteException remoteException) {
      Log.w("DeployGate", "DeployGate service failed to be initialized.");
      return;
    } 
  }
  
  public static void unregisterCallback(DeployGateCallback paramDeployGateCallback) {
    DeployGate deployGate = sInstance;
    if (deployGate == null)
      return; 
    if (paramDeployGateCallback == null)
      return; 
    deployGate.mCallbacks.remove(paramDeployGateCallback);
  }
  
  private static void waitForInitialized() {
    try {
      sInstance.mInitializedLatch.await();
      return;
    } catch (InterruptedException interruptedException) {
      Log.w("DeployGate", "Interrupted while waiting initialization");
      return;
    } 
  }
  
  void callbackDeployGateUnavailable() {
    this.mHandler.post(new Runnable() {
          public void run() {
            for (DeployGateCallback deployGateCallback : DeployGate.this.mCallbacks) {
              deployGateCallback.onInitialized(false);
              deployGateCallback.onStatusChanged(false, false, null, false);
            } 
          }
        });
  }
  
  protected boolean canLogCat() {
    return (Build.VERSION.SDK_INT >= 16) ? true : ((this.mApplicationContext.getPackageManager().checkPermission("android.permission.READ_LOGS", this.mApplicationContext.getPackageName()) == 0));
  }
  
  public int getUpdateRevision() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? 0 : deployGate.mAppUpdateRevision;
  }
  
  public int getUpdateVersionCode() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? 0 : deployGate.mAppUpdateVersionCode;
  }
  
  public String getUpdateVersionName() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? null : deployGate.mAppUpdateVersionName;
  }
  
  public boolean hasUpdate() {
    DeployGate deployGate = sInstance;
    return (deployGate == null) ? false : deployGate.mAppUpdateAvailable;
  }
  
  void sendCrashReport(Throwable paramThrowable) {
    if (this.mRemoteService == null)
      return; 
    Bundle bundle = new Bundle();
    bundle.putSerializable("exception", paramThrowable);
    try {
      this.mRemoteService.sendEvent(this.mApplicationContext.getPackageName(), "reportCrash", bundle);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("failed to send crash report: ");
      stringBuilder.append(remoteException.getMessage());
      Log.w("DeployGate", stringBuilder.toString());
      return;
    } 
  }
  
  void sendLog(String paramString1, String paramString2) {
    if (this.mRemoteService == null)
      return; 
    Bundle bundle = new Bundle();
    bundle.putSerializable("log", paramString2);
    bundle.putSerializable("logType", paramString1);
    try {
      this.mRemoteService.sendEvent(this.mApplicationContext.getPackageName(), "customLog", bundle);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("failed to send custom log: ");
      stringBuilder.append(remoteException.getMessage());
      Log.w("DeployGate", stringBuilder.toString());
      return;
    } 
  }
  
  private static class LogCatTransportWorker implements Runnable {
    private boolean mIsOneShot;
    
    private final String mPackageName;
    
    private Process mProcess;
    
    private final IDeployGateSdkService mService;
    
    public LogCatTransportWorker(String param1String, IDeployGateSdkService param1IDeployGateSdkService, boolean param1Boolean) {
      this.mPackageName = param1String;
      this.mService = param1IDeployGateSdkService;
      this.mIsOneShot = param1Boolean;
    }
    
    private boolean send(ArrayList<String> param1ArrayList) {
      Bundle bundle = new Bundle();
      bundle.putStringArrayList("log", param1ArrayList);
      try {
        this.mService.sendEvent(this.mPackageName, "sendLogcat", bundle);
        return true;
      } catch (RemoteException remoteException) {
        return false;
      } 
    }
    
    public void run() {
      // Byte code:
      //   0: aconst_null
      //   1: astore #4
      //   3: aconst_null
      //   4: astore_2
      //   5: aload_0
      //   6: aconst_null
      //   7: putfield mProcess : Ljava/lang/Process;
      //   10: aload_2
      //   11: astore_1
      //   12: new java/util/LinkedList
      //   15: dup
      //   16: invokespecial <init> : ()V
      //   19: astore #5
      //   21: aload_2
      //   22: astore_1
      //   23: aload #5
      //   25: ldc 'logcat'
      //   27: invokevirtual add : (Ljava/lang/Object;)Z
      //   30: pop
      //   31: aload_2
      //   32: astore_1
      //   33: new java/util/ArrayList
      //   36: dup
      //   37: invokespecial <init> : ()V
      //   40: astore_3
      //   41: aload_2
      //   42: astore_1
      //   43: aload_0
      //   44: getfield mIsOneShot : Z
      //   47: ifeq -> 94
      //   50: aload_2
      //   51: astore_1
      //   52: aload #5
      //   54: ldc '-d'
      //   56: invokevirtual add : (Ljava/lang/Object;)Z
      //   59: pop
      //   60: aload_2
      //   61: astore_1
      //   62: getstatic android/os/Build$VERSION.SDK_INT : I
      //   65: bipush #8
      //   67: if_icmplt -> 94
      //   70: aload_2
      //   71: astore_1
      //   72: aload #5
      //   74: ldc '-t'
      //   76: invokevirtual add : (Ljava/lang/Object;)Z
      //   79: pop
      //   80: aload_2
      //   81: astore_1
      //   82: aload #5
      //   84: sipush #500
      //   87: invokestatic valueOf : (I)Ljava/lang/String;
      //   90: invokevirtual add : (Ljava/lang/Object;)Z
      //   93: pop
      //   94: aload_2
      //   95: astore_1
      //   96: aload #5
      //   98: ldc '-v'
      //   100: invokevirtual add : (Ljava/lang/Object;)Z
      //   103: pop
      //   104: aload_2
      //   105: astore_1
      //   106: aload #5
      //   108: ldc 'threadtime'
      //   110: invokevirtual add : (Ljava/lang/Object;)Z
      //   113: pop
      //   114: aload_2
      //   115: astore_1
      //   116: aload #5
      //   118: ldc '*:V'
      //   120: invokevirtual add : (Ljava/lang/Object;)Z
      //   123: pop
      //   124: aload_2
      //   125: astore_1
      //   126: aload_0
      //   127: invokestatic getRuntime : ()Ljava/lang/Runtime;
      //   130: aload #5
      //   132: aload #5
      //   134: invokevirtual size : ()I
      //   137: anewarray java/lang/String
      //   140: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
      //   143: checkcast [Ljava/lang/String;
      //   146: invokevirtual exec : ([Ljava/lang/String;)Ljava/lang/Process;
      //   149: putfield mProcess : Ljava/lang/Process;
      //   152: aload_2
      //   153: astore_1
      //   154: new java/io/BufferedReader
      //   157: dup
      //   158: new java/io/InputStreamReader
      //   161: dup
      //   162: aload_0
      //   163: getfield mProcess : Ljava/lang/Process;
      //   166: invokevirtual getInputStream : ()Ljava/io/InputStream;
      //   169: invokespecial <init> : (Ljava/io/InputStream;)V
      //   172: sipush #8192
      //   175: invokespecial <init> : (Ljava/io/Reader;I)V
      //   178: astore_2
      //   179: ldc 'DeployGate'
      //   181: ldc 'Start retrieving logcat'
      //   183: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
      //   186: pop
      //   187: aload_2
      //   188: invokevirtual readLine : ()Ljava/lang/String;
      //   191: astore_1
      //   192: aload_1
      //   193: ifnull -> 287
      //   196: new java/lang/StringBuilder
      //   199: dup
      //   200: invokespecial <init> : ()V
      //   203: astore #4
      //   205: aload #4
      //   207: aload_1
      //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   211: pop
      //   212: aload #4
      //   214: ldc '\\n'
      //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   219: pop
      //   220: aload_3
      //   221: aload #4
      //   223: invokevirtual toString : ()Ljava/lang/String;
      //   226: invokevirtual add : (Ljava/lang/Object;)Z
      //   229: pop
      //   230: aload_0
      //   231: getfield mIsOneShot : Z
      //   234: ifeq -> 256
      //   237: aload_3
      //   238: invokevirtual size : ()I
      //   241: sipush #500
      //   244: if_icmple -> 187
      //   247: aload_3
      //   248: iconst_0
      //   249: invokevirtual remove : (I)Ljava/lang/Object;
      //   252: pop
      //   253: goto -> 187
      //   256: aload_2
      //   257: invokevirtual ready : ()Z
      //   260: ifne -> 187
      //   263: aload_0
      //   264: aload_3
      //   265: invokespecial send : (Ljava/util/ArrayList;)Z
      //   268: ifeq -> 278
      //   271: aload_3
      //   272: invokevirtual clear : ()V
      //   275: goto -> 187
      //   278: aload_2
      //   279: invokevirtual close : ()V
      //   282: aload_0
      //   283: invokevirtual stop : ()V
      //   286: return
      //   287: aload_3
      //   288: invokevirtual isEmpty : ()Z
      //   291: ifne -> 300
      //   294: aload_0
      //   295: aload_3
      //   296: invokespecial send : (Ljava/util/ArrayList;)Z
      //   299: pop
      //   300: aload_2
      //   301: invokevirtual close : ()V
      //   304: goto -> 381
      //   307: astore_3
      //   308: aload_2
      //   309: astore_1
      //   310: aload_3
      //   311: astore_2
      //   312: goto -> 386
      //   315: astore_3
      //   316: goto -> 327
      //   319: astore_2
      //   320: goto -> 386
      //   323: astore_3
      //   324: aload #4
      //   326: astore_2
      //   327: aload_2
      //   328: astore_1
      //   329: new java/lang/StringBuilder
      //   332: dup
      //   333: invokespecial <init> : ()V
      //   336: astore #4
      //   338: aload_2
      //   339: astore_1
      //   340: aload #4
      //   342: ldc 'Logcat stopped: '
      //   344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   347: pop
      //   348: aload_2
      //   349: astore_1
      //   350: aload #4
      //   352: aload_3
      //   353: invokevirtual getMessage : ()Ljava/lang/String;
      //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   359: pop
      //   360: aload_2
      //   361: astore_1
      //   362: ldc 'DeployGate'
      //   364: aload #4
      //   366: invokevirtual toString : ()Ljava/lang/String;
      //   369: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   372: pop
      //   373: aload_2
      //   374: ifnull -> 381
      //   377: aload_2
      //   378: invokevirtual close : ()V
      //   381: aload_0
      //   382: invokevirtual stop : ()V
      //   385: return
      //   386: aload_1
      //   387: ifnull -> 394
      //   390: aload_1
      //   391: invokevirtual close : ()V
      //   394: aload_0
      //   395: invokevirtual stop : ()V
      //   398: aload_2
      //   399: athrow
      //   400: astore_1
      //   401: goto -> 282
      //   404: astore_1
      //   405: goto -> 381
      //   408: astore_1
      //   409: goto -> 394
      // Exception table:
      //   from	to	target	type
      //   12	21	323	java/io/IOException
      //   12	21	319	finally
      //   23	31	323	java/io/IOException
      //   23	31	319	finally
      //   33	41	323	java/io/IOException
      //   33	41	319	finally
      //   43	50	323	java/io/IOException
      //   43	50	319	finally
      //   52	60	323	java/io/IOException
      //   52	60	319	finally
      //   62	70	323	java/io/IOException
      //   62	70	319	finally
      //   72	80	323	java/io/IOException
      //   72	80	319	finally
      //   82	94	323	java/io/IOException
      //   82	94	319	finally
      //   96	104	323	java/io/IOException
      //   96	104	319	finally
      //   106	114	323	java/io/IOException
      //   106	114	319	finally
      //   116	124	323	java/io/IOException
      //   116	124	319	finally
      //   126	152	323	java/io/IOException
      //   126	152	319	finally
      //   154	179	323	java/io/IOException
      //   154	179	319	finally
      //   179	187	315	java/io/IOException
      //   179	187	307	finally
      //   187	192	315	java/io/IOException
      //   187	192	307	finally
      //   196	253	315	java/io/IOException
      //   196	253	307	finally
      //   256	275	315	java/io/IOException
      //   256	275	307	finally
      //   278	282	400	java/io/IOException
      //   287	300	315	java/io/IOException
      //   287	300	307	finally
      //   300	304	404	java/io/IOException
      //   329	338	319	finally
      //   340	348	319	finally
      //   350	360	319	finally
      //   362	373	319	finally
      //   377	381	404	java/io/IOException
      //   390	394	408	java/io/IOException
    }
    
    public void stop() {
      Process process = this.mProcess;
      if (process != null)
        process.destroy(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\deploygate\sdk\DeployGate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */