package com.android.billingclient.api;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.google.android.gms.internal.play_billing.zza;
import java.util.List;

final class zzd extends BroadcastReceiver {
  private final PurchasesUpdatedListener zzb;
  
  private boolean zzc;
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    BillingResult billingResult = zza.zzc(paramIntent, "BillingBroadcastManager");
    List<Purchase> list = zza.zzf(paramIntent.getExtras());
    this.zzb.onPurchasesUpdated(billingResult, list);
  }
  
  public final void zza(Context paramContext, IntentFilter paramIntentFilter) {
    if (!this.zzc) {
      paramContext.registerReceiver(zze.zzd(this.zza), paramIntentFilter);
      this.zzc = true;
    } 
  }
  
  public final void zzb(Context paramContext) {
    if (this.zzc) {
      paramContext.unregisterReceiver(zze.zzd(this.zza));
      this.zzc = false;
      return;
    } 
    zza.zzb("BillingBroadcastManager", "Receiver is not registered.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */