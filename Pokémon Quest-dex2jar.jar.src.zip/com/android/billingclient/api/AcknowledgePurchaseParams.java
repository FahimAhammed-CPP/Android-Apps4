package com.android.billingclient.api;

import androidx.annotation.NonNull;

public final class AcknowledgePurchaseParams {
  private String zza;
  
  private AcknowledgePurchaseParams() {}
  
  @NonNull
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  @NonNull
  public String getPurchaseToken() {
    return this.zza;
  }
  
  public static final class Builder {
    private String zza;
    
    private Builder() {}
    
    @NonNull
    public AcknowledgePurchaseParams build() {
      if (this.zza != null) {
        AcknowledgePurchaseParams acknowledgePurchaseParams = new AcknowledgePurchaseParams(null);
        AcknowledgePurchaseParams.zza(acknowledgePurchaseParams, this.zza);
        return acknowledgePurchaseParams;
      } 
      throw new IllegalArgumentException("Purchase token must be set");
    }
    
    @NonNull
    public Builder setPurchaseToken(@NonNull String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\AcknowledgePurchaseParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */