package com.android.billingclient.api;

final class zzag implements Runnable {
  zzag(zzah paramzzah) {}
  
  public final void run() {
    BillingClientImpl.zzj(this.zza.zza, 0);
    BillingClientImpl.zzi(this.zza.zza, null);
    zzah.zze(this.zza, zzam.zzr);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */