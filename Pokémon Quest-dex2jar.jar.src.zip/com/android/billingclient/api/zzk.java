package com.android.billingclient.api;

import java.util.concurrent.Callable;

final class zzk implements Callable<Void> {
  zzk(BillingClientImpl paramBillingClientImpl, String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */