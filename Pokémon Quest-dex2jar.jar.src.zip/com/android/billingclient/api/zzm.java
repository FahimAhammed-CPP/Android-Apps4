package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zza;

final class zzm implements Runnable {
  zzm(zzo paramzzo, Exception paramException) {}
  
  public final void run() {
    String str = String.valueOf(this.zza);
    StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 32);
    stringBuilder.append("Error acknowledge purchase; ex: ");
    stringBuilder.append(str);
    zza.zzb("BillingClient", stringBuilder.toString());
    this.zzb.zzb.onAcknowledgePurchaseResponse(zzam.zzq);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */