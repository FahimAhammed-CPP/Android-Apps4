package com.android.billingclient.api;

final class zzn implements Runnable {
  zzn(zzo paramzzo, int paramInt, String paramString) {}
  
  public final void run() {
    AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener = this.zzc.zzb;
    BillingResult.Builder builder = BillingResult.newBuilder();
    builder.setResponseCode(this.zza);
    builder.setDebugMessage(this.zzb);
    acknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(builder.build());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */