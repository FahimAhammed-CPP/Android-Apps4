package com.android.billingclient.api;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class Purchase {
  private final String zza;
  
  private final String zzb;
  
  private final JSONObject zzc;
  
  public Purchase(@NonNull String paramString1, @NonNull String paramString2) throws JSONException {
    this.zza = paramString1;
    this.zzb = paramString2;
    this.zzc = new JSONObject(this.zza);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Purchase))
      return false; 
    paramObject = paramObject;
    return (TextUtils.equals(this.zza, paramObject.getOriginalJson()) && TextUtils.equals(this.zzb, paramObject.getSignature()));
  }
  
  @Nullable
  public AccountIdentifiers getAccountIdentifiers() {
    String str1 = this.zzc.optString("obfuscatedAccountId");
    String str2 = this.zzc.optString("obfuscatedProfileId");
    return (str1 == null && str2 == null) ? null : new AccountIdentifiers(str1, str2);
  }
  
  @NonNull
  public String getDeveloperPayload() {
    return this.zzc.optString("developerPayload");
  }
  
  @NonNull
  public String getOrderId() {
    return this.zzc.optString("orderId");
  }
  
  @NonNull
  public String getOriginalJson() {
    return this.zza;
  }
  
  @NonNull
  public String getPackageName() {
    return this.zzc.optString("packageName");
  }
  
  public int getPurchaseState() {
    return (this.zzc.optInt("purchaseState", 1) != 4) ? 1 : 2;
  }
  
  public long getPurchaseTime() {
    return this.zzc.optLong("purchaseTime");
  }
  
  @NonNull
  public String getPurchaseToken() {
    JSONObject jSONObject = this.zzc;
    return jSONObject.optString("token", jSONObject.optString("purchaseToken"));
  }
  
  @NonNull
  public String getSignature() {
    return this.zzb;
  }
  
  @NonNull
  @zzb
  public String getSku() {
    return this.zzc.optString("productId");
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  public boolean isAcknowledged() {
    return this.zzc.optBoolean("acknowledged", true);
  }
  
  public boolean isAutoRenewing() {
    return this.zzc.optBoolean("autoRenewing");
  }
  
  @NonNull
  public String toString() {
    String str = String.valueOf(this.zza);
    return (str.length() != 0) ? "Purchase. Json: ".concat(str) : new String("Purchase. Json: ");
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface PurchaseState {
    public static final int PENDING = 2;
    
    public static final int PURCHASED = 1;
    
    public static final int UNSPECIFIED_STATE = 0;
  }
  
  public static class PurchasesResult {
    @Nullable
    private final List<Purchase> zza;
    
    private final BillingResult zzb;
    
    public PurchasesResult(@NonNull BillingResult param1BillingResult, @Nullable List<Purchase> param1List) {
      this.zza = param1List;
      this.zzb = param1BillingResult;
    }
    
    @NonNull
    public BillingResult getBillingResult() {
      return this.zzb;
    }
    
    @Nullable
    public List<Purchase> getPurchasesList() {
      return this.zza;
    }
    
    public int getResponseCode() {
      return getBillingResult().getResponseCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\Purchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */