package com.android.billingclient.api;

final class zzae implements Runnable {
  zzae(zzah paramzzah, BillingResult paramBillingResult) {}
  
  public final void run() {
    synchronized (zzah.zzb(this.zzb)) {
      if (zzah.zzc(this.zzb) != null)
        zzah.zzc(this.zzb).onBillingSetupFinished(this.zza); 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */