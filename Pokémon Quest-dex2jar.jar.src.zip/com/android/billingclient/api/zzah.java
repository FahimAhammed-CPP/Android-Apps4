package com.android.billingclient.api;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.internal.play_billing.zza;
import com.google.android.gms.internal.play_billing.zzc;

final class zzah implements ServiceConnection {
  private final Object zzb = new Object();
  
  private boolean zzc = false;
  
  private BillingClientStateListener zzd;
  
  private final void zzf(BillingResult paramBillingResult) {
    BillingClientImpl.zze(this.zza, new zzae(this, paramBillingResult));
  }
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    zza.zza("BillingClient", "Billing service connected.");
    BillingClientImpl.zzi(this.zza, zzc.zzo(paramIBinder));
    if (BillingClientImpl.zzw(this.zza, new zzaf(this), 30000L, new zzag(this)) == null)
      zzf(BillingClientImpl.zzx(this.zza)); 
  }
  
  public final void onServiceDisconnected(ComponentName paramComponentName) {
    zza.zzb("BillingClient", "Billing service disconnected.");
    BillingClientImpl.zzi(this.zza, null);
    BillingClientImpl.zzj(this.zza, 0);
    synchronized (this.zzb) {
      BillingClientStateListener billingClientStateListener = this.zzd;
      if (billingClientStateListener != null)
        billingClientStateListener.onBillingServiceDisconnected(); 
      return;
    } 
  }
  
  final void zza() {
    synchronized (this.zzb) {
      this.zzd = null;
      this.zzc = true;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */