package com.android.billingclient.api;

final class zzac implements Runnable {
  zzac(zzad paramzzad, zzap paramzzap) {}
  
  public final void run() {
    SkuDetailsResponseListener skuDetailsResponseListener = this.zzb.zzc;
    BillingResult.Builder builder = BillingResult.newBuilder();
    builder.setResponseCode(this.zza.zzb());
    builder.setDebugMessage(this.zza.zzc());
    skuDetailsResponseListener.onSkuDetailsResponse(builder.build(), this.zza.zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */