package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zza;

final class zzv implements Runnable {
  zzv(BillingClientImpl paramBillingClientImpl, int paramInt, ConsumeResponseListener paramConsumeResponseListener, BillingResult paramBillingResult, String paramString) {}
  
  public final void run() {
    int i = this.zza;
    StringBuilder stringBuilder = new StringBuilder(63);
    stringBuilder.append("Error consuming purchase with token. Response code: ");
    stringBuilder.append(i);
    zza.zzb("BillingClient", stringBuilder.toString());
    this.zzb.onConsumeResponse(this.zzc, this.zzd);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */