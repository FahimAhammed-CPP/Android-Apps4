package com.android.billingclient.api;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.internal.play_billing.zza;
import com.google.android.gms.internal.play_billing.zzd;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

class BillingClientImpl extends BillingClient {
  private int zza = 0;
  
  private final String zzb;
  
  private final Handler zzc = new Handler(Looper.getMainLooper());
  
  private zze zzd;
  
  private Context zze;
  
  private Context zzf;
  
  private zzd zzg;
  
  private zzah zzh;
  
  private boolean zzi;
  
  private boolean zzj;
  
  private int zzk = 0;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private boolean zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private boolean zzt;
  
  private ExecutorService zzu;
  
  private BillingClientImpl(Activity paramActivity, boolean paramBoolean, String paramString) {
    this(paramActivity.getApplicationContext(), paramBoolean, new zzaj(), paramString, null);
  }
  
  private BillingClientImpl(Context paramContext, boolean paramBoolean, PurchasesUpdatedListener paramPurchasesUpdatedListener, String paramString1, String paramString2) {
    this.zzb = paramString1;
    initialize(paramContext, paramPurchasesUpdatedListener, paramBoolean);
  }
  
  private BillingClientImpl(String paramString) {
    this.zzb = paramString;
  }
  
  @UiThread
  BillingClientImpl(@Nullable String paramString, boolean paramBoolean, Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener) {
    this(paramContext, true, paramPurchasesUpdatedListener, str, null);
  }
  
  private void initialize(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, boolean paramBoolean) {
    this.zzf = paramContext.getApplicationContext();
    this.zzd = new zze(this.zzf, paramPurchasesUpdatedListener);
    this.zze = paramContext;
    this.zzt = paramBoolean;
  }
  
  private int launchBillingFlowCpp(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    return launchBillingFlow(paramActivity, paramBillingFlowParams).getResponseCode();
  }
  
  private void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, long paramLong) {
    launchPriceChangeConfirmationFlow(paramActivity, paramPriceChangeFlowParams, new zzaj(paramLong));
  }
  
  private void startConnection(long paramLong) {
    zzaj zzaj = new zzaj(paramLong);
    if (isReady()) {
      zza.zza("BillingClient", "Service connection is valid. No need to re-initialize.");
      zzaj.onBillingSetupFinished(zzam.zzp);
      return;
    } 
    int i = this.zza;
    if (i == 1) {
      zza.zzb("BillingClient", "Client is already in the process of connecting to billing service.");
      zzaj.onBillingSetupFinished(zzam.zzd);
      return;
    } 
    if (i == 3) {
      zza.zzb("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      zzaj.onBillingSetupFinished(zzam.zzq);
      return;
    } 
    this.zza = 1;
    this.zzd.zza();
    zza.zza("BillingClient", "Starting in-app billing setup.");
    this.zzh = new zzah(this, zzaj, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List<ResolveInfo> list = this.zzf.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zzf.bindService(intent, this.zzh, 1)) {
            zza.zza("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zza.zzb("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zza.zzb("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zza.zza("BillingClient", "Billing service unavailable on device.");
    zzaj.onBillingSetupFinished(zzam.zzc);
  }
  
  private final BillingResult zzA(String paramString) {
    Future<?> future = zzz(new zzt(this, paramString), 5000L, null);
    try {
      return (((Integer)future.get(5000L, TimeUnit.MILLISECONDS)).intValue() == 0) ? zzam.zzp : zzam.zzi;
    } catch (Exception exception) {
      zza.zzb("BillingClient", "Exception while checking if billing is supported; try to reconnect");
      return zzam.zzq;
    } 
  }
  
  private final void zzB(Runnable paramRunnable) {
    if (Thread.interrupted())
      return; 
    this.zzc.post(paramRunnable);
  }
  
  private final BillingResult zzC() {
    int i = this.zza;
    return (i == 0 || i == 3) ? zzam.zzq : zzam.zzl;
  }
  
  private final BillingResult zzy(BillingResult paramBillingResult) {
    this.zzd.zzb().onPurchasesUpdated(paramBillingResult, null);
    return paramBillingResult;
  }
  
  @Nullable
  private final <T> Future<T> zzz(Callable<T> paramCallable, long paramLong, @Nullable Runnable paramRunnable) {
    double d = paramLong;
    Double.isNaN(d);
    paramLong = (long)(d * 0.95D);
    if (this.zzu == null)
      this.zzu = Executors.newFixedThreadPool(zza.zza, new zzq(this)); 
    try {
      Future<T> future = this.zzu.submit(paramCallable);
      this.zzc.postDelayed(new zzr(this, future, paramRunnable), paramLong);
      return future;
    } catch (Exception exception) {
      String str = String.valueOf(exception);
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 28);
      stringBuilder.append("Async task throws exception ");
      stringBuilder.append(str);
      zza.zzb("BillingClient", stringBuilder.toString());
      return null;
    } 
  }
  
  public final void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener) {
    if (!isReady()) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzam.zzq);
      return;
    } 
    if (TextUtils.isEmpty(paramAcknowledgePurchaseParams.getPurchaseToken())) {
      zza.zzb("BillingClient", "Please provide a valid purchase token.");
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzam.zzk);
      return;
    } 
    if (!this.zzn) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzam.zzb);
      return;
    } 
    if (zzz(new zzo(this, paramAcknowledgePurchaseParams, paramAcknowledgePurchaseResponseListener), 30000L, new zzp(this, paramAcknowledgePurchaseResponseListener)) == null)
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzC()); 
  }
  
  public final void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener) {
    if (!isReady()) {
      paramConsumeResponseListener.onConsumeResponse(zzam.zzq, paramConsumeParams.getPurchaseToken());
      return;
    } 
    if (zzz(new zzh(this, paramConsumeParams, paramConsumeResponseListener), 30000L, new zzi(this, paramConsumeResponseListener, paramConsumeParams)) == null)
      paramConsumeResponseListener.onConsumeResponse(zzC(), paramConsumeParams.getPurchaseToken()); 
  }
  
  public final void endConnection() {
    Exception exception;
    try {
      this.zze = null;
      this.zzd.zzc();
      zzah zzah1 = this.zzh;
      if (zzah1 != null)
        zzah1.zza(); 
      if (this.zzh != null && this.zzg != null) {
        zza.zza("BillingClient", "Unbinding from service.");
        this.zzf.unbindService(this.zzh);
        this.zzh = null;
      } 
      this.zzg = null;
      ExecutorService executorService = this.zzu;
      if (executorService != null) {
        executorService.shutdownNow();
        this.zzu = null;
      } 
      this.zza = 3;
      return;
    } catch (Exception exception1) {
      String str = String.valueOf(exception1);
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 48);
      stringBuilder.append("There was an exception while ending connection: ");
      stringBuilder.append(str);
      zza.zzb("BillingClient", stringBuilder.toString());
      this.zza = 3;
      return;
    } finally {}
    this.zza = 3;
    throw exception;
  }
  
  public final BillingResult isFeatureSupported(String paramString) {
    byte b;
    if (!isReady())
      return zzam.zzq; 
    switch (paramString.hashCode()) {
      default:
        b = -1;
        break;
      case 1987365622:
        if (paramString.equals("subscriptions")) {
          b = 0;
          break;
        } 
      case 1219490065:
        if (paramString.equals("subscriptionsOnVr")) {
          b = 3;
          break;
        } 
      case 292218239:
        if (paramString.equals("inAppItemsOnVr")) {
          b = 2;
          break;
        } 
      case 207616302:
        if (paramString.equals("priceChangeConfirmation")) {
          b = 4;
          break;
        } 
      case 100293:
        if (paramString.equals("eee")) {
          b = 9;
          break;
        } 
      case 99300:
        if (paramString.equals("ddd")) {
          b = 7;
          break;
        } 
      case 98307:
        if (paramString.equals("ccc")) {
          b = 8;
          break;
        } 
      case 97314:
        if (paramString.equals("bbb")) {
          b = 5;
          break;
        } 
      case 96321:
        if (paramString.equals("aaa")) {
          b = 6;
          break;
        } 
      case -422092961:
        if (paramString.equals("subscriptionsUpdate")) {
          b = 1;
          break;
        } 
    } 
    switch (b) {
      default:
        paramString = String.valueOf(paramString);
        if (paramString.length() != 0) {
          paramString = "Unsupported feature: ".concat(paramString);
          zza.zzb("BillingClient", paramString);
          return zzam.zzv;
        } 
        break;
      case 8:
      case 9:
        return this.zzs ? zzam.zzp : zzam.zzi;
      case 7:
        return this.zzq ? zzam.zzp : zzam.zzi;
      case 6:
        return this.zzr ? zzam.zzp : zzam.zzi;
      case 5:
        return this.zzp ? zzam.zzp : zzam.zzi;
      case 4:
        return this.zzm ? zzam.zzp : zzam.zzi;
      case 3:
        return zzA("subs");
      case 2:
        return zzA("inapp");
      case 1:
        return this.zzj ? zzam.zzp : zzam.zzi;
      case 0:
        return this.zzi ? zzam.zzp : zzam.zzi;
    } 
    paramString = new String("Unsupported feature: ");
    zza.zzb("BillingClient", paramString);
    return zzam.zzv;
  }
  
  public final boolean isReady() {
    return (this.zza == 2 && this.zzg != null && this.zzh != null);
  }
  
  public final BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    // Byte code:
    //   0: ldc_w 'BUY_INTENT'
    //   3: astore #12
    //   5: aload_0
    //   6: invokevirtual isReady : ()Z
    //   9: ifne -> 24
    //   12: getstatic com/android/billingclient/api/zzam.zzq : Lcom/android/billingclient/api/BillingResult;
    //   15: astore_1
    //   16: aload_0
    //   17: aload_1
    //   18: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   21: pop
    //   22: aload_1
    //   23: areturn
    //   24: aload_2
    //   25: invokevirtual zza : ()Ljava/util/ArrayList;
    //   28: astore #16
    //   30: aload #16
    //   32: iconst_0
    //   33: invokevirtual get : (I)Ljava/lang/Object;
    //   36: checkcast com/android/billingclient/api/SkuDetails
    //   39: astore #14
    //   41: aload #14
    //   43: invokevirtual getType : ()Ljava/lang/String;
    //   46: astore #15
    //   48: aload #15
    //   50: ldc_w 'subs'
    //   53: invokevirtual equals : (Ljava/lang/Object;)Z
    //   56: ifeq -> 89
    //   59: aload_0
    //   60: getfield zzi : Z
    //   63: ifeq -> 69
    //   66: goto -> 89
    //   69: ldc 'BillingClient'
    //   71: ldc_w 'Current client doesn't support subscriptions.'
    //   74: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   77: getstatic com/android/billingclient/api/zzam.zzs : Lcom/android/billingclient/api/BillingResult;
    //   80: astore_1
    //   81: aload_0
    //   82: aload_1
    //   83: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   86: pop
    //   87: aload_1
    //   88: areturn
    //   89: aload_2
    //   90: invokevirtual getOldSku : ()Ljava/lang/String;
    //   93: astore #17
    //   95: aload #17
    //   97: ifnull -> 130
    //   100: aload_0
    //   101: getfield zzj : Z
    //   104: ifeq -> 110
    //   107: goto -> 130
    //   110: ldc 'BillingClient'
    //   112: ldc_w 'Current client doesn't support subscriptions update.'
    //   115: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   118: getstatic com/android/billingclient/api/zzam.zzt : Lcom/android/billingclient/api/BillingResult;
    //   121: astore_1
    //   122: aload_0
    //   123: aload_1
    //   124: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   127: pop
    //   128: aload_1
    //   129: areturn
    //   130: aload_2
    //   131: invokevirtual zzc : ()Z
    //   134: ifeq -> 167
    //   137: aload_0
    //   138: getfield zzl : Z
    //   141: ifeq -> 147
    //   144: goto -> 167
    //   147: ldc 'BillingClient'
    //   149: ldc_w 'Current client doesn't support extra params for buy intent.'
    //   152: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   155: getstatic com/android/billingclient/api/zzam.zzh : Lcom/android/billingclient/api/BillingResult;
    //   158: astore_1
    //   159: aload_0
    //   160: aload_1
    //   161: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   164: pop
    //   165: aload_1
    //   166: areturn
    //   167: aload #16
    //   169: invokevirtual size : ()I
    //   172: iconst_1
    //   173: if_icmple -> 206
    //   176: aload_0
    //   177: getfield zzs : Z
    //   180: ifeq -> 186
    //   183: goto -> 206
    //   186: ldc 'BillingClient'
    //   188: ldc_w 'Current client doesn't support multi-item purchases.'
    //   191: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   194: getstatic com/android/billingclient/api/zzam.zzu : Lcom/android/billingclient/api/BillingResult;
    //   197: astore_1
    //   198: aload_0
    //   199: aload_1
    //   200: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   203: pop
    //   204: aload_1
    //   205: areturn
    //   206: ldc_w ''
    //   209: astore #11
    //   211: ldc_w ''
    //   214: astore #10
    //   216: iconst_0
    //   217: istore_3
    //   218: iload_3
    //   219: aload #16
    //   221: invokevirtual size : ()I
    //   224: if_icmpge -> 329
    //   227: aload #10
    //   229: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   232: astore #10
    //   234: aload #16
    //   236: iload_3
    //   237: invokevirtual get : (I)Ljava/lang/Object;
    //   240: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   243: astore #13
    //   245: new java/lang/StringBuilder
    //   248: dup
    //   249: aload #10
    //   251: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   254: invokevirtual length : ()I
    //   257: aload #13
    //   259: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   262: invokevirtual length : ()I
    //   265: iadd
    //   266: invokespecial <init> : (I)V
    //   269: astore #18
    //   271: aload #18
    //   273: aload #10
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: aload #18
    //   281: aload #13
    //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: pop
    //   287: aload #18
    //   289: invokevirtual toString : ()Ljava/lang/String;
    //   292: astore #13
    //   294: aload #13
    //   296: astore #10
    //   298: iload_3
    //   299: aload #16
    //   301: invokevirtual size : ()I
    //   304: iconst_1
    //   305: isub
    //   306: if_icmpge -> 322
    //   309: aload #13
    //   311: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   314: ldc_w ', '
    //   317: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   320: astore #10
    //   322: iload_3
    //   323: iconst_1
    //   324: iadd
    //   325: istore_3
    //   326: goto -> 218
    //   329: new java/lang/StringBuilder
    //   332: dup
    //   333: aload #10
    //   335: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   338: invokevirtual length : ()I
    //   341: bipush #41
    //   343: iadd
    //   344: aload #15
    //   346: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   349: invokevirtual length : ()I
    //   352: iadd
    //   353: invokespecial <init> : (I)V
    //   356: astore #13
    //   358: aload #13
    //   360: ldc_w 'Constructing buy intent for '
    //   363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   366: pop
    //   367: aload #13
    //   369: aload #10
    //   371: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: pop
    //   375: aload #13
    //   377: ldc_w ', item type: '
    //   380: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   383: pop
    //   384: aload #13
    //   386: aload #15
    //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: ldc 'BillingClient'
    //   394: aload #13
    //   396: invokevirtual toString : ()Ljava/lang/String;
    //   399: invokestatic zza : (Ljava/lang/String;Ljava/lang/String;)V
    //   402: aload_0
    //   403: getfield zzl : Z
    //   406: ifeq -> 1060
    //   409: aload_2
    //   410: aload_0
    //   411: getfield zzn : Z
    //   414: aload_0
    //   415: getfield zzt : Z
    //   418: aload_0
    //   419: getfield zzb : Ljava/lang/String;
    //   422: invokestatic zzg : (Lcom/android/billingclient/api/BillingFlowParams;ZZLjava/lang/String;)Landroid/os/Bundle;
    //   425: astore #17
    //   427: new java/util/ArrayList
    //   430: dup
    //   431: invokespecial <init> : ()V
    //   434: astore #18
    //   436: new java/util/ArrayList
    //   439: dup
    //   440: invokespecial <init> : ()V
    //   443: astore #19
    //   445: new java/util/ArrayList
    //   448: dup
    //   449: invokespecial <init> : ()V
    //   452: astore #20
    //   454: new java/util/ArrayList
    //   457: dup
    //   458: invokespecial <init> : ()V
    //   461: astore #21
    //   463: aload #16
    //   465: invokeinterface size : ()I
    //   470: istore #4
    //   472: iconst_0
    //   473: istore #5
    //   475: iconst_0
    //   476: istore #7
    //   478: iconst_0
    //   479: istore #6
    //   481: iconst_0
    //   482: istore_3
    //   483: iload #5
    //   485: iload #4
    //   487: if_icmpge -> 657
    //   490: aload #16
    //   492: iload #5
    //   494: invokeinterface get : (I)Ljava/lang/Object;
    //   499: checkcast com/android/billingclient/api/SkuDetails
    //   502: astore #22
    //   504: aload #22
    //   506: invokevirtual zzb : ()Ljava/lang/String;
    //   509: invokevirtual isEmpty : ()Z
    //   512: ifne -> 529
    //   515: aload #18
    //   517: aload #22
    //   519: invokevirtual zzb : ()Ljava/lang/String;
    //   522: invokevirtual add : (Ljava/lang/Object;)Z
    //   525: pop
    //   526: goto -> 529
    //   529: aload #22
    //   531: invokevirtual getOriginalJson : ()Ljava/lang/String;
    //   534: astore #13
    //   536: new org/json/JSONObject
    //   539: dup
    //   540: aload #13
    //   542: invokespecial <init> : (Ljava/lang/String;)V
    //   545: ldc_w 'offer_id_token'
    //   548: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   551: astore #13
    //   553: goto -> 560
    //   556: aload #11
    //   558: astore #13
    //   560: aload #22
    //   562: invokevirtual zzc : ()Ljava/lang/String;
    //   565: astore #23
    //   567: aload #22
    //   569: invokevirtual zzd : ()I
    //   572: istore #9
    //   574: aload #19
    //   576: aload #13
    //   578: invokevirtual add : (Ljava/lang/Object;)Z
    //   581: pop
    //   582: iload #7
    //   584: aload #13
    //   586: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   589: iconst_1
    //   590: ixor
    //   591: ior
    //   592: istore #7
    //   594: aload #20
    //   596: aload #23
    //   598: invokevirtual add : (Ljava/lang/Object;)Z
    //   601: pop
    //   602: iload #6
    //   604: aload #23
    //   606: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   609: iconst_1
    //   610: ixor
    //   611: ior
    //   612: istore #8
    //   614: aload #21
    //   616: iload #9
    //   618: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   621: invokevirtual add : (Ljava/lang/Object;)Z
    //   624: pop
    //   625: iload #9
    //   627: ifeq -> 636
    //   630: iconst_1
    //   631: istore #6
    //   633: goto -> 639
    //   636: iconst_0
    //   637: istore #6
    //   639: iload_3
    //   640: iload #6
    //   642: ior
    //   643: istore_3
    //   644: iload #5
    //   646: iconst_1
    //   647: iadd
    //   648: istore #5
    //   650: iload #8
    //   652: istore #6
    //   654: goto -> 483
    //   657: aload #18
    //   659: invokevirtual isEmpty : ()Z
    //   662: ifne -> 675
    //   665: aload #17
    //   667: ldc_w 'skuDetailsTokens'
    //   670: aload #18
    //   672: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   675: iload #7
    //   677: ifeq -> 709
    //   680: aload_0
    //   681: getfield zzq : Z
    //   684: ifne -> 699
    //   687: getstatic com/android/billingclient/api/zzam.zzi : Lcom/android/billingclient/api/BillingResult;
    //   690: astore_1
    //   691: aload_0
    //   692: aload_1
    //   693: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   696: pop
    //   697: aload_1
    //   698: areturn
    //   699: aload #17
    //   701: ldc_w 'SKU_OFFER_ID_TOKEN_LIST'
    //   704: aload #19
    //   706: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   709: iload #6
    //   711: ifeq -> 724
    //   714: aload #17
    //   716: ldc_w 'SKU_OFFER_ID_LIST'
    //   719: aload #20
    //   721: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   724: iload_3
    //   725: ifeq -> 738
    //   728: aload #17
    //   730: ldc_w 'SKU_OFFER_TYPE_LIST'
    //   733: aload #21
    //   735: invokevirtual putIntegerArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   738: aload #14
    //   740: invokevirtual zza : ()Ljava/lang/String;
    //   743: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   746: ifne -> 767
    //   749: aload #17
    //   751: ldc_w 'skuPackageName'
    //   754: aload #14
    //   756: invokevirtual zza : ()Ljava/lang/String;
    //   759: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   762: iconst_1
    //   763: istore_3
    //   764: goto -> 769
    //   767: iconst_0
    //   768: istore_3
    //   769: aconst_null
    //   770: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   773: ifne -> 785
    //   776: aload #17
    //   778: ldc_w 'accountName'
    //   781: aconst_null
    //   782: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   785: aload #16
    //   787: invokevirtual size : ()I
    //   790: istore #5
    //   792: iconst_1
    //   793: istore #4
    //   795: iload #5
    //   797: iconst_1
    //   798: if_icmple -> 910
    //   801: new java/util/ArrayList
    //   804: dup
    //   805: aload #16
    //   807: invokevirtual size : ()I
    //   810: iconst_1
    //   811: isub
    //   812: invokespecial <init> : (I)V
    //   815: astore #11
    //   817: new java/util/ArrayList
    //   820: dup
    //   821: aload #16
    //   823: invokevirtual size : ()I
    //   826: iconst_1
    //   827: isub
    //   828: invokespecial <init> : (I)V
    //   831: astore #13
    //   833: iload #4
    //   835: aload #16
    //   837: invokevirtual size : ()I
    //   840: if_icmpge -> 890
    //   843: aload #11
    //   845: aload #16
    //   847: iload #4
    //   849: invokevirtual get : (I)Ljava/lang/Object;
    //   852: checkcast com/android/billingclient/api/SkuDetails
    //   855: invokevirtual getSku : ()Ljava/lang/String;
    //   858: invokevirtual add : (Ljava/lang/Object;)Z
    //   861: pop
    //   862: aload #13
    //   864: aload #16
    //   866: iload #4
    //   868: invokevirtual get : (I)Ljava/lang/Object;
    //   871: checkcast com/android/billingclient/api/SkuDetails
    //   874: invokevirtual getType : ()Ljava/lang/String;
    //   877: invokevirtual add : (Ljava/lang/Object;)Z
    //   880: pop
    //   881: iload #4
    //   883: iconst_1
    //   884: iadd
    //   885: istore #4
    //   887: goto -> 833
    //   890: aload #17
    //   892: ldc_w 'additionalSkus'
    //   895: aload #11
    //   897: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   900: aload #17
    //   902: ldc_w 'additionalSkuTypes'
    //   905: aload #13
    //   907: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   910: aload_1
    //   911: invokevirtual getIntent : ()Landroid/content/Intent;
    //   914: ldc_w 'PROXY_PACKAGE'
    //   917: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   920: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   923: ifne -> 986
    //   926: aload_1
    //   927: invokevirtual getIntent : ()Landroid/content/Intent;
    //   930: ldc_w 'PROXY_PACKAGE'
    //   933: invokevirtual getStringExtra : (Ljava/lang/String;)Ljava/lang/String;
    //   936: astore #11
    //   938: aload #17
    //   940: ldc_w 'proxyPackage'
    //   943: aload #11
    //   945: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   948: aload #17
    //   950: ldc_w 'proxyPackageVersion'
    //   953: aload_0
    //   954: getfield zzf : Landroid/content/Context;
    //   957: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   960: aload #11
    //   962: iconst_0
    //   963: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   966: getfield versionName : Ljava/lang/String;
    //   969: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   972: goto -> 986
    //   975: aload #17
    //   977: ldc_w 'proxyPackageVersion'
    //   980: ldc_w 'package not found'
    //   983: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   986: aload_0
    //   987: getfield zzr : Z
    //   990: ifeq -> 1003
    //   993: iload_3
    //   994: ifeq -> 1003
    //   997: bipush #15
    //   999: istore_3
    //   1000: goto -> 1032
    //   1003: aload_0
    //   1004: getfield zzn : Z
    //   1007: ifeq -> 1016
    //   1010: bipush #9
    //   1012: istore_3
    //   1013: goto -> 1032
    //   1016: aload_2
    //   1017: invokevirtual getVrPurchaseFlow : ()Z
    //   1020: ifeq -> 1029
    //   1023: bipush #7
    //   1025: istore_3
    //   1026: goto -> 1032
    //   1029: bipush #6
    //   1031: istore_3
    //   1032: aload_0
    //   1033: new com/android/billingclient/api/zzy
    //   1036: dup
    //   1037: aload_0
    //   1038: iload_3
    //   1039: aload #14
    //   1041: aload #15
    //   1043: aload_2
    //   1044: aload #17
    //   1046: invokespecial <init> : (Lcom/android/billingclient/api/BillingClientImpl;ILcom/android/billingclient/api/SkuDetails;Ljava/lang/String;Lcom/android/billingclient/api/BillingFlowParams;Landroid/os/Bundle;)V
    //   1049: ldc2_w 5000
    //   1052: aconst_null
    //   1053: invokespecial zzz : (Ljava/util/concurrent/Callable;JLjava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   1056: astore_2
    //   1057: goto -> 1114
    //   1060: ldc_w 'BUY_INTENT'
    //   1063: astore #12
    //   1065: aload #17
    //   1067: ifnull -> 1093
    //   1070: aload_0
    //   1071: new com/android/billingclient/api/zzz
    //   1074: dup
    //   1075: aload_0
    //   1076: aload_2
    //   1077: aload #14
    //   1079: invokespecial <init> : (Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/billingclient/api/BillingFlowParams;Lcom/android/billingclient/api/SkuDetails;)V
    //   1082: ldc2_w 5000
    //   1085: aconst_null
    //   1086: invokespecial zzz : (Ljava/util/concurrent/Callable;JLjava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   1089: astore_2
    //   1090: goto -> 1114
    //   1093: aload_0
    //   1094: new com/android/billingclient/api/zzaa
    //   1097: dup
    //   1098: aload_0
    //   1099: aload #14
    //   1101: aload #15
    //   1103: invokespecial <init> : (Lcom/android/billingclient/api/BillingClientImpl;Lcom/android/billingclient/api/SkuDetails;Ljava/lang/String;)V
    //   1106: ldc2_w 5000
    //   1109: aconst_null
    //   1110: invokespecial zzz : (Ljava/util/concurrent/Callable;JLjava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   1113: astore_2
    //   1114: aload_2
    //   1115: ldc2_w 5000
    //   1118: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   1121: invokeinterface get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   1126: checkcast android/os/Bundle
    //   1129: astore #11
    //   1131: aload #11
    //   1133: ldc 'BillingClient'
    //   1135: invokestatic zzd : (Landroid/os/Bundle;Ljava/lang/String;)I
    //   1138: istore_3
    //   1139: aload #11
    //   1141: ldc 'BillingClient'
    //   1143: invokestatic zze : (Landroid/os/Bundle;Ljava/lang/String;)Ljava/lang/String;
    //   1146: astore_2
    //   1147: iload_3
    //   1148: ifeq -> 1213
    //   1151: new java/lang/StringBuilder
    //   1154: dup
    //   1155: bipush #52
    //   1157: invokespecial <init> : (I)V
    //   1160: astore_1
    //   1161: aload_1
    //   1162: ldc_w 'Unable to buy item, Error response code: '
    //   1165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1168: pop
    //   1169: aload_1
    //   1170: iload_3
    //   1171: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1174: pop
    //   1175: ldc 'BillingClient'
    //   1177: aload_1
    //   1178: invokevirtual toString : ()Ljava/lang/String;
    //   1181: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   1184: invokestatic newBuilder : ()Lcom/android/billingclient/api/BillingResult$Builder;
    //   1187: astore_1
    //   1188: aload_1
    //   1189: iload_3
    //   1190: invokevirtual setResponseCode : (I)Lcom/android/billingclient/api/BillingResult$Builder;
    //   1193: pop
    //   1194: aload_1
    //   1195: aload_2
    //   1196: invokevirtual setDebugMessage : (Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult$Builder;
    //   1199: pop
    //   1200: aload_1
    //   1201: invokevirtual build : ()Lcom/android/billingclient/api/BillingResult;
    //   1204: astore_1
    //   1205: aload_0
    //   1206: aload_1
    //   1207: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   1210: pop
    //   1211: aload_1
    //   1212: areturn
    //   1213: new android/content/Intent
    //   1216: dup
    //   1217: aload_1
    //   1218: ldc_w com/android/billingclient/api/ProxyBillingActivity
    //   1221: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   1224: astore_2
    //   1225: aload_2
    //   1226: aload #12
    //   1228: aload #11
    //   1230: aload #12
    //   1232: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   1235: checkcast android/app/PendingIntent
    //   1238: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   1241: pop
    //   1242: aload_1
    //   1243: aload_2
    //   1244: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   1247: getstatic com/android/billingclient/api/zzam.zzp : Lcom/android/billingclient/api/BillingResult;
    //   1250: areturn
    //   1251: new java/lang/StringBuilder
    //   1254: dup
    //   1255: aload #10
    //   1257: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   1260: invokevirtual length : ()I
    //   1263: bipush #69
    //   1265: iadd
    //   1266: invokespecial <init> : (I)V
    //   1269: astore_1
    //   1270: aload_1
    //   1271: ldc_w 'Exception while launching billing flow: ; for sku: '
    //   1274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1277: pop
    //   1278: aload_1
    //   1279: aload #10
    //   1281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1284: pop
    //   1285: aload_1
    //   1286: ldc_w '; try to reconnect'
    //   1289: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1292: pop
    //   1293: ldc 'BillingClient'
    //   1295: aload_1
    //   1296: invokevirtual toString : ()Ljava/lang/String;
    //   1299: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   1302: getstatic com/android/billingclient/api/zzam.zzq : Lcom/android/billingclient/api/BillingResult;
    //   1305: astore_1
    //   1306: aload_0
    //   1307: aload_1
    //   1308: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   1311: pop
    //   1312: aload_1
    //   1313: areturn
    //   1314: new java/lang/StringBuilder
    //   1317: dup
    //   1318: aload #10
    //   1320: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   1323: invokevirtual length : ()I
    //   1326: bipush #68
    //   1328: iadd
    //   1329: invokespecial <init> : (I)V
    //   1332: astore_1
    //   1333: aload_1
    //   1334: ldc_w 'Time out while launching billing flow: ; for sku: '
    //   1337: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1340: pop
    //   1341: aload_1
    //   1342: aload #10
    //   1344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1347: pop
    //   1348: aload_1
    //   1349: ldc_w '; try to reconnect'
    //   1352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1355: pop
    //   1356: ldc 'BillingClient'
    //   1358: aload_1
    //   1359: invokevirtual toString : ()Ljava/lang/String;
    //   1362: invokestatic zzb : (Ljava/lang/String;Ljava/lang/String;)V
    //   1365: getstatic com/android/billingclient/api/zzam.zzr : Lcom/android/billingclient/api/BillingResult;
    //   1368: astore_1
    //   1369: aload_0
    //   1370: aload_1
    //   1371: invokespecial zzy : (Lcom/android/billingclient/api/BillingResult;)Lcom/android/billingclient/api/BillingResult;
    //   1374: pop
    //   1375: aload_1
    //   1376: areturn
    //   1377: astore #13
    //   1379: goto -> 556
    //   1382: astore #11
    //   1384: goto -> 975
    //   1387: astore_1
    //   1388: goto -> 1314
    //   1391: astore_1
    //   1392: goto -> 1251
    // Exception table:
    //   from	to	target	type
    //   536	553	1377	org/json/JSONException
    //   948	972	1382	android/content/pm/PackageManager$NameNotFoundException
    //   1114	1147	1387	java/util/concurrent/TimeoutException
    //   1114	1147	1387	java/util/concurrent/CancellationException
    //   1114	1147	1391	java/lang/Exception
    //   1151	1211	1387	java/util/concurrent/TimeoutException
    //   1151	1211	1387	java/util/concurrent/CancellationException
    //   1151	1211	1391	java/lang/Exception
    //   1213	1247	1387	java/util/concurrent/TimeoutException
    //   1213	1247	1387	java/util/concurrent/CancellationException
    //   1213	1247	1391	java/lang/Exception
  }
  
  public final void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (!isReady()) {
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzq);
      return;
    } 
    if (paramPriceChangeFlowParams == null || paramPriceChangeFlowParams.getSkuDetails() == null) {
      zza.zzb("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzn);
      return;
    } 
    String str = paramPriceChangeFlowParams.getSkuDetails().getSku();
    if (str == null) {
      zza.zzb("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzn);
      return;
    } 
    if (!this.zzm) {
      zza.zzb("BillingClient", "Current client doesn't support price change confirmation flow.");
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzi);
      return;
    } 
    Bundle bundle = new Bundle();
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putBoolean("subs_price_change", true);
    Future<?> future = zzz(new zzs(this, str, bundle), 5000L, null);
    try {
      zzx zzx;
      Bundle bundle1 = (Bundle)future.get(5000L, TimeUnit.MILLISECONDS);
      int i = zza.zzd(bundle1, "BillingClient");
      String str1 = zza.zze(bundle1, "BillingClient");
      BillingResult.Builder builder = BillingResult.newBuilder();
      builder.setResponseCode(i);
      builder.setDebugMessage(str1);
      BillingResult billingResult = builder.build();
      if (i == 0) {
        zzx = new zzx(this, this.zzc, paramPriceChangeConfirmationListener);
        Intent intent = new Intent((Context)paramActivity, ProxyBillingActivity.class);
        intent.putExtra("SUBS_MANAGEMENT_INTENT", bundle1.getParcelable("SUBS_MANAGEMENT_INTENT"));
        intent.putExtra("result_receiver", (Parcelable)zzx);
        paramActivity.startActivity(intent);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder(68);
      stringBuilder.append("Unable to launch price change flow, error response code: ");
      stringBuilder.append(i);
      zza.zzb("BillingClient", stringBuilder.toString());
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult((BillingResult)zzx);
      return;
    } catch (TimeoutException|java.util.concurrent.CancellationException timeoutException) {
      StringBuilder stringBuilder = new StringBuilder(str.length() + 70);
      stringBuilder.append("Time out while launching Price Change Flow for sku: ");
      stringBuilder.append(str);
      stringBuilder.append("; try to reconnect");
      zza.zzb("BillingClient", stringBuilder.toString());
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzr);
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder(str.length() + 78);
      stringBuilder.append("Exception caught while launching Price Change Flow for sku: ");
      stringBuilder.append(str);
      stringBuilder.append("; try to reconnect");
      zza.zzb("BillingClient", stringBuilder.toString());
      paramPriceChangeConfirmationListener.onPriceChangeConfirmationResult(zzam.zzq);
      return;
    } 
  }
  
  public final void queryPurchaseHistoryAsync(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    if (!isReady()) {
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzam.zzq, null);
      return;
    } 
    if (zzz(new zzk(this, paramString, paramPurchaseHistoryResponseListener), 30000L, new zzl(this, paramPurchaseHistoryResponseListener)) == null)
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzC(), null); 
  }
  
  public final Purchase.PurchasesResult queryPurchases(String paramString) {
    if (!isReady())
      return new Purchase.PurchasesResult(zzam.zzq, null); 
    if (TextUtils.isEmpty(paramString)) {
      zza.zzb("BillingClient", "Please provide a valid SKU type.");
      return new Purchase.PurchasesResult(zzam.zzg, null);
    } 
    Future<?> future = zzz(new zzab(this, paramString), 5000L, null);
    try {
      return (Purchase.PurchasesResult)future.get(5000L, TimeUnit.MILLISECONDS);
    } catch (TimeoutException|java.util.concurrent.CancellationException timeoutException) {
      return new Purchase.PurchasesResult(zzam.zzr, null);
    } catch (Exception exception) {
      return new Purchase.PurchasesResult(zzam.zzl, null);
    } 
  }
  
  public final void querySkuDetailsAsync(SkuDetailsParams paramSkuDetailsParams, SkuDetailsResponseListener paramSkuDetailsResponseListener) {
    if (!isReady()) {
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzam.zzq, null);
      return;
    } 
    String str = paramSkuDetailsParams.getSkuType();
    List<String> list = paramSkuDetailsParams.getSkusList();
    if (TextUtils.isEmpty(str)) {
      zza.zzb("BillingClient", "Please fix the input params. SKU type can't be empty.");
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzam.zzg, null);
      return;
    } 
    if (list != null) {
      ArrayList<zzat> arrayList = new ArrayList();
      for (String str1 : list) {
        zzas zzas = new zzas(null);
        zzas.zza(str1);
        arrayList.add(zzas.zzb());
      } 
      if (zzz(new zzad(this, str, arrayList, null, paramSkuDetailsResponseListener), 30000L, new zzg(this, paramSkuDetailsResponseListener)) == null)
        paramSkuDetailsResponseListener.onSkuDetailsResponse(zzC(), null); 
      return;
    } 
    zza.zzb("BillingClient", "Please fix the input params. The list of SKUs can't be empty - set SKU list or SkuWithOffer list.");
    paramSkuDetailsResponseListener.onSkuDetailsResponse(zzam.zzf, null);
  }
  
  public final void startConnection(BillingClientStateListener paramBillingClientStateListener) {
    if (isReady()) {
      zza.zza("BillingClient", "Service connection is valid. No need to re-initialize.");
      paramBillingClientStateListener.onBillingSetupFinished(zzam.zzp);
      return;
    } 
    int i = this.zza;
    if (i == 1) {
      zza.zzb("BillingClient", "Client is already in the process of connecting to billing service.");
      paramBillingClientStateListener.onBillingSetupFinished(zzam.zzd);
      return;
    } 
    if (i == 3) {
      zza.zzb("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      paramBillingClientStateListener.onBillingSetupFinished(zzam.zzq);
      return;
    } 
    this.zza = 1;
    this.zzd.zza();
    zza.zza("BillingClient", "Starting in-app billing setup.");
    this.zzh = new zzah(this, paramBillingClientStateListener, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List<ResolveInfo> list = this.zzf.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zzf.bindService(intent, this.zzh, 1)) {
            zza.zza("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zza.zzb("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zza.zzb("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zza.zza("BillingClient", "Billing service unavailable on device.");
    paramBillingClientStateListener.onBillingSetupFinished(zzam.zzc);
  }
  
  @VisibleForTesting
  final zzap zza(String paramString1, List<zzat> paramList, @Nullable String paramString2) {
    ArrayList<SkuDetails> arrayList = new ArrayList();
    int j = paramList.size();
    int i = 0;
    label44: while (true) {
      if (i < j) {
        int k = i + 20;
        if (k > j) {
          m = j;
        } else {
          m = k;
        } 
        ArrayList<zzat> arrayList1 = new ArrayList(paramList.subList(i, m));
        ArrayList<String> arrayList2 = new ArrayList();
        int m = arrayList1.size();
        for (i = 0; i < m; i++)
          arrayList2.add(((zzat)arrayList1.get(i)).zza()); 
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("ITEM_ID_LIST", arrayList2);
        bundle.putString("playBillingLibraryVersion", this.zzb);
        try {
          Bundle bundle1;
          if (this.zzo) {
            bundle1 = this.zzg.zzm(10, this.zzf.getPackageName(), paramString1, bundle, zza.zzi(this.zzk, this.zzt, this.zzb, null, arrayList1));
          } else {
            bundle1 = this.zzg.zzb(3, this.zzf.getPackageName(), paramString1, bundle);
          } 
          if (bundle1 == null) {
            zza.zzb("BillingClient", "querySkuDetailsAsync got null sku details list");
            return new zzap(4, "Item is unavailable for purchase.", null);
          } 
          if (!bundle1.containsKey("DETAILS_LIST")) {
            k = zza.zzd(bundle1, "BillingClient");
            paramString1 = zza.zze(bundle1, "BillingClient");
            if (k != 0) {
              StringBuilder stringBuilder = new StringBuilder(50);
              stringBuilder.append("getSkuDetails() failed. Response code: ");
              stringBuilder.append(k);
              zza.zzb("BillingClient", stringBuilder.toString());
              return new zzap(k, paramString1, arrayList);
            } 
            zza.zzb("BillingClient", "getSkuDetails() returned a bundle with neither an error nor a detail list.");
            return new zzap(6, paramString1, arrayList);
          } 
          ArrayList<String> arrayList3 = bundle1.getStringArrayList("DETAILS_LIST");
          if (arrayList3 != null) {
            i = 0;
            while (true) {
              if (i < arrayList3.size()) {
                String str = arrayList3.get(i);
                try {
                  SkuDetails skuDetails = new SkuDetails(str);
                  String str1 = String.valueOf(skuDetails);
                  StringBuilder stringBuilder = new StringBuilder(String.valueOf(str1).length() + 17);
                  stringBuilder.append("Got sku details: ");
                  stringBuilder.append(str1);
                  zza.zza("BillingClient", stringBuilder.toString());
                  arrayList.add(skuDetails);
                  i++;
                } catch (JSONException jSONException) {
                  zza.zzb("BillingClient", "Got a JSON exception trying to decode SkuDetails.");
                  return new zzap(6, "Error trying to decode SkuDetails.", null);
                } 
                continue;
              } 
              i = k;
              continue label44;
            } 
            break;
          } 
          zza.zzb("BillingClient", "querySkuDetailsAsync got null response list");
          return new zzap(4, "Item is unavailable for purchase.", null);
        } catch (Exception exception) {
          String str = String.valueOf(exception);
          StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 63);
          stringBuilder.append("querySkuDetailsAsync got a remote exception (try to reconnect).");
          stringBuilder.append(str);
          zza.zzb("BillingClient", stringBuilder.toString());
          return new zzap(-1, "Service connection is disconnected.", null);
        } 
      } 
      return new zzap(0, "", arrayList);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\BillingClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */