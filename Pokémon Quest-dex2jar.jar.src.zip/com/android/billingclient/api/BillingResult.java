package com.android.billingclient.api;

import androidx.annotation.NonNull;

public final class BillingResult {
  private int zza;
  
  private String zzb;
  
  @NonNull
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  @NonNull
  public String getDebugMessage() {
    return this.zzb;
  }
  
  public int getResponseCode() {
    return this.zza;
  }
  
  public static class Builder {
    private int zza;
    
    private String zzb = "";
    
    private Builder() {}
    
    @NonNull
    public BillingResult build() {
      BillingResult billingResult = new BillingResult();
      BillingResult.zza(billingResult, this.zza);
      BillingResult.zzb(billingResult, this.zzb);
      return billingResult;
    }
    
    @NonNull
    public Builder setDebugMessage(@NonNull String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    @NonNull
    public Builder setResponseCode(int param1Int) {
      this.zza = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\BillingResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */