package com.android.billingclient.api;

import android.content.Context;
import android.content.IntentFilter;

final class zze {
  private final Context zza;
  
  private final zzd zzb;
  
  zze(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener) {
    this.zza = paramContext;
    this.zzb = new zzd(this, paramPurchasesUpdatedListener, null);
  }
  
  final void zza() {
    this.zzb.zza(this.zza, new IntentFilter("com.android.vending.billing.PURCHASES_UPDATED"));
  }
  
  final PurchasesUpdatedListener zzb() {
    return zzd.zzc(this.zzb);
  }
  
  final void zzc() {
    this.zzb.zzb(this.zza);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */