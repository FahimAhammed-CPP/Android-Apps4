package com.android.billingclient.api;

import android.text.TextUtils;

public final class zzas {
  private String zza;
  
  private zzas() {}
  
  public final zzas zza(String paramString) {
    this.zza = paramString;
    return this;
  }
  
  public final zzat zzb() {
    if (!TextUtils.isEmpty(this.zza))
      return new zzat(this.zza, null, null); 
    throw new IllegalArgumentException("SKU must be set.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */