package com.android.billingclient.api;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

public class PurchaseHistoryRecord {
  private final String zza;
  
  private final String zzb;
  
  private final JSONObject zzc;
  
  public PurchaseHistoryRecord(@NonNull String paramString1, @NonNull String paramString2) throws JSONException {
    this.zza = paramString1;
    this.zzb = paramString2;
    this.zzc = new JSONObject(this.zza);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PurchaseHistoryRecord))
      return false; 
    paramObject = paramObject;
    return (TextUtils.equals(this.zza, paramObject.getOriginalJson()) && TextUtils.equals(this.zzb, paramObject.getSignature()));
  }
  
  @NonNull
  public String getDeveloperPayload() {
    return this.zzc.optString("developerPayload");
  }
  
  @NonNull
  public String getOriginalJson() {
    return this.zza;
  }
  
  public long getPurchaseTime() {
    return this.zzc.optLong("purchaseTime");
  }
  
  @NonNull
  public String getPurchaseToken() {
    JSONObject jSONObject = this.zzc;
    return jSONObject.optString("token", jSONObject.optString("purchaseToken"));
  }
  
  @NonNull
  public String getSignature() {
    return this.zzb;
  }
  
  @NonNull
  @zzb
  public String getSku() {
    return this.zzc.optString("productId");
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  @NonNull
  public String toString() {
    String str = String.valueOf(this.zza);
    return (str.length() != 0) ? "PurchaseHistoryRecord. Json: ".concat(str) : new String("PurchaseHistoryRecord. Json: ");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\PurchaseHistoryRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */