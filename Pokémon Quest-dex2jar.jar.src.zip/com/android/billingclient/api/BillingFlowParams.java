package com.android.billingclient.api;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

public class BillingFlowParams {
  @NonNull
  public static final String EXTRA_PARAM_KEY_ACCOUNT_ID = "accountId";
  
  @NonNull
  public static final String EXTRA_PARAM_KEY_OLD_SKUS = "skusToReplace";
  
  @NonNull
  public static final String EXTRA_PARAM_KEY_OLD_SKU_PURCHASE_TOKEN = "oldSkuPurchaseToken";
  
  @NonNull
  public static final String EXTRA_PARAM_KEY_REPLACE_SKUS_PRORATION_MODE = "prorationMode";
  
  @NonNull
  public static final String EXTRA_PARAM_KEY_VR = "vr";
  
  private boolean zza;
  
  private String zzb;
  
  private String zzc;
  
  private String zzd;
  
  private String zze;
  
  private int zzf = 0;
  
  private ArrayList<SkuDetails> zzg;
  
  private boolean zzh;
  
  private BillingFlowParams() {}
  
  @NonNull
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  @Nullable
  @zzb
  public String getOldSku() {
    return this.zzc;
  }
  
  @Nullable
  @zzb
  public String getOldSkuPurchaseToken() {
    return this.zzd;
  }
  
  @zzb
  public int getReplaceSkusProrationMode() {
    return this.zzf;
  }
  
  @NonNull
  @zzb
  public String getSku() {
    return ((SkuDetails)this.zzg.get(0)).getSku();
  }
  
  @NonNull
  @zzb
  public SkuDetails getSkuDetails() {
    return this.zzg.get(0);
  }
  
  @NonNull
  @zzb
  public String getSkuType() {
    return ((SkuDetails)this.zzg.get(0)).getType();
  }
  
  public boolean getVrPurchaseFlow() {
    return this.zzh;
  }
  
  @NonNull
  public final ArrayList<SkuDetails> zza() {
    ArrayList<SkuDetails> arrayList = new ArrayList();
    arrayList.addAll(this.zzg);
    return arrayList;
  }
  
  @Nullable
  public final String zzb() {
    return this.zzb;
  }
  
  final boolean zzc() {
    return (this.zzh || this.zzb != null || this.zze != null || this.zzf != 0 || this.zza);
  }
  
  @Nullable
  public final String zzd() {
    return this.zze;
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private String zzc;
    
    private String zzd;
    
    private int zze = 0;
    
    private ArrayList<SkuDetails> zzf;
    
    private boolean zzg;
    
    private Builder() {}
    
    @NonNull
    public BillingFlowParams build() {
      ArrayList<SkuDetails> arrayList = this.zzf;
      if (arrayList != null && !arrayList.isEmpty()) {
        arrayList = this.zzf;
        int j = arrayList.size();
        int i = 0;
        while (i < j) {
          if ((SkuDetails)arrayList.get(i) != null) {
            i++;
            continue;
          } 
          throw new IllegalArgumentException("SKU cannot be null.");
        } 
        if (this.zzf.size() > 1) {
          SkuDetails skuDetails = this.zzf.get(0);
          String str1 = skuDetails.getType();
          ArrayList<SkuDetails> arrayList1 = this.zzf;
          j = arrayList1.size();
          i = 0;
          while (i < j) {
            SkuDetails skuDetails1 = arrayList1.get(i);
            if (str1.equals("play_pass_subs") || skuDetails1.getType().equals("play_pass_subs") || str1.equals(skuDetails1.getType())) {
              i++;
              continue;
            } 
            throw new IllegalArgumentException("SKUs should have the same type.");
          } 
          String str2 = skuDetails.zza();
          arrayList1 = this.zzf;
          j = arrayList1.size();
          i = 0;
          while (i < j) {
            SkuDetails skuDetails1 = arrayList1.get(i);
            if (str1.equals("play_pass_subs") || skuDetails1.getType().equals("play_pass_subs") || str2.equals(skuDetails1.zza())) {
              i++;
              continue;
            } 
            throw new IllegalArgumentException("All SKUs must have the same package name.");
          } 
        } 
        BillingFlowParams billingFlowParams = new BillingFlowParams(null);
        BillingFlowParams.zze(billingFlowParams, true ^ ((SkuDetails)this.zzf.get(0)).zza().isEmpty());
        BillingFlowParams.zzf(billingFlowParams, this.zza);
        BillingFlowParams.zzg(billingFlowParams, this.zzd);
        BillingFlowParams.zzh(billingFlowParams, this.zzb);
        BillingFlowParams.zzi(billingFlowParams, this.zzc);
        BillingFlowParams.zzj(billingFlowParams, this.zze);
        BillingFlowParams.zzk(billingFlowParams, this.zzf);
        BillingFlowParams.zzl(billingFlowParams, this.zzg);
        return billingFlowParams;
      } 
      throw new IllegalArgumentException("SkuDetails must be provided.");
    }
    
    @NonNull
    public Builder setObfuscatedAccountId(@NonNull String param1String) {
      this.zza = param1String;
      return this;
    }
    
    @NonNull
    public Builder setObfuscatedProfileId(@NonNull String param1String) {
      this.zzd = param1String;
      return this;
    }
    
    @NonNull
    @zzb
    public Builder setOldSku(@NonNull String param1String1, @NonNull String param1String2) {
      this.zzb = param1String1;
      this.zzc = param1String2;
      return this;
    }
    
    @NonNull
    @zzb
    public Builder setReplaceSkusProrationMode(int param1Int) {
      this.zze = param1Int;
      return this;
    }
    
    @NonNull
    public Builder setSkuDetails(@NonNull SkuDetails param1SkuDetails) {
      ArrayList<SkuDetails> arrayList = new ArrayList();
      arrayList.add(param1SkuDetails);
      this.zzf = arrayList;
      return this;
    }
    
    @NonNull
    public Builder setVrPurchaseFlow(boolean param1Boolean) {
      this.zzg = param1Boolean;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProrationMode {
    public static final int DEFERRED = 4;
    
    public static final int IMMEDIATE_AND_CHARGE_PRORATED_PRICE = 2;
    
    public static final int IMMEDIATE_WITHOUT_PRORATION = 3;
    
    public static final int IMMEDIATE_WITH_TIME_PRORATION = 1;
    
    public static final int UNKNOWN_SUBSCRIPTION_UPGRADE_DOWNGRADE_POLICY = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\BillingFlowParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */