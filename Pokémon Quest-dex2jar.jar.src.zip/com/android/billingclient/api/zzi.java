package com.android.billingclient.api;

final class zzi implements Runnable {
  zzi(BillingClientImpl paramBillingClientImpl, ConsumeResponseListener paramConsumeResponseListener, ConsumeParams paramConsumeParams) {}
  
  public final void run() {
    this.zza.onConsumeResponse(zzam.zzr, this.zzb.getPurchaseToken());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */