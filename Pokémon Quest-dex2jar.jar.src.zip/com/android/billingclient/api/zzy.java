package com.android.billingclient.api;

import android.os.Bundle;
import java.util.concurrent.Callable;

final class zzy implements Callable<Bundle> {
  zzy(BillingClientImpl paramBillingClientImpl, int paramInt, SkuDetails paramSkuDetails, String paramString, BillingFlowParams paramBillingFlowParams, Bundle paramBundle) {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */