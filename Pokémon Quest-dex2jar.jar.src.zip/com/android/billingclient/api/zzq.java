package com.android.billingclient.api;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

final class zzq implements ThreadFactory {
  private final ThreadFactory zza = Executors.defaultThreadFactory();
  
  private final AtomicInteger zzb = new AtomicInteger(1);
  
  zzq(BillingClientImpl paramBillingClientImpl) {}
  
  public final Thread newThread(Runnable paramRunnable) {
    paramRunnable = this.zza.newThread(paramRunnable);
    int i = this.zzb.getAndIncrement();
    StringBuilder stringBuilder = new StringBuilder(30);
    stringBuilder.append("PlayBillingLibrary-");
    stringBuilder.append(i);
    paramRunnable.setName(stringBuilder.toString());
    return (Thread)paramRunnable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */