package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zza;
import java.util.concurrent.Future;

final class zzr implements Runnable {
  zzr(BillingClientImpl paramBillingClientImpl, Future paramFuture, Runnable paramRunnable) {}
  
  public final void run() {
    if (!this.zza.isDone() && !this.zza.isCancelled()) {
      this.zza.cancel(true);
      zza.zzb("BillingClient", "Async task is taking too long, cancel it!");
      Runnable runnable = this.zzb;
      if (runnable != null)
        runnable.run(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */