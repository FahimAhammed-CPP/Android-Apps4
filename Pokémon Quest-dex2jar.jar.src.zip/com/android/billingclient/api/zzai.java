package com.android.billingclient.api;

import androidx.annotation.Nullable;
import java.util.List;

final class zzai {
  private final List<PurchaseHistoryRecord> zza;
  
  private final BillingResult zzb;
  
  zzai(BillingResult paramBillingResult, @Nullable List<PurchaseHistoryRecord> paramList) {
    this.zza = paramList;
    this.zzb = paramBillingResult;
  }
  
  final BillingResult zza() {
    return this.zzb;
  }
  
  final List<PurchaseHistoryRecord> zzb() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */