package com.android.billingclient.api;

import androidx.annotation.Nullable;
import java.util.List;

final class zzap {
  @Nullable
  private final List<SkuDetails> zza;
  
  private final int zzb;
  
  private final String zzc;
  
  public zzap(int paramInt, String paramString, @Nullable List<SkuDetails> paramList) {
    this.zzb = paramInt;
    this.zzc = paramString;
    this.zza = paramList;
  }
  
  @Nullable
  public final List<SkuDetails> zza() {
    return this.zza;
  }
  
  public final int zzb() {
    return this.zzb;
  }
  
  public final String zzc() {
    return this.zzc;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */