package com.android.billingclient.api;

import android.os.Bundle;
import java.util.concurrent.Callable;

final class zzs implements Callable<Bundle> {
  zzs(BillingClientImpl paramBillingClientImpl, String paramString, Bundle paramBundle) {}
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */