package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zza;

final class zzw implements Runnable {
  zzw(BillingClientImpl paramBillingClientImpl, Exception paramException, ConsumeResponseListener paramConsumeResponseListener, String paramString) {}
  
  public final void run() {
    String str = String.valueOf(this.zza);
    StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 30);
    stringBuilder.append("Error consuming purchase; ex: ");
    stringBuilder.append(str);
    zza.zzb("BillingClient", stringBuilder.toString());
    this.zzb.onConsumeResponse(zzam.zzq, this.zzc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\android\billingclient\api\zzw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */