package com.google.android.gms.ads.formats;

import android.support.annotation.Nullable;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.internal.zzzt;

@zzzt
public final class NativeAdOptions {
  public static final int ADCHOICES_BOTTOM_LEFT = 3;
  
  public static final int ADCHOICES_BOTTOM_RIGHT = 2;
  
  public static final int ADCHOICES_TOP_LEFT = 0;
  
  public static final int ADCHOICES_TOP_RIGHT = 1;
  
  public static final int ORIENTATION_ANY = 0;
  
  public static final int ORIENTATION_LANDSCAPE = 2;
  
  public static final int ORIENTATION_PORTRAIT = 1;
  
  private final boolean zzalm;
  
  private final int zzaln;
  
  private final boolean zzalo;
  
  private final int zzalp;
  
  private final VideoOptions zzalq;
  
  private NativeAdOptions(Builder paramBuilder) {
    this.zzalm = Builder.zza(paramBuilder);
    this.zzaln = Builder.zzb(paramBuilder);
    this.zzalo = Builder.zzc(paramBuilder);
    this.zzalp = Builder.zzd(paramBuilder);
    this.zzalq = Builder.zze(paramBuilder);
  }
  
  public final int getAdChoicesPlacement() {
    return this.zzalp;
  }
  
  public final int getImageOrientation() {
    return this.zzaln;
  }
  
  @Nullable
  public final VideoOptions getVideoOptions() {
    return this.zzalq;
  }
  
  public final boolean shouldRequestMultipleImages() {
    return this.zzalo;
  }
  
  public final boolean shouldReturnUrlsForImageAssets() {
    return this.zzalm;
  }
  
  public static @interface AdChoicesPlacement {}
  
  public static final class Builder {
    private boolean zzalm = false;
    
    private int zzaln = -1;
    
    private boolean zzalo = false;
    
    private int zzalp = 1;
    
    private VideoOptions zzalq;
    
    public final NativeAdOptions build() {
      return new NativeAdOptions(this, null);
    }
    
    public final Builder setAdChoicesPlacement(@AdChoicesPlacement int param1Int) {
      this.zzalp = param1Int;
      return this;
    }
    
    public final Builder setImageOrientation(int param1Int) {
      this.zzaln = param1Int;
      return this;
    }
    
    public final Builder setRequestMultipleImages(boolean param1Boolean) {
      this.zzalo = param1Boolean;
      return this;
    }
    
    public final Builder setReturnUrlsForImageAssets(boolean param1Boolean) {
      this.zzalm = param1Boolean;
      return this;
    }
    
    public final Builder setVideoOptions(VideoOptions param1VideoOptions) {
      this.zzalq = param1VideoOptions;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\formats\NativeAdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */