package com.google.android.gms.ads.formats;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzn;
import com.google.android.gms.internal.zzaji;
import com.google.android.gms.internal.zzjo;
import com.google.android.gms.internal.zzpg;

public class NativeAdView extends FrameLayout {
  private final FrameLayout zzalr;
  
  private final zzpg zzals;
  
  public NativeAdView(Context paramContext) {
    super(paramContext);
    this.zzalr = zzc(paramContext);
    this.zzals = zzbg();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.zzalr = zzc(paramContext);
    this.zzals = zzbg();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.zzalr = zzc(paramContext);
    this.zzals = zzbg();
  }
  
  @TargetApi(21)
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.zzalr = zzc(paramContext);
    this.zzals = zzbg();
  }
  
  private final zzpg zzbg() {
    zzbp.zzb(this.zzalr, "createDelegate must be called after mOverlayFrame has been created");
    return zzjo.zzhv().zza(this.zzalr.getContext(), this, this.zzalr);
  }
  
  private final FrameLayout zzc(Context paramContext) {
    FrameLayout frameLayout = new FrameLayout(paramContext);
    frameLayout.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    addView((View)frameLayout);
    return frameLayout;
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    super.bringChildToFront((View)this.zzalr);
  }
  
  public void bringChildToFront(View paramView) {
    super.bringChildToFront(paramView);
    FrameLayout frameLayout = this.zzalr;
    if (frameLayout != paramView)
      super.bringChildToFront((View)frameLayout); 
  }
  
  public void destroy() {
    try {
      this.zzals.destroy();
      return;
    } catch (RemoteException remoteException) {
      zzaji.zzb("Unable to destroy native ad view", (Throwable)remoteException);
      return;
    } 
  }
  
  public AdChoicesView getAdChoicesView() {
    View view = zzp("1098");
    return (view instanceof AdChoicesView) ? (AdChoicesView)view : null;
  }
  
  public void onVisibilityChanged(View paramView, int paramInt) {
    super.onVisibilityChanged(paramView, paramInt);
    zzpg zzpg1 = this.zzals;
    if (zzpg1 != null)
      try {
        zzpg1.zzb(zzn.zzw(paramView), paramInt);
        return;
      } catch (RemoteException remoteException) {
        zzaji.zzb("Unable to call onVisibilityChanged on delegate", (Throwable)remoteException);
      }  
  }
  
  public void removeAllViews() {
    super.removeAllViews();
    addView((View)this.zzalr);
  }
  
  public void removeView(View paramView) {
    if (this.zzalr == paramView)
      return; 
    super.removeView(paramView);
  }
  
  public void setAdChoicesView(AdChoicesView paramAdChoicesView) {
    zza("1098", (View)paramAdChoicesView);
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    try {
      this.zzals.zze((IObjectWrapper)paramNativeAd.zzbf());
      return;
    } catch (RemoteException remoteException) {
      zzaji.zzb("Unable to call setNativeAd on delegate", (Throwable)remoteException);
      return;
    } 
  }
  
  protected final void zza(String paramString, View paramView) {
    try {
      this.zzals.zzd(paramString, zzn.zzw(paramView));
      return;
    } catch (RemoteException remoteException) {
      zzaji.zzb("Unable to call setAssetView on delegate", (Throwable)remoteException);
      return;
    } 
  }
  
  protected final View zzp(String paramString) {
    try {
      IObjectWrapper iObjectWrapper = this.zzals.zzak(paramString);
      if (iObjectWrapper != null)
        return (View)zzn.zzab(iObjectWrapper); 
    } catch (RemoteException remoteException) {
      zzaji.zzb("Unable to call getAssetView on delegate", (Throwable)remoteException);
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\formats\NativeAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */