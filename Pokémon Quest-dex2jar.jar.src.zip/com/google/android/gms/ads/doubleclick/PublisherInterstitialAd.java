package com.google.android.gms.ads.doubleclick;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.Correlator;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.internal.zzlk;

public final class PublisherInterstitialAd {
  private final zzlk zzala;
  
  public PublisherInterstitialAd(Context paramContext) {
    this.zzala = new zzlk(paramContext, this);
    zzbp.zzb(paramContext, "Context cannot be null");
  }
  
  public final AdListener getAdListener() {
    return this.zzala.getAdListener();
  }
  
  public final String getAdUnitId() {
    return this.zzala.getAdUnitId();
  }
  
  public final AppEventListener getAppEventListener() {
    return this.zzala.getAppEventListener();
  }
  
  public final String getMediationAdapterClassName() {
    return this.zzala.getMediationAdapterClassName();
  }
  
  public final OnCustomRenderedAdLoadedListener getOnCustomRenderedAdLoadedListener() {
    return this.zzala.getOnCustomRenderedAdLoadedListener();
  }
  
  public final boolean isLoaded() {
    return this.zzala.isLoaded();
  }
  
  public final boolean isLoading() {
    return this.zzala.isLoading();
  }
  
  @RequiresPermission("android.permission.INTERNET")
  public final void loadAd(PublisherAdRequest paramPublisherAdRequest) {
    this.zzala.zza(paramPublisherAdRequest.zzaz());
  }
  
  public final void setAdListener(AdListener paramAdListener) {
    this.zzala.setAdListener(paramAdListener);
  }
  
  public final void setAdUnitId(String paramString) {
    this.zzala.setAdUnitId(paramString);
  }
  
  public final void setAppEventListener(AppEventListener paramAppEventListener) {
    this.zzala.setAppEventListener(paramAppEventListener);
  }
  
  public final void setCorrelator(Correlator paramCorrelator) {
    this.zzala.setCorrelator(paramCorrelator);
  }
  
  public final void setImmersiveMode(boolean paramBoolean) {
    this.zzala.setImmersiveMode(paramBoolean);
  }
  
  public final void setOnCustomRenderedAdLoadedListener(OnCustomRenderedAdLoadedListener paramOnCustomRenderedAdLoadedListener) {
    this.zzala.setOnCustomRenderedAdLoadedListener(paramOnCustomRenderedAdLoadedListener);
  }
  
  public final void show() {
    this.zzala.show();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\doubleclick\PublisherInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */