package com.google.android.gms.ads.doubleclick;

import android.content.Context;
import android.support.annotation.RequiresPermission;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.Correlator;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.common.internal.zzbp;
import com.google.android.gms.internal.zzaji;
import com.google.android.gms.internal.zzkf;
import com.google.android.gms.internal.zzli;

public final class PublisherAdView extends ViewGroup {
  private final zzli zzaky = new zzli(this);
  
  public PublisherAdView(Context paramContext) {
    super(paramContext);
  }
  
  public PublisherAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    zzbp.zzb(paramContext, "Context cannot be null");
  }
  
  public PublisherAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public final void destroy() {
    this.zzaky.destroy();
  }
  
  public final AdListener getAdListener() {
    return this.zzaky.getAdListener();
  }
  
  public final AdSize getAdSize() {
    return this.zzaky.getAdSize();
  }
  
  public final AdSize[] getAdSizes() {
    return this.zzaky.getAdSizes();
  }
  
  public final String getAdUnitId() {
    return this.zzaky.getAdUnitId();
  }
  
  public final AppEventListener getAppEventListener() {
    return this.zzaky.getAppEventListener();
  }
  
  public final String getMediationAdapterClassName() {
    return this.zzaky.getMediationAdapterClassName();
  }
  
  public final OnCustomRenderedAdLoadedListener getOnCustomRenderedAdLoadedListener() {
    return this.zzaky.getOnCustomRenderedAdLoadedListener();
  }
  
  public final VideoController getVideoController() {
    return this.zzaky.getVideoController();
  }
  
  public final VideoOptions getVideoOptions() {
    return this.zzaky.getVideoOptions();
  }
  
  public final boolean isLoading() {
    return this.zzaky.isLoading();
  }
  
  @RequiresPermission("android.permission.INTERNET")
  public final void loadAd(PublisherAdRequest paramPublisherAdRequest) {
    this.zzaky.zza(paramPublisherAdRequest.zzaz());
  }
  
  protected final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  protected final void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      i = view.getMeasuredWidth();
      j = view.getMeasuredHeight();
    } else {
      AdSize adSize;
      view = null;
      try {
        AdSize adSize1 = getAdSize();
        adSize = adSize1;
      } catch (NullPointerException nullPointerException) {
        zzaji.zzb("Unable to retrieve ad size.", nullPointerException);
      } 
      if (adSize != null) {
        Context context = getContext();
        i = adSize.getWidthInPixels(context);
        j = adSize.getHeightInPixels(context);
      } else {
        j = 0;
      } 
    } 
    i = Math.max(i, getSuggestedMinimumWidth());
    int j = Math.max(j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(i, paramInt1), View.resolveSize(j, paramInt2));
  }
  
  public final void pause() {
    this.zzaky.pause();
  }
  
  public final void recordManualImpression() {
    this.zzaky.recordManualImpression();
  }
  
  public final void resume() {
    this.zzaky.resume();
  }
  
  public final void setAdListener(AdListener paramAdListener) {
    this.zzaky.setAdListener(paramAdListener);
  }
  
  public final void setAdSizes(AdSize... paramVarArgs) {
    if (paramVarArgs != null && paramVarArgs.length > 0) {
      this.zzaky.zza(paramVarArgs);
      return;
    } 
    throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
  }
  
  public final void setAdUnitId(String paramString) {
    this.zzaky.setAdUnitId(paramString);
  }
  
  public final void setAppEventListener(AppEventListener paramAppEventListener) {
    this.zzaky.setAppEventListener(paramAppEventListener);
  }
  
  public final void setCorrelator(Correlator paramCorrelator) {
    this.zzaky.setCorrelator(paramCorrelator);
  }
  
  public final void setManualImpressionsEnabled(boolean paramBoolean) {
    this.zzaky.setManualImpressionsEnabled(paramBoolean);
  }
  
  public final void setOnCustomRenderedAdLoadedListener(OnCustomRenderedAdLoadedListener paramOnCustomRenderedAdLoadedListener) {
    this.zzaky.setOnCustomRenderedAdLoadedListener(paramOnCustomRenderedAdLoadedListener);
  }
  
  public final void setVideoOptions(VideoOptions paramVideoOptions) {
    this.zzaky.setVideoOptions(paramVideoOptions);
  }
  
  public final boolean zza(zzkf paramzzkf) {
    return this.zzaky.zza(paramzzkf);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\doubleclick\PublisherAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */