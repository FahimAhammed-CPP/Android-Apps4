package com.google.android.gms.ads.doubleclick;

import android.view.View;

public interface CustomRenderedAd {
  String getBaseUrl();
  
  String getContent();
  
  void onAdRendered(View paramView);
  
  void recordClick();
  
  void recordImpression();
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\doubleclick\CustomRenderedAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */