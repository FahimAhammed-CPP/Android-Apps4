package com.google.android.gms.ads.doubleclick;

public interface OnCustomRenderedAdLoadedListener {
  void onCustomRenderedAdLoaded(CustomRenderedAd paramCustomRenderedAd);
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\android\gms\ads\doubleclick\OnCustomRenderedAdLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */