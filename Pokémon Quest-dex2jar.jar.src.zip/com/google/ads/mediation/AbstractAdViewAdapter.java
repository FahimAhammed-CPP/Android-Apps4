package com.google.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.ads.formats.NativeAd;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAdView;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeAdMapper;
import com.google.android.gms.ads.mediation.NativeAppInstallAdMapper;
import com.google.android.gms.ads.mediation.NativeContentAdMapper;
import com.google.android.gms.ads.mediation.NativeMediationAdRequest;
import com.google.android.gms.ads.mediation.OnImmersiveModeUpdatedListener;
import com.google.android.gms.ads.mediation.zza;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdListener;
import com.google.android.gms.internal.zzaje;
import com.google.android.gms.internal.zzaji;
import com.google.android.gms.internal.zzalt;
import com.google.android.gms.internal.zzis;
import com.google.android.gms.internal.zzjo;
import com.google.android.gms.internal.zzky;
import com.google.android.gms.internal.zzzt;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

@zzzt
public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationNativeAdapter, OnImmersiveModeUpdatedListener, zza, MediationRewardedVideoAdAdapter, zzalt {
  public static final String AD_UNIT_ID_PARAMETER = "pubid";
  
  private AdView zzgm;
  
  private InterstitialAd zzgn;
  
  private AdLoader zzgo;
  
  private Context zzgp;
  
  private InterstitialAd zzgq;
  
  private MediationRewardedVideoAdListener zzgr;
  
  private RewardedVideoAdListener zzgs = new zza(this);
  
  private final AdRequest zza(Context paramContext, MediationAdRequest paramMediationAdRequest, Bundle paramBundle1, Bundle paramBundle2) {
    AdRequest.Builder builder = new AdRequest.Builder();
    Date date = paramMediationAdRequest.getBirthday();
    if (date != null)
      builder.setBirthday(date); 
    int i = paramMediationAdRequest.getGender();
    if (i != 0)
      builder.setGender(i); 
    Set set = paramMediationAdRequest.getKeywords();
    if (set != null) {
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        builder.addKeyword(iterator.next()); 
    } 
    Location location = paramMediationAdRequest.getLocation();
    if (location != null)
      builder.setLocation(location); 
    if (paramMediationAdRequest.isTesting()) {
      zzjo.zzhu();
      builder.addTestDevice(zzaje.zzay(paramContext));
    } 
    if (paramMediationAdRequest.taggedForChildDirectedTreatment() != -1) {
      i = paramMediationAdRequest.taggedForChildDirectedTreatment();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      builder.tagForChildDirectedTreatment(bool);
    } 
    builder.setIsDesignedForFamilies(paramMediationAdRequest.isDesignedForFamilies());
    builder.addNetworkExtrasBundle(AdMobAdapter.class, zza(paramBundle1, paramBundle2));
    return builder.build();
  }
  
  public String getAdUnitId(Bundle paramBundle) {
    return paramBundle.getString("pubid");
  }
  
  public View getBannerView() {
    return (View)this.zzgm;
  }
  
  public Bundle getInterstitialAdapterInfo() {
    return (new MediationAdapter.zza()).zzaf(1).zztm();
  }
  
  public zzky getVideoController() {
    AdView adView = this.zzgm;
    if (adView != null) {
      VideoController videoController = adView.getVideoController();
      if (videoController != null)
        return videoController.zzbc(); 
    } 
    return null;
  }
  
  public void initialize(Context paramContext, MediationAdRequest paramMediationAdRequest, String paramString, MediationRewardedVideoAdListener paramMediationRewardedVideoAdListener, Bundle paramBundle1, Bundle paramBundle2) {
    this.zzgp = paramContext.getApplicationContext();
    this.zzgr = paramMediationRewardedVideoAdListener;
    this.zzgr.onInitializationSucceeded(this);
  }
  
  public boolean isInitialized() {
    return (this.zzgr != null);
  }
  
  public void loadAd(MediationAdRequest paramMediationAdRequest, Bundle paramBundle1, Bundle paramBundle2) {
    Context context = this.zzgp;
    if (context == null || this.zzgr == null) {
      zzaji.e("AdMobAdapter.loadAd called before initialize.");
      return;
    } 
    this.zzgq = new InterstitialAd(context);
    this.zzgq.zza(true);
    this.zzgq.setAdUnitId(getAdUnitId(paramBundle1));
    this.zzgq.setRewardedVideoAdListener(this.zzgs);
    this.zzgq.loadAd(zza(this.zzgp, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void onDestroy() {
    AdView adView = this.zzgm;
    if (adView != null) {
      adView.destroy();
      this.zzgm = null;
    } 
    if (this.zzgn != null)
      this.zzgn = null; 
    if (this.zzgo != null)
      this.zzgo = null; 
    if (this.zzgq != null)
      this.zzgq = null; 
  }
  
  public void onImmersiveModeUpdated(boolean paramBoolean) {
    InterstitialAd interstitialAd = this.zzgn;
    if (interstitialAd != null)
      interstitialAd.setImmersiveMode(paramBoolean); 
    interstitialAd = this.zzgq;
    if (interstitialAd != null)
      interstitialAd.setImmersiveMode(paramBoolean); 
  }
  
  public void onPause() {
    AdView adView = this.zzgm;
    if (adView != null)
      adView.pause(); 
  }
  
  public void onResume() {
    AdView adView = this.zzgm;
    if (adView != null)
      adView.resume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.zzgm = new AdView(paramContext);
    this.zzgm.setAdSize(new AdSize(paramAdSize.getWidth(), paramAdSize.getHeight()));
    this.zzgm.setAdUnitId(getAdUnitId(paramBundle1));
    this.zzgm.setAdListener(new zzc(this, paramMediationBannerListener));
    this.zzgm.loadAd(zza(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.zzgn = new InterstitialAd(paramContext);
    this.zzgn.setAdUnitId(getAdUnitId(paramBundle1));
    this.zzgn.setAdListener(new zzd(this, paramMediationInterstitialListener));
    this.zzgn.loadAd(zza(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void requestNativeAd(Context paramContext, MediationNativeListener paramMediationNativeListener, Bundle paramBundle1, NativeMediationAdRequest paramNativeMediationAdRequest, Bundle paramBundle2) {
    zze zze = new zze(this, paramMediationNativeListener);
    AdLoader.Builder builder = (new AdLoader.Builder(paramContext, paramBundle1.getString("pubid"))).withAdListener(zze);
    NativeAdOptions nativeAdOptions = paramNativeMediationAdRequest.getNativeAdOptions();
    if (nativeAdOptions != null)
      builder.withNativeAdOptions(nativeAdOptions); 
    if (paramNativeMediationAdRequest.isAppInstallAdRequested())
      builder.forAppInstallAd(zze); 
    if (paramNativeMediationAdRequest.isContentAdRequested())
      builder.forContentAd(zze); 
    if (paramNativeMediationAdRequest.zzmc())
      for (String str : paramNativeMediationAdRequest.zzmd().keySet()) {
        if (((Boolean)paramNativeMediationAdRequest.zzmd().get(str)).booleanValue()) {
          zze zze1 = zze;
        } else {
          nativeAdOptions = null;
        } 
        builder.forCustomTemplateAd(str, zze, (NativeCustomTemplateAd.OnCustomClickListener)nativeAdOptions);
      }  
    this.zzgo = builder.build();
    this.zzgo.loadAd(zza(paramContext, (MediationAdRequest)paramNativeMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void showInterstitial() {
    this.zzgn.show();
  }
  
  public void showVideo() {
    this.zzgq.show();
  }
  
  protected abstract Bundle zza(Bundle paramBundle1, Bundle paramBundle2);
  
  static final class zza extends NativeAppInstallAdMapper {
    private final NativeAppInstallAd zzgu;
    
    public zza(NativeAppInstallAd param1NativeAppInstallAd) {
      this.zzgu = param1NativeAppInstallAd;
      setHeadline(param1NativeAppInstallAd.getHeadline().toString());
      setImages(param1NativeAppInstallAd.getImages());
      setBody(param1NativeAppInstallAd.getBody().toString());
      setIcon(param1NativeAppInstallAd.getIcon());
      setCallToAction(param1NativeAppInstallAd.getCallToAction().toString());
      if (param1NativeAppInstallAd.getStarRating() != null)
        setStarRating(param1NativeAppInstallAd.getStarRating().doubleValue()); 
      if (param1NativeAppInstallAd.getStore() != null)
        setStore(param1NativeAppInstallAd.getStore().toString()); 
      if (param1NativeAppInstallAd.getPrice() != null)
        setPrice(param1NativeAppInstallAd.getPrice().toString()); 
      setOverrideImpressionRecording(true);
      setOverrideClickHandling(true);
      zza(param1NativeAppInstallAd.getVideoController());
    }
    
    public final void trackView(View param1View) {
      if (param1View instanceof NativeAdView)
        ((NativeAdView)param1View).setNativeAd((NativeAd)this.zzgu); 
    }
  }
  
  static final class zzb extends NativeContentAdMapper {
    private final NativeContentAd zzgv;
    
    public zzb(NativeContentAd param1NativeContentAd) {
      this.zzgv = param1NativeContentAd;
      setHeadline(param1NativeContentAd.getHeadline().toString());
      setImages(param1NativeContentAd.getImages());
      setBody(param1NativeContentAd.getBody().toString());
      if (param1NativeContentAd.getLogo() != null)
        setLogo(param1NativeContentAd.getLogo()); 
      setCallToAction(param1NativeContentAd.getCallToAction().toString());
      setAdvertiser(param1NativeContentAd.getAdvertiser().toString());
      setOverrideImpressionRecording(true);
      setOverrideClickHandling(true);
      zza(param1NativeContentAd.getVideoController());
    }
    
    public final void trackView(View param1View) {
      if (param1View instanceof NativeAdView)
        ((NativeAdView)param1View).setNativeAd((NativeAd)this.zzgv); 
    }
  }
  
  static final class zzc extends AdListener implements AppEventListener, zzis {
    private AbstractAdViewAdapter zzgw;
    
    private MediationBannerListener zzgx;
    
    public zzc(AbstractAdViewAdapter param1AbstractAdViewAdapter, MediationBannerListener param1MediationBannerListener) {
      this.zzgw = param1AbstractAdViewAdapter;
      this.zzgx = param1MediationBannerListener;
    }
    
    public final void onAdClicked() {
      this.zzgx.onAdClicked(this.zzgw);
    }
    
    public final void onAdClosed() {
      this.zzgx.onAdClosed(this.zzgw);
    }
    
    public final void onAdFailedToLoad(int param1Int) {
      this.zzgx.onAdFailedToLoad(this.zzgw, param1Int);
    }
    
    public final void onAdLeftApplication() {
      this.zzgx.onAdLeftApplication(this.zzgw);
    }
    
    public final void onAdLoaded() {
      this.zzgx.onAdLoaded(this.zzgw);
    }
    
    public final void onAdOpened() {
      this.zzgx.onAdOpened(this.zzgw);
    }
    
    public final void onAppEvent(String param1String1, String param1String2) {
      this.zzgx.zza(this.zzgw, param1String1, param1String2);
    }
  }
  
  static final class zzd extends AdListener implements zzis {
    private AbstractAdViewAdapter zzgw;
    
    private MediationInterstitialListener zzgy;
    
    public zzd(AbstractAdViewAdapter param1AbstractAdViewAdapter, MediationInterstitialListener param1MediationInterstitialListener) {
      this.zzgw = param1AbstractAdViewAdapter;
      this.zzgy = param1MediationInterstitialListener;
    }
    
    public final void onAdClicked() {
      this.zzgy.onAdClicked((MediationInterstitialAdapter)this.zzgw);
    }
    
    public final void onAdClosed() {
      this.zzgy.onAdClosed((MediationInterstitialAdapter)this.zzgw);
    }
    
    public final void onAdFailedToLoad(int param1Int) {
      this.zzgy.onAdFailedToLoad((MediationInterstitialAdapter)this.zzgw, param1Int);
    }
    
    public final void onAdLeftApplication() {
      this.zzgy.onAdLeftApplication((MediationInterstitialAdapter)this.zzgw);
    }
    
    public final void onAdLoaded() {
      this.zzgy.onAdLoaded((MediationInterstitialAdapter)this.zzgw);
    }
    
    public final void onAdOpened() {
      this.zzgy.onAdOpened((MediationInterstitialAdapter)this.zzgw);
    }
  }
  
  static final class zze extends AdListener implements NativeAppInstallAd.OnAppInstallAdLoadedListener, NativeContentAd.OnContentAdLoadedListener, NativeCustomTemplateAd.OnCustomClickListener, NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener {
    private AbstractAdViewAdapter zzgw;
    
    private MediationNativeListener zzgz;
    
    public zze(AbstractAdViewAdapter param1AbstractAdViewAdapter, MediationNativeListener param1MediationNativeListener) {
      this.zzgw = param1AbstractAdViewAdapter;
      this.zzgz = param1MediationNativeListener;
    }
    
    public final void onAdClicked() {
      this.zzgz.onAdClicked(this.zzgw);
    }
    
    public final void onAdClosed() {
      this.zzgz.onAdClosed(this.zzgw);
    }
    
    public final void onAdFailedToLoad(int param1Int) {
      this.zzgz.onAdFailedToLoad(this.zzgw, param1Int);
    }
    
    public final void onAdImpression() {
      this.zzgz.onAdImpression(this.zzgw);
    }
    
    public final void onAdLeftApplication() {
      this.zzgz.onAdLeftApplication(this.zzgw);
    }
    
    public final void onAdLoaded() {}
    
    public final void onAdOpened() {
      this.zzgz.onAdOpened(this.zzgw);
    }
    
    public final void onAppInstallAdLoaded(NativeAppInstallAd param1NativeAppInstallAd) {
      this.zzgz.onAdLoaded(this.zzgw, (NativeAdMapper)new AbstractAdViewAdapter.zza(param1NativeAppInstallAd));
    }
    
    public final void onContentAdLoaded(NativeContentAd param1NativeContentAd) {
      this.zzgz.onAdLoaded(this.zzgw, (NativeAdMapper)new AbstractAdViewAdapter.zzb(param1NativeContentAd));
    }
    
    public final void onCustomClick(NativeCustomTemplateAd param1NativeCustomTemplateAd, String param1String) {
      this.zzgz.zza(this.zzgw, param1NativeCustomTemplateAd, param1String);
    }
    
    public final void onCustomTemplateAdLoaded(NativeCustomTemplateAd param1NativeCustomTemplateAd) {
      this.zzgz.zza(this.zzgw, param1NativeCustomTemplateAd);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\AbstractAdViewAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */