package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.internal.zzaji;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter<CustomEventExtras, CustomEventServerParameters>, MediationInterstitialAdapter<CustomEventExtras, CustomEventServerParameters> {
  private View zzhf;
  
  private CustomEventBanner zzhg;
  
  private CustomEventInterstitial zzhh;
  
  private final void zza(View paramView) {
    this.zzhf = paramView;
  }
  
  private static <T> T zzh(String paramString) {
    try {
      return (T)Class.forName(paramString).newInstance();
    } catch (Throwable throwable) {
      String str = throwable.getMessage();
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 46 + String.valueOf(str).length());
      stringBuilder.append("Could not instantiate custom event adapter: ");
      stringBuilder.append(paramString);
      stringBuilder.append(". ");
      stringBuilder.append(str);
      zzaji.zzcs(stringBuilder.toString());
      return null;
    } 
  }
  
  public final void destroy() {
    CustomEventBanner customEventBanner = this.zzhg;
    if (customEventBanner != null)
      customEventBanner.destroy(); 
    CustomEventInterstitial customEventInterstitial = this.zzhh;
    if (customEventInterstitial != null)
      customEventInterstitial.destroy(); 
  }
  
  public final Class<CustomEventExtras> getAdditionalParametersType() {
    return CustomEventExtras.class;
  }
  
  public final View getBannerView() {
    return this.zzhf;
  }
  
  public final Class<CustomEventServerParameters> getServerParametersType() {
    return CustomEventServerParameters.class;
  }
  
  public final void requestBannerAd(MediationBannerListener paramMediationBannerListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.zzhg = zzh(paramCustomEventServerParameters.className);
    if (this.zzhg == null) {
      paramMediationBannerListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.zzhg.requestBannerAd(new zza(this, paramMediationBannerListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramAdSize, paramMediationAdRequest, object);
  }
  
  public final void requestInterstitialAd(MediationInterstitialListener paramMediationInterstitialListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.zzhh = zzh(paramCustomEventServerParameters.className);
    if (this.zzhh == null) {
      paramMediationInterstitialListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.zzhh.requestInterstitialAd(new zzb(this, this, paramMediationInterstitialListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramMediationAdRequest, object);
  }
  
  public final void showInterstitial() {
    this.zzhh.showInterstitial();
  }
  
  static final class zza implements CustomEventBannerListener {
    private final CustomEventAdapter zzhi;
    
    private final MediationBannerListener zzhj;
    
    public zza(CustomEventAdapter param1CustomEventAdapter, MediationBannerListener param1MediationBannerListener) {
      this.zzhi = param1CustomEventAdapter;
      this.zzhj = param1MediationBannerListener;
    }
    
    public final void onClick() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhj.onClick(this.zzhi);
    }
    
    public final void onDismissScreen() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhj.onDismissScreen(this.zzhi);
    }
    
    public final void onFailedToReceiveAd() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhj.onFailedToReceiveAd(this.zzhi, AdRequest.ErrorCode.NO_FILL);
    }
    
    public final void onLeaveApplication() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhj.onLeaveApplication(this.zzhi);
    }
    
    public final void onPresentScreen() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhj.onPresentScreen(this.zzhi);
    }
    
    public final void onReceivedAd(View param1View) {
      zzaji.zzcb("Custom event adapter called onReceivedAd.");
      CustomEventAdapter.zza(this.zzhi, param1View);
      this.zzhj.onReceivedAd(this.zzhi);
    }
  }
  
  final class zzb implements CustomEventInterstitialListener {
    private final CustomEventAdapter zzhi;
    
    private final MediationInterstitialListener zzhk;
    
    public zzb(CustomEventAdapter this$0, CustomEventAdapter param1CustomEventAdapter1, MediationInterstitialListener param1MediationInterstitialListener) {
      this.zzhi = param1CustomEventAdapter1;
      this.zzhk = param1MediationInterstitialListener;
    }
    
    public final void onDismissScreen() {
      zzaji.zzcb("Custom event adapter called onDismissScreen.");
      this.zzhk.onDismissScreen(this.zzhi);
    }
    
    public final void onFailedToReceiveAd() {
      zzaji.zzcb("Custom event adapter called onFailedToReceiveAd.");
      this.zzhk.onFailedToReceiveAd(this.zzhi, AdRequest.ErrorCode.NO_FILL);
    }
    
    public final void onLeaveApplication() {
      zzaji.zzcb("Custom event adapter called onLeaveApplication.");
      this.zzhk.onLeaveApplication(this.zzhi);
    }
    
    public final void onPresentScreen() {
      zzaji.zzcb("Custom event adapter called onPresentScreen.");
      this.zzhk.onPresentScreen(this.zzhi);
    }
    
    public final void onReceivedAd() {
      zzaji.zzcb("Custom event adapter called onReceivedAd.");
      this.zzhk.onReceivedAd(this.zzhl);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */