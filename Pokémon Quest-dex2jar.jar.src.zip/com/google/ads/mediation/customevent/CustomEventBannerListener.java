package com.google.ads.mediation.customevent;

import android.view.View;

@Deprecated
public interface CustomEventBannerListener extends CustomEventListener {
  void onClick();
  
  void onReceivedAd(View paramView);
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventBannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */