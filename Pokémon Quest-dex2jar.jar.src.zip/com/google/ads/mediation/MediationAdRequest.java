package com.google.ads.mediation;

import android.location.Location;
import com.google.ads.AdRequest;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

@Deprecated
public class MediationAdRequest {
  private final Date zzha;
  
  private final AdRequest.Gender zzhb;
  
  private final Set<String> zzhc;
  
  private final boolean zzhd;
  
  private final Location zzhe;
  
  public MediationAdRequest(Date paramDate, AdRequest.Gender paramGender, Set<String> paramSet, boolean paramBoolean, Location paramLocation) {
    this.zzha = paramDate;
    this.zzhb = paramGender;
    this.zzhc = paramSet;
    this.zzhd = paramBoolean;
    this.zzhe = paramLocation;
  }
  
  public Integer getAgeInYears() {
    Integer integer;
    if (this.zzha != null) {
      Calendar calendar1 = Calendar.getInstance();
      Calendar calendar2 = Calendar.getInstance();
      calendar1.setTime(this.zzha);
      integer = Integer.valueOf(calendar2.get(1) - calendar1.get(1));
      if (calendar2.get(2) >= calendar1.get(2)) {
        Integer integer1 = integer;
        if (calendar2.get(2) == calendar1.get(2)) {
          integer1 = integer;
          if (calendar2.get(5) < calendar1.get(5))
            return Integer.valueOf(integer.intValue() - 1); 
        } 
        return integer1;
      } 
    } else {
      return null;
    } 
    return Integer.valueOf(integer.intValue() - 1);
  }
  
  public Date getBirthday() {
    return this.zzha;
  }
  
  public AdRequest.Gender getGender() {
    return this.zzhb;
  }
  
  public Set<String> getKeywords() {
    return this.zzhc;
  }
  
  public Location getLocation() {
    return this.zzhe;
  }
  
  public boolean isTesting() {
    return this.zzhd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\MediationAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */