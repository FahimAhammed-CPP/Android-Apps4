package com.google.ads.mediation;

@Deprecated
public final class EmptyNetworkExtras implements NetworkExtras {}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\EmptyNetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */