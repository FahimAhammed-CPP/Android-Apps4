package com.google.ads.mediation;

import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

final class zza implements RewardedVideoAdListener {
  zza(AbstractAdViewAdapter paramAbstractAdViewAdapter) {}
  
  public final void onRewarded(RewardItem paramRewardItem) {
    AbstractAdViewAdapter.zza(this.zzgt).onRewarded(this.zzgt, paramRewardItem);
  }
  
  public final void onRewardedVideoAdClosed() {
    AbstractAdViewAdapter.zza(this.zzgt).onAdClosed(this.zzgt);
    AbstractAdViewAdapter.zza(this.zzgt, (InterstitialAd)null);
  }
  
  public final void onRewardedVideoAdFailedToLoad(int paramInt) {
    AbstractAdViewAdapter.zza(this.zzgt).onAdFailedToLoad(this.zzgt, paramInt);
  }
  
  public final void onRewardedVideoAdLeftApplication() {
    AbstractAdViewAdapter.zza(this.zzgt).onAdLeftApplication(this.zzgt);
  }
  
  public final void onRewardedVideoAdLoaded() {
    AbstractAdViewAdapter.zza(this.zzgt).onAdLoaded(this.zzgt);
  }
  
  public final void onRewardedVideoAdOpened() {
    AbstractAdViewAdapter.zza(this.zzgt).onAdOpened(this.zzgt);
  }
  
  public final void onRewardedVideoStarted() {
    AbstractAdViewAdapter.zza(this.zzgt).onVideoStarted(this.zzgt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\mediation\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */