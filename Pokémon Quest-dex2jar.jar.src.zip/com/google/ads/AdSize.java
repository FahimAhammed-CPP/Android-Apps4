package com.google.ads;

import android.content.Context;

@Deprecated
public final class AdSize {
  public static final int AUTO_HEIGHT = -2;
  
  public static final AdSize BANNER;
  
  public static final int FULL_WIDTH = -1;
  
  public static final AdSize IAB_BANNER;
  
  public static final AdSize IAB_LEADERBOARD;
  
  public static final AdSize IAB_MRECT;
  
  public static final AdSize IAB_WIDE_SKYSCRAPER;
  
  public static final int LANDSCAPE_AD_HEIGHT = 32;
  
  public static final int LARGE_AD_HEIGHT = 90;
  
  public static final int PORTRAIT_AD_HEIGHT = 50;
  
  public static final AdSize SMART_BANNER = new AdSize(-1, -2, "mb");
  
  private final com.google.android.gms.ads.AdSize zzcg;
  
  static {
    BANNER = new AdSize(320, 50, "mb");
    IAB_MRECT = new AdSize(300, 250, "as");
    IAB_BANNER = new AdSize(468, 60, "as");
    IAB_LEADERBOARD = new AdSize(728, 90, "as");
    IAB_WIDE_SKYSCRAPER = new AdSize(160, 600, "as");
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this(new com.google.android.gms.ads.AdSize(paramInt1, paramInt2));
  }
  
  private AdSize(int paramInt1, int paramInt2, String paramString) {
    this(new com.google.android.gms.ads.AdSize(paramInt1, paramInt2));
  }
  
  public AdSize(com.google.android.gms.ads.AdSize paramAdSize) {
    this.zzcg = paramAdSize;
  }
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof AdSize))
      return false; 
    paramObject = paramObject;
    return this.zzcg.equals(((AdSize)paramObject).zzcg);
  }
  
  public final AdSize findBestSize(AdSize... paramVarArgs) {
    AdSize adSize = null;
    if (paramVarArgs == null)
      return null; 
    float f = 0.0F;
    int j = getWidth();
    int k = getHeight();
    int m = paramVarArgs.length;
    int i = 0;
    while (i < m) {
      AdSize adSize2 = paramVarArgs[i];
      int n = adSize2.getWidth();
      int i1 = adSize2.getHeight();
      AdSize adSize1 = adSize;
      float f1 = f;
      if (isSizeAppropriate(n, i1)) {
        f1 = (n * i1) / (j * k);
        float f2 = f1;
        if (f1 > 1.0F)
          f2 = 1.0F / f1; 
        adSize1 = adSize;
        f1 = f;
        if (f2 > f) {
          adSize1 = adSize2;
          f1 = f2;
        } 
      } 
      i++;
      adSize = adSize1;
      f = f1;
    } 
    return adSize;
  }
  
  public final int getHeight() {
    return this.zzcg.getHeight();
  }
  
  public final int getHeightInPixels(Context paramContext) {
    return this.zzcg.getHeightInPixels(paramContext);
  }
  
  public final int getWidth() {
    return this.zzcg.getWidth();
  }
  
  public final int getWidthInPixels(Context paramContext) {
    return this.zzcg.getWidthInPixels(paramContext);
  }
  
  public final int hashCode() {
    return this.zzcg.hashCode();
  }
  
  public final boolean isAutoHeight() {
    return this.zzcg.isAutoHeight();
  }
  
  public final boolean isCustomAdSize() {
    return false;
  }
  
  public final boolean isFullWidth() {
    return this.zzcg.isFullWidth();
  }
  
  public final boolean isSizeAppropriate(int paramInt1, int paramInt2) {
    int i = getWidth();
    int j = getHeight();
    float f1 = paramInt1;
    float f2 = i;
    if (f1 <= f2 * 1.25F && f1 >= f2 * 0.8F) {
      f1 = paramInt2;
      f2 = j;
      if (f1 <= 1.25F * f2 && f1 >= f2 * 0.8F)
        return true; 
    } 
    return false;
  }
  
  public final String toString() {
    return this.zzcg.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Pokémon Quest-dex2jar.jar!\com\google\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */