package com.facebook.appevents.cloudbridge;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\020\n\000\n\002\020\016\n\002\b\022\b\001\030\0002\b\022\004\022\0020\0000\001B\017\b\002\022\006\020\002\032\0020\003¢\006\002\020\004R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006j\002\b\007j\002\b\bj\002\b\tj\002\b\nj\002\b\013j\002\b\fj\002\b\rj\002\b\016j\002\b\017j\002\b\020j\002\b\021j\002\b\022j\002\b\023j\002\b\024¨\006\025"}, d2 = {"Lcom/facebook/appevents/cloudbridge/ConversionsAPIEventName;", "", "rawValue", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getRawValue", "()Ljava/lang/String;", "UNLOCKED_ACHIEVEMENT", "ACTIVATED_APP", "ADDED_PAYMENT_INFO", "ADDED_TO_CART", "ADDED_TO_WISHLIST", "COMPLETED_REGISTRATION", "VIEWED_CONTENT", "INITIATED_CHECKOUT", "ACHIEVED_LEVEL", "PURCHASED", "RATED", "SEARCHED", "SPENT_CREDITS", "COMPLETED_TUTORIAL", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public enum ConversionsAPIEventName {
  ACHIEVED_LEVEL,
  ACTIVATED_APP,
  ADDED_PAYMENT_INFO,
  ADDED_TO_CART,
  ADDED_TO_WISHLIST,
  COMPLETED_REGISTRATION,
  COMPLETED_TUTORIAL,
  INITIATED_CHECKOUT,
  PURCHASED,
  RATED,
  SEARCHED,
  SPENT_CREDITS,
  UNLOCKED_ACHIEVEMENT("AchievementUnlocked"),
  VIEWED_CONTENT("AchievementUnlocked");
  
  private final String rawValue;
  
  static {
    ACTIVATED_APP = new ConversionsAPIEventName("ACTIVATED_APP", 1, "ActivateApp");
    ADDED_PAYMENT_INFO = new ConversionsAPIEventName("ADDED_PAYMENT_INFO", 2, "AddPaymentInfo");
    ADDED_TO_CART = new ConversionsAPIEventName("ADDED_TO_CART", 3, "AddToCart");
    ADDED_TO_WISHLIST = new ConversionsAPIEventName("ADDED_TO_WISHLIST", 4, "AddToWishlist");
    COMPLETED_REGISTRATION = new ConversionsAPIEventName("COMPLETED_REGISTRATION", 5, "CompleteRegistration");
    VIEWED_CONTENT = new ConversionsAPIEventName("VIEWED_CONTENT", 6, "ViewContent");
    INITIATED_CHECKOUT = new ConversionsAPIEventName("INITIATED_CHECKOUT", 7, "InitiateCheckout");
    ACHIEVED_LEVEL = new ConversionsAPIEventName("ACHIEVED_LEVEL", 8, "LevelAchieved");
    PURCHASED = new ConversionsAPIEventName("PURCHASED", 9, "Purchase");
    RATED = new ConversionsAPIEventName("RATED", 10, "Rate");
    SEARCHED = new ConversionsAPIEventName("SEARCHED", 11, "Search");
    SPENT_CREDITS = new ConversionsAPIEventName("SPENT_CREDITS", 12, "SpentCredits");
    COMPLETED_TUTORIAL = new ConversionsAPIEventName("COMPLETED_TUTORIAL", 13, "TutorialCompletion");
    $VALUES = $values();
  }
  
  ConversionsAPIEventName(String paramString1) {
    this.rawValue = paramString1;
  }
  
  public final String getRawValue() {
    return this.rawValue;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\cloudbridge\ConversionsAPIEventName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */