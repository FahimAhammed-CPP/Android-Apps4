package com.facebook.appevents;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lcom/facebook/appevents/FlushResult;", "", "(Ljava/lang/String;I)V", "SUCCESS", "SERVER_ERROR", "NO_CONNECTIVITY", "UNKNOWN_ERROR", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public enum FlushResult {
  NO_CONNECTIVITY, SERVER_ERROR, SUCCESS, UNKNOWN_ERROR;
  
  static {
    SERVER_ERROR = new FlushResult("SERVER_ERROR", 1);
    NO_CONNECTIVITY = new FlushResult("NO_CONNECTIVITY", 2);
    UNKNOWN_ERROR = new FlushResult("UNKNOWN_ERROR", 3);
    $VALUES = $values();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\FlushResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */