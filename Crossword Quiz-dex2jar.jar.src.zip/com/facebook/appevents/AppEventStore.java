package com.facebook.appevents;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\030\020\006\032\0020\0072\006\020\b\032\0020\t2\006\020\n\032\0020\013H\007J\020\020\006\032\0020\0072\006\020\f\032\0020\rH\007R\026\020\003\032\n \005*\004\030\0010\0040\004X\004¢\006\002\n\000¨\006\016"}, d2 = {"Lcom/facebook/appevents/AppEventStore;", "", "()V", "TAG", "", "kotlin.jvm.PlatformType", "persistEvents", "", "accessTokenAppIdPair", "Lcom/facebook/appevents/AccessTokenAppIdPair;", "appEvents", "Lcom/facebook/appevents/SessionEventsState;", "eventsToPersist", "Lcom/facebook/appevents/AppEventCollection;", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class AppEventStore {
  public static final AppEventStore INSTANCE = new AppEventStore();
  
  private static final String TAG = AppEventStore.class.getName();
  
  @JvmStatic
  public static final void persistEvents(AccessTokenAppIdPair paramAccessTokenAppIdPair, SessionEventsState paramSessionEventsState) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'accessTokenAppIdPair'
    //   20: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_1
    //   24: ldc 'appEvents'
    //   26: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   29: getstatic com/facebook/appevents/internal/AppEventUtility.INSTANCE : Lcom/facebook/appevents/internal/AppEventUtility;
    //   32: astore_3
    //   33: invokestatic assertIsNotMainThread : ()V
    //   36: getstatic com/facebook/appevents/AppEventDiskStore.INSTANCE : Lcom/facebook/appevents/AppEventDiskStore;
    //   39: astore_3
    //   40: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   43: astore_3
    //   44: aload_3
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   50: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   53: getstatic com/facebook/appevents/AppEventDiskStore.INSTANCE : Lcom/facebook/appevents/AppEventDiskStore;
    //   56: astore_0
    //   57: aload_3
    //   58: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   61: ldc com/facebook/appevents/AppEventStore
    //   63: monitorexit
    //   64: return
    //   65: astore_0
    //   66: aload_0
    //   67: ldc com/facebook/appevents/AppEventStore
    //   69: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   72: ldc com/facebook/appevents/AppEventStore
    //   74: monitorexit
    //   75: return
    //   76: astore_0
    //   77: ldc com/facebook/appevents/AppEventStore
    //   79: monitorexit
    //   80: aload_0
    //   81: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	76	finally
    //   17	61	65	finally
    //   66	72	76	finally
  }
  
  @JvmStatic
  public static final void persistEvents(AppEventCollection paramAppEventCollection) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_1
    //   9: iload_1
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'eventsToPersist'
    //   20: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: getstatic com/facebook/appevents/internal/AppEventUtility.INSTANCE : Lcom/facebook/appevents/internal/AppEventUtility;
    //   26: astore_2
    //   27: invokestatic assertIsNotMainThread : ()V
    //   30: getstatic com/facebook/appevents/AppEventDiskStore.INSTANCE : Lcom/facebook/appevents/AppEventDiskStore;
    //   33: astore_2
    //   34: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   37: astore_2
    //   38: aload_0
    //   39: invokevirtual keySet : ()Ljava/util/Set;
    //   42: invokeinterface iterator : ()Ljava/util/Iterator;
    //   47: astore_3
    //   48: aload_3
    //   49: invokeinterface hasNext : ()Z
    //   54: ifeq -> 111
    //   57: aload_3
    //   58: invokeinterface next : ()Ljava/lang/Object;
    //   63: checkcast com/facebook/appevents/AccessTokenAppIdPair
    //   66: astore #4
    //   68: aload_0
    //   69: aload #4
    //   71: invokevirtual get : (Lcom/facebook/appevents/AccessTokenAppIdPair;)Lcom/facebook/appevents/SessionEventsState;
    //   74: astore #5
    //   76: aload #5
    //   78: ifnull -> 95
    //   81: aload_2
    //   82: aload #4
    //   84: aload #5
    //   86: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   89: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   92: goto -> 48
    //   95: new java/lang/IllegalStateException
    //   98: dup
    //   99: ldc 'Required value was null.'
    //   101: invokevirtual toString : ()Ljava/lang/String;
    //   104: invokespecial <init> : (Ljava/lang/String;)V
    //   107: checkcast java/lang/Throwable
    //   110: athrow
    //   111: getstatic com/facebook/appevents/AppEventDiskStore.INSTANCE : Lcom/facebook/appevents/AppEventDiskStore;
    //   114: astore_0
    //   115: aload_2
    //   116: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   119: ldc com/facebook/appevents/AppEventStore
    //   121: monitorexit
    //   122: return
    //   123: astore_0
    //   124: aload_0
    //   125: ldc com/facebook/appevents/AppEventStore
    //   127: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   130: ldc com/facebook/appevents/AppEventStore
    //   132: monitorexit
    //   133: return
    //   134: astore_0
    //   135: ldc com/facebook/appevents/AppEventStore
    //   137: monitorexit
    //   138: goto -> 143
    //   141: aload_0
    //   142: athrow
    //   143: goto -> 141
    // Exception table:
    //   from	to	target	type
    //   3	9	134	finally
    //   17	48	123	finally
    //   48	76	123	finally
    //   81	92	123	finally
    //   95	111	123	finally
    //   111	119	123	finally
    //   124	130	134	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\AppEventStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */