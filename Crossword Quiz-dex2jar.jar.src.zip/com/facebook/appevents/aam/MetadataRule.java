package com.facebook.appevents.aam;

import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\000\n\002\020\016\n\000\n\002\020 \n\002\b\t\b\007\030\000 \r2\0020\001:\001\rB%\b\002\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0030\005\022\006\020\006\032\0020\003¢\006\002\020\007R\031\020\004\032\b\022\004\022\0020\0030\0058F¢\006\b\n\000\032\004\b\b\020\tR\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\n\020\013R\021\020\006\032\0020\003¢\006\b\n\000\032\004\b\f\020\013¨\006\016"}, d2 = {"Lcom/facebook/appevents/aam/MetadataRule;", "", "name", "", "keyRules", "", "valRule", "(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V", "getKeyRules", "()Ljava/util/List;", "getName", "()Ljava/lang/String;", "getValRule", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class MetadataRule {
  public static final Companion Companion = new Companion(null);
  
  private static final String FIELD_K = "k";
  
  private static final String FIELD_K_DELIMITER = ",";
  
  private static final String FIELD_V = "v";
  
  private static final Set<MetadataRule> rules = new CopyOnWriteArraySet<MetadataRule>();
  
  private final List<String> keyRules;
  
  private final String name;
  
  private final String valRule;
  
  private MetadataRule(String paramString1, List<String> paramList, String paramString2) {
    this.name = paramString1;
    this.valRule = paramString2;
    this.keyRules = paramList;
  }
  
  @JvmStatic
  public static final Set<String> getEnabledRuleNames() {
    if (CrashShieldHandler.isObjectCrashing(MetadataRule.class))
      return null; 
    try {
      return Companion.getEnabledRuleNames();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, MetadataRule.class);
    } 
  }
  
  @JvmStatic
  public static final Set<MetadataRule> getRules() {
    if (CrashShieldHandler.isObjectCrashing(MetadataRule.class))
      return null; 
    try {
      return Companion.getRules();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, MetadataRule.class);
    } 
  }
  
  @JvmStatic
  public static final void updateRules(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(MetadataRule.class))
      return; 
    try {
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, MetadataRule.class);
    } 
  }
  
  public final List<String> getKeyRules() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return new ArrayList<String>(this.keyRules);
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public final String getName() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.name;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public final String getValRule() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.valRule;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\n\002\020#\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\"\n\002\b\004\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\n\032\0020\0132\006\020\f\032\0020\rH\002J\016\020\016\032\b\022\004\022\0020\0040\017H\007J\016\020\020\032\b\022\004\022\0020\t0\017H\007J\020\020\021\032\0020\0132\006\020\022\032\0020\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\024\020\007\032\b\022\004\022\0020\t0\bX\004¢\006\002\n\000¨\006\023"}, d2 = {"Lcom/facebook/appevents/aam/MetadataRule$Companion;", "", "()V", "FIELD_K", "", "FIELD_K_DELIMITER", "FIELD_V", "rules", "", "Lcom/facebook/appevents/aam/MetadataRule;", "constructRules", "", "jsonObject", "Lorg/json/JSONObject;", "getEnabledRuleNames", "", "getRules", "updateRules", "rulesFromServer", "facebook-core_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    private final void constructRules(JSONObject param1JSONObject) {
      Iterator<String> iterator = param1JSONObject.keys();
      while (iterator.hasNext()) {
        boolean bool;
        String str1 = iterator.next();
        JSONObject jSONObject = param1JSONObject.optJSONObject(str1);
        if (jSONObject == null)
          continue; 
        String str3 = jSONObject.optString("k");
        String str2 = jSONObject.optString("v");
        Intrinsics.checkNotNullExpressionValue(str3, "k");
        String str4 = str3;
        if (str4.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          continue; 
        Set<MetadataRule> set = MetadataRule.access$getRules$cp();
        Intrinsics.checkNotNullExpressionValue(str1, "key");
        List list = StringsKt.split$default(str4, new String[] { "," }, false, 0, 6, null);
        Intrinsics.checkNotNullExpressionValue(str2, "v");
        set.add(new MetadataRule(str1, list, str2, null));
      } 
    }
    
    @JvmStatic
    public final Set<String> getEnabledRuleNames() {
      HashSet<String> hashSet = new HashSet();
      Iterator<MetadataRule> iterator = MetadataRule.access$getRules$cp().iterator();
      while (iterator.hasNext())
        hashSet.add(((MetadataRule)iterator.next()).getName()); 
      return hashSet;
    }
    
    @JvmStatic
    public final Set<MetadataRule> getRules() {
      return new HashSet<MetadataRule>(MetadataRule.access$getRules$cp());
    }
    
    @JvmStatic
    public final void updateRules(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "rulesFromServer");
      try {
        MetadataRule.access$getRules$cp().clear();
        constructRules(new JSONObject(param1String));
        return;
      } catch (JSONException jSONException) {
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\appevents\aam\MetadataRule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */