package com.facebook.bolts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;

@Metadata(d1 = {"\000t\n\002\030\002\n\000\n\002\020\000\n\002\b\004\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\002\n\002\020!\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\020\002\n\002\b\006\n\002\020\t\n\000\n\002\030\002\n\002\b\004\030\000 @*\004\b\000\020\0012\0020\002:\003@ABB\007\b\020¢\006\002\020\003B\021\b\022\022\b\020\004\032\004\030\0018\000¢\006\002\020\005B\017\b\022\022\006\020\006\032\0020\007¢\006\002\020\bJ\022\020%\032\b\022\004\022\002H&0\000\"\004\b\001\020&J4\020'\032\b\022\004\022\0020\0210\0002\f\020(\032\b\022\004\022\0020\0070)2\030\020*\032\024\022\004\022\0020\021\022\n\022\b\022\004\022\0020\0210\0000\020J>\020'\032\b\022\004\022\0020\0210\0002\f\020(\032\b\022\004\022\0020\0070)2\030\020*\032\024\022\004\022\0020\021\022\n\022\b\022\004\022\0020\0210\0000\0202\b\020+\032\004\030\0010,JJ\020'\032\b\022\004\022\0020\0210\0002\f\020(\032\b\022\004\022\0020\0070)2\030\020*\032\024\022\004\022\0020\021\022\n\022\b\022\004\022\0020\0210\0000\0202\b\b\002\020-\032\0020.2\n\b\002\020+\032\004\030\0010,J&\020/\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\020J0\020/\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\b\020+\032\004\030\0010,J.\020/\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\006\020-\032\0020.J8\020/\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\006\020-\032\0020.2\b\020+\032\004\030\0010,J,\0201\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\020J6\0201\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\b\020+\032\004\030\0010,J4\0201\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\006\020-\032\0020.J>\0201\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\006\020-\032\0020.2\b\020+\032\004\030\0010,J\f\0202\032\b\022\004\022\0020\0210\000J&\0203\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\020J0\0203\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\b\020+\032\004\030\0010,J.\0203\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\006\020-\032\0020.J8\0203\032\b\022\004\022\002H00\000\"\004\b\001\02002\022\020*\032\016\022\004\022\0028\000\022\004\022\002H00\0202\006\020-\032\0020.2\b\020+\032\004\030\0010,J,\0204\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\020J6\0204\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\b\020+\032\004\030\0010,J4\0204\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\006\020-\032\0020.J>\0204\032\b\022\004\022\002H00\000\"\004\b\001\02002\030\020*\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\002H00\0000\0202\006\020-\032\0020.2\b\020+\032\004\030\0010,J\b\0205\032\00206H\002J\006\0207\032\0020\007J\026\0208\032\0020\0072\016\020\022\032\n\030\0010\023j\004\030\001`\024J\025\0209\032\0020\0072\b\020\004\032\004\030\0018\000¢\006\002\020:J\006\020;\032\00206J\026\020;\032\0020\0072\006\020<\032\0020=2\006\020>\032\0020?R\016\020\t\032\0020\007X\016¢\006\002\n\000R\016\020\n\032\0020\007X\016¢\006\002\n\000R\026\020\013\032\n \r*\004\030\0010\f0\fX\004¢\006\002\n\000R\"\020\016\032\026\022\020\022\016\022\004\022\0028\000\022\004\022\0020\0210\020\030\0010\017X\016¢\006\002\n\000R\031\020\022\032\n\030\0010\023j\004\030\001`\0248F¢\006\006\032\004\b\025\020\026R\026\020\027\032\n\030\0010\023j\004\030\001`\024X\016¢\006\002\n\000R\016\020\030\032\0020\007X\016¢\006\002\n\000R\021\020\031\032\0020\0078F¢\006\006\032\004\b\031\020\032R\021\020\033\032\0020\0078F¢\006\006\032\004\b\033\020\032R\021\020\034\032\0020\0078F¢\006\006\032\004\b\034\020\032R\016\020\035\032\0020\036X\004¢\006\002\n\000R\023\020\004\032\004\030\0018\0008F¢\006\006\032\004\b\037\020 R\022\020!\032\004\030\0018\000X\016¢\006\004\n\002\020\"R\020\020#\032\004\030\0010$X\016¢\006\002\n\000¨\006C"}, d2 = {"Lcom/facebook/bolts/Task;", "TResult", "", "()V", "result", "(Ljava/lang/Object;)V", "cancelled", "", "(Z)V", "cancelledField", "completeField", "condition", "Ljava/util/concurrent/locks/Condition;", "kotlin.jvm.PlatformType", "continuations", "", "Lcom/facebook/bolts/Continuation;", "Ljava/lang/Void;", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "getError", "()Ljava/lang/Exception;", "errorField", "errorHasBeenObserved", "isCancelled", "()Z", "isCompleted", "isFaulted", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "getResult", "()Ljava/lang/Object;", "resultField", "Ljava/lang/Object;", "unobservedErrorNotifier", "Lcom/facebook/bolts/UnobservedErrorNotifier;", "cast", "TOut", "continueWhile", "predicate", "Ljava/util/concurrent/Callable;", "continuation", "ct", "Lcom/facebook/bolts/CancellationToken;", "executor", "Ljava/util/concurrent/Executor;", "continueWith", "TContinuationResult", "continueWithTask", "makeVoid", "onSuccess", "onSuccessTask", "runContinuations", "", "trySetCancelled", "trySetError", "trySetResult", "(Ljava/lang/Object;)Z", "waitForCompletion", "duration", "", "timeUnit", "Ljava/util/concurrent/TimeUnit;", "Companion", "TaskCompletionSource", "UnobservedExceptionHandler", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class Task<TResult> {
  public static final ExecutorService BACKGROUND_EXECUTOR;
  
  public static final Companion Companion = new Companion(null);
  
  private static final Executor IMMEDIATE_EXECUTOR;
  
  private static final Task<?> TASK_CANCELLED;
  
  private static final Task<Boolean> TASK_FALSE;
  
  private static final Task<?> TASK_NULL;
  
  private static final Task<Boolean> TASK_TRUE;
  
  public static final Executor UI_THREAD_EXECUTOR;
  
  private static volatile UnobservedExceptionHandler unobservedExceptionHandler;
  
  private boolean cancelledField;
  
  private boolean completeField;
  
  private final Condition condition;
  
  private List<Continuation<TResult, Void>> continuations;
  
  private Exception errorField;
  
  private boolean errorHasBeenObserved;
  
  private final ReentrantLock lock;
  
  private TResult resultField;
  
  private UnobservedErrorNotifier unobservedErrorNotifier;
  
  static {
    BACKGROUND_EXECUTOR = BoltsExecutors.Companion.background();
    IMMEDIATE_EXECUTOR = BoltsExecutors.Companion.immediate$facebook_bolts_release();
    UI_THREAD_EXECUTOR = AndroidExecutors.Companion.uiThread();
    TASK_NULL = new Task(null);
    TASK_TRUE = new Task((TResult)Boolean.valueOf(true));
    TASK_FALSE = new Task((TResult)Boolean.valueOf(false));
    TASK_CANCELLED = new Task(true);
  }
  
  public Task() {
    ReentrantLock reentrantLock = new ReentrantLock();
    this.lock = reentrantLock;
    this.condition = reentrantLock.newCondition();
    this.continuations = new ArrayList<Continuation<TResult, Void>>();
  }
  
  private Task(TResult paramTResult) {
    ReentrantLock reentrantLock = new ReentrantLock();
    this.lock = reentrantLock;
    this.condition = reentrantLock.newCondition();
    this.continuations = new ArrayList<Continuation<TResult, Void>>();
    trySetResult(paramTResult);
  }
  
  private Task(boolean paramBoolean) {
    ReentrantLock reentrantLock = new ReentrantLock();
    this.lock = reentrantLock;
    this.condition = reentrantLock.newCondition();
    this.continuations = new ArrayList<Continuation<TResult, Void>>();
    if (paramBoolean) {
      trySetCancelled();
      return;
    } 
    trySetResult(null);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> call(Callable<TResult> paramCallable) {
    return Companion.call(paramCallable);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> call(Callable<TResult> paramCallable, CancellationToken paramCancellationToken) {
    return Companion.call(paramCallable, paramCancellationToken);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> call(Callable<TResult> paramCallable, Executor paramExecutor) {
    return Companion.call(paramCallable, paramExecutor);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> call(Callable<TResult> paramCallable, Executor paramExecutor, CancellationToken paramCancellationToken) {
    return Companion.call(paramCallable, paramExecutor, paramCancellationToken);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> callInBackground(Callable<TResult> paramCallable) {
    return Companion.callInBackground(paramCallable);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> callInBackground(Callable<TResult> paramCallable, CancellationToken paramCancellationToken) {
    return Companion.callInBackground(paramCallable, paramCancellationToken);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> cancelled() {
    return Companion.cancelled();
  }
  
  private static final Void continueWith$lambda-10$lambda-9(TaskCompletionSource paramTaskCompletionSource, Continuation paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken, Task paramTask) {
    Intrinsics.checkNotNullParameter(paramTaskCompletionSource, "$tcs");
    Intrinsics.checkNotNullParameter(paramContinuation, "$continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "$executor");
    Intrinsics.checkNotNullParameter(paramTask, "task");
    Companion.completeImmediately(paramTaskCompletionSource, paramContinuation, paramTask, paramExecutor, paramCancellationToken);
    return null;
  }
  
  private static final Void continueWithTask$lambda-12$lambda-11(TaskCompletionSource paramTaskCompletionSource, Continuation paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken, Task paramTask) {
    Intrinsics.checkNotNullParameter(paramTaskCompletionSource, "$tcs");
    Intrinsics.checkNotNullParameter(paramContinuation, "$continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "$executor");
    Intrinsics.checkNotNullParameter(paramTask, "task");
    Companion.completeAfterTask(paramTaskCompletionSource, paramContinuation, paramTask, paramExecutor, paramCancellationToken);
    return null;
  }
  
  @JvmStatic
  public static final Task<Void> delay(long paramLong) {
    return Companion.delay(paramLong);
  }
  
  @JvmStatic
  public static final Task<Void> delay(long paramLong, CancellationToken paramCancellationToken) {
    return Companion.delay(paramLong, paramCancellationToken);
  }
  
  @JvmStatic
  public static final Task<Void> delay$facebook_bolts_release(long paramLong, ScheduledExecutorService paramScheduledExecutorService, CancellationToken paramCancellationToken) {
    return Companion.delay$facebook_bolts_release(paramLong, paramScheduledExecutorService, paramCancellationToken);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> forError(Exception paramException) {
    return Companion.forError(paramException);
  }
  
  @JvmStatic
  public static final <TResult> Task<TResult> forResult(TResult paramTResult) {
    return Companion.forResult(paramTResult);
  }
  
  @JvmStatic
  public static final UnobservedExceptionHandler getUnobservedExceptionHandler() {
    return Companion.getUnobservedExceptionHandler();
  }
  
  private static final Task makeVoid$lambda-8(Task paramTask) {
    Intrinsics.checkNotNullParameter(paramTask, "task");
    return paramTask.isCancelled() ? Companion.cancelled() : (paramTask.isFaulted() ? Companion.forError(paramTask.getError()) : Companion.forResult(null));
  }
  
  private static final Task onSuccess$lambda-13(CancellationToken paramCancellationToken, Continuation paramContinuation, Task paramTask) {
    Intrinsics.checkNotNullParameter(paramContinuation, "$continuation");
    Intrinsics.checkNotNullParameter(paramTask, "task");
    return (paramCancellationToken != null && paramCancellationToken.isCancellationRequested()) ? Companion.cancelled() : (paramTask.isFaulted() ? Companion.forError(paramTask.getError()) : (paramTask.isCancelled() ? Companion.cancelled() : paramTask.continueWith(paramContinuation)));
  }
  
  private static final Task onSuccessTask$lambda-14(CancellationToken paramCancellationToken, Continuation paramContinuation, Task paramTask) {
    Intrinsics.checkNotNullParameter(paramContinuation, "$continuation");
    Intrinsics.checkNotNullParameter(paramTask, "task");
    return (paramCancellationToken != null && paramCancellationToken.isCancellationRequested()) ? Companion.cancelled() : (paramTask.isFaulted() ? Companion.forError(paramTask.getError()) : (paramTask.isCancelled() ? Companion.cancelled() : paramTask.continueWithTask(paramContinuation)));
  }
  
  private final void runContinuations() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      List<Continuation<TResult, Void>> list = this.continuations;
      if (list != null) {
        Iterator<Continuation<TResult, Void>> iterator = list.iterator();
        while (iterator.hasNext())
          Continuation continuation = iterator.next(); 
      } 
      this.continuations = null;
      Unit unit = Unit.INSTANCE;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  @JvmStatic
  public static final void setUnobservedExceptionHandler(UnobservedExceptionHandler paramUnobservedExceptionHandler) {
    Companion.setUnobservedExceptionHandler(paramUnobservedExceptionHandler);
  }
  
  @JvmStatic
  public static final Task<Void> whenAll(Collection<? extends Task<?>> paramCollection) {
    return Companion.whenAll(paramCollection);
  }
  
  @JvmStatic
  public static final <TResult> Task<List<TResult>> whenAllResult(Collection<Task<TResult>> paramCollection) {
    return Companion.whenAllResult(paramCollection);
  }
  
  @JvmStatic
  public static final Task<Task<?>> whenAny(Collection<? extends Task<?>> paramCollection) {
    return Companion.whenAny(paramCollection);
  }
  
  @JvmStatic
  public static final <TResult> Task<Task<TResult>> whenAnyResult(Collection<Task<TResult>> paramCollection) {
    return Companion.whenAnyResult(paramCollection);
  }
  
  public final <TOut> Task<TOut> cast() {
    return this;
  }
  
  public final Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation) {
    Intrinsics.checkNotNullParameter(paramCallable, "predicate");
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWhile(paramCallable, paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public final Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramCallable, "predicate");
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWhile(paramCallable, paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public final Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramCallable, "predicate");
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    Task$continueWhile$predicateContinuation$1 task$continueWhile$predicateContinuation$1 = new Task$continueWhile$predicateContinuation$1(paramCancellationToken, paramCallable, paramContinuation, paramExecutor);
    return makeVoid().continueWithTask(task$continueWhile$predicateContinuation$1, paramExecutor);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWith(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWith(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return continueWith(paramContinuation, paramExecutor, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool = isCompleted();
      if (!bool) {
        List<Continuation<TResult, Void>> list = this.continuations;
        if (list != null)
          list.add(new Task$.ExternalSyntheticLambda2(taskCompletionSource, paramContinuation, paramExecutor, paramCancellationToken)); 
      } 
      Unit unit = Unit.INSTANCE;
      reentrantLock.unlock();
      return taskCompletionSource.getTask();
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWithTask(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return continueWithTask(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return continueWithTask(paramContinuation, paramExecutor, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool = isCompleted();
      if (!bool) {
        List<Continuation<TResult, Void>> list = this.continuations;
        if (list != null)
          list.add(new Task$.ExternalSyntheticLambda3(taskCompletionSource, paramContinuation, paramExecutor, paramCancellationToken)); 
      } 
      Unit unit = Unit.INSTANCE;
      reentrantLock.unlock();
      return taskCompletionSource.getTask();
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final Exception getError() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (this.errorField != null) {
        this.errorHasBeenObserved = true;
        UnobservedErrorNotifier unobservedErrorNotifier = this.unobservedErrorNotifier;
        if (unobservedErrorNotifier != null) {
          unobservedErrorNotifier.setObserved();
          this.unobservedErrorNotifier = null;
        } 
      } 
      return this.errorField;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final TResult getResult() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      return this.resultField;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean isCancelled() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      return this.cancelledField;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean isCompleted() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      return this.completeField;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean isFaulted() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool;
      Exception exception = this.errorField;
      if (exception != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final Task<Void> makeVoid() {
    return continueWithTask((Continuation<?, Task<Void>>)Task$.ExternalSyntheticLambda4.INSTANCE);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return onSuccess(paramContinuation, IMMEDIATE_EXECUTOR, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return onSuccess(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return onSuccess(paramContinuation, paramExecutor, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return continueWithTask((Continuation<?, Task<TContinuationResult>>)new Task$.ExternalSyntheticLambda0(paramCancellationToken, paramContinuation), paramExecutor);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return onSuccessTask(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    return onSuccessTask(paramContinuation, IMMEDIATE_EXECUTOR, paramCancellationToken);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return onSuccessTask(paramContinuation, paramExecutor, null);
  }
  
  public final <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation, Executor paramExecutor, CancellationToken paramCancellationToken) {
    Intrinsics.checkNotNullParameter(paramContinuation, "continuation");
    Intrinsics.checkNotNullParameter(paramExecutor, "executor");
    return continueWithTask((Continuation<?, Task<TContinuationResult>>)new Task$.ExternalSyntheticLambda1(paramCancellationToken, paramContinuation), paramExecutor);
  }
  
  public final boolean trySetCancelled() {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool = this.completeField;
      if (bool)
        return false; 
      this.completeField = true;
      this.cancelledField = true;
      this.condition.signalAll();
      runContinuations();
      return true;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean trySetError(Exception paramException) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool = this.completeField;
      if (bool)
        return false; 
      this.completeField = true;
      this.errorField = paramException;
      this.errorHasBeenObserved = false;
      this.condition.signalAll();
      runContinuations();
      if (!this.errorHasBeenObserved && unobservedExceptionHandler != null)
        this.unobservedErrorNotifier = new UnobservedErrorNotifier(this); 
      return true;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean trySetResult(TResult paramTResult) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      boolean bool = this.completeField;
      if (bool)
        return false; 
      this.completeField = true;
      this.resultField = paramTResult;
      this.condition.signalAll();
      runContinuations();
      return true;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void waitForCompletion() throws InterruptedException {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (!isCompleted())
        this.condition.await(); 
      Unit unit = Unit.INSTANCE;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final boolean waitForCompletion(long paramLong, TimeUnit paramTimeUnit) throws InterruptedException {
    Intrinsics.checkNotNullParameter(paramTimeUnit, "timeUnit");
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (!isCompleted())
        this.condition.await(paramLong, paramTimeUnit); 
      return isCompleted();
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  @Metadata(d1 = {"\000~\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\t\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\036\n\000\n\002\020 \n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J$\020\020\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\023H\007J.\020\020\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\0232\b\020\024\032\004\030\0010\025H\007J,\020\020\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\0232\006\020\026\032\0020\006H\007J6\020\020\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\0232\006\020\026\032\0020\0062\b\020\024\032\004\030\0010\025H\007J$\020\027\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\023H\007J.\020\027\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020\022\032\n\022\006\022\004\030\001H\0210\0232\b\020\024\032\004\030\0010\025H\007J\024\020\030\032\b\022\004\022\002H\0210\b\"\004\b\001\020\021H\007J\\\020\031\032\0020\032\"\004\b\001\020\033\"\004\b\002\020\0212\f\020\034\032\b\022\004\022\002H\0330\0352\030\020\036\032\024\022\004\022\002H\021\022\n\022\b\022\004\022\002H\0330\b0\0372\f\020 \032\b\022\004\022\002H\0210\b2\006\020\026\032\0020\0062\b\020\024\032\004\030\0010\025H\002JV\020!\032\0020\032\"\004\b\001\020\033\"\004\b\002\020\0212\f\020\034\032\b\022\004\022\002H\0330\0352\022\020\036\032\016\022\004\022\002H\021\022\004\022\002H\0330\0372\f\020 \032\b\022\004\022\002H\0210\b2\006\020\026\032\0020\0062\b\020\024\032\004\030\0010\025H\002J\030\020\"\032\n\022\006\022\004\030\0010#0\b2\006\020\"\032\0020$H\007J\"\020\"\032\n\022\006\022\004\030\0010#0\b2\006\020\"\032\0020$2\b\020%\032\004\030\0010\025H\007J/\020\"\032\n\022\006\022\004\030\0010#0\b2\006\020\"\032\0020$2\006\020\026\032\0020&2\b\020%\032\004\030\0010\025H\001¢\006\002\b'J$\020(\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\016\020)\032\n\030\0010*j\004\030\001`+H\007J#\020,\032\b\022\004\022\002H\0210\b\"\004\b\001\020\0212\b\020-\032\004\030\001H\021H\007¢\006\002\020.J\n\020/\032\004\030\0010\017H\007J\022\0200\032\0020\0322\b\0201\032\004\030\0010\017H\007J \0202\032\b\022\004\022\0020#0\b2\020\0203\032\f\022\b\022\006\022\002\b\0030\b04H\007J0\0205\032\020\022\f\022\n\022\006\022\004\030\001H\021060\b\"\004\b\001\020\0212\022\0203\032\016\022\n\022\b\022\004\022\002H\0210\b04H\007J$\0207\032\f\022\b\022\006\022\002\b\0030\b0\b2\020\0203\032\f\022\b\022\006\022\002\b\0030\b04H\007J.\0208\032\016\022\n\022\b\022\004\022\002H\0210\b0\b\"\004\b\001\020\0212\022\0203\032\016\022\n\022\b\022\004\022\002H\0210\b04H\007R\020\020\003\032\0020\0048\006X\004¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000R\022\020\007\032\006\022\002\b\0030\bX\004¢\006\002\n\000R\024\020\t\032\b\022\004\022\0020\n0\bX\004¢\006\002\n\000R\022\020\013\032\006\022\002\b\0030\bX\004¢\006\002\n\000R\024\020\f\032\b\022\004\022\0020\n0\bX\004¢\006\002\n\000R\020\020\r\032\0020\0068\006X\004¢\006\002\n\000R\020\020\016\032\004\030\0010\017X\016¢\006\002\n\000¨\0069"}, d2 = {"Lcom/facebook/bolts/Task$Companion;", "", "()V", "BACKGROUND_EXECUTOR", "Ljava/util/concurrent/ExecutorService;", "IMMEDIATE_EXECUTOR", "Ljava/util/concurrent/Executor;", "TASK_CANCELLED", "Lcom/facebook/bolts/Task;", "TASK_FALSE", "", "TASK_NULL", "TASK_TRUE", "UI_THREAD_EXECUTOR", "unobservedExceptionHandler", "Lcom/facebook/bolts/Task$UnobservedExceptionHandler;", "call", "TResult", "callable", "Ljava/util/concurrent/Callable;", "ct", "Lcom/facebook/bolts/CancellationToken;", "executor", "callInBackground", "cancelled", "completeAfterTask", "", "TContinuationResult", "tcs", "Lcom/facebook/bolts/TaskCompletionSource;", "continuation", "Lcom/facebook/bolts/Continuation;", "task", "completeImmediately", "delay", "Ljava/lang/Void;", "", "cancellationToken", "Ljava/util/concurrent/ScheduledExecutorService;", "delay$facebook_bolts_release", "forError", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "forResult", "value", "(Ljava/lang/Object;)Lcom/facebook/bolts/Task;", "getUnobservedExceptionHandler", "setUnobservedExceptionHandler", "eh", "whenAll", "tasks", "", "whenAllResult", "", "whenAny", "whenAnyResult", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    private static final void call$lambda-2(CancellationToken param1CancellationToken, TaskCompletionSource param1TaskCompletionSource, Callable param1Callable) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      Intrinsics.checkNotNullParameter(param1Callable, "$callable");
      if (param1CancellationToken != null && param1CancellationToken.isCancellationRequested()) {
        param1TaskCompletionSource.setCancelled();
        return;
      } 
      try {
        param1TaskCompletionSource.setResult(param1Callable.call());
        return;
      } catch (CancellationException cancellationException) {
        param1TaskCompletionSource.setCancelled();
        return;
      } catch (Exception exception) {
        param1TaskCompletionSource.setError(exception);
        return;
      } 
    }
    
    private final <TContinuationResult, TResult> void completeAfterTask(TaskCompletionSource<TContinuationResult> param1TaskCompletionSource, Continuation<TResult, Task<TContinuationResult>> param1Continuation, Task<TResult> param1Task, Executor param1Executor, CancellationToken param1CancellationToken) {
      try {
        param1Executor.execute((Runnable)new Task$Companion$.ExternalSyntheticLambda3(param1CancellationToken, param1TaskCompletionSource, param1Continuation, param1Task));
        return;
      } catch (Exception exception) {
        param1TaskCompletionSource.setError((Exception)new ExecutorException(exception));
        return;
      } 
    }
    
    private static final void completeAfterTask$lambda-7(CancellationToken param1CancellationToken, TaskCompletionSource param1TaskCompletionSource, Continuation param1Continuation, Task param1Task) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      Intrinsics.checkNotNullParameter(param1Continuation, "$continuation");
      Intrinsics.checkNotNullParameter(param1Task, "$task");
      if (param1CancellationToken != null && param1CancellationToken.isCancellationRequested()) {
        param1TaskCompletionSource.setCancelled();
        return;
      } 
      try {
        Task task = (Task)param1Continuation.then(param1Task);
        if (task == null) {
          param1TaskCompletionSource.setResult(null);
          return;
        } 
        task.continueWith((Continuation)new Task$Companion$.ExternalSyntheticLambda0(param1CancellationToken, param1TaskCompletionSource));
        return;
      } catch (CancellationException cancellationException) {
        param1TaskCompletionSource.setCancelled();
        return;
      } catch (Exception exception) {
        param1TaskCompletionSource.setError(exception);
        return;
      } 
    }
    
    private static final Void completeAfterTask$lambda-7$lambda-6(CancellationToken param1CancellationToken, TaskCompletionSource param1TaskCompletionSource, Task param1Task) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      Intrinsics.checkNotNullParameter(param1Task, "task");
      if (param1CancellationToken != null && param1CancellationToken.isCancellationRequested()) {
        param1TaskCompletionSource.setCancelled();
        return null;
      } 
      if (param1Task.isCancelled()) {
        param1TaskCompletionSource.setCancelled();
        return null;
      } 
      if (param1Task.isFaulted()) {
        param1TaskCompletionSource.setError(param1Task.getError());
        return null;
      } 
      param1TaskCompletionSource.setResult(param1Task.getResult());
      return null;
    }
    
    private final <TContinuationResult, TResult> void completeImmediately(TaskCompletionSource<TContinuationResult> param1TaskCompletionSource, Continuation<TResult, TContinuationResult> param1Continuation, Task<TResult> param1Task, Executor param1Executor, CancellationToken param1CancellationToken) {
      try {
        param1Executor.execute((Runnable)new Task$Companion$.ExternalSyntheticLambda4(param1CancellationToken, param1TaskCompletionSource, param1Continuation, param1Task));
        return;
      } catch (Exception exception) {
        param1TaskCompletionSource.setError((Exception)new ExecutorException(exception));
        return;
      } 
    }
    
    private static final void completeImmediately$lambda-5(CancellationToken param1CancellationToken, TaskCompletionSource param1TaskCompletionSource, Continuation param1Continuation, Task param1Task) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      Intrinsics.checkNotNullParameter(param1Continuation, "$continuation");
      Intrinsics.checkNotNullParameter(param1Task, "$task");
      if (param1CancellationToken != null && param1CancellationToken.isCancellationRequested()) {
        param1TaskCompletionSource.setCancelled();
        return;
      } 
      try {
        param1TaskCompletionSource.setResult(param1Continuation.then(param1Task));
        return;
      } catch (CancellationException cancellationException) {
        param1TaskCompletionSource.setCancelled();
        return;
      } catch (Exception exception) {
        param1TaskCompletionSource.setError(exception);
        return;
      } 
    }
    
    private static final void delay$lambda-0(TaskCompletionSource param1TaskCompletionSource) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      param1TaskCompletionSource.trySetResult(null);
    }
    
    private static final void delay$lambda-1(ScheduledFuture param1ScheduledFuture, TaskCompletionSource param1TaskCompletionSource) {
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$tcs");
      param1ScheduledFuture.cancel(true);
      param1TaskCompletionSource.trySetCancelled();
    }
    
    private static final Void whenAny$lambda-4(AtomicBoolean param1AtomicBoolean, TaskCompletionSource param1TaskCompletionSource, Task param1Task) {
      Intrinsics.checkNotNullParameter(param1AtomicBoolean, "$isAnyTaskComplete");
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$firstCompleted");
      Intrinsics.checkNotNullParameter(param1Task, "it");
      if (param1AtomicBoolean.compareAndSet(false, true)) {
        param1TaskCompletionSource.setResult(param1Task);
      } else {
        param1Task.getError();
      } 
      return null;
    }
    
    private static final Void whenAnyResult$lambda-3(AtomicBoolean param1AtomicBoolean, TaskCompletionSource param1TaskCompletionSource, Task param1Task) {
      Intrinsics.checkNotNullParameter(param1AtomicBoolean, "$isAnyTaskComplete");
      Intrinsics.checkNotNullParameter(param1TaskCompletionSource, "$firstCompleted");
      Intrinsics.checkNotNullParameter(param1Task, "it");
      if (param1AtomicBoolean.compareAndSet(false, true)) {
        param1TaskCompletionSource.setResult(param1Task);
      } else {
        param1Task.getError();
      } 
      return null;
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> call(Callable<TResult> param1Callable) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      return call(param1Callable, Task.IMMEDIATE_EXECUTOR, null);
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> call(Callable<TResult> param1Callable, CancellationToken param1CancellationToken) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      return call(param1Callable, Task.IMMEDIATE_EXECUTOR, param1CancellationToken);
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> call(Callable<TResult> param1Callable, Executor param1Executor) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      Intrinsics.checkNotNullParameter(param1Executor, "executor");
      return call(param1Callable, param1Executor, null);
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> call(Callable<TResult> param1Callable, Executor param1Executor, CancellationToken param1CancellationToken) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      Intrinsics.checkNotNullParameter(param1Executor, "executor");
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      try {
        param1Executor.execute((Runnable)new Task$Companion$.ExternalSyntheticLambda5(param1CancellationToken, taskCompletionSource, param1Callable));
      } catch (Exception exception) {
        taskCompletionSource.setError((Exception)new ExecutorException(exception));
      } 
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> callInBackground(Callable<TResult> param1Callable) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      return call(param1Callable, Task.BACKGROUND_EXECUTOR, null);
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> callInBackground(Callable<TResult> param1Callable, CancellationToken param1CancellationToken) {
      Intrinsics.checkNotNullParameter(param1Callable, "callable");
      return call(param1Callable, Task.BACKGROUND_EXECUTOR, param1CancellationToken);
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> cancelled() {
      return (Task)Task.TASK_CANCELLED;
    }
    
    @JvmStatic
    public final Task<Void> delay(long param1Long) {
      return delay$facebook_bolts_release(param1Long, BoltsExecutors.Companion.scheduled$facebook_bolts_release(), null);
    }
    
    @JvmStatic
    public final Task<Void> delay(long param1Long, CancellationToken param1CancellationToken) {
      return delay$facebook_bolts_release(param1Long, BoltsExecutors.Companion.scheduled$facebook_bolts_release(), param1CancellationToken);
    }
    
    @JvmStatic
    public final Task<Void> delay$facebook_bolts_release(long param1Long, ScheduledExecutorService param1ScheduledExecutorService, CancellationToken param1CancellationToken) {
      Intrinsics.checkNotNullParameter(param1ScheduledExecutorService, "executor");
      if (param1CancellationToken != null && param1CancellationToken.isCancellationRequested())
        return cancelled(); 
      if (param1Long <= 0L)
        return forResult(null); 
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      ScheduledFuture<?> scheduledFuture = param1ScheduledExecutorService.schedule((Runnable)new Task$Companion$.ExternalSyntheticLambda6(taskCompletionSource), param1Long, TimeUnit.MILLISECONDS);
      if (param1CancellationToken != null)
        param1CancellationToken.register((Runnable)new Task$Companion$.ExternalSyntheticLambda7(scheduledFuture, taskCompletionSource)); 
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> forError(Exception param1Exception) {
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      taskCompletionSource.setError(param1Exception);
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final <TResult> Task<TResult> forResult(TResult param1TResult) {
      if (param1TResult == null)
        return (Task)Task.TASK_NULL; 
      if (param1TResult instanceof Boolean)
        return ((Boolean)param1TResult).booleanValue() ? Task.TASK_TRUE : Task.TASK_FALSE; 
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      taskCompletionSource.setResult(param1TResult);
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final Task.UnobservedExceptionHandler getUnobservedExceptionHandler() {
      return Task.unobservedExceptionHandler;
    }
    
    @JvmStatic
    public final void setUnobservedExceptionHandler(Task.UnobservedExceptionHandler param1UnobservedExceptionHandler) {
      Task.unobservedExceptionHandler = param1UnobservedExceptionHandler;
    }
    
    @JvmStatic
    public final Task<Void> whenAll(Collection<? extends Task<?>> param1Collection) {
      Intrinsics.checkNotNullParameter(param1Collection, "tasks");
      if (param1Collection.isEmpty())
        return forResult(null); 
      TaskCompletionSource<Void> taskCompletionSource = new TaskCompletionSource();
      ArrayList<Exception> arrayList = new ArrayList();
      ReentrantLock reentrantLock = new ReentrantLock();
      AtomicInteger atomicInteger = new AtomicInteger(param1Collection.size());
      AtomicBoolean atomicBoolean = new AtomicBoolean(false);
      Iterator<? extends Task<?>> iterator = param1Collection.iterator();
      while (iterator.hasNext())
        ((Task)iterator.next()).continueWith(new Task$Companion$whenAll$1<Object, Object>(reentrantLock, atomicBoolean, atomicInteger, arrayList, taskCompletionSource)); 
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final <TResult> Task<List<TResult>> whenAllResult(Collection<Task<TResult>> param1Collection) {
      Intrinsics.checkNotNullParameter(param1Collection, "tasks");
      return whenAll(param1Collection).onSuccess(new Task$Companion$whenAllResult$1(param1Collection));
    }
    
    @JvmStatic
    public final Task<Task<?>> whenAny(Collection<? extends Task<?>> param1Collection) {
      Intrinsics.checkNotNullParameter(param1Collection, "tasks");
      if (param1Collection.isEmpty())
        return forResult(null); 
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      AtomicBoolean atomicBoolean = new AtomicBoolean(false);
      Iterator<? extends Task<?>> iterator = param1Collection.iterator();
      while (iterator.hasNext())
        ((Task)iterator.next()).continueWith((Continuation)new Task$Companion$.ExternalSyntheticLambda2(atomicBoolean, taskCompletionSource)); 
      return taskCompletionSource.getTask();
    }
    
    @JvmStatic
    public final <TResult> Task<Task<TResult>> whenAnyResult(Collection<Task<TResult>> param1Collection) {
      Intrinsics.checkNotNullParameter(param1Collection, "tasks");
      if (param1Collection.isEmpty())
        return forResult(null); 
      TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
      AtomicBoolean atomicBoolean = new AtomicBoolean(false);
      Iterator<Task<TResult>> iterator = param1Collection.iterator();
      while (iterator.hasNext())
        ((Task)iterator.next()).continueWith((Continuation)new Task$Companion$.ExternalSyntheticLambda1(atomicBoolean, taskCompletionSource)); 
      return taskCompletionSource.getTask();
    }
    
    @Metadata(d1 = {"\000\022\n\000\n\002\020\001\n\002\b\002\n\002\030\002\n\002\020\000\020\000\032\004\030\0010\001\"\004\b\000\020\0022\f\020\003\032\b\022\004\022\0020\0050\004H\n"}, d2 = {"<anonymous>", "", "TResult", "it", "Lcom/facebook/bolts/Task;", ""}, k = 3, mv = {1, 5, 1}, xi = 48)
    static final class Task$Companion$whenAll$1<TTaskResult, TContinuationResult> implements Continuation {
      Task$Companion$whenAll$1(ReentrantLock param2ReentrantLock, AtomicBoolean param2AtomicBoolean, AtomicInteger param2AtomicInteger, ArrayList<Exception> param2ArrayList, TaskCompletionSource<Void> param2TaskCompletionSource) {}
      
      public final Void then(Task<Object> param2Task) {
        Intrinsics.checkNotNullParameter(param2Task, "it");
        if (param2Task.isFaulted()) {
          ReentrantLock reentrantLock = this.$errorLock;
          ArrayList<Exception> arrayList = this.$causes;
          reentrantLock.lock();
          try {
            arrayList.add(param2Task.getError());
          } finally {
            reentrantLock.unlock();
          } 
        } 
        if (param2Task.isCancelled())
          this.$isCancelled.set(true); 
        if (this.$count.decrementAndGet() == 0) {
          if (this.$causes.size() != 0) {
            if (this.$causes.size() == 1) {
              this.$allFinished.setError(this.$causes.get(0));
              return null;
            } 
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String str = String.format("There were %d exceptions.", Arrays.copyOf(new Object[] { Integer.valueOf(this.$causes.size()) }, 1));
            Intrinsics.checkNotNullExpressionValue(str, "java.lang.String.format(format, *args)");
            Exception exception = (Exception)new AggregateException(str, this.$causes);
            this.$allFinished.setError(exception);
            return null;
          } 
          if (this.$isCancelled.get()) {
            this.$allFinished.setCancelled();
            return null;
          } 
          this.$allFinished.setResult(null);
        } 
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\030\002\n\002\020 \n\002\b\002\n\002\030\002\n\000*\001\000\b\n\030\0002\026\022\004\022\0020\002\022\f\022\n\022\006\022\004\030\0018\0000\0030\001J\036\020\004\032\n\022\006\022\004\030\0018\0000\0032\f\020\005\032\b\022\004\022\0020\0020\006H\026¨\006\007"}, d2 = {"com/facebook/bolts/Task$Companion$whenAllResult$1", "Lcom/facebook/bolts/Continuation;", "Ljava/lang/Void;", "", "then", "task", "Lcom/facebook/bolts/Task;", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class Task$Companion$whenAllResult$1 implements Continuation<Void, List<? extends TResult>> {
      Task$Companion$whenAllResult$1(Collection<Task<TResult>> param2Collection) {}
      
      public List<TResult> then(Task<Void> param2Task) {
        Intrinsics.checkNotNullParameter(param2Task, "task");
        if (this.$tasks.isEmpty())
          return CollectionsKt.emptyList(); 
        ArrayList<TResult> arrayList = new ArrayList();
        Iterator<Task<TResult>> iterator = this.$tasks.iterator();
        while (iterator.hasNext())
          arrayList.add(((Task)iterator.next()).getResult()); 
        return arrayList;
      }
    }
  }
  
  @Metadata(d1 = {"\000\022\n\000\n\002\020\001\n\002\b\002\n\002\030\002\n\002\020\000\020\000\032\004\030\0010\001\"\004\b\000\020\0022\f\020\003\032\b\022\004\022\0020\0050\004H\n"}, d2 = {"<anonymous>", "", "TResult", "it", "Lcom/facebook/bolts/Task;", ""}, k = 3, mv = {1, 5, 1}, xi = 48)
  static final class Task$Companion$whenAll$1<TTaskResult, TContinuationResult> implements Continuation {
    Task$Companion$whenAll$1(ReentrantLock param1ReentrantLock, AtomicBoolean param1AtomicBoolean, AtomicInteger param1AtomicInteger, ArrayList<Exception> param1ArrayList, TaskCompletionSource<Void> param1TaskCompletionSource) {}
    
    public final Void then(Task<Object> param1Task) {
      Intrinsics.checkNotNullParameter(param1Task, "it");
      if (param1Task.isFaulted()) {
        ReentrantLock reentrantLock = this.$errorLock;
        ArrayList<Exception> arrayList = this.$causes;
        reentrantLock.lock();
        try {
          arrayList.add(param1Task.getError());
        } finally {
          reentrantLock.unlock();
        } 
      } 
      if (param1Task.isCancelled())
        this.$isCancelled.set(true); 
      if (this.$count.decrementAndGet() == 0) {
        if (this.$causes.size() != 0) {
          if (this.$causes.size() == 1) {
            this.$allFinished.setError(this.$causes.get(0));
            return null;
          } 
          StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
          String str = String.format("There were %d exceptions.", Arrays.copyOf(new Object[] { Integer.valueOf(this.$causes.size()) }, 1));
          Intrinsics.checkNotNullExpressionValue(str, "java.lang.String.format(format, *args)");
          Exception exception = (Exception)new AggregateException(str, this.$causes);
          this.$allFinished.setError(exception);
          return null;
        } 
        if (this.$isCancelled.get()) {
          this.$allFinished.setCancelled();
          return null;
        } 
        this.$allFinished.setResult(null);
      } 
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\030\002\n\002\020 \n\002\b\002\n\002\030\002\n\000*\001\000\b\n\030\0002\026\022\004\022\0020\002\022\f\022\n\022\006\022\004\030\0018\0000\0030\001J\036\020\004\032\n\022\006\022\004\030\0018\0000\0032\f\020\005\032\b\022\004\022\0020\0020\006H\026¨\006\007"}, d2 = {"com/facebook/bolts/Task$Companion$whenAllResult$1", "Lcom/facebook/bolts/Continuation;", "Ljava/lang/Void;", "", "then", "task", "Lcom/facebook/bolts/Task;", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Task$Companion$whenAllResult$1 implements Continuation<Void, List<? extends TResult>> {
    Task$Companion$whenAllResult$1(Collection<Task<TResult>> param1Collection) {}
    
    public List<TResult> then(Task<Void> param1Task) {
      Intrinsics.checkNotNullParameter(param1Task, "task");
      if (this.$tasks.isEmpty())
        return CollectionsKt.emptyList(); 
      ArrayList<TResult> arrayList = new ArrayList();
      Iterator<Task<TResult>> iterator = this.$tasks.iterator();
      while (iterator.hasNext())
        arrayList.add(((Task)iterator.next()).getResult()); 
      return arrayList;
    }
  }
  
  @Deprecated(message = "Please use [TaskCompletionSource] instead. ")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\b\004\030\0002\b\022\004\022\0028\0000\001B\007\b\000¢\006\002\020\002¨\006\003"}, d2 = {"Lcom/facebook/bolts/Task$TaskCompletionSource;", "Lcom/facebook/bolts/TaskCompletionSource;", "(Lcom/facebook/bolts/Task;)V", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public final class TaskCompletionSource extends TaskCompletionSource<TResult> {}
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\034\020\002\032\0020\0032\n\020\004\032\006\022\002\b\0030\0052\006\020\006\032\0020\007H&¨\006\b"}, d2 = {"Lcom/facebook/bolts/Task$UnobservedExceptionHandler;", "", "unobservedException", "", "t", "Lcom/facebook/bolts/Task;", "e", "Lcom/facebook/bolts/UnobservedTaskException;", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static interface UnobservedExceptionHandler {
    void unobservedException(Task<?> param1Task, UnobservedTaskException param1UnobservedTaskException);
  }
  
  @Metadata(d1 = {"\000\025\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\024\022\004\022\0020\002\022\n\022\b\022\004\022\0020\0020\0030\001J\034\020\004\032\b\022\004\022\0020\0020\0032\f\020\005\032\b\022\004\022\0020\0020\003H\026¨\006\006"}, d2 = {"com/facebook/bolts/Task$continueWhile$predicateContinuation$1", "Lcom/facebook/bolts/Continuation;", "Ljava/lang/Void;", "Lcom/facebook/bolts/Task;", "then", "task", "facebook-bolts_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Task$continueWhile$predicateContinuation$1 implements Continuation<Void, Task<Void>> {
    Task$continueWhile$predicateContinuation$1(CancellationToken param1CancellationToken, Callable<Boolean> param1Callable, Continuation<Void, Task<Void>> param1Continuation, Executor param1Executor) {}
    
    public Task<Void> then(Task<Void> param1Task) throws Exception {
      Intrinsics.checkNotNullParameter(param1Task, "task");
      CancellationToken cancellationToken = this.$ct;
      if (cancellationToken != null && cancellationToken.isCancellationRequested())
        return Task.Companion.cancelled(); 
      cancellationToken = (CancellationToken)this.$predicate.call();
      Intrinsics.checkNotNullExpressionValue(cancellationToken, "predicate.call()");
      return ((Boolean)cancellationToken).booleanValue() ? Task.Companion.<Void>forResult(null).<Void>onSuccessTask(this.$continuation, this.$executor).onSuccessTask(this, this.$executor) : Task.Companion.forResult(null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\bolts\Task.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */