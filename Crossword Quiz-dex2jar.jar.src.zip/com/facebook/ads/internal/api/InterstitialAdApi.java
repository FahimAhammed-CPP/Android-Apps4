package com.facebook.ads.internal.api;

import com.facebook.ads.ExtraHints;
import com.facebook.ads.FullScreenAd;
import com.facebook.ads.InterstitialAd;

public interface InterstitialAdApi extends FullScreenAd {
  InterstitialAd.InterstitialAdLoadConfigBuilder buildLoadAdConfig();
  
  InterstitialAd.InterstitialAdShowConfigBuilder buildShowAdConfig();
  
  boolean isAdLoaded();
  
  void loadAd(InterstitialAd.InterstitialLoadAdConfig paramInterstitialLoadAdConfig);
  
  void registerAdCompanionView(AdCompanionView paramAdCompanionView);
  
  @Deprecated
  void setExtraHints(ExtraHints paramExtraHints);
  
  boolean show();
  
  boolean show(InterstitialAd.InterstitialShowAdConfig paramInterstitialShowAdConfig);
  
  void unregisterAdCompanionView();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\facebook\ads\internal\api\InterstitialAdApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */