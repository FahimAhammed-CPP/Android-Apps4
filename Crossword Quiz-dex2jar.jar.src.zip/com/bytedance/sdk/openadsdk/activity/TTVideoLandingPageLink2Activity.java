package com.bytedance.sdk.openadsdk.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bykv.vk.openvk.component.video.api.d.c;
import com.bytedance.sdk.component.utils.t;
import com.bytedance.sdk.openadsdk.TTAdSdk;
import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.c.h;
import com.bytedance.sdk.openadsdk.common.LandingPageLoadingLayout;
import com.bytedance.sdk.openadsdk.common.g;
import com.bytedance.sdk.openadsdk.core.k;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.core.u;
import com.bytedance.sdk.openadsdk.core.video.nativevideo.c;
import com.bytedance.sdk.openadsdk.core.widget.TTRoundRectImageView;
import com.bytedance.sdk.openadsdk.core.widget.a.c;
import com.bytedance.sdk.openadsdk.core.widget.a.d;
import com.bytedance.sdk.openadsdk.f.d;
import com.bytedance.sdk.openadsdk.i.d;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;

public class TTVideoLandingPageLink2Activity extends TTVideoLandingPageActivity implements d {
  private LandingPageLoadingLayout R;
  
  private View S;
  
  private View T;
  
  private boolean U;
  
  private TextView V;
  
  private TextView W;
  
  private TextView X;
  
  private TextView Y;
  
  private TTRoundRectImageView Z;
  
  private TextView aa;
  
  private TextView ab;
  
  private long ac;
  
  private boolean ad = false;
  
  private boolean ae;
  
  private g af;
  
  private LinearLayout ag;
  
  private void a(String paramString) {
    c.a(this.e, this.p, "landingpage_split_screen", paramString, null);
  }
  
  private void m() {
    LandingPageLoadingLayout landingPageLoadingLayout = this.R;
    if (landingPageLoadingLayout != null)
      landingPageLoadingLayout.b(); 
  }
  
  protected String a() {
    return "tt_activity_videolandingpage_link2";
  }
  
  protected String c() {
    return "tt_top_back";
  }
  
  protected void d() {
    super.d();
    TextView textView = (TextView)findViewById(t.e((Context)this, "tt_top_dislike"));
    this.X = textView;
    if (textView != null) {
      textView.setText(t.a(m.a(), "tt_reward_feedback"));
      this.X.setOnClickListener(new View.OnClickListener(this) {
            public void onClick(View param1View) {
              Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$4;->onClick(Landroid/view/View;)V");
              CreativeInfoManager.onViewClicked("com.bytedance.sdk", param1View);
              safedk_TTVideoLandingPageLink2Activity$4_onClick_183f71de6849a9a44af68583488db771(param1View);
            }
            
            public void safedk_TTVideoLandingPageLink2Activity$4_onClick_183f71de6849a9a44af68583488db771(View param1View) {
              TTDelegateActivity.a(this.a.p, "");
            }
          });
    } 
    this.Y = (TextView)findViewById(t.e((Context)this, "tt_top_skip"));
    this.R = (LandingPageLoadingLayout)findViewById(t.e((Context)this, "tt_loading_layout"));
    this.S = findViewById(t.e(this.e, "tt_browser_webview_loading"));
    this.T = findViewById(t.e(this.e, "tt_back_container"));
    this.V = (TextView)findViewById(t.e(this.e, "tt_back_container_title"));
    this.W = (TextView)findViewById(t.e(this.e, "tt_back_container_des"));
    this.Z = (TTRoundRectImageView)findViewById(t.e(this.e, "tt_back_container_icon"));
    this.ab = (TextView)findViewById(t.e(this.e, "tt_back_container_download"));
    if (this.p.N() != null && !TextUtils.isEmpty(this.p.N().a()))
      d.a().a(this.p.N(), (ImageView)this.Z); 
    this.V.setText(this.p.L());
    this.W.setText(this.p.W());
    ((TextView)findViewById(t.e((Context)this, "tt_ad_loading_logo"))).setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$5;->onClick(Landroid/view/View;)V");
            CreativeInfoManager.onViewClicked("com.bytedance.sdk", param1View);
            safedk_TTVideoLandingPageLink2Activity$5_onClick_9fee6148bff7bd1fe5405435fc5d12f6(param1View);
          }
          
          public void safedk_TTVideoLandingPageLink2Activity$5_onClick_9fee6148bff7bd1fe5405435fc5d12f6(View param1View) {
            TTWebsiteActivity.a(this.a.e, this.a.p, this.a.F);
          }
        });
    if (this.ae) {
      ((ViewStub)findViewById(t.e((Context)this, "tt_browser_new_bottom_bar_view_stub"))).setVisibility(0);
      LinearLayout linearLayout = (LinearLayout)findViewById(t.e((Context)this, "tt_bottom_bar"));
      this.ag = linearLayout;
      linearLayout.setVisibility(8);
      this.af = new g((Context)this, this.ag, this.a, this.p, "landingpage_split_screen");
      if (this.a.getWebView() != null)
        this.a.getWebView().setOnTouchListener(new View.OnTouchListener(this) {
              float a = 0.0F;
              
              public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
                Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$6;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z");
                CreativeInfoManager.onViewTouched("com.bytedance.sdk", param1View, param1MotionEvent);
                return safedk_TTVideoLandingPageLink2Activity$6_onTouch_a0c400b0a183eea4b3836b9fb6c9940d(param1View, param1MotionEvent);
              }
              
              public boolean safedk_TTVideoLandingPageLink2Activity$6_onTouch_a0c400b0a183eea4b3836b9fb6c9940d(View param1View, MotionEvent param1MotionEvent) {
                if (param1MotionEvent.getAction() == 0)
                  this.a = param1MotionEvent.getY(); 
                if (param1MotionEvent.getAction() == 2) {
                  float f1 = param1MotionEvent.getY();
                  float f2 = this.a;
                  if (f1 - f2 > 8.0F) {
                    if (TTVideoLandingPageLink2Activity.g(this.b) != null)
                      TTVideoLandingPageLink2Activity.g(this.b).a(); 
                    return false;
                  } 
                  if (f1 - f2 < -8.0F && TTVideoLandingPageLink2Activity.g(this.b) != null)
                    TTVideoLandingPageLink2Activity.g(this.b).b(); 
                } 
                return false;
              }
            }); 
    } 
    LandingPageLoadingLayout landingPageLoadingLayout = this.R;
    if (landingPageLoadingLayout != null)
      landingPageLoadingLayout.a(this.p, this.F); 
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.bytedance.sdk", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected void e() {
    if (f()) {
      super.e();
      if (this.n.getNativeVideoController() != null) {
        this.n.getNativeVideoController().a(false);
        ((c)this.n.getNativeVideoController()).g(false);
        this.n.setIsNeedShowDetail(false);
        this.l.setClickable(true);
        this.l.setOnTouchListener(new View.OnTouchListener(this) {
              public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
                Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$7;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z");
                CreativeInfoManager.onViewTouched("com.bytedance.sdk", param1View, param1MotionEvent);
                return safedk_TTVideoLandingPageLink2Activity$7_onTouch_cfe5e0accc0e775e72b03f928acb3731(param1View, param1MotionEvent);
              }
              
              public boolean safedk_TTVideoLandingPageLink2Activity$7_onTouch_cfe5e0accc0e775e72b03f928acb3731(View param1View, MotionEvent param1MotionEvent) {
                if (param1MotionEvent.getAction() == 0)
                  TTVideoLandingPageLink2Activity.a(this.a, "click_video"); 
                return false;
              }
            });
      } 
      ((c)this.n.getNativeVideoController()).a(new c.a(this) {
            public void a() {}
            
            public void a(long param1Long, int param1Int) {}
            
            public void a(long param1Long1, long param1Long2) {
              if (TTVideoLandingPageLink2Activity.k(this.a) != null) {
                int i = (int)Math.max(0L, (param1Long2 - param1Long1) / 1000L);
                TextView textView = TTVideoLandingPageLink2Activity.k(this.a);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i);
                stringBuilder.append("");
                textView.setText(stringBuilder.toString());
                if (i <= 0)
                  TTVideoLandingPageLink2Activity.k(this.a).setVisibility(8); 
              } 
            }
            
            public void b(long param1Long, int param1Int) {}
          });
      return;
    } 
    try {
      ImageView imageView = new ImageView((Context)this);
      imageView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
      imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
      d.a().a(this.p.Q().get(0), imageView);
      this.l.setVisibility(0);
      this.l.removeAllViews();
      this.l.addView((View)imageView);
      imageView.setOnClickListener(new View.OnClickListener(this) {
            public void onClick(View param1View) {
              Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$9;->onClick(Landroid/view/View;)V");
              CreativeInfoManager.onViewClicked("com.bytedance.sdk", param1View);
              safedk_TTVideoLandingPageLink2Activity$9_onClick_f6019ec4eb2552f50d49372c3dd49493(param1View);
            }
            
            public void safedk_TTVideoLandingPageLink2Activity$9_onClick_f6019ec4eb2552f50d49372c3dd49493(View param1View) {
              c.b(m.a(), this.a.p, "landingpage_split_screen");
            }
          });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  protected boolean f() {
    return (this.m == 5 || this.m == 15 || this.m == 50);
  }
  
  public void j() {
    super.j();
    if (this.p != null)
      this.p.a(true); 
    TextView textView = this.ab;
    if (textView != null) {
      textView.setText(b());
      this.ab.setClickable(true);
      this.ab.setOnClickListener((View.OnClickListener)this.Q);
      this.ab.setOnTouchListener((View.OnTouchListener)this.Q);
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    LandingPageLoadingLayout landingPageLoadingLayout = this.R;
    if (landingPageLoadingLayout != null)
      landingPageLoadingLayout.a(); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.ae = m.d().o();
    super.onCreate(paramBundle);
    if (!TTAdSdk.isInitSuccess() || this.p == null || this.a == null) {
      finish();
      return;
    } 
    this.a.setWebViewClient((WebViewClient)new d(this, this.e, this.i, this.g, this.M, true) {
          public void onLoadResource(WebView param1WebView, String param1String) {
            super.onLoadResource(param1WebView, param1String);
            CreativeInfoManager.onResourceLoaded("com.bytedance.sdk", param1WebView, param1String);
          }
          
          public void onPageFinished(WebView param1WebView, String param1String) {
            Logger.d("Pangle|SafeDK: Execution> Lcom/bytedance/sdk/openadsdk/activity/TTVideoLandingPageLink2Activity$1;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
            CreativeInfoManager.onWebViewPageFinished("com.bytedance.sdk", param1WebView, param1String);
            safedk_TTVideoLandingPageLink2Activity$1_onPageFinished_bc496d52b96cac02d8371603d45dfbce(param1WebView, param1String);
          }
          
          public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
            super.onPageStarted(param1WebView, param1String, param1Bitmap);
            TTVideoLandingPageLink2Activity.a(this.a, System.currentTimeMillis());
          }
          
          public void safedk_TTVideoLandingPageLink2Activity$1_onPageFinished_bc496d52b96cac02d8371603d45dfbce(WebView param1WebView, String param1String) {
            super.onPageFinished(param1WebView, param1String);
            try {
              if (TTVideoLandingPageLink2Activity.a(this.a) != null && !TTVideoLandingPageLink2Activity.b(this.a))
                TTVideoLandingPageLink2Activity.a(this.a).setVisibility(8); 
              if (TTVideoLandingPageLink2Activity.c(this.a) != null)
                TTVideoLandingPageLink2Activity.c(this.a).setVisibility(0); 
              TTVideoLandingPageLink2Activity.a(this.a, true);
              TTVideoLandingPageLink2Activity.d(this.a);
              TTVideoLandingPageLink2Activity tTVideoLandingPageLink2Activity = this.a;
              return;
            } finally {
              param1WebView = null;
            } 
          }
          
          public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
            return CreativeInfoManager.onWebViewResponseWithHeaders("com.bytedance.sdk", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
          }
          
          public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
            return CreativeInfoManager.onWebViewResponse("com.bytedance.sdk", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
          }
        });
    this.a.setWebChromeClient((WebChromeClient)new c(this, this.i, this.M) {
          public void onProgressChanged(WebView param1WebView, int param1Int) {
            super.onProgressChanged(param1WebView, param1Int);
            if (TTVideoLandingPageLink2Activity.f(this.a) && TTVideoLandingPageLink2Activity.g(this.a) != null && param1Int == 100)
              TTVideoLandingPageLink2Activity.g(this.a).a(param1WebView); 
            if (this.a.C != null && !this.a.isFinishing() && param1Int == 100 && this.a.C.isShown() && !TTVideoLandingPageLink2Activity.b(this.a)) {
              if (TTVideoLandingPageLink2Activity.a(this.a) != null)
                TTVideoLandingPageLink2Activity.a(this.a).setVisibility(8); 
              if (TTVideoLandingPageLink2Activity.c(this.a) != null)
                TTVideoLandingPageLink2Activity.c(this.a).setVisibility(0); 
              TTVideoLandingPageLink2Activity.d(this.a);
            } 
            if (TTVideoLandingPageLink2Activity.h(this.a) != null)
              TTVideoLandingPageLink2Activity.h(this.a).a(param1Int); 
          }
        });
    TextView textView = (TextView)findViewById(t.e((Context)this, "tt_loading_tip"));
    this.aa = textView;
    if (textView != null && this.p.a() != null)
      this.aa.setText(this.p.a().c()); 
    long l2 = 10000L;
    long l1 = l2;
    if (this.p != null) {
      l1 = l2;
      if (this.p.a() != null)
        l1 = this.p.a().a() * 1000L; 
    } 
    k.c().postDelayed(new Runnable(this) {
          public void run() {
            try {
              TTVideoLandingPageLink2Activity.b(this.a, true);
              if (TTVideoLandingPageLink2Activity.h(this.a) != null)
                TTVideoLandingPageLink2Activity.h(this.a).b(); 
              TTVideoLandingPageLink2Activity.i(this.a).setVisibility(0);
              if (!TTVideoLandingPageLink2Activity.j(this.a)) {
                TTVideoLandingPageLink2Activity tTVideoLandingPageLink2Activity = this.a;
                c.a((Context)tTVideoLandingPageLink2Activity, tTVideoLandingPageLink2Activity.p, this.a.F, System.currentTimeMillis() - TTVideoLandingPageLink2Activity.e(this.a), false);
              } 
              return;
            } catch (Exception exception) {
              return;
            } 
          }
        }l1);
  }
  
  protected void onDestroy() {
    m();
    if (!this.U && this.M != null && this.a != null && this.R.getVisibility() == 8)
      this.M.a(this.a); 
    super.onDestroy();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\activity\TTVideoLandingPageLink2Activity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */