package com.bytedance.sdk.openadsdk.j;

public class f {
  private static a a;
  
  public static void a(a parama) {
    a = parama;
  }
  
  public static void a(String paramString1, String paramString2) {
    a a1 = a;
    if (a1 == null)
      return; 
    a1.a(paramString1, paramString2);
  }
  
  public static void a(String paramString1, String paramString2, Throwable paramThrowable) {
    if (a == null)
      return; 
    Throwable throwable = paramThrowable;
    if (paramThrowable == null)
      throwable = new Throwable(); 
    a.a(paramString1, paramString2, throwable);
  }
  
  public static boolean a() {
    return (a != null);
  }
  
  public static interface a {
    void a(String param1String1, String param1String2);
    
    void a(String param1String1, String param1String2, Throwable param1Throwable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\j\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */