package com.bytedance.sdk.openadsdk.component.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Xfermode;
import android.util.AttributeSet;
import android.widget.TextView;

public class ButtonFlash extends TextView {
  private int a;
  
  private int b;
  
  private Paint c;
  
  private LinearGradient d;
  
  private RectF e;
  
  private Matrix f;
  
  private ValueAnimator g;
  
  private boolean h = true;
  
  public ButtonFlash(Context paramContext) {
    super(paramContext);
    b();
  }
  
  public ButtonFlash(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    b();
  }
  
  public ButtonFlash(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    b();
  }
  
  private void b() {
    this.e = new RectF();
    this.c = new Paint();
    c();
  }
  
  private void c() {
    ValueAnimator valueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
    this.g = valueAnimator;
    valueAnimator.setDuration(3000L);
    this.g.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this) {
          public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
            float f1 = ((Float)param1ValueAnimator.getAnimatedValue()).floatValue();
            float f2 = (ButtonFlash.a(this.a) * 2);
            float f3 = ButtonFlash.a(this.a);
            if (ButtonFlash.b(this.a) != null)
              ButtonFlash.b(this.a).setTranslate(f2 * f1 - f3, ButtonFlash.c(this.a)); 
            if (ButtonFlash.d(this.a) != null)
              ButtonFlash.d(this.a).setLocalMatrix(ButtonFlash.b(this.a)); 
            this.a.invalidate();
          }
        });
    if (this.h) {
      this.g.setRepeatCount(-1);
      valueAnimator = this.g;
      if (valueAnimator != null)
        valueAnimator.start(); 
    } 
  }
  
  public void a() {
    ValueAnimator valueAnimator = this.g;
    if (valueAnimator != null) {
      valueAnimator.removeAllUpdateListeners();
      this.g.cancel();
      invalidate();
    } 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.f != null)
      paramCanvas.drawRoundRect(this.e, 100.0F, 100.0F, this.c); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    this.a = paramInt1;
    this.b = paramInt2;
    float f1 = this.a / 2.0F;
    float f2 = this.b;
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    LinearGradient linearGradient = new LinearGradient(0.0F, 0.0F, f1, f2, new int[] { 16777215, 1358954495, 16777215 }, new float[] { 0.1F, 0.3F, 0.5F }, tileMode);
    this.d = linearGradient;
    this.c.setShader((Shader)linearGradient);
    this.c.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.LIGHTEN));
    Matrix matrix = new Matrix();
    this.f = matrix;
    matrix.setTranslate(-this.a, this.b);
    this.d.setLocalMatrix(this.f);
    this.e.set(0.0F, 0.0F, this.a, this.b);
  }
  
  public void setAutoRun(boolean paramBoolean) {
    this.h = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\component\view\ButtonFlash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */