package com.bytedance.sdk.openadsdk.core;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.bykv.vk.openvk.component.video.api.c.c;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.adexpress.a.c.c;
import com.bytedance.sdk.component.utils.t;
import com.bytedance.sdk.openadsdk.a.b.a;
import com.bytedance.sdk.openadsdk.a.b.g;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAd;
import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.c.f;
import com.bytedance.sdk.openadsdk.core.b.a;
import com.bytedance.sdk.openadsdk.core.b.b;
import com.bytedance.sdk.openadsdk.core.b.c;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.k.a.e;
import com.bytedance.sdk.openadsdk.l.aa;
import com.bytedance.sdk.openadsdk.l.r;
import com.com.bytedance.overseas.sdk.a.c;
import com.com.bytedance.overseas.sdk.a.d;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class l {
  private final n a;
  
  private c b;
  
  private final Context c;
  
  private final PAGNativeAd d;
  
  private List<View> e = new ArrayList<View>();
  
  private String f = c.c1671532477447dc("el`f``bXim");
  
  private g g;
  
  private long h;
  
  private Double i = null;
  
  private f j = new f();
  
  private a k;
  
  private b l;
  
  private a m;
  
  public l(Context paramContext, PAGNativeAd paramPAGNativeAd, n paramn, String paramString, a parama) {
    this.d = paramPAGNativeAd;
    this.a = paramn;
    this.c = paramContext;
    this.f = paramString;
    this.k = parama;
    if (paramn.M() == 4)
      this.b = d.a(paramContext, paramn, this.f); 
  }
  
  private EmptyView a(ViewGroup paramViewGroup) {
    for (int i = 0; i < paramViewGroup.getChildCount(); i++) {
      View view = paramViewGroup.getChildAt(i);
      if (view instanceof EmptyView)
        return (EmptyView)view; 
    } 
    return null;
  }
  
  private EmptyView a(ViewGroup paramViewGroup, List<View> paramList1, List<View> paramList2, List<View> paramList3, g paramg) {
    label22: while (true) {
      byte b1;
      for (b1 = 82;; b1 = 80) {
        EmptyView emptyView1;
        EmptyView emptyView2;
        switch (b1) {
          case 81:
            continue label22;
          case 80:
            this.g = paramg;
            paramViewGroup.addOnLayoutChangeListener(new View.OnLayoutChangeListener(this, paramViewGroup) {
                  public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
                    l.a(this.b).a(System.currentTimeMillis(), v.a((View)this.a));
                  }
                });
            this.e = paramList1;
            emptyView2 = a(paramViewGroup);
            emptyView1 = emptyView2;
            if (emptyView2 == null) {
              emptyView1 = new EmptyView(this.c, (View)paramViewGroup);
              paramViewGroup.addView((View)emptyView1);
            } 
            emptyView1.a();
            emptyView1.setRefClickViews(paramList2);
            if (paramList1 != null) {
              for (View view : this.e) {
                if (view != null)
                  view.setTag(t.e(m.a(), c.c1671532477445dc("tu]j`ZotWcoibQyrfffp")), Boolean.valueOf(true)); 
              } 
              paramList3.addAll(paramList1);
            } 
            emptyView1.setRefCreativeViews(paramList3);
            return emptyView1;
        } 
      } 
      break;
    } 
  }
  
  private void a(ViewGroup paramViewGroup, View paramView) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put(c.c1671532477445dc("cmk`oZudmgin"), Integer.valueOf(1));
    Context context2 = this.c;
    n n1 = this.a;
    String str = this.f;
    b b2 = new b(context2, n1, str, aa.a(str));
    this.l = b2;
    b2.a((View)paramViewGroup);
    this.l.b(paramView);
    this.l.a(this.b);
    this.l.a(this.d);
    this.l.a(hashMap);
    this.l.a(new b.a(this) {
          public void a(View param1View, int param1Int) {
            if (l.b(this.a) != null)
              l.b(this.a).a(param1View, l.c(this.a)); 
          }
        });
    Context context1 = this.c;
    n1 = this.a;
    str = this.f;
    a a1 = new a(context1, n1, str, aa.a(str));
    this.m = a1;
    a1.a((View)paramViewGroup);
    this.m.b(paramView);
    this.m.a(this.b);
    this.m.a(this.d);
    this.m.a(hashMap);
    this.m.a(new b.a(this) {
          public void a(View param1View, int param1Int) {
            if (l.b(this.a) != null)
              l.b(this.a).b(param1View, l.c(this.a)); 
            e.a(l.d(this.a), 9);
            l.e(this.a).z();
            for (param1Int = 73;; param1Int = 72) {
              switch (param1Int) {
                case 72:
                  return;
              } 
            } 
          }
        });
    byte b1 = 19;
    while (true) {
      switch (b1) {
        case 18:
        case 19:
          b1 = 20;
          break;
        case 20:
          break;
      } 
    } 
  }
  
  private void a(ViewGroup paramViewGroup, EmptyView paramEmptyView, List<View> paramList1, List<View> paramList2) {
    paramEmptyView.a(paramList1, (c)this.l);
    paramEmptyView.a(paramList2, (c)this.m);
    a a1 = this.k;
    if (a1 != null && a1.a() != null) {
      this.k.a().setOnClickListener((View.OnClickListener)this.m);
      this.k.a().setOnTouchListener((View.OnTouchListener)this.m);
    } 
    a1 = this.k;
    if (a1 != null && a1.b() != null) {
      this.k.b().setOnClickListener((View.OnClickListener)this.m);
      this.k.b().setOnTouchListener((View.OnTouchListener)this.m);
    } 
    a1 = this.k;
    if (a1 != null)
      a1.a(this.m); 
    paramEmptyView.setCallback(new EmptyView.a(this, paramViewGroup) {
          public void a() {
            l.a(this.b).a(System.currentTimeMillis(), v.a((View)this.a));
          }
          
          @JProtect
          public void a(View param1View) {
            // Byte code:
            //   0: aload_0
            //   1: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   4: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/c/f;
            //   7: invokestatic currentTimeMillis : ()J
            //   10: aload_0
            //   11: getfield a : Landroid/view/ViewGroup;
            //   14: invokestatic a : (Landroid/view/View;)F
            //   17: invokevirtual a : (JF)V
            //   20: aload_0
            //   21: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   24: invokestatic currentTimeMillis : ()J
            //   27: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/l;J)J
            //   30: pop2
            //   31: new java/util/HashMap
            //   34: dup
            //   35: invokespecial <init> : ()V
            //   38: astore_2
            //   39: aload_0
            //   40: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   43: invokestatic h : (Lcom/bytedance/sdk/openadsdk/core/l;)Ljava/util/List;
            //   46: ifnull -> 182
            //   49: new org/json/JSONArray
            //   52: dup
            //   53: invokespecial <init> : ()V
            //   56: astore_3
            //   57: aload_0
            //   58: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   61: invokestatic h : (Lcom/bytedance/sdk/openadsdk/core/l;)Ljava/util/List;
            //   64: invokeinterface iterator : ()Ljava/util/Iterator;
            //   69: astore #4
            //   71: aload #4
            //   73: invokeinterface hasNext : ()Z
            //   78: ifeq -> 166
            //   81: aload #4
            //   83: invokeinterface next : ()Ljava/lang/Object;
            //   88: checkcast android/view/View
            //   91: astore #6
            //   93: aload #6
            //   95: ifnull -> 71
            //   98: new org/json/JSONObject
            //   101: dup
            //   102: invokespecial <init> : ()V
            //   105: astore #5
            //   107: aload #5
            //   109: ldc 'whfwl'
            //   111: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   114: aload #6
            //   116: invokevirtual getWidth : ()I
            //   119: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
            //   122: pop
            //   123: aload #5
            //   125: ldc 'hdkdlq'
            //   127: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   130: aload #6
            //   132: invokevirtual getHeight : ()I
            //   135: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
            //   138: pop
            //   139: aload #5
            //   141: ldc 'amrke'
            //   143: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   146: aload #6
            //   148: invokevirtual getAlpha : ()F
            //   151: f2d
            //   152: invokevirtual put : (Ljava/lang/String;D)Lorg/json/JSONObject;
            //   155: pop
            //   156: aload_3
            //   157: aload #5
            //   159: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
            //   162: pop
            //   163: goto -> 71
            //   166: aload_2
            //   167: ldc 'ilcdaZpnm~'
            //   169: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   172: aload_3
            //   173: invokevirtual toString : ()Ljava/lang/String;
            //   176: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
            //   181: pop
            //   182: aload_0
            //   183: getfield a : Landroid/view/ViewGroup;
            //   186: ifnull -> 265
            //   189: new org/json/JSONObject
            //   192: dup
            //   193: invokespecial <init> : ()V
            //   196: astore_3
            //   197: aload_3
            //   198: ldc 'whfwl'
            //   200: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   203: aload_0
            //   204: getfield a : Landroid/view/ViewGroup;
            //   207: invokevirtual getWidth : ()I
            //   210: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
            //   213: pop
            //   214: aload_3
            //   215: ldc 'hdkdlq'
            //   217: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   220: aload_0
            //   221: getfield a : Landroid/view/ViewGroup;
            //   224: invokevirtual getHeight : ()I
            //   227: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
            //   230: pop
            //   231: aload_3
            //   232: ldc 'amrke'
            //   234: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   237: aload_0
            //   238: getfield a : Landroid/view/ViewGroup;
            //   241: invokevirtual getAlpha : ()F
            //   244: f2d
            //   245: invokevirtual put : (Ljava/lang/String;D)Lorg/json/JSONObject;
            //   248: pop
            //   249: aload_2
            //   250: ldc 'rnmw[sob'
            //   252: invokestatic c1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
            //   255: aload_3
            //   256: invokevirtual toString : ()Ljava/lang/String;
            //   259: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
            //   264: pop
            //   265: aload_0
            //   266: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   269: invokestatic i : (Lcom/bytedance/sdk/openadsdk/core/l;)Landroid/content/Context;
            //   272: aload_0
            //   273: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   276: invokestatic d : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   279: aload_0
            //   280: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   283: invokestatic g : (Lcom/bytedance/sdk/openadsdk/core/l;)Ljava/lang/String;
            //   286: aload_2
            //   287: aload_0
            //   288: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   291: invokestatic j : (Lcom/bytedance/sdk/openadsdk/core/l;)Ljava/lang/Double;
            //   294: invokestatic a : (Landroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/util/Map;Ljava/lang/Double;)V
            //   297: aload_0
            //   298: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   301: invokestatic b : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/a/b/g;
            //   304: ifnull -> 326
            //   307: aload_0
            //   308: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   311: invokestatic b : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/a/b/g;
            //   314: aload_0
            //   315: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   318: invokestatic c : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/api/nativeAd/PAGNativeAd;
            //   321: invokeinterface a : (Lcom/bytedance/sdk/openadsdk/api/nativeAd/PAGNativeAd;)V
            //   326: aload_0
            //   327: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   330: invokestatic d : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   333: invokevirtual aj : ()Z
            //   336: ifeq -> 350
            //   339: aload_0
            //   340: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   343: invokestatic d : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   346: aload_1
            //   347: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/n;Landroid/view/View;)V
            //   350: aload_0
            //   351: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   354: invokestatic d : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   357: invokevirtual ay : ()Lcom/bytedance/sdk/openadsdk/core/g/a;
            //   360: ifnull -> 380
            //   363: aload_0
            //   364: getfield b : Lcom/bytedance/sdk/openadsdk/core/l;
            //   367: invokestatic d : (Lcom/bytedance/sdk/openadsdk/core/l;)Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   370: invokevirtual ay : ()Lcom/bytedance/sdk/openadsdk/core/g/a;
            //   373: invokevirtual a : ()Lcom/bytedance/sdk/openadsdk/core/g/d;
            //   376: lconst_0
            //   377: invokevirtual a : (J)V
            //   380: return
            //   381: astore #6
            //   383: goto -> 156
            //   386: astore #4
            //   388: goto -> 249
            // Exception table:
            //   from	to	target	type
            //   107	156	381	finally
            //   197	249	386	finally
          }
          
          public void a(boolean param1Boolean) {
            byte b;
            if (!param1Boolean && l.f(this.b) > 0L) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(System.currentTimeMillis() - l.f(this.b));
              stringBuilder.append("");
              String str = stringBuilder.toString();
              l.a(this.b).a(System.currentTimeMillis(), v.a((View)this.a));
              c.a(str, l.d(this.b), l.g(this.b), l.a(this.b));
              l.a(this.b, 0L);
              b = 64;
            } else {
              l.a(this.b).a(System.currentTimeMillis(), v.a((View)this.a));
              l.a(this.b, System.currentTimeMillis());
            } 
            while (true) {
              switch (b) {
                case 65:
                  b = 66;
                  break;
                case 64:
                case 66:
                  break;
              } 
            } 
          }
          
          public void b() {
            if (l.f(this.b) > 0L) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(System.currentTimeMillis() - l.f(this.b));
              stringBuilder.append("");
              c.a(stringBuilder.toString(), l.d(this.b), l.g(this.b), l.a(this.b));
              l.a(this.b, 0L);
            } 
          }
        });
  }
  
  public f a() {
    return this.j;
  }
  
  public void a(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Lcom/bytedance/sdk/openadsdk/a/b/g;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 26
    //   11: aload #4
    //   13: aload_1
    //   14: aload_0
    //   15: getfield d : Lcom/bytedance/sdk/openadsdk/api/nativeAd/PAGNativeAd;
    //   18: invokeinterface b : (Landroid/view/View;Lcom/bytedance/sdk/openadsdk/api/nativeAd/PAGNativeAd;)V
    //   23: goto -> 127
    //   26: bipush #94
    //   28: istore_2
    //   29: bipush #125
    //   31: istore_3
    //   32: iload_2
    //   33: tableswitch default -> 60, 94 -> 121, 95 -> 63, 96 -> 92
    //   60: goto -> 26
    //   63: iload_3
    //   64: tableswitch default -> 92, 94 -> 127, 95 -> 26, 96 -> 127
    //   92: iload_3
    //   93: tableswitch default -> 120, 55 -> 136, 56 -> 26, 57 -> 136
    //   120: return
    //   121: iload_3
    //   122: bipush #39
    //   124: if_icmpne -> 136
    //   127: bipush #95
    //   129: istore_2
    //   130: bipush #95
    //   132: istore_3
    //   133: goto -> 32
    //   136: return
  }
  
  public void a(ViewGroup paramViewGroup, List<View> paramList1, List<View> paramList2, List<View> paramList3, View paramView, g paramg) {
    EmptyView[] arrayOfEmptyView = new EmptyView[1];
    arrayOfEmptyView[0] = null;
    boolean bool = r.u();
    if (bool) {
      k.c().post(new Runnable(this, arrayOfEmptyView, paramViewGroup, paramList1, paramList2, paramList3, paramg) {
            public void run() {
              this.a[0] = l.a(this.g, this.b, this.c, this.d, this.e, this.f);
            }
          });
    } else {
      arrayOfEmptyView[0] = a(paramViewGroup, paramList1, paramList2, paramList3, paramg);
    } 
    if (bool) {
      k.c().post(new Runnable(this, paramViewGroup, paramView) {
            public void run() {
              l.a(this.c, this.a, this.b);
              byte b = 92;
              label12: while (true) {
                byte b1 = 14;
                while (true) {
                  switch (b1) {
                    default:
                      continue label12;
                    case 15:
                      switch (b) {
                        case 95:
                          return;
                      } 
                      break;
                    case 13:
                    case 14:
                      break;
                  } 
                  b1 = 15;
                  b = 95;
                } 
                break;
              } 
            }
          });
    } else {
      a(paramViewGroup, paramView);
    } 
    if (bool) {
      k.c().post(new Runnable(this, paramViewGroup, arrayOfEmptyView, paramList2, paramList3) {
            public void run() {
              l.a(this.e, this.a, this.b[0], this.c, this.d);
            }
          });
    } else {
      a(paramViewGroup, arrayOfEmptyView[0], paramList2, paramList3);
    } 
    if (bool) {
      k.c().post(new Runnable(this, arrayOfEmptyView) {
            public void run() {
              this.a[0].setNeedCheckingShow(true);
            }
          });
      return;
    } 
    arrayOfEmptyView[0].setNeedCheckingShow(true);
  }
  
  public void a(Double paramDouble) {
    this.i = paramDouble;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\core\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */