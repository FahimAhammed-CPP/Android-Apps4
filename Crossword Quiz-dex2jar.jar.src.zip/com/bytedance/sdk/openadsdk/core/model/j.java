package com.bytedance.sdk.openadsdk.core.model;

import android.util.SparseArray;
import com.bytedance.sdk.component.adexpress.c;
import com.bytedance.sdk.openadsdk.core.b.c;
import org.json.JSONObject;

public class j implements c {
  public final float a;
  
  public final float b;
  
  public final float c;
  
  public final float d;
  
  public final long e;
  
  public final long f;
  
  public final int g;
  
  public final int h;
  
  public final int i;
  
  public final int j;
  
  public final String k;
  
  public int l;
  
  public JSONObject m;
  
  public SparseArray<c.a> n;
  
  public final boolean o;
  
  public int p;
  
  private j(a parama) {
    this.a = a.a(parama);
    this.b = a.b(parama);
    this.c = a.c(parama);
    this.d = a.d(parama);
    this.e = a.e(parama);
    this.f = a.f(parama);
    this.g = a.g(parama);
    this.h = a.h(parama);
    this.i = a.i(parama);
    this.j = a.j(parama);
    this.k = a.k(parama);
    this.n = parama.a;
    this.o = a.l(parama);
    this.l = a.m(parama);
    this.m = a.n(parama);
    this.p = a.o(parama);
  }
  
  public static class a {
    protected SparseArray<c.a> a = new SparseArray();
    
    private long b;
    
    private long c;
    
    private float d;
    
    private float e;
    
    private float f;
    
    private float g;
    
    private int h;
    
    private int i;
    
    private int j;
    
    private int k;
    
    private String l;
    
    private int m;
    
    private JSONObject n;
    
    private int o;
    
    private boolean p;
    
    public a a(float param1Float) {
      this.d = param1Float;
      return this;
    }
    
    public a a(int param1Int) {
      this.o = param1Int;
      return this;
    }
    
    public a a(long param1Long) {
      this.b = param1Long;
      return this;
    }
    
    public a a(SparseArray<c.a> param1SparseArray) {
      this.a = param1SparseArray;
      return this;
    }
    
    public a a(String param1String) {
      this.l = param1String;
      return this;
    }
    
    public a a(JSONObject param1JSONObject) {
      this.n = param1JSONObject;
      return this;
    }
    
    public a a(boolean param1Boolean) {
      this.p = param1Boolean;
      return this;
    }
    
    public j a() {
      return new j(this);
    }
    
    public a b(float param1Float) {
      this.e = param1Float;
      return this;
    }
    
    public a b(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public a b(long param1Long) {
      this.c = param1Long;
      return this;
    }
    
    public a c(float param1Float) {
      this.f = param1Float;
      return this;
    }
    
    public a c(int param1Int) {
      this.h = param1Int;
      return this;
    }
    
    public a d(float param1Float) {
      this.g = param1Float;
      return this;
    }
    
    public a d(int param1Int) {
      this.i = param1Int;
      return this;
    }
    
    public a e(int param1Int) {
      this.j = param1Int;
      return this;
    }
    
    public a f(int param1Int) {
      this.k = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\core\model\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */