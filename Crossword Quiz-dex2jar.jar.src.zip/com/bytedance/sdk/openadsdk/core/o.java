package com.bytedance.sdk.openadsdk.core;

import android.content.Context;
import android.os.Looper;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.bykv.vk.openvk.component.video.api.c.c;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.adexpress.a.c.c;
import com.bytedance.sdk.component.d.k;
import com.bytedance.sdk.component.f.b.c;
import com.bytedance.sdk.component.f.b.d;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.openadsdk.AdSlot;
import com.bytedance.sdk.openadsdk.ApmHelper;
import com.bytedance.sdk.openadsdk.FilterWord;
import com.bytedance.sdk.openadsdk.TTAdSdk;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.bytedance.sdk.openadsdk.c.a;
import com.bytedance.sdk.openadsdk.c.a.e;
import com.bytedance.sdk.openadsdk.c.c;
import com.bytedance.sdk.openadsdk.c.e;
import com.bytedance.sdk.openadsdk.component.reward.n;
import com.bytedance.sdk.openadsdk.core.a.a;
import com.bytedance.sdk.openadsdk.core.d.b;
import com.bytedance.sdk.openadsdk.core.e.c;
import com.bytedance.sdk.openadsdk.core.g.a;
import com.bytedance.sdk.openadsdk.core.model.a;
import com.bytedance.sdk.openadsdk.core.model.b;
import com.bytedance.sdk.openadsdk.core.model.d;
import com.bytedance.sdk.openadsdk.core.model.k;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.model.o;
import com.bytedance.sdk.openadsdk.core.model.s;
import com.bytedance.sdk.openadsdk.core.settings.e;
import com.bytedance.sdk.openadsdk.core.settings.f;
import com.bytedance.sdk.openadsdk.core.settings.j;
import com.bytedance.sdk.openadsdk.d.d;
import com.bytedance.sdk.openadsdk.i.d;
import com.bytedance.sdk.openadsdk.l.aa;
import com.bytedance.sdk.openadsdk.l.f;
import com.bytedance.sdk.openadsdk.l.z;
import com.safedk.android.internal.partials.PangleVideoBridge;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class o implements n<a> {
  private static volatile boolean f = false;
  
  private static boolean h = true;
  
  private final Context a;
  
  private final boolean b;
  
  private final String c;
  
  private long d;
  
  private int e;
  
  private com.bytedance.sdk.component.d.o g = new com.bytedance.sdk.component.d.o(this) {
      public void a(int param1Int, String param1String, Throwable param1Throwable) {}
      
      public void a(k param1k) {}
    };
  
  o(Context paramContext) {
    this.a = paramContext;
    this.b = e();
    this.c = g();
  }
  
  private static String a(int paramInt) {
    if (paramInt != 120) {
      if (paramInt != 160) {
        if (paramInt != 240) {
          if (paramInt != 320) {
            String str3;
            if (paramInt != 480) {
              if (paramInt != 640)
                return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("merj"); 
              str3 = "xyzk`uo";
            } else {
              str3 = "xyjgtl";
            } 
            return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str3);
          } 
          String str2 = "xifsm";
          return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str2);
        } 
        String str1 = "herj";
        return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str1);
      } 
      return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("merj");
    } 
    String str = "lerj";
    return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str);
  }
  
  public static String a(Context paramContext) {
    try {
      return (telephonyManager == null) ? "" : telephonyManager.getSimOperator();
    } finally {
      paramContext = null;
    } 
  }
  
  public static JSONObject a(AdSlot paramAdSlot) {
    JSONObject jSONObject = new JSONObject();
    try {
      j j = m.d();
      jSONObject.put(e.e1671532477438dc("pdppkkgkasooSlj"), j.K());
      jSONObject.put(e.e1671532477438dc("llv"), f.b());
      jSONObject.put(e.e1671532477438dc("cnrse"), h.d().k());
      jSONObject.put(e.e1671532477438dc("gerq"), h.d().j());
      jSONObject.put(e.e1671532477438dc("ir]d`utX}zoy"), m.d().H());
      jSONObject.put(e.e1671532477438dc("cbrb"), h.d().v());
      if (paramAdSlot != null && p.a.containsKey(Integer.valueOf(paramAdSlot.getCodeId()))) {
        p p = (p)p.a.get(Integer.valueOf(paramAdSlot.getCodeId()));
        if (p != null) {
          jSONObject.put(e.e1671532477438dc("l`qweaiji`d"), p.b());
          jSONObject.put(e.e1671532477438dc("l`qwfphcdl"), p.c());
          jSONObject.put(e.e1671532477438dc("l`qwgiodc"), p.d());
          jSONObject.put(e.e1671532477438dc("l`qwwnow"), p.e());
        } 
      } 
      a(jSONObject, e.e1671532477438dc("kd{tkwbt"), h.d().m());
      a(jSONObject, e.e1671532477438dc("d`vb"), b(paramAdSlot));
      return jSONObject;
    } catch (Exception exception) {
      return jSONObject;
    } 
  }
  
  private JSONObject a(AdSlot paramAdSlot, int paramInt, o paramo) {
    JSONObject jSONObject;
    int j = 3;
    int i;
    for (i = 3;; i = 2) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            i = 1;
            continue;
          } 
        } else {
          jSONObject = new JSONObject();
          try {
            String str;
            jSONObject.put(d.d1671532477445dc("ie"), paramAdSlot.getCodeId());
            jSONObject.put(d.d1671532477445dc("aevzt`"), paramInt);
            if (!TextUtils.isEmpty(paramAdSlot.getAdId()) || !TextUtils.isEmpty(paramAdSlot.getCreativeId()) || !TextUtils.isEmpty(paramAdSlot.getExt())) {
              JSONObject jSONObject1 = new JSONObject();
              if (!TextUtils.isEmpty(paramAdSlot.getAdId()))
                jSONObject1.put(a.a1671532477445dc("ae]j`"), paramAdSlot.getAdId()); 
              if (!TextUtils.isEmpty(paramAdSlot.getCreativeId()))
                jSONObject1.put(a.a1671532477445dc("csgbplpbW`n"), paramAdSlot.getCreativeId()); 
              if (paramAdSlot.getExt() != null)
                jSONObject1.put(a.a1671532477445dc("eyv"), paramAdSlot.getExt()); 
              jSONObject.put(d.d1671532477445dc("psgum`qXimy"), jSONObject1);
            } 
            if (paramo != null) {
              jSONObject.put(a.a1671532477445dc("rdlgawYjm}bdh"), paramo.f);
              if (paramo.f == 1) {
                str = a.a1671532477445dc("abaftqccWzcqi");
                i = paramAdSlot.getImgAcceptedWidth();
              } else {
                if (paramo.f == 2)
                  a(jSONObject, a.a1671532477445dc("abaftqccWzcqi"), paramAdSlot.getExpressViewAcceptedWidth(), paramAdSlot.getExpressViewAcceptedHeight()); 
                jSONObject.put(d.d1671532477445dc("puro[lbt"), b(paramAdSlot.getCodeId()));
                jSONObject.put(d.d1671532477445dc("pnq"), AdSlot.getPosition(paramInt));
                jSONObject.put(d.d1671532477445dc("ir]pquvhz}Uo|a"), paramAdSlot.isSupportDeepLink());
              } 
            } else {
              jSONObject.put(d.d1671532477445dc("rdlgawYjm}bdh"), 1);
              str = d.d1671532477445dc("abaftqccWzcqi");
              i = paramAdSlot.getImgAcceptedWidth();
            } 
            a(jSONObject, str, i, paramAdSlot.getImgAcceptedHeight());
            jSONObject.put(d.d1671532477445dc("puro[lbt"), b(paramAdSlot.getCodeId()));
            jSONObject.put(d.d1671532477445dc("pnq"), AdSlot.getPosition(paramInt));
            jSONObject.put(d.d1671532477445dc("ir]pquvhz}Uo|a"), paramAdSlot.isSupportDeepLink());
          } catch (Exception exception) {
            return jSONObject;
          } 
        }  
    } 
    if (i > 3)
      i = j; 
    if (paramInt == 7 || paramInt == 8)
      i = 1; 
    j = i;
    if (paramo != null) {
      j = i;
      if (paramo.e != null)
        j = exception.getAdCount(); 
    } 
    jSONObject.put(d.d1671532477445dc("ae]`kphs"), j);
    if (paramInt == 1) {
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put(d.d1671532477445dc("ir]qkqgsmVhjbck}"), exception.getIsRotateBanner());
      jSONObject1.put(d.d1671532477445dc("rnvbp`Ysado"), exception.getRotateTime());
      jSONObject1.put(d.d1671532477445dc("rnvbp`Yhzmoy"), exception.getRotateOrder());
      jSONObject.put(a.a1671532477445dc("b`lmaw"), jSONObject1);
    } 
    return jSONObject;
  }
  
  @JProtect
  private JSONObject a(AdSlot paramAdSlot, o paramo, int paramInt) {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #10
    //   9: aload #10
    //   11: astore #8
    //   13: new org/json/JSONObject
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: astore #11
    //   22: aload_2
    //   23: ifnull -> 59
    //   26: aload #10
    //   28: astore #8
    //   30: aload_2
    //   31: getfield a : Ljava/lang/String;
    //   34: checkcast java/lang/CharSequence
    //   37: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   40: ifeq -> 46
    //   43: goto -> 59
    //   46: aload #10
    //   48: astore #8
    //   50: aload_2
    //   51: getfield a : Ljava/lang/String;
    //   54: astore #9
    //   56: goto -> 68
    //   59: aload #10
    //   61: astore #8
    //   63: invokestatic d : ()Ljava/lang/String;
    //   66: astore #9
    //   68: iload_3
    //   69: bipush #7
    //   71: if_icmpne -> 128
    //   74: aload_2
    //   75: ifnull -> 219
    //   78: aload #10
    //   80: astore #8
    //   82: aload_2
    //   83: getfield b : I
    //   86: ifle -> 219
    //   89: aload #10
    //   91: astore #8
    //   93: ldc_w 'rds\p|vb'
    //   96: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   99: astore #7
    //   101: aload #10
    //   103: astore #8
    //   105: aload_2
    //   106: getfield b : I
    //   109: istore #4
    //   111: aload #10
    //   113: astore #8
    //   115: aload #11
    //   117: aload #7
    //   119: iload #4
    //   121: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   124: pop
    //   125: goto -> 219
    //   128: iload_3
    //   129: bipush #8
    //   131: if_icmpne -> 174
    //   134: aload_2
    //   135: ifnull -> 219
    //   138: aload #10
    //   140: astore #8
    //   142: aload_2
    //   143: getfield c : I
    //   146: ifle -> 219
    //   149: aload #10
    //   151: astore #8
    //   153: ldc_w 'rds\p|vb'
    //   156: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   159: astore #7
    //   161: aload #10
    //   163: astore #8
    //   165: aload_2
    //   166: getfield c : I
    //   169: istore #4
    //   171: goto -> 111
    //   174: iload_3
    //   175: iconst_3
    //   176: if_icmpne -> 219
    //   179: aload_2
    //   180: ifnull -> 219
    //   183: aload #10
    //   185: astore #8
    //   187: aload_2
    //   188: getfield d : I
    //   191: ifle -> 219
    //   194: aload #10
    //   196: astore #8
    //   198: ldc_w 'rds\p|vb'
    //   201: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   204: astore #7
    //   206: aload #10
    //   208: astore #8
    //   210: aload_2
    //   211: getfield d : I
    //   214: istore #4
    //   216: goto -> 111
    //   219: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   222: invokevirtual j : ()Ljava/lang/String;
    //   225: astore #7
    //   227: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   230: invokevirtual n : ()Ljava/lang/String;
    //   233: astore #8
    //   235: aload #7
    //   237: ifnull -> 296
    //   240: aload #8
    //   242: ifnull -> 296
    //   245: new org/json/JSONObject
    //   248: dup
    //   249: invokespecial <init> : ()V
    //   252: astore #12
    //   254: aload #12
    //   256: ldc_w 'vdppmjh'
    //   259: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   262: aload #7
    //   264: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   267: pop
    //   268: aload #12
    //   270: ldc_w 'p`pbi'
    //   273: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   276: aload #8
    //   278: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   281: pop
    //   282: aload #11
    //   284: ldc_w 'acvfwq'
    //   287: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   290: aload #12
    //   292: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   295: pop
    //   296: aload #10
    //   298: astore #8
    //   300: aload #11
    //   302: ldc_w 'rdsvavrXam'
    //   305: invokestatic c1671532477431dc : (Ljava/lang/String;)Ljava/lang/String;
    //   308: aload #9
    //   310: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   313: pop
    //   314: aload #10
    //   316: astore #8
    //   318: aload #11
    //   320: ldc_w 'ae]p`nYqm{ybcc'
    //   323: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   326: ldc_w '4/;-4+0'
    //   329: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   332: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   335: pop
    //   336: aload #10
    //   338: astore #8
    //   340: aload #11
    //   342: ldc_w 'snwqg`Ysqyo'
    //   345: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   348: ldc_w 'aqr'
    //   351: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   354: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   357: pop
    //   358: aload #10
    //   360: astore #8
    //   362: aload #11
    //   364: ldc_w 'aqr'
    //   367: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   370: aload_0
    //   371: invokespecial c : ()Lorg/json/JSONObject;
    //   374: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   377: pop
    //   378: aload #10
    //   380: astore #8
    //   382: aload_0
    //   383: getfield a : Landroid/content/Context;
    //   386: iconst_1
    //   387: invokestatic a : (Landroid/content/Context;Z)Lorg/json/JSONObject;
    //   390: astore #7
    //   392: aload #10
    //   394: astore #8
    //   396: aload #11
    //   398: ldc_w 'ddtjg`'
    //   401: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   404: aload #7
    //   406: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   409: pop
    //   410: aload #10
    //   412: astore #8
    //   414: aload #11
    //   416: ldc_w 'urgq'
    //   419: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   422: aload_1
    //   423: invokestatic a : (Lcom/bytedance/sdk/openadsdk/AdSlot;)Lorg/json/JSONObject;
    //   426: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   429: pop
    //   430: aload #10
    //   432: astore #8
    //   434: aload #11
    //   436: ldc_w 'u`'
    //   439: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   442: invokestatic c : ()Ljava/lang/String;
    //   445: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   448: pop
    //   449: aload #10
    //   451: astore #8
    //   453: aload #11
    //   455: ldc_w 'cicmj`j'
    //   458: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   461: ldc_w 'm`km'
    //   464: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   467: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   470: pop
    //   471: aload #10
    //   473: astore #8
    //   475: new org/json/JSONArray
    //   478: dup
    //   479: invokespecial <init> : ()V
    //   482: astore #7
    //   484: aload #10
    //   486: astore #8
    //   488: aload #7
    //   490: aload_0
    //   491: aload_1
    //   492: iload_3
    //   493: aload_2
    //   494: invokespecial a : (Lcom/bytedance/sdk/openadsdk/AdSlot;ILcom/bytedance/sdk/openadsdk/core/model/o;)Lorg/json/JSONObject;
    //   497: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   500: pop
    //   501: aload #10
    //   503: astore #8
    //   505: aload #11
    //   507: ldc_w 'aeqokqu'
    //   510: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   513: aload #7
    //   515: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   518: pop
    //   519: aload #10
    //   521: astore #8
    //   523: aload_0
    //   524: aload #11
    //   526: aload_2
    //   527: invokespecial a : (Lorg/json/JSONObject;Lcom/bytedance/sdk/openadsdk/core/model/o;)V
    //   530: aload #10
    //   532: astore #8
    //   534: invokestatic currentTimeMillis : ()J
    //   537: ldc2_w 1000
    //   540: ldiv
    //   541: lstore #5
    //   543: aload #10
    //   545: astore #8
    //   547: aload #11
    //   549: ldc_w 'tr'
    //   552: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   555: lload #5
    //   557: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   560: pop
    //   561: ldc ''
    //   563: astore #7
    //   565: aload #7
    //   567: astore_2
    //   568: aload #10
    //   570: astore #8
    //   572: aload_1
    //   573: invokevirtual getCodeId : ()Ljava/lang/String;
    //   576: ifnull -> 609
    //   579: aload #7
    //   581: astore_2
    //   582: aload #9
    //   584: ifnull -> 609
    //   587: aload #10
    //   589: astore #8
    //   591: lload #5
    //   593: invokestatic valueOf : (J)Ljava/lang/String;
    //   596: aload_1
    //   597: invokevirtual getCodeId : ()Ljava/lang/String;
    //   600: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   603: aload #9
    //   605: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   608: astore_2
    //   609: aload #10
    //   611: astore #8
    //   613: aload #11
    //   615: ldc_w 'rds\wlai'
    //   618: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   621: aload_2
    //   622: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   625: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   628: pop
    //   629: aload #10
    //   631: astore #8
    //   633: aload #11
    //   635: invokestatic a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   638: astore_1
    //   639: aload_1
    //   640: astore #8
    //   642: aload_1
    //   643: ldc_w 'ae]p`nYqm{ybcc'
    //   646: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   649: ldc_w '4/;-4+0'
    //   652: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   655: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   658: pop
    //   659: aload_1
    //   660: astore #8
    //   662: aload_1
    //   663: ldc_w 'owgqw`gX~lxxeb`Pdhbv'
    //   666: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   669: iconst_1
    //   670: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   673: pop
    //   674: aload_1
    //   675: areturn
    //   676: astore_1
    //   677: aload #8
    //   679: areturn
    //   680: astore #7
    //   682: goto -> 296
    // Exception table:
    //   from	to	target	type
    //   13	22	676	finally
    //   30	43	676	finally
    //   50	56	676	finally
    //   63	68	676	finally
    //   82	89	676	finally
    //   93	101	676	finally
    //   105	111	676	finally
    //   115	125	676	finally
    //   142	149	676	finally
    //   153	161	676	finally
    //   165	171	676	finally
    //   187	194	676	finally
    //   198	206	676	finally
    //   210	216	676	finally
    //   219	235	680	finally
    //   245	296	680	finally
    //   300	314	676	finally
    //   318	336	676	finally
    //   340	358	676	finally
    //   362	378	676	finally
    //   382	392	676	finally
    //   396	410	676	finally
    //   414	430	676	finally
    //   434	449	676	finally
    //   453	471	676	finally
    //   475	484	676	finally
    //   488	501	676	finally
    //   505	519	676	finally
    //   523	530	676	finally
    //   534	543	676	finally
    //   547	561	676	finally
    //   572	579	676	finally
    //   591	609	676	finally
    //   613	629	676	finally
    //   633	639	676	finally
    //   642	659	676	finally
    //   662	674	676	finally
  }
  
  private void a(long paramLong, String paramString1, int paramInt1, a parama, int paramInt2, String paramString2) {}
  
  private void a(a parama) {
    if (parama == null)
      return; 
    String str = parama.c().optString(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lne\\a}rui"), "");
    long l2 = n.r(str);
    int j = n.u(str);
    long l1 = l2;
    if (l2 == 0L)
      l1 = this.d; 
    this.d = l1;
    int i = j;
    if (j == 0)
      i = this.e; 
    this.e = i;
  }
  
  private void a(a parama) {
    List<n> list = parama.b();
    if (list != null) {
      if (list.size() == 0)
        return; 
      for (int i = 0; i < list.size(); i++) {
        n n1 = list.get(i);
        if (n1 != null && n1.b() == null) {
          a("", n1.N());
          a("", n1.O());
          List<k> list1 = n1.Q();
          if (list1 != null && list1.size() > 0)
            for (int j = 0; j < list1.size(); j++)
              a(n1, list1.get(j));  
          if (n1.K() != null)
            a(n1.K().h(), (k)null); 
        } 
      } 
    } 
  }
  
  private void a(n paramn, k paramk) {
    l.c(ApmHelper.ApmHelper1671532477463dc("ile@efnb"), ApmHelper.ApmHelper1671532477463dc("lncgMhaFfmXn|b|{*1"));
    if (paramk == null)
      return; 
    long l = System.currentTimeMillis();
    com.bytedance.sdk.openadsdk.e.a.a(paramk).a(new com.bytedance.sdk.component.d.o(this, l, paramn) {
          public void a(int param1Int, String param1String, Throwable param1Throwable) {
            long l1 = System.currentTimeMillis();
            long l2 = this.a;
            JSONObject jSONObject = new JSONObject();
            try {
              jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("esplvZehll"), param1Int);
              jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("esplvZkb{zkli"), param1String);
            } catch (JSONException jSONException1) {
              JSONException jSONException2 = jSONException1;
              jSONException1.printStackTrace();
            } 
            l.c(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("ile@efnb"), com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lncgMhaFfmXn|b|{*1tr}y"));
            Context context = o.a(this.c);
            n n1 = this.b;
            c.b(context, n1, aa.a(n1), com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("lncg[lkfolUn~a}"), l1 - l2, jSONObject);
          }
          
          public void a(k param1k) {
            throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
          }
        });
  }
  
  private void a(o paramo, z paramz1, z paramz2, int paramInt, z paramz3, n paramn, String paramString) {
    if (!m.d().P())
      return; 
    JSONObject jSONObject = new JSONObject();
    long l2 = 0L;
    long l1 = l2;
    if (paramo != null) {
      l1 = l2;
      try {
        if (paramo.g.a > 0L) {
          jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("cmkfjqYt|hxSygbu"), paramz1.a(paramo.g));
          l1 = paramz3.a(paramo.g);
        } 
        jSONObject.put(ApmHelper.ApmHelper1671532477463dc("ndvtkwmX|`gn"), paramz2.a(paramz1));
        jSONObject.put(ApmHelper.ApmHelper1671532477463dc("sdtfvZrnel"), paramInt);
        jSONObject.put(ApmHelper.ApmHelper1671532477463dc("cmkfjqYbfmUe`k"), paramz3.a(paramz2));
        c.a(this.a, paramn, paramString, com.bytedance.sdk.component.f.c.a.a1671532477457dc("lncg[dbX|`gn"), l1, jSONObject);
        return;
      } catch (Exception exception) {
        return;
      } 
    } 
    jSONObject.put(ApmHelper.ApmHelper1671532477463dc("ndvtkwmX|`gn"), paramz2.a(paramz1));
    jSONObject.put(ApmHelper.ApmHelper1671532477463dc("sdtfvZrnel"), paramInt);
    jSONObject.put(ApmHelper.ApmHelper1671532477463dc("cmkfjqYbfmUe`k"), paramz3.a(paramz2));
    c.a(this.a, paramn, paramString, com.bytedance.sdk.component.f.c.a.a1671532477457dc("lncg[dbX|`gn"), l1, jSONObject);
  }
  
  private void a(n.a parama, b paramb) {
    parama.a(-1, g.a(-1));
    paramb.a(-1);
    b.a(paramb);
  }
  
  private void a(n.b paramb) {
    paramb.a(-1, g.a(-1));
  }
  
  private void a(String paramString, k paramk) {
    if (!TextUtils.isEmpty(paramString)) {
      com.bytedance.sdk.openadsdk.e.a.a(paramString).a(this.g);
      return;
    } 
    if (paramk == null)
      return; 
    com.bytedance.sdk.openadsdk.e.a.a(paramk).a(this.g);
  }
  
  private void a(JSONObject paramJSONObject, o paramo) {
    if (paramo != null) {
      if (paramo.e == null)
        return; 
      try {
        paramJSONObject.put(d.d1671532477445dc("snwqg`YsmdkbS}|`tdqgK|rd"), paramo.e);
        label20: while (true) {
          byte b1 = 74;
          byte b2 = 55;
          while (true) {
            switch (b1) {
              case 72:
                continue label20;
              case 73:
                switch (b2) {
                  case 94:
                    b1 = 73;
                    b2 = 96;
                    break;
                  case 95:
                  case 96:
                    break;
                } 
                continue;
              case 74:
                switch (b2) {
                  default:
                  
                  case 56:
                  case 57:
                    break;
                } 
                break;
            } 
            b1 = 72;
          } 
          break;
        } 
        return;
      } catch (Exception exception) {
        return;
      } 
    } 
  }
  
  private void a(JSONObject paramJSONObject, String paramString, float paramFloat1, float paramFloat2) {
    if (paramFloat1 >= 0.0F && paramFloat2 >= 0.0F) {
      JSONObject jSONObject = new JSONObject();
      JSONArray jSONArray = new JSONArray();
      try {
        jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("whfwl"), (int)paramFloat1);
        jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("hdkdlq"), (int)paramFloat2);
        jSONArray.put(jSONObject);
        paramJSONObject.put(paramString, jSONArray);
        return;
      } catch (Exception exception) {
        return;
      } 
    } 
  }
  
  private void a(JSONObject paramJSONObject, String paramString, int paramInt1, int paramInt2) {
    if (paramInt1 > 0 && paramInt2 > 0) {
      JSONObject jSONObject = new JSONObject();
      JSONArray jSONArray = new JSONArray();
      try {
        jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("whfwl"), paramInt1);
        jSONObject.put(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("hdkdlq"), paramInt2);
        jSONArray.put(jSONObject);
        paramJSONObject.put(paramString, jSONArray);
        paramInt1 = 55;
        byte b = 0;
        label32: while (true) {
          int i = 72;
          byte b1 = b;
          while (true) {
            paramInt2 = paramInt1;
            int j = paramInt1;
            switch (i) {
              default:
                b = b1;
                continue label32;
              case 74:
                label28: while (true) {
                  paramInt1 = paramInt2;
                  b = b1;
                  i = paramInt2;
                  j = paramInt2;
                  switch (b1) {
                    case true:
                      continue label32;
                    default:
                      j = paramInt2;
                      break;
                    case true:
                      while (true) {
                        paramInt1 = i;
                        b = b1;
                        paramInt2 = i;
                        switch (i) {
                          case 29:
                            continue label32;
                          case 30:
                            continue label32;
                          case 31:
                            continue label28;
                        } 
                        i = 30;
                      } 
                    case true:
                      break;
                  } 
                  break;
                } 
                break;
              case 73:
                j = paramInt1;
                if (b1 <= 57)
                  return; 
                break;
              case 72:
                break;
            } 
            i = 73;
            b1 = 16;
            paramInt1 = j;
          } 
          break;
        } 
      } catch (Exception exception) {
        return;
      } 
    } 
  }
  
  private static void a(JSONObject paramJSONObject, String paramString1, String paramString2) throws JSONException {
    if (!TextUtils.isEmpty(paramString2))
      paramJSONObject.put(paramString1, paramString2); 
  }
  
  @JProtect
  public static String b() {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: invokestatic e : ()Z
    //   11: ifeq -> 30
    //   14: ldc_w 'MHWJ)'
    //   17: astore_0
    //   18: aload_1
    //   19: aload_0
    //   20: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: pop
    //   27: goto -> 88
    //   30: invokestatic b : ()Z
    //   33: ifeq -> 43
    //   36: ldc_w 'FM[NA('
    //   39: astore_0
    //   40: goto -> 18
    //   43: invokestatic n : ()Ljava/lang/String;
    //   46: astore_0
    //   47: aload_0
    //   48: invokestatic a : (Ljava/lang/String;)Z
    //   51: ifeq -> 65
    //   54: aload_1
    //   55: ldc_w 'ELWJ)'
    //   58: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_0
    //   66: checkcast java/lang/CharSequence
    //   69: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   72: ifne -> 88
    //   75: aload_1
    //   76: aload_0
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: ldc_w '-'
    //   84: astore_0
    //   85: goto -> 18
    //   88: aload_1
    //   89: getstatic android/os/Build$VERSION.INCREMENTAL : Ljava/lang/String;
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload_1
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: areturn
    //   101: astore_0
    //   102: goto -> 96
    // Exception table:
    //   from	to	target	type
    //   8	14	101	finally
    //   18	27	101	finally
    //   30	36	101	finally
    //   43	65	101	finally
    //   65	81	101	finally
    //   88	96	101	finally
  }
  
  private static String b(AdSlot paramAdSlot) {
    String str2 = h.d().n();
    if (paramAdSlot == null) {
      str1 = str2;
      if (TextUtils.isEmpty(str2))
        str1 = ""; 
      return str1;
    } 
    String str1 = str1.getUserData();
    if (TextUtils.isEmpty(str2))
      return str1; 
    if (TextUtils.isEmpty(str1))
      return str2; 
    HashSet<String> hashSet = new HashSet();
    try {
      JSONArray jSONArray = new JSONArray(str1);
      int j = jSONArray.length();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        JSONObject jSONObject = jSONArray.getJSONObject(i);
        if (jSONObject != null)
          hashSet.add(jSONObject.optString(c.c1671532477445dc("n`of"), null)); 
      } 
    } finally {
      str1 = null;
    } 
  }
  
  public static JSONArray b(String paramString) {
    try {
      Set set = com.bytedance.sdk.component.adexpress.a.b.a.b(paramString);
      if (set != null) {
        if (set.size() == 0)
          return null; 
        JSONArray jSONArray = new JSONArray();
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext()) {
          com.bytedance.sdk.component.adexpress.a.c.b b = com.bytedance.sdk.component.adexpress.a.b.a.a(iterator.next());
          if (b != null) {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(n.n1671532477404dc("ie"), b.b());
            jSONObject.put(n.n1671532477404dc("me7"), b.c());
            jSONArray.put(jSONObject);
          } 
        } 
        return jSONArray;
      } 
      return null;
    } catch (Exception exception) {
      Log.e(n.n1671532477404dc("NdvBtlOjxe"), n.n1671532477404dc("gdvSewci|]zgEi}50"), exception);
      return null;
    } 
  }
  
  private JSONArray b(List<FilterWord> paramList) {
    if (paramList == null || paramList.isEmpty())
      return null; 
    JSONArray jSONArray = new JSONArray();
    Iterator<FilterWord> iterator = paramList.iterator();
    while (iterator.hasNext())
      jSONArray.put(((FilterWord)iterator.next()).getId()); 
    return jSONArray;
  }
  
  @JProtect
  private JSONObject b(String paramString, List<FilterWord> paramList) {
    JSONObject jSONObject = new JSONObject();
    try {
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put(d.d1671532477445dc("abvjkk"), d.d1671532477445dc("dhqomnc"));
      jSONObject1.put(d.d1671532477445dc("thofwqgjx"), System.currentTimeMillis());
      jSONObject1.put(d.d1671532477445dc("ae]p`nYqm{ybcc"), d.d1671532477445dc("4/;-4+0"));
      jSONObject1.put(d.d1671532477445dc("eyvqe"), paramString);
      jSONObject1.put(d.d1671532477445dc("fhnwawYpg{nx"), b(paramList));
      JSONArray jSONArray = new JSONArray();
      jSONArray.put(jSONObject1);
      jSONObject.put(d.d1671532477445dc("abvjkku"), jSONArray);
      return jSONObject;
    } catch (Exception exception) {
      return jSONObject;
    } 
  }
  
  @JProtect
  private void b(AdSlot paramAdSlot, o paramo, int paramInt, n.a parama) {
    // Byte code:
    //   0: invokestatic e : ()V
    //   3: new com/bytedance/sdk/openadsdk/core/model/b
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: astore #6
    //   12: aload #6
    //   14: aload_1
    //   15: invokevirtual a : (Lcom/bytedance/sdk/openadsdk/AdSlot;)V
    //   18: invokestatic a : ()Z
    //   21: ifne -> 59
    //   24: aload #4
    //   26: ifnull -> 58
    //   29: aload #4
    //   31: sipush #1000
    //   34: ldc_w 'Ae"qatsb{}*b-zj}a}aug{a9jzin{{\\frOADUB\\bJEEXLM[H]FFfVV^V^|s'
    //   37: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   40: invokeinterface a : (ILjava/lang/String;)V
    //   45: aload #6
    //   47: sipush #1000
    //   50: invokevirtual a : (I)V
    //   53: aload #6
    //   55: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   58: return
    //   59: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   62: invokevirtual J : ()Z
    //   65: ifne -> 101
    //   68: aload #4
    //   70: ifnull -> 100
    //   73: aload #4
    //   75: bipush #-16
    //   77: bipush #-16
    //   79: invokestatic a : (I)Ljava/lang/String;
    //   82: invokeinterface a : (ILjava/lang/String;)V
    //   87: aload #6
    //   89: sipush #1001
    //   92: invokevirtual a : (I)V
    //   95: aload #6
    //   97: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   100: return
    //   101: aload #4
    //   103: ifnonnull -> 107
    //   106: return
    //   107: aload_0
    //   108: aload_1
    //   109: invokevirtual getCodeId : ()Ljava/lang/String;
    //   112: invokespecial c : (Ljava/lang/String;)Z
    //   115: ifeq -> 145
    //   118: aload #4
    //   120: bipush #-8
    //   122: bipush #-8
    //   124: invokestatic a : (I)Ljava/lang/String;
    //   127: invokeinterface a : (ILjava/lang/String;)V
    //   132: aload #6
    //   134: bipush #-8
    //   136: invokevirtual a : (I)V
    //   139: aload #6
    //   141: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   144: return
    //   145: aload_1
    //   146: invokevirtual getBidAdm : ()Ljava/lang/String;
    //   149: checkcast java/lang/CharSequence
    //   152: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   155: ifne -> 488
    //   158: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/h/b;
    //   161: invokevirtual c : ()V
    //   164: aload #6
    //   166: iconst_2
    //   167: invokevirtual b : (I)V
    //   170: aload #6
    //   172: aload_1
    //   173: invokevirtual getBidAdm : ()Ljava/lang/String;
    //   176: invokevirtual a : (Ljava/lang/String;)V
    //   179: ldc_w 'bhfgmka'
    //   182: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   185: astore #7
    //   187: new java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: astore #8
    //   196: aload #8
    //   198: ldc_w 'gdvB`%dnlHnf,d}/fp~zp９c8nswp=zvRDAWH\WI[YN\\fYFJCWGAGXR\[_JXLK)2'.!+2}h#/\\r)#bnfyk'
    //   201: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload #8
    //   210: aload_1
    //   211: invokevirtual getBidAdm : ()Ljava/lang/String;
    //   214: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: pop
    //   221: aload #7
    //   223: aload #8
    //   225: invokevirtual toString : ()Ljava/lang/String;
    //   228: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   231: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   234: invokevirtual N : ()Z
    //   237: ifeq -> 269
    //   240: invokestatic getAdManager : ()Lcom/bytedance/sdk/openadsdk/TTAdManager;
    //   243: invokeinterface getDebugLog : ()I
    //   248: iconst_1
    //   249: if_icmpne -> 269
    //   252: ldc_w 'P`ldh`YCmklS@aku'
    //   255: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   258: aload_1
    //   259: invokevirtual getBidAdm : ()Ljava/lang/String;
    //   262: aload_0
    //   263: getfield a : Landroid/content/Context;
    //   266: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    //   269: aload_0
    //   270: aload_1
    //   271: invokevirtual getBidAdm : ()Ljava/lang/String;
    //   274: invokestatic jsonObjectInit : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   277: invokevirtual a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   280: astore #7
    //   282: aload #7
    //   284: ifnonnull -> 296
    //   287: aload_0
    //   288: aload #4
    //   290: aload #6
    //   292: invokespecial a : (Lcom/bytedance/sdk/openadsdk/core/n$a;Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   295: return
    //   296: aload #7
    //   298: aload_1
    //   299: aload_2
    //   300: invokestatic a : (Lorg/json/JSONObject;Lcom/bytedance/sdk/openadsdk/AdSlot;Lcom/bytedance/sdk/openadsdk/core/model/o;)Lcom/bytedance/sdk/openadsdk/core/o$a;
    //   303: astore_1
    //   304: aload #6
    //   306: aload_1
    //   307: getfield j : Ljava/util/ArrayList;
    //   310: invokevirtual a : (Ljava/util/ArrayList;)V
    //   313: aload_0
    //   314: getfield a : Landroid/content/Context;
    //   317: aload_1
    //   318: getfield i : Ljava/lang/String;
    //   321: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)V
    //   324: aload_1
    //   325: getfield d : I
    //   328: sipush #20000
    //   331: if_icmpeq -> 364
    //   334: aload #4
    //   336: aload_1
    //   337: getfield d : I
    //   340: aload_1
    //   341: getfield e : Ljava/lang/String;
    //   344: invokeinterface a : (ILjava/lang/String;)V
    //   349: aload #6
    //   351: aload_1
    //   352: getfield d : I
    //   355: invokevirtual a : (I)V
    //   358: aload #6
    //   360: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   363: return
    //   364: aload_1
    //   365: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   368: ifnonnull -> 380
    //   371: aload_0
    //   372: aload #4
    //   374: aload #6
    //   376: invokespecial a : (Lcom/bytedance/sdk/openadsdk/core/n$a;Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   379: return
    //   380: aload_1
    //   381: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   384: invokevirtual b : ()Ljava/util/List;
    //   387: ifnull -> 428
    //   390: aload_1
    //   391: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   394: invokevirtual b : ()Ljava/util/List;
    //   397: invokeinterface size : ()I
    //   402: ifle -> 428
    //   405: aload_1
    //   406: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   409: invokevirtual b : ()Ljava/util/List;
    //   412: iconst_0
    //   413: invokeinterface get : (I)Ljava/lang/Object;
    //   418: checkcast com/bytedance/sdk/openadsdk/core/model/n
    //   421: iload_3
    //   422: invokestatic b : (I)Ljava/lang/String;
    //   425: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;)V
    //   428: aload_1
    //   429: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   432: aload #7
    //   434: invokevirtual toString : ()Ljava/lang/String;
    //   437: invokevirtual c : (Ljava/lang/String;)V
    //   440: aload #4
    //   442: aload_1
    //   443: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   446: aload #6
    //   448: invokeinterface a : (Lcom/bytedance/sdk/openadsdk/core/model/a;Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   453: aload_0
    //   454: aload_1
    //   455: getfield h : Lcom/bytedance/sdk/openadsdk/core/model/a;
    //   458: invokespecial a : (Lcom/bytedance/sdk/openadsdk/core/model/a;)V
    //   461: return
    //   462: astore_1
    //   463: ldc_w 'NdvBtlOjxe'
    //   466: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   469: ldc_w 'gdv#ea&bz{ey6-'
    //   472: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   475: aload_1
    //   476: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   479: aload_0
    //   480: aload #4
    //   482: aload #6
    //   484: invokespecial a : (Lcom/bytedance/sdk/openadsdk/core/n$a;Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   487: return
    //   488: aload_0
    //   489: aload_1
    //   490: aload_2
    //   491: iload_3
    //   492: invokespecial a : (Lcom/bytedance/sdk/openadsdk/AdSlot;Lcom/bytedance/sdk/openadsdk/core/model/o;I)Lorg/json/JSONObject;
    //   495: astore #8
    //   497: aload #8
    //   499: ifnonnull -> 529
    //   502: aload #4
    //   504: bipush #-9
    //   506: bipush #-9
    //   508: invokestatic a : (I)Ljava/lang/String;
    //   511: invokeinterface a : (ILjava/lang/String;)V
    //   516: aload #6
    //   518: bipush #-9
    //   520: invokevirtual a : (I)V
    //   523: aload #6
    //   525: invokestatic a : (Lcom/bytedance/sdk/openadsdk/core/model/b;)V
    //   528: return
    //   529: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   532: invokevirtual N : ()Z
    //   535: ifeq -> 572
    //   538: invokestatic getAdManager : ()Lcom/bytedance/sdk/openadsdk/TTAdManager;
    //   541: invokeinterface getDebugLog : ()I
    //   546: iconst_1
    //   547: if_icmpne -> 572
    //   550: aload #8
    //   552: invokevirtual toString : ()Ljava/lang/String;
    //   555: astore #7
    //   557: ldc_w 'P`ldh`YCmklS@aku'
    //   560: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   563: aload #7
    //   565: aload_0
    //   566: getfield a : Landroid/content/Context;
    //   569: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    //   572: ldc_w '/`rj+db(}gcdb"}k{>uv`Jwsk6'
    //   575: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   578: iconst_1
    //   579: invokestatic a : (Ljava/lang/String;Z)Ljava/lang/String;
    //   582: astore #9
    //   584: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/i/d;
    //   587: invokevirtual b : ()Lcom/bytedance/sdk/component/f/a;
    //   590: invokevirtual b : ()Lcom/bytedance/sdk/component/f/b/d;
    //   593: astore #7
    //   595: aload #7
    //   597: aload #7
    //   599: aload #9
    //   601: invokestatic a : (Lcom/bytedance/sdk/component/f/b/c;Ljava/lang/String;)Ljava/lang/String;
    //   604: invokevirtual a : (Ljava/lang/String;)V
    //   607: goto -> 610
    //   610: aload #7
    //   612: aload #8
    //   614: invokevirtual a : (Lorg/json/JSONObject;)V
    //   617: aload #9
    //   619: aload #8
    //   621: invokevirtual toString : ()Ljava/lang/String;
    //   624: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;
    //   627: astore #8
    //   629: aload #8
    //   631: ifnull -> 719
    //   634: aload #8
    //   636: invokeinterface size : ()I
    //   641: ifle -> 719
    //   644: ldc_w 'mrqgo%kt{maCiljjbb('
    //   647: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   650: aload #8
    //   652: invokevirtual toString : ()Ljava/lang/String;
    //   655: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
    //   658: aload #8
    //   660: invokeinterface keySet : ()Ljava/util/Set;
    //   665: invokeinterface iterator : ()Ljava/util/Iterator;
    //   670: astore #9
    //   672: aload #9
    //   674: invokeinterface hasNext : ()Z
    //   679: ifeq -> 719
    //   682: aload #9
    //   684: invokeinterface next : ()Ljava/lang/Object;
    //   689: checkcast java/lang/String
    //   692: astore #10
    //   694: aload #7
    //   696: aload #10
    //   698: aload #8
    //   700: aload #10
    //   702: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   707: checkcast java/lang/String
    //   710: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   713: goto -> 672
    //   716: goto -> 672
    //   719: aload #7
    //   721: ldc_w 'Urgq)Dabf}'
    //   724: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   727: invokestatic c : ()Ljava/lang/String;
    //   730: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   733: goto -> 736
    //   736: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/l/z;
    //   739: astore #8
    //   741: aload_1
    //   742: invokevirtual getRequestExtraMap : ()Ljava/util/Map;
    //   745: astore #9
    //   747: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/h;
    //   750: invokevirtual s : ()Z
    //   753: ifeq -> 767
    //   756: aload #9
    //   758: ifnull -> 767
    //   761: iconst_1
    //   762: istore #5
    //   764: goto -> 770
    //   767: iconst_0
    //   768: istore #5
    //   770: iload #5
    //   772: ifeq -> 791
    //   775: aload #9
    //   777: ldc_w 'pfcg[vrfz}'
    //   780: invokestatic a1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   783: aload #8
    //   785: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   790: pop
    //   791: aload #7
    //   793: new com/bytedance/sdk/openadsdk/core/o$2
    //   796: dup
    //   797: aload_0
    //   798: iload #5
    //   800: aload #9
    //   802: aload #8
    //   804: aload #6
    //   806: aload #4
    //   808: aload_1
    //   809: iload_3
    //   810: aload_2
    //   811: invokespecial <init> : (Lcom/bytedance/sdk/openadsdk/core/o;ZLjava/util/Map;Lcom/bytedance/sdk/openadsdk/l/z;Lcom/bytedance/sdk/openadsdk/core/model/b;Lcom/bytedance/sdk/openadsdk/core/n$a;Lcom/bytedance/sdk/openadsdk/AdSlot;ILcom/bytedance/sdk/openadsdk/core/model/o;)V
    //   814: invokevirtual a : (Lcom/bytedance/sdk/component/f/a/a;)V
    //   817: getstatic com/bytedance/sdk/openadsdk/c/a/e.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   820: invokevirtual incrementAndGet : ()I
    //   823: pop
    //   824: invokestatic c : ()V
    //   827: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/core/d;
    //   830: invokevirtual b : ()V
    //   833: return
    //   834: astore #10
    //   836: goto -> 610
    //   839: astore #10
    //   841: goto -> 716
    //   844: astore #8
    //   846: goto -> 736
    // Exception table:
    //   from	to	target	type
    //   269	282	462	finally
    //   287	295	462	finally
    //   296	363	462	finally
    //   364	379	462	finally
    //   380	428	462	finally
    //   428	461	462	finally
    //   595	607	834	java/lang/Exception
    //   694	713	839	java/lang/Exception
    //   719	733	844	java/lang/Exception
  }
  
  @JProtect
  private JSONObject c() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("aqrj`"), h.d().f());
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("n`of"), h.d().g());
      g(jSONObject);
      Context context = m.a();
      String str2 = "";
      String str1 = str2;
      if (context != null)
        try {
          str1 = context.getPackageResourcePath();
        } finally {
          str1 = null;
          String str = com.bytedance.sdk.component.f.c.a.a1671532477457dc("NdvBtlOjxe");
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(com.bytedance.sdk.component.f.c.a.a1671532477457dc("f`koaa&sg)mnx-zgu1scdytymstr=wqSUCOHDRNGG\n[MNENWT\022CUA^\031\030\\HISO\004\037"));
          stringBuilder.append(str1.getMessage());
          l.e(str, stringBuilder.toString());
        }  
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("p`ahebcXagymabP`pf{"), str1);
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("ir]selbXiyz"), h.d().l());
      if (c.b() != null)
        jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("aqi\\wlai"), c.b()); 
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("aqr\\vphiagmTxdcj"), (System.currentTimeMillis() - PAGSdk.INIT_TIME) / 1000L);
      jSONObject.put(com.bytedance.sdk.component.f.c.a.a1671532477457dc("flumehc"), f.g(this.a));
      str1 = com.bytedance.sdk.component.f.c.a.a1671532477457dc("ir]jjlr");
      if (TTAdSdk.isInitSuccess()) {
        boolean bool1 = true;
        jSONObject.put(str1, bool1);
        return jSONObject;
      } 
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
    boolean bool = false;
    jSONObject.put((String)jSONException, bool);
    return jSONObject;
  }
  
  private boolean c(String paramString) {
    if (b.a())
      return true; 
    if (b.a(paramString)) {
      paramString = b.b();
      if (!TextUtils.isEmpty(paramString))
        c.a(this.a, paramString, System.currentTimeMillis()); 
      return true;
    } 
    return false;
  }
  
  private boolean c(JSONObject paramJSONObject) {
    return (paramJSONObject != null && paramJSONObject.length() > 0);
  }
  
  @JProtect
  private JSONObject d() {
    // Byte code:
    //   0: bipush #26
    //   2: istore_2
    //   3: bipush #31
    //   5: istore #4
    //   7: iload_2
    //   8: istore_3
    //   9: iload #4
    //   11: tableswitch default -> 36, 31 -> 716, 32 -> 39, 33 -> 716
    //   36: goto -> 726
    //   39: iload_3
    //   40: istore_2
    //   41: iload_3
    //   42: tableswitch default -> 68, 18 -> 71, 19 -> 71, 20 -> 3
    //   68: goto -> 716
    //   71: new org/json/JSONObject
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore #6
    //   80: aload #6
    //   82: ldc_w 'u`'
    //   85: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   88: invokestatic c : ()Ljava/lang/String;
    //   91: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   94: pop
    //   95: aload #6
    //   97: ldc_w 'ae]p`nYqm{ybcc'
    //   100: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   103: ldc_w '4/;-4+0'
    //   106: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   109: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   112: pop
    //   113: aload #6
    //   115: ldc_w 'sho\ku'
    //   118: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   121: aload_0
    //   122: getfield a : Landroid/content/Context;
    //   125: invokestatic a : (Landroid/content/Context;)Ljava/lang/String;
    //   128: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   131: pop
    //   132: ldc_w 'rnmw'
    //   135: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   138: astore #7
    //   140: aload_0
    //   141: getfield b : Z
    //   144: istore #5
    //   146: iconst_1
    //   147: istore_3
    //   148: iload #5
    //   150: ifeq -> 743
    //   153: iconst_1
    //   154: istore_2
    //   155: goto -> 158
    //   158: aload #6
    //   160: aload #7
    //   162: iload_2
    //   163: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   166: pop
    //   167: aload #6
    //   169: ldc_w 'thof~jhb'
    //   172: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   175: invokestatic f : ()I
    //   178: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   181: pop
    //   182: aload #6
    //   184: ldc_w 'abafwv'
    //   187: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   190: aload_0
    //   191: getfield a : Landroid/content/Context;
    //   194: invokestatic a : (Landroid/content/Context;)Ljava/lang/String;
    //   197: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   200: pop
    //   201: aload #6
    //   203: ldc_w 'or'
    //   206: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   209: ldc_w 'Aofqklb'
    //   212: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   215: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   218: pop
    //   219: aload #6
    //   221: ldc_w 'or]uawungg'
    //   224: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   227: getstatic android/os/Build$VERSION.RELEASE : Ljava/lang/String;
    //   230: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   233: pop
    //   234: aload #6
    //   236: ldc_w 'or]btl'
    //   239: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   242: getstatic android/os/Build$VERSION.SDK_INT : I
    //   245: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   248: pop
    //   249: aload #6
    //   251: ldc_w 'ddtjg`Ysqyo'
    //   254: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   257: aload_0
    //   258: getfield c : Ljava/lang/String;
    //   261: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   264: pop
    //   265: aload #6
    //   267: ldc_w 'ddtjg`Yjgmog'
    //   270: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   273: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   276: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   279: pop
    //   280: aload #6
    //   282: ldc_w 'ddtjg`Yezhdo'
    //   285: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   288: getstatic android/os/Build.BRAND : Ljava/lang/String;
    //   291: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   294: pop
    //   295: aload #6
    //   297: ldc_w 'ddtjg`Yjigmmnzzbt`'
    //   300: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   303: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   306: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   309: pop
    //   310: aload #6
    //   312: ldc_w 'l`ldqdab'
    //   315: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   318: invokestatic getDefault : ()Ljava/util/Locale;
    //   321: invokevirtual getLanguage : ()Ljava/lang/String;
    //   324: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   327: pop
    //   328: ldc_w 'rdqlhprngg'
    //   331: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   334: astore #7
    //   336: new java/lang/StringBuilder
    //   339: dup
    //   340: invokespecial <init> : ()V
    //   343: astore #8
    //   345: aload #8
    //   347: aload_0
    //   348: getfield a : Landroid/content/Context;
    //   351: invokestatic d : (Landroid/content/Context;)I
    //   354: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   357: pop
    //   358: aload #8
    //   360: ldc_w 'x'
    //   363: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   366: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   369: pop
    //   370: aload #8
    //   372: aload_0
    //   373: getfield a : Landroid/content/Context;
    //   376: invokestatic c : (Landroid/content/Context;)I
    //   379: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   382: pop
    //   383: aload #6
    //   385: aload #7
    //   387: aload #8
    //   389: invokevirtual toString : ()Ljava/lang/String;
    //   392: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   395: pop
    //   396: aload #6
    //   398: ldc_w 'dhqshdXlldxeyw'
    //   401: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   404: aload_0
    //   405: getfield a : Landroid/content/Context;
    //   408: invokestatic g : (Landroid/content/Context;)I
    //   411: invokestatic a : (I)Ljava/lang/String;
    //   414: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   417: pop
    //   418: aload #6
    //   420: ldc_w 'ddlpmqXlyc'
    //   423: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   426: aload_0
    //   427: getfield a : Landroid/content/Context;
    //   430: invokestatic g : (Landroid/content/Context;)I
    //   433: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   436: pop
    //   437: aload #6
    //   439: ldc_w 'ddtjg`Ynl'
    //   442: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   445: aload_0
    //   446: getfield a : Landroid/content/Context;
    //   449: invokestatic a : (Landroid/content/Context;)Ljava/lang/String;
    //   452: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   455: pop
    //   456: aload #6
    //   458: ldc_w 'ahf'
    //   461: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   464: ldc_w '1252'
    //   467: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   470: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   473: pop
    //   474: aload #6
    //   476: ldc_w 'rno'
    //   479: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   482: invokestatic b : ()Ljava/lang/String;
    //   485: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   488: pop
    //   489: aload #6
    //   491: ldc_w 'cqw\ego'
    //   494: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   497: getstatic android/os/Build.CPU_ABI : Ljava/lang/String;
    //   500: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   503: pop
    //   504: aload #6
    //   506: ldc_w 'uu'
    //   509: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   512: aload_0
    //   513: getfield e : I
    //   516: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   519: pop
    //   520: aload #6
    //   522: ldc_w 'uhf'
    //   525: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   528: aload_0
    //   529: getfield d : J
    //   532: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   535: pop
    //   536: aload #6
    //   538: ldc_w 'gnmdh`Yfam'
    //   541: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   544: invokestatic a : ()Lcom/com/bytedance/overseas/sdk/b/a;
    //   547: invokevirtual b : ()Ljava/lang/String;
    //   550: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   553: pop
    //   554: aload #6
    //   556: ldc_w 'lnabh`Ykigm~mjk'
    //   559: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   562: invokestatic c : ()Ljava/lang/String;
    //   565: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   568: pop
    //   569: invokestatic d : ()F
    //   572: fstore_1
    //   573: aload #6
    //   575: ldc_w 'sbpfakYez`mcx'
    //   578: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   581: fload_1
    //   582: ldc_w 10.0
    //   585: fmul
    //   586: f2d
    //   587: invokestatic ceil : (D)D
    //   590: ldc2_w 10.0
    //   593: ddiv
    //   594: invokevirtual put : (Ljava/lang/String;D)Lorg/json/JSONObject;
    //   597: pop
    //   598: ldc_w 'ir]pgwcbfVemj'
    //   601: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   604: astore #7
    //   606: iload_3
    //   607: istore_2
    //   608: invokestatic a : ()Z
    //   611: ifeq -> 616
    //   614: iconst_0
    //   615: istore_2
    //   616: aload #6
    //   618: aload #7
    //   620: iload_2
    //   621: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   624: pop
    //   625: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/settings/j;
    //   628: astore #7
    //   630: aload #6
    //   632: ldc_w 'fnp`aZjffnjkh'
    //   635: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   638: aload_0
    //   639: getfield a : Landroid/content/Context;
    //   642: ldc_w 'tu]`ljitmVfjbj{nwt'
    //   645: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   648: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   651: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   654: pop
    //   655: aload #7
    //   657: ldc_w 'moa'
    //   660: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   663: invokevirtual w : (Ljava/lang/String;)Z
    //   666: ifeq -> 684
    //   669: aload #6
    //   671: ldc_w 'moa'
    //   674: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   677: invokestatic c : ()Ljava/lang/String;
    //   680: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   683: pop
    //   684: aload #7
    //   686: ldc_w 'mba'
    //   689: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   692: invokevirtual w : (Ljava/lang/String;)Z
    //   695: ifeq -> 713
    //   698: aload #6
    //   700: ldc_w 'mba'
    //   703: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
    //   706: invokestatic b : ()Ljava/lang/String;
    //   709: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   712: pop
    //   713: aload #6
    //   715: areturn
    //   716: bipush #32
    //   718: istore #4
    //   720: bipush #18
    //   722: istore_3
    //   723: goto -> 9
    //   726: iload_3
    //   727: istore_2
    //   728: iload #4
    //   730: bipush #78
    //   732: if_icmple -> 3
    //   735: goto -> 735
    //   738: astore #7
    //   740: aload #6
    //   742: areturn
    //   743: iconst_0
    //   744: istore_2
    //   745: goto -> 158
    // Exception table:
    //   from	to	target	type
    //   80	146	738	java/lang/Exception
    //   158	606	738	java/lang/Exception
    //   608	614	738	java/lang/Exception
    //   616	684	738	java/lang/Exception
    //   684	713	738	java/lang/Exception
  }
  
  @JProtect
  private void d(JSONObject paramJSONObject) {
    // Byte code:
    //   0: invokestatic d : ()Lcom/bytedance/sdk/openadsdk/core/h;
    //   3: invokevirtual s : ()Z
    //   6: ifne -> 10
    //   9: return
    //   10: aload_1
    //   11: ldc_w 'hdcgaw'
    //   14: invokestatic c1671532477431dc : (Ljava/lang/String;)Ljava/lang/String;
    //   17: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   20: ldc_w 'ahf'
    //   23: invokestatic c1671532477431dc : (Ljava/lang/String;)Ljava/lang/String;
    //   26: ldc_w '4441'
    //   29: invokestatic c1671532477431dc : (Ljava/lang/String;)Ljava/lang/String;
    //   32: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   35: pop
    //   36: goto -> 44
    //   39: astore_2
    //   40: aload_2
    //   41: invokevirtual printStackTrace : ()V
    //   44: aload_1
    //   45: invokestatic a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   48: astore_2
    //   49: aload_0
    //   50: aload_2
    //   51: invokespecial c : (Lorg/json/JSONObject;)Z
    //   54: ifne -> 60
    //   57: goto -> 62
    //   60: aload_2
    //   61: astore_1
    //   62: aload_0
    //   63: aload_1
    //   64: invokespecial e : (Lorg/json/JSONObject;)Ljava/util/Map;
    //   67: astore_3
    //   68: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/i/d;
    //   71: invokevirtual b : ()Lcom/bytedance/sdk/component/f/a;
    //   74: invokevirtual b : ()Lcom/bytedance/sdk/component/f/b/d;
    //   77: astore_2
    //   78: aload_2
    //   79: invokestatic m : ()Ljava/lang/String;
    //   82: invokevirtual a : (Ljava/lang/String;)V
    //   85: aload_3
    //   86: ifnull -> 151
    //   89: aload_3
    //   90: invokeinterface entrySet : ()Ljava/util/Set;
    //   95: invokeinterface iterator : ()Ljava/util/Iterator;
    //   100: astore_3
    //   101: aload_3
    //   102: invokeinterface hasNext : ()Z
    //   107: ifeq -> 151
    //   110: aload_3
    //   111: invokeinterface next : ()Ljava/lang/Object;
    //   116: checkcast java/util/Map$Entry
    //   119: astore #4
    //   121: aload_2
    //   122: aload #4
    //   124: invokeinterface getKey : ()Ljava/lang/Object;
    //   129: checkcast java/lang/String
    //   132: aload #4
    //   134: invokeinterface getValue : ()Ljava/lang/Object;
    //   139: checkcast java/lang/String
    //   142: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   145: goto -> 101
    //   148: goto -> 101
    //   151: aload_2
    //   152: aload_1
    //   153: invokevirtual toString : ()Ljava/lang/String;
    //   156: invokevirtual c : (Ljava/lang/String;)V
    //   159: aload_2
    //   160: ldc_w 'Urgq)Dabf}'
    //   163: invokestatic c1671532477431dc : (Ljava/lang/String;)Ljava/lang/String;
    //   166: invokestatic c : ()Ljava/lang/String;
    //   169: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   172: aload_2
    //   173: new com/bytedance/sdk/openadsdk/core/o$5
    //   176: dup
    //   177: aload_0
    //   178: invokespecial <init> : (Lcom/bytedance/sdk/openadsdk/core/o;)V
    //   181: invokevirtual a : (Lcom/bytedance/sdk/component/f/a/a;)V
    //   184: return
    //   185: astore #4
    //   187: goto -> 148
    //   190: astore_1
    //   191: goto -> 172
    // Exception table:
    //   from	to	target	type
    //   10	36	39	java/lang/Exception
    //   121	145	185	java/lang/Exception
    //   159	172	190	java/lang/Exception
  }
  
  private Map<String, String> e(JSONObject paramJSONObject) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put(d.d1671532477445dc("Cnlwakr*\\pzn"), d.d1671532477445dc("aqromfgsafd$f~aa+1q{ugerl$ooz0&"));
    if (c(paramJSONObject))
      hashMap.put(d.d1671532477445dc("Cnlwakr*Mgidhd`h"), d.d1671532477445dc("uokljZuccVoeobjj")); 
    return (Map)hashMap;
  }
  
  private static boolean e() {
    boolean bool = false;
    try {
      if (!(new File(ApmHelper.ApmHelper1671532477463dc("/r{pp`k(j`d$x"))).exists()) {
        boolean bool1 = (new File(ApmHelper.ApmHelper1671532477463dc("/r{pp`k(pkce#~{"))).exists();
        return bool1 ? true : bool;
      } 
      return true;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  private static int f() {
    int j = TimeZone.getDefault().getRawOffset() / 3600000;
    int i = j;
    if (j < -12)
      i = -12; 
    j = i;
    if (i > 12)
      j = 12; 
    return j;
  }
  
  private boolean f(JSONObject paramJSONObject) {
    if (paramJSONObject != null)
      try {
        boolean bool = paramJSONObject.optString(com.bytedance.sdk.component.f.c.a.a1671532477457dc("mdqpebc")).equalsIgnoreCase(com.bytedance.sdk.component.f.c.a.a1671532477457dc("sta`avu"));
        label19: while (true) {
          byte b1 = 94;
          for (byte b2 = 125;; b2 = 95) {
            switch (b1) {
              default:
                continue label19;
              case 95:
                switch (b2) {
                  default:
                    switch (b2) {
                      case 56:
                        continue label19;
                      default:
                        break;
                      case 55:
                      case 57:
                        break;
                    } 
                  case 95:
                    return bool;
                  case 94:
                  case 96:
                    break;
                } 
                break;
              case 96:
              
              case 94:
                break;
            } 
            b1 = 95;
          } 
          break;
        } 
      } finally {} 
    return false;
  }
  
  private String g() {
    if (f.b(this.a)) {
      String str1 = "tw";
      return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str1);
    } 
    if (f.a(this.a))
      return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("aofqklbXxhn"); 
    String str = "aofqklb";
    return com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc(str);
  }
  
  @JProtect
  private void g(JSONObject paramJSONObject) {
    try {
      paramJSONObject.put(d.d1671532477445dc("p`ahebcXfhgn"), aa.e());
      paramJSONObject.put(d.d1671532477445dc("vdppmjhXkfnn"), aa.f());
      paramJSONObject.put(d.d1671532477445dc("vdppmjh"), aa.g());
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  public com.bytedance.sdk.component.adexpress.a.c.a a() {
    boolean bool = f.a();
    com.bytedance.sdk.component.f.b.b b2 = null;
    if (!bool)
      return null; 
    com.bytedance.sdk.component.f.b.b b1 = d.a().b().c();
    try {
      b1.a(d.a((c)b1, m.d().F()));
    } catch (Exception exception1) {
      exception1.printStackTrace();
    } 
    com.bytedance.sdk.component.f.b b = b1.a();
    b1 = b2;
    if (b != null) {
      b1 = b2;
      try {
        com.bytedance.sdk.component.adexpress.a.c.a a;
        if (b.f())
          a = com.bytedance.sdk.component.adexpress.a.c.a.d(b.d()); 
        return a;
      } catch (Exception exception) {
        return null;
      } 
    } 
    return (com.bytedance.sdk.component.adexpress.a.c.a)exception;
  }
  
  @JProtect
  public e a(List<a> paramList) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore_3
    //   4: invokestatic a : ()Z
    //   7: ifne -> 12
    //   10: aconst_null
    //   11: areturn
    //   12: ldc ''
    //   14: astore #10
    //   16: aload #10
    //   18: astore #9
    //   20: aload_1
    //   21: invokeinterface size : ()I
    //   26: ifle -> 87
    //   29: aload #10
    //   31: astore #9
    //   33: aload_1
    //   34: iconst_0
    //   35: invokeinterface get : (I)Ljava/lang/Object;
    //   40: ifnull -> 87
    //   43: aload #10
    //   45: astore #9
    //   47: aload_1
    //   48: iconst_0
    //   49: invokeinterface get : (I)Ljava/lang/Object;
    //   54: checkcast com/bytedance/sdk/openadsdk/c/a
    //   57: invokevirtual c : ()Lorg/json/JSONObject;
    //   60: ifnull -> 87
    //   63: aload_1
    //   64: iconst_0
    //   65: invokeinterface get : (I)Ljava/lang/Object;
    //   70: checkcast com/bytedance/sdk/openadsdk/c/a
    //   73: invokevirtual c : ()Lorg/json/JSONObject;
    //   76: ldc_w 'aqr\hjaX}{f'
    //   79: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   82: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   85: astore #9
    //   87: new org/json/JSONObject
    //   90: dup
    //   91: invokespecial <init> : ()V
    //   94: astore #10
    //   96: aload_0
    //   97: aload_1
    //   98: iconst_0
    //   99: invokeinterface get : (I)Ljava/lang/Object;
    //   104: checkcast com/bytedance/sdk/openadsdk/c/a
    //   107: invokespecial a : (Lcom/bytedance/sdk/openadsdk/c/a;)V
    //   110: aload #10
    //   112: ldc_w 'hdcgaw'
    //   115: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   118: aload_0
    //   119: invokespecial d : ()Lorg/json/JSONObject;
    //   122: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   125: pop
    //   126: new org/json/JSONArray
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: astore #11
    //   135: aload_1
    //   136: invokeinterface iterator : ()Ljava/util/Iterator;
    //   141: astore_1
    //   142: aload_1
    //   143: invokeinterface hasNext : ()Z
    //   148: ifeq -> 172
    //   151: aload #11
    //   153: aload_1
    //   154: invokeinterface next : ()Ljava/lang/Object;
    //   159: checkcast com/bytedance/sdk/openadsdk/c/a
    //   162: invokevirtual d : ()Lorg/json/JSONObject;
    //   165: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   168: pop
    //   169: goto -> 142
    //   172: aload #10
    //   174: ldc_w 'ewgmp'
    //   177: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   180: aload #11
    //   182: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   185: pop
    //   186: invokestatic currentTimeMillis : ()J
    //   189: lstore #5
    //   191: aload #10
    //   193: ldc_w '_fgm[qojm'
    //   196: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   199: lload #5
    //   201: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   204: pop
    //   205: aload #10
    //   207: ldc_w 'lnabhZrnel'
    //   210: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   213: lload #5
    //   215: ldc2_w 1000
    //   218: ldiv
    //   219: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   222: pop
    //   223: aload #10
    //   225: invokestatic a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   228: astore #11
    //   230: aload #11
    //   232: astore_1
    //   233: aload_0
    //   234: aload #11
    //   236: invokespecial c : (Lorg/json/JSONObject;)Z
    //   239: ifne -> 245
    //   242: aload #10
    //   244: astore_1
    //   245: aload_0
    //   246: aload_1
    //   247: invokespecial e : (Lorg/json/JSONObject;)Ljava/util/Map;
    //   250: astore #12
    //   252: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/i/d;
    //   255: invokevirtual b : ()Lcom/bytedance/sdk/component/f/a;
    //   258: invokevirtual b : ()Lcom/bytedance/sdk/component/f/b/d;
    //   261: astore #11
    //   263: aload #11
    //   265: aload #9
    //   267: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   270: invokevirtual a : (Ljava/lang/String;)V
    //   273: aload #12
    //   275: ifnull -> 342
    //   278: aload #12
    //   280: invokeinterface entrySet : ()Ljava/util/Set;
    //   285: invokeinterface iterator : ()Ljava/util/Iterator;
    //   290: astore #9
    //   292: aload #9
    //   294: invokeinterface hasNext : ()Z
    //   299: ifeq -> 342
    //   302: aload #9
    //   304: invokeinterface next : ()Ljava/lang/Object;
    //   309: checkcast java/util/Map$Entry
    //   312: astore #12
    //   314: aload #11
    //   316: aload #12
    //   318: invokeinterface getKey : ()Ljava/lang/Object;
    //   323: checkcast java/lang/String
    //   326: aload #12
    //   328: invokeinterface getValue : ()Ljava/lang/Object;
    //   333: checkcast java/lang/String
    //   336: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   339: goto -> 292
    //   342: aload #11
    //   344: aload_1
    //   345: invokevirtual toString : ()Ljava/lang/String;
    //   348: invokevirtual c : (Ljava/lang/String;)V
    //   351: aload #11
    //   353: ldc_w 'Urgq)Dabf}'
    //   356: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   359: invokestatic c : ()Ljava/lang/String;
    //   362: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   365: aload #11
    //   367: invokevirtual a : ()Lcom/bytedance/sdk/component/f/b;
    //   370: astore #11
    //   372: aload #11
    //   374: ifnull -> 576
    //   377: aload #11
    //   379: invokevirtual f : ()Z
    //   382: ifeq -> 576
    //   385: aload #11
    //   387: invokevirtual d : ()Ljava/lang/String;
    //   390: checkcast java/lang/CharSequence
    //   393: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   396: ifne -> 576
    //   399: aload_0
    //   400: aload #11
    //   402: invokevirtual d : ()Ljava/lang/String;
    //   405: invokestatic jsonObjectInit : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   408: invokespecial f : (Lorg/json/JSONObject;)Z
    //   411: istore #7
    //   413: goto -> 416
    //   416: ldc_w 'esplv%sicge|b'
    //   419: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   422: astore #9
    //   424: aload #11
    //   426: ifnull -> 582
    //   429: aload #11
    //   431: invokevirtual a : ()I
    //   434: istore_2
    //   435: goto -> 438
    //   438: iload #7
    //   440: ifne -> 463
    //   443: iload_2
    //   444: sipush #200
    //   447: if_icmpne -> 463
    //   450: ldc_w 'sdpuaw&tip*ecy.|erqvgf'
    //   453: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   456: astore_1
    //   457: iconst_1
    //   458: istore #8
    //   460: goto -> 491
    //   463: aload #9
    //   465: astore_1
    //   466: aload #11
    //   468: ifnull -> 587
    //   471: aload #9
    //   473: astore_1
    //   474: aload #11
    //   476: invokevirtual b : ()Ljava/lang/String;
    //   479: ifnull -> 587
    //   482: aload #11
    //   484: invokevirtual b : ()Ljava/lang/String;
    //   487: astore_1
    //   488: goto -> 587
    //   491: aload_0
    //   492: aload #10
    //   494: invokespecial d : (Lorg/json/JSONObject;)V
    //   497: getstatic com/bytedance/sdk/openadsdk/c/a/a.a : Lcom/bytedance/sdk/openadsdk/c/a/b;
    //   500: iload #7
    //   502: iload_2
    //   503: invokestatic currentTimeMillis : ()J
    //   506: lload_3
    //   507: lsub
    //   508: invokestatic a : (Lcom/bytedance/sdk/openadsdk/c/a/b;ZIJ)V
    //   511: new com/bytedance/sdk/openadsdk/c/e
    //   514: dup
    //   515: iload #7
    //   517: iload_2
    //   518: aload_1
    //   519: iload #8
    //   521: invokespecial <init> : (ZILjava/lang/String;Z)V
    //   524: astore_1
    //   525: aload_1
    //   526: areturn
    //   527: astore_1
    //   528: ldc_w 'NdvBtlOjxe'
    //   531: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   534: ldc_w 'uqnleaCqmg~+i|`b'
    //   537: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   540: aload_1
    //   541: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   544: new com/bytedance/sdk/openadsdk/c/e
    //   547: dup
    //   548: iconst_0
    //   549: sipush #509
    //   552: ldc_w 'sdpumfcXj|yr'
    //   555: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   558: iconst_0
    //   559: invokespecial <init> : (ZILjava/lang/String;Z)V
    //   562: areturn
    //   563: astore_1
    //   564: goto -> 223
    //   567: astore #12
    //   569: goto -> 292
    //   572: astore_1
    //   573: goto -> 365
    //   576: iconst_0
    //   577: istore #7
    //   579: goto -> 416
    //   582: iconst_0
    //   583: istore_2
    //   584: goto -> 438
    //   587: iconst_0
    //   588: istore #8
    //   590: goto -> 491
    // Exception table:
    //   from	to	target	type
    //   0	10	527	finally
    //   20	29	527	finally
    //   33	43	527	finally
    //   47	87	527	finally
    //   87	96	527	finally
    //   96	142	563	org/json/JSONException
    //   96	142	527	finally
    //   142	169	563	org/json/JSONException
    //   142	169	527	finally
    //   172	223	563	org/json/JSONException
    //   172	223	527	finally
    //   223	230	527	finally
    //   233	242	527	finally
    //   245	273	527	finally
    //   278	292	527	finally
    //   292	314	527	finally
    //   314	339	567	java/lang/Exception
    //   314	339	527	finally
    //   342	351	527	finally
    //   351	365	572	java/lang/Exception
    //   351	365	527	finally
    //   365	372	527	finally
    //   377	413	527	finally
    //   416	424	527	finally
    //   429	435	527	finally
    //   450	457	527	finally
    //   474	488	527	finally
    //   491	525	527	finally
  }
  
  public JSONObject a(JSONObject paramJSONObject) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 6
    //   4: aload_1
    //   5: areturn
    //   6: getstatic com/bytedance/sdk/openadsdk/core/o.h : Z
    //   9: ifeq -> 106
    //   12: aload_1
    //   13: ldc_w 'cxrkaw'
    //   16: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   19: iconst_m1
    //   20: invokevirtual optInt : (Ljava/lang/String;I)I
    //   23: istore_2
    //   24: aload_1
    //   25: ldc_w 'mdqpebc'
    //   28: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   31: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   34: astore #5
    //   36: aload_1
    //   37: ldc_w 'atawmjhXx{chi'
    //   40: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   43: ldc ''
    //   45: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   48: astore #6
    //   50: aload #5
    //   52: astore #4
    //   54: iload_2
    //   55: iconst_3
    //   56: if_icmpne -> 66
    //   59: aload #5
    //   61: invokestatic b : (Ljava/lang/String;)Ljava/lang/String;
    //   64: astore #4
    //   66: aload #4
    //   68: checkcast java/lang/CharSequence
    //   71: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   74: istore_3
    //   75: iload_3
    //   76: ifne -> 106
    //   79: aload #4
    //   81: invokestatic jsonObjectInit : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   84: astore #4
    //   86: aload #4
    //   88: ldc_w 'atawmjhXx{chi'
    //   91: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   94: aload #6
    //   96: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   99: pop
    //   100: goto -> 109
    //   103: goto -> 109
    //   106: aload_1
    //   107: astore #4
    //   109: getstatic com/bytedance/sdk/openadsdk/core/o.h : Z
    //   112: ifeq -> 118
    //   115: aload #4
    //   117: astore_1
    //   118: aload_1
    //   119: areturn
    //   120: astore #4
    //   122: goto -> 106
    //   125: astore #5
    //   127: goto -> 103
    // Exception table:
    //   from	to	target	type
    //   6	50	120	java/lang/Exception
    //   59	66	120	java/lang/Exception
    //   66	75	120	java/lang/Exception
    //   79	86	120	finally
    //   86	100	125	finally
  }
  
  public void a(AdSlot paramAdSlot, o paramo, int paramInt, n.a parama) {
    a a1 = new a(parama);
    if (Looper.myLooper() == Looper.getMainLooper()) {
      k.b().post((Runnable)new g(this, d.d1671532477445dc("gdvB`"), paramAdSlot, paramo, paramInt, (n.a)a1) {
            public void run() {
              o.a(this.e, this.a, this.b, this.c, this.d);
            }
          });
      return;
    } 
    b(paramAdSlot, paramo, paramInt, (n.a)a1);
  }
  
  public void a(String paramString) {
    com.bytedance.sdk.component.f.b.b b = d.a().b().c();
    b.a(paramString);
    b.a(new com.bytedance.sdk.component.f.a.a(this) {
          public void a(c param1c, com.bytedance.sdk.component.f.b param1b) {
            l.b(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("cmkfjq&eamnbbj.|erqvgf"), param1b.d());
          }
          
          public void a(c param1c, IOException param1IOException) {
            l.b(com.bykv.vk.openvk.component.video.api.c.a.a1671532477452dc("cmkfjq&eamnbbj.iqx~"), param1IOException.toString());
          }
        });
  }
  
  public void a(String paramString, List<FilterWord> paramList) {
    if (!f.a())
      return; 
    JSONObject jSONObject = b(paramString, paramList);
    if (jSONObject == null)
      return; 
    d d = d.a().b().b();
    d.a(aa.d(c.c1671532477431dc("/`rj+db(}gcdb\"jfc}{xqJsa}wn4")));
    d.c(com.bytedance.sdk.component.utils.a.a(jSONObject).toString());
    d.a(new com.bytedance.sdk.component.f.a.a(this) {
          public void a(c param1c, com.bytedance.sdk.component.f.b param1b) {}
          
          public void a(c param1c, IOException param1IOException) {}
        });
  }
  
  public void a(JSONObject paramJSONObject, n.b paramb) {
    // Byte code:
    //   0: bipush #95
    //   2: istore_3
    //   3: bipush #95
    //   5: istore #4
    //   7: iload_3
    //   8: tableswitch default -> 36, 94 -> 99, 95 -> 39, 96 -> 68
    //   36: goto -> 213
    //   39: iload #4
    //   41: tableswitch default -> 68, 94 -> 0, 95 -> 213, 96 -> 0
    //   68: iload #4
    //   70: tableswitch default -> 96, 55 -> 0, 56 -> 213, 57 -> 0
    //   96: goto -> 109
    //   99: iload #4
    //   101: bipush #39
    //   103: if_icmpne -> 109
    //   106: goto -> 0
    //   109: invokestatic a : ()Z
    //   112: ifne -> 135
    //   115: aload_2
    //   116: ifnull -> 134
    //   119: aload_2
    //   120: sipush #1000
    //   123: ldc_w 'Ae"qatsb{}*b-zj}a}aug{a9jzin{{\\frOADUB\\bJEEXLM[H]FFfVV^V^|s'
    //   126: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   129: invokeinterface a : (ILjava/lang/String;)V
    //   134: return
    //   135: aload_1
    //   136: ifnull -> 212
    //   139: aload_2
    //   140: ifnonnull -> 144
    //   143: return
    //   144: aload_1
    //   145: invokestatic a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   148: astore_1
    //   149: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/i/d;
    //   152: invokevirtual b : ()Lcom/bytedance/sdk/component/f/a;
    //   155: invokevirtual b : ()Lcom/bytedance/sdk/component/f/b/d;
    //   158: astore #5
    //   160: aload #5
    //   162: aload #5
    //   164: ldc_w '/`rj+db(}gcdb"}k{>`vctdsGosyr1mEVCQ@\\n'
    //   167: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   170: invokestatic d : (Ljava/lang/String;)Ljava/lang/String;
    //   173: invokestatic a : (Lcom/bytedance/sdk/component/f/b/c;Ljava/lang/String;)Ljava/lang/String;
    //   176: invokevirtual a : (Ljava/lang/String;)V
    //   179: goto -> 189
    //   182: astore #6
    //   184: aload #6
    //   186: invokevirtual printStackTrace : ()V
    //   189: aload #5
    //   191: aload_1
    //   192: invokevirtual toString : ()Ljava/lang/String;
    //   195: invokevirtual c : (Ljava/lang/String;)V
    //   198: aload #5
    //   200: new com/bytedance/sdk/openadsdk/core/o$7
    //   203: dup
    //   204: aload_0
    //   205: aload_2
    //   206: invokespecial <init> : (Lcom/bytedance/sdk/openadsdk/core/o;Lcom/bytedance/sdk/openadsdk/core/n$b;)V
    //   209: invokevirtual a : (Lcom/bytedance/sdk/component/f/a/a;)V
    //   212: return
    //   213: bipush #94
    //   215: istore_3
    //   216: bipush #125
    //   218: istore #4
    //   220: goto -> 7
    // Exception table:
    //   from	to	target	type
    //   160	179	182	java/lang/Exception
  }
  
  public void a(JSONObject paramJSONObject, String paramString) {
    d d = d.a().b().b();
    d.a(paramString);
    d.a(paramJSONObject);
    d.a(new com.bytedance.sdk.component.f.a.a(this) {
          public void a(c param1c, com.bytedance.sdk.component.f.b param1b) {
            l.b(a.a1671532477445dc("eyg`TSRhIyg+xmluba"), param1b.d());
          }
          
          public void a(c param1c, IOException param1IOException) {
            l.b(a.a1671532477445dc("eyg`TSRhIyg+jlgc"), param1IOException.toString());
          }
        });
  }
  
  public e b(JSONObject paramJSONObject) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore #4
    //   5: invokestatic a : ()Z
    //   8: ifne -> 13
    //   11: aconst_null
    //   12: areturn
    //   13: aload_1
    //   14: ifnull -> 367
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: ifgt -> 26
    //   24: aconst_null
    //   25: areturn
    //   26: aload_1
    //   27: invokestatic a : (Lorg/json/JSONObject;)Lorg/json/JSONObject;
    //   30: astore_1
    //   31: invokestatic a : ()Lcom/bytedance/sdk/openadsdk/i/d;
    //   34: invokevirtual b : ()Lcom/bytedance/sdk/component/f/a;
    //   37: invokevirtual b : ()Lcom/bytedance/sdk/component/f/b/d;
    //   40: astore #10
    //   42: iconst_0
    //   43: istore #7
    //   45: aload #10
    //   47: ldc_w '/`rj+db(}gcdb"}k{>aguae8zxnxt2'
    //   50: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   53: invokestatic d : (Ljava/lang/String;)Ljava/lang/String;
    //   56: invokevirtual a : (Ljava/lang/String;)V
    //   59: aload #10
    //   61: aload_1
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: invokevirtual c : (Ljava/lang/String;)V
    //   68: aload #10
    //   70: ldc_w 'Urgq)Dabf}'
    //   73: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   76: invokestatic c : ()Ljava/lang/String;
    //   79: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   82: aload #10
    //   84: invokevirtual a : ()Lcom/bytedance/sdk/component/f/b;
    //   87: astore #11
    //   89: ldc_w 'esplv%sicge|b'
    //   92: invokestatic d1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   95: astore_1
    //   96: aload #11
    //   98: ifnonnull -> 113
    //   101: new com/bytedance/sdk/openadsdk/c/e
    //   104: dup
    //   105: iconst_0
    //   106: iconst_0
    //   107: aload_1
    //   108: iconst_0
    //   109: invokespecial <init> : (ZILjava/lang/String;Z)V
    //   112: areturn
    //   113: aload #11
    //   115: invokevirtual f : ()Z
    //   118: istore #8
    //   120: iconst_1
    //   121: istore #6
    //   123: iload #8
    //   125: ifeq -> 215
    //   128: aload #11
    //   130: invokevirtual d : ()Ljava/lang/String;
    //   133: checkcast java/lang/CharSequence
    //   136: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   139: ifne -> 215
    //   142: aload #11
    //   144: invokevirtual d : ()Ljava/lang/String;
    //   147: invokestatic jsonObjectInit : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   150: astore #10
    //   152: aload #10
    //   154: ldc_w 'cnff'
    //   157: invokestatic d1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   160: iconst_m1
    //   161: invokevirtual optInt : (Ljava/lang/String;I)I
    //   164: istore_2
    //   165: aload #10
    //   167: ldc 'd`vb'
    //   169: invokestatic d1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   172: ldc ''
    //   174: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   177: astore #10
    //   179: iload_2
    //   180: sipush #20000
    //   183: if_icmpne -> 192
    //   186: iconst_1
    //   187: istore #7
    //   189: goto -> 195
    //   192: iconst_0
    //   193: istore #7
    //   195: aload #10
    //   197: astore_1
    //   198: iload #7
    //   200: istore #8
    //   202: iload_2
    //   203: ldc_w 60005
    //   206: if_icmpne -> 218
    //   209: aload #10
    //   211: astore_1
    //   212: goto -> 225
    //   215: iconst_0
    //   216: istore #8
    //   218: iconst_0
    //   219: istore #6
    //   221: iload #8
    //   223: istore #7
    //   225: aload #11
    //   227: invokevirtual a : ()I
    //   230: istore_2
    //   231: aload_1
    //   232: astore #10
    //   234: iload #7
    //   236: istore #9
    //   238: iload_2
    //   239: istore_3
    //   240: iload #6
    //   242: istore #8
    //   244: aload #11
    //   246: invokevirtual f : ()Z
    //   249: ifne -> 306
    //   252: aload #11
    //   254: invokevirtual b : ()Ljava/lang/String;
    //   257: astore #10
    //   259: iload #7
    //   261: istore #9
    //   263: iload_2
    //   264: istore_3
    //   265: iload #6
    //   267: istore #8
    //   269: goto -> 306
    //   272: goto -> 293
    //   275: iconst_0
    //   276: istore_2
    //   277: goto -> 293
    //   280: iconst_0
    //   281: istore_2
    //   282: iconst_0
    //   283: istore #8
    //   285: iload #7
    //   287: istore #6
    //   289: iload #8
    //   291: istore #7
    //   293: iload #6
    //   295: istore #8
    //   297: iload_2
    //   298: istore_3
    //   299: iload #7
    //   301: istore #9
    //   303: aload_1
    //   304: astore #10
    //   306: getstatic com/bytedance/sdk/openadsdk/c/a/a.b : Lcom/bytedance/sdk/openadsdk/c/a/b;
    //   309: iload #9
    //   311: iload_3
    //   312: invokestatic currentTimeMillis : ()J
    //   315: lload #4
    //   317: lsub
    //   318: invokestatic a : (Lcom/bytedance/sdk/openadsdk/c/a/b;ZIJ)V
    //   321: new com/bytedance/sdk/openadsdk/c/e
    //   324: dup
    //   325: iload #9
    //   327: iload_3
    //   328: aload #10
    //   330: iload #8
    //   332: invokespecial <init> : (ZILjava/lang/String;Z)V
    //   335: areturn
    //   336: getstatic com/bytedance/sdk/openadsdk/c/a/a.b : Lcom/bytedance/sdk/openadsdk/c/a/b;
    //   339: iconst_0
    //   340: iconst_0
    //   341: invokestatic currentTimeMillis : ()J
    //   344: lload #4
    //   346: lsub
    //   347: invokestatic a : (Lcom/bytedance/sdk/openadsdk/c/a/b;ZIJ)V
    //   350: new com/bytedance/sdk/openadsdk/c/e
    //   353: dup
    //   354: iconst_0
    //   355: iconst_0
    //   356: ldc_w 'esplv%sicge|b'
    //   359: invokestatic d1671532477445dc : (Ljava/lang/String;)Ljava/lang/String;
    //   362: iconst_0
    //   363: invokespecial <init> : (ZILjava/lang/String;Z)V
    //   366: areturn
    //   367: aconst_null
    //   368: areturn
    //   369: astore_1
    //   370: goto -> 336
    //   373: astore #10
    //   375: goto -> 280
    //   378: astore #10
    //   380: goto -> 275
    //   383: astore #10
    //   385: goto -> 272
    // Exception table:
    //   from	to	target	type
    //   45	82	369	finally
    //   101	113	373	finally
    //   113	120	373	finally
    //   128	179	373	finally
    //   225	231	378	finally
    //   244	259	383	finally
  }
  
  public static class a {
    final int a;
    
    final long b;
    
    final long c;
    
    final int d;
    
    final String e;
    
    final int f;
    
    final String g;
    
    public final a h;
    
    final String i;
    
    final ArrayList<Integer> j;
    
    private a(String param1String1, int param1Int1, int param1Int2, String param1String2, int param1Int3, String param1String3, a param1a, long param1Long1, long param1Long2, ArrayList<Integer> param1ArrayList) {
      this.a = param1Int1;
      this.d = param1Int2;
      this.e = param1String2;
      this.g = param1String3;
      this.h = param1a;
      this.i = param1String1;
      this.f = param1Int3;
      this.b = param1Long1;
      this.c = param1Long2;
      this.j = param1ArrayList;
    }
    
    public static a a(JSONObject param1JSONObject, AdSlot param1AdSlot, o param1o) {
      String str1 = param1JSONObject.optString(c.c1671532477447dc("dhf"));
      int i = param1JSONObject.optInt(c.c1671532477447dc("psm`avunfnUe`kP}b"));
      long l1 = param1JSONObject.optLong(c.c1671532477447dc("s^pfg`oqmV~x"));
      long l2 = param1JSONObject.optLong(a.a1671532477445dc("s^qfjaYs{"));
      int j = param1JSONObject.optInt(a.a1671532477445dc("sucwqvYdgmo"));
      String str2 = param1JSONObject.optString(a.a1671532477445dc("ddq`"));
      String str3 = param1JSONObject.optString(a.a1671532477445dc("rdsvavrXam"));
      int k = param1JSONObject.optInt(a.a1671532477445dc("rdcpkk"));
      Pair pair = b.a(param1JSONObject, param1AdSlot, param1o);
      if (pair != null && pair.first != null)
        ((a)pair.first).a(param1JSONObject.optLong(a.a1671532477445dc("rdsvavrXio~n~"))); 
      return (pair == null) ? new a(str1, i, j, str2, k, str3, null, l1, l2, null) : new a(str1, i, j, str2, k, str3, (a)pair.first, l1, l2, (ArrayList<Integer>)pair.second);
    }
  }
  
  public static class b {
    public final int a;
    
    public final boolean b;
    
    public final s c;
    
    private b(int param1Int, boolean param1Boolean, s param1s) {
      this.a = param1Int;
      this.b = param1Boolean;
      this.c = param1s;
    }
    
    public static b a(JSONObject param1JSONObject) {
      if (param1JSONObject == null)
        return null; 
      int i = param1JSONObject.optInt(c.c1671532477431dc("cnff"));
      boolean bool = param1JSONObject.optBoolean(c.c1671532477431dc("vdpjb|"));
      JSONObject jSONObject = param1JSONObject.optJSONObject(c.c1671532477431dc("d`vb"));
      s s1 = new s();
      if (jSONObject != null)
        try {
          s1.a(jSONObject.optInt(c.c1671532477431dc("rdcpkk")));
          s1.b(jSONObject.optInt(c.c1671532477431dc("cnps[qwm")));
          s1.c(jSONObject.optInt(c.c1671532477431dc("rdubvaYfefex")));
          s1.a(jSONObject.optString(c.c1671532477431dc("rdubvaYiido")));
        } finally {
          jSONObject = null;
        }  
      return new b(i, bool, s1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\core\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */