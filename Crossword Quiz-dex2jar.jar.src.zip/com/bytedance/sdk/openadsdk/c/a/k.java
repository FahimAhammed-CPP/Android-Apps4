package com.bytedance.sdk.openadsdk.c.a;

import com.bytedance.sdk.component.e.a.b;
import com.bytedance.sdk.component.e.a.d.a.a;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.h.a;
import com.bytedance.sdk.openadsdk.h.a.a;
import com.bytedance.sdk.openadsdk.h.c.a;
import com.bytedance.sdk.openadsdk.l.q;
import com.bytedance.sdk.openadsdk.l.y;
import com.bytedance.sdk.openadsdk.multipro.b;
import org.json.JSONObject;

class k implements a {
  public static final k a = new k();
  
  private void a(g paramg) {
    if (paramg == null)
      return; 
    if (!y.f()) {
      y.b(paramg, 5);
      return;
    } 
    paramg.run();
  }
  
  public void a() {}
  
  public void a(a parama) {
    a(parama, false);
  }
  
  public void a(a parama, boolean paramBoolean) {
    a(new g(this, "uploadLogEvent", parama, paramBoolean) {
          public void run() {
            try {
              byte b;
              a a2 = this.a.a();
              if (a2 == null)
                return; 
              JSONObject jSONObject = a2.a();
              a a1 = new a(q.a(), jSONObject);
              a1.c((byte)0);
              if (this.b) {
                b = 2;
              } else {
                b = 3;
              } 
              a1.b(b);
              a1.a((byte)1);
              if (b.b())
                c.a(m.a(), b.c()); 
              return;
            } finally {
              Exception exception = null;
            } 
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\c\a\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */