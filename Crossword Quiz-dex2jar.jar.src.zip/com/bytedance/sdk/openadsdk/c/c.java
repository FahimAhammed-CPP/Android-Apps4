package com.bytedance.sdk.openadsdk.c;

import android.content.Context;
import android.text.TextUtils;
import com.bykv.vk.openvk.component.video.api.c.a;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.f.c.a;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.component.utils.h;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.openadsdk.AdSlot;
import com.bytedance.sdk.openadsdk.ApmHelper;
import com.bytedance.sdk.openadsdk.FilterWord;
import com.bytedance.sdk.openadsdk.c.a.c;
import com.bytedance.sdk.openadsdk.c.b.a;
import com.bytedance.sdk.openadsdk.component.reward.n;
import com.bytedance.sdk.openadsdk.core.b;
import com.bytedance.sdk.openadsdk.core.g.a;
import com.bytedance.sdk.openadsdk.core.j;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.core.model.d;
import com.bytedance.sdk.openadsdk.core.model.g;
import com.bytedance.sdk.openadsdk.core.model.n;
import com.bytedance.sdk.openadsdk.core.p;
import com.bytedance.sdk.openadsdk.core.settings.e;
import com.bytedance.sdk.openadsdk.dislike.a;
import com.bytedance.sdk.openadsdk.k.a;
import com.bytedance.sdk.openadsdk.l.f;
import com.bytedance.sdk.openadsdk.l.l;
import com.bytedance.sdk.openadsdk.l.y;
import com.bytedance.sdk.openadsdk.l.z;
import com.safedk.android.internal.partials.PangleVideoBridge;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
  public static void a(long paramLong, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject, f paramf, a parama) {
    if (paramn == null)
      return; 
    (new a.a(paramLong)).f(paramn.Z()).h(paramn.ba()).e(paramn.ad()).a(paramn.aa()).b(paramString1).c(paramString2).a(paramJSONObject).a(parama);
  }
  
  public static void a(Context paramContext, n paramn) {
    if (paramn == null)
      return; 
    a(paramContext, paramn, com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("l`lgmkawino"));
  }
  
  public static void a(Context paramContext, n paramn, String paramString) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    try {
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.putOpt(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("rdlgawYsqyo"), com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("h4"));
      jSONObject1.putOpt(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("rdlgawYsqyoT>"), Integer.valueOf(0));
      jSONObject.putOpt(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("ae]f|qtfWmkm"), jSONObject1);
    } catch (Exception exception) {}
    c(paramContext, paramn, paramString, com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("oqgm[ptkWa?"), jSONObject);
  }
  
  public static void a(Context paramContext, n paramn, String paramString, long paramLong) {
    // Byte code:
    //   0: bipush #55
    //   2: istore #5
    //   4: iconst_0
    //   5: istore #10
    //   7: bipush #72
    //   9: istore #7
    //   11: iload #10
    //   13: istore #8
    //   15: iload #5
    //   17: istore #6
    //   19: iload #5
    //   21: istore #9
    //   23: iload #7
    //   25: tableswitch default -> 52, 72 -> 291, 73 -> 163, 74 -> 59
    //   52: iload #8
    //   54: istore #10
    //   56: goto -> 7
    //   59: iload #6
    //   61: istore #5
    //   63: iload #8
    //   65: istore #10
    //   67: iload #6
    //   69: istore #7
    //   71: iload #6
    //   73: istore #9
    //   75: iload #8
    //   77: tableswitch default -> 104, 52 -> 7, 53 -> 115, 54 -> 291
    //   104: iload #6
    //   106: istore #5
    //   108: iload #8
    //   110: istore #10
    //   112: goto -> 7
    //   115: iload #7
    //   117: istore #5
    //   119: iload #8
    //   121: istore #10
    //   123: iload #7
    //   125: istore #6
    //   127: iload #7
    //   129: tableswitch default -> 156, 29 -> 7, 30 -> 7, 31 -> 59
    //   156: bipush #30
    //   158: istore #7
    //   160: goto -> 115
    //   163: iload #8
    //   165: istore #10
    //   167: iload #8
    //   169: bipush #57
    //   171: if_icmpgt -> 7
    //   174: aload_1
    //   175: ifnonnull -> 179
    //   178: return
    //   179: new org/json/JSONObject
    //   182: dup
    //   183: invokespecial <init> : ()V
    //   186: astore #11
    //   188: new org/json/JSONObject
    //   191: dup
    //   192: invokespecial <init> : ()V
    //   195: astore #12
    //   197: aload #12
    //   199: ldc 'rdlgawYsqyo'
    //   201: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   204: ldc 'h4'
    //   206: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   209: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   212: pop
    //   213: aload #12
    //   215: ldc 'rdlgawYsqyoT>'
    //   217: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   220: iconst_0
    //   221: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   224: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   227: pop
    //   228: aload #12
    //   230: ldc 'iovfvdesafdTahzgu'
    //   232: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   235: aload_1
    //   236: invokevirtual h : ()I
    //   239: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   242: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   245: pop
    //   246: aload #11
    //   248: ldc 'ae]f|qtfWmkm'
    //   250: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   253: aload #12
    //   255: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   258: pop
    //   259: aload #11
    //   261: ldc 'dtpbplii'
    //   263: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   266: lload_3
    //   267: ldc2_w 600000
    //   270: invokestatic min : (JJ)J
    //   273: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   276: pop
    //   277: aload_0
    //   278: aload_1
    //   279: aload_2
    //   280: ldc 'lncg'
    //   282: invokestatic c1671532477447dc : (Ljava/lang/String;)Ljava/lang/String;
    //   285: aload #11
    //   287: invokestatic c : (Landroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   290: return
    //   291: bipush #73
    //   293: istore #7
    //   295: bipush #16
    //   297: istore #8
    //   299: iload #9
    //   301: istore #5
    //   303: goto -> 15
    //   306: astore #12
    //   308: goto -> 277
    // Exception table:
    //   from	to	target	type
    //   188	277	306	java/lang/Exception
  }
  
  public static void a(Context paramContext, n paramn, String paramString, long paramLong, boolean paramBoolean) {
    a(new g(n.n1671532477404dc("ooNsHjgcagm"), paramn, paramBoolean, paramLong, paramContext, paramString) {
          public void run() {
            if (this.a == null)
              return; 
            JSONObject jSONObject2 = new JSONObject();
            JSONObject jSONObject1 = new JSONObject();
            try {
              byte b;
              String str = n.n1671532477404dc("ig]otZjhimcekR}zsrw`g");
              if (this.b) {
                b = 1;
              } else {
                b = 2;
              } 
              jSONObject2.put(str, b);
              jSONObject1.put(n.n1671532477404dc("ae]f|qtfWmkm"), jSONObject2.toString());
              jSONObject1.put(n.n1671532477404dc("dtpbplii"), this.c);
            } finally {
              jSONObject2 = null;
            } 
          }
        });
  }
  
  @JProtect
  public static void a(Context paramContext, n paramn, String paramString, z paramz) {
    if (paramn == null)
      return; 
    long l = System.currentTimeMillis();
    a(new g(a.a1671532477452dc("sdlgHjgcL|xjxdaa"), paramContext, paramz, paramString, l, paramn) {
          public void run() {
            String str;
            if (this.a == null)
              return; 
            if (!m.d().P())
              return; 
            JSONObject jSONObject = new JSONObject();
            try {
              jSONObject.put(e.e1671532477438dc("dtpbplii"), this.b.c());
            } finally {
              Exception exception = null;
            } 
            byte b = -1;
            switch (str.hashCode()) {
              case 1912999166:
                if (str.equals(e.e1671532477438dc("dsct[db")))
                  b = 5; 
                break;
              case 1844104722:
                if (str.equals(e.e1671532477438dc("iovfvdesafd")))
                  b = 1; 
                break;
              case -712491894:
                if (str.equals(e.e1671532477438dc("el`f``bXim")))
                  b = 2; 
                break;
              case -764631662:
                if (str.equals(e.e1671532477438dc("ftnowftbmgUbbyk}ce{g}tzHy}")))
                  b = 4; 
                break;
              case -1364000502:
                if (str.equals(e.e1671532477438dc("rdubvaccWcoib")))
                  b = 3; 
                break;
              case -1695837674:
                if (str.equals(e.e1671532477438dc("b`lmawYfl")))
                  b = 0; 
                break;
            } 
            if (b != 0) {
              if (b != 1) {
                if (b != 2) {
                  if (b != 3) {
                    if (b != 4) {
                      if (b != 5) {
                        str = "";
                      } else {
                        str = "dsct[dbXdfkoxdcj";
                        str = e.e1671532477438dc(str);
                      } 
                    } else {
                      str = "ftnowftbmgUbbyk}ce{g}tzHy}Ews|zkILG";
                      str = e.e1671532477438dc(str);
                    } 
                  } else {
                    str = "rdubvaccWcoibQcpvg}xs";
                    str = e.e1671532477438dc(str);
                  } 
                } else {
                  str = "el`f``bXimUgclj{y|w";
                  str = e.e1671532477438dc(str);
                } 
              } else {
                str = "iovfvdesafdT`bokdxv";
                str = e.e1671532477438dc(str);
              } 
            } else {
              str = "b`lmawYflVfdmizf}t";
              str = e.e1671532477438dc(str);
            } 
            c.a(this.d, this.a, this.e, this.c, str, jSONObject);
          }
        });
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2) {
    if (paramn == null)
      return; 
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2);
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2, long paramLong, int paramInt, Map<String, Object> paramMap, f paramf) {
    label28: while (true) {
      for (byte b = 82;; b = 80) {
        JSONObject jSONObject1;
        JSONObject jSONObject2;
        switch (b) {
          case 81:
            continue label28;
          case 80:
            if (paramn == null)
              return; 
            jSONObject1 = new JSONObject();
            jSONObject2 = new JSONObject();
            try {
              jSONObject1.put(c1671532477431dc("dtpbplii"), paramLong);
              jSONObject1.put(c1671532477431dc("pdp`akr"), paramInt);
              if (paramMap != null)
                for (Map.Entry<String, Object> entry : paramMap.entrySet())
                  jSONObject2.put((String)entry.getKey(), entry.getValue());  
              if ((c1671532477431dc("fdgg[gtbib").equals(paramString2) || c1671532477431dc("fdgg[jpbz").equals(paramString2)) && paramf != null)
                paramf.a(jSONObject2); 
              jSONObject1.put(c1671532477431dc("ae]f|qtfWmkm"), jSONObject2.toString());
            } finally {}
            b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject1);
            return;
        } 
      } 
      break;
    } 
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2, long paramLong, JSONObject paramJSONObject) {
    label21: while (true) {
      byte b;
      for (b = 15;; b = 14) {
        switch (b) {
          case 13:
            continue label21;
          case 14:
            if (paramn == null)
              return; 
            if (paramContext != null && paramn != null) {
              if (paramJSONObject == null)
                return; 
              JSONObject jSONObject = new JSONObject();
              try {
                jSONObject.put(n.n1671532477404dc("dtpbplii"), paramLong);
                jSONObject.put(n.n1671532477404dc("ae]f|qtfWmkm"), paramJSONObject.toString());
              } catch (Exception exception) {
                exception.printStackTrace();
              } 
              b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
            } 
            return;
        } 
      } 
      break;
    } 
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject2 = new JSONObject();
    JSONObject jSONObject1 = new JSONObject();
    if (paramMap != null) {
      try {
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject2.put((String)entry.getKey(), entry.getValue()); 
      } finally {
        paramMap = null;
      } 
      b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject1);
      return;
    } 
    jSONObject1.put(a.a1671532477445dc("ae]f|qtfWmkm"), jSONObject2.toString());
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject) {
    // Byte code:
    //   0: bipush #94
    //   2: istore #5
    //   4: bipush #125
    //   6: istore #6
    //   8: iload #5
    //   10: tableswitch default -> 36, 94 -> 196, 95 -> 39, 96 -> 166
    //   36: goto -> 0
    //   39: iload #6
    //   41: tableswitch default -> 68, 94 -> 196, 95 -> 71, 96 -> 196
    //   68: goto -> 166
    //   71: aload_1
    //   72: ifnonnull -> 76
    //   75: return
    //   76: aload #4
    //   78: ifnull -> 138
    //   81: new org/json/JSONObject
    //   84: dup
    //   85: invokespecial <init> : ()V
    //   88: astore #7
    //   90: aload #7
    //   92: ldc 'ae]f|qtfWmkm'
    //   94: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   97: aload #4
    //   99: invokevirtual toString : ()Ljava/lang/String;
    //   102: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   105: pop
    //   106: goto -> 123
    //   109: astore #4
    //   111: aload #4
    //   113: checkcast org/json/JSONException
    //   116: astore #8
    //   118: aload #4
    //   120: invokevirtual printStackTrace : ()V
    //   123: invokestatic currentTimeMillis : ()J
    //   126: aload_0
    //   127: aload_1
    //   128: aload_2
    //   129: aload_3
    //   130: aload #7
    //   132: invokestatic b : (JLandroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   135: goto -> 148
    //   138: invokestatic currentTimeMillis : ()J
    //   141: aload_0
    //   142: aload_1
    //   143: aload_2
    //   144: aload_3
    //   145: invokestatic b : (JLandroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/lang/String;)V
    //   148: ldc_w 'cmk`o'
    //   151: invokestatic n1671532477404dc : (Ljava/lang/String;)Ljava/lang/String;
    //   154: aload_3
    //   155: invokevirtual equals : (Ljava/lang/Object;)Z
    //   158: ifeq -> 165
    //   161: aload_1
    //   162: invokestatic c : (Lcom/bytedance/sdk/openadsdk/core/model/n;)V
    //   165: return
    //   166: iload #6
    //   168: tableswitch default -> 196, 55 -> 196, 56 -> 0, 57 -> 196
    //   196: bipush #95
    //   198: istore #5
    //   200: bipush #95
    //   202: istore #6
    //   204: goto -> 8
    // Exception table:
    //   from	to	target	type
    //   90	106	109	org/json/JSONException
  }
  
  public static void a(Context paramContext, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject, long paramLong) {
    if (paramn == null)
      return; 
    if (paramContext != null && paramn != null) {
      if (paramJSONObject == null)
        return; 
      JSONObject jSONObject = new JSONObject();
      try {
        jSONObject.put(n.n1671532477404dc("ae]f|qtfWmkm"), paramJSONObject.toString());
        jSONObject.put(n.n1671532477404dc("dtpbplii"), paramLong);
      } finally {}
      b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
    } 
  }
  
  @JProtect
  public static void a(Context paramContext, n paramn, String paramString, Map<String, Object> paramMap, Double paramDouble) {
    if (paramn == null)
      return; 
    long l = System.currentTimeMillis();
    a(new g(a.a1671532477445dc("ooQkkr"), paramn, paramMap, paramDouble, paramString, l) {
          public void run() {
            try {
              p.b(this.a);
              JSONObject jSONObject = new JSONObject();
              try {
                JSONObject jSONObject1 = new JSONObject();
                Map map2 = this.b;
                if (map2 != null)
                  for (Map.Entry entry : map2.entrySet())
                    jSONObject1.put((String)entry.getKey(), entry.getValue());  
                jSONObject1.put(ApmHelper.ApmHelper1671532477463dc("iovfvdesafdTahzgu"), this.a.h());
                jSONObject1.put(ApmHelper.ApmHelper1671532477463dc("rdco[lhsm{khxdaaO|wg|zr"), this.a.g());
                jSONObject.put(ApmHelper.ApmHelper1671532477463dc("ae]f|qtfWmkm"), jSONObject1.toString());
                jSONObject.putOpt(ApmHelper.ApmHelper1671532477463dc("lne\\a}rui"), this.a.ad());
                double d1 = (System.currentTimeMillis() / 1000L);
                double d2 = this.a.aY();
                Double.isNaN(d1);
                float f = Double.valueOf(d1 - d2).floatValue();
                String str = ApmHelper.ApmHelper1671532477463dc("simt[qojm");
                if (f <= 0.0F)
                  f = 0.0F; 
                jSONObject.putOpt(str, Float.valueOf(f));
                jSONObject.putOpt(ApmHelper.ApmHelper1671532477463dc("u`]skiodq"), Integer.valueOf(this.a.G()));
                str = this.a.t();
                boolean bool = TextUtils.isEmpty(str);
                if (!bool) {
                  bool = TextUtils.isEmpty(str);
                  if (!bool)
                    try {
                      int i = Math.round(Float.parseFloat(str) * 100000.0F);
                      jSONObject.put(ApmHelper.ApmHelper1671532477463dc("tufptZvuajo"), i);
                    } finally {
                      str = null;
                      jSONObject.put(ApmHelper.ApmHelper1671532477463dc("tufptZvuajo"), 0);
                    }  
                } 
                Map map1 = this.a.ak();
                if (map1 != null)
                  try {
                    map1 = (Map)this.a.ak().get(ApmHelper.ApmHelper1671532477463dc("sei\\flbcagmTxt~j"));
                    if (map1 != null && Integer.parseInt(map1.toString()) == 2)
                      if (this.c != null) {
                        jSONObject.put(ApmHelper.ApmHelper1671532477463dc("tufptZvuajo"), Math.round(this.c.doubleValue() * 100000.0D));
                      } else {
                        map1 = (Map)this.a.ak().get(ApmHelper.ApmHelper1671532477463dc("psk`a"));
                        if (map1 != null)
                          jSONObject.put(ApmHelper.ApmHelper1671532477463dc("tufptZvuajo"), Math.round(Double.parseDouble(map1.toString()) * 100000.0D)); 
                      }  
                  } finally {} 
                i.a(this.a, this.d);
              } catch (JSONException jSONException1) {}
            } catch (JSONException jSONException) {
              jSONException = null;
            } 
            (new a.a(this.e)).b(this.d).c(ApmHelper.ApmHelper1671532477463dc("simt")).f(this.a.Z()).a(this.a.aa()).a((JSONObject)jSONException).h(this.a.ba()).a(null);
            if (!this.a.aD())
              if (this.a.bb()) {
                com.bytedance.sdk.openadsdk.core.g.b.c.a(this.a.S(), new com.bytedance.sdk.openadsdk.core.g.b.c.b(ApmHelper.ApmHelper1671532477463dc("simt[ptk{"), this.a));
              } else {
                c.b(this.a);
              }  
            com.bytedance.sdk.openadsdk.core.e.c.c();
          }
        });
  }
  
  public static void a(Context paramContext, String paramString, long paramLong) {
    com.bytedance.sdk.openadsdk.core.d.c.a(paramContext, paramString, paramLong);
  }
  
  @JProtect
  public static void a(Context paramContext, String paramString1, n paramn, g paramg, String paramString2, boolean paramBoolean, Map<String, Object> paramMap, int paramInt) {
    long l = System.currentTimeMillis();
    a(new g(n.n1671532477404dc("ooAomfm"), paramn, paramContext, paramg, paramBoolean, paramInt, paramMap, l, paramString2, paramString1) {
          public void run() {
            if (this.a == null)
              return; 
            if (this.b == null)
              m.a(); 
            JSONObject jSONObject = new JSONObject();
            try {
              g g1 = this.c;
              if (g1 != null) {
                JSONObject jSONObject1 = g1.a();
                jSONObject1.put(a.a1671532477457dc("ir]ueioc"), this.d);
                int i = this.e;
                if (i >= 1 && i <= 2)
                  jSONObject1.put(a.a1671532477457dc("urgq[gcoicd~Rzv`t"), this.e); 
                Map map = this.f;
                if (map != null)
                  for (Map.Entry entry : map.entrySet())
                    jSONObject1.put((String)entry.getKey(), entry.getValue());  
                jSONObject1.put(a.a1671532477457dc("iovfvdesafdTahzgu"), this.a.h());
                jSONObject.put(a.a1671532477457dc("ae]f|qtfWmkm"), jSONObject1.toString());
              } 
              jSONObject.putOpt(c.c1671532477431dc("lne\\a}rui"), this.a.ad());
              double d1 = (System.currentTimeMillis() / 1000L);
              double d2 = this.a.aY();
              Double.isNaN(d1);
              float f = Double.valueOf(d1 - d2).floatValue();
              String str = c.c1671532477431dc("simt[qojm");
              if (f <= 0.0F)
                f = 0.0F; 
              jSONObject.putOpt(str, Float.valueOf(f));
              jSONObject.putOpt(c.c1671532477431dc("u`]skiodq"), Integer.valueOf(this.a.G()));
            } catch (JSONException jSONException) {}
            (new a.a(this.g)).b(this.h).c(this.i).f(this.a.Z()).a(this.a.aa()).a(jSONObject).h(this.a.ba()).a(null);
            if (!TextUtils.isEmpty(j.a(m.a())) && a.a1671532477457dc("cmk`o").equals(this.i))
              c.a(a.a(this.a.T(), true)); 
            if (a.a1671532477457dc("cmk`o").equals(this.i))
              p.c(this.a); 
          }
        });
    label16: while (true) {
      paramInt = 73;
      byte b = 96;
      while (true) {
        switch (paramInt) {
          case 73:
            switch (b) {
              case 94:
                continue label16;
              default:
                switch (b) {
                  default:
                    continue label16;
                  case 55:
                    return;
                  case 56:
                  case 57:
                    break;
                } 
                break;
              case 95:
              case 96:
                break;
            } 
          case 74:
          
          case 72:
            paramInt = 74;
            b = 55;
            continue;
        } 
        paramInt = 72;
      } 
      break;
    } 
  }
  
  public static void a(g paramg) {
    if (paramg == null)
      return; 
    if (y.e()) {
      h.a().post(new Runnable(paramg) {
            public void run() {
              y.b(this.a, 10);
            }
          });
      return;
    } 
    paramg.run();
  }
  
  public static void a(AdSlot paramAdSlot) {
    String str;
    if (paramAdSlot == null) {
      str = "";
    } else if (TextUtils.isEmpty(str.getBidAdm())) {
      str = str.getCodeId();
    } else {
      return;
    } 
    a(str);
  }
  
  public static void a(n paramn) {}
  
  public static void a(n paramn, String paramString) {
    // Byte code:
    //   0: bipush #74
    //   2: istore_2
    //   3: bipush #55
    //   5: istore_3
    //   6: iload_2
    //   7: tableswitch default -> 32, 72 -> 0, 73 -> 35, 74 -> 64
    //   32: goto -> 178
    //   35: iload_3
    //   36: tableswitch default -> 64, 94 -> 169, 95 -> 95, 96 -> 95
    //   64: iload_3
    //   65: tableswitch default -> 92, 55 -> 169, 56 -> 95, 57 -> 95
    //   92: goto -> 169
    //   95: aload_0
    //   96: ifnonnull -> 100
    //   99: return
    //   100: new org/json/JSONObject
    //   103: dup
    //   104: invokespecial <init> : ()V
    //   107: astore #4
    //   109: new org/json/JSONObject
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: astore #5
    //   118: aload #5
    //   120: ldc_w 'rdtfmfcX|z'
    //   123: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   126: invokestatic currentTimeMillis : ()J
    //   129: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   132: pop
    //   133: aload #4
    //   135: ldc 'ae]f|qtfWmkm'
    //   137: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   140: aload #5
    //   142: invokevirtual toString : ()Ljava/lang/String;
    //   145: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   148: pop
    //   149: invokestatic currentTimeMillis : ()J
    //   152: invokestatic a : ()Landroid/content/Context;
    //   155: aload_0
    //   156: aload_1
    //   157: ldc_w 'bhfgmkaXzline{k'
    //   160: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   163: aload #4
    //   165: invokestatic b : (JLandroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   168: return
    //   169: bipush #73
    //   171: istore_2
    //   172: bipush #96
    //   174: istore_3
    //   175: goto -> 6
    //   178: bipush #72
    //   180: istore_2
    //   181: goto -> 6
    //   184: astore #5
    //   186: goto -> 149
    // Exception table:
    //   from	to	target	type
    //   118	149	184	java/lang/Exception
  }
  
  public static void a(n paramn, String paramString, long paramLong) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put(a.a1671532477452dc("dtpbplii"), paramLong);
    } catch (Exception exception) {}
    b(System.currentTimeMillis(), m.a(), paramn, paramString, a.a1671532477452dc("bhfgmkaXdfko"), jSONObject);
  }
  
  public static void a(n paramn, String paramString, long paramLong, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    long l = System.currentTimeMillis();
    a(new g(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("ooCstJvbfHn"), paramLong, paramMap, l, paramn, paramString) {
          public void run() {
            for (byte b = 82;; b = 80) {
              JSONObject jSONObject;
              switch (b) {
                case 80:
                  jSONObject = new JSONObject();
                  try {
                    if (this.a != -1L)
                      jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("dtpbplii"), this.a); 
                    JSONObject jSONObject1 = new JSONObject();
                    Map map = this.b;
                    if (map != null)
                      for (Map.Entry entry : map.entrySet())
                        jSONObject1.put((String)entry.getKey(), entry.getValue());  
                    jSONObject.put(ApmHelper.ApmHelper1671532477463dc("ae]f|qtfWmkm"), jSONObject1.toString());
                  } catch (JSONException jSONException1) {
                    JSONException jSONException2 = jSONException1;
                    jSONException1.printStackTrace();
                  } 
                  c.a(this.c, this.d, ApmHelper.ApmHelper1671532477463dc("oqgm[db"), this.e, jSONObject, (f)null, (a)null);
                  return;
              } 
            } 
          }
        });
  }
  
  public static void a(n paramn, String paramString1, String paramString2) {
    // Byte code:
    //   0: bipush #92
    //   2: istore_3
    //   3: bipush #14
    //   5: istore #4
    //   7: iload #4
    //   9: tableswitch default -> 36, 13 -> 140, 14 -> 140, 15 -> 39
    //   36: goto -> 3
    //   39: iload_3
    //   40: tableswitch default -> 68, 94 -> 140, 95 -> 71, 96 -> 140
    //   68: goto -> 140
    //   71: aload_0
    //   72: ifnonnull -> 76
    //   75: return
    //   76: new org/json/JSONObject
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore #5
    //   85: new org/json/JSONObject
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore #6
    //   94: aload #6
    //   96: ldc_w 'esplvZkto'
    //   99: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   102: aload_2
    //   103: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   106: pop
    //   107: aload #5
    //   109: ldc 'ae]f|qtfWmkm'
    //   111: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   114: aload #6
    //   116: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   119: pop
    //   120: invokestatic currentTimeMillis : ()J
    //   123: invokestatic a : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_1
    //   128: ldc_w 'simt[`tug{'
    //   131: invokestatic a1671532477452dc : (Ljava/lang/String;)Ljava/lang/String;
    //   134: aload #5
    //   136: invokestatic b : (JLandroid/content/Context;Lcom/bytedance/sdk/openadsdk/core/model/n;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   139: return
    //   140: bipush #15
    //   142: istore #4
    //   144: bipush #95
    //   146: istore_3
    //   147: goto -> 7
    //   150: astore_2
    //   151: goto -> 120
    // Exception table:
    //   from	to	target	type
    //   94	120	150	org/json/JSONException
  }
  
  @JProtect
  public static void a(n paramn, String paramString1, String paramString2, String paramString3, long paramLong1, long paramLong2, JSONObject paramJSONObject) {
    if (paramn == null)
      return; 
    long l = System.currentTimeMillis();
    a(new g(n.n1671532477404dc("sdlgNvGcMoex"), paramJSONObject, paramString3, paramString2, paramn, l, paramString1, paramLong1, paramLong2) {
          public void run() {
            label36: while (true) {
              for (byte b = 20;; b = 19) {
                switch (b) {
                  case 18:
                    continue label36;
                  default:
                    continue;
                  case 19:
                  
                  case 20:
                    continue;
                } 
                float f = 0.0F;
                SYNTHETIC_LOCAL_VARIABLE_7.putOpt((String)SYNTHETIC_LOCAL_VARIABLE_8, Float.valueOf(f));
                if (!TextUtils.isEmpty(j.a(m.a()))) {
                  n n1 = this.d;
                  if (n1 != null)
                    c.a(a.a(n1.T(), true)); 
                } 
                (new a.a(this.e)).d(this.f).b(this.c).c(this.b).f(String.valueOf(this.g)).g(String.valueOf(this.h)).a(this.d.aa()).a(this.a).h(this.d.ba()).a(null);
                if (l.d())
                  l.c(a.a1671532477445dc("AeGuakr"), a.a1671532477445dc("sdlgNvGcMoex")); 
                return;
              } 
              break;
            } 
          }
        });
  }
  
  @JProtect
  public static void a(n paramn, String paramString, Map<String, Object> paramMap) {
    long l = System.currentTimeMillis();
    if (paramn == null)
      return; 
    a(new g(c1671532477431dc("ooNleaBrzh~bccKyuf"), paramMap, l, paramn, paramString) {
          public void run() {
            Context context = m.a();
            JSONObject jSONObject = new JSONObject();
            Map map = this.a;
            if (map != null && map.size() > 0) {
              try {
                JSONObject jSONObject1 = new JSONObject();
                jSONObject1.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("ddtjg`"), f.d(context).toString());
                Object object = this.a.remove(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("tnvbhZrnel"));
                for (Map.Entry entry : this.a.entrySet())
                  jSONObject1.put((String)entry.getKey(), entry.getValue()); 
                boolean bool = object instanceof Long;
                if (bool) {
                  jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("dtpbplii"), object);
                } else {
                  jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("dtpbplii"), 0);
                } 
                jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("ae]f|qtfWmkm"), jSONObject1.toString());
              } catch (Exception exception) {}
              c.a(this.b, context, this.c, this.d, com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("lncg[dbXl|xjxdaa"), jSONObject);
              return;
            } 
            c.a(this.b, context, this.c, this.d, com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("lncg[dbXl|xjxdaa"));
          }
        });
  }
  
  public static void a(String paramString) {
    long l = System.currentTimeMillis();
    a(new g(e.e1671532477438dc("sdlgHdus[ae|Mi"), paramString, l) {
          public void run() {
            try {
              JSONObject jSONObject1 = new JSONObject();
              JSONObject jSONObject2 = new JSONObject();
              jSONObject2.put(d.d1671532477445dc("smmw"), this.a);
              jSONObject1.put(n.n1671532477404dc("ae]f|qtfWmkm"), jSONObject2.toString());
              long l = System.currentTimeMillis() - l.c();
              if (l <= 600000L && l >= 0L) {
                jSONObject1.put(n.n1671532477404dc("dtpbplii"), l);
                n n = b.a(PangleVideoBridge.jsonObjectInit(l.a()));
                if (n == null)
                  return; 
                return;
              } 
              return;
            } finally {
              Exception exception = null;
            } 
          }
        });
  }
  
  @JProtect
  public static void a(String paramString1, n paramn, String paramString2, f paramf) {
    if (paramn != null && paramf != null) {
      if (!paramf.a())
        return; 
      long l = System.currentTimeMillis();
      a(new g(a.a1671532477445dc("aeQkkrRnelXn|b|{"), paramString1, paramf, l, paramn, paramString2) {
            public void run() {
              JSONObject jSONObject = new JSONObject();
              try {
                jSONObject.put(a.a1671532477452dc("dtpbplii"), this.a);
                f f1 = this.b;
                if (f1 != null && f1.b() != null)
                  jSONObject.put(a.a1671532477452dc("ae]f|qtfWmkm"), this.b.b().toString()); 
              } finally {
                Exception exception;
              } 
              c.a(this.c, m.a(), this.d, this.e, a.a1671532477452dc("ae]pljqX|`gn"), jSONObject);
            }
          });
    } 
  }
  
  public static void a(String paramString, List<FilterWord> paramList) {
    a.a().a(paramString, paramList);
  }
  
  @JProtect
  private static void b(long paramLong, Context paramContext, n paramn, String paramString1, String paramString2) {
    if (paramn == null)
      return; 
    a(new g(a.a1671532477452dc("sdlgAsci|"), paramn, paramLong, paramString1, paramString2) {
          public void run() {
            JSONObject jSONObject = new JSONObject();
            try {
              jSONObject.putOpt(a.a1671532477457dc("lne\\a}rui"), this.a.ad());
              jSONObject.putOpt(a.a1671532477457dc("u`]skiodq"), Integer.valueOf(this.a.G()));
            } catch (JSONException jSONException) {}
            (new a.a(this.b)).b(this.c).c(this.d).f(this.a.Z()).a(this.a.aa()).a(jSONObject).h(this.a.ba()).a(null);
          }
        });
  }
  
  @JProtect
  private static void b(long paramLong, Context paramContext, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject) {
    if (paramn == null)
      return; 
    a(new g(n.n1671532477404dc("sdlgAsci|"), paramJSONObject, paramn, paramLong, paramString1, paramString2) {
          public void run() {
            // Byte code:
            //   0: bipush #73
            //   2: istore_1
            //   3: iload_1
            //   4: tableswitch default -> 32, 72 -> 35, 73 -> 167, 74 -> 0
            //   32: goto -> 167
            //   35: aload_0
            //   36: getfield a : Lorg/json/JSONObject;
            //   39: astore_2
            //   40: aload_2
            //   41: ifnull -> 87
            //   44: aload_2
            //   45: ldc 'lne\a}rui'
            //   47: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
            //   50: aload_0
            //   51: getfield b : Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   54: invokevirtual ad : ()Ljava/lang/String;
            //   57: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   60: pop
            //   61: aload_0
            //   62: getfield a : Lorg/json/JSONObject;
            //   65: ldc 'u`]skiodq'
            //   67: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
            //   70: aload_0
            //   71: getfield b : Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   74: invokevirtual G : ()I
            //   77: invokestatic valueOf : (I)Ljava/lang/Integer;
            //   80: invokevirtual putOpt : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   83: pop
            //   84: goto -> 100
            //   87: ldc 'AeGuakr'
            //   89: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
            //   92: ldc 'cbp#hja+(eelShv{bp2zg5szhmc'
            //   94: invokestatic e1671532477438dc : (Ljava/lang/String;)Ljava/lang/String;
            //   97: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
            //   100: new com/bytedance/sdk/openadsdk/c/a$a
            //   103: dup
            //   104: aload_0
            //   105: getfield c : J
            //   108: invokespecial <init> : (J)V
            //   111: aload_0
            //   112: getfield d : Ljava/lang/String;
            //   115: invokevirtual b : (Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   118: aload_0
            //   119: getfield e : Ljava/lang/String;
            //   122: invokevirtual c : (Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   125: aload_0
            //   126: getfield b : Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   129: invokevirtual Z : ()Ljava/lang/String;
            //   132: invokevirtual f : (Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   135: aload_0
            //   136: getfield b : Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   139: invokevirtual aa : ()Ljava/lang/String;
            //   142: invokevirtual a : (Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   145: aload_0
            //   146: getfield a : Lorg/json/JSONObject;
            //   149: invokevirtual a : (Lorg/json/JSONObject;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   152: aload_0
            //   153: getfield b : Lcom/bytedance/sdk/openadsdk/core/model/n;
            //   156: invokevirtual ba : ()Ljava/lang/String;
            //   159: invokevirtual h : (Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/c/a$a;
            //   162: aconst_null
            //   163: invokevirtual a : (Lcom/bytedance/sdk/openadsdk/c/b/a;)V
            //   166: return
            //   167: bipush #72
            //   169: istore_1
            //   170: goto -> 3
            //   173: astore_2
            //   174: goto -> 100
            // Exception table:
            //   from	to	target	type
            //   35	40	173	org/json/JSONException
            //   44	84	173	org/json/JSONException
            //   87	100	173	org/json/JSONException
          }
        });
  }
  
  public static void b(Context paramContext, n paramn, String paramString) {
    a(new g(n.n1671532477404dc("phawqwcDd`i`"), paramn, paramContext, paramString) {
          public void run() {
            if (this.a == null)
              return; 
            JSONObject jSONObject2 = new JSONObject();
            JSONObject jSONObject1 = new JSONObject();
            try {
              jSONObject2.put(n.n1671532477404dc("ae]phjrX|pzn"), this.a.y().getNativeAdType());
              jSONObject2.put(n.n1671532477404dc("iovfvdesafdTahzgu"), this.a.h());
              jSONObject1.put(n.n1671532477404dc("ae]f|qtfWmkm"), jSONObject2.toString());
            } finally {
              jSONObject2 = null;
            } 
          }
        });
    byte b = 92;
    label12: while (true) {
      byte b1 = 14;
      while (true) {
        switch (b1) {
          default:
            continue label12;
          case 15:
            switch (b) {
              case 95:
                return;
            } 
            break;
          case 13:
          case 14:
            break;
        } 
        b1 = 15;
        b = 95;
      } 
      break;
    } 
  }
  
  public static void b(Context paramContext, n paramn, String paramString1, String paramString2) {
    if (paramn == null)
      return; 
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2);
  }
  
  public static void b(Context paramContext, n paramn, String paramString1, String paramString2, long paramLong, JSONObject paramJSONObject) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("dtpbplii"), paramLong);
      if (paramJSONObject != null)
        jSONObject.putOpt(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("ae]f|qtfWmkm"), paramJSONObject); 
    } catch (Exception exception) {}
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
  }
  
  public static void b(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject2 = new JSONObject();
    JSONObject jSONObject1 = new JSONObject();
    if (paramMap != null) {
      try {
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject2.put((String)entry.getKey(), entry.getValue()); 
      } finally {
        paramMap = null;
      } 
      b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject1);
      return;
    } 
    jSONObject1.put(n.n1671532477404dc("ae]f|qtfWmkm"), jSONObject2.toString());
  }
  
  public static void b(Context paramContext, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    if (paramJSONObject != null)
      try {
        jSONObject.put(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("ae]f|qtfWmkm"), paramJSONObject.toString());
      } catch (Exception exception) {} 
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
  }
  
  public static void b(n paramn) {
    if (!TextUtils.isEmpty(j.a(m.a())))
      c.a(a.a(paramn.S(), true)); 
  }
  
  public static void b(n paramn, String paramString, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    a(paramn, paramString, -1L, paramMap);
  }
  
  public static void c(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject1 = new JSONObject();
    JSONObject jSONObject2 = new JSONObject();
    if (paramMap != null) {
      try {
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject2.put((String)entry.getKey(), entry.getValue()); 
        jSONObject1.put(c1671532477431dc("ae]f|qtfWmkm"), jSONObject2.toString());
      } catch (JSONException jSONException) {
        JSONException jSONException1 = jSONException;
        jSONException.printStackTrace();
      } 
      b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject1);
      return;
    } 
    jSONObject1.put(c1671532477431dc("ae]f|qtfWmkm"), jSONException.toString());
  }
  
  @JProtect
  public static void c(Context paramContext, n paramn, String paramString1, String paramString2, JSONObject paramJSONObject) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = paramJSONObject;
    if (paramJSONObject == null)
      jSONObject = new JSONObject(); 
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
  }
  
  public static String c1671532477431dc(String paramString) {
    label20: while (true) {
      int i = 73;
      byte b = 96;
      while (true) {
        char[] arrayOfChar;
        switch (i) {
          case 73:
            switch (b) {
              case 94:
                continue label20;
              default:
                switch (b) {
                  default:
                    continue label20;
                  case 55:
                    arrayOfChar = paramString.toCharArray();
                    for (i = 0; i < arrayOfChar.length; i++)
                      arrayOfChar[i] = (char)(arrayOfChar[i] ^ i); 
                    return new String(arrayOfChar);
                  case 56:
                  case 57:
                    break;
                } 
                break;
              case 95:
              case 96:
                break;
            } 
          case 74:
          
          case 72:
            i = 74;
            b = 55;
            continue;
        } 
        i = 72;
      } 
      break;
    } 
  }
  
  public static void d(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject1 = new JSONObject();
    JSONObject jSONObject2 = new JSONObject();
    if (paramMap != null) {
      try {
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject2.put((String)entry.getKey(), entry.getValue()); 
        jSONObject1.put(c1671532477431dc("ae]f|qtfWmkm"), jSONObject2.toString());
      } catch (JSONException jSONException) {
        JSONException jSONException1 = jSONException;
        jSONException.printStackTrace();
      } 
      b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject1);
      return;
    } 
    jSONObject1.put(c1671532477431dc("ae]f|qtfWmkm"), jSONException.toString());
  }
  
  public static void e(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    try {
      JSONObject jSONObject1 = new JSONObject();
      if (paramMap != null)
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject1.put((String)entry.getKey(), entry.getValue());  
      jSONObject1.put(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("dq]`v`gsaoTxt~j"), paramn.bc());
      jSONObject.put(com.bykv.vk.openvk.component.video.api.c.c.c1671532477447dc("ae]f|qtfWmkm"), jSONObject1.toString());
    } catch (Exception exception) {}
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
  }
  
  public static void f(Context paramContext, n paramn, String paramString1, String paramString2, Map<String, Object> paramMap) {
    if (paramn == null)
      return; 
    JSONObject jSONObject = new JSONObject();
    try {
      JSONObject jSONObject1 = new JSONObject();
      if (paramMap != null)
        for (Map.Entry<String, Object> entry : paramMap.entrySet())
          jSONObject1.put((String)entry.getKey(), entry.getValue());  
      jSONObject.put(com.bytedance.sdk.component.adexpress.a.c.c.c1671532477445dc("ae]f|qtfWmkm"), jSONObject1.toString());
    } catch (JSONException jSONException1) {
      JSONException jSONException2 = jSONException1;
      jSONException1.printStackTrace();
    } 
    b(System.currentTimeMillis(), paramContext, paramn, paramString1, paramString2, jSONObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\c\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */