package com.bytedance.sdk.openadsdk;

import com.bytedance.sdk.openadsdk.common.b;
import java.util.List;

@Deprecated
public interface TTAdNative {
  @Deprecated
  void loadAppOpenAd(AdSlot paramAdSlot, AppOpenAdListener paramAppOpenAdListener, int paramInt);
  
  @Deprecated
  void loadBannerExpressAd(AdSlot paramAdSlot, NativeExpressAdListener paramNativeExpressAdListener);
  
  @Deprecated
  void loadFeedAd(AdSlot paramAdSlot, FeedAdListener paramFeedAdListener);
  
  @Deprecated
  void loadFullScreenVideoAd(AdSlot paramAdSlot, FullScreenVideoAdListener paramFullScreenVideoAdListener);
  
  @Deprecated
  void loadRewardVideoAd(AdSlot paramAdSlot, RewardVideoAdListener paramRewardVideoAdListener);
  
  @Deprecated
  public static interface AppOpenAdListener extends b {
    void onAppOpenAdLoaded(TTAppOpenAd param1TTAppOpenAd);
    
    void onError(int param1Int, String param1String);
  }
  
  @Deprecated
  public static interface BannerAdListener extends b {
    void onBannerAdLoad(TTBannerAd param1TTBannerAd);
    
    void onError(int param1Int, String param1String);
  }
  
  @Deprecated
  public static interface FeedAdListener extends b {
    @Deprecated
    void onError(int param1Int, String param1String);
    
    @Deprecated
    void onFeedAdLoad(List<TTFeedAd> param1List);
  }
  
  @Deprecated
  public static interface FullScreenVideoAdListener extends b {
    void onError(int param1Int, String param1String);
    
    void onFullScreenVideoAdLoad(TTFullScreenVideoAd param1TTFullScreenVideoAd);
    
    void onFullScreenVideoCached();
  }
  
  @Deprecated
  public static interface InteractionAdListener extends b {
    void onError(int param1Int, String param1String);
    
    void onInteractionAdLoad(TTInteractionAd param1TTInteractionAd);
  }
  
  @Deprecated
  public static interface NativeAdListener extends b {
    void onError(int param1Int, String param1String);
    
    void onNativeAdLoad(List<TTNativeAd> param1List);
  }
  
  @Deprecated
  public static interface NativeExpressAdListener extends b {
    void onError(int param1Int, String param1String);
    
    void onNativeExpressAdLoad(List<TTNativeExpressAd> param1List);
  }
  
  @Deprecated
  public static interface RewardVideoAdListener extends b {
    void onError(int param1Int, String param1String);
    
    void onRewardVideoAdLoad(TTRewardVideoAd param1TTRewardVideoAd);
    
    void onRewardVideoCached();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\TTAdNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */