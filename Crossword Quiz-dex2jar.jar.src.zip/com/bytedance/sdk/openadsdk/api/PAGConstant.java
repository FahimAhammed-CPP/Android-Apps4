package com.bytedance.sdk.openadsdk.api;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public interface PAGConstant {
  @Retention(RetentionPolicy.CLASS)
  public static @interface PAGChildDirectedType {
    public static final int PAG_CHILD_DIRECTED_TYPE_CHILD = 1;
    
    public static final int PAG_CHILD_DIRECTED_TYPE_DEFAULT = -1;
    
    public static final int PAG_CHILD_DIRECTED_TYPE_NON_CHILD = 0;
  }
  
  @Retention(RetentionPolicy.CLASS)
  public static @interface PAGDoNotSellType {
    public static final int PAG_DO_NOT_SELL_TYPE_DEFAULT = -1;
    
    public static final int PAG_DO_NOT_SELL_TYPE_NOT_SELL = 1;
    
    public static final int PAG_DO_NOT_SELL_TYPE_SELL = 0;
  }
  
  @Retention(RetentionPolicy.CLASS)
  public static @interface PAGGDPRConsentType {
    public static final int PAG_GDPR_CONSENT_TYPE_CONSENT = 1;
    
    public static final int PAG_GDPR_CONSENT_TYPE_DEFAULT = -1;
    
    public static final int PAG_GDPR_CONSENT_TYPE_NO_CONSENT = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\api\PAGConstant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */