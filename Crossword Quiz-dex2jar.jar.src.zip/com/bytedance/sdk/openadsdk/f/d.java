package com.bytedance.sdk.openadsdk.f;

import org.json.JSONArray;

public interface d {
  void a(boolean paramBoolean, JSONArray paramJSONArray);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */