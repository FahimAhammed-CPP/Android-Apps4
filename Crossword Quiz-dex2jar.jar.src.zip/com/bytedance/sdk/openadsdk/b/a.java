package com.bytedance.sdk.openadsdk.b;

import com.bytedance.sdk.component.utils.f;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class a {
  private final ExecutorService a = Executors.newSingleThreadExecutor();
  
  private void b(File paramFile) throws IOException {
    try {
      f.b(paramFile);
    } finally {
      Exception exception = null;
    } 
  }
  
  public void a(File paramFile) throws IOException {
    this.a.submit(new a(paramFile));
  }
  
  protected abstract void a(List<File> paramList);
  
  protected abstract boolean a(long paramLong, int paramInt);
  
  protected abstract boolean a(File paramFile, long paramLong, int paramInt);
  
  long b(List<File> paramList) {
    Iterator<File> iterator = paramList.iterator();
    long l;
    for (l = 0L; iterator.hasNext(); l += ((File)iterator.next()).length());
    return l;
  }
  
  private class a implements Callable<Void> {
    private final File b;
    
    private a(a this$0, File param1File) {
      this.b = param1File;
    }
    
    public Void a() throws Exception {
      a.a(this.a, this.b);
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */