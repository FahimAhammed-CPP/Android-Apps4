package com.bytedance.sdk.openadsdk.l;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import com.bytedance.JProtect;
import com.bytedance.sdk.component.g.g;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.component.utils.t;
import com.bytedance.sdk.openadsdk.core.j;
import com.bytedance.sdk.openadsdk.core.m;
import com.bytedance.sdk.openadsdk.core.settings.j;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import java.io.IOException;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class f {
  public static String a = "";
  
  private static volatile boolean b = false;
  
  private static volatile boolean c = false;
  
  private static volatile boolean d = false;
  
  private static volatile boolean e = false;
  
  private static volatile boolean f = true;
  
  private static long g;
  
  private static int h;
  
  private static int i;
  
  private static int j;
  
  private static int k;
  
  private static int l;
  
  @JProtect
  public static JSONObject a(Context paramContext, boolean paramBoolean) {
    JSONObject jSONObject = new JSONObject();
    try {
      String str;
      jSONObject.put("sys_adb_status", e(paramContext));
      a(jSONObject);
      jSONObject.put("type", c(paramContext));
      boolean bool = true;
      jSONObject.put("os", 1);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Build.VERSION.RELEASE);
      stringBuilder.append("");
      jSONObject.put("os_version", stringBuilder.toString());
      jSONObject.put("vendor", Build.MANUFACTURER);
      jSONObject.put("conn_type", aa.m(paramContext));
      jSONObject.put("app_set_id", com.bytedance.sdk.openadsdk.core.settings.c.b());
      jSONObject.put("app_set_id_scope", com.bytedance.sdk.openadsdk.core.settings.c.a());
      jSONObject.put("installed_source", com.bytedance.sdk.openadsdk.core.settings.c.c());
      jSONObject.put("screen_width", ab.c(paramContext));
      jSONObject.put("screen_height", ab.d(paramContext));
      jSONObject.put("sec_did", com.bytedance.sdk.openadsdk.core.e.c.d());
      j j = m.d();
      if (j.w("boot")) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(System.currentTimeMillis() - SystemClock.elapsedRealtime());
        stringBuilder.append("");
        jSONObject.put("boot", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(SystemClock.elapsedRealtime());
        stringBuilder.append("");
        jSONObject.put("power_on_time", stringBuilder.toString());
      } 
      jSONObject.put("uuid", j.c(paramContext));
      jSONObject.put("rom_version", r.a());
      jSONObject.put("sys_compiling_time", j.b(paramContext));
      jSONObject.put("timezone", aa.r());
      jSONObject.put("language", j.a());
      jSONObject.put("carrier_name", s.a());
      if (paramBoolean) {
        str = aa.a(paramContext);
      } else {
        str = aa.b(paramContext);
      } 
      jSONObject.put("total_mem", String.valueOf(Long.parseLong(str) * 1024L));
      jSONObject.put("locale_language", c());
      jSONObject.put("screen_bright", Math.ceil((d() * 10.0F)) / 10.0D);
      if (a())
        bool = false; 
      jSONObject.put("is_screen_off", bool);
      jSONObject.put("cpu_num", e.a(paramContext));
      jSONObject.put("cpu_max_freq", e.b(paramContext));
      jSONObject.put("cpu_min_freq", e.c(paramContext));
      d.a a = d.a();
      jSONObject.put("battery_remaining_pct", (int)a.b);
      jSONObject.put("is_charging", a.a);
      jSONObject.put("total_space", String.valueOf(aa.c(paramContext)));
      jSONObject.put("free_space_in", String.valueOf(aa.d(paramContext)));
      jSONObject.put("sdcard_size", String.valueOf(aa.e(paramContext)));
      jSONObject.put("rooted", aa.f(paramContext));
      jSONObject.put("enable_assisted_clicking", e());
      jSONObject.put("force_language", t.a(paramContext, "tt_choose_language"));
      jSONObject.put("airplane", f(paramContext));
      jSONObject.put("darkmode", l(paramContext));
      jSONObject.put("headset", m(paramContext));
      jSONObject.put("ringmute", n(paramContext));
      jSONObject.put("screenscale", o(paramContext));
      jSONObject.put("volume", p(paramContext));
      jSONObject.put("low_power_mode", q(paramContext));
      if (j.w("mnc"))
        jSONObject.put("mnc", s.c()); 
      if (j.w("mcc"))
        jSONObject.put("mcc", s.b()); 
      return jSONObject;
    } catch (Exception exception) {
      return jSONObject;
    } 
  }
  
  private static void a(JSONObject paramJSONObject) throws JSONException {
    b(paramJSONObject);
  }
  
  @JProtect
  public static boolean a() {
    int i;
    byte b2;
    if (SystemClock.elapsedRealtime() - g >= 20000L) {
      g = SystemClock.elapsedRealtime();
      try {
        PowerManager powerManager = (PowerManager)m.a().getSystemService("power");
      } finally {
        Exception exception = null;
      } 
    } else {
    
    } 
    int j = i;
    byte b1 = b2;
  }
  
  public static boolean a(Context paramContext) {
    boolean bool = false;
    try {
      int i = (paramContext.getResources().getConfiguration()).screenLayout;
      return bool;
    } finally {
      paramContext = null;
    } 
  }
  
  public static int b() {
    return com.bytedance.sdk.openadsdk.core.c.a(m.a()).b("limit_ad_track", -1);
  }
  
  private static void b(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.put("model", Build.MODEL);
    if (m.d().w("gaid"))
      paramJSONObject.put("gaid", com.com.bytedance.overseas.sdk.b.a.a().b()); 
  }
  
  public static boolean b(Context paramContext) {
    boolean bool = false;
    try {
      int i = (paramContext.getResources().getConfiguration()).uiMode;
      return bool;
    } finally {
      paramContext = null;
    } 
  }
  
  public static int c(Context paramContext) {
    return b(paramContext) ? 3 : (a(paramContext) ? 2 : 1);
  }
  
  public static String c() {
    if (Build.VERSION.SDK_INT >= 21) {
      String str = Locale.getDefault().toLanguageTag();
      return !TextUtils.isEmpty(str) ? str : "";
    } 
    return Locale.getDefault().getLanguage();
  }
  
  public static float d() {
    byte b1;
    byte b2 = -1;
    try {
      Context context = m.a();
    } finally {
      Exception exception = null;
      l.e("DeviceUtils", exception.getMessage());
    } 
    return (b1 < 0) ? -1.0F : (Math.round(b1 / 255.0F * 10.0F) / 10.0F);
  }
  
  public static JSONObject d(Context paramContext) {
    return a(paramContext, false);
  }
  
  public static int e() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static int e(Context paramContext) {
    if (paramContext == null)
      return -1; 
    try {
      return Settings.Secure.getInt(contentResolver, "adb_enabled", -1);
    } finally {
      paramContext = null;
      l.e("DeviceUtils", paramContext.getMessage());
    } 
  }
  
  public static int f(Context paramContext) {
    try {
      int i = Build.VERSION.SDK_INT;
    } finally {
      paramContext = null;
    } 
    return 0;
  }
  
  @JProtect
  public static void f() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static String g(Context paramContext) {
    if (TextUtils.isEmpty(a))
      a = com.bytedance.sdk.openadsdk.core.c.a(paramContext).b("framework_name", ""); 
    return a;
  }
  
  public static void g() {
    try {
      int i = ((AudioManager)m.a().getSystemService("audio")).getRingerMode();
      if (i == 2)
        return; 
      if (i == 1)
        return; 
      return;
    } finally {
      Exception exception = null;
    } 
  }
  
  public static void h(Context paramContext) {
    if (paramContext != null)
      a.a(paramContext.getApplicationContext()); 
  }
  
  public static void i(Context paramContext) {
    if (!e) {
      if (paramContext == null)
        return; 
      paramContext = paramContext.getApplicationContext();
      if (paramContext == null)
        return; 
      try {
        if (Build.MANUFACTURER.equalsIgnoreCase("XIAOMI")) {
          v(paramContext);
        } else {
          b.a(paramContext);
        } 
        return;
      } finally {
        paramContext = null;
      } 
    } 
  }
  
  private static int l(Context paramContext) {
    try {
      int i = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode;
      return (i == 32) ? 1 : ((i == 16) ? 0 : -1);
    } finally {
      paramContext = null;
    } 
  }
  
  private static int m(Context paramContext) {
    return k;
  }
  
  private static int n(Context paramContext) {
    return h;
  }
  
  private static float o(Context paramContext) {
    return (paramContext.getResources().getDisplayMetrics()).density;
  }
  
  private static int p(Context paramContext) {
    return j;
  }
  
  private static int q(Context paramContext) {
    return l;
  }
  
  private static void r(Context paramContext) {
    try {
      AudioManager audioManager = (AudioManager)paramContext.getSystemService("audio");
      i = audioManager.getStreamMaxVolume(3);
      double d1 = audioManager.getStreamVolume(3);
      int i = i;
      double d2 = i;
      Double.isNaN(d1);
      Double.isNaN(d2);
      i = (int)(d1 / d2 * 100.0D);
      return;
    } finally {
      paramContext = null;
    } 
  }
  
  private static void s(Context paramContext) {
    if (paramContext == null)
      return; 
    y.b(new g("DeviceUtils_get_low_power_mode", paramContext.getApplicationContext()) {
          public void run() {
            f.a(f.j(this.a));
          }
        });
  }
  
  private static int t(Context paramContext) {
    if (paramContext == null)
      return 0; 
    try {
      if (Build.MANUFACTURER.equalsIgnoreCase("XIAOMI") || Build.MANUFACTURER.equalsIgnoreCase("HUAWEI"))
        return u(paramContext); 
      PowerManager powerManager = (PowerManager)paramContext.getSystemService("power");
    } finally {
      paramContext = null;
    } 
    return 0;
  }
  
  private static int u(Context paramContext) {
    try {
      boolean bool1 = Build.MANUFACTURER.equalsIgnoreCase("XIAOMI");
      boolean bool = true;
    } finally {
      paramContext = null;
    } 
    return 0;
  }
  
  private static void v(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    if (context == null)
      return; 
    ContentObserver contentObserver = new ContentObserver(null, context) {
        public void onChange(boolean param1Boolean) {
          super.onChange(param1Boolean);
          f.k(this.a);
        }
      };
    paramContext.getContentResolver().registerContentObserver(Uri.parse("content://settings/system/POWER_SAVE_MODE_OPEN"), false, contentObserver);
  }
  
  static class a extends BroadcastReceiver {
    private static void b(Context param1Context) {
      if (!f.j()) {
        if (param1Context == null)
          return; 
        try {
          IntentFilter intentFilter = new IntentFilter();
          intentFilter.addAction("android.media.VOLUME_CHANGED_ACTION");
          intentFilter.addAction("android.intent.action.HEADSET_PLUG");
          param1Context.registerReceiver(new a(), intentFilter);
          return;
        } finally {
          param1Context = null;
        } 
      } 
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent == null)
        return; 
      if ("android.media.VOLUME_CHANGED_ACTION".equals(param1Intent.getAction())) {
        if (param1Intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) == 3) {
          f.b(param1Intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0));
          if (f.h() != 0) {
            double d1 = f.i();
            double d2 = f.h();
            Double.isNaN(d1);
            Double.isNaN(d2);
            f.b((int)(d1 / d2 * 100.0D));
            return;
          } 
        } 
      } else if ("android.intent.action.HEADSET_PLUG".equals(param1Intent.getAction())) {
        f.c(param1Intent.getIntExtra("state", 0));
      } 
    }
  }
  
  private static class b extends BroadcastReceiver {
    private static void b(Context param1Context) {
      if (Build.VERSION.SDK_INT >= 21 && param1Context != null) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
        intentFilter.addAction("huawei.intent.action.POWER_MODE_CHANGED_ACTION");
        param1Context.registerReceiver(new b(), intentFilter);
      } 
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null) {
        if (param1Context == null)
          return; 
        if ("android.os.action.POWER_SAVE_MODE_CHANGED".equals(param1Intent.getAction())) {
          f.k(param1Context);
          return;
        } 
        if ("huawei.intent.action.POWER_MODE_CHANGED_ACTION".equals(param1Intent.getAction())) {
          boolean bool = false;
          if (param1Intent.getIntExtra("state", 0) == 1)
            bool = true; 
          f.a(bool);
        } 
      } 
    }
  }
  
  public static class c implements Runnable {
    public void run() {
      try {
        AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(m.a());
      } catch (IOException iOException) {
      
      } finally {
        Exception exception = null;
        l.e("DeviceUtils", exception.getMessage());
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\openadsdk\l\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */