package com.bytedance.sdk.component.adexpress.dynamic.interact;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.bytedance.sdk.component.adexpress.c.b;
import com.bytedance.sdk.component.adexpress.dynamic.b.g;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicBaseWidget;
import com.bytedance.sdk.component.adexpress.widget.WriggleGuideAnimationView;
import com.bytedance.sdk.component.adexpress.widget.WriggleGuideView;
import com.bytedance.sdk.component.utils.t;

public class q implements f<WriggleGuideAnimationView> {
  private WriggleGuideAnimationView a;
  
  private Context b;
  
  private DynamicBaseWidget c;
  
  private g d;
  
  private String e;
  
  private int f;
  
  public q(Context paramContext, DynamicBaseWidget paramDynamicBaseWidget, g paramg, String paramString, int paramInt) {
    this.b = paramContext;
    this.c = paramDynamicBaseWidget;
    this.d = paramg;
    this.e = paramString;
    this.f = paramInt;
    e();
  }
  
  private void e() {
    int i = this.d.N();
    if ("18".equals(this.e)) {
      Context context = this.b;
      WriggleGuideAnimationView wriggleGuideAnimationView = new WriggleGuideAnimationView(context, t.f(context, "tt_hand_wriggle_guide"), this.f);
      this.a = wriggleGuideAnimationView;
      if (wriggleGuideAnimationView.getWriggleLayout() != null)
        this.a.getWriggleLayout().setOnClickListener((View.OnClickListener)this.c.getDynamicClickListener()); 
      if (this.a.getTopTextView() != null)
        this.a.getTopTextView().setText(t.b(this.b, "tt_splash_wriggle_top_text_style_17")); 
    } else {
      Context context = this.b;
      this.a = new WriggleGuideAnimationView(context, t.f(context, "tt_hand_wriggle_guide"), this.f);
    } 
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
    layoutParams.gravity = 81;
    layoutParams.bottomMargin = (int)b.a(this.b, i);
    this.a.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.a.setShakeText(this.d.R());
    this.a.setClipChildren(false);
    WriggleGuideView wriggleGuideView = this.a.getWriggleProgressIv();
    this.a.setOnShakeViewListener(new WriggleGuideAnimationView.a(this, wriggleGuideView) {
          public void a() {
            WriggleGuideView wriggleGuideView = this.a;
            if (wriggleGuideView != null)
              wriggleGuideView.a(new WriggleGuideView.a(this) {
                    public void a() {
                      q.b(this.a.b).setOnClickListener((View.OnClickListener)q.a(this.a.b).getDynamicClickListener());
                      q.b(this.a.b).performClick();
                    }
                  }); 
          }
        });
  }
  
  public void a() {
    this.a.a();
  }
  
  public void b() {
    this.a.clearAnimation();
  }
  
  public WriggleGuideAnimationView c() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\adexpress\dynamic\interact\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */