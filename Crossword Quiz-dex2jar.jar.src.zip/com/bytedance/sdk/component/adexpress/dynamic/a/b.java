package com.bytedance.sdk.component.adexpress.dynamic.a;

import android.content.Context;
import com.bytedance.sdk.component.adexpress.dynamic.b.h;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicBaseInternalScrollWidgetImp;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicBaseScrollWidgetImp;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicBaseWidget;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicBaseWidgetImp;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicButton;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicClose;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicDislike;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicDislikeFeedBack;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicImageView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicLeisureWidget;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicLogoAd;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicLogoUnion;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicMutedView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicPrivacyView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicRoot;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicRootView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicSkipCountDown;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicSkipCountDownBtn;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicSkipCountDownContainer;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicSplitLineView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicStarView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicTextView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicTimeOuter;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicTimeOuterContainerWidgetImp;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicTimeOuterSkip;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicUnKnowView;
import com.bytedance.sdk.component.adexpress.dynamic.dynamicview.DynamicVideoView;

public class b {
  public static DynamicBaseWidget a(Context paramContext, DynamicRootView paramDynamicRootView, h paramh) {
    DynamicUnKnowView dynamicUnKnowView2 = null;
    DynamicUnKnowView dynamicUnKnowView1 = dynamicUnKnowView2;
    if (paramContext != null) {
      dynamicUnKnowView1 = dynamicUnKnowView2;
      if (paramDynamicRootView != null) {
        dynamicUnKnowView1 = dynamicUnKnowView2;
        if (paramh != null) {
          if (paramh.j() == null)
            return null; 
          switch (paramh.j().a()) {
            default:
              return null;
            case 26:
              return (DynamicBaseWidget)new DynamicBaseInternalScrollWidgetImp(paramContext, paramDynamicRootView, paramh);
            case 25:
              return (DynamicBaseWidget)new DynamicLeisureWidget(paramContext, paramDynamicRootView, paramh);
            case 24:
              return (DynamicBaseWidget)new DynamicBaseScrollWidgetImp(paramContext, paramDynamicRootView, paramh);
            case 23:
              return (DynamicBaseWidget)new DynamicPrivacyView(paramContext, paramDynamicRootView, paramh);
            case 22:
              return (DynamicBaseWidget)new DynamicClose(paramContext, paramDynamicRootView, paramh);
            case 21:
              return (DynamicBaseWidget)new DynamicSkipCountDownBtn(paramContext, paramDynamicRootView, paramh);
            case 20:
              return (DynamicBaseWidget)new DynamicSkipCountDown(paramContext, paramDynamicRootView, paramh);
            case 19:
              return (DynamicBaseWidget)new DynamicSkipCountDownContainer(paramContext, paramDynamicRootView, paramh);
            case 18:
              return (DynamicBaseWidget)new DynamicSplitLineView(paramContext, paramDynamicRootView, paramh);
            case 16:
              return (DynamicBaseWidget)new DynamicImageView(paramContext, paramDynamicRootView, paramh);
            case 15:
              return (DynamicBaseWidget)new DynamicTimeOuterSkip(paramContext, paramDynamicRootView, paramh);
            case 14:
              return (DynamicBaseWidget)new DynamicTimeOuterContainerWidgetImp(paramContext, paramDynamicRootView, paramh);
            case 13:
              return (DynamicBaseWidget)new DynamicTimeOuter(paramContext, paramDynamicRootView, paramh);
            case 12:
              return (DynamicBaseWidget)new DynamicDislikeFeedBack(paramContext, paramDynamicRootView, paramh);
            case 11:
              return (DynamicBaseWidget)new DynamicStarView(paramContext, paramDynamicRootView, paramh);
            case 10:
              return (DynamicBaseWidget)new DynamicMutedView(paramContext, paramDynamicRootView, paramh);
            case 8:
              return (DynamicBaseWidget)new DynamicRoot(paramContext, paramDynamicRootView, paramh);
            case 7:
              return (DynamicBaseWidget)new DynamicVideoView(paramContext, paramDynamicRootView, paramh);
            case 6:
            case 9:
            case 17:
              return (DynamicBaseWidget)new DynamicBaseWidgetImp(paramContext, paramDynamicRootView, paramh);
            case 5:
              return (DynamicBaseWidget)new DynamicLogoUnion(paramContext, paramDynamicRootView, paramh);
            case 4:
              return (DynamicBaseWidget)new DynamicLogoAd(paramContext, paramDynamicRootView, paramh);
            case 3:
              return (DynamicBaseWidget)new DynamicDislike(paramContext, paramDynamicRootView, paramh);
            case 2:
              return (DynamicBaseWidget)new DynamicButton(paramContext, paramDynamicRootView, paramh);
            case 1:
              return (DynamicBaseWidget)new DynamicImageView(paramContext, paramDynamicRootView, paramh);
            case 0:
              return (DynamicBaseWidget)new DynamicTextView(paramContext, paramDynamicRootView, paramh);
            case -1:
              break;
          } 
          dynamicUnKnowView1 = new DynamicUnKnowView(paramContext, paramDynamicRootView, paramh);
        } 
      } 
    } 
    return (DynamicBaseWidget)dynamicUnKnowView1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\adexpress\dynamic\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */