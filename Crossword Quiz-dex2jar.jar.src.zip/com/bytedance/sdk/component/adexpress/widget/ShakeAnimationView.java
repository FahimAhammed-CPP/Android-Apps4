package com.bytedance.sdk.component.adexpress.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bytedance.sdk.component.utils.t;
import com.bytedance.sdk.component.utils.u;

public class ShakeAnimationView extends LinearLayout {
  private TextView a;
  
  private ImageView b;
  
  private u c;
  
  private TextView d;
  
  private a e;
  
  private LinearLayout f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  public ShakeAnimationView(Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramContext);
    this.g = paramInt2;
    this.h = paramInt3;
    this.i = paramInt4;
    a(paramContext, paramInt1);
  }
  
  public void a() {
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, "alpha", new float[] { 0.0F, 1.0F });
    objectAnimator.setDuration(300L);
    objectAnimator.start();
    postDelayed(new Runnable(this) {
          public void run() {
            if (ShakeAnimationView.a(this.a) != null) {
              RotateAnimation rotateAnimation = new RotateAnimation(-14.0F, 14.0F, 1, 0.9F, 1, 0.9F);
              rotateAnimation.setInterpolator(new ShakeAnimationView.b());
              rotateAnimation.setDuration(1000L);
              rotateAnimation.setAnimationListener(new Animation.AnimationListener(this, rotateAnimation) {
                    public void onAnimationEnd(Animation param2Animation) {
                      this.b.a.postDelayed(new Runnable(this) {
                            public void run() {
                              ShakeAnimationView.a(this.a.b.a).startAnimation((Animation)this.a.a);
                            }
                          },  250L);
                    }
                    
                    public void onAnimationRepeat(Animation param2Animation) {}
                    
                    public void onAnimationStart(Animation param2Animation) {}
                  });
              ShakeAnimationView.a(this.a).startAnimation((Animation)rotateAnimation);
            } 
          }
        }500L);
  }
  
  protected void a(Context paramContext, int paramInt) {
    inflate(paramContext, paramInt, (ViewGroup)this);
    this.f = (LinearLayout)findViewById(t.e(paramContext, "tt_hand_container"));
    this.b = (ImageView)findViewById(t.e(paramContext, "tt_splash_rock_img"));
    this.a = (TextView)findViewById(t.e(paramContext, "tt_splash_rock_top_text"));
    this.d = (TextView)findViewById(t.e(paramContext, "tt_splash_rock_text"));
    GradientDrawable gradientDrawable = new GradientDrawable();
    gradientDrawable.setShape(1);
    gradientDrawable.setColor(Color.parseColor("#57000000"));
    this.f.setBackground((Drawable)gradientDrawable);
  }
  
  public LinearLayout getShakeLayout() {
    return this.f;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (isShown()) {
      if (this.c == null)
        this.c = new u(getContext().getApplicationContext()); 
      this.c.a(new u.a(this) {
            public void a(int param1Int) {
              boolean bool;
              if (ShakeAnimationView.b(this.a) != null) {
                bool = ShakeAnimationView.b(this.a).c();
              } else {
                bool = false;
              } 
              if (param1Int == 1 && this.a.isShown() && ShakeAnimationView.c(this.a) != null)
                ShakeAnimationView.c(this.a).a(bool); 
            }
          });
      this.c.a(this.g);
      this.c.c(this.h);
      this.c.a(this.i);
      this.c.a();
    } 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    u u1 = this.c;
    if (u1 != null)
      u1.b(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    u u1 = this.c;
    if (u1 != null) {
      if (paramBoolean) {
        u1.a();
        return;
      } 
      u1.b();
    } 
  }
  
  public void setOnShakeViewListener(a parama) {
    this.e = parama;
  }
  
  public void setShakeText(String paramString) {
    this.d.setText(paramString);
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
  
  private static class b implements Interpolator {
    private b() {}
    
    public float getInterpolation(float param1Float) {
      return (param1Float <= 0.25F) ? (param1Float * -2.0F + 0.5F) : ((param1Float <= 0.5F) ? (param1Float * 4.0F - 1.0F) : ((param1Float <= 0.75F) ? (param1Float * -4.0F + 3.0F) : (param1Float * 2.0F - 1.5F)));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bytedance\sdk\component\adexpress\widget\ShakeAnimationView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */