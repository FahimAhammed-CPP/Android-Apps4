package com.apm.insight.f;

import android.text.TextUtils;
import com.apm.insight.CrashType;
import com.apm.insight.entity.a;
import com.apm.insight.entity.c;
import com.apm.insight.k.g;
import com.apm.insight.l.q;
import com.apm.insight.l.v;
import com.apm.insight.runtime.a.f;
import java.util.Map;
import org.json.JSONObject;

public final class b {
  private static String a(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt) {
    if (paramArrayOfStackTraceElement == null || paramArrayOfStackTraceElement.length <= 0)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    while (paramInt < paramArrayOfStackTraceElement.length) {
      v.a(paramArrayOfStackTraceElement[paramInt], stringBuilder);
      paramInt++;
    } 
    return stringBuilder.toString();
  }
  
  public static void a(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2, String paramString3) {
    try {
      return;
    } finally {
      paramObject = null;
    } 
  }
  
  public static void a(Throwable paramThrowable, String paramString, boolean paramBoolean) {
    a(paramThrowable, paramString, paramBoolean, "core_exception_monitor");
  }
  
  public static void a(Throwable paramThrowable, String paramString1, boolean paramBoolean, String paramString2) {
    a(paramThrowable, paramString1, paramBoolean, (Map<String, String>)null, paramString2);
  }
  
  public static void a(Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2) {
    try {
      return;
    } finally {
      paramThrowable = null;
    } 
  }
  
  private static void a(Map<String, String> paramMap, c paramc) {
    try {
      JSONObject jSONObject = new JSONObject();
      return;
    } finally {
      paramMap = null;
    } 
  }
  
  public static void a(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt, String paramString1, String paramString2, Map<String, String> paramMap) {
    try {
      return;
    } finally {
      paramArrayOfStackTraceElement = null;
    } 
  }
  
  private static void b(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2) {
    c(paramObject, paramThrowable, paramString1, paramBoolean, paramMap, "EnsureNotReachHere", paramString2);
  }
  
  private static void b(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt, String paramString1, String paramString2, String paramString3, Map<String, String> paramMap) {
    if (paramArrayOfStackTraceElement != null) {
      try {
        if (paramArrayOfStackTraceElement.length <= paramInt + 1)
          return; 
      } finally {
        paramArrayOfStackTraceElement = null;
        q.b((Throwable)paramArrayOfStackTraceElement);
      } 
    } else {
      return;
    } 
    StackTraceElement stackTraceElement = paramArrayOfStackTraceElement[paramInt];
    if (stackTraceElement == null)
      return; 
    String str = a(paramArrayOfStackTraceElement, paramInt);
    if (TextUtils.isEmpty(str))
      return; 
    c c = c.a(stackTraceElement, str, paramString1, Thread.currentThread().getName(), true, paramString2, paramString3);
    a(paramMap, c);
    f.a().a(CrashType.ENSURE, (a)c);
    g.a(c);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[report] ");
    stringBuilder.append(paramString1);
    q.b(stringBuilder.toString());
  }
  
  private static void c(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2, String paramString3) {
    if (paramThrowable == null)
      return; 
    try {
      StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[0];
      if (stackTraceElement == null)
        return; 
      String str = v.a(paramThrowable);
      if (TextUtils.isEmpty(str))
        return; 
      c c = c.a(stackTraceElement, str, paramString1, Thread.currentThread().getName(), paramBoolean, paramString2, paramString3);
      if (paramObject != null)
        c.a("exception_line_num", com.apm.insight.entity.b.a(paramObject, paramThrowable, arrayOfStackTraceElement)); 
      a(paramMap, c);
      f.a().a(CrashType.ENSURE, (a)c);
      g.a(paramObject, c);
      paramObject = new StringBuilder();
      paramObject.append("[reportException] ");
      return;
    } finally {
      paramObject = null;
      q.b((Throwable)paramObject);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\apm\insight\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */