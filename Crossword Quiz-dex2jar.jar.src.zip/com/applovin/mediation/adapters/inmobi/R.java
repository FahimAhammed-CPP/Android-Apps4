package com.applovin.mediation.adapters.inmobi;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class array {
    public static final int al_exo_playback_speeds = 2130903040;
    
    public static final int al_exo_speed_multiplied_by_100 = 2130903041;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130968579;
    
    public static final int actionBarItemBackground = 2130968580;
    
    public static final int actionBarPopupTheme = 2130968581;
    
    public static final int actionBarSize = 2130968582;
    
    public static final int actionBarSplitStyle = 2130968583;
    
    public static final int actionBarStyle = 2130968584;
    
    public static final int actionBarTabBarStyle = 2130968585;
    
    public static final int actionBarTabStyle = 2130968586;
    
    public static final int actionBarTabTextStyle = 2130968587;
    
    public static final int actionBarTheme = 2130968588;
    
    public static final int actionBarWidgetTheme = 2130968589;
    
    public static final int actionButtonStyle = 2130968590;
    
    public static final int actionDropDownStyle = 2130968591;
    
    public static final int actionLayout = 2130968592;
    
    public static final int actionMenuTextAppearance = 2130968593;
    
    public static final int actionMenuTextColor = 2130968594;
    
    public static final int actionModeBackground = 2130968595;
    
    public static final int actionModeCloseButtonStyle = 2130968596;
    
    public static final int actionModeCloseDrawable = 2130968597;
    
    public static final int actionModeCopyDrawable = 2130968598;
    
    public static final int actionModeCutDrawable = 2130968599;
    
    public static final int actionModeFindDrawable = 2130968600;
    
    public static final int actionModePasteDrawable = 2130968601;
    
    public static final int actionModePopupWindowStyle = 2130968602;
    
    public static final int actionModeSelectAllDrawable = 2130968603;
    
    public static final int actionModeShareDrawable = 2130968604;
    
    public static final int actionModeSplitBackground = 2130968605;
    
    public static final int actionModeStyle = 2130968606;
    
    public static final int actionModeWebSearchDrawable = 2130968607;
    
    public static final int actionOverflowButtonStyle = 2130968608;
    
    public static final int actionOverflowMenuStyle = 2130968609;
    
    public static final int actionProviderClass = 2130968610;
    
    public static final int actionViewClass = 2130968611;
    
    public static final int activityChooserViewStyle = 2130968612;
    
    public static final int adSize = 2130968613;
    
    public static final int adSizes = 2130968614;
    
    public static final int adUnitId = 2130968616;
    
    public static final int al_ad_marker_color = 2130968617;
    
    public static final int al_ad_marker_width = 2130968618;
    
    public static final int al_animation_enabled = 2130968619;
    
    public static final int al_auto_show = 2130968620;
    
    public static final int al_backgroundTint = 2130968621;
    
    public static final int al_bar_gravity = 2130968622;
    
    public static final int al_bar_height = 2130968623;
    
    public static final int al_buffered_color = 2130968624;
    
    public static final int al_controller_layout_id = 2130968625;
    
    public static final int al_default_artwork = 2130968626;
    
    public static final int al_hide_during_ads = 2130968627;
    
    public static final int al_hide_on_touch = 2130968628;
    
    public static final int al_keep_content_on_player_reset = 2130968629;
    
    public static final int al_played_ad_marker_color = 2130968630;
    
    public static final int al_played_color = 2130968631;
    
    public static final int al_player_layout_id = 2130968632;
    
    public static final int al_repeat_toggle_modes = 2130968633;
    
    public static final int al_resize_mode = 2130968634;
    
    public static final int al_scrubber_color = 2130968635;
    
    public static final int al_scrubber_disabled_size = 2130968636;
    
    public static final int al_scrubber_dragged_size = 2130968637;
    
    public static final int al_scrubber_drawable = 2130968638;
    
    public static final int al_scrubber_enabled_size = 2130968639;
    
    public static final int al_show_buffering = 2130968640;
    
    public static final int al_show_fastforward_button = 2130968641;
    
    public static final int al_show_next_button = 2130968642;
    
    public static final int al_show_previous_button = 2130968643;
    
    public static final int al_show_rewind_button = 2130968644;
    
    public static final int al_show_shuffle_button = 2130968645;
    
    public static final int al_show_subtitle_button = 2130968646;
    
    public static final int al_show_timeout = 2130968647;
    
    public static final int al_show_vr_button = 2130968648;
    
    public static final int al_shutter_background_color = 2130968649;
    
    public static final int al_surface_type = 2130968650;
    
    public static final int al_time_bar_min_update_interval = 2130968651;
    
    public static final int al_touch_target_height = 2130968652;
    
    public static final int al_unplayed_color = 2130968653;
    
    public static final int al_use_artwork = 2130968654;
    
    public static final int al_use_controller = 2130968655;
    
    public static final int alertDialogButtonGroupStyle = 2130968656;
    
    public static final int alertDialogCenterButtons = 2130968657;
    
    public static final int alertDialogStyle = 2130968658;
    
    public static final int alertDialogTheme = 2130968659;
    
    public static final int allowStacking = 2130968660;
    
    public static final int alpha = 2130968661;
    
    public static final int alphabeticModifiers = 2130968662;
    
    public static final int arrowHeadLength = 2130968668;
    
    public static final int arrowShaftLength = 2130968669;
    
    public static final int autoCompleteTextViewStyle = 2130968672;
    
    public static final int autoSizeMaxTextSize = 2130968673;
    
    public static final int autoSizeMinTextSize = 2130968674;
    
    public static final int autoSizePresetSizes = 2130968675;
    
    public static final int autoSizeStepGranularity = 2130968676;
    
    public static final int autoSizeTextType = 2130968677;
    
    public static final int background = 2130968679;
    
    public static final int backgroundSplit = 2130968680;
    
    public static final int backgroundStacked = 2130968681;
    
    public static final int backgroundTint = 2130968682;
    
    public static final int backgroundTintMode = 2130968683;
    
    public static final int barLength = 2130968685;
    
    public static final int borderlessButtonStyle = 2130968692;
    
    public static final int buttonBarButtonStyle = 2130968694;
    
    public static final int buttonBarNegativeButtonStyle = 2130968695;
    
    public static final int buttonBarNeutralButtonStyle = 2130968696;
    
    public static final int buttonBarPositiveButtonStyle = 2130968697;
    
    public static final int buttonBarStyle = 2130968698;
    
    public static final int buttonCompat = 2130968699;
    
    public static final int buttonGravity = 2130968700;
    
    public static final int buttonIconDimen = 2130968701;
    
    public static final int buttonPanelSideLayout = 2130968702;
    
    public static final int buttonSize = 2130968703;
    
    public static final int buttonStyle = 2130968704;
    
    public static final int buttonStyleSmall = 2130968705;
    
    public static final int buttonTint = 2130968706;
    
    public static final int buttonTintMode = 2130968707;
    
    public static final int checkboxStyle = 2130968727;
    
    public static final int checkedTextViewStyle = 2130968728;
    
    public static final int circleCrop = 2130968729;
    
    public static final int closeIcon = 2130968738;
    
    public static final int closeItemLayout = 2130968739;
    
    public static final int collapseContentDescription = 2130968740;
    
    public static final int collapseIcon = 2130968741;
    
    public static final int color = 2130968742;
    
    public static final int colorAccent = 2130968743;
    
    public static final int colorBackgroundFloating = 2130968744;
    
    public static final int colorButtonNormal = 2130968745;
    
    public static final int colorControlActivated = 2130968746;
    
    public static final int colorControlHighlight = 2130968747;
    
    public static final int colorControlNormal = 2130968748;
    
    public static final int colorError = 2130968749;
    
    public static final int colorPrimary = 2130968750;
    
    public static final int colorPrimaryDark = 2130968751;
    
    public static final int colorScheme = 2130968752;
    
    public static final int colorSwitchThumbNormal = 2130968753;
    
    public static final int commitIcon = 2130968768;
    
    public static final int contentDescription = 2130968776;
    
    public static final int contentInsetEnd = 2130968777;
    
    public static final int contentInsetEndWithActions = 2130968778;
    
    public static final int contentInsetLeft = 2130968779;
    
    public static final int contentInsetRight = 2130968780;
    
    public static final int contentInsetStart = 2130968781;
    
    public static final int contentInsetStartWithNavigation = 2130968782;
    
    public static final int controlBackground = 2130968789;
    
    public static final int coordinatorLayoutStyle = 2130968790;
    
    public static final int customNavigationLayout = 2130968801;
    
    public static final int defaultQueryHint = 2130968806;
    
    public static final int dialogCornerRadius = 2130968811;
    
    public static final int dialogPreferredPadding = 2130968812;
    
    public static final int dialogTheme = 2130968813;
    
    public static final int displayOptions = 2130968814;
    
    public static final int divider = 2130968815;
    
    public static final int dividerHorizontal = 2130968816;
    
    public static final int dividerPadding = 2130968817;
    
    public static final int dividerVertical = 2130968818;
    
    public static final int drawableBottomCompat = 2130968823;
    
    public static final int drawableEndCompat = 2130968824;
    
    public static final int drawableLeftCompat = 2130968825;
    
    public static final int drawableRightCompat = 2130968826;
    
    public static final int drawableSize = 2130968827;
    
    public static final int drawableStartCompat = 2130968828;
    
    public static final int drawableTint = 2130968829;
    
    public static final int drawableTintMode = 2130968830;
    
    public static final int drawableTopCompat = 2130968831;
    
    public static final int drawerArrowStyle = 2130968832;
    
    public static final int dropDownListViewStyle = 2130968833;
    
    public static final int dropdownListPreferredItemHeight = 2130968834;
    
    public static final int editTextBackground = 2130968836;
    
    public static final int editTextColor = 2130968837;
    
    public static final int editTextStyle = 2130968838;
    
    public static final int elevation = 2130968839;
    
    public static final int expandActivityOverflowButtonDrawable = 2130968841;
    
    public static final int fastScrollEnabled = 2130968842;
    
    public static final int fastScrollHorizontalThumbDrawable = 2130968843;
    
    public static final int fastScrollHorizontalTrackDrawable = 2130968844;
    
    public static final int fastScrollVerticalThumbDrawable = 2130968845;
    
    public static final int fastScrollVerticalTrackDrawable = 2130968846;
    
    public static final int firstBaselineToTopHeight = 2130968847;
    
    public static final int font = 2130968867;
    
    public static final int fontFamily = 2130968868;
    
    public static final int fontProviderAuthority = 2130968869;
    
    public static final int fontProviderCerts = 2130968870;
    
    public static final int fontProviderFetchStrategy = 2130968871;
    
    public static final int fontProviderFetchTimeout = 2130968872;
    
    public static final int fontProviderPackage = 2130968873;
    
    public static final int fontProviderQuery = 2130968874;
    
    public static final int fontStyle = 2130968876;
    
    public static final int fontVariationSettings = 2130968877;
    
    public static final int fontWeight = 2130968878;
    
    public static final int gapBetweenBars = 2130968880;
    
    public static final int goIcon = 2130968881;
    
    public static final int height = 2130968884;
    
    public static final int hideOnContentScroll = 2130968885;
    
    public static final int homeAsUpIndicator = 2130968886;
    
    public static final int homeLayout = 2130968887;
    
    public static final int icon = 2130968890;
    
    public static final int iconTint = 2130968891;
    
    public static final int iconTintMode = 2130968892;
    
    public static final int iconifiedByDefault = 2130968893;
    
    public static final int imageAspectRatio = 2130968896;
    
    public static final int imageAspectRatioAdjust = 2130968897;
    
    public static final int imageButtonStyle = 2130968898;
    
    public static final int indeterminateProgressStyle = 2130968904;
    
    public static final int initialActivityCount = 2130968905;
    
    public static final int isLightTheme = 2130968906;
    
    public static final int itemPadding = 2130968907;
    
    public static final int keylines = 2130968909;
    
    public static final int lastBaselineToBottomHeight = 2130968910;
    
    public static final int layout = 2130968911;
    
    public static final int layoutManager = 2130968914;
    
    public static final int layout_anchor = 2130968915;
    
    public static final int layout_anchorGravity = 2130968916;
    
    public static final int layout_behavior = 2130968917;
    
    public static final int layout_dodgeInsetEdges = 2130968964;
    
    public static final int layout_insetEdge = 2130968974;
    
    public static final int layout_keyline = 2130968975;
    
    public static final int lineHeight = 2130968980;
    
    public static final int listChoiceBackgroundIndicator = 2130968981;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130968982;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130968983;
    
    public static final int listDividerAlertDialog = 2130968984;
    
    public static final int listItemLayout = 2130968985;
    
    public static final int listLayout = 2130968986;
    
    public static final int listMenuViewStyle = 2130968987;
    
    public static final int listPopupWindowStyle = 2130968988;
    
    public static final int listPreferredItemHeight = 2130968989;
    
    public static final int listPreferredItemHeightLarge = 2130968990;
    
    public static final int listPreferredItemHeightSmall = 2130968991;
    
    public static final int listPreferredItemPaddingEnd = 2130968992;
    
    public static final int listPreferredItemPaddingLeft = 2130968993;
    
    public static final int listPreferredItemPaddingRight = 2130968994;
    
    public static final int listPreferredItemPaddingStart = 2130968995;
    
    public static final int logo = 2130968997;
    
    public static final int logoDescription = 2130968998;
    
    public static final int maxButtonHeight = 2130969000;
    
    public static final int measureWithLargestChild = 2130969012;
    
    public static final int menu = 2130969013;
    
    public static final int multiChoiceItemLayout = 2130969040;
    
    public static final int navigationContentDescription = 2130969041;
    
    public static final int navigationIcon = 2130969042;
    
    public static final int navigationMode = 2130969043;
    
    public static final int numericModifiers = 2130969046;
    
    public static final int overlapAnchor = 2130969054;
    
    public static final int paddingBottomNoButtons = 2130969056;
    
    public static final int paddingEnd = 2130969057;
    
    public static final int paddingStart = 2130969058;
    
    public static final int paddingTopNoTitle = 2130969059;
    
    public static final int panelBackground = 2130969060;
    
    public static final int panelMenuListTheme = 2130969061;
    
    public static final int panelMenuListWidth = 2130969062;
    
    public static final int popupMenuStyle = 2130969073;
    
    public static final int popupTheme = 2130969074;
    
    public static final int popupWindowStyle = 2130969075;
    
    public static final int preserveIconSpacing = 2130969076;
    
    public static final int progressBarPadding = 2130969077;
    
    public static final int progressBarStyle = 2130969078;
    
    public static final int queryBackground = 2130969082;
    
    public static final int queryHint = 2130969083;
    
    public static final int radioButtonStyle = 2130969085;
    
    public static final int ratingBarStyle = 2130969086;
    
    public static final int ratingBarStyleIndicator = 2130969087;
    
    public static final int ratingBarStyleSmall = 2130969088;
    
    public static final int recyclerViewStyle = 2130969093;
    
    public static final int reverseLayout = 2130969098;
    
    public static final int scopeUris = 2130969104;
    
    public static final int searchHintIcon = 2130969105;
    
    public static final int searchIcon = 2130969106;
    
    public static final int searchViewStyle = 2130969107;
    
    public static final int seekBarStyle = 2130969108;
    
    public static final int selectableItemBackground = 2130969109;
    
    public static final int selectableItemBackgroundBorderless = 2130969110;
    
    public static final int showAsAction = 2130969113;
    
    public static final int showDividers = 2130969114;
    
    public static final int showText = 2130969116;
    
    public static final int showTitle = 2130969117;
    
    public static final int singleChoiceItemLayout = 2130969118;
    
    public static final int spanCount = 2130969126;
    
    public static final int spinBars = 2130969127;
    
    public static final int spinnerDropDownItemStyle = 2130969128;
    
    public static final int spinnerStyle = 2130969129;
    
    public static final int splitTrack = 2130969130;
    
    public static final int srcCompat = 2130969136;
    
    public static final int stackFromEnd = 2130969137;
    
    public static final int state_above_anchor = 2130969140;
    
    public static final int statusBarBackground = 2130969141;
    
    public static final int subMenuArrow = 2130969142;
    
    public static final int submitBackground = 2130969143;
    
    public static final int subtitle = 2130969144;
    
    public static final int subtitleTextAppearance = 2130969145;
    
    public static final int subtitleTextColor = 2130969146;
    
    public static final int subtitleTextStyle = 2130969147;
    
    public static final int suggestionRowLayout = 2130969148;
    
    public static final int switchMinWidth = 2130969149;
    
    public static final int switchPadding = 2130969150;
    
    public static final int switchStyle = 2130969151;
    
    public static final int switchTextAppearance = 2130969152;
    
    public static final int textAllCaps = 2130969157;
    
    public static final int textAppearanceLargePopupMenu = 2130969158;
    
    public static final int textAppearanceListItem = 2130969159;
    
    public static final int textAppearanceListItemSecondary = 2130969160;
    
    public static final int textAppearanceListItemSmall = 2130969161;
    
    public static final int textAppearancePopupMenuHeader = 2130969162;
    
    public static final int textAppearanceSearchResultSubtitle = 2130969163;
    
    public static final int textAppearanceSearchResultTitle = 2130969164;
    
    public static final int textAppearanceSmallPopupMenu = 2130969165;
    
    public static final int textColorAlertDialogListItem = 2130969171;
    
    public static final int textColorSearchUrl = 2130969172;
    
    public static final int textLocale = 2130969174;
    
    public static final int theme = 2130969183;
    
    public static final int thickness = 2130969184;
    
    public static final int thumbTextPadding = 2130969185;
    
    public static final int thumbTint = 2130969186;
    
    public static final int thumbTintMode = 2130969187;
    
    public static final int tickMark = 2130969188;
    
    public static final int tickMarkTint = 2130969189;
    
    public static final int tickMarkTintMode = 2130969190;
    
    public static final int tint = 2130969191;
    
    public static final int tintMode = 2130969192;
    
    public static final int title = 2130969193;
    
    public static final int titleMargin = 2130969194;
    
    public static final int titleMarginBottom = 2130969195;
    
    public static final int titleMarginEnd = 2130969196;
    
    public static final int titleMarginStart = 2130969197;
    
    public static final int titleMarginTop = 2130969198;
    
    public static final int titleMargins = 2130969199;
    
    public static final int titleTextAppearance = 2130969200;
    
    public static final int titleTextColor = 2130969201;
    
    public static final int titleTextStyle = 2130969202;
    
    public static final int toolbarNavigationButtonStyle = 2130969203;
    
    public static final int toolbarStyle = 2130969204;
    
    public static final int tooltipForegroundColor = 2130969205;
    
    public static final int tooltipFrameBackground = 2130969206;
    
    public static final int tooltipText = 2130969207;
    
    public static final int track = 2130969211;
    
    public static final int trackTint = 2130969212;
    
    public static final int trackTintMode = 2130969213;
    
    public static final int ttcIndex = 2130969222;
    
    public static final int viewInflaterClass = 2130969224;
    
    public static final int voiceIcon = 2130969230;
    
    public static final int windowActionBar = 2130969238;
    
    public static final int windowActionBarOverlay = 2130969239;
    
    public static final int windowActionModeOverlay = 2130969240;
    
    public static final int windowFixedHeightMajor = 2130969241;
    
    public static final int windowFixedHeightMinor = 2130969242;
    
    public static final int windowFixedWidthMajor = 2130969243;
    
    public static final int windowFixedWidthMinor = 2130969244;
    
    public static final int windowMinWidthMajor = 2130969245;
    
    public static final int windowMinWidthMinor = 2130969246;
    
    public static final int windowNoTitle = 2130969247;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    
    public static final int abc_allow_stacked_button_bar = 2131034113;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034114;
    
    public static final int enable_system_alarm_service_default = 2131034115;
    
    public static final int enable_system_job_service_default = 2131034117;
    
    public static final int workmanager_test_configuration = 2131034118;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131099648;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131099649;
    
    public static final int abc_btn_colored_borderless_text_material = 2131099650;
    
    public static final int abc_btn_colored_text_material = 2131099651;
    
    public static final int abc_color_highlight_material = 2131099652;
    
    public static final int abc_hint_foreground_material_dark = 2131099655;
    
    public static final int abc_hint_foreground_material_light = 2131099656;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131099657;
    
    public static final int abc_primary_text_disable_only_material_light = 2131099658;
    
    public static final int abc_primary_text_material_dark = 2131099659;
    
    public static final int abc_primary_text_material_light = 2131099660;
    
    public static final int abc_search_url_text = 2131099661;
    
    public static final int abc_search_url_text_normal = 2131099662;
    
    public static final int abc_search_url_text_pressed = 2131099663;
    
    public static final int abc_search_url_text_selected = 2131099664;
    
    public static final int abc_secondary_text_material_dark = 2131099665;
    
    public static final int abc_secondary_text_material_light = 2131099666;
    
    public static final int abc_tint_btn_checkable = 2131099667;
    
    public static final int abc_tint_default = 2131099668;
    
    public static final int abc_tint_edittext = 2131099669;
    
    public static final int abc_tint_seek_thumb = 2131099670;
    
    public static final int abc_tint_spinner = 2131099671;
    
    public static final int abc_tint_switch_track = 2131099672;
    
    public static final int accent_material_dark = 2131099673;
    
    public static final int accent_material_light = 2131099674;
    
    public static final int al_exo_black_opacity_60 = 2131099675;
    
    public static final int al_exo_black_opacity_70 = 2131099676;
    
    public static final int al_exo_bottom_bar_background = 2131099677;
    
    public static final int al_exo_edit_mode_background_color = 2131099678;
    
    public static final int al_exo_error_message_background_color = 2131099679;
    
    public static final int al_exo_styled_error_message_background = 2131099680;
    
    public static final int al_exo_white = 2131099681;
    
    public static final int al_exo_white_opacity_70 = 2131099682;
    
    public static final int androidx_core_ripple_material_light = 2131099683;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131099684;
    
    public static final int applovin_sdk_adBadgeTextColor = 2131099685;
    
    public static final int applovin_sdk_adControlbutton_brightBlueColor = 2131099686;
    
    public static final int applovin_sdk_brand_color = 2131099687;
    
    public static final int applovin_sdk_brand_color_dark = 2131099688;
    
    public static final int applovin_sdk_checkmarkColor = 2131099689;
    
    public static final int applovin_sdk_ctaButtonColor = 2131099690;
    
    public static final int applovin_sdk_ctaButtonPressedColor = 2131099691;
    
    public static final int applovin_sdk_disclosureButtonColor = 2131099692;
    
    public static final int applovin_sdk_greenColor = 2131099693;
    
    public static final int applovin_sdk_listViewBackground = 2131099694;
    
    public static final int applovin_sdk_listViewSectionTextColor = 2131099695;
    
    public static final int applovin_sdk_textColorPrimary = 2131099696;
    
    public static final int applovin_sdk_textColorPrimaryDark = 2131099697;
    
    public static final int applovin_sdk_textColorSecondaryDark = 2131099698;
    
    public static final int applovin_sdk_warningColor = 2131099699;
    
    public static final int applovin_sdk_xmarkColor = 2131099700;
    
    public static final int background_floating_material_dark = 2131099701;
    
    public static final int background_floating_material_light = 2131099702;
    
    public static final int background_material_dark = 2131099703;
    
    public static final int background_material_light = 2131099704;
    
    public static final int bright_foreground_disabled_material_dark = 2131099706;
    
    public static final int bright_foreground_disabled_material_light = 2131099707;
    
    public static final int bright_foreground_inverse_material_dark = 2131099708;
    
    public static final int bright_foreground_inverse_material_light = 2131099709;
    
    public static final int bright_foreground_material_dark = 2131099710;
    
    public static final int bright_foreground_material_light = 2131099711;
    
    public static final int browser_actions_bg_grey = 2131099712;
    
    public static final int browser_actions_divider_color = 2131099713;
    
    public static final int browser_actions_text_color = 2131099714;
    
    public static final int browser_actions_title_color = 2131099715;
    
    public static final int button_material_dark = 2131099716;
    
    public static final int button_material_light = 2131099717;
    
    public static final int common_google_signin_btn_text_dark = 2131099740;
    
    public static final int common_google_signin_btn_text_dark_default = 2131099741;
    
    public static final int common_google_signin_btn_text_dark_disabled = 2131099742;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131099743;
    
    public static final int common_google_signin_btn_text_dark_pressed = 2131099744;
    
    public static final int common_google_signin_btn_text_light = 2131099745;
    
    public static final int common_google_signin_btn_text_light_default = 2131099746;
    
    public static final int common_google_signin_btn_text_light_disabled = 2131099747;
    
    public static final int common_google_signin_btn_text_light_focused = 2131099748;
    
    public static final int common_google_signin_btn_text_light_pressed = 2131099749;
    
    public static final int common_google_signin_btn_tint = 2131099750;
    
    public static final int dim_foreground_disabled_material_dark = 2131099751;
    
    public static final int dim_foreground_disabled_material_light = 2131099752;
    
    public static final int dim_foreground_material_dark = 2131099753;
    
    public static final int dim_foreground_material_light = 2131099754;
    
    public static final int error_color_material_dark = 2131099755;
    
    public static final int error_color_material_light = 2131099756;
    
    public static final int foreground_material_dark = 2131099757;
    
    public static final int foreground_material_light = 2131099758;
    
    public static final int highlighted_text_material_dark = 2131099762;
    
    public static final int highlighted_text_material_light = 2131099763;
    
    public static final int material_blue_grey_800 = 2131099786;
    
    public static final int material_blue_grey_900 = 2131099787;
    
    public static final int material_blue_grey_950 = 2131099788;
    
    public static final int material_deep_teal_200 = 2131099789;
    
    public static final int material_deep_teal_500 = 2131099790;
    
    public static final int material_grey_100 = 2131099791;
    
    public static final int material_grey_300 = 2131099792;
    
    public static final int material_grey_50 = 2131099793;
    
    public static final int material_grey_600 = 2131099794;
    
    public static final int material_grey_800 = 2131099795;
    
    public static final int material_grey_850 = 2131099796;
    
    public static final int material_grey_900 = 2131099797;
    
    public static final int notification_action_color_filter = 2131099857;
    
    public static final int notification_icon_bg_color = 2131099858;
    
    public static final int primary_dark_material_dark = 2131099860;
    
    public static final int primary_dark_material_light = 2131099861;
    
    public static final int primary_material_dark = 2131099862;
    
    public static final int primary_material_light = 2131099863;
    
    public static final int primary_text_default_material_dark = 2131099864;
    
    public static final int primary_text_default_material_light = 2131099865;
    
    public static final int primary_text_disabled_material_dark = 2131099866;
    
    public static final int primary_text_disabled_material_light = 2131099867;
    
    public static final int ripple_material_dark = 2131099869;
    
    public static final int ripple_material_light = 2131099870;
    
    public static final int secondary_text_default_material_dark = 2131099871;
    
    public static final int secondary_text_default_material_light = 2131099872;
    
    public static final int secondary_text_disabled_material_dark = 2131099873;
    
    public static final int secondary_text_disabled_material_light = 2131099874;
    
    public static final int switch_thumb_disabled_material_dark = 2131099883;
    
    public static final int switch_thumb_disabled_material_light = 2131099884;
    
    public static final int switch_thumb_material_dark = 2131099885;
    
    public static final int switch_thumb_material_light = 2131099886;
    
    public static final int switch_thumb_normal_material_dark = 2131099887;
    
    public static final int switch_thumb_normal_material_light = 2131099888;
    
    public static final int tooltip_background_dark = 2131099889;
    
    public static final int tooltip_background_light = 2131099890;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131165184;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static final int abc_action_bar_default_height_material = 2131165186;
    
    public static final int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static final int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static final int abc_action_bar_elevation_material = 2131165189;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static final int abc_action_bar_stacked_max_height = 2131165193;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static final int abc_action_button_min_height_material = 2131165197;
    
    public static final int abc_action_button_min_width_material = 2131165198;
    
    public static final int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static final int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static final int abc_alert_dialog_button_dimen = 2131165201;
    
    public static final int abc_button_inset_horizontal_material = 2131165202;
    
    public static final int abc_button_inset_vertical_material = 2131165203;
    
    public static final int abc_button_padding_horizontal_material = 2131165204;
    
    public static final int abc_button_padding_vertical_material = 2131165205;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static final int abc_config_prefDialogWidth = 2131165207;
    
    public static final int abc_control_corner_material = 2131165208;
    
    public static final int abc_control_inset_material = 2131165209;
    
    public static final int abc_control_padding_material = 2131165210;
    
    public static final int abc_dialog_corner_radius_material = 2131165211;
    
    public static final int abc_dialog_fixed_height_major = 2131165212;
    
    public static final int abc_dialog_fixed_height_minor = 2131165213;
    
    public static final int abc_dialog_fixed_width_major = 2131165214;
    
    public static final int abc_dialog_fixed_width_minor = 2131165215;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static final int abc_dialog_min_width_major = 2131165218;
    
    public static final int abc_dialog_min_width_minor = 2131165219;
    
    public static final int abc_dialog_padding_material = 2131165220;
    
    public static final int abc_dialog_padding_top_material = 2131165221;
    
    public static final int abc_dialog_title_divider_material = 2131165222;
    
    public static final int abc_disabled_alpha_material_dark = 2131165223;
    
    public static final int abc_disabled_alpha_material_light = 2131165224;
    
    public static final int abc_dropdownitem_icon_width = 2131165225;
    
    public static final int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static final int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static final int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static final int abc_edit_text_inset_top_material = 2131165230;
    
    public static final int abc_floating_window_z = 2131165231;
    
    public static final int abc_list_item_height_large_material = 2131165232;
    
    public static final int abc_list_item_height_material = 2131165233;
    
    public static final int abc_list_item_height_small_material = 2131165234;
    
    public static final int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static final int abc_panel_menu_list_width = 2131165236;
    
    public static final int abc_progress_bar_height_material = 2131165237;
    
    public static final int abc_search_view_preferred_height = 2131165238;
    
    public static final int abc_search_view_preferred_width = 2131165239;
    
    public static final int abc_seekbar_track_background_height_material = 2131165240;
    
    public static final int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static final int abc_select_dialog_padding_start_material = 2131165242;
    
    public static final int abc_switch_padding = 2131165243;
    
    public static final int abc_text_size_body_1_material = 2131165244;
    
    public static final int abc_text_size_body_2_material = 2131165245;
    
    public static final int abc_text_size_button_material = 2131165246;
    
    public static final int abc_text_size_caption_material = 2131165247;
    
    public static final int abc_text_size_display_1_material = 2131165248;
    
    public static final int abc_text_size_display_2_material = 2131165249;
    
    public static final int abc_text_size_display_3_material = 2131165250;
    
    public static final int abc_text_size_display_4_material = 2131165251;
    
    public static final int abc_text_size_headline_material = 2131165252;
    
    public static final int abc_text_size_large_material = 2131165253;
    
    public static final int abc_text_size_medium_material = 2131165254;
    
    public static final int abc_text_size_menu_header_material = 2131165255;
    
    public static final int abc_text_size_menu_material = 2131165256;
    
    public static final int abc_text_size_small_material = 2131165257;
    
    public static final int abc_text_size_subhead_material = 2131165258;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131165259;
    
    public static final int abc_text_size_title_material = 2131165260;
    
    public static final int abc_text_size_title_material_toolbar = 2131165261;
    
    public static final int al_exo_error_message_height = 2131165262;
    
    public static final int al_exo_error_message_margin_bottom = 2131165263;
    
    public static final int al_exo_error_message_text_padding_horizontal = 2131165264;
    
    public static final int al_exo_error_message_text_padding_vertical = 2131165265;
    
    public static final int al_exo_error_message_text_size = 2131165266;
    
    public static final int al_exo_icon_horizontal_margin = 2131165267;
    
    public static final int al_exo_icon_padding = 2131165268;
    
    public static final int al_exo_icon_padding_bottom = 2131165269;
    
    public static final int al_exo_icon_size = 2131165270;
    
    public static final int al_exo_icon_text_size = 2131165271;
    
    public static final int al_exo_media_button_height = 2131165272;
    
    public static final int al_exo_media_button_width = 2131165273;
    
    public static final int al_exo_setting_width = 2131165274;
    
    public static final int al_exo_settings_height = 2131165275;
    
    public static final int al_exo_settings_icon_size = 2131165276;
    
    public static final int al_exo_settings_main_text_size = 2131165277;
    
    public static final int al_exo_settings_offset = 2131165278;
    
    public static final int al_exo_settings_sub_text_size = 2131165279;
    
    public static final int al_exo_settings_text_height = 2131165280;
    
    public static final int al_exo_small_icon_height = 2131165281;
    
    public static final int al_exo_small_icon_horizontal_margin = 2131165282;
    
    public static final int al_exo_small_icon_padding_horizontal = 2131165283;
    
    public static final int al_exo_small_icon_padding_vertical = 2131165284;
    
    public static final int al_exo_small_icon_width = 2131165285;
    
    public static final int al_exo_styled_bottom_bar_height = 2131165286;
    
    public static final int al_exo_styled_bottom_bar_margin_top = 2131165287;
    
    public static final int al_exo_styled_bottom_bar_time_padding = 2131165288;
    
    public static final int al_exo_styled_controls_padding = 2131165289;
    
    public static final int al_exo_styled_minimal_controls_margin_bottom = 2131165290;
    
    public static final int al_exo_styled_progress_bar_height = 2131165291;
    
    public static final int al_exo_styled_progress_dragged_thumb_size = 2131165292;
    
    public static final int al_exo_styled_progress_enabled_thumb_size = 2131165293;
    
    public static final int al_exo_styled_progress_layout_height = 2131165294;
    
    public static final int al_exo_styled_progress_margin_bottom = 2131165295;
    
    public static final int al_exo_styled_progress_touch_target_height = 2131165296;
    
    public static final int applovin_sdk_actionBarHeight = 2131165301;
    
    public static final int applovin_sdk_adControlButton_height = 2131165302;
    
    public static final int applovin_sdk_adControlButton_width = 2131165303;
    
    public static final int applovin_sdk_mediationDebuggerDetailListItemTextSize = 2131165304;
    
    public static final int applovin_sdk_mediationDebuggerSectionHeight = 2131165305;
    
    public static final int applovin_sdk_mediationDebuggerSectionTextSize = 2131165306;
    
    public static final int applovin_sdk_mrec_height = 2131165307;
    
    public static final int applovin_sdk_mrec_width = 2131165308;
    
    public static final int browser_actions_context_menu_max_width = 2131165311;
    
    public static final int browser_actions_context_menu_min_padding = 2131165312;
    
    public static final int compat_button_inset_horizontal_material = 2131165332;
    
    public static final int compat_button_inset_vertical_material = 2131165333;
    
    public static final int compat_button_padding_horizontal_material = 2131165334;
    
    public static final int compat_button_padding_vertical_material = 2131165335;
    
    public static final int compat_control_corner_material = 2131165336;
    
    public static final int compat_notification_large_icon_max_height = 2131165337;
    
    public static final int compat_notification_large_icon_max_width = 2131165338;
    
    public static final int default_margin = 2131165339;
    
    public static final int disabled_alpha_material_dark = 2131165342;
    
    public static final int disabled_alpha_material_light = 2131165343;
    
    public static final int fastscroll_default_thickness = 2131165344;
    
    public static final int fastscroll_margin = 2131165345;
    
    public static final int fastscroll_minimum_range = 2131165346;
    
    public static final int highlight_alpha_material_colored = 2131165347;
    
    public static final int highlight_alpha_material_dark = 2131165348;
    
    public static final int highlight_alpha_material_light = 2131165349;
    
    public static final int hint_alpha_material_dark = 2131165350;
    
    public static final int hint_alpha_material_light = 2131165351;
    
    public static final int hint_pressed_alpha_material_dark = 2131165352;
    
    public static final int hint_pressed_alpha_material_light = 2131165353;
    
    public static final int item_touch_helper_max_drag_scroll_per_frame = 2131165413;
    
    public static final int item_touch_helper_swipe_escape_max_velocity = 2131165414;
    
    public static final int item_touch_helper_swipe_escape_velocity = 2131165415;
    
    public static final int notification_action_icon_size = 2131165429;
    
    public static final int notification_action_text_size = 2131165430;
    
    public static final int notification_big_circle_margin = 2131165431;
    
    public static final int notification_content_margin_start = 2131165432;
    
    public static final int notification_large_icon_height = 2131165433;
    
    public static final int notification_large_icon_width = 2131165434;
    
    public static final int notification_main_column_padding_top = 2131165435;
    
    public static final int notification_media_narrow_margin = 2131165436;
    
    public static final int notification_right_icon_size = 2131165437;
    
    public static final int notification_right_side_padding_top = 2131165438;
    
    public static final int notification_small_icon_background_padding = 2131165439;
    
    public static final int notification_small_icon_size_as_large = 2131165440;
    
    public static final int notification_subtext_size = 2131165441;
    
    public static final int notification_top_pad = 2131165442;
    
    public static final int notification_top_pad_large_text = 2131165443;
    
    public static final int text_margin = 2131165454;
    
    public static final int tooltip_corner_radius = 2131165455;
    
    public static final int tooltip_horizontal_padding = 2131165456;
    
    public static final int tooltip_margin = 2131165457;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131165458;
    
    public static final int tooltip_precise_anchor_threshold = 2131165459;
    
    public static final int tooltip_vertical_padding = 2131165460;
    
    public static final int tooltip_y_offset_non_touch = 2131165461;
    
    public static final int tooltip_y_offset_touch = 2131165462;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131230730;
    
    public static final int abc_action_bar_item_background_material = 2131230731;
    
    public static final int abc_btn_borderless_material = 2131230732;
    
    public static final int abc_btn_check_material = 2131230733;
    
    public static final int abc_btn_check_material_anim = 2131230734;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131230735;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131230736;
    
    public static final int abc_btn_colored_material = 2131230737;
    
    public static final int abc_btn_default_mtrl_shape = 2131230738;
    
    public static final int abc_btn_radio_material = 2131230739;
    
    public static final int abc_btn_radio_material_anim = 2131230740;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131230741;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131230742;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131230743;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131230744;
    
    public static final int abc_cab_background_internal_bg = 2131230745;
    
    public static final int abc_cab_background_top_material = 2131230746;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131230747;
    
    public static final int abc_control_background_material = 2131230748;
    
    public static final int abc_dialog_material_background = 2131230749;
    
    public static final int abc_edit_text_material = 2131230750;
    
    public static final int abc_ic_ab_back_material = 2131230751;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131230752;
    
    public static final int abc_ic_clear_material = 2131230753;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131230754;
    
    public static final int abc_ic_go_search_api_material = 2131230755;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131230756;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131230757;
    
    public static final int abc_ic_menu_overflow_material = 2131230758;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131230759;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131230760;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131230761;
    
    public static final int abc_ic_search_api_material = 2131230762;
    
    public static final int abc_ic_star_black_16dp = 2131230763;
    
    public static final int abc_ic_star_black_36dp = 2131230764;
    
    public static final int abc_ic_star_black_48dp = 2131230765;
    
    public static final int abc_ic_star_half_black_16dp = 2131230766;
    
    public static final int abc_ic_star_half_black_36dp = 2131230767;
    
    public static final int abc_ic_star_half_black_48dp = 2131230768;
    
    public static final int abc_ic_voice_search_api_material = 2131230769;
    
    public static final int abc_item_background_holo_dark = 2131230770;
    
    public static final int abc_item_background_holo_light = 2131230771;
    
    public static final int abc_list_divider_material = 2131230772;
    
    public static final int abc_list_divider_mtrl_alpha = 2131230773;
    
    public static final int abc_list_focused_holo = 2131230774;
    
    public static final int abc_list_longpressed_holo = 2131230775;
    
    public static final int abc_list_pressed_holo_dark = 2131230776;
    
    public static final int abc_list_pressed_holo_light = 2131230777;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131230778;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131230779;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131230780;
    
    public static final int abc_list_selector_disabled_holo_light = 2131230781;
    
    public static final int abc_list_selector_holo_dark = 2131230782;
    
    public static final int abc_list_selector_holo_light = 2131230783;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131230784;
    
    public static final int abc_popup_background_mtrl_mult = 2131230785;
    
    public static final int abc_ratingbar_indicator_material = 2131230786;
    
    public static final int abc_ratingbar_material = 2131230787;
    
    public static final int abc_ratingbar_small_material = 2131230788;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131230789;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131230790;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131230791;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131230792;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131230793;
    
    public static final int abc_seekbar_thumb_material = 2131230794;
    
    public static final int abc_seekbar_tick_mark_material = 2131230795;
    
    public static final int abc_seekbar_track_material = 2131230796;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131230797;
    
    public static final int abc_spinner_textfield_background_material = 2131230798;
    
    public static final int abc_switch_thumb_material = 2131230799;
    
    public static final int abc_switch_track_mtrl_alpha = 2131230800;
    
    public static final int abc_tab_indicator_material = 2131230801;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131230802;
    
    public static final int abc_text_cursor_material = 2131230803;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131230804;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131230805;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131230806;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131230807;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131230808;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131230809;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131230810;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131230811;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131230812;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131230813;
    
    public static final int abc_textfield_search_material = 2131230814;
    
    public static final int abc_vector_test = 2131230815;
    
    public static final int al_exo_controls_fastforward = 2131230818;
    
    public static final int al_exo_controls_fullscreen_enter = 2131230819;
    
    public static final int al_exo_controls_fullscreen_exit = 2131230820;
    
    public static final int al_exo_controls_next = 2131230821;
    
    public static final int al_exo_controls_pause = 2131230822;
    
    public static final int al_exo_controls_play = 2131230823;
    
    public static final int al_exo_controls_previous = 2131230824;
    
    public static final int al_exo_controls_repeat_all = 2131230825;
    
    public static final int al_exo_controls_repeat_off = 2131230826;
    
    public static final int al_exo_controls_repeat_one = 2131230827;
    
    public static final int al_exo_controls_rewind = 2131230828;
    
    public static final int al_exo_controls_shuffle_off = 2131230829;
    
    public static final int al_exo_controls_shuffle_on = 2131230830;
    
    public static final int al_exo_controls_vr = 2131230831;
    
    public static final int al_exo_notification_fastforward = 2131230832;
    
    public static final int al_exo_notification_next = 2131230833;
    
    public static final int al_exo_notification_pause = 2131230834;
    
    public static final int al_exo_notification_play = 2131230835;
    
    public static final int al_exo_notification_previous = 2131230836;
    
    public static final int al_exo_notification_rewind = 2131230837;
    
    public static final int al_exo_notification_small_icon = 2131230838;
    
    public static final int al_exo_notification_stop = 2131230839;
    
    public static final int al_exo_styled_controls_audiotrack = 2131230840;
    
    public static final int al_exo_styled_controls_check = 2131230841;
    
    public static final int al_exo_styled_controls_fastforward = 2131230842;
    
    public static final int al_exo_styled_controls_fullscreen_enter = 2131230843;
    
    public static final int al_exo_styled_controls_fullscreen_exit = 2131230844;
    
    public static final int al_exo_styled_controls_next = 2131230845;
    
    public static final int al_exo_styled_controls_overflow_hide = 2131230846;
    
    public static final int al_exo_styled_controls_overflow_show = 2131230847;
    
    public static final int al_exo_styled_controls_pause = 2131230848;
    
    public static final int al_exo_styled_controls_play = 2131230849;
    
    public static final int al_exo_styled_controls_previous = 2131230850;
    
    public static final int al_exo_styled_controls_repeat_all = 2131230851;
    
    public static final int al_exo_styled_controls_repeat_off = 2131230852;
    
    public static final int al_exo_styled_controls_repeat_one = 2131230853;
    
    public static final int al_exo_styled_controls_rewind = 2131230854;
    
    public static final int al_exo_styled_controls_settings = 2131230855;
    
    public static final int al_exo_styled_controls_shuffle_off = 2131230856;
    
    public static final int al_exo_styled_controls_shuffle_on = 2131230857;
    
    public static final int al_exo_styled_controls_speed = 2131230858;
    
    public static final int al_exo_styled_controls_subtitle_off = 2131230859;
    
    public static final int al_exo_styled_controls_subtitle_on = 2131230860;
    
    public static final int al_exo_styled_controls_vr = 2131230861;
    
    public static final int applovin_creative_debugger_report_ad_rounded_button = 2131230862;
    
    public static final int applovin_exo_edit_mode_logo = 2131230863;
    
    public static final int applovin_exo_ic_audiotrack = 2131230864;
    
    public static final int applovin_exo_ic_check = 2131230865;
    
    public static final int applovin_exo_ic_chevron_left = 2131230866;
    
    public static final int applovin_exo_ic_chevron_right = 2131230867;
    
    public static final int applovin_exo_ic_default_album_image = 2131230868;
    
    public static final int applovin_exo_ic_forward = 2131230869;
    
    public static final int applovin_exo_ic_fullscreen_enter = 2131230870;
    
    public static final int applovin_exo_ic_fullscreen_exit = 2131230871;
    
    public static final int applovin_exo_ic_pause_circle_filled = 2131230872;
    
    public static final int applovin_exo_ic_play_circle_filled = 2131230873;
    
    public static final int applovin_exo_ic_rewind = 2131230874;
    
    public static final int applovin_exo_ic_settings = 2131230875;
    
    public static final int applovin_exo_ic_skip_next = 2131230876;
    
    public static final int applovin_exo_ic_skip_previous = 2131230877;
    
    public static final int applovin_exo_ic_speed = 2131230878;
    
    public static final int applovin_exo_ic_subtitle_off = 2131230879;
    
    public static final int applovin_exo_ic_subtitle_on = 2131230880;
    
    public static final int applovin_exo_icon_circular_play = 2131230881;
    
    public static final int applovin_exo_icon_fastforward = 2131230882;
    
    public static final int applovin_exo_icon_fullscreen_enter = 2131230883;
    
    public static final int applovin_exo_icon_fullscreen_exit = 2131230884;
    
    public static final int applovin_exo_icon_next = 2131230885;
    
    public static final int applovin_exo_icon_pause = 2131230886;
    
    public static final int applovin_exo_icon_play = 2131230887;
    
    public static final int applovin_exo_icon_previous = 2131230888;
    
    public static final int applovin_exo_icon_repeat_all = 2131230889;
    
    public static final int applovin_exo_icon_repeat_off = 2131230890;
    
    public static final int applovin_exo_icon_repeat_one = 2131230891;
    
    public static final int applovin_exo_icon_rewind = 2131230892;
    
    public static final int applovin_exo_icon_shuffle_off = 2131230893;
    
    public static final int applovin_exo_icon_shuffle_on = 2131230894;
    
    public static final int applovin_exo_icon_stop = 2131230895;
    
    public static final int applovin_exo_icon_vr = 2131230896;
    
    public static final int applovin_exo_rounded_rectangle = 2131230897;
    
    public static final int applovin_ic_check_mark_bordered = 2131230898;
    
    public static final int applovin_ic_check_mark_borderless = 2131230899;
    
    public static final int applovin_ic_disclosure_arrow = 2131230900;
    
    public static final int applovin_ic_mediation_adcolony = 2131230901;
    
    public static final int applovin_ic_mediation_admob = 2131230902;
    
    public static final int applovin_ic_mediation_amazon_marketplace = 2131230903;
    
    public static final int applovin_ic_mediation_amazon_tam = 2131230904;
    
    public static final int applovin_ic_mediation_applovin = 2131230905;
    
    public static final int applovin_ic_mediation_bidmachine = 2131230906;
    
    public static final int applovin_ic_mediation_chartboost = 2131230907;
    
    public static final int applovin_ic_mediation_criteo = 2131230908;
    
    public static final int applovin_ic_mediation_facebook = 2131230909;
    
    public static final int applovin_ic_mediation_fyber = 2131230910;
    
    public static final int applovin_ic_mediation_google_ad_manager = 2131230911;
    
    public static final int applovin_ic_mediation_hyprmx = 2131230912;
    
    public static final int applovin_ic_mediation_inmobi = 2131230913;
    
    public static final int applovin_ic_mediation_ironsource = 2131230914;
    
    public static final int applovin_ic_mediation_line = 2131230915;
    
    public static final int applovin_ic_mediation_maio = 2131230916;
    
    public static final int applovin_ic_mediation_mintegral = 2131230917;
    
    public static final int applovin_ic_mediation_mobilefuse = 2131230918;
    
    public static final int applovin_ic_mediation_mopub = 2131230919;
    
    public static final int applovin_ic_mediation_mytarget = 2131230920;
    
    public static final int applovin_ic_mediation_nend = 2131230921;
    
    public static final int applovin_ic_mediation_ogury_presage = 2131230922;
    
    public static final int applovin_ic_mediation_pangle = 2131230923;
    
    public static final int applovin_ic_mediation_placeholder = 2131230924;
    
    public static final int applovin_ic_mediation_smaato = 2131230925;
    
    public static final int applovin_ic_mediation_snap = 2131230926;
    
    public static final int applovin_ic_mediation_tapjoy = 2131230927;
    
    public static final int applovin_ic_mediation_tiktok = 2131230928;
    
    public static final int applovin_ic_mediation_unity = 2131230929;
    
    public static final int applovin_ic_mediation_verizon = 2131230930;
    
    public static final int applovin_ic_mediation_verve = 2131230931;
    
    public static final int applovin_ic_mediation_vungle = 2131230932;
    
    public static final int applovin_ic_mediation_yandex = 2131230933;
    
    public static final int applovin_ic_mute_to_unmute = 2131230934;
    
    public static final int applovin_ic_privacy_icon = 2131230935;
    
    public static final int applovin_ic_privacy_icon_layered_list = 2131230936;
    
    public static final int applovin_ic_share = 2131230937;
    
    public static final int applovin_ic_unmute_to_mute = 2131230938;
    
    public static final int applovin_ic_warning = 2131230939;
    
    public static final int applovin_ic_white_small = 2131230940;
    
    public static final int applovin_ic_x_mark = 2131230941;
    
    public static final int applovin_rounded_button = 2131230942;
    
    public static final int applovin_rounded_text_view_border = 2131230943;
    
    public static final int btn_checkbox_checked_mtrl = 2131230949;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131230950;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131230951;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131230952;
    
    public static final int btn_radio_off_mtrl = 2131230955;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131230956;
    
    public static final int btn_radio_on_mtrl = 2131230957;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131230958;
    
    public static final int circular_shape = 2131230961;
    
    public static final int common_full_open_on_phone = 2131230982;
    
    public static final int common_google_signin_btn_icon_dark = 2131230983;
    
    public static final int common_google_signin_btn_icon_dark_focused = 2131230984;
    
    public static final int common_google_signin_btn_icon_dark_normal = 2131230985;
    
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131230986;
    
    public static final int common_google_signin_btn_icon_disabled = 2131230987;
    
    public static final int common_google_signin_btn_icon_light = 2131230988;
    
    public static final int common_google_signin_btn_icon_light_focused = 2131230989;
    
    public static final int common_google_signin_btn_icon_light_normal = 2131230990;
    
    public static final int common_google_signin_btn_icon_light_normal_background = 2131230991;
    
    public static final int common_google_signin_btn_text_dark = 2131230992;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131230993;
    
    public static final int common_google_signin_btn_text_dark_normal = 2131230994;
    
    public static final int common_google_signin_btn_text_dark_normal_background = 2131230995;
    
    public static final int common_google_signin_btn_text_disabled = 2131230996;
    
    public static final int common_google_signin_btn_text_light = 2131230997;
    
    public static final int common_google_signin_btn_text_light_focused = 2131230998;
    
    public static final int common_google_signin_btn_text_light_normal = 2131230999;
    
    public static final int common_google_signin_btn_text_light_normal_background = 2131231000;
    
    public static final int googleg_disabled_color_18 = 2131231005;
    
    public static final int googleg_standard_color_18 = 2131231006;
    
    public static final int mraid_close = 2131231179;
    
    public static final int notification_action_background = 2131231180;
    
    public static final int notification_bg = 2131231181;
    
    public static final int notification_bg_low = 2131231182;
    
    public static final int notification_bg_low_normal = 2131231183;
    
    public static final int notification_bg_low_pressed = 2131231184;
    
    public static final int notification_bg_normal = 2131231185;
    
    public static final int notification_bg_normal_pressed = 2131231186;
    
    public static final int notification_icon_background = 2131231187;
    
    public static final int notification_template_icon_bg = 2131231188;
    
    public static final int notification_template_icon_low_bg = 2131231189;
    
    public static final int notification_tile_bg = 2131231190;
    
    public static final int notify_panel_notification_icon_bg = 2131231191;
    
    public static final int tooltip_frame_dark = 2131231220;
    
    public static final int tooltip_frame_light = 2131231221;
  }
  
  public static final class font {
    public static final int roboto_medium_numbers = 2131296256;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131361814;
    
    public static final int accessibility_custom_action_0 = 2131361815;
    
    public static final int accessibility_custom_action_1 = 2131361816;
    
    public static final int accessibility_custom_action_10 = 2131361817;
    
    public static final int accessibility_custom_action_11 = 2131361818;
    
    public static final int accessibility_custom_action_12 = 2131361819;
    
    public static final int accessibility_custom_action_13 = 2131361820;
    
    public static final int accessibility_custom_action_14 = 2131361821;
    
    public static final int accessibility_custom_action_15 = 2131361822;
    
    public static final int accessibility_custom_action_16 = 2131361823;
    
    public static final int accessibility_custom_action_17 = 2131361824;
    
    public static final int accessibility_custom_action_18 = 2131361825;
    
    public static final int accessibility_custom_action_19 = 2131361826;
    
    public static final int accessibility_custom_action_2 = 2131361827;
    
    public static final int accessibility_custom_action_20 = 2131361828;
    
    public static final int accessibility_custom_action_21 = 2131361829;
    
    public static final int accessibility_custom_action_22 = 2131361830;
    
    public static final int accessibility_custom_action_23 = 2131361831;
    
    public static final int accessibility_custom_action_24 = 2131361832;
    
    public static final int accessibility_custom_action_25 = 2131361833;
    
    public static final int accessibility_custom_action_26 = 2131361834;
    
    public static final int accessibility_custom_action_27 = 2131361835;
    
    public static final int accessibility_custom_action_28 = 2131361836;
    
    public static final int accessibility_custom_action_29 = 2131361837;
    
    public static final int accessibility_custom_action_3 = 2131361838;
    
    public static final int accessibility_custom_action_30 = 2131361839;
    
    public static final int accessibility_custom_action_31 = 2131361840;
    
    public static final int accessibility_custom_action_4 = 2131361841;
    
    public static final int accessibility_custom_action_5 = 2131361842;
    
    public static final int accessibility_custom_action_6 = 2131361843;
    
    public static final int accessibility_custom_action_7 = 2131361844;
    
    public static final int accessibility_custom_action_8 = 2131361845;
    
    public static final int accessibility_custom_action_9 = 2131361846;
    
    public static final int action_bar = 2131361851;
    
    public static final int action_bar_activity_content = 2131361852;
    
    public static final int action_bar_container = 2131361853;
    
    public static final int action_bar_root = 2131361854;
    
    public static final int action_bar_spinner = 2131361855;
    
    public static final int action_bar_subtitle = 2131361856;
    
    public static final int action_bar_title = 2131361857;
    
    public static final int action_container = 2131361858;
    
    public static final int action_context_bar = 2131361859;
    
    public static final int action_divider = 2131361860;
    
    public static final int action_image = 2131361861;
    
    public static final int action_menu_divider = 2131361862;
    
    public static final int action_menu_presenter = 2131361863;
    
    public static final int action_mode_bar = 2131361864;
    
    public static final int action_mode_bar_stub = 2131361865;
    
    public static final int action_mode_close_button = 2131361866;
    
    public static final int action_share = 2131361867;
    
    public static final int action_text = 2131361868;
    
    public static final int actions = 2131361869;
    
    public static final int activity_chooser_view_content = 2131361870;
    
    public static final int ad_control_button = 2131361871;
    
    public static final int ad_controls_view = 2131361872;
    
    public static final int ad_presenter_view = 2131361873;
    
    public static final int ad_view_container = 2131361874;
    
    public static final int add = 2131361875;
    
    public static final int adjust_height = 2131361876;
    
    public static final int adjust_width = 2131361877;
    
    public static final int al_exo_ad_overlay = 2131361878;
    
    public static final int al_exo_artwork = 2131361879;
    
    public static final int al_exo_audio_track = 2131361880;
    
    public static final int al_exo_basic_controls = 2131361881;
    
    public static final int al_exo_bottom_bar = 2131361882;
    
    public static final int al_exo_buffering = 2131361883;
    
    public static final int al_exo_center_controls = 2131361884;
    
    public static final int al_exo_content_frame = 2131361885;
    
    public static final int al_exo_controller = 2131361886;
    
    public static final int al_exo_controller_placeholder = 2131361887;
    
    public static final int al_exo_controls_background = 2131361888;
    
    public static final int al_exo_duration = 2131361889;
    
    public static final int al_exo_error_message = 2131361890;
    
    public static final int al_exo_extra_controls = 2131361891;
    
    public static final int al_exo_extra_controls_scroll_view = 2131361892;
    
    public static final int al_exo_ffwd = 2131361893;
    
    public static final int al_exo_ffwd_with_amount = 2131361894;
    
    public static final int al_exo_fullscreen = 2131361895;
    
    public static final int al_exo_minimal_controls = 2131361896;
    
    public static final int al_exo_minimal_fullscreen = 2131361897;
    
    public static final int al_exo_next = 2131361898;
    
    public static final int al_exo_overflow_hide = 2131361899;
    
    public static final int al_exo_overflow_show = 2131361900;
    
    public static final int al_exo_overlay = 2131361901;
    
    public static final int al_exo_pause = 2131361902;
    
    public static final int al_exo_play = 2131361903;
    
    public static final int al_exo_play_pause = 2131361904;
    
    public static final int al_exo_playback_speed = 2131361905;
    
    public static final int al_exo_position = 2131361906;
    
    public static final int al_exo_prev = 2131361907;
    
    public static final int al_exo_progress = 2131361908;
    
    public static final int al_exo_progress_placeholder = 2131361909;
    
    public static final int al_exo_repeat_toggle = 2131361910;
    
    public static final int al_exo_rew = 2131361911;
    
    public static final int al_exo_rew_with_amount = 2131361912;
    
    public static final int al_exo_settings = 2131361913;
    
    public static final int al_exo_shuffle = 2131361914;
    
    public static final int al_exo_shutter = 2131361915;
    
    public static final int al_exo_subtitle = 2131361916;
    
    public static final int al_exo_subtitles = 2131361917;
    
    public static final int al_exo_time = 2131361918;
    
    public static final int al_exo_vr = 2131361919;
    
    public static final int alertTitle = 2131361920;
    
    public static final int always = 2131361924;
    
    public static final int app_open_ad_control_button = 2131361929;
    
    public static final int app_open_ad_control_view = 2131361930;
    
    public static final int applovin_native_ad_content_linear_layout = 2131361931;
    
    public static final int applovin_native_ad_view_container = 2131361932;
    
    public static final int applovin_native_advertiser_text_view = 2131361933;
    
    public static final int applovin_native_badge_text_view = 2131361934;
    
    public static final int applovin_native_body_text_view = 2131361935;
    
    public static final int applovin_native_cta_button = 2131361936;
    
    public static final int applovin_native_guideline = 2131361937;
    
    public static final int applovin_native_icon_and_text_layout = 2131361938;
    
    public static final int applovin_native_icon_image_view = 2131361939;
    
    public static final int applovin_native_icon_view = 2131361940;
    
    public static final int applovin_native_inner_linear_layout = 2131361941;
    
    public static final int applovin_native_inner_parent_layout = 2131361942;
    
    public static final int applovin_native_leader_icon_and_text_layout = 2131361943;
    
    public static final int applovin_native_media_content_view = 2131361944;
    
    public static final int applovin_native_options_view = 2131361945;
    
    public static final int applovin_native_title_text_view = 2131361946;
    
    public static final int async = 2131361948;
    
    public static final int auto = 2131361949;
    
    public static final int banner_ad_view_container = 2131361954;
    
    public static final int banner_control_button = 2131361957;
    
    public static final int banner_control_view = 2131361958;
    
    public static final int banner_label = 2131361960;
    
    public static final int blocking = 2131361968;
    
    public static final int bottom = 2131361970;
    
    public static final int browser_actions_header_text = 2131361976;
    
    public static final int browser_actions_menu_item_icon = 2131361977;
    
    public static final int browser_actions_menu_item_text = 2131361978;
    
    public static final int browser_actions_menu_items = 2131361979;
    
    public static final int browser_actions_menu_view = 2131361980;
    
    public static final int buttonPanel = 2131361989;
    
    public static final int center = 2131361996;
    
    public static final int checkbox = 2131362001;
    
    public static final int checked = 2131362002;
    
    public static final int chronometer = 2131362003;
    
    public static final int content = 2131362027;
    
    public static final int contentPanel = 2131362028;
    
    public static final int custom = 2131362033;
    
    public static final int customPanel = 2131362034;
    
    public static final int dark = 2131362035;
    
    public static final int decor_content_parent = 2131362038;
    
    public static final int default_activity_button = 2131362039;
    
    public static final int detailImageView = 2131362042;
    
    public static final int dialog_button = 2131362043;
    
    public static final int edit_query = 2131362063;
    
    public static final int email_report_tv = 2131362064;
    
    public static final int end = 2131362065;
    
    public static final int exo_check = 2131362067;
    
    public static final int exo_icon = 2131362068;
    
    public static final int exo_main_text = 2131362069;
    
    public static final int exo_settings_listview = 2131362070;
    
    public static final int exo_sub_text = 2131362071;
    
    public static final int exo_text = 2131362072;
    
    public static final int exo_track_selection_view = 2131362073;
    
    public static final int expand_activities_button = 2131362074;
    
    public static final int expanded_menu = 2131362075;
    
    public static final int fill = 2131362076;
    
    public static final int fit = 2131362079;
    
    public static final int fixed_height = 2131362080;
    
    public static final int fixed_width = 2131362081;
    
    public static final int forever = 2131362083;
    
    public static final int group_divider = 2131362093;
    
    public static final int home = 2131362098;
    
    public static final int icon = 2131362189;
    
    public static final int icon_group = 2131362190;
    
    public static final int icon_only = 2131362191;
    
    public static final int image = 2131362195;
    
    public static final int imageView = 2131362196;
    
    public static final int image_view = 2131362200;
    
    public static final int info = 2131362203;
    
    public static final int inter_container = 2131362216;
    
    public static final int interstitial_control_button = 2131362218;
    
    public static final int interstitial_control_view = 2131362219;
    
    public static final int italic = 2131362221;
    
    public static final int item_touch_helper_previous_elevation = 2131362223;
    
    public static final int left = 2131362229;
    
    public static final int light = 2131362231;
    
    public static final int line1 = 2131362232;
    
    public static final int line3 = 2131362233;
    
    public static final int listMode = 2131362235;
    
    public static final int listView = 2131362236;
    
    public static final int list_item = 2131362237;
    
    public static final int message = 2131362400;
    
    public static final int mraid_close_indicator = 2131362407;
    
    public static final int mrec_ad_view_container = 2131362409;
    
    public static final int mrec_control_button = 2131362410;
    
    public static final int mrec_control_view = 2131362411;
    
    public static final int multiply = 2131362412;
    
    public static final int native_ad_view_container = 2131362413;
    
    public static final int native_control_button = 2131362414;
    
    public static final int native_control_view = 2131362415;
    
    public static final int never = 2131362416;
    
    public static final int none = 2131362421;
    
    public static final int normal = 2131362422;
    
    public static final int notification_background = 2131362424;
    
    public static final int notification_main_column = 2131362425;
    
    public static final int notification_main_column_container = 2131362426;
    
    public static final int off = 2131362427;
    
    public static final int on = 2131362429;
    
    public static final int parentPanel = 2131362439;
    
    public static final int progress_circular = 2131362449;
    
    public static final int progress_horizontal = 2131362450;
    
    public static final int radio = 2131362451;
    
    public static final int report_ad_button = 2131362456;
    
    public static final int rewarded_control_button = 2131362458;
    
    public static final int rewarded_control_view = 2131362459;
    
    public static final int rewarded_interstitial_control_button = 2131362460;
    
    public static final int rewarded_interstitial_control_view = 2131362461;
    
    public static final int right = 2131362462;
    
    public static final int right_icon = 2131362463;
    
    public static final int right_side = 2131362464;
    
    public static final int screen = 2131362466;
    
    public static final int scrollIndicatorDown = 2131362467;
    
    public static final int scrollIndicatorUp = 2131362468;
    
    public static final int scrollView = 2131362469;
    
    public static final int search_badge = 2131362470;
    
    public static final int search_bar = 2131362471;
    
    public static final int search_button = 2131362472;
    
    public static final int search_close_btn = 2131362473;
    
    public static final int search_edit_frame = 2131362474;
    
    public static final int search_go_btn = 2131362475;
    
    public static final int search_mag_icon = 2131362476;
    
    public static final int search_plate = 2131362477;
    
    public static final int search_src_text = 2131362478;
    
    public static final int search_voice_btn = 2131362479;
    
    public static final int select_dialog_listview = 2131362481;
    
    public static final int shortcut = 2131362484;
    
    public static final int show_mrec_button = 2131362488;
    
    public static final int show_native_button = 2131362489;
    
    public static final int spacer = 2131362514;
    
    public static final int spherical_gl_surface_view = 2131362516;
    
    public static final int split_action_bar = 2131362518;
    
    public static final int src_atop = 2131362523;
    
    public static final int src_in = 2131362524;
    
    public static final int src_over = 2131362525;
    
    public static final int standard = 2131362526;
    
    public static final int start = 2131362527;
    
    public static final int status_textview = 2131362533;
    
    public static final int submenuarrow = 2131362535;
    
    public static final int submit_area = 2131362536;
    
    public static final int surface_view = 2131362538;
    
    public static final int tabMode = 2131362539;
    
    public static final int tag_accessibility_actions = 2131362541;
    
    public static final int tag_accessibility_clickable_spans = 2131362542;
    
    public static final int tag_accessibility_heading = 2131362543;
    
    public static final int tag_accessibility_pane_title = 2131362544;
    
    public static final int tag_screen_reader_focusable = 2131362548;
    
    public static final int tag_transition_group = 2131362550;
    
    public static final int tag_unhandled_key_event_manager = 2131362551;
    
    public static final int tag_unhandled_key_listeners = 2131362552;
    
    public static final int text = 2131362554;
    
    public static final int text2 = 2131362555;
    
    public static final int textSpacerNoButtons = 2131362556;
    
    public static final int textSpacerNoTitle = 2131362557;
    
    public static final int texture_view = 2131362558;
    
    public static final int time = 2131362559;
    
    public static final int title = 2131362560;
    
    public static final int titleDividerNoCustom = 2131362561;
    
    public static final int title_template = 2131362562;
    
    public static final int top = 2131362564;
    
    public static final int topPanel = 2131362565;
    
    public static final int unchecked = 2131362855;
    
    public static final int uniform = 2131362856;
    
    public static final int up = 2131362858;
    
    public static final int video_decoder_gl_surface_view = 2131362861;
    
    public static final int when_playing = 2131362878;
    
    public static final int wide = 2131362879;
    
    public static final int wrap_content = 2131362882;
    
    public static final int zoom = 2131362886;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131427328;
    
    public static final int abc_config_activityShortDur = 2131427329;
    
    public static final int al_exo_media_button_opacity_percentage_disabled = 2131427330;
    
    public static final int al_exo_media_button_opacity_percentage_enabled = 2131427331;
    
    public static final int cancel_button_image_alpha = 2131427333;
    
    public static final int config_tooltipAnimTime = 2131427338;
    
    public static final int google_play_services_version = 2131427341;
    
    public static final int status_bar_notification_info_maxnum = 2131427346;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131492864;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131492865;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131492866;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131492867;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131492868;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131492869;
    
    public static final int fast_out_slow_in = 2131492870;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131558400;
    
    public static final int abc_action_bar_up_container = 2131558401;
    
    public static final int abc_action_menu_item_layout = 2131558402;
    
    public static final int abc_action_menu_layout = 2131558403;
    
    public static final int abc_action_mode_bar = 2131558404;
    
    public static final int abc_action_mode_close_item_material = 2131558405;
    
    public static final int abc_activity_chooser_view = 2131558406;
    
    public static final int abc_activity_chooser_view_list_item = 2131558407;
    
    public static final int abc_alert_dialog_button_bar_material = 2131558408;
    
    public static final int abc_alert_dialog_material = 2131558409;
    
    public static final int abc_alert_dialog_title_material = 2131558410;
    
    public static final int abc_cascading_menu_item_layout = 2131558411;
    
    public static final int abc_dialog_title_material = 2131558412;
    
    public static final int abc_expanded_menu_layout = 2131558413;
    
    public static final int abc_list_menu_item_checkbox = 2131558414;
    
    public static final int abc_list_menu_item_icon = 2131558415;
    
    public static final int abc_list_menu_item_layout = 2131558416;
    
    public static final int abc_list_menu_item_radio = 2131558417;
    
    public static final int abc_popup_menu_header_item_layout = 2131558418;
    
    public static final int abc_popup_menu_item_layout = 2131558419;
    
    public static final int abc_screen_content_include = 2131558420;
    
    public static final int abc_screen_simple = 2131558421;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131558422;
    
    public static final int abc_screen_toolbar = 2131558423;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131558424;
    
    public static final int abc_search_view = 2131558425;
    
    public static final int abc_select_dialog_material = 2131558426;
    
    public static final int abc_tooltip = 2131558427;
    
    public static final int applovin_debugger_list_item_detail = 2131558430;
    
    public static final int applovin_exo_list_divider = 2131558431;
    
    public static final int applovin_exo_player_control_view = 2131558432;
    
    public static final int applovin_exo_player_view = 2131558433;
    
    public static final int applovin_exo_styled_player_control_ffwd_button = 2131558434;
    
    public static final int applovin_exo_styled_player_control_rewind_button = 2131558435;
    
    public static final int applovin_exo_styled_player_control_view = 2131558436;
    
    public static final int applovin_exo_styled_player_view = 2131558437;
    
    public static final int applovin_exo_styled_settings_list = 2131558438;
    
    public static final int applovin_exo_styled_settings_list_item = 2131558439;
    
    public static final int applovin_exo_styled_sub_settings_list_item = 2131558440;
    
    public static final int applovin_exo_track_selection_dialog = 2131558441;
    
    public static final int applovin_native_ad_media_view = 2131558442;
    
    public static final int browser_actions_context_menu_page = 2131558444;
    
    public static final int browser_actions_context_menu_row = 2131558445;
    
    public static final int creative_debugger_displayed_ad_detail_activity = 2131558454;
    
    public static final int custom_dialog = 2131558455;
    
    public static final int max_hybrid_native_ad_view = 2131558482;
    
    public static final int max_native_ad_banner_icon_and_text_layout = 2131558483;
    
    public static final int max_native_ad_banner_view = 2131558484;
    
    public static final int max_native_ad_leader_view = 2131558485;
    
    public static final int max_native_ad_media_banner_view = 2131558486;
    
    public static final int max_native_ad_medium_template_1 = 2131558487;
    
    public static final int max_native_ad_mrec_view = 2131558488;
    
    public static final int max_native_ad_recycler_view_item = 2131558489;
    
    public static final int max_native_ad_small_template_1 = 2131558490;
    
    public static final int max_native_ad_vertical_banner_view = 2131558491;
    
    public static final int max_native_ad_vertical_leader_view = 2131558492;
    
    public static final int max_native_ad_vertical_media_banner_view = 2131558493;
    
    public static final int mdtb_interstitial_ad = 2131558531;
    
    public static final int mediation_debugger_ad_unit_detail_activity = 2131558532;
    
    public static final int mediation_debugger_list_item_right_detail = 2131558533;
    
    public static final int mediation_debugger_list_section = 2131558534;
    
    public static final int mediation_debugger_list_section_centered = 2131558535;
    
    public static final int mediation_debugger_list_view = 2131558536;
    
    public static final int mediation_debugger_multi_ad_activity = 2131558537;
    
    public static final int notification_action = 2131558540;
    
    public static final int notification_action_tombstone = 2131558541;
    
    public static final int notification_template_custom_big = 2131558548;
    
    public static final int notification_template_icon_group = 2131558549;
    
    public static final int notification_template_part_chronometer = 2131558553;
    
    public static final int notification_template_part_time = 2131558554;
    
    public static final int select_dialog_item_material = 2131558555;
    
    public static final int select_dialog_multichoice_material = 2131558556;
    
    public static final int select_dialog_singlechoice_material = 2131558557;
    
    public static final int support_simple_spinner_dropdown_item = 2131558566;
  }
  
  public static final class menu {
    public static final int creative_debugger_displayed_ad_activity_menu = 2131623936;
    
    public static final int mediation_debugger_activity_menu = 2131623937;
  }
  
  public static final class plurals {
    public static final int al_exo_controls_fastforward_by_amount_description = 2131755008;
    
    public static final int al_exo_controls_rewind_by_amount_description = 2131755009;
  }
  
  public static final class raw {
    public static final int omsdk_v_1_0 = 2131820546;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131886080;
    
    public static final int abc_action_bar_up_description = 2131886081;
    
    public static final int abc_action_menu_overflow_description = 2131886082;
    
    public static final int abc_action_mode_done = 2131886083;
    
    public static final int abc_activity_chooser_view_see_all = 2131886084;
    
    public static final int abc_activitychooserview_choose_application = 2131886085;
    
    public static final int abc_capital_off = 2131886086;
    
    public static final int abc_capital_on = 2131886087;
    
    public static final int abc_menu_alt_shortcut_label = 2131886088;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131886089;
    
    public static final int abc_menu_delete_shortcut_label = 2131886090;
    
    public static final int abc_menu_enter_shortcut_label = 2131886091;
    
    public static final int abc_menu_function_shortcut_label = 2131886092;
    
    public static final int abc_menu_meta_shortcut_label = 2131886093;
    
    public static final int abc_menu_shift_shortcut_label = 2131886094;
    
    public static final int abc_menu_space_shortcut_label = 2131886095;
    
    public static final int abc_menu_sym_shortcut_label = 2131886096;
    
    public static final int abc_prepend_shortcut_label = 2131886097;
    
    public static final int abc_search_hint = 2131886098;
    
    public static final int abc_searchview_description_clear = 2131886099;
    
    public static final int abc_searchview_description_query = 2131886100;
    
    public static final int abc_searchview_description_search = 2131886101;
    
    public static final int abc_searchview_description_submit = 2131886102;
    
    public static final int abc_searchview_description_voice = 2131886103;
    
    public static final int abc_shareactionprovider_share_with = 2131886104;
    
    public static final int abc_shareactionprovider_share_with_application = 2131886105;
    
    public static final int abc_toolbar_collapse_description = 2131886106;
    
    public static final int al_exo_controls_cc_disabled_description = 2131886109;
    
    public static final int al_exo_controls_cc_enabled_description = 2131886110;
    
    public static final int al_exo_controls_custom_playback_speed = 2131886111;
    
    public static final int al_exo_controls_fastforward_description = 2131886112;
    
    public static final int al_exo_controls_fullscreen_enter_description = 2131886113;
    
    public static final int al_exo_controls_fullscreen_exit_description = 2131886114;
    
    public static final int al_exo_controls_hide = 2131886115;
    
    public static final int al_exo_controls_next_description = 2131886116;
    
    public static final int al_exo_controls_overflow_hide_description = 2131886117;
    
    public static final int al_exo_controls_overflow_show_description = 2131886118;
    
    public static final int al_exo_controls_pause_description = 2131886119;
    
    public static final int al_exo_controls_play_description = 2131886120;
    
    public static final int al_exo_controls_playback_speed = 2131886121;
    
    public static final int al_exo_controls_playback_speed_normal = 2131886122;
    
    public static final int al_exo_controls_previous_description = 2131886123;
    
    public static final int al_exo_controls_repeat_all_description = 2131886124;
    
    public static final int al_exo_controls_repeat_off_description = 2131886125;
    
    public static final int al_exo_controls_repeat_one_description = 2131886126;
    
    public static final int al_exo_controls_rewind_description = 2131886127;
    
    public static final int al_exo_controls_seek_bar_description = 2131886128;
    
    public static final int al_exo_controls_settings_description = 2131886129;
    
    public static final int al_exo_controls_show = 2131886130;
    
    public static final int al_exo_controls_shuffle_off_description = 2131886131;
    
    public static final int al_exo_controls_shuffle_on_description = 2131886132;
    
    public static final int al_exo_controls_stop_description = 2131886133;
    
    public static final int al_exo_controls_time_placeholder = 2131886134;
    
    public static final int al_exo_controls_vr_description = 2131886135;
    
    public static final int al_exo_download_completed = 2131886136;
    
    public static final int al_exo_download_description = 2131886137;
    
    public static final int al_exo_download_downloading = 2131886138;
    
    public static final int al_exo_download_failed = 2131886139;
    
    public static final int al_exo_download_notification_channel_name = 2131886140;
    
    public static final int al_exo_download_paused = 2131886141;
    
    public static final int al_exo_download_paused_for_network = 2131886142;
    
    public static final int al_exo_download_paused_for_wifi = 2131886143;
    
    public static final int al_exo_download_removing = 2131886144;
    
    public static final int al_exo_item_list = 2131886145;
    
    public static final int al_exo_track_bitrate = 2131886146;
    
    public static final int al_exo_track_mono = 2131886147;
    
    public static final int al_exo_track_resolution = 2131886148;
    
    public static final int al_exo_track_role_alternate = 2131886149;
    
    public static final int al_exo_track_role_closed_captions = 2131886150;
    
    public static final int al_exo_track_role_commentary = 2131886151;
    
    public static final int al_exo_track_role_supplementary = 2131886152;
    
    public static final int al_exo_track_selection_auto = 2131886153;
    
    public static final int al_exo_track_selection_none = 2131886154;
    
    public static final int al_exo_track_selection_title_audio = 2131886155;
    
    public static final int al_exo_track_selection_title_text = 2131886156;
    
    public static final int al_exo_track_selection_title_video = 2131886157;
    
    public static final int al_exo_track_stereo = 2131886158;
    
    public static final int al_exo_track_surround = 2131886159;
    
    public static final int al_exo_track_surround_5_point_1 = 2131886160;
    
    public static final int al_exo_track_surround_7_point_1 = 2131886161;
    
    public static final int al_exo_track_unknown = 2131886162;
    
    public static final int app_name = 2131886165;
    
    public static final int applovin_creative_debugger_disabled_text = 2131886166;
    
    public static final int applovin_creative_debugger_no_ads_text = 2131886167;
    
    public static final int applovin_list_item_image_description = 2131886168;
    
    public static final int common_google_play_services_enable_button = 2131886199;
    
    public static final int common_google_play_services_enable_text = 2131886200;
    
    public static final int common_google_play_services_enable_title = 2131886201;
    
    public static final int common_google_play_services_install_button = 2131886202;
    
    public static final int common_google_play_services_install_text = 2131886203;
    
    public static final int common_google_play_services_install_title = 2131886204;
    
    public static final int common_google_play_services_notification_channel_name = 2131886205;
    
    public static final int common_google_play_services_notification_ticker = 2131886206;
    
    public static final int common_google_play_services_unknown_issue = 2131886207;
    
    public static final int common_google_play_services_unsupported_text = 2131886208;
    
    public static final int common_google_play_services_update_button = 2131886209;
    
    public static final int common_google_play_services_update_text = 2131886210;
    
    public static final int common_google_play_services_update_title = 2131886211;
    
    public static final int common_google_play_services_updating_text = 2131886212;
    
    public static final int common_google_play_services_wear_update_text = 2131886213;
    
    public static final int common_open_on_phone = 2131886214;
    
    public static final int common_signin_button_text = 2131886215;
    
    public static final int common_signin_button_text_long = 2131886216;
    
    public static final int copy_toast_msg = 2131886217;
    
    public static final int fallback_menu_item_copy_link = 2131886246;
    
    public static final int fallback_menu_item_open_in_browser = 2131886247;
    
    public static final int fallback_menu_item_share_link = 2131886248;
    
    public static final int search_menu_title = 2131886358;
    
    public static final int status_bar_notification_info_overflow = 2131886381;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131951616;
    
    public static final int AlertDialog_AppCompat_Light = 2131951617;
    
    public static final int Animation_AppCompat_Dialog = 2131951618;
    
    public static final int Animation_AppCompat_DropDownUp = 2131951619;
    
    public static final int Animation_AppCompat_Tooltip = 2131951620;
    
    public static final int AppLovinExoMediaButton = 2131951622;
    
    public static final int AppLovinExoMediaButton_FastForward = 2131951623;
    
    public static final int AppLovinExoMediaButton_Next = 2131951624;
    
    public static final int AppLovinExoMediaButton_Pause = 2131951625;
    
    public static final int AppLovinExoMediaButton_Play = 2131951626;
    
    public static final int AppLovinExoMediaButton_Previous = 2131951627;
    
    public static final int AppLovinExoMediaButton_Rewind = 2131951628;
    
    public static final int AppLovinExoMediaButton_VR = 2131951629;
    
    public static final int AppLovinExoStyledControls = 2131951630;
    
    public static final int AppLovinExoStyledControls_Button = 2131951631;
    
    public static final int AppLovinExoStyledControls_ButtonText = 2131951649;
    
    public static final int AppLovinExoStyledControls_Button_Bottom = 2131951632;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_AudioTrack = 2131951633;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_CC = 2131951634;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_FullScreen = 2131951635;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_OverflowHide = 2131951636;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_OverflowShow = 2131951637;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_PlaybackSpeed = 2131951638;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_RepeatToggle = 2131951639;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_Settings = 2131951640;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_Shuffle = 2131951641;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_VR = 2131951642;
    
    public static final int AppLovinExoStyledControls_Button_Center = 2131951643;
    
    public static final int AppLovinExoStyledControls_Button_Center_FfwdWithAmount = 2131951644;
    
    public static final int AppLovinExoStyledControls_Button_Center_Next = 2131951645;
    
    public static final int AppLovinExoStyledControls_Button_Center_PlayPause = 2131951646;
    
    public static final int AppLovinExoStyledControls_Button_Center_Previous = 2131951647;
    
    public static final int AppLovinExoStyledControls_Button_Center_RewWithAmount = 2131951648;
    
    public static final int AppLovinExoStyledControls_TimeBar = 2131951650;
    
    public static final int AppLovinExoStyledControls_TimeText = 2131951651;
    
    public static final int AppLovinExoStyledControls_TimeText_Duration = 2131951652;
    
    public static final int AppLovinExoStyledControls_TimeText_Position = 2131951653;
    
    public static final int AppLovinExoStyledControls_TimeText_Separator = 2131951654;
    
    public static final int Base_AlertDialog_AppCompat = 2131951656;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131951657;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131951658;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131951659;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131951660;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131951663;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131951662;
    
    public static final int Base_TextAppearance_AppCompat = 2131951664;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131951665;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131951666;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131951667;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131951668;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131951669;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131951670;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131951671;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131951672;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131951673;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131951674;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131951675;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131951676;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131951677;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131951678;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131951679;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131951680;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131951681;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131951682;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131951683;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131951684;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131951685;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131951686;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131951687;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131951688;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131951689;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131951690;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131951691;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131951692;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131951693;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131951694;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131951695;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131951696;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131951697;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131951698;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131951699;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131951700;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131951701;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131951702;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131951703;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131951704;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131951705;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131951706;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131951707;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131951708;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131951709;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131951710;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131951711;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131951726;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131951727;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131951728;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131951729;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131951730;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131951731;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131951732;
    
    public static final int Base_Theme_AppCompat = 2131951712;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131951713;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131951714;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131951718;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131951715;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131951716;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131951717;
    
    public static final int Base_Theme_AppCompat_Light = 2131951719;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131951720;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131951721;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131951725;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131951722;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131951723;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131951724;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131951737;
    
    public static final int Base_V21_Theme_AppCompat = 2131951733;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131951734;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131951735;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131951736;
    
    public static final int Base_V22_Theme_AppCompat = 2131951738;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131951739;
    
    public static final int Base_V23_Theme_AppCompat = 2131951740;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131951741;
    
    public static final int Base_V26_Theme_AppCompat = 2131951742;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131951743;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131951744;
    
    public static final int Base_V28_Theme_AppCompat = 2131951745;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131951746;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131951751;
    
    public static final int Base_V7_Theme_AppCompat = 2131951747;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131951748;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131951749;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131951750;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131951752;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131951753;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131951754;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131951755;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131951756;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131951757;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131951758;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131951759;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131951760;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131951761;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131951762;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131951763;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131951764;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131951765;
    
    public static final int Base_Widget_AppCompat_Button = 2131951766;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131951772;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131951773;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131951767;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131951768;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131951769;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131951770;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131951771;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131951774;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131951775;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131951776;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131951777;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131951778;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131951779;
    
    public static final int Base_Widget_AppCompat_EditText = 2131951780;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131951781;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131951782;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131951783;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131951784;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131951785;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131951786;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131951787;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131951788;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131951789;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131951790;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131951791;
    
    public static final int Base_Widget_AppCompat_ListView = 2131951792;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131951793;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131951794;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131951795;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131951796;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131951797;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131951798;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131951799;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131951800;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131951801;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131951802;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131951803;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131951804;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131951805;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131951806;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131951807;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131951808;
    
    public static final int Base_Widget_AppCompat_TextView = 2131951809;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131951810;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131951811;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131951812;
    
    public static final int LargeIconView = 2131951835;
    
    public static final int Platform_AppCompat = 2131951837;
    
    public static final int Platform_AppCompat_Light = 2131951838;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131951839;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131951840;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131951841;
    
    public static final int Platform_V21_AppCompat = 2131951842;
    
    public static final int Platform_V21_AppCompat_Light = 2131951843;
    
    public static final int Platform_V25_AppCompat = 2131951844;
    
    public static final int Platform_V25_AppCompat_Light = 2131951845;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131951846;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131951849;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131951850;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131951851;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131951852;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131951853;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131951854;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131951855;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131951856;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131951857;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131951863;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131951858;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131951859;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131951860;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131951861;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131951862;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131951864;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131951865;
    
    public static final int SmallIconView = 2131951867;
    
    public static final int TextAppearance_AppCompat = 2131951869;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131951870;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131951871;
    
    public static final int TextAppearance_AppCompat_Button = 2131951872;
    
    public static final int TextAppearance_AppCompat_Caption = 2131951873;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131951874;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131951875;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131951876;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131951877;
    
    public static final int TextAppearance_AppCompat_Headline = 2131951878;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131951879;
    
    public static final int TextAppearance_AppCompat_Large = 2131951880;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131951881;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131951882;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131951883;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131951884;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131951885;
    
    public static final int TextAppearance_AppCompat_Medium = 2131951886;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131951887;
    
    public static final int TextAppearance_AppCompat_Menu = 2131951888;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131951889;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131951890;
    
    public static final int TextAppearance_AppCompat_Small = 2131951891;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131951892;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131951893;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131951894;
    
    public static final int TextAppearance_AppCompat_Title = 2131951895;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131951896;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131951897;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131951898;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131951899;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131951900;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131951901;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131951902;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131951903;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131951904;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131951905;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131951906;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131951907;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131951908;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131951909;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131951910;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131951911;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131951912;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131951913;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131951914;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131951915;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131951916;
    
    public static final int TextAppearance_Compat_Notification = 2131951917;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131951918;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131951920;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131951923;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131951925;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131951927;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131951928;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131951929;
    
    public static final int ThemeOverlay_AppCompat = 2131951956;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131951957;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131951958;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131951959;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131951960;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131951961;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131951962;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131951963;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131951964;
    
    public static final int Theme_AppCompat = 2131951930;
    
    public static final int Theme_AppCompat_CompactMenu = 2131951931;
    
    public static final int Theme_AppCompat_DayNight = 2131951932;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131951933;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131951934;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131951937;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131951935;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131951936;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131951938;
    
    public static final int Theme_AppCompat_Dialog = 2131951939;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131951942;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131951940;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131951941;
    
    public static final int Theme_AppCompat_Light = 2131951944;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131951945;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131951946;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131951949;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131951947;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131951948;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131951950;
    
    public static final int Theme_AppCompat_NoActionBar = 2131951951;
    
    public static final int Theme_IAPTheme = 2131951954;
    
    public static final int Widget_AppCompat_ActionBar = 2131951965;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131951966;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131951967;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131951968;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131951969;
    
    public static final int Widget_AppCompat_ActionButton = 2131951970;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131951971;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131951972;
    
    public static final int Widget_AppCompat_ActionMode = 2131951973;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131951974;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131951975;
    
    public static final int Widget_AppCompat_Button = 2131951976;
    
    public static final int Widget_AppCompat_ButtonBar = 2131951982;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131951983;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131951977;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131951978;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131951979;
    
    public static final int Widget_AppCompat_Button_Colored = 2131951980;
    
    public static final int Widget_AppCompat_Button_Small = 2131951981;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131951984;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131951985;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131951986;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131951987;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131951988;
    
    public static final int Widget_AppCompat_EditText = 2131951989;
    
    public static final int Widget_AppCompat_ImageButton = 2131951990;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131951991;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131951992;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131951993;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131951994;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131951995;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131951996;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131951997;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131951998;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131951999;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131952000;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131952001;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131952002;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131952003;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131952004;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131952005;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131952006;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131952007;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131952008;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131952009;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131952010;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131952011;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131952012;
    
    public static final int Widget_AppCompat_ListMenuView = 2131952013;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131952014;
    
    public static final int Widget_AppCompat_ListView = 2131952015;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131952016;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131952017;
    
    public static final int Widget_AppCompat_PopupMenu = 2131952018;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131952019;
    
    public static final int Widget_AppCompat_PopupWindow = 2131952020;
    
    public static final int Widget_AppCompat_ProgressBar = 2131952021;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131952022;
    
    public static final int Widget_AppCompat_RatingBar = 2131952023;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131952024;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131952025;
    
    public static final int Widget_AppCompat_SearchView = 2131952026;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131952027;
    
    public static final int Widget_AppCompat_SeekBar = 2131952028;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131952029;
    
    public static final int Widget_AppCompat_Spinner = 2131952030;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131952031;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131952032;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131952033;
    
    public static final int Widget_AppCompat_TextView = 2131952034;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131952035;
    
    public static final int Widget_AppCompat_Toolbar = 2131952036;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131952037;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952038;
    
    public static final int Widget_Compat_NotificationActionText = 2131952039;
    
    public static final int Widget_Support_CoordinatorLayout = 2131952040;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar = 2131952041;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar_TitleTextStyle = 2131952042;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_Theme = 2131952043;
    
    public static final int com_applovin_creative_debugger_ui_DisplayedAdActivity_ReportAdButton = 2131952044;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar = 2131952045;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_Live = 2131952046;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_TitleTextStyle = 2131952047;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_Theme = 2131952048;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_Theme_Live = 2131952049;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AdBadgeTextView = 2131952050;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AutoScrollingTextView = 2131952051;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_CTAButton = 2131952052;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeAdBadgeTextView = 2131952053;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingBodyTextView = 2131952054;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingTitleTextView = 2131952055;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalBodyTextSize = 2131952056;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalTitleTextSize = 2131952057;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ScrollingTitleTextView = 2131952058;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallAdBadgeTextView = 2131952059;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingBodyTextView = 2131952060;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingTitleTextView = 2131952061;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalBodyTextSize = 2131952062;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalTitleTextSize = 2131952063;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_TitleTextStyle = 2131952064;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130968679, 2130968680, 2130968681, 2130968777, 2130968778, 2130968779, 2130968780, 2130968781, 2130968782, 2130968801, 
        2130968814, 2130968815, 2130968839, 2130968884, 2130968885, 2130968886, 2130968887, 2130968890, 2130968904, 2130968907, 
        2130968997, 2130969043, 2130969074, 2130969077, 2130969078, 2130969144, 2130969147, 2130969193, 2130969202 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130968679, 2130968680, 2130968739, 2130968884, 2130969147, 2130969202 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130968841, 2130968905 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AdsAttrs = new int[] { 2130968613, 2130968614, 2130968616 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130968701, 2130968702, 2130968985, 2130968986, 2130969040, 2130969117, 2130969118 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130969136, 2130969191, 2130969192 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130969188, 2130969189, 2130969190 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130968673, 2130968674, 2130968675, 2130968676, 2130968677, 2130968823, 2130968824, 2130968825, 2130968826, 
        2130968828, 2130968829, 2130968830, 2130968831, 2130968847, 2130968868, 2130968877, 2130968910, 2130968980, 2130969157, 
        2130969174 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 
        2130968587, 2130968588, 2130968589, 2130968590, 2130968591, 2130968593, 2130968594, 2130968595, 2130968596, 2130968597, 
        2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 
        2130968608, 2130968609, 2130968612, 2130968656, 2130968657, 2130968658, 2130968659, 2130968672, 2130968692, 2130968694, 
        2130968695, 2130968696, 2130968697, 2130968698, 2130968704, 2130968705, 2130968727, 2130968728, 2130968743, 2130968744, 
        2130968745, 2130968746, 2130968747, 2130968748, 2130968749, 2130968750, 2130968751, 2130968753, 2130968789, 2130968811, 
        2130968812, 2130968813, 2130968816, 2130968818, 2130968833, 2130968834, 2130968836, 2130968837, 2130968838, 2130968886, 
        2130968898, 2130968981, 2130968982, 2130968983, 2130968984, 2130968987, 2130968988, 2130968989, 2130968990, 2130968991, 
        2130968992, 2130968993, 2130968994, 2130968995, 2130969060, 2130969061, 2130969062, 2130969073, 2130969075, 2130969085, 
        2130969086, 2130969087, 2130969088, 2130969107, 2130969108, 2130969109, 2130969110, 2130969128, 2130969129, 2130969151, 
        2130969158, 2130969159, 2130969160, 2130969161, 2130969162, 2130969163, 2130969164, 2130969165, 2130969171, 2130969172, 
        2130969203, 2130969204, 2130969205, 2130969206, 2130969224, 2130969238, 2130969239, 2130969240, 2130969241, 2130969242, 
        2130969243, 2130969244, 2130969245, 2130969246, 2130969247 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] AppLovinAspectRatioFrameLayout = new int[] { 2130968634 };
    
    public static final int AppLovinAspectRatioFrameLayout_al_resize_mode = 0;
    
    public static final int[] AppLovinDefaultTimeBar = new int[] { 
        2130968617, 2130968618, 2130968622, 2130968623, 2130968624, 2130968630, 2130968631, 2130968635, 2130968636, 2130968637, 
        2130968638, 2130968639, 2130968652, 2130968653 };
    
    public static final int AppLovinDefaultTimeBar_al_ad_marker_color = 0;
    
    public static final int AppLovinDefaultTimeBar_al_ad_marker_width = 1;
    
    public static final int AppLovinDefaultTimeBar_al_bar_gravity = 2;
    
    public static final int AppLovinDefaultTimeBar_al_bar_height = 3;
    
    public static final int AppLovinDefaultTimeBar_al_buffered_color = 4;
    
    public static final int AppLovinDefaultTimeBar_al_played_ad_marker_color = 5;
    
    public static final int AppLovinDefaultTimeBar_al_played_color = 6;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_color = 7;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_disabled_size = 8;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_dragged_size = 9;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_drawable = 10;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_enabled_size = 11;
    
    public static final int AppLovinDefaultTimeBar_al_touch_target_height = 12;
    
    public static final int AppLovinDefaultTimeBar_al_unplayed_color = 13;
    
    public static final int[] AppLovinPlayerControlView = new int[] { 
        2130968617, 2130968618, 2130968622, 2130968623, 2130968624, 2130968625, 2130968630, 2130968631, 2130968633, 2130968635, 
        2130968636, 2130968637, 2130968638, 2130968639, 2130968641, 2130968642, 2130968643, 2130968644, 2130968645, 2130968647, 
        2130968651, 2130968652, 2130968653 };
    
    public static final int AppLovinPlayerControlView_al_ad_marker_color = 0;
    
    public static final int AppLovinPlayerControlView_al_ad_marker_width = 1;
    
    public static final int AppLovinPlayerControlView_al_bar_gravity = 2;
    
    public static final int AppLovinPlayerControlView_al_bar_height = 3;
    
    public static final int AppLovinPlayerControlView_al_buffered_color = 4;
    
    public static final int AppLovinPlayerControlView_al_controller_layout_id = 5;
    
    public static final int AppLovinPlayerControlView_al_played_ad_marker_color = 6;
    
    public static final int AppLovinPlayerControlView_al_played_color = 7;
    
    public static final int AppLovinPlayerControlView_al_repeat_toggle_modes = 8;
    
    public static final int AppLovinPlayerControlView_al_scrubber_color = 9;
    
    public static final int AppLovinPlayerControlView_al_scrubber_disabled_size = 10;
    
    public static final int AppLovinPlayerControlView_al_scrubber_dragged_size = 11;
    
    public static final int AppLovinPlayerControlView_al_scrubber_drawable = 12;
    
    public static final int AppLovinPlayerControlView_al_scrubber_enabled_size = 13;
    
    public static final int AppLovinPlayerControlView_al_show_fastforward_button = 14;
    
    public static final int AppLovinPlayerControlView_al_show_next_button = 15;
    
    public static final int AppLovinPlayerControlView_al_show_previous_button = 16;
    
    public static final int AppLovinPlayerControlView_al_show_rewind_button = 17;
    
    public static final int AppLovinPlayerControlView_al_show_shuffle_button = 18;
    
    public static final int AppLovinPlayerControlView_al_show_timeout = 19;
    
    public static final int AppLovinPlayerControlView_al_time_bar_min_update_interval = 20;
    
    public static final int AppLovinPlayerControlView_al_touch_target_height = 21;
    
    public static final int AppLovinPlayerControlView_al_unplayed_color = 22;
    
    public static final int[] AppLovinPlayerView = new int[] { 
        2130968617, 2130968618, 2130968620, 2130968623, 2130968624, 2130968625, 2130968626, 2130968627, 2130968628, 2130968629, 
        2130968630, 2130968631, 2130968632, 2130968633, 2130968634, 2130968635, 2130968636, 2130968637, 2130968638, 2130968639, 
        2130968640, 2130968645, 2130968647, 2130968649, 2130968650, 2130968651, 2130968652, 2130968653, 2130968654, 2130968655 };
    
    public static final int AppLovinPlayerView_al_ad_marker_color = 0;
    
    public static final int AppLovinPlayerView_al_ad_marker_width = 1;
    
    public static final int AppLovinPlayerView_al_auto_show = 2;
    
    public static final int AppLovinPlayerView_al_bar_height = 3;
    
    public static final int AppLovinPlayerView_al_buffered_color = 4;
    
    public static final int AppLovinPlayerView_al_controller_layout_id = 5;
    
    public static final int AppLovinPlayerView_al_default_artwork = 6;
    
    public static final int AppLovinPlayerView_al_hide_during_ads = 7;
    
    public static final int AppLovinPlayerView_al_hide_on_touch = 8;
    
    public static final int AppLovinPlayerView_al_keep_content_on_player_reset = 9;
    
    public static final int AppLovinPlayerView_al_played_ad_marker_color = 10;
    
    public static final int AppLovinPlayerView_al_played_color = 11;
    
    public static final int AppLovinPlayerView_al_player_layout_id = 12;
    
    public static final int AppLovinPlayerView_al_repeat_toggle_modes = 13;
    
    public static final int AppLovinPlayerView_al_resize_mode = 14;
    
    public static final int AppLovinPlayerView_al_scrubber_color = 15;
    
    public static final int AppLovinPlayerView_al_scrubber_disabled_size = 16;
    
    public static final int AppLovinPlayerView_al_scrubber_dragged_size = 17;
    
    public static final int AppLovinPlayerView_al_scrubber_drawable = 18;
    
    public static final int AppLovinPlayerView_al_scrubber_enabled_size = 19;
    
    public static final int AppLovinPlayerView_al_show_buffering = 20;
    
    public static final int AppLovinPlayerView_al_show_shuffle_button = 21;
    
    public static final int AppLovinPlayerView_al_show_timeout = 22;
    
    public static final int AppLovinPlayerView_al_shutter_background_color = 23;
    
    public static final int AppLovinPlayerView_al_surface_type = 24;
    
    public static final int AppLovinPlayerView_al_time_bar_min_update_interval = 25;
    
    public static final int AppLovinPlayerView_al_touch_target_height = 26;
    
    public static final int AppLovinPlayerView_al_unplayed_color = 27;
    
    public static final int AppLovinPlayerView_al_use_artwork = 28;
    
    public static final int AppLovinPlayerView_al_use_controller = 29;
    
    public static final int[] AppLovinStyledPlayerControlView = new int[] { 
        2130968617, 2130968618, 2130968619, 2130968622, 2130968623, 2130968624, 2130968625, 2130968630, 2130968631, 2130968633, 
        2130968635, 2130968636, 2130968637, 2130968638, 2130968639, 2130968641, 2130968642, 2130968643, 2130968644, 2130968645, 
        2130968646, 2130968647, 2130968648, 2130968651, 2130968652, 2130968653 };
    
    public static final int AppLovinStyledPlayerControlView_al_ad_marker_color = 0;
    
    public static final int AppLovinStyledPlayerControlView_al_ad_marker_width = 1;
    
    public static final int AppLovinStyledPlayerControlView_al_animation_enabled = 2;
    
    public static final int AppLovinStyledPlayerControlView_al_bar_gravity = 3;
    
    public static final int AppLovinStyledPlayerControlView_al_bar_height = 4;
    
    public static final int AppLovinStyledPlayerControlView_al_buffered_color = 5;
    
    public static final int AppLovinStyledPlayerControlView_al_controller_layout_id = 6;
    
    public static final int AppLovinStyledPlayerControlView_al_played_ad_marker_color = 7;
    
    public static final int AppLovinStyledPlayerControlView_al_played_color = 8;
    
    public static final int AppLovinStyledPlayerControlView_al_repeat_toggle_modes = 9;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_color = 10;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_disabled_size = 11;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_dragged_size = 12;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_drawable = 13;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_enabled_size = 14;
    
    public static final int AppLovinStyledPlayerControlView_al_show_fastforward_button = 15;
    
    public static final int AppLovinStyledPlayerControlView_al_show_next_button = 16;
    
    public static final int AppLovinStyledPlayerControlView_al_show_previous_button = 17;
    
    public static final int AppLovinStyledPlayerControlView_al_show_rewind_button = 18;
    
    public static final int AppLovinStyledPlayerControlView_al_show_shuffle_button = 19;
    
    public static final int AppLovinStyledPlayerControlView_al_show_subtitle_button = 20;
    
    public static final int AppLovinStyledPlayerControlView_al_show_timeout = 21;
    
    public static final int AppLovinStyledPlayerControlView_al_show_vr_button = 22;
    
    public static final int AppLovinStyledPlayerControlView_al_time_bar_min_update_interval = 23;
    
    public static final int AppLovinStyledPlayerControlView_al_touch_target_height = 24;
    
    public static final int AppLovinStyledPlayerControlView_al_unplayed_color = 25;
    
    public static final int[] AppLovinStyledPlayerView = new int[] { 
        2130968617, 2130968618, 2130968619, 2130968620, 2130968622, 2130968623, 2130968624, 2130968625, 2130968626, 2130968627, 
        2130968628, 2130968629, 2130968630, 2130968631, 2130968632, 2130968633, 2130968634, 2130968635, 2130968636, 2130968637, 
        2130968638, 2130968639, 2130968640, 2130968645, 2130968646, 2130968647, 2130968648, 2130968649, 2130968650, 2130968651, 
        2130968652, 2130968653, 2130968654, 2130968655 };
    
    public static final int AppLovinStyledPlayerView_al_ad_marker_color = 0;
    
    public static final int AppLovinStyledPlayerView_al_ad_marker_width = 1;
    
    public static final int AppLovinStyledPlayerView_al_animation_enabled = 2;
    
    public static final int AppLovinStyledPlayerView_al_auto_show = 3;
    
    public static final int AppLovinStyledPlayerView_al_bar_gravity = 4;
    
    public static final int AppLovinStyledPlayerView_al_bar_height = 5;
    
    public static final int AppLovinStyledPlayerView_al_buffered_color = 6;
    
    public static final int AppLovinStyledPlayerView_al_controller_layout_id = 7;
    
    public static final int AppLovinStyledPlayerView_al_default_artwork = 8;
    
    public static final int AppLovinStyledPlayerView_al_hide_during_ads = 9;
    
    public static final int AppLovinStyledPlayerView_al_hide_on_touch = 10;
    
    public static final int AppLovinStyledPlayerView_al_keep_content_on_player_reset = 11;
    
    public static final int AppLovinStyledPlayerView_al_played_ad_marker_color = 12;
    
    public static final int AppLovinStyledPlayerView_al_played_color = 13;
    
    public static final int AppLovinStyledPlayerView_al_player_layout_id = 14;
    
    public static final int AppLovinStyledPlayerView_al_repeat_toggle_modes = 15;
    
    public static final int AppLovinStyledPlayerView_al_resize_mode = 16;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_color = 17;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_disabled_size = 18;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_dragged_size = 19;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_drawable = 20;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_enabled_size = 21;
    
    public static final int AppLovinStyledPlayerView_al_show_buffering = 22;
    
    public static final int AppLovinStyledPlayerView_al_show_shuffle_button = 23;
    
    public static final int AppLovinStyledPlayerView_al_show_subtitle_button = 24;
    
    public static final int AppLovinStyledPlayerView_al_show_timeout = 25;
    
    public static final int AppLovinStyledPlayerView_al_show_vr_button = 26;
    
    public static final int AppLovinStyledPlayerView_al_shutter_background_color = 27;
    
    public static final int AppLovinStyledPlayerView_al_surface_type = 28;
    
    public static final int AppLovinStyledPlayerView_al_time_bar_min_update_interval = 29;
    
    public static final int AppLovinStyledPlayerView_al_touch_target_height = 30;
    
    public static final int AppLovinStyledPlayerView_al_unplayed_color = 31;
    
    public static final int AppLovinStyledPlayerView_al_use_artwork = 32;
    
    public static final int AppLovinStyledPlayerView_al_use_controller = 33;
    
    public static final int[] ButtonBarLayout = new int[] { 2130968660 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968661 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130968699, 2130968706, 2130968707 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] CoordinatorLayout = new int[] { 2130968909, 2130969141 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130968915, 2130968916, 2130968917, 2130968964, 2130968974, 2130968975 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130968668, 2130968669, 2130968685, 2130968742, 2130968827, 2130968880, 2130969127, 2130969184 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130968869, 2130968870, 2130968871, 2130968872, 2130968873, 2130968874, 2130968875 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968867, 2130968876, 2130968877, 2130968878, 2130969222 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968815, 2130968817, 2130969012, 2130969114 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] LoadingImageView = new int[] { 2130968729, 2130968896, 2130968897 };
    
    public static final int LoadingImageView_circleCrop = 0;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968592, 2130968610, 2130968611, 2130968662, 2130968776, 2130968891, 2130968892, 
        2130969046, 2130969113, 2130969207 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969076, 2130969142 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969054 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130969140 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130969056, 2130969059 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] RecyclerView = new int[] { 
        16842948, 16842987, 16842993, 2130968842, 2130968843, 2130968844, 2130968845, 2130968846, 2130968914, 2130969098, 
        2130969126, 2130969137 };
    
    public static final int RecyclerView_android_clipToPadding = 1;
    
    public static final int RecyclerView_android_descendantFocusability = 2;
    
    public static final int RecyclerView_android_orientation = 0;
    
    public static final int RecyclerView_fastScrollEnabled = 3;
    
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
    
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
    
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
    
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
    
    public static final int RecyclerView_layoutManager = 8;
    
    public static final int RecyclerView_reverseLayout = 9;
    
    public static final int RecyclerView_spanCount = 10;
    
    public static final int RecyclerView_stackFromEnd = 11;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130968738, 2130968768, 2130968806, 2130968881, 2130968893, 2130968911, 
        2130969082, 2130969083, 2130969105, 2130969106, 2130969143, 2130969148, 2130969230 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] SignInButton = new int[] { 2130968703, 2130968752, 2130969104 };
    
    public static final int SignInButton_buttonSize = 0;
    
    public static final int SignInButton_colorScheme = 1;
    
    public static final int SignInButton_scopeUris = 2;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969074 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969116, 2130969130, 2130969149, 2130969150, 2130969152, 2130969185, 2130969186, 
        2130969187, 2130969211, 2130969212, 2130969213 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130968868, 2130968877, 2130969157, 2130969174 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968700, 2130968740, 2130968741, 2130968777, 2130968778, 2130968779, 2130968780, 2130968781, 
        2130968782, 2130968997, 2130968998, 2130969000, 2130969013, 2130969041, 2130969042, 2130969074, 2130969144, 2130969145, 
        2130969146, 2130969193, 2130969194, 2130969195, 2130969196, 2130969197, 2130969198, 2130969199, 2130969200, 2130969201 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130969057, 2130969058, 2130969183 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968682, 2130968683 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132082689;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\mediation\adapters\inmobi\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */