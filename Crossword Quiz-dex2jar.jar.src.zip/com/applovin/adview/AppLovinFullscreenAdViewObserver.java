package com.applovin.adview;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import com.applovin.impl.adview.activity.b.a;
import com.applovin.impl.adview.o;
import com.applovin.impl.sdk.n;
import java.util.concurrent.atomic.AtomicBoolean;

public class AppLovinFullscreenAdViewObserver implements LifecycleObserver {
  private final n a;
  
  private final AtomicBoolean b = new AtomicBoolean(true);
  
  private a c;
  
  private o d;
  
  public AppLovinFullscreenAdViewObserver(Lifecycle paramLifecycle, o paramo, n paramn) {
    this.d = paramo;
    this.a = paramn;
    paramLifecycle.addObserver(this);
  }
  
  @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
  public void onDestroy() {
    o o1 = this.d;
    if (o1 != null) {
      o1.a();
      this.d = null;
    } 
    a a1 = this.c;
    if (a1 != null) {
      a1.h();
      this.c.k();
      this.c = null;
    } 
  }
  
  @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
  public void onPause() {
    a a1 = this.c;
    if (a1 != null) {
      a1.g();
      this.c.e();
    } 
  }
  
  @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
  public void onResume() {
    if (this.b.getAndSet(false))
      return; 
    a a1 = this.c;
    if (a1 != null) {
      a1.f();
      this.c.a(0L);
    } 
  }
  
  @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
  public void onStop() {
    a a1 = this.c;
    if (a1 != null)
      a1.j(); 
  }
  
  public void setPresenter(a parama) {
    this.c = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\adview\AppLovinFullscreenAdViewObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */