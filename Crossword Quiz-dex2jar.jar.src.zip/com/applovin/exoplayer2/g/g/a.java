package com.applovin.exoplayer2.g.g;

import android.os.Parcel;
import android.os.Parcelable;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.y;

public final class a extends b {
  public static final Parcelable.Creator<a> CREATOR = new Parcelable.Creator<a>() {
      public a a(Parcel param1Parcel) {
        return new a(param1Parcel);
      }
      
      public a[] a(int param1Int) {
        return new a[param1Int];
      }
    };
  
  public final long a;
  
  public final long b;
  
  public final byte[] c;
  
  private a(long paramLong1, byte[] paramArrayOfbyte, long paramLong2) {
    this.a = paramLong2;
    this.b = paramLong1;
    this.c = paramArrayOfbyte;
  }
  
  private a(Parcel paramParcel) {
    this.a = paramParcel.readLong();
    this.b = paramParcel.readLong();
    this.c = (byte[])ai.a(paramParcel.createByteArray());
  }
  
  static a a(y paramy, int paramInt, long paramLong) {
    long l = paramy.o();
    paramInt -= 4;
    byte[] arrayOfByte = new byte[paramInt];
    paramy.a(arrayOfByte, 0, paramInt);
    return new a(l, arrayOfByte, paramLong);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeLong(this.a);
    paramParcel.writeLong(this.b);
    paramParcel.writeByteArray(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\g\g\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */