package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class aq {
  static int a(Set<?> paramSet) {
    Iterator<?> iterator = paramSet.iterator();
    int i;
    for (i = 0; iterator.hasNext(); i = i + b ^ 0xFFFFFFFF ^ 0xFFFFFFFF) {
      byte b;
      Object object = iterator.next();
      if (object != null) {
        b = object.hashCode();
      } else {
        b = 0;
      } 
    } 
    return i;
  }
  
  public static <E> b<E> a(Set<E> paramSet, Set<?> paramSet1) {
    Preconditions.checkNotNull(paramSet, "set1");
    Preconditions.checkNotNull(paramSet1, "set2");
    return new b<E>(paramSet, paramSet1) {
        public ax<E> a() {
          return new b(this) {
              final Iterator<E> a;
              
              protected E a() {
                while (this.a.hasNext()) {
                  E e = this.a.next();
                  if (this.b.b.contains(e))
                    return e; 
                } 
                return b();
              }
            };
        }
        
        public boolean contains(Object param1Object) {
          return (this.a.contains(param1Object) && this.b.contains(param1Object));
        }
        
        public boolean containsAll(Collection<?> param1Collection) {
          return (this.a.containsAll(param1Collection) && this.b.containsAll(param1Collection));
        }
        
        public boolean isEmpty() {
          return Collections.disjoint(this.b, this.a);
        }
        
        public int size() {
          Iterator<Object> iterator = this.a.iterator();
          int i = 0;
          while (iterator.hasNext()) {
            Object object = iterator.next();
            if (this.b.contains(object))
              i++; 
          } 
          return i;
        }
      };
  }
  
  public static <E> HashSet<E> a() {
    return new HashSet<E>();
  }
  
  public static <E> HashSet<E> a(int paramInt) {
    return new HashSet<E>(ab.a(paramInt));
  }
  
  static boolean a(Set<?> paramSet, @NullableDecl Object paramObject) {
    if (paramSet == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      paramObject = paramObject;
      try {
        if (paramSet.size() == paramObject.size()) {
          boolean bool = paramSet.containsAll((Collection<?>)paramObject);
          if (bool)
            return true; 
        } 
        return false;
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    } 
    return false;
  }
  
  static boolean a(Set<?> paramSet, Collection<?> paramCollection) {
    Preconditions.checkNotNull(paramCollection);
    Collection<?> collection = paramCollection;
    if (paramCollection instanceof af)
      collection = ((af)paramCollection).a(); 
    return (collection instanceof Set && collection.size() > paramSet.size()) ? y.a(paramSet.iterator(), collection) : a(paramSet, collection.iterator());
  }
  
  static boolean a(Set<?> paramSet, Iterator<?> paramIterator) {
    boolean bool;
    for (bool = false; paramIterator.hasNext(); bool |= paramSet.remove(paramIterator.next()));
    return bool;
  }
  
  public static <E> Set<E> b() {
    return Collections.newSetFromMap(ab.c());
  }
  
  static abstract class a<E> extends AbstractSet<E> {
    public boolean removeAll(Collection<?> param1Collection) {
      return aq.a(this, param1Collection);
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      return super.retainAll((Collection)Preconditions.checkNotNull(param1Collection));
    }
  }
  
  public static abstract class b<E> extends AbstractSet<E> {
    private b() {}
    
    public abstract ax<E> a();
    
    @Deprecated
    public final boolean add(E param1E) {
      throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public final boolean addAll(Collection<? extends E> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public final void clear() {
      throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public final boolean remove(Object param1Object) {
      throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public final boolean removeAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public final boolean retainAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */