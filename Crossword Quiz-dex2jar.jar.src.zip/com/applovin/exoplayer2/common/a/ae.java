package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import com.applovin.exoplayer2.common.base.Supplier;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class ae {
  public static <K, V> z<K, V> a(Map<K, Collection<V>> paramMap, Supplier<? extends List<V>> paramSupplier) {
    return new a<K, V>(paramMap, paramSupplier);
  }
  
  static boolean a(ac<?, ?> paramac, @NullableDecl Object paramObject) {
    if (paramObject == paramac)
      return true; 
    if (paramObject instanceof ac) {
      paramObject = paramObject;
      return paramac.b().equals(paramObject.b());
    } 
    return false;
  }
  
  private static class a<K, V> extends c<K, V> {
    transient Supplier<? extends List<V>> a;
    
    a(Map<K, Collection<V>> param1Map, Supplier<? extends List<V>> param1Supplier) {
      super(param1Map);
      this.a = (Supplier<? extends List<V>>)Preconditions.checkNotNull(param1Supplier);
    }
    
    protected List<V> a() {
      return (List<V>)this.a.get();
    }
    
    Set<K> f() {
      return g();
    }
    
    Map<K, Collection<V>> n() {
      return o();
    }
  }
  
  static abstract class b<K, V> extends AbstractCollection<Map.Entry<K, V>> {
    abstract ac<K, V> a();
    
    public void clear() {
      a().e();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      if (param1Object instanceof Map.Entry) {
        param1Object = param1Object;
        return a().b(param1Object.getKey(), param1Object.getValue());
      } 
      return false;
    }
    
    public boolean remove(@NullableDecl Object param1Object) {
      if (param1Object instanceof Map.Entry) {
        param1Object = param1Object;
        return a().c(param1Object.getKey(), param1Object.getValue());
      } 
      return false;
    }
    
    public int size() {
      return a().d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */