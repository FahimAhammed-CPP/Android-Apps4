package com.applovin.exoplayer2.common.a;

import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class p {
  static int a(int paramInt) {
    return (int)(Integer.rotateLeft((int)(paramInt * -862048943L), 15) * 461845907L);
  }
  
  static int a(int paramInt, double paramDouble) {
    paramInt = Math.max(paramInt, 2);
    int i = Integer.highestOneBit(paramInt);
    double d = i;
    Double.isNaN(d);
    if (paramInt > (int)(paramDouble * d)) {
      paramInt = i << 1;
      return (paramInt > 0) ? paramInt : 1073741824;
    } 
    return i;
  }
  
  static int a(@NullableDecl Object paramObject) {
    int i;
    if (paramObject == null) {
      i = 0;
    } else {
      i = paramObject.hashCode();
    } 
    return a(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */