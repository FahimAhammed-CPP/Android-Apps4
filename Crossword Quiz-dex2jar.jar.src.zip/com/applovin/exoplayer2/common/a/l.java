package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Objects;
import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

class l<K, V> extends AbstractMap<K, V> implements Serializable {
  @MonotonicNonNullDecl
  transient long[] a;
  
  @MonotonicNonNullDecl
  transient Object[] b;
  
  @MonotonicNonNullDecl
  transient Object[] c;
  
  transient float d;
  
  transient int e;
  
  @MonotonicNonNullDecl
  private transient int[] f;
  
  private transient int g;
  
  private transient int h;
  
  @MonotonicNonNullDecl
  private transient Set<K> i;
  
  @MonotonicNonNullDecl
  private transient Set<Map.Entry<K, V>> j;
  
  @MonotonicNonNullDecl
  private transient Collection<V> k;
  
  l() {
    a(3, 1.0F);
  }
  
  l(int paramInt) {
    this(paramInt, 1.0F);
  }
  
  l(int paramInt, float paramFloat) {
    a(paramInt, paramFloat);
  }
  
  private static int a(long paramLong) {
    return (int)(paramLong >>> 32L);
  }
  
  private int a(@NullableDecl Object paramObject) {
    int j = p.a(paramObject);
    for (int i = this.f[i() & j]; i != -1; i = b(l1)) {
      long l1 = this.a[i];
      if (a(l1) == j && Objects.equal(paramObject, this.b[i]))
        return i; 
    } 
    return -1;
  }
  
  private static long a(long paramLong, int paramInt) {
    return paramLong & 0xFFFFFFFF00000000L | paramInt & 0xFFFFFFFFL;
  }
  
  public static <K, V> l<K, V> a() {
    return new l<K, V>();
  }
  
  public static <K, V> l<K, V> a(int paramInt) {
    return new l<K, V>(paramInt);
  }
  
  @NullableDecl
  private V a(@NullableDecl Object paramObject, int paramInt) {
    int k = i() & paramInt;
    int i = this.f[k];
    if (i == -1)
      return null; 
    int j = -1;
    while (true) {
      if (a(this.a[i]) == paramInt && Objects.equal(paramObject, this.b[i])) {
        paramObject = this.c[i];
        if (j == -1) {
          this.f[k] = b(this.a[i]);
        } else {
          long[] arrayOfLong = this.a;
          arrayOfLong[j] = a(arrayOfLong[j], b(arrayOfLong[i]));
        } 
        d(i);
        this.h--;
        this.e++;
        return (V)paramObject;
      } 
      int m = b(this.a[i]);
      if (m == -1)
        return null; 
      j = i;
      i = m;
    } 
  }
  
  private static int b(long paramLong) {
    return (int)paramLong;
  }
  
  private static int[] f(int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    Arrays.fill(arrayOfInt, -1);
    return arrayOfInt;
  }
  
  private static long[] g(int paramInt) {
    long[] arrayOfLong = new long[paramInt];
    Arrays.fill(arrayOfLong, -1L);
    return arrayOfLong;
  }
  
  private void h(int paramInt) {
    int i = this.a.length;
    if (paramInt > i) {
      int j = Math.max(1, i >>> 1) + i;
      paramInt = j;
      if (j < 0)
        paramInt = Integer.MAX_VALUE; 
      if (paramInt != i)
        c(paramInt); 
    } 
  }
  
  private int i() {
    return this.f.length - 1;
  }
  
  private void i(int paramInt) {
    if (this.f.length >= 1073741824) {
      this.g = Integer.MAX_VALUE;
      return;
    } 
    int i = (int)(paramInt * this.d);
    int[] arrayOfInt = f(paramInt);
    long[] arrayOfLong = this.a;
    int j = arrayOfInt.length;
    for (paramInt = 0; paramInt < this.h; paramInt++) {
      int k = a(arrayOfLong[paramInt]);
      int m = k & j - 1;
      int n = arrayOfInt[m];
      arrayOfInt[m] = paramInt;
      arrayOfLong[paramInt] = k << 32L | 0xFFFFFFFFL & n;
    } 
    this.g = i + 1;
    this.f = arrayOfInt;
  }
  
  private V j(int paramInt) {
    return a(this.b[paramInt], a(this.a[paramInt]));
  }
  
  int a(int paramInt1, int paramInt2) {
    return paramInt1 - 1;
  }
  
  void a(int paramInt, float paramFloat) {
    boolean bool2 = false;
    if (paramInt >= 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    Preconditions.checkArgument(bool1, "Initial capacity must be non-negative");
    boolean bool1 = bool2;
    if (paramFloat > 0.0F)
      bool1 = true; 
    Preconditions.checkArgument(bool1, "Illegal load factor");
    int i = p.a(paramInt, paramFloat);
    this.f = f(i);
    this.d = paramFloat;
    this.b = new Object[paramInt];
    this.c = new Object[paramInt];
    this.a = g(paramInt);
    this.g = Math.max(1, (int)(i * paramFloat));
  }
  
  void a(int paramInt1, @NullableDecl K paramK, @NullableDecl V paramV, int paramInt2) {
    this.a[paramInt1] = paramInt2 << 32L | 0xFFFFFFFFL;
    this.b[paramInt1] = paramK;
    this.c[paramInt1] = paramV;
  }
  
  int b() {
    return isEmpty() ? -1 : 0;
  }
  
  void b(int paramInt) {}
  
  Set<K> c() {
    return new c(this);
  }
  
  void c(int paramInt) {
    this.b = Arrays.copyOf(this.b, paramInt);
    this.c = Arrays.copyOf(this.c, paramInt);
    long[] arrayOfLong = this.a;
    int i = arrayOfLong.length;
    arrayOfLong = Arrays.copyOf(arrayOfLong, paramInt);
    if (paramInt > i)
      Arrays.fill(arrayOfLong, i, paramInt, -1L); 
    this.a = arrayOfLong;
  }
  
  public void clear() {
    this.e++;
    Arrays.fill(this.b, 0, this.h, (Object)null);
    Arrays.fill(this.c, 0, this.h, (Object)null);
    Arrays.fill(this.f, -1);
    Arrays.fill(this.a, -1L);
    this.h = 0;
  }
  
  public boolean containsKey(@NullableDecl Object paramObject) {
    return (a(paramObject) != -1);
  }
  
  public boolean containsValue(@NullableDecl Object paramObject) {
    for (int i = 0; i < this.h; i++) {
      if (Objects.equal(paramObject, this.c[i]))
        return true; 
    } 
    return false;
  }
  
  Iterator<K> d() {
    return new b<K>(this) {
        K a(int param1Int) {
          return (K)this.a.b[param1Int];
        }
      };
  }
  
  void d(int paramInt) {
    int i = size() - 1;
    if (paramInt < i) {
      Object[] arrayOfObject1 = this.b;
      arrayOfObject1[paramInt] = arrayOfObject1[i];
      Object[] arrayOfObject2 = this.c;
      arrayOfObject2[paramInt] = arrayOfObject2[i];
      arrayOfObject1[i] = null;
      arrayOfObject2[i] = null;
      long[] arrayOfLong = this.a;
      long l1 = arrayOfLong[i];
      arrayOfLong[paramInt] = l1;
      arrayOfLong[i] = -1L;
      int m = a(l1) & i();
      int[] arrayOfInt = this.f;
      int k = arrayOfInt[m];
      int j = k;
      if (k == i) {
        arrayOfInt[m] = paramInt;
        return;
      } 
      while (true) {
        l1 = this.a[j];
        k = b(l1);
        if (k == i) {
          this.a[j] = a(l1, paramInt);
          return;
        } 
        j = k;
      } 
    } 
    this.b[paramInt] = null;
    this.c[paramInt] = null;
    this.a[paramInt] = -1L;
  }
  
  int e(int paramInt) {
    return (++paramInt < this.h) ? paramInt : -1;
  }
  
  Set<Map.Entry<K, V>> e() {
    return new a(this);
  }
  
  public Set<Map.Entry<K, V>> entrySet() {
    Set<Map.Entry<K, V>> set2 = this.j;
    Set<Map.Entry<K, V>> set1 = set2;
    if (set2 == null) {
      set1 = e();
      this.j = set1;
    } 
    return set1;
  }
  
  Iterator<Map.Entry<K, V>> f() {
    return new b<Map.Entry<K, V>>(this) {
        Map.Entry<K, V> b(int param1Int) {
          return new l.d(this.a, param1Int);
        }
      };
  }
  
  Collection<V> g() {
    return new e(this);
  }
  
  public V get(@NullableDecl Object paramObject) {
    int i = a(paramObject);
    b(i);
    return (V)((i == -1) ? null : this.c[i]);
  }
  
  Iterator<V> h() {
    return new b<V>(this) {
        V a(int param1Int) {
          return (V)this.a.c[param1Int];
        }
      };
  }
  
  public boolean isEmpty() {
    return (this.h == 0);
  }
  
  public Set<K> keySet() {
    Set<K> set2 = this.i;
    Set<K> set1 = set2;
    if (set2 == null) {
      set1 = c();
      this.i = set1;
    } 
    return set1;
  }
  
  @NullableDecl
  public V put(@NullableDecl K paramK, @NullableDecl V paramV) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : [J
    //   4: astore #11
    //   6: aload_0
    //   7: getfield b : [Ljava/lang/Object;
    //   10: astore #12
    //   12: aload_0
    //   13: getfield c : [Ljava/lang/Object;
    //   16: astore #10
    //   18: aload_1
    //   19: invokestatic a : (Ljava/lang/Object;)I
    //   22: istore #5
    //   24: aload_0
    //   25: invokespecial i : ()I
    //   28: iload #5
    //   30: iand
    //   31: istore #7
    //   33: aload_0
    //   34: getfield h : I
    //   37: istore #6
    //   39: aload_0
    //   40: getfield f : [I
    //   43: astore #13
    //   45: aload #13
    //   47: iload #7
    //   49: iaload
    //   50: istore #4
    //   52: iload #4
    //   54: istore_3
    //   55: iload #4
    //   57: iconst_m1
    //   58: if_icmpne -> 71
    //   61: aload #13
    //   63: iload #7
    //   65: iload #6
    //   67: iastore
    //   68: goto -> 139
    //   71: aload #11
    //   73: iload_3
    //   74: laload
    //   75: lstore #8
    //   77: lload #8
    //   79: invokestatic a : (J)I
    //   82: iload #5
    //   84: if_icmpne -> 115
    //   87: aload_1
    //   88: aload #12
    //   90: iload_3
    //   91: aaload
    //   92: invokestatic equal : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   95: ifeq -> 115
    //   98: aload #10
    //   100: iload_3
    //   101: aaload
    //   102: astore_1
    //   103: aload #10
    //   105: iload_3
    //   106: aload_2
    //   107: aastore
    //   108: aload_0
    //   109: iload_3
    //   110: invokevirtual b : (I)V
    //   113: aload_1
    //   114: areturn
    //   115: lload #8
    //   117: invokestatic b : (J)I
    //   120: istore #4
    //   122: iload #4
    //   124: iconst_m1
    //   125: if_icmpne -> 213
    //   128: aload #11
    //   130: iload_3
    //   131: lload #8
    //   133: iload #6
    //   135: invokestatic a : (JI)J
    //   138: lastore
    //   139: iload #6
    //   141: ldc 2147483647
    //   143: if_icmpeq -> 203
    //   146: iload #6
    //   148: iconst_1
    //   149: iadd
    //   150: istore_3
    //   151: aload_0
    //   152: iload_3
    //   153: invokespecial h : (I)V
    //   156: aload_0
    //   157: iload #6
    //   159: aload_1
    //   160: aload_2
    //   161: iload #5
    //   163: invokevirtual a : (ILjava/lang/Object;Ljava/lang/Object;I)V
    //   166: aload_0
    //   167: iload_3
    //   168: putfield h : I
    //   171: iload #6
    //   173: aload_0
    //   174: getfield g : I
    //   177: if_icmplt -> 191
    //   180: aload_0
    //   181: aload_0
    //   182: getfield f : [I
    //   185: arraylength
    //   186: iconst_2
    //   187: imul
    //   188: invokespecial i : (I)V
    //   191: aload_0
    //   192: aload_0
    //   193: getfield e : I
    //   196: iconst_1
    //   197: iadd
    //   198: putfield e : I
    //   201: aconst_null
    //   202: areturn
    //   203: new java/lang/IllegalStateException
    //   206: dup
    //   207: ldc 'Cannot contain more than Integer.MAX_VALUE elements!'
    //   209: invokespecial <init> : (Ljava/lang/String;)V
    //   212: athrow
    //   213: iload #4
    //   215: istore_3
    //   216: goto -> 71
  }
  
  @NullableDecl
  public V remove(@NullableDecl Object paramObject) {
    return a(paramObject, p.a(paramObject));
  }
  
  public int size() {
    return this.h;
  }
  
  public Collection<V> values() {
    Collection<V> collection2 = this.k;
    Collection<V> collection1 = collection2;
    if (collection2 == null) {
      collection1 = g();
      this.k = collection1;
    } 
    return collection1;
  }
  
  class a extends AbstractSet<Map.Entry<K, V>> {
    a(l this$0) {}
    
    public void clear() {
      this.a.clear();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof Map.Entry;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        int i = l.a(this.a, param1Object.getKey());
        bool1 = bool2;
        if (i != -1) {
          bool1 = bool2;
          if (Objects.equal(this.a.c[i], param1Object.getValue()))
            bool1 = true; 
        } 
      } 
      return bool1;
    }
    
    public Iterator<Map.Entry<K, V>> iterator() {
      return this.a.f();
    }
    
    public boolean remove(@NullableDecl Object param1Object) {
      if (param1Object instanceof Map.Entry) {
        param1Object = param1Object;
        int i = l.a(this.a, param1Object.getKey());
        if (i != -1 && Objects.equal(this.a.c[i], param1Object.getValue())) {
          l.a(this.a, i);
          return true;
        } 
      } 
      return false;
    }
    
    public int size() {
      return l.a(this.a);
    }
  }
  
  private abstract class b<T> implements Iterator<T> {
    int b = l.this.e;
    
    int c = l.this.b();
    
    int d = -1;
    
    private b(l this$0) {}
    
    private void a() {
      if (this.e.e == this.b)
        return; 
      throw new ConcurrentModificationException();
    }
    
    abstract T a(int param1Int);
    
    public boolean hasNext() {
      return (this.c >= 0);
    }
    
    public T next() {
      a();
      if (hasNext()) {
        int i = this.c;
        this.d = i;
        T t = a(i);
        this.c = this.e.e(this.c);
        return t;
      } 
      throw new NoSuchElementException();
    }
    
    public void remove() {
      boolean bool;
      a();
      if (this.d >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      j.a(bool);
      this.b++;
      l.a(this.e, this.d);
      this.c = this.e.a(this.c, this.d);
      this.d = -1;
    }
  }
  
  class c extends AbstractSet<K> {
    c(l this$0) {}
    
    public void clear() {
      this.a.clear();
    }
    
    public boolean contains(Object param1Object) {
      return this.a.containsKey(param1Object);
    }
    
    public Iterator<K> iterator() {
      return this.a.d();
    }
    
    public boolean remove(@NullableDecl Object param1Object) {
      int i = l.a(this.a, param1Object);
      if (i == -1)
        return false; 
      l.a(this.a, i);
      return true;
    }
    
    public int size() {
      return l.a(this.a);
    }
  }
  
  final class d extends e<K, V> {
    @NullableDecl
    private final K b;
    
    private int c;
    
    d(l this$0, int param1Int) {
      this.b = (K)this$0.b[param1Int];
      this.c = param1Int;
    }
    
    private void a() {
      int i = this.c;
      if (i == -1 || i >= this.a.size() || !Objects.equal(this.b, this.a.b[this.c]))
        this.c = l.a(this.a, this.b); 
    }
    
    public K getKey() {
      return this.b;
    }
    
    public V getValue() {
      a();
      return (V)((this.c == -1) ? null : this.a.c[this.c]);
    }
    
    public V setValue(V param1V) {
      a();
      if (this.c == -1) {
        this.a.put(this.b, param1V);
        return null;
      } 
      Object object = this.a.c[this.c];
      this.a.c[this.c] = param1V;
      return (V)object;
    }
  }
  
  class e extends AbstractCollection<V> {
    e(l this$0) {}
    
    public void clear() {
      this.a.clear();
    }
    
    public Iterator<V> iterator() {
      return this.a.h();
    }
    
    public int size() {
      return l.a(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */