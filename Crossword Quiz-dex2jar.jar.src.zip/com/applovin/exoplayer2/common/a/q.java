package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class q<E> extends AbstractCollection<E> implements Serializable {
  private static final Object[] a = new Object[0];
  
  int a(Object[] paramArrayOfObject, int paramInt) {
    ax<E> ax = a();
    while (ax.hasNext()) {
      paramArrayOfObject[paramInt] = ax.next();
      paramInt++;
    } 
    return paramInt;
  }
  
  public abstract ax<E> a();
  
  @Deprecated
  public final boolean add(E paramE) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  Object[] b() {
    return null;
  }
  
  int c() {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void clear() {
    throw new UnsupportedOperationException();
  }
  
  public abstract boolean contains(@NullableDecl Object paramObject);
  
  int d() {
    throw new UnsupportedOperationException();
  }
  
  public s<E> e() {
    return isEmpty() ? s.g() : s.b(toArray());
  }
  
  abstract boolean f();
  
  @Deprecated
  public final boolean remove(Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean removeAll(Collection<?> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean retainAll(Collection<?> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  public final Object[] toArray() {
    return toArray(a);
  }
  
  public final <T> T[] toArray(T[] paramArrayOfT) {
    T[] arrayOfT;
    Preconditions.checkNotNull(paramArrayOfT);
    int i = size();
    if (paramArrayOfT.length < i) {
      Object[] arrayOfObject = b();
      if (arrayOfObject != null)
        return (T[])aj.a(arrayOfObject, c(), d(), (Object[])paramArrayOfT); 
      arrayOfObject = ah.a((Object[])paramArrayOfT, i);
    } else {
      arrayOfT = paramArrayOfT;
      if (paramArrayOfT.length > i) {
        paramArrayOfT[i] = null;
        arrayOfT = paramArrayOfT;
      } 
    } 
    a((Object[])arrayOfT, 0);
    return arrayOfT;
  }
  
  static abstract class a<E> extends b<E> {
    Object[] a;
    
    int b;
    
    boolean c;
    
    a(int param1Int) {
      j.a(param1Int, "initialCapacity");
      this.a = new Object[param1Int];
      this.b = 0;
    }
    
    private void a(int param1Int) {
      Object[] arrayOfObject = this.a;
      if (arrayOfObject.length < param1Int) {
        this.a = Arrays.copyOf(arrayOfObject, a(arrayOfObject.length, param1Int));
      } else if (this.c) {
        this.a = (Object[])arrayOfObject.clone();
      } else {
        return;
      } 
      this.c = false;
    }
    
    public a<E> a(E param1E) {
      Preconditions.checkNotNull(param1E);
      a(this.b + 1);
      Object[] arrayOfObject = this.a;
      int i = this.b;
      this.b = i + 1;
      arrayOfObject[i] = param1E;
      return this;
    }
  }
  
  public static abstract class b<E> {
    static int a(int param1Int1, int param1Int2) {
      if (param1Int2 >= 0) {
        int i = param1Int1 + (param1Int1 >> 1) + 1;
        param1Int1 = i;
        if (i < param1Int2)
          param1Int1 = Integer.highestOneBit(param1Int2 - 1) << 1; 
        param1Int2 = param1Int1;
        if (param1Int1 < 0)
          param1Int2 = Integer.MAX_VALUE; 
        return param1Int2;
      } 
      throw new AssertionError("cannot store more than MAX_VALUE elements");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */