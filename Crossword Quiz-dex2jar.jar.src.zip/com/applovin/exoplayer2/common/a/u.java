package com.applovin.exoplayer2.common.a;

import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class u<K, V> implements Serializable, Map<K, V> {
  static final Map.Entry<?, ?>[] a = (Map.Entry<?, ?>[])new Map.Entry[0];
  
  @LazyInit
  private transient w<Map.Entry<K, V>> b;
  
  @LazyInit
  private transient w<K> c;
  
  @LazyInit
  private transient q<V> d;
  
  public static <K, V> u<K, V> a() {
    return (u)al.b;
  }
  
  public static <K, V> u<K, V> a(Iterable<? extends Map.Entry<? extends K, ? extends V>> paramIterable) {
    byte b;
    if (paramIterable instanceof Collection) {
      b = ((Collection)paramIterable).size();
    } else {
      b = 4;
    } 
    a<Object, Object> a = new a<Object, Object>(b);
    a.a(paramIterable);
    return (u)a.a();
  }
  
  public static <K, V> u<K, V> a(Map<? extends K, ? extends V> paramMap) {
    if (paramMap instanceof u && !(paramMap instanceof java.util.SortedMap)) {
      u<K, V> u1 = (u)paramMap;
      if (!u1.i())
        return u1; 
    } 
    return a(paramMap.entrySet());
  }
  
  public static <K, V> a<K, V> b() {
    return new a<K, V>();
  }
  
  public w<Map.Entry<K, V>> c() {
    w<Map.Entry<K, V>> w2 = this.b;
    w<Map.Entry<K, V>> w1 = w2;
    if (w2 == null) {
      w1 = d();
      this.b = w1;
    } 
    return w1;
  }
  
  @Deprecated
  public final void clear() {
    throw new UnsupportedOperationException();
  }
  
  public boolean containsKey(@NullableDecl Object paramObject) {
    return (get(paramObject) != null);
  }
  
  public boolean containsValue(@NullableDecl Object paramObject) {
    return g().contains(paramObject);
  }
  
  abstract w<Map.Entry<K, V>> d();
  
  public w<K> e() {
    w<K> w2 = this.c;
    w<K> w1 = w2;
    if (w2 == null) {
      w1 = f();
      this.c = w1;
    } 
    return w1;
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    return ab.d(this, paramObject);
  }
  
  abstract w<K> f();
  
  public q<V> g() {
    q<V> q2 = this.d;
    q<V> q1 = q2;
    if (q2 == null) {
      q1 = h();
      this.d = q1;
    } 
    return q1;
  }
  
  public abstract V get(@NullableDecl Object paramObject);
  
  public final V getOrDefault(@NullableDecl Object paramObject, @NullableDecl V paramV) {
    paramObject = get(paramObject);
    if (paramObject != null)
      paramV = (V)paramObject; 
    return paramV;
  }
  
  abstract q<V> h();
  
  public int hashCode() {
    return aq.a(c());
  }
  
  abstract boolean i();
  
  public boolean isEmpty() {
    return (size() == 0);
  }
  
  @Deprecated
  public final V put(K paramK, V paramV) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void putAll(Map<? extends K, ? extends V> paramMap) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final V remove(Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  public String toString() {
    return ab.a(this);
  }
  
  public static class a<K, V> {
    @MonotonicNonNullDecl
    Comparator<? super V> a;
    
    Object[] b;
    
    int c;
    
    boolean d;
    
    public a() {
      this(4);
    }
    
    a(int param1Int) {
      this.b = new Object[param1Int * 2];
      this.c = 0;
      this.d = false;
    }
    
    private void a(int param1Int) {
      param1Int *= 2;
      Object[] arrayOfObject = this.b;
      if (param1Int > arrayOfObject.length) {
        this.b = Arrays.copyOf(arrayOfObject, q.b.a(arrayOfObject.length, param1Int));
        this.d = false;
      } 
    }
    
    public a<K, V> a(Iterable<? extends Map.Entry<? extends K, ? extends V>> param1Iterable) {
      if (param1Iterable instanceof Collection)
        a(this.c + ((Collection)param1Iterable).size()); 
      Iterator<? extends Map.Entry<? extends K, ? extends V>> iterator = param1Iterable.iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
      return this;
    }
    
    public a<K, V> a(K param1K, V param1V) {
      a(this.c + 1);
      j.a(param1K, param1V);
      Object[] arrayOfObject = this.b;
      int i = this.c;
      arrayOfObject[i * 2] = param1K;
      arrayOfObject[i * 2 + 1] = param1V;
      this.c = i + 1;
      return this;
    }
    
    public a<K, V> a(Map.Entry<? extends K, ? extends V> param1Entry) {
      return a(param1Entry.getKey(), param1Entry.getValue());
    }
    
    public u<K, V> a() {
      b();
      this.d = true;
      return al.a(this.c, this.b);
    }
    
    void b() {
      if (this.a != null) {
        if (this.d)
          this.b = Arrays.copyOf(this.b, this.c * 2); 
        Map.Entry[] arrayOfEntry = new Map.Entry[this.c];
        int j = 0;
        int i = 0;
        while (true) {
          int k = this.c;
          if (i < k) {
            Object[] arrayOfObject = this.b;
            k = i * 2;
            arrayOfEntry[i] = new AbstractMap.SimpleImmutableEntry<Object, Object>(arrayOfObject[k], arrayOfObject[k + 1]);
            i++;
            continue;
          } 
          Arrays.sort(arrayOfEntry, 0, k, ai.<V>a(this.a).a(ab.b()));
          for (i = j; i < this.c; i++) {
            Object[] arrayOfObject = this.b;
            j = i * 2;
            arrayOfObject[j] = arrayOfEntry[i].getKey();
            this.b[j + 1] = arrayOfEntry[i].getValue();
          } 
          break;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */