package com.applovin.exoplayer2.common.a;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

abstract class c<K, V> extends d<K, V> implements z<K, V> {
  protected c(Map<K, Collection<V>> paramMap) {
    super(paramMap);
  }
  
  Collection<V> a(K paramK, Collection<V> paramCollection) {
    return a(paramK, (List<V>)paramCollection, (d<K, V>.i)null);
  }
  
  <E> Collection<E> a(Collection<E> paramCollection) {
    return Collections.unmodifiableList((List<? extends E>)paramCollection);
  }
  
  abstract List<V> a();
  
  public List<V> a(@NullableDecl K paramK) {
    return (List<V>)super.b(paramK);
  }
  
  public boolean a(@NullableDecl K paramK, @NullableDecl V paramV) {
    return super.a(paramK, paramV);
  }
  
  public Map<K, Collection<V>> b() {
    return super.b();
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    return super.equals(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */