package com.applovin.exoplayer2.common.a;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class x {
  @NullableDecl
  public static <T> T a(Iterable<? extends T> paramIterable, @NullableDecl T paramT) {
    return y.a(paramIterable.iterator(), paramT);
  }
  
  private static <T> T a(List<T> paramList) {
    return paramList.get(paramList.size() - 1);
  }
  
  public static String a(Iterable<?> paramIterable) {
    return y.a(paramIterable.iterator());
  }
  
  static Object[] b(Iterable<?> paramIterable) {
    return d(paramIterable).toArray();
  }
  
  public static <T> T c(Iterable<T> paramIterable) {
    if (paramIterable instanceof List) {
      paramIterable = paramIterable;
      if (!paramIterable.isEmpty())
        return a((List<T>)paramIterable); 
      throw new NoSuchElementException();
    } 
    return y.b(paramIterable.iterator());
  }
  
  private static <E> Collection<E> d(Iterable<E> paramIterable) {
    return (paramIterable instanceof Collection) ? (Collection<E>)paramIterable : aa.a(paramIterable.iterator());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */