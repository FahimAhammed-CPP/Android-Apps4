package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class al<K, V> extends u<K, V> {
  static final u<Object, Object> b = new al(null, new Object[0], 0);
  
  final transient Object[] c;
  
  private final transient int[] d;
  
  private final transient int e;
  
  private al(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    this.d = paramArrayOfint;
    this.c = paramArrayOfObject;
    this.e = paramInt;
  }
  
  static <K, V> al<K, V> a(int paramInt, Object[] paramArrayOfObject) {
    if (paramInt == 0)
      return (al)b; 
    if (paramInt == 1) {
      j.a(paramArrayOfObject[0], paramArrayOfObject[1]);
      return new al<K, V>(null, paramArrayOfObject, 1);
    } 
    Preconditions.checkPositionIndex(paramInt, paramArrayOfObject.length >> 1);
    return new al<K, V>(a(paramArrayOfObject, paramInt, w.a(paramInt), 0), paramArrayOfObject, paramInt);
  }
  
  static Object a(@NullableDecl int[] paramArrayOfint, @NullableDecl Object[] paramArrayOfObject, int paramInt1, int paramInt2, @NullableDecl Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #6
    //   3: aload #4
    //   5: ifnonnull -> 10
    //   8: aconst_null
    //   9: areturn
    //   10: iload_2
    //   11: iconst_1
    //   12: if_icmpne -> 37
    //   15: aload #6
    //   17: astore_0
    //   18: aload_1
    //   19: iload_3
    //   20: aaload
    //   21: aload #4
    //   23: invokevirtual equals : (Ljava/lang/Object;)Z
    //   26: ifeq -> 35
    //   29: aload_1
    //   30: iload_3
    //   31: iconst_1
    //   32: ixor
    //   33: aaload
    //   34: astore_0
    //   35: aload_0
    //   36: areturn
    //   37: aload_0
    //   38: ifnonnull -> 43
    //   41: aconst_null
    //   42: areturn
    //   43: aload_0
    //   44: arraylength
    //   45: istore_3
    //   46: aload #4
    //   48: invokevirtual hashCode : ()I
    //   51: invokestatic a : (I)I
    //   54: istore_2
    //   55: iload_2
    //   56: iload_3
    //   57: iconst_1
    //   58: isub
    //   59: iand
    //   60: istore_2
    //   61: aload_0
    //   62: iload_2
    //   63: iaload
    //   64: istore #5
    //   66: iload #5
    //   68: iconst_m1
    //   69: if_icmpne -> 74
    //   72: aconst_null
    //   73: areturn
    //   74: aload_1
    //   75: iload #5
    //   77: aaload
    //   78: aload #4
    //   80: invokevirtual equals : (Ljava/lang/Object;)Z
    //   83: ifeq -> 93
    //   86: aload_1
    //   87: iload #5
    //   89: iconst_1
    //   90: ixor
    //   91: aaload
    //   92: areturn
    //   93: iload_2
    //   94: iconst_1
    //   95: iadd
    //   96: istore_2
    //   97: goto -> 55
  }
  
  static int[] a(Object[] paramArrayOfObject, int paramInt1, int paramInt2, int paramInt3) {
    StringBuilder stringBuilder;
    if (paramInt1 == 1) {
      j.a(paramArrayOfObject[paramInt3], paramArrayOfObject[paramInt3 ^ 0x1]);
      return null;
    } 
    int[] arrayOfInt = new int[paramInt2];
    Arrays.fill(arrayOfInt, -1);
    int i = 0;
    label17: while (i < paramInt1) {
      int j = i * 2;
      int k = j + paramInt3;
      Object object1 = paramArrayOfObject[k];
      Object object2 = paramArrayOfObject[j + (paramInt3 ^ 0x1)];
      j.a(object1, object2);
      j = p.a(object1.hashCode());
      while (true) {
        j &= paramInt2 - 1;
        int m = arrayOfInt[j];
        if (m == -1) {
          arrayOfInt[j] = k;
          i++;
          continue label17;
        } 
        if (!paramArrayOfObject[m].equals(object1)) {
          j++;
          continue;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Multiple entries with same key: ");
        stringBuilder.append(object1);
        stringBuilder.append("=");
        stringBuilder.append(object2);
        stringBuilder.append(" and ");
        stringBuilder.append(paramArrayOfObject[m]);
        stringBuilder.append("=");
        stringBuilder.append(paramArrayOfObject[m ^ 0x1]);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return (int[])stringBuilder;
  }
  
  w<Map.Entry<K, V>> d() {
    return new a<K, V>(this, this.c, 0, this.e);
  }
  
  w<K> f() {
    return new b<K>(this, new c(this.c, 0, this.e));
  }
  
  @NullableDecl
  public V get(@NullableDecl Object paramObject) {
    return (V)a(this.d, this.c, this.e, 0, paramObject);
  }
  
  q<V> h() {
    return (q<V>)new c(this.c, 1, this.e);
  }
  
  boolean i() {
    return false;
  }
  
  public int size() {
    return this.e;
  }
  
  static class a<K, V> extends w<Map.Entry<K, V>> {
    private final transient u<K, V> a;
    
    private final transient Object[] b;
    
    private final transient int c;
    
    private final transient int d;
    
    a(u<K, V> param1u, Object[] param1ArrayOfObject, int param1Int1, int param1Int2) {
      this.a = param1u;
      this.b = param1ArrayOfObject;
      this.c = param1Int1;
      this.d = param1Int2;
    }
    
    int a(Object[] param1ArrayOfObject, int param1Int) {
      return e().a(param1ArrayOfObject, param1Int);
    }
    
    public ax<Map.Entry<K, V>> a() {
      return e().a();
    }
    
    public boolean contains(Object param1Object) {
      boolean bool = param1Object instanceof Map.Entry;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        Map.Entry entry = (Map.Entry)param1Object;
        param1Object = entry.getKey();
        entry = (Map.Entry)entry.getValue();
        bool1 = bool2;
        if (entry != null) {
          bool1 = bool2;
          if (entry.equals(this.a.get(param1Object)))
            bool1 = true; 
        } 
      } 
      return bool1;
    }
    
    boolean f() {
      return true;
    }
    
    s<Map.Entry<K, V>> i() {
      return new s<Map.Entry<K, V>>(this) {
          public Map.Entry<K, V> b(int param2Int) {
            Preconditions.checkElementIndex(param2Int, al.a.a(this.a));
            Object[] arrayOfObject = al.a.b(this.a);
            param2Int *= 2;
            return new AbstractMap.SimpleImmutableEntry<K, V>((K)arrayOfObject[al.a.c(this.a) + param2Int], (V)al.a.b(this.a)[param2Int + (al.a.c(this.a) ^ 0x1)]);
          }
          
          public boolean f() {
            return true;
          }
          
          public int size() {
            return al.a.a(this.a);
          }
        };
    }
    
    public int size() {
      return this.d;
    }
  }
  
  class null extends s<Map.Entry<K, V>> {
    null(al this$0) {}
    
    public Map.Entry<K, V> b(int param1Int) {
      Preconditions.checkElementIndex(param1Int, al.a.a(this.a));
      Object[] arrayOfObject = al.a.b(this.a);
      param1Int *= 2;
      return new AbstractMap.SimpleImmutableEntry<K, V>((K)arrayOfObject[al.a.c(this.a) + param1Int], (V)al.a.b(this.a)[param1Int + (al.a.c(this.a) ^ 0x1)]);
    }
    
    public boolean f() {
      return true;
    }
    
    public int size() {
      return al.a.a(this.a);
    }
  }
  
  static final class b<K> extends w<K> {
    private final transient u<K, ?> a;
    
    private final transient s<K> b;
    
    b(u<K, ?> param1u, s<K> param1s) {
      this.a = param1u;
      this.b = param1s;
    }
    
    int a(Object[] param1ArrayOfObject, int param1Int) {
      return e().a(param1ArrayOfObject, param1Int);
    }
    
    public ax<K> a() {
      return e().a();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      return (this.a.get(param1Object) != null);
    }
    
    public s<K> e() {
      return this.b;
    }
    
    boolean f() {
      return true;
    }
    
    public int size() {
      return this.a.size();
    }
  }
  
  static final class c extends s<Object> {
    private final transient Object[] a;
    
    private final transient int b;
    
    private final transient int c;
    
    c(Object[] param1ArrayOfObject, int param1Int1, int param1Int2) {
      this.a = param1ArrayOfObject;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    boolean f() {
      return true;
    }
    
    public Object get(int param1Int) {
      Preconditions.checkElementIndex(param1Int, this.c);
      return this.a[param1Int * 2 + this.b];
    }
    
    public int size() {
      return this.c;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\a\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */