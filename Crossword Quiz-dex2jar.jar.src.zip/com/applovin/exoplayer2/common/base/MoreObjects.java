package com.applovin.exoplayer2.common.base;

import java.util.Objects;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class MoreObjects {
  public static <T> T firstNonNull(@NullableDecl T paramT1, @NullableDecl T paramT2) {
    if (paramT1 != null)
      return paramT1; 
    Objects.requireNonNull(paramT2, "Both parameters are null");
    return paramT2;
  }
  
  public static ToStringHelper toStringHelper(Class<?> paramClass) {
    return new ToStringHelper(paramClass.getSimpleName());
  }
  
  public static ToStringHelper toStringHelper(Object paramObject) {
    return new ToStringHelper(paramObject.getClass().getSimpleName());
  }
  
  public static ToStringHelper toStringHelper(String paramString) {
    return new ToStringHelper(paramString);
  }
  
  public static final class ToStringHelper {
    private final String className;
    
    private final a holderHead;
    
    private a holderTail;
    
    private boolean omitNullValues;
    
    private ToStringHelper(String param1String) {
      a a1 = new a();
      this.holderHead = a1;
      this.holderTail = a1;
      this.omitNullValues = false;
      this.className = Preconditions.<String>checkNotNull(param1String);
    }
    
    private a addHolder() {
      a a1 = new a();
      this.holderTail.c = a1;
      this.holderTail = a1;
      return a1;
    }
    
    private ToStringHelper addHolder(@NullableDecl Object param1Object) {
      (addHolder()).b = param1Object;
      return this;
    }
    
    private ToStringHelper addHolder(String param1String, @NullableDecl Object param1Object) {
      a a1 = addHolder();
      a1.b = param1Object;
      a1.a = Preconditions.<String>checkNotNull(param1String);
      return this;
    }
    
    public ToStringHelper add(String param1String, char param1Char) {
      return addHolder(param1String, String.valueOf(param1Char));
    }
    
    public ToStringHelper add(String param1String, double param1Double) {
      return addHolder(param1String, String.valueOf(param1Double));
    }
    
    public ToStringHelper add(String param1String, float param1Float) {
      return addHolder(param1String, String.valueOf(param1Float));
    }
    
    public ToStringHelper add(String param1String, int param1Int) {
      return addHolder(param1String, String.valueOf(param1Int));
    }
    
    public ToStringHelper add(String param1String, long param1Long) {
      return addHolder(param1String, String.valueOf(param1Long));
    }
    
    public ToStringHelper add(String param1String, @NullableDecl Object param1Object) {
      return addHolder(param1String, param1Object);
    }
    
    public ToStringHelper add(String param1String, boolean param1Boolean) {
      return addHolder(param1String, String.valueOf(param1Boolean));
    }
    
    public ToStringHelper addValue(char param1Char) {
      return addHolder(String.valueOf(param1Char));
    }
    
    public ToStringHelper addValue(double param1Double) {
      return addHolder(String.valueOf(param1Double));
    }
    
    public ToStringHelper addValue(float param1Float) {
      return addHolder(String.valueOf(param1Float));
    }
    
    public ToStringHelper addValue(int param1Int) {
      return addHolder(String.valueOf(param1Int));
    }
    
    public ToStringHelper addValue(long param1Long) {
      return addHolder(String.valueOf(param1Long));
    }
    
    public ToStringHelper addValue(@NullableDecl Object param1Object) {
      return addHolder(param1Object);
    }
    
    public ToStringHelper addValue(boolean param1Boolean) {
      return addHolder(String.valueOf(param1Boolean));
    }
    
    public ToStringHelper omitNullValues() {
      this.omitNullValues = true;
      return this;
    }
    
    public String toString() {
      // Byte code:
      //   0: aload_0
      //   1: getfield omitNullValues : Z
      //   4: istore_1
      //   5: new java/lang/StringBuilder
      //   8: dup
      //   9: bipush #32
      //   11: invokespecial <init> : (I)V
      //   14: astore #5
      //   16: aload #5
      //   18: aload_0
      //   19: getfield className : Ljava/lang/String;
      //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   25: pop
      //   26: aload #5
      //   28: bipush #123
      //   30: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   33: pop
      //   34: aload_0
      //   35: getfield holderHead : Lcom/applovin/exoplayer2/common/base/MoreObjects$ToStringHelper$a;
      //   38: getfield c : Lcom/applovin/exoplayer2/common/base/MoreObjects$ToStringHelper$a;
      //   41: astore_2
      //   42: ldc ''
      //   44: astore_3
      //   45: aload_2
      //   46: ifnull -> 168
      //   49: aload_2
      //   50: getfield b : Ljava/lang/Object;
      //   53: astore #6
      //   55: iload_1
      //   56: ifeq -> 67
      //   59: aload_3
      //   60: astore #4
      //   62: aload #6
      //   64: ifnull -> 157
      //   67: aload #5
      //   69: aload_3
      //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   73: pop
      //   74: aload_2
      //   75: getfield a : Ljava/lang/String;
      //   78: ifnull -> 99
      //   81: aload #5
      //   83: aload_2
      //   84: getfield a : Ljava/lang/String;
      //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   90: pop
      //   91: aload #5
      //   93: bipush #61
      //   95: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   98: pop
      //   99: aload #6
      //   101: ifnull -> 145
      //   104: aload #6
      //   106: invokevirtual getClass : ()Ljava/lang/Class;
      //   109: invokevirtual isArray : ()Z
      //   112: ifeq -> 145
      //   115: iconst_1
      //   116: anewarray java/lang/Object
      //   119: dup
      //   120: iconst_0
      //   121: aload #6
      //   123: aastore
      //   124: invokestatic deepToString : ([Ljava/lang/Object;)Ljava/lang/String;
      //   127: astore_3
      //   128: aload #5
      //   130: aload_3
      //   131: iconst_1
      //   132: aload_3
      //   133: invokevirtual length : ()I
      //   136: iconst_1
      //   137: isub
      //   138: invokevirtual append : (Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;
      //   141: pop
      //   142: goto -> 153
      //   145: aload #5
      //   147: aload #6
      //   149: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   152: pop
      //   153: ldc ', '
      //   155: astore #4
      //   157: aload_2
      //   158: getfield c : Lcom/applovin/exoplayer2/common/base/MoreObjects$ToStringHelper$a;
      //   161: astore_2
      //   162: aload #4
      //   164: astore_3
      //   165: goto -> 45
      //   168: aload #5
      //   170: bipush #125
      //   172: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   175: pop
      //   176: aload #5
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: areturn
    }
    
    private static final class a {
      @NullableDecl
      String a;
      
      @NullableDecl
      Object b;
      
      @NullableDecl
      a c;
      
      private a() {}
    }
  }
  
  private static final class a {
    @NullableDecl
    String a;
    
    @NullableDecl
    Object b;
    
    @NullableDecl
    a c;
    
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\MoreObjects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */