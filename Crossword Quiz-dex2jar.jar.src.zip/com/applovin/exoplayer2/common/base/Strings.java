package com.applovin.exoplayer2.common.base;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class Strings {
  public static String commonPrefix(CharSequence paramCharSequence1, CharSequence paramCharSequence2) {
    Preconditions.checkNotNull(paramCharSequence1);
    Preconditions.checkNotNull(paramCharSequence2);
    int j = Math.min(paramCharSequence1.length(), paramCharSequence2.length());
    int i;
    for (i = 0; i < j && paramCharSequence1.charAt(i) == paramCharSequence2.charAt(i); i++);
    int k = i - 1;
    if (!validSurrogatePairAt(paramCharSequence1, k)) {
      j = i;
      if (validSurrogatePairAt(paramCharSequence2, k)) {
        j = i - 1;
        return paramCharSequence1.subSequence(0, j).toString();
      } 
      return paramCharSequence1.subSequence(0, j).toString();
    } 
    j = i - 1;
    return paramCharSequence1.subSequence(0, j).toString();
  }
  
  public static String commonSuffix(CharSequence paramCharSequence1, CharSequence paramCharSequence2) {
    Preconditions.checkNotNull(paramCharSequence1);
    Preconditions.checkNotNull(paramCharSequence2);
    int j = Math.min(paramCharSequence1.length(), paramCharSequence2.length());
    int i;
    for (i = 0; i < j && paramCharSequence1.charAt(paramCharSequence1.length() - i - 1) == paramCharSequence2.charAt(paramCharSequence2.length() - i - 1); i++);
    if (!validSurrogatePairAt(paramCharSequence1, paramCharSequence1.length() - i - 1)) {
      j = i;
      if (validSurrogatePairAt(paramCharSequence2, paramCharSequence2.length() - i - 1)) {
        j = i - 1;
        return paramCharSequence1.subSequence(paramCharSequence1.length() - j, paramCharSequence1.length()).toString();
      } 
      return paramCharSequence1.subSequence(paramCharSequence1.length() - j, paramCharSequence1.length()).toString();
    } 
    j = i - 1;
    return paramCharSequence1.subSequence(paramCharSequence1.length() - j, paramCharSequence1.length()).toString();
  }
  
  public static String lenientFormat(@NullableDecl String paramString, @NullableDecl Object... paramVarArgs) {
    Object[] arrayOfObject;
    String str = String.valueOf(paramString);
    int k = 0;
    if (paramVarArgs == null) {
      arrayOfObject = new Object[1];
      arrayOfObject[0] = "(Object[])null";
    } else {
      int m = 0;
      while (true) {
        arrayOfObject = paramVarArgs;
        if (m < paramVarArgs.length) {
          paramVarArgs[m] = lenientToString(paramVarArgs[m]);
          m++;
          continue;
        } 
        break;
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder(str.length() + arrayOfObject.length * 16);
    int j = 0;
    int i;
    for (i = k; i < arrayOfObject.length; i++) {
      k = str.indexOf("%s", j);
      if (k == -1)
        break; 
      stringBuilder.append(str, j, k);
      stringBuilder.append(arrayOfObject[i]);
      j = k + 2;
    } 
    stringBuilder.append(str, j, str.length());
    if (i < arrayOfObject.length) {
      stringBuilder.append(" [");
      j = i + 1;
      stringBuilder.append(arrayOfObject[i]);
      for (i = j; i < arrayOfObject.length; i++) {
        stringBuilder.append(", ");
        stringBuilder.append(arrayOfObject[i]);
      } 
      stringBuilder.append(']');
    } 
    return stringBuilder.toString();
  }
  
  private static String lenientToString(@NullableDecl Object paramObject) {
    try {
      return String.valueOf(paramObject);
    } catch (Exception exception) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(paramObject.getClass().getName());
      stringBuilder2.append('@');
      stringBuilder2.append(Integer.toHexString(System.identityHashCode(paramObject)));
      paramObject = stringBuilder2.toString();
      Logger logger = Logger.getLogger("com.applovin.exoplayer2.common.base.Strings");
      Level level = Level.WARNING;
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append("Exception during lenientFormat for ");
      stringBuilder3.append((String)paramObject);
      logger.log(level, stringBuilder3.toString(), exception);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("<");
      stringBuilder1.append((String)paramObject);
      stringBuilder1.append(" threw ");
      stringBuilder1.append(exception.getClass().getName());
      stringBuilder1.append(">");
      return stringBuilder1.toString();
    } 
  }
  
  public static String padEnd(String paramString, int paramInt, char paramChar) {
    Preconditions.checkNotNull(paramString);
    if (paramString.length() >= paramInt)
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder(paramInt);
    stringBuilder.append(paramString);
    for (int i = paramString.length(); i < paramInt; i++)
      stringBuilder.append(paramChar); 
    return stringBuilder.toString();
  }
  
  public static String padStart(String paramString, int paramInt, char paramChar) {
    Preconditions.checkNotNull(paramString);
    if (paramString.length() >= paramInt)
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder(paramInt);
    for (int i = paramString.length(); i < paramInt; i++)
      stringBuilder.append(paramChar); 
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public static String repeat(String paramString, int paramInt) {
    Preconditions.checkNotNull(paramString);
    boolean bool = true;
    if (paramInt <= 1) {
      if (paramInt < 0)
        bool = false; 
      Preconditions.checkArgument(bool, "invalid count: %s", paramInt);
      if (paramInt == 0)
        paramString = ""; 
      return paramString;
    } 
    int i = paramString.length();
    long l = i * paramInt;
    int j = (int)l;
    if (j == l) {
      char[] arrayOfChar = new char[j];
      paramString.getChars(0, i, arrayOfChar, 0);
      paramInt = i;
      while (true) {
        i = j - paramInt;
        if (paramInt < i) {
          System.arraycopy(arrayOfChar, 0, arrayOfChar, paramInt, paramInt);
          paramInt <<= 1;
          continue;
        } 
        System.arraycopy(arrayOfChar, 0, arrayOfChar, paramInt, i);
        return new String(arrayOfChar);
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Required array size too large: ");
    stringBuilder.append(l);
    ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException = new ArrayIndexOutOfBoundsException(stringBuilder.toString());
    throw arrayIndexOutOfBoundsException;
  }
  
  static boolean validSurrogatePairAt(CharSequence paramCharSequence, int paramInt) {
    return (paramInt >= 0 && paramInt <= paramCharSequence.length() - 2 && Character.isHighSurrogate(paramCharSequence.charAt(paramInt)) && Character.isLowSurrogate(paramCharSequence.charAt(paramInt + 1)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Strings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */