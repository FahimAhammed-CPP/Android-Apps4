package com.applovin.exoplayer2.common.base;

import com.google.errorprone.annotations.concurrent.LazyInit;
import java.io.Serializable;
import java.util.Iterator;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class Converter<A, B> implements Function<A, B> {
  private final boolean handleNullAutomatically;
  
  @LazyInit
  @MonotonicNonNullDecl
  private transient Converter<B, A> reverse;
  
  protected Converter() {
    this(true);
  }
  
  Converter(boolean paramBoolean) {
    this.handleNullAutomatically = paramBoolean;
  }
  
  public static <A, B> Converter<A, B> from(Function<? super A, ? extends B> paramFunction, Function<? super B, ? extends A> paramFunction1) {
    return new b<A, B>(paramFunction, paramFunction1);
  }
  
  public static <T> Converter<T, T> identity() {
    return c.a;
  }
  
  public final <C> Converter<A, C> andThen(Converter<B, C> paramConverter) {
    return doAndThen(paramConverter);
  }
  
  @Deprecated
  @NullableDecl
  public final B apply(@NullableDecl A paramA) {
    return convert(paramA);
  }
  
  @NullableDecl
  public final B convert(@NullableDecl A paramA) {
    return correctedDoForward(paramA);
  }
  
  public Iterable<B> convertAll(Iterable<? extends A> paramIterable) {
    Preconditions.checkNotNull(paramIterable, "fromIterable");
    return new Iterable<B>(this, paramIterable) {
        public Iterator<B> iterator() {
          return new Iterator<B>(this) {
              private final Iterator<? extends A> b;
              
              public boolean hasNext() {
                return this.b.hasNext();
              }
              
              public B next() {
                return (B)this.a.b.convert(this.b.next());
              }
              
              public void remove() {
                this.b.remove();
              }
            };
        }
      };
  }
  
  @NullableDecl
  A correctedDoBackward(@NullableDecl B paramB) {
    return this.handleNullAutomatically ? ((paramB == null) ? null : Preconditions.checkNotNull(doBackward(paramB))) : doBackward(paramB);
  }
  
  @NullableDecl
  B correctedDoForward(@NullableDecl A paramA) {
    return this.handleNullAutomatically ? ((paramA == null) ? null : Preconditions.checkNotNull(doForward(paramA))) : doForward(paramA);
  }
  
  <C> Converter<A, C> doAndThen(Converter<B, C> paramConverter) {
    return new a<A, Object, C>(this, Preconditions.<Converter<?, C>>checkNotNull(paramConverter));
  }
  
  protected abstract A doBackward(B paramB);
  
  protected abstract B doForward(A paramA);
  
  public boolean equals(@NullableDecl Object paramObject) {
    return super.equals(paramObject);
  }
  
  public Converter<B, A> reverse() {
    Converter<B, A> converter2 = this.reverse;
    Converter<B, A> converter1 = converter2;
    if (converter2 == null) {
      converter1 = new d<A, B>(this);
      this.reverse = converter1;
    } 
    return converter1;
  }
  
  private static final class a<A, B, C> extends Converter<A, C> implements Serializable {
    final Converter<A, B> a;
    
    final Converter<B, C> b;
    
    a(Converter<A, B> param1Converter, Converter<B, C> param1Converter1) {
      this.a = param1Converter;
      this.b = param1Converter1;
    }
    
    @NullableDecl
    A correctedDoBackward(@NullableDecl C param1C) {
      return this.a.correctedDoBackward(this.b.correctedDoBackward(param1C));
    }
    
    @NullableDecl
    C correctedDoForward(@NullableDecl A param1A) {
      return this.b.correctedDoForward(this.a.correctedDoForward(param1A));
    }
    
    protected A doBackward(C param1C) {
      throw new AssertionError();
    }
    
    protected C doForward(A param1A) {
      throw new AssertionError();
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof a;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        bool1 = bool2;
        if (this.a.equals(((a)param1Object).a)) {
          bool1 = bool2;
          if (this.b.equals(((a)param1Object).b))
            bool1 = true; 
        } 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return this.a.hashCode() * 31 + this.b.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(".andThen(");
      stringBuilder.append(this.b);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static final class b<A, B> extends Converter<A, B> implements Serializable {
    private final Function<? super A, ? extends B> a;
    
    private final Function<? super B, ? extends A> b;
    
    private b(Function<? super A, ? extends B> param1Function, Function<? super B, ? extends A> param1Function1) {
      this.a = Preconditions.<Function<? super A, ? extends B>>checkNotNull(param1Function);
      this.b = Preconditions.<Function<? super B, ? extends A>>checkNotNull(param1Function1);
    }
    
    protected A doBackward(B param1B) {
      return this.b.apply(param1B);
    }
    
    protected B doForward(A param1A) {
      return this.a.apply(param1A);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      boolean bool = param1Object instanceof b;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        param1Object = param1Object;
        bool1 = bool2;
        if (this.a.equals(((b)param1Object).a)) {
          bool1 = bool2;
          if (this.b.equals(((b)param1Object).b))
            bool1 = true; 
        } 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return this.a.hashCode() * 31 + this.b.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Converter.from(");
      stringBuilder.append(this.a);
      stringBuilder.append(", ");
      stringBuilder.append(this.b);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private static final class c<T> extends Converter<T, T> implements Serializable {
    static final c a = new c();
    
    public c<T> a() {
      return this;
    }
    
    <S> Converter<T, S> doAndThen(Converter<T, S> param1Converter) {
      return Preconditions.<Converter<T, S>>checkNotNull(param1Converter, "otherConverter");
    }
    
    protected T doBackward(T param1T) {
      return param1T;
    }
    
    protected T doForward(T param1T) {
      return param1T;
    }
    
    public String toString() {
      return "Converter.identity()";
    }
  }
  
  private static final class d<A, B> extends Converter<B, A> implements Serializable {
    final Converter<A, B> a;
    
    d(Converter<A, B> param1Converter) {
      this.a = param1Converter;
    }
    
    @NullableDecl
    B correctedDoBackward(@NullableDecl A param1A) {
      return this.a.correctedDoForward(param1A);
    }
    
    @NullableDecl
    A correctedDoForward(@NullableDecl B param1B) {
      return this.a.correctedDoBackward(param1B);
    }
    
    protected B doBackward(A param1A) {
      throw new AssertionError();
    }
    
    protected A doForward(B param1B) {
      throw new AssertionError();
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object instanceof d) {
        param1Object = param1Object;
        return this.a.equals(((d)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() ^ 0xFFFFFFFF;
    }
    
    public Converter<A, B> reverse() {
      return this.a;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(".reverse()");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Converter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */