package com.applovin.exoplayer2.common.base;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class Optional<T> implements Serializable {
  private static final long serialVersionUID = 0L;
  
  public static <T> Optional<T> absent() {
    return a.a();
  }
  
  public static <T> Optional<T> fromNullable(@NullableDecl T paramT) {
    return (paramT == null) ? absent() : new d<T>(paramT);
  }
  
  public static <T> Optional<T> of(T paramT) {
    return new d<T>(Preconditions.checkNotNull(paramT));
  }
  
  public static <T> Iterable<T> presentInstances(Iterable<? extends Optional<? extends T>> paramIterable) {
    Preconditions.checkNotNull(paramIterable);
    return new Iterable<T>(paramIterable) {
        public Iterator<T> iterator() {
          return new b<T>(this) {
              private final Iterator<? extends Optional<? extends T>> b;
              
              protected T a() {
                while (this.b.hasNext()) {
                  Optional<T> optional = (Optional)this.b.next();
                  if (optional.isPresent())
                    return optional.get(); 
                } 
                return b();
              }
            };
        }
      };
  }
  
  public abstract Set<T> asSet();
  
  public abstract boolean equals(@NullableDecl Object paramObject);
  
  public abstract T get();
  
  public abstract int hashCode();
  
  public abstract boolean isPresent();
  
  public abstract Optional<T> or(Optional<? extends T> paramOptional);
  
  public abstract T or(Supplier<? extends T> paramSupplier);
  
  public abstract T or(T paramT);
  
  @NullableDecl
  public abstract T orNull();
  
  public abstract String toString();
  
  public abstract <V> Optional<V> transform(Function<? super T, V> paramFunction);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Optional.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */