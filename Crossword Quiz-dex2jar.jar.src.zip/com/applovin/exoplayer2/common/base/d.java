package com.applovin.exoplayer2.common.base;

import java.util.Collections;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class d<T> extends Optional<T> {
  private final T a;
  
  d(T paramT) {
    this.a = paramT;
  }
  
  public Set<T> asSet() {
    return Collections.singleton(this.a);
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    if (paramObject instanceof d) {
      paramObject = paramObject;
      return this.a.equals(((d)paramObject).a);
    } 
    return false;
  }
  
  public T get() {
    return this.a;
  }
  
  public int hashCode() {
    return this.a.hashCode() + 1502476572;
  }
  
  public boolean isPresent() {
    return true;
  }
  
  public Optional<T> or(Optional<? extends T> paramOptional) {
    Preconditions.checkNotNull(paramOptional);
    return this;
  }
  
  public T or(Supplier<? extends T> paramSupplier) {
    Preconditions.checkNotNull(paramSupplier);
    return this.a;
  }
  
  public T or(T paramT) {
    Preconditions.checkNotNull(paramT, "use Optional.orNull() instead of Optional.or(null)");
    return this.a;
  }
  
  public T orNull() {
    return this.a;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Optional.of(");
    stringBuilder.append(this.a);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public <V> Optional<V> transform(Function<? super T, V> paramFunction) {
    return new d(Preconditions.checkNotNull((T)paramFunction.apply(this.a), "the Function passed to Optional.transform() must not return null."));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */