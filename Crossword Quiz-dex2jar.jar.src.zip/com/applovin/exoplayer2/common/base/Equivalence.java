package com.applovin.exoplayer2.common.base;

import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class Equivalence<T> {
  public static Equivalence<Object> equals() {
    return a.a;
  }
  
  public static Equivalence<Object> identity() {
    return c.a;
  }
  
  protected abstract boolean doEquivalent(T paramT1, T paramT2);
  
  protected abstract int doHash(T paramT);
  
  public final boolean equivalent(@NullableDecl T paramT1, @NullableDecl T paramT2) {
    return (paramT1 == paramT2) ? true : ((paramT1 == null || paramT2 == null) ? false : doEquivalent(paramT1, paramT2));
  }
  
  public final Predicate<T> equivalentTo(@NullableDecl T paramT) {
    return new b<T>(this, paramT);
  }
  
  public final int hash(@NullableDecl T paramT) {
    return (paramT == null) ? 0 : doHash(paramT);
  }
  
  public final <S extends T> Wrapper<S> wrap(@NullableDecl S paramS) {
    return new Wrapper<S>(this, paramS);
  }
  
  public static final class Wrapper<T> implements Serializable {
    private static final long serialVersionUID = 0L;
    
    private final Equivalence<? super T> equivalence;
    
    @NullableDecl
    private final T reference;
    
    private Wrapper(Equivalence<? super T> param1Equivalence, @NullableDecl T param1T) {
      this.equivalence = Preconditions.<Equivalence<? super T>>checkNotNull(param1Equivalence);
      this.reference = param1T;
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object == this)
        return true; 
      if (param1Object instanceof Wrapper) {
        param1Object = param1Object;
        if (this.equivalence.equals(((Wrapper)param1Object).equivalence))
          return this.equivalence.equivalent(this.reference, ((Wrapper)param1Object).reference); 
      } 
      return false;
    }
    
    @NullableDecl
    public T get() {
      return this.reference;
    }
    
    public int hashCode() {
      return this.equivalence.hash(this.reference);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.equivalence);
      stringBuilder.append(".wrap(");
      stringBuilder.append(this.reference);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static final class a extends Equivalence<Object> implements Serializable {
    static final a a = new a();
    
    protected boolean doEquivalent(Object param1Object1, Object param1Object2) {
      return param1Object1.equals(param1Object2);
    }
    
    protected int doHash(Object param1Object) {
      return param1Object.hashCode();
    }
  }
  
  private static final class b<T> implements Predicate<T>, Serializable {
    private final Equivalence<T> a;
    
    @NullableDecl
    private final T b;
    
    b(Equivalence<T> param1Equivalence, @NullableDecl T param1T) {
      this.a = Preconditions.<Equivalence<T>>checkNotNull(param1Equivalence);
      this.b = param1T;
    }
    
    public boolean apply(@NullableDecl T param1T) {
      return this.a.equivalent(param1T, this.b);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object instanceof b) {
        param1Object = param1Object;
        return (this.a.equals(((b)param1Object).a) && Objects.equal(this.b, ((b)param1Object).b));
      } 
      return false;
    }
    
    public int hashCode() {
      return Objects.hashCode(new Object[] { this.a, this.b });
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(".equivalentTo(");
      stringBuilder.append(this.b);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static final class c extends Equivalence<Object> implements Serializable {
    static final c a = new c();
    
    protected boolean doEquivalent(Object param1Object1, Object param1Object2) {
      return false;
    }
    
    protected int doHash(Object param1Object) {
      return System.identityHashCode(param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Equivalence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */