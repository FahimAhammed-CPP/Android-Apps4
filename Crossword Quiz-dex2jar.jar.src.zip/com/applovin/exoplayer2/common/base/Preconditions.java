package com.applovin.exoplayer2.common.base;

import java.util.Objects;
import org.checkerframework.checker.nullness.compatqual.NonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class Preconditions {
  private static String badElementIndex(int paramInt1, int paramInt2, @NullableDecl String paramString) {
    if (paramInt1 < 0)
      return Strings.lenientFormat("%s (%s) must not be negative", new Object[] { paramString, Integer.valueOf(paramInt1) }); 
    if (paramInt2 >= 0)
      return Strings.lenientFormat("%s (%s) must be less than size (%s)", new Object[] { paramString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("negative size: ");
    stringBuilder.append(paramInt2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static String badPositionIndex(int paramInt1, int paramInt2, @NullableDecl String paramString) {
    if (paramInt1 < 0)
      return Strings.lenientFormat("%s (%s) must not be negative", new Object[] { paramString, Integer.valueOf(paramInt1) }); 
    if (paramInt2 >= 0)
      return Strings.lenientFormat("%s (%s) must not be greater than size (%s)", new Object[] { paramString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("negative size: ");
    stringBuilder.append(paramInt2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static String badPositionIndexes(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < 0 || paramInt1 > paramInt3) ? badPositionIndex(paramInt1, paramInt3, "start index") : ((paramInt2 < 0 || paramInt2 > paramInt3) ? badPositionIndex(paramInt2, paramInt3, "end index") : Strings.lenientFormat("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) }));
  }
  
  public static void checkArgument(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException();
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, char paramChar1, char paramChar2) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar1), Character.valueOf(paramChar2) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, char paramChar, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Integer.valueOf(paramInt) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, char paramChar, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Long.valueOf(paramLong) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, char paramChar, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), paramObject }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, int paramInt, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Character.valueOf(paramChar) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, int paramInt1, int paramInt2) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, int paramInt, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, int paramInt, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), paramObject }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, long paramLong, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Character.valueOf(paramChar) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, long paramLong, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Integer.valueOf(paramInt) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, long paramLong1, long paramLong2) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong1), Long.valueOf(paramLong2) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, long paramLong, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), paramObject }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject, Character.valueOf(paramChar) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject, Integer.valueOf(paramInt) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject, Long.valueOf(paramLong) }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2 }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3 }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3, @NullableDecl Object paramObject4) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3, paramObject4 }));
  }
  
  public static void checkArgument(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object... paramVarArgs) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(Strings.lenientFormat(paramString, paramVarArgs));
  }
  
  public static int checkElementIndex(int paramInt1, int paramInt2) {
    return checkElementIndex(paramInt1, paramInt2, "index");
  }
  
  public static int checkElementIndex(int paramInt1, int paramInt2, @NullableDecl String paramString) {
    if (paramInt1 >= 0 && paramInt1 < paramInt2)
      return paramInt1; 
    throw new IndexOutOfBoundsException(badElementIndex(paramInt1, paramInt2, paramString));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, char paramChar) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, char paramChar1, char paramChar2) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar1), Character.valueOf(paramChar2) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, char paramChar, int paramInt) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Integer.valueOf(paramInt) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, char paramChar, long paramLong) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Long.valueOf(paramLong) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, char paramChar, @NullableDecl Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), paramObject }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, int paramInt) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, int paramInt, char paramChar) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Character.valueOf(paramChar) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, int paramInt1, int paramInt2) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, int paramInt, long paramLong) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, int paramInt, @NullableDecl Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), paramObject }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, long paramLong) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, long paramLong, char paramChar) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Character.valueOf(paramChar) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, long paramLong, int paramInt) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Integer.valueOf(paramInt) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, long paramLong1, long paramLong2) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong1), Long.valueOf(paramLong2) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, long paramLong, @NullableDecl Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), paramObject }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject, char paramChar) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject, Character.valueOf(paramChar) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject, int paramInt) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject, Integer.valueOf(paramInt) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject, long paramLong) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject, Long.valueOf(paramLong) }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2 }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3 }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3, @NullableDecl Object paramObject4) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3, paramObject4 }));
  }
  
  @NonNullDecl
  public static <T> T checkNotNull(@NonNullDecl T paramT, @NullableDecl String paramString, @NullableDecl Object... paramVarArgs) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(Strings.lenientFormat(paramString, paramVarArgs));
  }
  
  public static int checkPositionIndex(int paramInt1, int paramInt2) {
    return checkPositionIndex(paramInt1, paramInt2, "index");
  }
  
  public static int checkPositionIndex(int paramInt1, int paramInt2, @NullableDecl String paramString) {
    if (paramInt1 >= 0 && paramInt1 <= paramInt2)
      return paramInt1; 
    throw new IndexOutOfBoundsException(badPositionIndex(paramInt1, paramInt2, paramString));
  }
  
  public static void checkPositionIndexes(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 >= 0 && paramInt2 >= paramInt1 && paramInt2 <= paramInt3)
      return; 
    throw new IndexOutOfBoundsException(badPositionIndexes(paramInt1, paramInt2, paramInt3));
  }
  
  public static void checkState(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException();
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(String.valueOf(paramObject));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, char paramChar1, char paramChar2) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar1), Character.valueOf(paramChar2) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, char paramChar, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Integer.valueOf(paramInt) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, char paramChar, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), Long.valueOf(paramLong) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, char paramChar, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Character.valueOf(paramChar), paramObject }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, int paramInt, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Character.valueOf(paramChar) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, int paramInt1, int paramInt2) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, int paramInt, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, int paramInt, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Integer.valueOf(paramInt), paramObject }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, long paramLong, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Character.valueOf(paramChar) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, long paramLong, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), Integer.valueOf(paramInt) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, long paramLong1, long paramLong2) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong1), Long.valueOf(paramLong2) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, long paramLong, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { Long.valueOf(paramLong), paramObject }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, char paramChar) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject, Character.valueOf(paramChar) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, int paramInt) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject, Integer.valueOf(paramInt) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject, long paramLong) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject, Long.valueOf(paramLong) }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2 }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3 }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object paramObject1, @NullableDecl Object paramObject2, @NullableDecl Object paramObject3, @NullableDecl Object paramObject4) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, new Object[] { paramObject1, paramObject2, paramObject3, paramObject4 }));
  }
  
  public static void checkState(boolean paramBoolean, @NullableDecl String paramString, @NullableDecl Object... paramVarArgs) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(Strings.lenientFormat(paramString, paramVarArgs));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\base\Preconditions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */