package com.applovin.exoplayer2.common.b;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class c {
  public static int a(int paramInt) {
    return paramInt;
  }
  
  public static int a(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2) ? -1 : ((paramInt1 > paramInt2) ? 1 : 0);
  }
  
  public static int a(long paramLong) {
    boolean bool;
    int i = (int)paramLong;
    if (i == paramLong) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool, "Out of range: %s", paramLong);
    return i;
  }
  
  public static List<Integer> a(int... paramVarArgs) {
    return (paramVarArgs.length == 0) ? Collections.emptyList() : new a(paramVarArgs);
  }
  
  public static int[] a(Collection<? extends Number> paramCollection) {
    if (paramCollection instanceof a)
      return ((a)paramCollection).a(); 
    Object[] arrayOfObject = paramCollection.toArray();
    int j = arrayOfObject.length;
    int[] arrayOfInt = new int[j];
    for (int i = 0; i < j; i++)
      arrayOfInt[i] = ((Number)Preconditions.checkNotNull(arrayOfObject[i])).intValue(); 
    return arrayOfInt;
  }
  
  private static int c(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    while (paramInt2 < paramInt3) {
      if (paramArrayOfint[paramInt2] == paramInt1)
        return paramInt2; 
      paramInt2++;
    } 
    return -1;
  }
  
  private static int d(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3) {
    while (--paramInt3 >= paramInt2) {
      if (paramArrayOfint[paramInt3] == paramInt1)
        return paramInt3; 
      paramInt3--;
    } 
    return -1;
  }
  
  private static class a extends AbstractList<Integer> implements Serializable, RandomAccess {
    final int[] a;
    
    final int b;
    
    final int c;
    
    a(int[] param1ArrayOfint) {
      this(param1ArrayOfint, 0, param1ArrayOfint.length);
    }
    
    a(int[] param1ArrayOfint, int param1Int1, int param1Int2) {
      this.a = param1ArrayOfint;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public Integer a(int param1Int) {
      Preconditions.checkElementIndex(param1Int, size());
      return Integer.valueOf(this.a[this.b + param1Int]);
    }
    
    public Integer a(int param1Int, Integer param1Integer) {
      Preconditions.checkElementIndex(param1Int, size());
      int[] arrayOfInt = this.a;
      int i = this.b;
      int j = arrayOfInt[i + param1Int];
      arrayOfInt[i + param1Int] = ((Integer)Preconditions.checkNotNull(param1Integer)).intValue();
      return Integer.valueOf(j);
    }
    
    int[] a() {
      return Arrays.copyOfRange(this.a, this.b, this.c);
    }
    
    public boolean contains(Object param1Object) {
      return (param1Object instanceof Integer && c.a(this.a, ((Integer)param1Object).intValue(), this.b, this.c) != -1);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object == this)
        return true; 
      if (param1Object instanceof a) {
        param1Object = param1Object;
        int j = size();
        if (param1Object.size() != j)
          return false; 
        for (int i = 0; i < j; i++) {
          if (this.a[this.b + i] != ((a)param1Object).a[((a)param1Object).b + i])
            return false; 
        } 
        return true;
      } 
      return super.equals(param1Object);
    }
    
    public int hashCode() {
      int i = this.b;
      int j = 1;
      while (i < this.c) {
        j = j * 31 + c.a(this.a[i]);
        i++;
      } 
      return j;
    }
    
    public int indexOf(Object param1Object) {
      if (param1Object instanceof Integer) {
        int i = c.a(this.a, ((Integer)param1Object).intValue(), this.b, this.c);
        if (i >= 0)
          return i - this.b; 
      } 
      return -1;
    }
    
    public boolean isEmpty() {
      return false;
    }
    
    public int lastIndexOf(Object param1Object) {
      if (param1Object instanceof Integer) {
        int i = c.b(this.a, ((Integer)param1Object).intValue(), this.b, this.c);
        if (i >= 0)
          return i - this.b; 
      } 
      return -1;
    }
    
    public int size() {
      return this.c - this.b;
    }
    
    public List<Integer> subList(int param1Int1, int param1Int2) {
      Preconditions.checkPositionIndexes(param1Int1, param1Int2, size());
      if (param1Int1 == param1Int2)
        return Collections.emptyList(); 
      int[] arrayOfInt = this.a;
      int i = this.b;
      return new a(arrayOfInt, param1Int1 + i, i + param1Int2);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(size() * 5);
      stringBuilder.append('[');
      stringBuilder.append(this.a[this.b]);
      int i = this.b;
      while (true) {
        if (++i < this.c) {
          stringBuilder.append(", ");
          stringBuilder.append(this.a[i]);
          continue;
        } 
        stringBuilder.append(']');
        return stringBuilder.toString();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\exoplayer2\common\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */