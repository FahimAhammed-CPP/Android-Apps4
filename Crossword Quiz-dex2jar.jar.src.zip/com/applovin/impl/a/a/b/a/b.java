package com.applovin.impl.a.a.b.a;

import android.app.Activity;
import android.content.Context;
import com.applovin.impl.a.a.b.a.a.a;
import com.applovin.impl.mediation.debugger.ui.d.c;
import com.applovin.impl.mediation.debugger.ui.d.d;
import com.applovin.impl.mediation.debugger.ui.d.e;
import com.applovin.impl.sdk.n;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class b extends d {
  private n a;
  
  private List<com.applovin.impl.a.a.a.a> b;
  
  private final AtomicBoolean d = new AtomicBoolean();
  
  private List<c> e = new ArrayList<c>();
  
  public b(Context paramContext) {
    super(paramContext);
  }
  
  private List<c> a(List<com.applovin.impl.a.a.a.a> paramList) {
    ArrayList<a> arrayList = new ArrayList(paramList.size());
    Iterator<com.applovin.impl.a.a.a.a> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(new a(iterator.next(), this.c)); 
    return (List)arrayList;
  }
  
  protected int a(int paramInt) {
    return this.e.size();
  }
  
  public void a() {
    this.d.compareAndSet(true, false);
  }
  
  public void a(List<com.applovin.impl.a.a.a.a> paramList, n paramn) {
    this.a = paramn;
    this.b = paramList;
    if (!(this.c instanceof Activity)) {
      Activity activity = paramn.ar();
      if (activity != null)
        this.c = (Context)activity; 
    } 
    if (paramList != null && this.d.compareAndSet(false, true))
      this.e = a(this.b); 
    AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
          public void run() {
            this.a.notifyDataSetChanged();
          }
        });
  }
  
  protected c b(int paramInt) {
    return (c)new e("RECENT ADS");
  }
  
  public boolean b() {
    return (this.e.size() == 0);
  }
  
  public n c() {
    return this.a;
  }
  
  protected List<c> c(int paramInt) {
    return this.e;
  }
  
  public List<com.applovin.impl.a.a.a.a> d() {
    return this.b;
  }
  
  protected int e() {
    return a.b.ordinal();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CreativeDebuggerListAdapter{isInitialized=");
    stringBuilder.append(this.d.get());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public enum a {
    a, b;
    
    static {
      a a1 = new a("RECENT_ADS", 0);
      a = a1;
      a a2 = new a("COUNT", 1);
      b = a2;
      c = new a[] { a1, a2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\a\a\b\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */