package com.applovin.impl.sdk.a;

import android.content.Context;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.v;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.iab.omid.library.applovin.Omid;
import com.iab.omid.library.applovin.ScriptInjector;
import com.iab.omid.library.applovin.adsession.Partner;

public class f {
  private final n a;
  
  private final Context b;
  
  private String c;
  
  public f(n paramn) {
    this.a = paramn;
    this.b = paramn.P();
  }
  
  public String a(String paramString) {
    try {
      return ScriptInjector.injectScriptContentIntoHtml(this.c, paramString);
    } finally {
      Exception exception = null;
      this.a.D();
      if (v.a())
        this.a.D().b("OpenMeasurementService", "Failed to inject JavaScript SDK into HTML", exception); 
    } 
  }
  
  public void a() {
    if (((Boolean)this.a.a(b.az)).booleanValue()) {
      this.a.D();
      if (v.a()) {
        v v = this.a.D();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Initializing Open Measurement SDK v");
        stringBuilder.append(c());
        stringBuilder.append("...");
        v.b("OpenMeasurementService", stringBuilder.toString());
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              // Byte code:
              //   0: invokestatic currentTimeMillis : ()J
              //   3: lstore_1
              //   4: aload_0
              //   5: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   8: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   11: invokestatic activate : (Landroid/content/Context;)V
              //   14: aload_0
              //   15: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   18: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/n;
              //   21: invokevirtual D : ()Lcom/applovin/impl/sdk/v;
              //   24: pop
              //   25: invokestatic a : ()Z
              //   28: ifeq -> 125
              //   31: aload_0
              //   32: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   35: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/n;
              //   38: invokevirtual D : ()Lcom/applovin/impl/sdk/v;
              //   41: astore #4
              //   43: new java/lang/StringBuilder
              //   46: dup
              //   47: invokespecial <init> : ()V
              //   50: astore #5
              //   52: aload #5
              //   54: ldc 'Init '
              //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   59: pop
              //   60: aload_0
              //   61: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   64: invokevirtual b : ()Z
              //   67: ifeq -> 76
              //   70: ldc 'succeeded'
              //   72: astore_3
              //   73: goto -> 79
              //   76: ldc 'failed'
              //   78: astore_3
              //   79: aload #5
              //   81: aload_3
              //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   85: pop
              //   86: aload #5
              //   88: ldc ' and took '
              //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   93: pop
              //   94: aload #5
              //   96: invokestatic currentTimeMillis : ()J
              //   99: lload_1
              //   100: lsub
              //   101: invokevirtual append : (J)Ljava/lang/StringBuilder;
              //   104: pop
              //   105: aload #5
              //   107: ldc 'ms'
              //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   112: pop
              //   113: aload #4
              //   115: ldc 'OpenMeasurementService'
              //   117: aload #5
              //   119: invokevirtual toString : ()Ljava/lang/String;
              //   122: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
              //   125: new java/io/BufferedReader
              //   128: dup
              //   129: new java/io/InputStreamReader
              //   132: dup
              //   133: aload_0
              //   134: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   137: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   140: invokevirtual getResources : ()Landroid/content/res/Resources;
              //   143: getstatic com/applovin/sdk/R$raw.omsdk_v_1_0 : I
              //   146: invokevirtual openRawResource : (I)Ljava/io/InputStream;
              //   149: invokespecial <init> : (Ljava/io/InputStream;)V
              //   152: invokespecial <init> : (Ljava/io/Reader;)V
              //   155: astore_3
              //   156: new java/lang/StringBuilder
              //   159: dup
              //   160: invokespecial <init> : ()V
              //   163: astore #4
              //   165: aload_3
              //   166: invokevirtual readLine : ()Ljava/lang/String;
              //   169: astore #5
              //   171: aload #5
              //   173: ifnull -> 187
              //   176: aload #4
              //   178: aload #5
              //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   183: pop
              //   184: goto -> 165
              //   187: aload_0
              //   188: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   191: aload #4
              //   193: invokevirtual toString : ()Ljava/lang/String;
              //   196: invokestatic a : (Lcom/applovin/impl/sdk/a/f;Ljava/lang/String;)Ljava/lang/String;
              //   199: pop
              //   200: aload_3
              //   201: invokevirtual close : ()V
              //   204: return
              //   205: astore #4
              //   207: ldc 'OpenMeasurementService'
              //   209: ldc 'Failed to load JavaScript Open Measurement SDK'
              //   211: aload #4
              //   213: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   216: pop
              //   217: aload_3
              //   218: invokevirtual close : ()V
              //   221: return
              //   222: astore_3
              //   223: ldc 'OpenMeasurementService'
              //   225: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   227: aload_3
              //   228: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   231: pop
              //   232: return
              //   233: astore #4
              //   235: aload_3
              //   236: invokevirtual close : ()V
              //   239: goto -> 252
              //   242: astore_3
              //   243: ldc 'OpenMeasurementService'
              //   245: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   247: aload_3
              //   248: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   251: pop
              //   252: aload #4
              //   254: athrow
              //   255: astore_3
              //   256: aload_0
              //   257: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   260: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/n;
              //   263: invokevirtual D : ()Lcom/applovin/impl/sdk/v;
              //   266: pop
              //   267: invokestatic a : ()Z
              //   270: ifeq -> 291
              //   273: aload_0
              //   274: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   277: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/n;
              //   280: invokevirtual D : ()Lcom/applovin/impl/sdk/v;
              //   283: ldc 'OpenMeasurementService'
              //   285: ldc 'Failed to retrieve resource omskd_v_1_0.js'
              //   287: aload_3
              //   288: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
              //   291: return
              // Exception table:
              //   from	to	target	type
              //   125	156	255	finally
              //   156	165	205	finally
              //   165	171	205	finally
              //   176	184	205	finally
              //   187	200	205	finally
              //   200	204	222	java/io/IOException
              //   207	217	233	finally
              //   217	221	222	java/io/IOException
              //   235	239	242	java/io/IOException
            }
          });
    } 
  }
  
  public boolean b() {
    return Omid.isActive();
  }
  
  public String c() {
    return Omid.getVersion();
  }
  
  public Partner d() {
    return Partner.createPartner((String)this.a.a(b.aA), AppLovinSdk.VERSION);
  }
  
  public String e() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */