package com.applovin.impl.sdk;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.sdk.AppLovinSdkUtils;
import com.safedk.android.internal.partials.AppLovinNetworkBridge;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class f {
  private static final int a = (int)TimeUnit.SECONDS.toMillis(30L);
  
  private static final f m = new f();
  
  private final AtomicLong b = new AtomicLong(0L);
  
  private Handler c;
  
  private final HandlerThread d = new HandlerThread("applovin-anr-detector");
  
  private Handler e;
  
  private final AtomicBoolean f = new AtomicBoolean();
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  private n h;
  
  private Thread i;
  
  private long j = TimeUnit.SECONDS.toMillis(4L);
  
  private long k = TimeUnit.SECONDS.toMillis(3L);
  
  private long l = TimeUnit.SECONDS.toMillis(3L);
  
  private static String a(String paramString) {
    try {
      return URLEncoder.encode(paramString, "UTF-8");
    } finally {
      paramString = null;
    } 
  }
  
  private void a() {
    if (this.g.get())
      this.f.set(true); 
  }
  
  public static void a(n paramn) {
    if (paramn != null) {
      if (((Boolean)paramn.a(b.fa)).booleanValue() && !Utils.isPubInDebugMode(paramn.P(), paramn)) {
        m.b(paramn);
        return;
      } 
      m.a();
    } 
  }
  
  private void b() {
    try {
      HttpURLConnection httpURLConnection = (HttpURLConnection)c().openConnection();
      int i = a;
      httpURLConnection.setConnectTimeout(i);
      httpURLConnection.setReadTimeout(i);
      httpURLConnection.setDefaultUseCaches(false);
      httpURLConnection.setAllowUserInteraction(false);
      httpURLConnection.setUseCaches(false);
      httpURLConnection.setInstanceFollowRedirects(true);
      httpURLConnection.setDoOutput(false);
      i = AppLovinNetworkBridge.httpUrlConnectionGetResponseCode(httpURLConnection);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ANR reported with code ");
      return;
    } finally {
      Exception exception = null;
      Log.w("applovin-anr-detector", "Failed to report ANR", exception);
    } 
  }
  
  private void b(n paramn) {
    if (this.g.compareAndSet(false, true)) {
      this.h = paramn;
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              f.a(this.a, Thread.currentThread());
            }
          });
      this.j = ((Long)paramn.a(b.fb)).longValue();
      this.k = ((Long)paramn.a(b.fc)).longValue();
      this.l = ((Long)paramn.a(b.fd)).longValue();
      this.c = new Handler(paramn.P().getMainLooper());
      this.d.start();
      this.c.post(new b());
      Handler handler = new Handler(this.d.getLooper());
      this.e = handler;
      handler.postDelayed(new a(), this.l / 2L);
    } 
  }
  
  private URL c() {
    // Byte code:
    //   0: ldc ''
    //   2: astore #8
    //   4: aload_0
    //   5: getfield h : Lcom/applovin/impl/sdk/n;
    //   8: invokevirtual P : ()Landroid/content/Context;
    //   11: astore_3
    //   12: iconst_0
    //   13: istore_1
    //   14: aload_3
    //   15: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   18: astore #4
    //   20: aload_3
    //   21: invokevirtual getPackageName : ()Ljava/lang/String;
    //   24: astore_3
    //   25: aload #4
    //   27: aload_3
    //   28: iconst_0
    //   29: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   32: astore #5
    //   34: aload_3
    //   35: astore #6
    //   37: goto -> 49
    //   40: ldc ''
    //   42: astore_3
    //   43: aconst_null
    //   44: astore #5
    //   46: aload_3
    //   47: astore #6
    //   49: aload_0
    //   50: getfield h : Lcom/applovin/impl/sdk/n;
    //   53: invokevirtual ah : ()Lcom/applovin/impl/sdk/t;
    //   56: invokevirtual c : ()Ljava/lang/Object;
    //   59: astore_3
    //   60: aload_3
    //   61: instanceof com/applovin/impl/sdk/ad/e
    //   64: istore_2
    //   65: ldc_w 'None'
    //   68: astore #9
    //   70: iload_2
    //   71: ifeq -> 95
    //   74: aload_3
    //   75: checkcast com/applovin/impl/sdk/ad/e
    //   78: astore_3
    //   79: ldc_w 'AppLovin'
    //   82: astore #4
    //   84: aload_3
    //   85: invokevirtual getAdIdNumber : ()J
    //   88: invokestatic toString : (J)Ljava/lang/String;
    //   91: astore_3
    //   92: goto -> 121
    //   95: aload_3
    //   96: instanceof com/applovin/impl/mediation/a/a
    //   99: ifeq -> 669
    //   102: aload_3
    //   103: checkcast com/applovin/impl/mediation/a/a
    //   106: astore_3
    //   107: aload_3
    //   108: invokevirtual getNetworkName : ()Ljava/lang/String;
    //   111: astore #4
    //   113: aload_3
    //   114: invokevirtual getCreativeId : ()Ljava/lang/String;
    //   117: astore_3
    //   118: goto -> 121
    //   121: aload_0
    //   122: getfield i : Ljava/lang/Thread;
    //   125: astore #10
    //   127: aload #9
    //   129: astore #7
    //   131: aload #10
    //   133: ifnull -> 207
    //   136: aload #9
    //   138: astore #7
    //   140: aload #10
    //   142: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   145: arraylength
    //   146: ifle -> 207
    //   149: aload_0
    //   150: getfield i : Ljava/lang/Thread;
    //   153: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   156: iconst_0
    //   157: aaload
    //   158: astore #7
    //   160: new java/lang/StringBuilder
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: astore #9
    //   169: aload #9
    //   171: aload #7
    //   173: invokevirtual getClassName : ()Ljava/lang/String;
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload #9
    //   182: ldc_w '.'
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: aload #9
    //   191: aload #7
    //   193: invokevirtual getMethodName : ()Ljava/lang/String;
    //   196: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: pop
    //   200: aload #9
    //   202: invokevirtual toString : ()Ljava/lang/String;
    //   205: astore #7
    //   207: new java/lang/StringBuilder
    //   210: dup
    //   211: invokespecial <init> : ()V
    //   214: astore #9
    //   216: aload #9
    //   218: aload_0
    //   219: getfield h : Lcom/applovin/impl/sdk/n;
    //   222: getstatic com/applovin/impl/sdk/c/b.bi : Lcom/applovin/impl/sdk/c/b;
    //   225: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   228: checkcast java/lang/String
    //   231: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload #9
    //   237: ldc_w '?type=anr&platform=android&package_name='
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload #9
    //   246: aload #6
    //   248: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: pop
    //   255: aload #9
    //   257: ldc_w '&applovin_random_token='
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: aload #9
    //   266: aload_0
    //   267: getfield h : Lcom/applovin/impl/sdk/n;
    //   270: invokevirtual p : ()Ljava/lang/String;
    //   273: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: pop
    //   280: aload #9
    //   282: ldc_w '&compass_random_token='
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: pop
    //   289: aload #9
    //   291: aload_0
    //   292: getfield h : Lcom/applovin/impl/sdk/n;
    //   295: invokevirtual o : ()Ljava/lang/String;
    //   298: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: pop
    //   305: aload #9
    //   307: ldc_w '&model='
    //   310: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   313: pop
    //   314: aload #9
    //   316: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   319: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: pop
    //   326: aload #9
    //   328: ldc_w '&brand='
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload #9
    //   337: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   340: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: aload #9
    //   349: ldc_w '&brand_name='
    //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   355: pop
    //   356: aload #9
    //   358: getstatic android/os/Build.BRAND : Ljava/lang/String;
    //   361: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   364: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: pop
    //   368: aload #9
    //   370: ldc_w '&hardware='
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #9
    //   379: getstatic android/os/Build.HARDWARE : Ljava/lang/String;
    //   382: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: pop
    //   389: aload #9
    //   391: ldc_w '&revision='
    //   394: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   397: pop
    //   398: aload #9
    //   400: getstatic android/os/Build.DEVICE : Ljava/lang/String;
    //   403: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   406: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   409: pop
    //   410: aload #9
    //   412: ldc_w '&app_version='
    //   415: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   418: pop
    //   419: aload #8
    //   421: astore #6
    //   423: aload #5
    //   425: ifnull -> 435
    //   428: aload #5
    //   430: getfield versionName : Ljava/lang/String;
    //   433: astore #6
    //   435: aload #9
    //   437: aload #6
    //   439: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   442: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   445: pop
    //   446: aload #9
    //   448: ldc_w '&app_version_code='
    //   451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   454: pop
    //   455: aload #5
    //   457: ifnull -> 466
    //   460: aload #5
    //   462: getfield versionCode : I
    //   465: istore_1
    //   466: aload #9
    //   468: iload_1
    //   469: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   472: pop
    //   473: aload #9
    //   475: ldc_w '&os='
    //   478: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   481: pop
    //   482: aload #9
    //   484: getstatic android/os/Build$VERSION.RELEASE : Ljava/lang/String;
    //   487: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: pop
    //   494: aload #9
    //   496: ldc_w '&api_level='
    //   499: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   502: pop
    //   503: aload #9
    //   505: getstatic android/os/Build$VERSION.SDK_INT : I
    //   508: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   511: pop
    //   512: aload #9
    //   514: ldc_w '&sdk_version='
    //   517: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   520: pop
    //   521: aload #9
    //   523: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   526: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   529: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   532: pop
    //   533: aload #9
    //   535: ldc_w '&fs_ad_network='
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: pop
    //   542: aload #9
    //   544: aload #4
    //   546: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   549: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   552: pop
    //   553: aload #9
    //   555: ldc_w '&fs_ad_creative_id='
    //   558: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   561: pop
    //   562: aload #9
    //   564: aload_3
    //   565: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   568: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   571: pop
    //   572: aload #9
    //   574: ldc_w '&top_main_method='
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: pop
    //   581: aload #9
    //   583: aload #7
    //   585: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   588: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   591: pop
    //   592: aload #9
    //   594: ldc_w '&aei='
    //   597: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   600: pop
    //   601: aload #9
    //   603: aload_0
    //   604: getfield h : Lcom/applovin/impl/sdk/n;
    //   607: getstatic com/applovin/impl/sdk/c/b.au : Lcom/applovin/impl/sdk/c/b;
    //   610: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   613: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   616: pop
    //   617: aload #9
    //   619: ldc_w '&mei='
    //   622: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   625: pop
    //   626: aload #9
    //   628: aload_0
    //   629: getfield h : Lcom/applovin/impl/sdk/n;
    //   632: getstatic com/applovin/impl/sdk/c/b.av : Lcom/applovin/impl/sdk/c/b;
    //   635: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   638: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   641: pop
    //   642: new java/net/URL
    //   645: dup
    //   646: aload #9
    //   648: invokevirtual toString : ()Ljava/lang/String;
    //   651: invokespecial <init> : (Ljava/lang/String;)V
    //   654: astore_3
    //   655: aload_3
    //   656: areturn
    //   657: astore_3
    //   658: goto -> 40
    //   661: astore #4
    //   663: goto -> 43
    //   666: astore_3
    //   667: aconst_null
    //   668: areturn
    //   669: ldc_w 'None'
    //   672: astore_3
    //   673: aload_3
    //   674: astore #4
    //   676: goto -> 121
    // Exception table:
    //   from	to	target	type
    //   14	25	657	finally
    //   25	34	661	finally
    //   49	65	666	java/net/MalformedURLException
    //   74	79	666	java/net/MalformedURLException
    //   84	92	666	java/net/MalformedURLException
    //   95	118	666	java/net/MalformedURLException
    //   121	127	666	java/net/MalformedURLException
    //   140	207	666	java/net/MalformedURLException
    //   207	419	666	java/net/MalformedURLException
    //   428	435	666	java/net/MalformedURLException
    //   435	455	666	java/net/MalformedURLException
    //   460	466	666	java/net/MalformedURLException
    //   466	655	666	java/net/MalformedURLException
  }
  
  private class a implements Runnable {
    private a(f this$0) {}
    
    public void run() {
      if (!f.a(this.a).get()) {
        long l = System.currentTimeMillis() - f.b(this.a).get();
        if (l < 0L || l > f.e(this.a)) {
          f.f(this.a);
          f.g(this.a);
        } 
        f.i(this.a).postDelayed(this, f.h(this.a));
      } 
    }
  }
  
  private class b implements Runnable {
    private b(f this$0) {}
    
    public void run() {
      if (!f.a(this.a).get()) {
        f.b(this.a).set(System.currentTimeMillis());
        f.d(this.a).postDelayed(this, f.c(this.a));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */