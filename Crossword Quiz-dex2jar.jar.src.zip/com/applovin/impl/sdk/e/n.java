package com.applovin.impl.sdk.e;

import android.app.Activity;
import com.applovin.impl.sdk.aa;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.e;
import com.applovin.impl.sdk.k;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.l;
import com.applovin.impl.sdk.utils.q;
import com.applovin.impl.sdk.v;
import com.applovin.sdk.AppLovinSdk;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class n extends a {
  private final com.applovin.impl.sdk.n a;
  
  public n(com.applovin.impl.sdk.n paramn) {
    super("TaskInitializeSdk", paramn);
    this.a = paramn;
  }
  
  private void a() {
    if (this.a.G().a())
      return; 
    Activity activity = this.a.ar();
    if (activity != null) {
      this.a.G().a(activity);
      return;
    } 
    this.a.V().a((a)new z(this.a, true, new Runnable(this) {
            public void run() {
              n.a(this.a).G().a(n.a(this.a).ai().a());
            }
          }), o.a.a, TimeUnit.SECONDS.toMillis(1L));
  }
  
  private void b() {
    if (!this.a.e()) {
      String str;
      boolean bool = this.a.O().d();
      if (bool) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((this.a.Y().k()).b);
        stringBuilder.append(" (use this for test devices)");
        str = stringBuilder.toString();
      } else {
        str = "<Enable verbose logging to see the GAID to use for test devices - https://monetization-support.applovin.com/hc/en-us/articles/236114328-How-can-I-expose-verbose-logging-for-the-SDK>";
      } 
      Map map1 = this.a.Y().d();
      Map map2 = this.a.Y().c();
      l l = new l();
      l.a().a("=====AppLovin SDK=====");
      l.a("===SDK Versions===").a("Version", AppLovinSdk.VERSION).a("Plugin Version", this.a.a(b.dI)).a("Ad Review Version", e.a()).a("OM SDK Version", this.a.ao().c());
      l.a("===Device Info===").a("OS", Utils.getAndroidOSInfo()).a("GAID", str).a("Model", map1.get("model")).a("Locale", map1.get("locale")).a("Emulator", map1.get("sim")).a("Tablet", map1.get("is_tablet"));
      l.a("===App Info===").a("Application ID", map2.get("package_name")).a("Target SDK", map2.get("target_sdk")).a("ExoPlayer Version", Integer.valueOf(Utils.getExoPlayerVersionCode()));
      l.a("===SDK Settings===").a("SDK Key", this.a.C()).a("Mediation Provider", this.a.u()).a("TG", q.a(this.a)).a("AEI", this.a.a(b.au)).a("MEI", this.a.a(b.av)).a("Test Mode On", Boolean.valueOf(this.a.N().a())).a("Verbose Logging On", Boolean.valueOf(bool));
      l.a("===Privacy States===\nPlease review AppLovin MAX documentation to be compliant with regional privacy policies.").a(k.a(f()));
      l.a();
      v.f("AppLovinSdk", l.toString());
    } 
  }
  
  public void run() {
    // Byte code:
    //   0: ldc_w 'succeeded'
    //   3: astore #8
    //   5: invokestatic currentTimeMillis : ()J
    //   8: lstore_1
    //   9: aload_0
    //   10: getfield d : Lcom/applovin/impl/sdk/v;
    //   13: astore #5
    //   15: invokestatic a : ()Z
    //   18: ifeq -> 81
    //   21: aload_0
    //   22: getfield d : Lcom/applovin/impl/sdk/v;
    //   25: astore #5
    //   27: aload_0
    //   28: getfield c : Ljava/lang/String;
    //   31: astore #6
    //   33: new java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: astore #7
    //   42: aload #7
    //   44: ldc_w 'Initializing AppLovin SDK v'
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: aload #7
    //   53: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #7
    //   62: ldc_w '...'
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: aload #6
    //   73: aload #7
    //   75: invokevirtual toString : ()Ljava/lang/String;
    //   78: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   81: aload_0
    //   82: getfield a : Lcom/applovin/impl/sdk/n;
    //   85: invokevirtual W : ()Lcom/applovin/impl/sdk/d/g;
    //   88: invokevirtual d : ()V
    //   91: aload_0
    //   92: getfield a : Lcom/applovin/impl/sdk/n;
    //   95: invokevirtual W : ()Lcom/applovin/impl/sdk/d/g;
    //   98: getstatic com/applovin/impl/sdk/d/f.e : Lcom/applovin/impl/sdk/d/f;
    //   101: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   104: aload_0
    //   105: getfield a : Lcom/applovin/impl/sdk/n;
    //   108: invokevirtual W : ()Lcom/applovin/impl/sdk/d/g;
    //   111: getstatic com/applovin/impl/sdk/d/f.f : Lcom/applovin/impl/sdk/d/f;
    //   114: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   117: aload_0
    //   118: getfield a : Lcom/applovin/impl/sdk/n;
    //   121: invokevirtual ae : ()Lcom/applovin/impl/sdk/r;
    //   124: aload_0
    //   125: invokevirtual f : ()Landroid/content/Context;
    //   128: invokevirtual a : (Landroid/content/Context;)V
    //   131: aload_0
    //   132: getfield a : Lcom/applovin/impl/sdk/n;
    //   135: invokevirtual ae : ()Lcom/applovin/impl/sdk/r;
    //   138: aload_0
    //   139: invokevirtual f : ()Landroid/content/Context;
    //   142: invokevirtual b : (Landroid/content/Context;)V
    //   145: aload_0
    //   146: getfield a : Lcom/applovin/impl/sdk/n;
    //   149: invokevirtual V : ()Lcom/applovin/impl/sdk/e/o;
    //   152: new com/applovin/impl/sdk/e/b
    //   155: dup
    //   156: aload_0
    //   157: getfield a : Lcom/applovin/impl/sdk/n;
    //   160: invokespecial <init> : (Lcom/applovin/impl/sdk/n;)V
    //   163: getstatic com/applovin/impl/sdk/e/o$a.a : Lcom/applovin/impl/sdk/e/o$a;
    //   166: invokevirtual a : (Lcom/applovin/impl/sdk/e/a;Lcom/applovin/impl/sdk/e/o$a;)V
    //   169: aload_0
    //   170: getfield a : Lcom/applovin/impl/sdk/n;
    //   173: invokevirtual Y : ()Lcom/applovin/impl/sdk/o;
    //   176: invokevirtual e : ()V
    //   179: aload_0
    //   180: getfield a : Lcom/applovin/impl/sdk/n;
    //   183: invokevirtual ak : ()Lcom/applovin/impl/sdk/utils/o;
    //   186: invokevirtual a : ()V
    //   189: aload_0
    //   190: getfield a : Lcom/applovin/impl/sdk/n;
    //   193: invokevirtual an : ()Lcom/applovin/impl/a/a/a;
    //   196: invokevirtual a : ()V
    //   199: aload_0
    //   200: invokevirtual f : ()Landroid/content/Context;
    //   203: aload_0
    //   204: getfield a : Lcom/applovin/impl/sdk/n;
    //   207: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/n;)Z
    //   210: ifeq -> 220
    //   213: aload_0
    //   214: getfield a : Lcom/applovin/impl/sdk/n;
    //   217: invokevirtual h : ()V
    //   220: aload_0
    //   221: getfield a : Lcom/applovin/impl/sdk/n;
    //   224: invokevirtual aq : ()Lcom/applovin/impl/sdk/array/ArrayService;
    //   227: invokevirtual collectAppHubData : ()V
    //   230: aload_0
    //   231: invokespecial b : ()V
    //   234: aload_0
    //   235: getfield a : Lcom/applovin/impl/sdk/n;
    //   238: getstatic com/applovin/impl/sdk/c/b.ec : Lcom/applovin/impl/sdk/c/b;
    //   241: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   244: checkcast java/lang/Boolean
    //   247: invokevirtual booleanValue : ()Z
    //   250: ifeq -> 264
    //   253: new com/applovin/impl/sdk/e/n$1
    //   256: dup
    //   257: aload_0
    //   258: invokespecial <init> : (Lcom/applovin/impl/sdk/e/n;)V
    //   261: invokestatic runOnUiThread : (Ljava/lang/Runnable;)V
    //   264: aload_0
    //   265: invokespecial a : ()V
    //   268: aload_0
    //   269: getfield a : Lcom/applovin/impl/sdk/n;
    //   272: iconst_1
    //   273: invokevirtual a : (Z)V
    //   276: aload_0
    //   277: getfield a : Lcom/applovin/impl/sdk/n;
    //   280: invokevirtual X : ()Lcom/applovin/impl/sdk/network/f;
    //   283: invokevirtual c : ()V
    //   286: aload_0
    //   287: getfield a : Lcom/applovin/impl/sdk/n;
    //   290: invokevirtual x : ()Lcom/applovin/sdk/AppLovinEventService;
    //   293: checkcast com/applovin/impl/sdk/EventServiceImpl
    //   296: invokevirtual maybeTrackAppOpenEvent : ()V
    //   299: aload_0
    //   300: getfield a : Lcom/applovin/impl/sdk/n;
    //   303: invokevirtual K : ()Lcom/applovin/impl/mediation/debugger/b;
    //   306: invokevirtual b : ()Z
    //   309: ifeq -> 322
    //   312: aload_0
    //   313: getfield a : Lcom/applovin/impl/sdk/n;
    //   316: invokevirtual e : ()Z
    //   319: ifeq -> 368
    //   322: aload_0
    //   323: getfield a : Lcom/applovin/impl/sdk/n;
    //   326: getstatic com/applovin/impl/sdk/c/a.h : Lcom/applovin/impl/sdk/c/b;
    //   329: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   332: checkcast java/lang/Boolean
    //   335: invokevirtual booleanValue : ()Z
    //   338: ifeq -> 378
    //   341: aload_0
    //   342: getfield a : Lcom/applovin/impl/sdk/n;
    //   345: invokevirtual P : ()Landroid/content/Context;
    //   348: aload_0
    //   349: getfield a : Lcom/applovin/impl/sdk/n;
    //   352: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/n;)Z
    //   355: ifeq -> 378
    //   358: aload_0
    //   359: getfield a : Lcom/applovin/impl/sdk/n;
    //   362: invokevirtual f : ()Z
    //   365: ifeq -> 378
    //   368: aload_0
    //   369: getfield a : Lcom/applovin/impl/sdk/n;
    //   372: invokevirtual K : ()Lcom/applovin/impl/mediation/debugger/b;
    //   375: invokevirtual a : ()V
    //   378: aload_0
    //   379: getfield a : Lcom/applovin/impl/sdk/n;
    //   382: invokevirtual ao : ()Lcom/applovin/impl/sdk/a/f;
    //   385: invokevirtual a : ()V
    //   388: aload_0
    //   389: getfield a : Lcom/applovin/impl/sdk/n;
    //   392: getstatic com/applovin/impl/sdk/c/b.aI : Lcom/applovin/impl/sdk/c/b;
    //   395: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   398: checkcast java/lang/Boolean
    //   401: invokevirtual booleanValue : ()Z
    //   404: ifeq -> 432
    //   407: aload_0
    //   408: getfield a : Lcom/applovin/impl/sdk/n;
    //   411: getstatic com/applovin/impl/sdk/c/b.aJ : Lcom/applovin/impl/sdk/c/b;
    //   414: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   417: checkcast java/lang/Long
    //   420: invokevirtual longValue : ()J
    //   423: lstore_3
    //   424: aload_0
    //   425: getfield a : Lcom/applovin/impl/sdk/n;
    //   428: lload_3
    //   429: invokevirtual a : (J)V
    //   432: aload_0
    //   433: getfield d : Lcom/applovin/impl/sdk/v;
    //   436: astore #5
    //   438: invokestatic a : ()Z
    //   441: ifeq -> 755
    //   444: aload_0
    //   445: getfield d : Lcom/applovin/impl/sdk/v;
    //   448: astore #11
    //   450: aload_0
    //   451: getfield c : Ljava/lang/String;
    //   454: astore #10
    //   456: new java/lang/StringBuilder
    //   459: dup
    //   460: invokespecial <init> : ()V
    //   463: astore #9
    //   465: aload #9
    //   467: ldc_w 'AppLovin SDK '
    //   470: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   473: pop
    //   474: aload #9
    //   476: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   479: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   482: pop
    //   483: aload #9
    //   485: ldc_w ' initialization '
    //   488: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   491: pop
    //   492: aload #11
    //   494: astore #5
    //   496: aload #10
    //   498: astore #6
    //   500: aload #9
    //   502: astore #7
    //   504: aload_0
    //   505: getfield a : Lcom/applovin/impl/sdk/n;
    //   508: invokevirtual d : ()Z
    //   511: ifeq -> 701
    //   514: aload #11
    //   516: astore #5
    //   518: aload #10
    //   520: astore #6
    //   522: aload #9
    //   524: astore #7
    //   526: goto -> 706
    //   529: astore #5
    //   531: ldc_w 'AppLovinSdk'
    //   534: ldc_w 'Failed to initialize SDK!'
    //   537: aload #5
    //   539: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   542: aload_0
    //   543: getfield a : Lcom/applovin/impl/sdk/n;
    //   546: iconst_0
    //   547: invokevirtual a : (Z)V
    //   550: aload_0
    //   551: getfield a : Lcom/applovin/impl/sdk/n;
    //   554: invokevirtual ao : ()Lcom/applovin/impl/sdk/a/f;
    //   557: invokevirtual a : ()V
    //   560: aload_0
    //   561: getfield a : Lcom/applovin/impl/sdk/n;
    //   564: getstatic com/applovin/impl/sdk/c/b.aI : Lcom/applovin/impl/sdk/c/b;
    //   567: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   570: checkcast java/lang/Boolean
    //   573: invokevirtual booleanValue : ()Z
    //   576: ifeq -> 604
    //   579: aload_0
    //   580: getfield a : Lcom/applovin/impl/sdk/n;
    //   583: getstatic com/applovin/impl/sdk/c/b.aJ : Lcom/applovin/impl/sdk/c/b;
    //   586: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   589: checkcast java/lang/Long
    //   592: invokevirtual longValue : ()J
    //   595: lstore_3
    //   596: aload_0
    //   597: getfield a : Lcom/applovin/impl/sdk/n;
    //   600: lload_3
    //   601: invokevirtual a : (J)V
    //   604: aload_0
    //   605: getfield d : Lcom/applovin/impl/sdk/v;
    //   608: astore #5
    //   610: invokestatic a : ()Z
    //   613: ifeq -> 755
    //   616: aload_0
    //   617: getfield d : Lcom/applovin/impl/sdk/v;
    //   620: astore #11
    //   622: aload_0
    //   623: getfield c : Ljava/lang/String;
    //   626: astore #10
    //   628: new java/lang/StringBuilder
    //   631: dup
    //   632: invokespecial <init> : ()V
    //   635: astore #9
    //   637: aload #9
    //   639: ldc_w 'AppLovin SDK '
    //   642: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   645: pop
    //   646: aload #9
    //   648: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   651: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   654: pop
    //   655: aload #9
    //   657: ldc_w ' initialization '
    //   660: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: pop
    //   664: aload #11
    //   666: astore #5
    //   668: aload #10
    //   670: astore #6
    //   672: aload #9
    //   674: astore #7
    //   676: aload_0
    //   677: getfield a : Lcom/applovin/impl/sdk/n;
    //   680: invokevirtual d : ()Z
    //   683: ifeq -> 701
    //   686: aload #11
    //   688: astore #5
    //   690: aload #10
    //   692: astore #6
    //   694: aload #9
    //   696: astore #7
    //   698: goto -> 706
    //   701: ldc_w 'failed'
    //   704: astore #8
    //   706: aload #7
    //   708: aload #8
    //   710: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   713: pop
    //   714: aload #7
    //   716: ldc_w ' in '
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: pop
    //   723: aload #7
    //   725: invokestatic currentTimeMillis : ()J
    //   728: lload_1
    //   729: lsub
    //   730: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #7
    //   736: ldc_w 'ms'
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #5
    //   745: aload #6
    //   747: aload #7
    //   749: invokevirtual toString : ()Ljava/lang/String;
    //   752: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   755: return
    //   756: astore #5
    //   758: aload_0
    //   759: getfield a : Lcom/applovin/impl/sdk/n;
    //   762: invokevirtual ao : ()Lcom/applovin/impl/sdk/a/f;
    //   765: invokevirtual a : ()V
    //   768: aload_0
    //   769: getfield a : Lcom/applovin/impl/sdk/n;
    //   772: getstatic com/applovin/impl/sdk/c/b.aI : Lcom/applovin/impl/sdk/c/b;
    //   775: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   778: checkcast java/lang/Boolean
    //   781: invokevirtual booleanValue : ()Z
    //   784: ifeq -> 812
    //   787: aload_0
    //   788: getfield a : Lcom/applovin/impl/sdk/n;
    //   791: getstatic com/applovin/impl/sdk/c/b.aJ : Lcom/applovin/impl/sdk/c/b;
    //   794: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   797: checkcast java/lang/Long
    //   800: invokevirtual longValue : ()J
    //   803: lstore_3
    //   804: aload_0
    //   805: getfield a : Lcom/applovin/impl/sdk/n;
    //   808: lload_3
    //   809: invokevirtual a : (J)V
    //   812: aload_0
    //   813: getfield d : Lcom/applovin/impl/sdk/v;
    //   816: astore #6
    //   818: invokestatic a : ()Z
    //   821: ifeq -> 939
    //   824: aload_0
    //   825: getfield d : Lcom/applovin/impl/sdk/v;
    //   828: astore #6
    //   830: aload_0
    //   831: getfield c : Ljava/lang/String;
    //   834: astore #7
    //   836: new java/lang/StringBuilder
    //   839: dup
    //   840: invokespecial <init> : ()V
    //   843: astore #9
    //   845: aload #9
    //   847: ldc_w 'AppLovin SDK '
    //   850: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   853: pop
    //   854: aload #9
    //   856: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   859: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   862: pop
    //   863: aload #9
    //   865: ldc_w ' initialization '
    //   868: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   871: pop
    //   872: aload_0
    //   873: getfield a : Lcom/applovin/impl/sdk/n;
    //   876: invokevirtual d : ()Z
    //   879: ifeq -> 885
    //   882: goto -> 890
    //   885: ldc_w 'failed'
    //   888: astore #8
    //   890: aload #9
    //   892: aload #8
    //   894: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   897: pop
    //   898: aload #9
    //   900: ldc_w ' in '
    //   903: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   906: pop
    //   907: aload #9
    //   909: invokestatic currentTimeMillis : ()J
    //   912: lload_1
    //   913: lsub
    //   914: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   917: pop
    //   918: aload #9
    //   920: ldc_w 'ms'
    //   923: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   926: pop
    //   927: aload #6
    //   929: aload #7
    //   931: aload #9
    //   933: invokevirtual toString : ()Ljava/lang/String;
    //   936: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   939: aload #5
    //   941: athrow
    // Exception table:
    //   from	to	target	type
    //   81	220	529	finally
    //   220	264	529	finally
    //   264	322	529	finally
    //   322	368	529	finally
    //   368	378	529	finally
    //   531	550	756	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\e\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */