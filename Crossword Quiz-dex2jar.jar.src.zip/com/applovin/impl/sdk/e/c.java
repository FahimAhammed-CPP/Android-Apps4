package com.applovin.impl.sdk.e;

import android.net.Uri;
import android.os.Bundle;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.h;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.d.d;
import com.applovin.impl.sdk.d.e;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.network.b;
import com.applovin.impl.sdk.r;
import com.applovin.impl.sdk.s;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.v;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinSdkUtils;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public abstract class c extends a implements h.a {
  protected final e a;
  
  private AppLovinAdLoadListener e;
  
  private final r f;
  
  private final s g;
  
  private final Collection<Character> h;
  
  private final e i;
  
  private boolean j;
  
  c(String paramString, e parame, n paramn, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    super(paramString, paramn);
    if (parame != null) {
      this.a = parame;
      this.e = paramAppLovinAdLoadListener;
      this.f = paramn.ae();
      this.g = paramn.ad();
      this.h = j();
      this.i = new e();
      return;
    } 
    throw new IllegalArgumentException("No ad specified.");
  }
  
  private Uri a(Uri paramUri, String paramString) {
    String str1;
    StringBuilder stringBuilder;
    v v;
    String str2;
    if (paramUri != null) {
      String str = paramUri.toString();
      if (StringUtils.isValidString(str)) {
        v = this.d;
        if (v.a()) {
          v = this.d;
          str2 = this.c;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Caching ");
          stringBuilder1.append(paramString);
          stringBuilder1.append(" image...");
          v.b(str2, stringBuilder1.toString());
        } 
        return c(str);
      } 
      v v1 = this.d;
      if (v.a()) {
        v = this.d;
        str1 = this.c;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to cache ");
        stringBuilder1.append(paramString);
        str2 = " image";
        stringBuilder = stringBuilder1;
      } else {
        return null;
      } 
    } else {
      v v1 = this.d;
      if (v.a()) {
        v = this.d;
        str1 = this.c;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No ");
        stringBuilder1.append((String)stringBuilder);
        str2 = " image to cache";
        stringBuilder = stringBuilder1;
      } else {
        return null;
      } 
    } 
    stringBuilder.append(str2);
    v.b(str1, stringBuilder.toString());
    return null;
  }
  
  private Uri a(String paramString1, String paramString2) {
    StringBuilder stringBuilder1;
    if (this.g != null)
      return b(paramString1, paramString2); 
    String str2 = paramString2.replace("/", "_");
    String str3 = this.a.L();
    String str1 = str2;
    if (StringUtils.isValidString(str3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    File file = this.f.a(str1, this.b.P());
    if (file == null)
      return null; 
    if (file.exists()) {
      this.i.b(file.length());
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("file://");
      stringBuilder1.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append((String)stringBuilder1);
    stringBuilder2.append(paramString2);
    paramString2 = stringBuilder2.toString();
    List<String> list = Arrays.asList(new String[] { (String)stringBuilder1 });
    if (this.f.a(file, paramString2, list, this.i)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("file://");
      stringBuilder.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder.toString());
    } 
    return null;
  }
  
  private Uri b(String paramString1, String paramString2) {
    StringBuilder stringBuilder1;
    String str2 = paramString2.replace("/", "_");
    String str3 = this.a.L();
    String str1 = str2;
    if (StringUtils.isValidString(str3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    File file = this.g.a(str1, this.b.P());
    if (file == null)
      return null; 
    if (file.exists()) {
      this.i.b(file.length());
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("file://");
      stringBuilder1.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append((String)stringBuilder1);
    stringBuilder2.append(paramString2);
    paramString2 = stringBuilder2.toString();
    List<String> list = Arrays.asList(new String[] { (String)stringBuilder1 });
    if (this.g.a(file, paramString2, list, this.i)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("file://");
      stringBuilder.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder.toString());
    } 
    return null;
  }
  
  private Uri c(String paramString) {
    return c(paramString, this.a.I(), true);
  }
  
  private Collection<Character> j() {
    HashSet<Character> hashSet = new HashSet();
    char[] arrayOfChar = ((String)this.b.a(b.bv)).toCharArray();
    int j = arrayOfChar.length;
    for (int i = 0; i < j; i++)
      hashSet.add(Character.valueOf(arrayOfChar[i])); 
    hashSet.add(Character.valueOf('"'));
    return hashSet;
  }
  
  Uri a(String paramString) {
    return a(paramString, this.a.I(), true);
  }
  
  Uri a(String paramString, List<String> paramList, boolean paramBoolean) {
    if (this.g != null)
      return b(paramString, paramList, paramBoolean); 
    if (StringUtils.isValidString(paramString)) {
      v v = this.d;
      if (v.a()) {
        v = this.d;
        String str1 = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Caching video ");
        stringBuilder.append(paramString);
        stringBuilder.append("...");
        v.b(str1, stringBuilder.toString());
      } 
      String str = this.f.a(f(), paramString, this.a.L(), paramList, paramBoolean, this.i);
      if (StringUtils.isValidString(str)) {
        v v1;
        File file = this.f.a(str, f());
        if (file != null) {
          v v2;
          Uri uri = Uri.fromFile(file);
          if (uri != null) {
            v2 = this.d;
            if (v.a()) {
              v2 = this.d;
              String str1 = this.c;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Finish caching video for ad #");
              stringBuilder.append(this.a.getAdIdNumber());
              stringBuilder.append(". Updating ad with cachedVideoFilename = ");
              stringBuilder.append(str);
              v2.b(str1, stringBuilder.toString());
            } 
            return uri;
          } 
          v1 = this.d;
          if (v.a()) {
            v1 = this.d;
            str = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to create URI from cached video file = ");
            stringBuilder.append(v2);
            v1.e(str, stringBuilder.toString());
          } 
        } else {
          v v2 = this.d;
          if (v.a()) {
            v2 = this.d;
            String str1 = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to cache video = ");
            stringBuilder.append((String)v1);
            stringBuilder.append("Video file was missing or null");
            v2.e(str1, stringBuilder.toString());
          } 
        } 
      } else {
        v v1 = this.d;
        if (v.a())
          this.d.e(this.c, "Failed to cache video"); 
        h();
      } 
    } 
    return null;
  }
  
  String a(String paramString, List<String> paramList) {
    if (this.g != null)
      return b(paramString, paramList); 
    if (StringUtils.isValidString(paramString)) {
      v v;
      String str1;
      Uri uri = Uri.parse(paramString);
      if (uri == null) {
        v = this.d;
        if (v.a())
          this.d.b(this.c, "Nothing to cache, skipping..."); 
        return null;
      } 
      if (((Boolean)this.b.a(b.fe)).booleanValue()) {
        str1 = Utils.getFileName(uri);
      } else {
        str1 = str1.getLastPathSegment();
      } 
      String str2 = str1;
      if (StringUtils.isValidString(this.a.L())) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a.L());
        stringBuilder.append(str1);
        str2 = stringBuilder.toString();
      } 
      try {
        File file = this.f.a(str2, f());
        if (file != null && file.exists())
          return this.f.a(file); 
        try {
          return this.f.a(file);
        } finally {
          paramList = null;
        } 
        Utils.close((Closeable)str1, this.b);
        throw paramList;
      } finally {
        paramList = null;
        v v1 = this.d;
      } 
    } 
    return null;
  }
  
  String a(String paramString, List<String> paramList, e parame) {
    v v;
    if (!StringUtils.isValidString(paramString))
      return paramString; 
    if (!((Boolean)this.b.a(b.bw)).booleanValue()) {
      v = this.d;
      if (v.a())
        this.d.b(this.c, "Resource caching is disabled, skipping cache..."); 
      return paramString;
    } 
    StringBuilder stringBuilder = new StringBuilder(paramString);
    boolean bool1 = parame.shouldCancelHtmlCachingIfShown();
    boolean bool2 = parame.aK();
    List list = parame.H();
    for (String str : v) {
      boolean bool4 = false;
      boolean bool3 = false;
      continue;
      while (true) {
        stringBuilder.replace(SYNTHETIC_LOCAL_VARIABLE_5, SYNTHETIC_LOCAL_VARIABLE_4, SYNTHETIC_LOCAL_VARIABLE_9.toString());
        parame.b((Uri)SYNTHETIC_LOCAL_VARIABLE_9);
        this.i.b();
      } 
    } 
    return stringBuilder.toString();
  }
  
  protected void a() {
    this.b.L().b(this);
  }
  
  public void a(a parama) {
    if (parama.f().equalsIgnoreCase(this.a.N())) {
      v v = this.d;
      if (v.a())
        this.d.e(this.c, "Updating flag for timeout..."); 
      this.j = true;
    } 
    this.b.L().b(this);
  }
  
  void a(AppLovinAdBase paramAppLovinAdBase) {
    d.a(this.i, paramAppLovinAdBase, this.b);
  }
  
  Uri b(String paramString, List<String> paramList, boolean paramBoolean) {
    if (StringUtils.isValidString(paramString)) {
      v v = this.d;
      if (v.a()) {
        v = this.d;
        String str1 = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Caching video ");
        stringBuilder.append(paramString);
        stringBuilder.append("...");
        v.b(str1, stringBuilder.toString());
      } 
      String str = this.g.a(f(), paramString, this.a.L(), paramList, paramBoolean, this.i);
      if (StringUtils.isValidString(str)) {
        v v1;
        File file = this.g.a(str, f());
        if (file != null) {
          v v2;
          Uri uri = Uri.fromFile(file);
          if (uri != null) {
            v2 = this.d;
            if (v.a()) {
              v2 = this.d;
              String str1 = this.c;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Finish caching video for ad #");
              stringBuilder.append(this.a.getAdIdNumber());
              stringBuilder.append(". Updating ad with cachedVideoFilename = ");
              stringBuilder.append(str);
              v2.b(str1, stringBuilder.toString());
            } 
            return uri;
          } 
          v1 = this.d;
          if (v.a()) {
            v1 = this.d;
            str = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to create URI from cached video file = ");
            stringBuilder.append(v2);
            v1.e(str, stringBuilder.toString());
          } 
        } else {
          v v2 = this.d;
          if (v.a()) {
            v2 = this.d;
            String str1 = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to cache video = ");
            stringBuilder.append((String)v1);
            stringBuilder.append("Video file was missing or null");
            v2.e(str1, stringBuilder.toString());
          } 
        } 
      } else {
        v v1 = this.d;
        if (v.a())
          this.d.e(this.c, "Failed to cache video"); 
        h();
        Bundle bundle = new Bundle();
        bundle.putLong("ad_id", this.a.getAdIdNumber());
        bundle.putInt("load_response_code", this.i.e());
        Exception exception = this.i.d();
        if (exception != null)
          bundle.putString("load_exception_message", exception.getMessage()); 
        this.b.aj().a(bundle, "video_caching_failed");
      } 
    } 
    return null;
  }
  
  String b(String paramString) {
    if (!StringUtils.isValidString(paramString))
      return null; 
    com.applovin.impl.sdk.network.c c1 = com.applovin.impl.sdk.network.c.a(this.b).a(paramString).b("GET").a("").a(0).a();
    AtomicReference<String> atomicReference = new AtomicReference(null);
    this.b.U().a(c1, new b.a(), new b.c<String>(this, atomicReference, paramString) {
          public void a(int param1Int, String param1String1, String param1String2) {
            v v = this.c.d;
            if (v.a()) {
              v = this.c.d;
              param1String2 = this.c.c;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Failed to load resource from '");
              stringBuilder.append(this.b);
              stringBuilder.append("'");
              v.e(param1String2, stringBuilder.toString());
            } 
          }
          
          public void a(String param1String, int param1Int) {
            this.a.set(param1String);
          }
        });
    paramString = atomicReference.get();
    if (paramString != null)
      this.i.a(paramString.length()); 
    return paramString;
  }
  
  String b(String paramString, List<String> paramList) {
    if (StringUtils.isValidString(paramString)) {
      v v;
      String str1;
      ByteArrayOutputStream byteArrayOutputStream;
      Uri uri = Uri.parse(paramString);
      if (uri == null) {
        v = this.d;
        if (v.a())
          this.d.b(this.c, "Nothing to cache, skipping..."); 
        return null;
      } 
      if (((Boolean)this.b.a(b.fe)).booleanValue()) {
        str1 = Utils.getFileName(uri);
      } else {
        str1 = str1.getLastPathSegment();
      } 
      String str2 = str1;
      if (StringUtils.isValidString(this.a.L())) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a.L());
        stringBuilder.append(str1);
        str2 = stringBuilder.toString();
      } 
      File file = this.g.a(str2, f());
      if (file != null && file.exists()) {
        byteArrayOutputStream = this.g.a(file);
      } else {
        str1 = null;
      } 
      if (str1 == null) {
        ByteArrayOutputStream byteArrayOutputStream1 = this.g.a((String)v, paramList, true, this.i);
        byteArrayOutputStream = byteArrayOutputStream1;
        if (byteArrayOutputStream1 != null) {
          this.g.a(byteArrayOutputStream1, file);
          this.i.a(byteArrayOutputStream1.size());
          byteArrayOutputStream = byteArrayOutputStream1;
        } 
      } else {
        this.i.b(byteArrayOutputStream.size());
      } 
      try {
        return byteArrayOutputStream.toString("UTF-8");
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      } finally {
        paramList = null;
        v v1 = this.d;
        if (v.a()) {
          v1 = this.d;
          String str = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("String resource at ");
          stringBuilder.append((String)unsupportedEncodingException);
          stringBuilder.append(" failed to load.");
          v1.b(str, stringBuilder.toString(), (Throwable)paramList);
        } 
      } 
    } 
    return null;
  }
  
  protected boolean b() {
    return this.j;
  }
  
  Uri c(String paramString, List<String> paramList, boolean paramBoolean) {
    if (this.g != null)
      return d(paramString, paramList, paramBoolean); 
  }
  
  void c() {
    v v2 = this.d;
    if (v.a())
      this.d.b(this.c, "Caching mute images..."); 
    Uri uri = a(this.a.aC(), "mute");
    if (uri != null)
      this.a.c(uri); 
    uri = a(this.a.aD(), "unmute");
    if (uri != null)
      this.a.d(uri); 
    v v1 = this.d;
    if (v.a()) {
      v1 = this.d;
      String str = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ad updated with muteImageFilename = ");
      stringBuilder.append(this.a.aC());
      stringBuilder.append(", unmuteImageFilename = ");
      stringBuilder.append(this.a.aD());
      v1.b(str, stringBuilder.toString());
    } 
  }
  
  Uri d(String paramString, List<String> paramList, boolean paramBoolean) {
    try {
      String str = this.g.a(f(), paramString, this.a.L(), paramList, paramBoolean, this.i);
      if (StringUtils.isValidString(str)) {
        v v;
        File file = this.g.a(str, f());
        if (file != null) {
          Uri uri = Uri.fromFile(file);
          if (uri != null)
            return uri; 
          v = this.d;
          if (v.a())
            this.d.e(this.c, "Unable to extract Uri from image file"); 
        } else {
          v v1 = this.d;
          if (v.a()) {
            v1 = this.d;
            String str1 = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to retrieve File from cached image filename = ");
            stringBuilder.append((String)v);
            v1.e(str1, stringBuilder.toString());
          } 
        } 
      } 
    } finally {
      paramList = null;
      v v = this.d;
    } 
    return null;
  }
  
  void h() {
    AppLovinAdLoadListener appLovinAdLoadListener = this.e;
    if (appLovinAdLoadListener != null) {
      appLovinAdLoadListener.failedToReceiveAd(-202);
      this.e = null;
    } 
  }
  
  void i() {
    v v = this.d;
    if (v.a()) {
      v = this.d;
      String str = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rendered new ad:");
      stringBuilder.append(this.a);
      v.b(str, stringBuilder.toString());
    } 
    AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
          public void run() {
            if (c.a(this.a) != null) {
              c.a(this.a).adReceived((AppLovinAd)this.a.a);
              c.a(this.a, (AppLovinAdLoadListener)null);
            } 
          }
        });
  }
  
  public void run() {
    if (this.a.M()) {
      v v = this.d;
      if (v.a())
        this.d.b(this.c, "Subscribing to timeout events..."); 
      this.b.L().a(this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\sdk\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */