package com.applovin.impl.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.d;
import com.applovin.impl.sdk.b;
import com.applovin.impl.sdk.e;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.i;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.v;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

public class MaxFullscreenAdImpl extends a implements b.a, e.a {
  private final a a;
  
  private final b b;
  
  private final com.applovin.impl.mediation.b c;
  
  private final Object d = new Object();
  
  private com.applovin.impl.mediation.a.c e = null;
  
  private c f = c.a;
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  private boolean h;
  
  private boolean i;
  
  private WeakReference<Activity> j = new WeakReference<Activity>(null);
  
  private WeakReference<ViewGroup> k = new WeakReference<ViewGroup>(null);
  
  private WeakReference<Lifecycle> l = new WeakReference<Lifecycle>(null);
  
  protected final b listenerWrapper;
  
  public MaxFullscreenAdImpl(String paramString1, MaxAdFormat paramMaxAdFormat, a parama, String paramString2, n paramn) {
    super(paramString1, paramMaxAdFormat, paramString2, paramn);
    this.a = parama;
    b b1 = new b();
    this.listenerWrapper = b1;
    this.b = new b(paramn, this);
    this.c = new com.applovin.impl.mediation.b(paramn, b1);
    paramn.E().a(this);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Created new ");
    stringBuilder.append(paramString2);
    stringBuilder.append(" (");
    stringBuilder.append(this);
    stringBuilder.append(")");
    v.f(paramString2, stringBuilder.toString());
  }
  
  private void a() {
    synchronized (this.d) {
      com.applovin.impl.mediation.a.c c1 = this.e;
      this.e = null;
      this.sdk.H().destroyAd((MaxAd)c1);
      return;
    } 
  }
  
  private void a(com.applovin.impl.mediation.a.c paramc) {
    if (this.b.a((com.applovin.impl.mediation.a.a)paramc)) {
      v v1 = this.logger;
      if (v.a()) {
        v1 = this.logger;
        String str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Handle ad loaded for regular ad: ");
        stringBuilder.append(paramc);
        v1.b(str, stringBuilder.toString());
      } 
      this.e = paramc;
      return;
    } 
    v v = this.logger;
    if (v.a())
      this.logger.b(this.tag, "Loaded an expired ad, running expire logic..."); 
    onAdExpired((MaxAd)paramc);
  }
  
  private void a(c paramc, Runnable paramRunnable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   4: astore #4
    //   6: aload_0
    //   7: getfield d : Ljava/lang/Object;
    //   10: astore #7
    //   12: aload #7
    //   14: monitorenter
    //   15: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   18: astore #5
    //   20: iconst_1
    //   21: istore_3
    //   22: aload #4
    //   24: aload #5
    //   26: if_acmpne -> 136
    //   29: aload_1
    //   30: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   33: if_acmpne -> 39
    //   36: goto -> 679
    //   39: aload_1
    //   40: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   43: if_acmpne -> 49
    //   46: goto -> 679
    //   49: aload_1
    //   50: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   53: if_acmpne -> 69
    //   56: aload_0
    //   57: getfield tag : Ljava/lang/String;
    //   60: astore #4
    //   62: ldc 'No ad is loading or loaded'
    //   64: astore #5
    //   66: goto -> 171
    //   69: aload_0
    //   70: getfield logger : Lcom/applovin/impl/sdk/v;
    //   73: astore #4
    //   75: invokestatic a : ()Z
    //   78: ifeq -> 885
    //   81: aload_0
    //   82: getfield logger : Lcom/applovin/impl/sdk/v;
    //   85: astore #4
    //   87: aload_0
    //   88: getfield tag : Ljava/lang/String;
    //   91: astore #5
    //   93: new java/lang/StringBuilder
    //   96: dup
    //   97: invokespecial <init> : ()V
    //   100: astore #6
    //   102: aload #6
    //   104: ldc 'Unable to transition to: '
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #6
    //   112: aload_1
    //   113: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   116: pop
    //   117: aload #6
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: astore #6
    //   124: aload #4
    //   126: aload #5
    //   128: aload #6
    //   130: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   133: goto -> 885
    //   136: aload #4
    //   138: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   141: if_acmpne -> 279
    //   144: aload_1
    //   145: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   148: if_acmpne -> 154
    //   151: goto -> 679
    //   154: aload_1
    //   155: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   158: if_acmpne -> 181
    //   161: aload_0
    //   162: getfield tag : Ljava/lang/String;
    //   165: astore #4
    //   167: ldc 'An ad is already loading'
    //   169: astore #5
    //   171: aload #4
    //   173: aload #5
    //   175: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   178: goto -> 885
    //   181: aload_1
    //   182: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   185: if_acmpne -> 191
    //   188: goto -> 679
    //   191: aload_1
    //   192: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   195: if_acmpne -> 211
    //   198: aload_0
    //   199: getfield tag : Ljava/lang/String;
    //   202: astore #4
    //   204: ldc 'An ad is not ready to be shown yet'
    //   206: astore #5
    //   208: goto -> 171
    //   211: aload_1
    //   212: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   215: if_acmpne -> 221
    //   218: goto -> 679
    //   221: aload_0
    //   222: getfield logger : Lcom/applovin/impl/sdk/v;
    //   225: astore #4
    //   227: invokestatic a : ()Z
    //   230: ifeq -> 885
    //   233: aload_0
    //   234: getfield logger : Lcom/applovin/impl/sdk/v;
    //   237: astore #4
    //   239: aload_0
    //   240: getfield tag : Ljava/lang/String;
    //   243: astore #5
    //   245: new java/lang/StringBuilder
    //   248: dup
    //   249: invokespecial <init> : ()V
    //   252: astore #6
    //   254: aload #6
    //   256: ldc 'Unable to transition to: '
    //   258: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: aload #6
    //   264: aload_1
    //   265: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   268: pop
    //   269: aload #6
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore #6
    //   276: goto -> 124
    //   279: aload #4
    //   281: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   284: if_acmpne -> 433
    //   287: aload_1
    //   288: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   291: if_acmpne -> 297
    //   294: goto -> 679
    //   297: aload_1
    //   298: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   301: if_acmpne -> 317
    //   304: aload_0
    //   305: getfield tag : Ljava/lang/String;
    //   308: astore #4
    //   310: ldc 'An ad is already loaded'
    //   312: astore #5
    //   314: goto -> 171
    //   317: aload_1
    //   318: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   321: if_acmpne -> 355
    //   324: aload_0
    //   325: getfield logger : Lcom/applovin/impl/sdk/v;
    //   328: astore #4
    //   330: invokestatic a : ()Z
    //   333: ifeq -> 885
    //   336: aload_0
    //   337: getfield logger : Lcom/applovin/impl/sdk/v;
    //   340: astore #4
    //   342: aload_0
    //   343: getfield tag : Ljava/lang/String;
    //   346: astore #5
    //   348: ldc 'An ad is already marked as ready'
    //   350: astore #6
    //   352: goto -> 124
    //   355: aload_1
    //   356: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   359: if_acmpne -> 365
    //   362: goto -> 679
    //   365: aload_1
    //   366: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   369: if_acmpne -> 375
    //   372: goto -> 679
    //   375: aload_0
    //   376: getfield logger : Lcom/applovin/impl/sdk/v;
    //   379: astore #4
    //   381: invokestatic a : ()Z
    //   384: ifeq -> 885
    //   387: aload_0
    //   388: getfield logger : Lcom/applovin/impl/sdk/v;
    //   391: astore #4
    //   393: aload_0
    //   394: getfield tag : Ljava/lang/String;
    //   397: astore #5
    //   399: new java/lang/StringBuilder
    //   402: dup
    //   403: invokespecial <init> : ()V
    //   406: astore #6
    //   408: aload #6
    //   410: ldc 'Unable to transition to: '
    //   412: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   415: pop
    //   416: aload #6
    //   418: aload_1
    //   419: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   422: pop
    //   423: aload #6
    //   425: invokevirtual toString : ()Ljava/lang/String;
    //   428: astore #6
    //   430: goto -> 124
    //   433: aload #4
    //   435: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   438: if_acmpne -> 597
    //   441: aload_1
    //   442: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   445: if_acmpne -> 451
    //   448: goto -> 679
    //   451: aload_1
    //   452: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   455: if_acmpne -> 471
    //   458: aload_0
    //   459: getfield tag : Ljava/lang/String;
    //   462: astore #4
    //   464: ldc 'Can not load another ad while the ad is showing'
    //   466: astore #5
    //   468: goto -> 171
    //   471: aload_1
    //   472: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   475: if_acmpne -> 509
    //   478: aload_0
    //   479: getfield logger : Lcom/applovin/impl/sdk/v;
    //   482: astore #4
    //   484: invokestatic a : ()Z
    //   487: ifeq -> 885
    //   490: aload_0
    //   491: getfield logger : Lcom/applovin/impl/sdk/v;
    //   494: astore #4
    //   496: aload_0
    //   497: getfield tag : Ljava/lang/String;
    //   500: astore #5
    //   502: ldc 'An ad is already showing, ignoring'
    //   504: astore #6
    //   506: goto -> 124
    //   509: aload_1
    //   510: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   513: if_acmpne -> 529
    //   516: aload_0
    //   517: getfield tag : Ljava/lang/String;
    //   520: astore #4
    //   522: ldc 'The ad is already showing, not showing another one'
    //   524: astore #5
    //   526: goto -> 171
    //   529: aload_1
    //   530: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   533: if_acmpne -> 539
    //   536: goto -> 679
    //   539: aload_0
    //   540: getfield logger : Lcom/applovin/impl/sdk/v;
    //   543: astore #4
    //   545: invokestatic a : ()Z
    //   548: ifeq -> 885
    //   551: aload_0
    //   552: getfield logger : Lcom/applovin/impl/sdk/v;
    //   555: astore #4
    //   557: aload_0
    //   558: getfield tag : Ljava/lang/String;
    //   561: astore #5
    //   563: new java/lang/StringBuilder
    //   566: dup
    //   567: invokespecial <init> : ()V
    //   570: astore #6
    //   572: aload #6
    //   574: ldc 'Unable to transition to: '
    //   576: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   579: pop
    //   580: aload #6
    //   582: aload_1
    //   583: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   586: pop
    //   587: aload #6
    //   589: invokevirtual toString : ()Ljava/lang/String;
    //   592: astore #6
    //   594: goto -> 124
    //   597: aload #4
    //   599: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   602: if_acmpne -> 618
    //   605: aload_0
    //   606: getfield tag : Ljava/lang/String;
    //   609: astore #4
    //   611: ldc 'No operations are allowed on a destroyed instance'
    //   613: astore #5
    //   615: goto -> 171
    //   618: aload_0
    //   619: getfield logger : Lcom/applovin/impl/sdk/v;
    //   622: astore #4
    //   624: invokestatic a : ()Z
    //   627: ifeq -> 885
    //   630: aload_0
    //   631: getfield logger : Lcom/applovin/impl/sdk/v;
    //   634: astore #4
    //   636: aload_0
    //   637: getfield tag : Ljava/lang/String;
    //   640: astore #5
    //   642: new java/lang/StringBuilder
    //   645: dup
    //   646: invokespecial <init> : ()V
    //   649: astore #6
    //   651: aload #6
    //   653: ldc 'Unknown state: '
    //   655: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   658: pop
    //   659: aload #6
    //   661: aload_0
    //   662: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   665: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   668: pop
    //   669: aload #6
    //   671: invokevirtual toString : ()Ljava/lang/String;
    //   674: astore #6
    //   676: goto -> 124
    //   679: iload_3
    //   680: ifeq -> 777
    //   683: aload_0
    //   684: getfield logger : Lcom/applovin/impl/sdk/v;
    //   687: astore #4
    //   689: invokestatic a : ()Z
    //   692: ifeq -> 769
    //   695: aload_0
    //   696: getfield logger : Lcom/applovin/impl/sdk/v;
    //   699: astore #4
    //   701: aload_0
    //   702: getfield tag : Ljava/lang/String;
    //   705: astore #5
    //   707: new java/lang/StringBuilder
    //   710: dup
    //   711: invokespecial <init> : ()V
    //   714: astore #6
    //   716: aload #6
    //   718: ldc 'Transitioning from '
    //   720: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   723: pop
    //   724: aload #6
    //   726: aload_0
    //   727: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   730: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #6
    //   736: ldc ' to '
    //   738: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   741: pop
    //   742: aload #6
    //   744: aload_1
    //   745: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   748: pop
    //   749: aload #6
    //   751: ldc '...'
    //   753: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   756: pop
    //   757: aload #4
    //   759: aload #5
    //   761: aload #6
    //   763: invokevirtual toString : ()Ljava/lang/String;
    //   766: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   769: aload_0
    //   770: aload_1
    //   771: putfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   774: goto -> 855
    //   777: aload_0
    //   778: getfield logger : Lcom/applovin/impl/sdk/v;
    //   781: astore #4
    //   783: invokestatic a : ()Z
    //   786: ifeq -> 855
    //   789: aload_0
    //   790: getfield logger : Lcom/applovin/impl/sdk/v;
    //   793: astore #4
    //   795: aload_0
    //   796: getfield tag : Ljava/lang/String;
    //   799: astore #5
    //   801: new java/lang/StringBuilder
    //   804: dup
    //   805: invokespecial <init> : ()V
    //   808: astore #6
    //   810: aload #6
    //   812: ldc 'Not allowed transition from '
    //   814: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   817: pop
    //   818: aload #6
    //   820: aload_0
    //   821: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   824: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   827: pop
    //   828: aload #6
    //   830: ldc ' to '
    //   832: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   835: pop
    //   836: aload #6
    //   838: aload_1
    //   839: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   842: pop
    //   843: aload #4
    //   845: aload #5
    //   847: aload #6
    //   849: invokevirtual toString : ()Ljava/lang/String;
    //   852: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)V
    //   855: aload #7
    //   857: monitorexit
    //   858: iload_3
    //   859: ifeq -> 872
    //   862: aload_2
    //   863: ifnull -> 872
    //   866: aload_2
    //   867: invokeinterface run : ()V
    //   872: return
    //   873: astore_1
    //   874: aload #7
    //   876: monitorexit
    //   877: goto -> 882
    //   880: aload_1
    //   881: athrow
    //   882: goto -> 880
    //   885: iconst_0
    //   886: istore_3
    //   887: goto -> 679
    // Exception table:
    //   from	to	target	type
    //   15	20	873	finally
    //   29	36	873	finally
    //   39	46	873	finally
    //   49	62	873	finally
    //   69	124	873	finally
    //   124	133	873	finally
    //   136	151	873	finally
    //   154	167	873	finally
    //   171	178	873	finally
    //   181	188	873	finally
    //   191	204	873	finally
    //   211	218	873	finally
    //   221	276	873	finally
    //   279	294	873	finally
    //   297	310	873	finally
    //   317	348	873	finally
    //   355	362	873	finally
    //   365	372	873	finally
    //   375	430	873	finally
    //   433	448	873	finally
    //   451	464	873	finally
    //   471	502	873	finally
    //   509	522	873	finally
    //   529	536	873	finally
    //   539	594	873	finally
    //   597	611	873	finally
    //   618	676	873	finally
    //   683	769	873	finally
    //   769	774	873	finally
    //   777	855	873	finally
    //   855	858	873	finally
    //   874	877	873	finally
  }
  
  private void a(MaxAd paramMaxAd) {
    this.b.a();
    a();
    this.sdk.J().b((com.applovin.impl.mediation.a.a)paramMaxAd);
  }
  
  private void a(String paramString1, String paramString2) {
    this.c.b(this.e);
    this.e.e(paramString1);
    this.e.f(paramString2);
    this.sdk.an().a(this.e);
    v v = this.logger;
    if (v.a()) {
      v = this.logger;
      paramString2 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Showing ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'; loaded ad: ");
      stringBuilder.append(this.e);
      stringBuilder.append("...");
      v.b(paramString2, stringBuilder.toString());
    } 
    a((com.applovin.impl.mediation.a.a)this.e);
  }
  
  private boolean a(Activity paramActivity) {
    if (paramActivity != null || MaxAdFormat.APP_OPEN == this.adFormat) {
      MaxErrorImpl maxErrorImpl;
      boolean bool;
      if (!isReady()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to show ad before it is ready - please check ad readiness using ");
        stringBuilder.append(this.tag);
        stringBuilder.append("#isReady()");
        String str1 = stringBuilder.toString();
        v.i(this.tag, str1);
        maxErrorImpl = new MaxErrorImpl(-24, str1);
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      if (Utils.getAlwaysFinishActivitiesSetting(this.sdk.P()) != 0 && this.sdk.q().shouldFailAdDisplayIfDontKeepActivitiesIsEnabled())
        if (!Utils.isPubInDebugMode(this.sdk.P(), this.sdk)) {
          if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.T)).booleanValue()) {
            v.i(this.tag, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            maxErrorImpl = new MaxErrorImpl(-5602, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
            return false;
          } 
        } else {
          throw new IllegalStateException("Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
        }  
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.z)).booleanValue() && (this.sdk.ah().a() || this.sdk.ah().b())) {
        v.i(this.tag, "Attempting to show ad when another fullscreen ad is already showing");
        maxErrorImpl = new MaxErrorImpl(-23, "Attempting to show ad when another fullscreen ad is already showing");
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.A)).booleanValue() && !i.a(this.sdk.P())) {
        v.i(this.tag, "Attempting to show ad with no internet connection");
        maxErrorImpl = new MaxErrorImpl(-1009);
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      String str = (String)this.sdk.q().getExtraParameters().get("fullscreen_ads_block_showing_if_activity_is_finishing");
      if (StringUtils.isValidString(str) && Boolean.valueOf(str).booleanValue()) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool || ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.B)).booleanValue()) && maxErrorImpl != null && maxErrorImpl.isFinishing()) {
        v.i(this.tag, "Attempting to show ad when activity is finishing");
        maxErrorImpl = new MaxErrorImpl(-5601, "Attempting to show ad when activity is finishing");
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      return true;
    } 
    throw new IllegalArgumentException("Attempting to show ad without a valid activity.");
  }
  
  private void b() {
    if (this.g.compareAndSet(true, false))
      synchronized (this.d) {
        com.applovin.impl.mediation.a.c c1 = this.e;
        this.e = null;
        this.sdk.H().destroyAd((MaxAd)c1);
        this.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      }  
  }
  
  public void destroy() {
    a(c.e, new Runnable(this) {
          public void run() {
            synchronized (MaxFullscreenAdImpl.a(this.a)) {
              if (MaxFullscreenAdImpl.b(this.a) != null) {
                v v = this.a.logger;
                if (v.a()) {
                  v = this.a.logger;
                  String str = this.a.tag;
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Destroying ad for '");
                  stringBuilder.append(this.a.adUnitId);
                  stringBuilder.append("'; current ad: ");
                  stringBuilder.append(MaxFullscreenAdImpl.b(this.a));
                  stringBuilder.append("...");
                  v.b(str, stringBuilder.toString());
                } 
                this.a.sdk.H().destroyAd((MaxAd)MaxFullscreenAdImpl.b(this.a));
              } 
              this.a.sdk.E().b(this.a);
              MaxFullscreenAdImpl.c(this.a);
              return;
            } 
          }
        });
  }
  
  public boolean isReady() {
    synchronized (this.d) {
      com.applovin.impl.mediation.a.c c1 = this.e;
      if (c1 != null && c1.e() && this.f == c.c)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public void loadAd(Activity paramActivity) {
    loadAd(paramActivity, d.a.a);
  }
  
  public void loadAd(Activity paramActivity, d.a parama) {
    v v1;
    String str;
    v v2 = this.logger;
    if (v.a()) {
      v2 = this.logger;
      String str1 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'...");
      v2.b(str1, stringBuilder.toString());
    } 
    if (isReady()) {
      v1 = this.logger;
      if (v.a()) {
        v1 = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An ad is already loaded for '");
        stringBuilder.append(this.adUnitId);
        stringBuilder.append("'");
        v1.b(str, stringBuilder.toString());
      } 
      k.a(this.adListener, (MaxAd)this.e, true);
      return;
    } 
    a(c.b, new Runnable(this, (Activity)v1, (d.a)str) {
          public void run() {
            Context context;
            Activity activity = this.a;
            if (activity == null)
              if (this.c.sdk.ar() != null) {
                activity = this.c.sdk.ar();
              } else {
                context = this.c.sdk.P();
              }  
            this.c.sdk.H().loadAd(this.c.adUnitId, null, this.c.adFormat, this.b, this.c.localExtraParameters, this.c.extraParameters, context, this.c.listenerWrapper);
          }
        });
  }
  
  public void onAdExpired(MaxAd paramMaxAd) {
    Activity activity;
    v v = this.logger;
    if (v.a()) {
      v = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ad expired ");
      stringBuilder.append(getAdUnitId());
      v.b(str, stringBuilder.toString());
    } 
    this.g.set(true);
    a a1 = this.a;
    if (a1 != null) {
      activity = a1.getActivity();
    } else {
      activity = this.sdk.ai().a();
    } 
    if (activity == null) {
      b();
      this.listenerWrapper.onAdLoadFailed(this.adUnitId, (MaxError)MaxAdapterError.MISSING_ACTIVITY);
      return;
    } 
    this.extraParameters.put("expired_ad_ad_unit_id", getAdUnitId());
    this.sdk.H().loadAd(this.adUnitId, null, this.adFormat, d.a.e, this.localExtraParameters, this.extraParameters, (Context)activity, this.listenerWrapper);
  }
  
  public void onCreativeIdGenerated(String paramString1, String paramString2) {
    com.applovin.impl.mediation.a.c c1 = this.e;
    if (c1 != null && c1.f().equalsIgnoreCase(paramString1)) {
      this.e.b(paramString2);
      k.a(this.adReviewListener, paramString2, (MaxAd)this.e);
    } 
  }
  
  public void showAd(String paramString1, String paramString2, Activity paramActivity) {
    String str1;
    String str2 = this.sdk.N().c();
    if (this.sdk.N().b() && str2 != null && !str2.equals(this.e.S())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to show ad from <");
      stringBuilder.append(this.e.S());
      stringBuilder.append("> which does not match selected ad network <");
      stringBuilder.append(str2);
      stringBuilder.append(">");
      str1 = stringBuilder.toString();
      v.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.ar(); 
    if (!a(paramActivity))
      return; 
    a(c.d, new Runnable(this, str1, paramString2, paramActivity) {
          public void run() {
            MaxFullscreenAdImpl.a(this.d, this.a, this.b);
            MaxFullscreenAdImpl.a(this.d, false);
            MaxFullscreenAdImpl.a(this.d, new WeakReference<Activity>(this.c));
            this.d.sdk.H().showFullscreenAd(MaxFullscreenAdImpl.b(this.d), this.c, this.d.listenerWrapper);
          }
        });
  }
  
  public void showAd(String paramString1, String paramString2, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity) {
    String str1;
    if (paramViewGroup == null || paramLifecycle == null) {
      v.i(this.tag, "Attempting to show ad with null containerView or lifecycle.");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad with null containerView or lifecycle.");
      k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
      return;
    } 
    String str2 = this.sdk.N().c();
    if (this.sdk.N().b() && str2 != null && !str2.equals(this.e.S())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to show ad from <");
      stringBuilder.append(this.e.S());
      stringBuilder.append("> which does not match selected ad network <");
      stringBuilder.append(str2);
      stringBuilder.append(">");
      str1 = stringBuilder.toString();
      v.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.ar(); 
    if (!a(paramActivity))
      return; 
    a(c.d, new Runnable(this, str1, paramString2, paramActivity, paramViewGroup, paramLifecycle) {
          public void run() {
            MaxFullscreenAdImpl.a(this.f, this.a, this.b);
            MaxFullscreenAdImpl.a(this.f, true);
            MaxFullscreenAdImpl.a(this.f, new WeakReference<Activity>(this.c));
            MaxFullscreenAdImpl.b(this.f, new WeakReference<ViewGroup>(this.d));
            MaxFullscreenAdImpl.c(this.f, new WeakReference<Lifecycle>(this.e));
            this.f.sdk.H().showFullscreenAd(MaxFullscreenAdImpl.b(this.f), this.d, this.e, this.c, this.f.listenerWrapper);
          }
        });
  }
  
  public String toString() {
    MaxAdListener maxAdListener;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.tag);
    stringBuilder.append("{adUnitId='");
    stringBuilder.append(this.adUnitId);
    stringBuilder.append('\'');
    stringBuilder.append(", adListener=");
    if (this.adListener == this.a) {
      String str = "this";
    } else {
      maxAdListener = this.adListener;
    } 
    stringBuilder.append(maxAdListener);
    stringBuilder.append(", revenueListener=");
    stringBuilder.append(this.revenueListener);
    stringBuilder.append(", requestListener");
    stringBuilder.append(this.requestListener);
    stringBuilder.append(", adReviewListener");
    stringBuilder.append(this.adReviewListener);
    stringBuilder.append(", isReady=");
    stringBuilder.append(isReady());
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static interface a {
    Activity getActivity();
  }
  
  private class b implements a.a, MaxAdListener, MaxAdRevenueListener, MaxRewardedAdListener {
    private b(MaxFullscreenAdImpl this$0) {}
    
    public void onAdClicked(MaxAd param1MaxAd) {
      k.d(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {
      boolean bool = MaxFullscreenAdImpl.e(this.a);
      MaxFullscreenAdImpl.b(this.a, false);
      com.applovin.impl.mediation.a.c c = (com.applovin.impl.mediation.a.c)param1MaxAd;
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd, bool, c, param1MaxError) {
            public void run() {
              MaxFullscreenAdImpl.a(this.e.a, this.a);
              if (!this.b && this.c.G() && this.e.a.sdk.M().a(this.e.a.adUnitId)) {
                AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
                      public void run() {
                        Activity activity;
                        MaxFullscreenAdImpl.b(this.a.e.a, true);
                        if (MaxFullscreenAdImpl.m(this.a.e.a) != null) {
                          activity = MaxFullscreenAdImpl.m(this.a.e.a).getActivity();
                        } else {
                          activity = null;
                        } 
                        this.a.e.a.loadAd(activity);
                      }
                    });
                return;
              } 
              k.a(this.e.a.adListener, this.a, this.d, true);
            }
          });
    }
    
    public void onAdDisplayed(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      MaxFullscreenAdImpl.k(this.a).a();
      k.b(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdHidden(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      MaxFullscreenAdImpl.l(this.a).a(param1MaxAd);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd) {
            public void run() {
              MaxFullscreenAdImpl.a(this.b.a, this.a);
              k.c(this.b.a.adListener, this.a, true);
            }
          });
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      MaxFullscreenAdImpl.j(this.a);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1String, param1MaxError) {
            public void run() {
              k.a(this.c.a.adListener, this.a, this.b, true);
            }
          });
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.a(this.a, (com.applovin.impl.mediation.a.c)param1MaxAd);
      if (MaxFullscreenAdImpl.d(this.a).compareAndSet(true, false)) {
        this.a.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      } 
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.c, new Runnable(this, param1MaxAd) {
            public void run() {
              if (MaxFullscreenAdImpl.e(this.b.a)) {
                Activity activity = MaxFullscreenAdImpl.f(this.b.a).get();
                if (activity == null)
                  activity = this.b.a.sdk.ar(); 
                if (MaxFullscreenAdImpl.g(this.b.a)) {
                  this.b.a.showAd(MaxFullscreenAdImpl.b(this.b.a).getPlacement(), MaxFullscreenAdImpl.b(this.b.a).ag(), MaxFullscreenAdImpl.h(this.b.a).get(), MaxFullscreenAdImpl.i(this.b.a).get(), activity);
                  return;
                } 
                this.b.a.showAd(MaxFullscreenAdImpl.b(this.b.a).getPlacement(), MaxFullscreenAdImpl.b(this.b.a).ag(), activity);
                return;
              } 
              k.a(this.b.a.adListener, this.a, true);
            }
          });
    }
    
    public void onAdRequestStarted(String param1String) {
      k.a(this.a.requestListener, param1String, true);
    }
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {
      k.a(this.a.revenueListener, param1MaxAd);
    }
    
    public void onRewardedVideoCompleted(MaxAd param1MaxAd) {
      k.f(this.a.adListener, param1MaxAd, true);
    }
    
    public void onRewardedVideoStarted(MaxAd param1MaxAd) {
      k.e(this.a.adListener, param1MaxAd, true);
    }
    
    public void onUserRewarded(MaxAd param1MaxAd, MaxReward param1MaxReward) {
      k.a(this.a.adListener, param1MaxAd, param1MaxReward, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      if (MaxFullscreenAdImpl.e(this.b.a)) {
        Activity activity = MaxFullscreenAdImpl.f(this.b.a).get();
        if (activity == null)
          activity = this.b.a.sdk.ar(); 
        if (MaxFullscreenAdImpl.g(this.b.a)) {
          this.b.a.showAd(MaxFullscreenAdImpl.b(this.b.a).getPlacement(), MaxFullscreenAdImpl.b(this.b.a).ag(), MaxFullscreenAdImpl.h(this.b.a).get(), MaxFullscreenAdImpl.i(this.b.a).get(), activity);
          return;
        } 
        this.b.a.showAd(MaxFullscreenAdImpl.b(this.b.a).getPlacement(), MaxFullscreenAdImpl.b(this.b.a).ag(), activity);
        return;
      } 
      k.a(this.b.a.adListener, this.a, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, String param1String, MaxError param1MaxError) {}
    
    public void run() {
      k.a(this.c.a.adListener, this.a, this.b, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.b.a, this.a);
      k.c(this.b.a.adListener, this.a, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd, boolean param1Boolean, com.applovin.impl.mediation.a.c param1c, MaxError param1MaxError) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.e.a, this.a);
      if (!this.b && this.c.G() && this.e.a.sdk.M().a(this.e.a.adUnitId)) {
        AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
              public void run() {
                Activity activity;
                MaxFullscreenAdImpl.b(this.a.e.a, true);
                if (MaxFullscreenAdImpl.m(this.a.e.a) != null) {
                  activity = MaxFullscreenAdImpl.m(this.a.e.a).getActivity();
                } else {
                  activity = null;
                } 
                this.a.e.a.loadAd(activity);
              }
            });
        return;
      } 
      k.a(this.e.a.adListener, this.a, this.d, true);
    }
  }
  
  class null implements Runnable {
    public void run() {
      Activity activity;
      MaxFullscreenAdImpl.b(this.a.e.a, true);
      if (MaxFullscreenAdImpl.m(this.a.e.a) != null) {
        activity = MaxFullscreenAdImpl.m(this.a.e.a).getActivity();
      } else {
        activity = null;
      } 
      this.a.e.a.loadAd(activity);
    }
  }
  
  public enum c {
    a, b, c, d, e;
    
    static {
      c c1 = new c("IDLE", 0);
      a = c1;
      c c2 = new c("LOADING", 1);
      b = c2;
      c c3 = new c("READY", 2);
      c = c3;
      c c4 = new c("SHOWING", 3);
      d = c4;
      c c5 = new c("DESTROYED", 4);
      e = c5;
      f = new c[] { c1, c2, c3, c4, c5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\mediation\ads\MaxFullscreenAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */