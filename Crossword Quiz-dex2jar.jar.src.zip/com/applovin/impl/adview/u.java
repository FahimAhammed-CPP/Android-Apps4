package com.applovin.impl.adview;

import android.net.Uri;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.applovin.impl.sdk.n;
import com.applovin.impl.sdk.v;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import java.lang.ref.WeakReference;

public class u extends WebViewClient {
  private final v a;
  
  private WeakReference<a> b;
  
  public u(n paramn) {
    this.a = paramn.D();
  }
  
  private void a(WebView paramWebView, String paramString) {
    if (v.a()) {
      v v1 = this.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Processing click on ad URL \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      v1.c("WebViewButtonClient", stringBuilder.toString());
    } 
    if (paramString != null && paramWebView instanceof t) {
      t t = (t)paramWebView;
      Uri uri = Uri.parse(paramString);
      String str2 = uri.getScheme();
      String str3 = uri.getHost();
      String str1 = uri.getPath();
      a a = this.b.get();
      if ("applovin".equalsIgnoreCase(str2) && "com.applovin.sdk".equalsIgnoreCase(str3) && a != null) {
        if ("/track_click".equals(str1)) {
          a.a(t);
          return;
        } 
        if ("/close_ad".equals(str1)) {
          a.b(t);
          return;
        } 
        if ("/skip_ad".equals(str1)) {
          a.c(t);
          return;
        } 
        if (v.a()) {
          v v1 = this.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown URL: ");
          stringBuilder.append(paramString);
          v1.d("WebViewButtonClient", stringBuilder.toString());
        } 
        if (v.a()) {
          v v1 = this.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Path: ");
          stringBuilder.append(str1);
          v1.d("WebViewButtonClient", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public void a(WeakReference<a> paramWeakReference) {
    this.b = paramWeakReference;
  }
  
  public void onLoadResource(WebView paramWebView, String paramString) {
    super.onLoadResource(paramWebView, paramString);
    CreativeInfoManager.onResourceLoaded("com.applovin", paramWebView, paramString);
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    super.onPageFinished(paramWebView, paramString);
    CreativeInfoManager.onWebViewPageFinished("com.applovin", paramWebView, paramString);
  }
  
  public boolean onRenderProcessGone(WebView paramWebView, RenderProcessGoneDetail paramRenderProcessGoneDetail) {
    return true;
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    return CreativeInfoManager.onWebViewResponseWithHeaders("com.applovin", paramWebView, paramWebResourceRequest, super.shouldInterceptRequest(paramWebView, paramWebResourceRequest));
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, String paramString) {
    return CreativeInfoManager.onWebViewResponse("com.applovin", paramWebView, paramString, super.shouldInterceptRequest(paramWebView, paramString));
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    a(paramWebView, paramString);
    return true;
  }
  
  public static interface a {
    void a(t param1t);
    
    void b(t param1t);
    
    void c(t param1t);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\applovin\impl\advie\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */