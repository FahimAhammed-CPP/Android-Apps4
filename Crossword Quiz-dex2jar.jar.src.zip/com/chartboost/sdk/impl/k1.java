package com.chartboost.sdk.impl;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class k1 extends WebChromeClient implements h6.a {
  public final View a;
  
  public final ViewGroup b;
  
  public boolean c;
  
  public FrameLayout d;
  
  public WebChromeClient.CustomViewCallback e;
  
  public a f;
  
  public final j1 g;
  
  public final Handler h;
  
  public final h6 i;
  
  public final o3 j;
  
  public k1(View paramView, ViewGroup paramViewGroup, j1 paramj1, Handler paramHandler) {
    this.a = paramView;
    this.b = paramViewGroup;
    this.c = false;
    this.g = paramj1;
    this.h = paramHandler;
    this.j = new o3(this, paramj1);
    this.i = new h6();
  }
  
  public String a(JSONObject paramJSONObject, String paramString) {
    StringBuilder stringBuilder2;
    com.chartboost.sdk.internal.Model.a a1;
    this.j.a(paramJSONObject);
    paramString.hashCode();
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 1880941391:
        if (!paramString.equals("getMaxSize"))
          break; 
        b = 27;
        break;
      case 1270488759:
        if (!paramString.equals("tracking"))
          break; 
        b = 26;
        break;
      case 1124446108:
        if (!paramString.equals("warning"))
          break; 
        b = 25;
        break;
      case 1082777163:
        if (!paramString.equals("totalVideoDuration"))
          break; 
        b = 24;
        break;
      case 1000390722:
        if (!paramString.equals("videoReplay"))
          break; 
        b = 23;
        break;
      case 939594121:
        if (!paramString.equals("videoPaused"))
          break; 
        b = 22;
        break;
      case 937504109:
        if (!paramString.equals("getOrientationProperties"))
          break; 
        b = 21;
        break;
      case 550290366:
        if (!paramString.equals("rewardedVideoCompleted"))
          break; 
        b = 20;
        break;
      case 160987616:
        if (!paramString.equals("getParameters"))
          break; 
        b = 19;
        break;
      case 133423073:
        if (!paramString.equals("setOrientationProperties"))
          break; 
        b = 18;
        break;
      case 96784904:
        if (!paramString.equals("error"))
          break; 
        b = 17;
        break;
      case 95458899:
        if (!paramString.equals("debug"))
          break; 
        b = 16;
        break;
      case 94756344:
        if (!paramString.equals("close"))
          break; 
        b = 15;
        break;
      case 94750088:
        if (!paramString.equals("click"))
          break; 
        b = 14;
        break;
      case 3529469:
        if (!paramString.equals("show"))
          break; 
        b = 13;
        break;
      case 3363353:
        if (!paramString.equals("mute"))
          break; 
        b = 12;
        break;
      case -55818203:
        if (!paramString.equals("pauseVideo"))
          break; 
        b = 11;
        break;
      case -640720077:
        if (!paramString.equals("videoPlaying"))
          break; 
        b = 10;
        break;
      case -715147645:
        if (!paramString.equals("getScreenSize"))
          break; 
        b = 9;
        break;
      case -840405966:
        if (!paramString.equals("unmute"))
          break; 
        b = 8;
        break;
      case -934326481:
        if (!paramString.equals("reward"))
          break; 
        b = 7;
        break;
      case -1086137328:
        if (!paramString.equals("videoCompleted"))
          break; 
        b = 6;
        break;
      case -1263203643:
        if (!paramString.equals("openUrl"))
          break; 
        b = 5;
        break;
      case -1554056650:
        if (!paramString.equals("currentVideoDuration"))
          break; 
        b = 4;
        break;
      case -1757019252:
        if (!paramString.equals("getCurrentPosition"))
          break; 
        b = 3;
        break;
      case -1886160473:
        if (!paramString.equals("playVideo"))
          break; 
        b = 2;
        break;
      case -2012425132:
        if (!paramString.equals("getDefaultPosition"))
          break; 
        b = 1;
        break;
      case -2070199965:
        if (!paramString.equals("closeVideo"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback not recognized.");
        Log.e("CBWebChromeClient", stringBuilder2.toString());
        return "Function name not recognized.";
      case 27:
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return this.g.o();
      case 26:
        this.h.post(this.j.l);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 25:
        Log.d(m1.class.getName(), "Javascript warning occurred");
        this.h.post(this.j.q);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 24:
        this.h.post(this.j.k);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 23:
        this.h.post(this.j.p);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 22:
        this.h.post(this.j.n);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 21:
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return this.g.p();
      case 20:
        this.h.post(this.j.s);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        return "Native function successfully called.";
      case 19:
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("JavaScript to native ");
        stringBuilder2.append(paramString);
        stringBuilder2.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder2.toString());
        a1 = this.g.C;
        if (a1 != null) {
          k k = a1.q;
          if (k != null) {
            JSONObject jSONObject = v0.a(new v0.a[0]);
            for (Map.Entry entry : k.c.entrySet())
              v0.a(jSONObject, (String)entry.getKey(), entry.getValue()); 
            for (Map.Entry entry : k.b.entrySet()) {
              g0 g0 = (g0)entry.getValue();
              String str = (String)entry.getKey();
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(g0.a);
              stringBuilder.append("/");
              stringBuilder.append(g0.b);
              v0.a(jSONObject, str, stringBuilder.toString());
            } 
            return jSONObject.toString();
          } 
        } 
        return "{}";
      case 18:
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        this.h.post(this.j.r);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 17:
        Log.d(m1.class.getName(), "Javascript Error occured");
        this.h.post(this.j.h);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 16:
        this.h.post(this.j.g);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 15:
        this.h.post(this.j.e);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 14:
        this.h.post(this.j.d);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 13:
        this.h.post(this.j.j);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 12:
        this.h.post(this.j.x);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 11:
        this.h.post(this.j.v);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 10:
        this.h.post(this.j.o);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 9:
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return this.g.q();
      case 8:
        this.h.post(this.j.y);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 7:
        this.h.post(this.j.t);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 6:
        this.h.post(this.j.m);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 5:
        this.h.post(this.j.i);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 4:
        this.h.post(this.j.f);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 3:
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return this.g.j();
      case 2:
        this.h.post(this.j.u);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return "Native function successfully called.";
      case 1:
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("JavaScript to native ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" callback triggered.");
        Log.d("CBWebChromeClient", stringBuilder1.toString());
        return this.g.k();
      case 0:
        break;
    } 
    this.h.post(this.j.w);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("JavaScript to native ");
    stringBuilder1.append(paramString);
    stringBuilder1.append(" callback triggered.");
    Log.d("CBWebChromeClient", stringBuilder1.toString());
    return "Native function successfully called.";
  }
  
  public final void a(String paramString) {
    h6 h61 = this.i;
    if (h61 != null)
      h61.a(paramString, this); 
  }
  
  public void a(JSONObject paramJSONObject) {
    a(paramJSONObject, "error");
  }
  
  public boolean onConsoleMessage(ConsoleMessage paramConsoleMessage) {
    String str = paramConsoleMessage.message();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Chartboost Webview:");
    stringBuilder.append(str);
    stringBuilder.append(" -- From line ");
    stringBuilder.append(paramConsoleMessage.lineNumber());
    stringBuilder.append(" of ");
    stringBuilder.append(paramConsoleMessage.sourceId());
    Log.d("k1", stringBuilder.toString());
    a(str);
    return true;
  }
  
  public void onHideCustomView() {
    if (this.c) {
      this.b.setVisibility(4);
      this.b.removeView((View)this.d);
      this.a.setVisibility(0);
      WebChromeClient.CustomViewCallback customViewCallback = this.e;
      if (customViewCallback != null && !customViewCallback.getClass().getName().contains(".chromium."))
        this.e.onCustomViewHidden(); 
      this.c = false;
      this.d = null;
      this.e = null;
      a a1 = this.f;
      if (a1 != null)
        a1.a(false); 
    } 
  }
  
  public boolean onJsPrompt(WebView paramWebView, String paramString1, String paramString2, String paramString3, JsPromptResult paramJsPromptResult) {
    try {
      JSONObject jSONObject = new JSONObject(paramString2);
      String str = jSONObject.getString("eventType");
      jSONObject = jSONObject.getJSONObject("eventArgs");
      paramJsPromptResult.confirm(a(jSONObject, str));
      return true;
    } catch (JSONException jSONException) {
      m3.b("CBWebChromeClient", "Exception caught parsing the function name from js to native");
      return true;
    } 
  }
  
  public void onShowCustomView(View paramView, int paramInt, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
    onShowCustomView(paramView, paramCustomViewCallback);
  }
  
  public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
    if (paramView instanceof FrameLayout) {
      FrameLayout frameLayout = (FrameLayout)paramView;
      this.c = true;
      this.d = frameLayout;
      this.e = paramCustomViewCallback;
      this.a.setVisibility(4);
      this.b.addView((View)this.d, new ViewGroup.LayoutParams(-1, -1));
      this.b.setVisibility(0);
      a a1 = this.f;
      if (a1 != null)
        a1.a(true); 
    } 
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */