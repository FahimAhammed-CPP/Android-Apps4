package com.chartboost.sdk.impl;

import com.chartboost.sdk.Mediation;

public class c2 extends r5 {
  public c2(String paramString1, String paramString2, String paramString3, String paramString4) {
    this(paramString1, paramString2, paramString3, paramString4, null);
  }
  
  public c2(String paramString1, String paramString2, String paramString3, String paramString4, Mediation paramMediation) {
    super(paramString1, paramString2, paramString3, paramString4, paramMediation);
    a(r5.a.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */