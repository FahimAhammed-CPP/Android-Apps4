package com.chartboost.sdk.impl;

import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

@Metadata(bv = {}, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\027\022\006\020\023\032\0020\022\022\006\020\025\032\0020\024¢\006\004\b\026\020\027R\033\020\007\032\0020\0028VX\002¢\006\f\n\004\b\003\020\004\032\004\b\005\020\006R\033\020\f\032\0020\b8VX\002¢\006\f\n\004\b\t\020\004\032\004\b\n\020\013R\033\020\021\032\0020\r8BX\002¢\006\f\n\004\b\016\020\004\032\004\b\017\020\020¨\006\030"}, d2 = {"Lcom/chartboost/sdk/impl/r4;", "Lcom/chartboost/sdk/impl/q4;", "Lcom/chartboost/sdk/impl/f1;", "uiManager$delegate", "Lkotlin/Lazy;", "b", "()Lcom/chartboost/sdk/impl/f1;", "uiManager", "Lcom/chartboost/sdk/impl/i1;", "viewController$delegate", "a", "()Lcom/chartboost/sdk/impl/i1;", "viewController", "Lcom/chartboost/sdk/impl/a0;", "animationManager$delegate", "c", "()Lcom/chartboost/sdk/impl/a0;", "animationManager", "Lcom/chartboost/sdk/impl/y;", "androidComponent", "Lcom/chartboost/sdk/impl/e0;", "applicationComponent", "<init>", "(Lcom/chartboost/sdk/impl/y;Lcom/chartboost/sdk/impl/e0;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class r4 implements q4 {
  public final Lazy a;
  
  public final Lazy b;
  
  public final Lazy c;
  
  public r4(y paramy, e0 parame0) {
    this.a = LazyKt.lazy(new b(paramy, this));
    this.b = LazyKt.lazy(new c(this, parame0, paramy));
    this.c = LazyKt.lazy(new a(paramy));
  }
  
  public i1 a() {
    return (i1)this.b.getValue();
  }
  
  public f1 b() {
    return (f1)this.a.getValue();
  }
  
  public final a0 c() {
    return (a0)this.c.getValue();
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/a0;", "a", "()Lcom/chartboost/sdk/impl/a0;"}, k = 3, mv = {1, 6, 0})
  public static final class a extends Lambda implements Function0<a0> {
    public a(y param1y) {
      super(0);
    }
    
    public final a0 a() {
      return new a0(this.a.b());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/f1;", "a", "()Lcom/chartboost/sdk/impl/f1;"}, k = 3, mv = {1, 6, 0})
  public static final class b extends Lambda implements Function0<f1> {
    public b(y param1y, r4 param1r4) {
      super(0);
    }
    
    public final f1 a() {
      return new f1(this.a.c(), this.a.b(), this.b.a());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/i1;", "a", "()Lcom/chartboost/sdk/impl/i1;"}, k = 3, mv = {1, 6, 0})
  public static final class c extends Lambda implements Function0<i1> {
    public c(r4 param1r4, e0 param1e0, y param1y) {
      super(0);
    }
    
    public final i1 a() {
      return new i1(r4.a(this.a), this.b.n(), this.b.g(), this.c.b());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\r4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */