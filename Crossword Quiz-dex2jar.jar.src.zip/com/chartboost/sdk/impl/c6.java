package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Libraries.CBUtility;
import com.chartboost.sdk.internal.Model.CBError;
import java.io.File;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {}, d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\t\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\030\0002\n\022\006\022\004\030\0010\0020\001:\001\004BA\022\b\020\020\032\004\030\0010\017\022\b\020\022\032\004\030\0010\021\022\b\020\f\032\004\030\0010\013\022\b\020\024\032\004\030\0010\023\022\b\b\002\020\026\032\0020\025\022\006\020\027\032\0020\013¢\006\004\b\030\020\031J\b\020\004\032\0020\003H\026J\034\020\004\032\0020\b2\b\020\005\032\004\030\0010\0022\b\020\007\032\004\030\0010\006H\026J\034\020\004\032\0020\b2\b\020\n\032\004\030\0010\t2\b\020\005\032\004\030\0010\006H\026J\030\020\004\032\0020\b2\006\020\f\032\0020\0132\006\020\016\032\0020\rH\026¨\006\032"}, d2 = {"Lcom/chartboost/sdk/impl/c6;", "Lcom/chartboost/sdk/impl/w0;", "", "Lcom/chartboost/sdk/impl/x0;", "a", "response", "Lcom/chartboost/sdk/impl/z0;", "serverResponse", "", "Lcom/chartboost/sdk/internal/Model/CBError;", "error", "", "uri", "", "expectedContentSize", "Lcom/chartboost/sdk/impl/b1;", "reachability", "Ljava/io/File;", "outputFile", "Lcom/chartboost/sdk/impl/c6$a;", "callback", "Lcom/chartboost/sdk/impl/f4;", "priority", "appId", "<init>", "(Lcom/chartboost/sdk/impl/b1;Ljava/io/File;Ljava/lang/String;Lcom/chartboost/sdk/impl/c6$a;Lcom/chartboost/sdk/impl/f4;Ljava/lang/String;)V", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class c6 extends w0<Object> {
  public final b1 j;
  
  public final a k;
  
  public final f4 l;
  
  public final String m;
  
  public c6(b1 paramb1, File paramFile, String paramString1, a parama, f4 paramf4, String paramString2) {
    super("GET", paramString1, paramf4, paramFile);
    this.j = paramb1;
    this.k = parama;
    this.l = paramf4;
    this.m = paramString2;
    this.i = 1;
  }
  
  public x0 a() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("X-Chartboost-App", this.m);
    String str = CBUtility.b();
    Intrinsics.checkNotNullExpressionValue(str, "getUserAgent()");
    hashMap.put("X-Chartboost-Client", str);
    b1 b11 = this.j;
    if (b11 != null) {
      a2 a2 = b11.b();
    } else {
      b11 = null;
    } 
    hashMap.put("X-Chartboost-Reachability", String.valueOf(b11));
    return new x0(hashMap, null, null);
  }
  
  public void a(CBError paramCBError, z0 paramz0) {
    a a1 = this.k;
    if (a1 != null) {
      String str1 = this.b;
      Intrinsics.checkNotNullExpressionValue(str1, "uri");
      String str2 = this.e.getName();
      Intrinsics.checkNotNullExpressionValue(str2, "outputFile.name");
      a1.a(str1, str2, paramCBError);
    } 
  }
  
  public void a(Object paramObject, z0 paramz0) {
    paramObject = this.k;
    if (paramObject != null) {
      String str1 = this.b;
      Intrinsics.checkNotNullExpressionValue(str1, "uri");
      String str2 = this.e.getName();
      Intrinsics.checkNotNullExpressionValue(str2, "outputFile.name");
      paramObject.a(str1, str2);
    } 
  }
  
  public void a(String paramString, long paramLong) {
    Intrinsics.checkNotNullParameter(paramString, "uri");
    a a1 = this.k;
    if (a1 != null) {
      String str = this.e.getName();
      Intrinsics.checkNotNullExpressionValue(str, "outputFile.name");
      a1.a(paramString, str, paramLong, null);
    } 
  }
  
  @Metadata(bv = {}, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\002\n\002\020\t\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\bf\030\0002\0020\001J*\020\n\032\0020\t2\006\020\003\032\0020\0022\006\020\004\032\0020\0022\006\020\006\032\0020\0052\b\020\b\032\004\030\0010\007H&J\030\020\n\032\0020\t2\006\020\013\032\0020\0022\006\020\004\032\0020\002H&J\"\020\n\032\0020\t2\006\020\013\032\0020\0022\006\020\004\032\0020\0022\b\020\r\032\004\030\0010\fH&¨\006\016"}, d2 = {"Lcom/chartboost/sdk/impl/c6$a;", "", "", "url", "videoFileName", "", "expectedContentSize", "Lcom/chartboost/sdk/impl/b6$a;", "adUnitVideoPrecacheTempCallback", "", "a", "uri", "Lcom/chartboost/sdk/internal/Model/CBError;", "error", "Chartboost-9.1.1_productionRelease"}, k = 1, mv = {1, 6, 0})
  public static interface a {
    void a(String param1String1, String param1String2);
    
    void a(String param1String1, String param1String2, long param1Long, b6.a param1a);
    
    void a(String param1String1, String param1String2, CBError param1CBError);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\chartboost\sdk\impl\c6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */