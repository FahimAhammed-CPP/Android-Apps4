package com.adjust.sdk;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Process;
import com.adjust.sdk.network.ActivityPackageSender;
import com.adjust.sdk.network.IActivityPackageSender;
import com.adjust.sdk.network.UtilNetworking;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadExecutor;
import com.adjust.sdk.scheduler.TimerCycle;
import com.adjust.sdk.scheduler.TimerOnce;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.json.JSONObject;

public class ActivityHandler implements IActivityHandler {
  private static final String ACTIVITY_STATE_NAME = "Activity state";
  
  private static final String ATTRIBUTION_NAME = "Attribution";
  
  private static long BACKGROUND_TIMER_INTERVAL = 0L;
  
  private static final String BACKGROUND_TIMER_NAME = "Background timer";
  
  private static final String DELAY_START_TIMER_NAME = "Delay Start timer";
  
  private static long FOREGROUND_TIMER_INTERVAL = 0L;
  
  private static final String FOREGROUND_TIMER_NAME = "Foreground timer";
  
  private static long FOREGROUND_TIMER_START = 0L;
  
  private static final String SESSION_CALLBACK_PARAMETERS_NAME = "Session Callback parameters";
  
  private static long SESSION_INTERVAL = 0L;
  
  private static final String SESSION_PARAMETERS_NAME = "Session parameters";
  
  private static final String SESSION_PARTNER_PARAMETERS_NAME = "Session Partner parameters";
  
  private static long SUBSESSION_INTERVAL = 0L;
  
  private static final String TIME_TRAVEL = "Time travel!";
  
  private ActivityState activityState;
  
  private AdjustConfig adjustConfig;
  
  private AdjustAttribution attribution;
  
  private IAttributionHandler attributionHandler;
  
  private TimerOnce backgroundTimer;
  
  private String basePath;
  
  private TimerOnce delayStartTimer;
  
  private a deviceInfo;
  
  private ThreadExecutor executor;
  
  private TimerCycle foregroundTimer;
  
  private String gdprPath;
  
  private InstallReferrer installReferrer;
  
  private InstallReferrerHuawei installReferrerHuawei;
  
  private InternalState internalState;
  
  private ILogger logger;
  
  private IPackageHandler packageHandler;
  
  private ISdkClickHandler sdkClickHandler;
  
  private SessionParameters sessionParameters;
  
  private String subscriptionPath;
  
  private ActivityHandler(AdjustConfig paramAdjustConfig) {
    boolean bool;
    init(paramAdjustConfig);
    ILogger iLogger = AdjustFactory.getLogger();
    this.logger = iLogger;
    iLogger.lockLogLevel();
    this.executor = (ThreadExecutor)new SingleThreadCachedScheduler("ActivityHandler");
    InternalState internalState = new InternalState();
    this.internalState = internalState;
    Boolean bool1 = paramAdjustConfig.startEnabled;
    if (bool1 != null) {
      bool = bool1.booleanValue();
    } else {
      bool = true;
    } 
    internalState.enabled = bool;
    internalState = this.internalState;
    internalState.offline = paramAdjustConfig.startOffline;
    internalState.background = true;
    internalState.delayStart = false;
    internalState.updatePackages = false;
    internalState.sessionResponseProcessed = false;
    internalState.firstSdkStart = false;
    internalState.preinstallHasBeenRead = false;
    this.executor.submit(new k(this));
  }
  
  private void backgroundTimerFiredI() {
    if (toSendI())
      this.packageHandler.sendFirstPackage(); 
  }
  
  private boolean checkActivityStateI(ActivityState paramActivityState) {
    if (this.internalState.hasFirstSdkStartNotOcurred()) {
      this.logger.error("Sdk did not yet start", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private boolean checkAdjustAdRevenue(AdjustAdRevenue paramAdjustAdRevenue) {
    if (paramAdjustAdRevenue == null) {
      this.logger.error("Ad revenue object missing", new Object[0]);
      return false;
    } 
    if (!paramAdjustAdRevenue.isValid()) {
      this.logger.error("Ad revenue object not initialized correctly", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private void checkAfterNewStartI() {
    checkAfterNewStartI(SharedPreferencesManager.getDefaultInstance(getContext()));
  }
  
  private void checkAfterNewStartI(SharedPreferencesManager paramSharedPreferencesManager) {
    String str = paramSharedPreferencesManager.getPushToken();
    if (str != null && !str.equals(this.activityState.pushToken))
      setPushToken(str, true); 
    if (paramSharedPreferencesManager.getRawReferrerArray() != null)
      sendReftagReferrer(); 
    checkForPreinstallI();
    this.installReferrer.startConnection();
    this.installReferrerHuawei.readReferrer();
    readInstallReferrerSamsung();
    readInstallReferrerXiaomi();
  }
  
  private void checkAttributionStateI() {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (this.internalState.isFirstLaunch() && this.internalState.hasSessionResponseNotBeenProcessed())
      return; 
    if (this.attribution != null && !this.activityState.askingAttribution)
      return; 
    this.attributionHandler.getAttribution();
  }
  
  private boolean checkEventI(AdjustEvent paramAdjustEvent) {
    if (paramAdjustEvent == null) {
      this.logger.error("Event missing", new Object[0]);
      return false;
    } 
    if (!paramAdjustEvent.isValid()) {
      this.logger.error("Event not initialized correctly", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private void checkForInstallReferrerInfo(SdkClickResponseData paramSdkClickResponseData) {
    boolean bool1;
    if (!paramSdkClickResponseData.isInstallReferrer)
      return; 
    String str = paramSdkClickResponseData.referrerApi;
    boolean bool2 = true;
    if (str != null && str.equalsIgnoreCase("huawei_ads")) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      ActivityState activityState = this.activityState;
      activityState.clickTimeHuawei = paramSdkClickResponseData.clickTime;
      activityState.installBeginHuawei = paramSdkClickResponseData.installBegin;
      activityState.installReferrerHuawei = paramSdkClickResponseData.installReferrer;
    } else {
      str = paramSdkClickResponseData.referrerApi;
      if (str != null && str.equalsIgnoreCase("huawei_app_gallery")) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        ActivityState activityState = this.activityState;
        activityState.clickTimeHuawei = paramSdkClickResponseData.clickTime;
        activityState.installBeginHuawei = paramSdkClickResponseData.installBegin;
        activityState.installReferrerHuaweiAppGallery = paramSdkClickResponseData.installReferrer;
      } else {
        str = paramSdkClickResponseData.referrerApi;
        if (str != null && str.equalsIgnoreCase("samsung")) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool1) {
          ActivityState activityState = this.activityState;
          activityState.clickTimeSamsung = paramSdkClickResponseData.clickTime;
          activityState.installBeginSamsung = paramSdkClickResponseData.installBegin;
          activityState.installReferrerSamsung = paramSdkClickResponseData.installReferrer;
        } else {
          str = paramSdkClickResponseData.referrerApi;
          if (str != null && str.equalsIgnoreCase("xiaomi")) {
            bool1 = bool2;
          } else {
            bool1 = false;
          } 
          ActivityState activityState = this.activityState;
          if (bool1) {
            activityState.clickTimeXiaomi = paramSdkClickResponseData.clickTime;
            activityState.installBeginXiaomi = paramSdkClickResponseData.installBegin;
            activityState.installReferrerXiaomi = paramSdkClickResponseData.installReferrer;
            activityState.clickTimeServerXiaomi = paramSdkClickResponseData.clickTimeServer;
            activityState.installBeginServerXiaomi = paramSdkClickResponseData.installBeginServer;
            activityState.installVersionXiaomi = paramSdkClickResponseData.installVersion;
          } else {
            activityState.clickTime = paramSdkClickResponseData.clickTime;
            activityState.installBegin = paramSdkClickResponseData.installBegin;
            activityState.installReferrer = paramSdkClickResponseData.installReferrer;
            activityState.clickTimeServer = paramSdkClickResponseData.clickTimeServer;
            activityState.installBeginServer = paramSdkClickResponseData.installBeginServer;
            activityState.installVersion = paramSdkClickResponseData.installVersion;
            activityState.googlePlayInstant = paramSdkClickResponseData.googlePlayInstant;
          } 
        } 
      } 
    } 
    writeActivityStateI();
  }
  
  private void checkForPreinstallI() {
    ActivityState activityState = this.activityState;
    if (activityState == null)
      return; 
    if (!activityState.enabled)
      return; 
    if (activityState.isGdprForgotten)
      return; 
    sendPreinstallReferrerI();
    if (!this.adjustConfig.preinstallTrackingEnabled)
      return; 
    if (this.internalState.hasPreinstallBeenRead())
      return; 
    String str = this.deviceInfo.i;
    if (str == null || str.isEmpty()) {
      this.logger.debug("Can't read preinstall payload, invalid package name", new Object[0]);
      return;
    } 
    SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
    long l2 = sharedPreferencesManager.getPreinstallPayloadReadStatus();
    if (PreinstallUtil.hasAllLocationsBeenRead(l2)) {
      this.internalState.preinstallHasBeenRead = true;
      return;
    } 
    long l1 = l2;
    if (PreinstallUtil.hasNotBeenRead("system_properties", l2)) {
      String str1 = PreinstallUtil.getPayloadFromSystemProperty(this.deviceInfo.i, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "system_properties");
        l1 = l2;
      } else {
        l1 = PreinstallUtil.markAsRead("system_properties", l2);
      } 
    } 
    l2 = l1;
    if (PreinstallUtil.hasNotBeenRead("system_properties_reflection", l1)) {
      String str1 = PreinstallUtil.getPayloadFromSystemPropertyReflection(this.deviceInfo.i, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "system_properties_reflection");
        l2 = l1;
      } else {
        l2 = PreinstallUtil.markAsRead("system_properties_reflection", l1);
      } 
    } 
    l1 = l2;
    if (PreinstallUtil.hasNotBeenRead("system_properties_path", l2)) {
      String str1 = PreinstallUtil.getPayloadFromSystemPropertyFilePath(this.deviceInfo.i, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "system_properties_path");
        l1 = l2;
      } else {
        l1 = PreinstallUtil.markAsRead("system_properties_path", l2);
      } 
    } 
    l2 = l1;
    if (PreinstallUtil.hasNotBeenRead("system_properties_path_reflection", l1)) {
      String str1 = PreinstallUtil.getPayloadFromSystemPropertyFilePathReflection(this.deviceInfo.i, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "system_properties_path_reflection");
        l2 = l1;
      } else {
        l2 = PreinstallUtil.markAsRead("system_properties_path_reflection", l1);
      } 
    } 
    l1 = l2;
    if (PreinstallUtil.hasNotBeenRead("content_provider", l2)) {
      String str1 = PreinstallUtil.getPayloadFromContentProviderDefault(this.adjustConfig.context, this.deviceInfo.i, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "content_provider");
        l1 = l2;
      } else {
        l1 = PreinstallUtil.markAsRead("content_provider", l2);
      } 
    } 
    l2 = l1;
    if (PreinstallUtil.hasNotBeenRead("content_provider_intent_action", l1)) {
      List list = PreinstallUtil.getPayloadsFromContentProviderIntentAction(this.adjustConfig.context, this.deviceInfo.i, this.logger);
      if (list != null && !list.isEmpty()) {
        Iterator<String> iterator = list.iterator();
        while (true) {
          l2 = l1;
          if (iterator.hasNext()) {
            String str1 = iterator.next();
            this.sdkClickHandler.sendPreinstallPayload(str1, "content_provider_intent_action");
            continue;
          } 
          break;
        } 
      } else {
        l2 = PreinstallUtil.markAsRead("content_provider_intent_action", l1);
      } 
    } 
    l1 = l2;
    if (PreinstallUtil.hasNotBeenRead("content_provider_no_permission", l2)) {
      List list = PreinstallUtil.getPayloadsFromContentProviderNoPermission(this.adjustConfig.context, this.deviceInfo.i, this.logger);
      if (list != null && !list.isEmpty()) {
        Iterator<String> iterator = list.iterator();
        while (true) {
          l1 = l2;
          if (iterator.hasNext()) {
            String str1 = iterator.next();
            this.sdkClickHandler.sendPreinstallPayload(str1, "content_provider_no_permission");
            continue;
          } 
          break;
        } 
      } else {
        l1 = PreinstallUtil.markAsRead("content_provider_no_permission", l2);
      } 
    } 
    l2 = l1;
    if (PreinstallUtil.hasNotBeenRead("file_system", l1)) {
      String str1 = PreinstallUtil.getPayloadFromFileSystem(this.deviceInfo.i, this.adjustConfig.preinstallFilePath, this.logger);
      if (str1 != null && !str1.isEmpty()) {
        this.sdkClickHandler.sendPreinstallPayload(str1, "file_system");
        l2 = l1;
      } else {
        l2 = PreinstallUtil.markAsRead("file_system", l1);
      } 
    } 
    sharedPreferencesManager.setPreinstallPayloadReadStatus(l2);
    this.internalState.preinstallHasBeenRead = true;
  }
  
  private boolean checkOrderIdI(String paramString) {
    if (paramString != null) {
      if (paramString.isEmpty())
        return true; 
      if (this.activityState.findOrderId(paramString)) {
        this.logger.info("Skipping duplicated order ID '%s'", new Object[] { paramString });
        return false;
      } 
      this.activityState.addOrderId(paramString);
      this.logger.verbose("Added order ID '%s'", new Object[] { paramString });
    } 
    return true;
  }
  
  private Intent createDeeplinkIntentI(Uri paramUri) {
    Intent intent;
    if (this.adjustConfig.deepLinkComponent == null) {
      intent = new Intent("android.intent.action.VIEW", paramUri);
    } else {
      AdjustConfig adjustConfig = this.adjustConfig;
      intent = new Intent("android.intent.action.VIEW", (Uri)intent, adjustConfig.context, adjustConfig.deepLinkComponent);
    } 
    intent.setFlags(268435456);
    intent.setPackage(this.adjustConfig.context.getPackageName());
    return intent;
  }
  
  private void delayStartI() {
    double d;
    if (this.internalState.isNotInDelayedStart())
      return; 
    if (isToUpdatePackagesI())
      return; 
    Double double_ = this.adjustConfig.delayStart;
    if (double_ != null) {
      d = double_.doubleValue();
    } else {
      d = 0.0D;
    } 
    long l1 = AdjustFactory.getMaxDelayStart();
    long l2 = (long)(1000.0D * d);
    if (l2 > l1) {
      double d1 = (l1 / 1000L);
      DecimalFormat decimalFormat = Util.SecondsDisplayFormat;
      String str1 = decimalFormat.format(d);
      String str2 = decimalFormat.format(d1);
      this.logger.warn("Delay start of %s seconds bigger than max allowed value of %s seconds", new Object[] { str1, str2 });
      d = d1;
    } else {
      l1 = l2;
    } 
    String str = Util.SecondsDisplayFormat.format(d);
    this.logger.info("Waiting %s seconds before starting first session", new Object[] { str });
    this.delayStartTimer.startIn(l1);
    this.internalState.updatePackages = true;
    ActivityState activityState = this.activityState;
    if (activityState != null) {
      activityState.updatePackages = true;
      writeActivityStateI();
    } 
  }
  
  public static boolean deleteActivityState(Context paramContext) {
    return paramContext.deleteFile("AdjustIoActivityState");
  }
  
  public static boolean deleteAttribution(Context paramContext) {
    return paramContext.deleteFile("AdjustAttribution");
  }
  
  public static boolean deleteSessionCallbackParameters(Context paramContext) {
    return paramContext.deleteFile("AdjustSessionCallbackParameters");
  }
  
  public static boolean deleteSessionPartnerParameters(Context paramContext) {
    return paramContext.deleteFile("AdjustSessionPartnerParameters");
  }
  
  public static void deleteState(Context paramContext) {
    deleteActivityState(paramContext);
    deleteAttribution(paramContext);
    deleteSessionCallbackParameters(paramContext);
    deleteSessionPartnerParameters(paramContext);
    SharedPreferencesManager.getDefaultInstance(paramContext).clear();
  }
  
  private void disableThirdPartySharingForCoppaEnabledI() {
    if (!shouldDisableThirdPartySharingWhenCoppaEnabled())
      return; 
    this.activityState.isThirdPartySharingDisabledForCoppa = true;
    writeActivityStateI();
    AdjustThirdPartySharing adjustThirdPartySharing = new AdjustThirdPartySharing(Boolean.FALSE);
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildThirdPartySharingPackage(adjustThirdPartySharing);
    this.packageHandler.addPackage(activityPackage);
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  private void disableThirdPartySharingI() {
    SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
    sharedPreferencesManager.setDisableThirdPartySharing();
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    ActivityState activityState = this.activityState;
    if (activityState.isGdprForgotten)
      return; 
    if (activityState.isThirdPartySharingDisabled)
      return; 
    if (this.adjustConfig.coppaCompliantEnabled) {
      this.logger.warn("Call to disable third party sharing API ignored, already done when COPPA enabled", new Object[0]);
      return;
    } 
    activityState.isThirdPartySharingDisabled = true;
    writeActivityStateI();
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildDisableThirdPartySharingPackage();
    this.packageHandler.addPackage(activityPackage);
    sharedPreferencesManager.removeDisableThirdPartySharing();
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  private void endI() {
    if (!toSendI())
      pauseSendingI(); 
    if (updateActivityStateI(System.currentTimeMillis()))
      writeActivityStateI(); 
  }
  
  private void foregroundTimerFiredI() {
    if (!isEnabledI()) {
      stopForegroundTimerI();
      return;
    } 
    if (toSendI())
      this.packageHandler.sendFirstPackage(); 
    if (updateActivityStateI(System.currentTimeMillis()))
      writeActivityStateI(); 
  }
  
  private void gdprForgetMeI() {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    ActivityState activityState = this.activityState;
    if (activityState.isGdprForgotten)
      return; 
    activityState.isGdprForgotten = true;
    writeActivityStateI();
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildGdprPackage();
    this.packageHandler.addPackage(activityPackage);
    SharedPreferencesManager.getDefaultInstance(getContext()).removeGdprForgetMe();
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  public static ActivityHandler getInstance(AdjustConfig paramAdjustConfig) {
    if (paramAdjustConfig == null) {
      AdjustFactory.getLogger().error("AdjustConfig missing", new Object[0]);
      return null;
    } 
    if (!paramAdjustConfig.isValid()) {
      AdjustFactory.getLogger().error("AdjustConfig not initialized correctly", new Object[0]);
      return null;
    } 
    if (paramAdjustConfig.processName != null) {
      int i = Process.myPid();
      ActivityManager activityManager = (ActivityManager)paramAdjustConfig.context.getSystemService("activity");
      if (activityManager == null)
        return null; 
      List list = activityManager.getRunningAppProcesses();
      if (list == null)
        return null; 
      for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
        if (runningAppProcessInfo.pid == i) {
          if (!runningAppProcessInfo.processName.equalsIgnoreCase(paramAdjustConfig.processName)) {
            AdjustFactory.getLogger().info("Skipping initialization in background process (%s)", new Object[] { runningAppProcessInfo.processName });
            return null;
          } 
          break;
        } 
      } 
    } 
    return new ActivityHandler(paramAdjustConfig);
  }
  
  private void gotOptOutResponseI() {
    this.activityState.isGdprForgotten = true;
    writeActivityStateI();
    this.packageHandler.flush();
    setEnabledI(false);
  }
  
  private boolean hasChangedStateI(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2) {
    if (paramBoolean1 != paramBoolean2)
      return true; 
    if (paramBoolean1) {
      this.logger.debug(paramString1, new Object[0]);
      return false;
    } 
    this.logger.debug(paramString2, new Object[0]);
    return false;
  }
  
  private void initI() {
    SESSION_INTERVAL = AdjustFactory.getSessionInterval();
    SUBSESSION_INTERVAL = AdjustFactory.getSubsessionInterval();
    FOREGROUND_TIMER_INTERVAL = AdjustFactory.getTimerInterval();
    FOREGROUND_TIMER_START = AdjustFactory.getTimerStart();
    BACKGROUND_TIMER_INTERVAL = AdjustFactory.getTimerInterval();
    readAttributionI(this.adjustConfig.context);
    readActivityStateI(this.adjustConfig.context);
    this.sessionParameters = new SessionParameters();
    readSessionCallbackParametersI(this.adjustConfig.context);
    readSessionPartnerParametersI(this.adjustConfig.context);
    AdjustConfig adjustConfig4 = this.adjustConfig;
    if (adjustConfig4.startEnabled != null)
      adjustConfig4.preLaunchActions.preLaunchActionsArray.add(new a0(this)); 
    if (this.internalState.hasFirstSdkStartOcurred()) {
      InternalState internalState = this.internalState;
      ActivityState activityState = this.activityState;
      internalState.enabled = activityState.enabled;
      internalState.updatePackages = activityState.updatePackages;
      internalState.firstLaunch = false;
    } else {
      this.internalState.firstLaunch = true;
    } 
    readConfigFile(this.adjustConfig.context);
    adjustConfig4 = this.adjustConfig;
    this.deviceInfo = new a(adjustConfig4.context, adjustConfig4.sdkPrefix);
    if (this.adjustConfig.eventBufferingEnabled)
      this.logger.info("Event buffering is enabled", new Object[0]); 
    this.deviceInfo.b(this.adjustConfig);
    if (this.deviceInfo.a == null) {
      if (!Util.canReadPlayIds(this.adjustConfig)) {
        if (this.adjustConfig.coppaCompliantEnabled)
          this.logger.info("Cannot read Google Play Services Advertising ID with COPPA enabled", new Object[0]); 
        if (this.adjustConfig.playStoreKidsAppEnabled)
          this.logger.info("Cannot read Google Play Services Advertising ID with play store kids app enabled", new Object[0]); 
      } else {
        this.logger.warn("Unable to get Google Play Services Advertising ID at start time", new Object[0]);
      } 
      if (this.deviceInfo.f == null)
        if (!Util.canReadNonPlayIds(this.adjustConfig)) {
          if (this.adjustConfig.coppaCompliantEnabled)
            this.logger.info("Cannot read non Play IDs with COPPA enabled", new Object[0]); 
          if (this.adjustConfig.playStoreKidsAppEnabled)
            this.logger.info("Cannot read non Play IDs with play store kids app enabled", new Object[0]); 
        } else {
          this.logger.error("Unable to get any Device IDs. Please check if Proguard is correctly set with Adjust SDK", new Object[0]);
        }  
    } else {
      this.logger.info("Google Play Services Advertising ID read correctly at start time", new Object[0]);
    } 
    String str = this.adjustConfig.defaultTracker;
    if (str != null)
      this.logger.info("Default tracker: '%s'", new Object[] { str }); 
    str = this.adjustConfig.pushToken;
    if (str != null) {
      this.logger.info("Push token: '%s'", new Object[] { str });
      if (this.internalState.hasFirstSdkStartOcurred()) {
        setPushToken(this.adjustConfig.pushToken, false);
      } else {
        SharedPreferencesManager.getDefaultInstance(getContext()).savePushToken(this.adjustConfig.pushToken);
      } 
    } else if (this.internalState.hasFirstSdkStartOcurred()) {
      str = SharedPreferencesManager.getDefaultInstance(getContext()).getPushToken();
      if (str != null)
        setPushToken(str, true); 
    } 
    if (this.internalState.hasFirstSdkStartOcurred()) {
      SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
      if (sharedPreferencesManager.getGdprForgetMe()) {
        gdprForgetMe();
      } else {
        if (sharedPreferencesManager.getDisableThirdPartySharing())
          disableThirdPartySharing(); 
        Iterator<AdjustThirdPartySharing> iterator = this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray.iterator();
        while (iterator.hasNext())
          trackThirdPartySharing(iterator.next()); 
        Boolean bool = this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked;
        if (bool != null)
          trackMeasurementConsent(bool.booleanValue()); 
        this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray = new ArrayList();
        this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked = null;
      } 
    } 
    this.foregroundTimer = new TimerCycle(new b0(this), FOREGROUND_TIMER_START, FOREGROUND_TIMER_INTERVAL, "Foreground timer");
    if (this.adjustConfig.sendInBackground) {
      this.logger.info("Send in background configured", new Object[0]);
      this.backgroundTimer = new TimerOnce(new c0(this), "Background timer");
    } 
    if (this.internalState.hasFirstSdkStartNotOcurred()) {
      Double double_ = this.adjustConfig.delayStart;
      if (double_ != null && double_.doubleValue() > 0.0D) {
        this.logger.info("Delay start configured", new Object[0]);
        this.internalState.delayStart = true;
        this.delayStartTimer = new TimerOnce(new d0(this), "Delay Start timer");
      } 
    } 
    UtilNetworking.setUserAgent(this.adjustConfig.userAgent);
    AdjustConfig adjustConfig3 = this.adjustConfig;
    ActivityPackageSender activityPackageSender3 = new ActivityPackageSender(adjustConfig3.urlStrategy, adjustConfig3.basePath, adjustConfig3.gdprPath, adjustConfig3.subscriptionPath, this.deviceInfo.h);
    this.packageHandler = AdjustFactory.getPackageHandler(this, this.adjustConfig.context, toSendI(false), (IActivityPackageSender)activityPackageSender3);
    AdjustConfig adjustConfig2 = this.adjustConfig;
    ActivityPackageSender activityPackageSender2 = new ActivityPackageSender(adjustConfig2.urlStrategy, adjustConfig2.basePath, adjustConfig2.gdprPath, adjustConfig2.subscriptionPath, this.deviceInfo.h);
    this.attributionHandler = AdjustFactory.getAttributionHandler(this, toSendI(false), (IActivityPackageSender)activityPackageSender2);
    AdjustConfig adjustConfig1 = this.adjustConfig;
    ActivityPackageSender activityPackageSender1 = new ActivityPackageSender(adjustConfig1.urlStrategy, adjustConfig1.basePath, adjustConfig1.gdprPath, adjustConfig1.subscriptionPath, this.deviceInfo.h);
    this.sdkClickHandler = AdjustFactory.getSdkClickHandler(this, toSendI(true), (IActivityPackageSender)activityPackageSender1);
    if (isToUpdatePackagesI())
      updatePackagesI(); 
    this.installReferrer = new InstallReferrer(this.adjustConfig.context, new e0(this));
    this.installReferrerHuawei = new InstallReferrerHuawei(this.adjustConfig.context, new f0(this));
    preLaunchActionsI(this.adjustConfig.preLaunchActions.preLaunchActionsArray);
    sendReftagReferrerI();
  }
  
  private boolean isEnabledI() {
    ActivityState activityState = this.activityState;
    return (activityState != null) ? activityState.enabled : this.internalState.isEnabled();
  }
  
  private boolean isToUpdatePackagesI() {
    ActivityState activityState = this.activityState;
    return (activityState != null) ? activityState.updatePackages : this.internalState.itHasToUpdatePackages();
  }
  
  private boolean isValidReferrerDetails(ReferrerDetails paramReferrerDetails) {
    boolean bool = false;
    if (paramReferrerDetails == null)
      return false; 
    String str = paramReferrerDetails.installReferrer;
    if (str == null)
      return false; 
    if (str.length() != 0)
      bool = true; 
    return bool;
  }
  
  private void launchAttributionListenerI(Handler paramHandler) {
    if (this.adjustConfig.onAttributionChangedListener == null)
      return; 
    paramHandler.post(new n0(this));
  }
  
  private void launchAttributionResponseTasksI(AttributionResponseData paramAttributionResponseData) {
    updateAdidI(((ResponseData)paramAttributionResponseData).adid);
    Handler handler = new Handler(this.adjustConfig.context.getMainLooper());
    if (updateAttributionI(((ResponseData)paramAttributionResponseData).attribution))
      launchAttributionListenerI(handler); 
    prepareDeeplinkI(paramAttributionResponseData.deeplink, handler);
  }
  
  private void launchDeeplinkMain(Intent paramIntent, Uri paramUri) {
    boolean bool;
    if (this.adjustConfig.context.getPackageManager().queryIntentActivities(paramIntent, 0).size() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      this.logger.error("Unable to open deferred deep link (%s)", new Object[] { paramUri });
      return;
    } 
    this.logger.info("Open deferred deep link (%s)", new Object[] { paramUri });
    safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(this.adjustConfig.context, paramIntent);
  }
  
  private void launchEventResponseTasksI(EventResponseData paramEventResponseData) {
    j0 j0;
    k0 k0;
    updateAdidI(((ResponseData)paramEventResponseData).adid);
    Handler handler = new Handler(this.adjustConfig.context.getMainLooper());
    boolean bool = ((ResponseData)paramEventResponseData).success;
    if (bool && this.adjustConfig.onEventTrackingSucceededListener != null) {
      this.logger.debug("Launching success event tracking listener", new Object[0]);
      j0 = new j0(this, paramEventResponseData);
    } else if (!bool && this.adjustConfig.onEventTrackingFailedListener != null) {
      this.logger.debug("Launching failed event tracking listener", new Object[0]);
      k0 = new k0(this, (EventResponseData)j0);
    } else {
      return;
    } 
    handler.post(k0);
  }
  
  private void launchSdkClickResponseTasksI(SdkClickResponseData paramSdkClickResponseData) {
    updateAdidI(((ResponseData)paramSdkClickResponseData).adid);
    Handler handler = new Handler(this.adjustConfig.context.getMainLooper());
    if (updateAttributionI(((ResponseData)paramSdkClickResponseData).attribution))
      launchAttributionListenerI(handler); 
  }
  
  private void launchSessionResponseListenerI(SessionResponseData paramSessionResponseData, Handler paramHandler) {
    l0 l0;
    m0 m0;
    boolean bool = ((ResponseData)paramSessionResponseData).success;
    if (bool && this.adjustConfig.onSessionTrackingSucceededListener != null) {
      this.logger.debug("Launching success session tracking listener", new Object[0]);
      l0 = new l0(this, paramSessionResponseData);
    } else if (!bool && this.adjustConfig.onSessionTrackingFailedListener != null) {
      this.logger.debug("Launching failed session tracking listener", new Object[0]);
      m0 = new m0(this, (SessionResponseData)l0);
    } else {
      return;
    } 
    paramHandler.post(m0);
  }
  
  private void launchSessionResponseTasksI(SessionResponseData paramSessionResponseData) {
    this.logger.debug("Launching SessionResponse tasks", new Object[0]);
    updateAdidI(((ResponseData)paramSessionResponseData).adid);
    Handler handler = new Handler(this.adjustConfig.context.getMainLooper());
    if (updateAttributionI(((ResponseData)paramSessionResponseData).attribution))
      launchAttributionListenerI(handler); 
    if (this.attribution == null && !this.activityState.askingAttribution)
      this.attributionHandler.getAttribution(); 
    if (((ResponseData)paramSessionResponseData).success)
      SharedPreferencesManager.getDefaultInstance(getContext()).setInstallTracked(); 
    launchSessionResponseListenerI(paramSessionResponseData, handler);
    this.internalState.sessionResponseProcessed = true;
  }
  
  private void pauseSendingI() {
    this.attributionHandler.pauseSending();
    this.packageHandler.pauseSending();
    if (!toSendI(true)) {
      this.sdkClickHandler.pauseSending();
      return;
    } 
    this.sdkClickHandler.resumeSending();
  }
  
  private boolean pausedI() {
    return pausedI(false);
  }
  
  private boolean pausedI(boolean paramBoolean) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramBoolean) {
      if (!this.internalState.isOffline()) {
        paramBoolean = bool1;
        return !isEnabledI() ? true : paramBoolean;
      } 
    } else {
      if (!this.internalState.isOffline() && isEnabledI()) {
        paramBoolean = bool2;
        if (this.internalState.isInDelayedStart())
          paramBoolean = true; 
        return paramBoolean;
      } 
      paramBoolean = true;
    } 
    return true;
  }
  
  private void preLaunchActionsI(List<IRunActivityHandler> paramList) {
    if (paramList == null)
      return; 
    Iterator<IRunActivityHandler> iterator = paramList.iterator();
    while (iterator.hasNext())
      ((IRunActivityHandler)iterator.next()).run(this); 
  }
  
  private void prepareDeeplinkI(Uri paramUri, Handler paramHandler) {
    if (paramUri == null)
      return; 
    this.logger.info("Deferred deeplink received (%s)", new Object[] { paramUri });
    paramHandler.post(new o0(this, paramUri, createDeeplinkIntentI(paramUri)));
  }
  
  private void processCachedDeeplinkI() {
    if (!checkActivityStateI(this.activityState))
      return; 
    SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
    String str = sharedPreferencesManager.getDeeplinkUrl();
    long l = sharedPreferencesManager.getDeeplinkClickTime();
    if (str == null)
      return; 
    if (l == -1L)
      return; 
    readOpenUrl(Uri.parse(str), l);
    sharedPreferencesManager.removeDeeplink();
  }
  
  private void processCoppaComplianceI() {
    if (!this.adjustConfig.coppaCompliantEnabled) {
      resetThirdPartySharingCoppaActivityStateI();
      return;
    } 
    disableThirdPartySharingForCoppaEnabledI();
  }
  
  private void processSessionI() {
    if (this.activityState.isGdprForgotten)
      return; 
    long l1 = System.currentTimeMillis();
    ActivityState activityState = this.activityState;
    long l2 = l1 - activityState.lastActivity;
    if (l2 < 0L) {
      this.logger.error("Time travel!", new Object[0]);
      this.activityState.lastActivity = l1;
      writeActivityStateI();
      return;
    } 
    if (l2 > SESSION_INTERVAL) {
      trackNewSessionI(l1);
      checkAfterNewStartI();
      return;
    } 
    if (l2 > SUBSESSION_INTERVAL) {
      int i = activityState.subsessionCount + 1;
      activityState.subsessionCount = i;
      activityState.sessionLength += l2;
      activityState.lastActivity = l1;
      this.logger.verbose("Started subsession %d of session %d", new Object[] { Integer.valueOf(i), Integer.valueOf(this.activityState.sessionCount) });
      writeActivityStateI();
      checkForPreinstallI();
      this.installReferrer.startConnection();
      this.installReferrerHuawei.readReferrer();
      readInstallReferrerSamsung();
      readInstallReferrerXiaomi();
      return;
    } 
    this.logger.verbose("Time span since last activity too short for a new subsession", new Object[0]);
  }
  
  private void readActivityStateI(Context paramContext) {
    try {
      this.activityState = (ActivityState)Util.readObject(paramContext, "AdjustIoActivityState", "Activity state", ActivityState.class);
    } catch (Exception exception) {
      this.logger.error("Failed to read %s file (%s)", new Object[] { "Activity state", exception.getMessage() });
      this.activityState = null;
    } 
    if (this.activityState != null)
      this.internalState.firstSdkStart = true; 
  }
  
  private void readAttributionI(Context paramContext) {
    try {
      this.attribution = (AdjustAttribution)Util.readObject(paramContext, "AdjustAttribution", "Attribution", AdjustAttribution.class);
      return;
    } catch (Exception exception) {
      this.logger.error("Failed to read %s file (%s)", new Object[] { "Attribution", exception.getMessage() });
      this.attribution = null;
      return;
    } 
  }
  
  private void readConfigFile(Context paramContext) {
    try {
      InputStream inputStream = paramContext.getAssets().open("adjust_config.properties");
      Properties properties = new Properties();
      properties.load(inputStream);
      this.logger.verbose("adjust_config.properties file read and loaded", new Object[0]);
      String str = properties.getProperty("defaultTracker");
      if (str != null)
        this.adjustConfig.defaultTracker = str; 
      return;
    } catch (Exception exception) {
      this.logger.debug("%s file not found in this app", new Object[] { exception.getMessage() });
      return;
    } 
  }
  
  private void readInstallReferrerSamsung() {
    this.executor.submit(new h0(this));
  }
  
  private void readInstallReferrerXiaomi() {
    this.executor.submit(new i0(this));
  }
  
  private void readOpenUrlI(Uri paramUri, long paramLong) {
    if (!isEnabledI())
      return; 
    if (Util.isUrlFilteredOut(paramUri)) {
      ILogger iLogger = this.logger;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Deep link (");
      stringBuilder.append(paramUri.toString());
      stringBuilder.append(") processing skipped");
      iLogger.debug(stringBuilder.toString(), new Object[0]);
      return;
    } 
    ActivityPackage activityPackage = PackageFactory.buildDeeplinkSdkClickPackage(paramUri, paramLong, this.activityState, this.adjustConfig, this.deviceInfo, this.sessionParameters);
    if (activityPackage == null)
      return; 
    this.sdkClickHandler.sendSdkClick(activityPackage);
  }
  
  private void readSessionCallbackParametersI(Context paramContext) {
    try {
      this.sessionParameters.callbackParameters = (Map)Util.readObject(paramContext, "AdjustSessionCallbackParameters", "Session Callback parameters", Map.class);
      return;
    } catch (Exception exception) {
      this.logger.error("Failed to read %s file (%s)", new Object[] { "Session Callback parameters", exception.getMessage() });
      this.sessionParameters.callbackParameters = null;
      return;
    } 
  }
  
  private void readSessionPartnerParametersI(Context paramContext) {
    try {
      this.sessionParameters.partnerParameters = (Map)Util.readObject(paramContext, "AdjustSessionPartnerParameters", "Session Partner parameters", Map.class);
      return;
    } catch (Exception exception) {
      this.logger.error("Failed to read %s file (%s)", new Object[] { "Session Partner parameters", exception.getMessage() });
      this.sessionParameters.partnerParameters = null;
      return;
    } 
  }
  
  private void resetThirdPartySharingCoppaActivityStateI() {
    ActivityState activityState = this.activityState;
    if (activityState == null)
      return; 
    if (activityState.isThirdPartySharingDisabledForCoppa) {
      activityState.isThirdPartySharingDisabledForCoppa = false;
      writeActivityStateI();
    } 
  }
  
  private void resumeSendingI() {
    this.attributionHandler.resumeSending();
    this.packageHandler.resumeSending();
    this.sdkClickHandler.resumeSending();
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.adjust");
    paramContext.startActivity(paramIntent);
  }
  
  private void sendFirstPackagesI() {
    if (this.internalState.isNotInDelayedStart()) {
      this.logger.info("Start delay expired or never configured", new Object[0]);
      return;
    } 
    updatePackagesI();
    this.internalState.delayStart = false;
    this.delayStartTimer.cancel();
    this.delayStartTimer = null;
    updateHandlersStatusAndSendI();
  }
  
  private void sendInstallReferrerI(ReferrerDetails paramReferrerDetails, String paramString) {
    if (!isEnabledI())
      return; 
    if (!isValidReferrerDetails(paramReferrerDetails))
      return; 
    if (Util.isEqualReferrerDetails(paramReferrerDetails, paramString, this.activityState))
      return; 
    ActivityPackage activityPackage = PackageFactory.buildInstallReferrerSdkClickPackage(paramReferrerDetails, paramString, this.activityState, this.adjustConfig, this.deviceInfo, this.sessionParameters);
    this.sdkClickHandler.sendSdkClick(activityPackage);
  }
  
  private void sendPreinstallReferrerI() {
    if (!isEnabledI())
      return; 
    if (this.internalState.hasFirstSdkStartNotOcurred())
      return; 
    String str = SharedPreferencesManager.getDefaultInstance(getContext()).getPreinstallReferrer();
    if (str != null) {
      if (str.isEmpty())
        return; 
      this.sdkClickHandler.sendPreinstallPayload(str, "system_installer_referrer");
    } 
  }
  
  private void sendReftagReferrerI() {
    if (!isEnabledI())
      return; 
    if (this.internalState.hasFirstSdkStartNotOcurred())
      return; 
    this.sdkClickHandler.sendReftagReferrers();
  }
  
  private void setAskingAttributionI(boolean paramBoolean) {
    this.activityState.askingAttribution = paramBoolean;
    writeActivityStateI();
  }
  
  private void setEnabledI(boolean paramBoolean) {
    if (!hasChangedStateI(isEnabledI(), paramBoolean, "Adjust already enabled", "Adjust already disabled"))
      return; 
    if (paramBoolean) {
      ActivityState activityState = this.activityState;
      if (activityState != null && activityState.isGdprForgotten) {
        this.logger.error("Re-enabling SDK not possible for forgotten user", new Object[0]);
        return;
      } 
    } 
    InternalState internalState = this.internalState;
    internalState.enabled = paramBoolean;
    if (internalState.hasFirstSdkStartNotOcurred()) {
      updateStatusI(paramBoolean ^ true, "Handlers will start as paused due to the SDK being disabled", "Handlers will still start as paused", "Handlers will start as active due to the SDK being enabled");
      return;
    } 
    this.activityState.enabled = paramBoolean;
    writeActivityStateI();
    if (paramBoolean) {
      SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
      if (sharedPreferencesManager.getGdprForgetMe()) {
        gdprForgetMeI();
      } else {
        processCoppaComplianceI();
        if (sharedPreferencesManager.getDisableThirdPartySharing())
          disableThirdPartySharingI(); 
        Iterator<AdjustThirdPartySharing> iterator = this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray.iterator();
        while (iterator.hasNext())
          trackThirdPartySharingI(iterator.next()); 
        Boolean bool = this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked;
        if (bool != null)
          trackMeasurementConsentI(bool.booleanValue()); 
        this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray = new ArrayList();
        this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked = null;
      } 
      if (!sharedPreferencesManager.getInstallTracked()) {
        this.logger.debug("Detected that install was not tracked at enable time", new Object[0]);
        trackNewSessionI(System.currentTimeMillis());
      } 
      checkAfterNewStartI(sharedPreferencesManager);
    } 
    updateStatusI(paramBoolean ^ true, "Pausing handlers due to SDK being disabled", "Handlers remain paused", "Resuming handlers due to SDK being enabled");
  }
  
  private void setOfflineModeI(boolean paramBoolean) {
    String str1;
    String str2;
    String str3;
    if (!hasChangedStateI(this.internalState.isOffline(), paramBoolean, "Adjust already in offline mode", "Adjust already in online mode"))
      return; 
    InternalState internalState = this.internalState;
    internalState.offline = paramBoolean;
    if (internalState.hasFirstSdkStartNotOcurred()) {
      str1 = "Handlers will start paused due to SDK being offline";
      str2 = "Handlers will still start as paused";
      str3 = "Handlers will start as active due to SDK being online";
    } else {
      str1 = "Pausing handlers to put SDK offline mode";
      str2 = "Handlers remain paused";
      str3 = "Resuming handlers to put SDK in online mode";
    } 
    updateStatusI(paramBoolean, str1, str2, str3);
  }
  
  private void setPushTokenI(String paramString) {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    ActivityState activityState = this.activityState;
    if (activityState.isGdprForgotten)
      return; 
    if (paramString == null)
      return; 
    if (paramString.equals(activityState.pushToken))
      return; 
    this.activityState.pushToken = paramString;
    writeActivityStateI();
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildInfoPackage("push");
    this.packageHandler.addPackage(activityPackage);
    SharedPreferencesManager.getDefaultInstance(getContext()).removePushToken();
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  private boolean shouldDisableThirdPartySharingWhenCoppaEnabled() {
    if (this.activityState == null)
      return false; 
    if (!isEnabledI())
      return false; 
    ActivityState activityState = this.activityState;
    return activityState.isGdprForgotten ? false : (activityState.isThirdPartySharingDisabledForCoppa ^ true);
  }
  
  private void startBackgroundTimerI() {
    if (this.backgroundTimer == null)
      return; 
    if (!toSendI())
      return; 
    if (this.backgroundTimer.getFireIn() > 0L)
      return; 
    this.backgroundTimer.startIn(BACKGROUND_TIMER_INTERVAL);
  }
  
  private void startFirstSessionI() {
    this.activityState = new ActivityState();
    this.internalState.firstSdkStart = true;
    updateHandlersStatusAndSendI();
    long l = System.currentTimeMillis();
    SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(getContext());
    this.activityState.pushToken = sharedPreferencesManager.getPushToken();
    if (this.internalState.isEnabled())
      if (sharedPreferencesManager.getGdprForgetMe()) {
        gdprForgetMeI();
      } else {
        processCoppaComplianceI();
        if (sharedPreferencesManager.getDisableThirdPartySharing())
          disableThirdPartySharingI(); 
        Iterator<AdjustThirdPartySharing> iterator = this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray.iterator();
        while (iterator.hasNext())
          trackThirdPartySharingI(iterator.next()); 
        Boolean bool = this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked;
        if (bool != null)
          trackMeasurementConsentI(bool.booleanValue()); 
        this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray = new ArrayList();
        this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked = null;
        this.activityState.sessionCount = 1;
        transferSessionPackageI(l);
        checkAfterNewStartI(sharedPreferencesManager);
      }  
    this.activityState.resetSessionAttributes(l);
    this.activityState.enabled = this.internalState.isEnabled();
    this.activityState.updatePackages = this.internalState.itHasToUpdatePackages();
    writeActivityStateI();
    sharedPreferencesManager.removePushToken();
    sharedPreferencesManager.removeGdprForgetMe();
    sharedPreferencesManager.removeDisableThirdPartySharing();
    processCachedDeeplinkI();
  }
  
  private void startForegroundTimerI() {
    if (!isEnabledI())
      return; 
    this.foregroundTimer.start();
  }
  
  private void startI() {
    if (this.internalState.hasFirstSdkStartNotOcurred()) {
      AdjustSigner.onResume(this.adjustConfig.logger);
      startFirstSessionI();
      return;
    } 
    if (!this.activityState.enabled)
      return; 
    AdjustSigner.onResume(this.adjustConfig.logger);
    updateHandlersStatusAndSendI();
    processCoppaComplianceI();
    processSessionI();
    checkAttributionStateI();
    processCachedDeeplinkI();
  }
  
  private void stopBackgroundTimerI() {
    TimerOnce timerOnce = this.backgroundTimer;
    if (timerOnce == null)
      return; 
    timerOnce.cancel();
  }
  
  private void stopForegroundTimerI() {
    this.foregroundTimer.suspend();
  }
  
  private void teardownActivityStateS() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/ActivityState
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield activityState : Lcom/adjust/sdk/ActivityState;
    //   8: ifnonnull -> 16
    //   11: ldc_w com/adjust/sdk/ActivityState
    //   14: monitorexit
    //   15: return
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield activityState : Lcom/adjust/sdk/ActivityState;
    //   21: ldc_w com/adjust/sdk/ActivityState
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: ldc_w com/adjust/sdk/ActivityState
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   4	15	26	finally
    //   16	25	26	finally
    //   27	31	26	finally
  }
  
  private void teardownAllSessionParametersS() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/SessionParameters
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield sessionParameters : Lcom/adjust/sdk/SessionParameters;
    //   8: ifnonnull -> 16
    //   11: ldc_w com/adjust/sdk/SessionParameters
    //   14: monitorexit
    //   15: return
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield sessionParameters : Lcom/adjust/sdk/SessionParameters;
    //   21: ldc_w com/adjust/sdk/SessionParameters
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: ldc_w com/adjust/sdk/SessionParameters
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   4	15	26	finally
    //   16	25	26	finally
    //   27	31	26	finally
  }
  
  private void teardownAttributionS() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/AdjustAttribution
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield attribution : Lcom/adjust/sdk/AdjustAttribution;
    //   8: ifnonnull -> 16
    //   11: ldc_w com/adjust/sdk/AdjustAttribution
    //   14: monitorexit
    //   15: return
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield attribution : Lcom/adjust/sdk/AdjustAttribution;
    //   21: ldc_w com/adjust/sdk/AdjustAttribution
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: ldc_w com/adjust/sdk/AdjustAttribution
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   4	15	26	finally
    //   16	25	26	finally
    //   27	31	26	finally
  }
  
  private boolean toSendI() {
    return toSendI(false);
  }
  
  private boolean toSendI(boolean paramBoolean) {
    return pausedI(paramBoolean) ? false : (this.adjustConfig.sendInBackground ? true : this.internalState.isInForeground());
  }
  
  private void trackAdRevenueI(AdjustAdRevenue paramAdjustAdRevenue) {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    if (!checkAdjustAdRevenue(paramAdjustAdRevenue))
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildAdRevenuePackage(paramAdjustAdRevenue, this.internalState.isInDelayedStart());
    this.packageHandler.addPackage(activityPackage);
    this.packageHandler.sendFirstPackage();
  }
  
  private void trackAdRevenueI(String paramString, JSONObject paramJSONObject) {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildAdRevenuePackage(paramString, paramJSONObject);
    this.packageHandler.addPackage(activityPackage);
    this.packageHandler.sendFirstPackage();
  }
  
  private void trackEventI(AdjustEvent paramAdjustEvent) {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    if (!checkEventI(paramAdjustEvent))
      return; 
    if (!checkOrderIdI(paramAdjustEvent.orderId))
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    long l = System.currentTimeMillis();
    ActivityState activityState = this.activityState;
    activityState.eventCount++;
    updateActivityStateI(l);
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildEventPackage(paramAdjustEvent, this.internalState.isInDelayedStart());
    this.packageHandler.addPackage(activityPackage);
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
    } else {
      this.packageHandler.sendFirstPackage();
    } 
    if (this.adjustConfig.sendInBackground && this.internalState.isInBackground())
      startBackgroundTimerI(); 
    writeActivityStateI();
  }
  
  private void trackMeasurementConsentI(boolean paramBoolean) {
    if (!checkActivityStateI(this.activityState)) {
      this.adjustConfig.preLaunchActions.lastMeasurementConsentTracked = Boolean.valueOf(paramBoolean);
      return;
    } 
    if (!isEnabledI())
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildMeasurementConsentPackage(paramBoolean);
    this.packageHandler.addPackage(activityPackage);
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  private void trackNewSessionI(long paramLong) {
    ActivityState activityState = this.activityState;
    long l = activityState.lastActivity;
    activityState.sessionCount++;
    activityState.lastInterval = paramLong - l;
    transferSessionPackageI(paramLong);
    this.activityState.resetSessionAttributes(paramLong);
    writeActivityStateI();
  }
  
  private void trackSubscriptionI(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription) {
    if (!checkActivityStateI(this.activityState))
      return; 
    if (!isEnabledI())
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildSubscriptionPackage(paramAdjustPlayStoreSubscription, this.internalState.isInDelayedStart());
    this.packageHandler.addPackage(activityPackage);
    this.packageHandler.sendFirstPackage();
  }
  
  private void trackThirdPartySharingI(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    if (!checkActivityStateI(this.activityState)) {
      this.adjustConfig.preLaunchActions.preLaunchAdjustThirdPartySharingArray.add(paramAdjustThirdPartySharing);
      return;
    } 
    if (!isEnabledI())
      return; 
    if (this.activityState.isGdprForgotten)
      return; 
    if (this.adjustConfig.coppaCompliantEnabled) {
      this.logger.warn("Calling third party sharing API not allowed when COPPA enabled", new Object[0]);
      return;
    } 
    long l = System.currentTimeMillis();
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, l)).buildThirdPartySharingPackage(paramAdjustThirdPartySharing);
    this.packageHandler.addPackage(activityPackage);
    if (this.adjustConfig.eventBufferingEnabled) {
      this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      return;
    } 
    this.packageHandler.sendFirstPackage();
  }
  
  private void transferSessionPackageI(long paramLong) {
    ActivityPackage activityPackage = (new PackageBuilder(this.adjustConfig, this.deviceInfo, this.activityState, this.sessionParameters, paramLong)).buildSessionPackage(this.internalState.isInDelayedStart());
    this.packageHandler.addPackage(activityPackage);
    this.packageHandler.sendFirstPackage();
  }
  
  private boolean updateActivityStateI(long paramLong) {
    if (!checkActivityStateI(this.activityState))
      return false; 
    ActivityState activityState = this.activityState;
    long l = paramLong - activityState.lastActivity;
    if (l > SESSION_INTERVAL)
      return false; 
    activityState.lastActivity = paramLong;
    if (l < 0L) {
      this.logger.error("Time travel!", new Object[0]);
    } else {
      activityState.sessionLength += l;
      activityState.timeSpent += l;
    } 
    return true;
  }
  
  private void updateAdidI(String paramString) {
    if (paramString == null)
      return; 
    if (paramString.equals(this.activityState.adid))
      return; 
    this.activityState.adid = paramString;
    writeActivityStateI();
  }
  
  private void updateHandlersStatusAndSendI() {
    if (!toSendI()) {
      pauseSendingI();
      return;
    } 
    resumeSendingI();
    if (!this.adjustConfig.eventBufferingEnabled || (this.internalState.isFirstLaunch() && this.internalState.hasSessionResponseNotBeenProcessed()))
      this.packageHandler.sendFirstPackage(); 
  }
  
  private void updatePackagesI() {
    this.packageHandler.updatePackages(this.sessionParameters);
    this.internalState.updatePackages = false;
    ActivityState activityState = this.activityState;
    if (activityState != null) {
      activityState.updatePackages = false;
      writeActivityStateI();
    } 
  }
  
  private void updateStatusI(boolean paramBoolean, String paramString1, String paramString2, String paramString3) {
    if (paramBoolean) {
      this.logger.info(paramString1, new Object[0]);
    } else {
      StringBuilder stringBuilder;
      if (pausedI(false)) {
        if (pausedI(true)) {
          this.logger.info(paramString2, new Object[0]);
        } else {
          ILogger iLogger = this.logger;
          stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(", except the Sdk Click Handler");
          iLogger.info(stringBuilder.toString(), new Object[0]);
        } 
      } else {
        this.logger.info((String)stringBuilder, new Object[0]);
      } 
    } 
    updateHandlersStatusAndSendI();
  }
  
  private void writeActivityStateI() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/ActivityState
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield activityState : Lcom/adjust/sdk/ActivityState;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnonnull -> 18
    //   13: ldc_w com/adjust/sdk/ActivityState
    //   16: monitorexit
    //   17: return
    //   18: aload_1
    //   19: aload_0
    //   20: getfield adjustConfig : Lcom/adjust/sdk/AdjustConfig;
    //   23: getfield context : Landroid/content/Context;
    //   26: ldc_w 'AdjustIoActivityState'
    //   29: ldc 'Activity state'
    //   31: invokestatic writeObject : (Ljava/lang/Object;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   34: ldc_w com/adjust/sdk/ActivityState
    //   37: monitorexit
    //   38: return
    //   39: astore_1
    //   40: ldc_w com/adjust/sdk/ActivityState
    //   43: monitorexit
    //   44: aload_1
    //   45: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	39	finally
    //   13	17	39	finally
    //   18	38	39	finally
    //   40	44	39	finally
  }
  
  private void writeAttributionI() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/AdjustAttribution
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield attribution : Lcom/adjust/sdk/AdjustAttribution;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnonnull -> 18
    //   13: ldc_w com/adjust/sdk/AdjustAttribution
    //   16: monitorexit
    //   17: return
    //   18: aload_1
    //   19: aload_0
    //   20: getfield adjustConfig : Lcom/adjust/sdk/AdjustConfig;
    //   23: getfield context : Landroid/content/Context;
    //   26: ldc_w 'AdjustAttribution'
    //   29: ldc 'Attribution'
    //   31: invokestatic writeObject : (Ljava/lang/Object;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   34: ldc_w com/adjust/sdk/AdjustAttribution
    //   37: monitorexit
    //   38: return
    //   39: astore_1
    //   40: ldc_w com/adjust/sdk/AdjustAttribution
    //   43: monitorexit
    //   44: aload_1
    //   45: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	39	finally
    //   13	17	39	finally
    //   18	38	39	finally
    //   40	44	39	finally
  }
  
  private void writeSessionCallbackParametersI() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/SessionParameters
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield sessionParameters : Lcom/adjust/sdk/SessionParameters;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnonnull -> 18
    //   13: ldc_w com/adjust/sdk/SessionParameters
    //   16: monitorexit
    //   17: return
    //   18: aload_1
    //   19: getfield callbackParameters : Ljava/util/Map;
    //   22: aload_0
    //   23: getfield adjustConfig : Lcom/adjust/sdk/AdjustConfig;
    //   26: getfield context : Landroid/content/Context;
    //   29: ldc_w 'AdjustSessionCallbackParameters'
    //   32: ldc 'Session Callback parameters'
    //   34: invokestatic writeObject : (Ljava/lang/Object;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   37: ldc_w com/adjust/sdk/SessionParameters
    //   40: monitorexit
    //   41: return
    //   42: astore_1
    //   43: ldc_w com/adjust/sdk/SessionParameters
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	42	finally
    //   13	17	42	finally
    //   18	41	42	finally
    //   43	47	42	finally
  }
  
  private void writeSessionPartnerParametersI() {
    // Byte code:
    //   0: ldc_w com/adjust/sdk/SessionParameters
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield sessionParameters : Lcom/adjust/sdk/SessionParameters;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnonnull -> 18
    //   13: ldc_w com/adjust/sdk/SessionParameters
    //   16: monitorexit
    //   17: return
    //   18: aload_1
    //   19: getfield partnerParameters : Ljava/util/Map;
    //   22: aload_0
    //   23: getfield adjustConfig : Lcom/adjust/sdk/AdjustConfig;
    //   26: getfield context : Landroid/content/Context;
    //   29: ldc_w 'AdjustSessionPartnerParameters'
    //   32: ldc 'Session Partner parameters'
    //   34: invokestatic writeObject : (Ljava/lang/Object;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   37: ldc_w com/adjust/sdk/SessionParameters
    //   40: monitorexit
    //   41: return
    //   42: astore_1
    //   43: ldc_w com/adjust/sdk/SessionParameters
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	42	finally
    //   13	17	42	finally
    //   18	41	42	finally
    //   43	47	42	finally
  }
  
  public void addSessionCallbackParameter(String paramString1, String paramString2) {
    this.executor.submit(new h(this, paramString1, paramString2));
  }
  
  public void addSessionCallbackParameterI(String paramString1, String paramString2) {
    if (!Util.isValidParameter(paramString1, "key", "Session Callback"))
      return; 
    if (!Util.isValidParameter(paramString2, "value", "Session Callback"))
      return; 
    SessionParameters sessionParameters = this.sessionParameters;
    if (sessionParameters.callbackParameters == null)
      sessionParameters.callbackParameters = new LinkedHashMap<Object, Object>(); 
    String str = (String)this.sessionParameters.callbackParameters.get(paramString1);
    if (paramString2.equals(str)) {
      this.logger.verbose("Key %s already present with the same value", new Object[] { paramString1 });
      return;
    } 
    if (str != null)
      this.logger.warn("Key %s will be overwritten", new Object[] { paramString1 }); 
    this.sessionParameters.callbackParameters.put(paramString1, paramString2);
    writeSessionCallbackParametersI();
  }
  
  public void addSessionPartnerParameter(String paramString1, String paramString2) {
    this.executor.submit(new i(this, paramString1, paramString2));
  }
  
  public void addSessionPartnerParameterI(String paramString1, String paramString2) {
    if (!Util.isValidParameter(paramString1, "key", "Session Partner"))
      return; 
    if (!Util.isValidParameter(paramString2, "value", "Session Partner"))
      return; 
    SessionParameters sessionParameters = this.sessionParameters;
    if (sessionParameters.partnerParameters == null)
      sessionParameters.partnerParameters = new LinkedHashMap<Object, Object>(); 
    String str = (String)this.sessionParameters.partnerParameters.get(paramString1);
    if (paramString2.equals(str)) {
      this.logger.verbose("Key %s already present with the same value", new Object[] { paramString1 });
      return;
    } 
    if (str != null)
      this.logger.warn("Key %s will be overwritten", new Object[] { paramString1 }); 
    this.sessionParameters.partnerParameters.put(paramString1, paramString2);
    writeSessionPartnerParametersI();
  }
  
  public void backgroundTimerFired() {
    this.executor.submit(new z(this));
  }
  
  public void disableThirdPartySharing() {
    this.executor.submit(new q(this));
  }
  
  public void finishedTrackingActivity(ResponseData paramResponseData) {
    SdkClickResponseData sdkClickResponseData;
    if (paramResponseData instanceof SessionResponseData) {
      this.logger.debug("Finished tracking session", new Object[0]);
      this.attributionHandler.checkSessionResponse((SessionResponseData)paramResponseData);
      return;
    } 
    if (paramResponseData instanceof SdkClickResponseData) {
      sdkClickResponseData = (SdkClickResponseData)paramResponseData;
      checkForInstallReferrerInfo(sdkClickResponseData);
      this.attributionHandler.checkSdkClickResponse(sdkClickResponseData);
      return;
    } 
    if (sdkClickResponseData instanceof EventResponseData)
      launchEventResponseTasks((EventResponseData)sdkClickResponseData); 
  }
  
  public void foregroundTimerFired() {
    this.executor.submit(new y(this));
  }
  
  public void gdprForgetMe() {
    this.executor.submit(new p(this));
  }
  
  public ActivityState getActivityState() {
    return this.activityState;
  }
  
  public String getAdid() {
    ActivityState activityState = this.activityState;
    return (activityState == null) ? null : activityState.adid;
  }
  
  public AdjustConfig getAdjustConfig() {
    return this.adjustConfig;
  }
  
  public AdjustAttribution getAttribution() {
    return this.attribution;
  }
  
  public Context getContext() {
    return this.adjustConfig.context;
  }
  
  public a getDeviceInfo() {
    return this.deviceInfo;
  }
  
  public InternalState getInternalState() {
    return this.internalState;
  }
  
  public SessionParameters getSessionParameters() {
    return this.sessionParameters;
  }
  
  public void gotOptOutResponse() {
    this.executor.submit(new x(this));
  }
  
  public void init(AdjustConfig paramAdjustConfig) {
    this.adjustConfig = paramAdjustConfig;
  }
  
  public boolean isEnabled() {
    return isEnabledI();
  }
  
  public void launchAttributionResponseTasks(AttributionResponseData paramAttributionResponseData) {
    this.executor.submit(new f(this, paramAttributionResponseData));
  }
  
  public void launchEventResponseTasks(EventResponseData paramEventResponseData) {
    this.executor.submit(new c(this, paramEventResponseData));
  }
  
  public void launchSdkClickResponseTasks(SdkClickResponseData paramSdkClickResponseData) {
    this.executor.submit(new d(this, paramSdkClickResponseData));
  }
  
  public void launchSessionResponseTasks(SessionResponseData paramSessionResponseData) {
    this.executor.submit(new e(this, paramSessionResponseData));
  }
  
  public void onPause() {
    this.internalState.background = true;
    this.executor.submit(new g0(this));
  }
  
  public void onResume() {
    this.internalState.background = false;
    this.executor.submit(new v(this));
  }
  
  public void readOpenUrl(Uri paramUri, long paramLong) {
    this.executor.submit(new s0(this, paramUri, paramLong));
  }
  
  public void removeSessionCallbackParameter(String paramString) {
    this.executor.submit(new j(this, paramString));
  }
  
  public void removeSessionCallbackParameterI(String paramString) {
    if (!Util.isValidParameter(paramString, "key", "Session Callback"))
      return; 
    Map map = this.sessionParameters.callbackParameters;
    if (map == null) {
      this.logger.warn("Session Callback parameters are not set", new Object[0]);
      return;
    } 
    if ((String)map.remove(paramString) == null) {
      this.logger.warn("Key %s does not exist", new Object[] { paramString });
      return;
    } 
    this.logger.debug("Key %s will be removed", new Object[] { paramString });
    writeSessionCallbackParametersI();
  }
  
  public void removeSessionPartnerParameter(String paramString) {
    this.executor.submit(new l(this, paramString));
  }
  
  public void removeSessionPartnerParameterI(String paramString) {
    if (!Util.isValidParameter(paramString, "key", "Session Partner"))
      return; 
    Map map = this.sessionParameters.partnerParameters;
    if (map == null) {
      this.logger.warn("Session Partner parameters are not set", new Object[0]);
      return;
    } 
    if ((String)map.remove(paramString) == null) {
      this.logger.warn("Key %s does not exist", new Object[] { paramString });
      return;
    } 
    this.logger.debug("Key %s will be removed", new Object[] { paramString });
    writeSessionPartnerParametersI();
  }
  
  public void resetSessionCallbackParameters() {
    this.executor.submit(new m(this));
  }
  
  public void resetSessionCallbackParametersI() {
    if (this.sessionParameters.callbackParameters == null)
      this.logger.warn("Session Callback parameters are not set", new Object[0]); 
    this.sessionParameters.callbackParameters = null;
    writeSessionCallbackParametersI();
  }
  
  public void resetSessionPartnerParameters() {
    this.executor.submit(new n(this));
  }
  
  public void resetSessionPartnerParametersI() {
    if (this.sessionParameters.partnerParameters == null)
      this.logger.warn("Session Partner parameters are not set", new Object[0]); 
    this.sessionParameters.partnerParameters = null;
    writeSessionPartnerParametersI();
  }
  
  public void sendFirstPackages() {
    this.executor.submit(new g(this));
  }
  
  public void sendInstallReferrer(ReferrerDetails paramReferrerDetails, String paramString) {
    this.executor.submit(new b(this, paramReferrerDetails, paramString));
  }
  
  public void sendPreinstallReferrer() {
    this.executor.submit(new a(this));
  }
  
  public void sendReftagReferrer() {
    this.executor.submit(new u0(this));
  }
  
  public void setAskingAttribution(boolean paramBoolean) {
    this.executor.submit(new t0(this, paramBoolean));
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.executor.submit(new q0(this, paramBoolean));
  }
  
  public void setOfflineMode(boolean paramBoolean) {
    this.executor.submit(new r0(this, paramBoolean));
  }
  
  public void setPushToken(String paramString, boolean paramBoolean) {
    this.executor.submit(new o(this, paramBoolean, paramString));
  }
  
  public void teardown() {
    TimerOnce timerOnce2 = this.backgroundTimer;
    if (timerOnce2 != null)
      timerOnce2.teardown(); 
    TimerCycle timerCycle = this.foregroundTimer;
    if (timerCycle != null)
      timerCycle.teardown(); 
    TimerOnce timerOnce1 = this.delayStartTimer;
    if (timerOnce1 != null)
      timerOnce1.teardown(); 
    ThreadExecutor threadExecutor = this.executor;
    if (threadExecutor != null)
      threadExecutor.teardown(); 
    IPackageHandler iPackageHandler = this.packageHandler;
    if (iPackageHandler != null)
      iPackageHandler.teardown(); 
    IAttributionHandler iAttributionHandler = this.attributionHandler;
    if (iAttributionHandler != null)
      iAttributionHandler.teardown(); 
    ISdkClickHandler iSdkClickHandler = this.sdkClickHandler;
    if (iSdkClickHandler != null)
      iSdkClickHandler.teardown(); 
    SessionParameters sessionParameters = this.sessionParameters;
    if (sessionParameters != null) {
      Map map = sessionParameters.callbackParameters;
      if (map != null)
        map.clear(); 
      map = this.sessionParameters.partnerParameters;
      if (map != null)
        map.clear(); 
    } 
    teardownActivityStateS();
    teardownAttributionS();
    teardownAllSessionParametersS();
    this.packageHandler = null;
    this.logger = null;
    this.foregroundTimer = null;
    this.executor = null;
    this.backgroundTimer = null;
    this.delayStartTimer = null;
    this.internalState = null;
    this.deviceInfo = null;
    this.adjustConfig = null;
    this.attributionHandler = null;
    this.sdkClickHandler = null;
    this.sessionParameters = null;
  }
  
  public void trackAdRevenue(AdjustAdRevenue paramAdjustAdRevenue) {
    this.executor.submit(new u(this, paramAdjustAdRevenue));
  }
  
  public void trackAdRevenue(String paramString, JSONObject paramJSONObject) {
    this.executor.submit(new t(this, paramString, paramJSONObject));
  }
  
  public void trackEvent(AdjustEvent paramAdjustEvent) {
    this.executor.submit(new p0(this, paramAdjustEvent));
  }
  
  public void trackMeasurementConsent(boolean paramBoolean) {
    this.executor.submit(new s(this, paramBoolean));
  }
  
  public void trackPlayStoreSubscription(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription) {
    this.executor.submit(new w(this, paramAdjustPlayStoreSubscription));
  }
  
  public void trackThirdPartySharing(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    this.executor.submit(new r(this, paramAdjustThirdPartySharing));
  }
  
  public boolean updateAttributionI(AdjustAttribution paramAdjustAttribution) {
    if (paramAdjustAttribution == null)
      return false; 
    if (paramAdjustAttribution.equals(this.attribution))
      return false; 
    this.attribution = paramAdjustAttribution;
    writeAttributionI();
    return true;
  }
  
  public class InternalState {
    public boolean background;
    
    public boolean delayStart;
    
    public boolean enabled;
    
    public boolean firstLaunch;
    
    public boolean firstSdkStart;
    
    public boolean offline;
    
    public boolean preinstallHasBeenRead;
    
    public boolean sessionResponseProcessed;
    
    public boolean updatePackages;
    
    public boolean hasFirstSdkStartNotOcurred() {
      return this.firstSdkStart ^ true;
    }
    
    public boolean hasFirstSdkStartOcurred() {
      return this.firstSdkStart;
    }
    
    public boolean hasPreinstallBeenRead() {
      return this.preinstallHasBeenRead;
    }
    
    public boolean hasSessionResponseNotBeenProcessed() {
      return this.sessionResponseProcessed ^ true;
    }
    
    public boolean isDisabled() {
      return this.enabled ^ true;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public boolean isFirstLaunch() {
      return this.firstLaunch;
    }
    
    public boolean isInBackground() {
      return this.background;
    }
    
    public boolean isInDelayedStart() {
      return this.delayStart;
    }
    
    public boolean isInForeground() {
      return this.background ^ true;
    }
    
    public boolean isNotFirstLaunch() {
      return this.firstLaunch ^ true;
    }
    
    public boolean isNotInDelayedStart() {
      return this.delayStart ^ true;
    }
    
    public boolean isOffline() {
      return this.offline;
    }
    
    public boolean isOnline() {
      return this.offline ^ true;
    }
    
    public boolean itHasToUpdatePackages() {
      return this.updatePackages;
    }
  }
  
  public final class a implements Runnable {
    public a(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.sendPreinstallReferrerI();
    }
  }
  
  public final class a0 implements IRunActivityHandler {
    public a0(ActivityHandler this$0) {}
    
    public final void run(ActivityHandler param1ActivityHandler) {
      param1ActivityHandler.setEnabledI(this.a.adjustConfig.startEnabled.booleanValue());
    }
  }
  
  public final class b implements Runnable {
    public b(ActivityHandler this$0, ReferrerDetails param1ReferrerDetails, String param1String) {}
    
    public final void run() {
      this.c.sendInstallReferrerI(this.a, this.b);
    }
  }
  
  public final class b0 implements Runnable {
    public b0(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.foregroundTimerFired();
    }
  }
  
  public final class c implements Runnable {
    public c(ActivityHandler this$0, EventResponseData param1EventResponseData) {}
    
    public final void run() {
      this.b.launchEventResponseTasksI(this.a);
    }
  }
  
  public final class c0 implements Runnable {
    public c0(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.backgroundTimerFired();
    }
  }
  
  public final class d implements Runnable {
    public d(ActivityHandler this$0, SdkClickResponseData param1SdkClickResponseData) {}
    
    public final void run() {
      this.b.launchSdkClickResponseTasksI(this.a);
    }
  }
  
  public final class d0 implements Runnable {
    public d0(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.sendFirstPackages();
    }
  }
  
  public final class e implements Runnable {
    public e(ActivityHandler this$0, SessionResponseData param1SessionResponseData) {}
    
    public final void run() {
      this.b.launchSessionResponseTasksI(this.a);
    }
  }
  
  public final class e0 implements InstallReferrerReadListener {
    public e0(ActivityHandler this$0) {}
    
    public final void onInstallReferrerRead(ReferrerDetails param1ReferrerDetails, String param1String) {
      this.a.sendInstallReferrer(param1ReferrerDetails, param1String);
    }
  }
  
  public final class f implements Runnable {
    public f(ActivityHandler this$0, AttributionResponseData param1AttributionResponseData) {}
    
    public final void run() {
      this.b.launchAttributionResponseTasksI(this.a);
    }
  }
  
  public final class f0 implements InstallReferrerReadListener {
    public f0(ActivityHandler this$0) {}
    
    public final void onInstallReferrerRead(ReferrerDetails param1ReferrerDetails, String param1String) {
      this.a.sendInstallReferrer(param1ReferrerDetails, param1String);
    }
  }
  
  public final class g implements Runnable {
    public g(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.sendFirstPackagesI();
    }
  }
  
  public final class g0 implements Runnable {
    public g0(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.stopForegroundTimerI();
      this.a.startBackgroundTimerI();
      this.a.logger.verbose("Subsession end", new Object[0]);
      this.a.endI();
    }
  }
  
  public final class h implements Runnable {
    public h(ActivityHandler this$0, String param1String1, String param1String2) {}
    
    public final void run() {
      this.c.addSessionCallbackParameterI(this.a, this.b);
    }
  }
  
  public final class h0 implements Runnable {
    public h0(ActivityHandler this$0) {}
    
    public final void run() {
      ReferrerDetails referrerDetails = Reflection.getSamsungReferrer(this.a.getContext(), this.a.logger);
      if (referrerDetails != null)
        this.a.sendInstallReferrer(referrerDetails, "samsung"); 
    }
  }
  
  public final class i implements Runnable {
    public i(ActivityHandler this$0, String param1String1, String param1String2) {}
    
    public final void run() {
      this.c.addSessionPartnerParameterI(this.a, this.b);
    }
  }
  
  public final class i0 implements Runnable {
    public i0(ActivityHandler this$0) {}
    
    public final void run() {
      ReferrerDetails referrerDetails = Reflection.getXiaomiReferrer(this.a.getContext(), this.a.logger);
      if (referrerDetails != null)
        this.a.sendInstallReferrer(referrerDetails, "xiaomi"); 
    }
  }
  
  public final class j implements Runnable {
    public j(ActivityHandler this$0, String param1String) {}
    
    public final void run() {
      this.b.removeSessionCallbackParameterI(this.a);
    }
  }
  
  public final class j0 implements Runnable {
    public j0(ActivityHandler this$0, EventResponseData param1EventResponseData) {}
    
    public final void run() {
      if (this.b.adjustConfig == null)
        return; 
      if (this.b.adjustConfig.onEventTrackingSucceededListener == null)
        return; 
      this.b.adjustConfig.onEventTrackingSucceededListener.onFinishedEventTrackingSucceeded(this.a.getSuccessResponseData());
    }
  }
  
  public final class k implements Runnable {
    public k(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.initI();
    }
  }
  
  public final class k0 implements Runnable {
    public k0(ActivityHandler this$0, EventResponseData param1EventResponseData) {}
    
    public final void run() {
      if (this.b.adjustConfig == null)
        return; 
      if (this.b.adjustConfig.onEventTrackingFailedListener == null)
        return; 
      this.b.adjustConfig.onEventTrackingFailedListener.onFinishedEventTrackingFailed(this.a.getFailureResponseData());
    }
  }
  
  public final class l implements Runnable {
    public l(ActivityHandler this$0, String param1String) {}
    
    public final void run() {
      this.b.removeSessionPartnerParameterI(this.a);
    }
  }
  
  public final class l0 implements Runnable {
    public l0(ActivityHandler this$0, SessionResponseData param1SessionResponseData) {}
    
    public final void run() {
      if (this.b.adjustConfig == null)
        return; 
      if (this.b.adjustConfig.onSessionTrackingSucceededListener == null)
        return; 
      this.b.adjustConfig.onSessionTrackingSucceededListener.onFinishedSessionTrackingSucceeded(this.a.getSuccessResponseData());
    }
  }
  
  public final class m implements Runnable {
    public m(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.resetSessionCallbackParametersI();
    }
  }
  
  public final class m0 implements Runnable {
    public m0(ActivityHandler this$0, SessionResponseData param1SessionResponseData) {}
    
    public final void run() {
      if (this.b.adjustConfig == null)
        return; 
      if (this.b.adjustConfig.onSessionTrackingFailedListener == null)
        return; 
      this.b.adjustConfig.onSessionTrackingFailedListener.onFinishedSessionTrackingFailed(this.a.getFailureResponseData());
    }
  }
  
  public final class n implements Runnable {
    public n(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.resetSessionPartnerParametersI();
    }
  }
  
  public final class n0 implements Runnable {
    public n0(ActivityHandler this$0) {}
    
    public final void run() {
      if (this.a.adjustConfig == null)
        return; 
      if (this.a.adjustConfig.onAttributionChangedListener == null)
        return; 
      this.a.adjustConfig.onAttributionChangedListener.onAttributionChanged(this.a.attribution);
    }
  }
  
  public final class o implements Runnable {
    public o(ActivityHandler this$0, boolean param1Boolean, String param1String) {}
    
    public final void run() {
      if (!this.a)
        SharedPreferencesManager.getDefaultInstance(this.c.getContext()).savePushToken(this.b); 
      if (this.c.internalState.hasFirstSdkStartNotOcurred())
        return; 
      this.c.setPushTokenI(this.b);
    }
  }
  
  public final class o0 implements Runnable {
    public o0(ActivityHandler this$0, Uri param1Uri, Intent param1Intent) {}
    
    public final void run() {
      if (this.c.adjustConfig == null)
        return; 
      boolean bool = true;
      if (this.c.adjustConfig.onDeeplinkResponseListener != null)
        bool = this.c.adjustConfig.onDeeplinkResponseListener.launchReceivedDeeplink(this.a); 
      if (bool)
        this.c.launchDeeplinkMain(this.b, this.a); 
    }
  }
  
  public final class p implements Runnable {
    public p(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.gdprForgetMeI();
    }
  }
  
  public final class p0 implements Runnable {
    public p0(ActivityHandler this$0, AdjustEvent param1AdjustEvent) {}
    
    public final void run() {
      if (this.b.internalState.hasFirstSdkStartNotOcurred()) {
        this.b.logger.warn("Event tracked before first activity resumed.\nIf it was triggered in the Application class, it might timestamp or even send an install long before the user opens the app.\nPlease check https://github.com/adjust/android_sdk#can-i-trigger-an-event-at-application-launch for more information.", new Object[0]);
        this.b.startI();
      } 
      this.b.trackEventI(this.a);
    }
  }
  
  public final class q implements Runnable {
    public q(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.disableThirdPartySharingI();
    }
  }
  
  public final class q0 implements Runnable {
    public q0(ActivityHandler this$0, boolean param1Boolean) {}
    
    public final void run() {
      this.b.setEnabledI(this.a);
    }
  }
  
  public final class r implements Runnable {
    public r(ActivityHandler this$0, AdjustThirdPartySharing param1AdjustThirdPartySharing) {}
    
    public final void run() {
      this.b.trackThirdPartySharingI(this.a);
    }
  }
  
  public final class r0 implements Runnable {
    public r0(ActivityHandler this$0, boolean param1Boolean) {}
    
    public final void run() {
      this.b.setOfflineModeI(this.a);
    }
  }
  
  public final class s implements Runnable {
    public s(ActivityHandler this$0, boolean param1Boolean) {}
    
    public final void run() {
      this.b.trackMeasurementConsentI(this.a);
    }
  }
  
  public final class s0 implements Runnable {
    public s0(ActivityHandler this$0, Uri param1Uri, long param1Long) {}
    
    public final void run() {
      this.c.readOpenUrlI(this.a, this.b);
    }
  }
  
  public final class t implements Runnable {
    public t(ActivityHandler this$0, String param1String, JSONObject param1JSONObject) {}
    
    public final void run() {
      this.c.trackAdRevenueI(this.a, this.b);
    }
  }
  
  public final class t0 implements Runnable {
    public t0(ActivityHandler this$0, boolean param1Boolean) {}
    
    public final void run() {
      this.b.setAskingAttributionI(this.a);
    }
  }
  
  public final class u implements Runnable {
    public u(ActivityHandler this$0, AdjustAdRevenue param1AdjustAdRevenue) {}
    
    public final void run() {
      this.b.trackAdRevenueI(this.a);
    }
  }
  
  public final class u0 implements Runnable {
    public u0(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.sendReftagReferrerI();
    }
  }
  
  public final class v implements Runnable {
    public v(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.delayStartI();
      this.a.stopBackgroundTimerI();
      this.a.startForegroundTimerI();
      this.a.logger.verbose("Subsession start", new Object[0]);
      this.a.startI();
    }
  }
  
  public final class w implements Runnable {
    public w(ActivityHandler this$0, AdjustPlayStoreSubscription param1AdjustPlayStoreSubscription) {}
    
    public final void run() {
      this.b.trackSubscriptionI(this.a);
    }
  }
  
  public final class x implements Runnable {
    public x(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.gotOptOutResponseI();
    }
  }
  
  public final class y implements Runnable {
    public y(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.foregroundTimerFiredI();
    }
  }
  
  public final class z implements Runnable {
    public z(ActivityHandler this$0) {}
    
    public final void run() {
      this.a.backgroundTimerFiredI();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\adjust\sdk\ActivityHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */