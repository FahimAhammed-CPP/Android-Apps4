package com.bumptech.glide.manager;

class ApplicationLifecycle implements Lifecycle {
  public void addListener(LifecycleListener paramLifecycleListener) {
    paramLifecycleListener.onStart();
  }
  
  public void removeListener(LifecycleListener paramLifecycleListener) {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\bumptech\glide\manager\ApplicationLifecycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */