package com.a.a.a.a.h;

import com.a.a.a.a.h.a.b;
import com.a.a.a.a.h.a.c;
import com.a.a.a.a.h.a.d;
import com.a.a.a.a.h.a.e;
import com.a.a.a.a.h.a.f;
import java.util.HashSet;
import org.json.JSONObject;

public class c implements b.b {
  private JSONObject a;
  
  private final c b;
  
  public c(c paramc) {
    this.b = paramc;
  }
  
  public JSONObject a() {
    return this.a;
  }
  
  public void a(JSONObject paramJSONObject) {
    this.a = paramJSONObject;
  }
  
  public void a(JSONObject paramJSONObject, HashSet<String> paramHashSet, long paramLong) {
    this.b.b((b)new f(this, paramHashSet, paramJSONObject, paramLong));
  }
  
  public void b() {
    this.b.b((b)new d(this));
  }
  
  public void b(JSONObject paramJSONObject, HashSet<String> paramHashSet, long paramLong) {
    this.b.b((b)new e(this, paramHashSet, paramJSONObject, paramLong));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\a\a\a\a\h\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */