package com.android.installreferrer.api;

import android.content.Context;
import android.os.RemoteException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public abstract class InstallReferrerClient {
  public static Builder newBuilder(Context paramContext) {
    return new Builder(paramContext);
  }
  
  public abstract void endConnection();
  
  public abstract ReferrerDetails getInstallReferrer() throws RemoteException;
  
  public abstract boolean isReady();
  
  public abstract void startConnection(InstallReferrerStateListener paramInstallReferrerStateListener);
  
  public static final class Builder {
    private final Context mContext;
    
    private Builder(Context param1Context) {
      this.mContext = param1Context;
    }
    
    public InstallReferrerClient build() {
      Context context = this.mContext;
      if (context != null)
        return new InstallReferrerClientImpl(context); 
      throw new IllegalArgumentException("Please provide a valid Context.");
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface InstallReferrerResponse {
    public static final int DEVELOPER_ERROR = 3;
    
    public static final int FEATURE_NOT_SUPPORTED = 2;
    
    public static final int OK = 0;
    
    public static final int PERMISSION_ERROR = 4;
    
    public static final int SERVICE_DISCONNECTED = -1;
    
    public static final int SERVICE_UNAVAILABLE = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\com\android\installreferrer\api\InstallReferrerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */