package androidx.work;

public interface RunnableScheduler {
  void cancel(Runnable paramRunnable);
  
  void scheduleWithDelay(long paramLong, Runnable paramRunnable);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\work\RunnableScheduler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */