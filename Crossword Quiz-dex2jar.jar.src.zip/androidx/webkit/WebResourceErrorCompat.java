package androidx.webkit;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public abstract class WebResourceErrorCompat {
  public abstract CharSequence getDescription();
  
  public abstract int getErrorCode();
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface NetErrorCode {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\WebResourceErrorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */