package androidx.webkit;

public class WebMessageCompat {
  private String mData;
  
  private WebMessagePortCompat[] mPorts;
  
  public WebMessageCompat(String paramString) {
    this.mData = paramString;
  }
  
  public WebMessageCompat(String paramString, WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    this.mData = paramString;
    this.mPorts = paramArrayOfWebMessagePortCompat;
  }
  
  public String getData() {
    return this.mData;
  }
  
  public WebMessagePortCompat[] getPorts() {
    return this.mPorts;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\WebMessageCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */