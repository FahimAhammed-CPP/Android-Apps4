package androidx.webkit;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ProxyConfig {
  private static final String BYPASS_RULE_REMOVE_IMPLICIT = "<-loopback>";
  
  private static final String BYPASS_RULE_SIMPLE_NAMES = "<local>";
  
  private static final String DIRECT = "direct://";
  
  public static final String MATCH_ALL_SCHEMES = "*";
  
  public static final String MATCH_HTTP = "http";
  
  public static final String MATCH_HTTPS = "https";
  
  private List<String> mBypassRules;
  
  private List<ProxyRule> mProxyRules;
  
  public ProxyConfig(List<ProxyRule> paramList, List<String> paramList1) {
    this.mProxyRules = paramList;
    this.mBypassRules = paramList1;
  }
  
  public List<String> getBypassRules() {
    return Collections.unmodifiableList(this.mBypassRules);
  }
  
  public List<ProxyRule> getProxyRules() {
    return Collections.unmodifiableList(this.mProxyRules);
  }
  
  public static final class Builder {
    private List<String> mBypassRules = new ArrayList<String>();
    
    private List<ProxyConfig.ProxyRule> mProxyRules = new ArrayList<ProxyConfig.ProxyRule>();
    
    public Builder() {}
    
    public Builder(ProxyConfig param1ProxyConfig) {}
    
    private List<String> bypassRules() {
      return this.mBypassRules;
    }
    
    private List<ProxyConfig.ProxyRule> proxyRules() {
      return this.mProxyRules;
    }
    
    public Builder addBypassRule(String param1String) {
      this.mBypassRules.add(param1String);
      return this;
    }
    
    public Builder addDirect() {
      return addDirect("*");
    }
    
    public Builder addDirect(String param1String) {
      this.mProxyRules.add(new ProxyConfig.ProxyRule(param1String, "direct://"));
      return this;
    }
    
    public Builder addProxyRule(String param1String) {
      this.mProxyRules.add(new ProxyConfig.ProxyRule(param1String));
      return this;
    }
    
    public Builder addProxyRule(String param1String1, String param1String2) {
      this.mProxyRules.add(new ProxyConfig.ProxyRule(param1String2, param1String1));
      return this;
    }
    
    public ProxyConfig build() {
      return new ProxyConfig(proxyRules(), bypassRules());
    }
    
    public Builder bypassSimpleHostnames() {
      return addBypassRule("<local>");
    }
    
    public Builder removeImplicitRules() {
      return addBypassRule("<-loopback>");
    }
  }
  
  public static final class ProxyRule {
    private String mSchemeFilter;
    
    private String mUrl;
    
    public ProxyRule(String param1String) {
      this("*", param1String);
    }
    
    public ProxyRule(String param1String1, String param1String2) {
      this.mSchemeFilter = param1String1;
      this.mUrl = param1String2;
    }
    
    public String getSchemeFilter() {
      return this.mSchemeFilter;
    }
    
    public String getUrl() {
      return this.mUrl;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProxyScheme {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\ProxyConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */