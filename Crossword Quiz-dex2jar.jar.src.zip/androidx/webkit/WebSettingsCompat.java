package androidx.webkit;

import android.webkit.WebSettings;
import androidx.webkit.internal.WebSettingsAdapter;
import androidx.webkit.internal.WebViewFeatureInternal;
import androidx.webkit.internal.WebViewGlueCommunicator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class WebSettingsCompat {
  public static final int DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING = 2;
  
  public static final int DARK_STRATEGY_USER_AGENT_DARKENING_ONLY = 0;
  
  public static final int DARK_STRATEGY_WEB_THEME_DARKENING_ONLY = 1;
  
  public static final int FORCE_DARK_AUTO = 1;
  
  public static final int FORCE_DARK_OFF = 0;
  
  public static final int FORCE_DARK_ON = 2;
  
  private static WebSettingsAdapter getAdapter(WebSettings paramWebSettings) {
    return WebViewGlueCommunicator.getCompatConverter().convertSettings(paramWebSettings);
  }
  
  public static int getDisabledActionModeMenuItems(WebSettings paramWebSettings) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.DISABLED_ACTION_MODE_MENU_ITEMS;
    if (webViewFeatureInternal.isSupportedByFramework())
      return paramWebSettings.getDisabledActionModeMenuItems(); 
    if (webViewFeatureInternal.isSupportedByWebView())
      return getAdapter(paramWebSettings).getDisabledActionModeMenuItems(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static int getForceDark(WebSettings paramWebSettings) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.FORCE_DARK;
    if (webViewFeatureInternal.isSupportedByFramework())
      return paramWebSettings.getForceDark(); 
    if (webViewFeatureInternal.isSupportedByWebView())
      return getAdapter(paramWebSettings).getForceDark(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static int getForceDarkStrategy(WebSettings paramWebSettings) {
    if (WebViewFeatureInternal.FORCE_DARK_STRATEGY.isSupportedByWebView())
      return getAdapter(paramWebSettings).getForceDark(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static boolean getOffscreenPreRaster(WebSettings paramWebSettings) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.OFF_SCREEN_PRERASTER;
    if (webViewFeatureInternal.isSupportedByFramework())
      return paramWebSettings.getOffscreenPreRaster(); 
    if (webViewFeatureInternal.isSupportedByWebView())
      return getAdapter(paramWebSettings).getOffscreenPreRaster(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static boolean getSafeBrowsingEnabled(WebSettings paramWebSettings) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.SAFE_BROWSING_ENABLE;
    if (webViewFeatureInternal.isSupportedByFramework())
      return paramWebSettings.getSafeBrowsingEnabled(); 
    if (webViewFeatureInternal.isSupportedByWebView())
      return getAdapter(paramWebSettings).getSafeBrowsingEnabled(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setDisabledActionModeMenuItems(WebSettings paramWebSettings, int paramInt) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.DISABLED_ACTION_MODE_MENU_ITEMS;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      paramWebSettings.setDisabledActionModeMenuItems(paramInt);
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setDisabledActionModeMenuItems(paramInt);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setForceDark(WebSettings paramWebSettings, int paramInt) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.FORCE_DARK;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      paramWebSettings.setForceDark(paramInt);
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setForceDark(paramInt);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setForceDarkStrategy(WebSettings paramWebSettings, int paramInt) {
    if (WebViewFeatureInternal.FORCE_DARK_STRATEGY.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setForceDarkStrategy(paramInt);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setOffscreenPreRaster(WebSettings paramWebSettings, boolean paramBoolean) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.OFF_SCREEN_PRERASTER;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      paramWebSettings.setOffscreenPreRaster(paramBoolean);
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setOffscreenPreRaster(paramBoolean);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setSafeBrowsingEnabled(WebSettings paramWebSettings, boolean paramBoolean) {
    WebViewFeatureInternal webViewFeatureInternal = WebViewFeatureInternal.SAFE_BROWSING_ENABLE;
    if (webViewFeatureInternal.isSupportedByFramework()) {
      paramWebSettings.setSafeBrowsingEnabled(paramBoolean);
      return;
    } 
    if (webViewFeatureInternal.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setSafeBrowsingEnabled(paramBoolean);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static void setWillSuppressErrorPage(WebSettings paramWebSettings, boolean paramBoolean) {
    if (WebViewFeatureInternal.SUPPRESS_ERROR_PAGE.isSupportedByWebView()) {
      getAdapter(paramWebSettings).setWillSuppressErrorPage(paramBoolean);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public static boolean willSuppressErrorPage(WebSettings paramWebSettings) {
    if (WebViewFeatureInternal.SUPPRESS_ERROR_PAGE.isSupportedByWebView())
      return getAdapter(paramWebSettings).willSuppressErrorPage(); 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @Target({ElementType.PARAMETER, ElementType.METHOD})
  public static @interface ForceDark {}
  
  @Retention(RetentionPolicy.SOURCE)
  @Target({ElementType.PARAMETER, ElementType.METHOD})
  public static @interface ForceDarkStrategy {}
  
  @Retention(RetentionPolicy.SOURCE)
  @Target({ElementType.PARAMETER, ElementType.METHOD})
  public static @interface MenuItemFlags {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\webkit\WebSettingsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */