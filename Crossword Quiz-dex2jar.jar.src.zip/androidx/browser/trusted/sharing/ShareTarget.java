package androidx.browser.trusted.sharing;

import android.os.Bundle;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class ShareTarget {
  public static final String ENCODING_TYPE_MULTIPART = "multipart/form-data";
  
  public static final String ENCODING_TYPE_URL_ENCODED = "application/x-www-form-urlencoded";
  
  public static final String KEY_ACTION = "androidx.browser.trusted.sharing.KEY_ACTION";
  
  public static final String KEY_ENCTYPE = "androidx.browser.trusted.sharing.KEY_ENCTYPE";
  
  public static final String KEY_METHOD = "androidx.browser.trusted.sharing.KEY_METHOD";
  
  public static final String KEY_PARAMS = "androidx.browser.trusted.sharing.KEY_PARAMS";
  
  public static final String METHOD_GET = "GET";
  
  public static final String METHOD_POST = "POST";
  
  public final String action;
  
  public final String encodingType;
  
  public final String method;
  
  public final Params params;
  
  public ShareTarget(String paramString1, String paramString2, String paramString3, Params paramParams) {
    this.action = paramString1;
    this.method = paramString2;
    this.encodingType = paramString3;
    this.params = paramParams;
  }
  
  public static ShareTarget fromBundle(Bundle paramBundle) {
    String str1 = paramBundle.getString("androidx.browser.trusted.sharing.KEY_ACTION");
    String str2 = paramBundle.getString("androidx.browser.trusted.sharing.KEY_METHOD");
    String str3 = paramBundle.getString("androidx.browser.trusted.sharing.KEY_ENCTYPE");
    Params params = Params.fromBundle(paramBundle.getBundle("androidx.browser.trusted.sharing.KEY_PARAMS"));
    return (str1 == null || params == null) ? null : new ShareTarget(str1, str2, str3, params);
  }
  
  public Bundle toBundle() {
    Bundle bundle = new Bundle();
    bundle.putString("androidx.browser.trusted.sharing.KEY_ACTION", this.action);
    bundle.putString("androidx.browser.trusted.sharing.KEY_METHOD", this.method);
    bundle.putString("androidx.browser.trusted.sharing.KEY_ENCTYPE", this.encodingType);
    bundle.putBundle("androidx.browser.trusted.sharing.KEY_PARAMS", this.params.toBundle());
    return bundle;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface EncodingType {}
  
  public static final class FileFormField {
    public static final String KEY_ACCEPTED_TYPES = "androidx.browser.trusted.sharing.KEY_ACCEPTED_TYPES";
    
    public static final String KEY_NAME = "androidx.browser.trusted.sharing.KEY_FILE_NAME";
    
    public final List<String> acceptedTypes;
    
    public final String name;
    
    public FileFormField(String param1String, List<String> param1List) {
      this.name = param1String;
      this.acceptedTypes = Collections.unmodifiableList(param1List);
    }
    
    static FileFormField fromBundle(Bundle param1Bundle) {
      FileFormField fileFormField;
      Bundle bundle = null;
      if (param1Bundle == null)
        return null; 
      String str = param1Bundle.getString("androidx.browser.trusted.sharing.KEY_FILE_NAME");
      ArrayList<String> arrayList = param1Bundle.getStringArrayList("androidx.browser.trusted.sharing.KEY_ACCEPTED_TYPES");
      param1Bundle = bundle;
      if (str != null) {
        if (arrayList == null)
          return null; 
        fileFormField = new FileFormField(str, arrayList);
      } 
      return fileFormField;
    }
    
    Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putString("androidx.browser.trusted.sharing.KEY_FILE_NAME", this.name);
      bundle.putStringArrayList("androidx.browser.trusted.sharing.KEY_ACCEPTED_TYPES", new ArrayList<String>(this.acceptedTypes));
      return bundle;
    }
  }
  
  public static class Params {
    public static final String KEY_FILES = "androidx.browser.trusted.sharing.KEY_FILES";
    
    public static final String KEY_TEXT = "androidx.browser.trusted.sharing.KEY_TEXT";
    
    public static final String KEY_TITLE = "androidx.browser.trusted.sharing.KEY_TITLE";
    
    public final List<ShareTarget.FileFormField> files;
    
    public final String text;
    
    public final String title;
    
    public Params(String param1String1, String param1String2, List<ShareTarget.FileFormField> param1List) {
      this.title = param1String1;
      this.text = param1String2;
      this.files = param1List;
    }
    
    static Params fromBundle(Bundle param1Bundle) {
      ArrayList<ShareTarget.FileFormField> arrayList = null;
      if (param1Bundle == null)
        return null; 
      ArrayList arrayList1 = param1Bundle.getParcelableArrayList("androidx.browser.trusted.sharing.KEY_FILES");
      if (arrayList1 != null) {
        ArrayList<ShareTarget.FileFormField> arrayList2 = new ArrayList();
        Iterator<Bundle> iterator = arrayList1.iterator();
        while (true) {
          arrayList = arrayList2;
          if (iterator.hasNext()) {
            arrayList2.add(ShareTarget.FileFormField.fromBundle(iterator.next()));
            continue;
          } 
          break;
        } 
      } 
      return new Params(param1Bundle.getString("androidx.browser.trusted.sharing.KEY_TITLE"), param1Bundle.getString("androidx.browser.trusted.sharing.KEY_TEXT"), arrayList);
    }
    
    Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putString("androidx.browser.trusted.sharing.KEY_TITLE", this.title);
      bundle.putString("androidx.browser.trusted.sharing.KEY_TEXT", this.text);
      if (this.files != null) {
        ArrayList<Bundle> arrayList = new ArrayList();
        Iterator<ShareTarget.FileFormField> iterator = this.files.iterator();
        while (iterator.hasNext())
          arrayList.add(((ShareTarget.FileFormField)iterator.next()).toBundle()); 
        bundle.putParcelableArrayList("androidx.browser.trusted.sharing.KEY_FILES", arrayList);
      } 
      return bundle;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RequestMethod {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\browser\trusted\sharing\ShareTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */