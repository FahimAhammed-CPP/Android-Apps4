package androidx.exifinterface.media;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.util.Log;
import android.util.Pair;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class ExifInterface {
  public static final short ALTITUDE_ABOVE_SEA_LEVEL = 0;
  
  public static final short ALTITUDE_BELOW_SEA_LEVEL = 1;
  
  static final Charset ASCII;
  
  public static final int[] BITS_PER_SAMPLE_GREYSCALE_1;
  
  public static final int[] BITS_PER_SAMPLE_GREYSCALE_2;
  
  public static final int[] BITS_PER_SAMPLE_RGB;
  
  static final short BYTE_ALIGN_II = 18761;
  
  static final short BYTE_ALIGN_MM = 19789;
  
  public static final int COLOR_SPACE_S_RGB = 1;
  
  public static final int COLOR_SPACE_UNCALIBRATED = 65535;
  
  public static final short CONTRAST_HARD = 2;
  
  public static final short CONTRAST_NORMAL = 0;
  
  public static final short CONTRAST_SOFT = 1;
  
  public static final int DATA_DEFLATE_ZIP = 8;
  
  public static final int DATA_HUFFMAN_COMPRESSED = 2;
  
  public static final int DATA_JPEG = 6;
  
  public static final int DATA_JPEG_COMPRESSED = 7;
  
  public static final int DATA_LOSSY_JPEG = 34892;
  
  public static final int DATA_PACK_BITS_COMPRESSED = 32773;
  
  public static final int DATA_UNCOMPRESSED = 1;
  
  private static final boolean DEBUG = false;
  
  static final byte[] EXIF_ASCII_PREFIX;
  
  private static final ExifTag[] EXIF_POINTER_TAGS;
  
  static final ExifTag[][] EXIF_TAGS;
  
  public static final short EXPOSURE_MODE_AUTO = 0;
  
  public static final short EXPOSURE_MODE_AUTO_BRACKET = 2;
  
  public static final short EXPOSURE_MODE_MANUAL = 1;
  
  public static final short EXPOSURE_PROGRAM_ACTION = 6;
  
  public static final short EXPOSURE_PROGRAM_APERTURE_PRIORITY = 3;
  
  public static final short EXPOSURE_PROGRAM_CREATIVE = 5;
  
  public static final short EXPOSURE_PROGRAM_LANDSCAPE_MODE = 8;
  
  public static final short EXPOSURE_PROGRAM_MANUAL = 1;
  
  public static final short EXPOSURE_PROGRAM_NORMAL = 2;
  
  public static final short EXPOSURE_PROGRAM_NOT_DEFINED = 0;
  
  public static final short EXPOSURE_PROGRAM_PORTRAIT_MODE = 7;
  
  public static final short EXPOSURE_PROGRAM_SHUTTER_PRIORITY = 4;
  
  public static final short FILE_SOURCE_DSC = 3;
  
  public static final short FILE_SOURCE_OTHER = 0;
  
  public static final short FILE_SOURCE_REFLEX_SCANNER = 2;
  
  public static final short FILE_SOURCE_TRANSPARENT_SCANNER = 1;
  
  public static final short FLAG_FLASH_FIRED = 1;
  
  public static final short FLAG_FLASH_MODE_AUTO = 24;
  
  public static final short FLAG_FLASH_MODE_COMPULSORY_FIRING = 8;
  
  public static final short FLAG_FLASH_MODE_COMPULSORY_SUPPRESSION = 16;
  
  public static final short FLAG_FLASH_NO_FLASH_FUNCTION = 32;
  
  public static final short FLAG_FLASH_RED_EYE_SUPPORTED = 64;
  
  public static final short FLAG_FLASH_RETURN_LIGHT_DETECTED = 6;
  
  public static final short FLAG_FLASH_RETURN_LIGHT_NOT_DETECTED = 4;
  
  private static final List<Integer> FLIPPED_ROTATION_ORDER;
  
  public static final short FORMAT_CHUNKY = 1;
  
  public static final short FORMAT_PLANAR = 2;
  
  public static final short GAIN_CONTROL_HIGH_GAIN_DOWN = 4;
  
  public static final short GAIN_CONTROL_HIGH_GAIN_UP = 2;
  
  public static final short GAIN_CONTROL_LOW_GAIN_DOWN = 3;
  
  public static final short GAIN_CONTROL_LOW_GAIN_UP = 1;
  
  public static final short GAIN_CONTROL_NONE = 0;
  
  public static final String GPS_DIRECTION_MAGNETIC = "M";
  
  public static final String GPS_DIRECTION_TRUE = "T";
  
  public static final String GPS_DISTANCE_KILOMETERS = "K";
  
  public static final String GPS_DISTANCE_MILES = "M";
  
  public static final String GPS_DISTANCE_NAUTICAL_MILES = "N";
  
  public static final String GPS_MEASUREMENT_2D = "2";
  
  public static final String GPS_MEASUREMENT_3D = "3";
  
  public static final short GPS_MEASUREMENT_DIFFERENTIAL_CORRECTED = 1;
  
  public static final String GPS_MEASUREMENT_INTERRUPTED = "V";
  
  public static final String GPS_MEASUREMENT_IN_PROGRESS = "A";
  
  public static final short GPS_MEASUREMENT_NO_DIFFERENTIAL = 0;
  
  public static final String GPS_SPEED_KILOMETERS_PER_HOUR = "K";
  
  public static final String GPS_SPEED_KNOTS = "N";
  
  public static final String GPS_SPEED_MILES_PER_HOUR = "M";
  
  static final byte[] IDENTIFIER_EXIF_APP1;
  
  private static final ExifTag[] IFD_EXIF_TAGS;
  
  private static final int IFD_FORMAT_BYTE = 1;
  
  static final int[] IFD_FORMAT_BYTES_PER_FORMAT;
  
  private static final int IFD_FORMAT_DOUBLE = 12;
  
  private static final int IFD_FORMAT_IFD = 13;
  
  static final String[] IFD_FORMAT_NAMES;
  
  private static final int IFD_FORMAT_SBYTE = 6;
  
  private static final int IFD_FORMAT_SINGLE = 11;
  
  private static final int IFD_FORMAT_SLONG = 9;
  
  private static final int IFD_FORMAT_SRATIONAL = 10;
  
  private static final int IFD_FORMAT_SSHORT = 8;
  
  private static final int IFD_FORMAT_STRING = 2;
  
  private static final int IFD_FORMAT_ULONG = 4;
  
  private static final int IFD_FORMAT_UNDEFINED = 7;
  
  private static final int IFD_FORMAT_URATIONAL = 5;
  
  private static final int IFD_FORMAT_USHORT = 3;
  
  private static final ExifTag[] IFD_GPS_TAGS;
  
  private static final ExifTag[] IFD_INTEROPERABILITY_TAGS;
  
  private static final int IFD_OFFSET = 8;
  
  private static final ExifTag[] IFD_THUMBNAIL_TAGS;
  
  private static final ExifTag[] IFD_TIFF_TAGS;
  
  private static final int IFD_TYPE_EXIF = 1;
  
  private static final int IFD_TYPE_GPS = 2;
  
  private static final int IFD_TYPE_INTEROPERABILITY = 3;
  
  private static final int IFD_TYPE_ORF_CAMERA_SETTINGS = 7;
  
  private static final int IFD_TYPE_ORF_IMAGE_PROCESSING = 8;
  
  private static final int IFD_TYPE_ORF_MAKER_NOTE = 6;
  
  private static final int IFD_TYPE_PEF = 9;
  
  static final int IFD_TYPE_PREVIEW = 5;
  
  static final int IFD_TYPE_PRIMARY = 0;
  
  static final int IFD_TYPE_THUMBNAIL = 4;
  
  private static final int IMAGE_TYPE_ARW = 1;
  
  private static final int IMAGE_TYPE_CR2 = 2;
  
  private static final int IMAGE_TYPE_DNG = 3;
  
  private static final int IMAGE_TYPE_JPEG = 4;
  
  private static final int IMAGE_TYPE_NEF = 5;
  
  private static final int IMAGE_TYPE_NRW = 6;
  
  private static final int IMAGE_TYPE_ORF = 7;
  
  private static final int IMAGE_TYPE_PEF = 8;
  
  private static final int IMAGE_TYPE_RAF = 9;
  
  private static final int IMAGE_TYPE_RW2 = 10;
  
  private static final int IMAGE_TYPE_SRW = 11;
  
  private static final int IMAGE_TYPE_UNKNOWN = 0;
  
  private static final ExifTag JPEG_INTERCHANGE_FORMAT_LENGTH_TAG;
  
  private static final ExifTag JPEG_INTERCHANGE_FORMAT_TAG;
  
  static final byte[] JPEG_SIGNATURE;
  
  public static final String LATITUDE_NORTH = "N";
  
  public static final String LATITUDE_SOUTH = "S";
  
  public static final short LIGHT_SOURCE_CLOUDY_WEATHER = 10;
  
  public static final short LIGHT_SOURCE_COOL_WHITE_FLUORESCENT = 14;
  
  public static final short LIGHT_SOURCE_D50 = 23;
  
  public static final short LIGHT_SOURCE_D55 = 20;
  
  public static final short LIGHT_SOURCE_D65 = 21;
  
  public static final short LIGHT_SOURCE_D75 = 22;
  
  public static final short LIGHT_SOURCE_DAYLIGHT = 1;
  
  public static final short LIGHT_SOURCE_DAYLIGHT_FLUORESCENT = 12;
  
  public static final short LIGHT_SOURCE_DAY_WHITE_FLUORESCENT = 13;
  
  public static final short LIGHT_SOURCE_FINE_WEATHER = 9;
  
  public static final short LIGHT_SOURCE_FLASH = 4;
  
  public static final short LIGHT_SOURCE_FLUORESCENT = 2;
  
  public static final short LIGHT_SOURCE_ISO_STUDIO_TUNGSTEN = 24;
  
  public static final short LIGHT_SOURCE_OTHER = 255;
  
  public static final short LIGHT_SOURCE_SHADE = 11;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_A = 17;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_B = 18;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_C = 19;
  
  public static final short LIGHT_SOURCE_TUNGSTEN = 3;
  
  public static final short LIGHT_SOURCE_UNKNOWN = 0;
  
  public static final short LIGHT_SOURCE_WARM_WHITE_FLUORESCENT = 16;
  
  public static final short LIGHT_SOURCE_WHITE_FLUORESCENT = 15;
  
  public static final String LONGITUDE_EAST = "E";
  
  public static final String LONGITUDE_WEST = "W";
  
  static final byte MARKER = -1;
  
  static final byte MARKER_APP1 = -31;
  
  private static final byte MARKER_COM = -2;
  
  static final byte MARKER_EOI = -39;
  
  private static final byte MARKER_SOF0 = -64;
  
  private static final byte MARKER_SOF1 = -63;
  
  private static final byte MARKER_SOF10 = -54;
  
  private static final byte MARKER_SOF11 = -53;
  
  private static final byte MARKER_SOF13 = -51;
  
  private static final byte MARKER_SOF14 = -50;
  
  private static final byte MARKER_SOF15 = -49;
  
  private static final byte MARKER_SOF2 = -62;
  
  private static final byte MARKER_SOF3 = -61;
  
  private static final byte MARKER_SOF5 = -59;
  
  private static final byte MARKER_SOF6 = -58;
  
  private static final byte MARKER_SOF7 = -57;
  
  private static final byte MARKER_SOF9 = -55;
  
  private static final byte MARKER_SOI = -40;
  
  private static final byte MARKER_SOS = -38;
  
  private static final int MAX_THUMBNAIL_SIZE = 512;
  
  public static final short METERING_MODE_AVERAGE = 1;
  
  public static final short METERING_MODE_CENTER_WEIGHT_AVERAGE = 2;
  
  public static final short METERING_MODE_MULTI_SPOT = 4;
  
  public static final short METERING_MODE_OTHER = 255;
  
  public static final short METERING_MODE_PARTIAL = 6;
  
  public static final short METERING_MODE_PATTERN = 5;
  
  public static final short METERING_MODE_SPOT = 3;
  
  public static final short METERING_MODE_UNKNOWN = 0;
  
  private static final ExifTag[] ORF_CAMERA_SETTINGS_TAGS;
  
  private static final ExifTag[] ORF_IMAGE_PROCESSING_TAGS;
  
  private static final byte[] ORF_MAKER_NOTE_HEADER_1;
  
  private static final int ORF_MAKER_NOTE_HEADER_1_SIZE = 8;
  
  private static final byte[] ORF_MAKER_NOTE_HEADER_2;
  
  private static final int ORF_MAKER_NOTE_HEADER_2_SIZE = 12;
  
  private static final ExifTag[] ORF_MAKER_NOTE_TAGS;
  
  private static final short ORF_SIGNATURE_1 = 20306;
  
  private static final short ORF_SIGNATURE_2 = 21330;
  
  public static final int ORIENTATION_FLIP_HORIZONTAL = 2;
  
  public static final int ORIENTATION_FLIP_VERTICAL = 4;
  
  public static final int ORIENTATION_NORMAL = 1;
  
  public static final int ORIENTATION_ROTATE_180 = 3;
  
  public static final int ORIENTATION_ROTATE_270 = 8;
  
  public static final int ORIENTATION_ROTATE_90 = 6;
  
  public static final int ORIENTATION_TRANSPOSE = 5;
  
  public static final int ORIENTATION_TRANSVERSE = 7;
  
  public static final int ORIENTATION_UNDEFINED = 0;
  
  public static final int ORIGINAL_RESOLUTION_IMAGE = 0;
  
  private static final int PEF_MAKER_NOTE_SKIP_SIZE = 6;
  
  private static final String PEF_SIGNATURE = "PENTAX";
  
  private static final ExifTag[] PEF_TAGS;
  
  public static final int PHOTOMETRIC_INTERPRETATION_BLACK_IS_ZERO = 1;
  
  public static final int PHOTOMETRIC_INTERPRETATION_RGB = 2;
  
  public static final int PHOTOMETRIC_INTERPRETATION_WHITE_IS_ZERO = 0;
  
  public static final int PHOTOMETRIC_INTERPRETATION_YCBCR = 6;
  
  private static final int RAF_INFO_SIZE = 160;
  
  private static final int RAF_JPEG_LENGTH_VALUE_SIZE = 4;
  
  private static final int RAF_OFFSET_TO_JPEG_IMAGE_OFFSET = 84;
  
  private static final String RAF_SIGNATURE = "FUJIFILMCCD-RAW";
  
  public static final int REDUCED_RESOLUTION_IMAGE = 1;
  
  public static final short RENDERED_PROCESS_CUSTOM = 1;
  
  public static final short RENDERED_PROCESS_NORMAL = 0;
  
  public static final short RESOLUTION_UNIT_CENTIMETERS = 3;
  
  public static final short RESOLUTION_UNIT_INCHES = 2;
  
  private static final List<Integer> ROTATION_ORDER;
  
  private static final short RW2_SIGNATURE = 85;
  
  public static final short SATURATION_HIGH = 0;
  
  public static final short SATURATION_LOW = 0;
  
  public static final short SATURATION_NORMAL = 0;
  
  public static final short SCENE_CAPTURE_TYPE_LANDSCAPE = 1;
  
  public static final short SCENE_CAPTURE_TYPE_NIGHT = 3;
  
  public static final short SCENE_CAPTURE_TYPE_PORTRAIT = 2;
  
  public static final short SCENE_CAPTURE_TYPE_STANDARD = 0;
  
  public static final short SCENE_TYPE_DIRECTLY_PHOTOGRAPHED = 1;
  
  public static final short SENSITIVITY_TYPE_ISO_SPEED = 3;
  
  public static final short SENSITIVITY_TYPE_REI = 2;
  
  public static final short SENSITIVITY_TYPE_REI_AND_ISO = 6;
  
  public static final short SENSITIVITY_TYPE_SOS = 1;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_ISO = 5;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_REI = 4;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_REI_AND_ISO = 7;
  
  public static final short SENSITIVITY_TYPE_UNKNOWN = 0;
  
  public static final short SENSOR_TYPE_COLOR_SEQUENTIAL = 5;
  
  public static final short SENSOR_TYPE_COLOR_SEQUENTIAL_LINEAR = 8;
  
  public static final short SENSOR_TYPE_NOT_DEFINED = 1;
  
  public static final short SENSOR_TYPE_ONE_CHIP = 2;
  
  public static final short SENSOR_TYPE_THREE_CHIP = 4;
  
  public static final short SENSOR_TYPE_TRILINEAR = 7;
  
  public static final short SENSOR_TYPE_TWO_CHIP = 3;
  
  public static final short SHARPNESS_HARD = 2;
  
  public static final short SHARPNESS_NORMAL = 0;
  
  public static final short SHARPNESS_SOFT = 1;
  
  private static final int SIGNATURE_CHECK_SIZE = 5000;
  
  static final byte START_CODE = 42;
  
  public static final short SUBJECT_DISTANCE_RANGE_CLOSE_VIEW = 2;
  
  public static final short SUBJECT_DISTANCE_RANGE_DISTANT_VIEW = 3;
  
  public static final short SUBJECT_DISTANCE_RANGE_MACRO = 1;
  
  public static final short SUBJECT_DISTANCE_RANGE_UNKNOWN = 0;
  
  private static final String TAG = "ExifInterface";
  
  public static final String TAG_APERTURE_VALUE = "ApertureValue";
  
  public static final String TAG_ARTIST = "Artist";
  
  public static final String TAG_BITS_PER_SAMPLE = "BitsPerSample";
  
  public static final String TAG_BODY_SERIAL_NUMBER = "BodySerialNumber";
  
  public static final String TAG_BRIGHTNESS_VALUE = "BrightnessValue";
  
  public static final String TAG_CAMARA_OWNER_NAME = "CameraOwnerName";
  
  public static final String TAG_CFA_PATTERN = "CFAPattern";
  
  public static final String TAG_COLOR_SPACE = "ColorSpace";
  
  public static final String TAG_COMPONENTS_CONFIGURATION = "ComponentsConfiguration";
  
  public static final String TAG_COMPRESSED_BITS_PER_PIXEL = "CompressedBitsPerPixel";
  
  public static final String TAG_COMPRESSION = "Compression";
  
  public static final String TAG_CONTRAST = "Contrast";
  
  public static final String TAG_COPYRIGHT = "Copyright";
  
  public static final String TAG_CUSTOM_RENDERED = "CustomRendered";
  
  public static final String TAG_DATETIME = "DateTime";
  
  public static final String TAG_DATETIME_DIGITIZED = "DateTimeDigitized";
  
  public static final String TAG_DATETIME_ORIGINAL = "DateTimeOriginal";
  
  public static final String TAG_DEFAULT_CROP_SIZE = "DefaultCropSize";
  
  public static final String TAG_DEVICE_SETTING_DESCRIPTION = "DeviceSettingDescription";
  
  public static final String TAG_DIGITAL_ZOOM_RATIO = "DigitalZoomRatio";
  
  public static final String TAG_DNG_VERSION = "DNGVersion";
  
  private static final String TAG_EXIF_IFD_POINTER = "ExifIFDPointer";
  
  public static final String TAG_EXIF_VERSION = "ExifVersion";
  
  public static final String TAG_EXPOSURE_BIAS_VALUE = "ExposureBiasValue";
  
  public static final String TAG_EXPOSURE_INDEX = "ExposureIndex";
  
  public static final String TAG_EXPOSURE_MODE = "ExposureMode";
  
  public static final String TAG_EXPOSURE_PROGRAM = "ExposureProgram";
  
  public static final String TAG_EXPOSURE_TIME = "ExposureTime";
  
  public static final String TAG_FILE_SOURCE = "FileSource";
  
  public static final String TAG_FLASH = "Flash";
  
  public static final String TAG_FLASHPIX_VERSION = "FlashpixVersion";
  
  public static final String TAG_FLASH_ENERGY = "FlashEnergy";
  
  public static final String TAG_FOCAL_LENGTH = "FocalLength";
  
  public static final String TAG_FOCAL_LENGTH_IN_35MM_FILM = "FocalLengthIn35mmFilm";
  
  public static final String TAG_FOCAL_PLANE_RESOLUTION_UNIT = "FocalPlaneResolutionUnit";
  
  public static final String TAG_FOCAL_PLANE_X_RESOLUTION = "FocalPlaneXResolution";
  
  public static final String TAG_FOCAL_PLANE_Y_RESOLUTION = "FocalPlaneYResolution";
  
  public static final String TAG_F_NUMBER = "FNumber";
  
  public static final String TAG_GAIN_CONTROL = "GainControl";
  
  public static final String TAG_GAMMA = "Gamma";
  
  public static final String TAG_GPS_ALTITUDE = "GPSAltitude";
  
  public static final String TAG_GPS_ALTITUDE_REF = "GPSAltitudeRef";
  
  public static final String TAG_GPS_AREA_INFORMATION = "GPSAreaInformation";
  
  public static final String TAG_GPS_DATESTAMP = "GPSDateStamp";
  
  public static final String TAG_GPS_DEST_BEARING = "GPSDestBearing";
  
  public static final String TAG_GPS_DEST_BEARING_REF = "GPSDestBearingRef";
  
  public static final String TAG_GPS_DEST_DISTANCE = "GPSDestDistance";
  
  public static final String TAG_GPS_DEST_DISTANCE_REF = "GPSDestDistanceRef";
  
  public static final String TAG_GPS_DEST_LATITUDE = "GPSDestLatitude";
  
  public static final String TAG_GPS_DEST_LATITUDE_REF = "GPSDestLatitudeRef";
  
  public static final String TAG_GPS_DEST_LONGITUDE = "GPSDestLongitude";
  
  public static final String TAG_GPS_DEST_LONGITUDE_REF = "GPSDestLongitudeRef";
  
  public static final String TAG_GPS_DIFFERENTIAL = "GPSDifferential";
  
  public static final String TAG_GPS_DOP = "GPSDOP";
  
  public static final String TAG_GPS_H_POSITIONING_ERROR = "GPSHPositioningError";
  
  public static final String TAG_GPS_IMG_DIRECTION = "GPSImgDirection";
  
  public static final String TAG_GPS_IMG_DIRECTION_REF = "GPSImgDirectionRef";
  
  private static final String TAG_GPS_INFO_IFD_POINTER = "GPSInfoIFDPointer";
  
  public static final String TAG_GPS_LATITUDE = "GPSLatitude";
  
  public static final String TAG_GPS_LATITUDE_REF = "GPSLatitudeRef";
  
  public static final String TAG_GPS_LONGITUDE = "GPSLongitude";
  
  public static final String TAG_GPS_LONGITUDE_REF = "GPSLongitudeRef";
  
  public static final String TAG_GPS_MAP_DATUM = "GPSMapDatum";
  
  public static final String TAG_GPS_MEASURE_MODE = "GPSMeasureMode";
  
  public static final String TAG_GPS_PROCESSING_METHOD = "GPSProcessingMethod";
  
  public static final String TAG_GPS_SATELLITES = "GPSSatellites";
  
  public static final String TAG_GPS_SPEED = "GPSSpeed";
  
  public static final String TAG_GPS_SPEED_REF = "GPSSpeedRef";
  
  public static final String TAG_GPS_STATUS = "GPSStatus";
  
  public static final String TAG_GPS_TIMESTAMP = "GPSTimeStamp";
  
  public static final String TAG_GPS_TRACK = "GPSTrack";
  
  public static final String TAG_GPS_TRACK_REF = "GPSTrackRef";
  
  public static final String TAG_GPS_VERSION_ID = "GPSVersionID";
  
  private static final String TAG_HAS_THUMBNAIL = "HasThumbnail";
  
  public static final String TAG_IMAGE_DESCRIPTION = "ImageDescription";
  
  public static final String TAG_IMAGE_LENGTH = "ImageLength";
  
  public static final String TAG_IMAGE_UNIQUE_ID = "ImageUniqueID";
  
  public static final String TAG_IMAGE_WIDTH = "ImageWidth";
  
  private static final String TAG_INTEROPERABILITY_IFD_POINTER = "InteroperabilityIFDPointer";
  
  public static final String TAG_INTEROPERABILITY_INDEX = "InteroperabilityIndex";
  
  public static final String TAG_ISO_SPEED = "ISOSpeed";
  
  public static final String TAG_ISO_SPEED_LATITUDE_YYY = "ISOSpeedLatitudeyyy";
  
  public static final String TAG_ISO_SPEED_LATITUDE_ZZZ = "ISOSpeedLatitudezzz";
  
  @Deprecated
  public static final String TAG_ISO_SPEED_RATINGS = "ISOSpeedRatings";
  
  public static final String TAG_JPEG_INTERCHANGE_FORMAT = "JPEGInterchangeFormat";
  
  public static final String TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = "JPEGInterchangeFormatLength";
  
  public static final String TAG_LENS_MAKE = "LensMake";
  
  public static final String TAG_LENS_MODEL = "LensModel";
  
  public static final String TAG_LENS_SERIAL_NUMBER = "LensSerialNumber";
  
  public static final String TAG_LENS_SPECIFICATION = "LensSpecification";
  
  public static final String TAG_LIGHT_SOURCE = "LightSource";
  
  public static final String TAG_MAKE = "Make";
  
  public static final String TAG_MAKER_NOTE = "MakerNote";
  
  public static final String TAG_MAX_APERTURE_VALUE = "MaxApertureValue";
  
  public static final String TAG_METERING_MODE = "MeteringMode";
  
  public static final String TAG_MODEL = "Model";
  
  public static final String TAG_NEW_SUBFILE_TYPE = "NewSubfileType";
  
  public static final String TAG_OECF = "OECF";
  
  public static final String TAG_ORF_ASPECT_FRAME = "AspectFrame";
  
  private static final String TAG_ORF_CAMERA_SETTINGS_IFD_POINTER = "CameraSettingsIFDPointer";
  
  private static final String TAG_ORF_IMAGE_PROCESSING_IFD_POINTER = "ImageProcessingIFDPointer";
  
  public static final String TAG_ORF_PREVIEW_IMAGE_LENGTH = "PreviewImageLength";
  
  public static final String TAG_ORF_PREVIEW_IMAGE_START = "PreviewImageStart";
  
  public static final String TAG_ORF_THUMBNAIL_IMAGE = "ThumbnailImage";
  
  public static final String TAG_ORIENTATION = "Orientation";
  
  public static final String TAG_PHOTOGRAPHIC_SENSITIVITY = "PhotographicSensitivity";
  
  public static final String TAG_PHOTOMETRIC_INTERPRETATION = "PhotometricInterpretation";
  
  public static final String TAG_PIXEL_X_DIMENSION = "PixelXDimension";
  
  public static final String TAG_PIXEL_Y_DIMENSION = "PixelYDimension";
  
  public static final String TAG_PLANAR_CONFIGURATION = "PlanarConfiguration";
  
  public static final String TAG_PRIMARY_CHROMATICITIES = "PrimaryChromaticities";
  
  private static final ExifTag TAG_RAF_IMAGE_SIZE;
  
  public static final String TAG_RECOMMENDED_EXPOSURE_INDEX = "RecommendedExposureIndex";
  
  public static final String TAG_REFERENCE_BLACK_WHITE = "ReferenceBlackWhite";
  
  public static final String TAG_RELATED_SOUND_FILE = "RelatedSoundFile";
  
  public static final String TAG_RESOLUTION_UNIT = "ResolutionUnit";
  
  public static final String TAG_ROWS_PER_STRIP = "RowsPerStrip";
  
  public static final String TAG_RW2_ISO = "ISO";
  
  public static final String TAG_RW2_JPG_FROM_RAW = "JpgFromRaw";
  
  public static final String TAG_RW2_SENSOR_BOTTOM_BORDER = "SensorBottomBorder";
  
  public static final String TAG_RW2_SENSOR_LEFT_BORDER = "SensorLeftBorder";
  
  public static final String TAG_RW2_SENSOR_RIGHT_BORDER = "SensorRightBorder";
  
  public static final String TAG_RW2_SENSOR_TOP_BORDER = "SensorTopBorder";
  
  public static final String TAG_SAMPLES_PER_PIXEL = "SamplesPerPixel";
  
  public static final String TAG_SATURATION = "Saturation";
  
  public static final String TAG_SCENE_CAPTURE_TYPE = "SceneCaptureType";
  
  public static final String TAG_SCENE_TYPE = "SceneType";
  
  public static final String TAG_SENSING_METHOD = "SensingMethod";
  
  public static final String TAG_SENSITIVITY_TYPE = "SensitivityType";
  
  public static final String TAG_SHARPNESS = "Sharpness";
  
  public static final String TAG_SHUTTER_SPEED_VALUE = "ShutterSpeedValue";
  
  public static final String TAG_SOFTWARE = "Software";
  
  public static final String TAG_SPATIAL_FREQUENCY_RESPONSE = "SpatialFrequencyResponse";
  
  public static final String TAG_SPECTRAL_SENSITIVITY = "SpectralSensitivity";
  
  public static final String TAG_STANDARD_OUTPUT_SENSITIVITY = "StandardOutputSensitivity";
  
  public static final String TAG_STRIP_BYTE_COUNTS = "StripByteCounts";
  
  public static final String TAG_STRIP_OFFSETS = "StripOffsets";
  
  public static final String TAG_SUBFILE_TYPE = "SubfileType";
  
  public static final String TAG_SUBJECT_AREA = "SubjectArea";
  
  public static final String TAG_SUBJECT_DISTANCE = "SubjectDistance";
  
  public static final String TAG_SUBJECT_DISTANCE_RANGE = "SubjectDistanceRange";
  
  public static final String TAG_SUBJECT_LOCATION = "SubjectLocation";
  
  public static final String TAG_SUBSEC_TIME = "SubSecTime";
  
  public static final String TAG_SUBSEC_TIME_DIGITIZED = "SubSecTimeDigitized";
  
  public static final String TAG_SUBSEC_TIME_ORIGINAL = "SubSecTimeOriginal";
  
  private static final String TAG_SUB_IFD_POINTER = "SubIFDPointer";
  
  private static final String TAG_THUMBNAIL_DATA = "ThumbnailData";
  
  public static final String TAG_THUMBNAIL_IMAGE_LENGTH = "ThumbnailImageLength";
  
  public static final String TAG_THUMBNAIL_IMAGE_WIDTH = "ThumbnailImageWidth";
  
  private static final String TAG_THUMBNAIL_LENGTH = "ThumbnailLength";
  
  private static final String TAG_THUMBNAIL_OFFSET = "ThumbnailOffset";
  
  public static final String TAG_TRANSFER_FUNCTION = "TransferFunction";
  
  public static final String TAG_USER_COMMENT = "UserComment";
  
  public static final String TAG_WHITE_BALANCE = "WhiteBalance";
  
  public static final String TAG_WHITE_POINT = "WhitePoint";
  
  public static final String TAG_X_RESOLUTION = "XResolution";
  
  public static final String TAG_Y_CB_CR_COEFFICIENTS = "YCbCrCoefficients";
  
  public static final String TAG_Y_CB_CR_POSITIONING = "YCbCrPositioning";
  
  public static final String TAG_Y_CB_CR_SUB_SAMPLING = "YCbCrSubSampling";
  
  public static final String TAG_Y_RESOLUTION = "YResolution";
  
  @Deprecated
  public static final int WHITEBALANCE_AUTO = 0;
  
  @Deprecated
  public static final int WHITEBALANCE_MANUAL = 1;
  
  public static final short WHITE_BALANCE_AUTO = 0;
  
  public static final short WHITE_BALANCE_MANUAL = 1;
  
  public static final short Y_CB_CR_POSITIONING_CENTERED = 1;
  
  public static final short Y_CB_CR_POSITIONING_CO_SITED = 2;
  
  private static final HashMap<Integer, Integer> sExifPointerTagMap;
  
  private static final HashMap<Integer, ExifTag>[] sExifTagMapsForReading;
  
  private static final HashMap<String, ExifTag>[] sExifTagMapsForWriting;
  
  private static SimpleDateFormat sFormatter;
  
  private static final Pattern sGpsTimestampPattern;
  
  private static final Pattern sNonZeroTimePattern;
  
  private static final HashSet<String> sTagSetForCompatibility;
  
  private final AssetManager.AssetInputStream mAssetInputStream;
  
  private final HashMap<String, ExifAttribute>[] mAttributes;
  
  private Set<Integer> mAttributesOffsets;
  
  private ByteOrder mExifByteOrder;
  
  private int mExifOffset;
  
  private final String mFilename;
  
  private boolean mHasThumbnail;
  
  private boolean mIsSupportedFile;
  
  private int mMimeType;
  
  private int mOrfMakerNoteOffset;
  
  private int mOrfThumbnailLength;
  
  private int mOrfThumbnailOffset;
  
  private int mRw2JpgFromRawOffset;
  
  private byte[] mThumbnailBytes;
  
  private int mThumbnailCompression;
  
  private int mThumbnailLength;
  
  private int mThumbnailOffset;
  
  static {
    Integer integer1 = Integer.valueOf(1);
    Integer integer2 = Integer.valueOf(3);
    Integer integer3 = Integer.valueOf(2);
    Integer integer4 = Integer.valueOf(8);
    ROTATION_ORDER = Arrays.asList(new Integer[] { integer1, Integer.valueOf(6), integer2, integer4 });
    Integer integer5 = Integer.valueOf(7);
    Integer integer6 = Integer.valueOf(5);
    FLIPPED_ROTATION_ORDER = Arrays.asList(new Integer[] { integer3, integer5, Integer.valueOf(4), integer6 });
    BITS_PER_SAMPLE_RGB = new int[] { 8, 8, 8 };
    BITS_PER_SAMPLE_GREYSCALE_1 = new int[] { 4 };
    BITS_PER_SAMPLE_GREYSCALE_2 = new int[] { 8 };
    JPEG_SIGNATURE = new byte[] { -1, -40, -1 };
    ORF_MAKER_NOTE_HEADER_1 = new byte[] { 79, 76, 89, 77, 80, 0 };
    ORF_MAKER_NOTE_HEADER_2 = new byte[] { 79, 76, 89, 77, 80, 85, 83, 0, 73, 73 };
    IFD_FORMAT_NAMES = new String[] { 
        "", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", 
        "SRATIONAL", "SINGLE", "DOUBLE" };
    IFD_FORMAT_BYTES_PER_FORMAT = new int[] { 
        0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 
        8, 4, 8, 1 };
    EXIF_ASCII_PREFIX = new byte[] { 65, 83, 67, 73, 73, 0, 0, 0 };
    ExifTag[] arrayOfExifTag1 = new ExifTag[41];
    arrayOfExifTag1[0] = new ExifTag("NewSubfileType", 254, 4);
    arrayOfExifTag1[1] = new ExifTag("SubfileType", 255, 4);
    arrayOfExifTag1[2] = new ExifTag("ImageWidth", 256, 3, 4);
    arrayOfExifTag1[3] = new ExifTag("ImageLength", 257, 3, 4);
    arrayOfExifTag1[4] = new ExifTag("BitsPerSample", 258, 3);
    arrayOfExifTag1[5] = new ExifTag("Compression", 259, 3);
    arrayOfExifTag1[6] = new ExifTag("PhotometricInterpretation", 262, 3);
    arrayOfExifTag1[7] = new ExifTag("ImageDescription", 270, 2);
    arrayOfExifTag1[8] = new ExifTag("Make", 271, 2);
    arrayOfExifTag1[9] = new ExifTag("Model", 272, 2);
    arrayOfExifTag1[10] = new ExifTag("StripOffsets", 273, 3, 4);
    arrayOfExifTag1[11] = new ExifTag("Orientation", 274, 3);
    arrayOfExifTag1[12] = new ExifTag("SamplesPerPixel", 277, 3);
    arrayOfExifTag1[13] = new ExifTag("RowsPerStrip", 278, 3, 4);
    arrayOfExifTag1[14] = new ExifTag("StripByteCounts", 279, 3, 4);
    arrayOfExifTag1[15] = new ExifTag("XResolution", 282, 5);
    arrayOfExifTag1[16] = new ExifTag("YResolution", 283, 5);
    arrayOfExifTag1[17] = new ExifTag("PlanarConfiguration", 284, 3);
    arrayOfExifTag1[18] = new ExifTag("ResolutionUnit", 296, 3);
    arrayOfExifTag1[19] = new ExifTag("TransferFunction", 301, 3);
    arrayOfExifTag1[20] = new ExifTag("Software", 305, 2);
    arrayOfExifTag1[21] = new ExifTag("DateTime", 306, 2);
    arrayOfExifTag1[22] = new ExifTag("Artist", 315, 2);
    arrayOfExifTag1[23] = new ExifTag("WhitePoint", 318, 5);
    arrayOfExifTag1[24] = new ExifTag("PrimaryChromaticities", 319, 5);
    arrayOfExifTag1[25] = new ExifTag("SubIFDPointer", 330, 4);
    arrayOfExifTag1[26] = new ExifTag("JPEGInterchangeFormat", 513, 4);
    arrayOfExifTag1[27] = new ExifTag("JPEGInterchangeFormatLength", 514, 4);
    arrayOfExifTag1[28] = new ExifTag("YCbCrCoefficients", 529, 5);
    arrayOfExifTag1[29] = new ExifTag("YCbCrSubSampling", 530, 3);
    arrayOfExifTag1[30] = new ExifTag("YCbCrPositioning", 531, 3);
    arrayOfExifTag1[31] = new ExifTag("ReferenceBlackWhite", 532, 5);
    arrayOfExifTag1[32] = new ExifTag("Copyright", 33432, 2);
    arrayOfExifTag1[33] = new ExifTag("ExifIFDPointer", 34665, 4);
    arrayOfExifTag1[34] = new ExifTag("GPSInfoIFDPointer", 34853, 4);
    arrayOfExifTag1[35] = new ExifTag("SensorTopBorder", 4, 4);
    arrayOfExifTag1[36] = new ExifTag("SensorLeftBorder", 5, 4);
    arrayOfExifTag1[37] = new ExifTag("SensorBottomBorder", 6, 4);
    arrayOfExifTag1[38] = new ExifTag("SensorRightBorder", 7, 4);
    arrayOfExifTag1[39] = new ExifTag("ISO", 23, 3);
    arrayOfExifTag1[40] = new ExifTag("JpgFromRaw", 46, 7);
    IFD_TIFF_TAGS = arrayOfExifTag1;
    ExifTag[] arrayOfExifTag2 = new ExifTag[59];
    arrayOfExifTag2[0] = new ExifTag("ExposureTime", 33434, 5);
    arrayOfExifTag2[1] = new ExifTag("FNumber", 33437, 5);
    arrayOfExifTag2[2] = new ExifTag("ExposureProgram", 34850, 3);
    arrayOfExifTag2[3] = new ExifTag("SpectralSensitivity", 34852, 2);
    arrayOfExifTag2[4] = new ExifTag("PhotographicSensitivity", 34855, 3);
    arrayOfExifTag2[5] = new ExifTag("OECF", 34856, 7);
    arrayOfExifTag2[6] = new ExifTag("ExifVersion", 36864, 2);
    arrayOfExifTag2[7] = new ExifTag("DateTimeOriginal", 36867, 2);
    arrayOfExifTag2[8] = new ExifTag("DateTimeDigitized", 36868, 2);
    arrayOfExifTag2[9] = new ExifTag("ComponentsConfiguration", 37121, 7);
    arrayOfExifTag2[10] = new ExifTag("CompressedBitsPerPixel", 37122, 5);
    arrayOfExifTag2[11] = new ExifTag("ShutterSpeedValue", 37377, 10);
    arrayOfExifTag2[12] = new ExifTag("ApertureValue", 37378, 5);
    arrayOfExifTag2[13] = new ExifTag("BrightnessValue", 37379, 10);
    arrayOfExifTag2[14] = new ExifTag("ExposureBiasValue", 37380, 10);
    arrayOfExifTag2[15] = new ExifTag("MaxApertureValue", 37381, 5);
    arrayOfExifTag2[16] = new ExifTag("SubjectDistance", 37382, 5);
    arrayOfExifTag2[17] = new ExifTag("MeteringMode", 37383, 3);
    arrayOfExifTag2[18] = new ExifTag("LightSource", 37384, 3);
    arrayOfExifTag2[19] = new ExifTag("Flash", 37385, 3);
    arrayOfExifTag2[20] = new ExifTag("FocalLength", 37386, 5);
    arrayOfExifTag2[21] = new ExifTag("SubjectArea", 37396, 3);
    arrayOfExifTag2[22] = new ExifTag("MakerNote", 37500, 7);
    arrayOfExifTag2[23] = new ExifTag("UserComment", 37510, 7);
    arrayOfExifTag2[24] = new ExifTag("SubSecTime", 37520, 2);
    arrayOfExifTag2[25] = new ExifTag("SubSecTimeOriginal", 37521, 2);
    arrayOfExifTag2[26] = new ExifTag("SubSecTimeDigitized", 37522, 2);
    arrayOfExifTag2[27] = new ExifTag("FlashpixVersion", 40960, 7);
    arrayOfExifTag2[28] = new ExifTag("ColorSpace", 40961, 3);
    arrayOfExifTag2[29] = new ExifTag("PixelXDimension", 40962, 3, 4);
    arrayOfExifTag2[30] = new ExifTag("PixelYDimension", 40963, 3, 4);
    arrayOfExifTag2[31] = new ExifTag("RelatedSoundFile", 40964, 2);
    arrayOfExifTag2[32] = new ExifTag("InteroperabilityIFDPointer", 40965, 4);
    arrayOfExifTag2[33] = new ExifTag("FlashEnergy", 41483, 5);
    arrayOfExifTag2[34] = new ExifTag("SpatialFrequencyResponse", 41484, 7);
    arrayOfExifTag2[35] = new ExifTag("FocalPlaneXResolution", 41486, 5);
    arrayOfExifTag2[36] = new ExifTag("FocalPlaneYResolution", 41487, 5);
    arrayOfExifTag2[37] = new ExifTag("FocalPlaneResolutionUnit", 41488, 3);
    arrayOfExifTag2[38] = new ExifTag("SubjectLocation", 41492, 3);
    arrayOfExifTag2[39] = new ExifTag("ExposureIndex", 41493, 5);
    arrayOfExifTag2[40] = new ExifTag("SensingMethod", 41495, 3);
    arrayOfExifTag2[41] = new ExifTag("FileSource", 41728, 7);
    arrayOfExifTag2[42] = new ExifTag("SceneType", 41729, 7);
    arrayOfExifTag2[43] = new ExifTag("CFAPattern", 41730, 7);
    arrayOfExifTag2[44] = new ExifTag("CustomRendered", 41985, 3);
    arrayOfExifTag2[45] = new ExifTag("ExposureMode", 41986, 3);
    arrayOfExifTag2[46] = new ExifTag("WhiteBalance", 41987, 3);
    arrayOfExifTag2[47] = new ExifTag("DigitalZoomRatio", 41988, 5);
    arrayOfExifTag2[48] = new ExifTag("FocalLengthIn35mmFilm", 41989, 3);
    arrayOfExifTag2[49] = new ExifTag("SceneCaptureType", 41990, 3);
    arrayOfExifTag2[50] = new ExifTag("GainControl", 41991, 3);
    arrayOfExifTag2[51] = new ExifTag("Contrast", 41992, 3);
    arrayOfExifTag2[52] = new ExifTag("Saturation", 41993, 3);
    arrayOfExifTag2[53] = new ExifTag("Sharpness", 41994, 3);
    arrayOfExifTag2[54] = new ExifTag("DeviceSettingDescription", 41995, 7);
    arrayOfExifTag2[55] = new ExifTag("SubjectDistanceRange", 41996, 3);
    arrayOfExifTag2[56] = new ExifTag("ImageUniqueID", 42016, 2);
    arrayOfExifTag2[57] = new ExifTag("DNGVersion", 50706, 1);
    arrayOfExifTag2[58] = new ExifTag("DefaultCropSize", 50720, 3, 4);
    IFD_EXIF_TAGS = arrayOfExifTag2;
    ExifTag[] arrayOfExifTag3 = new ExifTag[31];
    arrayOfExifTag3[0] = new ExifTag("GPSVersionID", 0, 1);
    arrayOfExifTag3[1] = new ExifTag("GPSLatitudeRef", 1, 2);
    arrayOfExifTag3[2] = new ExifTag("GPSLatitude", 2, 5);
    arrayOfExifTag3[3] = new ExifTag("GPSLongitudeRef", 3, 2);
    arrayOfExifTag3[4] = new ExifTag("GPSLongitude", 4, 5);
    arrayOfExifTag3[5] = new ExifTag("GPSAltitudeRef", 5, 1);
    arrayOfExifTag3[6] = new ExifTag("GPSAltitude", 6, 5);
    arrayOfExifTag3[7] = new ExifTag("GPSTimeStamp", 7, 5);
    arrayOfExifTag3[8] = new ExifTag("GPSSatellites", 8, 2);
    arrayOfExifTag3[9] = new ExifTag("GPSStatus", 9, 2);
    arrayOfExifTag3[10] = new ExifTag("GPSMeasureMode", 10, 2);
    arrayOfExifTag3[11] = new ExifTag("GPSDOP", 11, 5);
    arrayOfExifTag3[12] = new ExifTag("GPSSpeedRef", 12, 2);
    arrayOfExifTag3[13] = new ExifTag("GPSSpeed", 13, 5);
    arrayOfExifTag3[14] = new ExifTag("GPSTrackRef", 14, 2);
    arrayOfExifTag3[15] = new ExifTag("GPSTrack", 15, 5);
    arrayOfExifTag3[16] = new ExifTag("GPSImgDirectionRef", 16, 2);
    arrayOfExifTag3[17] = new ExifTag("GPSImgDirection", 17, 5);
    arrayOfExifTag3[18] = new ExifTag("GPSMapDatum", 18, 2);
    arrayOfExifTag3[19] = new ExifTag("GPSDestLatitudeRef", 19, 2);
    arrayOfExifTag3[20] = new ExifTag("GPSDestLatitude", 20, 5);
    arrayOfExifTag3[21] = new ExifTag("GPSDestLongitudeRef", 21, 2);
    arrayOfExifTag3[22] = new ExifTag("GPSDestLongitude", 22, 5);
    arrayOfExifTag3[23] = new ExifTag("GPSDestBearingRef", 23, 2);
    arrayOfExifTag3[24] = new ExifTag("GPSDestBearing", 24, 5);
    arrayOfExifTag3[25] = new ExifTag("GPSDestDistanceRef", 25, 2);
    arrayOfExifTag3[26] = new ExifTag("GPSDestDistance", 26, 5);
    arrayOfExifTag3[27] = new ExifTag("GPSProcessingMethod", 27, 7);
    arrayOfExifTag3[28] = new ExifTag("GPSAreaInformation", 28, 7);
    arrayOfExifTag3[29] = new ExifTag("GPSDateStamp", 29, 2);
    arrayOfExifTag3[30] = new ExifTag("GPSDifferential", 30, 3);
    IFD_GPS_TAGS = arrayOfExifTag3;
    ExifTag[] arrayOfExifTag4 = new ExifTag[1];
    arrayOfExifTag4[0] = new ExifTag("InteroperabilityIndex", 1, 2);
    IFD_INTEROPERABILITY_TAGS = arrayOfExifTag4;
    ExifTag[] arrayOfExifTag5 = new ExifTag[37];
    arrayOfExifTag5[0] = new ExifTag("NewSubfileType", 254, 4);
    arrayOfExifTag5[1] = new ExifTag("SubfileType", 255, 4);
    arrayOfExifTag5[2] = new ExifTag("ThumbnailImageWidth", 256, 3, 4);
    arrayOfExifTag5[3] = new ExifTag("ThumbnailImageLength", 257, 3, 4);
    arrayOfExifTag5[4] = new ExifTag("BitsPerSample", 258, 3);
    arrayOfExifTag5[5] = new ExifTag("Compression", 259, 3);
    arrayOfExifTag5[6] = new ExifTag("PhotometricInterpretation", 262, 3);
    arrayOfExifTag5[7] = new ExifTag("ImageDescription", 270, 2);
    arrayOfExifTag5[8] = new ExifTag("Make", 271, 2);
    arrayOfExifTag5[9] = new ExifTag("Model", 272, 2);
    arrayOfExifTag5[10] = new ExifTag("StripOffsets", 273, 3, 4);
    arrayOfExifTag5[11] = new ExifTag("Orientation", 274, 3);
    arrayOfExifTag5[12] = new ExifTag("SamplesPerPixel", 277, 3);
    arrayOfExifTag5[13] = new ExifTag("RowsPerStrip", 278, 3, 4);
    arrayOfExifTag5[14] = new ExifTag("StripByteCounts", 279, 3, 4);
    arrayOfExifTag5[15] = new ExifTag("XResolution", 282, 5);
    arrayOfExifTag5[16] = new ExifTag("YResolution", 283, 5);
    arrayOfExifTag5[17] = new ExifTag("PlanarConfiguration", 284, 3);
    arrayOfExifTag5[18] = new ExifTag("ResolutionUnit", 296, 3);
    arrayOfExifTag5[19] = new ExifTag("TransferFunction", 301, 3);
    arrayOfExifTag5[20] = new ExifTag("Software", 305, 2);
    arrayOfExifTag5[21] = new ExifTag("DateTime", 306, 2);
    arrayOfExifTag5[22] = new ExifTag("Artist", 315, 2);
    arrayOfExifTag5[23] = new ExifTag("WhitePoint", 318, 5);
    arrayOfExifTag5[24] = new ExifTag("PrimaryChromaticities", 319, 5);
    arrayOfExifTag5[25] = new ExifTag("SubIFDPointer", 330, 4);
    arrayOfExifTag5[26] = new ExifTag("JPEGInterchangeFormat", 513, 4);
    arrayOfExifTag5[27] = new ExifTag("JPEGInterchangeFormatLength", 514, 4);
    arrayOfExifTag5[28] = new ExifTag("YCbCrCoefficients", 529, 5);
    arrayOfExifTag5[29] = new ExifTag("YCbCrSubSampling", 530, 3);
    arrayOfExifTag5[30] = new ExifTag("YCbCrPositioning", 531, 3);
    arrayOfExifTag5[31] = new ExifTag("ReferenceBlackWhite", 532, 5);
    arrayOfExifTag5[32] = new ExifTag("Copyright", 33432, 2);
    arrayOfExifTag5[33] = new ExifTag("ExifIFDPointer", 34665, 4);
    arrayOfExifTag5[34] = new ExifTag("GPSInfoIFDPointer", 34853, 4);
    arrayOfExifTag5[35] = new ExifTag("DNGVersion", 50706, 1);
    arrayOfExifTag5[36] = new ExifTag("DefaultCropSize", 50720, 3, 4);
    IFD_THUMBNAIL_TAGS = arrayOfExifTag5;
    TAG_RAF_IMAGE_SIZE = new ExifTag("StripOffsets", 273, 3);
    ExifTag[] arrayOfExifTag6 = new ExifTag[3];
    arrayOfExifTag6[0] = new ExifTag("ThumbnailImage", 256, 7);
    arrayOfExifTag6[1] = new ExifTag("CameraSettingsIFDPointer", 8224, 4);
    arrayOfExifTag6[2] = new ExifTag("ImageProcessingIFDPointer", 8256, 4);
    ORF_MAKER_NOTE_TAGS = arrayOfExifTag6;
    ExifTag[] arrayOfExifTag7 = new ExifTag[2];
    arrayOfExifTag7[0] = new ExifTag("PreviewImageStart", 257, 4);
    arrayOfExifTag7[1] = new ExifTag("PreviewImageLength", 258, 4);
    ORF_CAMERA_SETTINGS_TAGS = arrayOfExifTag7;
    ExifTag[] arrayOfExifTag8 = new ExifTag[1];
    arrayOfExifTag8[0] = new ExifTag("AspectFrame", 4371, 3);
    ORF_IMAGE_PROCESSING_TAGS = arrayOfExifTag8;
    ExifTag[] arrayOfExifTag9 = new ExifTag[1];
    arrayOfExifTag9[0] = new ExifTag("ColorSpace", 55, 3);
    PEF_TAGS = arrayOfExifTag9;
    ExifTag[][] arrayOfExifTag = new ExifTag[10][];
    arrayOfExifTag[0] = arrayOfExifTag1;
    arrayOfExifTag[1] = arrayOfExifTag2;
    arrayOfExifTag[2] = arrayOfExifTag3;
    arrayOfExifTag[3] = arrayOfExifTag4;
    arrayOfExifTag[4] = arrayOfExifTag5;
    arrayOfExifTag[5] = arrayOfExifTag1;
    arrayOfExifTag[6] = arrayOfExifTag6;
    arrayOfExifTag[7] = arrayOfExifTag7;
    arrayOfExifTag[8] = arrayOfExifTag8;
    arrayOfExifTag[9] = arrayOfExifTag9;
    EXIF_TAGS = arrayOfExifTag;
    EXIF_POINTER_TAGS = new ExifTag[] { new ExifTag("SubIFDPointer", 330, 4), new ExifTag("ExifIFDPointer", 34665, 4), new ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifTag("InteroperabilityIFDPointer", 40965, 4), new ExifTag("CameraSettingsIFDPointer", 8224, 1), new ExifTag("ImageProcessingIFDPointer", 8256, 1) };
    JPEG_INTERCHANGE_FORMAT_TAG = new ExifTag("JPEGInterchangeFormat", 513, 4);
    JPEG_INTERCHANGE_FORMAT_LENGTH_TAG = new ExifTag("JPEGInterchangeFormatLength", 514, 4);
    sExifTagMapsForReading = (HashMap<Integer, ExifTag>[])new HashMap[arrayOfExifTag.length];
    sExifTagMapsForWriting = (HashMap<String, ExifTag>[])new HashMap[arrayOfExifTag.length];
    sTagSetForCompatibility = new HashSet<String>(Arrays.asList(new String[] { "FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp" }));
    sExifPointerTagMap = new HashMap<Integer, Integer>();
    Charset charset = Charset.forName("US-ASCII");
    ASCII = charset;
    IDENTIFIER_EXIF_APP1 = "Exif\000\000".getBytes(charset);
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
    sFormatter = simpleDateFormat;
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    int i = 0;
    while (true) {
      ExifTag[][] arrayOfExifTag10 = EXIF_TAGS;
      if (i < arrayOfExifTag10.length) {
        sExifTagMapsForReading[i] = new HashMap<Integer, ExifTag>();
        sExifTagMapsForWriting[i] = new HashMap<String, ExifTag>();
        for (ExifTag exifTag : arrayOfExifTag10[i]) {
          sExifTagMapsForReading[i].put(Integer.valueOf(exifTag.number), exifTag);
          sExifTagMapsForWriting[i].put(exifTag.name, exifTag);
        } 
        i++;
        continue;
      } 
      HashMap<Integer, Integer> hashMap = sExifPointerTagMap;
      arrayOfExifTag2 = EXIF_POINTER_TAGS;
      hashMap.put(Integer.valueOf((arrayOfExifTag2[0]).number), integer6);
      hashMap.put(Integer.valueOf((arrayOfExifTag2[1]).number), integer1);
      hashMap.put(Integer.valueOf((arrayOfExifTag2[2]).number), integer3);
      hashMap.put(Integer.valueOf((arrayOfExifTag2[3]).number), integer2);
      hashMap.put(Integer.valueOf((arrayOfExifTag2[4]).number), integer5);
      hashMap.put(Integer.valueOf((arrayOfExifTag2[5]).number), integer4);
      sNonZeroTimePattern = Pattern.compile(".*[1-9].*");
      sGpsTimestampPattern = Pattern.compile("^([0-9][0-9]):([0-9][0-9]):([0-9][0-9])$");
      return;
    } 
  }
  
  public ExifInterface(InputStream paramInputStream) throws IOException {
    ExifTag[][] arrayOfExifTag = EXIF_TAGS;
    this.mAttributes = (HashMap<String, ExifAttribute>[])new HashMap[arrayOfExifTag.length];
    this.mAttributesOffsets = new HashSet<Integer>(arrayOfExifTag.length);
    this.mExifByteOrder = ByteOrder.BIG_ENDIAN;
    if (paramInputStream != null) {
      this.mFilename = null;
      if (paramInputStream instanceof AssetManager.AssetInputStream) {
        this.mAssetInputStream = (AssetManager.AssetInputStream)paramInputStream;
      } else {
        this.mAssetInputStream = null;
      } 
      loadAttributes(paramInputStream);
      return;
    } 
    throw new IllegalArgumentException("inputStream cannot be null");
  }
  
  public ExifInterface(String paramString) throws IOException {
    ExifTag[][] arrayOfExifTag = EXIF_TAGS;
    this.mAttributes = (HashMap<String, ExifAttribute>[])new HashMap[arrayOfExifTag.length];
    this.mAttributesOffsets = new HashSet<Integer>(arrayOfExifTag.length);
    this.mExifByteOrder = ByteOrder.BIG_ENDIAN;
    if (paramString != null) {
      String str = null;
      this.mAssetInputStream = null;
      this.mFilename = paramString;
      try {
        FileInputStream fileInputStream = new FileInputStream(paramString);
      } finally {
        arrayOfExifTag = null;
      } 
      closeQuietly((Closeable)paramString);
      throw arrayOfExifTag;
    } 
    throw new IllegalArgumentException("filename cannot be null");
  }
  
  private void addDefaultValuesForCompatibility() {
    String str = getAttribute("DateTimeOriginal");
    if (str != null && getAttribute("DateTime") == null)
      this.mAttributes[0].put("DateTime", ExifAttribute.createString(str)); 
    if (getAttribute("ImageWidth") == null)
      this.mAttributes[0].put("ImageWidth", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("ImageLength") == null)
      this.mAttributes[0].put("ImageLength", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("Orientation") == null)
      this.mAttributes[0].put("Orientation", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("LightSource") == null)
      this.mAttributes[1].put("LightSource", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
  }
  
  private static void closeQuietly(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (RuntimeException runtimeException) {
        throw runtimeException;
      } catch (Exception exception) {
        return;
      }  
  }
  
  private String convertDecimalDegree(double paramDouble) {
    long l1 = (long)paramDouble;
    double d = l1;
    Double.isNaN(d);
    paramDouble -= d;
    long l2 = (long)(paramDouble * 60.0D);
    d = l2;
    Double.isNaN(d);
    long l3 = Math.round((paramDouble - d / 60.0D) * 3600.0D * 1.0E7D);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(l1);
    stringBuilder.append("/1,");
    stringBuilder.append(l2);
    stringBuilder.append("/1,");
    stringBuilder.append(l3);
    stringBuilder.append("/10000000");
    return stringBuilder.toString();
  }
  
  private static double convertRationalLatLonToDouble(String paramString1, String paramString2) {
    try {
      String[] arrayOfString1 = paramString1.split(",", -1);
      String[] arrayOfString2 = arrayOfString1[0].split("/", -1);
      double d1 = Double.parseDouble(arrayOfString2[0].trim()) / Double.parseDouble(arrayOfString2[1].trim());
      arrayOfString2 = arrayOfString1[1].split("/", -1);
      double d2 = Double.parseDouble(arrayOfString2[0].trim()) / Double.parseDouble(arrayOfString2[1].trim());
      arrayOfString1 = arrayOfString1[2].split("/", -1);
      double d3 = Double.parseDouble(arrayOfString1[0].trim()) / Double.parseDouble(arrayOfString1[1].trim());
      d1 = d1 + d2 / 60.0D + d3 / 3600.0D;
      if (paramString2.equals("S") || paramString2.equals("W"))
        return -d1; 
      if (!paramString2.equals("N")) {
        if (paramString2.equals("E"))
          return d1; 
        throw new IllegalArgumentException();
      } 
      return d1;
    } catch (NumberFormatException|ArrayIndexOutOfBoundsException numberFormatException) {
      throw new IllegalArgumentException();
    } 
  }
  
  private static long[] convertToLongArray(Object paramObject) {
    if (paramObject instanceof int[]) {
      paramObject = paramObject;
      long[] arrayOfLong = new long[paramObject.length];
      for (int i = 0; i < paramObject.length; i++)
        arrayOfLong[i] = paramObject[i]; 
      return arrayOfLong;
    } 
    return (paramObject instanceof long[]) ? (long[])paramObject : null;
  }
  
  private static int copy(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    byte[] arrayOfByte = new byte[8192];
    int i = 0;
    while (true) {
      int j = paramInputStream.read(arrayOfByte);
      if (j != -1) {
        i += j;
        paramOutputStream.write(arrayOfByte, 0, j);
        continue;
      } 
      return i;
    } 
  }
  
  private ExifAttribute getExifAttribute(String paramString) {
    String str = paramString;
    if ("ISOSpeedRatings".equals(paramString))
      str = "PhotographicSensitivity"; 
    for (int i = 0; i < EXIF_TAGS.length; i++) {
      ExifAttribute exifAttribute = this.mAttributes[i].get(str);
      if (exifAttribute != null)
        return exifAttribute; 
    } 
    return null;
  }
  
  private void getJpegAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt1, int paramInt2) throws IOException {
    paramByteOrderedDataInputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    paramByteOrderedDataInputStream.seek(paramInt1);
    int i = paramByteOrderedDataInputStream.readByte();
    if (i == -1) {
      if (paramByteOrderedDataInputStream.readByte() == -40) {
        paramInt1 = paramInt1 + 1 + 1;
        while (true) {
          i = paramByteOrderedDataInputStream.readByte();
          if (i == -1) {
            byte b = paramByteOrderedDataInputStream.readByte();
            if (b != -39) {
              if (b == -38)
                continue; 
              i = paramByteOrderedDataInputStream.readUnsignedShort() - 2;
              int j = paramInt1 + 1 + 1 + 2;
              if (i >= 0) {
                if (b != -31) {
                  if (b != -2) {
                    switch (b) {
                      default:
                        switch (b) {
                          default:
                            switch (b) {
                              default:
                                switch (b) {
                                  default:
                                    paramInt1 = i;
                                    i = j;
                                    break;
                                  case -51:
                                  case -50:
                                  case -49:
                                    break;
                                } 
                                break;
                              case -55:
                              case -54:
                              case -53:
                                break;
                            } 
                            break;
                          case -59:
                          case -58:
                          case -57:
                            break;
                        } 
                      case -64:
                      case -63:
                      case -62:
                      case -61:
                        if (paramByteOrderedDataInputStream.skipBytes(1) == 1) {
                          this.mAttributes[paramInt2].put("ImageLength", ExifAttribute.createULong(paramByteOrderedDataInputStream.readUnsignedShort(), this.mExifByteOrder));
                          this.mAttributes[paramInt2].put("ImageWidth", ExifAttribute.createULong(paramByteOrderedDataInputStream.readUnsignedShort(), this.mExifByteOrder));
                          paramInt1 = i - 5;
                          i = j;
                          break;
                        } 
                        throw new IOException("Invalid SOFx");
                    } 
                  } else {
                    byte[] arrayOfByte = new byte[i];
                    if (paramByteOrderedDataInputStream.read(arrayOfByte) == i) {
                      i = j;
                      if (getAttribute("UserComment") == null) {
                        this.mAttributes[1].put("UserComment", ExifAttribute.createString(new String(arrayOfByte, ASCII)));
                        i = j;
                      } 
                    } else {
                      throw new IOException("Invalid exif");
                    } 
                    paramInt1 = 0;
                  } 
                } else if (i < 6) {
                  paramInt1 = i;
                  i = j;
                } else {
                  byte[] arrayOfByte = new byte[6];
                  if (paramByteOrderedDataInputStream.read(arrayOfByte) == 6) {
                    j += 6;
                    paramInt1 = i - 6;
                    if (!Arrays.equals(arrayOfByte, IDENTIFIER_EXIF_APP1)) {
                      i = j;
                    } else {
                      if (paramInt1 > 0) {
                        this.mExifOffset = j;
                        arrayOfByte = new byte[paramInt1];
                        if (paramByteOrderedDataInputStream.read(arrayOfByte) == paramInt1) {
                          i = j + paramInt1;
                          readExifSegment(arrayOfByte, paramInt2);
                        } else {
                          throw new IOException("Invalid exif");
                        } 
                      } else {
                        throw new IOException("Invalid exif");
                      } 
                      paramInt1 = 0;
                    } 
                  } else {
                    throw new IOException("Invalid exif");
                  } 
                } 
                if (paramInt1 >= 0) {
                  if (paramByteOrderedDataInputStream.skipBytes(paramInt1) == paramInt1) {
                    paramInt1 = i + paramInt1;
                    continue;
                  } 
                  throw new IOException("Invalid JPEG segment");
                } 
                throw new IOException("Invalid length");
              } 
              throw new IOException("Invalid length");
            } 
            paramByteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Invalid marker:");
          stringBuilder2.append(Integer.toHexString(i & 0xFF));
          throw new IOException(stringBuilder2.toString());
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid marker: ");
      stringBuilder1.append(Integer.toHexString(i & 0xFF));
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid marker: ");
    stringBuilder.append(Integer.toHexString(i & 0xFF));
    IOException iOException = new IOException(stringBuilder.toString());
    throw iOException;
  }
  
  private int getMimeType(BufferedInputStream paramBufferedInputStream) throws IOException {
    paramBufferedInputStream.mark(5000);
    byte[] arrayOfByte = new byte[5000];
    paramBufferedInputStream.read(arrayOfByte);
    paramBufferedInputStream.reset();
    return isJpegFormat(arrayOfByte) ? 4 : (isRafFormat(arrayOfByte) ? 9 : (isOrfFormat(arrayOfByte) ? 7 : (isRw2Format(arrayOfByte) ? 10 : 0)));
  }
  
  private void getOrfAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    getRawAttributes(paramByteOrderedDataInputStream);
    ExifAttribute exifAttribute = this.mAttributes[1].get("MakerNote");
    if (exifAttribute != null) {
      ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(exifAttribute.bytes);
      byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
      byte[] arrayOfByte1 = ORF_MAKER_NOTE_HEADER_1;
      byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
      byteOrderedDataInputStream.readFully(arrayOfByte2);
      byteOrderedDataInputStream.seek(0L);
      byte[] arrayOfByte3 = ORF_MAKER_NOTE_HEADER_2;
      byte[] arrayOfByte4 = new byte[arrayOfByte3.length];
      byteOrderedDataInputStream.readFully(arrayOfByte4);
      if (Arrays.equals(arrayOfByte2, arrayOfByte1)) {
        byteOrderedDataInputStream.seek(8L);
      } else if (Arrays.equals(arrayOfByte4, arrayOfByte3)) {
        byteOrderedDataInputStream.seek(12L);
      } 
      readImageFileDirectory(byteOrderedDataInputStream, 6);
      ExifAttribute exifAttribute1 = this.mAttributes[7].get("PreviewImageStart");
      ExifAttribute exifAttribute2 = this.mAttributes[7].get("PreviewImageLength");
      if (exifAttribute1 != null && exifAttribute2 != null) {
        this.mAttributes[5].put("JPEGInterchangeFormat", exifAttribute1);
        this.mAttributes[5].put("JPEGInterchangeFormatLength", exifAttribute2);
      } 
      exifAttribute1 = this.mAttributes[8].get("AspectFrame");
      if (exifAttribute1 != null) {
        int[] arrayOfInt = (int[])exifAttribute1.getValue(this.mExifByteOrder);
        if (arrayOfInt == null || arrayOfInt.length != 4) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid aspect frame values. frame=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        if (arrayOfInt[2] > arrayOfInt[0] && arrayOfInt[3] > arrayOfInt[1]) {
          int m = arrayOfInt[2] - arrayOfInt[0] + 1;
          int k = arrayOfInt[3] - arrayOfInt[1] + 1;
          int j = m;
          int i = k;
          if (m < k) {
            j = m + k;
            i = j - k;
            j -= i;
          } 
          ExifAttribute exifAttribute3 = ExifAttribute.createUShort(j, this.mExifByteOrder);
          exifAttribute2 = ExifAttribute.createUShort(i, this.mExifByteOrder);
          this.mAttributes[0].put("ImageWidth", exifAttribute3);
          this.mAttributes[0].put("ImageLength", exifAttribute2);
          return;
        } 
      } 
    } 
  }
  
  private void getRafAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    paramByteOrderedDataInputStream.skipBytes(84);
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    paramByteOrderedDataInputStream.read(arrayOfByte1);
    paramByteOrderedDataInputStream.skipBytes(4);
    paramByteOrderedDataInputStream.read(arrayOfByte2);
    int i = ByteBuffer.wrap(arrayOfByte1).getInt();
    int j = ByteBuffer.wrap(arrayOfByte2).getInt();
    getJpegAttributes(paramByteOrderedDataInputStream, i, 5);
    paramByteOrderedDataInputStream.seek(j);
    paramByteOrderedDataInputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    j = paramByteOrderedDataInputStream.readInt();
    for (i = 0; i < j; i++) {
      ExifAttribute exifAttribute;
      int k = paramByteOrderedDataInputStream.readUnsignedShort();
      int m = paramByteOrderedDataInputStream.readUnsignedShort();
      if (k == TAG_RAF_IMAGE_SIZE.number) {
        i = paramByteOrderedDataInputStream.readShort();
        j = paramByteOrderedDataInputStream.readShort();
        exifAttribute = ExifAttribute.createUShort(i, this.mExifByteOrder);
        ExifAttribute exifAttribute1 = ExifAttribute.createUShort(j, this.mExifByteOrder);
        this.mAttributes[0].put("ImageLength", exifAttribute);
        this.mAttributes[0].put("ImageWidth", exifAttribute1);
        return;
      } 
      exifAttribute.skipBytes(m);
    } 
  }
  
  private void getRawAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    parseTiffHeaders(paramByteOrderedDataInputStream, paramByteOrderedDataInputStream.available());
    readImageFileDirectory(paramByteOrderedDataInputStream, 0);
    updateImageSizeValues(paramByteOrderedDataInputStream, 0);
    updateImageSizeValues(paramByteOrderedDataInputStream, 5);
    updateImageSizeValues(paramByteOrderedDataInputStream, 4);
    validateImages(paramByteOrderedDataInputStream);
    if (this.mMimeType == 8) {
      ExifAttribute exifAttribute = this.mAttributes[1].get("MakerNote");
      if (exifAttribute != null) {
        ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(exifAttribute.bytes);
        byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
        byteOrderedDataInputStream.seek(6L);
        readImageFileDirectory(byteOrderedDataInputStream, 9);
        ExifAttribute exifAttribute1 = this.mAttributes[9].get("ColorSpace");
        if (exifAttribute1 != null)
          this.mAttributes[1].put("ColorSpace", exifAttribute1); 
      } 
    } 
  }
  
  private void getRw2Attributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    getRawAttributes(paramByteOrderedDataInputStream);
    if ((ExifAttribute)this.mAttributes[0].get("JpgFromRaw") != null)
      getJpegAttributes(paramByteOrderedDataInputStream, this.mRw2JpgFromRawOffset, 5); 
    ExifAttribute exifAttribute1 = this.mAttributes[0].get("ISO");
    ExifAttribute exifAttribute2 = this.mAttributes[1].get("PhotographicSensitivity");
    if (exifAttribute1 != null && exifAttribute2 == null)
      this.mAttributes[1].put("PhotographicSensitivity", exifAttribute1); 
  }
  
  private static Pair<Integer, Integer> guessDataFormat(String paramString) {
    Pair<Integer, Integer> pair;
    long l1;
    long l2;
    boolean bool = paramString.contains(",");
    int i = 1;
    Integer integer1 = Integer.valueOf(2);
    Integer integer2 = Integer.valueOf(-1);
    if (bool) {
      String[] arrayOfString = paramString.split(",", -1);
      Pair<Integer, Integer> pair1 = guessDataFormat(arrayOfString[0]);
      pair = pair1;
      if (((Integer)pair1.first).intValue() == 2)
        return pair1; 
      while (i < arrayOfString.length) {
        byte b1;
        byte b2;
        pair1 = guessDataFormat(arrayOfString[i]);
        if (((Integer)pair1.first).equals(pair.first) || ((Integer)pair1.second).equals(pair.first)) {
          b1 = ((Integer)pair.first).intValue();
        } else {
          b1 = -1;
        } 
        if (((Integer)pair.second).intValue() != -1 && (((Integer)pair1.first).equals(pair.second) || ((Integer)pair1.second).equals(pair.second))) {
          b2 = ((Integer)pair.second).intValue();
        } else {
          b2 = -1;
        } 
        if (b1 == -1 && b2 == -1)
          return new Pair(integer1, integer2); 
        if (b1 == -1) {
          pair = new Pair(Integer.valueOf(b2), integer2);
        } else if (b2 == -1) {
          pair = new Pair(Integer.valueOf(b1), integer2);
        } 
        i++;
      } 
      return pair;
    } 
    if (pair.contains("/")) {
      String[] arrayOfString = pair.split("/", -1);
      if (arrayOfString.length == 2) {
        try {
          l1 = (long)Double.parseDouble(arrayOfString[0]);
          l2 = (long)Double.parseDouble(arrayOfString[1]);
          if (l1 < 0L || l2 < 0L)
            return new Pair(Integer.valueOf(10), integer2); 
        } catch (NumberFormatException numberFormatException) {
          return new Pair(integer1, integer2);
        } 
      } else {
        return new Pair(integer1, integer2);
      } 
    } else {
      try {
        Long long_ = Long.valueOf(Long.parseLong((String)numberFormatException));
        return (long_.longValue() >= 0L && long_.longValue() <= 65535L) ? new Pair(Integer.valueOf(3), Integer.valueOf(4)) : ((long_.longValue() < 0L) ? new Pair(Integer.valueOf(9), integer2) : new Pair(Integer.valueOf(4), integer2));
      } catch (NumberFormatException numberFormatException1) {
        try {
          Double.parseDouble((String)numberFormatException);
          return new Pair(Integer.valueOf(12), integer2);
        } catch (NumberFormatException numberFormatException2) {
          return new Pair(integer1, integer2);
        } 
      } 
    } 
    return (l1 > 2147483647L || l2 > 2147483647L) ? new Pair(Integer.valueOf(5), integer2) : new Pair(Integer.valueOf(10), Integer.valueOf(5));
  }
  
  private void handleThumbnailFromJfif(ByteOrderedDataInputStream paramByteOrderedDataInputStream, HashMap paramHashMap) throws IOException {
    // Byte code:
    //   0: aload_2
    //   1: ldc_w 'JPEGInterchangeFormat'
    //   4: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   7: checkcast androidx/exifinterface/media/ExifInterface$ExifAttribute
    //   10: astore #7
    //   12: aload_2
    //   13: ldc_w 'JPEGInterchangeFormatLength'
    //   16: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast androidx/exifinterface/media/ExifInterface$ExifAttribute
    //   22: astore_2
    //   23: aload #7
    //   25: ifnull -> 180
    //   28: aload_2
    //   29: ifnull -> 180
    //   32: aload #7
    //   34: aload_0
    //   35: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   38: invokevirtual getIntValue : (Ljava/nio/ByteOrder;)I
    //   41: istore #4
    //   43: aload_2
    //   44: aload_0
    //   45: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   48: invokevirtual getIntValue : (Ljava/nio/ByteOrder;)I
    //   51: aload_1
    //   52: invokevirtual available : ()I
    //   55: iload #4
    //   57: isub
    //   58: invokestatic min : (II)I
    //   61: istore #5
    //   63: aload_0
    //   64: getfield mMimeType : I
    //   67: istore #6
    //   69: iload #6
    //   71: iconst_4
    //   72: if_icmpeq -> 110
    //   75: iload #6
    //   77: bipush #9
    //   79: if_icmpeq -> 110
    //   82: iload #6
    //   84: bipush #10
    //   86: if_icmpne -> 92
    //   89: goto -> 110
    //   92: iload #4
    //   94: istore_3
    //   95: iload #6
    //   97: bipush #7
    //   99: if_icmpne -> 120
    //   102: aload_0
    //   103: getfield mOrfMakerNoteOffset : I
    //   106: istore_3
    //   107: goto -> 115
    //   110: aload_0
    //   111: getfield mExifOffset : I
    //   114: istore_3
    //   115: iload #4
    //   117: iload_3
    //   118: iadd
    //   119: istore_3
    //   120: iload_3
    //   121: ifle -> 180
    //   124: iload #5
    //   126: ifle -> 180
    //   129: aload_0
    //   130: iconst_1
    //   131: putfield mHasThumbnail : Z
    //   134: aload_0
    //   135: iload_3
    //   136: putfield mThumbnailOffset : I
    //   139: aload_0
    //   140: iload #5
    //   142: putfield mThumbnailLength : I
    //   145: aload_0
    //   146: getfield mFilename : Ljava/lang/String;
    //   149: ifnonnull -> 180
    //   152: aload_0
    //   153: getfield mAssetInputStream : Landroid/content/res/AssetManager$AssetInputStream;
    //   156: ifnonnull -> 180
    //   159: iload #5
    //   161: newarray byte
    //   163: astore_2
    //   164: aload_1
    //   165: iload_3
    //   166: i2l
    //   167: invokevirtual seek : (J)V
    //   170: aload_1
    //   171: aload_2
    //   172: invokevirtual readFully : ([B)V
    //   175: aload_0
    //   176: aload_2
    //   177: putfield mThumbnailBytes : [B
    //   180: return
  }
  
  private void handleThumbnailFromStrips(ByteOrderedDataInputStream paramByteOrderedDataInputStream, HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("StripOffsets");
    ExifAttribute exifAttribute2 = (ExifAttribute)paramHashMap.get("StripByteCounts");
    if (exifAttribute1 != null && exifAttribute2 != null) {
      long[] arrayOfLong1 = convertToLongArray(exifAttribute1.getValue(this.mExifByteOrder));
      long[] arrayOfLong2 = convertToLongArray(exifAttribute2.getValue(this.mExifByteOrder));
      if (arrayOfLong1 == null) {
        Log.w("ExifInterface", "stripOffsets should not be null.");
        return;
      } 
      if (arrayOfLong2 == null) {
        Log.w("ExifInterface", "stripByteCounts should not be null.");
        return;
      } 
      long l = 0L;
      int j = arrayOfLong2.length;
      int i;
      for (i = 0; i < j; i++)
        l += arrayOfLong2[i]; 
      int m = (int)l;
      byte[] arrayOfByte = new byte[m];
      j = 0;
      int k = 0;
      i = 0;
      while (j < arrayOfLong1.length) {
        int i1 = (int)arrayOfLong1[j];
        int n = (int)arrayOfLong2[j];
        i1 -= k;
        if (i1 < 0)
          Log.d("ExifInterface", "Invalid strip offset value"); 
        paramByteOrderedDataInputStream.seek(i1);
        byte[] arrayOfByte1 = new byte[n];
        paramByteOrderedDataInputStream.read(arrayOfByte1);
        k = k + i1 + n;
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, i, n);
        i += n;
        j++;
      } 
      this.mHasThumbnail = true;
      this.mThumbnailBytes = arrayOfByte;
      this.mThumbnailLength = m;
    } 
  }
  
  private static boolean isJpegFormat(byte[] paramArrayOfbyte) throws IOException {
    int i = 0;
    while (true) {
      byte[] arrayOfByte = JPEG_SIGNATURE;
      if (i < arrayOfByte.length) {
        if (paramArrayOfbyte[i] != arrayOfByte[i])
          return false; 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  private boolean isOrfFormat(byte[] paramArrayOfbyte) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    ByteOrder byteOrder = readByteOrder(byteOrderedDataInputStream);
    this.mExifByteOrder = byteOrder;
    byteOrderedDataInputStream.setByteOrder(byteOrder);
    short s = byteOrderedDataInputStream.readShort();
    byteOrderedDataInputStream.close();
    return (s == 20306 || s == 21330);
  }
  
  private boolean isRafFormat(byte[] paramArrayOfbyte) throws IOException {
    byte[] arrayOfByte = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
    for (int i = 0; i < arrayOfByte.length; i++) {
      if (paramArrayOfbyte[i] != arrayOfByte[i])
        return false; 
    } 
    return true;
  }
  
  private boolean isRw2Format(byte[] paramArrayOfbyte) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    ByteOrder byteOrder = readByteOrder(byteOrderedDataInputStream);
    this.mExifByteOrder = byteOrder;
    byteOrderedDataInputStream.setByteOrder(byteOrder);
    short s = byteOrderedDataInputStream.readShort();
    byteOrderedDataInputStream.close();
    return (s == 85);
  }
  
  private boolean isSupportedDataType(HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute = (ExifAttribute)paramHashMap.get("BitsPerSample");
    if (exifAttribute != null) {
      int[] arrayOfInt1 = (int[])exifAttribute.getValue(this.mExifByteOrder);
      int[] arrayOfInt2 = BITS_PER_SAMPLE_RGB;
      if (Arrays.equals(arrayOfInt2, arrayOfInt1))
        return true; 
      if (this.mMimeType == 3) {
        ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("PhotometricInterpretation");
        if (exifAttribute1 != null) {
          int i = exifAttribute1.getIntValue(this.mExifByteOrder);
          if ((i == 1 && Arrays.equals(arrayOfInt1, BITS_PER_SAMPLE_GREYSCALE_2)) || (i == 6 && Arrays.equals(arrayOfInt1, arrayOfInt2)))
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private boolean isThumbnail(HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute2 = (ExifAttribute)paramHashMap.get("ImageLength");
    ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("ImageWidth");
    if (exifAttribute2 != null && exifAttribute1 != null) {
      int i = exifAttribute2.getIntValue(this.mExifByteOrder);
      int j = exifAttribute1.getIntValue(this.mExifByteOrder);
      if (i <= 512 && j <= 512)
        return true; 
    } 
    return false;
  }
  
  private void loadAttributes(InputStream paramInputStream) throws IOException {
    int i = 0;
    try {
      while (i < EXIF_TAGS.length) {
        this.mAttributes[i] = new HashMap<String, ExifAttribute>();
        i++;
      } 
      paramInputStream = new BufferedInputStream(paramInputStream, 5000);
      BufferedInputStream bufferedInputStream = (BufferedInputStream)paramInputStream;
      this.mMimeType = getMimeType((BufferedInputStream)paramInputStream);
      paramInputStream = new ByteOrderedDataInputStream(paramInputStream);
      switch (this.mMimeType) {
        case 10:
          getRw2Attributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 9:
          getRafAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 7:
          getOrfAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 4:
          getJpegAttributes((ByteOrderedDataInputStream)paramInputStream, 0, 0);
          break;
        case 0:
        case 1:
        case 2:
        case 3:
        case 5:
        case 6:
        case 8:
        case 11:
          getRawAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
      } 
      setThumbnailData((ByteOrderedDataInputStream)paramInputStream);
    } catch (IOException iOException) {
    
    } finally {
      addDefaultValuesForCompatibility();
    } 
    addDefaultValuesForCompatibility();
  }
  
  private void parseTiffHeaders(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    ByteOrder byteOrder = readByteOrder(paramByteOrderedDataInputStream);
    this.mExifByteOrder = byteOrder;
    paramByteOrderedDataInputStream.setByteOrder(byteOrder);
    int i = paramByteOrderedDataInputStream.readUnsignedShort();
    int j = this.mMimeType;
    if (j == 7 || j == 10 || i == 42) {
      i = paramByteOrderedDataInputStream.readInt();
      if (i >= 8 && i < paramInt) {
        paramInt = i - 8;
        if (paramInt > 0) {
          if (paramByteOrderedDataInputStream.skipBytes(paramInt) == paramInt)
            return; 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Couldn't jump to first Ifd: ");
          stringBuilder2.append(paramInt);
          throw new IOException(stringBuilder2.toString());
        } 
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid first Ifd offset: ");
      stringBuilder1.append(i);
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid start code: ");
    stringBuilder.append(Integer.toHexString(i));
    throw new IOException(stringBuilder.toString());
  }
  
  private void printAttributes() {
    for (int i = 0; i < this.mAttributes.length; i++) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The size of tag group[");
      stringBuilder.append(i);
      stringBuilder.append("]: ");
      stringBuilder.append(this.mAttributes[i].size());
      Log.d("ExifInterface", stringBuilder.toString());
      for (Map.Entry<String, ExifAttribute> entry : this.mAttributes[i].entrySet()) {
        ExifAttribute exifAttribute = (ExifAttribute)entry.getValue();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("tagName: ");
        stringBuilder1.append((String)entry.getKey());
        stringBuilder1.append(", tagType: ");
        stringBuilder1.append(exifAttribute.toString());
        stringBuilder1.append(", tagValue: '");
        stringBuilder1.append(exifAttribute.getStringValue(this.mExifByteOrder));
        stringBuilder1.append("'");
        Log.d("ExifInterface", stringBuilder1.toString());
      } 
    } 
  }
  
  private ByteOrder readByteOrder(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    short s = paramByteOrderedDataInputStream.readShort();
    if (s != 18761) {
      if (s == 19789)
        return ByteOrder.BIG_ENDIAN; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid byte order: ");
      stringBuilder.append(Integer.toHexString(s));
      throw new IOException(stringBuilder.toString());
    } 
    return ByteOrder.LITTLE_ENDIAN;
  }
  
  private void readExifSegment(byte[] paramArrayOfbyte, int paramInt) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    parseTiffHeaders(byteOrderedDataInputStream, paramArrayOfbyte.length);
    readImageFileDirectory(byteOrderedDataInputStream, paramInt);
  }
  
  private void readImageFileDirectory(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAttributesOffsets : Ljava/util/Set;
    //   4: aload_1
    //   5: getfield mPosition : I
    //   8: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   11: invokeinterface add : (Ljava/lang/Object;)Z
    //   16: pop
    //   17: aload_1
    //   18: getfield mPosition : I
    //   21: iconst_2
    //   22: iadd
    //   23: aload_1
    //   24: getfield mLength : I
    //   27: if_icmple -> 31
    //   30: return
    //   31: aload_1
    //   32: invokevirtual readShort : ()S
    //   35: istore #4
    //   37: aload_1
    //   38: getfield mPosition : I
    //   41: iload #4
    //   43: bipush #12
    //   45: imul
    //   46: iadd
    //   47: aload_1
    //   48: getfield mLength : I
    //   51: if_icmpgt -> 1289
    //   54: iload #4
    //   56: ifgt -> 60
    //   59: return
    //   60: iconst_0
    //   61: istore #5
    //   63: iload #5
    //   65: iload #4
    //   67: if_icmpge -> 1125
    //   70: aload_1
    //   71: invokevirtual readUnsignedShort : ()I
    //   74: istore #7
    //   76: aload_1
    //   77: invokevirtual readUnsignedShort : ()I
    //   80: istore #6
    //   82: aload_1
    //   83: invokevirtual readInt : ()I
    //   86: istore #8
    //   88: aload_1
    //   89: invokevirtual peek : ()I
    //   92: i2l
    //   93: ldc2_w 4
    //   96: ladd
    //   97: lstore #12
    //   99: getstatic androidx/exifinterface/media/ExifInterface.sExifTagMapsForReading : [Ljava/util/HashMap;
    //   102: iload_2
    //   103: aaload
    //   104: iload #7
    //   106: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   109: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   112: checkcast androidx/exifinterface/media/ExifInterface$ExifTag
    //   115: astore #16
    //   117: aload #16
    //   119: ifnonnull -> 163
    //   122: new java/lang/StringBuilder
    //   125: dup
    //   126: invokespecial <init> : ()V
    //   129: astore #17
    //   131: aload #17
    //   133: ldc_w 'Skip the tag entry since tag number is not defined: '
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: aload #17
    //   142: iload #7
    //   144: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   147: pop
    //   148: ldc_w 'ExifInterface'
    //   151: aload #17
    //   153: invokevirtual toString : ()Ljava/lang/String;
    //   156: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   159: pop
    //   160: goto -> 394
    //   163: iload #6
    //   165: ifle -> 356
    //   168: getstatic androidx/exifinterface/media/ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT : [I
    //   171: astore #17
    //   173: iload #6
    //   175: aload #17
    //   177: arraylength
    //   178: if_icmplt -> 184
    //   181: goto -> 356
    //   184: aload #16
    //   186: iload #6
    //   188: invokevirtual isFormatCompatible : (I)Z
    //   191: ifne -> 259
    //   194: new java/lang/StringBuilder
    //   197: dup
    //   198: invokespecial <init> : ()V
    //   201: astore #17
    //   203: aload #17
    //   205: ldc_w 'Skip the tag entry since data format ('
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: pop
    //   212: aload #17
    //   214: getstatic androidx/exifinterface/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   217: iload #6
    //   219: aaload
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: pop
    //   224: aload #17
    //   226: ldc_w ') is unexpected for tag: '
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #17
    //   235: aload #16
    //   237: getfield name : Ljava/lang/String;
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: ldc_w 'ExifInterface'
    //   247: aload #17
    //   249: invokevirtual toString : ()Ljava/lang/String;
    //   252: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   255: pop
    //   256: goto -> 160
    //   259: iload #6
    //   261: istore_3
    //   262: iload #6
    //   264: bipush #7
    //   266: if_icmpne -> 275
    //   269: aload #16
    //   271: getfield primaryFormat : I
    //   274: istore_3
    //   275: iload #8
    //   277: i2l
    //   278: lstore #10
    //   280: aload #17
    //   282: iload_3
    //   283: iaload
    //   284: i2l
    //   285: lload #10
    //   287: lmul
    //   288: lstore #10
    //   290: lload #10
    //   292: lconst_0
    //   293: lcmp
    //   294: iflt -> 315
    //   297: lload #10
    //   299: ldc2_w 2147483647
    //   302: lcmp
    //   303: ifle -> 309
    //   306: goto -> 315
    //   309: iconst_1
    //   310: istore #6
    //   312: goto -> 403
    //   315: new java/lang/StringBuilder
    //   318: dup
    //   319: invokespecial <init> : ()V
    //   322: astore #17
    //   324: aload #17
    //   326: ldc_w 'Skip the tag entry since the number of components is invalid: '
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: pop
    //   333: aload #17
    //   335: iload #8
    //   337: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   340: pop
    //   341: ldc_w 'ExifInterface'
    //   344: aload #17
    //   346: invokevirtual toString : ()Ljava/lang/String;
    //   349: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   352: pop
    //   353: goto -> 400
    //   356: new java/lang/StringBuilder
    //   359: dup
    //   360: invokespecial <init> : ()V
    //   363: astore #17
    //   365: aload #17
    //   367: ldc_w 'Skip the tag entry since data format is invalid: '
    //   370: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   373: pop
    //   374: aload #17
    //   376: iload #6
    //   378: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   381: pop
    //   382: ldc_w 'ExifInterface'
    //   385: aload #17
    //   387: invokevirtual toString : ()Ljava/lang/String;
    //   390: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   393: pop
    //   394: lconst_0
    //   395: lstore #10
    //   397: iload #6
    //   399: istore_3
    //   400: iconst_0
    //   401: istore #6
    //   403: iload #6
    //   405: ifne -> 417
    //   408: aload_1
    //   409: lload #12
    //   411: invokevirtual seek : (J)V
    //   414: goto -> 1115
    //   417: lload #10
    //   419: ldc2_w 4
    //   422: lcmp
    //   423: ifle -> 692
    //   426: aload_1
    //   427: invokevirtual readInt : ()I
    //   430: istore #6
    //   432: aload_0
    //   433: getfield mMimeType : I
    //   436: istore #9
    //   438: iload #9
    //   440: bipush #7
    //   442: if_icmpne -> 590
    //   445: ldc_w 'MakerNote'
    //   448: aload #16
    //   450: getfield name : Ljava/lang/String;
    //   453: invokevirtual equals : (Ljava/lang/Object;)Z
    //   456: ifeq -> 468
    //   459: aload_0
    //   460: iload #6
    //   462: putfield mOrfMakerNoteOffset : I
    //   465: goto -> 587
    //   468: iload_2
    //   469: bipush #6
    //   471: if_icmpne -> 587
    //   474: ldc_w 'ThumbnailImage'
    //   477: aload #16
    //   479: getfield name : Ljava/lang/String;
    //   482: invokevirtual equals : (Ljava/lang/Object;)Z
    //   485: ifeq -> 587
    //   488: aload_0
    //   489: iload #6
    //   491: putfield mOrfThumbnailOffset : I
    //   494: aload_0
    //   495: iload #8
    //   497: putfield mOrfThumbnailLength : I
    //   500: bipush #6
    //   502: aload_0
    //   503: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   506: invokestatic createUShort : (ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   509: astore #17
    //   511: aload_0
    //   512: getfield mOrfThumbnailOffset : I
    //   515: i2l
    //   516: aload_0
    //   517: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   520: invokestatic createULong : (JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   523: astore #18
    //   525: aload_0
    //   526: getfield mOrfThumbnailLength : I
    //   529: i2l
    //   530: aload_0
    //   531: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   534: invokestatic createULong : (JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   537: astore #19
    //   539: aload_0
    //   540: getfield mAttributes : [Ljava/util/HashMap;
    //   543: iconst_4
    //   544: aaload
    //   545: ldc_w 'Compression'
    //   548: aload #17
    //   550: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   553: pop
    //   554: aload_0
    //   555: getfield mAttributes : [Ljava/util/HashMap;
    //   558: iconst_4
    //   559: aaload
    //   560: ldc_w 'JPEGInterchangeFormat'
    //   563: aload #18
    //   565: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   568: pop
    //   569: aload_0
    //   570: getfield mAttributes : [Ljava/util/HashMap;
    //   573: iconst_4
    //   574: aaload
    //   575: ldc_w 'JPEGInterchangeFormatLength'
    //   578: aload #19
    //   580: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   583: pop
    //   584: goto -> 617
    //   587: goto -> 617
    //   590: iload #9
    //   592: bipush #10
    //   594: if_icmpne -> 617
    //   597: ldc_w 'JpgFromRaw'
    //   600: aload #16
    //   602: getfield name : Ljava/lang/String;
    //   605: invokevirtual equals : (Ljava/lang/Object;)Z
    //   608: ifeq -> 617
    //   611: aload_0
    //   612: iload #6
    //   614: putfield mRw2JpgFromRawOffset : I
    //   617: iload #6
    //   619: i2l
    //   620: lstore #14
    //   622: lload #14
    //   624: lload #10
    //   626: ladd
    //   627: aload_1
    //   628: getfield mLength : I
    //   631: i2l
    //   632: lcmp
    //   633: ifgt -> 645
    //   636: aload_1
    //   637: lload #14
    //   639: invokevirtual seek : (J)V
    //   642: goto -> 692
    //   645: new java/lang/StringBuilder
    //   648: dup
    //   649: invokespecial <init> : ()V
    //   652: astore #16
    //   654: aload #16
    //   656: ldc_w 'Skip the tag entry since data offset is invalid: '
    //   659: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   662: pop
    //   663: aload #16
    //   665: iload #6
    //   667: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   670: pop
    //   671: ldc_w 'ExifInterface'
    //   674: aload #16
    //   676: invokevirtual toString : ()Ljava/lang/String;
    //   679: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   682: pop
    //   683: aload_1
    //   684: lload #12
    //   686: invokevirtual seek : (J)V
    //   689: goto -> 1115
    //   692: getstatic androidx/exifinterface/media/ExifInterface.sExifPointerTagMap : Ljava/util/HashMap;
    //   695: iload #7
    //   697: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   700: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   703: checkcast java/lang/Integer
    //   706: astore #17
    //   708: aload #17
    //   710: ifnull -> 955
    //   713: ldc2_w -1
    //   716: lstore #10
    //   718: iload_3
    //   719: iconst_3
    //   720: if_icmpeq -> 774
    //   723: iload_3
    //   724: iconst_4
    //   725: if_icmpeq -> 765
    //   728: iload_3
    //   729: bipush #8
    //   731: if_icmpeq -> 757
    //   734: iload_3
    //   735: bipush #9
    //   737: if_icmpeq -> 749
    //   740: iload_3
    //   741: bipush #13
    //   743: if_icmpeq -> 749
    //   746: goto -> 786
    //   749: aload_1
    //   750: invokevirtual readInt : ()I
    //   753: istore_3
    //   754: goto -> 779
    //   757: aload_1
    //   758: invokevirtual readShort : ()S
    //   761: istore_3
    //   762: goto -> 779
    //   765: aload_1
    //   766: invokevirtual readUnsignedInt : ()J
    //   769: lstore #10
    //   771: goto -> 746
    //   774: aload_1
    //   775: invokevirtual readUnsignedShort : ()I
    //   778: istore_3
    //   779: iload_3
    //   780: i2l
    //   781: lstore #10
    //   783: goto -> 746
    //   786: lload #10
    //   788: lconst_0
    //   789: lcmp
    //   790: ifle -> 908
    //   793: lload #10
    //   795: aload_1
    //   796: getfield mLength : I
    //   799: i2l
    //   800: lcmp
    //   801: ifge -> 908
    //   804: aload_0
    //   805: getfield mAttributesOffsets : Ljava/util/Set;
    //   808: lload #10
    //   810: l2i
    //   811: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   814: invokeinterface contains : (Ljava/lang/Object;)Z
    //   819: ifne -> 841
    //   822: aload_1
    //   823: lload #10
    //   825: invokevirtual seek : (J)V
    //   828: aload_0
    //   829: aload_1
    //   830: aload #17
    //   832: invokevirtual intValue : ()I
    //   835: invokespecial readImageFileDirectory : (Landroidx/exifinterface/media/ExifInterface$ByteOrderedDataInputStream;I)V
    //   838: goto -> 946
    //   841: new java/lang/StringBuilder
    //   844: dup
    //   845: invokespecial <init> : ()V
    //   848: astore #16
    //   850: aload #16
    //   852: ldc_w 'Skip jump into the IFD since it has already been read: IfdType '
    //   855: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   858: pop
    //   859: aload #16
    //   861: aload #17
    //   863: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   866: pop
    //   867: aload #16
    //   869: ldc_w ' (at '
    //   872: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   875: pop
    //   876: aload #16
    //   878: lload #10
    //   880: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   883: pop
    //   884: aload #16
    //   886: ldc_w ')'
    //   889: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   892: pop
    //   893: ldc_w 'ExifInterface'
    //   896: aload #16
    //   898: invokevirtual toString : ()Ljava/lang/String;
    //   901: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   904: pop
    //   905: goto -> 946
    //   908: new java/lang/StringBuilder
    //   911: dup
    //   912: invokespecial <init> : ()V
    //   915: astore #16
    //   917: aload #16
    //   919: ldc_w 'Skip jump into the IFD since its offset is invalid: '
    //   922: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   925: pop
    //   926: aload #16
    //   928: lload #10
    //   930: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   933: pop
    //   934: ldc_w 'ExifInterface'
    //   937: aload #16
    //   939: invokevirtual toString : ()Ljava/lang/String;
    //   942: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   945: pop
    //   946: aload_1
    //   947: lload #12
    //   949: invokevirtual seek : (J)V
    //   952: goto -> 1115
    //   955: lload #10
    //   957: l2i
    //   958: newarray byte
    //   960: astore #17
    //   962: aload_1
    //   963: aload #17
    //   965: invokevirtual readFully : ([B)V
    //   968: new androidx/exifinterface/media/ExifInterface$ExifAttribute
    //   971: dup
    //   972: iload_3
    //   973: iload #8
    //   975: aload #17
    //   977: invokespecial <init> : (II[B)V
    //   980: astore #17
    //   982: aload_0
    //   983: getfield mAttributes : [Ljava/util/HashMap;
    //   986: iload_2
    //   987: aaload
    //   988: aload #16
    //   990: getfield name : Ljava/lang/String;
    //   993: aload #17
    //   995: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   998: pop
    //   999: ldc_w 'DNGVersion'
    //   1002: aload #16
    //   1004: getfield name : Ljava/lang/String;
    //   1007: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1010: ifeq -> 1018
    //   1013: aload_0
    //   1014: iconst_3
    //   1015: putfield mMimeType : I
    //   1018: ldc_w 'Make'
    //   1021: aload #16
    //   1023: getfield name : Ljava/lang/String;
    //   1026: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1029: ifne -> 1046
    //   1032: ldc_w 'Model'
    //   1035: aload #16
    //   1037: getfield name : Ljava/lang/String;
    //   1040: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1043: ifeq -> 1064
    //   1046: aload #17
    //   1048: aload_0
    //   1049: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1052: invokevirtual getStringValue : (Ljava/nio/ByteOrder;)Ljava/lang/String;
    //   1055: ldc_w 'PENTAX'
    //   1058: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1061: ifne -> 1092
    //   1064: ldc_w 'Compression'
    //   1067: aload #16
    //   1069: getfield name : Ljava/lang/String;
    //   1072: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1075: ifeq -> 1098
    //   1078: aload #17
    //   1080: aload_0
    //   1081: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1084: invokevirtual getIntValue : (Ljava/nio/ByteOrder;)I
    //   1087: ldc 65535
    //   1089: if_icmpne -> 1098
    //   1092: aload_0
    //   1093: bipush #8
    //   1095: putfield mMimeType : I
    //   1098: aload_1
    //   1099: invokevirtual peek : ()I
    //   1102: i2l
    //   1103: lload #12
    //   1105: lcmp
    //   1106: ifeq -> 1115
    //   1109: aload_1
    //   1110: lload #12
    //   1112: invokevirtual seek : (J)V
    //   1115: iload #5
    //   1117: iconst_1
    //   1118: iadd
    //   1119: i2s
    //   1120: istore #5
    //   1122: goto -> 63
    //   1125: aload_1
    //   1126: invokevirtual peek : ()I
    //   1129: iconst_4
    //   1130: iadd
    //   1131: aload_1
    //   1132: getfield mLength : I
    //   1135: if_icmpgt -> 1289
    //   1138: aload_1
    //   1139: invokevirtual readInt : ()I
    //   1142: istore_2
    //   1143: iload_2
    //   1144: i2l
    //   1145: lstore #10
    //   1147: lload #10
    //   1149: lconst_0
    //   1150: lcmp
    //   1151: ifle -> 1256
    //   1154: iload_2
    //   1155: aload_1
    //   1156: getfield mLength : I
    //   1159: if_icmpge -> 1256
    //   1162: aload_0
    //   1163: getfield mAttributesOffsets : Ljava/util/Set;
    //   1166: iload_2
    //   1167: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1170: invokeinterface contains : (Ljava/lang/Object;)Z
    //   1175: ifne -> 1222
    //   1178: aload_1
    //   1179: lload #10
    //   1181: invokevirtual seek : (J)V
    //   1184: aload_0
    //   1185: getfield mAttributes : [Ljava/util/HashMap;
    //   1188: iconst_4
    //   1189: aaload
    //   1190: invokevirtual isEmpty : ()Z
    //   1193: ifeq -> 1203
    //   1196: aload_0
    //   1197: aload_1
    //   1198: iconst_4
    //   1199: invokespecial readImageFileDirectory : (Landroidx/exifinterface/media/ExifInterface$ByteOrderedDataInputStream;I)V
    //   1202: return
    //   1203: aload_0
    //   1204: getfield mAttributes : [Ljava/util/HashMap;
    //   1207: iconst_5
    //   1208: aaload
    //   1209: invokevirtual isEmpty : ()Z
    //   1212: ifeq -> 1289
    //   1215: aload_0
    //   1216: aload_1
    //   1217: iconst_5
    //   1218: invokespecial readImageFileDirectory : (Landroidx/exifinterface/media/ExifInterface$ByteOrderedDataInputStream;I)V
    //   1221: return
    //   1222: new java/lang/StringBuilder
    //   1225: dup
    //   1226: invokespecial <init> : ()V
    //   1229: astore_1
    //   1230: aload_1
    //   1231: ldc_w 'Stop reading file since re-reading an IFD may cause an infinite loop: '
    //   1234: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1237: pop
    //   1238: aload_1
    //   1239: iload_2
    //   1240: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1243: pop
    //   1244: ldc_w 'ExifInterface'
    //   1247: aload_1
    //   1248: invokevirtual toString : ()Ljava/lang/String;
    //   1251: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   1254: pop
    //   1255: return
    //   1256: new java/lang/StringBuilder
    //   1259: dup
    //   1260: invokespecial <init> : ()V
    //   1263: astore_1
    //   1264: aload_1
    //   1265: ldc_w 'Stop reading file since a wrong offset may cause an infinite loop: '
    //   1268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1271: pop
    //   1272: aload_1
    //   1273: iload_2
    //   1274: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1277: pop
    //   1278: ldc_w 'ExifInterface'
    //   1281: aload_1
    //   1282: invokevirtual toString : ()Ljava/lang/String;
    //   1285: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   1288: pop
    //   1289: return
  }
  
  private void removeAttribute(String paramString) {
    for (int i = 0; i < EXIF_TAGS.length; i++)
      this.mAttributes[i].remove(paramString); 
  }
  
  private void retrieveJpegImageSize(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    ExifAttribute exifAttribute1 = this.mAttributes[paramInt].get("ImageLength");
    ExifAttribute exifAttribute2 = this.mAttributes[paramInt].get("ImageWidth");
    if (exifAttribute1 == null || exifAttribute2 == null) {
      exifAttribute1 = this.mAttributes[paramInt].get("JPEGInterchangeFormat");
      if (exifAttribute1 != null)
        getJpegAttributes(paramByteOrderedDataInputStream, exifAttribute1.getIntValue(this.mExifByteOrder), paramInt); 
    } 
  }
  
  private void saveJpegAttributes(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    paramInputStream = new DataInputStream(paramInputStream);
    paramOutputStream = new ByteOrderedDataOutputStream(paramOutputStream, ByteOrder.BIG_ENDIAN);
    if (paramInputStream.readByte() == -1) {
      paramOutputStream.writeByte(-1);
      if (paramInputStream.readByte() == -40) {
        paramOutputStream.writeByte(-40);
        paramOutputStream.writeByte(-1);
        paramOutputStream.writeByte(-31);
        writeExifSegment((ByteOrderedDataOutputStream)paramOutputStream, 6);
        byte[] arrayOfByte = new byte[4096];
        while (paramInputStream.readByte() == -1) {
          int i = paramInputStream.readByte();
          if (i != -39 && i != -38) {
            if (i != -31) {
              paramOutputStream.writeByte(-1);
              paramOutputStream.writeByte(i);
              int k = paramInputStream.readUnsignedShort();
              paramOutputStream.writeUnsignedShort(k);
              k -= 2;
              if (k >= 0) {
                while (k > 0) {
                  int m = paramInputStream.read(arrayOfByte, 0, Math.min(k, 4096));
                  if (m >= 0) {
                    paramOutputStream.write(arrayOfByte, 0, m);
                    k -= m;
                  } 
                } 
                continue;
              } 
              throw new IOException("Invalid length");
            } 
            int j = paramInputStream.readUnsignedShort() - 2;
            if (j >= 0) {
              byte[] arrayOfByte1 = new byte[6];
              if (j >= 6)
                if (paramInputStream.read(arrayOfByte1) == 6) {
                  if (Arrays.equals(arrayOfByte1, IDENTIFIER_EXIF_APP1)) {
                    i = j - 6;
                    if (paramInputStream.skipBytes(i) == i)
                      continue; 
                    throw new IOException("Invalid length");
                  } 
                } else {
                  throw new IOException("Invalid exif");
                }  
              paramOutputStream.writeByte(-1);
              paramOutputStream.writeByte(i);
              paramOutputStream.writeUnsignedShort(j + 2);
              i = j;
              if (j >= 6) {
                i = j - 6;
                paramOutputStream.write(arrayOfByte1);
              } 
              while (i > 0) {
                j = paramInputStream.read(arrayOfByte, 0, Math.min(i, 4096));
                if (j >= 0) {
                  paramOutputStream.write(arrayOfByte, 0, j);
                  i -= j;
                } 
              } 
              continue;
            } 
            throw new IOException("Invalid length");
          } 
          paramOutputStream.writeByte(-1);
          paramOutputStream.writeByte(i);
          copy(paramInputStream, paramOutputStream);
          return;
        } 
        throw new IOException("Invalid marker");
      } 
      throw new IOException("Invalid marker");
    } 
    IOException iOException = new IOException("Invalid marker");
    throw iOException;
  }
  
  private void setThumbnailData(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    HashMap<String, ExifAttribute> hashMap = this.mAttributes[4];
    ExifAttribute exifAttribute = hashMap.get("Compression");
    if (exifAttribute != null) {
      int i = exifAttribute.getIntValue(this.mExifByteOrder);
      this.mThumbnailCompression = i;
      if (i != 1)
        if (i != 6) {
          if (i != 7)
            return; 
        } else {
          handleThumbnailFromJfif(paramByteOrderedDataInputStream, hashMap);
          return;
        }  
      if (isSupportedDataType(hashMap)) {
        handleThumbnailFromStrips(paramByteOrderedDataInputStream, hashMap);
        return;
      } 
    } else {
      this.mThumbnailCompression = 6;
      handleThumbnailFromJfif(paramByteOrderedDataInputStream, hashMap);
    } 
  }
  
  private void swapBasedOnImageSize(int paramInt1, int paramInt2) throws IOException {
    if (!this.mAttributes[paramInt1].isEmpty()) {
      if (this.mAttributes[paramInt2].isEmpty())
        return; 
      ExifAttribute exifAttribute1 = this.mAttributes[paramInt1].get("ImageLength");
      ExifAttribute exifAttribute2 = this.mAttributes[paramInt1].get("ImageWidth");
      ExifAttribute exifAttribute3 = this.mAttributes[paramInt2].get("ImageLength");
      ExifAttribute exifAttribute4 = this.mAttributes[paramInt2].get("ImageWidth");
      if (exifAttribute1 != null) {
        if (exifAttribute2 == null)
          return; 
        if (exifAttribute3 != null) {
          if (exifAttribute4 == null)
            return; 
          int i = exifAttribute1.getIntValue(this.mExifByteOrder);
          int j = exifAttribute2.getIntValue(this.mExifByteOrder);
          int k = exifAttribute3.getIntValue(this.mExifByteOrder);
          int m = exifAttribute4.getIntValue(this.mExifByteOrder);
          if (i < k && j < m) {
            HashMap<String, ExifAttribute>[] arrayOfHashMap = this.mAttributes;
            HashMap<String, ExifAttribute> hashMap = arrayOfHashMap[paramInt1];
            arrayOfHashMap[paramInt1] = arrayOfHashMap[paramInt2];
            arrayOfHashMap[paramInt2] = hashMap;
          } 
        } 
      } 
    } 
  }
  
  private boolean updateAttribute(String paramString, ExifAttribute paramExifAttribute) {
    int i = 0;
    boolean bool = false;
    while (i < EXIF_TAGS.length) {
      if (this.mAttributes[i].containsKey(paramString)) {
        this.mAttributes[i].put(paramString, paramExifAttribute);
        bool = true;
      } 
      i++;
    } 
    return bool;
  }
  
  private void updateImageSizeValues(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    ExifAttribute exifAttribute1;
    ExifAttribute exifAttribute2 = this.mAttributes[paramInt].get("DefaultCropSize");
    ExifAttribute exifAttribute3 = this.mAttributes[paramInt].get("SensorTopBorder");
    ExifAttribute exifAttribute4 = this.mAttributes[paramInt].get("SensorLeftBorder");
    ExifAttribute exifAttribute5 = this.mAttributes[paramInt].get("SensorBottomBorder");
    ExifAttribute exifAttribute6 = this.mAttributes[paramInt].get("SensorRightBorder");
    if (exifAttribute2 != null) {
      ExifAttribute exifAttribute;
      if (exifAttribute2.format == 5) {
        Rational[] arrayOfRational = (Rational[])exifAttribute2.getValue(this.mExifByteOrder);
        if (arrayOfRational == null || arrayOfRational.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfRational));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        exifAttribute1 = ExifAttribute.createURational(arrayOfRational[0], this.mExifByteOrder);
        exifAttribute = ExifAttribute.createURational(arrayOfRational[1], this.mExifByteOrder);
      } else {
        int[] arrayOfInt = (int[])exifAttribute.getValue(this.mExifByteOrder);
        if (arrayOfInt == null || arrayOfInt.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        exifAttribute1 = ExifAttribute.createUShort(arrayOfInt[0], this.mExifByteOrder);
        exifAttribute = ExifAttribute.createUShort(arrayOfInt[1], this.mExifByteOrder);
      } 
      this.mAttributes[paramInt].put("ImageWidth", exifAttribute1);
      this.mAttributes[paramInt].put("ImageLength", exifAttribute);
      return;
    } 
    if (exifAttribute3 != null && exifAttribute4 != null && exifAttribute5 != null && exifAttribute6 != null) {
      int i = exifAttribute3.getIntValue(this.mExifByteOrder);
      int j = exifAttribute5.getIntValue(this.mExifByteOrder);
      int k = exifAttribute6.getIntValue(this.mExifByteOrder);
      int m = exifAttribute4.getIntValue(this.mExifByteOrder);
      if (j > i && k > m) {
        exifAttribute1 = ExifAttribute.createUShort(j - i, this.mExifByteOrder);
        exifAttribute2 = ExifAttribute.createUShort(k - m, this.mExifByteOrder);
        this.mAttributes[paramInt].put("ImageLength", exifAttribute1);
        this.mAttributes[paramInt].put("ImageWidth", exifAttribute2);
        return;
      } 
    } else {
      retrieveJpegImageSize((ByteOrderedDataInputStream)exifAttribute1, paramInt);
    } 
  }
  
  private void validateImages(InputStream paramInputStream) throws IOException {
    swapBasedOnImageSize(0, 5);
    swapBasedOnImageSize(0, 4);
    swapBasedOnImageSize(5, 4);
    ExifAttribute exifAttribute1 = this.mAttributes[1].get("PixelXDimension");
    ExifAttribute exifAttribute2 = this.mAttributes[1].get("PixelYDimension");
    if (exifAttribute1 != null && exifAttribute2 != null) {
      this.mAttributes[0].put("ImageWidth", exifAttribute1);
      this.mAttributes[0].put("ImageLength", exifAttribute2);
    } 
    if (this.mAttributes[4].isEmpty() && isThumbnail(this.mAttributes[5])) {
      HashMap<String, ExifAttribute>[] arrayOfHashMap = this.mAttributes;
      arrayOfHashMap[4] = arrayOfHashMap[5];
      arrayOfHashMap[5] = new HashMap<String, ExifAttribute>();
    } 
    if (!isThumbnail(this.mAttributes[4]))
      Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image."); 
  }
  
  private int writeExifSegment(ByteOrderedDataOutputStream paramByteOrderedDataOutputStream, int paramInt) throws IOException {
    char c;
    ExifTag[][] arrayOfExifTag = EXIF_TAGS;
    int[] arrayOfInt1 = new int[arrayOfExifTag.length];
    int[] arrayOfInt2 = new int[arrayOfExifTag.length];
    ExifTag[] arrayOfExifTag1 = EXIF_POINTER_TAGS;
    int j = arrayOfExifTag1.length;
    int i;
    for (i = 0; i < j; i++)
      removeAttribute((arrayOfExifTag1[i]).name); 
    removeAttribute(JPEG_INTERCHANGE_FORMAT_TAG.name);
    removeAttribute(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name);
    for (i = 0; i < EXIF_TAGS.length; i++) {
      Object[] arrayOfObject = this.mAttributes[i].entrySet().toArray();
      int m = arrayOfObject.length;
      for (j = 0; j < m; j++) {
        Map.Entry entry = (Map.Entry)arrayOfObject[j];
        if (entry.getValue() == null)
          this.mAttributes[i].remove(entry.getKey()); 
      } 
    } 
    if (!this.mAttributes[1].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[1]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (!this.mAttributes[2].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[2]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (!this.mAttributes[3].isEmpty())
      this.mAttributes[1].put((EXIF_POINTER_TAGS[3]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (this.mHasThumbnail) {
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifAttribute.createULong(0L, this.mExifByteOrder));
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name, ExifAttribute.createULong(this.mThumbnailLength, this.mExifByteOrder));
    } 
    for (i = 0; i < EXIF_TAGS.length; i++) {
      Iterator<Map.Entry> iterator = this.mAttributes[i].entrySet().iterator();
      j = 0;
      while (iterator.hasNext()) {
        int m = ((ExifAttribute)((Map.Entry)iterator.next()).getValue()).size();
        if (m > 4)
          j += m; 
      } 
      arrayOfInt2[i] = arrayOfInt2[i] + j;
    } 
    j = 0;
    for (i = 8; j < EXIF_TAGS.length; i = m) {
      int m = i;
      if (!this.mAttributes[j].isEmpty()) {
        arrayOfInt1[j] = i;
        m = i + this.mAttributes[j].size() * 12 + 2 + 4 + arrayOfInt2[j];
      } 
      j++;
    } 
    j = i;
    if (this.mHasThumbnail) {
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifAttribute.createULong(i, this.mExifByteOrder));
      this.mThumbnailOffset = paramInt + i;
      j = i + this.mThumbnailLength;
    } 
    int k = j + 8;
    if (!this.mAttributes[1].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[1]).name, ExifAttribute.createULong(arrayOfInt1[1], this.mExifByteOrder)); 
    if (!this.mAttributes[2].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[2]).name, ExifAttribute.createULong(arrayOfInt1[2], this.mExifByteOrder)); 
    if (!this.mAttributes[3].isEmpty())
      this.mAttributes[1].put((EXIF_POINTER_TAGS[3]).name, ExifAttribute.createULong(arrayOfInt1[3], this.mExifByteOrder)); 
    paramByteOrderedDataOutputStream.writeUnsignedShort(k);
    paramByteOrderedDataOutputStream.write(IDENTIFIER_EXIF_APP1);
    if (this.mExifByteOrder == ByteOrder.BIG_ENDIAN) {
      c = '䵍';
    } else {
      c = '䥉';
    } 
    paramByteOrderedDataOutputStream.writeShort(c);
    paramByteOrderedDataOutputStream.setByteOrder(this.mExifByteOrder);
    paramByteOrderedDataOutputStream.writeUnsignedShort(42);
    paramByteOrderedDataOutputStream.writeUnsignedInt(8L);
    for (paramInt = 0; paramInt < EXIF_TAGS.length; paramInt++) {
      if (!this.mAttributes[paramInt].isEmpty()) {
        paramByteOrderedDataOutputStream.writeUnsignedShort(this.mAttributes[paramInt].size());
        i = arrayOfInt1[paramInt] + 2 + this.mAttributes[paramInt].size() * 12 + 4;
        for (Map.Entry<String, ExifAttribute> entry : this.mAttributes[paramInt].entrySet()) {
          int m = ((ExifTag)sExifTagMapsForWriting[paramInt].get(entry.getKey())).number;
          ExifAttribute exifAttribute = (ExifAttribute)entry.getValue();
          j = exifAttribute.size();
          paramByteOrderedDataOutputStream.writeUnsignedShort(m);
          paramByteOrderedDataOutputStream.writeUnsignedShort(exifAttribute.format);
          paramByteOrderedDataOutputStream.writeInt(exifAttribute.numberOfComponents);
          if (j > 4) {
            paramByteOrderedDataOutputStream.writeUnsignedInt(i);
            i += j;
            continue;
          } 
          paramByteOrderedDataOutputStream.write(exifAttribute.bytes);
          if (j < 4)
            while (j < 4) {
              paramByteOrderedDataOutputStream.writeByte(0);
              j++;
            }  
        } 
        if (paramInt == 0 && !this.mAttributes[4].isEmpty()) {
          paramByteOrderedDataOutputStream.writeUnsignedInt(arrayOfInt1[4]);
        } else {
          paramByteOrderedDataOutputStream.writeUnsignedInt(0L);
        } 
        Iterator<Map.Entry> iterator = this.mAttributes[paramInt].entrySet().iterator();
        while (iterator.hasNext()) {
          ExifAttribute exifAttribute = (ExifAttribute)((Map.Entry)iterator.next()).getValue();
          if (exifAttribute.bytes.length > 4)
            paramByteOrderedDataOutputStream.write(exifAttribute.bytes, 0, exifAttribute.bytes.length); 
        } 
      } 
    } 
    if (this.mHasThumbnail)
      paramByteOrderedDataOutputStream.write(getThumbnailBytes()); 
    paramByteOrderedDataOutputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    return k;
  }
  
  public void flipHorizontally() {
    byte b = 1;
    switch (getAttributeInt("Orientation", 1)) {
      default:
        b = 0;
        break;
      case 8:
        b = 7;
        break;
      case 7:
        b = 8;
        break;
      case 6:
        b = 5;
        break;
      case 5:
        b = 6;
        break;
      case 4:
        b = 3;
        break;
      case 3:
        b = 4;
        break;
      case 1:
        b = 2;
        break;
      case 2:
        break;
    } 
    setAttribute("Orientation", Integer.toString(b));
  }
  
  public void flipVertically() {
    byte b = 1;
    switch (getAttributeInt("Orientation", 1)) {
      default:
        b = 0;
        break;
      case 8:
        b = 5;
        break;
      case 7:
        b = 6;
        break;
      case 6:
        b = 7;
        break;
      case 5:
        b = 8;
        break;
      case 3:
        b = 2;
        break;
      case 2:
        b = 3;
        break;
      case 1:
        b = 4;
        break;
      case 4:
        break;
    } 
    setAttribute("Orientation", Integer.toString(b));
  }
  
  public double getAltitude(double paramDouble) {
    double d = getAttributeDouble("GPSAltitude", -1.0D);
    byte b = -1;
    int i = getAttributeInt("GPSAltitudeRef", -1);
    if (d >= 0.0D && i >= 0) {
      if (i != 1)
        b = 1; 
      paramDouble = b;
      Double.isNaN(paramDouble);
      return d * paramDouble;
    } 
    return paramDouble;
  }
  
  public String getAttribute(String paramString) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute != null) {
      StringBuilder stringBuilder;
      if (!sTagSetForCompatibility.contains(paramString))
        return exifAttribute.getStringValue(this.mExifByteOrder); 
      if (paramString.equals("GPSTimeStamp")) {
        if (exifAttribute.format != 5 && exifAttribute.format != 10) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("GPS Timestamp format is not rational. format=");
          stringBuilder1.append(exifAttribute.format);
          Log.w("ExifInterface", stringBuilder1.toString());
          return null;
        } 
        Rational[] arrayOfRational = (Rational[])exifAttribute.getValue(this.mExifByteOrder);
        if (arrayOfRational == null || arrayOfRational.length != 3) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid GPS Timestamp array. array=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfRational));
          Log.w("ExifInterface", stringBuilder.toString());
          return null;
        } 
        return String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf((int)((float)(arrayOfRational[0]).numerator / (float)(arrayOfRational[0]).denominator)), Integer.valueOf((int)((float)(arrayOfRational[1]).numerator / (float)(arrayOfRational[1]).denominator)), Integer.valueOf((int)((float)(arrayOfRational[2]).numerator / (float)(arrayOfRational[2]).denominator)) });
      } 
      try {
        return Double.toString(stringBuilder.getDoubleValue(this.mExifByteOrder));
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
    } 
    return null;
  }
  
  public double getAttributeDouble(String paramString, double paramDouble) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute == null)
      return paramDouble; 
    try {
      return exifAttribute.getDoubleValue(this.mExifByteOrder);
    } catch (NumberFormatException numberFormatException) {
      return paramDouble;
    } 
  }
  
  public int getAttributeInt(String paramString, int paramInt) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute == null)
      return paramInt; 
    try {
      return exifAttribute.getIntValue(this.mExifByteOrder);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public long getDateTime() {
    String str = getAttribute("DateTime");
    if (str != null) {
      if (!sNonZeroTimePattern.matcher(str).matches())
        return -1L; 
      ParsePosition parsePosition = new ParsePosition(0);
      try {
        Date date = sFormatter.parse(str, parsePosition);
        if (date == null)
          return -1L; 
        long l2 = date.getTime();
        String str1 = getAttribute("SubSecTime");
        long l1 = l2;
        if (str1 != null)
          try {
            for (l1 = Long.parseLong(str1); l1 > 1000L; l1 /= 10L);
            return l2 + l1;
          } catch (NumberFormatException numberFormatException) {
            return l2;
          }  
        return l1;
      } catch (IllegalArgumentException illegalArgumentException) {
        return -1L;
      } 
    } 
    return -1L;
  }
  
  public long getGpsDateTime() {
    String str1 = getAttribute("GPSDateStamp");
    String str2 = getAttribute("GPSTimeStamp");
    if (str1 != null && str2 != null) {
      Pattern pattern = sNonZeroTimePattern;
      if (!pattern.matcher(str1).matches() && !pattern.matcher(str2).matches())
        return -1L; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(' ');
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
      ParsePosition parsePosition = new ParsePosition(0);
      try {
        Date date = sFormatter.parse(str1, parsePosition);
        return (date == null) ? -1L : date.getTime();
      } catch (IllegalArgumentException illegalArgumentException) {
        return -1L;
      } 
    } 
    return -1L;
  }
  
  @Deprecated
  public boolean getLatLong(float[] paramArrayOffloat) {
    double[] arrayOfDouble = getLatLong();
    if (arrayOfDouble == null)
      return false; 
    paramArrayOffloat[0] = (float)arrayOfDouble[0];
    paramArrayOffloat[1] = (float)arrayOfDouble[1];
    return true;
  }
  
  public double[] getLatLong() {
    String str1 = getAttribute("GPSLatitude");
    String str2 = getAttribute("GPSLatitudeRef");
    String str3 = getAttribute("GPSLongitude");
    String str4 = getAttribute("GPSLongitudeRef");
    if (str1 != null && str2 != null && str3 != null && str4 != null)
      try {
        double d1 = convertRationalLatLonToDouble(str1, str2);
        double d2 = convertRationalLatLonToDouble(str3, str4);
        return new double[] { d1, d2 };
      } catch (IllegalArgumentException illegalArgumentException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Latitude/longitude values are not parseable. ");
        stringBuilder.append(String.format("latValue=%s, latRef=%s, lngValue=%s, lngRef=%s", new Object[] { str1, str2, str3, str4 }));
        Log.w("ExifInterface", stringBuilder.toString());
      }  
    return null;
  }
  
  public int getRotationDegrees() {
    switch (getAttributeInt("Orientation", 1)) {
      default:
        return 0;
      case 6:
      case 7:
        return 90;
      case 5:
      case 8:
        return 270;
      case 3:
      case 4:
        break;
    } 
    return 180;
  }
  
  public byte[] getThumbnail() {
    int i = this.mThumbnailCompression;
    return (i == 6 || i == 7) ? getThumbnailBytes() : null;
  }
  
  public Bitmap getThumbnailBitmap() {
    if (!this.mHasThumbnail)
      return null; 
    if (this.mThumbnailBytes == null)
      this.mThumbnailBytes = getThumbnailBytes(); 
    int i = this.mThumbnailCompression;
    if (i == 6 || i == 7)
      return BitmapFactory.decodeByteArray(this.mThumbnailBytes, 0, this.mThumbnailLength); 
    if (i == 1) {
      int j = this.mThumbnailBytes.length / 3;
      int[] arrayOfInt = new int[j];
      for (i = 0; i < j; i++) {
        byte[] arrayOfByte = this.mThumbnailBytes;
        int k = i * 3;
        arrayOfInt[i] = (arrayOfByte[k] << 16) + 0 + (arrayOfByte[k + 1] << 8) + arrayOfByte[k + 2];
      } 
      ExifAttribute exifAttribute1 = this.mAttributes[4].get("ImageLength");
      ExifAttribute exifAttribute2 = this.mAttributes[4].get("ImageWidth");
      if (exifAttribute1 != null && exifAttribute2 != null) {
        i = exifAttribute1.getIntValue(this.mExifByteOrder);
        return Bitmap.createBitmap(arrayOfInt, exifAttribute2.getIntValue(this.mExifByteOrder), i, Bitmap.Config.ARGB_8888);
      } 
    } 
    return null;
  }
  
  public byte[] getThumbnailBytes() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mHasThumbnail : Z
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #6
    //   8: iload_2
    //   9: ifne -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload_0
    //   15: getfield mThumbnailBytes : [B
    //   18: astore #5
    //   20: aload #5
    //   22: ifnull -> 28
    //   25: aload #5
    //   27: areturn
    //   28: aload_0
    //   29: getfield mAssetInputStream : Landroid/content/res/AssetManager$AssetInputStream;
    //   32: astore #5
    //   34: aload #5
    //   36: ifnull -> 101
    //   39: aload #5
    //   41: astore #7
    //   43: aload #5
    //   45: astore #6
    //   47: aload #5
    //   49: invokevirtual markSupported : ()Z
    //   52: ifeq -> 71
    //   55: aload #5
    //   57: astore #7
    //   59: aload #5
    //   61: astore #6
    //   63: aload #5
    //   65: invokevirtual reset : ()V
    //   68: goto -> 127
    //   71: aload #5
    //   73: astore #7
    //   75: aload #5
    //   77: astore #6
    //   79: ldc_w 'ExifInterface'
    //   82: ldc_w 'Cannot read thumbnail from inputstream without mark/reset support'
    //   85: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   88: pop
    //   89: aload #5
    //   91: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   94: aconst_null
    //   95: areturn
    //   96: astore #5
    //   98: goto -> 295
    //   101: aload_0
    //   102: getfield mFilename : Ljava/lang/String;
    //   105: ifnull -> 124
    //   108: new java/io/FileInputStream
    //   111: dup
    //   112: aload_0
    //   113: getfield mFilename : Ljava/lang/String;
    //   116: invokespecial <init> : (Ljava/lang/String;)V
    //   119: astore #5
    //   121: goto -> 127
    //   124: aconst_null
    //   125: astore #5
    //   127: aload #5
    //   129: ifnull -> 269
    //   132: aload #5
    //   134: astore #7
    //   136: aload #5
    //   138: astore #6
    //   140: aload #5
    //   142: aload_0
    //   143: getfield mThumbnailOffset : I
    //   146: i2l
    //   147: invokevirtual skip : (J)J
    //   150: lstore_3
    //   151: aload #5
    //   153: astore #7
    //   155: aload #5
    //   157: astore #6
    //   159: aload_0
    //   160: getfield mThumbnailOffset : I
    //   163: istore_1
    //   164: lload_3
    //   165: iload_1
    //   166: i2l
    //   167: lcmp
    //   168: ifne -> 250
    //   171: aload #5
    //   173: astore #7
    //   175: aload #5
    //   177: astore #6
    //   179: aload_0
    //   180: getfield mThumbnailLength : I
    //   183: newarray byte
    //   185: astore #8
    //   187: aload #5
    //   189: astore #7
    //   191: aload #5
    //   193: astore #6
    //   195: aload #5
    //   197: aload #8
    //   199: invokevirtual read : ([B)I
    //   202: aload_0
    //   203: getfield mThumbnailLength : I
    //   206: if_icmpne -> 231
    //   209: aload #5
    //   211: astore #7
    //   213: aload #5
    //   215: astore #6
    //   217: aload_0
    //   218: aload #8
    //   220: putfield mThumbnailBytes : [B
    //   223: aload #5
    //   225: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   228: aload #8
    //   230: areturn
    //   231: aload #5
    //   233: astore #7
    //   235: aload #5
    //   237: astore #6
    //   239: new java/io/IOException
    //   242: dup
    //   243: ldc_w 'Corrupted image'
    //   246: invokespecial <init> : (Ljava/lang/String;)V
    //   249: athrow
    //   250: aload #5
    //   252: astore #7
    //   254: aload #5
    //   256: astore #6
    //   258: new java/io/IOException
    //   261: dup
    //   262: ldc_w 'Corrupted image'
    //   265: invokespecial <init> : (Ljava/lang/String;)V
    //   268: athrow
    //   269: aload #5
    //   271: astore #7
    //   273: aload #5
    //   275: astore #6
    //   277: new java/io/FileNotFoundException
    //   280: dup
    //   281: invokespecial <init> : ()V
    //   284: athrow
    //   285: astore #5
    //   287: goto -> 320
    //   290: astore #5
    //   292: aconst_null
    //   293: astore #7
    //   295: aload #7
    //   297: astore #6
    //   299: ldc_w 'ExifInterface'
    //   302: ldc_w 'Encountered exception while getting thumbnail'
    //   305: aload #5
    //   307: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   310: pop
    //   311: aload #7
    //   313: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   316: aconst_null
    //   317: areturn
    //   318: astore #5
    //   320: aload #6
    //   322: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   325: aload #5
    //   327: athrow
    // Exception table:
    //   from	to	target	type
    //   28	34	290	java/io/IOException
    //   28	34	285	finally
    //   47	55	96	java/io/IOException
    //   47	55	318	finally
    //   63	68	96	java/io/IOException
    //   63	68	318	finally
    //   79	89	96	java/io/IOException
    //   79	89	318	finally
    //   101	121	290	java/io/IOException
    //   101	121	285	finally
    //   140	151	96	java/io/IOException
    //   140	151	318	finally
    //   159	164	96	java/io/IOException
    //   159	164	318	finally
    //   179	187	96	java/io/IOException
    //   179	187	318	finally
    //   195	209	96	java/io/IOException
    //   195	209	318	finally
    //   217	223	96	java/io/IOException
    //   217	223	318	finally
    //   239	250	96	java/io/IOException
    //   239	250	318	finally
    //   258	269	96	java/io/IOException
    //   258	269	318	finally
    //   277	285	96	java/io/IOException
    //   277	285	318	finally
    //   299	311	318	finally
  }
  
  public long[] getThumbnailRange() {
    return !this.mHasThumbnail ? null : new long[] { this.mThumbnailOffset, this.mThumbnailLength };
  }
  
  public boolean hasThumbnail() {
    return this.mHasThumbnail;
  }
  
  public boolean isFlipped() {
    int i = getAttributeInt("Orientation", 1);
    return !(i != 2 && i != 7 && i != 4 && i != 5);
  }
  
  public boolean isThumbnailCompressed() {
    int i = this.mThumbnailCompression;
    return (i == 6 || i == 7);
  }
  
  public void resetOrientation() {
    setAttribute("Orientation", Integer.toString(1));
  }
  
  public void rotate(int paramInt) {
    if (paramInt % 90 == 0) {
      int k = getAttributeInt("Orientation", 1);
      List<Integer> list = ROTATION_ORDER;
      boolean bool1 = list.contains(Integer.valueOf(k));
      int j = 0;
      boolean bool = false;
      int i = 0;
      if (bool1) {
        j = (list.indexOf(Integer.valueOf(k)) + paramInt / 90) % 4;
        paramInt = i;
        if (j < 0)
          paramInt = 4; 
        i = ((Integer)list.get(j + paramInt)).intValue();
      } else {
        list = FLIPPED_ROTATION_ORDER;
        i = bool;
        if (list.contains(Integer.valueOf(k))) {
          i = (list.indexOf(Integer.valueOf(k)) + paramInt / 90) % 4;
          paramInt = j;
          if (i < 0)
            paramInt = 4; 
          i = ((Integer)list.get(i + paramInt)).intValue();
        } 
      } 
      setAttribute("Orientation", Integer.toString(i));
      return;
    } 
    throw new IllegalArgumentException("degree should be a multiple of 90");
  }
  
  public void saveAttributes() throws IOException {
    if (this.mIsSupportedFile && this.mMimeType == 4) {
      if (this.mFilename != null) {
        this.mThumbnailBytes = getThumbnail();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mFilename);
        stringBuilder.append(".tmp");
        File file = new File(stringBuilder.toString());
        if ((new File(this.mFilename)).renameTo(file)) {
          Closeable closeable1;
          Closeable closeable2;
          try {
          
          } finally {
            stringBuilder = null;
            closeable1 = null;
          } 
          closeQuietly(closeable2);
          closeQuietly(closeable1);
          file.delete();
          throw stringBuilder;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Could not rename to ");
        stringBuilder.append(file.getAbsolutePath());
        throw new IOException(stringBuilder.toString());
      } 
      throw new IOException("ExifInterface does not support saving attributes for the current input.");
    } 
    throw new IOException("ExifInterface only supports saving attributes on JPEG formats.");
  }
  
  public void setAltitude(double paramDouble) {
    String str;
    if (paramDouble >= 0.0D) {
      str = "0";
    } else {
      str = "1";
    } 
    setAttribute("GPSAltitude", (new Rational(Math.abs(paramDouble))).toString());
    setAttribute("GPSAltitudeRef", str);
  }
  
  public void setAttribute(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_2
    //   1: astore #7
    //   3: ldc_w 'ISOSpeedRatings'
    //   6: aload_1
    //   7: invokevirtual equals : (Ljava/lang/Object;)Z
    //   10: ifeq -> 21
    //   13: ldc_w 'PhotographicSensitivity'
    //   16: astore #6
    //   18: goto -> 24
    //   21: aload_1
    //   22: astore #6
    //   24: ldc_w 'ExifInterface'
    //   27: astore_1
    //   28: aload #7
    //   30: astore #5
    //   32: aload #7
    //   34: ifnull -> 286
    //   37: aload #7
    //   39: astore #5
    //   41: getstatic androidx/exifinterface/media/ExifInterface.sTagSetForCompatibility : Ljava/util/HashSet;
    //   44: aload #6
    //   46: invokevirtual contains : (Ljava/lang/Object;)Z
    //   49: ifeq -> 286
    //   52: aload #6
    //   54: ldc_w 'GPSTimeStamp'
    //   57: invokevirtual equals : (Ljava/lang/Object;)Z
    //   60: ifeq -> 217
    //   63: getstatic androidx/exifinterface/media/ExifInterface.sGpsTimestampPattern : Ljava/util/regex/Pattern;
    //   66: aload #7
    //   68: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   71: astore_2
    //   72: aload_2
    //   73: invokevirtual find : ()Z
    //   76: ifne -> 129
    //   79: new java/lang/StringBuilder
    //   82: dup
    //   83: invokespecial <init> : ()V
    //   86: astore_1
    //   87: aload_1
    //   88: ldc_w 'Invalid value for '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: pop
    //   95: aload_1
    //   96: aload #6
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: pop
    //   102: aload_1
    //   103: ldc_w ' : '
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload_1
    //   111: aload #7
    //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: pop
    //   117: ldc_w 'ExifInterface'
    //   120: aload_1
    //   121: invokevirtual toString : ()Ljava/lang/String;
    //   124: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   127: pop
    //   128: return
    //   129: new java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: astore #5
    //   138: aload #5
    //   140: aload_2
    //   141: iconst_1
    //   142: invokevirtual group : (I)Ljava/lang/String;
    //   145: invokestatic parseInt : (Ljava/lang/String;)I
    //   148: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload #5
    //   154: ldc_w '/1,'
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload #5
    //   163: aload_2
    //   164: iconst_2
    //   165: invokevirtual group : (I)Ljava/lang/String;
    //   168: invokestatic parseInt : (Ljava/lang/String;)I
    //   171: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload #5
    //   177: ldc_w '/1,'
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: aload #5
    //   186: aload_2
    //   187: iconst_3
    //   188: invokevirtual group : (I)Ljava/lang/String;
    //   191: invokestatic parseInt : (Ljava/lang/String;)I
    //   194: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload #5
    //   200: ldc_w '/1'
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload #5
    //   209: invokevirtual toString : ()Ljava/lang/String;
    //   212: astore #5
    //   214: goto -> 286
    //   217: new androidx/exifinterface/media/ExifInterface$Rational
    //   220: dup
    //   221: aload_2
    //   222: invokestatic parseDouble : (Ljava/lang/String;)D
    //   225: invokespecial <init> : (D)V
    //   228: invokevirtual toString : ()Ljava/lang/String;
    //   231: astore #5
    //   233: goto -> 286
    //   236: new java/lang/StringBuilder
    //   239: dup
    //   240: invokespecial <init> : ()V
    //   243: astore_1
    //   244: aload_1
    //   245: ldc_w 'Invalid value for '
    //   248: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: pop
    //   252: aload_1
    //   253: aload #6
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: pop
    //   259: aload_1
    //   260: ldc_w ' : '
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload_1
    //   268: aload #7
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: ldc_w 'ExifInterface'
    //   277: aload_1
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   284: pop
    //   285: return
    //   286: iconst_0
    //   287: istore #4
    //   289: iload #4
    //   291: getstatic androidx/exifinterface/media/ExifInterface.EXIF_TAGS : [[Landroidx/exifinterface/media/ExifInterface$ExifTag;
    //   294: arraylength
    //   295: if_icmpge -> 1374
    //   298: iload #4
    //   300: iconst_4
    //   301: if_icmpne -> 316
    //   304: aload_0
    //   305: getfield mHasThumbnail : Z
    //   308: ifne -> 316
    //   311: aload_1
    //   312: astore_2
    //   313: goto -> 1363
    //   316: getstatic androidx/exifinterface/media/ExifInterface.sExifTagMapsForWriting : [Ljava/util/HashMap;
    //   319: iload #4
    //   321: aaload
    //   322: aload #6
    //   324: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   327: checkcast androidx/exifinterface/media/ExifInterface$ExifTag
    //   330: astore #11
    //   332: aload_1
    //   333: astore_2
    //   334: aload #11
    //   336: ifnull -> 1363
    //   339: aload #5
    //   341: ifnonnull -> 362
    //   344: aload_0
    //   345: getfield mAttributes : [Ljava/util/HashMap;
    //   348: iload #4
    //   350: aaload
    //   351: aload #6
    //   353: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   356: pop
    //   357: aload_1
    //   358: astore_2
    //   359: goto -> 1363
    //   362: aload #5
    //   364: invokestatic guessDataFormat : (Ljava/lang/String;)Landroid/util/Pair;
    //   367: astore #9
    //   369: aload #11
    //   371: getfield primaryFormat : I
    //   374: aload #9
    //   376: getfield first : Ljava/lang/Object;
    //   379: checkcast java/lang/Integer
    //   382: invokevirtual intValue : ()I
    //   385: if_icmpeq -> 754
    //   388: aload #11
    //   390: getfield primaryFormat : I
    //   393: aload #9
    //   395: getfield second : Ljava/lang/Object;
    //   398: checkcast java/lang/Integer
    //   401: invokevirtual intValue : ()I
    //   404: if_icmpne -> 410
    //   407: goto -> 754
    //   410: aload #11
    //   412: getfield secondaryFormat : I
    //   415: iconst_m1
    //   416: if_icmpeq -> 466
    //   419: aload #11
    //   421: getfield secondaryFormat : I
    //   424: aload #9
    //   426: getfield first : Ljava/lang/Object;
    //   429: checkcast java/lang/Integer
    //   432: invokevirtual intValue : ()I
    //   435: if_icmpeq -> 457
    //   438: aload #11
    //   440: getfield secondaryFormat : I
    //   443: aload #9
    //   445: getfield second : Ljava/lang/Object;
    //   448: checkcast java/lang/Integer
    //   451: invokevirtual intValue : ()I
    //   454: if_icmpne -> 466
    //   457: aload #11
    //   459: getfield secondaryFormat : I
    //   462: istore_3
    //   463: goto -> 760
    //   466: aload #11
    //   468: getfield primaryFormat : I
    //   471: iconst_1
    //   472: if_icmpeq -> 745
    //   475: aload #11
    //   477: getfield primaryFormat : I
    //   480: bipush #7
    //   482: if_icmpeq -> 745
    //   485: aload #11
    //   487: getfield primaryFormat : I
    //   490: iconst_2
    //   491: if_icmpne -> 497
    //   494: goto -> 745
    //   497: new java/lang/StringBuilder
    //   500: dup
    //   501: invokespecial <init> : ()V
    //   504: astore #8
    //   506: aload #8
    //   508: ldc_w 'Given tag ('
    //   511: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   514: pop
    //   515: aload #8
    //   517: aload #6
    //   519: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   522: pop
    //   523: aload #8
    //   525: ldc_w ') value didn't match with one of expected '
    //   528: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   531: pop
    //   532: aload #8
    //   534: ldc_w 'formats: '
    //   537: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   540: pop
    //   541: getstatic androidx/exifinterface/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   544: astore #10
    //   546: aload #8
    //   548: aload #10
    //   550: aload #11
    //   552: getfield primaryFormat : I
    //   555: aaload
    //   556: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload #11
    //   562: getfield secondaryFormat : I
    //   565: istore_3
    //   566: ldc_w ''
    //   569: astore #7
    //   571: iload_3
    //   572: iconst_m1
    //   573: if_icmpne -> 583
    //   576: ldc_w ''
    //   579: astore_2
    //   580: goto -> 617
    //   583: new java/lang/StringBuilder
    //   586: dup
    //   587: invokespecial <init> : ()V
    //   590: astore_2
    //   591: aload_2
    //   592: ldc_w ', '
    //   595: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   598: pop
    //   599: aload_2
    //   600: aload #10
    //   602: aload #11
    //   604: getfield secondaryFormat : I
    //   607: aaload
    //   608: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: pop
    //   612: aload_2
    //   613: invokevirtual toString : ()Ljava/lang/String;
    //   616: astore_2
    //   617: aload #8
    //   619: aload_2
    //   620: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   623: pop
    //   624: aload #8
    //   626: ldc_w ' (guess: '
    //   629: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   632: pop
    //   633: aload #8
    //   635: aload #10
    //   637: aload #9
    //   639: getfield first : Ljava/lang/Object;
    //   642: checkcast java/lang/Integer
    //   645: invokevirtual intValue : ()I
    //   648: aaload
    //   649: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   652: pop
    //   653: aload #9
    //   655: getfield second : Ljava/lang/Object;
    //   658: checkcast java/lang/Integer
    //   661: invokevirtual intValue : ()I
    //   664: iconst_m1
    //   665: if_icmpne -> 674
    //   668: aload #7
    //   670: astore_2
    //   671: goto -> 714
    //   674: new java/lang/StringBuilder
    //   677: dup
    //   678: invokespecial <init> : ()V
    //   681: astore_2
    //   682: aload_2
    //   683: ldc_w ', '
    //   686: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   689: pop
    //   690: aload_2
    //   691: aload #10
    //   693: aload #9
    //   695: getfield second : Ljava/lang/Object;
    //   698: checkcast java/lang/Integer
    //   701: invokevirtual intValue : ()I
    //   704: aaload
    //   705: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   708: pop
    //   709: aload_2
    //   710: invokevirtual toString : ()Ljava/lang/String;
    //   713: astore_2
    //   714: aload #8
    //   716: aload_2
    //   717: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   720: pop
    //   721: aload #8
    //   723: ldc_w ')'
    //   726: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   729: pop
    //   730: aload_1
    //   731: aload #8
    //   733: invokevirtual toString : ()Ljava/lang/String;
    //   736: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   739: pop
    //   740: aload_1
    //   741: astore_2
    //   742: goto -> 1363
    //   745: aload #11
    //   747: getfield primaryFormat : I
    //   750: istore_3
    //   751: goto -> 760
    //   754: aload #11
    //   756: getfield primaryFormat : I
    //   759: istore_3
    //   760: iload_3
    //   761: tableswitch default -> 824, 1 -> 1342, 2 -> 1321, 3 -> 1255, 4 -> 1189, 5 -> 1093, 6 -> 824, 7 -> 1321, 8 -> 824, 9 -> 1025, 10 -> 928, 11 -> 824, 12 -> 860
    //   824: new java/lang/StringBuilder
    //   827: dup
    //   828: invokespecial <init> : ()V
    //   831: astore_2
    //   832: aload_2
    //   833: ldc_w 'Data format isn't one of expected formats: '
    //   836: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   839: pop
    //   840: aload_2
    //   841: iload_3
    //   842: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   845: pop
    //   846: aload_2
    //   847: invokevirtual toString : ()Ljava/lang/String;
    //   850: astore_2
    //   851: aload_1
    //   852: aload_2
    //   853: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   856: pop
    //   857: goto -> 1365
    //   860: aload #5
    //   862: ldc_w ','
    //   865: iconst_m1
    //   866: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   869: astore_2
    //   870: aload_2
    //   871: arraylength
    //   872: newarray double
    //   874: astore #7
    //   876: iconst_0
    //   877: istore_3
    //   878: iload_3
    //   879: aload_2
    //   880: arraylength
    //   881: if_icmpge -> 901
    //   884: aload #7
    //   886: iload_3
    //   887: aload_2
    //   888: iload_3
    //   889: aaload
    //   890: invokestatic parseDouble : (Ljava/lang/String;)D
    //   893: dastore
    //   894: iload_3
    //   895: iconst_1
    //   896: iadd
    //   897: istore_3
    //   898: goto -> 878
    //   901: aload_0
    //   902: getfield mAttributes : [Ljava/util/HashMap;
    //   905: iload #4
    //   907: aaload
    //   908: aload #6
    //   910: aload #7
    //   912: aload_0
    //   913: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   916: invokestatic createDouble : ([DLjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   919: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   922: pop
    //   923: aload_1
    //   924: astore_2
    //   925: goto -> 1363
    //   928: aload #5
    //   930: ldc_w ','
    //   933: iconst_m1
    //   934: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   937: astore #7
    //   939: aload #7
    //   941: arraylength
    //   942: anewarray androidx/exifinterface/media/ExifInterface$Rational
    //   945: astore_2
    //   946: iconst_0
    //   947: istore_3
    //   948: iload_3
    //   949: aload #7
    //   951: arraylength
    //   952: if_icmpge -> 1001
    //   955: aload #7
    //   957: iload_3
    //   958: aaload
    //   959: ldc_w '/'
    //   962: iconst_m1
    //   963: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   966: astore #8
    //   968: aload_2
    //   969: iload_3
    //   970: new androidx/exifinterface/media/ExifInterface$Rational
    //   973: dup
    //   974: aload #8
    //   976: iconst_0
    //   977: aaload
    //   978: invokestatic parseDouble : (Ljava/lang/String;)D
    //   981: d2l
    //   982: aload #8
    //   984: iconst_1
    //   985: aaload
    //   986: invokestatic parseDouble : (Ljava/lang/String;)D
    //   989: d2l
    //   990: invokespecial <init> : (JJ)V
    //   993: aastore
    //   994: iload_3
    //   995: iconst_1
    //   996: iadd
    //   997: istore_3
    //   998: goto -> 948
    //   1001: aload_0
    //   1002: getfield mAttributes : [Ljava/util/HashMap;
    //   1005: iload #4
    //   1007: aaload
    //   1008: aload #6
    //   1010: aload_2
    //   1011: aload_0
    //   1012: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1015: invokestatic createSRational : ([Landroidx/exifinterface/media/ExifInterface$Rational;Ljava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1018: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1021: pop
    //   1022: goto -> 1088
    //   1025: aload #5
    //   1027: ldc_w ','
    //   1030: iconst_m1
    //   1031: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1034: astore_2
    //   1035: aload_2
    //   1036: arraylength
    //   1037: newarray int
    //   1039: astore #7
    //   1041: iconst_0
    //   1042: istore_3
    //   1043: iload_3
    //   1044: aload_2
    //   1045: arraylength
    //   1046: if_icmpge -> 1066
    //   1049: aload #7
    //   1051: iload_3
    //   1052: aload_2
    //   1053: iload_3
    //   1054: aaload
    //   1055: invokestatic parseInt : (Ljava/lang/String;)I
    //   1058: iastore
    //   1059: iload_3
    //   1060: iconst_1
    //   1061: iadd
    //   1062: istore_3
    //   1063: goto -> 1043
    //   1066: aload_0
    //   1067: getfield mAttributes : [Ljava/util/HashMap;
    //   1070: iload #4
    //   1072: aaload
    //   1073: aload #6
    //   1075: aload #7
    //   1077: aload_0
    //   1078: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1081: invokestatic createSLong : ([ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1084: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1087: pop
    //   1088: aload_1
    //   1089: astore_2
    //   1090: goto -> 1363
    //   1093: aload #5
    //   1095: ldc_w ','
    //   1098: iconst_m1
    //   1099: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1102: astore_2
    //   1103: aload_2
    //   1104: arraylength
    //   1105: anewarray androidx/exifinterface/media/ExifInterface$Rational
    //   1108: astore #7
    //   1110: iconst_0
    //   1111: istore_3
    //   1112: iload_3
    //   1113: aload_2
    //   1114: arraylength
    //   1115: if_icmpge -> 1164
    //   1118: aload_2
    //   1119: iload_3
    //   1120: aaload
    //   1121: ldc_w '/'
    //   1124: iconst_m1
    //   1125: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1128: astore #8
    //   1130: aload #7
    //   1132: iload_3
    //   1133: new androidx/exifinterface/media/ExifInterface$Rational
    //   1136: dup
    //   1137: aload #8
    //   1139: iconst_0
    //   1140: aaload
    //   1141: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1144: d2l
    //   1145: aload #8
    //   1147: iconst_1
    //   1148: aaload
    //   1149: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1152: d2l
    //   1153: invokespecial <init> : (JJ)V
    //   1156: aastore
    //   1157: iload_3
    //   1158: iconst_1
    //   1159: iadd
    //   1160: istore_3
    //   1161: goto -> 1112
    //   1164: aload_0
    //   1165: getfield mAttributes : [Ljava/util/HashMap;
    //   1168: iload #4
    //   1170: aaload
    //   1171: aload #6
    //   1173: aload #7
    //   1175: aload_0
    //   1176: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1179: invokestatic createURational : ([Landroidx/exifinterface/media/ExifInterface$Rational;Ljava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1182: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1185: pop
    //   1186: goto -> 1360
    //   1189: aload #5
    //   1191: ldc_w ','
    //   1194: iconst_m1
    //   1195: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1198: astore_2
    //   1199: aload_2
    //   1200: arraylength
    //   1201: newarray long
    //   1203: astore #7
    //   1205: iconst_0
    //   1206: istore_3
    //   1207: iload_3
    //   1208: aload_2
    //   1209: arraylength
    //   1210: if_icmpge -> 1230
    //   1213: aload #7
    //   1215: iload_3
    //   1216: aload_2
    //   1217: iload_3
    //   1218: aaload
    //   1219: invokestatic parseLong : (Ljava/lang/String;)J
    //   1222: lastore
    //   1223: iload_3
    //   1224: iconst_1
    //   1225: iadd
    //   1226: istore_3
    //   1227: goto -> 1207
    //   1230: aload_0
    //   1231: getfield mAttributes : [Ljava/util/HashMap;
    //   1234: iload #4
    //   1236: aaload
    //   1237: aload #6
    //   1239: aload #7
    //   1241: aload_0
    //   1242: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1245: invokestatic createULong : ([JLjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1248: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1251: pop
    //   1252: goto -> 1360
    //   1255: aload #5
    //   1257: ldc_w ','
    //   1260: iconst_m1
    //   1261: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   1264: astore_2
    //   1265: aload_2
    //   1266: arraylength
    //   1267: newarray int
    //   1269: astore #7
    //   1271: iconst_0
    //   1272: istore_3
    //   1273: iload_3
    //   1274: aload_2
    //   1275: arraylength
    //   1276: if_icmpge -> 1296
    //   1279: aload #7
    //   1281: iload_3
    //   1282: aload_2
    //   1283: iload_3
    //   1284: aaload
    //   1285: invokestatic parseInt : (Ljava/lang/String;)I
    //   1288: iastore
    //   1289: iload_3
    //   1290: iconst_1
    //   1291: iadd
    //   1292: istore_3
    //   1293: goto -> 1273
    //   1296: aload_0
    //   1297: getfield mAttributes : [Ljava/util/HashMap;
    //   1300: iload #4
    //   1302: aaload
    //   1303: aload #6
    //   1305: aload #7
    //   1307: aload_0
    //   1308: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1311: invokestatic createUShort : ([ILjava/nio/ByteOrder;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1314: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1317: pop
    //   1318: goto -> 1360
    //   1321: aload_0
    //   1322: getfield mAttributes : [Ljava/util/HashMap;
    //   1325: iload #4
    //   1327: aaload
    //   1328: aload #6
    //   1330: aload #5
    //   1332: invokestatic createString : (Ljava/lang/String;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1335: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1338: pop
    //   1339: goto -> 1360
    //   1342: aload_0
    //   1343: getfield mAttributes : [Ljava/util/HashMap;
    //   1346: iload #4
    //   1348: aaload
    //   1349: aload #6
    //   1351: aload #5
    //   1353: invokestatic createByte : (Ljava/lang/String;)Landroidx/exifinterface/media/ExifInterface$ExifAttribute;
    //   1356: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1359: pop
    //   1360: goto -> 1365
    //   1363: aload_2
    //   1364: astore_1
    //   1365: iload #4
    //   1367: iconst_1
    //   1368: iadd
    //   1369: istore #4
    //   1371: goto -> 289
    //   1374: return
    //   1375: astore_1
    //   1376: goto -> 236
    // Exception table:
    //   from	to	target	type
    //   217	233	1375	java/lang/NumberFormatException
  }
  
  public void setDateTime(long paramLong) {
    setAttribute("DateTime", sFormatter.format(new Date(paramLong)));
    setAttribute("SubSecTime", Long.toString(paramLong % 1000L));
  }
  
  public void setGpsInfo(Location paramLocation) {
    if (paramLocation == null)
      return; 
    setAttribute("GPSProcessingMethod", paramLocation.getProvider());
    setLatLong(paramLocation.getLatitude(), paramLocation.getLongitude());
    setAltitude(paramLocation.getAltitude());
    setAttribute("GPSSpeedRef", "K");
    setAttribute("GPSSpeed", (new Rational((paramLocation.getSpeed() * (float)TimeUnit.HOURS.toSeconds(1L) / 1000.0F))).toString());
    String[] arrayOfString = sFormatter.format(new Date(paramLocation.getTime())).split("\\s+", -1);
    setAttribute("GPSDateStamp", arrayOfString[0]);
    setAttribute("GPSTimeStamp", arrayOfString[1]);
  }
  
  public void setLatLong(double paramDouble1, double paramDouble2) {
    if (paramDouble1 >= -90.0D && paramDouble1 <= 90.0D && !Double.isNaN(paramDouble1)) {
      if (paramDouble2 >= -180.0D && paramDouble2 <= 180.0D && !Double.isNaN(paramDouble2)) {
        String str;
        if (paramDouble1 >= 0.0D) {
          str = "N";
        } else {
          str = "S";
        } 
        setAttribute("GPSLatitudeRef", str);
        setAttribute("GPSLatitude", convertDecimalDegree(Math.abs(paramDouble1)));
        if (paramDouble2 >= 0.0D) {
          str = "E";
        } else {
          str = "W";
        } 
        setAttribute("GPSLongitudeRef", str);
        setAttribute("GPSLongitude", convertDecimalDegree(Math.abs(paramDouble2)));
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Longitude value ");
      stringBuilder1.append(paramDouble2);
      stringBuilder1.append(" is not valid.");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Latitude value ");
    stringBuilder.append(paramDouble1);
    stringBuilder.append(" is not valid.");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static class ByteOrderedDataInputStream extends InputStream implements DataInput {
    private static final ByteOrder BIG_ENDIAN = ByteOrder.BIG_ENDIAN;
    
    private static final ByteOrder LITTLE_ENDIAN = ByteOrder.LITTLE_ENDIAN;
    
    private ByteOrder mByteOrder = ByteOrder.BIG_ENDIAN;
    
    private DataInputStream mDataInputStream;
    
    final int mLength;
    
    int mPosition;
    
    static {
    
    }
    
    public ByteOrderedDataInputStream(InputStream param1InputStream) throws IOException {
      param1InputStream = new DataInputStream(param1InputStream);
      this.mDataInputStream = (DataInputStream)param1InputStream;
      int i = param1InputStream.available();
      this.mLength = i;
      this.mPosition = 0;
      this.mDataInputStream.mark(i);
    }
    
    public ByteOrderedDataInputStream(byte[] param1ArrayOfbyte) throws IOException {
      this(new ByteArrayInputStream(param1ArrayOfbyte));
    }
    
    public int available() throws IOException {
      return this.mDataInputStream.available();
    }
    
    public int peek() {
      return this.mPosition;
    }
    
    public int read() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.read();
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      param1Int1 = this.mDataInputStream.read(param1ArrayOfbyte, param1Int1, param1Int2);
      this.mPosition += param1Int1;
      return param1Int1;
    }
    
    public boolean readBoolean() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.readBoolean();
    }
    
    public byte readByte() throws IOException {
      int i = this.mPosition + 1;
      this.mPosition = i;
      if (i <= this.mLength) {
        i = this.mDataInputStream.read();
        if (i >= 0)
          return (byte)i; 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public char readChar() throws IOException {
      this.mPosition += 2;
      return this.mDataInputStream.readChar();
    }
    
    public double readDouble() throws IOException {
      return Double.longBitsToDouble(readLong());
    }
    
    public float readFloat() throws IOException {
      return Float.intBitsToFloat(readInt());
    }
    
    public void readFully(byte[] param1ArrayOfbyte) throws IOException {
      int i = this.mPosition + param1ArrayOfbyte.length;
      this.mPosition = i;
      if (i <= this.mLength) {
        if (this.mDataInputStream.read(param1ArrayOfbyte, 0, param1ArrayOfbyte.length) == param1ArrayOfbyte.length)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public void readFully(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      int i = this.mPosition + param1Int2;
      this.mPosition = i;
      if (i <= this.mLength) {
        if (this.mDataInputStream.read(param1ArrayOfbyte, param1Int1, param1Int2) == param1Int2)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public int readInt() throws IOException {
      int i = this.mPosition + 4;
      this.mPosition = i;
      if (i <= this.mLength) {
        i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        int k = this.mDataInputStream.read();
        int m = this.mDataInputStream.read();
        if ((i | j | k | m) >= 0) {
          ByteOrder byteOrder = this.mByteOrder;
          if (byteOrder == LITTLE_ENDIAN)
            return (m << 24) + (k << 16) + (j << 8) + i; 
          if (byteOrder == BIG_ENDIAN)
            return (i << 24) + (j << 16) + (k << 8) + m; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readLine() throws IOException {
      Log.d("ExifInterface", "Currently unsupported");
      return null;
    }
    
    public long readLong() throws IOException {
      int i = this.mPosition + 8;
      this.mPosition = i;
      if (i <= this.mLength) {
        i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        int k = this.mDataInputStream.read();
        int m = this.mDataInputStream.read();
        int n = this.mDataInputStream.read();
        int i1 = this.mDataInputStream.read();
        int i2 = this.mDataInputStream.read();
        int i3 = this.mDataInputStream.read();
        if ((i | j | k | m | n | i1 | i2 | i3) >= 0) {
          ByteOrder byteOrder = this.mByteOrder;
          if (byteOrder == LITTLE_ENDIAN)
            return (i3 << 56L) + (i2 << 48L) + (i1 << 40L) + (n << 32L) + (m << 24L) + (k << 16L) + (j << 8L) + i; 
          if (byteOrder == BIG_ENDIAN)
            return (i << 56L) + (j << 48L) + (k << 40L) + (m << 32L) + (n << 24L) + (i1 << 16L) + (i2 << 8L) + i3; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public short readShort() throws IOException {
      int i = this.mPosition + 2;
      this.mPosition = i;
      if (i <= this.mLength) {
        i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        if ((i | j) >= 0) {
          ByteOrder byteOrder = this.mByteOrder;
          if (byteOrder == LITTLE_ENDIAN)
            return (short)((j << 8) + i); 
          if (byteOrder == BIG_ENDIAN)
            return (short)((i << 8) + j); 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readUTF() throws IOException {
      this.mPosition += 2;
      return this.mDataInputStream.readUTF();
    }
    
    public int readUnsignedByte() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.readUnsignedByte();
    }
    
    public long readUnsignedInt() throws IOException {
      return readInt() & 0xFFFFFFFFL;
    }
    
    public int readUnsignedShort() throws IOException {
      int i = this.mPosition + 2;
      this.mPosition = i;
      if (i <= this.mLength) {
        i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        if ((i | j) >= 0) {
          ByteOrder byteOrder = this.mByteOrder;
          if (byteOrder == LITTLE_ENDIAN)
            return (j << 8) + i; 
          if (byteOrder == BIG_ENDIAN)
            return (i << 8) + j; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public void seek(long param1Long) throws IOException {
      int i = this.mPosition;
      if (i > param1Long) {
        this.mPosition = 0;
        this.mDataInputStream.reset();
        this.mDataInputStream.mark(this.mLength);
      } else {
        param1Long -= i;
      } 
      i = (int)param1Long;
      if (skipBytes(i) == i)
        return; 
      throw new IOException("Couldn't seek up to the byteCount");
    }
    
    public void setByteOrder(ByteOrder param1ByteOrder) {
      this.mByteOrder = param1ByteOrder;
    }
    
    public int skipBytes(int param1Int) throws IOException {
      int i = Math.min(param1Int, this.mLength - this.mPosition);
      for (param1Int = 0; param1Int < i; param1Int += this.mDataInputStream.skipBytes(i - param1Int));
      this.mPosition += param1Int;
      return param1Int;
    }
  }
  
  private static class ByteOrderedDataOutputStream extends FilterOutputStream {
    private ByteOrder mByteOrder;
    
    private final OutputStream mOutputStream;
    
    public ByteOrderedDataOutputStream(OutputStream param1OutputStream, ByteOrder param1ByteOrder) {
      super(param1OutputStream);
      this.mOutputStream = param1OutputStream;
      this.mByteOrder = param1ByteOrder;
    }
    
    public void setByteOrder(ByteOrder param1ByteOrder) {
      this.mByteOrder = param1ByteOrder;
    }
    
    public void write(byte[] param1ArrayOfbyte) throws IOException {
      this.mOutputStream.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      this.mOutputStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public void writeByte(int param1Int) throws IOException {
      this.mOutputStream.write(param1Int);
    }
    
    public void writeInt(int param1Int) throws IOException {
      if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.mOutputStream.write(param1Int >>> 0 & 0xFF);
        this.mOutputStream.write(param1Int >>> 8 & 0xFF);
        this.mOutputStream.write(param1Int >>> 16 & 0xFF);
        this.mOutputStream.write(param1Int >>> 24 & 0xFF);
        return;
      } 
      if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
        this.mOutputStream.write(param1Int >>> 24 & 0xFF);
        this.mOutputStream.write(param1Int >>> 16 & 0xFF);
        this.mOutputStream.write(param1Int >>> 8 & 0xFF);
        this.mOutputStream.write(param1Int >>> 0 & 0xFF);
      } 
    }
    
    public void writeShort(short param1Short) throws IOException {
      if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.mOutputStream.write(param1Short >>> 0 & 0xFF);
        this.mOutputStream.write(param1Short >>> 8 & 0xFF);
        return;
      } 
      if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
        this.mOutputStream.write(param1Short >>> 8 & 0xFF);
        this.mOutputStream.write(param1Short >>> 0 & 0xFF);
      } 
    }
    
    public void writeUnsignedInt(long param1Long) throws IOException {
      writeInt((int)param1Long);
    }
    
    public void writeUnsignedShort(int param1Int) throws IOException {
      writeShort((short)param1Int);
    }
  }
  
  private static class ExifAttribute {
    public final byte[] bytes;
    
    public final int format;
    
    public final int numberOfComponents;
    
    ExifAttribute(int param1Int1, int param1Int2, byte[] param1ArrayOfbyte) {
      this.format = param1Int1;
      this.numberOfComponents = param1Int2;
      this.bytes = param1ArrayOfbyte;
    }
    
    public static ExifAttribute createByte(String param1String) {
      if (param1String.length() == 1 && param1String.charAt(0) >= '0' && param1String.charAt(0) <= '1')
        return new ExifAttribute(1, 1, new byte[] { (byte)(param1String.charAt(0) - 48) }); 
      byte[] arrayOfByte = param1String.getBytes(ExifInterface.ASCII);
      return new ExifAttribute(1, arrayOfByte.length, arrayOfByte);
    }
    
    public static ExifAttribute createDouble(double param1Double, ByteOrder param1ByteOrder) {
      return createDouble(new double[] { param1Double }, param1ByteOrder);
    }
    
    public static ExifAttribute createDouble(double[] param1ArrayOfdouble, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[12] * param1ArrayOfdouble.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfdouble.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putDouble(param1ArrayOfdouble[i]); 
      return new ExifAttribute(12, param1ArrayOfdouble.length, byteBuffer.array());
    }
    
    public static ExifAttribute createSLong(int param1Int, ByteOrder param1ByteOrder) {
      return createSLong(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static ExifAttribute createSLong(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[9] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt(param1ArrayOfint[i]); 
      return new ExifAttribute(9, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public static ExifAttribute createSRational(ExifInterface.Rational param1Rational, ByteOrder param1ByteOrder) {
      return createSRational(new ExifInterface.Rational[] { param1Rational }, param1ByteOrder);
    }
    
    public static ExifAttribute createSRational(ExifInterface.Rational[] param1ArrayOfRational, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[10] * param1ArrayOfRational.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfRational.length;
      for (int i = 0; i < j; i++) {
        ExifInterface.Rational rational = param1ArrayOfRational[i];
        byteBuffer.putInt((int)rational.numerator);
        byteBuffer.putInt((int)rational.denominator);
      } 
      return new ExifAttribute(10, param1ArrayOfRational.length, byteBuffer.array());
    }
    
    public static ExifAttribute createString(String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append(false);
      byte[] arrayOfByte = stringBuilder.toString().getBytes(ExifInterface.ASCII);
      return new ExifAttribute(2, arrayOfByte.length, arrayOfByte);
    }
    
    public static ExifAttribute createULong(long param1Long, ByteOrder param1ByteOrder) {
      return createULong(new long[] { param1Long }, param1ByteOrder);
    }
    
    public static ExifAttribute createULong(long[] param1ArrayOflong, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[4] * param1ArrayOflong.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOflong.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt((int)param1ArrayOflong[i]); 
      return new ExifAttribute(4, param1ArrayOflong.length, byteBuffer.array());
    }
    
    public static ExifAttribute createURational(ExifInterface.Rational param1Rational, ByteOrder param1ByteOrder) {
      return createURational(new ExifInterface.Rational[] { param1Rational }, param1ByteOrder);
    }
    
    public static ExifAttribute createURational(ExifInterface.Rational[] param1ArrayOfRational, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[5] * param1ArrayOfRational.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfRational.length;
      for (int i = 0; i < j; i++) {
        ExifInterface.Rational rational = param1ArrayOfRational[i];
        byteBuffer.putInt((int)rational.numerator);
        byteBuffer.putInt((int)rational.denominator);
      } 
      return new ExifAttribute(5, param1ArrayOfRational.length, byteBuffer.array());
    }
    
    public static ExifAttribute createUShort(int param1Int, ByteOrder param1ByteOrder) {
      return createUShort(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static ExifAttribute createUShort(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[3] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putShort((short)param1ArrayOfint[i]); 
      return new ExifAttribute(3, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public double getDoubleValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Double.parseDouble((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof double[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof ExifInterface.Rational[]) {
          object = object;
          if (object.length == 1)
            return object[0].calculate(); 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a double value");
      } 
      throw new NumberFormatException("NULL can't be converted to a double value");
    }
    
    public int getIntValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Integer.parseInt((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return (int)object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a integer value");
      } 
      throw new NumberFormatException("NULL can't be converted to a integer value");
    }
    
    public String getStringValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object == null)
        return null; 
      if (object instanceof String)
        return (String)object; 
      StringBuilder stringBuilder = new StringBuilder();
      boolean bool = object instanceof long[];
      int j = 0;
      boolean bool1 = false;
      boolean bool2 = false;
      int i = 0;
      if (bool) {
        object = object;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof int[]) {
        object = object;
        i = j;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof double[]) {
        object = object;
        i = bool1;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof ExifInterface.Rational[]) {
        object = object;
        i = bool2;
        while (i < object.length) {
          stringBuilder.append(((ExifInterface.Rational)object[i]).numerator);
          stringBuilder.append('/');
          stringBuilder.append(((ExifInterface.Rational)object[i]).denominator);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      return null;
    }
    
    Object getValue(ByteOrder param1ByteOrder) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #13
      //   3: new androidx/exifinterface/media/ExifInterface$ByteOrderedDataInputStream
      //   6: dup
      //   7: aload_0
      //   8: getfield bytes : [B
      //   11: invokespecial <init> : ([B)V
      //   14: astore #14
      //   16: aload #14
      //   18: astore #13
      //   20: aload #14
      //   22: aload_1
      //   23: invokevirtual setByteOrder : (Ljava/nio/ByteOrder;)V
      //   26: aload #14
      //   28: astore #13
      //   30: aload_0
      //   31: getfield format : I
      //   34: istore #12
      //   36: iconst_1
      //   37: istore #5
      //   39: iconst_0
      //   40: istore_3
      //   41: iconst_0
      //   42: istore #6
      //   44: iconst_0
      //   45: istore #7
      //   47: iconst_0
      //   48: istore #8
      //   50: iconst_0
      //   51: istore #9
      //   53: iconst_0
      //   54: istore #10
      //   56: iconst_0
      //   57: istore #11
      //   59: iconst_0
      //   60: istore #4
      //   62: iconst_0
      //   63: istore_2
      //   64: iload #12
      //   66: tableswitch default -> 1084, 1 -> 861, 2 -> 681, 3 -> 615, 4 -> 549, 5 -> 470, 6 -> 861, 7 -> 681, 8 -> 404, 9 -> 338, 10 -> 257, 11 -> 191, 12 -> 128
      //   128: aload #14
      //   130: astore #13
      //   132: aload_0
      //   133: getfield numberOfComponents : I
      //   136: newarray double
      //   138: astore_1
      //   139: aload #14
      //   141: astore #13
      //   143: iload_2
      //   144: aload_0
      //   145: getfield numberOfComponents : I
      //   148: if_icmpge -> 170
      //   151: aload #14
      //   153: astore #13
      //   155: aload_1
      //   156: iload_2
      //   157: aload #14
      //   159: invokevirtual readDouble : ()D
      //   162: dastore
      //   163: iload_2
      //   164: iconst_1
      //   165: iadd
      //   166: istore_2
      //   167: goto -> 139
      //   170: aload #14
      //   172: invokevirtual close : ()V
      //   175: aload_1
      //   176: areturn
      //   177: astore #13
      //   179: ldc 'ExifInterface'
      //   181: ldc 'IOException occurred while closing InputStream'
      //   183: aload #13
      //   185: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   188: pop
      //   189: aload_1
      //   190: areturn
      //   191: aload #14
      //   193: astore #13
      //   195: aload_0
      //   196: getfield numberOfComponents : I
      //   199: newarray double
      //   201: astore_1
      //   202: iload_3
      //   203: istore_2
      //   204: aload #14
      //   206: astore #13
      //   208: iload_2
      //   209: aload_0
      //   210: getfield numberOfComponents : I
      //   213: if_icmpge -> 236
      //   216: aload #14
      //   218: astore #13
      //   220: aload_1
      //   221: iload_2
      //   222: aload #14
      //   224: invokevirtual readFloat : ()F
      //   227: f2d
      //   228: dastore
      //   229: iload_2
      //   230: iconst_1
      //   231: iadd
      //   232: istore_2
      //   233: goto -> 204
      //   236: aload #14
      //   238: invokevirtual close : ()V
      //   241: aload_1
      //   242: areturn
      //   243: astore #13
      //   245: ldc 'ExifInterface'
      //   247: ldc 'IOException occurred while closing InputStream'
      //   249: aload #13
      //   251: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   254: pop
      //   255: aload_1
      //   256: areturn
      //   257: aload #14
      //   259: astore #13
      //   261: aload_0
      //   262: getfield numberOfComponents : I
      //   265: anewarray androidx/exifinterface/media/ExifInterface$Rational
      //   268: astore_1
      //   269: iload #6
      //   271: istore_2
      //   272: aload #14
      //   274: astore #13
      //   276: iload_2
      //   277: aload_0
      //   278: getfield numberOfComponents : I
      //   281: if_icmpge -> 317
      //   284: aload #14
      //   286: astore #13
      //   288: aload_1
      //   289: iload_2
      //   290: new androidx/exifinterface/media/ExifInterface$Rational
      //   293: dup
      //   294: aload #14
      //   296: invokevirtual readInt : ()I
      //   299: i2l
      //   300: aload #14
      //   302: invokevirtual readInt : ()I
      //   305: i2l
      //   306: invokespecial <init> : (JJ)V
      //   309: aastore
      //   310: iload_2
      //   311: iconst_1
      //   312: iadd
      //   313: istore_2
      //   314: goto -> 272
      //   317: aload #14
      //   319: invokevirtual close : ()V
      //   322: aload_1
      //   323: areturn
      //   324: astore #13
      //   326: ldc 'ExifInterface'
      //   328: ldc 'IOException occurred while closing InputStream'
      //   330: aload #13
      //   332: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   335: pop
      //   336: aload_1
      //   337: areturn
      //   338: aload #14
      //   340: astore #13
      //   342: aload_0
      //   343: getfield numberOfComponents : I
      //   346: newarray int
      //   348: astore_1
      //   349: iload #7
      //   351: istore_2
      //   352: aload #14
      //   354: astore #13
      //   356: iload_2
      //   357: aload_0
      //   358: getfield numberOfComponents : I
      //   361: if_icmpge -> 383
      //   364: aload #14
      //   366: astore #13
      //   368: aload_1
      //   369: iload_2
      //   370: aload #14
      //   372: invokevirtual readInt : ()I
      //   375: iastore
      //   376: iload_2
      //   377: iconst_1
      //   378: iadd
      //   379: istore_2
      //   380: goto -> 352
      //   383: aload #14
      //   385: invokevirtual close : ()V
      //   388: aload_1
      //   389: areturn
      //   390: astore #13
      //   392: ldc 'ExifInterface'
      //   394: ldc 'IOException occurred while closing InputStream'
      //   396: aload #13
      //   398: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   401: pop
      //   402: aload_1
      //   403: areturn
      //   404: aload #14
      //   406: astore #13
      //   408: aload_0
      //   409: getfield numberOfComponents : I
      //   412: newarray int
      //   414: astore_1
      //   415: iload #8
      //   417: istore_2
      //   418: aload #14
      //   420: astore #13
      //   422: iload_2
      //   423: aload_0
      //   424: getfield numberOfComponents : I
      //   427: if_icmpge -> 449
      //   430: aload #14
      //   432: astore #13
      //   434: aload_1
      //   435: iload_2
      //   436: aload #14
      //   438: invokevirtual readShort : ()S
      //   441: iastore
      //   442: iload_2
      //   443: iconst_1
      //   444: iadd
      //   445: istore_2
      //   446: goto -> 418
      //   449: aload #14
      //   451: invokevirtual close : ()V
      //   454: aload_1
      //   455: areturn
      //   456: astore #13
      //   458: ldc 'ExifInterface'
      //   460: ldc 'IOException occurred while closing InputStream'
      //   462: aload #13
      //   464: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   467: pop
      //   468: aload_1
      //   469: areturn
      //   470: aload #14
      //   472: astore #13
      //   474: aload_0
      //   475: getfield numberOfComponents : I
      //   478: anewarray androidx/exifinterface/media/ExifInterface$Rational
      //   481: astore_1
      //   482: iload #9
      //   484: istore_2
      //   485: aload #14
      //   487: astore #13
      //   489: iload_2
      //   490: aload_0
      //   491: getfield numberOfComponents : I
      //   494: if_icmpge -> 528
      //   497: aload #14
      //   499: astore #13
      //   501: aload_1
      //   502: iload_2
      //   503: new androidx/exifinterface/media/ExifInterface$Rational
      //   506: dup
      //   507: aload #14
      //   509: invokevirtual readUnsignedInt : ()J
      //   512: aload #14
      //   514: invokevirtual readUnsignedInt : ()J
      //   517: invokespecial <init> : (JJ)V
      //   520: aastore
      //   521: iload_2
      //   522: iconst_1
      //   523: iadd
      //   524: istore_2
      //   525: goto -> 485
      //   528: aload #14
      //   530: invokevirtual close : ()V
      //   533: aload_1
      //   534: areturn
      //   535: astore #13
      //   537: ldc 'ExifInterface'
      //   539: ldc 'IOException occurred while closing InputStream'
      //   541: aload #13
      //   543: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   546: pop
      //   547: aload_1
      //   548: areturn
      //   549: aload #14
      //   551: astore #13
      //   553: aload_0
      //   554: getfield numberOfComponents : I
      //   557: newarray long
      //   559: astore_1
      //   560: iload #10
      //   562: istore_2
      //   563: aload #14
      //   565: astore #13
      //   567: iload_2
      //   568: aload_0
      //   569: getfield numberOfComponents : I
      //   572: if_icmpge -> 594
      //   575: aload #14
      //   577: astore #13
      //   579: aload_1
      //   580: iload_2
      //   581: aload #14
      //   583: invokevirtual readUnsignedInt : ()J
      //   586: lastore
      //   587: iload_2
      //   588: iconst_1
      //   589: iadd
      //   590: istore_2
      //   591: goto -> 563
      //   594: aload #14
      //   596: invokevirtual close : ()V
      //   599: aload_1
      //   600: areturn
      //   601: astore #13
      //   603: ldc 'ExifInterface'
      //   605: ldc 'IOException occurred while closing InputStream'
      //   607: aload #13
      //   609: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   612: pop
      //   613: aload_1
      //   614: areturn
      //   615: aload #14
      //   617: astore #13
      //   619: aload_0
      //   620: getfield numberOfComponents : I
      //   623: newarray int
      //   625: astore_1
      //   626: iload #11
      //   628: istore_2
      //   629: aload #14
      //   631: astore #13
      //   633: iload_2
      //   634: aload_0
      //   635: getfield numberOfComponents : I
      //   638: if_icmpge -> 660
      //   641: aload #14
      //   643: astore #13
      //   645: aload_1
      //   646: iload_2
      //   647: aload #14
      //   649: invokevirtual readUnsignedShort : ()I
      //   652: iastore
      //   653: iload_2
      //   654: iconst_1
      //   655: iadd
      //   656: istore_2
      //   657: goto -> 629
      //   660: aload #14
      //   662: invokevirtual close : ()V
      //   665: aload_1
      //   666: areturn
      //   667: astore #13
      //   669: ldc 'ExifInterface'
      //   671: ldc 'IOException occurred while closing InputStream'
      //   673: aload #13
      //   675: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   678: pop
      //   679: aload_1
      //   680: areturn
      //   681: iload #4
      //   683: istore_2
      //   684: aload #14
      //   686: astore #13
      //   688: aload_0
      //   689: getfield numberOfComponents : I
      //   692: getstatic androidx/exifinterface/media/ExifInterface.EXIF_ASCII_PREFIX : [B
      //   695: arraylength
      //   696: if_icmplt -> 755
      //   699: iconst_0
      //   700: istore_2
      //   701: iload #5
      //   703: istore_3
      //   704: aload #14
      //   706: astore #13
      //   708: iload_2
      //   709: getstatic androidx/exifinterface/media/ExifInterface.EXIF_ASCII_PREFIX : [B
      //   712: arraylength
      //   713: if_icmpge -> 739
      //   716: aload #14
      //   718: astore #13
      //   720: aload_0
      //   721: getfield bytes : [B
      //   724: iload_2
      //   725: baload
      //   726: getstatic androidx/exifinterface/media/ExifInterface.EXIF_ASCII_PREFIX : [B
      //   729: iload_2
      //   730: baload
      //   731: if_icmpeq -> 1087
      //   734: iconst_0
      //   735: istore_3
      //   736: goto -> 739
      //   739: iload #4
      //   741: istore_2
      //   742: iload_3
      //   743: ifeq -> 755
      //   746: aload #14
      //   748: astore #13
      //   750: getstatic androidx/exifinterface/media/ExifInterface.EXIF_ASCII_PREFIX : [B
      //   753: arraylength
      //   754: istore_2
      //   755: aload #14
      //   757: astore #13
      //   759: new java/lang/StringBuilder
      //   762: dup
      //   763: invokespecial <init> : ()V
      //   766: astore_1
      //   767: aload #14
      //   769: astore #13
      //   771: iload_2
      //   772: aload_0
      //   773: getfield numberOfComponents : I
      //   776: if_icmpge -> 831
      //   779: aload #14
      //   781: astore #13
      //   783: aload_0
      //   784: getfield bytes : [B
      //   787: iload_2
      //   788: baload
      //   789: istore_3
      //   790: iload_3
      //   791: ifne -> 797
      //   794: goto -> 831
      //   797: iload_3
      //   798: bipush #32
      //   800: if_icmplt -> 817
      //   803: aload #14
      //   805: astore #13
      //   807: aload_1
      //   808: iload_3
      //   809: i2c
      //   810: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   813: pop
      //   814: goto -> 1094
      //   817: aload #14
      //   819: astore #13
      //   821: aload_1
      //   822: bipush #63
      //   824: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   827: pop
      //   828: goto -> 1094
      //   831: aload #14
      //   833: astore #13
      //   835: aload_1
      //   836: invokevirtual toString : ()Ljava/lang/String;
      //   839: astore_1
      //   840: aload #14
      //   842: invokevirtual close : ()V
      //   845: aload_1
      //   846: areturn
      //   847: astore #13
      //   849: ldc 'ExifInterface'
      //   851: ldc 'IOException occurred while closing InputStream'
      //   853: aload #13
      //   855: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   858: pop
      //   859: aload_1
      //   860: areturn
      //   861: aload #14
      //   863: astore #13
      //   865: aload_0
      //   866: getfield bytes : [B
      //   869: astore_1
      //   870: aload #14
      //   872: astore #13
      //   874: aload_1
      //   875: arraylength
      //   876: iconst_1
      //   877: if_icmpne -> 939
      //   880: aload_1
      //   881: iconst_0
      //   882: baload
      //   883: iflt -> 939
      //   886: aload_1
      //   887: iconst_0
      //   888: baload
      //   889: iconst_1
      //   890: if_icmpgt -> 939
      //   893: aload #14
      //   895: astore #13
      //   897: new java/lang/String
      //   900: dup
      //   901: iconst_1
      //   902: newarray char
      //   904: dup
      //   905: iconst_0
      //   906: aload_1
      //   907: iconst_0
      //   908: baload
      //   909: bipush #48
      //   911: iadd
      //   912: i2c
      //   913: castore
      //   914: invokespecial <init> : ([C)V
      //   917: astore_1
      //   918: aload #14
      //   920: invokevirtual close : ()V
      //   923: aload_1
      //   924: areturn
      //   925: astore #13
      //   927: ldc 'ExifInterface'
      //   929: ldc 'IOException occurred while closing InputStream'
      //   931: aload #13
      //   933: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   936: pop
      //   937: aload_1
      //   938: areturn
      //   939: aload #14
      //   941: astore #13
      //   943: new java/lang/String
      //   946: dup
      //   947: aload_1
      //   948: getstatic androidx/exifinterface/media/ExifInterface.ASCII : Ljava/nio/charset/Charset;
      //   951: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
      //   954: astore_1
      //   955: aload #14
      //   957: invokevirtual close : ()V
      //   960: aload_1
      //   961: areturn
      //   962: astore #13
      //   964: ldc 'ExifInterface'
      //   966: ldc 'IOException occurred while closing InputStream'
      //   968: aload #13
      //   970: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   973: pop
      //   974: aload_1
      //   975: areturn
      //   976: aload #14
      //   978: invokevirtual close : ()V
      //   981: aconst_null
      //   982: areturn
      //   983: astore_1
      //   984: ldc 'ExifInterface'
      //   986: ldc 'IOException occurred while closing InputStream'
      //   988: aload_1
      //   989: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   992: pop
      //   993: aconst_null
      //   994: areturn
      //   995: astore #13
      //   997: aload #14
      //   999: astore_1
      //   1000: aload #13
      //   1002: astore #14
      //   1004: goto -> 1015
      //   1007: astore_1
      //   1008: goto -> 1051
      //   1011: astore #14
      //   1013: aconst_null
      //   1014: astore_1
      //   1015: aload_1
      //   1016: astore #13
      //   1018: ldc 'ExifInterface'
      //   1020: ldc 'IOException occurred during reading a value'
      //   1022: aload #14
      //   1024: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1027: pop
      //   1028: aload_1
      //   1029: ifnull -> 1048
      //   1032: aload_1
      //   1033: invokevirtual close : ()V
      //   1036: aconst_null
      //   1037: areturn
      //   1038: astore_1
      //   1039: ldc 'ExifInterface'
      //   1041: ldc 'IOException occurred while closing InputStream'
      //   1043: aload_1
      //   1044: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1047: pop
      //   1048: aconst_null
      //   1049: areturn
      //   1050: astore_1
      //   1051: aload #13
      //   1053: ifnull -> 1076
      //   1056: aload #13
      //   1058: invokevirtual close : ()V
      //   1061: goto -> 1076
      //   1064: astore #13
      //   1066: ldc 'ExifInterface'
      //   1068: ldc 'IOException occurred while closing InputStream'
      //   1070: aload #13
      //   1072: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1075: pop
      //   1076: goto -> 1081
      //   1079: aload_1
      //   1080: athrow
      //   1081: goto -> 1079
      //   1084: goto -> 976
      //   1087: iload_2
      //   1088: iconst_1
      //   1089: iadd
      //   1090: istore_2
      //   1091: goto -> 701
      //   1094: iload_2
      //   1095: iconst_1
      //   1096: iadd
      //   1097: istore_2
      //   1098: goto -> 767
      // Exception table:
      //   from	to	target	type
      //   3	16	1011	java/io/IOException
      //   3	16	1007	finally
      //   20	26	995	java/io/IOException
      //   20	26	1050	finally
      //   30	36	995	java/io/IOException
      //   30	36	1050	finally
      //   132	139	995	java/io/IOException
      //   132	139	1050	finally
      //   143	151	995	java/io/IOException
      //   143	151	1050	finally
      //   155	163	995	java/io/IOException
      //   155	163	1050	finally
      //   170	175	177	java/io/IOException
      //   195	202	995	java/io/IOException
      //   195	202	1050	finally
      //   208	216	995	java/io/IOException
      //   208	216	1050	finally
      //   220	229	995	java/io/IOException
      //   220	229	1050	finally
      //   236	241	243	java/io/IOException
      //   261	269	995	java/io/IOException
      //   261	269	1050	finally
      //   276	284	995	java/io/IOException
      //   276	284	1050	finally
      //   288	310	995	java/io/IOException
      //   288	310	1050	finally
      //   317	322	324	java/io/IOException
      //   342	349	995	java/io/IOException
      //   342	349	1050	finally
      //   356	364	995	java/io/IOException
      //   356	364	1050	finally
      //   368	376	995	java/io/IOException
      //   368	376	1050	finally
      //   383	388	390	java/io/IOException
      //   408	415	995	java/io/IOException
      //   408	415	1050	finally
      //   422	430	995	java/io/IOException
      //   422	430	1050	finally
      //   434	442	995	java/io/IOException
      //   434	442	1050	finally
      //   449	454	456	java/io/IOException
      //   474	482	995	java/io/IOException
      //   474	482	1050	finally
      //   489	497	995	java/io/IOException
      //   489	497	1050	finally
      //   501	521	995	java/io/IOException
      //   501	521	1050	finally
      //   528	533	535	java/io/IOException
      //   553	560	995	java/io/IOException
      //   553	560	1050	finally
      //   567	575	995	java/io/IOException
      //   567	575	1050	finally
      //   579	587	995	java/io/IOException
      //   579	587	1050	finally
      //   594	599	601	java/io/IOException
      //   619	626	995	java/io/IOException
      //   619	626	1050	finally
      //   633	641	995	java/io/IOException
      //   633	641	1050	finally
      //   645	653	995	java/io/IOException
      //   645	653	1050	finally
      //   660	665	667	java/io/IOException
      //   688	699	995	java/io/IOException
      //   688	699	1050	finally
      //   708	716	995	java/io/IOException
      //   708	716	1050	finally
      //   720	734	995	java/io/IOException
      //   720	734	1050	finally
      //   750	755	995	java/io/IOException
      //   750	755	1050	finally
      //   759	767	995	java/io/IOException
      //   759	767	1050	finally
      //   771	779	995	java/io/IOException
      //   771	779	1050	finally
      //   783	790	995	java/io/IOException
      //   783	790	1050	finally
      //   807	814	995	java/io/IOException
      //   807	814	1050	finally
      //   821	828	995	java/io/IOException
      //   821	828	1050	finally
      //   835	840	995	java/io/IOException
      //   835	840	1050	finally
      //   840	845	847	java/io/IOException
      //   865	870	995	java/io/IOException
      //   865	870	1050	finally
      //   874	880	995	java/io/IOException
      //   874	880	1050	finally
      //   897	918	995	java/io/IOException
      //   897	918	1050	finally
      //   918	923	925	java/io/IOException
      //   943	955	995	java/io/IOException
      //   943	955	1050	finally
      //   955	960	962	java/io/IOException
      //   976	981	983	java/io/IOException
      //   1018	1028	1050	finally
      //   1032	1036	1038	java/io/IOException
      //   1056	1061	1064	java/io/IOException
    }
    
    public int size() {
      return ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[this.format] * this.numberOfComponents;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(ExifInterface.IFD_FORMAT_NAMES[this.format]);
      stringBuilder.append(", data length:");
      stringBuilder.append(this.bytes.length);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static class ExifTag {
    public final String name;
    
    public final int number;
    
    public final int primaryFormat;
    
    public final int secondaryFormat;
    
    ExifTag(String param1String, int param1Int1, int param1Int2) {
      this.name = param1String;
      this.number = param1Int1;
      this.primaryFormat = param1Int2;
      this.secondaryFormat = -1;
    }
    
    ExifTag(String param1String, int param1Int1, int param1Int2, int param1Int3) {
      this.name = param1String;
      this.number = param1Int1;
      this.primaryFormat = param1Int2;
      this.secondaryFormat = param1Int3;
    }
    
    boolean isFormatCompatible(int param1Int) {
      int i = this.primaryFormat;
      if (i != 7) {
        if (param1Int == 7)
          return true; 
        if (i != param1Int) {
          int j = this.secondaryFormat;
          return (j == param1Int) ? true : (((i == 4 || j == 4) && param1Int == 3) ? true : (((i == 9 || j == 9) && param1Int == 8) ? true : (((i == 12 || j == 12) && param1Int == 11))));
        } 
      } 
      return true;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface IfdType {}
  
  private static class Rational {
    public final long denominator;
    
    public final long numerator;
    
    Rational(double param1Double) {
      this((long)(param1Double * 10000.0D), 10000L);
    }
    
    Rational(long param1Long1, long param1Long2) {
      if (param1Long2 == 0L) {
        this.numerator = 0L;
        this.denominator = 1L;
        return;
      } 
      this.numerator = param1Long1;
      this.denominator = param1Long2;
    }
    
    public double calculate() {
      double d1 = this.numerator;
      double d2 = this.denominator;
      Double.isNaN(d1);
      Double.isNaN(d2);
      return d1 / d2;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.numerator);
      stringBuilder.append("/");
      stringBuilder.append(this.denominator);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\exifinterface\media\ExifInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */