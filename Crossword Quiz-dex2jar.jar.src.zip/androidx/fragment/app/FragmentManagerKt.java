package androidx.fragment.app;

import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\"\n\000\n\002\020\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\0320\020\000\032\0020\001*\0020\0022\b\b\002\020\003\032\0020\0042\027\020\005\032\023\022\004\022\0020\007\022\004\022\0020\0010\006¢\006\002\b\bH\b\0320\020\t\032\0020\001*\0020\0022\b\b\002\020\003\032\0020\0042\027\020\005\032\023\022\004\022\0020\007\022\004\022\0020\0010\006¢\006\002\b\bH\b\032:\020\n\032\0020\001*\0020\0022\b\b\002\020\013\032\0020\0042\b\b\002\020\003\032\0020\0042\027\020\005\032\023\022\004\022\0020\007\022\004\022\0020\0010\006¢\006\002\b\bH\b¨\006\f"}, d2 = {"commit", "", "Landroidx/fragment/app/FragmentManager;", "allowStateLoss", "", "body", "Lkotlin/Function1;", "Landroidx/fragment/app/FragmentTransaction;", "Lkotlin/ExtensionFunctionType;", "commitNow", "transaction", "now", "fragment-ktx_release"}, k = 2, mv = {1, 1, 15})
public final class FragmentManagerKt {
  public static final void commit(FragmentManager paramFragmentManager, boolean paramBoolean, Function1<? super FragmentTransaction, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramFragmentManager, "$this$commit");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "body");
    FragmentTransaction fragmentTransaction = paramFragmentManager.beginTransaction();
    Intrinsics.checkExpressionValueIsNotNull(fragmentTransaction, "beginTransaction()");
    paramFunction1.invoke(fragmentTransaction);
    if (paramBoolean) {
      fragmentTransaction.commitAllowingStateLoss();
      return;
    } 
    fragmentTransaction.commit();
  }
  
  public static final void commitNow(FragmentManager paramFragmentManager, boolean paramBoolean, Function1<? super FragmentTransaction, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramFragmentManager, "$this$commitNow");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "body");
    FragmentTransaction fragmentTransaction = paramFragmentManager.beginTransaction();
    Intrinsics.checkExpressionValueIsNotNull(fragmentTransaction, "beginTransaction()");
    paramFunction1.invoke(fragmentTransaction);
    if (paramBoolean) {
      fragmentTransaction.commitNowAllowingStateLoss();
      return;
    } 
    fragmentTransaction.commitNow();
  }
  
  @Deprecated(message = "Use commit { .. } or commitNow { .. } extensions")
  public static final void transaction(FragmentManager paramFragmentManager, boolean paramBoolean1, boolean paramBoolean2, Function1<? super FragmentTransaction, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramFragmentManager, "$this$transaction");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "body");
    FragmentTransaction fragmentTransaction = paramFragmentManager.beginTransaction();
    Intrinsics.checkExpressionValueIsNotNull(fragmentTransaction, "beginTransaction()");
    paramFunction1.invoke(fragmentTransaction);
    if (paramBoolean1) {
      if (paramBoolean2) {
        fragmentTransaction.commitNowAllowingStateLoss();
        return;
      } 
      fragmentTransaction.commitNow();
      return;
    } 
    if (paramBoolean2) {
      fragmentTransaction.commitAllowingStateLoss();
      return;
    } 
    fragmentTransaction.commit();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\fragment\app\FragmentManagerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */