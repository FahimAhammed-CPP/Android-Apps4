package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.collection.ArraySet;
import androidx.core.os.CancellationSignal;
import androidx.fragment.R;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentManager implements FragmentResultOwner {
  private static boolean DEBUG = false;
  
  private static final String EXTRA_CREATED_FILLIN_INTENT = "androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE";
  
  public static final int POP_BACK_STACK_INCLUSIVE = 1;
  
  static final String TAG = "FragmentManager";
  
  static boolean USE_STATE_MANAGER = true;
  
  ArrayList<BackStackRecord> mBackStack;
  
  private ArrayList<OnBackStackChangedListener> mBackStackChangeListeners;
  
  private final AtomicInteger mBackStackIndex = new AtomicInteger();
  
  private FragmentContainer mContainer;
  
  private ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = -1;
  
  private SpecialEffectsControllerFactory mDefaultSpecialEffectsControllerFactory = new SpecialEffectsControllerFactory() {
      public SpecialEffectsController createController(ViewGroup param1ViewGroup) {
        return (SpecialEffectsController)new DefaultSpecialEffectsController(param1ViewGroup);
      }
    };
  
  private boolean mDestroyed;
  
  private Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManager.this.execPendingActions(true);
      }
    };
  
  private boolean mExecutingActions;
  
  private Map<Fragment, HashSet<CancellationSignal>> mExitAnimationCancellationSignals = Collections.synchronizedMap(new HashMap<Fragment, HashSet<CancellationSignal>>());
  
  private FragmentFactory mFragmentFactory = null;
  
  private final FragmentStore mFragmentStore = new FragmentStore();
  
  private final FragmentTransition.Callback mFragmentTransitionCallback = new FragmentTransition.Callback() {
      public void onComplete(Fragment param1Fragment, CancellationSignal param1CancellationSignal) {
        if (!param1CancellationSignal.isCanceled())
          FragmentManager.this.removeCancellationSignal(param1Fragment, param1CancellationSignal); 
      }
      
      public void onStart(Fragment param1Fragment, CancellationSignal param1CancellationSignal) {
        FragmentManager.this.addCancellationSignal(param1Fragment, param1CancellationSignal);
      }
    };
  
  private boolean mHavePendingDeferredStart;
  
  private FragmentHostCallback<?> mHost;
  
  private FragmentFactory mHostFragmentFactory = new FragmentFactory() {
      public Fragment instantiate(ClassLoader param1ClassLoader, String param1String) {
        return FragmentManager.this.getHost().instantiate(FragmentManager.this.getHost().getContext(), param1String, null);
      }
    };
  
  ArrayDeque<LaunchedFragmentInfo> mLaunchedFragments = new ArrayDeque<LaunchedFragmentInfo>();
  
  private final FragmentLayoutInflaterFactory mLayoutInflaterFactory = new FragmentLayoutInflaterFactory(this);
  
  private final FragmentLifecycleCallbacksDispatcher mLifecycleCallbacksDispatcher = new FragmentLifecycleCallbacksDispatcher(this);
  
  private boolean mNeedMenuInvalidate;
  
  private FragmentManagerViewModel mNonConfig;
  
  private final CopyOnWriteArrayList<FragmentOnAttachListener> mOnAttachListeners = new CopyOnWriteArrayList<FragmentOnAttachListener>();
  
  private final OnBackPressedCallback mOnBackPressedCallback = new OnBackPressedCallback(false) {
      public void handleOnBackPressed() {
        FragmentManager.this.handleOnBackPressed();
      }
    };
  
  private OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private Fragment mParent;
  
  private final ArrayList<OpGenerator> mPendingActions = new ArrayList<OpGenerator>();
  
  private ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  private ActivityResultLauncher<String[]> mRequestPermissions;
  
  private final Map<String, LifecycleAwareResultListener> mResultListeners = Collections.synchronizedMap(new HashMap<String, LifecycleAwareResultListener>());
  
  private final Map<String, Bundle> mResults = Collections.synchronizedMap(new HashMap<String, Bundle>());
  
  private SpecialEffectsControllerFactory mSpecialEffectsControllerFactory = null;
  
  private ActivityResultLauncher<Intent> mStartActivityForResult;
  
  private ActivityResultLauncher<IntentSenderRequest> mStartIntentSenderForResult;
  
  private boolean mStateSaved;
  
  private boolean mStopped;
  
  private ArrayList<Fragment> mTmpAddedFragments;
  
  private ArrayList<Boolean> mTmpIsPop;
  
  private ArrayList<BackStackRecord> mTmpRecords;
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    int i = this.mCurState;
    if (i < 1)
      return; 
    i = Math.min(i, 5);
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment.mState < i) {
        moveToState(fragment, i);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void cancelExitAnimation(Fragment paramFragment) {
    HashSet hashSet = this.mExitAnimationCancellationSignals.get(paramFragment);
    if (hashSet != null) {
      Iterator<CancellationSignal> iterator = hashSet.iterator();
      while (iterator.hasNext())
        ((CancellationSignal)iterator.next()).cancel(); 
      hashSet.clear();
      destroyFragmentView(paramFragment);
      this.mExitAnimationCancellationSignals.remove(paramFragment);
    } 
  }
  
  private void checkStateLoss() {
    if (!isStateSaved())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private Set<SpecialEffectsController> collectAllSpecialEffectsController() {
    HashSet<SpecialEffectsController> hashSet = new HashSet();
    Iterator iterator = this.mFragmentStore.getActiveFragmentStateManagers().iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = (((FragmentStateManager)iterator.next()).getFragment()).mContainer;
      if (viewGroup != null)
        hashSet.add(SpecialEffectsController.getOrCreateController(viewGroup, getSpecialEffectsControllerFactory())); 
    } 
    return hashSet;
  }
  
  private Set<SpecialEffectsController> collectChangedControllers(ArrayList<BackStackRecord> paramArrayList, int paramInt1, int paramInt2) {
    HashSet<SpecialEffectsController> hashSet = new HashSet();
    while (paramInt1 < paramInt2) {
      Iterator iterator = ((BackStackRecord)paramArrayList.get(paramInt1)).mOps.iterator();
      while (iterator.hasNext()) {
        Fragment fragment = ((FragmentTransaction.Op)iterator.next()).mFragment;
        if (fragment != null) {
          ViewGroup viewGroup = fragment.mContainer;
          if (viewGroup != null)
            hashSet.add(SpecialEffectsController.getOrCreateController(viewGroup, this)); 
        } 
      } 
      paramInt1++;
    } 
    return hashSet;
  }
  
  private void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      FragmentAnim.AnimationOrAnimator animationOrAnimator = FragmentAnim.loadAnimation(this.mHost.getContext(), fragment, fragment.mHidden ^ true);
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null && fragment.mHidden)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        fragment.mView.setVisibility(bool);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && isMenuAvailable(fragment))
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  private void destroyFragmentView(Fragment paramFragment) {
    paramFragment.performDestroyView();
    this.mLifecycleCallbacksDispatcher.dispatchOnFragmentViewDestroyed(paramFragment, false);
    paramFragment.mContainer = null;
    paramFragment.mView = null;
    paramFragment.mViewLifecycleOwner = null;
    paramFragment.mViewLifecycleOwnerLiveData.setValue(null);
    paramFragment.mInLayout = false;
  }
  
  private void dispatchParentPrimaryNavigationFragmentChanged(Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(findActiveFragment(paramFragment.mWho)))
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      this.mFragmentStore.dispatchStateChange(paramInt);
      moveToState(paramInt, false);
      if (USE_STATE_MANAGER) {
        Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
        while (iterator.hasNext())
          ((SpecialEffectsController)iterator.next()).forceCompleteAllOperations(); 
      } 
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  @Deprecated
  public static void enableDebugLogging(boolean paramBoolean) {
    DEBUG = paramBoolean;
  }
  
  public static void enableNewStateManager(boolean paramBoolean) {
    USE_STATE_MANAGER = paramBoolean;
  }
  
  private void endAnimatingAwayFragments() {
    if (USE_STATE_MANAGER) {
      Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
      while (iterator.hasNext())
        ((SpecialEffectsController)iterator.next()).forceCompleteAllOperations(); 
    } else if (!this.mExitAnimationCancellationSignals.isEmpty()) {
      for (Fragment fragment : this.mExitAnimationCancellationSignals.keySet()) {
        cancelExitAnimation(fragment);
        moveToState(fragment);
      } 
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost == null) {
        if (this.mDestroyed)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
        if (!paramBoolean)
          checkStateLoss(); 
        if (this.mTmpRecords == null) {
          this.mTmpRecords = new ArrayList<BackStackRecord>();
          this.mTmpIsPop = new ArrayList<Boolean>();
        } 
        this.mExecutingActions = true;
        try {
          executePostponedTransaction(null, null);
          return;
        } finally {
          this.mExecutingActions = false;
        } 
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((BackStackRecord)paramArrayList.get(paramInt1)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mFragmentStore.getFragments());
    Fragment fragment = getPrimaryNavigationFragment();
    int i = paramInt1;
    boolean bool = false;
    while (i < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
      i++;
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1 && this.mCurState >= 1)
      if (USE_STATE_MANAGER) {
        for (i = paramInt1; i < paramInt2; i++) {
          Iterator iterator = ((BackStackRecord)paramArrayList.get(i)).mOps.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((FragmentTransaction.Op)iterator.next()).mFragment;
            if (fragment1 != null && fragment1.mFragmentManager != null) {
              FragmentStateManager fragmentStateManager = createOrGetFragmentStateManager(fragment1);
              this.mFragmentStore.makeActive(fragmentStateManager);
            } 
          } 
        } 
      } else {
        FragmentTransition.startTransitions(this.mHost.getContext(), this.mContainer, paramArrayList, paramArrayList1, paramInt1, paramInt2, false, this.mFragmentTransitionCallback);
      }  
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (USE_STATE_MANAGER) {
      bool1 = ((Boolean)paramArrayList1.get(paramInt2 - 1)).booleanValue();
      for (i = paramInt1; i < paramInt2; i++) {
        BackStackRecord backStackRecord = paramArrayList.get(i);
        if (bool1) {
          int j;
          for (j = backStackRecord.mOps.size() - 1; j >= 0; j--) {
            Fragment fragment1 = ((FragmentTransaction.Op)backStackRecord.mOps.get(j)).mFragment;
            if (fragment1 != null)
              createOrGetFragmentStateManager(fragment1).moveToExpectedState(); 
          } 
        } else {
          Iterator iterator = backStackRecord.mOps.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((FragmentTransaction.Op)iterator.next()).mFragment;
            if (fragment1 != null)
              createOrGetFragmentStateManager(fragment1).moveToExpectedState(); 
          } 
        } 
      } 
      moveToState(this.mCurState, true);
      for (SpecialEffectsController specialEffectsController : collectChangedControllers(paramArrayList, paramInt1, paramInt2)) {
        specialEffectsController.updateOperationDirection(bool1);
        specialEffectsController.markPostponedState();
        specialEffectsController.executePendingOperations();
      } 
    } else {
      if (bool1) {
        ArraySet<Fragment> arraySet = new ArraySet();
        addAddedFragments(arraySet);
        i = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
        makeRemovedFragmentsInvisible(arraySet);
      } else {
        i = paramInt2;
      } 
      ArrayList<Boolean> arrayList1 = paramArrayList1;
      if (i != paramInt1 && bool1) {
        if (this.mCurState >= 1)
          FragmentTransition.startTransitions(this.mHost.getContext(), this.mContainer, paramArrayList, paramArrayList1, paramInt1, i, true, this.mFragmentTransitionCallback); 
        paramArrayList1 = arrayList1;
        moveToState(this.mCurState, true);
      } else {
        paramArrayList1 = arrayList1;
      } 
    } 
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue() && backStackRecord.mIndex >= 0)
        backStackRecord.mIndex = -1; 
      backStackRecord.runOnCommitRunnables();
      paramInt1++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_3
    //   13: goto -> 22
    //   16: aload #7
    //   18: invokevirtual size : ()I
    //   21: istore_3
    //   22: iconst_0
    //   23: istore #4
    //   25: iload_3
    //   26: istore #6
    //   28: iload #4
    //   30: iload #6
    //   32: if_icmpge -> 260
    //   35: aload_0
    //   36: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   39: iload #4
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/FragmentManager$StartEnterTransitionListener
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 123
    //   53: aload #7
    //   55: getfield mIsBack : Z
    //   58: ifne -> 123
    //   61: aload_1
    //   62: aload #7
    //   64: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore_3
    //   71: iload_3
    //   72: iconst_m1
    //   73: if_icmpeq -> 123
    //   76: aload_2
    //   77: ifnull -> 123
    //   80: aload_2
    //   81: iload_3
    //   82: invokevirtual get : (I)Ljava/lang/Object;
    //   85: checkcast java/lang/Boolean
    //   88: invokevirtual booleanValue : ()Z
    //   91: ifeq -> 123
    //   94: aload_0
    //   95: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   98: iload #4
    //   100: invokevirtual remove : (I)Ljava/lang/Object;
    //   103: pop
    //   104: iload #4
    //   106: iconst_1
    //   107: isub
    //   108: istore #5
    //   110: iload #6
    //   112: iconst_1
    //   113: isub
    //   114: istore_3
    //   115: aload #7
    //   117: invokevirtual cancelTransaction : ()V
    //   120: goto -> 248
    //   123: aload #7
    //   125: invokevirtual isReady : ()Z
    //   128: ifne -> 166
    //   131: iload #6
    //   133: istore_3
    //   134: iload #4
    //   136: istore #5
    //   138: aload_1
    //   139: ifnull -> 248
    //   142: iload #6
    //   144: istore_3
    //   145: iload #4
    //   147: istore #5
    //   149: aload #7
    //   151: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   154: aload_1
    //   155: iconst_0
    //   156: aload_1
    //   157: invokevirtual size : ()I
    //   160: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   163: ifeq -> 248
    //   166: aload_0
    //   167: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   170: iload #4
    //   172: invokevirtual remove : (I)Ljava/lang/Object;
    //   175: pop
    //   176: iload #4
    //   178: iconst_1
    //   179: isub
    //   180: istore #5
    //   182: iload #6
    //   184: iconst_1
    //   185: isub
    //   186: istore_3
    //   187: aload_1
    //   188: ifnull -> 243
    //   191: aload #7
    //   193: getfield mIsBack : Z
    //   196: ifne -> 243
    //   199: aload_1
    //   200: aload #7
    //   202: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   205: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   208: istore #4
    //   210: iload #4
    //   212: iconst_m1
    //   213: if_icmpeq -> 243
    //   216: aload_2
    //   217: ifnull -> 243
    //   220: aload_2
    //   221: iload #4
    //   223: invokevirtual get : (I)Ljava/lang/Object;
    //   226: checkcast java/lang/Boolean
    //   229: invokevirtual booleanValue : ()Z
    //   232: ifeq -> 243
    //   235: aload #7
    //   237: invokevirtual cancelTransaction : ()V
    //   240: goto -> 248
    //   243: aload #7
    //   245: invokevirtual completeTransaction : ()V
    //   248: iload #5
    //   250: iconst_1
    //   251: iadd
    //   252: istore #4
    //   254: iload_3
    //   255: istore #6
    //   257: goto -> 28
    //   260: return
  }
  
  public static <F extends Fragment> F findFragment(View paramView) {
    Fragment fragment = findViewFragment(paramView);
    if (fragment != null)
      return (F)fragment; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" does not have a Fragment set");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  static FragmentManager findFragmentManager(View paramView) {
    FragmentActivity fragmentActivity1;
    Fragment fragment = findViewFragment(paramView);
    if (fragment != null) {
      if (fragment.isAdded())
        return fragment.getChildFragmentManager(); 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("The Fragment ");
      stringBuilder1.append(fragment);
      stringBuilder1.append(" that owns View ");
      stringBuilder1.append(paramView);
      stringBuilder1.append(" has already been destroyed. Nested fragments should always use the child FragmentManager.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    Context context = paramView.getContext();
    FragmentActivity fragmentActivity2 = null;
    while (true) {
      fragmentActivity1 = fragmentActivity2;
      if (context instanceof ContextWrapper) {
        if (context instanceof FragmentActivity) {
          fragmentActivity1 = (FragmentActivity)context;
          break;
        } 
        context = ((ContextWrapper)context).getBaseContext();
        continue;
      } 
      break;
    } 
    if (fragmentActivity1 != null)
      return fragmentActivity1.getSupportFragmentManager(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not within a subclass of FragmentActivity.");
    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
    throw illegalStateException;
  }
  
  private static Fragment findViewFragment(View paramView) {
    while (paramView != null) {
      Fragment fragment = getViewFragment(paramView);
      if (fragment != null)
        return fragment; 
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        continue;
      } 
      viewParent = null;
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (USE_STATE_MANAGER) {
      Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
      while (iterator.hasNext())
        ((SpecialEffectsController)iterator.next()).forcePostponedExecutePendingOperations(); 
    } else if (this.mPostponedTransactions != null) {
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction(); 
    } 
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    synchronized (this.mPendingActions) {
      boolean bool = this.mPendingActions.isEmpty();
      int i = 0;
      if (bool)
        return false; 
      int j = this.mPendingActions.size();
      bool = false;
      while (i < j) {
        bool |= ((OpGenerator)this.mPendingActions.get(i)).generateOps(paramArrayList, paramArrayList1);
        i++;
      } 
      this.mPendingActions.clear();
      this.mHost.getHandler().removeCallbacks(this.mExecCommit);
      return bool;
    } 
  }
  
  private FragmentManagerViewModel getChildNonConfig(Fragment paramFragment) {
    return this.mNonConfig.getChildNonConfig(paramFragment);
  }
  
  private ViewGroup getFragmentContainer(Fragment paramFragment) {
    if (paramFragment.mContainer != null)
      return paramFragment.mContainer; 
    if (paramFragment.mContainerId <= 0)
      return null; 
    if (this.mContainer.onHasView()) {
      View view = this.mContainer.onFindViewById(paramFragment.mContainerId);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  static Fragment getViewFragment(View paramView) {
    Object object = paramView.getTag(R.id.fragment_container_view_tag);
    return (object instanceof Fragment) ? (Fragment)object : null;
  }
  
  static boolean isLoggingEnabled(int paramInt) {
    return (DEBUG || Log.isLoggable("FragmentManager", paramInt));
  }
  
  private boolean isMenuAvailable(Fragment paramFragment) {
    return ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.checkForMenus());
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.requireView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions(false);
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().popBackStackImmediate())
      return true; 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      executePostponedTransaction(paramArrayList, paramArrayList1);
      int k = paramArrayList.size();
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        int n = i;
        int m = j;
        if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
          if (j != i)
            executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          executeOpsTogether(paramArrayList, paramArrayList1, i, m);
          n = m - 1;
        } 
        i = n + 1;
      } 
      if (j != k)
        executeOpsTogether(paramArrayList, paramArrayList1, j, k); 
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Internal error with the back stack records");
    throw illegalStateException;
  }
  
  private void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void setVisibleRemovingFragment(Fragment paramFragment) {
    ViewGroup viewGroup = getFragmentContainer(paramFragment);
    if (viewGroup != null && paramFragment.getNextAnim() > 0) {
      if (viewGroup.getTag(R.id.visible_removing_fragment_view_tag) == null)
        viewGroup.setTag(R.id.visible_removing_fragment_view_tag, paramFragment); 
      ((Fragment)viewGroup.getTag(R.id.visible_removing_fragment_view_tag)).setNextAnim(paramFragment.getNextAnim());
    } 
  }
  
  private void startPendingDeferredFragments() {
    Iterator<FragmentStateManager> iterator = this.mFragmentStore.getActiveFragmentStateManagers().iterator();
    while (iterator.hasNext())
      performPendingDeferredStart(iterator.next()); 
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback<?> fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  private void updateOnBackPressedCallbackEnabled() {
    ArrayList<OpGenerator> arrayList;
    OnBackPressedCallback onBackPressedCallback;
    synchronized (this.mPendingActions) {
      boolean bool1 = this.mPendingActions.isEmpty();
      boolean bool = true;
      if (!bool1) {
        this.mOnBackPressedCallback.setEnabled(true);
        return;
      } 
      onBackPressedCallback = this.mOnBackPressedCallback;
      if (getBackStackEntryCount() <= 0 || !isPrimaryNavigation(this.mParent))
        bool = false; 
      onBackPressedCallback.setEnabled(bool);
      return;
    } 
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  void addCancellationSignal(Fragment paramFragment, CancellationSignal paramCancellationSignal) {
    if (this.mExitAnimationCancellationSignals.get(paramFragment) == null)
      this.mExitAnimationCancellationSignals.put(paramFragment, new HashSet<CancellationSignal>()); 
    ((HashSet<CancellationSignal>)this.mExitAnimationCancellationSignals.get(paramFragment)).add(paramCancellationSignal);
  }
  
  void addFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    FragmentStateManager fragmentStateManager = createOrGetFragmentStateManager(paramFragment);
    paramFragment.mFragmentManager = this;
    this.mFragmentStore.makeActive(fragmentStateManager);
    if (!paramFragment.mDetached) {
      this.mFragmentStore.addFragment(paramFragment);
      paramFragment.mRemoving = false;
      if (paramFragment.mView == null)
        paramFragment.mHiddenChanged = false; 
      if (isMenuAvailable(paramFragment))
        this.mNeedMenuInvalidate = true; 
    } 
  }
  
  public void addFragmentOnAttachListener(FragmentOnAttachListener paramFragmentOnAttachListener) {
    this.mOnAttachListeners.add(paramFragmentOnAttachListener);
  }
  
  public void addOnBackStackChangedListener(OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  void addRetainedFragment(Fragment paramFragment) {
    this.mNonConfig.addRetainedFragment(paramFragment);
  }
  
  int allocBackStackIndex() {
    return this.mBackStackIndex.getAndIncrement();
  }
  
  void attachController(FragmentHostCallback<?> paramFragmentHostCallback, FragmentContainer paramFragmentContainer, final Fragment parent) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = parent;
      if (parent != null) {
        addFragmentOnAttachListener(new FragmentOnAttachListener() {
              public void onAttachFragment(FragmentManager param1FragmentManager, Fragment param1Fragment) {
                parent.onAttachFragment(param1Fragment);
              }
            });
      } else if (paramFragmentHostCallback instanceof FragmentOnAttachListener) {
        addFragmentOnAttachListener((FragmentOnAttachListener)paramFragmentHostCallback);
      } 
      if (this.mParent != null)
        updateOnBackPressedCallbackEnabled(); 
      if (paramFragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
        Fragment fragment;
        OnBackPressedDispatcherOwner onBackPressedDispatcherOwner = (OnBackPressedDispatcherOwner)paramFragmentHostCallback;
        OnBackPressedDispatcher onBackPressedDispatcher = onBackPressedDispatcherOwner.getOnBackPressedDispatcher();
        this.mOnBackPressedDispatcher = onBackPressedDispatcher;
        if (parent != null)
          fragment = parent; 
        onBackPressedDispatcher.addCallback((LifecycleOwner)fragment, this.mOnBackPressedCallback);
      } 
      if (parent != null) {
        this.mNonConfig = parent.mFragmentManager.getChildNonConfig(parent);
      } else if (paramFragmentHostCallback instanceof ViewModelStoreOwner) {
        this.mNonConfig = FragmentManagerViewModel.getInstance(((ViewModelStoreOwner)paramFragmentHostCallback).getViewModelStore());
      } else {
        this.mNonConfig = new FragmentManagerViewModel(false);
      } 
      this.mNonConfig.setIsStateSaved(isStateSaved());
      this.mFragmentStore.setNonConfig(this.mNonConfig);
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof ActivityResultRegistryOwner) {
        ActivityResultRegistry activityResultRegistry = ((ActivityResultRegistryOwner)paramFragmentHostCallback).getActivityResultRegistry();
        if (parent != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(parent.mWho);
          stringBuilder1.append(":");
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentManager:");
        stringBuilder.append(str);
        String str = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartActivityForResult");
        this.mStartActivityForResult = activityResultRegistry.register(stringBuilder.toString(), (ActivityResultContract)new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
              public void onActivityResult(ActivityResult param1ActivityResult) {
                StringBuilder stringBuilder;
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No Activities were started for result for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                int i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Activity result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onActivityResult(i, stringBuilder.getResultCode(), stringBuilder.getData());
              }
            });
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartIntentSenderForResult");
        this.mStartIntentSenderForResult = activityResultRegistry.register(stringBuilder.toString(), new FragmentIntentSenderContract(), new ActivityResultCallback<ActivityResult>() {
              public void onActivityResult(ActivityResult param1ActivityResult) {
                StringBuilder stringBuilder;
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No IntentSenders were started for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                int i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onActivityResult(i, stringBuilder.getResultCode(), stringBuilder.getData());
              }
            });
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("RequestPermissions");
        this.mRequestPermissions = activityResultRegistry.register(stringBuilder.toString(), (ActivityResultContract)new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
              public void onActivityResult(Map<String, Boolean> param1Map) {
                StringBuilder stringBuilder;
                String[] arrayOfString = (String[])param1Map.keySet().toArray((Object[])new String[0]);
                ArrayList<Boolean> arrayList = new ArrayList(param1Map.values());
                int[] arrayOfInt = new int[arrayList.size()];
                int i;
                for (i = 0; i < arrayList.size(); i++) {
                  byte b;
                  if (((Boolean)arrayList.get(i)).booleanValue()) {
                    b = 0;
                  } else {
                    b = -1;
                  } 
                  arrayOfInt[i] = b;
                } 
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No permissions were requested for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Permission request result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onRequestPermissionsResult(i, arrayOfString, (int[])stringBuilder);
              }
            });
      } 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  void attachFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        this.mFragmentStore.addFragment(paramFragment);
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
      } 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return (FragmentTransaction)new BackStackRecord(this);
  }
  
  boolean checkForMenus() {
    Iterator<Fragment> iterator = this.mFragmentStore.getActiveFragments().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = isMenuAvailable(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  public final void clearFragmentResult(String paramString) {
    this.mResults.remove(paramString);
  }
  
  public final void clearFragmentResultListener(String paramString) {
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.remove(paramString);
    if (lifecycleAwareResultListener != null)
      lifecycleAwareResultListener.removeObserver(); 
  }
  
  void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2 && this.mCurState >= 1)
      FragmentTransition.startTransitions(this.mHost.getContext(), this.mContainer, arrayList, arrayList1, 0, 1, true, this.mFragmentTransitionCallback); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    for (Fragment fragment : this.mFragmentStore.getActiveFragments()) {
      if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
        if (fragment.mPostponedAlpha > 0.0F)
          fragment.mView.setAlpha(fragment.mPostponedAlpha); 
        if (paramBoolean3) {
          fragment.mPostponedAlpha = 0.0F;
          continue;
        } 
        fragment.mPostponedAlpha = -1.0F;
        fragment.mIsNewlyAdded = false;
      } 
    } 
  }
  
  FragmentStateManager createOrGetFragmentStateManager(Fragment paramFragment) {
    FragmentStateManager fragmentStateManager2 = this.mFragmentStore.getFragmentStateManager(paramFragment.mWho);
    if (fragmentStateManager2 != null)
      return fragmentStateManager2; 
    FragmentStateManager fragmentStateManager1 = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, paramFragment);
    fragmentStateManager1.restoreState(this.mHost.getContext().getClassLoader());
    fragmentStateManager1.setFragmentManagerState(this.mCurState);
    return fragmentStateManager1;
  }
  
  void detachFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mFragmentStore.removeFragment(paramFragment);
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
        setVisibleRemovingFragment(paramFragment);
      } 
    } 
  }
  
  void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(4);
  }
  
  void dispatchAttach() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(0);
  }
  
  void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(1);
  }
  
  boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    int j = this.mCurState;
    int i = 0;
    if (j < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    Iterator<Fragment> iterator = this.mFragmentStore.getFragments().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && isParentMenuVisible(fragment) && fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.mCreatedMenus != null)
      while (i < this.mCreatedMenus.size()) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
        i++;
      }  
    this.mCreatedMenus = arrayList;
    return bool;
  }
  
  void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions(true);
    endAnimatingAwayFragments();
    dispatchStateChange(-1);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
    if (this.mOnBackPressedDispatcher != null) {
      this.mOnBackPressedCallback.remove();
      this.mOnBackPressedDispatcher = null;
    } 
    ActivityResultLauncher<Intent> activityResultLauncher = this.mStartActivityForResult;
    if (activityResultLauncher != null) {
      activityResultLauncher.unregister();
      this.mStartIntentSenderForResult.unregister();
      this.mRequestPermissions.unregister();
    } 
  }
  
  void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  void dispatchLowMemory() {
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnAttachFragment(Fragment paramFragment) {
    Iterator<FragmentOnAttachListener> iterator = this.mOnAttachListeners.iterator();
    while (iterator.hasNext())
      ((FragmentOnAttachListener)iterator.next()).onAttachFragment(this, paramFragment); 
  }
  
  boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  void dispatchPause() {
    dispatchStateChange(5);
  }
  
  void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int i = this.mCurState;
    boolean bool = false;
    if (i < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && isParentMenuVisible(fragment) && fragment.performPrepareOptionsMenu(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  void dispatchPrimaryNavigationFragmentChanged() {
    updateOnBackPressedCallbackEnabled();
    dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
  }
  
  void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(7);
  }
  
  void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(5);
  }
  
  void dispatchStop() {
    this.mStopped = true;
    this.mNonConfig.setIsStateSaved(true);
    dispatchStateChange(4);
  }
  
  void dispatchViewCreated() {
    dispatchStateChange(2);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str = stringBuilder2.toString();
    this.mFragmentStore.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    ArrayList<Fragment> arrayList1 = this.mCreatedMenus;
    byte b = 0;
    if (arrayList1 != null) {
      int i = arrayList1.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int j;
        for (j = 0; j < i; j++) {
          Fragment fragment = this.mCreatedMenus.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int j;
        for (j = 0; j < i; j++) {
          BackStackRecord backStackRecord = this.mBackStack.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(backStackRecord.toString());
          backStackRecord.dump(str, paramPrintWriter);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.mBackStackIndex.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.mPendingActions) {
      int i = this.mPendingActions.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int j;
        for (j = b; j < i; j++) {
          OpGenerator opGenerator = this.mPendingActions.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(opGenerator);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.mHost);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.mContainer);
      if (this.mParent != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.mParent);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.mCurState);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.mStateSaved);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.mStopped);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.mDestroyed);
      if (this.mNeedMenuInvalidate) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.mNeedMenuInvalidate);
      } 
      return;
    } 
  }
  
  void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.mHost == null) {
        if (this.mDestroyed)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      checkStateLoss();
    } 
    synchronized (this.mPendingActions) {
      if (this.mHost == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.mPendingActions.add(paramOpGenerator);
      scheduleCommit();
      return;
    } 
  }
  
  boolean execPendingActions(boolean paramBoolean) {
    ensureExecReady(paramBoolean);
    paramBoolean = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
    return paramBoolean;
  }
  
  void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions(true);
    forcePostponedTransactions();
    return bool;
  }
  
  Fragment findActiveFragment(String paramString) {
    return this.mFragmentStore.findActiveFragment(paramString);
  }
  
  public Fragment findFragmentById(int paramInt) {
    return this.mFragmentStore.findFragmentById(paramInt);
  }
  
  public Fragment findFragmentByTag(String paramString) {
    return this.mFragmentStore.findFragmentByTag(paramString);
  }
  
  Fragment findFragmentByWho(String paramString) {
    return this.mFragmentStore.findFragmentByWho(paramString);
  }
  
  int getActiveFragmentCount() {
    return this.mFragmentStore.getActiveFragmentCount();
  }
  
  List<Fragment> getActiveFragments() {
    return this.mFragmentStore.getActiveFragments();
  }
  
  public BackStackEntry getBackStackEntryAt(int paramInt) {
    return (BackStackEntry)this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  FragmentContainer getContainer() {
    return this.mContainer;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = findActiveFragment(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public FragmentFactory getFragmentFactory() {
    FragmentFactory fragmentFactory = this.mFragmentFactory;
    if (fragmentFactory != null)
      return fragmentFactory; 
    Fragment fragment = this.mParent;
    return (fragment != null) ? fragment.mFragmentManager.getFragmentFactory() : this.mHostFragmentFactory;
  }
  
  FragmentStore getFragmentStore() {
    return this.mFragmentStore;
  }
  
  public List<Fragment> getFragments() {
    return this.mFragmentStore.getFragments();
  }
  
  FragmentHostCallback<?> getHost() {
    return this.mHost;
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return (LayoutInflater.Factory2)this.mLayoutInflaterFactory;
  }
  
  FragmentLifecycleCallbacksDispatcher getLifecycleCallbacksDispatcher() {
    return this.mLifecycleCallbacksDispatcher;
  }
  
  Fragment getParent() {
    return this.mParent;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  SpecialEffectsControllerFactory getSpecialEffectsControllerFactory() {
    SpecialEffectsControllerFactory specialEffectsControllerFactory = this.mSpecialEffectsControllerFactory;
    if (specialEffectsControllerFactory != null)
      return specialEffectsControllerFactory; 
    Fragment fragment = this.mParent;
    return (fragment != null) ? fragment.mFragmentManager.getSpecialEffectsControllerFactory() : this.mDefaultSpecialEffectsControllerFactory;
  }
  
  ViewModelStore getViewModelStore(Fragment paramFragment) {
    return this.mNonConfig.getViewModelStore(paramFragment);
  }
  
  void handleOnBackPressed() {
    execPendingActions(true);
    if (this.mOnBackPressedCallback.isEnabled()) {
      popBackStackImmediate();
      return;
    } 
    this.mOnBackPressedDispatcher.onBackPressed();
  }
  
  void hideFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
      setVisibleRemovingFragment(paramFragment);
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isParentMenuVisible(Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.isMenuVisible();
  }
  
  boolean isPrimaryNavigation(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    return (paramFragment.equals(fragmentManager.getPrimaryNavigationFragment()) && isPrimaryNavigation(fragmentManager.mParent));
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  void launchRequestPermissions(Fragment paramFragment, String[] paramArrayOfString, int paramInt) {
    LaunchedFragmentInfo launchedFragmentInfo;
    if (this.mRequestPermissions != null) {
      launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      this.mRequestPermissions.launch(paramArrayOfString);
      return;
    } 
    this.mHost.onRequestPermissionsFromFragment((Fragment)launchedFragmentInfo, paramArrayOfString, paramInt);
  }
  
  void launchStartActivityForResult(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    LaunchedFragmentInfo launchedFragmentInfo;
    if (this.mStartActivityForResult != null) {
      launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      if (paramIntent != null && paramBundle != null)
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
      this.mStartActivityForResult.launch(paramIntent);
      return;
    } 
    this.mHost.onStartActivityFromFragment((Fragment)launchedFragmentInfo, paramIntent, paramInt, paramBundle);
  }
  
  void launchStartIntentSenderForResult(Fragment paramFragment, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    IntentSenderRequest intentSenderRequest;
    StringBuilder stringBuilder;
    if (this.mStartIntentSenderForResult != null) {
      if (paramBundle != null) {
        if (paramIntent == null) {
          paramIntent = new Intent();
          paramIntent.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
        } 
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("ActivityOptions ");
          stringBuilder1.append(paramBundle);
          stringBuilder1.append(" were added to fillInIntent ");
          stringBuilder1.append(paramIntent);
          stringBuilder1.append(" for fragment ");
          stringBuilder1.append(paramFragment);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle);
      } 
      intentSenderRequest = (new IntentSenderRequest.Builder(paramIntentSender)).setFillInIntent(paramIntent).setFlags(paramInt3, paramInt2).build();
      LaunchedFragmentInfo launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt1);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      if (isLoggingEnabled(2)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(paramFragment);
        stringBuilder.append("is launching an IntentSender for result ");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.mStartIntentSenderForResult.launch(intentSenderRequest);
      return;
    } 
    this.mHost.onStartIntentSenderFromFragment(paramFragment, (IntentSender)intentSenderRequest, paramInt1, (Intent)stringBuilder, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (!this.mFragmentStore.containsActiveFragment(paramFragment.mWho)) {
      if (isLoggingEnabled(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.mCurState);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    moveToState(paramFragment);
    if (paramFragment.mView != null && paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
      if (paramFragment.mPostponedAlpha > 0.0F)
        paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
      paramFragment.mPostponedAlpha = 0.0F;
      paramFragment.mIsNewlyAdded = false;
      FragmentAnim.AnimationOrAnimator animationOrAnimator = FragmentAnim.loadAnimation(this.mHost.getContext(), paramFragment, true);
      if (animationOrAnimator != null)
        if (animationOrAnimator.animation != null) {
          paramFragment.mView.startAnimation(animationOrAnimator.animation);
        } else {
          animationOrAnimator.animator.setTarget(paramFragment.mView);
          animationOrAnimator.animator.start();
        }  
    } 
    if (paramFragment.mHiddenChanged)
      completeShowHideFragment(paramFragment); 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      if (USE_STATE_MANAGER) {
        this.mFragmentStore.moveToExpectedState();
      } else {
        null = this.mFragmentStore.getFragments().iterator();
        while (null.hasNext())
          moveFragmentToExpectedState(null.next()); 
        for (FragmentStateManager fragmentStateManager : this.mFragmentStore.getActiveFragmentStateManagers()) {
          Fragment fragment = fragmentStateManager.getFragment();
          if (!fragment.mIsNewlyAdded)
            moveFragmentToExpectedState(fragment); 
          if (fragment.mRemoving && !fragment.isInBackStack()) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          if (paramInt != 0)
            this.mFragmentStore.makeInactive(fragmentStateManager); 
        } 
      } 
      startPendingDeferredFragments();
      if (this.mNeedMenuInvalidate) {
        FragmentHostCallback<?> fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null && this.mCurState == 7) {
          fragmentHostCallback.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState);
  }
  
  void moveToState(Fragment paramFragment, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mFragmentStore : Landroidx/fragment/app/FragmentStore;
    //   4: aload_1
    //   5: getfield mWho : Ljava/lang/String;
    //   8: invokevirtual getFragmentStateManager : (Ljava/lang/String;)Landroidx/fragment/app/FragmentStateManager;
    //   11: astore #6
    //   13: iconst_1
    //   14: istore #4
    //   16: aload #6
    //   18: astore #5
    //   20: aload #6
    //   22: ifnonnull -> 49
    //   25: new androidx/fragment/app/FragmentStateManager
    //   28: dup
    //   29: aload_0
    //   30: getfield mLifecycleCallbacksDispatcher : Landroidx/fragment/app/FragmentLifecycleCallbacksDispatcher;
    //   33: aload_0
    //   34: getfield mFragmentStore : Landroidx/fragment/app/FragmentStore;
    //   37: aload_1
    //   38: invokespecial <init> : (Landroidx/fragment/app/FragmentLifecycleCallbacksDispatcher;Landroidx/fragment/app/FragmentStore;Landroidx/fragment/app/Fragment;)V
    //   41: astore #5
    //   43: aload #5
    //   45: iconst_1
    //   46: invokevirtual setFragmentManagerState : (I)V
    //   49: iload_2
    //   50: istore_3
    //   51: aload_1
    //   52: getfield mFromLayout : Z
    //   55: ifeq -> 83
    //   58: iload_2
    //   59: istore_3
    //   60: aload_1
    //   61: getfield mInLayout : Z
    //   64: ifeq -> 83
    //   67: iload_2
    //   68: istore_3
    //   69: aload_1
    //   70: getfield mState : I
    //   73: iconst_2
    //   74: if_icmpne -> 83
    //   77: iload_2
    //   78: iconst_2
    //   79: invokestatic max : (II)I
    //   82: istore_3
    //   83: iload_3
    //   84: aload #5
    //   86: invokevirtual computeExpectedState : ()I
    //   89: invokestatic min : (II)I
    //   92: istore_2
    //   93: aload_1
    //   94: getfield mState : I
    //   97: iload_2
    //   98: if_icmpgt -> 241
    //   101: aload_1
    //   102: getfield mState : I
    //   105: iload_2
    //   106: if_icmpge -> 126
    //   109: aload_0
    //   110: getfield mExitAnimationCancellationSignals : Ljava/util/Map;
    //   113: invokeinterface isEmpty : ()Z
    //   118: ifne -> 126
    //   121: aload_0
    //   122: aload_1
    //   123: invokespecial cancelExitAnimation : (Landroidx/fragment/app/Fragment;)V
    //   126: aload_1
    //   127: getfield mState : I
    //   130: istore_3
    //   131: iload_3
    //   132: iconst_m1
    //   133: if_icmpeq -> 165
    //   136: iload_3
    //   137: ifeq -> 175
    //   140: iload_3
    //   141: iconst_1
    //   142: if_icmpeq -> 184
    //   145: iload_3
    //   146: iconst_2
    //   147: if_icmpeq -> 204
    //   150: iload_3
    //   151: iconst_4
    //   152: if_icmpeq -> 214
    //   155: iload_3
    //   156: iconst_5
    //   157: if_icmpeq -> 224
    //   160: iload_2
    //   161: istore_3
    //   162: goto -> 685
    //   165: iload_2
    //   166: iconst_m1
    //   167: if_icmple -> 175
    //   170: aload #5
    //   172: invokevirtual attach : ()V
    //   175: iload_2
    //   176: ifle -> 184
    //   179: aload #5
    //   181: invokevirtual create : ()V
    //   184: iload_2
    //   185: iconst_m1
    //   186: if_icmple -> 194
    //   189: aload #5
    //   191: invokevirtual ensureInflatedView : ()V
    //   194: iload_2
    //   195: iconst_1
    //   196: if_icmple -> 204
    //   199: aload #5
    //   201: invokevirtual createView : ()V
    //   204: iload_2
    //   205: iconst_2
    //   206: if_icmple -> 214
    //   209: aload #5
    //   211: invokevirtual activityCreated : ()V
    //   214: iload_2
    //   215: iconst_4
    //   216: if_icmple -> 224
    //   219: aload #5
    //   221: invokevirtual start : ()V
    //   224: iload_2
    //   225: istore_3
    //   226: iload_2
    //   227: iconst_5
    //   228: if_icmple -> 685
    //   231: aload #5
    //   233: invokevirtual resume : ()V
    //   236: iload_2
    //   237: istore_3
    //   238: goto -> 685
    //   241: iload_2
    //   242: istore_3
    //   243: aload_1
    //   244: getfield mState : I
    //   247: iload_2
    //   248: if_icmple -> 685
    //   251: aload_1
    //   252: getfield mState : I
    //   255: istore_3
    //   256: iload_3
    //   257: ifeq -> 674
    //   260: iload_3
    //   261: iconst_1
    //   262: if_icmpeq -> 645
    //   265: iload_3
    //   266: iconst_2
    //   267: if_icmpeq -> 390
    //   270: iload_3
    //   271: iconst_4
    //   272: if_icmpeq -> 312
    //   275: iload_3
    //   276: iconst_5
    //   277: if_icmpeq -> 302
    //   280: iload_3
    //   281: bipush #7
    //   283: if_icmpeq -> 291
    //   286: iload_2
    //   287: istore_3
    //   288: goto -> 685
    //   291: iload_2
    //   292: bipush #7
    //   294: if_icmpge -> 302
    //   297: aload #5
    //   299: invokevirtual pause : ()V
    //   302: iload_2
    //   303: iconst_5
    //   304: if_icmpge -> 312
    //   307: aload #5
    //   309: invokevirtual stop : ()V
    //   312: iload_2
    //   313: iconst_4
    //   314: if_icmpge -> 390
    //   317: iconst_3
    //   318: invokestatic isLoggingEnabled : (I)Z
    //   321: ifeq -> 360
    //   324: new java/lang/StringBuilder
    //   327: dup
    //   328: invokespecial <init> : ()V
    //   331: astore #6
    //   333: aload #6
    //   335: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload #6
    //   344: aload_1
    //   345: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   348: pop
    //   349: ldc 'FragmentManager'
    //   351: aload #6
    //   353: invokevirtual toString : ()Ljava/lang/String;
    //   356: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   359: pop
    //   360: aload_1
    //   361: getfield mView : Landroid/view/View;
    //   364: ifnull -> 390
    //   367: aload_0
    //   368: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   371: aload_1
    //   372: invokevirtual onShouldSaveFragmentState : (Landroidx/fragment/app/Fragment;)Z
    //   375: ifeq -> 390
    //   378: aload_1
    //   379: getfield mSavedViewState : Landroid/util/SparseArray;
    //   382: ifnonnull -> 390
    //   385: aload #5
    //   387: invokevirtual saveViewState : ()V
    //   390: iload_2
    //   391: iconst_2
    //   392: if_icmpge -> 645
    //   395: aconst_null
    //   396: astore #7
    //   398: aload_1
    //   399: getfield mView : Landroid/view/View;
    //   402: ifnull -> 627
    //   405: aload_1
    //   406: getfield mContainer : Landroid/view/ViewGroup;
    //   409: ifnull -> 627
    //   412: aload_1
    //   413: getfield mContainer : Landroid/view/ViewGroup;
    //   416: aload_1
    //   417: getfield mView : Landroid/view/View;
    //   420: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   423: aload_1
    //   424: getfield mView : Landroid/view/View;
    //   427: invokevirtual clearAnimation : ()V
    //   430: aload_1
    //   431: invokevirtual isRemovingParent : ()Z
    //   434: ifne -> 627
    //   437: aload #7
    //   439: astore #6
    //   441: aload_0
    //   442: getfield mCurState : I
    //   445: iconst_m1
    //   446: if_icmple -> 501
    //   449: aload #7
    //   451: astore #6
    //   453: aload_0
    //   454: getfield mDestroyed : Z
    //   457: ifne -> 501
    //   460: aload #7
    //   462: astore #6
    //   464: aload_1
    //   465: getfield mView : Landroid/view/View;
    //   468: invokevirtual getVisibility : ()I
    //   471: ifne -> 501
    //   474: aload #7
    //   476: astore #6
    //   478: aload_1
    //   479: getfield mPostponedAlpha : F
    //   482: fconst_0
    //   483: fcmpl
    //   484: iflt -> 501
    //   487: aload_0
    //   488: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   491: invokevirtual getContext : ()Landroid/content/Context;
    //   494: aload_1
    //   495: iconst_0
    //   496: invokestatic loadAnimation : (Landroid/content/Context;Landroidx/fragment/app/Fragment;Z)Landroidx/fragment/app/FragmentAnim$AnimationOrAnimator;
    //   499: astore #6
    //   501: aload_1
    //   502: fconst_0
    //   503: putfield mPostponedAlpha : F
    //   506: aload_1
    //   507: getfield mContainer : Landroid/view/ViewGroup;
    //   510: astore #7
    //   512: aload_1
    //   513: getfield mView : Landroid/view/View;
    //   516: astore #8
    //   518: aload #6
    //   520: ifnull -> 533
    //   523: aload_1
    //   524: aload #6
    //   526: aload_0
    //   527: getfield mFragmentTransitionCallback : Landroidx/fragment/app/FragmentTransition$Callback;
    //   530: invokestatic animateRemoveFragment : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/FragmentAnim$AnimationOrAnimator;Landroidx/fragment/app/FragmentTransition$Callback;)V
    //   533: aload #7
    //   535: aload #8
    //   537: invokevirtual removeView : (Landroid/view/View;)V
    //   540: iconst_2
    //   541: invokestatic isLoggingEnabled : (I)Z
    //   544: ifeq -> 617
    //   547: new java/lang/StringBuilder
    //   550: dup
    //   551: invokespecial <init> : ()V
    //   554: astore #6
    //   556: aload #6
    //   558: ldc_w 'Removing view '
    //   561: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: pop
    //   565: aload #6
    //   567: aload #8
    //   569: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   572: pop
    //   573: aload #6
    //   575: ldc_w ' for fragment '
    //   578: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: aload #6
    //   584: aload_1
    //   585: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   588: pop
    //   589: aload #6
    //   591: ldc_w ' from container '
    //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: pop
    //   598: aload #6
    //   600: aload #7
    //   602: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   605: pop
    //   606: ldc 'FragmentManager'
    //   608: aload #6
    //   610: invokevirtual toString : ()Ljava/lang/String;
    //   613: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   616: pop
    //   617: aload #7
    //   619: aload_1
    //   620: getfield mContainer : Landroid/view/ViewGroup;
    //   623: if_acmpeq -> 627
    //   626: return
    //   627: aload_0
    //   628: getfield mExitAnimationCancellationSignals : Ljava/util/Map;
    //   631: aload_1
    //   632: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   637: ifnonnull -> 645
    //   640: aload #5
    //   642: invokevirtual destroyFragmentView : ()V
    //   645: iload_2
    //   646: iconst_1
    //   647: if_icmpge -> 674
    //   650: aload_0
    //   651: getfield mExitAnimationCancellationSignals : Ljava/util/Map;
    //   654: aload_1
    //   655: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   660: ifnull -> 669
    //   663: iload #4
    //   665: istore_2
    //   666: goto -> 674
    //   669: aload #5
    //   671: invokevirtual destroy : ()V
    //   674: iload_2
    //   675: ifge -> 683
    //   678: aload #5
    //   680: invokevirtual detach : ()V
    //   683: iload_2
    //   684: istore_3
    //   685: aload_1
    //   686: getfield mState : I
    //   689: iload_3
    //   690: if_icmpeq -> 776
    //   693: iconst_3
    //   694: invokestatic isLoggingEnabled : (I)Z
    //   697: ifeq -> 771
    //   700: new java/lang/StringBuilder
    //   703: dup
    //   704: invokespecial <init> : ()V
    //   707: astore #5
    //   709: aload #5
    //   711: ldc_w 'moveToState: Fragment state for '
    //   714: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   717: pop
    //   718: aload #5
    //   720: aload_1
    //   721: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   724: pop
    //   725: aload #5
    //   727: ldc_w ' not updated inline; expected state '
    //   730: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #5
    //   736: iload_3
    //   737: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   740: pop
    //   741: aload #5
    //   743: ldc_w ' found '
    //   746: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #5
    //   752: aload_1
    //   753: getfield mState : I
    //   756: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   759: pop
    //   760: ldc 'FragmentManager'
    //   762: aload #5
    //   764: invokevirtual toString : ()Ljava/lang/String;
    //   767: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   770: pop
    //   771: aload_1
    //   772: iload_3
    //   773: putfield mState : I
    //   776: return
  }
  
  void noteStateNotSaved() {
    if (this.mHost == null)
      return; 
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  @Deprecated
  public FragmentTransaction openTransaction() {
    return beginTransaction();
  }
  
  void performPendingDeferredStart(FragmentStateManager paramFragmentStateManager) {
    Fragment fragment = paramFragmentStateManager.getFragment();
    if (fragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      fragment.mDeferStart = false;
      if (USE_STATE_MANAGER) {
        paramFragmentStateManager.moveToExpectedState();
        return;
      } 
      moveToState(fragment);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0)
      return popBackStackImmediate(null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 70
    //   17: iload #4
    //   19: ifge -> 70
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 70
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield mBackStack : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: iconst_1
    //   61: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   64: invokevirtual add : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: iconst_1
    //   69: ireturn
    //   70: aload_3
    //   71: ifnonnull -> 88
    //   74: iload #4
    //   76: iflt -> 82
    //   79: goto -> 88
    //   82: iconst_m1
    //   83: istore #4
    //   85: goto -> 263
    //   88: aload #8
    //   90: invokevirtual size : ()I
    //   93: iconst_1
    //   94: isub
    //   95: istore #6
    //   97: iload #6
    //   99: iflt -> 162
    //   102: aload_0
    //   103: getfield mBackStack : Ljava/util/ArrayList;
    //   106: iload #6
    //   108: invokevirtual get : (I)Ljava/lang/Object;
    //   111: checkcast androidx/fragment/app/BackStackRecord
    //   114: astore #8
    //   116: aload_3
    //   117: ifnull -> 135
    //   120: aload_3
    //   121: aload #8
    //   123: invokevirtual getName : ()Ljava/lang/String;
    //   126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   129: ifeq -> 135
    //   132: goto -> 162
    //   135: iload #4
    //   137: iflt -> 153
    //   140: iload #4
    //   142: aload #8
    //   144: getfield mIndex : I
    //   147: if_icmpne -> 153
    //   150: goto -> 162
    //   153: iload #6
    //   155: iconst_1
    //   156: isub
    //   157: istore #6
    //   159: goto -> 97
    //   162: iload #6
    //   164: ifge -> 169
    //   167: iconst_0
    //   168: ireturn
    //   169: iload #6
    //   171: istore #7
    //   173: iload #5
    //   175: iconst_1
    //   176: iand
    //   177: ifeq -> 259
    //   180: iload #6
    //   182: iconst_1
    //   183: isub
    //   184: istore #5
    //   186: iload #5
    //   188: istore #7
    //   190: iload #5
    //   192: iflt -> 259
    //   195: aload_0
    //   196: getfield mBackStack : Ljava/util/ArrayList;
    //   199: iload #5
    //   201: invokevirtual get : (I)Ljava/lang/Object;
    //   204: checkcast androidx/fragment/app/BackStackRecord
    //   207: astore #8
    //   209: aload_3
    //   210: ifnull -> 229
    //   213: iload #5
    //   215: istore #6
    //   217: aload_3
    //   218: aload #8
    //   220: invokevirtual getName : ()Ljava/lang/String;
    //   223: invokevirtual equals : (Ljava/lang/Object;)Z
    //   226: ifne -> 180
    //   229: iload #5
    //   231: istore #7
    //   233: iload #4
    //   235: iflt -> 259
    //   238: iload #5
    //   240: istore #7
    //   242: iload #4
    //   244: aload #8
    //   246: getfield mIndex : I
    //   249: if_icmpne -> 259
    //   252: iload #5
    //   254: istore #6
    //   256: goto -> 180
    //   259: iload #7
    //   261: istore #4
    //   263: iload #4
    //   265: aload_0
    //   266: getfield mBackStack : Ljava/util/ArrayList;
    //   269: invokevirtual size : ()I
    //   272: iconst_1
    //   273: isub
    //   274: if_icmpne -> 279
    //   277: iconst_0
    //   278: ireturn
    //   279: aload_0
    //   280: getfield mBackStack : Ljava/util/ArrayList;
    //   283: invokevirtual size : ()I
    //   286: iconst_1
    //   287: isub
    //   288: istore #5
    //   290: iload #5
    //   292: iload #4
    //   294: if_icmple -> 329
    //   297: aload_1
    //   298: aload_0
    //   299: getfield mBackStack : Ljava/util/ArrayList;
    //   302: iload #5
    //   304: invokevirtual remove : (I)Ljava/lang/Object;
    //   307: invokevirtual add : (Ljava/lang/Object;)Z
    //   310: pop
    //   311: aload_2
    //   312: iconst_1
    //   313: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   316: invokevirtual add : (Ljava/lang/Object;)Z
    //   319: pop
    //   320: iload #5
    //   322: iconst_1
    //   323: isub
    //   324: istore #5
    //   326: goto -> 290
    //   329: iconst_1
    //   330: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacksDispatcher.registerFragmentLifecycleCallbacks(paramFragmentLifecycleCallbacks, paramBoolean);
  }
  
  void removeCancellationSignal(Fragment paramFragment, CancellationSignal paramCancellationSignal) {
    HashSet hashSet = this.mExitAnimationCancellationSignals.get(paramFragment);
    if (hashSet != null && hashSet.remove(paramCancellationSignal) && hashSet.isEmpty()) {
      this.mExitAnimationCancellationSignals.remove(paramFragment);
      if (paramFragment.mState < 5) {
        destroyFragmentView(paramFragment);
        moveToState(paramFragment);
      } 
    } 
  }
  
  void removeFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0) {
      this.mFragmentStore.removeFragment(paramFragment);
      if (isMenuAvailable(paramFragment))
        this.mNeedMenuInvalidate = true; 
      paramFragment.mRemoving = true;
      setVisibleRemovingFragment(paramFragment);
    } 
  }
  
  public void removeFragmentOnAttachListener(FragmentOnAttachListener paramFragmentOnAttachListener) {
    this.mOnAttachListeners.remove(paramFragmentOnAttachListener);
  }
  
  public void removeOnBackStackChangedListener(OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void removeRetainedFragment(Fragment paramFragment) {
    this.mNonConfig.removeRetainedFragment(paramFragment);
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You must use restoreSaveState when your FragmentHostCallback implements ViewModelStoreOwner")); 
    this.mNonConfig.restoreFromSnapshot(paramFragmentManagerNonConfig);
    restoreSaveState(paramParcelable);
  }
  
  void restoreSaveState(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
    if (fragmentManagerState.mActive == null)
      return; 
    this.mFragmentStore.resetActiveFragments();
    for (Parcelable paramParcelable : fragmentManagerState.mActive) {
      if (paramParcelable != null) {
        FragmentStateManager fragmentStateManager;
        Fragment fragment = this.mNonConfig.findRetainedFragmentByWho(((FragmentState)paramParcelable).mWho);
        if (fragment != null) {
          if (isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, fragment, (FragmentState)paramParcelable);
        } else {
          fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, this.mHost.getContext().getClassLoader(), getFragmentFactory(), (FragmentState)fragmentStateManager);
        } 
        fragment = fragmentStateManager.getFragment();
        fragment.mFragmentManager = this;
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreSaveState: active (");
          stringBuilder.append(fragment.mWho);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        fragmentStateManager.restoreState(this.mHost.getContext().getClassLoader());
        this.mFragmentStore.makeActive(fragmentStateManager);
        fragmentStateManager.setFragmentManagerState(this.mCurState);
      } 
    } 
    for (Fragment fragment : this.mNonConfig.getRetainedFragments()) {
      if (!this.mFragmentStore.containsActiveFragment(fragment.mWho)) {
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(fragmentManagerState.mActive);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mNonConfig.removeRetainedFragment(fragment);
        fragment.mFragmentManager = this;
        FragmentStateManager fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, fragment);
        fragmentStateManager.setFragmentManagerState(1);
        fragmentStateManager.moveToExpectedState();
        fragment.mRemoving = true;
        fragmentStateManager.moveToExpectedState();
      } 
    } 
    this.mFragmentStore.restoreAddedFragments(fragmentManagerState.mAdded);
    BackStackState[] arrayOfBackStackState = fragmentManagerState.mBackStack;
    byte b = 0;
    if (arrayOfBackStackState != null) {
      this.mBackStack = new ArrayList<BackStackRecord>(fragmentManagerState.mBackStack.length);
      for (int i = 0; i < fragmentManagerState.mBackStack.length; i++) {
        BackStackRecord backStackRecord = fragmentManagerState.mBackStack[i].instantiate(this);
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: back stack #");
          stringBuilder.append(i);
          stringBuilder.append(" (index ");
          stringBuilder.append(backStackRecord.mIndex);
          stringBuilder.append("): ");
          stringBuilder.append(backStackRecord);
          Log.v("FragmentManager", stringBuilder.toString());
          PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
          backStackRecord.dump("  ", printWriter, false);
          printWriter.close();
        } 
        this.mBackStack.add(backStackRecord);
      } 
    } else {
      this.mBackStack = null;
    } 
    this.mBackStackIndex.set(fragmentManagerState.mBackStackIndex);
    if (fragmentManagerState.mPrimaryNavActiveWho != null) {
      Fragment fragment = findActiveFragment(fragmentManagerState.mPrimaryNavActiveWho);
      this.mPrimaryNav = fragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
    } 
    ArrayList<String> arrayList = fragmentManagerState.mResultKeys;
    if (arrayList != null)
      for (int i = b; i < arrayList.size(); i++)
        this.mResults.put(arrayList.get(i), fragmentManagerState.mResults.get(i));  
    this.mLaunchedFragments = new ArrayDeque<LaunchedFragmentInfo>(fragmentManagerState.mLaunchedFragments);
  }
  
  @Deprecated
  FragmentManagerNonConfig retainNonConfig() {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You cannot use retainNonConfig when your FragmentHostCallback implements ViewModelStoreOwner.")); 
    return this.mNonConfig.getSnapshot();
  }
  
  Parcelable saveAllState() {
    StringBuilder stringBuilder;
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions(true);
    this.mStateSaved = true;
    this.mNonConfig.setIsStateSaved(true);
    ArrayList arrayList1 = this.mFragmentStore.saveActiveFragments();
    boolean bool = arrayList1.isEmpty();
    BackStackState[] arrayOfBackStackState2 = null;
    if (bool) {
      if (isLoggingEnabled(2))
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    ArrayList arrayList2 = this.mFragmentStore.saveAddedFragments();
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
    if (arrayList != null) {
      int i = arrayList.size();
      arrayOfBackStackState1 = arrayOfBackStackState2;
      if (i > 0) {
        arrayOfBackStackState2 = new BackStackState[i];
        int j = 0;
        while (true) {
          arrayOfBackStackState1 = arrayOfBackStackState2;
          if (j < i) {
            arrayOfBackStackState2[j] = new BackStackState(this.mBackStack.get(j));
            if (isLoggingEnabled(2)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(j);
              stringBuilder.append(": ");
              stringBuilder.append(this.mBackStack.get(j));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            j++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.mActive = arrayList1;
    fragmentManagerState.mAdded = arrayList2;
    fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
    fragmentManagerState.mBackStackIndex = this.mBackStackIndex.get();
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null)
      fragmentManagerState.mPrimaryNavActiveWho = fragment.mWho; 
    fragmentManagerState.mResultKeys.addAll(this.mResults.keySet());
    fragmentManagerState.mResults.addAll(this.mResults.values());
    fragmentManagerState.mLaunchedFragments = new ArrayList<LaunchedFragmentInfo>(this.mLaunchedFragments);
    return (Parcelable)fragmentManagerState;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    FragmentStateManager fragmentStateManager = this.mFragmentStore.getFragmentStateManager(paramFragment.mWho);
    if (fragmentStateManager == null || !fragmentStateManager.getFragment().equals(paramFragment)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragmentStateManager.saveInstanceState();
  }
  
  void scheduleCommit() {
    boolean bool1;
    boolean bool2;
    synchronized (this.mPendingActions) {
      ArrayList<StartEnterTransitionListener> arrayList = this.mPostponedTransactions;
      bool2 = false;
      if (arrayList != null && !arrayList.isEmpty()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.mPendingActions.size() == 1)
        bool2 = true; 
    } 
    if (bool1 || bool2) {
      this.mHost.getHandler().removeCallbacks(this.mExecCommit);
      this.mHost.getHandler().post(this.mExecCommit);
      updateOnBackPressedCallbackEnabled();
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  void setExitAnimationOrder(Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = getFragmentContainer(paramFragment);
    if (viewGroup != null && viewGroup instanceof FragmentContainerView)
      ((FragmentContainerView)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public void setFragmentFactory(FragmentFactory paramFragmentFactory) {
    this.mFragmentFactory = paramFragmentFactory;
  }
  
  public final void setFragmentResult(String paramString, Bundle paramBundle) {
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.get(paramString);
    if (lifecycleAwareResultListener != null && lifecycleAwareResultListener.isAtLeast(Lifecycle.State.STARTED)) {
      lifecycleAwareResultListener.onFragmentResult(paramString, paramBundle);
      return;
    } 
    this.mResults.put(paramString, paramBundle);
  }
  
  public final void setFragmentResultListener(final String requestKey, LifecycleOwner paramLifecycleOwner, final FragmentResultListener listener) {
    final Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    if (lifecycle.getCurrentState() == Lifecycle.State.DESTROYED)
      return; 
    LifecycleEventObserver lifecycleEventObserver = new LifecycleEventObserver() {
        public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
          if (param1Event == Lifecycle.Event.ON_START) {
            Bundle bundle = (Bundle)FragmentManager.this.mResults.get(requestKey);
            if (bundle != null) {
              listener.onFragmentResult(requestKey, bundle);
              FragmentManager.this.clearFragmentResult(requestKey);
            } 
          } 
          if (param1Event == Lifecycle.Event.ON_DESTROY) {
            lifecycle.removeObserver((LifecycleObserver)this);
            FragmentManager.this.mResultListeners.remove(requestKey);
          } 
        }
      };
    lifecycle.addObserver((LifecycleObserver)lifecycleEventObserver);
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.put(requestKey, new LifecycleAwareResultListener(lifecycle, listener, lifecycleEventObserver));
    if (lifecycleAwareResultListener != null)
      lifecycleAwareResultListener.removeObserver(); 
  }
  
  void setMaxLifecycle(Fragment paramFragment, Lifecycle.State paramState) {
    if (paramFragment.equals(findActiveFragment(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(findActiveFragment(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this))) {
      Fragment fragment = this.mPrimaryNav;
      this.mPrimaryNav = paramFragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
      dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void setSpecialEffectsControllerFactory(SpecialEffectsControllerFactory paramSpecialEffectsControllerFactory) {
    this.mSpecialEffectsControllerFactory = paramSpecialEffectsControllerFactory;
  }
  
  void showFragment(Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mParent)));
      stringBuilder.append("}");
    } else {
      FragmentHostCallback<?> fragmentHostCallback = this.mHost;
      if (fragmentHostCallback != null) {
        stringBuilder.append(fragmentHostCallback.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mHost)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    this.mLifecycleCallbacksDispatcher.unregisterFragmentLifecycleCallbacks(paramFragmentLifecycleCallbacks);
  }
  
  public static interface BackStackEntry {
    @Deprecated
    CharSequence getBreadCrumbShortTitle();
    
    @Deprecated
    int getBreadCrumbShortTitleRes();
    
    @Deprecated
    CharSequence getBreadCrumbTitle();
    
    @Deprecated
    int getBreadCrumbTitleRes();
    
    int getId();
    
    String getName();
  }
  
  static class FragmentIntentSenderContract extends ActivityResultContract<IntentSenderRequest, ActivityResult> {
    public Intent createIntent(Context param1Context, IntentSenderRequest param1IntentSenderRequest) {
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = param1IntentSenderRequest.getFillInIntent();
      IntentSenderRequest intentSenderRequest = param1IntentSenderRequest;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intentSenderRequest = param1IntentSenderRequest;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          intentSenderRequest = param1IntentSenderRequest;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false))
            intentSenderRequest = (new IntentSenderRequest.Builder(param1IntentSenderRequest.getIntentSender())).setFillInIntent(null).setFlags(param1IntentSenderRequest.getFlagsValues(), param1IntentSenderRequest.getFlagsMask()).build(); 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)intentSenderRequest);
      if (FragmentManager.isLoggingEnabled(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CreateIntent created the following intent: ");
        stringBuilder.append(intent1);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return intent1;
    }
    
    public ActivityResult parseResult(int param1Int, Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
  }
  
  public static abstract class FragmentLifecycleCallbacks {
    @Deprecated
    public void onFragmentActivityCreated(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void onFragmentAttached(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context) {}
    
    public void onFragmentCreated(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void onFragmentDestroyed(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentDetached(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentPaused(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentPreAttached(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context) {}
    
    public void onFragmentPreCreated(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void onFragmentResumed(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentSaveInstanceState(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void onFragmentStarted(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentStopped(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void onFragmentViewCreated(FragmentManager param1FragmentManager, Fragment param1Fragment, View param1View, Bundle param1Bundle) {}
    
    public void onFragmentViewDestroyed(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
  }
  
  static class LaunchedFragmentInfo implements Parcelable {
    public static final Parcelable.Creator<LaunchedFragmentInfo> CREATOR = new Parcelable.Creator<LaunchedFragmentInfo>() {
        public FragmentManager.LaunchedFragmentInfo createFromParcel(Parcel param2Parcel) {
          return new FragmentManager.LaunchedFragmentInfo(param2Parcel);
        }
        
        public FragmentManager.LaunchedFragmentInfo[] newArray(int param2Int) {
          return new FragmentManager.LaunchedFragmentInfo[param2Int];
        }
      };
    
    int mRequestCode;
    
    String mWho;
    
    LaunchedFragmentInfo(Parcel param1Parcel) {
      this.mWho = param1Parcel.readString();
      this.mRequestCode = param1Parcel.readInt();
    }
    
    LaunchedFragmentInfo(String param1String, int param1Int) {
      this.mWho = param1String;
      this.mRequestCode = param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.mWho);
      param1Parcel.writeInt(this.mRequestCode);
    }
  }
  
  class null implements Parcelable.Creator<LaunchedFragmentInfo> {
    public FragmentManager.LaunchedFragmentInfo createFromParcel(Parcel param1Parcel) {
      return new FragmentManager.LaunchedFragmentInfo(param1Parcel);
    }
    
    public FragmentManager.LaunchedFragmentInfo[] newArray(int param1Int) {
      return new FragmentManager.LaunchedFragmentInfo[param1Int];
    }
  }
  
  private static class LifecycleAwareResultListener implements FragmentResultListener {
    private final Lifecycle mLifecycle;
    
    private final FragmentResultListener mListener;
    
    private final LifecycleEventObserver mObserver;
    
    LifecycleAwareResultListener(Lifecycle param1Lifecycle, FragmentResultListener param1FragmentResultListener, LifecycleEventObserver param1LifecycleEventObserver) {
      this.mLifecycle = param1Lifecycle;
      this.mListener = param1FragmentResultListener;
      this.mObserver = param1LifecycleEventObserver;
    }
    
    public boolean isAtLeast(Lifecycle.State param1State) {
      return this.mLifecycle.getCurrentState().isAtLeast(param1State);
    }
    
    public void onFragmentResult(String param1String, Bundle param1Bundle) {
      this.mListener.onFragmentResult(param1String, param1Bundle);
    }
    
    public void removeObserver() {
      this.mLifecycle.removeObserver((LifecycleObserver)this.mObserver);
    }
  }
  
  public static interface OnBackStackChangedListener {
    void onBackStackChanged();
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      return (FragmentManager.this.mPrimaryNav != null && this.mId < 0 && this.mName == null && FragmentManager.this.mPrimaryNav.getChildFragmentManager().popBackStackImmediate()) ? false : FragmentManager.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    final boolean mIsBack;
    
    private int mNumPostponed;
    
    final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    void completeTransaction() {
      boolean bool;
      if (this.mNumPostponed > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      for (Fragment fragment : this.mRecord.mManager.getFragments()) {
        fragment.setOnStartEnterTransitionListener(null);
        if (bool && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
      } 
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, bool ^ true, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      int i = this.mNumPostponed - 1;
      this.mNumPostponed = i;
      if (i != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Quiz-dex2jar.jar!\androidx\fragment\app\FragmentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */