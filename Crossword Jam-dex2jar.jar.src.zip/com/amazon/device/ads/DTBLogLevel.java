package com.amazon.device.ads;

public enum DTBLogLevel {
  All, Debug, Error, Fatal, Info, Off, Trace, Warn;
  
  private int value;
  
  static {
    DTBLogLevel dTBLogLevel1 = new DTBLogLevel("All", 0, 0);
    All = dTBLogLevel1;
    DTBLogLevel dTBLogLevel2 = new DTBLogLevel("Trace", 1, 1);
    Trace = dTBLogLevel2;
    DTBLogLevel dTBLogLevel3 = new DTBLogLevel("Debug", 2, 2);
    Debug = dTBLogLevel3;
    DTBLogLevel dTBLogLevel4 = new DTBLogLevel("Info", 3, 3);
    Info = dTBLogLevel4;
    DTBLogLevel dTBLogLevel5 = new DTBLogLevel("Warn", 4, 4);
    Warn = dTBLogLevel5;
    DTBLogLevel dTBLogLevel6 = new DTBLogLevel("Error", 5, 5);
    Error = dTBLogLevel6;
    DTBLogLevel dTBLogLevel7 = new DTBLogLevel("Fatal", 6, 6);
    Fatal = dTBLogLevel7;
    DTBLogLevel dTBLogLevel8 = new DTBLogLevel("Off", 7, 7);
    Off = dTBLogLevel8;
    $VALUES = new DTBLogLevel[] { dTBLogLevel1, dTBLogLevel2, dTBLogLevel3, dTBLogLevel4, dTBLogLevel5, dTBLogLevel6, dTBLogLevel7, dTBLogLevel8 };
  }
  
  DTBLogLevel(int paramInt1) {
    this.value = paramInt1;
  }
  
  public int intValue() {
    return this.value;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\amazon\device\ads\DTBLogLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */