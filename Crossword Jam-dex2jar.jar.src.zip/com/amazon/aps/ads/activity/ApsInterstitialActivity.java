package com.amazon.aps.ads.activity;

import android.view.MotionEvent;
import com.amazon.device.ads.DTBInterstitialActivity;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public class ApsInterstitialActivity extends DTBInterstitialActivity {
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.amazon.device.ads", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\amazon\aps\ads\activity\ApsInterstitialActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */