package com.applovin.array.apphub.aidl;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IAppHubService extends IInterface {
  void directInstall(String paramString, Bundle paramBundle, IAppHubDirectDownloadServiceCallback paramIAppHubDirectDownloadServiceCallback) throws RemoteException;
  
  void dismissDirectDownloadAppDetails(String paramString) throws RemoteException;
  
  long getAppHubVersionCode() throws RemoteException;
  
  Bundle getEnabledFeatures() throws RemoteException;
  
  String getRandomUserToken() throws RemoteException;
  
  void showDirectDownloadAppDetails(String paramString, IAppHubDirectDownloadServiceCallback paramIAppHubDirectDownloadServiceCallback) throws RemoteException;
  
  void showDirectDownloadAppDetailsWithExtra(String paramString, Bundle paramBundle, IAppHubDirectDownloadServiceCallback paramIAppHubDirectDownloadServiceCallback) throws RemoteException;
  
  public static abstract class Stub extends Binder implements IAppHubService {
    private static final String DESCRIPTOR = "com.applovin.array.apphub.aidl.IAppHubService";
    
    static final int TRANSACTION_directInstall = 7;
    
    static final int TRANSACTION_dismissDirectDownloadAppDetails = 5;
    
    static final int TRANSACTION_getAppHubVersionCode = 2;
    
    static final int TRANSACTION_getEnabledFeatures = 3;
    
    static final int TRANSACTION_getRandomUserToken = 1;
    
    static final int TRANSACTION_showDirectDownloadAppDetails = 4;
    
    static final int TRANSACTION_showDirectDownloadAppDetailsWithExtra = 6;
    
    public Stub() {
      attachInterface(this, "com.applovin.array.apphub.aidl.IAppHubService");
    }
    
    public static IAppHubService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.applovin.array.apphub.aidl.IAppHubService");
      return (iInterface != null && iInterface instanceof IAppHubService) ? (IAppHubService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      Bundle bundle;
      if (param1Int1 != 1598968902) {
        Bundle bundle1;
        Bundle bundle2;
        String str2;
        long l;
        String str3;
        String str4 = null;
        Parcel parcel = null;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 7:
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            str4 = param1Parcel1.readString();
            param1Parcel2 = parcel;
            if (param1Parcel1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            directInstall(str4, bundle2, IAppHubDirectDownloadServiceCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
            return true;
          case 6:
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            str3 = param1Parcel1.readString();
            str2 = str4;
            if (param1Parcel1.readInt() != 0)
              bundle = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            showDirectDownloadAppDetailsWithExtra(str3, bundle, IAppHubDirectDownloadServiceCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
            return true;
          case 5:
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            dismissDirectDownloadAppDetails(param1Parcel1.readString());
            bundle.writeNoException();
            return true;
          case 4:
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            showDirectDownloadAppDetails(param1Parcel1.readString(), IAppHubDirectDownloadServiceCallback.Stub.asInterface(param1Parcel1.readStrongBinder()));
            return true;
          case 3:
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            bundle1 = getEnabledFeatures();
            bundle.writeNoException();
            if (bundle1 != null) {
              bundle.writeInt(1);
              bundle1.writeToParcel((Parcel)bundle, 1);
              return true;
            } 
            bundle.writeInt(0);
            return true;
          case 2:
            bundle1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
            l = getAppHubVersionCode();
            bundle.writeNoException();
            bundle.writeLong(l);
            return true;
          case 1:
            break;
        } 
        bundle1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubService");
        String str1 = getRandomUserToken();
        bundle.writeNoException();
        bundle.writeString(str1);
        return true;
      } 
      bundle.writeString("com.applovin.array.apphub.aidl.IAppHubService");
      return true;
    }
    
    private static class Proxy implements IAppHubService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void directInstall(String param2String, Bundle param2Bundle, IAppHubDirectDownloadServiceCallback param2IAppHubDirectDownloadServiceCallback) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          parcel.writeString(param2String);
          if (param2Bundle != null) {
            parcel.writeInt(1);
            param2Bundle.writeToParcel(parcel, 0);
          } else {
            parcel.writeInt(0);
          } 
          if (param2IAppHubDirectDownloadServiceCallback != null) {
            IBinder iBinder = param2IAppHubDirectDownloadServiceCallback.asBinder();
          } else {
            param2String = null;
          } 
          parcel.writeStrongBinder((IBinder)param2String);
          this.mRemote.transact(7, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void dismissDirectDownloadAppDetails(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          parcel1.writeString(param2String);
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public long getAppHubVersionCode() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readLong();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public Bundle getEnabledFeatures() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          Bundle bundle;
          parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            bundle = (Bundle)Bundle.CREATOR.createFromParcel(parcel2);
          } else {
            bundle = null;
          } 
          return bundle;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "com.applovin.array.apphub.aidl.IAppHubService";
      }
      
      public String getRandomUserToken() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void showDirectDownloadAppDetails(String param2String, IAppHubDirectDownloadServiceCallback param2IAppHubDirectDownloadServiceCallback) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          parcel.writeString(param2String);
          if (param2IAppHubDirectDownloadServiceCallback != null) {
            IBinder iBinder = param2IAppHubDirectDownloadServiceCallback.asBinder();
          } else {
            param2String = null;
          } 
          parcel.writeStrongBinder((IBinder)param2String);
          this.mRemote.transact(4, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void showDirectDownloadAppDetailsWithExtra(String param2String, Bundle param2Bundle, IAppHubDirectDownloadServiceCallback param2IAppHubDirectDownloadServiceCallback) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
          parcel.writeString(param2String);
          if (param2Bundle != null) {
            parcel.writeInt(1);
            param2Bundle.writeToParcel(parcel, 0);
          } else {
            parcel.writeInt(0);
          } 
          if (param2IAppHubDirectDownloadServiceCallback != null) {
            IBinder iBinder = param2IAppHubDirectDownloadServiceCallback.asBinder();
          } else {
            param2String = null;
          } 
          parcel.writeStrongBinder((IBinder)param2String);
          this.mRemote.transact(6, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IAppHubService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void directInstall(String param1String, Bundle param1Bundle, IAppHubDirectDownloadServiceCallback param1IAppHubDirectDownloadServiceCallback) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        parcel.writeString(param1String);
        if (param1Bundle != null) {
          parcel.writeInt(1);
          param1Bundle.writeToParcel(parcel, 0);
        } else {
          parcel.writeInt(0);
        } 
        if (param1IAppHubDirectDownloadServiceCallback != null) {
          IBinder iBinder = param1IAppHubDirectDownloadServiceCallback.asBinder();
        } else {
          param1String = null;
        } 
        parcel.writeStrongBinder((IBinder)param1String);
        this.mRemote.transact(7, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void dismissDirectDownloadAppDetails(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        parcel1.writeString(param1String);
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public long getAppHubVersionCode() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readLong();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public Bundle getEnabledFeatures() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        Bundle bundle;
        parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          bundle = (Bundle)Bundle.CREATOR.createFromParcel(parcel2);
        } else {
          bundle = null;
        } 
        return bundle;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "com.applovin.array.apphub.aidl.IAppHubService";
    }
    
    public String getRandomUserToken() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void showDirectDownloadAppDetails(String param1String, IAppHubDirectDownloadServiceCallback param1IAppHubDirectDownloadServiceCallback) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        parcel.writeString(param1String);
        if (param1IAppHubDirectDownloadServiceCallback != null) {
          IBinder iBinder = param1IAppHubDirectDownloadServiceCallback.asBinder();
        } else {
          param1String = null;
        } 
        parcel.writeStrongBinder((IBinder)param1String);
        this.mRemote.transact(4, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void showDirectDownloadAppDetailsWithExtra(String param1String, Bundle param1Bundle, IAppHubDirectDownloadServiceCallback param1IAppHubDirectDownloadServiceCallback) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubService");
        parcel.writeString(param1String);
        if (param1Bundle != null) {
          parcel.writeInt(1);
          param1Bundle.writeToParcel(parcel, 0);
        } else {
          parcel.writeInt(0);
        } 
        if (param1IAppHubDirectDownloadServiceCallback != null) {
          IBinder iBinder = param1IAppHubDirectDownloadServiceCallback.asBinder();
        } else {
          param1String = null;
        } 
        parcel.writeStrongBinder((IBinder)param1String);
        this.mRemote.transact(6, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\array\apphub\aidl\IAppHubService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */