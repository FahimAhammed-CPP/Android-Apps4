package com.applovin.impl.a.a.b.a;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.applovin.impl.a.a.a.a;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.l;
import com.applovin.sdk.R;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public class c extends Activity {
  private a a;
  
  private p b;
  
  private TextView c;
  
  private Button d;
  
  private void a() {
    l l = new l();
    l.a(this.b.af().a(this.a));
    String str = this.b.af().b(this.a.c());
    if (str != null) {
      l.a("\nBid Response Preview:\n");
      l.a(str);
    } 
    TextView textView = (TextView)findViewById(R.id.email_report_tv);
    this.c = textView;
    textView.setText(l.toString());
    this.c.setTextColor(-16777216);
  }
  
  public void a(a parama, p paramp) {
    this.a = parama;
    this.b = paramp;
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.applovin", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.a.a());
    stringBuilder.append(" - ");
    stringBuilder.append(this.a.b());
    setTitle(stringBuilder.toString());
    setContentView(R.layout.creative_debugger_displayed_ad_detail_activity);
    a();
    Button button = (Button)findViewById(R.id.report_ad_button);
    this.d = button;
    button.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            c.b(this.a).af().a(c.a(this.a), (Context)this.a, true);
          }
        });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(R.menu.creative_debugger_displayed_ad_activity_menu, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (R.id.action_share == paramMenuItem.getItemId()) {
      this.b.af().a(this.a, (Context)this, false);
      return true;
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\a\a\b\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */