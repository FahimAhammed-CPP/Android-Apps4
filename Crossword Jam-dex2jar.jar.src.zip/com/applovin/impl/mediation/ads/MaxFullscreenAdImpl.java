package com.applovin.impl.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.MediationServiceImpl;
import com.applovin.impl.mediation.d;
import com.applovin.impl.mediation.i;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.b;
import com.applovin.impl.sdk.d;
import com.applovin.impl.sdk.g;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.i;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.utils.p;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

public class MaxFullscreenAdImpl extends a implements b.a, d.a, g.a {
  private final a a;
  
  private final b b;
  
  private final com.applovin.impl.mediation.b c;
  
  private final Object d = new Object();
  
  private com.applovin.impl.mediation.a.c e = null;
  
  private c f = c.a;
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  private boolean h;
  
  private boolean i;
  
  private WeakReference<Activity> j = new WeakReference<Activity>(null);
  
  private WeakReference<ViewGroup> k = new WeakReference<ViewGroup>(null);
  
  private WeakReference<Lifecycle> l = new WeakReference<Lifecycle>(null);
  
  protected final b listenerWrapper;
  
  private final AtomicBoolean m = new AtomicBoolean();
  
  private p n;
  
  public MaxFullscreenAdImpl(String paramString1, MaxAdFormat paramMaxAdFormat, a parama, String paramString2, p paramp) {
    super(paramString1, paramMaxAdFormat, paramString2, paramp);
    this.a = parama;
    b b1 = new b();
    this.listenerWrapper = b1;
    this.c = new com.applovin.impl.mediation.b(paramp, b1);
    if (paramp.V() != null) {
      this.b = null;
    } else {
      this.b = new b(paramp, this);
    } 
    paramp.am().a(this);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Created new ");
    stringBuilder.append(paramString2);
    stringBuilder.append(" (");
    stringBuilder.append(this);
    stringBuilder.append(")");
    y.f(paramString2, stringBuilder.toString());
  }
  
  private void a(com.applovin.impl.mediation.a.c paramc) {
    boolean bool;
    if (this.sdk.V() != null) {
      bool = this.sdk.V().a((g)paramc, this);
    } else {
      bool = this.b.a((com.applovin.impl.mediation.a.a)paramc);
    } 
    if (bool) {
      if (y.a()) {
        y y = this.logger;
        String str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Handle ad loaded for regular ad: ");
        stringBuilder.append(paramc);
        y.b(str, stringBuilder.toString());
      } 
      this.e = paramc;
      return;
    } 
    if (y.a())
      this.logger.b(this.tag, "Loaded an expired ad, running expire logic..."); 
    onAdExpired((g)paramc);
  }
  
  private void a(c paramc, Runnable paramRunnable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   4: astore #5
    //   6: aload_0
    //   7: getfield d : Ljava/lang/Object;
    //   10: astore #4
    //   12: aload #4
    //   14: monitorenter
    //   15: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   18: astore #6
    //   20: iconst_1
    //   21: istore_3
    //   22: aload #5
    //   24: aload #6
    //   26: if_acmpne -> 125
    //   29: aload_1
    //   30: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   33: if_acmpne -> 39
    //   36: goto -> 636
    //   39: aload_1
    //   40: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   43: if_acmpne -> 49
    //   46: goto -> 636
    //   49: aload_1
    //   50: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   53: if_acmpne -> 68
    //   56: aload_0
    //   57: getfield tag : Ljava/lang/String;
    //   60: ldc 'No ad is loading or loaded'
    //   62: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   65: goto -> 824
    //   68: invokestatic a : ()Z
    //   71: ifeq -> 824
    //   74: aload_0
    //   75: getfield logger : Lcom/applovin/impl/sdk/y;
    //   78: astore #5
    //   80: aload_0
    //   81: getfield tag : Ljava/lang/String;
    //   84: astore #6
    //   86: new java/lang/StringBuilder
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: astore #7
    //   95: aload #7
    //   97: ldc 'Unable to transition to: '
    //   99: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: pop
    //   103: aload #7
    //   105: aload_1
    //   106: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #5
    //   112: aload #6
    //   114: aload #7
    //   116: invokevirtual toString : ()Ljava/lang/String;
    //   119: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   122: goto -> 824
    //   125: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   128: astore #7
    //   130: aload #5
    //   132: aload #7
    //   134: if_acmpne -> 260
    //   137: aload_1
    //   138: aload #6
    //   140: if_acmpne -> 146
    //   143: goto -> 636
    //   146: aload_1
    //   147: aload #7
    //   149: if_acmpne -> 164
    //   152: aload_0
    //   153: getfield tag : Ljava/lang/String;
    //   156: ldc 'An ad is already loading'
    //   158: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   161: goto -> 824
    //   164: aload_1
    //   165: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   168: if_acmpne -> 174
    //   171: goto -> 636
    //   174: aload_1
    //   175: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   178: if_acmpne -> 193
    //   181: aload_0
    //   182: getfield tag : Ljava/lang/String;
    //   185: ldc 'An ad is not ready to be shown yet'
    //   187: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   190: goto -> 824
    //   193: aload_1
    //   194: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   197: if_acmpne -> 203
    //   200: goto -> 636
    //   203: invokestatic a : ()Z
    //   206: ifeq -> 824
    //   209: aload_0
    //   210: getfield logger : Lcom/applovin/impl/sdk/y;
    //   213: astore #5
    //   215: aload_0
    //   216: getfield tag : Ljava/lang/String;
    //   219: astore #6
    //   221: new java/lang/StringBuilder
    //   224: dup
    //   225: invokespecial <init> : ()V
    //   228: astore #7
    //   230: aload #7
    //   232: ldc 'Unable to transition to: '
    //   234: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   237: pop
    //   238: aload #7
    //   240: aload_1
    //   241: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   244: pop
    //   245: aload #5
    //   247: aload #6
    //   249: aload #7
    //   251: invokevirtual toString : ()Ljava/lang/String;
    //   254: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   257: goto -> 824
    //   260: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   263: astore #8
    //   265: aload #5
    //   267: aload #8
    //   269: if_acmpne -> 404
    //   272: aload_1
    //   273: aload #6
    //   275: if_acmpne -> 281
    //   278: goto -> 636
    //   281: aload_1
    //   282: aload #7
    //   284: if_acmpne -> 299
    //   287: aload_0
    //   288: getfield tag : Ljava/lang/String;
    //   291: ldc 'An ad is already loaded'
    //   293: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   296: goto -> 824
    //   299: aload_1
    //   300: aload #8
    //   302: if_acmpne -> 327
    //   305: invokestatic a : ()Z
    //   308: ifeq -> 824
    //   311: aload_0
    //   312: getfield logger : Lcom/applovin/impl/sdk/y;
    //   315: aload_0
    //   316: getfield tag : Ljava/lang/String;
    //   319: ldc 'An ad is already marked as ready'
    //   321: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   324: goto -> 824
    //   327: aload_1
    //   328: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   331: if_acmpne -> 337
    //   334: goto -> 636
    //   337: aload_1
    //   338: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   341: if_acmpne -> 347
    //   344: goto -> 636
    //   347: invokestatic a : ()Z
    //   350: ifeq -> 824
    //   353: aload_0
    //   354: getfield logger : Lcom/applovin/impl/sdk/y;
    //   357: astore #5
    //   359: aload_0
    //   360: getfield tag : Ljava/lang/String;
    //   363: astore #6
    //   365: new java/lang/StringBuilder
    //   368: dup
    //   369: invokespecial <init> : ()V
    //   372: astore #7
    //   374: aload #7
    //   376: ldc 'Unable to transition to: '
    //   378: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   381: pop
    //   382: aload #7
    //   384: aload_1
    //   385: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   388: pop
    //   389: aload #5
    //   391: aload #6
    //   393: aload #7
    //   395: invokevirtual toString : ()Ljava/lang/String;
    //   398: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   401: goto -> 824
    //   404: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   407: astore #9
    //   409: aload #5
    //   411: aload #9
    //   413: if_acmpne -> 556
    //   416: aload_1
    //   417: aload #6
    //   419: if_acmpne -> 425
    //   422: goto -> 636
    //   425: aload_1
    //   426: aload #7
    //   428: if_acmpne -> 443
    //   431: aload_0
    //   432: getfield tag : Ljava/lang/String;
    //   435: ldc 'Can not load another ad while the ad is showing'
    //   437: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   440: goto -> 824
    //   443: aload_1
    //   444: aload #8
    //   446: if_acmpne -> 471
    //   449: invokestatic a : ()Z
    //   452: ifeq -> 824
    //   455: aload_0
    //   456: getfield logger : Lcom/applovin/impl/sdk/y;
    //   459: aload_0
    //   460: getfield tag : Ljava/lang/String;
    //   463: ldc 'An ad is already showing, ignoring'
    //   465: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   468: goto -> 824
    //   471: aload_1
    //   472: aload #9
    //   474: if_acmpne -> 489
    //   477: aload_0
    //   478: getfield tag : Ljava/lang/String;
    //   481: ldc 'The ad is already showing, not showing another one'
    //   483: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   486: goto -> 824
    //   489: aload_1
    //   490: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   493: if_acmpne -> 499
    //   496: goto -> 636
    //   499: invokestatic a : ()Z
    //   502: ifeq -> 824
    //   505: aload_0
    //   506: getfield logger : Lcom/applovin/impl/sdk/y;
    //   509: astore #5
    //   511: aload_0
    //   512: getfield tag : Ljava/lang/String;
    //   515: astore #6
    //   517: new java/lang/StringBuilder
    //   520: dup
    //   521: invokespecial <init> : ()V
    //   524: astore #7
    //   526: aload #7
    //   528: ldc 'Unable to transition to: '
    //   530: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   533: pop
    //   534: aload #7
    //   536: aload_1
    //   537: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   540: pop
    //   541: aload #5
    //   543: aload #6
    //   545: aload #7
    //   547: invokevirtual toString : ()Ljava/lang/String;
    //   550: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   553: goto -> 824
    //   556: aload #5
    //   558: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   561: if_acmpne -> 576
    //   564: aload_0
    //   565: getfield tag : Ljava/lang/String;
    //   568: ldc 'No operations are allowed on a destroyed instance'
    //   570: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   573: goto -> 824
    //   576: invokestatic a : ()Z
    //   579: ifeq -> 824
    //   582: aload_0
    //   583: getfield logger : Lcom/applovin/impl/sdk/y;
    //   586: astore #5
    //   588: aload_0
    //   589: getfield tag : Ljava/lang/String;
    //   592: astore #6
    //   594: new java/lang/StringBuilder
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: astore #7
    //   603: aload #7
    //   605: ldc 'Unknown state: '
    //   607: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   610: pop
    //   611: aload #7
    //   613: aload_0
    //   614: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   617: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   620: pop
    //   621: aload #5
    //   623: aload #6
    //   625: aload #7
    //   627: invokevirtual toString : ()Ljava/lang/String;
    //   630: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   633: goto -> 824
    //   636: iload_3
    //   637: ifeq -> 728
    //   640: invokestatic a : ()Z
    //   643: ifeq -> 720
    //   646: aload_0
    //   647: getfield logger : Lcom/applovin/impl/sdk/y;
    //   650: astore #5
    //   652: aload_0
    //   653: getfield tag : Ljava/lang/String;
    //   656: astore #6
    //   658: new java/lang/StringBuilder
    //   661: dup
    //   662: invokespecial <init> : ()V
    //   665: astore #7
    //   667: aload #7
    //   669: ldc 'Transitioning from '
    //   671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   674: pop
    //   675: aload #7
    //   677: aload_0
    //   678: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   681: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   684: pop
    //   685: aload #7
    //   687: ldc ' to '
    //   689: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   692: pop
    //   693: aload #7
    //   695: aload_1
    //   696: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   699: pop
    //   700: aload #7
    //   702: ldc '...'
    //   704: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   707: pop
    //   708: aload #5
    //   710: aload #6
    //   712: aload #7
    //   714: invokevirtual toString : ()Ljava/lang/String;
    //   717: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   720: aload_0
    //   721: aload_1
    //   722: putfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   725: goto -> 800
    //   728: invokestatic a : ()Z
    //   731: ifeq -> 800
    //   734: aload_0
    //   735: getfield logger : Lcom/applovin/impl/sdk/y;
    //   738: astore #5
    //   740: aload_0
    //   741: getfield tag : Ljava/lang/String;
    //   744: astore #6
    //   746: new java/lang/StringBuilder
    //   749: dup
    //   750: invokespecial <init> : ()V
    //   753: astore #7
    //   755: aload #7
    //   757: ldc 'Not allowed transition from '
    //   759: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   762: pop
    //   763: aload #7
    //   765: aload_0
    //   766: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   769: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   772: pop
    //   773: aload #7
    //   775: ldc ' to '
    //   777: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   780: pop
    //   781: aload #7
    //   783: aload_1
    //   784: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   787: pop
    //   788: aload #5
    //   790: aload #6
    //   792: aload #7
    //   794: invokevirtual toString : ()Ljava/lang/String;
    //   797: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)V
    //   800: aload #4
    //   802: monitorexit
    //   803: iload_3
    //   804: ifeq -> 817
    //   807: aload_2
    //   808: ifnull -> 817
    //   811: aload_2
    //   812: invokeinterface run : ()V
    //   817: return
    //   818: astore_1
    //   819: aload #4
    //   821: monitorexit
    //   822: aload_1
    //   823: athrow
    //   824: iconst_0
    //   825: istore_3
    //   826: goto -> 636
    // Exception table:
    //   from	to	target	type
    //   15	20	818	finally
    //   29	36	818	finally
    //   39	46	818	finally
    //   49	65	818	finally
    //   68	122	818	finally
    //   125	130	818	finally
    //   152	161	818	finally
    //   164	171	818	finally
    //   174	190	818	finally
    //   193	200	818	finally
    //   203	257	818	finally
    //   260	265	818	finally
    //   287	296	818	finally
    //   305	324	818	finally
    //   327	334	818	finally
    //   337	344	818	finally
    //   347	401	818	finally
    //   404	409	818	finally
    //   431	440	818	finally
    //   449	468	818	finally
    //   477	486	818	finally
    //   489	496	818	finally
    //   499	553	818	finally
    //   556	573	818	finally
    //   576	633	818	finally
    //   640	720	818	finally
    //   720	725	818	finally
    //   728	800	818	finally
    //   800	803	818	finally
    //   819	822	818	finally
  }
  
  private void a(MaxAd paramMaxAd) {
    if (this.sdk.V() != null) {
      this.sdk.V().a((g)paramMaxAd);
    } else {
      this.b.a();
    } 
    c();
    this.sdk.at().b((com.applovin.impl.mediation.a.a)paramMaxAd);
  }
  
  private void a(String paramString1, String paramString2) {
    this.c.b(this.e);
    this.e.e(paramString1);
    this.e.f(paramString2);
    this.sdk.af().a(this.e);
    if (y.a()) {
      y y = this.logger;
      paramString2 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Showing ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'; loaded ad: ");
      stringBuilder.append(this.e);
      stringBuilder.append("...");
      y.b(paramString2, stringBuilder.toString());
    } 
    a((com.applovin.impl.mediation.a.a)this.e);
  }
  
  private boolean a() {
    synchronized (this.d) {
      com.applovin.impl.mediation.a.c c1 = this.e;
      if (c1 != null && c1.f() && this.f == c.c)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  private boolean a(Activity paramActivity) {
    if (paramActivity != null || MaxAdFormat.APP_OPEN == this.adFormat) {
      MaxErrorImpl maxErrorImpl;
      boolean bool;
      if (!a()) {
        if (isReady()) {
          if (this.m.compareAndSet(false, true)) {
            this.sdk.au().b(this.adUnitId);
            d();
          } 
          return false;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to show ad before it is ready - please check ad readiness using ");
        stringBuilder.append(this.tag);
        stringBuilder.append("#isReady()");
        String str1 = stringBuilder.toString();
        y.i(this.tag, str1);
        this.sdk.Z().a(this.adUnitId);
        maxErrorImpl = new MaxErrorImpl(-24, str1);
        i i = new i(this.adUnitId, this.adFormat);
        if (y.a()) {
          y y = this.logger;
          String str2 = this.tag;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder1.append(i);
          stringBuilder1.append(", error=");
          stringBuilder1.append(maxErrorImpl);
          stringBuilder1.append("), listener=");
          stringBuilder1.append(this.adListener);
          y.b(str2, stringBuilder1.toString());
        } 
        k.a(this.adListener, (MaxAd)i, (MaxError)maxErrorImpl, true);
        return false;
      } 
      if (Utils.getAlwaysFinishActivitiesSetting(p.y()) != 0 && this.sdk.C().shouldFailAdDisplayIfDontKeepActivitiesIsEnabled())
        if (!Utils.isPubInDebugMode(p.y(), this.sdk)) {
          if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.S)).booleanValue()) {
            y.i(this.tag, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            maxErrorImpl = new MaxErrorImpl(-5602, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            if (y.a()) {
              y y = this.logger;
              String str1 = this.tag;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
              stringBuilder.append(this.e);
              stringBuilder.append(", error=");
              stringBuilder.append(maxErrorImpl);
              stringBuilder.append("), listener=");
              stringBuilder.append(this.adListener);
              y.b(str1, stringBuilder.toString());
            } 
            k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
            return false;
          } 
        } else {
          throw new IllegalStateException("Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
        }  
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.z)).booleanValue() && (this.sdk.Z().a() || this.sdk.Z().b())) {
        y.i(this.tag, "Attempting to show ad when another fullscreen ad is already showing");
        maxErrorImpl = new MaxErrorImpl(-23, "Attempting to show ad when another fullscreen ad is already showing");
        if (y.a()) {
          y y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.e);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str1, stringBuilder.toString());
        } 
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.A)).booleanValue() && !i.a(p.y())) {
        y.i(this.tag, "Attempting to show ad with no internet connection");
        maxErrorImpl = new MaxErrorImpl(-1009);
        if (y.a()) {
          y y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.e);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str1, stringBuilder.toString());
        } 
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      String str = (String)this.sdk.C().getExtraParameters().get("fullscreen_ads_block_showing_if_activity_is_finishing");
      if (StringUtils.isValidString(str) && Boolean.valueOf(str).booleanValue()) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool || ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.B)).booleanValue()) && maxErrorImpl != null && maxErrorImpl.isFinishing()) {
        y.i(this.tag, "Attempting to show ad when activity is finishing");
        maxErrorImpl = new MaxErrorImpl(-5601, "Attempting to show ad when activity is finishing");
        if (y.a()) {
          y y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.e);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str1, stringBuilder.toString());
        } 
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        return false;
      } 
      return true;
    } 
    throw new IllegalArgumentException("Attempting to show ad without a valid activity.");
  }
  
  private void b() {
    Activity activity = this.j.get();
    if (activity == null)
      activity = this.sdk.x(); 
    if (this.h) {
      showAd(this.e.getPlacement(), this.e.al(), this.k.get(), this.l.get(), activity);
      return;
    } 
    showAd(this.e.getPlacement(), this.e.al(), activity);
  }
  
  private void c() {
    synchronized (this.d) {
      com.applovin.impl.mediation.a.c c1 = this.e;
      this.e = null;
      this.sdk.ap().destroyAd((MaxAd)c1);
      return;
    } 
  }
  
  private void d() {
    e();
    this.n = p.a(((Long)this.sdk.a(com.applovin.impl.sdk.c.a.Z)).longValue(), this.sdk, new Runnable(this) {
          public void run() {
            if (MaxFullscreenAdImpl.d(this.a).compareAndSet(true, false)) {
              this.a.sdk.au().c(this.a.adUnitId);
              y.i(this.a.tag, "Failed to show an ad. Failed to load an ad in time to show.");
              this.a.sdk.Z().a(this.a.adUnitId);
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-24, "Failed to show an ad. Failed to load an ad in time to show.");
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
              i i = new i(maxFullscreenAdImpl.adUnitId, maxFullscreenAdImpl.adFormat);
              k.a(this.a.adListener, (MaxAd)i, (MaxError)maxErrorImpl, true);
            } 
          }
        });
  }
  
  private void e() {
    p p1 = this.n;
    if (p1 == null)
      return; 
    p1.d();
    this.n = null;
  }
  
  private void f() {
    if (this.g.compareAndSet(true, false))
      synchronized (this.d) {
        com.applovin.impl.mediation.a.c c1 = this.e;
        this.e = null;
        this.sdk.ap().destroyAd((MaxAd)c1);
        this.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      }  
  }
  
  public void destroy() {
    a(c.e, new Runnable(this) {
          public void run() {
            synchronized (MaxFullscreenAdImpl.a(this.a)) {
              if (MaxFullscreenAdImpl.b(this.a) != null) {
                y y = this.a.logger;
                if (y.a()) {
                  MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
                  y = maxFullscreenAdImpl.logger;
                  String str = maxFullscreenAdImpl.tag;
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Destroying ad for '");
                  stringBuilder.append(this.a.adUnitId);
                  stringBuilder.append("'; current ad: ");
                  stringBuilder.append(MaxFullscreenAdImpl.b(this.a));
                  stringBuilder.append("...");
                  y.b(str, stringBuilder.toString());
                } 
                this.a.sdk.ap().destroyAd((MaxAd)MaxFullscreenAdImpl.b(this.a));
              } 
              this.a.sdk.am().b(this.a);
              MaxFullscreenAdImpl.c(this.a);
              return;
            } 
          }
        });
  }
  
  public boolean isReady() {
    synchronized (this.d) {
      boolean bool1 = a();
      boolean bool = true;
      if (bool1)
        return true; 
      this.sdk.Z().a(this.adUnitId);
      if (!((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.W)).booleanValue() || this.f != c.b)
        bool = false; 
      return bool;
    } 
  }
  
  public void loadAd(Activity paramActivity) {
    loadAd(paramActivity, d.a.a);
  }
  
  public void loadAd(Activity paramActivity, d.a parama) {
    y y;
    String str;
    if (y.a()) {
      y y1 = this.logger;
      String str1 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'...");
      y1.b(str1, stringBuilder.toString());
    } 
    if (isReady()) {
      if (y.a()) {
        y = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An ad is already loaded for '");
        stringBuilder.append(this.adUnitId);
        stringBuilder.append("'");
        y.b(str, stringBuilder.toString());
      } 
      if (y.a()) {
        y = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.e);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.adListener, (MaxAd)this.e, true);
      return;
    } 
    a(c.b, new Runnable(this, (Activity)y, (d.a)str) {
          public void run() {
            Context context;
            Activity activity = this.a;
            if (activity == null)
              if (this.c.sdk.x() != null) {
                activity = this.c.sdk.x();
              } else {
                p p = this.c.sdk;
                context = p.y();
              }  
            MediationServiceImpl mediationServiceImpl = this.c.sdk.ap();
            MaxFullscreenAdImpl maxFullscreenAdImpl = this.c;
            mediationServiceImpl.loadAd(maxFullscreenAdImpl.adUnitId, null, maxFullscreenAdImpl.adFormat, this.b, maxFullscreenAdImpl.localExtraParameters, maxFullscreenAdImpl.extraParameters, context, maxFullscreenAdImpl.listenerWrapper);
          }
        });
  }
  
  public void onAdExpired() {
    Activity activity;
    if (y.a()) {
      y y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ad expired ");
      stringBuilder.append(getAdUnitId());
      y.b(str, stringBuilder.toString());
    } 
    this.g.set(true);
    a a1 = this.a;
    if (a1 != null) {
      activity = a1.getActivity();
    } else {
      activity = this.sdk.w().a();
    } 
    if (activity == null) {
      f();
      this.listenerWrapper.onAdLoadFailed(this.adUnitId, (MaxError)MaxAdapterError.MISSING_ACTIVITY);
      return;
    } 
    this.extraParameters.put("expired_ad_ad_unit_id", getAdUnitId());
    this.sdk.ap().loadAd(this.adUnitId, null, this.adFormat, d.a.e, this.localExtraParameters, this.extraParameters, (Context)activity, this.listenerWrapper);
  }
  
  public void onAdExpired(g paramg) {
    onAdExpired();
  }
  
  public void onCreativeIdGenerated(String paramString1, String paramString2) {
    com.applovin.impl.mediation.a.c c1 = this.e;
    if (c1 != null && c1.g().equalsIgnoreCase(paramString1)) {
      this.e.b(paramString2);
      k.a(this.adReviewListener, paramString2, (MaxAd)this.e);
    } 
  }
  
  public void showAd(String paramString1, String paramString2, Activity paramActivity) {
    String str1;
    String str2 = this.sdk.av().c();
    if (this.sdk.av().b() && str2 != null && !str2.equals(this.e.X())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to show ad from <");
      stringBuilder.append(this.e.X());
      stringBuilder.append("> which does not match selected ad network <");
      stringBuilder.append(str2);
      stringBuilder.append(">");
      str1 = stringBuilder.toString();
      y.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl1 = this.b;
                y = maxFullscreenAdImpl1.logger;
                String str = maxFullscreenAdImpl1.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.x(); 
    if (!a(paramActivity))
      return; 
    a(c.d, new Runnable(this, str1, paramString2, paramActivity) {
          public void run() {
            MaxFullscreenAdImpl.a(this.d, this.a, this.b);
            MaxFullscreenAdImpl.a(this.d, false);
            MaxFullscreenAdImpl.a(this.d, new WeakReference<Activity>(this.c));
            this.d.sdk.ap().showFullscreenAd(MaxFullscreenAdImpl.b(this.d), this.c, this.d.listenerWrapper);
          }
        });
  }
  
  public void showAd(String paramString1, String paramString2, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity) {
    String str1;
    y y;
    String str2;
    StringBuilder stringBuilder;
    if (paramViewGroup == null || paramLifecycle == null) {
      y.i(this.tag, "Attempting to show ad with null containerView or lifecycle.");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad with null containerView or lifecycle.");
      if (y.a()) {
        y = this.logger;
        str2 = this.tag;
        stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.e);
        stringBuilder.append(", error=");
        stringBuilder.append(maxErrorImpl);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y.b(str2, stringBuilder.toString());
      } 
      k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
      return;
    } 
    if (!str2.isShown() && ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.T)).booleanValue()) {
      y.i(this.tag, "Attempting to show ad when containerView and/or its ancestors are not visible");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad when containerView and/or its ancestors are not visible");
      k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
      return;
    } 
    String str3 = this.sdk.av().c();
    if (this.sdk.av().b() && str3 != null && !str3.equals(this.e.X())) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Attempting to show ad from <");
      stringBuilder1.append(this.e.X());
      stringBuilder1.append("> which does not match selected ad network <");
      stringBuilder1.append(str3);
      stringBuilder1.append(">");
      str1 = stringBuilder1.toString();
      y.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl1 = this.b;
                y = maxFullscreenAdImpl1.logger;
                String str = maxFullscreenAdImpl1.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.x(); 
    if (!a(paramActivity))
      return; 
    a(c.d, new Runnable(this, str1, (String)y, paramActivity, (ViewGroup)str2, (Lifecycle)stringBuilder) {
          public void run() {
            MaxFullscreenAdImpl.a(this.f, this.a, this.b);
            MaxFullscreenAdImpl.a(this.f, true);
            MaxFullscreenAdImpl.a(this.f, new WeakReference<Activity>(this.c));
            MaxFullscreenAdImpl.b(this.f, new WeakReference<ViewGroup>(this.d));
            MaxFullscreenAdImpl.c(this.f, new WeakReference<Lifecycle>(this.e));
            this.f.sdk.ap().showFullscreenAd(MaxFullscreenAdImpl.b(this.f), this.d, this.e, this.c, this.f.listenerWrapper);
          }
        });
  }
  
  @NonNull
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.tag);
    stringBuilder.append("{adUnitId='");
    stringBuilder.append(this.adUnitId);
    stringBuilder.append('\'');
    stringBuilder.append(", adListener=");
    MaxAdListener maxAdListener2 = this.adListener;
    MaxAdListener maxAdListener1 = maxAdListener2;
    if (maxAdListener2 == this.a)
      str = "this"; 
    stringBuilder.append(str);
    stringBuilder.append(", revenueListener=");
    stringBuilder.append(this.revenueListener);
    stringBuilder.append(", requestListener");
    stringBuilder.append(this.requestListener);
    stringBuilder.append(", adReviewListener");
    stringBuilder.append(this.adReviewListener);
    stringBuilder.append(", isReady=");
    stringBuilder.append(isReady());
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static interface a {
    Activity getActivity();
  }
  
  private class b implements a.a, MaxAdListener, MaxAdRevenueListener, MaxRewardedAdListener {
    private b(MaxFullscreenAdImpl this$0) {}
    
    public void onAdClicked(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdClicked(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.d(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {
      boolean bool = MaxFullscreenAdImpl.f(this.a);
      MaxFullscreenAdImpl.b(this.a, false);
      com.applovin.impl.mediation.a.c c = (com.applovin.impl.mediation.a.c)param1MaxAd;
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd, bool, c, param1MaxError) {
            public void run() {
              MaxFullscreenAdImpl.a(this.e.a, this.a);
              if (!this.b && this.c.I() && this.e.a.sdk.au().a(this.e.a.adUnitId)) {
                AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
                      public void run() {
                        Activity activity;
                        MaxFullscreenAdImpl.b(this.a.e.a, true);
                        if (MaxFullscreenAdImpl.l(this.a.e.a) != null) {
                          activity = MaxFullscreenAdImpl.l(this.a.e.a).getActivity();
                        } else {
                          activity = null;
                        } 
                        this.a.e.a.loadAd(activity);
                      }
                    });
                return;
              } 
              y y = this.e.a.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl = this.e.a;
                y = maxFullscreenAdImpl.logger;
                String str = maxFullscreenAdImpl.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.d);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.e.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.e.a.adListener, this.a, this.d, true);
            }
          });
    }
    
    public void onAdDisplayed(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      if (this.a.sdk.V() != null) {
        this.a.sdk.V().a((g)param1MaxAd);
      } else {
        MaxFullscreenAdImpl.j(this.a).a();
      } 
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayed(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.b(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdHidden(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      MaxFullscreenAdImpl.k(this.a).a(param1MaxAd);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd) {
            public void run() {
              MaxFullscreenAdImpl.a(this.b.a, this.a);
              y y = this.b.a.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl = this.b.a;
                y = maxFullscreenAdImpl.logger;
                String str = maxFullscreenAdImpl.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdHidden(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.c(this.b.a.adListener, this.a, true);
            }
          });
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      MaxFullscreenAdImpl.i(this.a);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1String, param1MaxError) {
            public void run() {
              y y = this.c.a.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl = this.c.a;
                y = maxFullscreenAdImpl.logger;
                String str = maxFullscreenAdImpl.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdLoadFailed(adUnitId=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.b);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.c.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.c.a.adListener, this.a, this.b, true);
            }
          });
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      this.a.sdk.Z().c(this.a.adUnitId);
      MaxFullscreenAdImpl.a(this.a, (com.applovin.impl.mediation.a.c)param1MaxAd);
      if (MaxFullscreenAdImpl.e(this.a).compareAndSet(true, false)) {
        this.a.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      } 
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.c, new Runnable(this, param1MaxAd) {
            public void run() {
              if (MaxFullscreenAdImpl.f(this.b.a)) {
                MaxFullscreenAdImpl.g(this.b.a);
                return;
              } 
              y y = this.b.a.logger;
              if (y.a()) {
                MaxFullscreenAdImpl maxFullscreenAdImpl = this.b.a;
                y = maxFullscreenAdImpl.logger;
                String str = maxFullscreenAdImpl.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.a.adListener, this.a, true);
              if (MaxFullscreenAdImpl.d(this.b.a).compareAndSet(true, false)) {
                MaxFullscreenAdImpl.h(this.b.a);
                this.b.a.sdk.au().c(this.b.a.adUnitId);
                MaxFullscreenAdImpl.g(this.b.a);
              } 
            }
          });
    }
    
    public void onAdRequestStarted(String param1String) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdRequestListener.onAdRequestStarted(adUnitId=");
        stringBuilder.append(param1String);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.requestListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.requestListener, param1String, true);
    }
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdRevenueListener.onAdRevenuePaid(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.revenueListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.revenueListener, param1MaxAd);
    }
    
    public void onRewardedVideoCompleted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onRewardedVideoCompleted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.f(this.a.adListener, param1MaxAd, true);
    }
    
    public void onRewardedVideoStarted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onRewardedVideoStarted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.e(this.a.adListener, param1MaxAd, true);
    }
    
    public void onUserRewarded(MaxAd param1MaxAd, MaxReward param1MaxReward) {
      y y = this.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onUserRewarded(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append(", reward=");
        stringBuilder.append(param1MaxReward);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.adListener, param1MaxAd, param1MaxReward, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      if (MaxFullscreenAdImpl.f(this.b.a)) {
        MaxFullscreenAdImpl.g(this.b.a);
        return;
      } 
      y y = this.b.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.b.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.b.a.adListener, this.a, true);
      if (MaxFullscreenAdImpl.d(this.b.a).compareAndSet(true, false)) {
        MaxFullscreenAdImpl.h(this.b.a);
        this.b.a.sdk.au().c(this.b.a.adUnitId);
        MaxFullscreenAdImpl.g(this.b.a);
      } 
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, String param1String, MaxError param1MaxError) {}
    
    public void run() {
      y y = this.c.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.c.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoadFailed(adUnitId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.b);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.c.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.c.a.adListener, this.a, this.b, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.b.a, this.a);
      y y = this.b.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.b.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdHidden(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.c(this.b.a.adListener, this.a, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd, boolean param1Boolean, com.applovin.impl.mediation.a.c param1c, MaxError param1MaxError) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.e.a, this.a);
      if (!this.b && this.c.I() && this.e.a.sdk.au().a(this.e.a.adUnitId)) {
        AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
              public void run() {
                Activity activity;
                MaxFullscreenAdImpl.b(this.a.e.a, true);
                if (MaxFullscreenAdImpl.l(this.a.e.a) != null) {
                  activity = MaxFullscreenAdImpl.l(this.a.e.a).getActivity();
                } else {
                  activity = null;
                } 
                this.a.e.a.loadAd(activity);
              }
            });
        return;
      } 
      y y = this.e.a.logger;
      if (y.a()) {
        MaxFullscreenAdImpl maxFullscreenAdImpl = this.e.a;
        y = maxFullscreenAdImpl.logger;
        String str = maxFullscreenAdImpl.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.d);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.e.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.e.a.adListener, this.a, this.d, true);
    }
  }
  
  class null implements Runnable {
    public void run() {
      Activity activity;
      MaxFullscreenAdImpl.b(this.a.e.a, true);
      if (MaxFullscreenAdImpl.l(this.a.e.a) != null) {
        activity = MaxFullscreenAdImpl.l(this.a.e.a).getActivity();
      } else {
        activity = null;
      } 
      this.a.e.a.loadAd(activity);
    }
  }
  
  public enum c {
    a, b, c, d, e;
    
    static {
      c c1 = new c("IDLE", 0);
      a = c1;
      c c2 = new c("LOADING", 1);
      b = c2;
      c c3 = new c("READY", 2);
      c = c3;
      c c4 = new c("SHOWING", 3);
      d = c4;
      c c5 = new c("DESTROYED", 4);
      e = c5;
      f = new c[] { c1, c2, c3, c4, c5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\mediation\ads\MaxFullscreenAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */