package com.applovin.impl.mediation.nativeAds.a;

import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.m;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.nativeAds.adPlacer.MaxAdPlacerSettings;
import java.util.Collection;
import java.util.Map;
import java.util.TreeSet;

public class a {
  private final m<Integer> a = new m();
  
  private final TreeSet<Integer> b = new TreeSet<Integer>();
  
  private final Map<Integer, MaxAd> c = CollectionUtils.map();
  
  private int d;
  
  private int e;
  
  public a(MaxAdPlacerSettings paramMaxAdPlacerSettings) {
    a(paramMaxAdPlacerSettings);
  }
  
  private int a(int paramInt, boolean paramBoolean) {
    int i = this.a.d(Integer.valueOf(paramInt));
    int j = i;
    if (!paramBoolean) {
      int k = paramInt + i;
      paramInt = i;
      while (true) {
        j = paramInt;
        if (paramInt < this.a.size()) {
          j = paramInt;
          if (k >= ((Integer)this.a.a(paramInt)).intValue()) {
            k++;
            paramInt++;
            continue;
          } 
        } 
        break;
      } 
    } 
    return j;
  }
  
  private void a(MaxAdPlacerSettings paramMaxAdPlacerSettings) {
    if (!paramMaxAdPlacerSettings.hasValidPositioning()) {
      y.i("MaxAdPlacerData", "No positioning info was provided with ad placer settings. You must set at least (1) one or more fixed positions or (2) a repeating interval greater than or equal to 2 for the ad placer to determine where to position ads.");
      return;
    } 
    this.a.addAll(paramMaxAdPlacerSettings.getFixedPositions());
    if (paramMaxAdPlacerSettings.isRepeatingEnabled()) {
      int j = paramMaxAdPlacerSettings.getRepeatingInterval();
      if (this.a.isEmpty())
        this.a.a(Integer.valueOf(j - 1)); 
      int i = ((Integer)this.a.a()).intValue();
      while (true) {
        i += j;
        if (this.a.size() < paramMaxAdPlacerSettings.getMaxAdCount()) {
          this.a.a(Integer.valueOf(i));
          continue;
        } 
        break;
      } 
    } 
  }
  
  private void c(int paramInt1, int paramInt2) {
    if (this.c.containsKey(Integer.valueOf(paramInt1))) {
      this.c.put(Integer.valueOf(paramInt2), this.c.get(Integer.valueOf(paramInt1)));
      this.b.add(Integer.valueOf(paramInt2));
      this.c.remove(Integer.valueOf(paramInt1));
      this.b.remove(Integer.valueOf(paramInt1));
    } 
  }
  
  public int a() {
    int i = this.d;
    if (i != -1) {
      if (this.e == -1)
        return -1; 
      while (i <= this.e) {
        if (a(i) && !b(i))
          return i; 
        i++;
      } 
    } 
    return -1;
  }
  
  public void a(int paramInt1, int paramInt2) {
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  public void a(MaxAd paramMaxAd, int paramInt) {
    this.c.put(Integer.valueOf(paramInt), paramMaxAd);
    this.b.add(Integer.valueOf(paramInt));
  }
  
  public void a(Collection<Integer> paramCollection) {
    for (Integer integer : paramCollection) {
      this.c.remove(integer);
      this.b.remove(integer);
    } 
  }
  
  public boolean a(int paramInt) {
    return this.a.contains(Integer.valueOf(paramInt));
  }
  
  public Collection<Integer> b() {
    return new TreeSet<Integer>(this.b);
  }
  
  public void b(int paramInt1, int paramInt2) {
    i(paramInt1);
    h(paramInt2);
  }
  
  public boolean b(int paramInt) {
    return this.b.contains(Integer.valueOf(paramInt));
  }
  
  public MaxAd c(int paramInt) {
    return this.c.get(Integer.valueOf(paramInt));
  }
  
  public void c() {
    this.c.clear();
    this.b.clear();
  }
  
  public Collection<Integer> d(int paramInt) {
    return new TreeSet<Integer>(this.b.tailSet(Integer.valueOf(paramInt), false));
  }
  
  public int e(int paramInt) {
    return (paramInt == 0) ? 0 : (paramInt + a(paramInt - 1, false));
  }
  
  public int f(int paramInt) {
    return paramInt + a(paramInt, false);
  }
  
  public int g(int paramInt) {
    return a(paramInt) ? -1 : (paramInt - a(paramInt, true));
  }
  
  public void h(int paramInt) {
    int i = this.a.c(Integer.valueOf(paramInt));
    for (paramInt = this.a.size() - 1; paramInt >= i; paramInt--) {
      Integer integer = (Integer)this.a.a(paramInt);
      int j = integer.intValue() + 1;
      c(integer.intValue(), j);
      this.a.a(paramInt, Integer.valueOf(j));
    } 
  }
  
  public void i(int paramInt) {
    int j = this.a.c(Integer.valueOf(paramInt));
    int i = j;
    if (a(paramInt)) {
      this.c.remove(Integer.valueOf(paramInt));
      this.b.remove(Integer.valueOf(paramInt));
      this.a.b(j);
      i = j;
    } 
    while (i < this.a.size()) {
      Integer integer = (Integer)this.a.a(i);
      paramInt = integer.intValue() - 1;
      c(integer.intValue(), paramInt);
      this.a.a(i, Integer.valueOf(paramInt));
      i++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\mediation\nativeAds\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */