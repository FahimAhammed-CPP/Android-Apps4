package com.applovin.impl.mediation.nativeAds.a;

import android.content.Context;
import androidx.annotation.Nullable;
import com.applovin.impl.mediation.d;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class b extends MaxNativeAdListener implements MaxAdRevenueListener {
  private final int a;
  
  private final MaxNativeAdLoader b;
  
  private final Queue<MaxAd> c = new LinkedList<MaxAd>();
  
  private boolean d = false;
  
  private final Object e = new Object();
  
  private a f;
  
  public b(String paramString, int paramInt, Context paramContext, a parama) {
    this.a = paramInt;
    this.f = parama;
    MaxNativeAdLoader maxNativeAdLoader = new MaxNativeAdLoader(paramString, paramContext);
    this.b = maxNativeAdLoader;
    maxNativeAdLoader.setNativeAdListener(this);
    maxNativeAdLoader.setRevenueListener(this);
    maxNativeAdLoader.setLocalExtraParameter("ad_request_type", d.a.f);
  }
  
  public void a() {
    this.f = null;
    e();
    this.b.destroy();
  }
  
  public void a(MaxAd paramMaxAd) {
    this.b.destroy(paramMaxAd);
  }
  
  public boolean a(MaxNativeAdView paramMaxNativeAdView, MaxAd paramMaxAd) {
    return this.b.render(paramMaxNativeAdView, paramMaxAd);
  }
  
  public boolean b() {
    synchronized (this.e) {
      if (!this.c.isEmpty())
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public void c() {
    synchronized (this.e) {
      if (!this.d && this.c.size() < this.a) {
        this.d = true;
        this.b.loadAd();
      } 
      return;
    } 
  }
  
  @Nullable
  public MaxAd d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aconst_null
    //   8: astore_1
    //   9: aload_0
    //   10: getfield c : Ljava/util/Queue;
    //   13: invokeinterface isEmpty : ()Z
    //   18: ifne -> 53
    //   21: aload_1
    //   22: ifnull -> 37
    //   25: aload_1
    //   26: invokeinterface getNativeAd : ()Lcom/applovin/mediation/nativeAds/MaxNativeAd;
    //   31: invokevirtual isExpired : ()Z
    //   34: ifeq -> 53
    //   37: aload_0
    //   38: getfield c : Ljava/util/Queue;
    //   41: invokeinterface remove : ()Ljava/lang/Object;
    //   46: checkcast com/applovin/mediation/MaxAd
    //   49: astore_1
    //   50: goto -> 9
    //   53: aload_0
    //   54: invokevirtual c : ()V
    //   57: aload_2
    //   58: monitorexit
    //   59: aload_1
    //   60: areturn
    //   61: astore_1
    //   62: aload_2
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   9	21	61	finally
    //   25	37	61	finally
    //   37	50	61	finally
    //   53	59	61	finally
    //   62	64	61	finally
  }
  
  public void e() {
    synchronized (this.e) {
      Iterator<MaxAd> iterator = this.c.iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
      this.c.clear();
      return;
    } 
  }
  
  public void onAdRevenuePaid(MaxAd paramMaxAd) {
    a a1 = this.f;
    if (a1 != null)
      a1.onAdRevenuePaid(paramMaxAd); 
  }
  
  public void onNativeAdClicked(MaxAd paramMaxAd) {
    a a1 = this.f;
    if (a1 != null)
      a1.onNativeAdClicked(paramMaxAd); 
  }
  
  public void onNativeAdLoadFailed(String paramString, MaxError paramMaxError) {
    a a1 = this.f;
    if (a1 != null)
      a1.onNativeAdLoadFailed(paramString, paramMaxError); 
  }
  
  public void onNativeAdLoaded(@Nullable MaxNativeAdView paramMaxNativeAdView, MaxAd paramMaxAd) {
    synchronized (this.e) {
      this.c.add(paramMaxAd);
      this.d = false;
      c();
      null = this.f;
      if (null != null)
        null.onNativeAdLoaded(); 
      return;
    } 
  }
  
  public static interface a {
    void onAdRevenuePaid(MaxAd param1MaxAd);
    
    void onNativeAdClicked(MaxAd param1MaxAd);
    
    void onNativeAdLoadFailed(String param1String, MaxError param1MaxError);
    
    void onNativeAdLoaded();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\mediation\nativeAds\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */