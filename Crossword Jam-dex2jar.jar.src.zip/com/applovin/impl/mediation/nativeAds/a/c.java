package com.applovin.impl.mediation.nativeAds.a;

import android.os.Handler;
import android.view.View;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class c {
  private final WeakHashMap<View, Integer> a = new WeakHashMap<View, Integer>();
  
  private final Object b = new Object();
  
  private final Handler c = new Handler();
  
  private boolean d = false;
  
  private final WeakReference<View> e;
  
  private final ViewTreeObserver.OnPreDrawListener f;
  
  private a g;
  
  public c(View paramView) {
    this.e = new WeakReference<View>(paramView);
    ViewTreeObserver viewTreeObserver = paramView.getViewTreeObserver();
    if (viewTreeObserver.isAlive()) {
      ViewTreeObserver.OnPreDrawListener onPreDrawListener = new ViewTreeObserver.OnPreDrawListener(this) {
          public boolean onPreDraw() {
            c.a(this.a);
            return true;
          }
        };
      this.f = onPreDrawListener;
      viewTreeObserver.addOnPreDrawListener(onPreDrawListener);
      return;
    } 
    this.f = null;
  }
  
  private void b() {
    if (this.d)
      return; 
    this.d = true;
    this.c.postDelayed(new Runnable(this) {
          public void run() {
            synchronized (c.b(this.a)) {
              c.a(this.a, false);
              Iterator<Map.Entry> iterator = c.c(this.a).entrySet().iterator();
              int i = -1;
              int j = i;
              while (iterator.hasNext()) {
                Map.Entry entry = iterator.next();
                View view = (View)entry.getKey();
                if (c.a(this.a, view)) {
                  Integer integer = (Integer)entry.getValue();
                  if (i == -1 && j == -1) {
                    i = integer.intValue();
                    j = integer.intValue();
                    continue;
                  } 
                  i = Math.min(i, ((Integer)entry.getValue()).intValue());
                  j = Math.max(j, ((Integer)entry.getValue()).intValue());
                } 
              } 
              if (c.d(this.a) != null)
                c.d(this.a).a(i, j); 
              return;
            } 
          }
        }100L);
  }
  
  private boolean b(View paramView) {
    return (paramView != null && paramView.getVisibility() == 0 && paramView.getParent() != null);
  }
  
  public void a() {
    this.g = null;
    View view = this.e.get();
    if (view != null) {
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      if (viewTreeObserver.isAlive()) {
        ViewTreeObserver.OnPreDrawListener onPreDrawListener = this.f;
        if (onPreDrawListener != null)
          viewTreeObserver.removeOnPreDrawListener(onPreDrawListener); 
      } 
      this.e.clear();
    } 
  }
  
  public void a(View paramView) {
    synchronized (this.b) {
      this.a.remove(paramView);
      return;
    } 
  }
  
  public void a(View paramView, int paramInt) {
    synchronized (this.b) {
      this.a.put(paramView, Integer.valueOf(paramInt));
      b();
      return;
    } 
  }
  
  public void a(a parama) {
    this.g = parama;
  }
  
  public static interface a {
    void a(int param1Int1, int param1Int2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\mediation\nativeAds\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */