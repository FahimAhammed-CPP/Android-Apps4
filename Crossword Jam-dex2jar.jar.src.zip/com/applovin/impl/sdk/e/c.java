package com.applovin.impl.sdk.e;

import android.net.Uri;
import android.text.TextUtils;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.h;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.d.d;
import com.applovin.impl.sdk.d.e;
import com.applovin.impl.sdk.network.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.v;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinSdkUtils;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public abstract class c extends a implements h.a {
  protected final e a;
  
  private AppLovinAdLoadListener b;
  
  private final v c;
  
  private final Collection<Character> d;
  
  private final e e;
  
  private boolean i;
  
  c(String paramString, e parame, p paramp, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    super(paramString, paramp);
    if (parame != null) {
      this.a = parame;
      this.b = paramAppLovinAdLoadListener;
      this.c = paramp.W();
      this.d = j();
      this.e = new e();
      return;
    } 
    throw new IllegalArgumentException("No ad specified.");
  }
  
  private Uri a(String paramString1, String paramString2) {
    StringBuilder stringBuilder1;
    String str2 = paramString2.replace("/", "_");
    String str3 = this.a.L();
    String str1 = str2;
    if (StringUtils.isValidString(str3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    File file = this.c.a(str1, p.y());
    if (file == null)
      return null; 
    if (file.exists()) {
      this.e.b(file.length());
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("file://");
      stringBuilder1.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append((String)stringBuilder1);
    stringBuilder2.append(paramString2);
    paramString2 = stringBuilder2.toString();
    List<String> list = Arrays.asList(new String[] { (String)stringBuilder1 });
    if (this.c.a(file, paramString2, list, this.e)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("file://");
      stringBuilder.append(file.getAbsolutePath());
      return Uri.parse(stringBuilder.toString());
    } 
    return null;
  }
  
  private Collection<Character> j() {
    HashSet<Character> hashSet = new HashSet();
    char[] arrayOfChar = ((String)this.f.a(b.bz)).toCharArray();
    int j = arrayOfChar.length;
    for (int i = 0; i < j; i++)
      hashSet.add(Character.valueOf(arrayOfChar[i])); 
    hashSet.add(Character.valueOf('"'));
    return hashSet;
  }
  
  protected Uri a(Uri paramUri, String paramString) {
    y y2;
    y y1;
    if (paramUri == null) {
      if (y.a()) {
        y2 = this.h;
        String str1 = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No ");
        stringBuilder.append(paramString);
        stringBuilder.append(" image to cache");
        y2.b(str1, stringBuilder.toString());
      } 
      return null;
    } 
    String str = y2.toString();
    if (TextUtils.isEmpty(str)) {
      if (y.a()) {
        y1 = this.h;
        String str1 = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to cache ");
        stringBuilder.append(paramString);
        stringBuilder.append(" image");
        y1.b(str1, stringBuilder.toString());
      } 
      return null;
    } 
    if (y.a()) {
      y y = this.h;
      String str1 = this.g;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Caching ");
      stringBuilder.append(paramString);
      stringBuilder.append(" image...");
      y.b(str1, stringBuilder.toString());
    } 
    return b((String)y1);
  }
  
  Uri a(String paramString) {
    return a(paramString, this.a.I(), true);
  }
  
  Uri a(String paramString, List<String> paramList, boolean paramBoolean) {
    if (StringUtils.isValidString(paramString)) {
      if (y.a()) {
        y y = this.h;
        String str1 = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Caching video ");
        stringBuilder.append(paramString);
        stringBuilder.append("...");
        y.b(str1, stringBuilder.toString());
      } 
      String str = this.c.a(f(), paramString, this.a.L(), paramList, paramBoolean, this.a.shouldUrlEncodeResourcePath(), this.e);
      if (StringUtils.isValidString(str)) {
        y y;
        File file = this.c.a(str, f());
        if (file != null) {
          y y1;
          Uri uri = Uri.fromFile(file);
          if (uri != null) {
            if (y.a()) {
              y1 = this.h;
              String str1 = this.g;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Finish caching video for ad #");
              stringBuilder.append(this.a.getAdIdNumber());
              stringBuilder.append(". Updating ad with cachedVideoFilename = ");
              stringBuilder.append(str);
              y1.b(str1, stringBuilder.toString());
            } 
            return uri;
          } 
          if (y.a()) {
            y = this.h;
            str = this.g;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to create URI from cached video file = ");
            stringBuilder.append(y1);
            y.e(str, stringBuilder.toString());
          } 
        } else if (y.a()) {
          y y1 = this.h;
          String str1 = this.g;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to cache video = ");
          stringBuilder.append((String)y);
          stringBuilder.append("Video file was missing or null");
          y1.e(str1, stringBuilder.toString());
        } 
      } else {
        if (y.a())
          this.h.e(this.g, "Failed to cache video"); 
        h();
      } 
    } 
    return null;
  }
  
  String a(String paramString, List<String> paramList, e parame) {
    if (TextUtils.isEmpty(paramString))
      return paramString; 
    if (!((Boolean)this.f.a(b.bA)).booleanValue()) {
      if (y.a())
        this.h.b(this.g, "Resource caching is disabled, skipping cache..."); 
      return paramString;
    } 
    StringBuilder stringBuilder = new StringBuilder(paramString);
    boolean bool1 = parame.shouldCancelHtmlCachingIfShown();
    boolean bool2 = parame.aM();
    List list = parame.H();
    for (String str : paramList) {
      int j = 0;
      int i = 0;
      while (j < stringBuilder.length()) {
        if (b())
          return paramString; 
        j = stringBuilder.indexOf(str, i);
        if (j == -1)
          break; 
        int k = stringBuilder.length();
        for (i = j; !this.d.contains(Character.valueOf(stringBuilder.charAt(i))) && i < k; i++);
        if (i > j && i != k) {
          String str1 = stringBuilder.substring(str.length() + j, i);
          if (StringUtils.isValidString(str1)) {
            if (bool1 && parame.hasShown()) {
              if (y.a())
                this.h.b(this.g, "Cancelling HTML caching due to ad being shown already"); 
              this.e.a();
              return paramString;
            } 
            if (bool2) {
              String str2 = parame.d();
              StringBuilder stringBuilder2 = new StringBuilder();
              stringBuilder2.append(str);
              stringBuilder2.append(str1);
              if (str2.equals(stringBuilder2.toString())) {
                if (y.a()) {
                  y y = this.h;
                  String str3 = this.g;
                  StringBuilder stringBuilder3 = new StringBuilder();
                  stringBuilder3.append("Postponing caching for \"");
                  stringBuilder3.append(str1);
                  stringBuilder3.append("\" video resource");
                  y.b(str3, stringBuilder3.toString());
                } 
                continue;
              } 
            } 
            Uri uri = a(str, str1);
            if (uri != null) {
              stringBuilder.replace(j, i, uri.toString());
              parame.b(uri);
              this.e.b();
              continue;
            } 
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(str);
            stringBuilder1.append(str1);
            if (list.contains(stringBuilder1.toString())) {
              h();
              this.i = true;
            } 
            this.e.c();
            continue;
          } 
          if (y.a()) {
            y y = this.h;
            String str2 = this.g;
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Skip caching of non-resource ");
            stringBuilder1.append(str1);
            y.b(str2, stringBuilder1.toString());
          } 
          continue;
        } 
        if (y.a())
          this.h.e(this.g, "Unable to cache resource; ad HTML is invalid."); 
        return paramString;
      } 
    } 
    return stringBuilder.toString();
  }
  
  protected void a() {
    this.f.ar().b(this);
  }
  
  public void a(a parama) {
    if (parama.g().equalsIgnoreCase(this.a.N())) {
      if (y.a())
        this.h.e(this.g, "Updating flag for timeout..."); 
      this.i = true;
    } 
    this.f.ar().b(this);
  }
  
  void a(AppLovinAdBase paramAppLovinAdBase) {
    d.a(this.e, paramAppLovinAdBase, this.f);
  }
  
  protected Uri b(String paramString) {
    return b(paramString, this.a.I(), true);
  }
  
  Uri b(String paramString, List<String> paramList, boolean paramBoolean) {
    try {
      String str = this.c.a(f(), paramString, this.a.L(), paramList, paramBoolean, this.a.shouldUrlEncodeResourcePath(), this.e);
      if (StringUtils.isValidString(str)) {
        Uri uri;
        File file = this.c.a(str, f());
        if (file != null) {
          uri = Uri.fromFile(file);
          if (uri != null)
            return uri; 
          if (y.a())
            this.h.e(this.g, "Unable to extract Uri from image file"); 
        } else if (y.a()) {
          y y = this.h;
          String str1 = this.g;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to retrieve File from cached image filename = ");
          stringBuilder.append((String)uri);
          y.e(str1, stringBuilder.toString());
        } 
      } 
    } finally {
      paramList = null;
    } 
  }
  
  protected boolean b() {
    return this.i;
  }
  
  String c(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    com.applovin.impl.sdk.network.c c1 = com.applovin.impl.sdk.network.c.a(this.f).a(paramString).b("GET").a("").a(0).a();
    AtomicReference<String> atomicReference = new AtomicReference(null);
    this.f.O().a(c1, new b.a(), new b.c<String>(this, atomicReference, paramString) {
          public void a(int param1Int, String param1String1, String param1String2) {
            y y = this.c.h;
            if (y.a()) {
              c c1 = this.c;
              y = c1.h;
              String str = c1.g;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Failed to load resource from '");
              stringBuilder.append(this.b);
              stringBuilder.append("'");
              y.e(str, stringBuilder.toString());
            } 
          }
          
          public void a(String param1String, int param1Int) {
            this.a.set(param1String);
          }
        });
    paramString = atomicReference.get();
    if (paramString != null)
      this.e.a(paramString.length()); 
    return paramString;
  }
  
  String c(String paramString, List<String> paramList, boolean paramBoolean) {
    if (StringUtils.isValidString(paramString)) {
      Uri uri = Uri.parse(paramString);
      if (uri == null) {
        if (y.a())
          this.h.b(this.g, "Nothing to cache, skipping..."); 
        return null;
      } 
      String str1 = Utils.getFileName(uri);
      String str2 = str1;
      if (paramBoolean)
        str2 = StringUtils.encodeUriString(str1); 
      int i = ((Integer)this.f.a(b.bE)).intValue();
      int j = StringUtils.emptyIfNull(str2).length() + StringUtils.emptyIfNull(this.a.L()).length();
      str1 = str2;
      if (j > i) {
        str1 = str2;
        if (StringUtils.isValidString(str2))
          str1 = str2.substring(j - i); 
      } 
      str2 = str1;
      if (StringUtils.isValidString(this.a.L())) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a.L());
        stringBuilder.append(str1);
        str2 = stringBuilder.toString();
      } 
      try {
        File file = this.c.a(str2, f());
        if (file != null && file.exists())
          return this.c.a(file); 
        try {
          InputStream inputStream = this.c.a(paramString, paramList, true, this.e);
          return this.c.a(file);
        } finally {
          file = null;
        } 
        Utils.close((Closeable)paramList, this.f);
        throw file;
      } finally {
        paramList = null;
      } 
    } 
    return null;
  }
  
  void c() {
    if (y.a())
      this.h.b(this.g, "Caching mute images..."); 
    Uri uri = a(this.a.aE(), "mute");
    if (uri != null)
      this.a.e(uri); 
    uri = a(this.a.aF(), "unmute");
    if (uri != null)
      this.a.f(uri); 
    if (y.a()) {
      y y = this.h;
      String str = this.g;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ad updated with muteImageFilename = ");
      stringBuilder.append(this.a.aE());
      stringBuilder.append(", unmuteImageFilename = ");
      stringBuilder.append(this.a.aF());
      y.b(str, stringBuilder.toString());
    } 
  }
  
  void h() {
    AppLovinAdLoadListener appLovinAdLoadListener = this.b;
    if (appLovinAdLoadListener != null) {
      appLovinAdLoadListener.failedToReceiveAd(-202);
      this.b = null;
    } 
  }
  
  void i() {
    if (y.a()) {
      y y = this.h;
      String str = this.g;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rendered new ad:");
      stringBuilder.append(this.a);
      y.b(str, stringBuilder.toString());
    } 
    AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
          public void run() {
            if (c.a(this.a) != null) {
              c.a(this.a).adReceived((AppLovinAd)this.a.a);
              c.a(this.a, (AppLovinAdLoadListener)null);
            } 
          }
        });
  }
  
  public void run() {
    if (this.a.M()) {
      if (y.a())
        this.h.b(this.g, "Subscribing to timeout events..."); 
      this.f.ar().a(this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */