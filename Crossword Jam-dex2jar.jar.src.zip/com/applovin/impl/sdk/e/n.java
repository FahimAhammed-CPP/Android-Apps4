package com.applovin.impl.sdk.e;

import android.app.Activity;
import com.applovin.impl.b.a;
import com.applovin.impl.b.a.b;
import com.applovin.impl.sdk.af;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.g;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.r;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.l;
import com.applovin.impl.sdk.utils.q;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinSdk;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class n extends a {
  private final p a;
  
  public n(p paramp) {
    super("TaskInitializeSdk", paramp);
    this.a = paramp;
  }
  
  private void a() {
    if (this.a.ao().a())
      return; 
    Activity activity = this.a.x();
    if (activity != null) {
      this.a.ao().a(activity);
      return;
    } 
    this.a.M().a((a)new z(this.a, true, new Runnable(this) {
            public void run() {
              n.a(this.a).ao().a(n.a(this.a).w().a());
            }
          }), o.a.a, TimeUnit.SECONDS.toMillis(1L));
  }
  
  private void b() {
    if (!this.a.e()) {
      Map map1;
      Map map2;
      boolean bool = this.a.N().d();
      r r = this.a.S();
      String str = "<Enable verbose logging to see the GAID to use for test devices - https://monetization-support.applovin.com/hc/en-us/articles/236114328-How-can-I-expose-verbose-logging-for-the-SDK>";
      if (r != null) {
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(this.a.Q().d().b());
          stringBuilder.append(" (use this for test devices)");
          String str1 = stringBuilder.toString();
        } 
        map1 = this.a.S().b();
        map2 = this.a.S().g();
      } else {
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(this.a.R().k().b());
          stringBuilder.append(" (use this for test devices)");
          str = stringBuilder.toString();
        } 
        map1 = this.a.R().d();
        map2 = this.a.R().c();
      } 
      l l = new l();
      l.a().a("=====AppLovin SDK=====");
      l.a("===SDK Versions===").a("Version", AppLovinSdk.VERSION).a("Plugin Version", this.a.a(b.dT)).a("Ad Review Version", g.a()).a("OM SDK Version", this.a.ag().c());
      l.a("===Device Info===").a("OS", Utils.getAndroidOSInfo()).a("GAID", str).a("Model", map1.get("model")).a("Locale", map1.get("locale")).a("Emulator", map1.get("sim")).a("Tablet", map1.get("is_tablet"));
      l.a("===App Info===").a("Application ID", map2.get("package_name")).a("Target SDK", map2.get("target_sdk")).a("ExoPlayer Version", Integer.valueOf(Utils.getExoPlayerVersionCode()));
      l.a("===SDK Settings===").a("SDK Key", this.a.B()).a("Mediation Provider", this.a.s()).a("TG", q.a(this.a)).a("AEI", this.a.a(b.ax)).a("MEI", this.a.a(b.ay)).a("Test Mode On", Boolean.valueOf(this.a.av().a())).a("Verbose Logging On", Boolean.valueOf(bool));
      l.a("===Privacy States===\nPlease review AppLovin MAX documentation to be compliant with regional privacy policies.").a(a.a(f()));
      b b = this.a.ae();
      bool = b.b();
      if (bool)
        l.a("===Consent Flow Settings===").a("Enabled", Boolean.valueOf(bool)).a("Privacy Policy URI", b.c()).a("Terms of Service URI", b.d()); 
      l.a();
      y.f("AppLovinSdk", l.toString());
    } 
  }
  
  public void run() {
    // Byte code:
    //   0: ldc_w 'succeeded'
    //   3: astore #8
    //   5: invokestatic currentTimeMillis : ()J
    //   8: lstore_1
    //   9: invokestatic a : ()Z
    //   12: ifeq -> 75
    //   15: aload_0
    //   16: getfield h : Lcom/applovin/impl/sdk/y;
    //   19: astore #5
    //   21: aload_0
    //   22: getfield g : Ljava/lang/String;
    //   25: astore #6
    //   27: new java/lang/StringBuilder
    //   30: dup
    //   31: invokespecial <init> : ()V
    //   34: astore #7
    //   36: aload #7
    //   38: ldc_w 'Initializing AppLovin SDK v'
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: pop
    //   45: aload #7
    //   47: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload #7
    //   56: ldc_w '...'
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: aload #5
    //   65: aload #6
    //   67: aload #7
    //   69: invokevirtual toString : ()Ljava/lang/String;
    //   72: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   75: aload_0
    //   76: getfield a : Lcom/applovin/impl/sdk/p;
    //   79: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   82: invokevirtual d : ()V
    //   85: aload_0
    //   86: getfield a : Lcom/applovin/impl/sdk/p;
    //   89: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   92: getstatic com/applovin/impl/sdk/d/f.e : Lcom/applovin/impl/sdk/d/f;
    //   95: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   98: aload_0
    //   99: getfield a : Lcom/applovin/impl/sdk/p;
    //   102: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   105: getstatic com/applovin/impl/sdk/d/f.f : Lcom/applovin/impl/sdk/d/f;
    //   108: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   111: aload_0
    //   112: getfield a : Lcom/applovin/impl/sdk/p;
    //   115: invokevirtual W : ()Lcom/applovin/impl/sdk/v;
    //   118: aload_0
    //   119: invokevirtual f : ()Landroid/content/Context;
    //   122: invokevirtual a : (Landroid/content/Context;)V
    //   125: aload_0
    //   126: getfield a : Lcom/applovin/impl/sdk/p;
    //   129: invokevirtual W : ()Lcom/applovin/impl/sdk/v;
    //   132: aload_0
    //   133: invokevirtual f : ()Landroid/content/Context;
    //   136: invokevirtual b : (Landroid/content/Context;)V
    //   139: aload_0
    //   140: getfield a : Lcom/applovin/impl/sdk/p;
    //   143: invokevirtual M : ()Lcom/applovin/impl/sdk/e/o;
    //   146: new com/applovin/impl/sdk/e/b
    //   149: dup
    //   150: aload_0
    //   151: getfield a : Lcom/applovin/impl/sdk/p;
    //   154: invokespecial <init> : (Lcom/applovin/impl/sdk/p;)V
    //   157: getstatic com/applovin/impl/sdk/e/o$a.a : Lcom/applovin/impl/sdk/e/o$a;
    //   160: invokevirtual a : (Lcom/applovin/impl/sdk/e/a;Lcom/applovin/impl/sdk/e/o$a;)V
    //   163: aload_0
    //   164: getfield a : Lcom/applovin/impl/sdk/p;
    //   167: invokevirtual S : ()Lcom/applovin/impl/sdk/r;
    //   170: ifnull -> 186
    //   173: aload_0
    //   174: getfield a : Lcom/applovin/impl/sdk/p;
    //   177: invokevirtual S : ()Lcom/applovin/impl/sdk/r;
    //   180: invokevirtual c : ()V
    //   183: goto -> 196
    //   186: aload_0
    //   187: getfield a : Lcom/applovin/impl/sdk/p;
    //   190: invokevirtual R : ()Lcom/applovin/impl/sdk/q;
    //   193: invokevirtual e : ()V
    //   196: aload_0
    //   197: getfield a : Lcom/applovin/impl/sdk/p;
    //   200: invokevirtual ac : ()Lcom/applovin/impl/sdk/utils/o;
    //   203: invokevirtual a : ()V
    //   206: aload_0
    //   207: getfield a : Lcom/applovin/impl/sdk/p;
    //   210: invokevirtual af : ()Lcom/applovin/impl/a/a/a;
    //   213: invokevirtual a : ()V
    //   216: aload_0
    //   217: invokevirtual f : ()Landroid/content/Context;
    //   220: aload_0
    //   221: getfield a : Lcom/applovin/impl/sdk/p;
    //   224: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/p;)Z
    //   227: ifeq -> 237
    //   230: aload_0
    //   231: getfield a : Lcom/applovin/impl/sdk/p;
    //   234: invokevirtual i : ()V
    //   237: aload_0
    //   238: getfield a : Lcom/applovin/impl/sdk/p;
    //   241: invokevirtual ai : ()Lcom/applovin/impl/sdk/array/ArrayService;
    //   244: invokevirtual collectAppHubData : ()V
    //   247: aload_0
    //   248: invokespecial b : ()V
    //   251: aload_0
    //   252: getfield a : Lcom/applovin/impl/sdk/p;
    //   255: getstatic com/applovin/impl/sdk/c/b.eo : Lcom/applovin/impl/sdk/c/b;
    //   258: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   261: checkcast java/lang/Boolean
    //   264: invokevirtual booleanValue : ()Z
    //   267: ifeq -> 281
    //   270: new com/applovin/impl/sdk/e/n$1
    //   273: dup
    //   274: aload_0
    //   275: invokespecial <init> : (Lcom/applovin/impl/sdk/e/n;)V
    //   278: invokestatic runOnUiThread : (Ljava/lang/Runnable;)V
    //   281: aload_0
    //   282: invokespecial a : ()V
    //   285: aload_0
    //   286: getfield a : Lcom/applovin/impl/sdk/p;
    //   289: iconst_1
    //   290: invokevirtual a : (Z)V
    //   293: aload_0
    //   294: getfield a : Lcom/applovin/impl/sdk/p;
    //   297: invokevirtual al : ()Lcom/applovin/impl/sdk/network/k;
    //   300: invokeinterface c : ()V
    //   305: aload_0
    //   306: getfield a : Lcom/applovin/impl/sdk/p;
    //   309: invokevirtual G : ()Lcom/applovin/impl/sdk/EventServiceImpl;
    //   312: invokevirtual maybeTrackAppOpenEvent : ()V
    //   315: aload_0
    //   316: getfield a : Lcom/applovin/impl/sdk/p;
    //   319: invokevirtual as : ()Lcom/applovin/impl/mediation/debugger/b;
    //   322: invokevirtual b : ()Z
    //   325: ifeq -> 338
    //   328: aload_0
    //   329: getfield a : Lcom/applovin/impl/sdk/p;
    //   332: invokevirtual e : ()Z
    //   335: ifeq -> 380
    //   338: aload_0
    //   339: getfield a : Lcom/applovin/impl/sdk/p;
    //   342: getstatic com/applovin/impl/sdk/c/a.h : Lcom/applovin/impl/sdk/c/b;
    //   345: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   348: checkcast java/lang/Boolean
    //   351: invokevirtual booleanValue : ()Z
    //   354: ifeq -> 390
    //   357: invokestatic y : ()Landroid/content/Context;
    //   360: aload_0
    //   361: getfield a : Lcom/applovin/impl/sdk/p;
    //   364: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/p;)Z
    //   367: ifeq -> 390
    //   370: aload_0
    //   371: getfield a : Lcom/applovin/impl/sdk/p;
    //   374: invokevirtual f : ()Z
    //   377: ifeq -> 390
    //   380: aload_0
    //   381: getfield a : Lcom/applovin/impl/sdk/p;
    //   384: invokevirtual as : ()Lcom/applovin/impl/mediation/debugger/b;
    //   387: invokevirtual a : ()V
    //   390: aload_0
    //   391: getfield a : Lcom/applovin/impl/sdk/p;
    //   394: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   397: invokevirtual a : ()V
    //   400: aload_0
    //   401: getfield a : Lcom/applovin/impl/sdk/p;
    //   404: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   407: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   410: checkcast java/lang/Boolean
    //   413: invokevirtual booleanValue : ()Z
    //   416: ifeq -> 444
    //   419: aload_0
    //   420: getfield a : Lcom/applovin/impl/sdk/p;
    //   423: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   426: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   429: checkcast java/lang/Long
    //   432: invokevirtual longValue : ()J
    //   435: lstore_3
    //   436: aload_0
    //   437: getfield a : Lcom/applovin/impl/sdk/p;
    //   440: lload_3
    //   441: invokevirtual a : (J)V
    //   444: invokestatic a : ()Z
    //   447: ifeq -> 755
    //   450: aload_0
    //   451: getfield h : Lcom/applovin/impl/sdk/y;
    //   454: astore #11
    //   456: aload_0
    //   457: getfield g : Ljava/lang/String;
    //   460: astore #10
    //   462: new java/lang/StringBuilder
    //   465: dup
    //   466: invokespecial <init> : ()V
    //   469: astore #9
    //   471: aload #9
    //   473: ldc_w 'AppLovin SDK '
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: pop
    //   480: aload #9
    //   482: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: pop
    //   489: aload #9
    //   491: ldc_w ' initialization '
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #11
    //   500: astore #5
    //   502: aload #10
    //   504: astore #6
    //   506: aload #9
    //   508: astore #7
    //   510: aload_0
    //   511: getfield a : Lcom/applovin/impl/sdk/p;
    //   514: invokevirtual d : ()Z
    //   517: ifeq -> 701
    //   520: aload #11
    //   522: astore #5
    //   524: aload #10
    //   526: astore #6
    //   528: aload #9
    //   530: astore #7
    //   532: goto -> 706
    //   535: astore #5
    //   537: ldc_w 'AppLovinSdk'
    //   540: ldc_w 'Failed to initialize SDK!'
    //   543: aload #5
    //   545: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   548: aload_0
    //   549: getfield a : Lcom/applovin/impl/sdk/p;
    //   552: iconst_0
    //   553: invokevirtual a : (Z)V
    //   556: aload_0
    //   557: getfield a : Lcom/applovin/impl/sdk/p;
    //   560: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   563: invokevirtual a : ()V
    //   566: aload_0
    //   567: getfield a : Lcom/applovin/impl/sdk/p;
    //   570: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   573: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   576: checkcast java/lang/Boolean
    //   579: invokevirtual booleanValue : ()Z
    //   582: ifeq -> 610
    //   585: aload_0
    //   586: getfield a : Lcom/applovin/impl/sdk/p;
    //   589: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   592: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   595: checkcast java/lang/Long
    //   598: invokevirtual longValue : ()J
    //   601: lstore_3
    //   602: aload_0
    //   603: getfield a : Lcom/applovin/impl/sdk/p;
    //   606: lload_3
    //   607: invokevirtual a : (J)V
    //   610: invokestatic a : ()Z
    //   613: ifeq -> 755
    //   616: aload_0
    //   617: getfield h : Lcom/applovin/impl/sdk/y;
    //   620: astore #11
    //   622: aload_0
    //   623: getfield g : Ljava/lang/String;
    //   626: astore #10
    //   628: new java/lang/StringBuilder
    //   631: dup
    //   632: invokespecial <init> : ()V
    //   635: astore #9
    //   637: aload #9
    //   639: ldc_w 'AppLovin SDK '
    //   642: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   645: pop
    //   646: aload #9
    //   648: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   651: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   654: pop
    //   655: aload #9
    //   657: ldc_w ' initialization '
    //   660: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: pop
    //   664: aload #11
    //   666: astore #5
    //   668: aload #10
    //   670: astore #6
    //   672: aload #9
    //   674: astore #7
    //   676: aload_0
    //   677: getfield a : Lcom/applovin/impl/sdk/p;
    //   680: invokevirtual d : ()Z
    //   683: ifeq -> 701
    //   686: aload #11
    //   688: astore #5
    //   690: aload #10
    //   692: astore #6
    //   694: aload #9
    //   696: astore #7
    //   698: goto -> 706
    //   701: ldc_w 'failed'
    //   704: astore #8
    //   706: aload #7
    //   708: aload #8
    //   710: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   713: pop
    //   714: aload #7
    //   716: ldc_w ' in '
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: pop
    //   723: aload #7
    //   725: invokestatic currentTimeMillis : ()J
    //   728: lload_1
    //   729: lsub
    //   730: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #7
    //   736: ldc_w 'ms'
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #5
    //   745: aload #6
    //   747: aload #7
    //   749: invokevirtual toString : ()Ljava/lang/String;
    //   752: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   755: return
    //   756: astore #5
    //   758: aload_0
    //   759: getfield a : Lcom/applovin/impl/sdk/p;
    //   762: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   765: invokevirtual a : ()V
    //   768: aload_0
    //   769: getfield a : Lcom/applovin/impl/sdk/p;
    //   772: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   775: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   778: checkcast java/lang/Boolean
    //   781: invokevirtual booleanValue : ()Z
    //   784: ifeq -> 812
    //   787: aload_0
    //   788: getfield a : Lcom/applovin/impl/sdk/p;
    //   791: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   794: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   797: checkcast java/lang/Long
    //   800: invokevirtual longValue : ()J
    //   803: lstore_3
    //   804: aload_0
    //   805: getfield a : Lcom/applovin/impl/sdk/p;
    //   808: lload_3
    //   809: invokevirtual a : (J)V
    //   812: invokestatic a : ()Z
    //   815: ifeq -> 933
    //   818: aload_0
    //   819: getfield h : Lcom/applovin/impl/sdk/y;
    //   822: astore #6
    //   824: aload_0
    //   825: getfield g : Ljava/lang/String;
    //   828: astore #7
    //   830: new java/lang/StringBuilder
    //   833: dup
    //   834: invokespecial <init> : ()V
    //   837: astore #9
    //   839: aload #9
    //   841: ldc_w 'AppLovin SDK '
    //   844: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   847: pop
    //   848: aload #9
    //   850: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   853: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   856: pop
    //   857: aload #9
    //   859: ldc_w ' initialization '
    //   862: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   865: pop
    //   866: aload_0
    //   867: getfield a : Lcom/applovin/impl/sdk/p;
    //   870: invokevirtual d : ()Z
    //   873: ifeq -> 879
    //   876: goto -> 884
    //   879: ldc_w 'failed'
    //   882: astore #8
    //   884: aload #9
    //   886: aload #8
    //   888: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   891: pop
    //   892: aload #9
    //   894: ldc_w ' in '
    //   897: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   900: pop
    //   901: aload #9
    //   903: invokestatic currentTimeMillis : ()J
    //   906: lload_1
    //   907: lsub
    //   908: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   911: pop
    //   912: aload #9
    //   914: ldc_w 'ms'
    //   917: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   920: pop
    //   921: aload #6
    //   923: aload #7
    //   925: aload #9
    //   927: invokevirtual toString : ()Ljava/lang/String;
    //   930: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   933: aload #5
    //   935: athrow
    // Exception table:
    //   from	to	target	type
    //   75	183	535	finally
    //   186	196	535	finally
    //   196	237	535	finally
    //   237	281	535	finally
    //   281	338	535	finally
    //   338	380	535	finally
    //   380	390	535	finally
    //   537	556	756	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\e\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */