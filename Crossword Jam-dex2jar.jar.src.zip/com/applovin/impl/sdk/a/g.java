package com.applovin.impl.sdk.a;

import android.text.TextUtils;
import android.webkit.WebView;
import androidx.annotation.Nullable;
import com.applovin.impl.c.a;
import com.applovin.impl.c.b;
import com.applovin.impl.c.f;
import com.applovin.impl.c.h;
import com.applovin.impl.c.m;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.y;
import com.iab.omid.library.applovin.adsession.AdSession;
import com.iab.omid.library.applovin.adsession.AdSessionConfiguration;
import com.iab.omid.library.applovin.adsession.AdSessionContext;
import com.iab.omid.library.applovin.adsession.CreativeType;
import com.iab.omid.library.applovin.adsession.ImpressionType;
import com.iab.omid.library.applovin.adsession.Owner;
import com.iab.omid.library.applovin.adsession.VerificationScriptResource;
import com.iab.omid.library.applovin.adsession.media.InteractionType;
import com.iab.omid.library.applovin.adsession.media.MediaEvents;
import com.iab.omid.library.applovin.adsession.media.Position;
import com.iab.omid.library.applovin.adsession.media.VastProperties;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class g extends b {
  private final a i;
  
  private final AtomicBoolean j = new AtomicBoolean();
  
  private MediaEvents k;
  
  private final VastProperties l;
  
  private final AtomicBoolean m = new AtomicBoolean();
  
  private final AtomicBoolean n = new AtomicBoolean();
  
  private final AtomicBoolean o = new AtomicBoolean();
  
  private final AtomicBoolean p = new AtomicBoolean();
  
  public g(a parama) {
    super((AppLovinAdBase)parama);
    this.i = parama;
    float f = (float)parama.i();
    if (parama.i() == -1L) {
      this.l = VastProperties.createVastPropertiesForNonSkippableMedia(true, Position.STANDALONE);
      return;
    } 
    this.l = VastProperties.createVastPropertiesForSkippableMedia(f, true, Position.STANDALONE);
  }
  
  @Nullable
  protected AdSessionConfiguration a() {
    try {
      CreativeType creativeType = CreativeType.VIDEO;
      return AdSessionConfiguration.createAdSessionConfiguration(creativeType, impressionType, owner, owner, false);
    } finally {
      Exception exception = null;
      if (y.a())
        this.c.b(this.d, "Failed to create ad session configuration", exception); 
    } 
  }
  
  @Nullable
  protected AdSessionContext a(@Nullable WebView paramWebView) {
    if (h || this.i.aY() != null) {
      ArrayList<VerificationScriptResource> arrayList = new ArrayList();
      for (b b1 : this.i.aY().a()) {
        List list = b1.b();
        if (list.isEmpty()) {
          m.a(b1.d(), f.d, this.b);
          continue;
        } 
        ArrayList<h> arrayList1 = new ArrayList();
        for (h h : list) {
          if ("omid".equalsIgnoreCase(h.a()))
            arrayList1.add(h); 
        } 
        if (arrayList1.isEmpty()) {
          m.a(b1.d(), f.c, this.b);
          continue;
        } 
        ArrayList<URL> arrayList2 = new ArrayList();
        for (h h : arrayList1) {
          try {
            arrayList2.add(new URL(h.b()));
          } finally {
            h = null;
          } 
        } 
        if (arrayList2.isEmpty()) {
          m.a(b1.d(), f.d, this.b);
          continue;
        } 
        String str1 = b1.c();
        String str2 = b1.a();
        if (StringUtils.isValidString(str1) && !StringUtils.isValidString(str2)) {
          m.a(b1.d(), f.d, this.b);
          continue;
        } 
        for (URL uRL : arrayList2) {
          VerificationScriptResource verificationScriptResource;
          if (StringUtils.isValidString(str1)) {
            verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithParameters(str2, uRL, str1);
          } else {
            verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithoutParameters((URL)verificationScriptResource);
          } 
          arrayList.add(verificationScriptResource);
        } 
      } 
      String str = this.b.ag().e();
      if (TextUtils.isEmpty(str)) {
        if (y.a())
          this.c.e(this.d, "JavaScript SDK content not loaded successfully"); 
        return null;
      } 
      try {
        return AdSessionContext.createNativeAdSessionContext(this.b.ag().d(), str, arrayList, this.i.getOpenMeasurementContentUrl(), this.i.getOpenMeasurementCustomReferenceData());
      } finally {
        str = null;
        if (y.a())
          this.c.b(this.d, "Failed to create ad session context", (Throwable)str); 
      } 
    } 
    throw new AssertionError();
  }
  
  public void a(float paramFloat, boolean paramBoolean) {
    if (this.m.compareAndSet(false, true))
      a("track started", new Runnable(this, paramFloat, paramBoolean) {
            public void run() {
              float f1;
              MediaEvents mediaEvents = g.b(this.c);
              float f2 = this.a;
              if (this.b) {
                f1 = 0.0F;
              } else {
                f1 = 1.0F;
              } 
              mediaEvents.start(f2, f1);
            }
          }); 
  }
  
  protected void a(AdSession paramAdSession) {
    try {
      return;
    } finally {
      paramAdSession = null;
      if (y.a())
        this.c.b(this.d, "Failed to create media events", (Throwable)paramAdSession); 
    } 
  }
  
  public void a(boolean paramBoolean) {
    a("track volume changed", new Runnable(this, paramBoolean) {
          public void run() {
            float f;
            MediaEvents mediaEvents = g.b(this.b);
            if (this.a) {
              f = 0.0F;
            } else {
              f = 1.0F;
            } 
            mediaEvents.volumeChange(f);
          }
        });
  }
  
  public void c() {
    a("track loaded", new Runnable(this) {
          public void run() {
            g g1 = this.a;
            g1.g.loaded(g.a(g1));
          }
        });
  }
  
  public void f() {
    if (this.n.compareAndSet(false, true))
      a("track first quartile", new Runnable(this) {
            public void run() {
              g.b(this.a).firstQuartile();
            }
          }); 
  }
  
  public void g() {
    if (this.o.compareAndSet(false, true))
      a("track midpoint", new Runnable(this) {
            public void run() {
              g.b(this.a).midpoint();
            }
          }); 
  }
  
  public void h() {
    if (this.p.compareAndSet(false, true))
      a("track third quartile", new Runnable(this) {
            public void run() {
              g.b(this.a).thirdQuartile();
            }
          }); 
  }
  
  public void i() {
    a("track completed", new Runnable(this) {
          public void run() {
            g.b(this.a).complete();
          }
        });
  }
  
  public void j() {
    a("track paused", new Runnable(this) {
          public void run() {
            g.b(this.a).pause();
          }
        });
  }
  
  public void k() {
    a("track resumed", new Runnable(this) {
          public void run() {
            g.b(this.a).resume();
          }
        });
  }
  
  public void l() {
    if (this.j.compareAndSet(false, true))
      a("buffer started", new Runnable(this) {
            public void run() {
              g.b(this.a).bufferStart();
            }
          }); 
  }
  
  public void m() {
    if (this.j.compareAndSet(true, false))
      a("buffer finished", new Runnable(this) {
            public void run() {
              g.b(this.a).bufferFinish();
            }
          }); 
  }
  
  public void n() {
    a("track skipped", new Runnable(this) {
          public void run() {
            g.b(this.a).skipped();
          }
        });
  }
  
  public void o() {
    a("track clicked", new Runnable(this) {
          public void run() {
            g.b(this.a).adUserInteraction(InteractionType.CLICK);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\a\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */