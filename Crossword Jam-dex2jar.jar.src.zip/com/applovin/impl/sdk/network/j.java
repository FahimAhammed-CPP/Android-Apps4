package com.applovin.impl.sdk.network;

import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

public class j {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private Map<String, String> e;
  
  private Map<String, String> f;
  
  private Map<String, Object> g;
  
  private boolean h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private String l;
  
  private int m;
  
  private j(a parama) {
    this.a = UUID.randomUUID().toString();
    this.b = a.a(parama);
    this.c = a.b(parama);
    this.d = a.c(parama);
    this.e = a.d(parama);
    this.f = a.e(parama);
    this.g = a.f(parama);
    this.h = a.g(parama);
    this.i = a.h(parama);
    this.j = a.i(parama);
    this.k = a.j(parama);
    this.l = a.k(parama);
    this.m = 0;
  }
  
  j(JSONObject paramJSONObject, p paramp) throws Exception {
    Map<String, String> map1;
    Map<String, String> map2;
    Map<String, Object> map;
    String str1 = JsonUtils.getString(paramJSONObject, "uniqueId", UUID.randomUUID().toString());
    String str2 = JsonUtils.getString(paramJSONObject, "communicatorRequestId", "");
    String str3 = JsonUtils.getString(paramJSONObject, "httpMethod", "");
    String str4 = paramJSONObject.getString("targetUrl");
    String str5 = JsonUtils.getString(paramJSONObject, "backupUrl", "");
    int i = paramJSONObject.getInt("attemptNumber");
    if (JsonUtils.valueExists(paramJSONObject, "parameters")) {
      map1 = Collections.synchronizedMap(JsonUtils.toStringMap(paramJSONObject.getJSONObject("parameters")));
    } else {
      map1 = CollectionUtils.map();
    } 
    if (JsonUtils.valueExists(paramJSONObject, "httpHeaders")) {
      map2 = Collections.synchronizedMap(JsonUtils.toStringMap(paramJSONObject.getJSONObject("httpHeaders")));
    } else {
      map2 = CollectionUtils.map();
    } 
    if (JsonUtils.valueExists(paramJSONObject, "requestBody")) {
      map = Collections.synchronizedMap(JsonUtils.toStringObjectMap(paramJSONObject.getJSONObject("requestBody")));
    } else {
      map = CollectionUtils.map();
    } 
    this.a = str1;
    this.b = str3;
    this.l = str2;
    this.c = str4;
    this.d = str5;
    this.e = map1;
    this.f = map2;
    this.g = map;
    this.h = paramJSONObject.optBoolean("isEncodingEnabled", false);
    this.i = paramJSONObject.optBoolean("gzipBodyEncoding", false);
    this.j = paramJSONObject.optBoolean("isAllowedPreInitEvent", false);
    this.k = paramJSONObject.optBoolean("shouldFireInWebView", false);
    this.m = i;
  }
  
  public static a o() {
    return new a();
  }
  
  String a() {
    return this.b;
  }
  
  String b() {
    return this.c;
  }
  
  String c() {
    return this.d;
  }
  
  Map<String, String> d() {
    return this.e;
  }
  
  Map<String, String> e() {
    return this.f;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return this.a.equals(((j)paramObject).a);
  }
  
  Map<String, Object> f() {
    return this.g;
  }
  
  boolean g() {
    return this.h;
  }
  
  boolean h() {
    return this.i;
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  boolean i() {
    return this.k;
  }
  
  String j() {
    return this.l;
  }
  
  int k() {
    return this.m;
  }
  
  void l() {
    this.m++;
  }
  
  void m() {
    Map<String, String> map = CollectionUtils.map(this.e);
    map.put("postback_ts", String.valueOf(System.currentTimeMillis()));
    this.e = map;
  }
  
  JSONObject n() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("uniqueId", this.a);
    jSONObject.put("communicatorRequestId", this.l);
    jSONObject.put("httpMethod", this.b);
    jSONObject.put("targetUrl", this.c);
    jSONObject.put("backupUrl", this.d);
    jSONObject.put("isEncodingEnabled", this.h);
    jSONObject.put("gzipBodyEncoding", this.i);
    jSONObject.put("isAllowedPreInitEvent", this.j);
    jSONObject.put("attemptNumber", this.m);
    if (this.e != null)
      jSONObject.put("parameters", new JSONObject(this.e)); 
    if (this.f != null)
      jSONObject.put("httpHeaders", new JSONObject(this.f)); 
    if (this.g != null)
      jSONObject.put("requestBody", new JSONObject(this.g)); 
    return jSONObject;
  }
  
  public boolean p() {
    return this.j;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PostbackRequest{uniqueId='");
    stringBuilder.append(this.a);
    stringBuilder.append('\'');
    stringBuilder.append(", communicatorRequestId='");
    stringBuilder.append(this.l);
    stringBuilder.append('\'');
    stringBuilder.append(", httpMethod='");
    stringBuilder.append(this.b);
    stringBuilder.append('\'');
    stringBuilder.append(", targetUrl='");
    stringBuilder.append(this.c);
    stringBuilder.append('\'');
    stringBuilder.append(", backupUrl='");
    stringBuilder.append(this.d);
    stringBuilder.append('\'');
    stringBuilder.append(", attemptNumber=");
    stringBuilder.append(this.m);
    stringBuilder.append(", isEncodingEnabled=");
    stringBuilder.append(this.h);
    stringBuilder.append(", isGzipBodyEncoding=");
    stringBuilder.append(this.i);
    stringBuilder.append(", isAllowedPreInitEvent=");
    stringBuilder.append(this.j);
    stringBuilder.append(", shouldFireInWebView=");
    stringBuilder.append(this.k);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static class a {
    private String a;
    
    private String b;
    
    private String c;
    
    private String d;
    
    private Map<String, String> e;
    
    private Map<String, String> f;
    
    private Map<String, Object> g;
    
    private boolean h;
    
    private boolean i;
    
    private boolean j;
    
    private boolean k;
    
    public a a(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public a a(Map<String, String> param1Map) {
      this.e = param1Map;
      return this;
    }
    
    public a a(boolean param1Boolean) {
      this.h = param1Boolean;
      return this;
    }
    
    public j a() {
      return new j(this);
    }
    
    public a b(String param1String) {
      this.b = param1String;
      return this;
    }
    
    public a b(Map<String, String> param1Map) {
      this.f = param1Map;
      return this;
    }
    
    public a b(boolean param1Boolean) {
      this.i = param1Boolean;
      return this;
    }
    
    public a c(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public a c(Map<String, Object> param1Map) {
      this.g = param1Map;
      return this;
    }
    
    public a c(boolean param1Boolean) {
      this.j = param1Boolean;
      return this;
    }
    
    public a d(String param1String) {
      this.d = param1String;
      return this;
    }
    
    public a d(boolean param1Boolean) {
      this.k = param1Boolean;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\network\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */