package com.applovin.impl.sdk.nativeAd;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.impl.adview.d;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.a.e;
import com.applovin.impl.sdk.ad;
import com.applovin.impl.sdk.array.ArrayDirectDownloadAd;
import com.applovin.impl.sdk.array.ArrayService;
import com.applovin.impl.sdk.network.l;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinSdkUtils;
import com.iab.omid.library.applovin.adsession.VerificationScriptResource;
import com.safedk.android.internal.partials.AppLovinNetworkBridge;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

public class AppLovinNativeAdImpl extends AppLovinAdBase implements AppLovinNativeAd {
  private static final String AD_RESPONSE_TYPE_APPLOVIN = "applovin";
  
  private static final String AD_RESPONSE_TYPE_ORTB = "ortb";
  
  private static final String AD_RESPONSE_TYPE_UNDEFINED = "undefined";
  
  private static final String DEFAULT_APPLOVIN_PRIVACY_URL = "https://www.applovin.com/privacy/";
  
  private static final float MINIMUM_STARS_TO_RENDER = 3.0F;
  
  private static final int VIEWABLE_MRC100_PERCENTAGE = 100;
  
  private static final int VIEWABLE_MRC50_PERCENTAGE = 50;
  
  private static final int VIEWABLE_MRC_REQUIRED_SECONDS = 1;
  
  private static final int VIEWABLE_VIDEO_MRC_REQUIRED_SECONDS = 2;
  
  private final e adEventTracker = new e(this);
  
  private final String advertiser;
  
  private final String body;
  
  private final String callToAction;
  
  private final Uri clickDestinationBackupUri;
  
  private final Uri clickDestinationUri;
  
  private final a clickHandler = new a(this);
  
  private final List<String> clickTrackingUrls;
  
  private AppLovinNativeAdEventListener eventListener;
  
  private Uri iconUri;
  
  private final List<l> impressionRequests;
  
  private final AtomicBoolean impressionTracked = new AtomicBoolean();
  
  private final List<String> jsTrackers;
  
  private Uri mainImageUri;
  
  private AppLovinMediaView mediaView;
  
  private ViewGroup nativeAdView;
  
  private final b onAttachStateChangeHandler = new b(this);
  
  private AppLovinOptionsView optionsView;
  
  private Uri privacyDestinationUri;
  
  private Uri privacyIconUri;
  
  private final List<View> registeredViews = new ArrayList<View>();
  
  private final Double starRating;
  
  private final String tag;
  
  private final String title;
  
  private final com.applovin.impl.c.a vastAd;
  
  @Nullable
  private View videoView;
  
  private final c viewableMRC100Callback;
  
  private ad viewableMRC100Tracker;
  
  private final c viewableMRC50Callback;
  
  private ad viewableMRC50Tracker;
  
  @Nullable
  private c viewableVideoMRC50Callback;
  
  @Nullable
  private ad viewableVideoMRC50Tracker;
  
  private AppLovinNativeAdImpl(Builder paramBuilder) {
    super(paramBuilder.adObject, paramBuilder.fullResponse, paramBuilder.sdk);
    this.title = paramBuilder.title;
    this.advertiser = paramBuilder.advertiser;
    this.body = paramBuilder.body;
    this.callToAction = paramBuilder.callToAction;
    this.iconUri = paramBuilder.iconUri;
    this.mainImageUri = paramBuilder.mainImageUri;
    this.privacyIconUri = paramBuilder.privacyIconUri;
    com.applovin.impl.c.a a1 = paramBuilder.vastAd;
    this.vastAd = a1;
    this.clickDestinationUri = paramBuilder.clickDestinationUri;
    this.clickDestinationBackupUri = paramBuilder.clickDestinationBackupUri;
    this.clickTrackingUrls = paramBuilder.clickTrackingUrls;
    this.jsTrackers = paramBuilder.jsTrackers;
    this.impressionRequests = paramBuilder.impressionRequests;
    Double double_ = paramBuilder.starRating;
    if (double_ == null || double_.doubleValue() < 3.0D)
      double_ = null; 
    this.starRating = double_;
    if (paramBuilder.privacyDestinationUri != null) {
      this.privacyDestinationUri = paramBuilder.privacyDestinationUri;
    } else if (!isDspAd() || getSdk().av().a()) {
      this.privacyDestinationUri = Uri.parse("https://www.applovin.com/privacy/");
    } 
    this.viewableMRC50Callback = new c(this, paramBuilder.viewableMRC50Requests);
    this.viewableMRC100Callback = new c(this, paramBuilder.viewableMRC100Requests);
    if (a1 != null && a1.hasVideoUrl())
      this.viewableVideoMRC50Callback = new c(this, paramBuilder.viewableVideo50Requests); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinNativeAd:");
    stringBuilder.append(getAdIdNumber());
    this.tag = stringBuilder.toString();
  }
  
  private List<com.applovin.impl.sdk.d.a> getDirectClickTrackingPostbacks() {
    synchronized (this.adObjectLock) {
      String str = getStringFromAdObject("click_tracking_url", null);
      return Utils.getPostbacks("click_tracking_urls", this.adObject, getClCode(), str, this.sdk);
    } 
  }
  
  private boolean isDspAd() {
    return "ortb".equalsIgnoreCase(getType());
  }
  
  private void maybeHandleOnAttachedToWindow(View paramView) {
    if (this.impressionTracked.compareAndSet(false, true)) {
      ad ad1 = new ad((View)this.nativeAdView, this.sdk, this.viewableMRC50Callback);
      this.viewableMRC50Tracker = ad1;
      TimeUnit timeUnit = TimeUnit.SECONDS;
      ad1.a(0, 50.0F, 50.0F, timeUnit.toMillis(1L), (View)this.nativeAdView);
      ad1 = new ad((View)this.nativeAdView, this.sdk, this.viewableMRC100Callback);
      this.viewableMRC100Tracker = ad1;
      ad1.a(0, 100.0F, 100.0F, timeUnit.toMillis(1L), (View)this.nativeAdView);
      com.applovin.impl.c.a a1 = this.vastAd;
      if (a1 != null && a1.hasVideoUrl()) {
        ad ad2 = new ad((View)this.nativeAdView, this.sdk, this.viewableVideoMRC50Callback);
        this.viewableVideoMRC50Tracker = ad2;
        ad2.a(0, 50.0F, 50.0F, timeUnit.toMillis(2L), this.videoView);
      } 
      List<String> list = this.jsTrackers;
      if (list != null && list.size() > 0)
        if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.b.fQ)).booleanValue()) {
          for (String str : this.jsTrackers)
            this.sdk.aa().a(str); 
        } else {
          String str = this.jsTrackers.get(0);
          if (StringUtils.isValidString(str)) {
            d d = new d(null, this.sdk, paramView.getContext());
            AppLovinNetworkBridge.webviewLoadData((WebView)d, str, "text/html", "UTF-8");
            AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, d) {
                  public void run() {
                    this.a.stopLoading();
                  }
                }timeUnit.toMillis(5L));
          } 
        }  
      for (l l : this.impressionRequests)
        this.sdk.ak().dispatchPostbackRequest(l, null); 
      this.adEventTracker.a(paramView);
      this.adEventTracker.d();
    } 
  }
  
  public void destroy() {
    unregisterViewsForInteraction();
    this.eventListener = null;
    this.adEventTracker.e();
  }
  
  public e getAdEventTracker() {
    return this.adEventTracker;
  }
  
  public long getAdIdNumber() {
    return getLongFromAdObject("ad_id", -1L);
  }
  
  public String getAdvertiser() {
    return this.advertiser;
  }
  
  public String getBody() {
    return this.body;
  }
  
  @Nullable
  public String getCachePrefix() {
    return getStringFromAdObject("cache_prefix", null);
  }
  
  public String getCallToAction() {
    return this.callToAction;
  }
  
  public a getClickHandler() {
    return this.clickHandler;
  }
  
  @Nullable
  public Bundle getDirectDownloadParameters() {
    Bundle bundle = null;
    JSONObject jSONObject = getJsonObjectFromAdObject("ah_parameters", null);
    if (jSONObject != null)
      bundle = JsonUtils.toBundle(jSONObject); 
    return bundle;
  }
  
  @Nullable
  public String getDirectDownloadToken() {
    return getStringFromAdObject("ah_dd_token", null);
  }
  
  public Uri getIconUri() {
    return this.iconUri;
  }
  
  public Uri getMainImageUri() {
    return this.mainImageUri;
  }
  
  public AppLovinMediaView getMediaView() {
    return this.mediaView;
  }
  
  @Nullable
  public String getOpenMeasurementContentUrl() {
    return getStringFromAdObject("omid_content_url", null);
  }
  
  public String getOpenMeasurementCustomReferenceData() {
    return getStringFromAdObject("omid_custom_ref_data", "");
  }
  
  public List<VerificationScriptResource> getOpenMeasurementVerificationScriptResources() {
    null = new ArrayList();
    synchronized (this.adObjectLock) {
      JSONArray jSONArray = JsonUtils.getJSONArray(this.adObject, "omid_verification_script_resources", null);
      if (jSONArray != null)
        for (int i = 0;; i++) {
          if (i < jSONArray.length()) {
            JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray, i, null);
            try {
              URL uRL = new URL(JsonUtils.getString(jSONObject, "url", null));
              String str1 = JsonUtils.getString(jSONObject, "vendor_key", null);
            } finally {
              Exception exception = null;
              this.sdk.L();
            } 
          } else {
            return null;
          } 
        }  
      return null;
    } 
  }
  
  public AppLovinOptionsView getOptionsView() {
    return this.optionsView;
  }
  
  public Uri getPrivacyDestinationUri() {
    return this.privacyDestinationUri;
  }
  
  public Uri getPrivacyIconUri() {
    return this.privacyIconUri;
  }
  
  public Double getStarRating() {
    return this.starRating;
  }
  
  public String getTitle() {
    return this.title;
  }
  
  public String getType() {
    return getStringFromAdObject("type", "undefined");
  }
  
  public com.applovin.impl.c.a getVastAd() {
    return this.vastAd;
  }
  
  public boolean isDirectDownloadEnabled() {
    return StringUtils.isValidString(getDirectDownloadToken());
  }
  
  public boolean isOpenMeasurementEnabled() {
    return getBooleanFromAdObject("omsdk_enabled", Boolean.FALSE);
  }
  
  public void registerViewsForInteraction(List<View> paramList, ViewGroup paramViewGroup) {
    this.nativeAdView = paramViewGroup;
    if (h.c() && this.nativeAdView.isAttachedToWindow()) {
      maybeHandleOnAttachedToWindow((View)this.nativeAdView);
    } else if (!h.c() && this.nativeAdView.getParent() != null) {
      maybeHandleOnAttachedToWindow((View)this.nativeAdView);
    } else {
      this.nativeAdView.addOnAttachStateChangeListener(this.onAttachStateChangeHandler);
    } 
    this.sdk.L();
    if (y.a()) {
      y y = this.sdk.L();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Registered ad view for impressions: ");
      stringBuilder.append(this.nativeAdView);
      y.b(str, stringBuilder.toString());
    } 
    if (this.clickDestinationUri == null && this.clickDestinationBackupUri == null) {
      this.sdk.L();
      if (y.a())
        this.sdk.L().b(this.tag, "Skipping click registration - no click URLs provided"); 
      return;
    } 
    for (View view : paramList) {
      if (view.hasOnClickListeners()) {
        this.sdk.L();
        if (y.a()) {
          y y = this.sdk.L();
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("View has an onClickListener already - ");
          stringBuilder.append(view);
          y.e(str, stringBuilder.toString());
        } 
      } 
      if (!view.isClickable()) {
        this.sdk.L();
        if (y.a()) {
          y y = this.sdk.L();
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("View is not clickable - ");
          stringBuilder.append(view);
          y.e(str, stringBuilder.toString());
        } 
      } 
      if (!view.isEnabled()) {
        this.sdk.L();
        if (y.a()) {
          y y = this.sdk.L();
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("View is not enabled - ");
          stringBuilder.append(view);
          y.e(str, stringBuilder.toString());
        } 
      } 
      if (view instanceof android.widget.Button) {
        this.sdk.L();
        if (y.a()) {
          y y = this.sdk.L();
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Registering click for button: ");
          stringBuilder.append(view);
          y.b(str, stringBuilder.toString());
        } 
      } else {
        this.sdk.L();
        if (y.a()) {
          y y = this.sdk.L();
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Registering click for view: ");
          stringBuilder.append(view);
          y.b(str, stringBuilder.toString());
        } 
      } 
      view.setOnClickListener(this.clickHandler);
      this.registeredViews.add(view);
    } 
    this.sdk.L();
    if (y.a()) {
      y y = this.sdk.L();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Registered views: ");
      stringBuilder.append(this.registeredViews);
      y.b(str, stringBuilder.toString());
    } 
  }
  
  public void setEventListener(AppLovinNativeAdEventListener paramAppLovinNativeAdEventListener) {
    this.eventListener = paramAppLovinNativeAdEventListener;
  }
  
  public void setIconUri(Uri paramUri) {
    this.iconUri = paramUri;
  }
  
  public void setMainImageUri(Uri paramUri) {
    this.mainImageUri = paramUri;
  }
  
  public void setPrivacyIconUri(Uri paramUri) {
    this.privacyIconUri = paramUri;
  }
  
  public void setUpNativeAdViewComponents() {
    com.applovin.impl.c.a a1 = this.vastAd;
    if (a1 != null && a1.hasVideoUrl()) {
      try {
        this.mediaView = (AppLovinMediaView)new AppLovinVastMediaView(this, this.sdk, p.y());
      } finally {
        a1 = null;
        this.sdk.L();
        if (y.a())
          this.sdk.L().a(this.tag, "Failed to create ExoPlayer VAST media view. Falling back to static image for media view.", (Throwable)a1); 
      } 
    } else {
      this.mediaView = new AppLovinMediaView(this, this.sdk, p.y());
    } 
    if (this.privacyDestinationUri != null) {
      this.optionsView = new AppLovinOptionsView(this, this.sdk, p.y());
      return;
    } 
    this.sdk.L();
    if (y.a())
      this.sdk.L().b(this.tag, "Privacy icon will not render because no native ad privacy URL is provided."); 
  }
  
  public void setVideoView(@Nullable View paramView) {
    this.videoView = paramView;
  }
  
  public boolean shouldInjectOpenMeasurementScriptDuringCaching() {
    return false;
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinNativeAd{adIdNumber=");
    stringBuilder.append(getAdIdNumber());
    stringBuilder.append(" - ");
    stringBuilder.append(getTitle());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void unregisterViewsForInteraction() {
    Iterator<View> iterator = this.registeredViews.iterator();
    while (iterator.hasNext())
      ((View)iterator.next()).setOnClickListener(null); 
    this.sdk.L();
    if (y.a()) {
      y y = this.sdk.L();
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unregistered views: ");
      stringBuilder.append(this.registeredViews);
      y.b(str, stringBuilder.toString());
    } 
    this.registeredViews.clear();
    ad ad1 = this.viewableMRC50Tracker;
    if (ad1 != null)
      ad1.a(); 
    ad1 = this.viewableMRC100Tracker;
    if (ad1 != null)
      ad1.a(); 
    ad1 = this.viewableVideoMRC50Tracker;
    if (ad1 != null)
      ad1.a(); 
    ViewGroup viewGroup = this.nativeAdView;
    if (viewGroup != null) {
      viewGroup.removeOnAttachStateChangeListener(this.onAttachStateChangeHandler);
      this.nativeAdView = null;
    } 
    AppLovinMediaView appLovinMediaView = this.mediaView;
    if (appLovinMediaView != null)
      appLovinMediaView.destroy(); 
    AppLovinOptionsView appLovinOptionsView = this.optionsView;
    if (appLovinOptionsView != null)
      appLovinOptionsView.destroy(); 
  }
  
  public static class Builder {
    private final JSONObject adObject;
    
    private String advertiser;
    
    private String body;
    
    private String callToAction;
    
    private Uri clickDestinationBackupUri;
    
    private Uri clickDestinationUri;
    
    private List<String> clickTrackingUrls;
    
    private final JSONObject fullResponse;
    
    private Uri iconUri;
    
    private List<l> impressionRequests;
    
    private List<String> jsTrackers;
    
    private Uri mainImageUri;
    
    private Uri privacyDestinationUri;
    
    private Uri privacyIconUri;
    
    private final p sdk;
    
    private Double starRating;
    
    private String title;
    
    private com.applovin.impl.c.a vastAd;
    
    private List<l> viewableMRC100Requests;
    
    private List<l> viewableMRC50Requests;
    
    private List<l> viewableVideo50Requests;
    
    public Builder(JSONObject param1JSONObject1, JSONObject param1JSONObject2, p param1p) {
      this.adObject = param1JSONObject1;
      this.fullResponse = param1JSONObject2;
      this.sdk = param1p;
    }
    
    public AppLovinNativeAdImpl build() {
      return new AppLovinNativeAdImpl(this);
    }
    
    public Builder setAdvertiser(String param1String) {
      this.advertiser = param1String;
      return this;
    }
    
    public Builder setBody(String param1String) {
      this.body = param1String;
      return this;
    }
    
    public Builder setCallToAction(String param1String) {
      this.callToAction = param1String;
      return this;
    }
    
    public Builder setClickDestinationBackupUri(Uri param1Uri) {
      this.clickDestinationBackupUri = param1Uri;
      return this;
    }
    
    public Builder setClickDestinationUri(Uri param1Uri) {
      this.clickDestinationUri = param1Uri;
      return this;
    }
    
    public Builder setClickTrackingUrls(List<String> param1List) {
      this.clickTrackingUrls = param1List;
      return this;
    }
    
    public Builder setIconUri(Uri param1Uri) {
      this.iconUri = param1Uri;
      return this;
    }
    
    public Builder setImpressionRequests(List<l> param1List) {
      this.impressionRequests = param1List;
      return this;
    }
    
    public Builder setJsTrackers(List<String> param1List) {
      this.jsTrackers = param1List;
      return this;
    }
    
    public Builder setMainImageUri(Uri param1Uri) {
      this.mainImageUri = param1Uri;
      return this;
    }
    
    public Builder setPrivacyDestinationUri(Uri param1Uri) {
      this.privacyDestinationUri = param1Uri;
      return this;
    }
    
    public Builder setPrivacyIconUri(Uri param1Uri) {
      this.privacyIconUri = param1Uri;
      return this;
    }
    
    public Builder setStarRating(Double param1Double) {
      this.starRating = param1Double;
      return this;
    }
    
    public Builder setTitle(String param1String) {
      this.title = param1String;
      return this;
    }
    
    public Builder setVastAd(com.applovin.impl.c.a param1a) {
      this.vastAd = param1a;
      return this;
    }
    
    public Builder setViewableMRC100Requests(List<l> param1List) {
      this.viewableMRC100Requests = param1List;
      return this;
    }
    
    public Builder setViewableMRC50Requests(List<l> param1List) {
      this.viewableMRC50Requests = param1List;
      return this;
    }
    
    public Builder setViewableVideo50Requests(List<l> param1List) {
      this.viewableVideo50Requests = param1List;
      return this;
    }
  }
  
  private static class a implements View.OnClickListener {
    private final AppLovinNativeAdImpl a;
    
    public a(AppLovinNativeAdImpl param1AppLovinNativeAdImpl) {
      this.a = param1AppLovinNativeAdImpl;
    }
    
    private void a(AppLovinNativeAdImpl param1AppLovinNativeAdImpl, Context param1Context) {
      y y;
      if (Utils.openUri(param1Context, param1AppLovinNativeAdImpl.clickDestinationUri, param1AppLovinNativeAdImpl.sdk)) {
        param1AppLovinNativeAdImpl.sdk.L();
        if (y.a()) {
          y = param1AppLovinNativeAdImpl.sdk.L();
          String str = param1AppLovinNativeAdImpl.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Opening URL: ");
          stringBuilder.append(param1AppLovinNativeAdImpl.clickDestinationUri);
          y.b(str, stringBuilder.toString());
          return;
        } 
      } else if (Utils.openUri((Context)y, param1AppLovinNativeAdImpl.clickDestinationBackupUri, param1AppLovinNativeAdImpl.sdk)) {
        param1AppLovinNativeAdImpl.sdk.L();
        if (y.a()) {
          y = param1AppLovinNativeAdImpl.sdk.L();
          String str = param1AppLovinNativeAdImpl.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Opening backup URL: ");
          stringBuilder.append(param1AppLovinNativeAdImpl.clickDestinationBackupUri);
          y.b(str, stringBuilder.toString());
        } 
      } 
    }
    
    public AppLovinNativeAdImpl a() {
      return this.a;
    }
    
    protected boolean a(Object param1Object) {
      return param1Object instanceof a;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof a))
        return false; 
      a a1 = (a)param1Object;
      if (!a1.a(this))
        return false; 
      param1Object = a();
      AppLovinNativeAdImpl appLovinNativeAdImpl = a1.a();
      if (param1Object == null) {
        if (appLovinNativeAdImpl != null)
          return false; 
      } else if (!param1Object.equals(appLovinNativeAdImpl)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      int i;
      AppLovinNativeAdImpl appLovinNativeAdImpl = a();
      if (appLovinNativeAdImpl == null) {
        i = 43;
      } else {
        i = appLovinNativeAdImpl.hashCode();
      } 
      return 59 + i;
    }
    
    public void onClick(View param1View) {
      this.a.sdk.L();
      if (y.a())
        this.a.sdk.L().b(this.a.tag, "Handle view clicked"); 
      this.a.sdk.E().maybeSubmitPersistentPostbacks(this.a.getDirectClickTrackingPostbacks());
      for (String str : this.a.clickTrackingUrls)
        this.a.sdk.ak().dispatchPostbackAsync(str, null); 
      k.a(this.a.eventListener, this.a);
      if (this.a.isDirectDownloadEnabled()) {
        this.a.sdk.ai().startDirectInstallOrDownloadProcess((ArrayDirectDownloadAd)this.a, new ArrayService.DirectDownloadListener(this, param1View) {
              public void onAppDetailsDismissed() {}
              
              public void onAppDetailsDisplayed() {}
              
              public void onFailure() {
                AppLovinNativeAdImpl.a a1 = this.b;
                AppLovinNativeAdImpl.a.a(a1, AppLovinNativeAdImpl.a.a(a1), this.a.getContext());
              }
            });
        return;
      } 
      a(this.a, param1View.getContext());
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppLovinNativeAdImpl.ClickHandler(ad=");
      stringBuilder.append(a());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  class null implements ArrayService.DirectDownloadListener {
    null(AppLovinNativeAdImpl this$0, View param1View) {}
    
    public void onAppDetailsDismissed() {}
    
    public void onAppDetailsDisplayed() {}
    
    public void onFailure() {
      AppLovinNativeAdImpl.a a1 = this.b;
      AppLovinNativeAdImpl.a.a(a1, AppLovinNativeAdImpl.a.a(a1), this.a.getContext());
    }
  }
  
  private static class b implements View.OnAttachStateChangeListener {
    private final AppLovinNativeAdImpl a;
    
    public b(AppLovinNativeAdImpl param1AppLovinNativeAdImpl) {
      this.a = param1AppLovinNativeAdImpl;
    }
    
    public AppLovinNativeAdImpl a() {
      return this.a;
    }
    
    protected boolean a(Object param1Object) {
      return param1Object instanceof b;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      b b1 = (b)param1Object;
      if (!b1.a(this))
        return false; 
      param1Object = a();
      AppLovinNativeAdImpl appLovinNativeAdImpl = b1.a();
      if (param1Object == null) {
        if (appLovinNativeAdImpl != null)
          return false; 
      } else if (!param1Object.equals(appLovinNativeAdImpl)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      int i;
      AppLovinNativeAdImpl appLovinNativeAdImpl = a();
      if (appLovinNativeAdImpl == null) {
        i = 43;
      } else {
        i = appLovinNativeAdImpl.hashCode();
      } 
      return 59 + i;
    }
    
    public void onViewAttachedToWindow(View param1View) {
      this.a.maybeHandleOnAttachedToWindow(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppLovinNativeAdImpl.OnAttachStateChangeHandler(ad=");
      stringBuilder.append(a());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  private class c implements ad.a {
    private final List<l> b;
    
    public c(AppLovinNativeAdImpl this$0, List<l> param1List) {
      this.b = param1List;
    }
    
    public List<l> a() {
      return this.b;
    }
    
    protected boolean a(Object param1Object) {
      return param1Object instanceof c;
    }
    
    public boolean equals(Object<l> param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof c))
        return false; 
      c c1 = (c)param1Object;
      if (!c1.a(this))
        return false; 
      param1Object = (Object<l>)a();
      List<l> list = c1.a();
      if (param1Object == null) {
        if (list != null)
          return false; 
      } else if (!param1Object.equals(list)) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      int i;
      List<l> list = a();
      if (list == null) {
        i = 43;
      } else {
        i = list.hashCode();
      } 
      return 59 + i;
    }
    
    public void onLogVisibilityImpression() {
      for (l l : this.b)
        this.a.sdk.ak().dispatchPostbackRequest(l, null); 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppLovinNativeAdImpl.VisibilityCallback(requests=");
      stringBuilder.append(a());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\nativeAd\AppLovinNativeAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */