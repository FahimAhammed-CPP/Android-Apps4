package com.applovin.impl.sdk;

import android.os.Process;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.CollectionUtils;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class AppLovinExceptionHandler implements Thread.UncaughtExceptionHandler {
  private static final AppLovinExceptionHandler a = new AppLovinExceptionHandler();
  
  private final Set<p> b = new HashSet<p>(2);
  
  private final AtomicBoolean c = new AtomicBoolean();
  
  private Thread.UncaughtExceptionHandler d;
  
  public static AppLovinExceptionHandler shared() {
    return a;
  }
  
  public void addSdk(p paramp) {
    this.b.add(paramp);
  }
  
  public void enable() {
    if (this.c.compareAndSet(false, true)) {
      this.d = Thread.getDefaultUncaughtExceptionHandler();
      Thread.setDefaultUncaughtExceptionHandler(this);
    } 
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    Iterator<p> iterator = this.b.iterator();
    long l = 1000L;
    while (iterator.hasNext()) {
      p p = iterator.next();
      if (!p.e()) {
        p.L();
        if (y.a())
          p.L().b("AppLovinExceptionHandler", "Detected unhandled exception"); 
        p.aj().a(t.a.b, CollectionUtils.map("top_main_method", paramThrowable.toString()));
        p.G().trackEventSynchronously("paused");
        l = ((Long)p.a(b.dz)).longValue();
      } 
    } 
    try {
      Thread.sleep(l);
    } catch (InterruptedException interruptedException) {}
    Thread.UncaughtExceptionHandler uncaughtExceptionHandler = this.d;
    if (uncaughtExceptionHandler != null) {
      uncaughtExceptionHandler.uncaughtException(paramThread, paramThrowable);
      return;
    } 
    Process.killProcess(Process.myPid());
    System.exit(1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\AppLovinExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */