package com.applovin.impl.sdk;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.hardware.SensorManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.LocaleList;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.c.d;
import com.applovin.impl.sdk.c.e;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.f;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.d;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.i;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.android.gms.appset.AppSetIdInfo;
import com.google.android.gms.tasks.OnSuccessListener;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicReference;

public class s {
  private static final AtomicReference<d.a> E = new AtomicReference<d.a>();
  
  private static final AtomicReference<b> F = new AtomicReference<b>();
  
  private static final AtomicReference<Integer> G = new AtomicReference<Integer>();
  
  private final int A;
  
  private final int B;
  
  private final p C;
  
  private final Context D;
  
  private final i a;
  
  private final j b;
  
  private final c c;
  
  private final d d;
  
  private final f e;
  
  private final h f;
  
  private final String g;
  
  private final String h;
  
  private final double i;
  
  private final boolean j;
  
  @Nullable
  private String k;
  
  private long l;
  
  private final a m;
  
  private final g n;
  
  private boolean o;
  
  @Nullable
  private e p;
  
  @Nullable
  private e q;
  
  @Nullable
  private e r;
  
  @Nullable
  private e s;
  
  @Nullable
  private e t;
  
  @Nullable
  private e u;
  
  @Nullable
  private e v;
  
  private final int w;
  
  private final int x;
  
  private final int y;
  
  private final int z;
  
  protected s(p paramp) {
    boolean bool;
    String str;
    this.C = paramp;
    Context context = p.y();
    this.D = context;
    this.w = ((Integer)paramp.a(b.er)).intValue();
    this.x = ((Integer)paramp.a(b.es)).intValue();
    this.y = ((Integer)paramp.a(b.et)).intValue();
    this.z = ((Integer)paramp.a(b.eu)).intValue();
    this.A = ((Integer)paramp.a(b.ev)).intValue();
    this.B = ((Integer)paramp.a(b.ew)).intValue();
    this.a = new i();
    this.b = new j();
    this.c = new c();
    this.d = new d();
    this.e = new f();
    this.f = new h();
    if (AppLovinSdkUtils.isFireOS(context)) {
      str = "fireos";
    } else {
      str = "android";
    } 
    this.g = str;
    int k = AppLovinSdkUtils.getOrientation(context);
    if (k == 1) {
      this.h = "portrait";
    } else if (k == 2) {
      this.h = "landscape";
    } else {
      this.h = "none";
    } 
    this.i = Math.round(TimeZone.getDefault().getOffset((new Date()).getTime()) * 10.0D / 3600000.0D) / 10.0D;
    SensorManager sensorManager = (SensorManager)context.getSystemService("sensor");
    k = 0;
    if (sensorManager != null && sensorManager.getDefaultSensor(4) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.j = bool;
    if (h.f()) {
      LocaleList localeList = context.getResources().getConfiguration().getLocales();
      StringBuilder stringBuilder = new StringBuilder();
      while (k < localeList.size()) {
        stringBuilder.append(localeList.get(k));
        stringBuilder.append(",");
        k++;
      } 
      if (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == ',')
        stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
      this.k = stringBuilder.toString();
    } 
    try {
      this.l = Environment.getDataDirectory().getTotalSpace();
    } finally {
      sensorManager = null;
      paramp.L();
    } 
  }
  
  private boolean H() {
    String str = Build.TAGS;
    return (str != null && str.contains(a("lz}$blpz")));
  }
  
  private boolean I() {
    for (int k = 0; k < 9; k++) {
      (new String[9])[0] = "&zpz}ld&hyy&Z|yl{|zl{'hyb";
      (new String[9])[1] = "&zk`g&z|";
      (new String[9])[2] = "&zpz}ld&k`g&z|";
      (new String[9])[3] = "&zpz}ld&qk`g&z|";
      (new String[9])[4] = "&mh}h&efjhe&qk`g&z|";
      (new String[9])[5] = "&mh}h&efjhe&k`g&z|";
      (new String[9])[6] = "&zpz}ld&zm&qk`g&z|";
      (new String[9])[7] = "&zpz}ld&k`g&oh`ezhol&z|";
      (new String[9])[8] = "&mh}h&efjhe&z|";
      if ((new File(a((new String[9])[k]))).exists())
        return true; 
    } 
    return false;
  }
  
  private String a(String paramString) {
    int m = paramString.length();
    char[] arrayOfChar = new char[m];
    for (int k = 0; k < m; k++) {
      arrayOfChar[k] = paramString.charAt(k);
      for (int n = 9; n >= 0; n--) {
        (new int[10])[0] = 11;
        (new int[10])[1] = 12;
        (new int[10])[2] = 10;
        (new int[10])[3] = 3;
        (new int[10])[4] = 2;
        (new int[10])[5] = 1;
        (new int[10])[6] = 15;
        (new int[10])[7] = 10;
        (new int[10])[8] = 15;
        (new int[10])[9] = 14;
        arrayOfChar[k] = (char)(arrayOfChar[k] ^ (new int[10])[n]);
      } 
    } 
    return new String(arrayOfChar);
  }
  
  public static void a(Context paramContext) {
    (new Thread(new Runnable(paramContext) {
          public void run() {
            s.E().set(d.a(this.a));
            if (!Utils.checkClassExistence("com.google.android.gms.appset.AppSet"))
              return; 
            try {
              return;
            } finally {
              Exception exception = null;
              y.f("DataProvider", "Could not collect AppSet ID.");
            } 
          }
        })).start();
  }
  
  private boolean b(String paramString) {
    boolean bool = false;
    try {
      int k = Settings.Secure.getInt(this.D.getContentResolver(), paramString);
      return bool;
    } finally {
      paramString = null;
    } 
  }
  
  public long A() {
    return this.l;
  }
  
  public a B() {
    return this.m;
  }
  
  public g C() {
    return this.n;
  }
  
  public boolean D() {
    return this.o;
  }
  
  @Nullable
  public b a() {
    return F.get();
  }
  
  @Nullable
  protected d.a b() {
    return E.get();
  }
  
  @Nullable
  protected Integer c() {
    return G.get();
  }
  
  public d.a d() {
    d.a a1 = d.a(this.D);
    if (a1 == null)
      return new d.a(); 
    if (((Boolean)this.C.a(b.dH)).booleanValue()) {
      if (a1.a() && !((Boolean)this.C.a(b.dG)).booleanValue())
        a1.a(""); 
      E.set(a1);
    } else {
      a1 = new d.a();
    } 
    boolean bool = StringUtils.isValidString(a1.b());
    boolean bool1 = false;
    if (bool) {
      List list = this.C.C().getTestDeviceAdvertisingIds();
      bool = bool1;
      if (list != null) {
        bool = bool1;
        if (list.contains(a1.b()))
          bool = true; 
      } 
      this.o = bool;
      return a1;
    } 
    this.o = false;
    return a1;
  }
  
  protected void e() {
    this.C.M().a((a)new f(this.C, new f.a(this) {
            public void a(d.a param1a) {
              s.E().set(param1a);
            }
          }), o.a.d);
    this.C.M().a((a)new z(this.C, true, new Runnable(this) {
            public void run() {
              s.G().set(s.a(this.a).b());
            }
          }), o.a.i);
  }
  
  protected String f() {
    e e1 = this.u;
    if (e1 != null && !e.a(e1))
      return (String)e.b(this.u); 
    e1 = new e(i.f(this.C), this.B);
    this.u = e1;
    return (String)e.b(e1);
  }
  
  @Nullable
  protected Long g() {
    e e1 = this.q;
    if (e1 != null && !e.a(e1))
      return Long.valueOf(((Long)e.b(this.q)).longValue()); 
    try {
      return Long.valueOf(l);
    } finally {
      e1 = null;
      this.C.L();
      if (y.a())
        this.C.L().b("DataProvider", "Unable to collect free space.", (Throwable)e1); 
    } 
  }
  
  @Nullable
  protected Float h() {
    e e1 = this.s;
    if (e1 != null && !e.a(e1))
      return Float.valueOf(((Float)e.b(this.s)).floatValue()); 
    if (this.C.ac() == null)
      return null; 
    e1 = new e(Float.valueOf(this.C.ac().c()), this.w);
    this.s = e1;
    return Float.valueOf(((Float)e.b(e1)).floatValue());
  }
  
  @Nullable
  protected Float i() {
    e e1 = this.t;
    if (e1 != null && !e.a(e1))
      return Float.valueOf(((Float)e.b(this.t)).floatValue()); 
    if (this.C.ac() == null)
      return null; 
    e1 = new e(Float.valueOf(this.C.ac().b()), this.w);
    this.t = e1;
    return Float.valueOf(((Float)e.b(e1)).floatValue());
  }
  
  @Nullable
  protected Integer j() {
    e e1 = this.v;
    if (e1 != null && !e.a(e1))
      return Integer.valueOf(((Integer)e.b(this.v)).intValue()); 
    try {
      e1 = new e(Integer.valueOf((int)(Settings.System.getInt(this.D.getContentResolver(), "screen_brightness") / 255.0F * 100.0F)), this.x);
      this.v = e1;
      int k = ((Integer)e.b(e1)).intValue();
      return Integer.valueOf(k);
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      this.C.L();
      if (y.a())
        this.C.L().b("DataProvider", "Unable to collect screen brightness", (Throwable)settingNotFoundException); 
      return null;
    } 
  }
  
  protected long k() {
    List<String> list = Arrays.asList(StringUtils.emptyIfNull(Settings.Secure.getString(this.D.getContentResolver(), "enabled_accessibility_services")).split(":"));
    if (list.contains("AccessibilityMenuService")) {
      l2 = 256L;
    } else {
      l2 = 0L;
    } 
    long l1 = l2;
    if (list.contains("SelectToSpeakService"))
      l1 = l2 | 0x200L; 
    long l2 = l1;
    if (list.contains("SoundAmplifierService"))
      l2 = l1 | 0x2L; 
    l1 = l2;
    if (list.contains("SpeechToTextAccessibilityService"))
      l1 = l2 | 0x80L; 
    l2 = l1;
    if (list.contains("SwitchAccessService"))
      l2 = l1 | 0x4L; 
    l1 = l2;
    if (((this.D.getResources().getConfiguration()).uiMode & 0x30) == 32)
      l1 = l2 | 0x400L; 
    l2 = l1;
    if (b("accessibility_enabled"))
      l2 = l1 | 0x8L; 
    l1 = l2;
    if (b("touch_exploration_enabled"))
      l1 = l2 | 0x10L; 
    l2 = l1;
    if (h.d()) {
      long l = l1;
      if (b("accessibility_display_inversion_enabled"))
        l = l1 | 0x20L; 
      l2 = l;
      if (b("skip_first_use_hints"))
        l2 = l | 0x40L; 
    } 
    l1 = l2;
    if (b("lock_screen_allow_remote_input"))
      l1 = l2 | 0x800L; 
    l2 = l1;
    if (b("enabled_accessibility_audio_description_by_default"))
      l2 = l1 | 0x1000L; 
    l1 = l2;
    if (b("accessibility_shortcut_on_lock_screen"))
      l1 = l2 | 0x2000L; 
    l2 = l1;
    if (b("wear_talkback_enabled"))
      l2 = l1 | 0x4000L; 
    l1 = l2;
    if (b("hush_gesture_used"))
      l1 = l2 | 0x8000L; 
    l2 = l1;
    if (b("high_text_contrast_enabled"))
      l2 = l1 | 0x10000L; 
    l1 = l2;
    if (b("accessibility_display_magnification_enabled"))
      l1 = l2 | 0x20000L; 
    l2 = l1;
    if (b("accessibility_display_magnification_navbar_enabled"))
      l2 = l1 | 0x40000L; 
    l1 = l2;
    if (b("accessibility_captioning_enabled"))
      l1 = l2 | 0x80000L; 
    l2 = l1;
    if (b("accessibility_display_daltonizer_enabled"))
      l2 = l1 | 0x100000L; 
    l1 = l2;
    if (b("accessibility_autoclick_enabled"))
      l1 = l2 | 0x200000L; 
    l2 = l1;
    if (b("accessibility_large_pointer_icon"))
      l2 = l1 | 0x400000L; 
    l1 = l2;
    if (b("reduce_bright_colors_activated"))
      l1 = l2 | 0x800000L; 
    l2 = l1;
    if (b("reduce_bright_colors_persist_across_reboots"))
      l2 = l1 | 0x1000000L; 
    l1 = l2;
    if (b("tty_mode_enabled"))
      l1 = l2 | 0x2000000L; 
    l2 = l1;
    if (b("rtt_calling_mode"))
      l2 = l1 | 0x4000000L; 
    return l2;
  }
  
  protected float l() {
    try {
      return Settings.System.getFloat(this.D.getContentResolver(), "font_scale");
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      this.C.L();
      if (y.a())
        this.C.L().b("DataProvider", "Error collecting font scale", (Throwable)settingNotFoundException); 
      return -1.0F;
    } 
  }
  
  protected boolean m() {
    e e1 = this.r;
    if (e1 != null && !e.a(e1))
      return ((Boolean)e.b(this.r)).booleanValue(); 
    e1 = new e(Boolean.valueOf(Utils.isVPNConnected()), this.z);
    this.r = e1;
    return ((Boolean)e.b(e1)).booleanValue();
  }
  
  protected boolean n() {
    boolean bool1 = h.f();
    boolean bool = false;
    if (!bool1)
      return false; 
    ConnectivityManager connectivityManager = (ConnectivityManager)this.D.getSystemService("connectivity");
    if (connectivityManager == null)
      return false; 
    try {
      return bool;
    } finally {
      connectivityManager = null;
      this.C.L();
      if (y.a())
        this.C.L().b("DataProvider", "Unable to collect constrained network info.", (Throwable)connectivityManager); 
    } 
  }
  
  protected boolean o() {
    boolean bool = false;
    try {
      return true;
    } finally {
      Exception exception = null;
    } 
  }
  
  public i p() {
    return this.a;
  }
  
  public j q() {
    return this.b;
  }
  
  public c r() {
    return this.c;
  }
  
  public d s() {
    return this.d;
  }
  
  public f t() {
    return this.e;
  }
  
  public h u() {
    return this.f;
  }
  
  public String v() {
    return this.g;
  }
  
  public String w() {
    return this.h;
  }
  
  public double x() {
    return this.i;
  }
  
  public boolean y() {
    return this.j;
  }
  
  @Nullable
  public String z() {
    return this.k;
  }
  
  public class a {
    private final String b;
    
    private final String c;
    
    private final String d;
    
    private final String e;
    
    private final String f;
    
    private final Long g;
    
    private final long h;
    
    private final int i;
    
    private final int j;
    
    private a(s this$0) {
      try {
        PackageManager packageManager = s.b(s.this).getPackageManager();
        ApplicationInfo applicationInfo = s.b(s.this).getApplicationInfo();
        File file = new File(applicationInfo.sourceDir);
        PackageInfo packageInfo = packageManager.getPackageInfo(s.b(s.this).getPackageName(), 0);
        this.b = packageManager.getApplicationLabel(applicationInfo).toString();
        this.c = packageInfo.versionName;
        this.i = packageInfo.versionCode;
        String str = applicationInfo.packageName;
        this.d = str;
        this.e = StringUtils.toShortSHA1Hash(str);
        this.h = file.lastModified();
        this.g = Long.valueOf(packageInfo.firstInstallTime);
        this.j = applicationInfo.targetSdkVersion;
        this.f = packageManager.getInstallerPackageName(str);
        return;
      } finally {}
    }
    
    @Nullable
    protected Long a() {
      p p = s.e(this.a);
      d d = d.g;
      Long long_ = (Long)p.a(d);
      if (long_ != null)
        return long_; 
      s.e(this.a).a(d, Long.valueOf(this.h));
      return null;
    }
    
    public String b() {
      return this.b;
    }
    
    public String c() {
      return this.c;
    }
    
    public String d() {
      return this.d;
    }
    
    public String e() {
      return this.e;
    }
    
    public String f() {
      return this.f;
    }
    
    public Long g() {
      return this.g;
    }
    
    public long h() {
      return this.h;
    }
    
    public int i() {
      return this.i;
    }
    
    public int j() {
      return this.j;
    }
  }
  
  public static class b {
    @Nullable
    private final String a;
    
    private final int b;
    
    public b(@Nullable String param1String, int param1Int) {
      this.a = param1String;
      this.b = param1Int;
    }
    
    @Nullable
    public String a() {
      return this.a;
    }
    
    public int b() {
      return this.b;
    }
  }
  
  protected class c {
    @Nullable
    private s.e b;
    
    @Nullable
    private s.e c;
    
    @Nullable
    private s.e d;
    
    @Nullable
    private final AudioManager e = (AudioManager)s.b(s.this).getSystemService("audio");
    
    private c(s this$0) {}
    
    protected int a() {
      s.e e2 = this.d;
      if (e2 != null && !s.e.a(e2))
        return ((Integer)s.e.b(this.d)).intValue(); 
      s s1 = this.a;
      s.e e1 = new s.e(Integer.valueOf(s.e(s1).ad().a()), s.d(this.a));
      this.d = e1;
      return ((Integer)s.e.b(e1)).intValue();
    }
    
    @Nullable
    protected Integer b() {
      s.e e1 = this.b;
      if (e1 != null && !s.e.a(e1))
        return Integer.valueOf(((Integer)s.e.b(this.b)).intValue()); 
      if (this.e == null)
        return null; 
      Float float_ = (Float)s.e(this.a).a(b.eg);
      try {
        int i = (int)(this.e.getStreamVolume(3) * float_.floatValue());
        return Integer.valueOf(i);
      } finally {
        float_ = null;
        s.e(this.a).L();
        if (y.a())
          s.e(this.a).L().b("DataProvider", "Unable to collect device volume", (Throwable)float_); 
      } 
    }
    
    @Nullable
    protected String c() {
      s.e e2 = this.c;
      if (e2 != null && !s.e.a(e2))
        return (String)s.e.b(this.c); 
      if (this.e == null)
        return null; 
      StringBuilder stringBuilder = new StringBuilder();
      if (h.e()) {
        AudioDeviceInfo[] arrayOfAudioDeviceInfo = this.e.getDevices(2);
        int j = arrayOfAudioDeviceInfo.length;
        for (int i = 0; i < j; i++) {
          stringBuilder.append(arrayOfAudioDeviceInfo[i].getType());
          stringBuilder.append(",");
        } 
      } else {
        if (this.e.isWiredHeadsetOn()) {
          stringBuilder.append(3);
          stringBuilder.append(",");
        } 
        if (this.e.isBluetoothScoOn()) {
          stringBuilder.append(7);
          stringBuilder.append(",");
        } 
        if (this.e.isBluetoothA2dpOn())
          stringBuilder.append(8); 
      } 
      if (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == ',')
        stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
      String str = stringBuilder.toString();
      if (TextUtils.isEmpty(str)) {
        s.e(this.a).L();
        if (y.a())
          s.e(this.a).L().b("DataProvider", "No sound outputs detected"); 
      } 
      s s1 = this.a;
      s.e e1 = new s.e(str, s.h(s1));
      this.c = e1;
      return (String)s.e.b(e1);
    }
  }
  
  protected class d {
    @Nullable
    private s.e b;
    
    @Nullable
    private s.e c;
    
    @Nullable
    private final Intent d;
    
    @Nullable
    private BatteryManager e;
    
    private d(s this$0) {
      IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
      this.d = s.b(s.this).registerReceiver(null, intentFilter);
      if (h.d())
        this.e = (BatteryManager)s.b(s.this).getSystemService("batterymanager"); 
    }
    
    @Nullable
    protected Integer a() {
      s.e e1 = this.b;
      if (e1 != null && !s.e.a(e1))
        return Integer.valueOf(((Integer)s.e.b(this.b)).intValue()); 
      if (h.d()) {
        BatteryManager batteryManager = this.e;
        if (batteryManager != null) {
          int k = batteryManager.getIntProperty(4);
          s.e e2 = new s.e(Integer.valueOf(k), s.d(this.a));
          this.b = e2;
          return Integer.valueOf(((Integer)s.e.b(e2)).intValue());
        } 
      } 
      Intent intent = this.d;
      if (intent == null)
        return null; 
      int i = intent.getIntExtra("level", -1);
      int j = this.d.getIntExtra("scale", -1);
      if (i >= 0) {
        if (j < 0)
          return null; 
        i = (int)(i / j * 100.0F);
        s.e e2 = new s.e(Integer.valueOf(i), s.d(this.a));
        this.b = e2;
        return Integer.valueOf(((Integer)s.e.b(e2)).intValue());
      } 
      return null;
    }
    
    @Nullable
    protected Integer b() {
      s.e e2 = this.c;
      if (e2 != null && !s.e.a(e2))
        return Integer.valueOf(((Integer)s.e.b(this.c)).intValue()); 
      if (h.g()) {
        BatteryManager batteryManager = this.e;
        if (batteryManager != null) {
          int k = batteryManager.getIntProperty(6);
          s.e e3 = new s.e(Integer.valueOf(k), s.d(this.a));
          this.c = e3;
          return Integer.valueOf(((Integer)s.e.b(e3)).intValue());
        } 
      } 
      Intent intent = this.d;
      if (intent == null)
        return null; 
      int j = intent.getIntExtra("status", -1);
      int i = j;
      if (j < 0)
        return null; 
      s.e e1 = new s.e(Integer.valueOf(i), s.d(this.a));
      this.c = e1;
      return Integer.valueOf(((Integer)s.e.b(e1)).intValue());
    }
  }
  
  private class e {
    private final Object b;
    
    private final long c;
    
    private e(s this$0, Object param1Object, long param1Long) {
      this.b = param1Object;
      this.c = b() + param1Long;
    }
    
    private boolean a() {
      return !((Boolean)s.e(this.a).a(b.dF)).booleanValue() ? true : ((this.c - b() <= 0L));
    }
    
    private long b() {
      return System.currentTimeMillis() / 1000L;
    }
  }
  
  protected class f {
    private int b;
    
    private int c;
    
    private int d;
    
    private float e;
    
    private float f;
    
    private float g;
    
    private double h;
    
    private f(s this$0) {
      DisplayMetrics displayMetrics = s.b(s.this).getResources().getDisplayMetrics();
      if (displayMetrics == null)
        return; 
      this.g = displayMetrics.density;
      this.e = displayMetrics.xdpi;
      this.f = displayMetrics.ydpi;
      this.d = displayMetrics.densityDpi;
      Point point = h.a(s.b(s.this));
      int i = point.x;
      this.b = i;
      this.c = point.y;
      this.h = Math.sqrt(Math.pow(i, 2.0D) + Math.pow(this.c, 2.0D)) / this.e;
    }
    
    public int a() {
      return this.b;
    }
    
    public int b() {
      return this.c;
    }
    
    public int c() {
      return this.d;
    }
    
    public float d() {
      return this.e;
    }
    
    public float e() {
      return this.f;
    }
    
    public float f() {
      return this.g;
    }
    
    public double g() {
      return this.h;
    }
  }
  
  public class g {
    private final SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(s.b(s.this));
    
    private g(s this$0) {}
    
    @Nullable
    public String a() {
      return (String)s.e(this.a).b(d.q, null, this.b);
    }
    
    @Nullable
    protected Object b() {
      String str2 = d.r.a();
      if (!this.b.contains(str2))
        return null; 
      String str1 = (String)e.a(str2, "", String.class, this.b);
      Integer integer = (Integer)e.a(str2, Integer.valueOf(2147483647), Integer.class, this.b);
      Long long_ = (Long)e.a(str2, Long.valueOf(Long.MAX_VALUE), Long.class, this.b);
      Boolean bool = (Boolean)e.a(str2, Boolean.FALSE, Boolean.class, this.b);
      return StringUtils.isValidString(str1) ? str1 : ((integer != null && integer.intValue() != Integer.MAX_VALUE) ? integer : ((long_ != null && long_.longValue() != Long.MAX_VALUE) ? long_ : bool));
    }
  }
  
  protected class h {
    private long b;
    
    @Nullable
    private s.e c;
    
    @Nullable
    private s.e d;
    
    @Nullable
    private s.e e;
    
    @Nullable
    private final ActivityManager f;
    
    private h(s this$0) {
      ActivityManager activityManager = (ActivityManager)s.b(s.this).getSystemService("activity");
      this.f = activityManager;
      if (activityManager == null)
        return; 
      ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
      try {
        return;
      } finally {
        activityManager = null;
        s.e(s.this).L();
        if (y.a())
          s.e(s.this).L().b("DataProvider", "Unable to collect memory info.", (Throwable)activityManager); 
      } 
    }
    
    @Nullable
    protected Long a() {
      s.e e1 = this.c;
      if (e1 != null && !s.e.a(e1))
        return Long.valueOf(((Long)s.e.b(this.c)).longValue()); 
      if (this.f == null)
        return null; 
      ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
      try {
        this.f.getMemoryInfo(memoryInfo);
        return Long.valueOf(l);
      } finally {
        memoryInfo = null;
        s.e(this.a).L();
        if (y.a())
          s.e(this.a).L().b("DataProvider", "Unable to collect available memory.", (Throwable)memoryInfo); 
      } 
    }
    
    @Nullable
    protected Long b() {
      s.e e1 = this.d;
      if (e1 != null && !s.e.a(e1))
        return Long.valueOf(((Long)s.e.b(this.d)).longValue()); 
      if (this.f == null)
        return null; 
      ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
      try {
        this.f.getMemoryInfo(memoryInfo);
        return Long.valueOf(l);
      } finally {
        memoryInfo = null;
        s.e(this.a).L();
        if (y.a())
          s.e(this.a).L().b("DataProvider", "Unable to collect low memory threshold.", (Throwable)memoryInfo); 
      } 
    }
    
    @Nullable
    protected Boolean c() {
      s.e e1 = this.e;
      if (e1 != null && !s.e.a(e1))
        return Boolean.valueOf(((Boolean)s.e.b(this.e)).booleanValue()); 
      if (this.f == null)
        return null; 
      ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
      try {
        this.f.getMemoryInfo(memoryInfo);
        return Boolean.valueOf(bool);
      } finally {
        memoryInfo = null;
        s.e(this.a).L();
        if (y.a())
          s.e(this.a).L().b("DataProvider", "Unable to collect has low memory.", (Throwable)memoryInfo); 
      } 
    }
    
    public long d() {
      return this.b;
    }
  }
  
  protected class i {
    @Nullable
    private final PowerManager b = (PowerManager)s.b(s.this).getSystemService("power");
    
    private i(s this$0) {}
    
    @Nullable
    protected Integer a() {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  protected class j {
    @Nullable
    private final TelephonyManager b;
    
    @Nullable
    private String c;
    
    @Nullable
    private String d;
    
    @Nullable
    private String e;
    
    @Nullable
    private String f;
    
    @Nullable
    private String g;
    
    @Nullable
    private s.e h;
    
    private j(s this$0) {
      String str;
      int i;
      TelephonyManager telephonyManager = (TelephonyManager)s.b(s.this).getSystemService("phone");
      this.b = telephonyManager;
      if (telephonyManager == null)
        return; 
      this.d = telephonyManager.getSimCountryIso().toUpperCase(Locale.ENGLISH);
      try {
        this.e = telephonyManager.getNetworkOperatorName();
      } finally {
        telephonyManager = null;
        s.e(s.this).L();
      } 
      this.f = this.c.substring(0, i);
      this.g = this.c.substring(i);
    }
    
    @Nullable
    protected Integer a() {
      s.e e1 = this.h;
      if (e1 != null && !s.e.a(e1))
        return Integer.valueOf(((Integer)s.e.b(this.h)).intValue()); 
      if (h.a("android.permission.READ_PHONE_STATE", s.b(this.a)) && this.b != null && h.f()) {
        int i = this.b.getDataNetworkType();
        e1 = new s.e(Integer.valueOf(i), s.f(this.a));
        this.h = e1;
        return Integer.valueOf(((Integer)s.e.b(e1)).intValue());
      } 
      return null;
    }
    
    @Nullable
    public String b() {
      return this.d;
    }
    
    @Nullable
    public String c() {
      return this.e;
    }
    
    @Nullable
    public String d() {
      return this.f;
    }
    
    @Nullable
    public String e() {
      return this.g;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */