package com.applovin.impl.sdk.b;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.p;
import com.applovin.sdk.AppLovinSdkUtils;

public class b {
  private final p a;
  
  private final Activity b;
  
  private AlertDialog c;
  
  private a d;
  
  public b(Activity paramActivity, p paramp) {
    this.a = paramp;
    this.b = paramActivity;
  }
  
  public void a() {
    this.b.runOnUiThread(new Runnable(this) {
          public void run() {
            if (b.a(this.a) != null)
              b.a(this.a).dismiss(); 
          }
        });
  }
  
  public void a(e parame, @Nullable Runnable paramRunnable) {
    this.b.runOnUiThread(new Runnable(this, parame, paramRunnable) {
          public void run() {
            AlertDialog.Builder builder = new AlertDialog.Builder((Context)b.d(this.c));
            builder.setTitle(this.a.an());
            String str = this.a.ao();
            if (AppLovinSdkUtils.isValidString(str))
              builder.setMessage(str); 
            builder.setPositiveButton(this.a.ap(), new DialogInterface.OnClickListener(this) {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                    Runnable runnable = this.a.b;
                    if (runnable != null)
                      runnable.run(); 
                  }
                });
            builder.setCancelable(false);
            b.a(this.c, builder.show());
          }
        });
  }
  
  public void a(a parama) {
    this.d = parama;
  }
  
  public void b() {
    this.b.runOnUiThread(new Runnable(this) {
          public void run() {
            b.a(this.a, (new AlertDialog.Builder((Context)b.d(this.a))).setTitle((CharSequence)b.b(this.a).a(com.applovin.impl.sdk.c.b.bK)).setMessage((CharSequence)b.b(this.a).a(com.applovin.impl.sdk.c.b.bL)).setCancelable(false).setPositiveButton((CharSequence)b.b(this.a).a(com.applovin.impl.sdk.c.b.bN), new DialogInterface.OnClickListener(this) {
                    public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                      b.c(this.a.a).a();
                    }
                  }).setNegativeButton((CharSequence)b.b(this.a).a(com.applovin.impl.sdk.c.b.bM), new DialogInterface.OnClickListener(this) {
                    public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                      b.c(this.a.a).b();
                    }
                  }).show());
          }
        });
  }
  
  public boolean c() {
    AlertDialog alertDialog = this.c;
    return (alertDialog != null) ? alertDialog.isShowing() : false;
  }
  
  public static interface a {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\sdk\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */