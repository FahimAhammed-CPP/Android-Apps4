package com.applovin.impl.adview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.annotation.Nullable;

@SuppressLint({"ViewConstructor"})
public class u extends View {
  private final o a;
  
  private boolean b;
  
  public u(o paramo, Context paramContext) {
    super(paramContext);
    this.a = paramo;
    setClickable(false);
    setFocusable(false);
  }
  
  public void a() {
    a(null);
  }
  
  public void a(@Nullable a parama) {
    if (this.b) {
      if (parama != null)
        parama.a(); 
      return;
    } 
    Drawable drawable = this.a.a();
    if (drawable == null) {
      if (parama != null)
        parama.b(); 
      return;
    } 
    setBackground(drawable);
    this.b = true;
    if (parama != null)
      parama.a(); 
  }
  
  public boolean b() {
    return this.b;
  }
  
  public String getIdentifier() {
    return this.a.b();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  static interface a {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\impl\advie\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */