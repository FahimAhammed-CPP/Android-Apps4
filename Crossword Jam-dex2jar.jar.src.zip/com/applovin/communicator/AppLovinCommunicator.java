package com.applovin.communicator;

import android.content.Context;
import com.applovin.impl.communicator.MessagingServiceImpl;
import com.applovin.impl.communicator.a;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;
import java.util.Collections;
import java.util.List;

public final class AppLovinCommunicator {
  private static AppLovinCommunicator a;
  
  private static final Object b = new Object();
  
  private p c;
  
  private y d;
  
  private final a e;
  
  private final MessagingServiceImpl f;
  
  private AppLovinCommunicator(Context paramContext) {
    this.e = new a(paramContext);
    this.f = new MessagingServiceImpl(paramContext);
  }
  
  private void a(String paramString) {
    if (this.d != null && y.a())
      this.d.b("AppLovinCommunicator", paramString); 
  }
  
  public static AppLovinCommunicator getInstance(Context paramContext) {
    synchronized (b) {
      if (a == null)
        a = new AppLovinCommunicator(paramContext.getApplicationContext()); 
      return a;
    } 
  }
  
  public void a(p paramp) {
    this.c = paramp;
    this.d = paramp.L();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Attached SDK instance: ");
    stringBuilder.append(paramp);
    stringBuilder.append("...");
    a(stringBuilder.toString());
  }
  
  public AppLovinCommunicatorMessagingService getMessagingService() {
    return (AppLovinCommunicatorMessagingService)this.f;
  }
  
  public boolean hasSubscriber(String paramString) {
    return this.e.a(paramString);
  }
  
  public boolean respondsToTopic(String paramString) {
    return this.c.ab().c(paramString);
  }
  
  public void subscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, String paramString) {
    subscribe(paramAppLovinCommunicatorSubscriber, Collections.singletonList(paramString));
  }
  
  public void subscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, List<String> paramList) {
    for (String str : paramList) {
      if (!this.e.a(paramAppLovinCommunicatorSubscriber, str)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to subscribe ");
        stringBuilder.append(paramAppLovinCommunicatorSubscriber);
        stringBuilder.append(" to topic: ");
        stringBuilder.append(str);
        a(stringBuilder.toString());
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinCommunicator{sdk=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void unsubscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, String paramString) {
    unsubscribe(paramAppLovinCommunicatorSubscriber, Collections.singletonList(paramString));
  }
  
  public void unsubscribe(AppLovinCommunicatorSubscriber paramAppLovinCommunicatorSubscriber, List<String> paramList) {
    for (String str : paramList) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unsubscribing ");
      stringBuilder.append(paramAppLovinCommunicatorSubscriber);
      stringBuilder.append(" from topic: ");
      stringBuilder.append(str);
      a(stringBuilder.toString());
      this.e.b(paramAppLovinCommunicatorSubscriber, str);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\communicator\AppLovinCommunicator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */