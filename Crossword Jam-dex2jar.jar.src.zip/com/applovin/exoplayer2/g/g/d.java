package com.applovin.exoplayer2.g.g;

import android.os.Parcel;
import android.os.Parcelable;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class d extends b {
  public static final Parcelable.Creator<d> CREATOR = new Parcelable.Creator<d>() {
      public d a(Parcel param1Parcel) {
        return new d(param1Parcel);
      }
      
      public d[] a(int param1Int) {
        return new d[param1Int];
      }
    };
  
  public final long a;
  
  public final boolean b;
  
  public final boolean c;
  
  public final boolean d;
  
  public final boolean e;
  
  public final long f;
  
  public final long g;
  
  public final List<a> h;
  
  public final boolean i;
  
  public final long j;
  
  public final int k;
  
  public final int l;
  
  public final int m;
  
  private d(long paramLong1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong2, long paramLong3, List<a> paramList, boolean paramBoolean5, long paramLong4, int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramLong1;
    this.b = paramBoolean1;
    this.c = paramBoolean2;
    this.d = paramBoolean3;
    this.e = paramBoolean4;
    this.f = paramLong2;
    this.g = paramLong3;
    this.h = Collections.unmodifiableList(paramList);
    this.i = paramBoolean5;
    this.j = paramLong4;
    this.k = paramInt1;
    this.l = paramInt2;
    this.m = paramInt3;
  }
  
  private d(Parcel paramParcel) {
    this.a = paramParcel.readLong();
    byte b1 = paramParcel.readByte();
    boolean bool2 = false;
    if (b1 == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.b = bool1;
    if (paramParcel.readByte() == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.c = bool1;
    if (paramParcel.readByte() == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.d = bool1;
    if (paramParcel.readByte() == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.e = bool1;
    this.f = paramParcel.readLong();
    this.g = paramParcel.readLong();
    int i = paramParcel.readInt();
    ArrayList<a> arrayList = new ArrayList(i);
    b1 = 0;
    while (b1 < i) {
      arrayList.add(a.b(paramParcel));
      int j = b1 + 1;
    } 
    this.h = Collections.unmodifiableList(arrayList);
    boolean bool1 = bool2;
    if (paramParcel.readByte() == 1)
      bool1 = true; 
    this.i = bool1;
    this.j = paramParcel.readLong();
    this.k = paramParcel.readInt();
    this.l = paramParcel.readInt();
    this.m = paramParcel.readInt();
  }
  
  static d a(y paramy, long paramLong, ag paramag) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    long l1;
    boolean bool4;
    boolean bool5;
    boolean bool6;
    boolean bool7;
    boolean bool8;
    long l2 = paramy.o();
    if ((paramy.h() & 0x80) != 0) {
      bool8 = true;
    } else {
      bool8 = false;
    } 
    List<?> list = Collections.emptyList();
    if (!bool8) {
      bool2 = paramy.h();
      if ((bool2 & 0x80) != 0) {
        bool4 = true;
      } else {
        bool4 = false;
      } 
      if ((bool2 & 0x40) != 0) {
        bool5 = true;
      } else {
        bool5 = false;
      } 
      if ((bool2 & 0x20) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool2 & 0x10) != 0) {
        bool6 = true;
      } else {
        bool6 = false;
      } 
      if (bool5 && !bool6) {
        l1 = g.a(paramy, paramLong);
      } else {
        l1 = -9223372036854775807L;
      } 
      if (!bool5) {
        int i = paramy.h();
        list = new ArrayList(i);
        for (bool2 = false; bool2 < i; bool2++) {
          long l;
          int j = paramy.h();
          if (!bool6) {
            l = g.a(paramy, paramLong);
          } else {
            l = -9223372036854775807L;
          } 
          list.add(new a(j, l, paramag.b(l)));
        } 
      } 
      if (bool1) {
        paramLong = paramy.h();
        if ((0x80L & paramLong) != 0L) {
          bool7 = true;
        } else {
          bool7 = false;
        } 
        paramLong = ((paramLong & 0x1L) << 32L | paramy.o()) * 1000L / 90L;
      } else {
        bool7 = false;
        paramLong = -9223372036854775807L;
      } 
      bool1 = paramy.i();
      bool2 = paramy.h();
      bool3 = paramy.h();
    } else {
      bool4 = false;
      bool6 = false;
      l1 = -9223372036854775807L;
      bool7 = false;
      paramLong = -9223372036854775807L;
      bool1 = false;
      bool2 = false;
      bool3 = false;
      bool5 = false;
    } 
    return new d(l2, bool8, bool4, bool5, bool6, l1, paramag.b(l1), (List)list, bool7, paramLong, bool1, bool2, bool3);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeLong(this.a);
    paramParcel.writeByte((byte)this.b);
    paramParcel.writeByte((byte)this.c);
    paramParcel.writeByte((byte)this.d);
    paramParcel.writeByte((byte)this.e);
    paramParcel.writeLong(this.f);
    paramParcel.writeLong(this.g);
    int i = this.h.size();
    paramParcel.writeInt(i);
    for (paramInt = 0; paramInt < i; paramInt++)
      ((a)this.h.get(paramInt)).a(paramParcel); 
    paramParcel.writeByte((byte)this.i);
    paramParcel.writeLong(this.j);
    paramParcel.writeInt(this.k);
    paramParcel.writeInt(this.l);
    paramParcel.writeInt(this.m);
  }
  
  public static final class a {
    public final int a;
    
    public final long b;
    
    public final long c;
    
    private a(int param1Int, long param1Long1, long param1Long2) {
      this.a = param1Int;
      this.b = param1Long1;
      this.c = param1Long2;
    }
    
    public static a b(Parcel param1Parcel) {
      return new a(param1Parcel.readInt(), param1Parcel.readLong(), param1Parcel.readLong());
    }
    
    public void a(Parcel param1Parcel) {
      param1Parcel.writeInt(this.a);
      param1Parcel.writeLong(this.b);
      param1Parcel.writeLong(this.c);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\exoplayer2\g\g\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */