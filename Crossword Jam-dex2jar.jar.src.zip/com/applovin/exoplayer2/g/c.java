package com.applovin.exoplayer2.g;

import com.applovin.exoplayer2.g.a.b;
import com.applovin.exoplayer2.g.b.b;
import com.applovin.exoplayer2.g.d.a;
import com.applovin.exoplayer2.g.e.g;
import com.applovin.exoplayer2.g.g.c;
import com.applovin.exoplayer2.v;

public interface c {
  public static final c a = new c() {
      public boolean a(v param1v) {
        String str = param1v.l;
        return ("application/id3".equals(str) || "application/x-emsg".equals(str) || "application/x-scte35".equals(str) || "application/x-icy".equals(str) || "application/vnd.dvb.ait".equals(str));
      }
      
      public b b(v param1v) {
        String str = param1v.l;
        if (str != null) {
          StringBuilder stringBuilder;
          str.hashCode();
          byte b = -1;
          switch (str.hashCode()) {
            case 1652648887:
              if (!str.equals("application/x-scte35"))
                break; 
              b = 4;
              break;
            case 1154383568:
              if (!str.equals("application/x-emsg"))
                break; 
              b = 3;
              break;
            case -1248341703:
              if (!str.equals("application/id3"))
                break; 
              b = 2;
              break;
            case -1348231605:
              if (!str.equals("application/x-icy"))
                break; 
              b = 1;
              break;
            case -1354451219:
              if (!str.equals("application/vnd.dvb.ait"))
                break; 
              b = 0;
              break;
          } 
          switch (b) {
            default:
              stringBuilder = new StringBuilder();
              stringBuilder.append("Attempted to create decoder for unsupported MIME type: ");
              stringBuilder.append(str);
              throw new IllegalArgumentException(stringBuilder.toString());
            case 4:
              return (b)new c();
            case 3:
              return (b)new b();
            case 2:
              return (b)new g();
            case 1:
              return (b)new a();
            case 0:
              break;
          } 
          return (b)new b();
        } 
      }
    };
  
  boolean a(v paramv);
  
  b b(v paramv);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\exoplayer2\g\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */