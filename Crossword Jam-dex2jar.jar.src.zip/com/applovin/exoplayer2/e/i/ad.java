package com.applovin.exoplayer2.e.i;

import android.util.SparseArray;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.y;
import java.util.Collections;
import java.util.List;

public interface ad {
  void a();
  
  void a(ag paramag, j paramj, d paramd);
  
  void a(y paramy, int paramInt) throws ai;
  
  public static final class a {
    public final String a;
    
    public final int b;
    
    public final byte[] c;
    
    public a(String param1String, int param1Int, byte[] param1ArrayOfbyte) {
      this.a = param1String;
      this.b = param1Int;
      this.c = param1ArrayOfbyte;
    }
  }
  
  public static final class b {
    public final int a;
    
    @Nullable
    public final String b;
    
    public final List<ad.a> c;
    
    public final byte[] d;
    
    public b(int param1Int, @Nullable String param1String, @Nullable List<ad.a> param1List, byte[] param1ArrayOfbyte) {
      List<ad.a> list;
      this.a = param1Int;
      this.b = param1String;
      if (param1List == null) {
        list = Collections.emptyList();
      } else {
        list = Collections.unmodifiableList(param1List);
      } 
      this.c = list;
      this.d = param1ArrayOfbyte;
    }
  }
  
  public static interface c {
    SparseArray<ad> a();
    
    @Nullable
    ad a(int param1Int, ad.b param1b);
  }
  
  public static final class d {
    private final String a;
    
    private final int b;
    
    private final int c;
    
    private int d;
    
    private String e;
    
    public d(int param1Int1, int param1Int2) {
      this(-2147483648, param1Int1, param1Int2);
    }
    
    public d(int param1Int1, int param1Int2, int param1Int3) {
      String str;
      if (param1Int1 != Integer.MIN_VALUE) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Int1);
        stringBuilder.append("/");
        str = stringBuilder.toString();
      } else {
        str = "";
      } 
      this.a = str;
      this.b = param1Int2;
      this.c = param1Int3;
      this.d = Integer.MIN_VALUE;
      this.e = "";
    }
    
    private void d() {
      if (this.d != Integer.MIN_VALUE)
        return; 
      throw new IllegalStateException("generateNewId() must be called before retrieving ids.");
    }
    
    public void a() {
      int i = this.d;
      if (i == Integer.MIN_VALUE) {
        i = this.b;
      } else {
        i += this.c;
      } 
      this.d = i;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(this.d);
      this.e = stringBuilder.toString();
    }
    
    public int b() {
      d();
      return this.d;
    }
    
    public String c() {
      d();
      return this.e;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\exoplayer2\e\i\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */