package com.applovin.exoplayer2.e.i;

import com.applovin.exoplayer2.l.y;

public final class ae {
  public static int a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2 && paramArrayOfbyte[paramInt1] != 71)
      paramInt1++; 
    return paramInt1;
  }
  
  public static long a(y paramy, int paramInt1, int paramInt2) {
    paramy.d(paramInt1);
    if (paramy.a() < 5)
      return -9223372036854775807L; 
    paramInt1 = paramy.q();
    if ((0x800000 & paramInt1) != 0)
      return -9223372036854775807L; 
    if ((0x1FFF00 & paramInt1) >> 8 != paramInt2)
      return -9223372036854775807L; 
    paramInt2 = 1;
    if ((paramInt1 & 0x20) != 0) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 == 0)
      return -9223372036854775807L; 
    if (paramy.h() >= 7 && paramy.a() >= 7) {
      if ((paramy.h() & 0x10) == 16) {
        paramInt1 = paramInt2;
      } else {
        paramInt1 = 0;
      } 
      if (paramInt1 != 0) {
        byte[] arrayOfByte = new byte[6];
        paramy.a(arrayOfByte, 0, 6);
        return a(arrayOfByte);
      } 
    } 
    return -9223372036854775807L;
  }
  
  private static long a(byte[] paramArrayOfbyte) {
    return (paramArrayOfbyte[0] & 0xFFL) << 25L | (paramArrayOfbyte[1] & 0xFFL) << 17L | (paramArrayOfbyte[2] & 0xFFL) << 9L | (paramArrayOfbyte[3] & 0xFFL) << 1L | (0xFFL & paramArrayOfbyte[4]) >> 7L;
  }
  
  public static boolean a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
    int j = -4;
    int i = 0;
    while (j <= 4) {
      int k = j * 188 + paramInt3;
      if (k < paramInt1 || k >= paramInt2 || paramArrayOfbyte[k] != 71) {
        i = 0;
      } else {
        k = i + 1;
        i = k;
        if (k == 5)
          return true; 
      } 
      j++;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\exoplayer2\e\i\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */