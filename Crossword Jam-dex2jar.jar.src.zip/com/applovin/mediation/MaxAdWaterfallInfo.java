package com.applovin.mediation;

import java.util.List;

public interface MaxAdWaterfallInfo {
  long getLatencyMillis();
  
  MaxAd getLoadedAd();
  
  String getName();
  
  List<MaxNetworkResponseInfo> getNetworkResponses();
  
  String getTestName();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\mediation\MaxAdWaterfallInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */