package com.applovin.mediation.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxRewardedInterstitialAdapter;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAppOpenAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedInterstitialAdapterListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.admanager.AdManagerAdView;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAdLoadCallback;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class GoogleAdManagerMediationAdapter extends MediationAdapterBase implements MaxInterstitialAdapter, MaxRewardedInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter {
  private static final AtomicBoolean initialized = new AtomicBoolean();
  
  private AdManagerAdView adView;
  
  private AppOpenAd appOpenAd;
  
  private AppOpenAdListener appOpenAdListener;
  
  private AdManagerInterstitialAd interstitialAd;
  
  private NativeAd nativeAd;
  
  private NativeAdView nativeAdView;
  
  private RewardedAd rewardedAd;
  
  private RewardedAdListener rewardedAdListener;
  
  private RewardedInterstitialAd rewardedInterstitialAd;
  
  private RewardedInterstitialAdListener rewardedInterstitialAdListener;
  
  public GoogleAdManagerMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private AdManagerAdRequest createAdRequestWithParameters(MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    AdManagerAdRequest.Builder builder = new AdManagerAdRequest.Builder();
    Bundle bundle2 = paramMaxAdapterParameters.getServerParameters();
    if (bundle2.getBoolean("set_mediation_identifier", true))
      builder.setRequestAgent(MediationAdapterBase.mediationTag()); 
    Bundle bundle1 = new Bundle();
    String str = BundleUtils.getString("event_id", bundle2);
    if (AppLovinSdkUtils.isValidString(str))
      bundle1.putString("placement_req_id", str); 
    Boolean bool = getPrivacySetting("hasUserConsent", paramMaxAdapterParameters);
    if (bool != null && !bool.booleanValue())
      bundle1.putString("npa", "1"); 
    int i = AppLovinSdk.VERSION_CODE;
    if (i >= 91100) {
      bool = getPrivacySetting("isDoNotSell", paramMaxAdapterParameters);
      if (bool != null && bool.booleanValue()) {
        bundle1.putInt("rdp", 1);
        PreferenceManager.getDefaultSharedPreferences(paramContext).edit().putInt("gad_rdp", 1).commit();
      } 
    } 
    if (i >= 11000000) {
      Map map = paramMaxAdapterParameters.getLocalExtraParameters();
      paramContext = (Context)map.get("google_max_ad_content_rating");
      if (paramContext instanceof String)
        bundle1.putString("max_ad_content_rating", (String)paramContext); 
      paramContext = (Context)map.get("google_content_url");
      if (paramContext instanceof String)
        builder.setContentUrl((String)paramContext); 
      paramContext = (Context)map.get("google_neighbouring_content_url_strings");
      if (paramContext instanceof List)
        try {
          builder.setNeighboringContentUrls((List)paramContext);
        } finally {
          paramContext = null;
        }  
      paramContext = (Context)map.get("ppid");
      if (paramContext instanceof String)
        builder.setPublisherProvidedId((String)paramContext); 
      map = (Map)map.get("custom_targeting");
      if (map instanceof Map)
        try {
          map = map;
        } finally {
          map = null;
        }  
    } 
    builder.addNetworkExtrasBundle(AdMobAdapter.class, bundle1);
    return builder.build();
  }
  
  private int getAdChoicesPlacement(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    int j = AppLovinSdk.VERSION_CODE;
    byte b = 1;
    int i = b;
    if (j >= 11000000) {
      Map map = paramMaxAdapterResponseParameters.getLocalExtraParameters();
      if (map != null) {
        map = (Map)map.get("gam_ad_choices_placement");
      } else {
        map = null;
      } 
      i = b;
      if (isValidAdChoicesPlacement(map))
        i = ((Integer)map).intValue(); 
    } 
    return i;
  }
  
  private int getAdaptiveBannerWidth(MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    if (AppLovinSdk.VERSION_CODE >= 11000000) {
      paramMaxAdapterParameters = (MaxAdapterParameters)paramMaxAdapterParameters.getLocalExtraParameters().get("adaptive_banner_width");
      if (paramMaxAdapterParameters instanceof Integer)
        return ((Integer)paramMaxAdapterParameters).intValue(); 
      if (paramMaxAdapterParameters != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Expected parameter \"adaptive_banner_width\" to be of type Integer, received: ");
        stringBuilder.append(paramMaxAdapterParameters.getClass());
        e(stringBuilder.toString());
      } 
    } 
    Display display = ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay();
    DisplayMetrics displayMetrics = new DisplayMetrics();
    display.getMetrics(displayMetrics);
    return AppLovinSdkUtils.pxToDp(paramContext, displayMetrics.widthPixels);
  }
  
  private Context getContext(@Nullable Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private Boolean getPrivacySetting(String paramString, MaxAdapterParameters paramMaxAdapterParameters) {
    try {
      return (Boolean)paramMaxAdapterParameters.getClass().getMethod(paramString, new Class[0]).invoke(paramMaxAdapterParameters, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error getting privacy setting ");
      stringBuilder.append(paramString);
      stringBuilder.append(" with exception: ");
      log(stringBuilder.toString(), exception);
      return (AppLovinSdk.VERSION_CODE >= 9140000) ? null : Boolean.FALSE;
    } 
  }
  
  private boolean isValidAdChoicesPlacement(Object paramObject) {
    null = paramObject instanceof Integer;
    boolean bool = true;
    if (null) {
      paramObject = paramObject;
      null = bool;
      if (paramObject.intValue() != 0) {
        null = bool;
        if (paramObject.intValue() != 1) {
          null = bool;
          if (paramObject.intValue() != 3) {
            if (paramObject.intValue() == 2)
              return true; 
          } else {
            return null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
    } 
    return false;
  }
  
  private void setRequestConfiguration(MaxAdapterParameters paramMaxAdapterParameters) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private AdSize toAdSize(MaxAdFormat paramMaxAdFormat, boolean paramBoolean, MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    MaxAdFormat maxAdFormat = MaxAdFormat.BANNER;
    if (paramMaxAdFormat == maxAdFormat || paramMaxAdFormat == MaxAdFormat.LEADER)
      return paramBoolean ? AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(paramContext, getAdaptiveBannerWidth(paramMaxAdapterParameters, paramContext)) : ((paramMaxAdFormat == maxAdFormat) ? AdSize.BANNER : AdSize.LEADERBOARD); 
    if (paramMaxAdFormat == MaxAdFormat.MREC)
      return AdSize.MEDIUM_RECTANGLE; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported ad format: ");
    stringBuilder.append(paramMaxAdFormat);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static MaxAdapterError toMaxError(AdError paramAdError) {
    int i = paramAdError.getCode();
    MaxAdapterError maxAdapterError = MaxAdapterError.UNSPECIFIED;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            switch (i) {
              default:
                return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), i, paramAdError.getMessage());
              case 8:
              case 11:
                maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
              case 9:
                maxAdapterError = MaxAdapterError.NO_FILL;
              case 10:
                break;
            } 
          } else {
          
          } 
        } else {
          maxAdapterError = MaxAdapterError.NO_CONNECTION;
        }  
      maxAdapterError = MaxAdapterError.BAD_REQUEST;
    } 
    maxAdapterError = MaxAdapterError.INTERNAL_ERROR;
  }
  
  private static void updateMuteState(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    Bundle bundle = paramMaxAdapterResponseParameters.getServerParameters();
    if (bundle.containsKey("is_muted"))
      MobileAds.setAppMuted(bundle.getBoolean("is_muted")); 
  }
  
  public String getAdapterVersion() {
    return "22.0.0.0";
  }
  
  public String getSdkVersion() {
    return String.valueOf(MobileAds.getVersion());
  }
  
  @SuppressLint({"MissingPermission"})
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, MaxAdapter.OnCompletionListener paramOnCompletionListener) {
    log("Initializing Google Ad Manager SDK...");
    if (initialized.compareAndSet(false, true))
      MobileAds.initialize(getContext(paramActivity)); 
    paramOnCompletionListener.onCompletion(MaxAdapter.InitializationStatus.DOES_NOT_APPLY, null);
  }
  
  @SuppressLint({"MissingPermission"})
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, MaxAdViewAdapterListener paramMaxAdViewAdapterListener) {
    NativeAdViewListener nativeAdViewListener;
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool2 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool2) {
      str1 = "native ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append(paramMaxAdFormat.getLabel());
    stringBuilder.append(" ad for placement id: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    AdManagerAdRequest adManagerAdRequest = createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    boolean bool1 = false;
    if (bool2) {
      NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
      builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
      if (paramMaxAdFormat == MaxAdFormat.MREC)
        bool1 = true; 
      builder.setRequestMultipleImages(bool1);
      nativeAdViewListener = new NativeAdViewListener(paramMaxAdapterResponseParameters, paramMaxAdFormat, paramActivity, paramMaxAdViewAdapterListener);
      (new AdLoader.Builder(context, str2)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdViewListener).withAdListener(nativeAdViewListener).build().loadAd(adManagerAdRequest);
      return;
    } 
    AdManagerAdView adManagerAdView = new AdManagerAdView(context);
    this.adView = adManagerAdView;
    adManagerAdView.setAdUnitId(str2);
    this.adView.setAdListener(new AdViewListener(str2, paramMaxAdFormat, paramMaxAdViewAdapterListener));
    bool1 = nativeAdViewListener.getServerParameters().getBoolean("adaptive_banner", false);
    this.adView.setAdSize(toAdSize(paramMaxAdFormat, bool1, (MaxAdapterParameters)nativeAdViewListener, context));
    this.adView.loadAd(adManagerAdRequest);
  }
  
  public void loadAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, final MaxAppOpenAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading app open ad: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    AdManagerAdRequest adManagerAdRequest = createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity);
    Context context = getContext(paramActivity);
    AppOpenAd.load(context, str, adManagerAdRequest, AppLovinSdkUtils.getOrientation(context), new AppOpenAd.AppOpenAdLoadCallback() {
          public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("App open ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            listener.onAppOpenAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(AppOpenAd param1AppOpenAd) {
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("App open ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            GoogleAdManagerMediationAdapter.access$202(GoogleAdManagerMediationAdapter.this, param1AppOpenAd);
            googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            GoogleAdManagerMediationAdapter.access$302(googleAdManagerMediationAdapter, new GoogleAdManagerMediationAdapter.AppOpenAdListener(placementId, listener));
            param1AppOpenAd.setFullScreenContentCallback(GoogleAdManagerMediationAdapter.this.appOpenAdListener);
            ResponseInfo responseInfo = GoogleAdManagerMediationAdapter.this.appOpenAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onAppOpenAdLoaded(bundle);
              return;
            } 
            listener.onAppOpenAdLoaded();
          }
        });
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxInterstitialAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading interstitial ad: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    AdManagerInterstitialAd.load((Context)paramActivity, str, createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new AdManagerInterstitialAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            listener.onInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull AdManagerInterstitialAd param1AdManagerInterstitialAd) {
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Interstitial ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            GoogleAdManagerMediationAdapter.access$002(GoogleAdManagerMediationAdapter.this, param1AdManagerInterstitialAd);
            GoogleAdManagerMediationAdapter.this.interstitialAd.setFullScreenContentCallback(new GoogleAdManagerMediationAdapter.InterstitialAdListener(placementId, listener));
            ResponseInfo responseInfo = GoogleAdManagerMediationAdapter.this.interstitialAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onInterstitialAdLoaded();
          }
        });
  }
  
  @SuppressLint({"MissingPermission"})
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading native ad for placement id: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    AdManagerAdRequest adManagerAdRequest = createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
    builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
    builder.setRequestMultipleImages(BundleUtils.getString("template", "", paramMaxAdapterResponseParameters.getServerParameters()).contains("medium"));
    NativeAdListener nativeAdListener = new NativeAdListener(paramMaxAdapterResponseParameters, context, paramMaxNativeAdAdapterListener);
    (new AdLoader.Builder(context, str)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdListener).withAdListener(nativeAdListener).build().loadAd((AdRequest)adManagerAdRequest);
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading rewarded ad: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedAd.load((Context)paramActivity, str, createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull RewardedAd param1RewardedAd) {
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter2 = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleAdManagerMediationAdapter2.log(stringBuilder.toString());
            GoogleAdManagerMediationAdapter.access$802(GoogleAdManagerMediationAdapter.this, param1RewardedAd);
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter1 = GoogleAdManagerMediationAdapter.this;
            GoogleAdManagerMediationAdapter.access$902(googleAdManagerMediationAdapter1, new GoogleAdManagerMediationAdapter.RewardedAdListener(placementId, listener));
            GoogleAdManagerMediationAdapter.this.rewardedAd.setFullScreenContentCallback(GoogleAdManagerMediationAdapter.this.rewardedAdListener);
            ResponseInfo responseInfo = GoogleAdManagerMediationAdapter.this.rewardedAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onRewardedAdLoaded(bundle);
              return;
            } 
            listener.onRewardedAdLoaded();
          }
        });
  }
  
  public void loadRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedInterstitialAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading rewarded interstitial ad: ");
    stringBuilder.append(str);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedInterstitialAd.load((Context)paramActivity, str, (AdRequest)createAdRequestWithParameters((MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedInterstitialAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull RewardedInterstitialAd param1RewardedInterstitialAd) {
            String str1;
            GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded interstitial ad loaded: ");
            stringBuilder.append(placementId);
            googleAdManagerMediationAdapter.log(stringBuilder.toString());
            GoogleAdManagerMediationAdapter.access$402(GoogleAdManagerMediationAdapter.this, param1RewardedInterstitialAd);
            googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
            String str2 = placementId;
            MaxRewardedInterstitialAdapterListener maxRewardedInterstitialAdapterListener = listener;
            param1RewardedInterstitialAd = null;
            GoogleAdManagerMediationAdapter.access$502(googleAdManagerMediationAdapter, new GoogleAdManagerMediationAdapter.RewardedInterstitialAdListener(str2, maxRewardedInterstitialAdapterListener));
            GoogleAdManagerMediationAdapter.this.rewardedInterstitialAd.setFullScreenContentCallback(GoogleAdManagerMediationAdapter.this.rewardedInterstitialAdListener);
            ResponseInfo responseInfo = GoogleAdManagerMediationAdapter.this.rewardedInterstitialAd.getResponseInfo();
            if (responseInfo != null)
              str1 = responseInfo.getResponseId(); 
            if (AppLovinSdk.VERSION_CODE > 9150000 && AppLovinSdkUtils.isValidString(str1)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", str1);
              listener.onRewardedInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onRewardedInterstitialAdLoaded();
          }
        });
  }
  
  public void onDestroy() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Destroy called for adapter ");
    stringBuilder.append(this);
    log(stringBuilder.toString());
    AdManagerInterstitialAd adManagerInterstitialAd = this.interstitialAd;
    if (adManagerInterstitialAd != null) {
      adManagerInterstitialAd.setFullScreenContentCallback(null);
      this.interstitialAd = null;
    } 
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.setFullScreenContentCallback(null);
      this.appOpenAd = null;
      this.appOpenAdListener = null;
    } 
    RewardedInterstitialAd rewardedInterstitialAd = this.rewardedInterstitialAd;
    if (rewardedInterstitialAd != null) {
      rewardedInterstitialAd.setFullScreenContentCallback(null);
      this.rewardedInterstitialAd = null;
      this.rewardedInterstitialAdListener = null;
    } 
    RewardedAd rewardedAd = this.rewardedAd;
    if (rewardedAd != null) {
      rewardedAd.setFullScreenContentCallback(null);
      this.rewardedAd = null;
      this.rewardedAdListener = null;
    } 
    AdManagerAdView adManagerAdView = this.adView;
    if (adManagerAdView != null) {
      adManagerAdView.destroy();
      this.adView = null;
    } 
    NativeAd nativeAd = this.nativeAd;
    if (nativeAd != null) {
      nativeAd.destroy();
      this.nativeAd = null;
    } 
    NativeAdView nativeAdView = this.nativeAdView;
    if (nativeAdView != null) {
      nativeAdView.destroy();
      this.nativeAdView = null;
    } 
  }
  
  public void showAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, MaxAppOpenAdapterListener paramMaxAppOpenAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing app open ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("App open ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxAppOpenAdapterListener.onAppOpenAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "App open ad not ready"));
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    AdManagerInterstitialAd adManagerInterstitialAd = this.interstitialAd;
    if (adManagerInterstitialAd != null) {
      adManagerInterstitialAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxInterstitialAdapterListener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing rewarded ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(@NonNull RewardItem param1RewardItem) {
              GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Rewarded ad user earned reward: ");
              stringBuilder.append(placementId);
              googleAdManagerMediationAdapter.log(stringBuilder.toString());
              GoogleAdManagerMediationAdapter.RewardedAdListener.access$1002(GoogleAdManagerMediationAdapter.this.rewardedAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Rewarded ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedAdapterListener.onRewardedAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
  }
  
  public void showRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedInterstitialAdapterListener paramMaxRewardedInterstitialAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing rewarded interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedInterstitialAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedInterstitialAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(@NonNull RewardItem param1RewardItem) {
              GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Rewarded interstitial ad user earned reward: ");
              stringBuilder.append(placementId);
              googleAdManagerMediationAdapter.log(stringBuilder.toString());
              GoogleAdManagerMediationAdapter.RewardedInterstitialAdListener.access$702(GoogleAdManagerMediationAdapter.this.rewardedInterstitialAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Rewarded interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedInterstitialAdapterListener.onRewardedInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded Interstitial ad not ready"));
  }
  
  private class AdViewListener extends AdListener {
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    AdViewListener(String param1String, MaxAdFormat param1MaxAdFormat, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1String;
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClosed() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error code: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdLoaded() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdk.VERSION_CODE >= 9150000) {
        Bundle bundle = new Bundle(3);
        ResponseInfo responseInfo = GoogleAdManagerMediationAdapter.this.adView.getResponseInfo();
        if (responseInfo != null) {
          String str = responseInfo.getResponseId();
        } else {
          responseInfo = null;
        } 
        if (AppLovinSdkUtils.isValidString((String)responseInfo))
          bundle.putString("creative_id", (String)responseInfo); 
        AdSize adSize = GoogleAdManagerMediationAdapter.this.adView.getAdSize();
        if (adSize != null) {
          bundle.putInt("ad_width", adSize.getWidth());
          bundle.putInt("ad_height", adSize.getHeight());
        } 
        this.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.adView, bundle);
        return;
      } 
      this.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.adView);
    }
    
    public void onAdOpened() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
  }
  
  private class AppOpenAdListener extends FullScreenContentCallback {
    private final MaxAppOpenAdapterListener listener;
    
    private final String placementId;
    
    AppOpenAdListener(String param1String, MaxAppOpenAdapterListener param1MaxAppOpenAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxAppOpenAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad clicked: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad hidden: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad display failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad shown: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class InterstitialAdListener extends FullScreenContentCallback {
    private final MaxInterstitialAdapterListener listener;
    
    private final String placementId;
    
    InterstitialAdListener(String param1String, MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad clicked: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class MaxGoogleAdManagerNativeAd extends MaxNativeAd {
    public MaxGoogleAdManagerNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      NativeAd nativeAd = GoogleAdManagerMediationAdapter.this.nativeAd;
      if (nativeAd == null) {
        GoogleAdManagerMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return;
      } 
      GoogleAdManagerMediationAdapter.access$1402(GoogleAdManagerMediationAdapter.this, new NativeAdView(param1MaxNativeAdView.getContext()));
      View view2 = param1MaxNativeAdView.getMainView();
      param1MaxNativeAdView.removeView(view2);
      GoogleAdManagerMediationAdapter.this.nativeAdView.addView(view2);
      param1MaxNativeAdView.addView((View)GoogleAdManagerMediationAdapter.this.nativeAdView);
      GoogleAdManagerMediationAdapter.this.nativeAdView.setIconView((View)param1MaxNativeAdView.getIconImageView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setHeadlineView((View)param1MaxNativeAdView.getTitleTextView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setAdvertiserView((View)param1MaxNativeAdView.getAdvertiserTextView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setBodyView((View)param1MaxNativeAdView.getBodyTextView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setCallToActionView((View)param1MaxNativeAdView.getCallToActionButton());
      View view1 = getMediaView();
      if (view1 instanceof MediaView) {
        GoogleAdManagerMediationAdapter.this.nativeAdView.setMediaView((MediaView)view1);
      } else if (view1 instanceof android.widget.ImageView) {
        GoogleAdManagerMediationAdapter.this.nativeAdView.setImageView(view1);
      } 
      GoogleAdManagerMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
    }
  }
  
  private class NativeAdListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final Context context;
    
    final MaxNativeAdAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    public NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.context = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter.this.log("Native ad clicked");
      this.listener.onNativeAdClicked();
    }
    
    public void onAdClosed() {
      GoogleAdManagerMediationAdapter.this.log("Native ad closed");
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter.this.log("Native ad shown");
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onAdOpened() {
      GoogleAdManagerMediationAdapter.this.log("Native ad opened");
    }
    
    public void onNativeAdLoaded(@NonNull final NativeAd nativeAd) {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad loaded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      GoogleAdManagerMediationAdapter.access$1202(GoogleAdManagerMediationAdapter.this, nativeAd);
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ad (");
        stringBuilder.append(nativeAd);
        stringBuilder.append(") does not have required assets.");
        googleAdManagerMediationAdapter.e(stringBuilder.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              // Byte code:
              //   0: aload_0
              //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
              //   7: astore #5
              //   9: aload_0
              //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   13: invokevirtual getImages : ()Ljava/util/List;
              //   16: astore_3
              //   17: aconst_null
              //   18: astore #6
              //   20: aload #5
              //   22: ifnull -> 66
              //   25: new com/google/android/gms/ads/nativead/MediaView
              //   28: dup
              //   29: aload_0
              //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
              //   33: getfield context : Landroid/content/Context;
              //   36: invokespecial <init> : (Landroid/content/Context;)V
              //   39: astore_3
              //   40: aload_3
              //   41: aload #5
              //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
              //   46: aload #5
              //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
              //   53: astore #4
              //   55: aload #5
              //   57: invokeinterface getAspectRatio : ()F
              //   62: fstore_1
              //   63: goto -> 154
              //   66: aload_3
              //   67: ifnull -> 147
              //   70: aload_3
              //   71: invokeinterface size : ()I
              //   76: ifle -> 147
              //   79: aload_3
              //   80: iconst_0
              //   81: invokeinterface get : (I)Ljava/lang/Object;
              //   86: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
              //   89: astore #4
              //   91: new android/widget/ImageView
              //   94: dup
              //   95: aload_0
              //   96: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
              //   99: getfield context : Landroid/content/Context;
              //   102: invokespecial <init> : (Landroid/content/Context;)V
              //   105: astore_3
              //   106: aload #4
              //   108: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   111: astore #5
              //   113: aload #5
              //   115: ifnull -> 147
              //   118: aload_3
              //   119: aload #4
              //   121: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   124: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
              //   127: aload #5
              //   129: invokevirtual getIntrinsicWidth : ()I
              //   132: i2f
              //   133: aload #5
              //   135: invokevirtual getIntrinsicHeight : ()I
              //   138: i2f
              //   139: fdiv
              //   140: fstore_1
              //   141: aconst_null
              //   142: astore #4
              //   144: goto -> 154
              //   147: fconst_0
              //   148: fstore_1
              //   149: aconst_null
              //   150: astore_3
              //   151: aload_3
              //   152: astore #4
              //   154: aload_0
              //   155: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   158: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
              //   161: astore #5
              //   163: aload #5
              //   165: ifnull -> 210
              //   168: aload #5
              //   170: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   173: ifnull -> 193
              //   176: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   179: dup
              //   180: aload #5
              //   182: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   185: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   188: astore #5
              //   190: goto -> 213
              //   193: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   196: dup
              //   197: aload #5
              //   199: invokevirtual getUri : ()Landroid/net/Uri;
              //   202: invokespecial <init> : (Landroid/net/Uri;)V
              //   205: astore #5
              //   207: goto -> 213
              //   210: aconst_null
              //   211: astore #5
              //   213: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
              //   216: dup
              //   217: invokespecial <init> : ()V
              //   220: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
              //   223: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   226: aload #5
              //   228: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   231: aload_0
              //   232: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   235: invokevirtual getHeadline : ()Ljava/lang/String;
              //   238: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   241: aload_0
              //   242: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   245: invokevirtual getAdvertiser : ()Ljava/lang/String;
              //   248: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   251: aload_0
              //   252: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   255: invokevirtual getBody : ()Ljava/lang/String;
              //   258: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   261: aload_3
              //   262: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   265: aload_0
              //   266: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   269: invokevirtual getCallToAction : ()Ljava/lang/String;
              //   272: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   275: astore_3
              //   276: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
              //   279: istore_2
              //   280: iload_2
              //   281: ldc 11040399
              //   283: if_icmplt -> 300
              //   286: aload_3
              //   287: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   290: dup
              //   291: aload #4
              //   293: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   296: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   299: pop
              //   300: iload_2
              //   301: ldc 11040000
              //   303: if_icmplt -> 312
              //   306: aload_3
              //   307: fload_1
              //   308: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   311: pop
              //   312: iload_2
              //   313: ldc 11070000
              //   315: if_icmplt -> 330
              //   318: aload_3
              //   319: aload_0
              //   320: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   323: invokevirtual getStarRating : ()Ljava/lang/Double;
              //   326: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   329: pop
              //   330: new com/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$MaxGoogleAdManagerNativeAd
              //   333: dup
              //   334: aload_0
              //   335: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
              //   338: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter;
              //   341: aload_3
              //   342: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
              //   345: astore #4
              //   347: aload_0
              //   348: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   351: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
              //   354: astore #5
              //   356: aload #6
              //   358: astore_3
              //   359: aload #5
              //   361: ifnull -> 370
              //   364: aload #5
              //   366: invokevirtual getResponseId : ()Ljava/lang/String;
              //   369: astore_3
              //   370: new android/os/Bundle
              //   373: dup
              //   374: iconst_1
              //   375: invokespecial <init> : (I)V
              //   378: astore #5
              //   380: aload #5
              //   382: ldc 'creative_id'
              //   384: aload_3
              //   385: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
              //   388: aload_0
              //   389: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
              //   392: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
              //   395: aload #4
              //   397: aload #5
              //   399: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
              //   404: return
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
      //   7: astore #5
      //   9: aload_0
      //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   13: invokevirtual getImages : ()Ljava/util/List;
      //   16: astore_3
      //   17: aconst_null
      //   18: astore #6
      //   20: aload #5
      //   22: ifnull -> 66
      //   25: new com/google/android/gms/ads/nativead/MediaView
      //   28: dup
      //   29: aload_0
      //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
      //   33: getfield context : Landroid/content/Context;
      //   36: invokespecial <init> : (Landroid/content/Context;)V
      //   39: astore_3
      //   40: aload_3
      //   41: aload #5
      //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
      //   46: aload #5
      //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
      //   53: astore #4
      //   55: aload #5
      //   57: invokeinterface getAspectRatio : ()F
      //   62: fstore_1
      //   63: goto -> 154
      //   66: aload_3
      //   67: ifnull -> 147
      //   70: aload_3
      //   71: invokeinterface size : ()I
      //   76: ifle -> 147
      //   79: aload_3
      //   80: iconst_0
      //   81: invokeinterface get : (I)Ljava/lang/Object;
      //   86: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
      //   89: astore #4
      //   91: new android/widget/ImageView
      //   94: dup
      //   95: aload_0
      //   96: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
      //   99: getfield context : Landroid/content/Context;
      //   102: invokespecial <init> : (Landroid/content/Context;)V
      //   105: astore_3
      //   106: aload #4
      //   108: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   111: astore #5
      //   113: aload #5
      //   115: ifnull -> 147
      //   118: aload_3
      //   119: aload #4
      //   121: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   124: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
      //   127: aload #5
      //   129: invokevirtual getIntrinsicWidth : ()I
      //   132: i2f
      //   133: aload #5
      //   135: invokevirtual getIntrinsicHeight : ()I
      //   138: i2f
      //   139: fdiv
      //   140: fstore_1
      //   141: aconst_null
      //   142: astore #4
      //   144: goto -> 154
      //   147: fconst_0
      //   148: fstore_1
      //   149: aconst_null
      //   150: astore_3
      //   151: aload_3
      //   152: astore #4
      //   154: aload_0
      //   155: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   158: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
      //   161: astore #5
      //   163: aload #5
      //   165: ifnull -> 210
      //   168: aload #5
      //   170: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   173: ifnull -> 193
      //   176: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   179: dup
      //   180: aload #5
      //   182: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   185: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   188: astore #5
      //   190: goto -> 213
      //   193: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   196: dup
      //   197: aload #5
      //   199: invokevirtual getUri : ()Landroid/net/Uri;
      //   202: invokespecial <init> : (Landroid/net/Uri;)V
      //   205: astore #5
      //   207: goto -> 213
      //   210: aconst_null
      //   211: astore #5
      //   213: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
      //   216: dup
      //   217: invokespecial <init> : ()V
      //   220: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
      //   223: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   226: aload #5
      //   228: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   231: aload_0
      //   232: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   235: invokevirtual getHeadline : ()Ljava/lang/String;
      //   238: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   241: aload_0
      //   242: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   245: invokevirtual getAdvertiser : ()Ljava/lang/String;
      //   248: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   251: aload_0
      //   252: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   255: invokevirtual getBody : ()Ljava/lang/String;
      //   258: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   261: aload_3
      //   262: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   265: aload_0
      //   266: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   269: invokevirtual getCallToAction : ()Ljava/lang/String;
      //   272: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   275: astore_3
      //   276: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
      //   279: istore_2
      //   280: iload_2
      //   281: ldc 11040399
      //   283: if_icmplt -> 300
      //   286: aload_3
      //   287: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   290: dup
      //   291: aload #4
      //   293: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   296: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   299: pop
      //   300: iload_2
      //   301: ldc 11040000
      //   303: if_icmplt -> 312
      //   306: aload_3
      //   307: fload_1
      //   308: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   311: pop
      //   312: iload_2
      //   313: ldc 11070000
      //   315: if_icmplt -> 330
      //   318: aload_3
      //   319: aload_0
      //   320: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   323: invokevirtual getStarRating : ()Ljava/lang/Double;
      //   326: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   329: pop
      //   330: new com/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$MaxGoogleAdManagerNativeAd
      //   333: dup
      //   334: aload_0
      //   335: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
      //   338: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter;
      //   341: aload_3
      //   342: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
      //   345: astore #4
      //   347: aload_0
      //   348: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   351: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
      //   354: astore #5
      //   356: aload #6
      //   358: astore_3
      //   359: aload #5
      //   361: ifnull -> 370
      //   364: aload #5
      //   366: invokevirtual getResponseId : ()Ljava/lang/String;
      //   369: astore_3
      //   370: new android/os/Bundle
      //   373: dup
      //   374: iconst_1
      //   375: invokespecial <init> : (I)V
      //   378: astore #5
      //   380: aload #5
      //   382: ldc 'creative_id'
      //   384: aload_3
      //   385: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   388: aload_0
      //   389: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleAdManagerMediationAdapter$NativeAdListener;
      //   392: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
      //   395: aload #4
      //   397: aload #5
      //   399: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
      //   404: return
    }
  }
  
  private class NativeAdViewListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final WeakReference<Activity> activityRef;
    
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Activity param1Activity, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.activityRef = new WeakReference<Activity>(param1Activity);
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdClosed() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdCollapsed();
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleAdManagerMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdOpened() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdExpanded();
    }
    
    public void onNativeAdLoaded(@NonNull final NativeAd nativeAd) {
      MaxNativeAd.MaxNativeAdImage maxNativeAdImage;
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      if (TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ");
        stringBuilder.append(this.adFormat.getLabel());
        stringBuilder.append(" ad failed to load: Google native ad is missing one or more required assets");
        googleAdManagerMediationAdapter.log(stringBuilder.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
        nativeAd.destroy();
        return;
      } 
      GoogleAdManagerMediationAdapter.access$1202(GoogleAdManagerMediationAdapter.this, nativeAd);
      final Activity activity = this.activityRef.get();
      final Context context = GoogleAdManagerMediationAdapter.this.getContext(activity);
      final MediaView mediaView = new MediaView(context);
      MediaContent mediaContent = nativeAd.getMediaContent();
      if (mediaContent != null)
        mediaView.setMediaContent(mediaContent); 
      NativeAd.Image image = nativeAd.getIcon();
      mediaContent = null;
      if (image != null)
        if (image.getDrawable() != null) {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(image.getDrawable());
        } else {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(image.getUri());
        }  
      final MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(this.adFormat).setIcon(maxNativeAdImage).setTitle(nativeAd.getHeadline()).setBody(nativeAd.getBody()).setMediaView((View)mediaView).setCallToAction(nativeAd.getCallToAction()).build();
      final String templateName = BundleUtils.getString("template", "", this.serverParameters);
      if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
        GoogleAdManagerMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default native template will be used."); 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              int i = AppLovinSdk.VERSION_CODE;
              if (i < 9140000) {
                GoogleAdManagerMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
              } else if (i >= 11010000) {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
              } else {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
              } 
              GoogleAdManagerMediationAdapter.access$1402(GoogleAdManagerMediationAdapter.this, new NativeAdView(context));
              GoogleAdManagerMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
              GoogleAdManagerMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
              GoogleAdManagerMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
              GoogleAdManagerMediationAdapter.this.nativeAdView.setMediaView(mediaView);
              GoogleAdManagerMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
              GoogleAdManagerMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
              GoogleAdManagerMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
              ResponseInfo responseInfo = nativeAd.getResponseInfo();
              if (responseInfo != null) {
                String str = responseInfo.getResponseId();
              } else {
                responseInfo = null;
              } 
              if (i >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", (String)responseInfo);
                GoogleAdManagerMediationAdapter.NativeAdViewListener nativeAdViewListener1 = GoogleAdManagerMediationAdapter.NativeAdViewListener.this;
                nativeAdViewListener1.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.nativeAdView, bundle);
                return;
              } 
              GoogleAdManagerMediationAdapter.NativeAdViewListener nativeAdViewListener = GoogleAdManagerMediationAdapter.NativeAdViewListener.this;
              nativeAdViewListener.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.nativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      int i = AppLovinSdk.VERSION_CODE;
      if (i < 9140000) {
        GoogleAdManagerMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
      } else if (i >= 11010000) {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
      } else {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
      } 
      GoogleAdManagerMediationAdapter.access$1402(GoogleAdManagerMediationAdapter.this, new NativeAdView(context));
      GoogleAdManagerMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setMediaView(mediaView);
      GoogleAdManagerMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
      GoogleAdManagerMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
      GoogleAdManagerMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
      ResponseInfo responseInfo = nativeAd.getResponseInfo();
      if (responseInfo != null) {
        String str = responseInfo.getResponseId();
      } else {
        responseInfo = null;
      } 
      if (i >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", (String)responseInfo);
        GoogleAdManagerMediationAdapter.NativeAdViewListener nativeAdViewListener1 = this.this$1;
        nativeAdViewListener1.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.nativeAdView, bundle);
        return;
      } 
      GoogleAdManagerMediationAdapter.NativeAdViewListener nativeAdViewListener = this.this$1;
      nativeAdViewListener.listener.onAdViewAdLoaded((View)GoogleAdManagerMediationAdapter.this.nativeAdView);
    }
  }
  
  private class RewardedAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedAdapterListener listener;
    
    private final String placementId;
    
    RewardedAdListener(String param1String, MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad clicked: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedAdVideoCompleted();
      if (this.hasGrantedReward || GoogleAdManagerMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleAdManagerMediationAdapter.this.getReward();
        GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter1 = GoogleAdManagerMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleAdManagerMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad hidden: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad shown: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdVideoStarted();
    }
  }
  
  private class RewardedInterstitialAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedInterstitialAdapterListener listener;
    
    private final String placementId;
    
    private RewardedInterstitialAdListener(String param1String, MaxRewardedInterstitialAdapterListener param1MaxRewardedInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad clicked");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedInterstitialAdVideoCompleted();
      if (this.hasGrantedReward || GoogleAdManagerMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleAdManagerMediationAdapter.this.getReward();
        GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter1 = GoogleAdManagerMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Rewarded interstitial ad rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleAdManagerMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleAdManagerMediationAdapter googleAdManagerMediationAdapter = GoogleAdManagerMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleAdManagerMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdVideoStarted();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\mediation\adapters\GoogleAdManagerMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */