package com.applovin.mediation.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAppOpenAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.vungle.warren.AdConfig;
import com.vungle.warren.BannerAdConfig;
import com.vungle.warren.Banners;
import com.vungle.warren.BuildConfig;
import com.vungle.warren.InitCallback;
import com.vungle.warren.LoadAdCallback;
import com.vungle.warren.NativeAd;
import com.vungle.warren.NativeAdLayout;
import com.vungle.warren.PlayAdCallback;
import com.vungle.warren.Plugin;
import com.vungle.warren.Vungle;
import com.vungle.warren.VungleApiClient;
import com.vungle.warren.VungleBanner;
import com.vungle.warren.VungleSettings;
import com.vungle.warren.error.VungleException;
import com.vungle.warren.ui.view.MediaView;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class VungleMediationAdapter extends MediationAdapterBase implements MaxSignalProvider, MaxInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter {
  private static final AtomicBoolean initialized = new AtomicBoolean();
  
  private static MaxAdapter.InitializationStatus status;
  
  private VungleBanner adViewAd;
  
  private NativeAd nativeAd;
  
  public VungleMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private AdConfig createAdConfig(Bundle paramBundle, Context paramContext) {
    AdConfig adConfig = new AdConfig();
    if (paramBundle.containsKey("ordinal"))
      adConfig.setOrdinal(paramBundle.getInt("ordinal")); 
    if (paramBundle.containsKey("immersive_mode"))
      adConfig.setImmersiveMode(paramBundle.getBoolean("immersive_mode")); 
    if (paramBundle.containsKey("is_muted"))
      adConfig.setMuted(paramBundle.getBoolean("is_muted")); 
    adConfig.setAdOrientation(vungleAdOrientation(paramContext));
    return adConfig;
  }
  
  private List<View> getClickableViews(MaxNativeAdView paramMaxNativeAdView) {
    ViewGroup viewGroup;
    FrameLayout frameLayout;
    ArrayList<TextView> arrayList = new ArrayList(6);
    if (paramMaxNativeAdView.getTitleTextView() != null)
      arrayList.add(paramMaxNativeAdView.getTitleTextView()); 
    if (paramMaxNativeAdView.getAdvertiserTextView() != null)
      arrayList.add(paramMaxNativeAdView.getAdvertiserTextView()); 
    if (paramMaxNativeAdView.getBodyTextView() != null)
      arrayList.add(paramMaxNativeAdView.getBodyTextView()); 
    if (paramMaxNativeAdView.getIconImageView() != null)
      arrayList.add(paramMaxNativeAdView.getIconImageView()); 
    if (paramMaxNativeAdView.getCallToActionButton() != null)
      arrayList.add(paramMaxNativeAdView.getCallToActionButton()); 
    if (AppLovinSdk.VERSION_CODE >= 11000000) {
      viewGroup = paramMaxNativeAdView.getMediaContentViewGroup();
    } else {
      frameLayout = viewGroup.getMediaContentView();
    } 
    if (frameLayout != null)
      arrayList.add(frameLayout); 
    return (List)arrayList;
  }
  
  private Context getContext(@Nullable Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private int getOrientation(Context paramContext) {
    if (paramContext != null) {
      Resources resources = paramContext.getResources();
      if (resources != null) {
        Configuration configuration = resources.getConfiguration();
        if (configuration != null)
          return configuration.orientation; 
      } 
    } 
    return 0;
  }
  
  private Boolean getPrivacySetting(String paramString, MaxAdapterParameters paramMaxAdapterParameters) {
    try {
      return (Boolean)paramMaxAdapterParameters.getClass().getMethod(paramString, new Class[0]).invoke(paramMaxAdapterParameters, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error getting privacy setting ");
      stringBuilder.append(paramString);
      stringBuilder.append(" with exception: ");
      log(stringBuilder.toString(), exception);
      return (AppLovinSdk.VERSION_CODE >= 9140000) ? null : Boolean.FALSE;
    } 
  }
  
  private boolean isValidPlacement(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    return (Vungle.getValidPlacements().contains(paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId()) || paramMaxAdapterResponseParameters.isTesting());
  }
  
  private void loadFullscreenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Context paramContext, LoadAdCallback paramLoadAdCallback) {
    AdConfig adConfig = createAdConfig(paramMaxAdapterResponseParameters.getServerParameters(), paramContext);
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    String str1 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    if (AppLovinSdkUtils.isValidString(str2)) {
      Vungle.loadAd(str1, str2, adConfig, paramLoadAdCallback);
      return;
    } 
    Vungle.loadAd(str1, adConfig, paramLoadAdCallback);
  }
  
  private void loadVungleNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Context paramContext, com.vungle.warren.NativeAdListener paramNativeAdListener) {
    AdConfig adConfig = new AdConfig();
    String str1 = paramMaxAdapterResponseParameters.getBidResponse();
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    updateUserPrivacySettings((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    this.nativeAd = new NativeAd(paramContext, str2);
    if (AppLovinSdkUtils.isValidString(str1)) {
      this.nativeAd.loadAd(adConfig, str1, paramNativeAdListener);
      return;
    } 
    this.nativeAd.loadAd(adConfig, paramNativeAdListener);
  }
  
  private void showAdViewAd(MaxAdFormat paramMaxAdFormat, BannerAdConfig paramBannerAdConfig, MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdViewAdapterListener paramMaxAdViewAdapterListener, PlayAdCallback paramPlayAdCallback) {
    String str1;
    String str4 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str4);
    String str3 = paramMaxAdFormat.getLabel();
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append(str3);
    stringBuilder2.append(" ad for placement: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (bool) {
      this.adViewAd = Banners.getBanner(str2, str4, paramBannerAdConfig, paramPlayAdCallback);
    } else {
      this.adViewAd = Banners.getBanner(str2, paramBannerAdConfig, paramPlayAdCallback);
    } 
    if (this.adViewAd != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str3);
      stringBuilder.append(" ad loaded");
      log(stringBuilder.toString());
      this.adViewAd.setGravity(17);
      paramMaxAdViewAdapterListener.onAdViewAdLoaded((View)this.adViewAd);
      return;
    } 
    MaxAdapterError maxAdapterError = MaxAdapterError.INVALID_LOAD_STATE;
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str3);
    stringBuilder1.append(" ad failed to load: ");
    stringBuilder1.append(maxAdapterError);
    log(stringBuilder1.toString());
    paramMaxAdViewAdapterListener.onAdViewAdLoadFailed(maxAdapterError);
  }
  
  private void showFullscreenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Context paramContext, PlayAdCallback paramPlayAdCallback) {
    AdConfig adConfig = createAdConfig(paramMaxAdapterResponseParameters.getServerParameters(), paramContext);
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    String str1 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    if (AppLovinSdkUtils.isValidString(str2)) {
      Vungle.playAd(str1, str2, adConfig, paramPlayAdCallback);
      return;
    } 
    Vungle.playAd(str1, adConfig, paramPlayAdCallback);
  }
  
  private static MaxAdapterError toMaxError(VungleException paramVungleException) {
    int i = paramVungleException.getExceptionCode();
    MaxAdapterError maxAdapterError2 = MaxAdapterError.UNSPECIFIED;
    MaxAdapterError maxAdapterError1 = maxAdapterError2;
    switch (i) {
      default:
        maxAdapterError1 = maxAdapterError2;
        break;
      case 27:
      case 31:
      case 32:
        maxAdapterError1 = MaxAdapterError.WEBVIEW_ERROR;
        break;
      case 14:
      case 21:
      case 22:
      case 26:
        maxAdapterError1 = MaxAdapterError.SERVER_ERROR;
        break;
      case 11:
      case 20:
      case 23:
      case 24:
      case 33:
      case 38:
        maxAdapterError1 = MaxAdapterError.NO_CONNECTION;
        break;
      case 10:
      case 25:
      case 39:
      case 40:
        maxAdapterError1 = MaxAdapterError.INTERNAL_ERROR;
        break;
      case 8:
      case 15:
        maxAdapterError1 = MaxAdapterError.INVALID_LOAD_STATE;
        break;
      case 6:
      case 7:
      case 9:
      case 16:
        maxAdapterError1 = MaxAdapterError.NOT_INITIALIZED;
        break;
      case 4:
      case 37:
        maxAdapterError1 = MaxAdapterError.AD_EXPIRED;
        break;
      case 3:
      case 5:
      case 12:
      case 13:
      case 17:
      case 18:
      case 19:
      case 28:
      case 29:
      case 30:
      case 34:
      case 35:
      case 36:
      case 41:
        maxAdapterError1 = MaxAdapterError.INVALID_CONFIGURATION;
        break;
      case 1:
        maxAdapterError1 = MaxAdapterError.NO_FILL;
        break;
      case 2:
        break;
    } 
    return new MaxAdapterError(maxAdapterError1.getErrorCode(), maxAdapterError1.getErrorMessage(), i, paramVungleException.getLocalizedMessage());
  }
  
  private void updateUserPrivacySettings(MaxAdapterParameters paramMaxAdapterParameters) {
    Boolean bool = getPrivacySetting("hasUserConsent", paramMaxAdapterParameters);
    if (bool != null) {
      Vungle.Consent consent;
      if (bool.booleanValue()) {
        consent = Vungle.Consent.OPTED_IN;
      } else {
        consent = Vungle.Consent.OPTED_OUT;
      } 
      Vungle.updateConsentStatus(consent, "");
    } 
    if (AppLovinSdk.VERSION_CODE >= 91100) {
      Boolean bool1 = getPrivacySetting("isDoNotSell", paramMaxAdapterParameters);
      if (bool1 != null) {
        Vungle.Consent consent;
        if (bool1.booleanValue()) {
          consent = Vungle.Consent.OPTED_OUT;
        } else {
          consent = Vungle.Consent.OPTED_IN;
        } 
        Vungle.updateCCPAStatus(consent);
      } 
    } 
  }
  
  private int vungleAdOrientation(Context paramContext) {
    int i = getOrientation(paramContext);
    return (i == 1) ? 0 : ((i == 2) ? 1 : 2);
  }
  
  private static AdConfig.AdSize vungleAdSize(MaxAdFormat paramMaxAdFormat) {
    if (paramMaxAdFormat == MaxAdFormat.BANNER)
      return AdConfig.AdSize.BANNER; 
    if (paramMaxAdFormat == MaxAdFormat.LEADER)
      return AdConfig.AdSize.BANNER_LEADERBOARD; 
    if (paramMaxAdFormat == MaxAdFormat.MREC)
      return AdConfig.AdSize.VUNGLE_MREC; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported ad view ad format: ");
    stringBuilder.append(paramMaxAdFormat.getLabel());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void collectSignal(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, Activity paramActivity, MaxSignalCollectionListener paramMaxSignalCollectionListener) {
    log("Collecting signal...");
    updateUserPrivacySettings((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters);
    paramMaxSignalCollectionListener.onSignalCollected(Vungle.getAvailableBidTokens(paramActivity.getApplicationContext()));
  }
  
  public String getAdapterVersion() {
    return "6.12.1.1";
  }
  
  public String getSdkVersion() {
    return getVersionString(BuildConfig.class, "VERSION_NAME");
  }
  
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, final MaxAdapter.OnCompletionListener onCompletionListener) {
    InitCallback initCallback;
    updateUserPrivacySettings((MaxAdapterParameters)paramMaxAdapterInitializationParameters);
    if (initialized.compareAndSet(false, true)) {
      String str = paramMaxAdapterInitializationParameters.getServerParameters().getString("app_id", null);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Initializing Vungle SDK with app id: ");
      stringBuilder.append(str);
      stringBuilder.append("...");
      log(stringBuilder.toString());
      status = MaxAdapter.InitializationStatus.INITIALIZING;
      Boolean bool = getPrivacySetting("isAgeRestrictedUser", (MaxAdapterParameters)paramMaxAdapterInitializationParameters);
      if (bool != null)
        Vungle.updateUserCoppaStatus(bool.booleanValue()); 
      Plugin.addWrapperInfo(VungleApiClient.WrapperFramework.max, getAdapterVersion());
      VungleSettings vungleSettings = (new VungleSettings.Builder()).disableBannerRefresh().build();
      initCallback = new InitCallback() {
          public void onAutoCacheAdAvailable(String param1String) {
            VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Auto-cached ad: ");
            stringBuilder.append(param1String);
            vungleMediationAdapter.log(stringBuilder.toString());
          }
          
          public void onError(VungleException param1VungleException) {
            VungleMediationAdapter.this.log("Vungle SDK failed to initialize with error: ", (Throwable)param1VungleException);
            VungleMediationAdapter.access$002(MaxAdapter.InitializationStatus.INITIALIZED_FAILURE);
            onCompletionListener.onCompletion(VungleMediationAdapter.status, param1VungleException.getLocalizedMessage());
          }
          
          public void onSuccess() {
            VungleMediationAdapter.this.log("Vungle SDK initialized");
            VungleMediationAdapter.access$002(MaxAdapter.InitializationStatus.INITIALIZED_SUCCESS);
            onCompletionListener.onCompletion(VungleMediationAdapter.status, null);
          }
        };
      Vungle.init(str, getContext(paramActivity), initCallback, vungleSettings);
      return;
    } 
    log("Vungle SDK already initialized");
    initCallback.onCompletion(status, null);
  }
  
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, final MaxAdFormat adFormat, Activity paramActivity, final MaxAdViewAdapterListener listener) {
    final StringBuilder parameters;
    String str5 = paramMaxAdapterResponseParameters.getBidResponse();
    final String adFormatLabel = adFormat.getLabel();
    String str4 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool1 = AppLovinSdkUtils.isValidString(str5);
    boolean bool2 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Loading ");
    String str2 = "";
    if (bool1) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    String str1 = str2;
    if (bool2)
      str1 = "native "; 
    stringBuilder2.append(str1);
    stringBuilder2.append(str3);
    stringBuilder2.append(" ad for placement: ");
    stringBuilder2.append(str4);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (!Vungle.isInitialized()) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Vungle SDK not successfully initialized: failing ");
      stringBuilder1.append(str3);
      stringBuilder1.append(" ad load...");
      log(stringBuilder1.toString());
      listener.onAdViewAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    if (!isValidPlacement((MaxAdapterResponseParameters)stringBuilder1)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str3);
      stringBuilder1.append(" ad failed to load due to an invalid placement id: ");
      stringBuilder1.append(str4);
      log(stringBuilder1.toString());
      listener.onAdViewAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
      return;
    } 
    if (bool2) {
      Context context = getContext(paramActivity);
      loadVungleNativeAd((MaxAdapterResponseParameters)stringBuilder1, context, new NativeAdViewListener((MaxAdapterResponseParameters)stringBuilder1, adFormat, context, listener));
      return;
    } 
    final AdViewAdListener playAdCallback = new AdViewAdListener(str3, listener);
    final BannerAdConfig adConfig = new BannerAdConfig();
    AdConfig.AdSize adSize = vungleAdSize(adFormat);
    bannerAdConfig.setAdSize(adSize);
    Bundle bundle = stringBuilder1.getServerParameters();
    if (bundle.containsKey("is_muted"))
      bannerAdConfig.setMuted(bundle.getBoolean("is_muted")); 
    if (bool1) {
      if (Banners.canPlayAd(str4, str5, adSize)) {
        showAdViewAd(adFormat, bannerAdConfig, (MaxAdapterResponseParameters)stringBuilder1, listener, adViewAdListener);
        return;
      } 
    } else if (Banners.canPlayAd(str4, adSize)) {
      showAdViewAd(adFormat, bannerAdConfig, (MaxAdapterResponseParameters)stringBuilder1, listener, adViewAdListener);
      return;
    } 
    updateUserPrivacySettings((MaxAdapterParameters)stringBuilder1);
    LoadAdCallback loadAdCallback = new LoadAdCallback() {
        public void onAdLoad(String param1String) {
          VungleMediationAdapter.this.showAdViewAd(adFormat, adConfig, parameters, listener, playAdCallback);
        }
        
        public void onError(String param1String, VungleException param1VungleException) {
          MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
          VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(adFormatLabel);
          stringBuilder.append(" ad for placement ");
          stringBuilder.append(param1String);
          stringBuilder.append(" failed to load with error: ");
          stringBuilder.append(maxAdapterError);
          vungleMediationAdapter.log(stringBuilder.toString());
          listener.onAdViewAdLoadFailed(maxAdapterError);
        }
      };
    if (bool1) {
      Banners.loadBanner(str4, str5, bannerAdConfig, loadAdCallback);
      return;
    } 
    Banners.loadBanner(str4, bannerAdConfig, loadAdCallback);
  }
  
  public void loadAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, final MaxAppOpenAdapterListener listener) {
    StringBuilder stringBuilder1;
    String str1;
    String str3 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str3);
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("app open ad for placement: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (!Vungle.isInitialized()) {
      log("Vungle SDK not successfully initialized: failing app open ad load...");
      listener.onAppOpenAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    if (!isValidPlacement(paramMaxAdapterResponseParameters)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("App open ad failed to load due to an invalid placement id: ");
      stringBuilder1.append(str2);
      log(stringBuilder1.toString());
      listener.onAppOpenAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
      return;
    } 
    if (bool) {
      if (Vungle.canPlayAd(str2, str3)) {
        log("App open ad loaded");
        listener.onAppOpenAdLoaded();
        return;
      } 
    } else if (Vungle.canPlayAd(str2)) {
      log("App open ad loaded");
      listener.onAppOpenAdLoaded();
      return;
    } 
    updateUserPrivacySettings((MaxAdapterParameters)stringBuilder1);
    loadFullscreenAd((MaxAdapterResponseParameters)stringBuilder1, getContext(paramActivity), new LoadAdCallback() {
          public void onAdLoad(String param1String) {
            VungleMediationAdapter.this.log("App open ad loaded");
            listener.onAppOpenAdLoaded();
          }
          
          public void onError(String param1String, VungleException param1VungleException) {
            MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
            VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("App open ad for placement ");
            stringBuilder.append(param1String);
            stringBuilder.append(" failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            vungleMediationAdapter.log(stringBuilder.toString());
            listener.onAppOpenAdLoadFailed(maxAdapterError);
          }
        });
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxInterstitialAdapterListener listener) {
    StringBuilder stringBuilder1;
    String str1;
    String str3 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str3);
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("interstitial ad for placement: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (!Vungle.isInitialized()) {
      log("Vungle SDK not successfully initialized: failing interstitial ad load...");
      listener.onInterstitialAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    if (!isValidPlacement(paramMaxAdapterResponseParameters)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Interstitial ad failed to load due to an invalid placement id: ");
      stringBuilder1.append(str2);
      log(stringBuilder1.toString());
      listener.onInterstitialAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
      return;
    } 
    if (bool) {
      if (Vungle.canPlayAd(str2, str3)) {
        log("Interstitial ad loaded");
        listener.onInterstitialAdLoaded();
        return;
      } 
    } else if (Vungle.canPlayAd(str2)) {
      log("Interstitial ad loaded");
      listener.onInterstitialAdLoaded();
      return;
    } 
    updateUserPrivacySettings((MaxAdapterParameters)stringBuilder1);
    loadFullscreenAd((MaxAdapterResponseParameters)stringBuilder1, getContext(paramActivity), new LoadAdCallback() {
          public void onAdLoad(String param1String) {
            VungleMediationAdapter.this.log("Interstitial ad loaded");
            listener.onInterstitialAdLoaded();
          }
          
          public void onError(String param1String, VungleException param1VungleException) {
            MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
            VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Interstitial ad for placement ");
            stringBuilder.append(param1String);
            stringBuilder.append(" failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            vungleMediationAdapter.log(stringBuilder.toString());
            listener.onInterstitialAdLoadFailed(maxAdapterError);
          }
        });
  }
  
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    StringBuilder stringBuilder1;
    String str1;
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("native ad for placement: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (!Vungle.isInitialized()) {
      log("Vungle SDK not successfully initialized: failing interstitial ad load...");
      paramMaxNativeAdAdapterListener.onNativeAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    if (!isValidPlacement(paramMaxAdapterResponseParameters)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Native ad failed to load due to an invalid placement id: ");
      stringBuilder1.append(str2);
      log(stringBuilder1.toString());
      paramMaxNativeAdAdapterListener.onNativeAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
      return;
    } 
    Context context = getContext(paramActivity);
    loadVungleNativeAd((MaxAdapterResponseParameters)stringBuilder1, context, new NativeAdListener((MaxAdapterResponseParameters)stringBuilder1, context, paramMaxNativeAdAdapterListener));
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedAdapterListener listener) {
    StringBuilder stringBuilder1;
    String str1;
    String str3 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str3);
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("rewarded ad for placement: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (!Vungle.isInitialized()) {
      log("Vungle SDK not successfully initialized: failing rewarded ad load...");
      listener.onRewardedAdLoadFailed(MaxAdapterError.NOT_INITIALIZED);
      return;
    } 
    if (!isValidPlacement(paramMaxAdapterResponseParameters)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Rewarded ad failed to load due to an invalid placement id: ");
      stringBuilder1.append(str2);
      log(stringBuilder1.toString());
      listener.onRewardedAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
      return;
    } 
    if (bool) {
      if (Vungle.canPlayAd(str2, str3)) {
        log("Rewarded ad loaded");
        listener.onRewardedAdLoaded();
        return;
      } 
    } else if (Vungle.canPlayAd(str2)) {
      log("Rewarded ad loaded");
      listener.onRewardedAdLoaded();
      return;
    } 
    updateUserPrivacySettings((MaxAdapterParameters)stringBuilder1);
    loadFullscreenAd((MaxAdapterResponseParameters)stringBuilder1, getContext(paramActivity), new LoadAdCallback() {
          public void onAdLoad(String param1String) {
            VungleMediationAdapter.this.log("Rewarded ad loaded");
            listener.onRewardedAdLoaded();
          }
          
          public void onError(String param1String, VungleException param1VungleException) {
            MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
            VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded ad for placement ");
            stringBuilder.append(param1String);
            stringBuilder.append(" failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            vungleMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedAdLoadFailed(maxAdapterError);
          }
        });
  }
  
  public void onDestroy() {
    VungleBanner vungleBanner = this.adViewAd;
    if (vungleBanner != null) {
      vungleBanner.destroyAd();
      this.adViewAd = null;
    } 
    NativeAd nativeAd = this.nativeAd;
    if (nativeAd != null) {
      nativeAd.unregisterView();
      this.nativeAd.destroy();
      this.nativeAd = null;
    } 
  }
  
  public void showAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, MaxAppOpenAdapterListener paramMaxAppOpenAdapterListener) {
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str2);
    String str3 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Showing ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("app open ad for placement: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    Context context = getContext(paramActivity);
    if (bool) {
      if (Vungle.canPlayAd(str3, str2)) {
        showFullscreenAd(paramMaxAdapterResponseParameters, context, new AppOpenAdListener(paramMaxAppOpenAdapterListener));
        return;
      } 
    } else if (Vungle.canPlayAd(str3)) {
      showFullscreenAd(paramMaxAdapterResponseParameters, context, new AppOpenAdListener(paramMaxAppOpenAdapterListener));
      return;
    } 
    log("App open ad not ready");
    paramMaxAppOpenAdapterListener.onAppOpenAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "App open ad not ready"));
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str2);
    String str3 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Showing ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("interstitial ad for placement: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (bool) {
      if (Vungle.canPlayAd(str3, str2)) {
        showFullscreenAd(paramMaxAdapterResponseParameters, getContext(paramActivity), new InterstitialAdListener(paramMaxInterstitialAdapterListener));
        return;
      } 
    } else if (Vungle.canPlayAd(str3)) {
      showFullscreenAd(paramMaxAdapterResponseParameters, getContext(paramActivity), new InterstitialAdListener(paramMaxInterstitialAdapterListener));
      return;
    } 
    log("Interstitial ad not ready");
    paramMaxInterstitialAdapterListener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getBidResponse();
    boolean bool = AppLovinSdkUtils.isValidString(str2);
    String str3 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Showing ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("rewarded ad for placement: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    if (bool) {
      if (Vungle.canPlayAd(str3, str2)) {
        configureReward(paramMaxAdapterResponseParameters);
        showFullscreenAd(paramMaxAdapterResponseParameters, getContext(paramActivity), new RewardedAdListener(paramMaxRewardedAdapterListener));
        return;
      } 
    } else if (Vungle.canPlayAd(str3)) {
      configureReward(paramMaxAdapterResponseParameters);
      showFullscreenAd(paramMaxAdapterResponseParameters, getContext(paramActivity), new RewardedAdListener(paramMaxRewardedAdapterListener));
      return;
    } 
    log("Rewarded ad not ready");
    paramMaxRewardedAdapterListener.onRewardedAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
  }
  
  private class AdViewAdListener implements PlayAdCallback {
    private final String adFormatLabel;
    
    private String creativeId;
    
    private final MaxAdViewAdapterListener listener;
    
    AdViewAdListener(String param1String, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.adFormatLabel = param1String;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append("ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad clicked");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdEnd(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad hidden");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdHidden();
    }
    
    public void onAdEnd(String param1String, boolean param1Boolean1, boolean param1Boolean2) {}
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad left application");
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdRewarded(String param1String) {}
    
    public void onAdStart(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad started");
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdViewed(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad displayed");
      vungleMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
        this.listener.onAdViewAdDisplayed(bundle);
        return;
      } 
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormatLabel);
      stringBuilder.append(" ad display failed with error: ");
      stringBuilder.append(maxAdapterError);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayFailed(maxAdapterError);
    }
  }
  
  private class AppOpenAdListener implements PlayAdCallback {
    private String creativeId;
    
    private final MaxAppOpenAdapterListener listener;
    
    AppOpenAdListener(MaxAppOpenAdapterListener param1MaxAppOpenAdapterListener) {
      this.listener = param1MaxAppOpenAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter.this.log("App open ad clicked");
      this.listener.onAppOpenAdClicked();
    }
    
    public void onAdEnd(String param1String) {
      VungleMediationAdapter.this.log("App open ad hidden");
      this.listener.onAppOpenAdHidden();
    }
    
    public void onAdEnd(String param1String, boolean param1Boolean1, boolean param1Boolean2) {}
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter.this.log("App open ad left application");
    }
    
    public void onAdRewarded(String param1String) {}
    
    public void onAdStart(String param1String) {
      VungleMediationAdapter.this.log("App open ad started");
    }
    
    public void onAdViewed(String param1String) {
      VungleMediationAdapter.this.log("App open ad displayed");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
        this.listener.onAppOpenAdDisplayed(bundle);
        return;
      } 
      this.listener.onAppOpenAdDisplayed();
    }
    
    public void onError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad failed to display with error: ");
      stringBuilder.append(maxAdapterError);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayFailed(maxAdapterError);
    }
  }
  
  private class InterstitialAdListener implements PlayAdCallback {
    private String creativeId;
    
    private final MaxInterstitialAdapterListener listener;
    
    InterstitialAdListener(MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter.this.log("Interstitial ad clicked");
      this.listener.onInterstitialAdClicked();
    }
    
    public void onAdEnd(String param1String) {
      VungleMediationAdapter.this.log("Interstitial ad hidden");
      this.listener.onInterstitialAdHidden();
    }
    
    public void onAdEnd(String param1String, boolean param1Boolean1, boolean param1Boolean2) {}
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter.this.log("Interstitial ad left application");
    }
    
    public void onAdRewarded(String param1String) {}
    
    public void onAdStart(String param1String) {
      VungleMediationAdapter.this.log("Interstitial ad started");
    }
    
    public void onAdViewed(String param1String) {
      VungleMediationAdapter.this.log("Interstitial ad displayed");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
        this.listener.onInterstitialAdDisplayed(bundle);
        return;
      } 
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad failed to display with error: ");
      stringBuilder.append(maxAdapterError);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayFailed(maxAdapterError);
    }
  }
  
  private class MaxVungleNativeAd extends MaxNativeAd {
    public MaxVungleNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      NativeAd nativeAd = VungleMediationAdapter.this.nativeAd;
      if (nativeAd == null) {
        VungleMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return;
      } 
      NativeAdLayout nativeAdLayout = new NativeAdLayout(param1MaxNativeAdView.getContext());
      View view = param1MaxNativeAdView.getMainView();
      param1MaxNativeAdView.removeView(view);
      nativeAdLayout.addView(view);
      param1MaxNativeAdView.addView((View)nativeAdLayout);
      nativeAd.registerViewForInteraction(nativeAdLayout, (MediaView)getMediaView(), param1MaxNativeAdView.getIconImageView(), VungleMediationAdapter.this.getClickableViews(param1MaxNativeAdView));
    }
  }
  
  private class NativeAdListener implements com.vungle.warren.NativeAdListener {
    private final Context applicationContext;
    
    private String creativeId;
    
    private final MaxNativeAdAdapterListener listener;
    
    private final Bundle serverParameters;
    
    NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.applicationContext = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad clicked with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdClicked();
    }
    
    public void onAdImpression(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad shown with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
      } else {
        param1String = null;
      } 
      this.listener.onNativeAdDisplayed((Bundle)param1String);
    }
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad left application with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdLoadError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad failed to load with error ");
      stringBuilder.append(maxAdapterError);
      stringBuilder.append(" with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdPlayError(String param1String, VungleException param1VungleException) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad failed to play with error ");
      stringBuilder.append(VungleMediationAdapter.toMaxError(param1VungleException));
      stringBuilder.append(" with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onNativeAdLoaded(NativeAd param1NativeAd) {
      if (VungleMediationAdapter.this.nativeAd == null || VungleMediationAdapter.this.nativeAd != param1NativeAd) {
        VungleMediationAdapter.this.log("Native ad failed to load: no fill");
        this.listener.onNativeAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(VungleMediationAdapter.this.nativeAd.getAdTitle())) {
        VungleMediationAdapter vungleMediationAdapter1 = VungleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ad (");
        stringBuilder1.append(VungleMediationAdapter.this.nativeAd);
        stringBuilder1.append(") does not have required assets.");
        vungleMediationAdapter1.e(stringBuilder1.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad loaded: ");
      stringBuilder.append(VungleMediationAdapter.this.nativeAd.getPlacementId());
      vungleMediationAdapter.log(stringBuilder.toString());
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MediaView mediaView = new MediaView(VungleMediationAdapter.NativeAdListener.this.applicationContext);
              String str = VungleMediationAdapter.this.nativeAd.getAppIcon();
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(VungleMediationAdapter.this.nativeAd.getAdTitle()).setAdvertiser(VungleMediationAdapter.this.nativeAd.getAdSponsoredText()).setBody(VungleMediationAdapter.this.nativeAd.getAdBodyText()).setCallToAction(VungleMediationAdapter.this.nativeAd.getAdCallToActionText()).setIcon(new MaxNativeAd.MaxNativeAdImage(Uri.parse(str))).setMediaView((View)mediaView);
              VungleMediationAdapter.MaxVungleNativeAd maxVungleNativeAd = new VungleMediationAdapter.MaxVungleNativeAd(builder);
              VungleMediationAdapter.NativeAdListener.this.listener.onNativeAdLoaded(maxVungleNativeAd, null);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MediaView mediaView = new MediaView(this.this$1.applicationContext);
      String str = VungleMediationAdapter.this.nativeAd.getAppIcon();
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(MaxAdFormat.NATIVE).setTitle(VungleMediationAdapter.this.nativeAd.getAdTitle()).setAdvertiser(VungleMediationAdapter.this.nativeAd.getAdSponsoredText()).setBody(VungleMediationAdapter.this.nativeAd.getAdBodyText()).setCallToAction(VungleMediationAdapter.this.nativeAd.getAdCallToActionText()).setIcon(new MaxNativeAd.MaxNativeAdImage(Uri.parse(str))).setMediaView((View)mediaView);
      VungleMediationAdapter.MaxVungleNativeAd maxVungleNativeAd = new VungleMediationAdapter.MaxVungleNativeAd(builder);
      this.this$1.listener.onNativeAdLoaded(maxVungleNativeAd, null);
    }
  }
  
  private class NativeAdViewListener implements com.vungle.warren.NativeAdListener {
    private final MaxAdFormat adFormat;
    
    private final Context applicationContext;
    
    private String creativeId;
    
    private final MaxAdViewAdapterListener listener;
    
    private final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Context param1Context, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.adFormat = param1MaxAdFormat;
      this.applicationContext = param1Context;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdImpression(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
      } else {
        param1String = null;
      } 
      this.listener.onAdViewAdDisplayed((Bundle)param1String);
    }
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad left application with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdLoadError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to load with error ");
      stringBuilder.append(maxAdapterError);
      stringBuilder.append(" with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdPlayError(String param1String, VungleException param1VungleException) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad failed to play with error ");
      stringBuilder.append(VungleMediationAdapter.toMaxError(param1VungleException));
      stringBuilder.append(" with placement id: ");
      stringBuilder.append(param1String);
      vungleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onNativeAdLoaded(NativeAd param1NativeAd) {
      if (VungleMediationAdapter.this.nativeAd == null || VungleMediationAdapter.this.nativeAd != param1NativeAd) {
        VungleMediationAdapter vungleMediationAdapter1 = VungleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad failed to load: no fill");
        vungleMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.NO_FILL);
        return;
      } 
      if (TextUtils.isEmpty(VungleMediationAdapter.this.nativeAd.getAdTitle())) {
        VungleMediationAdapter vungleMediationAdapter1 = VungleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Native ");
        stringBuilder1.append(this.adFormat.getLabel());
        stringBuilder1.append(" ad (");
        stringBuilder1.append(VungleMediationAdapter.this.nativeAd);
        stringBuilder1.append(") does not have required assets.");
        vungleMediationAdapter1.e(stringBuilder1.toString());
        this.listener.onAdViewAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(VungleMediationAdapter.this.nativeAd.getPlacementId());
      vungleMediationAdapter.log(stringBuilder.toString());
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              MediaView mediaView = new MediaView(VungleMediationAdapter.NativeAdViewListener.this.applicationContext);
              String str2 = VungleMediationAdapter.this.nativeAd.getAppIcon();
              MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(VungleMediationAdapter.NativeAdViewListener.this.adFormat).setTitle(VungleMediationAdapter.this.nativeAd.getAdTitle()).setAdvertiser(VungleMediationAdapter.this.nativeAd.getAdSponsoredText()).setBody(VungleMediationAdapter.this.nativeAd.getAdBodyText()).setCallToAction(VungleMediationAdapter.this.nativeAd.getAdCallToActionText()).setIcon(new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2))).setMediaView((View)mediaView);
              VungleMediationAdapter.MaxVungleNativeAd maxVungleNativeAd = new VungleMediationAdapter.MaxVungleNativeAd(builder);
              String str1 = BundleUtils.getString("template", "", VungleMediationAdapter.NativeAdViewListener.this.serverParameters);
              if (str1.contains("vertical")) {
                if (AppLovinSdk.VERSION_CODE < 9140500)
                  VungleMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
                if (str1.equals("vertical")) {
                  if (VungleMediationAdapter.NativeAdViewListener.this.adFormat == MaxAdFormat.LEADER) {
                    str1 = "vertical_leader_template";
                  } else {
                    str1 = "vertical_media_banner_template";
                  } 
                  maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, str1, VungleMediationAdapter.NativeAdViewListener.this.applicationContext);
                } else {
                  maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, (String)maxNativeAdView, VungleMediationAdapter.NativeAdViewListener.this.applicationContext);
                } 
              } else {
                MaxNativeAdView maxNativeAdView1;
                if (AppLovinSdk.VERSION_CODE < 9140500) {
                  String str;
                  if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView))
                    str = "no_body_banner_template"; 
                  maxNativeAdView1 = new MaxNativeAdView(maxVungleNativeAd, str, VungleMediationAdapter.NativeAdViewListener.this.applicationContext);
                } else {
                  String str;
                  if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView1))
                    str = "media_banner_template"; 
                  maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, str, VungleMediationAdapter.NativeAdViewListener.this.applicationContext);
                } 
              } 
              maxVungleNativeAd.prepareViewForInteraction(maxNativeAdView);
              VungleMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)maxNativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      MediaView mediaView = new MediaView(this.this$1.applicationContext);
      String str2 = VungleMediationAdapter.this.nativeAd.getAppIcon();
      MaxNativeAd.Builder builder = (new MaxNativeAd.Builder()).setAdFormat(this.this$1.adFormat).setTitle(VungleMediationAdapter.this.nativeAd.getAdTitle()).setAdvertiser(VungleMediationAdapter.this.nativeAd.getAdSponsoredText()).setBody(VungleMediationAdapter.this.nativeAd.getAdBodyText()).setCallToAction(VungleMediationAdapter.this.nativeAd.getAdCallToActionText()).setIcon(new MaxNativeAd.MaxNativeAdImage(Uri.parse(str2))).setMediaView((View)mediaView);
      VungleMediationAdapter.MaxVungleNativeAd maxVungleNativeAd = new VungleMediationAdapter.MaxVungleNativeAd(builder);
      String str1 = BundleUtils.getString("template", "", this.this$1.serverParameters);
      if (str1.contains("vertical")) {
        if (AppLovinSdk.VERSION_CODE < 9140500)
          VungleMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
        if (str1.equals("vertical")) {
          if (this.this$1.adFormat == MaxAdFormat.LEADER) {
            str1 = "vertical_leader_template";
          } else {
            str1 = "vertical_media_banner_template";
          } 
          maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, str1, this.this$1.applicationContext);
        } else {
          maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, (String)maxNativeAdView, this.this$1.applicationContext);
        } 
      } else {
        MaxNativeAdView maxNativeAdView1;
        if (AppLovinSdk.VERSION_CODE < 9140500) {
          String str;
          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView))
            str = "no_body_banner_template"; 
          maxNativeAdView1 = new MaxNativeAdView(maxVungleNativeAd, str, this.this$1.applicationContext);
        } else {
          String str;
          if (!AppLovinSdkUtils.isValidString((String)maxNativeAdView1))
            str = "media_banner_template"; 
          maxNativeAdView = new MaxNativeAdView(maxVungleNativeAd, str, this.this$1.applicationContext);
        } 
      } 
      maxVungleNativeAd.prepareViewForInteraction(maxNativeAdView);
      this.this$1.listener.onAdViewAdLoaded((View)maxNativeAdView);
    }
  }
  
  private class RewardedAdListener implements PlayAdCallback {
    private String creativeId;
    
    private boolean hasGrantedReward;
    
    private final MaxRewardedAdapterListener listener;
    
    RewardedAdListener(MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void creativeId(String param1String) {
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad with creative id: ");
      stringBuilder.append(param1String);
      stringBuilder.append(" will be played");
      vungleMediationAdapter.log(stringBuilder.toString());
      this.creativeId = param1String;
    }
    
    public void onAdClick(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad clicked");
      this.listener.onRewardedAdClicked();
    }
    
    public void onAdEnd(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad video completed");
      this.listener.onRewardedAdVideoCompleted();
      if (this.hasGrantedReward || VungleMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = VungleMediationAdapter.this.getReward();
        VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Rewarded user with reward: ");
        stringBuilder.append(maxReward);
        vungleMediationAdapter.log(stringBuilder.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      VungleMediationAdapter.this.log("Rewarded ad hidden");
      this.listener.onRewardedAdHidden();
    }
    
    public void onAdEnd(String param1String, boolean param1Boolean1, boolean param1Boolean2) {}
    
    public void onAdLeftApplication(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad left application");
    }
    
    public void onAdRewarded(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad user did earn reward");
      this.hasGrantedReward = true;
    }
    
    public void onAdStart(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad started");
    }
    
    public void onAdViewed(String param1String) {
      VungleMediationAdapter.this.log("Rewarded ad displayed");
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString(this.creativeId)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", this.creativeId);
        this.listener.onRewardedAdDisplayed(bundle);
      } else {
        this.listener.onRewardedAdDisplayed();
      } 
      this.listener.onRewardedAdVideoStarted();
    }
    
    public void onError(String param1String, VungleException param1VungleException) {
      MaxAdapterError maxAdapterError = VungleMediationAdapter.toMaxError(param1VungleException);
      VungleMediationAdapter vungleMediationAdapter = VungleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad failed to display with error: ");
      stringBuilder.append(maxAdapterError);
      vungleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayFailed(maxAdapterError);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\mediation\adapters\VungleMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */