package com.applovin.mediation.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxRewardedInterstitialAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAppOpenAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.ads.query.QueryInfoGenerationCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class GoogleMediationAdapter extends MediationAdapterBase implements MaxSignalProvider, MaxInterstitialAdapter, MaxRewardedInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter {
  private static final AtomicBoolean initialized = new AtomicBoolean();
  
  private static MaxAdapter.InitializationStatus status;
  
  private AdView adView;
  
  private AppOpenAd appOpenAd;
  
  private AppOpenAdListener appOpenAdListener;
  
  private InterstitialAd appOpenInterstitialAd;
  
  private AppOpenAdListener appOpenInterstitialAdListener;
  
  private InterstitialAd interstitialAd;
  
  private NativeAd nativeAd;
  
  private NativeAdView nativeAdView;
  
  private RewardedAd rewardedAd;
  
  private RewardedAdListener rewardedAdListener;
  
  private RewardedInterstitialAd rewardedInterstitialAd;
  
  private RewardedInterstitialAdListener rewardedInterstitialAdListener;
  
  public GoogleMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  @SuppressLint({"ApplySharedPref"})
  private AdRequest createAdRequestWithParameters(boolean paramBoolean, MaxAdFormat paramMaxAdFormat, MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    AdRequest.Builder builder = new AdRequest.Builder();
    Bundle bundle2 = paramMaxAdapterParameters.getServerParameters();
    Bundle bundle1 = new Bundle(6);
    if (paramBoolean) {
      String str1;
      boolean bool1 = "dv360".equalsIgnoreCase(BundleUtils.getString("bidder", "", bundle2));
      if (bool1) {
        str1 = "requester_type_3";
      } else {
        str1 = "requester_type_2";
      } 
      bundle1.putString("query_info_type", str1);
      paramBoolean = bool1;
      if (paramMaxAdapterParameters instanceof MaxAdapterResponseParameters) {
        str1 = ((MaxAdapterResponseParameters)paramMaxAdapterParameters).getBidResponse();
        paramBoolean = bool1;
        if (AppLovinSdkUtils.isValidString(str1)) {
          builder.setAdString(str1);
          paramBoolean = bool1;
        } 
      } 
    } else {
      paramBoolean = false;
    } 
    if (bundle2.getBoolean("set_mediation_identifier", true)) {
      String str1;
      if (paramBoolean) {
        str1 = "applovin_dv360";
      } else {
        str1 = "applovin";
      } 
      builder.setRequestAgent(str1);
    } 
    String str = BundleUtils.getString("event_id", bundle2);
    if (AppLovinSdkUtils.isValidString(str))
      bundle1.putString("placement_req_id", str); 
    Boolean bool = getPrivacySetting("hasUserConsent", paramMaxAdapterParameters);
    if (bool != null && !bool.booleanValue())
      bundle1.putString("npa", "1"); 
    int i = AppLovinSdk.VERSION_CODE;
    if (i >= 91100) {
      bool = getPrivacySetting("isDoNotSell", paramMaxAdapterParameters);
      if (bool != null && bool.booleanValue()) {
        bundle1.putInt("rdp", 1);
        PreferenceManager.getDefaultSharedPreferences(paramContext).edit().putInt("gad_rdp", 1).commit();
      } 
    } 
    if (i >= 11000000) {
      Map map = paramMaxAdapterParameters.getLocalExtraParameters();
      paramMaxAdapterParameters = (MaxAdapterParameters)map.get("google_max_ad_content_rating");
      if (paramMaxAdapterParameters instanceof String)
        bundle1.putString("max_ad_content_rating", (String)paramMaxAdapterParameters); 
      paramMaxAdapterParameters = (MaxAdapterParameters)map.get("google_content_url");
      if (paramMaxAdapterParameters instanceof String)
        builder.setContentUrl((String)paramMaxAdapterParameters); 
      map = (Map)map.get("google_neighbouring_content_url_strings");
      if (map instanceof List)
        try {
          builder.setNeighboringContentUrls((List)map);
        } finally {
          map = null;
        }  
    } 
    builder.addNetworkExtrasBundle(AdMobAdapter.class, bundle1);
    return builder.build();
  }
  
  private int getAdChoicesPlacement(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    int j = AppLovinSdk.VERSION_CODE;
    byte b = 1;
    int i = b;
    if (j >= 11000000) {
      Map map = paramMaxAdapterResponseParameters.getLocalExtraParameters();
      if (map != null) {
        map = (Map)map.get("admob_ad_choices_placement");
      } else {
        map = null;
      } 
      i = b;
      if (isValidAdChoicesPlacement(map))
        i = ((Integer)map).intValue(); 
    } 
    return i;
  }
  
  private int getAdaptiveBannerWidth(MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    if (AppLovinSdk.VERSION_CODE >= 11000000) {
      paramMaxAdapterParameters = (MaxAdapterParameters)paramMaxAdapterParameters.getLocalExtraParameters().get("adaptive_banner_width");
      if (paramMaxAdapterParameters instanceof Integer)
        return ((Integer)paramMaxAdapterParameters).intValue(); 
      if (paramMaxAdapterParameters != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Expected parameter \"adaptive_banner_width\" to be of type Integer, received: ");
        stringBuilder.append(paramMaxAdapterParameters.getClass());
        e(stringBuilder.toString());
      } 
    } 
    Display display = ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay();
    DisplayMetrics displayMetrics = new DisplayMetrics();
    display.getMetrics(displayMetrics);
    return AppLovinSdkUtils.pxToDp(paramContext, displayMetrics.widthPixels);
  }
  
  private Context getContext(@Nullable Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private Boolean getPrivacySetting(String paramString, MaxAdapterParameters paramMaxAdapterParameters) {
    try {
      return (Boolean)paramMaxAdapterParameters.getClass().getMethod(paramString, new Class[0]).invoke(paramMaxAdapterParameters, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Error getting privacy setting ");
      stringBuilder.append(paramString);
      stringBuilder.append(" with exception: ");
      log(stringBuilder.toString(), exception);
      return (AppLovinSdk.VERSION_CODE >= 9140000) ? null : Boolean.FALSE;
    } 
  }
  
  private boolean isValidAdChoicesPlacement(Object paramObject) {
    null = paramObject instanceof Integer;
    boolean bool = true;
    if (null) {
      paramObject = paramObject;
      null = bool;
      if (paramObject.intValue() != 0) {
        null = bool;
        if (paramObject.intValue() != 1) {
          null = bool;
          if (paramObject.intValue() != 3) {
            if (paramObject.intValue() == 2)
              return true; 
          } else {
            return null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
    } 
    return false;
  }
  
  private void setRequestConfiguration(MaxAdapterParameters paramMaxAdapterParameters) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private AdFormat toAdFormat(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters) {
    boolean bool;
    MaxAdFormat maxAdFormat = paramMaxAdapterSignalCollectionParameters.getAdFormat();
    if (paramMaxAdapterSignalCollectionParameters.getServerParameters().getBoolean("is_native") || maxAdFormat == MaxAdFormat.NATIVE) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? AdFormat.NATIVE : (maxAdFormat.isAdViewAd() ? AdFormat.BANNER : ((maxAdFormat == MaxAdFormat.INTERSTITIAL) ? AdFormat.INTERSTITIAL : ((maxAdFormat == MaxAdFormat.REWARDED) ? AdFormat.REWARDED : ((maxAdFormat == MaxAdFormat.REWARDED_INTERSTITIAL) ? AdFormat.REWARDED_INTERSTITIAL : AdFormat.UNKNOWN))));
  }
  
  private AdSize toAdSize(MaxAdFormat paramMaxAdFormat, boolean paramBoolean, MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    MaxAdFormat maxAdFormat = MaxAdFormat.BANNER;
    if (paramMaxAdFormat == maxAdFormat || paramMaxAdFormat == MaxAdFormat.LEADER)
      return paramBoolean ? AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(paramContext, getAdaptiveBannerWidth(paramMaxAdapterParameters, paramContext)) : ((paramMaxAdFormat == maxAdFormat) ? AdSize.BANNER : AdSize.LEADERBOARD); 
    if (paramMaxAdFormat == MaxAdFormat.MREC)
      return AdSize.MEDIUM_RECTANGLE; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported ad format: ");
    stringBuilder.append(paramMaxAdFormat);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static MaxAdapterError toMaxError(AdError paramAdError) {
    int i = paramAdError.getCode();
    MaxAdapterError maxAdapterError = MaxAdapterError.UNSPECIFIED;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            switch (i) {
              default:
                return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), i, paramAdError.getMessage());
              case 8:
              case 11:
                maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
              case 9:
                maxAdapterError = MaxAdapterError.NO_FILL;
              case 10:
                break;
            } 
          } else {
          
          } 
        } else {
          maxAdapterError = MaxAdapterError.NO_CONNECTION;
        }  
      maxAdapterError = MaxAdapterError.BAD_REQUEST;
    } 
    maxAdapterError = MaxAdapterError.INTERNAL_ERROR;
  }
  
  private static void updateMuteState(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    Bundle bundle = paramMaxAdapterResponseParameters.getServerParameters();
    if (bundle.containsKey("is_muted"))
      MobileAds.setAppMuted(bundle.getBoolean("is_muted")); 
  }
  
  public void collectSignal(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, Activity paramActivity, final MaxSignalCollectionListener callback) {
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters);
    Context context = getContext(paramActivity);
    AdRequest adRequest = createAdRequestWithParameters(true, paramMaxAdapterSignalCollectionParameters.getAdFormat(), (MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters, context);
    QueryInfo.generate(context, toAdFormat(paramMaxAdapterSignalCollectionParameters), adRequest, new QueryInfoGenerationCallback() {
          public void onFailure(@NonNull String param1String) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Signal collection failed with error: ");
            stringBuilder.append(param1String);
            googleMediationAdapter.log(stringBuilder.toString());
            callback.onSignalCollectionFailed(param1String);
          }
          
          public void onSuccess(@NonNull QueryInfo param1QueryInfo) {
            GoogleMediationAdapter.this.log("Signal collection successful");
            callback.onSignalCollected(param1QueryInfo.getQuery());
          }
        });
  }
  
  public String getAdapterVersion() {
    return "22.0.0.0";
  }
  
  public String getSdkVersion() {
    return String.valueOf(MobileAds.getVersion());
  }
  
  @SuppressLint({"MissingPermission"})
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, final MaxAdapter.OnCompletionListener onCompletionListener) {
    log("Initializing Google SDK...");
    if (initialized.compareAndSet(false, true)) {
      Context context = getContext(paramActivity);
      MobileAds.disableMediationAdapterInitialization(context);
      if (paramMaxAdapterInitializationParameters.getServerParameters().getBoolean("init_without_callback", false)) {
        status = MaxAdapter.InitializationStatus.DOES_NOT_APPLY;
        MobileAds.initialize(context);
        onCompletionListener.onCompletion(status, null);
        return;
      } 
      status = MaxAdapter.InitializationStatus.INITIALIZING;
      MobileAds.initialize(context, new OnInitializationCompleteListener() {
            public void onInitializationComplete(@NonNull InitializationStatus param1InitializationStatus) {
              MaxAdapter.InitializationStatus initializationStatus;
              AdapterStatus adapterStatus = (AdapterStatus)param1InitializationStatus.getAdapterStatusMap().get("com.google.android.gms.ads.MobileAds");
              if (adapterStatus != null) {
                AdapterStatus.State state = adapterStatus.getInitializationState();
              } else {
                adapterStatus = null;
              } 
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Initialization complete with status ");
              stringBuilder.append(adapterStatus);
              googleMediationAdapter.log(stringBuilder.toString());
              if (AdapterStatus.State.READY == adapterStatus) {
                initializationStatus = MaxAdapter.InitializationStatus.INITIALIZED_SUCCESS;
              } else {
                initializationStatus = MaxAdapter.InitializationStatus.INITIALIZED_UNKNOWN;
              } 
              GoogleMediationAdapter.access$002(initializationStatus);
              onCompletionListener.onCompletion(GoogleMediationAdapter.status, null);
            }
          });
      return;
    } 
    onCompletionListener.onCompletion(status, null);
  }
  
  @SuppressLint({"MissingPermission"})
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, MaxAdViewAdapterListener paramMaxAdViewAdapterListener) {
    NativeAdViewListener nativeAdViewListener;
    String str3 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool3 = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    boolean bool4 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    String str2 = "";
    if (bool3) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    String str1 = str2;
    if (bool4)
      str1 = "native "; 
    stringBuilder.append(str1);
    stringBuilder.append(paramMaxAdFormat.getLabel());
    stringBuilder.append(" ad for placement id: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    AdRequest adRequest = createAdRequestWithParameters(bool3, paramMaxAdFormat, (MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    boolean bool2 = false;
    boolean bool1 = false;
    if (bool4) {
      NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
      builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
      if (paramMaxAdFormat == MaxAdFormat.MREC)
        bool1 = true; 
      builder.setRequestMultipleImages(bool1);
      nativeAdViewListener = new NativeAdViewListener(paramMaxAdapterResponseParameters, paramMaxAdFormat, paramActivity, paramMaxAdViewAdapterListener);
      (new AdLoader.Builder(context, str3)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdViewListener).withAdListener(nativeAdViewListener).build().loadAd(adRequest);
      return;
    } 
    AdView adView = new AdView(context);
    this.adView = adView;
    adView.setAdUnitId(str3);
    this.adView.setAdListener(new AdViewListener(str3, paramMaxAdFormat, paramMaxAdViewAdapterListener));
    if (bool3) {
      bool1 = bool2;
    } else {
      bool1 = nativeAdViewListener.getServerParameters().getBoolean("adaptive_banner", false);
    } 
    this.adView.setAdSize(toAdSize(paramMaxAdFormat, bool1, (MaxAdapterParameters)nativeAdViewListener, context));
    this.adView.loadAd(adRequest);
  }
  
  public void loadAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, final MaxAppOpenAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool1 = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    boolean bool2 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_inter_placement");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    String str2 = "";
    if (bool1) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("app open ");
    String str1 = str2;
    if (bool2)
      str1 = "interstitial "; 
    stringBuilder.append(str1);
    stringBuilder.append("ad: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    if (bool2) {
      InterstitialAd.load(context, str3, createAdRequestWithParameters(bool1, MaxAdFormat.INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new InterstitialAdLoadCallback() {
            public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
              MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("App open interstitial ad (");
              stringBuilder.append(placementId);
              stringBuilder.append(") failed to load with error: ");
              stringBuilder.append(maxAdapterError);
              googleMediationAdapter.log(stringBuilder.toString());
              listener.onAppOpenAdLoadFailed(maxAdapterError);
            }
            
            public void onAdLoaded(@NonNull InterstitialAd param1InterstitialAd) {
              GoogleMediationAdapter googleMediationAdapter2 = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("App open interstitial ad loaded: ");
              stringBuilder.append(placementId);
              stringBuilder.append("...");
              googleMediationAdapter2.log(stringBuilder.toString());
              GoogleMediationAdapter.access$302(GoogleMediationAdapter.this, param1InterstitialAd);
              GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
              GoogleMediationAdapter.access$402(googleMediationAdapter1, new GoogleMediationAdapter.AppOpenAdListener(placementId, listener));
              GoogleMediationAdapter.this.appOpenInterstitialAd.setFullScreenContentCallback(GoogleMediationAdapter.this.appOpenInterstitialAdListener);
              ResponseInfo responseInfo = GoogleMediationAdapter.this.appOpenInterstitialAd.getResponseInfo();
              if (responseInfo != null) {
                String str = responseInfo.getResponseId();
              } else {
                responseInfo = null;
              } 
              if (AppLovinSdkUtils.isValidString((String)responseInfo)) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", (String)responseInfo);
                listener.onAppOpenAdLoaded(bundle);
                return;
              } 
              listener.onAppOpenAdLoaded();
            }
          });
      return;
    } 
    AppOpenAd.load(context, str3, createAdRequestWithParameters(bool1, MaxAdFormat.APP_OPEN, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), AppLovinSdkUtils.getOrientation(context), new AppOpenAd.AppOpenAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("App open ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onAppOpenAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull AppOpenAd param1AppOpenAd) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("App open ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$502(GoogleMediationAdapter.this, param1AppOpenAd);
            googleMediationAdapter = GoogleMediationAdapter.this;
            GoogleMediationAdapter.access$602(googleMediationAdapter, new GoogleMediationAdapter.AppOpenAdListener(placementId, listener));
            param1AppOpenAd.setFullScreenContentCallback(GoogleMediationAdapter.this.appOpenAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.appOpenAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onAppOpenAdLoaded(bundle);
              return;
            } 
            listener.onAppOpenAdLoaded();
          }
        });
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxInterstitialAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("interstitial ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    InterstitialAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new InterstitialAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull InterstitialAd param1InterstitialAd) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Interstitial ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$102(GoogleMediationAdapter.this, param1InterstitialAd);
            GoogleMediationAdapter.this.interstitialAd.setFullScreenContentCallback(new GoogleMediationAdapter.InterstitialAdListener(placementId, listener));
            ResponseInfo responseInfo = GoogleMediationAdapter.this.interstitialAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onInterstitialAdLoaded();
          }
        });
  }
  
  @SuppressLint({"MissingPermission"})
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    Context context;
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append(" native ad for placement id: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    if (paramActivity != null) {
      context = paramActivity.getApplicationContext();
    } else {
      context = getApplicationContext();
    } 
    AdRequest adRequest = createAdRequestWithParameters(bool, MaxAdFormat.NATIVE, (MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
    builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
    builder.setRequestMultipleImages(BundleUtils.getString("template", "", paramMaxAdapterResponseParameters.getServerParameters()).contains("medium"));
    NativeAdListener nativeAdListener = new NativeAdListener(paramMaxAdapterResponseParameters, context, paramMaxNativeAdAdapterListener);
    (new AdLoader.Builder(context, str2)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdListener).withAdListener(nativeAdListener).build().loadAd(adRequest);
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("rewarded ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.REWARDED, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull RewardedAd param1RewardedAd) {
            GoogleMediationAdapter googleMediationAdapter2 = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter2.log(stringBuilder.toString());
            GoogleMediationAdapter.access$1102(GoogleMediationAdapter.this, param1RewardedAd);
            GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
            GoogleMediationAdapter.access$1202(googleMediationAdapter1, new GoogleMediationAdapter.RewardedAdListener(placementId, listener));
            GoogleMediationAdapter.this.rewardedAd.setFullScreenContentCallback(GoogleMediationAdapter.this.rewardedAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.rewardedAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onRewardedAdLoaded(bundle);
              return;
            } 
            listener.onRewardedAdLoaded();
          }
        });
  }
  
  public void loadRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedInterstitialAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("rewarded interstitial ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedInterstitialAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.REWARDED_INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedInterstitialAdLoadCallback() {
          public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(@NonNull RewardedInterstitialAd param1RewardedInterstitialAd) {
            String str1;
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Rewarded interstitial ad loaded: ");
            stringBuilder.append(placementId);
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$702(GoogleMediationAdapter.this, param1RewardedInterstitialAd);
            googleMediationAdapter = GoogleMediationAdapter.this;
            String str2 = placementId;
            MaxRewardedInterstitialAdapterListener maxRewardedInterstitialAdapterListener = listener;
            param1RewardedInterstitialAd = null;
            GoogleMediationAdapter.access$802(googleMediationAdapter, new GoogleMediationAdapter.RewardedInterstitialAdListener(str2, maxRewardedInterstitialAdapterListener));
            GoogleMediationAdapter.this.rewardedInterstitialAd.setFullScreenContentCallback(GoogleMediationAdapter.this.rewardedInterstitialAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.rewardedInterstitialAd.getResponseInfo();
            if (responseInfo != null)
              str1 = responseInfo.getResponseId(); 
            if (AppLovinSdk.VERSION_CODE > 9150000 && AppLovinSdkUtils.isValidString(str1)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", str1);
              listener.onRewardedInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onRewardedInterstitialAdLoaded();
          }
        });
  }
  
  public void onDestroy() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Destroy called for adapter ");
    stringBuilder.append(this);
    log(stringBuilder.toString());
    InterstitialAd interstitialAd2 = this.interstitialAd;
    if (interstitialAd2 != null) {
      interstitialAd2.setFullScreenContentCallback(null);
      this.interstitialAd = null;
    } 
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.setFullScreenContentCallback(null);
      this.appOpenAd = null;
      this.appOpenAdListener = null;
    } 
    InterstitialAd interstitialAd1 = this.appOpenInterstitialAd;
    if (interstitialAd1 != null) {
      interstitialAd1.setFullScreenContentCallback(null);
      this.appOpenInterstitialAd = null;
      this.appOpenInterstitialAdListener = null;
    } 
    RewardedInterstitialAd rewardedInterstitialAd = this.rewardedInterstitialAd;
    if (rewardedInterstitialAd != null) {
      rewardedInterstitialAd.setFullScreenContentCallback(null);
      this.rewardedInterstitialAd = null;
      this.rewardedInterstitialAdListener = null;
    } 
    RewardedAd rewardedAd = this.rewardedAd;
    if (rewardedAd != null) {
      rewardedAd.setFullScreenContentCallback(null);
      this.rewardedAd = null;
      this.rewardedAdListener = null;
    } 
    AdView adView = this.adView;
    if (adView != null) {
      adView.destroy();
      this.adView = null;
    } 
    NativeAd nativeAd = this.nativeAd;
    if (nativeAd != null) {
      nativeAd.destroy();
      this.nativeAd = null;
    } 
    NativeAdView nativeAdView = this.nativeAdView;
    if (nativeAdView != null) {
      nativeAdView.destroy();
      this.nativeAdView = null;
    } 
  }
  
  public void showAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, @Nullable Activity paramActivity, MaxAppOpenAdapterListener paramMaxAppOpenAdapterListener) {
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_inter_placement");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing app open ");
    if (bool) {
      str1 = "interstitial ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("ad: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    InterstitialAd interstitialAd = this.appOpenInterstitialAd;
    if (interstitialAd != null) {
      interstitialAd.show(paramActivity);
      return;
    } 
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("App open ad failed to show: ");
    stringBuilder1.append(str2);
    log(stringBuilder1.toString());
    paramMaxAppOpenAdapterListener.onAppOpenAdLoadFailed(new MaxAdapterError(-4205, "Ad display failed", 0, "App open ad not ready"));
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    InterstitialAd interstitialAd = this.interstitialAd;
    if (interstitialAd != null) {
      interstitialAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxInterstitialAdapterListener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing rewarded ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(@NonNull RewardItem param1RewardItem) {
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Rewarded ad user earned reward: ");
              stringBuilder.append(placementId);
              googleMediationAdapter.log(stringBuilder.toString());
              GoogleMediationAdapter.RewardedAdListener.access$1302(GoogleMediationAdapter.this.rewardedAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Rewarded ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedAdapterListener.onRewardedAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
  }
  
  public void showRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedInterstitialAdapterListener paramMaxRewardedInterstitialAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Showing rewarded interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedInterstitialAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedInterstitialAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(@NonNull RewardItem param1RewardItem) {
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Rewarded interstitial ad user earned reward: ");
              stringBuilder.append(placementId);
              googleMediationAdapter.log(stringBuilder.toString());
              GoogleMediationAdapter.RewardedInterstitialAdListener.access$1002(GoogleMediationAdapter.this.rewardedInterstitialAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Rewarded interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedInterstitialAdapterListener.onRewardedInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded Interstitial ad not ready"));
  }
  
  private class AdViewListener extends AdListener {
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    AdViewListener(String param1String, MaxAdFormat param1MaxAdFormat, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1String;
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error code: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdLoaded() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdk.VERSION_CODE >= 9150000) {
        Bundle bundle = new Bundle(3);
        ResponseInfo responseInfo = GoogleMediationAdapter.this.adView.getResponseInfo();
        if (responseInfo != null) {
          String str = responseInfo.getResponseId();
        } else {
          responseInfo = null;
        } 
        if (AppLovinSdkUtils.isValidString((String)responseInfo))
          bundle.putString("creative_id", (String)responseInfo); 
        AdSize adSize = GoogleMediationAdapter.this.adView.getAdSize();
        if (adSize != null) {
          bundle.putInt("ad_width", adSize.getWidth());
          bundle.putInt("ad_height", adSize.getHeight());
        } 
        this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.adView, bundle);
        return;
      } 
      this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.adView);
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
  }
  
  private class AppOpenAdListener extends FullScreenContentCallback {
    private final MaxAppOpenAdapterListener listener;
    
    private final String placementId;
    
    AppOpenAdListener(String param1String, MaxAppOpenAdapterListener param1MaxAppOpenAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxAppOpenAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad display failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("App open ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class InterstitialAdListener extends FullScreenContentCallback {
    private final MaxInterstitialAdapterListener listener;
    
    private final String placementId;
    
    InterstitialAdListener(String param1String, MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class MaxGoogleNativeAd extends MaxNativeAd {
    public MaxGoogleNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      NativeAd nativeAd = GoogleMediationAdapter.this.nativeAd;
      if (nativeAd == null) {
        GoogleMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return;
      } 
      GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(param1MaxNativeAdView.getContext()));
      View view2 = param1MaxNativeAdView.getMainView();
      param1MaxNativeAdView.removeView(view2);
      GoogleMediationAdapter.this.nativeAdView.addView(view2);
      param1MaxNativeAdView.addView((View)GoogleMediationAdapter.this.nativeAdView);
      GoogleMediationAdapter.this.nativeAdView.setIconView((View)param1MaxNativeAdView.getIconImageView());
      GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)param1MaxNativeAdView.getTitleTextView());
      GoogleMediationAdapter.this.nativeAdView.setAdvertiserView((View)param1MaxNativeAdView.getAdvertiserTextView());
      GoogleMediationAdapter.this.nativeAdView.setBodyView((View)param1MaxNativeAdView.getBodyTextView());
      GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)param1MaxNativeAdView.getCallToActionButton());
      View view1 = getMediaView();
      if (view1 instanceof MediaView) {
        GoogleMediationAdapter.this.nativeAdView.setMediaView((MediaView)view1);
      } else if (view1 instanceof android.widget.ImageView) {
        GoogleMediationAdapter.this.nativeAdView.setImageView(view1);
      } 
      GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
    }
  }
  
  private class NativeAdListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final Context context;
    
    final MaxNativeAdAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    public NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.context = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter.this.log("Native ad clicked");
      this.listener.onNativeAdClicked();
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter.this.log("Native ad closed");
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter.this.log("Native ad shown");
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter.this.log("Native ad opened");
    }
    
    public void onNativeAdLoaded(@NonNull final NativeAd nativeAd) {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      GoogleMediationAdapter.access$1502(GoogleMediationAdapter.this, nativeAd);
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleMediationAdapter = GoogleMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ad (");
        stringBuilder.append(nativeAd);
        stringBuilder.append(") does not have required assets.");
        googleMediationAdapter.e(stringBuilder.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              // Byte code:
              //   0: aload_0
              //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
              //   7: astore #5
              //   9: aload_0
              //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   13: invokevirtual getImages : ()Ljava/util/List;
              //   16: astore_3
              //   17: aconst_null
              //   18: astore #6
              //   20: aload #5
              //   22: ifnull -> 66
              //   25: new com/google/android/gms/ads/nativead/MediaView
              //   28: dup
              //   29: aload_0
              //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   33: getfield context : Landroid/content/Context;
              //   36: invokespecial <init> : (Landroid/content/Context;)V
              //   39: astore_3
              //   40: aload_3
              //   41: aload #5
              //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
              //   46: aload #5
              //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
              //   53: astore #4
              //   55: aload #5
              //   57: invokeinterface getAspectRatio : ()F
              //   62: fstore_1
              //   63: goto -> 151
              //   66: aload_3
              //   67: ifnull -> 144
              //   70: aload_3
              //   71: invokeinterface size : ()I
              //   76: ifle -> 144
              //   79: aload_3
              //   80: iconst_0
              //   81: invokeinterface get : (I)Ljava/lang/Object;
              //   86: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
              //   89: astore #4
              //   91: new android/widget/ImageView
              //   94: dup
              //   95: aload_0
              //   96: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   99: getfield context : Landroid/content/Context;
              //   102: invokespecial <init> : (Landroid/content/Context;)V
              //   105: astore_3
              //   106: aload #4
              //   108: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   111: astore #4
              //   113: aload #4
              //   115: ifnull -> 144
              //   118: aload_3
              //   119: aload #4
              //   121: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
              //   124: aload #4
              //   126: invokevirtual getIntrinsicWidth : ()I
              //   129: i2f
              //   130: aload #4
              //   132: invokevirtual getIntrinsicHeight : ()I
              //   135: i2f
              //   136: fdiv
              //   137: fstore_1
              //   138: aconst_null
              //   139: astore #4
              //   141: goto -> 151
              //   144: fconst_0
              //   145: fstore_1
              //   146: aconst_null
              //   147: astore_3
              //   148: aload_3
              //   149: astore #4
              //   151: aload_0
              //   152: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   155: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
              //   158: astore #5
              //   160: aload #5
              //   162: ifnull -> 207
              //   165: aload #5
              //   167: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   170: ifnull -> 190
              //   173: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   176: dup
              //   177: aload #5
              //   179: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   182: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   185: astore #5
              //   187: goto -> 210
              //   190: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   193: dup
              //   194: aload #5
              //   196: invokevirtual getUri : ()Landroid/net/Uri;
              //   199: invokespecial <init> : (Landroid/net/Uri;)V
              //   202: astore #5
              //   204: goto -> 210
              //   207: aconst_null
              //   208: astore #5
              //   210: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
              //   213: dup
              //   214: invokespecial <init> : ()V
              //   217: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
              //   220: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   223: aload #5
              //   225: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   228: aload_0
              //   229: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   232: invokevirtual getHeadline : ()Ljava/lang/String;
              //   235: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   238: aload_0
              //   239: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   242: invokevirtual getAdvertiser : ()Ljava/lang/String;
              //   245: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   248: aload_0
              //   249: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   252: invokevirtual getBody : ()Ljava/lang/String;
              //   255: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   258: aload_3
              //   259: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   262: aload_0
              //   263: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   266: invokevirtual getCallToAction : ()Ljava/lang/String;
              //   269: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   272: astore_3
              //   273: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
              //   276: istore_2
              //   277: iload_2
              //   278: ldc 11040399
              //   280: if_icmplt -> 297
              //   283: aload_3
              //   284: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   287: dup
              //   288: aload #4
              //   290: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   293: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   296: pop
              //   297: iload_2
              //   298: ldc 11040000
              //   300: if_icmplt -> 309
              //   303: aload_3
              //   304: fload_1
              //   305: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   308: pop
              //   309: iload_2
              //   310: ldc 11070000
              //   312: if_icmplt -> 327
              //   315: aload_3
              //   316: aload_0
              //   317: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   320: invokevirtual getStarRating : ()Ljava/lang/Double;
              //   323: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   326: pop
              //   327: new com/applovin/mediation/adapters/GoogleMediationAdapter$MaxGoogleNativeAd
              //   330: dup
              //   331: aload_0
              //   332: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   335: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter;
              //   338: aload_3
              //   339: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
              //   342: astore #4
              //   344: aload_0
              //   345: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   348: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
              //   351: astore #5
              //   353: aload #6
              //   355: astore_3
              //   356: aload #5
              //   358: ifnull -> 367
              //   361: aload #5
              //   363: invokevirtual getResponseId : ()Ljava/lang/String;
              //   366: astore_3
              //   367: new android/os/Bundle
              //   370: dup
              //   371: iconst_1
              //   372: invokespecial <init> : (I)V
              //   375: astore #5
              //   377: aload #5
              //   379: ldc 'creative_id'
              //   381: aload_3
              //   382: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
              //   385: aload_0
              //   386: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   389: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
              //   392: aload #4
              //   394: aload #5
              //   396: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
              //   401: return
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
      //   7: astore #5
      //   9: aload_0
      //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   13: invokevirtual getImages : ()Ljava/util/List;
      //   16: astore_3
      //   17: aconst_null
      //   18: astore #6
      //   20: aload #5
      //   22: ifnull -> 66
      //   25: new com/google/android/gms/ads/nativead/MediaView
      //   28: dup
      //   29: aload_0
      //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   33: getfield context : Landroid/content/Context;
      //   36: invokespecial <init> : (Landroid/content/Context;)V
      //   39: astore_3
      //   40: aload_3
      //   41: aload #5
      //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
      //   46: aload #5
      //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
      //   53: astore #4
      //   55: aload #5
      //   57: invokeinterface getAspectRatio : ()F
      //   62: fstore_1
      //   63: goto -> 151
      //   66: aload_3
      //   67: ifnull -> 144
      //   70: aload_3
      //   71: invokeinterface size : ()I
      //   76: ifle -> 144
      //   79: aload_3
      //   80: iconst_0
      //   81: invokeinterface get : (I)Ljava/lang/Object;
      //   86: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
      //   89: astore #4
      //   91: new android/widget/ImageView
      //   94: dup
      //   95: aload_0
      //   96: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   99: getfield context : Landroid/content/Context;
      //   102: invokespecial <init> : (Landroid/content/Context;)V
      //   105: astore_3
      //   106: aload #4
      //   108: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   111: astore #4
      //   113: aload #4
      //   115: ifnull -> 144
      //   118: aload_3
      //   119: aload #4
      //   121: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
      //   124: aload #4
      //   126: invokevirtual getIntrinsicWidth : ()I
      //   129: i2f
      //   130: aload #4
      //   132: invokevirtual getIntrinsicHeight : ()I
      //   135: i2f
      //   136: fdiv
      //   137: fstore_1
      //   138: aconst_null
      //   139: astore #4
      //   141: goto -> 151
      //   144: fconst_0
      //   145: fstore_1
      //   146: aconst_null
      //   147: astore_3
      //   148: aload_3
      //   149: astore #4
      //   151: aload_0
      //   152: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   155: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
      //   158: astore #5
      //   160: aload #5
      //   162: ifnull -> 207
      //   165: aload #5
      //   167: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   170: ifnull -> 190
      //   173: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   176: dup
      //   177: aload #5
      //   179: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   182: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   185: astore #5
      //   187: goto -> 210
      //   190: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   193: dup
      //   194: aload #5
      //   196: invokevirtual getUri : ()Landroid/net/Uri;
      //   199: invokespecial <init> : (Landroid/net/Uri;)V
      //   202: astore #5
      //   204: goto -> 210
      //   207: aconst_null
      //   208: astore #5
      //   210: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
      //   213: dup
      //   214: invokespecial <init> : ()V
      //   217: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
      //   220: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   223: aload #5
      //   225: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   228: aload_0
      //   229: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   232: invokevirtual getHeadline : ()Ljava/lang/String;
      //   235: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   238: aload_0
      //   239: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   242: invokevirtual getAdvertiser : ()Ljava/lang/String;
      //   245: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   248: aload_0
      //   249: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   252: invokevirtual getBody : ()Ljava/lang/String;
      //   255: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   258: aload_3
      //   259: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   262: aload_0
      //   263: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   266: invokevirtual getCallToAction : ()Ljava/lang/String;
      //   269: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   272: astore_3
      //   273: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
      //   276: istore_2
      //   277: iload_2
      //   278: ldc 11040399
      //   280: if_icmplt -> 297
      //   283: aload_3
      //   284: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   287: dup
      //   288: aload #4
      //   290: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   293: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   296: pop
      //   297: iload_2
      //   298: ldc 11040000
      //   300: if_icmplt -> 309
      //   303: aload_3
      //   304: fload_1
      //   305: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   308: pop
      //   309: iload_2
      //   310: ldc 11070000
      //   312: if_icmplt -> 327
      //   315: aload_3
      //   316: aload_0
      //   317: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   320: invokevirtual getStarRating : ()Ljava/lang/Double;
      //   323: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   326: pop
      //   327: new com/applovin/mediation/adapters/GoogleMediationAdapter$MaxGoogleNativeAd
      //   330: dup
      //   331: aload_0
      //   332: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   335: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter;
      //   338: aload_3
      //   339: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
      //   342: astore #4
      //   344: aload_0
      //   345: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   348: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
      //   351: astore #5
      //   353: aload #6
      //   355: astore_3
      //   356: aload #5
      //   358: ifnull -> 367
      //   361: aload #5
      //   363: invokevirtual getResponseId : ()Ljava/lang/String;
      //   366: astore_3
      //   367: new android/os/Bundle
      //   370: dup
      //   371: iconst_1
      //   372: invokespecial <init> : (I)V
      //   375: astore #5
      //   377: aload #5
      //   379: ldc 'creative_id'
      //   381: aload_3
      //   382: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   385: aload_0
      //   386: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   389: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
      //   392: aload #4
      //   394: aload #5
      //   396: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
      //   401: return
    }
  }
  
  private class NativeAdViewListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final WeakReference<Activity> activityRef;
    
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Activity param1Activity, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.activityRef = new WeakReference<Activity>(param1Activity);
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdCollapsed();
    }
    
    public void onAdFailedToLoad(@NonNull LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdExpanded();
    }
    
    public void onNativeAdLoaded(@NonNull final NativeAd nativeAd) {
      MaxNativeAd.MaxNativeAdImage maxNativeAdImage;
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      if (TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleMediationAdapter = GoogleMediationAdapter.this;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Native ");
        stringBuilder.append(this.adFormat.getLabel());
        stringBuilder.append(" ad failed to load: Google native ad is missing one or more required assets");
        googleMediationAdapter.log(stringBuilder.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
        nativeAd.destroy();
        return;
      } 
      GoogleMediationAdapter.access$1502(GoogleMediationAdapter.this, nativeAd);
      final Activity activity = this.activityRef.get();
      final Context context = GoogleMediationAdapter.this.getContext(activity);
      final MediaView mediaView = new MediaView(context);
      MediaContent mediaContent = nativeAd.getMediaContent();
      if (mediaContent != null)
        mediaView.setMediaContent(mediaContent); 
      NativeAd.Image image = nativeAd.getIcon();
      mediaContent = null;
      if (image != null)
        if (image.getDrawable() != null) {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(image.getDrawable());
        } else {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(image.getUri());
        }  
      final MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(this.adFormat).setIcon(maxNativeAdImage).setTitle(nativeAd.getHeadline()).setBody(nativeAd.getBody()).setMediaView((View)mediaView).setCallToAction(nativeAd.getCallToAction()).build();
      final String templateName = BundleUtils.getString("template", "", this.serverParameters);
      if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
        GoogleMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              int i = AppLovinSdk.VERSION_CODE;
              if (i < 9140000) {
                GoogleMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
              } else if (i >= 11010000) {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
              } else {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
              } 
              GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(context));
              GoogleMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
              GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
              GoogleMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
              GoogleMediationAdapter.this.nativeAdView.setMediaView(mediaView);
              GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
              GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
              GoogleMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
              ResponseInfo responseInfo = nativeAd.getResponseInfo();
              if (responseInfo != null) {
                String str = responseInfo.getResponseId();
              } else {
                responseInfo = null;
              } 
              if (i >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", (String)responseInfo);
                GoogleMediationAdapter.NativeAdViewListener nativeAdViewListener1 = GoogleMediationAdapter.NativeAdViewListener.this;
                nativeAdViewListener1.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView, bundle);
                return;
              } 
              GoogleMediationAdapter.NativeAdViewListener nativeAdViewListener = GoogleMediationAdapter.NativeAdViewListener.this;
              nativeAdViewListener.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      int i = AppLovinSdk.VERSION_CODE;
      if (i < 9140000) {
        GoogleMediationAdapter.this.log("Native ads with media views are only supported on MAX SDK version 9.14.0 and above. Default native template will be used.");
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, activity);
      } else if (i >= 11010000) {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
      } else {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
      } 
      GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(context));
      GoogleMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
      GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
      GoogleMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
      GoogleMediationAdapter.this.nativeAdView.setMediaView(mediaView);
      GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
      GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
      GoogleMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
      ResponseInfo responseInfo = nativeAd.getResponseInfo();
      if (responseInfo != null) {
        String str = responseInfo.getResponseId();
      } else {
        responseInfo = null;
      } 
      if (i >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", (String)responseInfo);
        GoogleMediationAdapter.NativeAdViewListener nativeAdViewListener1 = this.this$1;
        nativeAdViewListener1.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView, bundle);
        return;
      } 
      GoogleMediationAdapter.NativeAdViewListener nativeAdViewListener = this.this$1;
      nativeAdViewListener.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView);
    }
  }
  
  private class RewardedAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedAdapterListener listener;
    
    private final String placementId;
    
    RewardedAdListener(String param1String, MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedAdVideoCompleted();
      if (this.hasGrantedReward || GoogleMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleMediationAdapter.this.getReward();
        GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdVideoStarted();
    }
  }
  
  private class RewardedInterstitialAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedInterstitialAdapterListener listener;
    
    private final String placementId;
    
    private RewardedInterstitialAdListener(String param1String, MaxRewardedInterstitialAdapterListener param1MaxRewardedInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedInterstitialAdVideoCompleted();
      if (this.hasGrantedReward || GoogleMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleMediationAdapter.this.getReward();
        GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Rewarded interstitial ad rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(@NonNull AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Rewarded interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdVideoStarted();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\applovin\mediation\adapters\GoogleMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */