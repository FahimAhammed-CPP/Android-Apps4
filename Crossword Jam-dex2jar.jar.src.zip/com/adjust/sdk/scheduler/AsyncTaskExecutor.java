package com.adjust.sdk.scheduler;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executors;

public abstract class AsyncTaskExecutor<Params, Result> {
  public abstract Result doInBackground(Params[] paramArrayOfParams);
  
  @SafeVarargs
  public final AsyncTaskExecutor<Params, Result> execute(Params... paramVarArgs) {
    onPreExecute();
    Handler handler = new Handler(Looper.getMainLooper());
    Executors.newSingleThreadExecutor().execute(new a(this, (Object[])paramVarArgs, handler));
    return this;
  }
  
  public void onPostExecute(Result paramResult) {}
  
  public void onPreExecute() {}
  
  public final class a implements Runnable {
    public a(AsyncTaskExecutor this$0, Object[] param1ArrayOfObject, Handler param1Handler) {}
    
    public final void run() {
      Object object = this.c.doInBackground(this.a);
      this.b.post(new a(this, object));
    }
    
    public final class a implements Runnable {
      public a(AsyncTaskExecutor.a this$0, Object param2Object) {}
      
      public final void run() {
        this.b.c.onPostExecute(this.a);
      }
    }
  }
  
  public final class a implements Runnable {
    public a(AsyncTaskExecutor this$0, Object param1Object) {}
    
    public final void run() {
      this.b.c.onPostExecute(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\adjust\sdk\scheduler\AsyncTaskExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */