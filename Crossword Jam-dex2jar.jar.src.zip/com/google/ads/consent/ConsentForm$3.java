package com.google.ads.consent;

import android.content.DialogInterface;

class ConsentForm$3 implements DialogInterface.OnShowListener {
  public void onShow(DialogInterface paramDialogInterface) {
    ConsentForm.b(this.this$0).d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\ads\consent\ConsentForm$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */