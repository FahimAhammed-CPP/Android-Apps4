package com.google.ads.consent;

import android.annotation.TargetApi;
import android.text.TextUtils;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;

class ConsentForm$2 extends WebViewClient {
  boolean isInternalRedirect;
  
  private void a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial b : (Ljava/lang/String;)Z
    //   5: ifne -> 9
    //   8: return
    //   9: iconst_1
    //   10: istore_2
    //   11: aload_0
    //   12: iconst_1
    //   13: putfield isInternalRedirect : Z
    //   16: aload_1
    //   17: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   20: astore #4
    //   22: aload #4
    //   24: ldc 'action'
    //   26: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
    //   29: astore_1
    //   30: aload #4
    //   32: ldc 'status'
    //   34: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
    //   37: astore_3
    //   38: aload #4
    //   40: ldc 'url'
    //   42: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
    //   45: astore #4
    //   47: aload_1
    //   48: invokevirtual hashCode : ()I
    //   51: pop
    //   52: aload_1
    //   53: invokevirtual hashCode : ()I
    //   56: lookupswitch default -> 92, -1370505102 -> 126, 150940456 -> 114, 1671672458 -> 97
    //   92: iconst_m1
    //   93: istore_2
    //   94: goto -> 140
    //   97: aload_1
    //   98: ldc 'dismiss'
    //   100: invokevirtual equals : (Ljava/lang/Object;)Z
    //   103: ifne -> 109
    //   106: goto -> 92
    //   109: iconst_2
    //   110: istore_2
    //   111: goto -> 140
    //   114: aload_1
    //   115: ldc 'browser'
    //   117: invokevirtual equals : (Ljava/lang/Object;)Z
    //   120: ifne -> 140
    //   123: goto -> 92
    //   126: aload_1
    //   127: ldc 'load_complete'
    //   129: invokevirtual equals : (Ljava/lang/Object;)Z
    //   132: ifne -> 138
    //   135: goto -> 92
    //   138: iconst_0
    //   139: istore_2
    //   140: iload_2
    //   141: tableswitch default -> 168, 0 -> 193, 1 -> 183, 2 -> 169
    //   168: return
    //   169: aload_0
    //   170: iconst_0
    //   171: putfield isInternalRedirect : Z
    //   174: aload_0
    //   175: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
    //   178: aload_3
    //   179: invokestatic d : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
    //   182: return
    //   183: aload_0
    //   184: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
    //   187: aload #4
    //   189: invokestatic e : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
    //   192: return
    //   193: aload_0
    //   194: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
    //   197: aload_3
    //   198: invokestatic c : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
    //   201: return
  }
  
  private boolean b(String paramString) {
    return (!TextUtils.isEmpty(paramString) && paramString.startsWith("consent://"));
  }
  
  public void onLoadResource(WebView paramWebView, String paramString) {
    Logger.d("AdMob|SafeDK: Execution> Lcom/google/ads/consent/ConsentForm$2;->onLoadResource(Landroid/webkit/WebView;Ljava/lang/String;)V");
    CreativeInfoManager.onResourceLoaded("com.google.ads", paramWebView, paramString);
    safedk_ConsentForm$2_onLoadResource_f8e46d4c36ccc625dea764a2495fc9db(paramWebView, paramString);
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    Logger.d("AdMob|SafeDK: Execution> Lcom/google/ads/consent/ConsentForm$2;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
    CreativeInfoManager.onWebViewPageFinished("com.google.ads", paramWebView, paramString);
    safedk_ConsentForm$2_onPageFinished_a0c4d1e15feb9fb7c2f68ff278316caa(paramWebView, paramString);
  }
  
  public void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceError paramWebResourceError) {
    super.onReceivedError(paramWebView, paramWebResourceRequest, paramWebResourceError);
    ConsentForm.a(this.this$0, ConsentForm.LoadState.NOT_READY);
    ConsentForm.b(this.this$0).b(paramWebResourceError.toString());
  }
  
  public void safedk_ConsentForm$2_onLoadResource_f8e46d4c36ccc625dea764a2495fc9db(WebView paramWebView, String paramString) {
    a(paramString);
  }
  
  public void safedk_ConsentForm$2_onPageFinished_a0c4d1e15feb9fb7c2f68ff278316caa(WebView paramWebView, String paramString) {
    if (!this.isInternalRedirect)
      ConsentForm.f(this.this$0, paramWebView); 
    super.onPageFinished(paramWebView, paramString);
  }
  
  public boolean safedk_ConsentForm$2_shouldOverrideUrlLoading_c8e9de4c8bfc76ed5713006f4765b561(WebView paramWebView, String paramString) {
    if (b(paramString)) {
      a(paramString);
      return true;
    } 
    return false;
  }
  
  @TargetApi(24)
  public boolean safedk_ConsentForm$2_shouldOverrideUrlLoading_fc3a5eb6fcf7bd0c7d31d10983a4badd(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    String str = paramWebResourceRequest.getUrl().toString();
    if (b(str)) {
      a(str);
      return true;
    } 
    return false;
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    return CreativeInfoManager.onWebViewResponseWithHeaders("com.google.ads", paramWebView, paramWebResourceRequest, super.shouldInterceptRequest(paramWebView, paramWebResourceRequest));
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, String paramString) {
    return CreativeInfoManager.onWebViewResponse("com.google.ads", paramWebView, paramString, super.shouldInterceptRequest(paramWebView, paramString));
  }
  
  @TargetApi(24)
  public boolean shouldOverrideUrlLoading(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    Logger.d("AdMob|SafeDK: Execution> Lcom/google/ads/consent/ConsentForm$2;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z");
    boolean bool = safedk_ConsentForm$2_shouldOverrideUrlLoading_fc3a5eb6fcf7bd0c7d31d10983a4badd(paramWebView, paramWebResourceRequest);
    CreativeInfoManager.onOverrideUrlLoadingWithHeaders("com.google.ads", paramWebView, paramWebResourceRequest, bool);
    return bool;
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    Logger.d("AdMob|SafeDK: Execution> Lcom/google/ads/consent/ConsentForm$2;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
    boolean bool = safedk_ConsentForm$2_shouldOverrideUrlLoading_c8e9de4c8bfc76ed5713006f4765b561(paramWebView, paramString);
    CreativeInfoManager.onOverrideUrlLoading("com.google.ads", paramWebView, paramString, bool);
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\ads\consent\ConsentForm$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */