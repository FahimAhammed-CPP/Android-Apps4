package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.app.job.JobInfo;
import androidx.annotation.RequiresApi;
import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;
import j.d.a.b.d;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@AutoValue
public abstract class t {
  private long a(int paramInt, long paramLong) {
    long l;
    paramInt--;
    if (paramLong > 1L) {
      l = paramLong;
    } else {
      l = 2L;
    } 
    double d = Math.max(1.0D, Math.log(10000.0D) / Math.log((l * paramInt)));
    return (long)(Math.pow(3.0D, paramInt) * paramLong * d);
  }
  
  public static a b() {
    return new a();
  }
  
  static t d(j.d.a.b.i.d0.a parama, Map<d, b> paramMap) {
    return (t)new q(parama, paramMap);
  }
  
  public static t f(j.d.a.b.i.d0.a parama) {
    a a1 = b();
    d d = d.b;
    b.a a2 = b.a();
    a2.b(30000L);
    a2.d(86400000L);
    a1.a(d, a2.a());
    d = d.d;
    a2 = b.a();
    a2.b(1000L);
    a2.d(86400000L);
    a1.a(d, a2.a());
    d = d.c;
    a2 = b.a();
    a2.b(86400000L);
    a2.d(86400000L);
    a2.c(i(new c[] { c.c }));
    a1.a(d, a2.a());
    a1.c(parama);
    return a1.b();
  }
  
  private static <T> Set<T> i(T... paramVarArgs) {
    return Collections.unmodifiableSet(new HashSet<T>(Arrays.asList(paramVarArgs)));
  }
  
  @RequiresApi(api = 21)
  private void j(JobInfo.Builder paramBuilder, Set<c> paramSet) {
    if (paramSet.contains(c.b)) {
      paramBuilder.setRequiredNetworkType(2);
    } else {
      paramBuilder.setRequiredNetworkType(1);
    } 
    if (paramSet.contains(c.d))
      paramBuilder.setRequiresCharging(true); 
    if (paramSet.contains(c.c))
      paramBuilder.setRequiresDeviceIdle(true); 
  }
  
  @RequiresApi(api = 21)
  public JobInfo.Builder c(JobInfo.Builder paramBuilder, d paramd, long paramLong, int paramInt) {
    paramBuilder.setMinimumLatency(g(paramd, paramLong, paramInt));
    j(paramBuilder, ((b)h().get(paramd)).c());
    return paramBuilder;
  }
  
  abstract j.d.a.b.i.d0.a e();
  
  public long g(d paramd, long paramLong, int paramInt) {
    long l = e().a();
    b b = h().get(paramd);
    return Math.min(Math.max(a(paramInt, b.b()), paramLong - l), b.d());
  }
  
  abstract Map<d, b> h();
  
  public static class a {
    private j.d.a.b.i.d0.a a;
    
    private Map<d, t.b> b = new HashMap<d, t.b>();
    
    public a a(d param1d, t.b param1b) {
      this.b.put(param1d, param1b);
      return this;
    }
    
    public t b() {
      Objects.requireNonNull(this.a, "missing required property: clock");
      if (this.b.keySet().size() >= (d.values()).length) {
        Map<d, t.b> map = this.b;
        this.b = new HashMap<d, t.b>();
        return t.d(this.a, map);
      } 
      throw new IllegalStateException("Not all priorities have been configured");
    }
    
    public a c(j.d.a.b.i.d0.a param1a) {
      this.a = param1a;
      return this;
    }
  }
  
  @AutoValue
  public static abstract class b {
    public static a a() {
      r.b b1 = new r.b();
      b1.c(Collections.emptySet());
      return (a)b1;
    }
    
    abstract long b();
    
    abstract Set<t.c> c();
    
    abstract long d();
    
    @Builder
    public static abstract class a {
      public abstract t.b a();
      
      public abstract a b(long param2Long);
      
      public abstract a c(Set<t.c> param2Set);
      
      public abstract a d(long param2Long);
    }
  }
  
  @Builder
  public static abstract class a {
    public abstract t.b a();
    
    public abstract a b(long param1Long);
    
    public abstract a c(Set<t.c> param1Set);
    
    public abstract a d(long param1Long);
  }
  
  public enum c {
    b, c, d;
    
    static {
      c c1 = new c("NETWORK_UNMETERED", 0);
      b = c1;
      c c2 = new c("DEVICE_IDLE", 1);
      c = c2;
      c c3 = new c("DEVICE_CHARGING", 2);
      d = c3;
      e = new c[] { c1, c2, c3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\datatransport\runtime\scheduling\jobscheduling\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */