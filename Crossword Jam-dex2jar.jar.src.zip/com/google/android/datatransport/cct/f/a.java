package com.google.android.datatransport.cct.f;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;

@AutoValue
public abstract class a {
  @NonNull
  public static a a() {
    return (a)new c.b();
  }
  
  @Nullable
  public abstract String b();
  
  @Nullable
  public abstract String c();
  
  @Nullable
  public abstract String d();
  
  @Nullable
  public abstract String e();
  
  @Nullable
  public abstract String f();
  
  @Nullable
  public abstract String g();
  
  @Nullable
  public abstract String h();
  
  @Nullable
  public abstract String i();
  
  @Nullable
  public abstract String j();
  
  @Nullable
  public abstract String k();
  
  @Nullable
  public abstract String l();
  
  @Nullable
  public abstract Integer m();
  
  @Builder
  public static abstract class a {
    @NonNull
    public abstract a a();
    
    @NonNull
    public abstract a b(@Nullable String param1String);
    
    @NonNull
    public abstract a c(@Nullable String param1String);
    
    @NonNull
    public abstract a d(@Nullable String param1String);
    
    @NonNull
    public abstract a e(@Nullable String param1String);
    
    @NonNull
    public abstract a f(@Nullable String param1String);
    
    @NonNull
    public abstract a g(@Nullable String param1String);
    
    @NonNull
    public abstract a h(@Nullable String param1String);
    
    @NonNull
    public abstract a i(@Nullable String param1String);
    
    @NonNull
    public abstract a j(@Nullable String param1String);
    
    @NonNull
    public abstract a k(@Nullable String param1String);
    
    @NonNull
    public abstract a l(@Nullable String param1String);
    
    @NonNull
    public abstract a m(@Nullable Integer param1Integer);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\datatransport\cct\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */