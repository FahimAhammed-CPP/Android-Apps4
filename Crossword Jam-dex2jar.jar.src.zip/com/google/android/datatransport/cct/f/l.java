package com.google.android.datatransport.cct.f;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;

@AutoValue
public abstract class l {
  private static a a() {
    return (a)new f.b();
  }
  
  @NonNull
  public static a i(@NonNull String paramString) {
    a a = a();
    a.g(paramString);
    return a;
  }
  
  @NonNull
  public static a j(@NonNull byte[] paramArrayOfbyte) {
    a a = a();
    a.f(paramArrayOfbyte);
    return a;
  }
  
  @Nullable
  public abstract Integer b();
  
  public abstract long c();
  
  public abstract long d();
  
  @Nullable
  public abstract o e();
  
  @Nullable
  public abstract byte[] f();
  
  @Nullable
  public abstract String g();
  
  public abstract long h();
  
  @Builder
  public static abstract class a {
    @NonNull
    public abstract l a();
    
    @NonNull
    public abstract a b(@Nullable Integer param1Integer);
    
    @NonNull
    public abstract a c(long param1Long);
    
    @NonNull
    public abstract a d(long param1Long);
    
    @NonNull
    public abstract a e(@Nullable o param1o);
    
    @NonNull
    abstract a f(@Nullable byte[] param1ArrayOfbyte);
    
    @NonNull
    abstract a g(@Nullable String param1String);
    
    @NonNull
    public abstract a h(long param1Long);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\datatransport\cct\f\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */