package com.google.android.exoplayer2.metadata.emsg;

import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.d;
import com.google.android.exoplayer2.metadata.g;
import j.d.a.c.i4.b0;
import j.d.a.c.i4.e;
import java.nio.ByteBuffer;
import java.util.Arrays;

public final class a extends g {
  protected Metadata b(d paramd, ByteBuffer paramByteBuffer) {
    return new Metadata(new Metadata.Entry[] { (Metadata.Entry)c(new b0(paramByteBuffer.array(), paramByteBuffer.limit())) });
  }
  
  public EventMessage c(b0 paramb0) {
    String str1 = paramb0.w();
    e.e(str1);
    str1 = str1;
    String str2 = paramb0.w();
    e.e(str2);
    return new EventMessage(str1, str2, paramb0.v(), paramb0.v(), Arrays.copyOfRange(paramb0.d(), paramb0.e(), paramb0.f()));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\metadata\emsg\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */