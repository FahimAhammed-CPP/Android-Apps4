package com.google.android.exoplayer2.metadata.emsg;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public final class b {
  private final ByteArrayOutputStream a;
  
  private final DataOutputStream b;
  
  public b() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
    this.a = byteArrayOutputStream;
    this.b = new DataOutputStream(byteArrayOutputStream);
  }
  
  private static void b(DataOutputStream paramDataOutputStream, String paramString) throws IOException {
    paramDataOutputStream.writeBytes(paramString);
    paramDataOutputStream.writeByte(0);
  }
  
  public byte[] a(EventMessage paramEventMessage) {
    this.a.reset();
    try {
      b(this.b, paramEventMessage.b);
      String str = paramEventMessage.c;
      if (str == null)
        str = ""; 
      b(this.b, str);
      this.b.writeLong(paramEventMessage.d);
      this.b.writeLong(paramEventMessage.e);
      this.b.write(paramEventMessage.f);
      this.b.flush();
      return this.a.toByteArray();
    } catch (IOException iOException) {
      throw new RuntimeException(iOException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\metadata\emsg\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */