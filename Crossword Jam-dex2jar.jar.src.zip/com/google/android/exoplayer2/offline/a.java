package com.google.android.exoplayer2.offline;

import java.util.List;

public interface a<T> {
  T copy(List<StreamKey> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\offline\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */