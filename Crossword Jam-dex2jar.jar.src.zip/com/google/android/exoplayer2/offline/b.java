package com.google.android.exoplayer2.offline;

import android.net.Uri;
import androidx.annotation.Nullable;
import j.d.a.c.h4.j0;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public final class b<T extends a<T>> implements j0.a<T> {
  private final j0.a<? extends T> a;
  
  @Nullable
  private final List<StreamKey> b;
  
  public b(j0.a<? extends T> parama, @Nullable List<StreamKey> paramList) {
    this.a = parama;
    this.b = paramList;
  }
  
  public T a(Uri paramUri, InputStream paramInputStream) throws IOException {
    a<a> a2 = (a)this.a.parse(paramUri, paramInputStream);
    List<StreamKey> list = this.b;
    a<a> a1 = a2;
    if (list != null) {
      if (list.isEmpty())
        return (T)a2; 
      a1 = a2.copy(this.b);
    } 
    return (T)a1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\offline\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */