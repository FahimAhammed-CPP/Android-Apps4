package com.google.android.exoplayer2.video;

import android.os.Handler;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import j.d.a.c.b4.e;
import j.d.a.c.b4.i;
import j.d.a.c.i4.e;
import j.d.a.c.i4.m0;
import j.d.a.c.n2;

public interface x {
  void b(String paramString);
  
  void e(n2 paramn2, @Nullable i parami);
  
  void g(Exception paramException);
  
  void h(e parame);
  
  void k(Object paramObject, long paramLong);
  
  void l(e parame);
  
  void o(long paramLong, int paramInt);
  
  void onDroppedFrames(int paramInt, long paramLong);
  
  void onVideoDecoderInitialized(String paramString, long paramLong1, long paramLong2);
  
  void onVideoSizeChanged(y paramy);
  
  @Deprecated
  void t(n2 paramn2);
  
  public static final class a {
    @Nullable
    private final Handler a;
    
    @Nullable
    private final x b;
    
    public a(@Nullable Handler param1Handler, @Nullable x param1x) {
      if (param1x != null) {
        e.e(param1Handler);
        param1Handler = param1Handler;
      } else {
        param1Handler = null;
      } 
      this.a = param1Handler;
      this.b = param1x;
    }
    
    public void A(Object param1Object) {
      if (this.a != null) {
        long l = SystemClock.elapsedRealtime();
        this.a.post((Runnable)new g(this, param1Object, l));
      } 
    }
    
    public void B(long param1Long, int param1Int) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new l(this, param1Long, param1Int)); 
    }
    
    public void C(Exception param1Exception) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new e(this, param1Exception)); 
    }
    
    public void D(y param1y) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new j(this, param1y)); 
    }
    
    public void a(String param1String, long param1Long1, long param1Long2) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new i(this, param1String, param1Long1, param1Long2)); 
    }
    
    public void b(String param1String) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new d(this, param1String)); 
    }
    
    public void c(e param1e) {
      param1e.c();
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new c(this, param1e)); 
    }
    
    public void d(int param1Int, long param1Long) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new h(this, param1Int, param1Long)); 
    }
    
    public void e(e param1e) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new f(this, param1e)); 
    }
    
    public void f(n2 param1n2, @Nullable i param1i) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new k(this, param1n2, param1i)); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\video\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */