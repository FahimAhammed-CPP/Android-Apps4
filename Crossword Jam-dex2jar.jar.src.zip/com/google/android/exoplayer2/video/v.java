package com.google.android.exoplayer2.video;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.view.Choreographer;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;
import androidx.annotation.DoNotInline;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import j.d.a.c.i4.m0;
import j.d.a.c.i4.t;

public final class v {
  private final q a = new q();
  
  @Nullable
  private final b b;
  
  @Nullable
  private final e c;
  
  private boolean d;
  
  @Nullable
  private Surface e;
  
  private float f;
  
  private float g;
  
  private float h;
  
  private float i;
  
  private int j;
  
  private long k;
  
  private long l;
  
  private long m;
  
  private long n;
  
  private long o;
  
  private long p;
  
  private long q;
  
  public v(@Nullable Context paramContext) {
    b b1 = f(paramContext);
    this.b = b1;
    if (b1 != null) {
      e e1 = e.d();
    } else {
      b1 = null;
    } 
    this.c = (e)b1;
    this.k = -9223372036854775807L;
    this.l = -9223372036854775807L;
    this.f = -1.0F;
    this.i = 1.0F;
    this.j = 0;
  }
  
  private static boolean b(long paramLong1, long paramLong2) {
    return (Math.abs(paramLong1 - paramLong2) <= 20000000L);
  }
  
  private void c() {
    if (m0.a >= 30) {
      Surface surface = this.e;
      if (surface != null && this.j != Integer.MIN_VALUE) {
        if (this.h == 0.0F)
          return; 
        this.h = 0.0F;
        a.a(surface, 0.0F);
      } 
    } 
  }
  
  private static long d(long paramLong1, long paramLong2, long paramLong3) {
    paramLong2 += (paramLong1 - paramLong2) / paramLong3 * paramLong3;
    if (paramLong1 <= paramLong2) {
      paramLong3 = paramLong2 - paramLong3;
    } else {
      long l = paramLong3 + paramLong2;
      paramLong3 = paramLong2;
      paramLong2 = l;
    } 
    return (paramLong2 - paramLong1 < paramLong1 - paramLong3) ? paramLong2 : paramLong3;
  }
  
  @Nullable
  private static b f(@Nullable Context paramContext) {
    b b1 = null;
    Context context = null;
    if (paramContext != null) {
      b b2;
      Context context1 = paramContext.getApplicationContext();
      paramContext = context;
      if (m0.a >= 17)
        b2 = d.d(context1); 
      b1 = b2;
      if (b2 == null)
        b1 = c.c(context1); 
    } 
    return b1;
  }
  
  private void n() {
    this.m = 0L;
    this.p = -1L;
    this.n = -1L;
  }
  
  private void p(@Nullable Display paramDisplay) {
    if (paramDisplay != null) {
      long l = (long)(1.0E9D / paramDisplay.getRefreshRate());
      this.k = l;
      this.l = l * 80L / 100L;
      return;
    } 
    t.i("VideoFrameReleaseHelper", "Unable to query display refresh rate");
    this.k = -9223372036854775807L;
    this.l = -9223372036854775807L;
  }
  
  private void q() {
    // Byte code:
    //   0: getstatic j/d/a/c/i4/m0.a : I
    //   3: bipush #30
    //   5: if_icmplt -> 180
    //   8: aload_0
    //   9: getfield e : Landroid/view/Surface;
    //   12: ifnonnull -> 16
    //   15: return
    //   16: aload_0
    //   17: getfield a : Lcom/google/android/exoplayer2/video/q;
    //   20: invokevirtual e : ()Z
    //   23: ifeq -> 37
    //   26: aload_0
    //   27: getfield a : Lcom/google/android/exoplayer2/video/q;
    //   30: invokevirtual b : ()F
    //   33: fstore_1
    //   34: goto -> 42
    //   37: aload_0
    //   38: getfield f : F
    //   41: fstore_1
    //   42: aload_0
    //   43: getfield g : F
    //   46: fstore_2
    //   47: fload_1
    //   48: fload_2
    //   49: fcmpl
    //   50: ifne -> 54
    //   53: return
    //   54: fload_1
    //   55: ldc -1.0
    //   57: fcmpl
    //   58: istore_3
    //   59: iconst_1
    //   60: istore #4
    //   62: iload_3
    //   63: ifeq -> 141
    //   66: fload_2
    //   67: ldc -1.0
    //   69: fcmpl
    //   70: ifeq -> 141
    //   73: aload_0
    //   74: getfield a : Lcom/google/android/exoplayer2/video/q;
    //   77: invokevirtual e : ()Z
    //   80: ifeq -> 102
    //   83: aload_0
    //   84: getfield a : Lcom/google/android/exoplayer2/video/q;
    //   87: invokevirtual d : ()J
    //   90: ldc2_w 5000000000
    //   93: lcmp
    //   94: iflt -> 102
    //   97: iconst_1
    //   98: istore_3
    //   99: goto -> 104
    //   102: iconst_0
    //   103: istore_3
    //   104: iload_3
    //   105: ifeq -> 114
    //   108: ldc 0.02
    //   110: fstore_2
    //   111: goto -> 116
    //   114: fconst_1
    //   115: fstore_2
    //   116: fload_1
    //   117: aload_0
    //   118: getfield g : F
    //   121: fsub
    //   122: invokestatic abs : (F)F
    //   125: fload_2
    //   126: fcmpl
    //   127: iflt -> 136
    //   130: iload #4
    //   132: istore_3
    //   133: goto -> 166
    //   136: iconst_0
    //   137: istore_3
    //   138: goto -> 166
    //   141: iload_3
    //   142: ifeq -> 151
    //   145: iload #4
    //   147: istore_3
    //   148: goto -> 166
    //   151: aload_0
    //   152: getfield a : Lcom/google/android/exoplayer2/video/q;
    //   155: invokevirtual c : ()I
    //   158: bipush #30
    //   160: if_icmplt -> 136
    //   163: iload #4
    //   165: istore_3
    //   166: iload_3
    //   167: ifeq -> 180
    //   170: aload_0
    //   171: fload_1
    //   172: putfield g : F
    //   175: aload_0
    //   176: iconst_0
    //   177: invokespecial r : (Z)V
    //   180: return
  }
  
  private void r(boolean paramBoolean) {
    if (m0.a >= 30) {
      Surface surface = this.e;
      if (surface != null) {
        if (this.j == Integer.MIN_VALUE)
          return; 
        float f2 = 0.0F;
        float f1 = f2;
        if (this.d) {
          float f = this.g;
          f1 = f2;
          if (f != -1.0F)
            f1 = this.i * f; 
        } 
        if (!paramBoolean && this.h == f1)
          return; 
        this.h = f1;
        a.a(surface, f1);
      } 
    } 
  }
  
  public long a(long paramLong) {
    if (this.p != -1L && this.a.e()) {
      long l = this.a.a();
      l = this.q + (long)((float)(l * (this.m - this.p)) / this.i);
      if (b(paramLong, l)) {
        paramLong = l;
      } else {
        n();
      } 
    } 
    this.n = this.m;
    this.o = paramLong;
    e e1 = this.c;
    if (e1 != null) {
      if (this.k == -9223372036854775807L)
        return paramLong; 
      long l = e1.b;
      return (l == -9223372036854775807L) ? paramLong : (d(paramLong, l, this.k) - this.l);
    } 
    return paramLong;
  }
  
  public void g(float paramFloat) {
    this.f = paramFloat;
    this.a.g();
    q();
  }
  
  public void h(long paramLong) {
    long l = this.n;
    if (l != -1L) {
      this.p = l;
      this.q = this.o;
    } 
    this.m++;
    this.a.f(paramLong * 1000L);
    q();
  }
  
  public void i(float paramFloat) {
    this.i = paramFloat;
    n();
    r(false);
  }
  
  public void j() {
    n();
  }
  
  public void k() {
    this.d = true;
    n();
    if (this.b != null) {
      e e1 = this.c;
      j.d.a.c.i4.e.e(e1);
      e1.a();
      this.b.a((b.a)new b(this));
    } 
    r(false);
  }
  
  public void l() {
    this.d = false;
    b b1 = this.b;
    if (b1 != null) {
      b1.b();
      e e1 = this.c;
      j.d.a.c.i4.e.e(e1);
      e1.e();
    } 
    c();
  }
  
  public void m(@Nullable Surface paramSurface) {
    Surface surface = paramSurface;
    if (paramSurface instanceof PlaceholderSurface)
      surface = null; 
    if (this.e == surface)
      return; 
    c();
    this.e = surface;
    r(true);
  }
  
  public void o(int paramInt) {
    if (this.j == paramInt)
      return; 
    this.j = paramInt;
    r(true);
  }
  
  @RequiresApi(30)
  private static final class a {
    @DoNotInline
    public static void a(Surface param1Surface, float param1Float) {
      boolean bool;
      if (param1Float == 0.0F) {
        bool = false;
      } else {
        bool = true;
      } 
      try {
        param1Surface.setFrameRate(param1Float, bool);
        return;
      } catch (IllegalStateException illegalStateException) {
        t.d("VideoFrameReleaseHelper", "Failed to call Surface.setFrameRate", illegalStateException);
        return;
      } 
    }
  }
  
  private static interface b {
    void a(a param1a);
    
    void b();
    
    public static interface a {
      void onDefaultDisplayChanged(@Nullable Display param2Display);
    }
  }
  
  public static interface a {
    void onDefaultDisplayChanged(@Nullable Display param1Display);
  }
  
  private static final class c implements b {
    private final WindowManager a;
    
    private c(WindowManager param1WindowManager) {
      this.a = param1WindowManager;
    }
    
    @Nullable
    public static v.b c(Context param1Context) {
      WindowManager windowManager = (WindowManager)param1Context.getSystemService("window");
      return (windowManager != null) ? new c(windowManager) : null;
    }
    
    public void a(v.b.a param1a) {
      param1a.onDefaultDisplayChanged(this.a.getDefaultDisplay());
    }
    
    public void b() {}
  }
  
  @RequiresApi(17)
  private static final class d implements b, DisplayManager.DisplayListener {
    private final DisplayManager a;
    
    @Nullable
    private v.b.a b;
    
    private d(DisplayManager param1DisplayManager) {
      this.a = param1DisplayManager;
    }
    
    private Display c() {
      return this.a.getDisplay(0);
    }
    
    @Nullable
    public static v.b d(Context param1Context) {
      DisplayManager displayManager = (DisplayManager)param1Context.getSystemService("display");
      return (displayManager != null) ? new d(displayManager) : null;
    }
    
    public void a(v.b.a param1a) {
      this.b = param1a;
      this.a.registerDisplayListener(this, m0.v());
      param1a.onDefaultDisplayChanged(c());
    }
    
    public void b() {
      this.a.unregisterDisplayListener(this);
      this.b = null;
    }
    
    public void onDisplayAdded(int param1Int) {}
    
    public void onDisplayChanged(int param1Int) {
      v.b.a a1 = this.b;
      if (a1 != null && param1Int == 0)
        a1.onDefaultDisplayChanged(c()); 
    }
    
    public void onDisplayRemoved(int param1Int) {}
  }
  
  private static final class e implements Choreographer.FrameCallback, Handler.Callback {
    private static final e g = new e();
    
    public volatile long b = -9223372036854775807L;
    
    private final Handler c;
    
    private final HandlerThread d;
    
    private Choreographer e;
    
    private int f;
    
    private e() {
      HandlerThread handlerThread = new HandlerThread("ExoPlayer:FrameReleaseChoreographer");
      this.d = handlerThread;
      handlerThread.start();
      Handler handler = m0.u(handlerThread.getLooper(), this);
      this.c = handler;
      handler.sendEmptyMessage(0);
    }
    
    private void b() {
      Choreographer choreographer = this.e;
      if (choreographer != null) {
        int i = this.f + 1;
        this.f = i;
        if (i == 1)
          choreographer.postFrameCallback(this); 
      } 
    }
    
    private void c() {
      try {
        this.e = Choreographer.getInstance();
        return;
      } catch (RuntimeException runtimeException) {
        t.j("VideoFrameReleaseHelper", "Vsync sampling disabled due to platform error", runtimeException);
        return;
      } 
    }
    
    public static e d() {
      return g;
    }
    
    private void f() {
      Choreographer choreographer = this.e;
      if (choreographer != null) {
        int i = this.f - 1;
        this.f = i;
        if (i == 0) {
          choreographer.removeFrameCallback(this);
          this.b = -9223372036854775807L;
        } 
      } 
    }
    
    public void a() {
      this.c.sendEmptyMessage(1);
    }
    
    public void doFrame(long param1Long) {
      this.b = param1Long;
      Choreographer choreographer = this.e;
      j.d.a.c.i4.e.e(choreographer);
      choreographer.postFrameCallbackDelayed(this, 500L);
    }
    
    public void e() {
      this.c.sendEmptyMessage(2);
    }
    
    public boolean handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != 0) {
        if (i != 1) {
          if (i != 2)
            return false; 
          f();
          return true;
        } 
        b();
        return true;
      } 
      c();
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\video\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */