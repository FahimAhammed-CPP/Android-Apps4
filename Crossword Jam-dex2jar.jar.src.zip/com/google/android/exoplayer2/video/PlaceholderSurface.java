package com.google.android.exoplayer2.video;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import j.d.a.c.i4.e;
import j.d.a.c.i4.n;
import j.d.a.c.i4.q;

@RequiresApi(17)
public final class PlaceholderSurface extends Surface {
  private static int e;
  
  private static boolean f;
  
  public final boolean b;
  
  private final b c;
  
  private boolean d;
  
  private PlaceholderSurface(b paramb, SurfaceTexture paramSurfaceTexture, boolean paramBoolean) {
    super(paramSurfaceTexture);
    this.c = paramb;
    this.b = paramBoolean;
  }
  
  private static int a(Context paramContext) {
    return q.b(paramContext) ? (q.c() ? 1 : 2) : 0;
  }
  
  public static boolean b(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/android/exoplayer2/video/PlaceholderSurface
    //   2: monitorenter
    //   3: getstatic com/google/android/exoplayer2/video/PlaceholderSurface.f : Z
    //   6: istore_3
    //   7: iconst_1
    //   8: istore_2
    //   9: iload_3
    //   10: ifne -> 24
    //   13: aload_0
    //   14: invokestatic a : (Landroid/content/Context;)I
    //   17: putstatic com/google/android/exoplayer2/video/PlaceholderSurface.e : I
    //   20: iconst_1
    //   21: putstatic com/google/android/exoplayer2/video/PlaceholderSurface.f : Z
    //   24: getstatic com/google/android/exoplayer2/video/PlaceholderSurface.e : I
    //   27: istore_1
    //   28: iload_1
    //   29: ifeq -> 35
    //   32: goto -> 37
    //   35: iconst_0
    //   36: istore_2
    //   37: ldc com/google/android/exoplayer2/video/PlaceholderSurface
    //   39: monitorexit
    //   40: iload_2
    //   41: ireturn
    //   42: astore_0
    //   43: ldc com/google/android/exoplayer2/video/PlaceholderSurface
    //   45: monitorexit
    //   46: aload_0
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	42	finally
    //   13	24	42	finally
    //   24	28	42	finally
  }
  
  public static PlaceholderSurface c(Context paramContext, boolean paramBoolean) {
    boolean bool;
    int i = 0;
    if (!paramBoolean || b(paramContext)) {
      bool = true;
    } else {
      bool = false;
    } 
    e.f(bool);
    b b1 = new b();
    if (paramBoolean)
      i = e; 
    return b1.a(i);
  }
  
  public void release() {
    super.release();
    synchronized (this.c) {
      if (!this.d) {
        this.c.c();
        this.d = true;
      } 
      return;
    } 
  }
  
  private static class b extends HandlerThread implements Handler.Callback {
    private n b;
    
    private Handler c;
    
    @Nullable
    private Error d;
    
    @Nullable
    private RuntimeException e;
    
    @Nullable
    private PlaceholderSurface f;
    
    public b() {
      super("ExoPlayer:PlaceholderSurface");
    }
    
    private void b(int param1Int) {
      boolean bool;
      e.e(this.b);
      this.b.h(param1Int);
      SurfaceTexture surfaceTexture = this.b.g();
      if (param1Int != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = new PlaceholderSurface(this, surfaceTexture, bool, null);
    }
    
    private void d() {
      e.e(this.b);
      this.b.i();
    }
    
    public PlaceholderSurface a(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual start : ()V
      //   4: aload_0
      //   5: new android/os/Handler
      //   8: dup
      //   9: aload_0
      //   10: invokevirtual getLooper : ()Landroid/os/Looper;
      //   13: aload_0
      //   14: invokespecial <init> : (Landroid/os/Looper;Landroid/os/Handler$Callback;)V
      //   17: putfield c : Landroid/os/Handler;
      //   20: aload_0
      //   21: new j/d/a/c/i4/n
      //   24: dup
      //   25: aload_0
      //   26: getfield c : Landroid/os/Handler;
      //   29: invokespecial <init> : (Landroid/os/Handler;)V
      //   32: putfield b : Lj/d/a/c/i4/n;
      //   35: aload_0
      //   36: monitorenter
      //   37: aload_0
      //   38: getfield c : Landroid/os/Handler;
      //   41: astore_3
      //   42: iconst_0
      //   43: istore_2
      //   44: aload_3
      //   45: iconst_1
      //   46: iload_1
      //   47: iconst_0
      //   48: invokevirtual obtainMessage : (III)Landroid/os/Message;
      //   51: invokevirtual sendToTarget : ()V
      //   54: iload_2
      //   55: istore_1
      //   56: aload_0
      //   57: getfield f : Lcom/google/android/exoplayer2/video/PlaceholderSurface;
      //   60: ifnonnull -> 91
      //   63: aload_0
      //   64: getfield e : Ljava/lang/RuntimeException;
      //   67: ifnonnull -> 91
      //   70: aload_0
      //   71: getfield d : Ljava/lang/Error;
      //   74: astore_3
      //   75: aload_3
      //   76: ifnonnull -> 91
      //   79: aload_0
      //   80: invokevirtual wait : ()V
      //   83: goto -> 56
      //   86: iconst_1
      //   87: istore_1
      //   88: goto -> 56
      //   91: aload_0
      //   92: monitorexit
      //   93: iload_1
      //   94: ifeq -> 103
      //   97: invokestatic currentThread : ()Ljava/lang/Thread;
      //   100: invokevirtual interrupt : ()V
      //   103: aload_0
      //   104: getfield e : Ljava/lang/RuntimeException;
      //   107: astore_3
      //   108: aload_3
      //   109: ifnonnull -> 138
      //   112: aload_0
      //   113: getfield d : Ljava/lang/Error;
      //   116: astore_3
      //   117: aload_3
      //   118: ifnonnull -> 136
      //   121: aload_0
      //   122: getfield f : Lcom/google/android/exoplayer2/video/PlaceholderSurface;
      //   125: astore_3
      //   126: aload_3
      //   127: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_3
      //   132: checkcast com/google/android/exoplayer2/video/PlaceholderSurface
      //   135: areturn
      //   136: aload_3
      //   137: athrow
      //   138: aload_3
      //   139: athrow
      //   140: astore_3
      //   141: aload_0
      //   142: monitorexit
      //   143: aload_3
      //   144: athrow
      //   145: astore_3
      //   146: goto -> 86
      // Exception table:
      //   from	to	target	type
      //   37	42	140	finally
      //   44	54	140	finally
      //   56	75	140	finally
      //   79	83	145	java/lang/InterruptedException
      //   79	83	140	finally
      //   91	93	140	finally
      //   141	143	140	finally
    }
    
    public void c() {
      e.e(this.c);
      this.c.sendEmptyMessage(2);
    }
    
    public boolean handleMessage(Message param1Message) {
      // Byte code:
      //   0: aload_1
      //   1: getfield what : I
      //   4: istore_2
      //   5: iload_2
      //   6: iconst_1
      //   7: if_icmpeq -> 48
      //   10: iload_2
      //   11: iconst_2
      //   12: if_icmpeq -> 17
      //   15: iconst_1
      //   16: ireturn
      //   17: aload_0
      //   18: invokespecial d : ()V
      //   21: aload_0
      //   22: invokevirtual quit : ()Z
      //   25: pop
      //   26: iconst_1
      //   27: ireturn
      //   28: astore_1
      //   29: ldc 'PlaceholderSurface'
      //   31: ldc 'Failed to release placeholder surface'
      //   33: aload_1
      //   34: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   37: goto -> 21
      //   40: astore_1
      //   41: aload_0
      //   42: invokevirtual quit : ()Z
      //   45: pop
      //   46: aload_1
      //   47: athrow
      //   48: aload_0
      //   49: aload_1
      //   50: getfield arg1 : I
      //   53: invokespecial b : (I)V
      //   56: aload_0
      //   57: monitorenter
      //   58: aload_0
      //   59: invokevirtual notify : ()V
      //   62: aload_0
      //   63: monitorexit
      //   64: iconst_1
      //   65: ireturn
      //   66: astore_1
      //   67: aload_0
      //   68: monitorexit
      //   69: aload_1
      //   70: athrow
      //   71: astore_1
      //   72: goto -> 133
      //   75: astore_1
      //   76: ldc 'PlaceholderSurface'
      //   78: ldc 'Failed to initialize placeholder surface'
      //   80: aload_1
      //   81: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   84: aload_0
      //   85: aload_1
      //   86: putfield d : Ljava/lang/Error;
      //   89: aload_0
      //   90: monitorenter
      //   91: aload_0
      //   92: invokevirtual notify : ()V
      //   95: aload_0
      //   96: monitorexit
      //   97: iconst_1
      //   98: ireturn
      //   99: astore_1
      //   100: aload_0
      //   101: monitorexit
      //   102: aload_1
      //   103: athrow
      //   104: astore_1
      //   105: ldc 'PlaceholderSurface'
      //   107: ldc 'Failed to initialize placeholder surface'
      //   109: aload_1
      //   110: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   113: aload_0
      //   114: aload_1
      //   115: putfield e : Ljava/lang/RuntimeException;
      //   118: aload_0
      //   119: monitorenter
      //   120: aload_0
      //   121: invokevirtual notify : ()V
      //   124: aload_0
      //   125: monitorexit
      //   126: iconst_1
      //   127: ireturn
      //   128: astore_1
      //   129: aload_0
      //   130: monitorexit
      //   131: aload_1
      //   132: athrow
      //   133: aload_0
      //   134: monitorenter
      //   135: aload_0
      //   136: invokevirtual notify : ()V
      //   139: aload_0
      //   140: monitorexit
      //   141: aload_1
      //   142: athrow
      //   143: astore_1
      //   144: aload_0
      //   145: monitorexit
      //   146: aload_1
      //   147: athrow
      // Exception table:
      //   from	to	target	type
      //   17	21	28	finally
      //   29	37	40	finally
      //   48	56	104	java/lang/RuntimeException
      //   48	56	75	java/lang/Error
      //   48	56	71	finally
      //   58	64	66	finally
      //   67	69	66	finally
      //   76	89	71	finally
      //   91	97	99	finally
      //   100	102	99	finally
      //   105	118	71	finally
      //   120	126	128	finally
      //   129	131	128	finally
      //   135	141	143	finally
      //   144	146	143	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\video\PlaceholderSurface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */