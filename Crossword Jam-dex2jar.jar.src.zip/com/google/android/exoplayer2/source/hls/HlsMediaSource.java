package com.google.android.exoplayer2.source.hls;

import android.os.Looper;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.drm.a0;
import com.google.android.exoplayer2.drm.c0;
import com.google.android.exoplayer2.drm.u;
import com.google.android.exoplayer2.drm.y;
import com.google.android.exoplayer2.source.hls.u.c;
import com.google.android.exoplayer2.source.hls.u.d;
import com.google.android.exoplayer2.source.hls.u.e;
import com.google.android.exoplayer2.source.hls.u.g;
import com.google.android.exoplayer2.source.hls.u.h;
import com.google.android.exoplayer2.source.hls.u.k;
import com.google.android.exoplayer2.source.hls.u.l;
import j.d.a.c.e4.i0;
import j.d.a.c.e4.l0;
import j.d.a.c.e4.m0;
import j.d.a.c.e4.n0;
import j.d.a.c.e4.q;
import j.d.a.c.e4.x;
import j.d.a.c.e4.x0;
import j.d.a.c.e4.z;
import j.d.a.c.h4.a0;
import j.d.a.c.h4.g0;
import j.d.a.c.h4.i;
import j.d.a.c.h4.n0;
import j.d.a.c.h4.r;
import j.d.a.c.i4.e;
import j.d.a.c.i4.m0;
import j.d.a.c.l2;
import j.d.a.c.t2;
import j.d.a.c.v3;
import java.io.IOException;
import java.util.List;

public final class HlsMediaSource extends q implements l.e {
  private final k i;
  
  private final t2.h j;
  
  private final j k;
  
  private final x l;
  
  private final a0 m;
  
  private final g0 n;
  
  private final boolean o;
  
  private final int p;
  
  private final boolean q;
  
  private final l r;
  
  private final long s;
  
  private final t2 t;
  
  private t2.g u;
  
  @Nullable
  private n0 v;
  
  static {
    l2.a("goog.exo.hls");
  }
  
  private HlsMediaSource(t2 paramt2, j paramj, k paramk, x paramx, a0 parama0, g0 paramg0, l paraml, long paramLong, boolean paramBoolean1, int paramInt, boolean paramBoolean2) {
    t2.h h1 = paramt2.c;
    e.e(h1);
    this.j = h1;
    this.t = paramt2;
    this.u = paramt2.d;
    this.k = paramj;
    this.i = paramk;
    this.l = paramx;
    this.m = parama0;
    this.n = paramg0;
    this.r = paraml;
    this.s = paramLong;
    this.o = paramBoolean1;
    this.p = paramInt;
    this.q = paramBoolean2;
  }
  
  private x0 D(g paramg, long paramLong1, long paramLong2, l paraml) {
    long l1;
    boolean bool;
    long l3 = paramg.h - this.r.d();
    if (paramg.o) {
      l1 = l3 + paramg.u;
    } else {
      l1 = -9223372036854775807L;
    } 
    long l4 = H(paramg);
    long l2 = this.u.b;
    if (l2 != -9223372036854775807L) {
      l2 = m0.A0(l2);
    } else {
      l2 = J(paramg, l4);
    } 
    K(paramg, m0.q(l2, l4, paramg.u + l4));
    l2 = I(paramg, l4);
    if (paramg.d == 2 && paramg.f) {
      bool = true;
    } else {
      bool = false;
    } 
    return new x0(paramLong1, paramLong2, -9223372036854775807L, l1, paramg.u, l3, l2, true, paramg.o ^ true, bool, paraml, this.t, this.u);
  }
  
  private x0 E(g paramg, long paramLong1, long paramLong2, l paraml) {
    if (paramg.e == -9223372036854775807L || paramg.r.isEmpty()) {
      long l3 = 0L;
      long l4 = paramg.u;
      return new x0(paramLong1, paramLong2, -9223372036854775807L, l4, l4, 0L, l3, true, false, true, paraml, this.t, null);
    } 
    if (!paramg.g) {
      long l3 = paramg.e;
      if (l3 == paramg.u) {
        l3 = paramg.e;
        long l5 = paramg.u;
        return new x0(paramLong1, paramLong2, -9223372036854775807L, l5, l5, 0L, l3, true, false, true, paraml, this.t, null);
      } 
      l3 = ((g.e)G(paramg.r, l3)).f;
      long l4 = paramg.u;
      return new x0(paramLong1, paramLong2, -9223372036854775807L, l4, l4, 0L, l3, true, false, true, paraml, this.t, null);
    } 
    long l1 = paramg.e;
    long l2 = paramg.u;
    return new x0(paramLong1, paramLong2, -9223372036854775807L, l2, l2, 0L, l1, true, false, true, paraml, this.t, null);
  }
  
  @Nullable
  private static g.b F(List<g.b> paramList, long paramLong) {
    g.b b = null;
    int i = 0;
    while (i < paramList.size()) {
      g.b b1 = paramList.get(i);
      long l1 = ((g.e)b1).f;
      if (l1 > paramLong || !b1.m) {
        b1 = b;
        if (l1 > paramLong)
          return b; 
      } 
      i++;
      b = b1;
    } 
    return b;
  }
  
  private static g.d G(List<g.d> paramList, long paramLong) {
    return paramList.get(m0.f(paramList, Long.valueOf(paramLong), true, true));
  }
  
  private long H(g paramg) {
    return paramg.p ? (m0.A0(m0.Z(this.s)) - paramg.d()) : 0L;
  }
  
  private long I(g paramg, long paramLong) {
    long l1 = paramg.e;
    if (l1 != -9223372036854775807L) {
      paramLong = l1;
    } else {
      paramLong = paramg.u + paramLong - m0.A0(this.u.b);
    } 
    if (paramg.g)
      return paramLong; 
    g.b b = F(paramg.s, paramLong);
    if (b != null)
      return ((g.e)b).f; 
    if (paramg.r.isEmpty())
      return 0L; 
    g.d d = G(paramg.r, paramLong);
    b = F(d.n, paramLong);
    return (b != null) ? ((g.e)b).f : ((g.e)d).f;
  }
  
  private static long J(g paramg, long paramLong) {
    g.f f = paramg.v;
    long l1 = paramg.e;
    if (l1 != -9223372036854775807L) {
      l1 = paramg.u - l1;
    } else {
      l1 = f.d;
      if (l1 == -9223372036854775807L || paramg.n == -9223372036854775807L) {
        l1 = f.c;
        if (l1 == -9223372036854775807L)
          l1 = paramg.m * 3L; 
      } 
    } 
    return l1 + paramLong;
  }
  
  private void K(g paramg, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : Lj/d/a/c/t2;
    //   4: getfield d : Lj/d/a/c/t2$g;
    //   7: astore #7
    //   9: aload #7
    //   11: getfield e : F
    //   14: ldc -3.4028235E38
    //   16: fcmpl
    //   17: ifne -> 64
    //   20: aload #7
    //   22: getfield f : F
    //   25: ldc -3.4028235E38
    //   27: fcmpl
    //   28: ifne -> 64
    //   31: aload_1
    //   32: getfield v : Lcom/google/android/exoplayer2/source/hls/u/g$f;
    //   35: astore_1
    //   36: aload_1
    //   37: getfield c : J
    //   40: ldc2_w -9223372036854775807
    //   43: lcmp
    //   44: ifne -> 64
    //   47: aload_1
    //   48: getfield d : J
    //   51: ldc2_w -9223372036854775807
    //   54: lcmp
    //   55: ifne -> 64
    //   58: iconst_1
    //   59: istore #6
    //   61: goto -> 67
    //   64: iconst_0
    //   65: istore #6
    //   67: new j/d/a/c/t2$g$a
    //   70: dup
    //   71: invokespecial <init> : ()V
    //   74: astore_1
    //   75: aload_1
    //   76: lload_2
    //   77: invokestatic X0 : (J)J
    //   80: invokevirtual k : (J)Lj/d/a/c/t2$g$a;
    //   83: pop
    //   84: fconst_1
    //   85: fstore #5
    //   87: iload #6
    //   89: ifeq -> 98
    //   92: fconst_1
    //   93: fstore #4
    //   95: goto -> 107
    //   98: aload_0
    //   99: getfield u : Lj/d/a/c/t2$g;
    //   102: getfield e : F
    //   105: fstore #4
    //   107: aload_1
    //   108: fload #4
    //   110: invokevirtual j : (F)Lj/d/a/c/t2$g$a;
    //   113: pop
    //   114: iload #6
    //   116: ifeq -> 126
    //   119: fload #5
    //   121: fstore #4
    //   123: goto -> 135
    //   126: aload_0
    //   127: getfield u : Lj/d/a/c/t2$g;
    //   130: getfield f : F
    //   133: fstore #4
    //   135: aload_1
    //   136: fload #4
    //   138: invokevirtual h : (F)Lj/d/a/c/t2$g$a;
    //   141: pop
    //   142: aload_0
    //   143: aload_1
    //   144: invokevirtual f : ()Lj/d/a/c/t2$g;
    //   147: putfield u : Lj/d/a/c/t2$g;
    //   150: return
  }
  
  protected void A(@Nullable n0 paramn0) {
    this.v = paramn0;
    this.m.prepare();
    a0 a01 = this.m;
    Looper looper = Looper.myLooper();
    e.e(looper);
    a01.b(looper, y());
    m0.a a = u(null);
    this.r.m(this.j.a, a, this);
  }
  
  protected void C() {
    this.r.stop();
    this.m.release();
  }
  
  public i0 a(l0.b paramb, i parami, long paramLong) {
    m0.a a1 = u(paramb);
    y.a a = s(paramb);
    return (i0)new o(this.i, this.r, this.k, this.v, this.m, a, this.n, a1, parami, this.l, this.o, this.p, this.q, y());
  }
  
  public void d(g paramg) {
    x0 x0;
    long l1;
    long l2;
    if (paramg.p) {
      l1 = m0.X0(paramg.h);
    } else {
      l1 = -9223372036854775807L;
    } 
    int i = paramg.d;
    if (i == 2 || i == 1) {
      l2 = l1;
    } else {
      l2 = -9223372036854775807L;
    } 
    h h1 = this.r.f();
    e.e(h1);
    l l3 = new l(h1, paramg);
    if (this.r.j()) {
      x0 = D(paramg, l2, l1, l3);
    } else {
      x0 = E((g)x0, l2, l1, l3);
    } 
    B((v3)x0);
  }
  
  public t2 getMediaItem() {
    return this.t;
  }
  
  public void i(i0 parami0) {
    ((o)parami0).q();
  }
  
  public void maybeThrowSourceInfoRefreshError() throws IOException {
    this.r.n();
  }
  
  public static final class Factory implements n0 {
    private final j a;
    
    private k b;
    
    private k c;
    
    private l.a d;
    
    private x e;
    
    private c0 f;
    
    private g0 g;
    
    private boolean h;
    
    private int i;
    
    private boolean j;
    
    private long k;
    
    public Factory(j param1j) {
      e.e(param1j);
      this.a = param1j;
      this.f = (c0)new u();
      this.c = (k)new c();
      this.d = d.q;
      this.b = k.a;
      this.g = (g0)new a0();
      this.e = (x)new z();
      this.i = 1;
      this.k = -9223372036854775807L;
      this.h = true;
    }
    
    public Factory(r.a param1a) {
      this((j)new f(param1a));
    }
    
    public HlsMediaSource a(t2 param1t2) {
      e e;
      e.e(param1t2.c);
      k k2 = this.c;
      List list = param1t2.c.e;
      k k1 = k2;
      if (!list.isEmpty())
        e = new e(k2, list); 
      j j1 = this.a;
      k k3 = this.b;
      x x1 = this.e;
      a0 a0 = this.f.a(param1t2);
      g0 g01 = this.g;
      return new HlsMediaSource(param1t2, j1, k3, x1, a0, g01, this.d.a(this.a, g01, (k)e), this.k, this.h, this.i, this.j, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\exoplayer2\source\hls\HlsMediaSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */