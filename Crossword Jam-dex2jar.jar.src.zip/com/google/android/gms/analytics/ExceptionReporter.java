package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.internal.gtm.zzch;
import java.util.ArrayList;
import java.util.Objects;

@VisibleForTesting
public class ExceptionReporter implements Thread.UncaughtExceptionHandler {
  private final Thread.UncaughtExceptionHandler zzrk;
  
  private final Tracker zzrl;
  
  private final Context zzrm;
  
  private ExceptionParser zzrn;
  
  private GoogleAnalytics zzro;
  
  public ExceptionReporter(Tracker paramTracker, Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler, Context paramContext) {
    Objects.requireNonNull(paramTracker, "tracker cannot be null");
    Objects.requireNonNull(paramContext, "context cannot be null");
    this.zzrk = paramUncaughtExceptionHandler;
    this.zzrl = paramTracker;
    this.zzrn = (ExceptionParser)new StandardExceptionParser(paramContext, new ArrayList());
    this.zzrm = paramContext.getApplicationContext();
    if (paramUncaughtExceptionHandler == null) {
      str = "null";
    } else {
      str = paramUncaughtExceptionHandler.getClass().getName();
    } 
    String str = String.valueOf(str);
    if (str.length() != 0) {
      str = "ExceptionReporter created, original handler is ".concat(str);
    } else {
      str = new String("ExceptionReporter created, original handler is ");
    } 
    zzch.zzab(str);
  }
  
  public ExceptionParser getExceptionParser() {
    return this.zzrn;
  }
  
  public void setExceptionParser(ExceptionParser paramExceptionParser) {
    this.zzrn = paramExceptionParser;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    String str1;
    if (this.zzrn != null) {
      if (paramThread != null) {
        str1 = paramThread.getName();
      } else {
        str1 = null;
      } 
      str1 = this.zzrn.getDescription(str1, paramThrowable);
    } else {
      str1 = "UncaughtException";
    } 
    String str2 = String.valueOf(str1);
    if (str2.length() != 0) {
      str2 = "Reporting uncaught exception: ".concat(str2);
    } else {
      str2 = new String("Reporting uncaught exception: ");
    } 
    zzch.zzab(str2);
    this.zzrl.send((new HitBuilders.ExceptionBuilder()).setDescription(str1).setFatal(true).build());
    if (this.zzro == null)
      this.zzro = GoogleAnalytics.getInstance(this.zzrm); 
    GoogleAnalytics googleAnalytics = this.zzro;
    googleAnalytics.dispatchLocalHits();
    googleAnalytics.zzab().zzcs().zzcj();
    if (this.zzrk != null) {
      zzch.zzab("Passing exception to the original handler");
      this.zzrk.uncaughtException(paramThread, paramThrowable);
    } 
  }
  
  final Thread.UncaughtExceptionHandler zzaf() {
    return this.zzrk;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\analytics\ExceptionReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */