package com.google.android.gms.ads.appopen;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.AdLoadCallback;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzavg;
import com.google.android.gms.internal.ads.zzbaj;
import com.google.android.gms.internal.ads.zzbar;
import com.google.android.gms.internal.ads.zzbci;
import com.google.android.gms.internal.ads.zzbyp;

public abstract class AppOpenAd {
  public static final int APP_OPEN_AD_ORIENTATION_LANDSCAPE = 2;
  
  public static final int APP_OPEN_AD_ORIENTATION_PORTRAIT = 1;
  
  @Deprecated
  public static void load(@NonNull Context paramContext, @NonNull String paramString, @NonNull AdRequest paramAdRequest, @AppOpenAdOrientation int paramInt, @NonNull AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "adUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdRequest, "AdRequest cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbar.zzc(paramContext);
    if (((Boolean)zzbci.zzd.zze()).booleanValue()) {
      zzbaj zzbaj = zzbar.zzjw;
      if (((Boolean)zzba.zzc().zzb(zzbaj)).booleanValue()) {
        zzbyp.zzb.execute((Runnable)new zzc(paramContext, paramString, paramAdRequest, paramInt, paramAppOpenAdLoadCallback));
        return;
      } 
    } 
    (new zzavg(paramContext, paramString, paramAdRequest.zza(), paramInt, paramAppOpenAdLoadCallback)).zza();
  }
  
  public static void load(@NonNull Context paramContext, @NonNull String paramString, @NonNull AdRequest paramAdRequest, @NonNull AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "adUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdRequest, "AdRequest cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbar.zzc(paramContext);
    if (((Boolean)zzbci.zzd.zze()).booleanValue()) {
      zzbaj zzbaj = zzbar.zzjw;
      if (((Boolean)zzba.zzc().zzb(zzbaj)).booleanValue()) {
        zzbyp.zzb.execute((Runnable)new zzb(paramContext, paramString, paramAdRequest, paramAppOpenAdLoadCallback));
        return;
      } 
    } 
    (new zzavg(paramContext, paramString, paramAdRequest.zza(), 3, paramAppOpenAdLoadCallback)).zza();
  }
  
  @Deprecated
  public static void load(@NonNull Context paramContext, @NonNull String paramString, @NonNull AdManagerAdRequest paramAdManagerAdRequest, @AppOpenAdOrientation int paramInt, @NonNull AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "adUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdManagerAdRequest, "AdManagerAdRequest cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbar.zzc(paramContext);
    if (((Boolean)zzbci.zzd.zze()).booleanValue()) {
      zzbaj zzbaj = zzbar.zzjw;
      if (((Boolean)zzba.zzc().zzb(zzbaj)).booleanValue()) {
        zzbyp.zzb.execute((Runnable)new zza(paramContext, paramString, paramAdManagerAdRequest, paramInt, paramAppOpenAdLoadCallback));
        return;
      } 
    } 
    (new zzavg(paramContext, paramString, paramAdManagerAdRequest.zza(), paramInt, paramAppOpenAdLoadCallback)).zza();
  }
  
  @NonNull
  public abstract String getAdUnitId();
  
  @Nullable
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  @Nullable
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  @NonNull
  public abstract ResponseInfo getResponseInfo();
  
  public abstract void setFullScreenContentCallback(@Nullable FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnPaidEventListener(@Nullable OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void show(@NonNull Activity paramActivity);
  
  public static abstract class AppOpenAdLoadCallback extends AdLoadCallback<AppOpenAd> {}
  
  public static @interface AppOpenAdOrientation {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\appopen\AppOpenAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */