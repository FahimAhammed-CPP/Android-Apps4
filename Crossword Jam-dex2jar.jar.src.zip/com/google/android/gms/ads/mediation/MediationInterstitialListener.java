package com.google.android.gms.ads.mediation;

import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;

@Deprecated
public interface MediationInterstitialListener {
  void onAdClicked(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter);
  
  void onAdClosed(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter);
  
  @Deprecated
  void onAdFailedToLoad(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter, int paramInt);
  
  void onAdFailedToLoad(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter, @NonNull AdError paramAdError);
  
  void onAdLeftApplication(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter);
  
  void onAdLoaded(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter);
  
  void onAdOpened(@NonNull MediationInterstitialAdapter paramMediationInterstitialAdapter);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationInterstitialListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */