package com.google.android.gms.ads.mediation;

public interface MediationExtrasReceiver {}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationExtrasReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */