package com.google.android.gms.ads;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.zzdw;
import com.google.android.gms.ads.internal.client.zzdx;
import com.google.android.gms.ads.mediation.MediationExtrasReceiver;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzbza;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class AdRequest {
  @NonNull
  public static final String DEVICE_ID_EMULATOR = "B3EEABB8EE11C2BE770B684D95219ECB";
  
  public static final int ERROR_CODE_APP_ID_MISSING = 8;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_AD_STRING = 11;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_MEDIATION_NO_FILL = 9;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  public static final int ERROR_CODE_REQUEST_ID_MISMATCH = 10;
  
  public static final int GENDER_FEMALE = 2;
  
  public static final int GENDER_MALE = 1;
  
  public static final int GENDER_UNKNOWN = 0;
  
  public static final int MAX_CONTENT_URL_LENGTH = 512;
  
  protected final zzdx zza;
  
  protected AdRequest(@NonNull Builder paramBuilder) {
    this.zza = new zzdx(paramBuilder.zza, null);
  }
  
  @Nullable
  public String getAdString() {
    return this.zza.zzj();
  }
  
  @NonNull
  public String getContentUrl() {
    return this.zza.zzk();
  }
  
  @Nullable
  public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(@NonNull Class<T> paramClass) {
    return this.zza.zzd(paramClass);
  }
  
  @NonNull
  public Bundle getCustomTargeting() {
    return this.zza.zze();
  }
  
  @NonNull
  public Set<String> getKeywords() {
    return this.zza.zzq();
  }
  
  @NonNull
  public List<String> getNeighboringContentUrls() {
    return this.zza.zzo();
  }
  
  @Nullable
  public <T extends MediationExtrasReceiver> Bundle getNetworkExtrasBundle(@NonNull Class<T> paramClass) {
    return this.zza.zzf(paramClass);
  }
  
  @NonNull
  public String getRequestAgent() {
    return this.zza.zzm();
  }
  
  public boolean isTestDevice(@NonNull Context paramContext) {
    return this.zza.zzs(paramContext);
  }
  
  public final zzdx zza() {
    return this.zza;
  }
  
  public static class Builder {
    protected final zzdw zza;
    
    public Builder() {
      zzdw zzdw1 = new zzdw();
      this.zza = zzdw1;
      zzdw1.zzv("B3EEABB8EE11C2BE770B684D95219ECB");
    }
    
    @NonNull
    public Builder addCustomEventExtrasBundle(@NonNull Class<? extends CustomEvent> param1Class, @NonNull Bundle param1Bundle) {
      this.zza.zzq(param1Class, param1Bundle);
      return this;
    }
    
    @NonNull
    public Builder addKeyword(@NonNull String param1String) {
      this.zza.zzs(param1String);
      return this;
    }
    
    @NonNull
    public Builder addNetworkExtrasBundle(@NonNull Class<? extends MediationExtrasReceiver> param1Class, @NonNull Bundle param1Bundle) {
      this.zza.zzt(param1Class, param1Bundle);
      if (param1Class.equals(AdMobAdapter.class) && param1Bundle.getBoolean("_emulatorLiveAds"))
        this.zza.zzw("B3EEABB8EE11C2BE770B684D95219ECB"); 
      return this;
    }
    
    @NonNull
    public AdRequest build() {
      return new AdRequest(this);
    }
    
    @NonNull
    public Builder setAdString(@NonNull String param1String) {
      this.zza.zzx(param1String);
      return this;
    }
    
    @NonNull
    public Builder setContentUrl(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String, "Content URL must be non-null.");
      Preconditions.checkNotEmpty(param1String, "Content URL must be non-empty.");
      int i = param1String.length();
      boolean bool = false;
      int j = param1String.length();
      if (i <= 512)
        bool = true; 
      Preconditions.checkArgument(bool, "Content URL must not exceed %d in length.  Provided length was %d.", new Object[] { Integer.valueOf(512), Integer.valueOf(j) });
      this.zza.zzz(param1String);
      return this;
    }
    
    @NonNull
    public Builder setHttpTimeoutMillis(int param1Int) {
      this.zza.zzB(param1Int);
      return this;
    }
    
    @NonNull
    public Builder setNeighboringContentUrls(@NonNull List<String> param1List) {
      if (param1List == null) {
        zzbza.zzj("neighboring content URLs list should not be null");
        return this;
      } 
      this.zza.zzD(param1List);
      return this;
    }
    
    @NonNull
    public Builder setRequestAgent(@NonNull String param1String) {
      this.zza.zzF(param1String);
      return this;
    }
    
    @Deprecated
    @NonNull
    public final Builder zza(@NonNull String param1String) {
      this.zza.zzv(param1String);
      return this;
    }
    
    @Deprecated
    @NonNull
    public final Builder zzb(@NonNull Date param1Date) {
      this.zza.zzy(param1Date);
      return this;
    }
    
    @Deprecated
    @NonNull
    public final Builder zzc(int param1Int) {
      this.zza.zzA(param1Int);
      return this;
    }
    
    @Deprecated
    @NonNull
    public final Builder zzd(boolean param1Boolean) {
      this.zza.zzC(param1Boolean);
      return this;
    }
    
    @Deprecated
    @NonNull
    public final Builder zze(boolean param1Boolean) {
      this.zza.zzG(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\AdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */