package com.google.android.gms.ads.internal.client;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.ads.zzbnc;
import com.google.android.gms.internal.ads.zzbnf;

@KeepForSdk
public class LiteSdkInfo extends zzck {
  public LiteSdkInfo(@NonNull Context paramContext) {}
  
  public zzbnf getAdapterCreator() {
    return (zzbnf)new zzbnc();
  }
  
  public zzen getLiteSdkVersion() {
    return new zzen(230500000, 230500000, "22.0.0");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\internal\client\LiteSdkInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */