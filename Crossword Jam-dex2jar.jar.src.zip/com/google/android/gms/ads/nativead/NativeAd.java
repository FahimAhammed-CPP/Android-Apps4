package com.google.android.gms.ads.nativead;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.MuteThisAdListener;
import com.google.android.gms.ads.MuteThisAdReason;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import java.util.List;

public abstract class NativeAd {
  public abstract void cancelUnconfirmedClick();
  
  public abstract void destroy();
  
  @Deprecated
  public abstract void enableCustomClickGesture();
  
  @Nullable
  public abstract AdChoicesInfo getAdChoicesInfo();
  
  @Nullable
  public abstract String getAdvertiser();
  
  @Nullable
  public abstract String getBody();
  
  @Nullable
  public abstract String getCallToAction();
  
  @NonNull
  public abstract Bundle getExtras();
  
  @Nullable
  public abstract String getHeadline();
  
  @Nullable
  public abstract Image getIcon();
  
  @NonNull
  public abstract List<Image> getImages();
  
  @Nullable
  public abstract MediaContent getMediaContent();
  
  @NonNull
  public abstract List<MuteThisAdReason> getMuteThisAdReasons();
  
  @Nullable
  public abstract String getPrice();
  
  @Nullable
  public abstract ResponseInfo getResponseInfo();
  
  @Nullable
  public abstract Double getStarRating();
  
  @Nullable
  public abstract String getStore();
  
  @Deprecated
  public abstract boolean isCustomClickGestureEnabled();
  
  public abstract boolean isCustomMuteThisAdEnabled();
  
  public abstract void muteThisAd(@NonNull MuteThisAdReason paramMuteThisAdReason);
  
  public abstract void performClick(@NonNull Bundle paramBundle);
  
  @Deprecated
  public abstract void recordCustomClickGesture();
  
  public abstract boolean recordImpression(@NonNull Bundle paramBundle);
  
  public abstract void reportTouchEvent(@NonNull Bundle paramBundle);
  
  public abstract void setMuteThisAdListener(@NonNull MuteThisAdListener paramMuteThisAdListener);
  
  public abstract void setOnPaidEventListener(@Nullable OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void setUnconfirmedClickListener(@NonNull UnconfirmedClickListener paramUnconfirmedClickListener);
  
  @Nullable
  protected abstract Object zza();
  
  public static abstract class AdChoicesInfo {
    @NonNull
    public abstract List<NativeAd.Image> getImages();
    
    @NonNull
    public abstract CharSequence getText();
  }
  
  public static abstract class Image {
    @Nullable
    public abstract Drawable getDrawable();
    
    public abstract double getScale();
    
    @Nullable
    public abstract Uri getUri();
  }
  
  public static interface OnNativeAdLoadedListener {
    void onNativeAdLoaded(@NonNull NativeAd param1NativeAd);
  }
  
  public static interface UnconfirmedClickListener {
    void onUnconfirmedClickCancelled();
    
    void onUnconfirmedClickReceived(@NonNull String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */