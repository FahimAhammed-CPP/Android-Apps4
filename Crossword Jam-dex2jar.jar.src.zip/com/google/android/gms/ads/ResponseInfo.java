package com.google.android.gms.ads;

import android.os.Bundle;
import android.os.RemoteException;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.internal.ads.zzbza;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ResponseInfo {
  @Nullable
  private final zzdn zza;
  
  private final List zzb;
  
  @Nullable
  private AdapterResponseInfo zzc;
  
  private ResponseInfo(@Nullable zzdn paramzzdn) {
    this.zza = paramzzdn;
    this.zzb = new ArrayList();
    if (paramzzdn != null)
      try {
        List list = paramzzdn.zzj();
        if (list != null) {
          Iterator<zzu> iterator = list.iterator();
          while (iterator.hasNext()) {
            AdapterResponseInfo adapterResponseInfo = AdapterResponseInfo.zza(iterator.next());
            if (adapterResponseInfo != null)
              this.zzb.add(adapterResponseInfo); 
          } 
        } 
      } catch (RemoteException remoteException) {
        zzbza.zzh("Could not forward getAdapterResponseInfo to ResponseInfo.", (Throwable)remoteException);
      }  
    paramzzdn = this.zza;
    if (paramzzdn == null)
      return; 
    try {
      zzu zzu = paramzzdn.zzf();
      if (zzu != null)
        this.zzc = AdapterResponseInfo.zza(zzu); 
      return;
    } catch (RemoteException remoteException) {
      zzbza.zzh("Could not forward getLoadedAdapterResponse to ResponseInfo.", (Throwable)remoteException);
      return;
    } 
  }
  
  @Nullable
  public static ResponseInfo zza(@Nullable zzdn paramzzdn) {
    return (paramzzdn != null) ? new ResponseInfo(paramzzdn) : null;
  }
  
  @NonNull
  public static ResponseInfo zzb(@Nullable zzdn paramzzdn) {
    return new ResponseInfo(paramzzdn);
  }
  
  @NonNull
  public List<AdapterResponseInfo> getAdapterResponses() {
    return this.zzb;
  }
  
  @Nullable
  public AdapterResponseInfo getLoadedAdapterResponseInfo() {
    return this.zzc;
  }
  
  @Nullable
  public String getMediationAdapterClassName() {
    try {
      zzdn zzdn1 = this.zza;
      if (zzdn1 != null)
        return zzdn1.zzg(); 
    } catch (RemoteException remoteException) {
      zzbza.zzh("Could not forward getMediationAdapterClassName to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  @NonNull
  public Bundle getResponseExtras() {
    try {
      zzdn zzdn1 = this.zza;
      if (zzdn1 != null)
        return zzdn1.zze(); 
    } catch (RemoteException remoteException) {
      zzbza.zzh("Could not forward getResponseExtras to ResponseInfo.", (Throwable)remoteException);
    } 
    return new Bundle();
  }
  
  @Nullable
  public String getResponseId() {
    try {
      zzdn zzdn1 = this.zza;
      if (zzdn1 != null)
        return zzdn1.zzi(); 
    } catch (RemoteException remoteException) {
      zzbza.zzh("Could not forward getResponseId to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  @NonNull
  public String toString() {
    try {
      return zzd().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  @Nullable
  @VisibleForTesting
  public final zzdn zzc() {
    return this.zza;
  }
  
  @NonNull
  public final JSONObject zzd() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    String str = getResponseId();
    if (str == null) {
      jSONObject.put("Response ID", "null");
    } else {
      jSONObject.put("Response ID", str);
    } 
    str = getMediationAdapterClassName();
    if (str == null) {
      jSONObject.put("Mediation Adapter Class Name", "null");
    } else {
      jSONObject.put("Mediation Adapter Class Name", str);
    } 
    JSONArray jSONArray = new JSONArray();
    Iterator<AdapterResponseInfo> iterator = this.zzb.iterator();
    while (iterator.hasNext())
      jSONArray.put(((AdapterResponseInfo)iterator.next()).zzb()); 
    jSONObject.put("Adapter Responses", jSONArray);
    AdapterResponseInfo adapterResponseInfo = this.zzc;
    if (adapterResponseInfo != null)
      jSONObject.put("Loaded Adapter Response", adapterResponseInfo.zzb()); 
    Bundle bundle = getResponseExtras();
    if (bundle != null)
      jSONObject.put("Response Extras", zzay.zzb().zzi(bundle)); 
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\ads\ResponseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */