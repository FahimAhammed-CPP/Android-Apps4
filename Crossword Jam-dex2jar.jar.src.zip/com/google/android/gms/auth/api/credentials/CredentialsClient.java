package com.google.android.gms.auth.api.credentials;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.api.Response;
import com.google.android.gms.common.api.internal.ApiExceptionMapper;
import com.google.android.gms.common.api.internal.StatusExceptionMapper;
import com.google.android.gms.common.internal.PendingResultUtil;
import com.google.android.gms.internal.auth-api.zbn;
import com.google.android.gms.tasks.Task;

@Deprecated
public class CredentialsClient extends GoogleApi<Auth.AuthCredentialsOptions> {
  CredentialsClient(@NonNull Activity paramActivity, @NonNull Auth.AuthCredentialsOptions paramAuthCredentialsOptions) {
    super(paramActivity, Auth.CREDENTIALS_API, (Api.ApiOptions)paramAuthCredentialsOptions, (StatusExceptionMapper)new ApiExceptionMapper());
  }
  
  CredentialsClient(@NonNull Context paramContext, @NonNull Auth.AuthCredentialsOptions paramAuthCredentialsOptions) {
    super(paramContext, Auth.CREDENTIALS_API, (Api.ApiOptions)paramAuthCredentialsOptions, (StatusExceptionMapper)new ApiExceptionMapper());
  }
  
  @Deprecated
  @NonNull
  public Task<Void> delete(@NonNull Credential paramCredential) {
    return PendingResultUtil.toVoidTask(Auth.CredentialsApi.delete(asGoogleApiClient(), paramCredential));
  }
  
  @Deprecated
  @NonNull
  public Task<Void> disableAutoSignIn() {
    return PendingResultUtil.toVoidTask(Auth.CredentialsApi.disableAutoSignIn(asGoogleApiClient()));
  }
  
  @Deprecated
  @NonNull
  public PendingIntent getHintPickerIntent(@NonNull HintRequest paramHintRequest) {
    return zbn.zba(getApplicationContext(), (Auth.AuthCredentialsOptions)getApiOptions(), paramHintRequest, ((Auth.AuthCredentialsOptions)getApiOptions()).zbd());
  }
  
  @Deprecated
  @NonNull
  public Task<CredentialRequestResponse> request(@NonNull CredentialRequest paramCredentialRequest) {
    return PendingResultUtil.toResponseTask(Auth.CredentialsApi.request(asGoogleApiClient(), paramCredentialRequest), (Response)new CredentialRequestResponse());
  }
  
  @Deprecated
  @NonNull
  public Task<Void> save(@NonNull Credential paramCredential) {
    return PendingResultUtil.toVoidTask(Auth.CredentialsApi.save(asGoogleApiClient(), paramCredential));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\auth\api\credentials\CredentialsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */