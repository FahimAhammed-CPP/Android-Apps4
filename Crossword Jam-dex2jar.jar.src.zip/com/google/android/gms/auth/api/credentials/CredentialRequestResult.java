package com.google.android.gms.auth.api.credentials;

import androidx.annotation.Nullable;
import com.google.android.gms.common.api.Result;

@Deprecated
public interface CredentialRequestResult extends Result {
  @Nullable
  Credential getCredential();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\google\android\gms\auth\api\credentials\CredentialRequestResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */