package com.facebook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.facebook.common.R;
import com.facebook.internal.FragmentWrapper;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;

public abstract class FacebookButtonBase extends Button {
  private String analyticsButtonCreatedEventName;
  
  private String analyticsButtonTappedEventName;
  
  private View.OnClickListener externalOnClickListener;
  
  private View.OnClickListener internalOnClickListener;
  
  private boolean overrideCompoundPadding;
  
  private int overrideCompoundPaddingLeft;
  
  private int overrideCompoundPaddingRight;
  
  private FragmentWrapper parentFragment;
  
  protected FacebookButtonBase(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, String paramString1, String paramString2) {
    super(paramContext, paramAttributeSet, 0);
    int i = paramInt2;
    if (paramInt2 == 0)
      i = getDefaultStyleResource(); 
    paramInt2 = i;
    if (i == 0)
      paramInt2 = R.style.com_facebook_button; 
    configureButton(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.analyticsButtonCreatedEventName = paramString1;
    this.analyticsButtonTappedEventName = paramString2;
    setClickable(true);
    setFocusable(true);
  }
  
  private void parseBackgroundAttributes(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      if (isInEditMode())
        return; 
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  @SuppressLint({"ResourceType"})
  private void parseCompoundDrawableAttributes(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
    
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  private void parseContentAttributes(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
    
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  private void parseTextAttributes(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
    
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  private void setupOnClickListener() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected void callExternalOnClickListener(View paramView) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramView = null;
      CrashShieldHandler.handleThrowable((Throwable)paramView, this);
    } 
  }
  
  protected void configureButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      parseBackgroundAttributes(paramContext, paramAttributeSet, paramInt1, paramInt2);
      parseCompoundDrawableAttributes(paramContext, paramAttributeSet, paramInt1, paramInt2);
      parseContentAttributes(paramContext, paramAttributeSet, paramInt1, paramInt2);
      return;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  protected Activity getActivity() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      Context context;
      for (context = getContext(); !(context instanceof Activity) && context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext());
      if (context instanceof Activity)
        return (Activity)context; 
      throw new FacebookException("Unable to get Activity.");
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected String getAnalyticsButtonCreatedEventName() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.analyticsButtonCreatedEventName;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected String getAnalyticsButtonTappedEventName() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.analyticsButtonTappedEventName;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @Nullable
  public ActivityResultRegistryOwner getAndroidxActivityResultRegistryOwner() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return (activity instanceof ActivityResultRegistryOwner) ? (ActivityResultRegistryOwner)activity : null;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public int getCompoundPaddingLeft() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return 0; 
    try {
      return this.overrideCompoundPadding ? this.overrideCompoundPaddingLeft : super.getCompoundPaddingLeft();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public int getCompoundPaddingRight() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return 0; 
    try {
      return this.overrideCompoundPadding ? this.overrideCompoundPaddingRight : super.getCompoundPaddingRight();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected abstract int getDefaultRequestCode();
  
  protected int getDefaultStyleResource() {
    if (CrashShieldHandler.isObjectCrashing(this));
    return 0;
  }
  
  public Fragment getFragment() {
    boolean bool = CrashShieldHandler.isObjectCrashing(this);
    Fragment fragment = null;
    if (bool)
      return null; 
    try {
      return fragment;
    } finally {
      fragment = null;
      CrashShieldHandler.handleThrowable((Throwable)fragment, this);
    } 
  }
  
  public Fragment getNativeFragment() {
    boolean bool = CrashShieldHandler.isObjectCrashing(this);
    Fragment fragment = null;
    if (bool)
      return null; 
    try {
      return fragment;
    } finally {
      fragment = null;
      CrashShieldHandler.handleThrowable((Throwable)fragment, this);
    } 
  }
  
  public int getRequestCode() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return 0; 
    try {
      return getDefaultRequestCode();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected void logButtonCreated(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  protected void logButtonTapped(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  protected int measureTextWidth(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return 0; 
    try {
      return (int)d;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, this);
    } 
  }
  
  protected void onAttachedToWindow() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      int i;
      if ((getGravity() & 0x1) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        i = getCompoundPaddingLeft();
        int j = getCompoundPaddingRight();
        int k = getCompoundDrawablePadding();
        k = Math.min((getWidth() - k + i - j - measureTextWidth(getText().toString())) / 2, (i - getPaddingLeft()) / 2);
        this.overrideCompoundPaddingLeft = i - k;
        this.overrideCompoundPaddingRight = j + k;
        this.overrideCompoundPadding = true;
      } 
      return;
    } finally {
      paramCanvas = null;
      CrashShieldHandler.handleThrowable((Throwable)paramCanvas, this);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setFragment(Fragment paramFragment) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramFragment = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFragment, this);
    } 
  }
  
  public void setFragment(Fragment paramFragment) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramFragment = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFragment, this);
    } 
  }
  
  protected void setInternalOnClickListener(View.OnClickListener paramOnClickListener) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramOnClickListener = null;
      CrashShieldHandler.handleThrowable((Throwable)paramOnClickListener, this);
    } 
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramOnClickListener = null;
      CrashShieldHandler.handleThrowable((Throwable)paramOnClickListener, this);
    } 
  }
  
  class a implements View.OnClickListener {
    a(FacebookButtonBase this$0) {}
    
    public void onClick(View param1View) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        FacebookButtonBase facebookButtonBase = this.b;
        facebookButtonBase.logButtonTapped(facebookButtonBase.getContext());
        return;
      } finally {
        param1View = null;
        CrashShieldHandler.handleThrowable((Throwable)param1View, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\FacebookButtonBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */