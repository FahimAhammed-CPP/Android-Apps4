package com.facebook.messenger;

import java.util.List;

public class MessengerThreadParams {
  public final String metadata;
  
  public final Origin origin;
  
  public final List<String> participants;
  
  public final String threadToken;
  
  public MessengerThreadParams(Origin paramOrigin, String paramString1, String paramString2, List<String> paramList) {
    this.threadToken = paramString1;
    this.metadata = paramString2;
    this.participants = paramList;
    this.origin = paramOrigin;
  }
  
  public enum Origin {
    COMPOSE_FLOW, REPLY_FLOW, UNKNOWN;
    
    static {
      Origin origin1 = new Origin("REPLY_FLOW", 0);
      REPLY_FLOW = origin1;
      Origin origin2 = new Origin("COMPOSE_FLOW", 1);
      COMPOSE_FLOW = origin2;
      Origin origin3 = new Origin("UNKNOWN", 2);
      UNKNOWN = origin3;
      $VALUES = new Origin[] { origin1, origin2, origin3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\messenger\MessengerThreadParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */