package com.facebook.gamingservices.cloudgaming;

import android.content.Context;
import androidx.annotation.Nullable;
import com.facebook.GraphResponse;
import com.facebook.gamingservices.cloudgaming.internal.SDKLogger;
import com.facebook.gamingservices.cloudgaming.internal.SDKMessageEnum;
import org.json.JSONException;
import org.json.JSONObject;

public class GameFeaturesLibrary {
  public static void canCreateShortcut(Context paramContext, JSONObject paramJSONObject, DaemonRequest.Callback paramCallback) {
    DaemonRequest.executeAsync(paramContext, paramJSONObject, paramCallback, SDKMessageEnum.CAN_CREATE_SHORTCUT);
  }
  
  public static void createShortcut(Context paramContext, JSONObject paramJSONObject, DaemonRequest.Callback paramCallback) {
    DaemonRequest.executeAsync(paramContext, paramJSONObject, paramCallback, SDKMessageEnum.CREATE_SHORTCUT);
  }
  
  public static void createTournamentAsync(Context paramContext, int paramInt, @Nullable String paramString1, @Nullable String paramString2, @Nullable String paramString3, @Nullable String paramString4, @Nullable Integer paramInteger, @Nullable JSONObject paramJSONObject, DaemonRequest.Callback paramCallback) {
    try {
      DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("initialScore", paramInt).put("title", paramString1).put("image", paramString2).put("sortOrder", paramString3).put("scoreFormat", paramString4).put("endTime", paramInteger).put("data", paramJSONObject), paramCallback, SDKMessageEnum.TOURNAMENT_CREATE_ASYNC);
      return;
    } catch (JSONException jSONException) {
      SDKLogger.logInternalError(paramContext, SDKMessageEnum.TOURNAMENT_CREATE_ASYNC, (Exception)jSONException);
      return;
    } 
  }
  
  public static void getPayload(Context paramContext, JSONObject paramJSONObject, DaemonRequest.Callback paramCallback) {
    DaemonRequest.executeAsync(paramContext, paramJSONObject, paramCallback, SDKMessageEnum.GET_PAYLOAD);
  }
  
  public static void getTournamentAsync(Context paramContext, DaemonRequest.Callback paramCallback) {
    DaemonRequest.executeAsync(paramContext, null, paramCallback, SDKMessageEnum.GET_TOURNAMENT_ASYNC);
  }
  
  public static void getTournamentsAsync(Context paramContext, DaemonRequest.Callback paramCallback) throws JSONException {
    DaemonRequest.executeAsync(paramContext, null, paramCallback, SDKMessageEnum.TOURNAMENT_GET_TOURNAMENTS_ASYNC);
  }
  
  public static void joinTournamentAsync(Context paramContext, String paramString, DaemonRequest.Callback paramCallback) throws JSONException {
    DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("tournamentId", paramString), paramCallback, SDKMessageEnum.TOURNAMENT_JOIN_ASYNC);
  }
  
  public static void performHapticFeedback(Context paramContext) {
    DaemonRequest.executeAsync(paramContext, null, new a(), SDKMessageEnum.PERFORM_HAPTIC_FEEDBACK_ASYNC);
  }
  
  public static void postSessionScore(Context paramContext, int paramInt, DaemonRequest.Callback paramCallback) {
    try {
      DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("score", paramInt), paramCallback, SDKMessageEnum.POST_SESSION_SCORE);
      return;
    } catch (JSONException jSONException) {
      SDKLogger.logInternalError(paramContext, SDKMessageEnum.POST_SESSION_SCORE, (Exception)jSONException);
      return;
    } 
  }
  
  public static void postSessionScoreAsync(Context paramContext, int paramInt, DaemonRequest.Callback paramCallback) {
    try {
      DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("score", paramInt), paramCallback, SDKMessageEnum.POST_SESSION_SCORE_ASYNC);
      return;
    } catch (JSONException jSONException) {
      SDKLogger.logInternalError(paramContext, SDKMessageEnum.POST_SESSION_SCORE_ASYNC, (Exception)jSONException);
      return;
    } 
  }
  
  public static void postTournamentScoreAsync(Context paramContext, int paramInt, DaemonRequest.Callback paramCallback) throws JSONException {
    DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("score", paramInt), paramCallback, SDKMessageEnum.TOURNAMENT_POST_SCORE_ASYNC);
  }
  
  public static void shareTournamentAsync(Context paramContext, @Nullable Integer paramInteger, @Nullable JSONObject paramJSONObject, DaemonRequest.Callback paramCallback) {
    try {
      DaemonRequest.executeAsync(paramContext, (new JSONObject()).put("score", paramInteger).put("data", paramJSONObject), paramCallback, SDKMessageEnum.TOURNAMENT_SHARE_ASYNC);
      return;
    } catch (JSONException jSONException) {
      SDKLogger.logInternalError(paramContext, SDKMessageEnum.TOURNAMENT_SHARE_ASYNC, (Exception)jSONException);
      return;
    } 
  }
  
  static final class a implements DaemonRequest.Callback {
    public void onCompleted(GraphResponse param1GraphResponse) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\gamingservices\cloudgaming\GameFeaturesLibrary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */