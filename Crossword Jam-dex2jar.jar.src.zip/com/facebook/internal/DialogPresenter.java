package com.facebook.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Pair;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.contract.ActivityResultContract;
import com.facebook.CallbackManager;
import com.facebook.CustomTabMainActivity;
import com.facebook.FacebookActivity;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.InternalAppEventsLogger;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import kotlin.Metadata;
import kotlin.d0.d.b0;
import kotlin.d0.d.m;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\025\n\000\n\002\020\016\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\000\n\002\020\b\n\002\b\002\bÆ\002\030\0002\0020\001:\0016B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007J\020\020\007\032\0020\0042\006\020\005\032\0020\006H\007J\022\020\b\032\004\030\0010\t2\006\020\005\032\0020\006H\002J\020\020\n\032\0020\0132\006\020\005\032\0020\006H\007J \020\f\032\0020\r2\006\020\016\032\0020\0172\006\020\020\032\0020\0172\006\020\005\032\0020\006H\002J \020\021\032\0020\0222\006\020\023\032\0020\0242\006\020\025\032\0020\0172\006\020\026\032\0020\017H\007J\030\020\027\032\0020\0222\006\020\030\032\0020\0312\006\020\032\032\0020\033H\007J\"\020\027\032\0020\0222\006\020\030\032\0020\0312\006\020\034\032\0020\0352\b\020\036\032\004\030\0010\037H\007J\030\020\027\032\0020\0222\006\020\030\032\0020\0312\006\020 \032\0020!H\007J\020\020\"\032\0020\0222\006\020\030\032\0020\031H\007J$\020#\032\0020\0222\006\020\030\032\0020\0312\b\020$\032\004\030\0010\0172\b\020%\032\004\030\0010&H\007J\032\020'\032\0020\0222\006\020\030\032\0020\0312\b\020(\032\004\030\0010)H\007J \020*\032\0020\0222\006\020\030\032\0020\0312\006\020+\032\0020,2\006\020\005\032\0020\006H\007J\032\020-\032\0020\0222\006\020\030\032\0020\0312\b\020.\032\004\030\0010)H\007J$\020/\032\0020\0222\006\020\030\032\0020\0312\b\020\020\032\004\030\0010\0172\b\020%\032\004\030\0010&H\007J\"\0200\032\0020\0222\006\020\030\032\0020\0312\b\020%\032\004\030\0010&2\006\020\005\032\0020\006H\007J*\0201\032\0020\0222\006\020\034\032\0020\0352\b\020\036\032\004\030\0010\0372\006\0202\032\002032\006\0204\032\00205H\007¨\0067"}, d2 = {"Lcom/facebook/internal/DialogPresenter;", "", "()V", "canPresentNativeDialogWithFeature", "", "feature", "Lcom/facebook/internal/DialogFeature;", "canPresentWebFallbackDialogWithFeature", "getDialogWebFallbackUri", "Landroid/net/Uri;", "getProtocolVersionForNativeDialog", "Lcom/facebook/internal/NativeProtocol$ProtocolVersionQueryResult;", "getVersionSpecForFeature", "", "applicationId", "", "actionName", "logDialogActivity", "", "context", "Landroid/content/Context;", "eventName", "outcome", "present", "appCall", "Lcom/facebook/internal/AppCall;", "activity", "Landroid/app/Activity;", "registry", "Landroidx/activity/result/ActivityResultRegistry;", "callbackManager", "Lcom/facebook/CallbackManager;", "fragmentWrapper", "Lcom/facebook/internal/FragmentWrapper;", "setupAppCallForCannotShowError", "setupAppCallForCustomTabDialog", "action", "parameters", "Landroid/os/Bundle;", "setupAppCallForErrorResult", "exception", "Lcom/facebook/FacebookException;", "setupAppCallForNativeDialog", "parameterProvider", "Lcom/facebook/internal/DialogPresenter$ParameterProvider;", "setupAppCallForValidationError", "validationError", "setupAppCallForWebDialog", "setupAppCallForWebFallbackDialog", "startActivityForResultWithAndroidX", "intent", "Landroid/content/Intent;", "requestCode", "", "ParameterProvider", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
public final class DialogPresenter {
  public static final DialogPresenter INSTANCE = new DialogPresenter();
  
  public static final boolean canPresentNativeDialogWithFeature(DialogFeature paramDialogFeature) {
    m.f(paramDialogFeature, "feature");
    return (getProtocolVersionForNativeDialog(paramDialogFeature).getProtocolVersion() != -1);
  }
  
  public static final boolean canPresentWebFallbackDialogWithFeature(DialogFeature paramDialogFeature) {
    m.f(paramDialogFeature, "feature");
    return (INSTANCE.getDialogWebFallbackUri(paramDialogFeature) != null);
  }
  
  private final Uri getDialogWebFallbackUri(DialogFeature paramDialogFeature) {
    String str2 = paramDialogFeature.name();
    String str1 = paramDialogFeature.getAction();
    String str3 = FacebookSdk.getApplicationId();
    FetchedAppSettings.DialogFeatureConfig dialogFeatureConfig = FetchedAppSettings.Companion.getDialogFeatureConfig(str3, str1, str2);
    return (dialogFeatureConfig != null) ? dialogFeatureConfig.getFallbackUrl() : null;
  }
  
  public static final NativeProtocol.ProtocolVersionQueryResult getProtocolVersionForNativeDialog(DialogFeature paramDialogFeature) {
    m.f(paramDialogFeature, "feature");
    String str1 = FacebookSdk.getApplicationId();
    String str2 = paramDialogFeature.getAction();
    return NativeProtocol.getLatestAvailableProtocolVersionForAction(str2, INSTANCE.getVersionSpecForFeature(str1, str2, paramDialogFeature));
  }
  
  private final int[] getVersionSpecForFeature(String paramString1, String paramString2, DialogFeature paramDialogFeature) {
    FetchedAppSettings.DialogFeatureConfig dialogFeatureConfig = FetchedAppSettings.Companion.getDialogFeatureConfig(paramString1, paramString2, paramDialogFeature.name());
    if (dialogFeatureConfig != null) {
      int[] arrayOfInt = dialogFeatureConfig.getVersionSpec();
      if (arrayOfInt != null)
        return arrayOfInt; 
    } 
    return new int[] { paramDialogFeature.getMinVersion() };
  }
  
  public static final void logDialogActivity(Context paramContext, String paramString1, String paramString2) {
    m.f(paramContext, "context");
    m.f(paramString1, "eventName");
    m.f(paramString2, "outcome");
    InternalAppEventsLogger internalAppEventsLogger = new InternalAppEventsLogger(paramContext);
    Bundle bundle = new Bundle();
    bundle.putString("fb_dialog_outcome", paramString2);
    internalAppEventsLogger.logEventImplicitly(paramString1, bundle);
  }
  
  public static final void present(AppCall paramAppCall, Activity paramActivity) {
    m.f(paramAppCall, "appCall");
    m.f(paramActivity, "activity");
    safedk_Activity_startActivityForResult_206f42f0b65887e835d87ee52d14d221(paramActivity, paramAppCall.getRequestIntent(), paramAppCall.getRequestCode());
    paramAppCall.setPending();
  }
  
  public static final void present(AppCall paramAppCall, ActivityResultRegistry paramActivityResultRegistry, CallbackManager paramCallbackManager) {
    m.f(paramAppCall, "appCall");
    m.f(paramActivityResultRegistry, "registry");
    Intent intent = paramAppCall.getRequestIntent();
    if (intent != null) {
      startActivityForResultWithAndroidX(paramActivityResultRegistry, paramCallbackManager, intent, paramAppCall.getRequestCode());
      paramAppCall.setPending();
    } 
  }
  
  public static final void present(AppCall paramAppCall, FragmentWrapper paramFragmentWrapper) {
    m.f(paramAppCall, "appCall");
    m.f(paramFragmentWrapper, "fragmentWrapper");
    safedk_FragmentWrapper_startActivityForResult_51accca8f1bb017fcda2a6aac31602e6(paramFragmentWrapper, paramAppCall.getRequestIntent(), paramAppCall.getRequestCode());
    paramAppCall.setPending();
  }
  
  public static void safedk_Activity_startActivityForResult_206f42f0b65887e835d87ee52d14d221(Activity paramActivity, Intent paramIntent, int paramInt) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.facebook");
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }
  
  public static void safedk_FragmentWrapper_startActivityForResult_51accca8f1bb017fcda2a6aac31602e6(FragmentWrapper paramFragmentWrapper, Intent paramIntent, int paramInt) {
    Logger.d("SafeDK-Special|SafeDK: Call> Lcom/facebook/internal/FragmentWrapper;->startActivityForResult(Landroid/content/Intent;I)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.facebook");
    paramFragmentWrapper.startActivityForResult(paramIntent, paramInt);
  }
  
  public static final void setupAppCallForCannotShowError(AppCall paramAppCall) {
    m.f(paramAppCall, "appCall");
    setupAppCallForValidationError(paramAppCall, new FacebookException("Unable to show the provided content via the web or the installed version of the Facebook app. Some dialogs are only supported starting API 14."));
  }
  
  public static final void setupAppCallForCustomTabDialog(AppCall paramAppCall, String paramString, Bundle paramBundle) {
    m.f(paramAppCall, "appCall");
    Validate.hasCustomTabRedirectActivity(FacebookSdk.getApplicationContext(), CustomTabUtils.getDefaultRedirectURI());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    Intent intent = new Intent(FacebookSdk.getApplicationContext(), CustomTabMainActivity.class);
    intent.putExtra(CustomTabMainActivity.EXTRA_ACTION, paramString);
    intent.putExtra(CustomTabMainActivity.EXTRA_PARAMS, paramBundle);
    intent.putExtra(CustomTabMainActivity.EXTRA_CHROME_PACKAGE, CustomTabUtils.getChromePackage());
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramString, NativeProtocol.getLatestKnownVersion(), null);
    paramAppCall.setRequestIntent(intent);
  }
  
  public static final void setupAppCallForErrorResult(AppCall paramAppCall, FacebookException paramFacebookException) {
    m.f(paramAppCall, "appCall");
    if (paramFacebookException == null)
      return; 
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Intent intent = new Intent();
    intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
    intent.setAction("PassThrough");
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), null, NativeProtocol.getLatestKnownVersion(), NativeProtocol.createBundleForException(paramFacebookException));
    paramAppCall.setRequestIntent(intent);
  }
  
  public static final void setupAppCallForNativeDialog(AppCall paramAppCall, ParameterProvider paramParameterProvider, DialogFeature paramDialogFeature) {
    m.f(paramAppCall, "appCall");
    m.f(paramParameterProvider, "parameterProvider");
    m.f(paramDialogFeature, "feature");
    Context context = FacebookSdk.getApplicationContext();
    String str = paramDialogFeature.getAction();
    NativeProtocol.ProtocolVersionQueryResult protocolVersionQueryResult = getProtocolVersionForNativeDialog(paramDialogFeature);
    int i = protocolVersionQueryResult.getProtocolVersion();
    if (i != -1) {
      Bundle bundle1;
      if (NativeProtocol.isVersionCompatibleWithBucketedIntent(i)) {
        bundle1 = paramParameterProvider.getParameters();
      } else {
        bundle1 = bundle1.getLegacyParameters();
      } 
      Bundle bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      Intent intent = NativeProtocol.createPlatformActivityIntent(context, paramAppCall.getCallId().toString(), str, protocolVersionQueryResult, bundle2);
      if (intent != null) {
        paramAppCall.setRequestIntent(intent);
        return;
      } 
      throw new FacebookException("Unable to create Intent; this likely means theFacebook app is not installed.");
    } 
    throw new FacebookException("Cannot present this dialog. This likely means that the Facebook app is not installed.");
  }
  
  public static final void setupAppCallForValidationError(AppCall paramAppCall, FacebookException paramFacebookException) {
    m.f(paramAppCall, "appCall");
    setupAppCallForErrorResult(paramAppCall, paramFacebookException);
  }
  
  public static final void setupAppCallForWebDialog(AppCall paramAppCall, String paramString, Bundle paramBundle) {
    m.f(paramAppCall, "appCall");
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    Bundle bundle = new Bundle();
    bundle.putString("action", paramString);
    bundle.putBundle("params", paramBundle);
    Intent intent = new Intent();
    NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramString, NativeProtocol.getLatestKnownVersion(), bundle);
    intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
    intent.setAction("FacebookDialogFragment");
    paramAppCall.setRequestIntent(intent);
  }
  
  public static final void setupAppCallForWebFallbackDialog(AppCall paramAppCall, Bundle paramBundle, DialogFeature paramDialogFeature) {
    m.f(paramAppCall, "appCall");
    m.f(paramDialogFeature, "feature");
    Validate.hasFacebookActivity(FacebookSdk.getApplicationContext());
    Validate.hasInternetPermissions(FacebookSdk.getApplicationContext());
    String str = paramDialogFeature.name();
    Uri uri = INSTANCE.getDialogWebFallbackUri(paramDialogFeature);
    if (uri != null) {
      int i = NativeProtocol.getLatestKnownVersion();
      str = paramAppCall.getCallId().toString();
      m.e(str, "appCall.callId.toString()");
      paramBundle = ServerProtocol.getQueryParamsForPlatformActivityIntentWebFallback(str, i, paramBundle);
      if (paramBundle != null) {
        Uri uri1;
        if (uri.isRelative()) {
          uri1 = Utility.buildUri(ServerProtocol.getDialogAuthority(), uri.toString(), paramBundle);
        } else {
          uri1 = Utility.buildUri(uri.getAuthority(), uri.getPath(), (Bundle)uri1);
        } 
        Bundle bundle = new Bundle();
        bundle.putString("url", uri1.toString());
        bundle.putBoolean("is_fallback", true);
        Intent intent = new Intent();
        NativeProtocol.setupProtocolRequestIntent(intent, paramAppCall.getCallId().toString(), paramDialogFeature.getAction(), NativeProtocol.getLatestKnownVersion(), bundle);
        intent.setClass(FacebookSdk.getApplicationContext(), FacebookActivity.class);
        intent.setAction("FacebookDialogFragment");
        paramAppCall.setRequestIntent(intent);
        return;
      } 
      throw new FacebookException("Unable to fetch the app's key-hash");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to fetch the Url for the DialogFeature : '");
    stringBuilder.append(str);
    stringBuilder.append('\'');
    throw new FacebookException(stringBuilder.toString());
  }
  
  public static final void startActivityForResultWithAndroidX(ActivityResultRegistry paramActivityResultRegistry, CallbackManager paramCallbackManager, Intent paramIntent, int paramInt) {
    m.f(paramActivityResultRegistry, "registry");
    m.f(paramIntent, "intent");
    b0 b0 = new b0();
    b0.b = null;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("facebook-dialog-request-");
    stringBuilder.append(paramInt);
    ActivityResultLauncher activityResultLauncher = paramActivityResultRegistry.register(stringBuilder.toString(), new DialogPresenter$startActivityForResultWithAndroidX$1(), new a(paramCallbackManager, paramInt, b0));
    b0.b = activityResultLauncher;
    activityResultLauncher = activityResultLauncher;
    if (activityResultLauncher != null)
      activityResultLauncher.launch(paramIntent); 
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\005\bf\030\0002\0020\001R\024\020\002\032\004\030\0010\003X¦\004¢\006\006\032\004\b\004\020\005R\024\020\006\032\004\030\0010\003X¦\004¢\006\006\032\004\b\007\020\005¨\006\b"}, d2 = {"Lcom/facebook/internal/DialogPresenter$ParameterProvider;", "", "legacyParameters", "Landroid/os/Bundle;", "getLegacyParameters", "()Landroid/os/Bundle;", "parameters", "getParameters", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static interface ParameterProvider {
    Bundle getLegacyParameters();
    
    Bundle getParameters();
  }
  
  @Metadata(d1 = {"\000\030\n\000\n\002\020\002\n\000\n\002\030\002\n\002\020\b\n\002\030\002\n\002\b\002\020\000\032\0020\0012*\020\002\032&\022\004\022\0020\004\022\006\022\004\030\0010\005 \006*\022\022\004\022\0020\004\022\006\022\004\030\0010\005\030\0010\0030\003H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "result", "Landroid/util/Pair;", "", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "onActivityResult"}, k = 3, mv = {1, 5, 1})
  static final class a<O> implements ActivityResultCallback {
    a(CallbackManager param1CallbackManager, int param1Int, b0 param1b0) {}
    
    public final void a(Pair<Integer, Intent> param1Pair) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lcom/facebook/CallbackManager;
      //   4: astore #4
      //   6: aload #4
      //   8: astore_3
      //   9: aload #4
      //   11: ifnonnull -> 22
      //   14: new com/facebook/internal/CallbackManagerImpl
      //   17: dup
      //   18: invokespecial <init> : ()V
      //   21: astore_3
      //   22: aload_0
      //   23: getfield b : I
      //   26: istore_2
      //   27: aload_1
      //   28: getfield first : Ljava/lang/Object;
      //   31: astore #4
      //   33: aload #4
      //   35: ldc 'result.first'
      //   37: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
      //   40: aload_3
      //   41: iload_2
      //   42: aload #4
      //   44: checkcast java/lang/Number
      //   47: invokevirtual intValue : ()I
      //   50: aload_1
      //   51: getfield second : Ljava/lang/Object;
      //   54: checkcast android/content/Intent
      //   57: invokeinterface onActivityResult : (IILandroid/content/Intent;)Z
      //   62: pop
      //   63: aload_0
      //   64: getfield c : Lkotlin/d0/d/b0;
      //   67: getfield b : Ljava/lang/Object;
      //   70: checkcast androidx/activity/result/ActivityResultLauncher
      //   73: astore_1
      //   74: aload_1
      //   75: ifnull -> 104
      //   78: aload_1
      //   79: monitorenter
      //   80: aload_1
      //   81: invokevirtual unregister : ()V
      //   84: aload_0
      //   85: getfield c : Lkotlin/d0/d/b0;
      //   88: aconst_null
      //   89: putfield b : Ljava/lang/Object;
      //   92: getstatic kotlin/w.a : Lkotlin/w;
      //   95: astore_3
      //   96: aload_1
      //   97: monitorexit
      //   98: return
      //   99: astore_3
      //   100: aload_1
      //   101: monitorexit
      //   102: aload_3
      //   103: athrow
      //   104: return
      // Exception table:
      //   from	to	target	type
      //   80	96	99	finally
    }
  }
  
  @Metadata(d1 = {"\000!\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\005*\001\000\b\n\030\0002\034\022\004\022\0020\002\022\022\022\020\022\004\022\0020\004\022\006\022\004\030\0010\0020\0030\001J\030\020\005\032\0020\0022\006\020\006\032\0020\0072\006\020\b\032\0020\002H\026J(\020\t\032\020\022\004\022\0020\004\022\006\022\004\030\0010\0020\0032\006\020\n\032\0020\0042\b\020\013\032\004\030\0010\002H\026¨\006\f"}, d2 = {"com/facebook/internal/DialogPresenter$startActivityForResultWithAndroidX$1", "Landroidx/activity/result/contract/ActivityResultContract;", "Landroid/content/Intent;", "Landroid/util/Pair;", "", "createIntent", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "intent", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class DialogPresenter$startActivityForResultWithAndroidX$1 extends ActivityResultContract<Intent, Pair<Integer, Intent>> {
    public Intent createIntent(Context param1Context, Intent param1Intent) {
      m.f(param1Context, "context");
      m.f(param1Intent, "input");
      return param1Intent;
    }
    
    public Pair<Integer, Intent> parseResult(int param1Int, Intent param1Intent) {
      Pair<Integer, Intent> pair = Pair.create(Integer.valueOf(param1Int), param1Intent);
      m.e(pair, "Pair.create(resultCode, intent)");
      return pair;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\internal\DialogPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */