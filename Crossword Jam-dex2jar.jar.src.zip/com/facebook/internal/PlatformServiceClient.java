package com.facebook.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import kotlin.Metadata;
import kotlin.d0.d.m;

@Metadata(d1 = {"\000^\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\b\b&\030\0002\0020\001:\001+B7\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\005\022\006\020\007\032\0020\005\022\006\020\b\032\0020\t\022\b\020\n\032\004\030\0010\t¢\006\002\020\013J\022\020\030\032\0020\0312\b\020\032\032\004\030\0010\033H\002J\006\020\034\032\0020\031J\020\020\035\032\0020\0312\006\020\036\032\0020\037H\004J\030\020 \032\0020\0312\006\020!\032\0020\"2\006\020#\032\0020$H\026J\020\020%\032\0020\0312\006\020!\032\0020\"H\026J\020\020&\032\0020\0312\006\020'\032\0020\033H$J\b\020(\032\0020\031H\002J\020\020)\032\0020\0312\b\020\020\032\004\030\0010\021J\006\020*\032\0020\025R\016\020\b\032\0020\tX\004¢\006\002\n\000R\024\020\002\032\0020\003X\004¢\006\b\n\000\032\004\b\f\020\rR\016\020\016\032\0020\017X\004¢\006\002\n\000R\020\020\020\032\004\030\0010\021X\016¢\006\002\n\000R\023\020\n\032\004\030\0010\t¢\006\b\n\000\032\004\b\022\020\023R\016\020\007\032\0020\005X\004¢\006\002\n\000R\016\020\006\032\0020\005X\004¢\006\002\n\000R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\024\032\0020\025X\016¢\006\002\n\000R\020\020\026\032\004\030\0010\027X\016¢\006\002\n\000¨\006,"}, d2 = {"Lcom/facebook/internal/PlatformServiceClient;", "Landroid/content/ServiceConnection;", "context", "Landroid/content/Context;", "requestMessage", "", "replyMessage", "protocolVersion", "applicationId", "", "nonce", "(Landroid/content/Context;IIILjava/lang/String;Ljava/lang/String;)V", "getContext", "()Landroid/content/Context;", "handler", "Landroid/os/Handler;", "listener", "Lcom/facebook/internal/PlatformServiceClient$CompletedListener;", "getNonce", "()Ljava/lang/String;", "running", "", "sender", "Landroid/os/Messenger;", "callback", "", "result", "Landroid/os/Bundle;", "cancel", "handleMessage", "message", "Landroid/os/Message;", "onServiceConnected", "name", "Landroid/content/ComponentName;", "service", "Landroid/os/IBinder;", "onServiceDisconnected", "populateRequestBundle", "data", "sendMessage", "setCompletedListener", "start", "CompletedListener", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
public abstract class PlatformServiceClient implements ServiceConnection {
  private final String applicationId;
  
  private final Context context;
  
  private final Handler handler;
  
  private CompletedListener listener;
  
  private final String nonce;
  
  private final int protocolVersion;
  
  private final int replyMessage;
  
  private final int requestMessage;
  
  private boolean running;
  
  private Messenger sender;
  
  public PlatformServiceClient(Context paramContext, int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2) {
    Context context = paramContext.getApplicationContext();
    if (context != null)
      paramContext = context; 
    this.context = paramContext;
    this.requestMessage = paramInt1;
    this.replyMessage = paramInt2;
    this.applicationId = paramString1;
    this.protocolVersion = paramInt3;
    this.nonce = paramString2;
    this.handler = new Handler() {
        public void handleMessage(Message param1Message) {
          if (CrashShieldHandler.isObjectCrashing(this))
            return; 
          try {
            return;
          } finally {
            param1Message = null;
            CrashShieldHandler.handleThrowable((Throwable)param1Message, this);
          } 
        }
      };
  }
  
  private final void callback(Bundle paramBundle) {
    if (!this.running)
      return; 
    this.running = false;
    CompletedListener completedListener = this.listener;
    if (completedListener != null)
      completedListener.completed(paramBundle); 
  }
  
  private final void sendMessage() {
    Bundle bundle = new Bundle();
    bundle.putString("com.facebook.platform.extra.APPLICATION_ID", this.applicationId);
    String str = this.nonce;
    if (str != null)
      bundle.putString("com.facebook.platform.extra.NONCE", str); 
    populateRequestBundle(bundle);
    Message message = Message.obtain(null, this.requestMessage);
    message.arg1 = this.protocolVersion;
    m.e(message, "request");
    message.setData(bundle);
    message.replyTo = new Messenger(this.handler);
    try {
      Messenger messenger = this.sender;
      if (messenger != null) {
        messenger.send(message);
        return;
      } 
    } catch (RemoteException remoteException) {
      callback(null);
    } 
  }
  
  public final void cancel() {
    this.running = false;
  }
  
  protected final Context getContext() {
    return this.context;
  }
  
  public final String getNonce() {
    return this.nonce;
  }
  
  protected final void handleMessage(Message paramMessage) {
    m.f(paramMessage, "message");
    if (paramMessage.what == this.replyMessage) {
      Bundle bundle = paramMessage.getData();
      if (bundle.getString("com.facebook.platform.status.ERROR_TYPE") != null) {
        callback(null);
      } else {
        callback(bundle);
      } 
      try {
        this.context.unbindService(this);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        return;
      } 
    } 
  }
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    m.f(paramComponentName, "name");
    m.f(paramIBinder, "service");
    this.sender = new Messenger(paramIBinder);
    sendMessage();
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    m.f(paramComponentName, "name");
    this.sender = null;
    try {
      this.context.unbindService(this);
    } catch (IllegalArgumentException illegalArgumentException) {}
    callback(null);
  }
  
  protected abstract void populateRequestBundle(Bundle paramBundle);
  
  public final void setCompletedListener(CompletedListener paramCompletedListener) {
    this.listener = paramCompletedListener;
  }
  
  public final boolean start() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield running : Z
    //   6: istore_3
    //   7: iconst_0
    //   8: istore_2
    //   9: iload_3
    //   10: ifeq -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: iconst_0
    //   16: ireturn
    //   17: aload_0
    //   18: getfield protocolVersion : I
    //   21: invokestatic getLatestAvailableProtocolVersionForService : (I)I
    //   24: istore_1
    //   25: iload_1
    //   26: iconst_m1
    //   27: if_icmpne -> 34
    //   30: aload_0
    //   31: monitorexit
    //   32: iconst_0
    //   33: ireturn
    //   34: aload_0
    //   35: getfield context : Landroid/content/Context;
    //   38: invokestatic createPlatformServiceIntent : (Landroid/content/Context;)Landroid/content/Intent;
    //   41: astore #4
    //   43: aload #4
    //   45: ifnonnull -> 51
    //   48: goto -> 70
    //   51: aload_0
    //   52: iconst_1
    //   53: putfield running : Z
    //   56: aload_0
    //   57: getfield context : Landroid/content/Context;
    //   60: aload #4
    //   62: aload_0
    //   63: iconst_1
    //   64: invokevirtual bindService : (Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   67: pop
    //   68: iconst_1
    //   69: istore_2
    //   70: aload_0
    //   71: monitorexit
    //   72: iload_2
    //   73: ireturn
    //   74: astore #4
    //   76: aload_0
    //   77: monitorexit
    //   78: aload #4
    //   80: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	74	finally
    //   17	25	74	finally
    //   34	43	74	finally
    //   51	68	74	finally
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\022\020\002\032\0020\0032\b\020\004\032\004\030\0010\005H&¨\006\006"}, d2 = {"Lcom/facebook/internal/PlatformServiceClient$CompletedListener;", "", "completed", "", "result", "Landroid/os/Bundle;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static interface CompletedListener {
    void completed(Bundle param1Bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\internal\PlatformServiceClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */