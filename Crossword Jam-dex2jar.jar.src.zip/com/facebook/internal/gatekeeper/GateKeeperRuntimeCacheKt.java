package com.facebook.internal.gatekeeper;

import kotlin.Metadata;

@Metadata(d1 = {"\000\b\n\000\n\002\020\016\n\000*\n\020\000\"\0020\0012\0020\001¨\006\002"}, d2 = {"AppID", "", "facebook-core_release"}, k = 2, mv = {1, 5, 1})
public final class GateKeeperRuntimeCacheKt {}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\internal\gatekeeper\GateKeeperRuntimeCacheKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */