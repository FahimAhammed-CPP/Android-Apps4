package com.facebook.internal;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.VisibleForTesting;
import com.facebook.AccessToken;
import com.facebook.FacebookDialogException;
import com.facebook.FacebookException;
import com.facebook.FacebookGraphResponseException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.common.R;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.login.LoginTargetApp;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.FacebookNetworkBridge;
import com.safedk.android.utils.Logger;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.g0;
import kotlin.d0.d.m;
import kotlin.y.i;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\n\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\020\002\n\002\b\005\n\002\020\007\n\002\b\t\n\002\030\002\n\002\b\t\n\002\020\003\n\002\b\f\b\026\030\000 N2\0020\001:\006MNOPQRB\027\b\024\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006B\037\b\022\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\007\032\0020\b¢\006\002\020\tB=\b\022\022\006\020\002\032\0020\003\022\b\020\n\032\004\030\0010\005\022\b\020\013\032\004\030\0010\f\022\006\020\007\032\0020\b\022\006\020\r\032\0020\016\022\b\020\017\032\004\030\0010\020¢\006\002\020\021J\b\020,\032\0020-H\026J\b\020.\032\0020-H\002J\b\020/\032\0020-H\026J(\0200\032\0020\b2\006\0201\032\0020\b2\006\0202\032\002032\006\0204\032\0020\b2\006\0205\032\0020\bH\002J\b\0206\032\0020-H\026J\022\0207\032\0020-2\b\0208\032\004\030\0010\fH\024J\b\0209\032\0020-H\026J\030\020:\032\0020\0302\006\020;\032\0020\b2\006\020<\032\0020=H\026J\b\020>\032\0020-H\024J\b\020?\032\0020-H\024J\020\020@\032\0020-2\006\020A\032\0020+H\026J\022\020B\032\0020\f2\b\020C\032\004\030\0010\005H\027J\006\020D\032\0020-J\022\020E\032\0020-2\b\020F\032\004\030\0010GH\004J\022\020H\032\0020-2\b\020I\032\004\030\0010\fH\004J\020\020J\032\0020-2\006\020\026\032\0020\005H\004J\020\020K\032\0020-2\006\020L\032\0020\bH\003R\020\020\022\032\004\030\0010\023X\016¢\006\002\n\000R\020\020\024\032\004\030\0010\025X\016¢\006\002\n\000R\016\020\026\032\0020\005X\016¢\006\002\n\000R\016\020\027\032\0020\030X\016¢\006\002\n\000R\036\020\032\032\0020\0302\006\020\031\032\0020\030@BX\016¢\006\b\n\000\032\004\b\032\020\033R\036\020\034\032\0020\0302\006\020\031\032\0020\030@BX\016¢\006\b\n\000\032\004\b\034\020\033R\034\020\035\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\036\020\037\"\004\b \020!R\020\020\"\032\004\030\0010#X\016¢\006\002\n\000R\024\020$\032\b\030\0010%R\0020\000X\016¢\006\002\n\000R\020\020\004\032\004\030\0010\005X\016¢\006\002\n\000R\"\020'\032\004\030\0010&2\b\020\031\032\004\030\0010&@BX\016¢\006\b\n\000\032\004\b(\020)R\020\020*\032\004\030\0010+X\016¢\006\002\n\000¨\006S"}, d2 = {"Lcom/facebook/internal/WebDialog;", "Landroid/app/Dialog;", "context", "Landroid/content/Context;", "url", "", "(Landroid/content/Context;Ljava/lang/String;)V", "theme", "", "(Landroid/content/Context;Ljava/lang/String;I)V", "action", "parameters", "Landroid/os/Bundle;", "targetApp", "Lcom/facebook/login/LoginTargetApp;", "listener", "Lcom/facebook/internal/WebDialog$OnCompleteListener;", "(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;ILcom/facebook/login/LoginTargetApp;Lcom/facebook/internal/WebDialog$OnCompleteListener;)V", "contentFrameLayout", "Landroid/widget/FrameLayout;", "crossImageView", "Landroid/widget/ImageView;", "expectedRedirectUrl", "isDetached", "", "<set-?>", "isListenerCalled", "()Z", "isPageFinished", "onCompleteListener", "getOnCompleteListener", "()Lcom/facebook/internal/WebDialog$OnCompleteListener;", "setOnCompleteListener", "(Lcom/facebook/internal/WebDialog$OnCompleteListener;)V", "spinner", "Landroid/app/ProgressDialog;", "uploadTask", "Lcom/facebook/internal/WebDialog$UploadStagingResourcesTask;", "Landroid/webkit/WebView;", "webView", "getWebView", "()Landroid/webkit/WebView;", "windowParams", "Landroid/view/WindowManager$LayoutParams;", "cancel", "", "createCrossImage", "dismiss", "getScaledSize", "screenSize", "density", "", "noPaddingSize", "maxPaddingSize", "onAttachedToWindow", "onCreate", "savedInstanceState", "onDetachedFromWindow", "onKeyDown", "keyCode", "event", "Landroid/view/KeyEvent;", "onStart", "onStop", "onWindowAttributesChanged", "params", "parseResponseUri", "urlString", "resize", "sendErrorToListener", "error", "", "sendSuccessToListener", "values", "setExpectedRedirectUrl", "setUpWebView", "margin", "Builder", "Companion", "DialogWebViewClient", "InitCallback", "OnCompleteListener", "UploadStagingResourcesTask", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
public class WebDialog extends Dialog {
  private static final int API_EC_DIALOG_CANCEL = 4201;
  
  private static final int BACKGROUND_GRAY = -872415232;
  
  public static final Companion Companion = new Companion(null);
  
  private static final int DEFAULT_THEME = R.style.com_facebook_activity_theme;
  
  public static final boolean DISABLE_SSL_CHECK_FOR_TESTING = false;
  
  private static final String DISPLAY_TOUCH = "touch";
  
  private static final String LOG_TAG = "FacebookSDK.WebDialog";
  
  private static final int MAX_PADDING_SCREEN_HEIGHT = 1280;
  
  private static final int MAX_PADDING_SCREEN_WIDTH = 800;
  
  private static final double MIN_SCALE_FACTOR = 0.5D;
  
  private static final int NO_PADDING_SCREEN_HEIGHT = 800;
  
  private static final int NO_PADDING_SCREEN_WIDTH = 480;
  
  private static final String PLATFORM_DIALOG_PATH_REGEX = "^/(v\\d+\\.\\d+/)??dialog/.*";
  
  private static InitCallback initCallback;
  
  private static volatile int webDialogTheme;
  
  private FrameLayout contentFrameLayout;
  
  private ImageView crossImageView;
  
  private String expectedRedirectUrl;
  
  private boolean isDetached;
  
  private boolean isListenerCalled;
  
  private boolean isPageFinished;
  
  private OnCompleteListener onCompleteListener;
  
  private ProgressDialog spinner;
  
  private b uploadTask;
  
  private String url;
  
  private WebView webView;
  
  private WindowManager.LayoutParams windowParams;
  
  protected WebDialog(Context paramContext, String paramString) {
    this(paramContext, paramString, Companion.getWebDialogTheme());
  }
  
  private WebDialog(Context paramContext, String paramString, int paramInt) {
    super(paramContext, i);
    this.expectedRedirectUrl = "fbconnect://success";
    this.url = paramString;
  }
  
  private WebDialog(Context paramContext, String paramString, Bundle paramBundle, int paramInt, LoginTargetApp paramLoginTargetApp, OnCompleteListener paramOnCompleteListener) {
    super(paramContext, i);
    Uri uri;
    String str3 = "fbconnect://success";
    this.expectedRedirectUrl = "fbconnect://success";
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    String str2 = str3;
    if (Utility.isChromeOS(paramContext))
      str2 = "fbconnect://chrome_os_success"; 
    this.expectedRedirectUrl = str2;
    bundle.putString("redirect_uri", str2);
    bundle.putString("display", "touch");
    bundle.putString("client_id", FacebookSdk.getApplicationId());
    g0 g0 = g0.a;
    String str1 = String.format(Locale.ROOT, "android-%s", Arrays.copyOf(new Object[] { FacebookSdk.getSdkVersion() }, 1));
    m.e(str1, "java.lang.String.format(locale, format, *args)");
    bundle.putString("sdk", str1);
    this.onCompleteListener = paramOnCompleteListener;
    if (m.a(paramString, "share") && bundle.containsKey("media")) {
      this.uploadTask = new b(this, paramString, bundle);
      return;
    } 
    if (WhenMappings.$EnumSwitchMapping$0[paramLoginTargetApp.ordinal()] != 1) {
      str1 = ServerProtocol.getDialogAuthority();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(FacebookSdk.getGraphApiVersion());
      stringBuilder.append("/");
      stringBuilder.append("dialog/");
      stringBuilder.append(paramString);
      uri = Utility.buildUri(str1, stringBuilder.toString(), bundle);
    } else {
      uri = Utility.buildUri(ServerProtocol.getInstagramDialogAuthority(), "oauth/authorize", bundle);
    } 
    this.url = uri.toString();
  }
  
  private final void createCrossImage() {
    ImageView imageView2 = new ImageView(getContext());
    this.crossImageView = imageView2;
    if (imageView2 != null)
      imageView2.setOnClickListener(new c(this)); 
    Context context = getContext();
    m.e(context, "context");
    Drawable drawable = context.getResources().getDrawable(R.drawable.com_facebook_close);
    ImageView imageView3 = this.crossImageView;
    if (imageView3 != null)
      imageView3.setImageDrawable(drawable); 
    ImageView imageView1 = this.crossImageView;
    if (imageView1 != null)
      imageView1.setVisibility(4); 
  }
  
  private final int getScaledSize(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    int i = (int)(paramInt1 / paramFloat);
    double d = 0.5D;
    if (i <= paramInt2) {
      d = 1.0D;
    } else if (i < paramInt3) {
      d = 0.5D + (paramInt3 - i) / (paramInt3 - paramInt2) * 0.5D;
    } 
    return (int)(paramInt1 * d);
  }
  
  public static final int getWebDialogTheme() {
    return Companion.getWebDialogTheme();
  }
  
  protected static final void initDefaultTheme(Context paramContext) {
    Companion.initDefaultTheme(paramContext);
  }
  
  public static final WebDialog newInstance(Context paramContext, String paramString, Bundle paramBundle, int paramInt, OnCompleteListener paramOnCompleteListener) {
    return Companion.newInstance(paramContext, paramString, paramBundle, paramInt, paramOnCompleteListener);
  }
  
  public static final WebDialog newInstance(Context paramContext, String paramString, Bundle paramBundle, int paramInt, LoginTargetApp paramLoginTargetApp, OnCompleteListener paramOnCompleteListener) {
    return Companion.newInstance(paramContext, paramString, paramBundle, paramInt, paramLoginTargetApp, paramOnCompleteListener);
  }
  
  public static final void setInitCallback(InitCallback paramInitCallback) {
    Companion.setInitCallback(paramInitCallback);
  }
  
  @SuppressLint({"SetJavaScriptEnabled"})
  private final void setUpWebView(int paramInt) {
    LinearLayout linearLayout = new LinearLayout(getContext());
    WebDialog$setUpWebView$1 webDialog$setUpWebView$1 = new WebDialog$setUpWebView$1(getContext());
    this.webView = webDialog$setUpWebView$1;
    InitCallback initCallback = initCallback;
    if (initCallback != null)
      initCallback.onInit(webDialog$setUpWebView$1); 
    WebView webView = this.webView;
    if (webView != null)
      webView.setVerticalScrollBarEnabled(false); 
    webView = this.webView;
    if (webView != null)
      webView.setHorizontalScrollBarEnabled(false); 
    webView = this.webView;
    if (webView != null)
      webView.setWebViewClient(new a(this)); 
    webView = this.webView;
    if (webView != null) {
      WebSettings webSettings = webView.getSettings();
      if (webSettings != null)
        webSettings.setJavaScriptEnabled(true); 
    } 
    webView = this.webView;
    if (webView != null) {
      String str = this.url;
      if (str != null) {
        FacebookNetworkBridge.webviewLoadUrl(webView, str);
      } else {
        throw new IllegalStateException("Required value was null.".toString());
      } 
    } 
    webView = this.webView;
    if (webView != null)
      webView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1)); 
    webView = this.webView;
    if (webView != null)
      webView.setVisibility(4); 
    webView = this.webView;
    if (webView != null) {
      WebSettings webSettings = webView.getSettings();
      if (webSettings != null)
        webSettings.setSavePassword(false); 
    } 
    webView = this.webView;
    if (webView != null) {
      WebSettings webSettings = webView.getSettings();
      if (webSettings != null)
        webSettings.setSaveFormData(false); 
    } 
    webView = this.webView;
    if (webView != null)
      webView.setFocusable(true); 
    webView = this.webView;
    if (webView != null)
      webView.setFocusableInTouchMode(true); 
    webView = this.webView;
    if (webView != null)
      webView.setOnTouchListener(e.b); 
    linearLayout.setPadding(paramInt, paramInt, paramInt, paramInt);
    linearLayout.addView((View)this.webView);
    linearLayout.setBackgroundColor(-872415232);
    FrameLayout frameLayout = this.contentFrameLayout;
    if (frameLayout != null)
      frameLayout.addView((View)linearLayout); 
  }
  
  public static final void setWebDialogTheme(int paramInt) {
    Companion.setWebDialogTheme(paramInt);
  }
  
  public void cancel() {
    if (this.onCompleteListener != null && !this.isListenerCalled)
      sendErrorToListener((Throwable)new FacebookOperationCanceledException()); 
  }
  
  public void dismiss() {
    WebView webView = this.webView;
    if (webView != null)
      webView.stopLoading(); 
    if (!this.isDetached) {
      ProgressDialog progressDialog = this.spinner;
      if (progressDialog != null && progressDialog.isShowing())
        progressDialog.dismiss(); 
    } 
    super.dismiss();
  }
  
  public final OnCompleteListener getOnCompleteListener() {
    return this.onCompleteListener;
  }
  
  protected final WebView getWebView() {
    return this.webView;
  }
  
  protected final boolean isListenerCalled() {
    return this.isListenerCalled;
  }
  
  protected final boolean isPageFinished() {
    return this.isPageFinished;
  }
  
  public void onAttachedToWindow() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield isDetached : Z
    //   5: aload_0
    //   6: invokevirtual getContext : ()Landroid/content/Context;
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'context'
    //   13: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   16: aload_1
    //   17: invokestatic mustFixWindowParamsForAutofill : (Landroid/content/Context;)Z
    //   20: ifeq -> 148
    //   23: aload_0
    //   24: getfield windowParams : Landroid/view/WindowManager$LayoutParams;
    //   27: astore_3
    //   28: aload_3
    //   29: ifnull -> 148
    //   32: aconst_null
    //   33: astore_2
    //   34: aload_3
    //   35: ifnull -> 46
    //   38: aload_3
    //   39: getfield token : Landroid/os/IBinder;
    //   42: astore_1
    //   43: goto -> 48
    //   46: aconst_null
    //   47: astore_1
    //   48: aload_1
    //   49: ifnonnull -> 148
    //   52: aload_3
    //   53: ifnull -> 98
    //   56: aload_0
    //   57: invokevirtual getOwnerActivity : ()Landroid/app/Activity;
    //   60: astore_1
    //   61: aload_1
    //   62: ifnull -> 91
    //   65: aload_1
    //   66: invokevirtual getWindow : ()Landroid/view/Window;
    //   69: astore_1
    //   70: aload_1
    //   71: ifnull -> 91
    //   74: aload_1
    //   75: invokevirtual getAttributes : ()Landroid/view/WindowManager$LayoutParams;
    //   78: astore_1
    //   79: aload_1
    //   80: ifnull -> 91
    //   83: aload_1
    //   84: getfield token : Landroid/os/IBinder;
    //   87: astore_1
    //   88: goto -> 93
    //   91: aconst_null
    //   92: astore_1
    //   93: aload_3
    //   94: aload_1
    //   95: putfield token : Landroid/os/IBinder;
    //   98: new java/lang/StringBuilder
    //   101: dup
    //   102: invokespecial <init> : ()V
    //   105: astore_3
    //   106: aload_3
    //   107: ldc_w 'Set token on onAttachedToWindow(): '
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: aload_0
    //   115: getfield windowParams : Landroid/view/WindowManager$LayoutParams;
    //   118: astore #4
    //   120: aload_2
    //   121: astore_1
    //   122: aload #4
    //   124: ifnull -> 133
    //   127: aload #4
    //   129: getfield token : Landroid/os/IBinder;
    //   132: astore_1
    //   133: aload_3
    //   134: aload_1
    //   135: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   138: pop
    //   139: ldc 'FacebookSDK.WebDialog'
    //   141: aload_3
    //   142: invokevirtual toString : ()Ljava/lang/String;
    //   145: invokestatic logd : (Ljava/lang/String;Ljava/lang/String;)V
    //   148: aload_0
    //   149: invokespecial onAttachedToWindow : ()V
    //   152: return
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ProgressDialog progressDialog = new ProgressDialog(getContext());
    this.spinner = progressDialog;
    if (progressDialog != null)
      progressDialog.requestWindowFeature(1); 
    progressDialog = this.spinner;
    if (progressDialog != null)
      progressDialog.setMessage(getContext().getString(R.string.com_facebook_loading)); 
    progressDialog = this.spinner;
    if (progressDialog != null)
      progressDialog.setCanceledOnTouchOutside(false); 
    progressDialog = this.spinner;
    if (progressDialog != null)
      progressDialog.setOnCancelListener(new d(this)); 
    requestWindowFeature(1);
    this.contentFrameLayout = new FrameLayout(getContext());
    resize();
    Window window = getWindow();
    if (window != null)
      window.setGravity(17); 
    window = getWindow();
    if (window != null)
      window.setSoftInputMode(16); 
    createCrossImage();
    if (this.url != null) {
      ImageView imageView = this.crossImageView;
      if (imageView != null) {
        Drawable drawable = imageView.getDrawable();
        m.e(drawable, "checkNotNull(crossImageView).drawable");
        setUpWebView(drawable.getIntrinsicWidth() / 2 + 1);
      } else {
        throw new IllegalStateException("Required value was null.".toString());
      } 
    } 
    FrameLayout frameLayout = this.contentFrameLayout;
    if (frameLayout != null)
      frameLayout.addView((View)this.crossImageView, new ViewGroup.LayoutParams(-2, -2)); 
    frameLayout = this.contentFrameLayout;
    if (frameLayout != null) {
      setContentView((View)frameLayout);
      return;
    } 
    throw new IllegalStateException("Required value was null.".toString());
  }
  
  public void onDetachedFromWindow() {
    this.isDetached = true;
    super.onDetachedFromWindow();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    WebView webView;
    m.f(paramKeyEvent, "event");
    if (paramInt == 4) {
      WebView webView1 = this.webView;
      if (webView1 != null && webView1 != null && webView1.canGoBack() == true) {
        webView = this.webView;
        if (webView != null)
          webView.goBack(); 
        return true;
      } 
      cancel();
    } 
    return super.onKeyDown(paramInt, (KeyEvent)webView);
  }
  
  protected void onStart() {
    super.onStart();
    b b1 = this.uploadTask;
    if (b1 != null) {
      if (b1 != null) {
        AsyncTask.Status status = b1.getStatus();
      } else {
        b1 = null;
      } 
      if (b1 == AsyncTask.Status.PENDING) {
        b1 = this.uploadTask;
        if (b1 != null)
          b1.execute((Object[])new Void[0]); 
        ProgressDialog progressDialog = this.spinner;
        if (progressDialog != null) {
          progressDialog.show();
          return;
        } 
        return;
      } 
    } 
    resize();
  }
  
  protected void onStop() {
    b b1 = this.uploadTask;
    if (b1 != null) {
      b1.cancel(true);
      ProgressDialog progressDialog = this.spinner;
      if (progressDialog != null)
        progressDialog.dismiss(); 
    } 
    super.onStop();
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams) {
    m.f(paramLayoutParams, "params");
    if (paramLayoutParams.token == null)
      this.windowParams = paramLayoutParams; 
    super.onWindowAttributesChanged(paramLayoutParams);
  }
  
  @VisibleForTesting(otherwise = 4)
  public Bundle parseResponseUri(String paramString) {
    Uri uri = Uri.parse(paramString);
    m.e(uri, "u");
    Bundle bundle = Utility.parseUrlQueryString(uri.getQuery());
    bundle.putAll(Utility.parseUrlQueryString(uri.getFragment()));
    return bundle;
  }
  
  public final void resize() {
    int k;
    Object object = getContext().getSystemService("window");
    Objects.requireNonNull(object, "null cannot be cast to non-null type android.view.WindowManager");
    object = ((WindowManager)object).getDefaultDisplay();
    DisplayMetrics displayMetrics = new DisplayMetrics();
    object.getMetrics(displayMetrics);
    int i = displayMetrics.widthPixels;
    int j = displayMetrics.heightPixels;
    if (i < j) {
      k = i;
    } else {
      k = j;
    } 
    int m = i;
    if (i < j)
      m = j; 
    i = Math.min(getScaledSize(k, displayMetrics.density, 480, 800), displayMetrics.widthPixels);
    j = Math.min(getScaledSize(m, displayMetrics.density, 800, 1280), displayMetrics.heightPixels);
    object = getWindow();
    if (object != null)
      object.setLayout(i, j); 
  }
  
  protected final void sendErrorToListener(Throwable paramThrowable) {
    if (this.onCompleteListener != null && !this.isListenerCalled) {
      FacebookException facebookException;
      this.isListenerCalled = true;
      if (paramThrowable instanceof FacebookException) {
        facebookException = (FacebookException)paramThrowable;
      } else {
        facebookException = new FacebookException((Throwable)facebookException);
      } 
      OnCompleteListener onCompleteListener = this.onCompleteListener;
      if (onCompleteListener != null)
        onCompleteListener.onComplete(null, facebookException); 
      dismiss();
    } 
  }
  
  protected final void sendSuccessToListener(Bundle paramBundle) {
    OnCompleteListener onCompleteListener = this.onCompleteListener;
    if (onCompleteListener != null && !this.isListenerCalled) {
      this.isListenerCalled = true;
      if (onCompleteListener != null)
        onCompleteListener.onComplete(paramBundle, null); 
      dismiss();
    } 
  }
  
  protected final void setExpectedRedirectUrl(String paramString) {
    m.f(paramString, "expectedRedirectUrl");
    this.expectedRedirectUrl = paramString;
  }
  
  public final void setOnCompleteListener(OnCompleteListener paramOnCompleteListener) {
    this.onCompleteListener = paramOnCompleteListener;
  }
  
  @Metadata(d1 = {"\000D\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\004\n\002\030\002\n\000\n\002\020\002\n\002\b\003\b\026\030\0002\0020\001B!\b\026\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\b\020\006\032\004\030\0010\007¢\006\002\020\bB+\b\026\022\006\020\002\032\0020\003\022\b\020\t\032\004\030\0010\005\022\006\020\004\032\0020\005\022\b\020\006\032\004\030\0010\007¢\006\002\020\nJ\n\020\034\032\004\030\0010\035H\026J$\020\036\032\0020\0372\b\020\002\032\004\030\0010\0032\006\020\004\032\0020\0052\b\020\006\032\004\030\0010\007H\002J\020\020 \032\0020\0002\b\020\023\032\004\030\0010\022J\016\020!\032\0020\0002\006\020\031\032\0020\030R\020\020\013\032\004\030\0010\fX\016¢\006\002\n\000R\020\020\004\032\004\030\0010\005X\016¢\006\002\n\000R\"\020\t\032\004\030\0010\0052\b\020\r\032\004\030\0010\005@BX\016¢\006\b\n\000\032\004\b\016\020\017R\"\020\002\032\004\030\0010\0032\b\020\r\032\004\030\0010\003@BX\016¢\006\b\n\000\032\004\b\020\020\021R\"\020\023\032\004\030\0010\0222\b\020\r\032\004\030\0010\022@BX\016¢\006\b\n\000\032\004\b\024\020\025R\"\020\006\032\004\030\0010\0072\b\020\r\032\004\030\0010\007@BX\016¢\006\b\n\000\032\004\b\026\020\027R\036\020\031\032\0020\0302\006\020\r\032\0020\030@BX\016¢\006\b\n\000\032\004\b\032\020\033¨\006\""}, d2 = {"Lcom/facebook/internal/WebDialog$Builder;", "", "context", "Landroid/content/Context;", "action", "", "parameters", "Landroid/os/Bundle;", "(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)V", "applicationId", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V", "accessToken", "Lcom/facebook/AccessToken;", "<set-?>", "getApplicationId", "()Ljava/lang/String;", "getContext", "()Landroid/content/Context;", "Lcom/facebook/internal/WebDialog$OnCompleteListener;", "listener", "getListener", "()Lcom/facebook/internal/WebDialog$OnCompleteListener;", "getParameters", "()Landroid/os/Bundle;", "", "theme", "getTheme", "()I", "build", "Lcom/facebook/internal/WebDialog;", "finishInit", "", "setOnCompleteListener", "setTheme", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static class Builder {
    private AccessToken accessToken;
    
    private String action;
    
    private String applicationId;
    
    private Context context;
    
    private WebDialog.OnCompleteListener listener;
    
    private Bundle parameters;
    
    private int theme;
    
    public Builder(Context param1Context, String param1String, Bundle param1Bundle) {
      AccessToken.Companion companion = AccessToken.Companion;
      this.accessToken = companion.getCurrentAccessToken();
      if (!companion.isCurrentAccessTokenActive()) {
        String str = Utility.getMetadataApplicationId(param1Context);
        if (str != null) {
          this.applicationId = str;
        } else {
          throw new FacebookException("Attempted to create a builder without a valid access token or a valid default Application ID.");
        } 
      } 
      finishInit(param1Context, param1String, param1Bundle);
    }
    
    public Builder(Context param1Context, String param1String1, String param1String2, Bundle param1Bundle) {
      String str = param1String1;
      if (param1String1 == null)
        str = Utility.getMetadataApplicationId(param1Context); 
      this.applicationId = Validate.notNullOrEmpty(str, "applicationId");
      finishInit(param1Context, param1String2, param1Bundle);
    }
    
    private final void finishInit(Context param1Context, String param1String, Bundle param1Bundle) {
      this.context = param1Context;
      this.action = param1String;
      if (param1Bundle != null) {
        this.parameters = param1Bundle;
        return;
      } 
      this.parameters = new Bundle();
    }
    
    public WebDialog build() {
      AccessToken accessToken = this.accessToken;
      if (accessToken != null) {
        Bundle bundle = this.parameters;
        AccessToken accessToken1 = null;
        if (bundle != null) {
          if (accessToken != null) {
            String str = accessToken.getApplicationId();
          } else {
            accessToken = null;
          } 
          bundle.putString("app_id", (String)accessToken);
        } 
        bundle = this.parameters;
        if (bundle != null) {
          String str;
          AccessToken accessToken2 = this.accessToken;
          accessToken = accessToken1;
          if (accessToken2 != null)
            str = accessToken2.getToken(); 
          bundle.putString("access_token", str);
        } 
      } else {
        Bundle bundle = this.parameters;
        if (bundle != null)
          bundle.putString("app_id", this.applicationId); 
      } 
      WebDialog.Companion companion = WebDialog.Companion;
      Context context = this.context;
      if (context != null)
        return companion.newInstance(context, this.action, this.parameters, this.theme, this.listener); 
      throw new IllegalStateException("Required value was null.".toString());
    }
    
    public final String getApplicationId() {
      return this.applicationId;
    }
    
    public final Context getContext() {
      return this.context;
    }
    
    public final WebDialog.OnCompleteListener getListener() {
      return this.listener;
    }
    
    public final Bundle getParameters() {
      return this.parameters;
    }
    
    public final int getTheme() {
      return this.theme;
    }
    
    public final Builder setOnCompleteListener(WebDialog.OnCompleteListener param1OnCompleteListener) {
      this.listener = param1OnCompleteListener;
      return this;
    }
    
    public final Builder setTheme(int param1Int) {
      this.theme = param1Int;
      return this;
    }
  }
  
  @Metadata(d1 = {"\000\\\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\013\n\000\n\002\020\016\n\002\b\004\n\002\020\006\n\002\b\004\n\002\030\002\n\002\b\003\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\026\032\0020\004H\007J\022\020\027\032\0020\0302\b\020\031\032\004\030\0010\032H\005J6\020\033\032\0020\0342\006\020\031\032\0020\0322\b\020\035\032\004\030\0010\n2\b\020\036\032\004\030\0010\0372\006\020 \032\0020\0042\b\020!\032\004\030\0010\"H\007J>\020\033\032\0020\0342\006\020\031\032\0020\0322\b\020\035\032\004\030\0010\n2\b\020\036\032\004\030\0010\0372\006\020 \032\0020\0042\006\020#\032\0020$2\b\020!\032\004\030\0010\"H\007J\022\020%\032\0020\0302\b\020&\032\004\030\0010\024H\007J\020\020'\032\0020\0302\006\020 \032\0020\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004X\004¢\006\002\n\000R\016\020\007\032\0020\bXT¢\006\002\n\000R\016\020\t\032\0020\nXT¢\006\002\n\000R\016\020\013\032\0020\nXT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\016\020\r\032\0020\004XT¢\006\002\n\000R\016\020\016\032\0020\017XT¢\006\002\n\000R\016\020\020\032\0020\004XT¢\006\002\n\000R\016\020\021\032\0020\004XT¢\006\002\n\000R\016\020\022\032\0020\nXT¢\006\002\n\000R\020\020\023\032\004\030\0010\024X\016¢\006\002\n\000R\016\020\025\032\0020\004X\016¢\006\002\n\000¨\006("}, d2 = {"Lcom/facebook/internal/WebDialog$Companion;", "", "()V", "API_EC_DIALOG_CANCEL", "", "BACKGROUND_GRAY", "DEFAULT_THEME", "DISABLE_SSL_CHECK_FOR_TESTING", "", "DISPLAY_TOUCH", "", "LOG_TAG", "MAX_PADDING_SCREEN_HEIGHT", "MAX_PADDING_SCREEN_WIDTH", "MIN_SCALE_FACTOR", "", "NO_PADDING_SCREEN_HEIGHT", "NO_PADDING_SCREEN_WIDTH", "PLATFORM_DIALOG_PATH_REGEX", "initCallback", "Lcom/facebook/internal/WebDialog$InitCallback;", "webDialogTheme", "getWebDialogTheme", "initDefaultTheme", "", "context", "Landroid/content/Context;", "newInstance", "Lcom/facebook/internal/WebDialog;", "action", "parameters", "Landroid/os/Bundle;", "theme", "listener", "Lcom/facebook/internal/WebDialog$OnCompleteListener;", "targetApp", "Lcom/facebook/login/LoginTargetApp;", "setInitCallback", "callback", "setWebDialogTheme", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    public final int getWebDialogTheme() {
      Validate.sdkInitialized();
      return WebDialog.webDialogTheme;
    }
    
    protected final void initDefaultTheme(Context param1Context) {
      if (param1Context == null)
        return; 
      try {
        ApplicationInfo applicationInfo = param1Context.getPackageManager().getApplicationInfo(param1Context.getPackageName(), 128);
        if (applicationInfo != null) {
          Bundle bundle = applicationInfo.metaData;
        } else {
          param1Context = null;
        } 
        if (param1Context == null)
          return; 
        if (WebDialog.webDialogTheme == 0)
          setWebDialogTheme(applicationInfo.metaData.getInt("com.facebook.sdk.WebDialogTheme")); 
        return;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        return;
      } 
    }
    
    public final WebDialog newInstance(Context param1Context, String param1String, Bundle param1Bundle, int param1Int, WebDialog.OnCompleteListener param1OnCompleteListener) {
      m.f(param1Context, "context");
      initDefaultTheme(param1Context);
      return new WebDialog(param1Context, param1String, param1Bundle, param1Int, LoginTargetApp.FACEBOOK, param1OnCompleteListener, null);
    }
    
    public final WebDialog newInstance(Context param1Context, String param1String, Bundle param1Bundle, int param1Int, LoginTargetApp param1LoginTargetApp, WebDialog.OnCompleteListener param1OnCompleteListener) {
      m.f(param1Context, "context");
      m.f(param1LoginTargetApp, "targetApp");
      initDefaultTheme(param1Context);
      return new WebDialog(param1Context, param1String, param1Bundle, param1Int, param1LoginTargetApp, param1OnCompleteListener, null);
    }
    
    public final void setInitCallback(WebDialog.InitCallback param1InitCallback) {
      WebDialog.initCallback = param1InitCallback;
    }
    
    public final void setWebDialogTheme(int param1Int) {
      if (param1Int == 0)
        param1Int = WebDialog.DEFAULT_THEME; 
      WebDialog.webDialogTheme = param1Int;
    }
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\022\020\002\032\0020\0032\b\020\004\032\004\030\0010\005H&¨\006\006"}, d2 = {"Lcom/facebook/internal/WebDialog$InitCallback;", "", "onInit", "", "webView", "Landroid/webkit/WebView;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static interface InitCallback {
    void onInit(WebView param1WebView);
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\034\020\002\032\0020\0032\b\020\004\032\004\030\0010\0052\b\020\006\032\004\030\0010\007H&¨\006\b"}, d2 = {"Lcom/facebook/internal/WebDialog$OnCompleteListener;", "", "onComplete", "", "values", "Landroid/os/Bundle;", "error", "Lcom/facebook/FacebookException;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static interface OnCompleteListener {
    void onComplete(Bundle param1Bundle, FacebookException param1FacebookException);
  }
  
  @Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\b\004\030\0002\0020\001B\005¢\006\002\020\002J\030\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\bH\026J\"\020\t\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b2\b\020\n\032\004\030\0010\013H\026J(\020\f\032\0020\0042\006\020\005\032\0020\0062\006\020\r\032\0020\0162\006\020\017\032\0020\b2\006\020\020\032\0020\bH\026J \020\021\032\0020\0042\006\020\005\032\0020\0062\006\020\022\032\0020\0232\006\020\024\032\0020\025H\026J\030\020\026\032\0020\0272\006\020\005\032\0020\0062\006\020\007\032\0020\bH\026¨\006\030"}, d2 = {"Lcom/facebook/internal/WebDialog$DialogWebViewClient;", "Landroid/webkit/WebViewClient;", "(Lcom/facebook/internal/WebDialog;)V", "onPageFinished", "", "view", "Landroid/webkit/WebView;", "url", "", "onPageStarted", "favicon", "Landroid/graphics/Bitmap;", "onReceivedError", "errorCode", "", "description", "failingUrl", "onReceivedSslError", "handler", "Landroid/webkit/SslErrorHandler;", "error", "Landroid/net/http/SslError;", "shouldOverrideUrlLoading", "", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  private final class a extends WebViewClient {
    public a(WebDialog this$0) {}
    
    public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context param1Context, Intent param1Intent) {
      Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
      if (param1Intent == null)
        return; 
      BrandSafetyUtils.detectAdClick(param1Intent, "com.facebook");
      param1Context.startActivity(param1Intent);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.facebook", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      Logger.d("Facebook|SafeDK: Execution> Lcom/facebook/internal/WebDialog$a;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
      CreativeInfoManager.onWebViewPageFinished("com.facebook", param1WebView, param1String);
      safedk_WebDialog$a_onPageFinished_76ffdd4228d1fe4001efe094fcbf5d66(param1WebView, param1String);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      m.f(param1WebView, "view");
      m.f(param1String, "url");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Webview loading URL: ");
      stringBuilder.append(param1String);
      Utility.logd("FacebookSDK.WebDialog", stringBuilder.toString());
      super.onPageStarted(param1WebView, param1String, param1Bitmap);
      if (!this.a.isDetached) {
        ProgressDialog progressDialog = this.a.spinner;
        if (progressDialog != null)
          progressDialog.show(); 
      } 
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
      m.f(param1WebView, "view");
      m.f(param1String1, "description");
      m.f(param1String2, "failingUrl");
      super.onReceivedError(param1WebView, param1Int, param1String1, param1String2);
      this.a.sendErrorToListener((Throwable)new FacebookDialogException(param1String1, param1Int, param1String2));
    }
    
    public void onReceivedSslError(WebView param1WebView, SslErrorHandler param1SslErrorHandler, SslError param1SslError) {
      m.f(param1WebView, "view");
      m.f(param1SslErrorHandler, "handler");
      m.f(param1SslError, "error");
      super.onReceivedSslError(param1WebView, param1SslErrorHandler, param1SslError);
      param1SslErrorHandler.cancel();
      this.a.sendErrorToListener((Throwable)new FacebookDialogException(null, -11, null));
    }
    
    public void safedk_WebDialog$a_onPageFinished_76ffdd4228d1fe4001efe094fcbf5d66(WebView param1WebView, String param1String) {
      m.f(param1WebView, "view");
      m.f(param1String, "url");
      super.onPageFinished(param1WebView, param1String);
      if (!this.a.isDetached) {
        ProgressDialog progressDialog = this.a.spinner;
        if (progressDialog != null)
          progressDialog.dismiss(); 
      } 
      FrameLayout frameLayout = this.a.contentFrameLayout;
      if (frameLayout != null)
        frameLayout.setBackgroundColor(0); 
      WebView webView = this.a.getWebView();
      if (webView != null)
        webView.setVisibility(0); 
      ImageView imageView = this.a.crossImageView;
      if (imageView != null)
        imageView.setVisibility(0); 
      this.a.isPageFinished = true;
    }
    
    public boolean safedk_WebDialog$a_shouldOverrideUrlLoading_72ee4bd182bba821bbfe2d69f10aa7b4(WebView param1WebView, String param1String) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'view'
      //   3: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_2
      //   7: ldc 'url'
      //   9: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
      //   12: new java/lang/StringBuilder
      //   15: dup
      //   16: invokespecial <init> : ()V
      //   19: astore_1
      //   20: aload_1
      //   21: ldc 'Redirect URL: '
      //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   26: pop
      //   27: aload_1
      //   28: aload_2
      //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   32: pop
      //   33: ldc 'FacebookSDK.WebDialog'
      //   35: aload_1
      //   36: invokevirtual toString : ()Ljava/lang/String;
      //   39: invokestatic logd : (Ljava/lang/String;Ljava/lang/String;)V
      //   42: aload_2
      //   43: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   46: astore_1
      //   47: aload_1
      //   48: ldc 'parsedURL'
      //   50: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
      //   53: aload_1
      //   54: invokevirtual getPath : ()Ljava/lang/String;
      //   57: ifnull -> 77
      //   60: ldc '^/(v\d+\.\d+/)??dialog/.*'
      //   62: aload_1
      //   63: invokevirtual getPath : ()Ljava/lang/String;
      //   66: invokestatic matches : (Ljava/lang/String;Ljava/lang/CharSequence;)Z
      //   69: ifeq -> 77
      //   72: iconst_1
      //   73: istore_3
      //   74: goto -> 79
      //   77: iconst_0
      //   78: istore_3
      //   79: aload_2
      //   80: aload_0
      //   81: getfield a : Lcom/facebook/internal/WebDialog;
      //   84: invokestatic access$getExpectedRedirectUrl$p : (Lcom/facebook/internal/WebDialog;)Ljava/lang/String;
      //   87: iconst_0
      //   88: iconst_2
      //   89: aconst_null
      //   90: invokestatic A : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   93: ifeq -> 309
      //   96: aload_0
      //   97: getfield a : Lcom/facebook/internal/WebDialog;
      //   100: aload_2
      //   101: invokevirtual parseResponseUri : (Ljava/lang/String;)Landroid/os/Bundle;
      //   104: astore #5
      //   106: aload #5
      //   108: ldc 'error'
      //   110: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   113: astore_1
      //   114: aload_1
      //   115: astore_2
      //   116: aload_1
      //   117: ifnonnull -> 128
      //   120: aload #5
      //   122: ldc 'error_type'
      //   124: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   127: astore_2
      //   128: aload #5
      //   130: ldc 'error_msg'
      //   132: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   135: astore #4
      //   137: aload #4
      //   139: astore_1
      //   140: aload #4
      //   142: ifnonnull -> 153
      //   145: aload #5
      //   147: ldc 'error_message'
      //   149: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   152: astore_1
      //   153: aload_1
      //   154: astore #4
      //   156: aload_1
      //   157: ifnonnull -> 169
      //   160: aload #5
      //   162: ldc 'error_description'
      //   164: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   167: astore #4
      //   169: aload #5
      //   171: ldc 'error_code'
      //   173: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
      //   176: astore_1
      //   177: aload_1
      //   178: ifnull -> 196
      //   181: aload_1
      //   182: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   185: ifne -> 196
      //   188: aload_1
      //   189: invokestatic parseInt : (Ljava/lang/String;)I
      //   192: istore_3
      //   193: goto -> 198
      //   196: iconst_m1
      //   197: istore_3
      //   198: aload_2
      //   199: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   202: ifeq -> 229
      //   205: aload #4
      //   207: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
      //   210: ifeq -> 229
      //   213: iload_3
      //   214: iconst_m1
      //   215: if_icmpne -> 229
      //   218: aload_0
      //   219: getfield a : Lcom/facebook/internal/WebDialog;
      //   222: aload #5
      //   224: invokevirtual sendSuccessToListener : (Landroid/os/Bundle;)V
      //   227: iconst_1
      //   228: ireturn
      //   229: aload_2
      //   230: ifnull -> 262
      //   233: aload_2
      //   234: ldc_w 'access_denied'
      //   237: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   240: ifne -> 253
      //   243: aload_2
      //   244: ldc_w 'OAuthAccessDeniedException'
      //   247: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   250: ifeq -> 262
      //   253: aload_0
      //   254: getfield a : Lcom/facebook/internal/WebDialog;
      //   257: invokevirtual cancel : ()V
      //   260: iconst_1
      //   261: ireturn
      //   262: iload_3
      //   263: sipush #4201
      //   266: if_icmpne -> 278
      //   269: aload_0
      //   270: getfield a : Lcom/facebook/internal/WebDialog;
      //   273: invokevirtual cancel : ()V
      //   276: iconst_1
      //   277: ireturn
      //   278: new com/facebook/FacebookRequestError
      //   281: dup
      //   282: iload_3
      //   283: aload_2
      //   284: aload #4
      //   286: invokespecial <init> : (ILjava/lang/String;Ljava/lang/String;)V
      //   289: astore_1
      //   290: aload_0
      //   291: getfield a : Lcom/facebook/internal/WebDialog;
      //   294: new com/facebook/FacebookServiceException
      //   297: dup
      //   298: aload_1
      //   299: aload #4
      //   301: invokespecial <init> : (Lcom/facebook/FacebookRequestError;Ljava/lang/String;)V
      //   304: invokevirtual sendErrorToListener : (Ljava/lang/Throwable;)V
      //   307: iconst_1
      //   308: ireturn
      //   309: aload_2
      //   310: ldc_w 'fbconnect://cancel'
      //   313: iconst_0
      //   314: iconst_2
      //   315: aconst_null
      //   316: invokestatic A : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   319: ifeq -> 331
      //   322: aload_0
      //   323: getfield a : Lcom/facebook/internal/WebDialog;
      //   326: invokevirtual cancel : ()V
      //   329: iconst_1
      //   330: ireturn
      //   331: iload_3
      //   332: ifne -> 378
      //   335: aload_2
      //   336: ldc_w 'touch'
      //   339: iconst_0
      //   340: iconst_2
      //   341: aconst_null
      //   342: invokestatic F : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   345: ifeq -> 350
      //   348: iconst_0
      //   349: ireturn
      //   350: aload_0
      //   351: getfield a : Lcom/facebook/internal/WebDialog;
      //   354: invokevirtual getContext : ()Landroid/content/Context;
      //   357: new android/content/Intent
      //   360: dup
      //   361: ldc_w 'android.intent.action.VIEW'
      //   364: aload_2
      //   365: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   368: invokespecial <init> : (Ljava/lang/String;Landroid/net/Uri;)V
      //   371: invokestatic safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6 : (Landroid/content/Context;Landroid/content/Intent;)V
      //   374: iconst_1
      //   375: ireturn
      //   376: iconst_0
      //   377: ireturn
      //   378: iconst_0
      //   379: ireturn
      //   380: astore_1
      //   381: goto -> 196
      //   384: astore_1
      //   385: goto -> 376
      // Exception table:
      //   from	to	target	type
      //   188	193	380	java/lang/NumberFormatException
      //   350	374	384	android/content/ActivityNotFoundException
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.facebook", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.facebook", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      Logger.d("Facebook|SafeDK: Execution> Lcom/facebook/internal/WebDialog$a;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
      boolean bool = safedk_WebDialog$a_shouldOverrideUrlLoading_72ee4bd182bba821bbfe2d69f10aa7b4(param1WebView, param1String);
      CreativeInfoManager.onOverrideUrlLoading("com.facebook", param1WebView, param1String, bool);
      return bool;
    }
  }
  
  @Metadata(d1 = {"\0004\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\021\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\003\b\004\030\0002\036\022\004\022\0020\002\022\004\022\0020\002\022\016\022\f\022\006\022\004\030\0010\004\030\0010\0030\001B\027\b\000\022\006\020\005\032\0020\004\022\006\020\006\032\0020\007¢\006\002\020\bJ+\020\r\032\f\022\006\022\004\030\0010\004\030\0010\0032\022\020\016\032\n\022\006\b\001\022\0020\0020\003\"\0020\002H\024¢\006\002\020\017J\037\020\020\032\0020\0212\020\020\022\032\f\022\006\022\004\030\0010\004\030\0010\003H\024¢\006\002\020\023R\016\020\005\032\0020\004X\004¢\006\002\n\000R\036\020\t\032\020\022\f\022\n\030\0010\nj\004\030\001`\0130\003X\016¢\006\004\n\002\020\fR\016\020\006\032\0020\007X\004¢\006\002\n\000¨\006\024"}, d2 = {"Lcom/facebook/internal/WebDialog$UploadStagingResourcesTask;", "Landroid/os/AsyncTask;", "Ljava/lang/Void;", "", "", "action", "parameters", "Landroid/os/Bundle;", "(Lcom/facebook/internal/WebDialog;Ljava/lang/String;Landroid/os/Bundle;)V", "exceptions", "Ljava/lang/Exception;", "Lkotlin/Exception;", "[Ljava/lang/Exception;", "doInBackground", "p0", "([Ljava/lang/Void;)[Ljava/lang/String;", "onPostExecute", "", "results", "([Ljava/lang/String;)V", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  private final class b extends AsyncTask<Void, Void, String[]> {
    private Exception[] a;
    
    private final String b;
    
    private final Bundle c;
    
    public b(WebDialog this$0, String param1String, Bundle param1Bundle) {
      this.b = param1String;
      this.c = param1Bundle;
      this.a = new Exception[0];
    }
    
    protected String[] b(Void... param1VarArgs) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return null; 
      try {
        m.f(param1VarArgs, "p0");
        return null;
      } finally {
        param1VarArgs = null;
        CrashShieldHandler.handleThrowable((Throwable)param1VarArgs, this);
      } 
    }
    
    protected void c(String[] param1ArrayOfString) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        ProgressDialog progressDialog = this.d.spinner;
        if (progressDialog != null)
          progressDialog.dismiss(); 
        for (Exception exception : this.a) {
          if (exception != null)
            return; 
        } 
        if (param1ArrayOfString == null)
          return; 
        List list = i.c((Object[])param1ArrayOfString);
        if (list.contains(null))
          return; 
        Utility.putJSONValueInBundle(this.c, "media", new JSONArray(list));
        String str = ServerProtocol.getDialogAuthority();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(FacebookSdk.getGraphApiVersion());
        stringBuilder.append("/");
        stringBuilder.append("dialog/");
        stringBuilder.append(this.b);
        Uri uri = Utility.buildUri(str, stringBuilder.toString(), this.c);
        this.d.url = uri.toString();
        ImageView imageView = this.d.crossImageView;
        if (imageView != null) {
          Drawable drawable = imageView.getDrawable();
          m.e(drawable, "checkNotNull(crossImageView).drawable");
          return;
        } 
        throw new IllegalStateException("Required value was null.".toString());
      } finally {
        param1ArrayOfString = null;
        CrashShieldHandler.handleThrowable((Throwable)param1ArrayOfString, this);
      } 
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "response", "Lcom/facebook/GraphResponse;", "onCompleted"}, k = 3, mv = {1, 5, 1})
    static final class a implements GraphRequest.Callback {
      a(WebDialog.b param2b, String[] param2ArrayOfString, int param2Int, CountDownLatch param2CountDownLatch) {}
      
      public final void onCompleted(GraphResponse param2GraphResponse) {
        m.f(param2GraphResponse, "response");
        try {
          FacebookRequestError facebookRequestError = param2GraphResponse.getError();
          String str = "Error staging photo.";
          if (facebookRequestError != null) {
            String str1 = facebookRequestError.getErrorMessage();
            if (str1 != null)
              str = str1; 
            throw new FacebookGraphResponseException(param2GraphResponse, str);
          } 
          JSONObject jSONObject = param2GraphResponse.getJSONObject();
          if (jSONObject != null) {
            String str1 = jSONObject.optString("uri");
            if (str1 != null) {
              this.b[this.c] = str1;
            } else {
              throw new FacebookException("Error staging photo.");
            } 
          } else {
            throw new FacebookException("Error staging photo.");
          } 
        } catch (Exception exception) {
          WebDialog.b.a(this.a)[this.c] = exception;
        } 
        this.d.countDown();
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "response", "Lcom/facebook/GraphResponse;", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class a implements GraphRequest.Callback {
    a(WebDialog.b param1b, String[] param1ArrayOfString, int param1Int, CountDownLatch param1CountDownLatch) {}
    
    public final void onCompleted(GraphResponse param1GraphResponse) {
      m.f(param1GraphResponse, "response");
      try {
        FacebookRequestError facebookRequestError = param1GraphResponse.getError();
        String str = "Error staging photo.";
        if (facebookRequestError != null) {
          String str1 = facebookRequestError.getErrorMessage();
          if (str1 != null)
            str = str1; 
          throw new FacebookGraphResponseException(param1GraphResponse, str);
        } 
        JSONObject jSONObject = param1GraphResponse.getJSONObject();
        if (jSONObject != null) {
          String str1 = jSONObject.optString("uri");
          if (str1 != null) {
            this.b[this.c] = str1;
          } else {
            throw new FacebookException("Error staging photo.");
          } 
        } else {
          throw new FacebookException("Error staging photo.");
        } 
      } catch (Exception exception) {
        WebDialog.b.a(this.a)[this.c] = exception;
      } 
      this.d.countDown();
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "it", "Landroid/view/View;", "kotlin.jvm.PlatformType", "onClick"}, k = 3, mv = {1, 5, 1})
  static final class c implements View.OnClickListener {
    c(WebDialog param1WebDialog) {}
    
    public final void onClick(View param1View) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        return;
      } finally {
        param1View = null;
        CrashShieldHandler.handleThrowable((Throwable)param1View, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "it", "Landroid/content/DialogInterface;", "kotlin.jvm.PlatformType", "onCancel"}, k = 3, mv = {1, 5, 1})
  static final class d implements DialogInterface.OnCancelListener {
    d(WebDialog param1WebDialog) {}
    
    public final void onCancel(DialogInterface param1DialogInterface) {
      this.b.cancel();
    }
  }
  
  @Metadata(d1 = {"\000\026\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\0032\016\020\005\032\n \004*\004\030\0010\0060\006H\n¢\006\002\b\007"}, d2 = {"<anonymous>", "", "v", "Landroid/view/View;", "kotlin.jvm.PlatformType", "event", "Landroid/view/MotionEvent;", "onTouch"}, k = 3, mv = {1, 5, 1})
  static final class e implements View.OnTouchListener {
    public static final e b = new e();
    
    public final boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      if (!param1View.hasFocus())
        param1View.requestFocus(); 
      return false;
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\013\n\000*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026¨\006\006"}, d2 = {"com/facebook/internal/WebDialog$setUpWebView$1", "Landroid/webkit/WebView;", "onWindowFocusChanged", "", "hasWindowFocus", "", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class WebDialog$setUpWebView$1 extends WebView {
    WebDialog$setUpWebView$1(Context param1Context) {
      super(param1Context);
    }
    
    public boolean dispatchTouchEvent(MotionEvent param1MotionEvent) {
      DetectTouchUtils.webViewOnTouch("com.facebook", this, param1MotionEvent);
      return super.dispatchTouchEvent(param1MotionEvent);
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      if (!true) {
        setMeasuredDimension(0, 0);
        return;
      } 
      super.onMeasure(param1Int1, param1Int2);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      try {
        super.onWindowFocusChanged(param1Boolean);
        return;
      } catch (NullPointerException nullPointerException) {
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\internal\WebDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */