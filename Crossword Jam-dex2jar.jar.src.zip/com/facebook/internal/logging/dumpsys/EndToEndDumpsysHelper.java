package com.facebook.internal.logging.dumpsys;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.webkit.WebView;
import android.widget.TextView;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.m;
import kotlin.k0.j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000N\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\021\n\002\b\006\b\007\030\000 \0352\0020\001:\003\033\034\035B\005¢\006\002\020\002JB\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\r\032\0020\0162\b\020\017\032\004\030\0010\0202\006\020\021\032\0020\0222\006\020\023\032\0020\0222\006\020\024\032\0020\0252\006\020\026\032\0020\025H\002J+\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\r\032\0020\0162\f\020\027\032\b\022\004\022\0020\f0\030H\002¢\006\002\020\031J(\020\032\032\0020\n2\006\020\r\032\0020\0162\006\020\017\032\0020\0202\006\020\013\032\0020\f2\006\020\026\032\0020\025H\002R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000¨\006\036"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper;", "", "()V", "lithoViewToStringMethod", "Ljava/lang/reflect/Method;", "rootResolver", "Lcom/facebook/internal/logging/dumpsys/AndroidRootResolver;", "webViewDumpHelper", "Lcom/facebook/internal/logging/dumpsys/WebViewDumpHelper;", "dumpViewHierarchy", "", "prefix", "", "writer", "Ljava/io/PrintWriter;", "view", "Landroid/view/View;", "leftOffset", "", "topOffset", "withWebView", "", "withProps", "args", "", "(Ljava/lang/String;Ljava/io/PrintWriter;[Ljava/lang/String;)V", "writeLithoViewSubHierarchy", "Api21Utils", "Api24Utils", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
@SuppressLint({"HexColorValueUsage", "CatchGeneralException", "BadMethodUse-java.lang.String.length"})
public final class EndToEndDumpsysHelper {
  private static final String ALL_ROOTS_ARGUMENT = "all-roots";
  
  public static final Companion Companion = new Companion(null);
  
  private static final String E2E_ARGUMENT = "e2e";
  
  private static final String LITHO_VIEW_CLASS = "com.facebook.litho.LithoView";
  
  private static final String LITHO_VIEW_TEST_HELPER_CLASS = "com.facebook.litho.LithoViewTestHelper";
  
  private static final String LITHO_VIEW_TO_STRING_METHOD = "viewToStringForE2E";
  
  private static final String RC_TEXT_VIEW_SIMPLE_CLASS_NAME = "RCTextView";
  
  private static final String TOP_ROOT_ARGUMENT = "top-root";
  
  private static final String WITH_PROPS_ARGUMENT = "props";
  
  private static final String WITH_WEBVIEW_ARGUMENT = "webview";
  
  private static EndToEndDumpsysHelper instance;
  
  private static Method rcTextViewGetTextMethod;
  
  private Method lithoViewToStringMethod;
  
  private final AndroidRootResolver rootResolver = new AndroidRootResolver();
  
  private final WebViewDumpHelper webViewDumpHelper = new WebViewDumpHelper();
  
  private final void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, View paramView, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
      return;
    } 
    paramPrintWriter.print(paramView.getClass().getName());
    paramPrintWriter.print("{");
    paramPrintWriter.print(Integer.toHexString(paramView.hashCode()));
    Companion companion = Companion;
    companion.writeViewFlags(paramPrintWriter, paramView);
    companion.writeViewBounds(paramPrintWriter, paramView, paramInt1, paramInt2);
    companion.writeViewTestId(paramPrintWriter, paramView);
    companion.writeViewText(paramPrintWriter, paramView);
    if (paramBoolean2 && Build.VERSION.SDK_INT >= 21)
      a.b.b(paramPrintWriter, paramView); 
    paramPrintWriter.println("}");
    if (companion.isExtendsLithoView(paramView))
      writeLithoViewSubHierarchy(paramPrintWriter, paramView, paramString, paramBoolean2); 
    if (paramBoolean1 && paramView instanceof WebView)
      this.webViewDumpHelper.handle((WebView)paramView); 
    if (!(paramView instanceof ViewGroup))
      return; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    paramInt2 = viewGroup.getChildCount();
    if (paramInt2 <= 0)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    paramString = stringBuilder.toString();
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
      dumpViewHierarchy(paramString, paramPrintWriter, viewGroup.getChildAt(paramInt1), arrayOfInt[0], arrayOfInt[1], paramBoolean1, paramBoolean2); 
  }
  
  private final void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("Top Level Window View Hierarchy:");
    Companion companion = Companion;
    boolean bool1 = companion.hasArgument(paramArrayOfString, "all-roots");
    boolean bool2 = companion.hasArgument(paramArrayOfString, "top-root");
    boolean bool3 = companion.hasArgument(paramArrayOfString, "webview");
    boolean bool4 = companion.hasArgument(paramArrayOfString, "props");
    try {
      List<?> list = this.rootResolver.listActiveRoots();
      if (list != null) {
        if (list.isEmpty())
          return; 
        Collections.reverse(list);
        paramArrayOfString = null;
        for (AndroidRootResolver.Root root : list) {
          if (root != null) {
            View view = root.getView();
            if (view == null || view.getVisibility() != 0)
              continue; 
            if (!bool1 && paramArrayOfString != null && Math.abs((root.getParam()).type - ((WindowManager.LayoutParams)paramArrayOfString).type) != 1)
              break; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(paramString);
            stringBuilder.append("  ");
            dumpViewHierarchy(stringBuilder.toString(), paramPrintWriter, root.getView(), 0, 0, bool3, bool4);
            WindowManager.LayoutParams layoutParams = root.getParam();
            if (bool2)
              break; 
          } 
        } 
        this.webViewDumpHelper.dump(paramPrintWriter);
        return;
      } 
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failure in view hierarchy dump: ");
      stringBuilder.append(exception.getMessage());
      paramPrintWriter.println(stringBuilder.toString());
      return;
    } 
  }
  
  public static final boolean maybeDump(String paramString, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    return Companion.maybeDump(paramString, paramPrintWriter, paramArrayOfString);
  }
  
  private final void writeLithoViewSubHierarchy(PrintWriter paramPrintWriter, View paramView, String paramString, boolean paramBoolean) {
    try {
      if (this.lithoViewToStringMethod == null) {
        Class<?> clazz = Class.forName("com.facebook.litho.LithoViewTestHelper");
        m.e(clazz, "Class.forName(LITHO_VIEW_TEST_HELPER_CLASS)");
        this.lithoViewToStringMethod = clazz.getDeclaredMethod("viewToStringForE2E", new Class[] { View.class, int.class, boolean.class });
      } 
      Method method = this.lithoViewToStringMethod;
      Object object = null;
      if (method != null)
        object = method.invoke(null, new Object[] { paramView, Integer.valueOf(paramString.length() / 2 + 1), Boolean.valueOf(paramBoolean) }); 
      if (object != null) {
        m.e(paramPrintWriter.append((String)object), "writer.append(lithoViewDump)");
        return;
      } 
      throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
    } catch (Exception exception) {
      paramPrintWriter.append(paramString).append("Failed litho view sub hierarch dump: ").append(Companion.fixString(exception.getMessage(), 100)).println();
      return;
    } 
  }
  
  @Metadata(d1 = {"\000Z\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\t\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\r\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\000\n\002\020\021\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\007\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\024\020\021\032\004\030\0010\0222\b\020\023\032\004\030\0010\024H\002J\032\020\025\032\0020\0042\b\020\026\032\004\030\0010\0272\006\020\030\032\0020\031H\002J\022\020\032\032\004\030\0010\0042\006\020\023\032\0020\024H\003J%\020\033\032\0020\0342\016\020\035\032\n\022\004\022\0020\004\030\0010\0362\006\020\037\032\0020\004H\002¢\006\002\020 J\020\020!\032\0020\0342\006\020\023\032\0020\024H\002J-\020\"\032\0020\0342\006\020#\032\0020\0042\006\020$\032\0020%2\016\020\035\032\n\022\004\022\0020\004\030\0010\036H\007¢\006\002\020&J\030\020'\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J(\020)\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\0242\006\020*\032\0020\0312\006\020+\032\0020\031H\002J\030\020,\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J\030\020-\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\002J\030\020.\032\0020(2\006\020$\032\0020%2\006\020\023\032\0020\024H\003R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\016\020\t\032\0020\004XT¢\006\002\n\000R\016\020\n\032\0020\004XT¢\006\002\n\000R\016\020\013\032\0020\004XT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\020\020\r\032\004\030\0010\016X\016¢\006\002\n\000R\020\020\017\032\004\030\0010\020X\016¢\006\002\n\000¨\006/"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Companion;", "", "()V", "ALL_ROOTS_ARGUMENT", "", "E2E_ARGUMENT", "LITHO_VIEW_CLASS", "LITHO_VIEW_TEST_HELPER_CLASS", "LITHO_VIEW_TO_STRING_METHOD", "RC_TEXT_VIEW_SIMPLE_CLASS_NAME", "TOP_ROOT_ARGUMENT", "WITH_PROPS_ARGUMENT", "WITH_WEBVIEW_ARGUMENT", "instance", "Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper;", "rcTextViewGetTextMethod", "Ljava/lang/reflect/Method;", "createNodeInfoFromView", "Landroid/view/accessibility/AccessibilityNodeInfo;", "view", "Landroid/view/View;", "fixString", "str", "", "maxLength", "", "getTextFromRcTextView", "hasArgument", "", "args", "", "argument", "([Ljava/lang/String;Ljava/lang/String;)Z", "isExtendsLithoView", "maybeDump", "prefix", "writer", "Ljava/io/PrintWriter;", "(Ljava/lang/String;Ljava/io/PrintWriter;[Ljava/lang/String;)Z", "maybeWriteViewTestIdFromTag", "", "writeViewBounds", "leftOffset", "topOffset", "writeViewFlags", "writeViewTestId", "writeViewText", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    private final AccessibilityNodeInfo createNodeInfoFromView(View param1View) {
      if (param1View == null)
        return null; 
      AccessibilityNodeInfo accessibilityNodeInfo = AccessibilityNodeInfo.obtain();
      try {
        param1View.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        return accessibilityNodeInfo;
      } catch (NullPointerException nullPointerException) {
        if (accessibilityNodeInfo != null)
          accessibilityNodeInfo.recycle(); 
        return null;
      } 
    }
    
    private final String fixString(CharSequence param1CharSequence, int param1Int) {
      if (param1CharSequence != null) {
        boolean bool;
        if (param1CharSequence.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          String str2 = j.w(j.w(j.w(param1CharSequence.toString(), " \n", " ", false, 4, null), "\n", " ", false, 4, null), "\"", "", false, 4, null);
          String str1 = str2;
          if (param1CharSequence.length() > param1Int) {
            param1CharSequence = new StringBuilder();
            Objects.requireNonNull(str2, "null cannot be cast to non-null type java.lang.String");
            str1 = str2.substring(0, param1Int);
            m.e(str1, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            param1CharSequence.append(str1);
            param1CharSequence.append("...");
            str1 = param1CharSequence.toString();
          } 
          return str1;
        } 
      } 
      return "";
    }
    
    @SuppressLint({"PrivateApi", "ReflectionMethodUse"})
    private final String getTextFromRcTextView(View param1View) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
      if (EndToEndDumpsysHelper.rcTextViewGetTextMethod == null)
        EndToEndDumpsysHelper.rcTextViewGetTextMethod = param1View.getClass().getDeclaredMethod("getText", new Class[0]); 
      Method method = EndToEndDumpsysHelper.rcTextViewGetTextMethod;
      String str = null;
      if (method != null) {
        Object object = method.invoke(param1View, new Object[0]);
      } else {
        param1View = null;
      } 
      if (param1View != null)
        str = param1View.toString(); 
      return str;
    }
    
    private final boolean hasArgument(String[] param1ArrayOfString, String param1String) {
      if (param1ArrayOfString == null)
        return false; 
      int j = param1ArrayOfString.length;
      for (int i = 0; i < j; i++) {
        if (j.p(param1String, param1ArrayOfString[i], true))
          return true; 
      } 
      return false;
    }
    
    private final boolean isExtendsLithoView(View param1View) {
      for (Class<?> clazz = param1View.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
        if (m.a(clazz.getName(), "com.facebook.litho.LithoView"))
          return true; 
      } 
      return false;
    }
    
    private final void maybeWriteViewTestIdFromTag(PrintWriter param1PrintWriter, View param1View) {
      Object object2 = param1View.getTag();
      Object object1 = object2;
      if (!(object2 instanceof String))
        object1 = null; 
      object1 = object1;
      if (object1 != null) {
        boolean bool;
        if (object1.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          return; 
        param1PrintWriter.print(" app:tag/");
        param1PrintWriter.print(fixString((CharSequence)object1, 60));
      } 
    }
    
    private final void writeViewBounds(PrintWriter param1PrintWriter, View param1View, int param1Int1, int param1Int2) {
      int[] arrayOfInt = new int[2];
      param1View.getLocationOnScreen(arrayOfInt);
      param1PrintWriter.print(" ");
      param1PrintWriter.print(arrayOfInt[0] - param1Int1);
      param1PrintWriter.print(",");
      param1PrintWriter.print(arrayOfInt[1] - param1Int2);
      param1PrintWriter.print("-");
      param1PrintWriter.print(arrayOfInt[0] + param1View.getWidth() - param1Int1);
      param1PrintWriter.print(",");
      param1PrintWriter.print(arrayOfInt[1] + param1View.getHeight() - param1Int2);
    }
    
    private final void writeViewFlags(PrintWriter param1PrintWriter, View param1View) {
      param1PrintWriter.print(" ");
      int i = param1View.getVisibility();
      String str5 = "V";
      String str2 = ".";
      if (i != 0) {
        if (i != 4) {
          if (i != 8) {
            param1PrintWriter.print(".");
          } else {
            param1PrintWriter.print("G");
          } 
        } else {
          param1PrintWriter.print("I");
        } 
      } else {
        param1PrintWriter.print("V");
      } 
      boolean bool = param1View.isFocusable();
      String str3 = "F";
      if (bool) {
        str1 = "F";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isEnabled()) {
        str1 = "E";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      param1PrintWriter.print(".");
      bool = param1View.isHorizontalScrollBarEnabled();
      String str4 = "H";
      if (bool) {
        str1 = "H";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isVerticalScrollBarEnabled()) {
        str1 = str5;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isClickable()) {
        str1 = "C";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isLongClickable()) {
        str1 = "L";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      param1PrintWriter.print(" ");
      if (param1View.isFocused()) {
        str1 = str3;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isSelected()) {
        str1 = "S";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isHovered()) {
        str1 = str4;
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      if (param1View.isActivated()) {
        str1 = "A";
      } else {
        str1 = ".";
      } 
      param1PrintWriter.print(str1);
      String str1 = str2;
      if (param1View.isDirty())
        str1 = "D"; 
      param1PrintWriter.print(str1);
    }
    
    private final void writeViewTestId(PrintWriter param1PrintWriter, View param1View) {
      try {
        String str;
        int i = param1View.getId();
        if (i == -1) {
          maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
          return;
        } 
        param1PrintWriter.append(" #");
        param1PrintWriter.append(Integer.toHexString(i));
        Resources resources = param1View.getResources();
        if (i <= 0 || resources == null) {
          maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
          return;
        } 
        int j = 0xFF000000 & i;
        if (j != 16777216) {
          if (j != 2130706432) {
            str = resources.getResourcePackageName(i);
            m.e(str, "resources.getResourcePackageName(id)");
          } else {
            str = "app";
          } 
        } else {
          str = "android";
        } 
        param1PrintWriter.print(" ");
        param1PrintWriter.print(str);
        param1PrintWriter.print(":");
        param1PrintWriter.print(resources.getResourceTypeName(i));
        param1PrintWriter.print("/");
        param1PrintWriter.print(resources.getResourceEntryName(i));
        return;
      } catch (Exception exception) {
        maybeWriteViewTestIdFromTag(param1PrintWriter, param1View);
        return;
      } 
    }
    
    @SuppressLint({"ReflectionMethodUse"})
    private final void writeViewText(PrintWriter param1PrintWriter, View param1View) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #9
      //   3: aload_2
      //   4: instanceof android/widget/TextView
      //   7: istore #8
      //   9: iconst_0
      //   10: istore #7
      //   12: iload #8
      //   14: ifeq -> 31
      //   17: aload_2
      //   18: checkcast android/widget/TextView
      //   21: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   24: invokevirtual toString : ()Ljava/lang/String;
      //   27: astore_2
      //   28: goto -> 167
      //   31: aload_2
      //   32: invokevirtual getClass : ()Ljava/lang/Class;
      //   35: invokevirtual getSimpleName : ()Ljava/lang/String;
      //   38: ldc_w 'RCTextView'
      //   41: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   44: ifeq -> 56
      //   47: aload_0
      //   48: aload_2
      //   49: invokespecial getTextFromRcTextView : (Landroid/view/View;)Ljava/lang/String;
      //   52: astore_2
      //   53: goto -> 167
      //   56: aload_2
      //   57: invokevirtual getContentDescription : ()Ljava/lang/CharSequence;
      //   60: astore #10
      //   62: aload #10
      //   64: ifnull -> 74
      //   67: aload #10
      //   69: invokevirtual toString : ()Ljava/lang/String;
      //   72: astore #9
      //   74: aload #9
      //   76: ifnull -> 94
      //   79: aload #9
      //   81: invokeinterface length : ()I
      //   86: ifne -> 216
      //   89: iconst_1
      //   90: istore_3
      //   91: goto -> 218
      //   94: aload_2
      //   95: invokevirtual getTag : ()Ljava/lang/Object;
      //   98: astore_2
      //   99: aload_2
      //   100: ifnull -> 292
      //   103: aload_2
      //   104: invokevirtual toString : ()Ljava/lang/String;
      //   107: astore_2
      //   108: aload_2
      //   109: invokeinterface length : ()I
      //   114: iconst_1
      //   115: isub
      //   116: istore_3
      //   117: iconst_0
      //   118: istore #4
      //   120: iload #4
      //   122: istore #5
      //   124: goto -> 225
      //   127: aload_2
      //   128: iload #6
      //   130: invokeinterface charAt : (I)C
      //   135: bipush #32
      //   137: invokestatic h : (II)I
      //   140: ifgt -> 249
      //   143: iconst_1
      //   144: istore #6
      //   146: goto -> 252
      //   149: aload_2
      //   150: iload #4
      //   152: iload_3
      //   153: iconst_1
      //   154: iadd
      //   155: invokeinterface subSequence : (II)Ljava/lang/CharSequence;
      //   160: invokevirtual toString : ()Ljava/lang/String;
      //   163: astore_2
      //   164: goto -> 167
      //   167: aload_2
      //   168: ifnull -> 213
      //   171: iload #7
      //   173: istore_3
      //   174: aload_2
      //   175: invokeinterface length : ()I
      //   180: ifne -> 298
      //   183: iconst_1
      //   184: istore_3
      //   185: goto -> 298
      //   188: aload_1
      //   189: ldc_w ' text="'
      //   192: invokevirtual print : (Ljava/lang/String;)V
      //   195: aload_1
      //   196: aload_0
      //   197: aload_2
      //   198: sipush #600
      //   201: invokespecial fixString : (Ljava/lang/CharSequence;I)Ljava/lang/String;
      //   204: invokevirtual print : (Ljava/lang/String;)V
      //   207: aload_1
      //   208: ldc '"'
      //   210: invokevirtual print : (Ljava/lang/String;)V
      //   213: return
      //   214: astore_1
      //   215: return
      //   216: iconst_0
      //   217: istore_3
      //   218: iload_3
      //   219: ifeq -> 292
      //   222: goto -> 94
      //   225: iload #4
      //   227: iload_3
      //   228: if_icmpgt -> 149
      //   231: iload #5
      //   233: ifne -> 243
      //   236: iload #4
      //   238: istore #6
      //   240: goto -> 127
      //   243: iload_3
      //   244: istore #6
      //   246: goto -> 127
      //   249: iconst_0
      //   250: istore #6
      //   252: iload #5
      //   254: ifne -> 277
      //   257: iload #6
      //   259: ifne -> 268
      //   262: iconst_1
      //   263: istore #5
      //   265: goto -> 225
      //   268: iload #4
      //   270: iconst_1
      //   271: iadd
      //   272: istore #4
      //   274: goto -> 225
      //   277: iload #6
      //   279: ifne -> 285
      //   282: goto -> 149
      //   285: iload_3
      //   286: iconst_1
      //   287: isub
      //   288: istore_3
      //   289: goto -> 225
      //   292: aload #9
      //   294: astore_2
      //   295: goto -> 167
      //   298: iload_3
      //   299: ifeq -> 188
      //   302: return
      // Exception table:
      //   from	to	target	type
      //   3	9	214	java/lang/Exception
      //   17	28	214	java/lang/Exception
      //   31	53	214	java/lang/Exception
      //   56	62	214	java/lang/Exception
      //   67	74	214	java/lang/Exception
      //   79	89	214	java/lang/Exception
      //   94	99	214	java/lang/Exception
      //   103	117	214	java/lang/Exception
      //   127	143	214	java/lang/Exception
      //   149	164	214	java/lang/Exception
      //   174	183	214	java/lang/Exception
      //   188	213	214	java/lang/Exception
    }
    
    public final boolean maybeDump(String param1String, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      m.f(param1String, "prefix");
      m.f(param1PrintWriter, "writer");
      if (param1ArrayOfString != null) {
        boolean bool;
        if (param1ArrayOfString.length == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool ^ true) != 0 && m.a("e2e", param1ArrayOfString[0])) {
          if (EndToEndDumpsysHelper.instance == null)
            EndToEndDumpsysHelper.instance = new EndToEndDumpsysHelper(); 
          EndToEndDumpsysHelper endToEndDumpsysHelper = EndToEndDumpsysHelper.instance;
          if (endToEndDumpsysHelper != null)
            endToEndDumpsysHelper.dumpViewHierarchy(param1String, param1PrintWriter, param1ArrayOfString); 
          return true;
        } 
      } 
      return false;
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\022\020\005\032\004\030\0010\0062\006\020\007\032\0020\bH\002J\026\020\t\032\0020\n2\006\020\013\032\0020\f2\006\020\007\032\0020\bR\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000¨\006\r"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Api21Utils;", "", "()V", "keyedTagsField", "Ljava/lang/reflect/Field;", "getTags", "Lorg/json/JSONObject;", "view", "Landroid/view/View;", "writeExtraProps", "", "writer", "Ljava/io/PrintWriter;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class a {
    private static Field a;
    
    public static final a b = new a();
    
    static {
      try {
        Field field = View.class.getDeclaredField("mKeyedTags");
        a = field;
        if (field != null)
          field.setAccessible(true); 
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        return;
      } 
    }
    
    private final JSONObject a(View param1View) {
      try {
        if (a == null) {
          Field field1 = View.class.getDeclaredField("mKeyedTags");
          a = field1;
          if (field1 != null)
            field1.setAccessible(true); 
        } 
        Field field = a;
        if (field != null) {
          Object object = field.get(param1View);
        } else {
          field = null;
        } 
        if (field != null) {
          SparseArray sparseArray = (SparseArray)field;
          if (sparseArray != null && sparseArray.size() > 0) {
            JSONObject jSONObject = new JSONObject();
            int i = 0;
            try {
              int j = sparseArray.size();
              while (true) {
                if (i < j) {
                  String str = ResourcesUtil.getIdStringQuietly(param1View.getResources(), sparseArray.keyAt(i));
                  try {
                    jSONObject.put(str, sparseArray.valueAt(i));
                  } catch (JSONException jSONException) {}
                  i++;
                  continue;
                } 
                return jSONObject;
              } 
            } catch (Exception exception) {}
            return jSONObject;
          } 
        } else {
          throw new NullPointerException("null cannot be cast to non-null type android.util.SparseArray<*>");
        } 
        return null;
      } catch (Exception exception) {
        return null;
      } 
    }
    
    public final void b(PrintWriter param1PrintWriter, View param1View) {
      int i = Build.VERSION.SDK_INT;
      m.f(param1PrintWriter, "writer");
      m.f(param1View, "view");
      if (i < 21)
        return; 
      EndToEndDumpsysHelper.Companion companion = EndToEndDumpsysHelper.Companion;
      AccessibilityNodeInfo accessibilityNodeInfo = companion.createNodeInfoFromView(param1View);
      if (accessibilityNodeInfo != null) {
        JSONObject jSONObject = new JSONObject();
        try {
          if (param1View instanceof TextView) {
            ColorStateList colorStateList = ((TextView)param1View).getTextColors();
            m.e(colorStateList, "view.textColors");
            jSONObject.put("textColor", colorStateList.getDefaultColor());
            jSONObject.put("textSize", ((TextView)param1View).getTextSize());
            jSONObject.put("hint", companion.fixString(((TextView)param1View).getHint(), 100));
          } 
          JSONObject jSONObject1 = a(param1View);
          if (jSONObject1 != null)
            jSONObject.put("keyedTags", jSONObject1); 
          JSONArray jSONArray = new JSONArray();
          for (AccessibilityNodeInfo.AccessibilityAction accessibilityAction : accessibilityNodeInfo.getActionList()) {
            m.e(accessibilityAction, "action");
            CharSequence charSequence = accessibilityAction.getLabel();
            if (charSequence != null) {
              charSequence = charSequence;
              if (charSequence != null)
                jSONArray.put(EndToEndDumpsysHelper.Companion.fixString(charSequence, 50)); 
              continue;
            } 
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
          } 
          if (jSONArray.length() > 0)
            jSONObject.put("actions", jSONArray); 
          EndToEndDumpsysHelper.Companion companion1 = EndToEndDumpsysHelper.Companion;
          String str = companion1.fixString(accessibilityNodeInfo.getContentDescription(), 50);
          if (str != null) {
            boolean bool;
            if (str.length() > 0) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool)
              jSONObject.put("content-description", str); 
          } 
          jSONObject.put("accessibility-focused", accessibilityNodeInfo.isAccessibilityFocused()).put("checkable", accessibilityNodeInfo.isCheckable()).put("checked", accessibilityNodeInfo.isChecked()).put("class-name", companion1.fixString(accessibilityNodeInfo.getClassName(), 50)).put("clickable", accessibilityNodeInfo.isClickable()).put("content-invalid", accessibilityNodeInfo.isContentInvalid()).put("dismissable", accessibilityNodeInfo.isDismissable()).put("editable", accessibilityNodeInfo.isEditable()).put("enabled", accessibilityNodeInfo.isEnabled()).put("focusable", accessibilityNodeInfo.isFocusable()).put("focused", accessibilityNodeInfo.isFocused()).put("long-clickable", accessibilityNodeInfo.isLongClickable()).put("multiline", accessibilityNodeInfo.isMultiLine()).put("password", accessibilityNodeInfo.isPassword()).put("scrollable", accessibilityNodeInfo.isScrollable()).put("selected", accessibilityNodeInfo.isSelected()).put("visible-to-user", accessibilityNodeInfo.isVisibleToUser());
          if (i >= 24)
            EndToEndDumpsysHelper.b.a.a(jSONObject, accessibilityNodeInfo); 
        } catch (Exception exception) {
          try {
            jSONObject.put("DUMP-ERROR", EndToEndDumpsysHelper.Companion.fixString(exception.getMessage(), 50));
          } catch (JSONException jSONException) {}
        } 
        param1PrintWriter.append(" props=\"").append(jSONObject.toString()).append("\"");
      } 
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÂ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Lcom/facebook/internal/logging/dumpsys/EndToEndDumpsysHelper$Api24Utils;", "", "()V", "addExtraProps", "", "props", "Lorg/json/JSONObject;", "nodeInfo", "Landroid/view/accessibility/AccessibilityNodeInfo;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class b {
    public static final b a = new b();
    
    public final void a(JSONObject param1JSONObject, AccessibilityNodeInfo param1AccessibilityNodeInfo) throws JSONException {
      m.f(param1JSONObject, "props");
      m.f(param1AccessibilityNodeInfo, "nodeInfo");
      if (Build.VERSION.SDK_INT < 24)
        return; 
      param1JSONObject.put("context-clickable", param1AccessibilityNodeInfo.isContextClickable()).put("drawing-order", param1AccessibilityNodeInfo.getDrawingOrder()).put("important-for-accessibility", param1AccessibilityNodeInfo.isImportantForAccessibility());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\internal\logging\dumpsys\EndToEndDumpsysHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */