package com.facebook.ads.internal.dynamicloading;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.Keep;
import androidx.annotation.Nullable;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.BuildConfig;
import com.facebook.ads.internal.settings.MultithreadedBundleWrapper;
import com.safedk.android.internal.partials.FacebookAudienceNetworkFilesBridge;
import dalvik.system.DexClassLoader;
import dalvik.system.InMemoryDexClassLoader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Keep
public class DynamicLoaderFactory {
  private static final String AUDIENCE_NETWORK_CODE_PATH = "audience_network";
  
  public static final String AUDIENCE_NETWORK_DEX = "audience_network.dex";
  
  private static final String CODE_CACHE_DIR = "code_cache";
  
  static final String DEX_LOADING_ERROR_MESSAGE = "Can't load Audience Network Dex. Please, check that audience_network.dex is inside of assets folder.";
  
  private static final int DEX_LOAD_RETRY_COUNT = 3;
  
  private static final int DEX_LOAD_RETRY_DELAY_MS = 200;
  
  private static final String DYNAMIC_LOADING_BUILD_TYPE = "releaseDL";
  
  public static final boolean LOAD_FROM_ASSETS = "releaseDL".equals(BuildConfig.BUILD_TYPE);
  
  private static final String OPTIMIZED_DEX_PATH = "optimized";
  
  private static final AtomicReference<DynamicLoader> sDynamicLoader = new AtomicReference<DynamicLoader>();
  
  private static boolean sFallbackMode;
  
  private static final AtomicBoolean sInitializing = new AtomicBoolean();
  
  private static boolean sUseLegacyClassLoader = true;
  
  private static AudienceNetworkAds.InitResult createErrorInitResult(Throwable paramThrowable) {
    return new c(paramThrowable);
  }
  
  private static String createErrorMessage(Throwable paramThrowable) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't load Audience Network Dex. Please, check that audience_network.dex is inside of assets folder.\n");
    stringBuilder.append(stackTraceToString(paramThrowable));
    return stringBuilder.toString();
  }
  
  @TargetApi(26)
  private static ClassLoader createInMemoryClassLoader(Context paramContext) throws IOException {
    InputStream inputStream = paramContext.getAssets().open("audience_network.dex");
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[1024];
    while (true) {
      int i = inputStream.read(arrayOfByte);
      if (i > 0) {
        byteArrayOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      inputStream.close();
      byteArrayOutputStream.flush();
      byteArrayOutputStream.close();
      return (ClassLoader)new InMemoryDexClassLoader(ByteBuffer.wrap(byteArrayOutputStream.toByteArray()), DynamicLoaderFactory.class.getClassLoader());
    } 
  }
  
  private static void doCallInitialize(Context paramContext, @Nullable DynamicLoader paramDynamicLoader, @Nullable Throwable paramThrowable, boolean paramBoolean, @Nullable MultithreadedBundleWrapper paramMultithreadedBundleWrapper, @Nullable AudienceNetworkAds.InitListener paramInitListener) {
    if (paramThrowable != null) {
      if (paramInitListener != null) {
        (new Handler(Looper.getMainLooper())).postDelayed(new b(paramInitListener, paramThrowable), 100L);
        return;
      } 
      Log.e("FBAudienceNetwork", "Can't load Audience Network Dex. Please, check that audience_network.dex is inside of assets folder.", paramThrowable);
      return;
    } 
    if (paramDynamicLoader != null) {
      if (paramBoolean) {
        paramDynamicLoader.createAudienceNetworkAdsApi().onContentProviderCreated(paramContext);
        return;
      } 
      paramDynamicLoader.createAudienceNetworkAdsApi().initialize(paramContext, paramMultithreadedBundleWrapper, paramInitListener);
    } 
  }
  
  private static DynamicLoader doMakeLoader(Context paramContext, boolean paramBoolean) throws Exception {
    AtomicReference<DynamicLoader> atomicReference = sDynamicLoader;
    DynamicLoader dynamicLoader2 = atomicReference.get();
    DynamicLoader dynamicLoader1 = dynamicLoader2;
    if (dynamicLoader2 == null) {
      if (!LOAD_FROM_ASSETS) {
        dynamicLoader1 = (DynamicLoader)Class.forName("com.facebook.ads.internal.dynamicloading.DynamicLoaderImpl").newInstance();
      } else {
        long l1 = System.currentTimeMillis();
        dynamicLoader1 = (DynamicLoader)makeAdsSdkClassLoader(paramContext.getApplicationContext()).loadClass("com.facebook.ads.internal.dynamicloading.DynamicLoaderImpl").newInstance();
        long l2 = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SDK dex loading time: ");
        stringBuilder.append(l2 - l1);
        stringBuilder.toString();
      } 
      if (paramBoolean)
        dynamicLoader1.maybeInitInternally(paramContext); 
      atomicReference.set(dynamicLoader1);
    } 
    return dynamicLoader1;
  }
  
  @SuppressLint({"PrivateApi", "CatchGeneralException"})
  @Nullable
  private static Context getApplicationContextViaReflection() {
    try {
      return (Context)Class.forName("android.app.ActivityThread").getMethod("currentApplication", new Class[0]).invoke(null, null);
    } finally {
      Exception exception = null;
      Log.e("FBAudienceNetwork", "Failed to fetch Context from  ActivityThread. Audience Network SDK won't work unless you call AudienceNetworkAds.buildInitSettings().withListener(InitListener).initialize().", exception);
    } 
  }
  
  private static File getCacheCodeDirLegacy(Context paramContext, File paramFile) throws IOException {
    paramFile = new File(paramFile, "code_cache");
    try {
      mkdirChecked(paramFile);
      return paramFile;
    } catch (IOException iOException) {
      File file = paramContext.getDir("code_cache", 0);
      mkdirChecked(file);
      return file;
    } 
  }
  
  private static File getCodeCacheDir(Context paramContext, File paramFile) throws IOException {
    return (Build.VERSION.SDK_INT >= 21) ? paramContext.getCodeCacheDir() : getCacheCodeDirLegacy(paramContext, paramFile);
  }
  
  @Nullable
  public static DynamicLoader getDynamicLoader() {
    return sDynamicLoader.get();
  }
  
  private static File getSecondaryDir(File paramFile) throws IOException {
    paramFile = new File(paramFile, "audience_network");
    mkdirChecked(paramFile);
    return paramFile;
  }
  
  public static void initialize(Context paramContext, @Nullable MultithreadedBundleWrapper paramMultithreadedBundleWrapper, @Nullable AudienceNetworkAds.InitListener paramInitListener, boolean paramBoolean) {
    if (paramBoolean || !sInitializing.getAndSet(true))
      (new Thread(new a(paramContext, paramBoolean, paramMultithreadedBundleWrapper, paramInitListener))).start(); 
  }
  
  public static boolean isFallbackMode() {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sFallbackMode : Z
    //   6: istore_0
    //   7: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   9: monitorexit
    //   10: iload_0
    //   11: ireturn
    //   12: astore_1
    //   13: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  private static ClassLoader makeAdsSdkClassLoader(Context paramContext) throws Exception {
    if (Build.VERSION.SDK_INT >= 30)
      return createInMemoryClassLoader(paramContext); 
    if (sUseLegacyClassLoader)
      return (ClassLoader)makeLegacyAdsSdkClassLoader(paramContext); 
    File file = getSecondaryDir(getCodeCacheDir(paramContext, new File((paramContext.getApplicationInfo()).dataDir)));
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(file.getPath());
    stringBuilder.append(File.separator);
    stringBuilder.append("audience_network.dex");
    String str = stringBuilder.toString();
    InputStream inputStream = paramContext.getAssets().open("audience_network.dex");
    FileOutputStream fileOutputStream = FacebookAudienceNetworkFilesBridge.fileOutputStreamCtor(str);
    byte[] arrayOfByte = new byte[1024];
    while (true) {
      int i = inputStream.read(arrayOfByte);
      if (i > 0) {
        fileOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      inputStream.close();
      fileOutputStream.flush();
      fileOutputStream.close();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(file.getPath());
      stringBuilder1.append(File.separator);
      stringBuilder1.append("optimized");
      file = new File(stringBuilder1.toString());
      mkdirChecked(file);
      return (ClassLoader)new DexClassLoader(str, file.getPath(), null, paramContext.getClassLoader());
    } 
  }
  
  private static DexClassLoader makeLegacyAdsSdkClassLoader(Context paramContext) throws Exception {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramContext.getFilesDir().getPath());
    stringBuilder.append(File.separator);
    stringBuilder.append("audience_network.dex");
    String str = stringBuilder.toString();
    InputStream inputStream = paramContext.getAssets().open("audience_network.dex");
    FileOutputStream fileOutputStream = FacebookAudienceNetworkFilesBridge.fileOutputStreamCtor(str);
    byte[] arrayOfByte = new byte[1024];
    while (true) {
      int i = inputStream.read(arrayOfByte);
      if (i > 0) {
        fileOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      inputStream.close();
      fileOutputStream.flush();
      fileOutputStream.close();
      return new DexClassLoader(str, paramContext.getDir("optimized", 0).getPath(), null, DynamicLoaderFactory.class.getClassLoader());
    } 
  }
  
  public static DynamicLoader makeLoader(Context paramContext) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   2: monitorenter
    //   3: aload_0
    //   4: iconst_1
    //   5: invokestatic makeLoader : (Landroid/content/Context;Z)Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
    //   8: astore_0
    //   9: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   11: monitorexit
    //   12: aload_0
    //   13: areturn
    //   14: astore_0
    //   15: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   17: monitorexit
    //   18: aload_0
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  @SuppressLint({"CatchGeneralException"})
  public static DynamicLoader makeLoader(Context paramContext, boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   2: monitorenter
    //   3: aload_0
    //   4: ldc_w 'Context can not be null.'
    //   7: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   10: pop
    //   11: aload_0
    //   12: iload_1
    //   13: invokestatic doMakeLoader : (Landroid/content/Context;Z)Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
    //   16: astore_2
    //   17: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   19: monitorexit
    //   20: aload_2
    //   21: areturn
    //   22: astore_2
    //   23: ldc 'FBAudienceNetwork'
    //   25: ldc 'Can't load Audience Network Dex. Please, check that audience_network.dex is inside of assets folder.'
    //   27: aload_2
    //   28: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   31: pop
    //   32: aload_0
    //   33: aload_2
    //   34: invokestatic createErrorMessage : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   37: ldc2_w 0.1
    //   40: invokestatic reportDexLoadingIssue : (Landroid/content/Context;Ljava/lang/String;D)V
    //   43: invokestatic makeFallbackLoader : ()Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
    //   46: astore_0
    //   47: getstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sDynamicLoader : Ljava/util/concurrent/atomic/AtomicReference;
    //   50: aload_0
    //   51: invokevirtual set : (Ljava/lang/Object;)V
    //   54: iconst_1
    //   55: putstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sFallbackMode : Z
    //   58: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   60: monitorexit
    //   61: aload_0
    //   62: areturn
    //   63: astore_0
    //   64: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   66: monitorexit
    //   67: aload_0
    //   68: athrow
    // Exception table:
    //   from	to	target	type
    //   3	11	63	finally
    //   11	17	22	finally
    //   23	58	63	finally
  }
  
  @SuppressLint({"CatchGeneralException"})
  public static DynamicLoader makeLoaderUnsafe() {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sDynamicLoader : Ljava/util/concurrent/atomic/AtomicReference;
    //   6: astore_0
    //   7: aload_0
    //   8: invokevirtual get : ()Ljava/lang/Object;
    //   11: ifnonnull -> 44
    //   14: invokestatic getApplicationContextViaReflection : ()Landroid/content/Context;
    //   17: astore_0
    //   18: aload_0
    //   19: ifnull -> 33
    //   22: aload_0
    //   23: iconst_1
    //   24: invokestatic makeLoader : (Landroid/content/Context;Z)Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
    //   27: astore_0
    //   28: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   30: monitorexit
    //   31: aload_0
    //   32: areturn
    //   33: new java/lang/RuntimeException
    //   36: dup
    //   37: ldc_w 'You must call AudienceNetworkAds.buildInitSettings(Context).initialize() before you can use Audience Network SDK.'
    //   40: invokespecial <init> : (Ljava/lang/String;)V
    //   43: athrow
    //   44: aload_0
    //   45: invokevirtual get : ()Ljava/lang/Object;
    //   48: checkcast com/facebook/ads/internal/dynamicloading/DynamicLoader
    //   51: astore_0
    //   52: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   54: monitorexit
    //   55: aload_0
    //   56: areturn
    //   57: astore_0
    //   58: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   60: monitorexit
    //   61: aload_0
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	57	finally
    //   22	28	57	finally
    //   33	44	57	finally
    //   44	52	57	finally
  }
  
  private static void mkdirChecked(File paramFile) throws IOException {
    paramFile.mkdir();
    if (!paramFile.isDirectory()) {
      String str;
      File file = paramFile.getParentFile();
      if (file == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to create dir ");
        stringBuilder1.append(paramFile.getPath());
        stringBuilder1.append(". Parent file is null.");
        str = stringBuilder1.toString();
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to create dir ");
        stringBuilder1.append(paramFile.getPath());
        stringBuilder1.append(". parent file is a dir ");
        stringBuilder1.append(str.isDirectory());
        stringBuilder1.append(", a file ");
        stringBuilder1.append(str.isFile());
        stringBuilder1.append(", exists ");
        stringBuilder1.append(str.exists());
        stringBuilder1.append(", readable ");
        stringBuilder1.append(str.canRead());
        stringBuilder1.append(", writable ");
        stringBuilder1.append(str.canWrite());
        str = stringBuilder1.toString();
      } 
      Log.e("FBAudienceNetwork", str);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to create directory ");
      stringBuilder.append(paramFile.getPath());
      stringBuilder.append(", detailed message: ");
      stringBuilder.append(str);
      throw new IOException(stringBuilder.toString());
    } 
  }
  
  public static void setFallbackMode(boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   2: monitorenter
    //   3: iload_0
    //   4: ifeq -> 23
    //   7: getstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sDynamicLoader : Ljava/util/concurrent/atomic/AtomicReference;
    //   10: invokestatic makeFallbackLoader : ()Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
    //   13: invokevirtual set : (Ljava/lang/Object;)V
    //   16: iconst_1
    //   17: putstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sFallbackMode : Z
    //   20: goto -> 34
    //   23: getstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sDynamicLoader : Ljava/util/concurrent/atomic/AtomicReference;
    //   26: aconst_null
    //   27: invokevirtual set : (Ljava/lang/Object;)V
    //   30: iconst_0
    //   31: putstatic com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory.sFallbackMode : Z
    //   34: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   36: monitorexit
    //   37: return
    //   38: astore_1
    //   39: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   7	20	38	finally
    //   23	34	38	finally
  }
  
  public static void setUseLegacyClassLoader(boolean paramBoolean) {
    sUseLegacyClassLoader = paramBoolean;
  }
  
  private static String stackTraceToString(Throwable paramThrowable) {
    return Log.getStackTraceString(paramThrowable);
  }
  
  class a implements Runnable {
    a(DynamicLoaderFactory this$0, boolean param1Boolean, MultithreadedBundleWrapper param1MultithreadedBundleWrapper, AudienceNetworkAds.InitListener param1InitListener) {}
    
    @SuppressLint({"CatchGeneralException"})
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Landroid/content/Context;
      //   4: invokestatic registerActivityCallbacks : (Landroid/content/Context;)V
      //   7: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
      //   9: monitorenter
      //   10: aconst_null
      //   11: astore #4
      //   13: aconst_null
      //   14: astore_2
      //   15: iconst_0
      //   16: istore_1
      //   17: aload #4
      //   19: astore_3
      //   20: iload_1
      //   21: iconst_3
      //   22: if_icmpge -> 80
      //   25: aload_0
      //   26: getfield b : Landroid/content/Context;
      //   29: iconst_0
      //   30: invokestatic access$000 : (Landroid/content/Context;Z)Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;
      //   33: astore_3
      //   34: goto -> 80
      //   37: astore_3
      //   38: iload_1
      //   39: iconst_2
      //   40: if_icmpne -> 71
      //   43: aload_0
      //   44: getfield c : Z
      //   47: ifne -> 118
      //   50: aload_0
      //   51: getfield b : Landroid/content/Context;
      //   54: aload_3
      //   55: invokestatic access$100 : (Ljava/lang/Throwable;)Ljava/lang/String;
      //   58: ldc2_w 0.1
      //   61: invokestatic reportDexLoadingIssue : (Landroid/content/Context;Ljava/lang/String;D)V
      //   64: iconst_1
      //   65: invokestatic setFallbackMode : (Z)V
      //   68: goto -> 118
      //   71: ldc2_w 200
      //   74: invokestatic sleep : (J)V
      //   77: goto -> 120
      //   80: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
      //   82: monitorexit
      //   83: aload_0
      //   84: getfield b : Landroid/content/Context;
      //   87: aload_3
      //   88: aload_2
      //   89: aload_0
      //   90: getfield c : Z
      //   93: aload_0
      //   94: getfield d : Lcom/facebook/ads/internal/settings/MultithreadedBundleWrapper;
      //   97: aload_0
      //   98: getfield e : Lcom/facebook/ads/AudienceNetworkAds$InitListener;
      //   101: invokestatic access$200 : (Landroid/content/Context;Lcom/facebook/ads/internal/dynamicloading/DynamicLoader;Ljava/lang/Throwable;ZLcom/facebook/ads/internal/settings/MultithreadedBundleWrapper;Lcom/facebook/ads/AudienceNetworkAds$InitListener;)V
      //   104: invokestatic access$300 : ()Ljava/util/concurrent/atomic/AtomicBoolean;
      //   107: iconst_0
      //   108: invokevirtual set : (Z)V
      //   111: return
      //   112: astore_2
      //   113: ldc com/facebook/ads/internal/dynamicloading/DynamicLoaderFactory
      //   115: monitorexit
      //   116: aload_2
      //   117: athrow
      //   118: aload_3
      //   119: astore_2
      //   120: iload_1
      //   121: iconst_1
      //   122: iadd
      //   123: istore_1
      //   124: goto -> 17
      // Exception table:
      //   from	to	target	type
      //   25	34	37	finally
      //   43	68	112	finally
      //   71	77	112	finally
      //   80	83	112	finally
      //   113	116	112	finally
    }
  }
  
  class b implements Runnable {
    b(DynamicLoaderFactory this$0, Throwable param1Throwable) {}
    
    public void run() {
      this.b.onInitialized(DynamicLoaderFactory.createErrorInitResult(this.c));
    }
  }
  
  class c implements AudienceNetworkAds.InitResult {
    c(DynamicLoaderFactory this$0) {}
    
    public String getMessage() {
      return DynamicLoaderFactory.createErrorMessage(this.a);
    }
    
    public boolean isSuccess() {
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\ads\internal\dynamicloading\DynamicLoaderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */