package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public class AbstractAdListener implements InterstitialAdExtendedListener, RewardedVideoAdExtendedListener, RewardedInterstitialAdExtendedListener {
  public void onAdClicked(Ad paramAd) {}
  
  public void onAdLoaded(Ad paramAd) {}
  
  public void onError(Ad paramAd, AdError paramAdError) {}
  
  public void onInterstitialActivityDestroyed() {}
  
  public void onInterstitialDismissed(Ad paramAd) {}
  
  public void onInterstitialDisplayed(Ad paramAd) {}
  
  public void onLoggingImpression(Ad paramAd) {}
  
  public void onRewardedAdCompleted() {}
  
  public void onRewardedAdServerFailed() {}
  
  public void onRewardedAdServerSucceeded() {}
  
  public void onRewardedInterstitialActivityDestroyed() {}
  
  public void onRewardedInterstitialClosed() {}
  
  public void onRewardedInterstitialCompleted() {}
  
  public void onRewardedVideoActivityDestroyed() {}
  
  public void onRewardedVideoClosed() {}
  
  public void onRewardedVideoCompleted() {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\ads\AbstractAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */