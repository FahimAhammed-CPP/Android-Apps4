package com.facebook.ads;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.annotation.Keep;
import androidx.annotation.Nullable;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.api.NativeAdImageApi;
import com.facebook.ads.internal.api.NativeAdRatingApi;
import com.facebook.ads.internal.bench.Benchmark;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.infer.annotation.Nullsafe;
import org.json.JSONObject;

@Keep
@Nullsafe(Nullsafe.Mode.LOCAL)
public abstract class NativeAdBase implements Ad {
  final NativeAdBaseApi mNativeAdBaseApi;
  
  @Benchmark
  NativeAdBase(Context paramContext, NativeAdBase paramNativeAdBase) {
    this.mNativeAdBaseApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdBaseApi(paramNativeAdBase.mNativeAdBaseApi);
  }
  
  @Benchmark
  public NativeAdBase(Context paramContext, String paramString) {
    this.mNativeAdBaseApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdBaseApi(paramContext, paramString);
  }
  
  @Benchmark
  public NativeAdBase(NativeAdBaseApi paramNativeAdBaseApi) {
    this.mNativeAdBaseApi = paramNativeAdBaseApi;
  }
  
  @Benchmark
  public static NativeAdBase fromBidPayload(Context paramContext, String paramString1, String paramString2) throws Exception {
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeAdBaseFromBidPayload(paramContext, paramString1, paramString2);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public NativeAdLoadConfigBuilder buildLoadAdConfig() {
    return this.mNativeAdBaseApi.buildLoadAdConfig(this);
  }
  
  public void destroy() {
    this.mNativeAdBaseApi.destroy();
  }
  
  @Benchmark
  public void downloadMedia() {
    this.mNativeAdBaseApi.downloadMedia();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdBodyText() {
    return this.mNativeAdBaseApi.getAdBodyText();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdCallToAction() {
    return this.mNativeAdBaseApi.getAdCallToAction();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public Image getAdChoicesIcon() {
    return (this.mNativeAdBaseApi.getAdChoicesIcon() == null) ? null : new Image(this.mNativeAdBaseApi.getAdChoicesIcon());
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdChoicesImageUrl() {
    return this.mNativeAdBaseApi.getAdChoicesImageUrl();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdChoicesLinkUrl() {
    return this.mNativeAdBaseApi.getAdChoicesLinkUrl();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdChoicesText() {
    return this.mNativeAdBaseApi.getAdChoicesText();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public Image getAdCoverImage() {
    return (this.mNativeAdBaseApi.getAdCoverImage() == null) ? null : new Image(this.mNativeAdBaseApi.getAdCoverImage());
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdHeadline() {
    return this.mNativeAdBaseApi.getAdHeadline();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public Image getAdIcon() {
    return (this.mNativeAdBaseApi.getAdIcon() == null) ? null : new Image(this.mNativeAdBaseApi.getAdIcon());
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdLinkDescription() {
    return this.mNativeAdBaseApi.getAdLinkDescription();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdSocialContext() {
    return this.mNativeAdBaseApi.getAdSocialContext();
  }
  
  @Deprecated
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public Rating getAdStarRating() {
    return (this.mNativeAdBaseApi.getAdStarRating() == null) ? null : new Rating(this.mNativeAdBaseApi.getAdStarRating());
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdTranslation() {
    return this.mNativeAdBaseApi.getAdTranslation();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdUntrimmedBodyText() {
    return this.mNativeAdBaseApi.getAdUntrimmedBodyText();
  }
  
  @Deprecated
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public NativeAdViewAttributes getAdViewAttributes() {
    return new NativeAdViewAttributes();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getAdvertiserName() {
    return this.mNativeAdBaseApi.getAdvertiserName();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public float getAspectRatio() {
    return this.mNativeAdBaseApi.getAspectRatio();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getId() {
    return this.mNativeAdBaseApi.getId();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public NativeAdBaseApi getInternalNativeAd() {
    return this.mNativeAdBaseApi;
  }
  
  public String getPlacementId() {
    return this.mNativeAdBaseApi.getPlacementId();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public Drawable getPreloadedIconViewDrawable() {
    return this.mNativeAdBaseApi.getPreloadedIconViewDrawable();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getPromotedTranslation() {
    return this.mNativeAdBaseApi.getPromotedTranslation();
  }
  
  @Nullable
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public String getSponsoredTranslation() {
    return this.mNativeAdBaseApi.getSponsoredTranslation();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean hasCallToAction() {
    return this.mNativeAdBaseApi.hasCallToAction();
  }
  
  public boolean isAdInvalidated() {
    return this.mNativeAdBaseApi.isAdInvalidated();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean isAdLoaded() {
    return this.mNativeAdBaseApi.isAdLoaded();
  }
  
  @Deprecated
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean isNativeConfigEnabled() {
    return false;
  }
  
  public void loadAd() {
    this.mNativeAdBaseApi.loadAd();
  }
  
  @Benchmark
  public void loadAd(NativeLoadAdConfig paramNativeLoadAdConfig) {
    this.mNativeAdBaseApi.loadAd(paramNativeLoadAdConfig);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public void onCtaBroadcast() {
    this.mNativeAdBaseApi.onCtaBroadcast();
  }
  
  @Deprecated
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mNativeAdBaseApi.setExtraHints(paramExtraHints);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public void setOnTouchListener(View.OnTouchListener paramOnTouchListener) {
    this.mNativeAdBaseApi.setOnTouchListener(paramOnTouchListener);
  }
  
  @Benchmark
  public void unregisterView() {
    this.mNativeAdBaseApi.unregisterView();
  }
  
  @Keep
  public static class Image {
    private final NativeAdImageApi mNativeAdImageApi;
    
    @Benchmark
    Image(NativeAdImageApi param1NativeAdImageApi) {
      this.mNativeAdImageApi = param1NativeAdImageApi;
    }
    
    @Nullable
    @Benchmark
    public static Image fromJSONObject(JSONObject param1JSONObject) {
      NativeAdImageApi nativeAdImageApi = DynamicLoaderFactory.makeLoaderUnsafe().createNativeAdImageApi(param1JSONObject);
      return (nativeAdImageApi == null) ? null : new Image(nativeAdImageApi);
    }
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    public int getHeight() {
      return this.mNativeAdImageApi.getHeight();
    }
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    public String getUrl() {
      return this.mNativeAdImageApi.getUrl();
    }
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    public int getWidth() {
      return this.mNativeAdImageApi.getWidth();
    }
  }
  
  @Keep
  public enum MediaCacheFlag {
    ALL, NONE;
    
    static {
      MediaCacheFlag mediaCacheFlag1 = new MediaCacheFlag("NONE", 0);
      NONE = mediaCacheFlag1;
      MediaCacheFlag mediaCacheFlag2 = new MediaCacheFlag("ALL", 1);
      ALL = mediaCacheFlag2;
      $VALUES = new MediaCacheFlag[] { mediaCacheFlag1, mediaCacheFlag2 };
    }
  }
  
  @Keep
  public static interface NativeAdLoadConfigBuilder extends Ad.LoadConfigBuilder {
    public static final int UNKNOWN_IMAGE_SIZE = -1;
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    NativeAdBase.NativeLoadAdConfig build();
    
    NativeAdLoadConfigBuilder withAdListener(NativeAdListener param1NativeAdListener);
    
    NativeAdLoadConfigBuilder withBid(String param1String);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    NativeAdLoadConfigBuilder withMediaCacheFlag(NativeAdBase.MediaCacheFlag param1MediaCacheFlag);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    NativeAdLoadConfigBuilder withPreloadedIconView(int param1Int1, int param1Int2);
  }
  
  @Keep
  public enum NativeComponentTag {
    AD_BODY, AD_CALL_TO_ACTION, AD_CHOICES_ICON, AD_COVER_IMAGE, AD_ICON, AD_MEDIA, AD_OPTIONS_VIEW, AD_SOCIAL_CONTEXT, AD_SUBTITLE, AD_TITLE;
    
    static {
      NativeComponentTag nativeComponentTag1 = new NativeComponentTag("AD_ICON", 0);
      AD_ICON = nativeComponentTag1;
      NativeComponentTag nativeComponentTag2 = new NativeComponentTag("AD_TITLE", 1);
      AD_TITLE = nativeComponentTag2;
      NativeComponentTag nativeComponentTag3 = new NativeComponentTag("AD_COVER_IMAGE", 2);
      AD_COVER_IMAGE = nativeComponentTag3;
      NativeComponentTag nativeComponentTag4 = new NativeComponentTag("AD_SUBTITLE", 3);
      AD_SUBTITLE = nativeComponentTag4;
      NativeComponentTag nativeComponentTag5 = new NativeComponentTag("AD_BODY", 4);
      AD_BODY = nativeComponentTag5;
      NativeComponentTag nativeComponentTag6 = new NativeComponentTag("AD_CALL_TO_ACTION", 5);
      AD_CALL_TO_ACTION = nativeComponentTag6;
      NativeComponentTag nativeComponentTag7 = new NativeComponentTag("AD_SOCIAL_CONTEXT", 6);
      AD_SOCIAL_CONTEXT = nativeComponentTag7;
      NativeComponentTag nativeComponentTag8 = new NativeComponentTag("AD_CHOICES_ICON", 7);
      AD_CHOICES_ICON = nativeComponentTag8;
      NativeComponentTag nativeComponentTag9 = new NativeComponentTag("AD_OPTIONS_VIEW", 8);
      AD_OPTIONS_VIEW = nativeComponentTag9;
      NativeComponentTag nativeComponentTag10 = new NativeComponentTag("AD_MEDIA", 9);
      AD_MEDIA = nativeComponentTag10;
      $VALUES = new NativeComponentTag[] { nativeComponentTag1, nativeComponentTag2, nativeComponentTag3, nativeComponentTag4, nativeComponentTag5, nativeComponentTag6, nativeComponentTag7, nativeComponentTag8, nativeComponentTag9, nativeComponentTag10 };
    }
    
    public static void tagView(View param1View, NativeComponentTag param1NativeComponentTag) {
      DynamicLoaderFactory.makeLoader(param1View.getContext()).createNativeComponentTagApi().tagView(param1View, param1NativeComponentTag);
    }
  }
  
  @Keep
  public static interface NativeLoadAdConfig extends Ad.LoadAdConfig {}
  
  @Keep
  public static class Rating {
    private final NativeAdRatingApi mNativeAdRatingApi;
    
    @Benchmark
    Rating(NativeAdRatingApi param1NativeAdRatingApi) {
      this.mNativeAdRatingApi = param1NativeAdRatingApi;
    }
    
    @Nullable
    @Benchmark
    public static Rating fromJSONObject(JSONObject param1JSONObject) {
      NativeAdRatingApi nativeAdRatingApi = DynamicLoaderFactory.makeLoaderUnsafe().createNativeAdRatingApi(param1JSONObject);
      return (nativeAdRatingApi == null) ? null : new Rating(nativeAdRatingApi);
    }
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    public double getScale() {
      return this.mNativeAdRatingApi.getScale();
    }
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    public double getValue() {
      return this.mNativeAdRatingApi.getValue();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\ads\NativeAdBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */