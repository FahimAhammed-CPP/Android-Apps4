package com.facebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;

public abstract class AccessTokenTracker {
  private static final String TAG = "AccessTokenTracker";
  
  private final LocalBroadcastManager broadcastManager;
  
  private boolean isTracking = false;
  
  private final BroadcastReceiver receiver;
  
  public AccessTokenTracker() {
    Validate.sdkInitialized();
    this.receiver = new b(null);
    this.broadcastManager = LocalBroadcastManager.getInstance(FacebookSdk.getApplicationContext());
    startTracking();
  }
  
  private void addBroadcastReceiver() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
    this.broadcastManager.registerReceiver(this.receiver, intentFilter);
  }
  
  public boolean isTracking() {
    return this.isTracking;
  }
  
  protected abstract void onCurrentAccessTokenChanged(AccessToken paramAccessToken1, AccessToken paramAccessToken2);
  
  public void startTracking() {
    if (this.isTracking)
      return; 
    addBroadcastReceiver();
    this.isTracking = true;
  }
  
  public void stopTracking() {
    if (!this.isTracking)
      return; 
    this.broadcastManager.unregisterReceiver(this.receiver);
    this.isTracking = false;
  }
  
  private class b extends BroadcastReceiver {
    private b(AccessTokenTracker this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if ("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED".equals(param1Intent.getAction())) {
        Utility.logd(AccessTokenTracker.TAG, "AccessTokenChanged");
        AccessToken accessToken1 = (AccessToken)param1Intent.getParcelableExtra("com.facebook.sdk.EXTRA_OLD_ACCESS_TOKEN");
        AccessToken accessToken2 = (AccessToken)param1Intent.getParcelableExtra("com.facebook.sdk.EXTRA_NEW_ACCESS_TOKEN");
        this.a.onCurrentAccessTokenChanged(accessToken1, accessToken2);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\AccessTokenTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */