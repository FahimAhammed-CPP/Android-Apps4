package com.facebook.share;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
    
    public static final int fragment_fast_out_extra_slow_in = 2130771996;
  }
  
  public static final class animator {
    public static final int fragment_close_enter = 2130837507;
    
    public static final int fragment_close_exit = 2130837508;
    
    public static final int fragment_fade_enter = 2130837509;
    
    public static final int fragment_fade_exit = 2130837510;
    
    public static final int fragment_open_enter = 2130837511;
    
    public static final int fragment_open_exit = 2130837512;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130968579;
    
    public static final int actionBarItemBackground = 2130968580;
    
    public static final int actionBarPopupTheme = 2130968581;
    
    public static final int actionBarSize = 2130968582;
    
    public static final int actionBarSplitStyle = 2130968583;
    
    public static final int actionBarStyle = 2130968584;
    
    public static final int actionBarTabBarStyle = 2130968585;
    
    public static final int actionBarTabStyle = 2130968586;
    
    public static final int actionBarTabTextStyle = 2130968587;
    
    public static final int actionBarTheme = 2130968588;
    
    public static final int actionBarWidgetTheme = 2130968589;
    
    public static final int actionButtonStyle = 2130968590;
    
    public static final int actionDropDownStyle = 2130968591;
    
    public static final int actionLayout = 2130968592;
    
    public static final int actionMenuTextAppearance = 2130968593;
    
    public static final int actionMenuTextColor = 2130968594;
    
    public static final int actionModeBackground = 2130968595;
    
    public static final int actionModeCloseButtonStyle = 2130968596;
    
    public static final int actionModeCloseDrawable = 2130968597;
    
    public static final int actionModeCopyDrawable = 2130968598;
    
    public static final int actionModeCutDrawable = 2130968599;
    
    public static final int actionModeFindDrawable = 2130968600;
    
    public static final int actionModePasteDrawable = 2130968601;
    
    public static final int actionModePopupWindowStyle = 2130968602;
    
    public static final int actionModeSelectAllDrawable = 2130968603;
    
    public static final int actionModeShareDrawable = 2130968604;
    
    public static final int actionModeSplitBackground = 2130968605;
    
    public static final int actionModeStyle = 2130968606;
    
    public static final int actionModeWebSearchDrawable = 2130968607;
    
    public static final int actionOverflowButtonStyle = 2130968608;
    
    public static final int actionOverflowMenuStyle = 2130968609;
    
    public static final int actionProviderClass = 2130968610;
    
    public static final int actionViewClass = 2130968611;
    
    public static final int activityChooserViewStyle = 2130968613;
    
    public static final int alertDialogButtonGroupStyle = 2130968657;
    
    public static final int alertDialogCenterButtons = 2130968658;
    
    public static final int alertDialogStyle = 2130968659;
    
    public static final int alertDialogTheme = 2130968660;
    
    public static final int allowStacking = 2130968662;
    
    public static final int alpha = 2130968663;
    
    public static final int alphabeticModifiers = 2130968664;
    
    public static final int arrowHeadLength = 2130968671;
    
    public static final int arrowShaftLength = 2130968672;
    
    public static final int autoCompleteTextViewStyle = 2130968675;
    
    public static final int autoSizeMaxTextSize = 2130968676;
    
    public static final int autoSizeMinTextSize = 2130968677;
    
    public static final int autoSizePresetSizes = 2130968678;
    
    public static final int autoSizeStepGranularity = 2130968679;
    
    public static final int autoSizeTextType = 2130968680;
    
    public static final int background = 2130968682;
    
    public static final int backgroundSplit = 2130968683;
    
    public static final int backgroundStacked = 2130968684;
    
    public static final int backgroundTint = 2130968685;
    
    public static final int backgroundTintMode = 2130968686;
    
    public static final int barLength = 2130968687;
    
    public static final int borderlessButtonStyle = 2130968701;
    
    public static final int buttonBarButtonStyle = 2130968716;
    
    public static final int buttonBarNegativeButtonStyle = 2130968717;
    
    public static final int buttonBarNeutralButtonStyle = 2130968718;
    
    public static final int buttonBarPositiveButtonStyle = 2130968719;
    
    public static final int buttonBarStyle = 2130968720;
    
    public static final int buttonCompat = 2130968721;
    
    public static final int buttonGravity = 2130968722;
    
    public static final int buttonIconDimen = 2130968723;
    
    public static final int buttonPanelSideLayout = 2130968724;
    
    public static final int buttonStyle = 2130968726;
    
    public static final int buttonStyleSmall = 2130968727;
    
    public static final int buttonTint = 2130968728;
    
    public static final int buttonTintMode = 2130968729;
    
    public static final int cardBackgroundColor = 2130968730;
    
    public static final int cardCornerRadius = 2130968731;
    
    public static final int cardElevation = 2130968732;
    
    public static final int cardMaxElevation = 2130968733;
    
    public static final int cardPreventCornerOverlap = 2130968734;
    
    public static final int cardUseCompatPadding = 2130968735;
    
    public static final int cardViewStyle = 2130968736;
    
    public static final int checkboxStyle = 2130968748;
    
    public static final int checkedTextViewStyle = 2130968753;
    
    public static final int closeIcon = 2130968782;
    
    public static final int closeItemLayout = 2130968789;
    
    public static final int collapseContentDescription = 2130968790;
    
    public static final int collapseIcon = 2130968791;
    
    public static final int color = 2130968794;
    
    public static final int colorAccent = 2130968795;
    
    public static final int colorBackgroundFloating = 2130968796;
    
    public static final int colorButtonNormal = 2130968797;
    
    public static final int colorControlActivated = 2130968798;
    
    public static final int colorControlHighlight = 2130968799;
    
    public static final int colorControlNormal = 2130968800;
    
    public static final int colorError = 2130968801;
    
    public static final int colorPrimary = 2130968802;
    
    public static final int colorPrimaryDark = 2130968803;
    
    public static final int colorSwitchThumbNormal = 2130968806;
    
    public static final int com_facebook_auxiliary_view_position = 2130968807;
    
    public static final int com_facebook_foreground_color = 2130968809;
    
    public static final int com_facebook_horizontal_alignment = 2130968810;
    
    public static final int com_facebook_object_id = 2130968816;
    
    public static final int com_facebook_object_type = 2130968817;
    
    public static final int com_facebook_style = 2130968819;
    
    public static final int commitIcon = 2130968821;
    
    public static final int contentDescription = 2130968829;
    
    public static final int contentInsetEnd = 2130968830;
    
    public static final int contentInsetEndWithActions = 2130968831;
    
    public static final int contentInsetLeft = 2130968832;
    
    public static final int contentInsetRight = 2130968833;
    
    public static final int contentInsetStart = 2130968834;
    
    public static final int contentInsetStartWithNavigation = 2130968835;
    
    public static final int contentPadding = 2130968836;
    
    public static final int contentPaddingBottom = 2130968837;
    
    public static final int contentPaddingLeft = 2130968838;
    
    public static final int contentPaddingRight = 2130968839;
    
    public static final int contentPaddingTop = 2130968840;
    
    public static final int controlBackground = 2130968844;
    
    public static final int coordinatorLayoutStyle = 2130968845;
    
    public static final int customNavigationLayout = 2130968863;
    
    public static final int defaultQueryHint = 2130968871;
    
    public static final int dialogCornerRadius = 2130968876;
    
    public static final int dialogPreferredPadding = 2130968877;
    
    public static final int dialogTheme = 2130968878;
    
    public static final int displayOptions = 2130968879;
    
    public static final int divider = 2130968880;
    
    public static final int dividerHorizontal = 2130968881;
    
    public static final int dividerPadding = 2130968882;
    
    public static final int dividerVertical = 2130968883;
    
    public static final int drawableBottomCompat = 2130968889;
    
    public static final int drawableEndCompat = 2130968890;
    
    public static final int drawableLeftCompat = 2130968891;
    
    public static final int drawableRightCompat = 2130968892;
    
    public static final int drawableSize = 2130968893;
    
    public static final int drawableStartCompat = 2130968894;
    
    public static final int drawableTint = 2130968895;
    
    public static final int drawableTintMode = 2130968896;
    
    public static final int drawableTopCompat = 2130968897;
    
    public static final int drawerArrowStyle = 2130968898;
    
    public static final int dropDownListViewStyle = 2130968899;
    
    public static final int dropdownListPreferredItemHeight = 2130968900;
    
    public static final int editTextBackground = 2130968902;
    
    public static final int editTextColor = 2130968903;
    
    public static final int editTextStyle = 2130968904;
    
    public static final int elevation = 2130968905;
    
    public static final int expandActivityOverflowButtonDrawable = 2130968910;
    
    public static final int firstBaselineToTopHeight = 2130968933;
    
    public static final int font = 2130968954;
    
    public static final int fontFamily = 2130968955;
    
    public static final int fontProviderAuthority = 2130968956;
    
    public static final int fontProviderCerts = 2130968957;
    
    public static final int fontProviderFetchStrategy = 2130968958;
    
    public static final int fontProviderFetchTimeout = 2130968959;
    
    public static final int fontProviderPackage = 2130968960;
    
    public static final int fontProviderQuery = 2130968961;
    
    public static final int fontStyle = 2130968963;
    
    public static final int fontVariationSettings = 2130968964;
    
    public static final int fontWeight = 2130968965;
    
    public static final int gapBetweenBars = 2130968968;
    
    public static final int goIcon = 2130968969;
    
    public static final int height = 2130968971;
    
    public static final int hideOnContentScroll = 2130968976;
    
    public static final int homeAsUpIndicator = 2130968981;
    
    public static final int homeLayout = 2130968982;
    
    public static final int icon = 2130968986;
    
    public static final int iconTint = 2130968992;
    
    public static final int iconTintMode = 2130968993;
    
    public static final int iconifiedByDefault = 2130968994;
    
    public static final int imageButtonStyle = 2130968999;
    
    public static final int indeterminateProgressStyle = 2130969004;
    
    public static final int initialActivityCount = 2130969006;
    
    public static final int isLightTheme = 2130969009;
    
    public static final int itemPadding = 2130969016;
    
    public static final int keylines = 2130969023;
    
    public static final int lastBaselineToBottomHeight = 2130969026;
    
    public static final int layout = 2130969027;
    
    public static final int layout_anchor = 2130969031;
    
    public static final int layout_anchorGravity = 2130969032;
    
    public static final int layout_behavior = 2130969033;
    
    public static final int layout_dodgeInsetEdges = 2130969082;
    
    public static final int layout_insetEdge = 2130969092;
    
    public static final int layout_keyline = 2130969093;
    
    public static final int lineHeight = 2130969101;
    
    public static final int listChoiceBackgroundIndicator = 2130969103;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130969104;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130969105;
    
    public static final int listDividerAlertDialog = 2130969106;
    
    public static final int listItemLayout = 2130969107;
    
    public static final int listLayout = 2130969108;
    
    public static final int listMenuViewStyle = 2130969109;
    
    public static final int listPopupWindowStyle = 2130969110;
    
    public static final int listPreferredItemHeight = 2130969111;
    
    public static final int listPreferredItemHeightLarge = 2130969112;
    
    public static final int listPreferredItemHeightSmall = 2130969113;
    
    public static final int listPreferredItemPaddingEnd = 2130969114;
    
    public static final int listPreferredItemPaddingLeft = 2130969115;
    
    public static final int listPreferredItemPaddingRight = 2130969116;
    
    public static final int listPreferredItemPaddingStart = 2130969117;
    
    public static final int logo = 2130969119;
    
    public static final int logoDescription = 2130969120;
    
    public static final int maxButtonHeight = 2130969125;
    
    public static final int measureWithLargestChild = 2130969136;
    
    public static final int menu = 2130969137;
    
    public static final int multiChoiceItemLayout = 2130969164;
    
    public static final int navigationContentDescription = 2130969165;
    
    public static final int navigationIcon = 2130969166;
    
    public static final int navigationMode = 2130969167;
    
    public static final int numericModifiers = 2130969172;
    
    public static final int overlapAnchor = 2130969180;
    
    public static final int paddingBottomNoButtons = 2130969182;
    
    public static final int paddingEnd = 2130969183;
    
    public static final int paddingStart = 2130969184;
    
    public static final int paddingTopNoTitle = 2130969185;
    
    public static final int panelBackground = 2130969186;
    
    public static final int panelMenuListTheme = 2130969187;
    
    public static final int panelMenuListWidth = 2130969188;
    
    public static final int popupMenuStyle = 2130969208;
    
    public static final int popupTheme = 2130969209;
    
    public static final int popupWindowStyle = 2130969210;
    
    public static final int preserveIconSpacing = 2130969211;
    
    public static final int progressBarPadding = 2130969214;
    
    public static final int progressBarStyle = 2130969215;
    
    public static final int queryBackground = 2130969219;
    
    public static final int queryHint = 2130969220;
    
    public static final int radioButtonStyle = 2130969222;
    
    public static final int ratingBarStyle = 2130969223;
    
    public static final int ratingBarStyleIndicator = 2130969224;
    
    public static final int ratingBarStyleSmall = 2130969225;
    
    public static final int searchHintIcon = 2130969249;
    
    public static final int searchIcon = 2130969250;
    
    public static final int searchViewStyle = 2130969252;
    
    public static final int seekBarStyle = 2130969260;
    
    public static final int selectableItemBackground = 2130969261;
    
    public static final int selectableItemBackgroundBorderless = 2130969262;
    
    public static final int showAsAction = 2130969267;
    
    public static final int showDividers = 2130969268;
    
    public static final int showText = 2130969271;
    
    public static final int showTitle = 2130969272;
    
    public static final int singleChoiceItemLayout = 2130969286;
    
    public static final int spinBars = 2130969295;
    
    public static final int spinnerDropDownItemStyle = 2130969296;
    
    public static final int spinnerStyle = 2130969297;
    
    public static final int splitTrack = 2130969302;
    
    public static final int srcCompat = 2130969308;
    
    public static final int state_above_anchor = 2130969311;
    
    public static final int statusBarBackground = 2130969316;
    
    public static final int subMenuArrow = 2130969320;
    
    public static final int submitBackground = 2130969321;
    
    public static final int subtitle = 2130969323;
    
    public static final int subtitleTextAppearance = 2130969324;
    
    public static final int subtitleTextColor = 2130969325;
    
    public static final int subtitleTextStyle = 2130969326;
    
    public static final int suggestionRowLayout = 2130969327;
    
    public static final int switchMinWidth = 2130969328;
    
    public static final int switchPadding = 2130969329;
    
    public static final int switchStyle = 2130969330;
    
    public static final int switchTextAppearance = 2130969331;
    
    public static final int textAllCaps = 2130969362;
    
    public static final int textAppearanceLargePopupMenu = 2130969373;
    
    public static final int textAppearanceListItem = 2130969374;
    
    public static final int textAppearanceListItemSecondary = 2130969375;
    
    public static final int textAppearanceListItemSmall = 2130969376;
    
    public static final int textAppearancePopupMenuHeader = 2130969378;
    
    public static final int textAppearanceSearchResultSubtitle = 2130969379;
    
    public static final int textAppearanceSearchResultTitle = 2130969380;
    
    public static final int textAppearanceSmallPopupMenu = 2130969381;
    
    public static final int textColorAlertDialogListItem = 2130969389;
    
    public static final int textColorSearchUrl = 2130969390;
    
    public static final int textLocale = 2130969394;
    
    public static final int theme = 2130969404;
    
    public static final int thickness = 2130969405;
    
    public static final int thumbTextPadding = 2130969406;
    
    public static final int thumbTint = 2130969407;
    
    public static final int thumbTintMode = 2130969408;
    
    public static final int tickMark = 2130969409;
    
    public static final int tickMarkTint = 2130969410;
    
    public static final int tickMarkTintMode = 2130969411;
    
    public static final int tint = 2130969412;
    
    public static final int tintMode = 2130969413;
    
    public static final int title = 2130969414;
    
    public static final int titleMargin = 2130969416;
    
    public static final int titleMarginBottom = 2130969417;
    
    public static final int titleMarginEnd = 2130969418;
    
    public static final int titleMarginStart = 2130969419;
    
    public static final int titleMarginTop = 2130969420;
    
    public static final int titleMargins = 2130969421;
    
    public static final int titleTextAppearance = 2130969422;
    
    public static final int titleTextColor = 2130969423;
    
    public static final int titleTextStyle = 2130969424;
    
    public static final int toolbarNavigationButtonStyle = 2130969427;
    
    public static final int toolbarStyle = 2130969428;
    
    public static final int tooltipForegroundColor = 2130969429;
    
    public static final int tooltipFrameBackground = 2130969430;
    
    public static final int tooltipText = 2130969431;
    
    public static final int track = 2130969435;
    
    public static final int trackTint = 2130969436;
    
    public static final int trackTintMode = 2130969437;
    
    public static final int ttcIndex = 2130969447;
    
    public static final int viewInflaterClass = 2130969453;
    
    public static final int voiceIcon = 2130969459;
    
    public static final int windowActionBar = 2130969467;
    
    public static final int windowActionBarOverlay = 2130969468;
    
    public static final int windowActionModeOverlay = 2130969469;
    
    public static final int windowFixedHeightMajor = 2130969470;
    
    public static final int windowFixedHeightMinor = 2130969471;
    
    public static final int windowFixedWidthMajor = 2130969472;
    
    public static final int windowFixedWidthMinor = 2130969473;
    
    public static final int windowMinWidthMajor = 2130969474;
    
    public static final int windowMinWidthMinor = 2130969475;
    
    public static final int windowNoTitle = 2130969476;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131034113;
    
    public static final int abc_allow_stacked_button_bar = 2131034114;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034115;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131099648;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131099649;
    
    public static final int abc_btn_colored_borderless_text_material = 2131099650;
    
    public static final int abc_btn_colored_text_material = 2131099651;
    
    public static final int abc_color_highlight_material = 2131099652;
    
    public static final int abc_hint_foreground_material_dark = 2131099655;
    
    public static final int abc_hint_foreground_material_light = 2131099656;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131099657;
    
    public static final int abc_primary_text_disable_only_material_light = 2131099658;
    
    public static final int abc_primary_text_material_dark = 2131099659;
    
    public static final int abc_primary_text_material_light = 2131099660;
    
    public static final int abc_search_url_text = 2131099661;
    
    public static final int abc_search_url_text_normal = 2131099662;
    
    public static final int abc_search_url_text_pressed = 2131099663;
    
    public static final int abc_search_url_text_selected = 2131099664;
    
    public static final int abc_secondary_text_material_dark = 2131099665;
    
    public static final int abc_secondary_text_material_light = 2131099666;
    
    public static final int abc_tint_btn_checkable = 2131099667;
    
    public static final int abc_tint_default = 2131099668;
    
    public static final int abc_tint_edittext = 2131099669;
    
    public static final int abc_tint_seek_thumb = 2131099670;
    
    public static final int abc_tint_spinner = 2131099671;
    
    public static final int abc_tint_switch_track = 2131099672;
    
    public static final int accent_material_dark = 2131099673;
    
    public static final int accent_material_light = 2131099674;
    
    public static final int androidx_core_ripple_material_light = 2131099683;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131099684;
    
    public static final int background_floating_material_dark = 2131099709;
    
    public static final int background_floating_material_light = 2131099710;
    
    public static final int background_material_dark = 2131099711;
    
    public static final int background_material_light = 2131099712;
    
    public static final int bright_foreground_disabled_material_dark = 2131099718;
    
    public static final int bright_foreground_disabled_material_light = 2131099719;
    
    public static final int bright_foreground_inverse_material_dark = 2131099720;
    
    public static final int bright_foreground_inverse_material_light = 2131099721;
    
    public static final int bright_foreground_material_dark = 2131099722;
    
    public static final int bright_foreground_material_light = 2131099723;
    
    public static final int browser_actions_bg_grey = 2131099724;
    
    public static final int browser_actions_divider_color = 2131099725;
    
    public static final int browser_actions_text_color = 2131099726;
    
    public static final int browser_actions_title_color = 2131099727;
    
    public static final int button_material_dark = 2131099728;
    
    public static final int button_material_light = 2131099729;
    
    public static final int cardview_dark_background = 2131099730;
    
    public static final int cardview_light_background = 2131099731;
    
    public static final int cardview_shadow_end_color = 2131099732;
    
    public static final int cardview_shadow_start_color = 2131099733;
    
    public static final int com_facebook_blue = 2131099739;
    
    public static final int com_facebook_button_background_color = 2131099740;
    
    public static final int com_facebook_button_background_color_disabled = 2131099741;
    
    public static final int com_facebook_button_background_color_pressed = 2131099742;
    
    public static final int com_facebook_button_send_background_color = 2131099743;
    
    public static final int com_facebook_button_send_background_color_pressed = 2131099744;
    
    public static final int com_facebook_button_text_color = 2131099745;
    
    public static final int com_facebook_device_auth_text = 2131099746;
    
    public static final int com_facebook_likeboxcountview_border_color = 2131099747;
    
    public static final int com_facebook_likeboxcountview_text_color = 2131099748;
    
    public static final int com_facebook_likeview_text_color = 2131099749;
    
    public static final int com_facebook_messenger_blue = 2131099750;
    
    public static final int com_facebook_primary_button_disabled_text_color = 2131099751;
    
    public static final int com_facebook_primary_button_pressed_text_color = 2131099752;
    
    public static final int com_facebook_primary_button_text_color = 2131099753;
    
    public static final int com_facebook_send_button_text_color = 2131099754;
    
    public static final int com_smart_login_code = 2131099755;
    
    public static final int dim_foreground_disabled_material_dark = 2131099780;
    
    public static final int dim_foreground_disabled_material_light = 2131099781;
    
    public static final int dim_foreground_material_dark = 2131099782;
    
    public static final int dim_foreground_material_light = 2131099783;
    
    public static final int error_color_material_dark = 2131099784;
    
    public static final int error_color_material_light = 2131099785;
    
    public static final int foreground_material_dark = 2131099787;
    
    public static final int foreground_material_light = 2131099788;
    
    public static final int highlighted_text_material_dark = 2131099793;
    
    public static final int highlighted_text_material_light = 2131099794;
    
    public static final int material_blue_grey_800 = 2131099816;
    
    public static final int material_blue_grey_900 = 2131099817;
    
    public static final int material_blue_grey_950 = 2131099818;
    
    public static final int material_deep_teal_200 = 2131099819;
    
    public static final int material_deep_teal_500 = 2131099820;
    
    public static final int material_grey_100 = 2131099821;
    
    public static final int material_grey_300 = 2131099822;
    
    public static final int material_grey_50 = 2131099823;
    
    public static final int material_grey_600 = 2131099824;
    
    public static final int material_grey_800 = 2131099825;
    
    public static final int material_grey_850 = 2131099826;
    
    public static final int material_grey_900 = 2131099827;
    
    public static final int notification_action_color_filter = 2131099913;
    
    public static final int notification_icon_bg_color = 2131099914;
    
    public static final int notification_material_background_media_default_color = 2131099915;
    
    public static final int primary_dark_material_dark = 2131099916;
    
    public static final int primary_dark_material_light = 2131099917;
    
    public static final int primary_material_dark = 2131099918;
    
    public static final int primary_material_light = 2131099919;
    
    public static final int primary_text_default_material_dark = 2131099920;
    
    public static final int primary_text_default_material_light = 2131099921;
    
    public static final int primary_text_disabled_material_dark = 2131099922;
    
    public static final int primary_text_disabled_material_light = 2131099923;
    
    public static final int ripple_material_dark = 2131099924;
    
    public static final int ripple_material_light = 2131099925;
    
    public static final int secondary_text_default_material_dark = 2131099926;
    
    public static final int secondary_text_default_material_light = 2131099927;
    
    public static final int secondary_text_disabled_material_dark = 2131099928;
    
    public static final int secondary_text_disabled_material_light = 2131099929;
    
    public static final int switch_thumb_disabled_material_dark = 2131099931;
    
    public static final int switch_thumb_disabled_material_light = 2131099932;
    
    public static final int switch_thumb_material_dark = 2131099933;
    
    public static final int switch_thumb_material_light = 2131099934;
    
    public static final int switch_thumb_normal_material_dark = 2131099935;
    
    public static final int switch_thumb_normal_material_light = 2131099936;
    
    public static final int tooltip_background_dark = 2131099937;
    
    public static final int tooltip_background_light = 2131099938;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131165184;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static final int abc_action_bar_default_height_material = 2131165186;
    
    public static final int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static final int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static final int abc_action_bar_elevation_material = 2131165189;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static final int abc_action_bar_stacked_max_height = 2131165193;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static final int abc_action_button_min_height_material = 2131165197;
    
    public static final int abc_action_button_min_width_material = 2131165198;
    
    public static final int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static final int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static final int abc_alert_dialog_button_dimen = 2131165201;
    
    public static final int abc_button_inset_horizontal_material = 2131165202;
    
    public static final int abc_button_inset_vertical_material = 2131165203;
    
    public static final int abc_button_padding_horizontal_material = 2131165204;
    
    public static final int abc_button_padding_vertical_material = 2131165205;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static final int abc_config_prefDialogWidth = 2131165207;
    
    public static final int abc_control_corner_material = 2131165208;
    
    public static final int abc_control_inset_material = 2131165209;
    
    public static final int abc_control_padding_material = 2131165210;
    
    public static final int abc_dialog_corner_radius_material = 2131165211;
    
    public static final int abc_dialog_fixed_height_major = 2131165212;
    
    public static final int abc_dialog_fixed_height_minor = 2131165213;
    
    public static final int abc_dialog_fixed_width_major = 2131165214;
    
    public static final int abc_dialog_fixed_width_minor = 2131165215;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static final int abc_dialog_min_width_major = 2131165218;
    
    public static final int abc_dialog_min_width_minor = 2131165219;
    
    public static final int abc_dialog_padding_material = 2131165220;
    
    public static final int abc_dialog_padding_top_material = 2131165221;
    
    public static final int abc_dialog_title_divider_material = 2131165222;
    
    public static final int abc_disabled_alpha_material_dark = 2131165223;
    
    public static final int abc_disabled_alpha_material_light = 2131165224;
    
    public static final int abc_dropdownitem_icon_width = 2131165225;
    
    public static final int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static final int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static final int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static final int abc_edit_text_inset_top_material = 2131165230;
    
    public static final int abc_floating_window_z = 2131165231;
    
    public static final int abc_list_item_height_large_material = 2131165232;
    
    public static final int abc_list_item_height_material = 2131165233;
    
    public static final int abc_list_item_height_small_material = 2131165234;
    
    public static final int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static final int abc_panel_menu_list_width = 2131165236;
    
    public static final int abc_progress_bar_height_material = 2131165237;
    
    public static final int abc_search_view_preferred_height = 2131165238;
    
    public static final int abc_search_view_preferred_width = 2131165239;
    
    public static final int abc_seekbar_track_background_height_material = 2131165240;
    
    public static final int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static final int abc_select_dialog_padding_start_material = 2131165242;
    
    public static final int abc_switch_padding = 2131165243;
    
    public static final int abc_text_size_body_1_material = 2131165244;
    
    public static final int abc_text_size_body_2_material = 2131165245;
    
    public static final int abc_text_size_button_material = 2131165246;
    
    public static final int abc_text_size_caption_material = 2131165247;
    
    public static final int abc_text_size_display_1_material = 2131165248;
    
    public static final int abc_text_size_display_2_material = 2131165249;
    
    public static final int abc_text_size_display_3_material = 2131165250;
    
    public static final int abc_text_size_display_4_material = 2131165251;
    
    public static final int abc_text_size_headline_material = 2131165252;
    
    public static final int abc_text_size_large_material = 2131165253;
    
    public static final int abc_text_size_medium_material = 2131165254;
    
    public static final int abc_text_size_menu_header_material = 2131165255;
    
    public static final int abc_text_size_menu_material = 2131165256;
    
    public static final int abc_text_size_small_material = 2131165257;
    
    public static final int abc_text_size_subhead_material = 2131165258;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131165259;
    
    public static final int abc_text_size_title_material = 2131165260;
    
    public static final int abc_text_size_title_material_toolbar = 2131165261;
    
    public static final int browser_actions_context_menu_max_width = 2131165313;
    
    public static final int browser_actions_context_menu_min_padding = 2131165314;
    
    public static final int cardview_compat_inset_shadow = 2131165315;
    
    public static final int cardview_default_elevation = 2131165316;
    
    public static final int cardview_default_radius = 2131165317;
    
    public static final int com_facebook_auth_dialog_corner_radius = 2131165319;
    
    public static final int com_facebook_auth_dialog_corner_radius_oversized = 2131165320;
    
    public static final int com_facebook_button_corner_radius = 2131165321;
    
    public static final int com_facebook_likeboxcountview_border_radius = 2131165323;
    
    public static final int com_facebook_likeboxcountview_border_width = 2131165324;
    
    public static final int com_facebook_likeboxcountview_caret_height = 2131165325;
    
    public static final int com_facebook_likeboxcountview_caret_width = 2131165326;
    
    public static final int com_facebook_likeboxcountview_text_padding = 2131165327;
    
    public static final int com_facebook_likeboxcountview_text_size = 2131165328;
    
    public static final int com_facebook_likeview_edge_padding = 2131165329;
    
    public static final int com_facebook_likeview_internal_padding = 2131165330;
    
    public static final int com_facebook_likeview_text_size = 2131165331;
    
    public static final int compat_button_inset_horizontal_material = 2131165335;
    
    public static final int compat_button_inset_vertical_material = 2131165336;
    
    public static final int compat_button_padding_horizontal_material = 2131165337;
    
    public static final int compat_button_padding_vertical_material = 2131165338;
    
    public static final int compat_control_corner_material = 2131165339;
    
    public static final int compat_notification_large_icon_max_height = 2131165340;
    
    public static final int compat_notification_large_icon_max_width = 2131165341;
    
    public static final int disabled_alpha_material_dark = 2131165387;
    
    public static final int disabled_alpha_material_light = 2131165388;
    
    public static final int highlight_alpha_material_colored = 2131165392;
    
    public static final int highlight_alpha_material_dark = 2131165393;
    
    public static final int highlight_alpha_material_light = 2131165394;
    
    public static final int hint_alpha_material_dark = 2131165395;
    
    public static final int hint_alpha_material_light = 2131165396;
    
    public static final int hint_pressed_alpha_material_dark = 2131165397;
    
    public static final int hint_pressed_alpha_material_light = 2131165398;
    
    public static final int notification_action_icon_size = 2131165522;
    
    public static final int notification_action_text_size = 2131165523;
    
    public static final int notification_big_circle_margin = 2131165524;
    
    public static final int notification_content_margin_start = 2131165525;
    
    public static final int notification_large_icon_height = 2131165526;
    
    public static final int notification_large_icon_width = 2131165527;
    
    public static final int notification_main_column_padding_top = 2131165528;
    
    public static final int notification_media_narrow_margin = 2131165529;
    
    public static final int notification_right_icon_size = 2131165530;
    
    public static final int notification_right_side_padding_top = 2131165531;
    
    public static final int notification_small_icon_background_padding = 2131165532;
    
    public static final int notification_small_icon_size_as_large = 2131165533;
    
    public static final int notification_subtext_size = 2131165534;
    
    public static final int notification_top_pad = 2131165535;
    
    public static final int notification_top_pad_large_text = 2131165536;
    
    public static final int tooltip_corner_radius = 2131165540;
    
    public static final int tooltip_horizontal_padding = 2131165541;
    
    public static final int tooltip_margin = 2131165542;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131165543;
    
    public static final int tooltip_precise_anchor_threshold = 2131165544;
    
    public static final int tooltip_vertical_padding = 2131165545;
    
    public static final int tooltip_y_offset_non_touch = 2131165546;
    
    public static final int tooltip_y_offset_touch = 2131165547;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131230736;
    
    public static final int abc_action_bar_item_background_material = 2131230737;
    
    public static final int abc_btn_borderless_material = 2131230738;
    
    public static final int abc_btn_check_material = 2131230739;
    
    public static final int abc_btn_check_material_anim = 2131230740;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131230741;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131230742;
    
    public static final int abc_btn_colored_material = 2131230743;
    
    public static final int abc_btn_default_mtrl_shape = 2131230744;
    
    public static final int abc_btn_radio_material = 2131230745;
    
    public static final int abc_btn_radio_material_anim = 2131230746;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131230747;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131230748;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131230749;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131230750;
    
    public static final int abc_cab_background_internal_bg = 2131230751;
    
    public static final int abc_cab_background_top_material = 2131230752;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131230753;
    
    public static final int abc_control_background_material = 2131230754;
    
    public static final int abc_dialog_material_background = 2131230755;
    
    public static final int abc_edit_text_material = 2131230756;
    
    public static final int abc_ic_ab_back_material = 2131230757;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131230758;
    
    public static final int abc_ic_clear_material = 2131230759;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131230760;
    
    public static final int abc_ic_go_search_api_material = 2131230761;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131230762;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131230763;
    
    public static final int abc_ic_menu_overflow_material = 2131230764;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131230765;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131230766;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131230767;
    
    public static final int abc_ic_search_api_material = 2131230768;
    
    public static final int abc_ic_star_black_16dp = 2131230769;
    
    public static final int abc_ic_star_black_36dp = 2131230770;
    
    public static final int abc_ic_star_black_48dp = 2131230771;
    
    public static final int abc_ic_star_half_black_16dp = 2131230772;
    
    public static final int abc_ic_star_half_black_36dp = 2131230773;
    
    public static final int abc_ic_star_half_black_48dp = 2131230774;
    
    public static final int abc_ic_voice_search_api_material = 2131230775;
    
    public static final int abc_item_background_holo_dark = 2131230776;
    
    public static final int abc_item_background_holo_light = 2131230777;
    
    public static final int abc_list_divider_material = 2131230778;
    
    public static final int abc_list_divider_mtrl_alpha = 2131230779;
    
    public static final int abc_list_focused_holo = 2131230780;
    
    public static final int abc_list_longpressed_holo = 2131230781;
    
    public static final int abc_list_pressed_holo_dark = 2131230782;
    
    public static final int abc_list_pressed_holo_light = 2131230783;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131230784;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131230785;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131230786;
    
    public static final int abc_list_selector_disabled_holo_light = 2131230787;
    
    public static final int abc_list_selector_holo_dark = 2131230788;
    
    public static final int abc_list_selector_holo_light = 2131230789;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131230790;
    
    public static final int abc_popup_background_mtrl_mult = 2131230791;
    
    public static final int abc_ratingbar_indicator_material = 2131230792;
    
    public static final int abc_ratingbar_material = 2131230793;
    
    public static final int abc_ratingbar_small_material = 2131230794;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131230795;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131230796;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131230797;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131230798;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131230799;
    
    public static final int abc_seekbar_thumb_material = 2131230800;
    
    public static final int abc_seekbar_tick_mark_material = 2131230801;
    
    public static final int abc_seekbar_track_material = 2131230802;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131230803;
    
    public static final int abc_spinner_textfield_background_material = 2131230804;
    
    public static final int abc_switch_thumb_material = 2131230805;
    
    public static final int abc_switch_track_mtrl_alpha = 2131230806;
    
    public static final int abc_tab_indicator_material = 2131230807;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131230808;
    
    public static final int abc_text_cursor_material = 2131230809;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131230810;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131230811;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131230812;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131230813;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131230814;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131230815;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131230816;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131230817;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131230818;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131230819;
    
    public static final int abc_textfield_search_material = 2131230820;
    
    public static final int abc_vector_test = 2131230821;
    
    public static final int btn_checkbox_checked_mtrl = 2131230972;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131230973;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131230974;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131230975;
    
    public static final int btn_radio_off_mtrl = 2131230976;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131230977;
    
    public static final int btn_radio_on_mtrl = 2131230978;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131230979;
    
    public static final int com_facebook_auth_dialog_background = 2131231014;
    
    public static final int com_facebook_auth_dialog_cancel_background = 2131231015;
    
    public static final int com_facebook_auth_dialog_header_background = 2131231016;
    
    public static final int com_facebook_button_background = 2131231017;
    
    public static final int com_facebook_button_icon = 2131231018;
    
    public static final int com_facebook_button_like_background = 2131231019;
    
    public static final int com_facebook_button_like_icon_selected = 2131231020;
    
    public static final int com_facebook_button_send_background = 2131231021;
    
    public static final int com_facebook_button_send_icon_blue = 2131231022;
    
    public static final int com_facebook_button_send_icon_white = 2131231023;
    
    public static final int com_facebook_close = 2131231024;
    
    public static final int com_facebook_favicon_blue = 2131231025;
    
    public static final int com_facebook_send_button_icon = 2131231028;
    
    public static final int notification_action_background = 2131231420;
    
    public static final int notification_bg = 2131231421;
    
    public static final int notification_bg_low = 2131231422;
    
    public static final int notification_bg_low_normal = 2131231423;
    
    public static final int notification_bg_low_pressed = 2131231424;
    
    public static final int notification_bg_normal = 2131231425;
    
    public static final int notification_bg_normal_pressed = 2131231426;
    
    public static final int notification_icon_background = 2131231427;
    
    public static final int notification_template_icon_bg = 2131231428;
    
    public static final int notification_template_icon_low_bg = 2131231429;
    
    public static final int notification_tile_bg = 2131231430;
    
    public static final int notify_panel_notification_icon_bg = 2131231431;
    
    public static final int tooltip_frame_dark = 2131231449;
    
    public static final int tooltip_frame_light = 2131231450;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131361812;
    
    public static final int accessibility_custom_action_0 = 2131361813;
    
    public static final int accessibility_custom_action_1 = 2131361814;
    
    public static final int accessibility_custom_action_10 = 2131361815;
    
    public static final int accessibility_custom_action_11 = 2131361816;
    
    public static final int accessibility_custom_action_12 = 2131361817;
    
    public static final int accessibility_custom_action_13 = 2131361818;
    
    public static final int accessibility_custom_action_14 = 2131361819;
    
    public static final int accessibility_custom_action_15 = 2131361820;
    
    public static final int accessibility_custom_action_16 = 2131361821;
    
    public static final int accessibility_custom_action_17 = 2131361822;
    
    public static final int accessibility_custom_action_18 = 2131361823;
    
    public static final int accessibility_custom_action_19 = 2131361824;
    
    public static final int accessibility_custom_action_2 = 2131361825;
    
    public static final int accessibility_custom_action_20 = 2131361826;
    
    public static final int accessibility_custom_action_21 = 2131361827;
    
    public static final int accessibility_custom_action_22 = 2131361828;
    
    public static final int accessibility_custom_action_23 = 2131361829;
    
    public static final int accessibility_custom_action_24 = 2131361830;
    
    public static final int accessibility_custom_action_25 = 2131361831;
    
    public static final int accessibility_custom_action_26 = 2131361832;
    
    public static final int accessibility_custom_action_27 = 2131361833;
    
    public static final int accessibility_custom_action_28 = 2131361834;
    
    public static final int accessibility_custom_action_29 = 2131361835;
    
    public static final int accessibility_custom_action_3 = 2131361836;
    
    public static final int accessibility_custom_action_30 = 2131361837;
    
    public static final int accessibility_custom_action_31 = 2131361838;
    
    public static final int accessibility_custom_action_4 = 2131361839;
    
    public static final int accessibility_custom_action_5 = 2131361840;
    
    public static final int accessibility_custom_action_6 = 2131361841;
    
    public static final int accessibility_custom_action_7 = 2131361842;
    
    public static final int accessibility_custom_action_8 = 2131361843;
    
    public static final int accessibility_custom_action_9 = 2131361844;
    
    public static final int action0 = 2131361845;
    
    public static final int action_bar = 2131361849;
    
    public static final int action_bar_activity_content = 2131361850;
    
    public static final int action_bar_container = 2131361851;
    
    public static final int action_bar_root = 2131361852;
    
    public static final int action_bar_spinner = 2131361853;
    
    public static final int action_bar_subtitle = 2131361854;
    
    public static final int action_bar_title = 2131361855;
    
    public static final int action_container = 2131361856;
    
    public static final int action_context_bar = 2131361857;
    
    public static final int action_divider = 2131361858;
    
    public static final int action_image = 2131361859;
    
    public static final int action_menu_divider = 2131361860;
    
    public static final int action_menu_presenter = 2131361861;
    
    public static final int action_mode_bar = 2131361862;
    
    public static final int action_mode_bar_stub = 2131361863;
    
    public static final int action_mode_close_button = 2131361864;
    
    public static final int action_text = 2131361866;
    
    public static final int actions = 2131361867;
    
    public static final int activity_chooser_view_content = 2131361868;
    
    public static final int add = 2131361873;
    
    public static final int alertTitle = 2131361918;
    
    public static final int async = 2131361951;
    
    public static final int blocking = 2131361968;
    
    public static final int bottom = 2131361971;
    
    public static final int box_count = 2131361976;
    
    public static final int browser_actions_header_text = 2131361977;
    
    public static final int browser_actions_menu_item_icon = 2131361978;
    
    public static final int browser_actions_menu_item_text = 2131361979;
    
    public static final int browser_actions_menu_items = 2131361980;
    
    public static final int browser_actions_menu_view = 2131361981;
    
    public static final int button = 2131361983;
    
    public static final int buttonPanel = 2131361984;
    
    public static final int cancel_action = 2131361987;
    
    public static final int cancel_button = 2131361988;
    
    public static final int center = 2131361990;
    
    public static final int checkbox = 2131361995;
    
    public static final int checked = 2131361996;
    
    public static final int chronometer = 2131361997;
    
    public static final int com_facebook_device_auth_instructions = 2131362019;
    
    public static final int com_facebook_fragment_container = 2131362020;
    
    public static final int com_facebook_login_fragment_progress_bar = 2131362021;
    
    public static final int com_facebook_smart_instructions_0 = 2131362022;
    
    public static final int com_facebook_smart_instructions_or = 2131362023;
    
    public static final int confirmation_code = 2131362027;
    
    public static final int content = 2131362032;
    
    public static final int contentPanel = 2131362033;
    
    public static final int custom = 2131362042;
    
    public static final int customPanel = 2131362043;
    
    public static final int decor_content_parent = 2131362048;
    
    public static final int default_activity_button = 2131362049;
    
    public static final int dialog_button = 2131362060;
    
    public static final int edit_query = 2131362081;
    
    public static final int end = 2131362084;
    
    public static final int end_padder = 2131362086;
    
    public static final int expand_activities_button = 2131362097;
    
    public static final int expanded_menu = 2131362098;
    
    public static final int forever = 2131362108;
    
    public static final int fragment_container_view_tag = 2131362109;
    
    public static final int group_divider = 2131362122;
    
    public static final int home = 2131362134;
    
    public static final int icon = 2131362229;
    
    public static final int icon_group = 2131362230;
    
    public static final int image = 2131362236;
    
    public static final int info = 2131362242;
    
    public static final int inline = 2131362243;
    
    public static final int italic = 2131362267;
    
    public static final int left = 2131362279;
    
    public static final int line1 = 2131362284;
    
    public static final int line3 = 2131362285;
    
    public static final int listMode = 2131362292;
    
    public static final int list_item = 2131362294;
    
    public static final int media_actions = 2131362461;
    
    public static final int message = 2131362463;
    
    public static final int multiply = 2131362479;
    
    public static final int none = 2131362490;
    
    public static final int normal = 2131362491;
    
    public static final int notification_background = 2131362496;
    
    public static final int notification_main_column = 2131362497;
    
    public static final int notification_main_column_container = 2131362498;
    
    public static final int off = 2131362499;
    
    public static final int on = 2131362503;
    
    public static final int open_graph = 2131362506;
    
    public static final int page = 2131362510;
    
    public static final int parentPanel = 2131362514;
    
    public static final int progress_bar = 2131362531;
    
    public static final int progress_circular = 2131362532;
    
    public static final int progress_horizontal = 2131362534;
    
    public static final int radio = 2131362537;
    
    public static final int right = 2131362547;
    
    public static final int right_icon = 2131362548;
    
    public static final int right_side = 2131362549;
    
    public static final int screen = 2131362556;
    
    public static final int scrollIndicatorDown = 2131362558;
    
    public static final int scrollIndicatorUp = 2131362559;
    
    public static final int scrollView = 2131362560;
    
    public static final int search_badge = 2131362563;
    
    public static final int search_bar = 2131362564;
    
    public static final int search_button = 2131362565;
    
    public static final int search_close_btn = 2131362566;
    
    public static final int search_edit_frame = 2131362567;
    
    public static final int search_go_btn = 2131362568;
    
    public static final int search_mag_icon = 2131362569;
    
    public static final int search_plate = 2131362570;
    
    public static final int search_src_text = 2131362571;
    
    public static final int search_voice_btn = 2131362572;
    
    public static final int select_dialog_listview = 2131362573;
    
    public static final int shortcut = 2131362577;
    
    public static final int spacer = 2131362595;
    
    public static final int special_effects_controller_view_tag = 2131362596;
    
    public static final int split_action_bar = 2131362600;
    
    public static final int src_atop = 2131362605;
    
    public static final int src_in = 2131362606;
    
    public static final int src_over = 2131362607;
    
    public static final int standard = 2131362608;
    
    public static final int start = 2131362609;
    
    public static final int status_bar_latest_event_content = 2131362616;
    
    public static final int submenuarrow = 2131362621;
    
    public static final int submit_area = 2131362622;
    
    public static final int tabMode = 2131362625;
    
    public static final int tag_accessibility_actions = 2131362627;
    
    public static final int tag_accessibility_clickable_spans = 2131362628;
    
    public static final int tag_accessibility_heading = 2131362629;
    
    public static final int tag_accessibility_pane_title = 2131362630;
    
    public static final int tag_screen_reader_focusable = 2131362634;
    
    public static final int tag_transition_group = 2131362636;
    
    public static final int tag_unhandled_key_event_manager = 2131362637;
    
    public static final int tag_unhandled_key_listeners = 2131362638;
    
    public static final int text = 2131362640;
    
    public static final int text2 = 2131362642;
    
    public static final int textSpacerNoButtons = 2131362643;
    
    public static final int textSpacerNoTitle = 2131362644;
    
    public static final int time = 2131362655;
    
    public static final int title = 2131362657;
    
    public static final int titleDividerNoCustom = 2131362658;
    
    public static final int title_template = 2131362659;
    
    public static final int top = 2131362662;
    
    public static final int topPanel = 2131362663;
    
    public static final int unchecked = 2131362674;
    
    public static final int uniform = 2131362676;
    
    public static final int unknown = 2131362677;
    
    public static final int up = 2131362679;
    
    public static final int view_tree_lifecycle_owner = 2131362689;
    
    public static final int view_tree_saved_state_registry_owner = 2131362690;
    
    public static final int view_tree_view_model_store_owner = 2131362691;
    
    public static final int visible_removing_fragment_view_tag = 2131362693;
    
    public static final int wrap_content = 2131362703;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131427329;
    
    public static final int abc_config_activityShortDur = 2131427330;
    
    public static final int cancel_button_image_alpha = 2131427336;
    
    public static final int config_tooltipAnimTime = 2131427341;
    
    public static final int status_bar_notification_info_maxnum = 2131427357;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131492864;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131492865;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131492866;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131492867;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131492868;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131492869;
    
    public static final int fast_out_slow_in = 2131492870;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131558400;
    
    public static final int abc_action_bar_up_container = 2131558401;
    
    public static final int abc_action_menu_item_layout = 2131558402;
    
    public static final int abc_action_menu_layout = 2131558403;
    
    public static final int abc_action_mode_bar = 2131558404;
    
    public static final int abc_action_mode_close_item_material = 2131558405;
    
    public static final int abc_activity_chooser_view = 2131558406;
    
    public static final int abc_activity_chooser_view_list_item = 2131558407;
    
    public static final int abc_alert_dialog_button_bar_material = 2131558408;
    
    public static final int abc_alert_dialog_material = 2131558409;
    
    public static final int abc_alert_dialog_title_material = 2131558410;
    
    public static final int abc_cascading_menu_item_layout = 2131558411;
    
    public static final int abc_dialog_title_material = 2131558412;
    
    public static final int abc_expanded_menu_layout = 2131558413;
    
    public static final int abc_list_menu_item_checkbox = 2131558414;
    
    public static final int abc_list_menu_item_icon = 2131558415;
    
    public static final int abc_list_menu_item_layout = 2131558416;
    
    public static final int abc_list_menu_item_radio = 2131558417;
    
    public static final int abc_popup_menu_header_item_layout = 2131558418;
    
    public static final int abc_popup_menu_item_layout = 2131558419;
    
    public static final int abc_screen_content_include = 2131558420;
    
    public static final int abc_screen_simple = 2131558421;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131558422;
    
    public static final int abc_screen_toolbar = 2131558423;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131558424;
    
    public static final int abc_search_view = 2131558425;
    
    public static final int abc_select_dialog_material = 2131558426;
    
    public static final int abc_tooltip = 2131558427;
    
    public static final int browser_actions_context_menu_page = 2131558447;
    
    public static final int browser_actions_context_menu_row = 2131558448;
    
    public static final int com_facebook_activity_layout = 2131558450;
    
    public static final int com_facebook_device_auth_dialog_fragment = 2131558451;
    
    public static final int com_facebook_login_fragment = 2131558452;
    
    public static final int com_facebook_smart_device_dialog_fragment = 2131558453;
    
    public static final int custom_dialog = 2131558458;
    
    public static final int notification_action = 2131558581;
    
    public static final int notification_action_tombstone = 2131558582;
    
    public static final int notification_media_action = 2131558583;
    
    public static final int notification_media_cancel_action = 2131558584;
    
    public static final int notification_template_big_media = 2131558585;
    
    public static final int notification_template_big_media_custom = 2131558586;
    
    public static final int notification_template_big_media_narrow = 2131558587;
    
    public static final int notification_template_big_media_narrow_custom = 2131558588;
    
    public static final int notification_template_custom_big = 2131558589;
    
    public static final int notification_template_icon_group = 2131558590;
    
    public static final int notification_template_lines_media = 2131558591;
    
    public static final int notification_template_media = 2131558592;
    
    public static final int notification_template_media_custom = 2131558593;
    
    public static final int notification_template_part_chronometer = 2131558594;
    
    public static final int notification_template_part_time = 2131558595;
    
    public static final int select_dialog_item_material = 2131558600;
    
    public static final int select_dialog_multichoice_material = 2131558601;
    
    public static final int select_dialog_singlechoice_material = 2131558602;
    
    public static final int support_simple_spinner_dropdown_item = 2131558604;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131886080;
    
    public static final int abc_action_bar_up_description = 2131886081;
    
    public static final int abc_action_menu_overflow_description = 2131886082;
    
    public static final int abc_action_mode_done = 2131886083;
    
    public static final int abc_activity_chooser_view_see_all = 2131886084;
    
    public static final int abc_activitychooserview_choose_application = 2131886085;
    
    public static final int abc_capital_off = 2131886086;
    
    public static final int abc_capital_on = 2131886087;
    
    public static final int abc_menu_alt_shortcut_label = 2131886088;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131886089;
    
    public static final int abc_menu_delete_shortcut_label = 2131886090;
    
    public static final int abc_menu_enter_shortcut_label = 2131886091;
    
    public static final int abc_menu_function_shortcut_label = 2131886092;
    
    public static final int abc_menu_meta_shortcut_label = 2131886093;
    
    public static final int abc_menu_shift_shortcut_label = 2131886094;
    
    public static final int abc_menu_space_shortcut_label = 2131886095;
    
    public static final int abc_menu_sym_shortcut_label = 2131886096;
    
    public static final int abc_prepend_shortcut_label = 2131886097;
    
    public static final int abc_search_hint = 2131886098;
    
    public static final int abc_searchview_description_clear = 2131886099;
    
    public static final int abc_searchview_description_query = 2131886100;
    
    public static final int abc_searchview_description_search = 2131886101;
    
    public static final int abc_searchview_description_submit = 2131886102;
    
    public static final int abc_searchview_description_voice = 2131886103;
    
    public static final int abc_shareactionprovider_share_with = 2131886104;
    
    public static final int abc_shareactionprovider_share_with_application = 2131886105;
    
    public static final int abc_toolbar_collapse_description = 2131886106;
    
    public static final int com_facebook_device_auth_instructions = 2131886214;
    
    public static final int com_facebook_image_download_unknown_error = 2131886215;
    
    public static final int com_facebook_internet_permission_error_message = 2131886216;
    
    public static final int com_facebook_internet_permission_error_title = 2131886217;
    
    public static final int com_facebook_like_button_liked = 2131886218;
    
    public static final int com_facebook_like_button_not_liked = 2131886219;
    
    public static final int com_facebook_loading = 2131886220;
    
    public static final int com_facebook_loginview_cancel_action = 2131886221;
    
    public static final int com_facebook_loginview_log_in_button = 2131886222;
    
    public static final int com_facebook_loginview_log_in_button_continue = 2131886223;
    
    public static final int com_facebook_loginview_log_in_button_long = 2131886224;
    
    public static final int com_facebook_loginview_log_out_action = 2131886225;
    
    public static final int com_facebook_loginview_log_out_button = 2131886226;
    
    public static final int com_facebook_loginview_logged_in_as = 2131886227;
    
    public static final int com_facebook_loginview_logged_in_using_facebook = 2131886228;
    
    public static final int com_facebook_send_button_text = 2131886229;
    
    public static final int com_facebook_share_button_text = 2131886230;
    
    public static final int com_facebook_smart_device_instructions = 2131886231;
    
    public static final int com_facebook_smart_device_instructions_or = 2131886232;
    
    public static final int com_facebook_smart_login_confirmation_cancel = 2131886233;
    
    public static final int com_facebook_smart_login_confirmation_continue_as = 2131886234;
    
    public static final int com_facebook_smart_login_confirmation_title = 2131886235;
    
    public static final int com_facebook_tooltip_default = 2131886236;
    
    public static final int search_menu_title = 2131886538;
    
    public static final int status_bar_notification_info_overflow = 2131886553;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131951617;
    
    public static final int AlertDialog_AppCompat_Light = 2131951618;
    
    public static final int Animation_AppCompat_Dialog = 2131951619;
    
    public static final int Animation_AppCompat_DropDownUp = 2131951620;
    
    public static final int Animation_AppCompat_Tooltip = 2131951621;
    
    public static final int Base_AlertDialog_AppCompat = 2131951658;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131951659;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131951660;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131951661;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131951662;
    
    public static final int Base_CardView = 2131951663;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131951665;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131951664;
    
    public static final int Base_TextAppearance_AppCompat = 2131951666;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131951667;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131951668;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131951669;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131951670;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131951671;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131951672;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131951673;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131951674;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131951675;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131951676;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131951677;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131951678;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131951679;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131951680;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131951681;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131951682;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131951683;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131951684;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131951685;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131951686;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131951687;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131951688;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131951689;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131951690;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131951691;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131951692;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131951693;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131951694;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131951695;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131951696;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131951697;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131951698;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131951699;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131951700;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131951701;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131951702;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131951703;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131951704;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131951705;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131951706;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131951707;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131951708;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131951709;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131951710;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131951711;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131951712;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131951713;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131951745;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131951746;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131951747;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131951748;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131951749;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131951750;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131951751;
    
    public static final int Base_Theme_AppCompat = 2131951714;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131951715;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131951716;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131951720;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131951717;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131951718;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131951719;
    
    public static final int Base_Theme_AppCompat_Light = 2131951721;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131951722;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131951723;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131951727;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131951724;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131951725;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131951726;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131951767;
    
    public static final int Base_V21_Theme_AppCompat = 2131951763;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131951764;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131951765;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131951766;
    
    public static final int Base_V22_Theme_AppCompat = 2131951768;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131951769;
    
    public static final int Base_V23_Theme_AppCompat = 2131951770;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131951771;
    
    public static final int Base_V26_Theme_AppCompat = 2131951772;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131951773;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131951774;
    
    public static final int Base_V28_Theme_AppCompat = 2131951775;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131951776;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131951781;
    
    public static final int Base_V7_Theme_AppCompat = 2131951777;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131951778;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131951779;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131951780;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131951782;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131951783;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131951784;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131951785;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131951786;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131951787;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131951788;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131951789;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131951790;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131951791;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131951792;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131951793;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131951794;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131951795;
    
    public static final int Base_Widget_AppCompat_Button = 2131951796;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131951802;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131951803;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131951797;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131951798;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131951799;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131951800;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131951801;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131951804;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131951805;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131951806;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131951807;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131951808;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131951809;
    
    public static final int Base_Widget_AppCompat_EditText = 2131951810;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131951811;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131951812;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131951813;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131951814;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131951815;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131951816;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131951817;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131951818;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131951819;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131951820;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131951821;
    
    public static final int Base_Widget_AppCompat_ListView = 2131951822;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131951823;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131951824;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131951825;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131951826;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131951827;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131951828;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131951829;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131951830;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131951831;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131951832;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131951833;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131951834;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131951835;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131951836;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131951837;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131951838;
    
    public static final int Base_Widget_AppCompat_TextView = 2131951839;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131951840;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131951841;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131951842;
    
    public static final int CardView = 2131951847;
    
    public static final int CardView_Dark = 2131951848;
    
    public static final int CardView_Light = 2131951849;
    
    public static final int Platform_AppCompat = 2131951870;
    
    public static final int Platform_AppCompat_Light = 2131951871;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131951876;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131951877;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131951878;
    
    public static final int Platform_V21_AppCompat = 2131951879;
    
    public static final int Platform_V21_AppCompat_Light = 2131951880;
    
    public static final int Platform_V25_AppCompat = 2131951881;
    
    public static final int Platform_V25_AppCompat_Light = 2131951882;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131951883;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131951885;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131951886;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131951887;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131951888;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131951889;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131951890;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131951891;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131951892;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131951893;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131951899;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131951894;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131951895;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131951896;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131951897;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131951898;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131951900;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131951901;
    
    public static final int TextAppearance_AppCompat = 2131951905;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131951906;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131951907;
    
    public static final int TextAppearance_AppCompat_Button = 2131951908;
    
    public static final int TextAppearance_AppCompat_Caption = 2131951909;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131951910;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131951911;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131951912;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131951913;
    
    public static final int TextAppearance_AppCompat_Headline = 2131951914;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131951915;
    
    public static final int TextAppearance_AppCompat_Large = 2131951916;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131951917;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131951918;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131951919;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131951920;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131951921;
    
    public static final int TextAppearance_AppCompat_Medium = 2131951922;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131951923;
    
    public static final int TextAppearance_AppCompat_Menu = 2131951924;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131951925;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131951926;
    
    public static final int TextAppearance_AppCompat_Small = 2131951927;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131951928;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131951929;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131951930;
    
    public static final int TextAppearance_AppCompat_Title = 2131951931;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131951932;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131951933;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131951934;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131951935;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131951936;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131951937;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131951938;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131951939;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131951940;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131951941;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131951942;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131951943;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131951944;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131951945;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131951946;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131951947;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131951948;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131951949;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131951950;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131951951;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131951952;
    
    public static final int TextAppearance_Compat_Notification = 2131951953;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131951954;
    
    public static final int TextAppearance_Compat_Notification_Info_Media = 2131951955;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131951956;
    
    public static final int TextAppearance_Compat_Notification_Line2_Media = 2131951957;
    
    public static final int TextAppearance_Compat_Notification_Media = 2131951958;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131951959;
    
    public static final int TextAppearance_Compat_Notification_Time_Media = 2131951960;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131951961;
    
    public static final int TextAppearance_Compat_Notification_Title_Media = 2131951962;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131951986;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131951987;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131951988;
    
    public static final int ThemeOverlay_AppCompat = 2131952041;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131952042;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131952043;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131952044;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131952045;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131952046;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131952047;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131952048;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131952049;
    
    public static final int Theme_AppCompat = 2131951989;
    
    public static final int Theme_AppCompat_CompactMenu = 2131951990;
    
    public static final int Theme_AppCompat_DayNight = 2131951991;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131951992;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131951993;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131951996;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131951994;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131951995;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131951997;
    
    public static final int Theme_AppCompat_Dialog = 2131951998;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131952001;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131951999;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131952000;
    
    public static final int Theme_AppCompat_Light = 2131952003;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131952004;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131952005;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131952008;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131952006;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131952007;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131952009;
    
    public static final int Theme_AppCompat_NoActionBar = 2131952011;
    
    public static final int Widget_AppCompat_ActionBar = 2131952062;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131952063;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131952064;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131952065;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131952066;
    
    public static final int Widget_AppCompat_ActionButton = 2131952067;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131952068;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131952069;
    
    public static final int Widget_AppCompat_ActionMode = 2131952070;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131952071;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131952072;
    
    public static final int Widget_AppCompat_Button = 2131952073;
    
    public static final int Widget_AppCompat_ButtonBar = 2131952079;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131952080;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131952074;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131952075;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131952076;
    
    public static final int Widget_AppCompat_Button_Colored = 2131952077;
    
    public static final int Widget_AppCompat_Button_Small = 2131952078;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131952081;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131952082;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131952083;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131952084;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131952085;
    
    public static final int Widget_AppCompat_EditText = 2131952086;
    
    public static final int Widget_AppCompat_ImageButton = 2131952087;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131952088;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131952089;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131952090;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131952091;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131952092;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131952093;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131952094;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131952095;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131952096;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131952097;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131952098;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131952099;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131952100;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131952101;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131952102;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131952103;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131952104;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131952105;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131952106;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131952107;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131952108;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131952109;
    
    public static final int Widget_AppCompat_ListMenuView = 2131952110;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131952111;
    
    public static final int Widget_AppCompat_ListView = 2131952112;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131952113;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131952114;
    
    public static final int Widget_AppCompat_PopupMenu = 2131952115;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131952116;
    
    public static final int Widget_AppCompat_PopupWindow = 2131952117;
    
    public static final int Widget_AppCompat_ProgressBar = 2131952118;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131952119;
    
    public static final int Widget_AppCompat_RatingBar = 2131952120;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131952121;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131952122;
    
    public static final int Widget_AppCompat_SearchView = 2131952123;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131952124;
    
    public static final int Widget_AppCompat_SeekBar = 2131952125;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131952126;
    
    public static final int Widget_AppCompat_Spinner = 2131952127;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131952128;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131952129;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131952130;
    
    public static final int Widget_AppCompat_TextView = 2131952131;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131952132;
    
    public static final int Widget_AppCompat_Toolbar = 2131952133;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131952134;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952135;
    
    public static final int Widget_Compat_NotificationActionText = 2131952136;
    
    public static final int Widget_Support_CoordinatorLayout = 2131952183;
    
    public static final int com_facebook_activity_theme = 2131952212;
    
    public static final int com_facebook_auth_dialog = 2131952213;
    
    public static final int com_facebook_auth_dialog_instructions_textview = 2131952214;
    
    public static final int com_facebook_button = 2131952215;
    
    public static final int com_facebook_button_like = 2131952216;
    
    public static final int com_facebook_button_send = 2131952217;
    
    public static final int com_facebook_button_share = 2131952218;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130968682, 2130968683, 2130968684, 2130968830, 2130968831, 2130968832, 2130968833, 2130968834, 2130968835, 2130968863, 
        2130968879, 2130968880, 2130968905, 2130968971, 2130968976, 2130968981, 2130968982, 2130968986, 2130969004, 2130969016, 
        2130969119, 2130969167, 2130969209, 2130969214, 2130969215, 2130969323, 2130969326, 2130969414, 2130969424 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130968682, 2130968683, 2130968789, 2130968971, 2130969326, 2130969424 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130968910, 2130969006 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130968723, 2130968724, 2130969107, 2130969108, 2130969164, 2130969272, 2130969286 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130969308, 2130969412, 2130969413 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130969409, 2130969410, 2130969411 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130968676, 2130968677, 2130968678, 2130968679, 2130968680, 2130968889, 2130968890, 2130968891, 2130968892, 
        2130968894, 2130968895, 2130968896, 2130968897, 2130968933, 2130968955, 2130968964, 2130969026, 2130969101, 2130969362, 
        2130969394 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 
        2130968587, 2130968588, 2130968589, 2130968590, 2130968591, 2130968593, 2130968594, 2130968595, 2130968596, 2130968597, 
        2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 
        2130968608, 2130968609, 2130968613, 2130968657, 2130968658, 2130968659, 2130968660, 2130968675, 2130968701, 2130968716, 
        2130968717, 2130968718, 2130968719, 2130968720, 2130968726, 2130968727, 2130968748, 2130968753, 2130968795, 2130968796, 
        2130968797, 2130968798, 2130968799, 2130968800, 2130968801, 2130968802, 2130968803, 2130968806, 2130968844, 2130968876, 
        2130968877, 2130968878, 2130968881, 2130968883, 2130968899, 2130968900, 2130968902, 2130968903, 2130968904, 2130968981, 
        2130968999, 2130969103, 2130969104, 2130969105, 2130969106, 2130969109, 2130969110, 2130969111, 2130969112, 2130969113, 
        2130969114, 2130969115, 2130969116, 2130969117, 2130969186, 2130969187, 2130969188, 2130969208, 2130969210, 2130969222, 
        2130969223, 2130969224, 2130969225, 2130969252, 2130969260, 2130969261, 2130969262, 2130969296, 2130969297, 2130969330, 
        2130969373, 2130969374, 2130969375, 2130969376, 2130969378, 2130969379, 2130969380, 2130969381, 2130969389, 2130969390, 
        2130969427, 2130969428, 2130969429, 2130969430, 2130969453, 2130969467, 2130969468, 2130969469, 2130969470, 2130969471, 
        2130969472, 2130969473, 2130969474, 2130969475, 2130969476 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] ButtonBarLayout = new int[] { 2130968662 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130968730, 2130968731, 2130968732, 2130968733, 2130968734, 2130968735, 2130968836, 2130968837, 
        2130968838, 2130968839, 2130968840 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968663, 2130969024 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130968721, 2130968728, 2130968729 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] CoordinatorLayout = new int[] { 2130969023, 2130969316 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130969031, 2130969032, 2130969033, 2130969082, 2130969092, 2130969093 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130968671, 2130968672, 2130968687, 2130968794, 2130968893, 2130968968, 2130969295, 2130969405 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130968956, 2130968957, 2130968958, 2130968959, 2130968960, 2130968961, 2130968962 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968954, 2130968963, 2130968964, 2130968965, 2130969447 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int[] FragmentContainerView = new int[] { 16842755, 16842961 };
    
    public static final int FragmentContainerView_android_name = 0;
    
    public static final int FragmentContainerView_android_tag = 1;
    
    public static final int Fragment_android_id = 1;
    
    public static final int Fragment_android_name = 0;
    
    public static final int Fragment_android_tag = 2;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968880, 2130968882, 2130969136, 2130969268 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968592, 2130968610, 2130968611, 2130968664, 2130968829, 2130968992, 2130968993, 
        2130969172, 2130969267, 2130969431 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969211, 2130969320 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969180 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130969311 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130969182, 2130969185 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130968782, 2130968821, 2130968871, 2130968969, 2130968994, 2130969027, 
        2130969219, 2130969220, 2130969249, 2130969250, 2130969321, 2130969327, 2130969459 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969209 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969271, 2130969302, 2130969328, 2130969329, 2130969331, 2130969406, 2130969407, 
        2130969408, 2130969435, 2130969436, 2130969437 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130968955, 2130968964, 2130969362, 2130969394 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968722, 2130968790, 2130968791, 2130968830, 2130968831, 2130968832, 2130968833, 2130968834, 
        2130968835, 2130969119, 2130969120, 2130969125, 2130969137, 2130969165, 2130969166, 2130969209, 2130969323, 2130969324, 
        2130969325, 2130969414, 2130969416, 2130969417, 2130969418, 2130969419, 2130969420, 2130969421, 2130969422, 2130969423 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130969183, 2130969184, 2130969404 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968685, 2130968686 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
    
    public static final int[] com_facebook_like_view = new int[] { 2130968807, 2130968809, 2130968810, 2130968816, 2130968817, 2130968819 };
    
    public static final int com_facebook_like_view_com_facebook_auxiliary_view_position = 0;
    
    public static final int com_facebook_like_view_com_facebook_foreground_color = 1;
    
    public static final int com_facebook_like_view_com_facebook_horizontal_alignment = 2;
    
    public static final int com_facebook_like_view_com_facebook_object_id = 3;
    
    public static final int com_facebook_like_view_com_facebook_object_type = 4;
    
    public static final int com_facebook_like_view_com_facebook_style = 5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\share\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */