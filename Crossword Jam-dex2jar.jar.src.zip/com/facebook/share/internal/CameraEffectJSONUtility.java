package com.facebook.share.internal;

import com.facebook.share.model.CameraEffectArguments;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.d0.d.m;
import kotlin.n;
import kotlin.t;
import kotlin.y.n0;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\bÆ\002\030\0002\0020\001:\001\016B\007\b\002¢\006\002\020\002J\024\020\b\032\004\030\0010\t2\b\020\n\032\004\030\0010\013H\007J\024\020\f\032\004\030\0010\0132\b\020\r\032\004\030\0010\tH\007R2\020\003\032&\022\b\022\006\022\002\b\0030\005\022\004\022\0020\0060\004j\022\022\b\022\006\022\002\b\0030\005\022\004\022\0020\006`\007X\004¢\006\002\n\000¨\006\017"}, d2 = {"Lcom/facebook/share/internal/CameraEffectJSONUtility;", "", "()V", "SETTERS", "Ljava/util/HashMap;", "Ljava/lang/Class;", "Lcom/facebook/share/internal/CameraEffectJSONUtility$Setter;", "Lkotlin/collections/HashMap;", "convertToCameraEffectArguments", "Lcom/facebook/share/model/CameraEffectArguments;", "jsonObject", "Lorg/json/JSONObject;", "convertToJSON", "arguments", "Setter", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
public final class CameraEffectJSONUtility {
  public static final CameraEffectJSONUtility INSTANCE = new CameraEffectJSONUtility();
  
  private static final HashMap<Class<?>, a> SETTERS = n0.k(new n[] { t.a(String.class, new CameraEffectJSONUtility$SETTERS$1()), t.a(String[].class, new CameraEffectJSONUtility$SETTERS$2()), t.a(JSONArray.class, new CameraEffectJSONUtility$SETTERS$3()) });
  
  public static final CameraEffectArguments convertToCameraEffectArguments(JSONObject paramJSONObject) throws JSONException {
    if (paramJSONObject == null)
      return null; 
    CameraEffectArguments.Builder builder = new CameraEffectArguments.Builder();
    Iterator<String> iterator = paramJSONObject.keys();
    while (iterator.hasNext()) {
      String str = iterator.next();
      Object object = paramJSONObject.get(str);
      if (object == JSONObject.NULL)
        continue; 
      a a = SETTERS.get(object.getClass());
      if (a != null) {
        m.e(a, "SETTERS[value.javaClass]…ype: \" + value.javaClass)");
        m.e(str, "key");
        a.setOnArgumentsBuilder(builder, str, object);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unsupported type: ");
      stringBuilder.append(object.getClass());
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return builder.build();
  }
  
  public static final JSONObject convertToJSON(CameraEffectArguments paramCameraEffectArguments) throws JSONException {
    if (paramCameraEffectArguments == null)
      return null; 
    JSONObject jSONObject = new JSONObject();
    for (String str : paramCameraEffectArguments.keySet()) {
      Object object = paramCameraEffectArguments.get(str);
      if (object != null) {
        m.e(object, "arguments[key] ?: // Nul…orted.\n          continue");
        a a = SETTERS.get(object.getClass());
        if (a != null) {
          m.e(a, "SETTERS[value.javaClass]…ype: \" + value.javaClass)");
          m.e(str, "key");
          a.setOnJSON(jSONObject, str, object);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unsupported type: ");
        stringBuilder.append(object.getClass());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return jSONObject;
  }
  
  @Metadata(d1 = {"\000+\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\"\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026J\"\020\n\032\0020\0032\006\020\013\032\0020\f2\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026¨\006\r"}, d2 = {"com/facebook/share/internal/CameraEffectJSONUtility$SETTERS$1", "Lcom/facebook/share/internal/CameraEffectJSONUtility$Setter;", "setOnArgumentsBuilder", "", "builder", "Lcom/facebook/share/model/CameraEffectArguments$Builder;", "key", "", "value", "", "setOnJSON", "json", "Lorg/json/JSONObject;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class CameraEffectJSONUtility$SETTERS$1 implements a {
    public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
      m.f(param1Builder, "builder");
      m.f(param1String, "key");
      Objects.requireNonNull(param1Object, "null cannot be cast to non-null type kotlin.String");
      param1Builder.putArgument(param1String, (String)param1Object);
    }
    
    public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
      m.f(param1JSONObject, "json");
      m.f(param1String, "key");
      param1JSONObject.put(param1String, param1Object);
    }
  }
  
  @Metadata(d1 = {"\000+\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\"\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026J\"\020\n\032\0020\0032\006\020\013\032\0020\f2\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026¨\006\r"}, d2 = {"com/facebook/share/internal/CameraEffectJSONUtility$SETTERS$2", "Lcom/facebook/share/internal/CameraEffectJSONUtility$Setter;", "setOnArgumentsBuilder", "", "builder", "Lcom/facebook/share/model/CameraEffectArguments$Builder;", "key", "", "value", "", "setOnJSON", "json", "Lorg/json/JSONObject;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class CameraEffectJSONUtility$SETTERS$2 implements a {
    public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
      m.f(param1Builder, "builder");
      m.f(param1String, "key");
      throw new IllegalArgumentException("Unexpected type from JSON");
    }
    
    public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
      m.f(param1JSONObject, "json");
      m.f(param1String, "key");
      JSONArray jSONArray = new JSONArray();
      Objects.requireNonNull(param1Object, "null cannot be cast to non-null type kotlin.Array<kotlin.String?>");
      param1Object = param1Object;
      int j = param1Object.length;
      int i;
      for (i = 0; i < j; i++)
        jSONArray.put(param1Object[i]); 
      param1JSONObject.put(param1String, jSONArray);
    }
  }
  
  @Metadata(d1 = {"\000+\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\"\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026J\"\020\n\032\0020\0032\006\020\013\032\0020\f2\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\tH\026¨\006\r"}, d2 = {"com/facebook/share/internal/CameraEffectJSONUtility$SETTERS$3", "Lcom/facebook/share/internal/CameraEffectJSONUtility$Setter;", "setOnArgumentsBuilder", "", "builder", "Lcom/facebook/share/model/CameraEffectArguments$Builder;", "key", "", "value", "", "setOnJSON", "json", "Lorg/json/JSONObject;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class CameraEffectJSONUtility$SETTERS$3 implements a {
    public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
      StringBuilder stringBuilder;
      m.f(param1Builder, "builder");
      m.f(param1String, "key");
      Objects.requireNonNull(param1Object, "null cannot be cast to non-null type org.json.JSONArray");
      JSONArray jSONArray = (JSONArray)param1Object;
      String[] arrayOfString = new String[jSONArray.length()];
      int i = 0;
      int j = jSONArray.length();
      while (i < j) {
        param1Object = jSONArray.get(i);
        if (param1Object instanceof String) {
          arrayOfString[i] = (String)param1Object;
          i++;
          continue;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected type in an array: ");
        stringBuilder.append(param1Object.getClass());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      stringBuilder.putArgument(param1String, arrayOfString);
    }
    
    public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
      m.f(param1JSONObject, "json");
      m.f(param1String, "key");
      throw new IllegalArgumentException("JSONArray's are not supported in bundles.");
    }
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\000\bb\030\0002\0020\001J\"\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\001H&J\"\020\t\032\0020\0032\006\020\n\032\0020\0132\006\020\006\032\0020\0072\b\020\b\032\004\030\0010\001H&¨\006\f"}, d2 = {"Lcom/facebook/share/internal/CameraEffectJSONUtility$Setter;", "", "setOnArgumentsBuilder", "", "builder", "Lcom/facebook/share/model/CameraEffectArguments$Builder;", "key", "", "value", "setOnJSON", "json", "Lorg/json/JSONObject;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  private static interface a {
    void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException;
    
    void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\share\internal\CameraEffectJSONUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */