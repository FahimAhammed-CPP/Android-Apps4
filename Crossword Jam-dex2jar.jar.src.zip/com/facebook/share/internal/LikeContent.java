package com.facebook.share.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.share.model.ShareModel;
import com.facebook.share.model.ShareModelBuilder;

@Deprecated
public class LikeContent implements ShareModel {
  @Deprecated
  public static final Parcelable.Creator<LikeContent> CREATOR = new a();
  
  private final String objectId;
  
  private final String objectType;
  
  @Deprecated
  LikeContent(Parcel paramParcel) {
    this.objectId = paramParcel.readString();
    this.objectType = paramParcel.readString();
  }
  
  private LikeContent(Builder paramBuilder) {
    this.objectId = paramBuilder.objectId;
    this.objectType = paramBuilder.objectType;
  }
  
  @Deprecated
  public int describeContents() {
    return 0;
  }
  
  @Deprecated
  public String getObjectId() {
    return this.objectId;
  }
  
  @Deprecated
  public String getObjectType() {
    return this.objectType;
  }
  
  @Deprecated
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.objectId);
    paramParcel.writeString(this.objectType);
  }
  
  @Deprecated
  public static class Builder implements ShareModelBuilder<LikeContent, Builder> {
    private String objectId;
    
    private String objectType;
    
    @Deprecated
    public LikeContent build() {
      return new LikeContent(this, null);
    }
    
    @Deprecated
    public Builder readFrom(LikeContent param1LikeContent) {
      return (param1LikeContent == null) ? this : setObjectId(param1LikeContent.getObjectId()).setObjectType(param1LikeContent.getObjectType());
    }
    
    @Deprecated
    public Builder setObjectId(String param1String) {
      this.objectId = param1String;
      return this;
    }
    
    @Deprecated
    public Builder setObjectType(String param1String) {
      this.objectType = param1String;
      return this;
    }
  }
  
  static final class a implements Parcelable.Creator<LikeContent> {
    public LikeContent a(Parcel param1Parcel) {
      return new LikeContent(param1Parcel);
    }
    
    public LikeContent[] b(int param1Int) {
      return new LikeContent[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\share\internal\LikeContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */