package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.m;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\000\n\002\020\002\n\002\b\005\030\000 \0362\016\022\004\022\0020\000\022\004\022\0020\0020\0012\0020\003:\002\035\036B\017\b\022\022\006\020\004\032\0020\002¢\006\002\020\005B\017\b\020\022\006\020\006\032\0020\007¢\006\002\020\bJ\b\020\027\032\0020\030H\026J\030\020\031\032\0020\0322\006\020\033\032\0020\0072\006\020\034\032\0020\030H\026R\023\020\t\032\004\030\0010\n¢\006\b\n\000\032\004\b\013\020\fR\023\020\r\032\004\030\0010\n¢\006\b\n\000\032\004\b\016\020\fR\023\020\017\032\004\030\0010\020¢\006\b\n\000\032\004\b\021\020\022R\023\020\023\032\004\030\0010\024¢\006\b\n\000\032\004\b\025\020\026¨\006\037"}, d2 = {"Lcom/facebook/share/model/ShareVideoContent;", "Lcom/facebook/share/model/ShareContent;", "Lcom/facebook/share/model/ShareVideoContent$Builder;", "Lcom/facebook/share/model/ShareModel;", "builder", "(Lcom/facebook/share/model/ShareVideoContent$Builder;)V", "parcel", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "contentDescription", "", "getContentDescription", "()Ljava/lang/String;", "contentTitle", "getContentTitle", "previewPhoto", "Lcom/facebook/share/model/SharePhoto;", "getPreviewPhoto", "()Lcom/facebook/share/model/SharePhoto;", "video", "Lcom/facebook/share/model/ShareVideo;", "getVideo", "()Lcom/facebook/share/model/ShareVideo;", "describeContents", "", "writeToParcel", "", "out", "flags", "Builder", "Companion", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
public final class ShareVideoContent extends ShareContent<ShareVideoContent, ShareVideoContent.Builder> implements ShareModel {
  public static final Parcelable.Creator<ShareVideoContent> CREATOR;
  
  public static final Companion Companion = new Companion(null);
  
  private final String contentDescription;
  
  private final String contentTitle;
  
  private final SharePhoto previewPhoto;
  
  private final ShareVideo video;
  
  static {
    CREATOR = new ShareVideoContent$Companion$CREATOR$1();
  }
  
  public ShareVideoContent(Parcel paramParcel) {
    super(paramParcel);
    this.contentDescription = paramParcel.readString();
    this.contentTitle = paramParcel.readString();
    SharePhoto.Builder builder = (new SharePhoto.Builder()).readFrom(paramParcel);
    m.e(builder, "previewPhotoBuilder");
    if (builder.getImageUrl() != null || builder.getBitmap() != null) {
      SharePhoto sharePhoto = builder.build();
    } else {
      builder = null;
    } 
    this.previewPhoto = (SharePhoto)builder;
    this.video = (new ShareVideo.Builder()).readFrom(paramParcel).build();
  }
  
  private ShareVideoContent(Builder paramBuilder) {
    super(paramBuilder);
    this.contentDescription = paramBuilder.getContentDescription$facebook_common_release();
    this.contentTitle = paramBuilder.getContentTitle$facebook_common_release();
    this.previewPhoto = paramBuilder.getPreviewPhoto$facebook_common_release();
    this.video = paramBuilder.getVideo$facebook_common_release();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final String getContentDescription() {
    return this.contentDescription;
  }
  
  public final String getContentTitle() {
    return this.contentTitle;
  }
  
  public final SharePhoto getPreviewPhoto() {
    return this.previewPhoto;
  }
  
  public final ShareVideo getVideo() {
    return this.video;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    m.f(paramParcel, "out");
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeString(this.contentDescription);
    paramParcel.writeString(this.contentTitle);
    paramParcel.writeParcelable((Parcelable)this.previewPhoto, 0);
    paramParcel.writeParcelable((Parcelable)this.video, 0);
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\b\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\f\030\0002\016\022\004\022\0020\002\022\004\022\0020\0000\001B\005¢\006\002\020\003J\b\020\031\032\0020\002H\026J\022\020\032\032\0020\0002\b\020\033\032\004\030\0010\002H\026J\020\020\034\032\0020\0002\b\020\004\032\004\030\0010\005J\020\020\035\032\0020\0002\b\020\n\032\004\030\0010\005J\020\020\036\032\0020\0002\b\020\r\032\004\030\0010\016J\020\020\037\032\0020\0002\b\020\023\032\004\030\0010\024R\034\020\004\032\004\030\0010\005X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\005X\016¢\006\016\n\000\032\004\b\013\020\007\"\004\b\f\020\tR\034\020\r\032\004\030\0010\016X\016¢\006\016\n\000\032\004\b\017\020\020\"\004\b\021\020\022R\034\020\023\032\004\030\0010\024X\016¢\006\016\n\000\032\004\b\025\020\026\"\004\b\027\020\030¨\006 "}, d2 = {"Lcom/facebook/share/model/ShareVideoContent$Builder;", "Lcom/facebook/share/model/ShareContent$Builder;", "Lcom/facebook/share/model/ShareVideoContent;", "()V", "contentDescription", "", "getContentDescription$facebook_common_release", "()Ljava/lang/String;", "setContentDescription$facebook_common_release", "(Ljava/lang/String;)V", "contentTitle", "getContentTitle$facebook_common_release", "setContentTitle$facebook_common_release", "previewPhoto", "Lcom/facebook/share/model/SharePhoto;", "getPreviewPhoto$facebook_common_release", "()Lcom/facebook/share/model/SharePhoto;", "setPreviewPhoto$facebook_common_release", "(Lcom/facebook/share/model/SharePhoto;)V", "video", "Lcom/facebook/share/model/ShareVideo;", "getVideo$facebook_common_release", "()Lcom/facebook/share/model/ShareVideo;", "setVideo$facebook_common_release", "(Lcom/facebook/share/model/ShareVideo;)V", "build", "readFrom", "content", "setContentDescription", "setContentTitle", "setPreviewPhoto", "setVideo", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class Builder extends ShareContent.Builder<ShareVideoContent, Builder> {
    private String contentDescription;
    
    private String contentTitle;
    
    private SharePhoto previewPhoto;
    
    private ShareVideo video;
    
    public ShareVideoContent build() {
      return new ShareVideoContent(this, null);
    }
    
    public final String getContentDescription$facebook_common_release() {
      return this.contentDescription;
    }
    
    public final String getContentTitle$facebook_common_release() {
      return this.contentTitle;
    }
    
    public final SharePhoto getPreviewPhoto$facebook_common_release() {
      return this.previewPhoto;
    }
    
    public final ShareVideo getVideo$facebook_common_release() {
      return this.video;
    }
    
    public Builder readFrom(ShareVideoContent param1ShareVideoContent) {
      return (param1ShareVideoContent == null) ? this : ((Builder)super.readFrom(param1ShareVideoContent)).setContentDescription(param1ShareVideoContent.getContentDescription()).setContentTitle(param1ShareVideoContent.getContentTitle()).setPreviewPhoto(param1ShareVideoContent.getPreviewPhoto()).setVideo(param1ShareVideoContent.getVideo());
    }
    
    public final Builder setContentDescription(String param1String) {
      this.contentDescription = param1String;
      return this;
    }
    
    public final void setContentDescription$facebook_common_release(String param1String) {
      this.contentDescription = param1String;
    }
    
    public final Builder setContentTitle(String param1String) {
      this.contentTitle = param1String;
      return this;
    }
    
    public final void setContentTitle$facebook_common_release(String param1String) {
      this.contentTitle = param1String;
    }
    
    public final Builder setPreviewPhoto(SharePhoto param1SharePhoto) {
      if (param1SharePhoto != null) {
        param1SharePhoto = (new SharePhoto.Builder()).readFrom(param1SharePhoto).build();
      } else {
        param1SharePhoto = null;
      } 
      this.previewPhoto = param1SharePhoto;
      return this;
    }
    
    public final void setPreviewPhoto$facebook_common_release(SharePhoto param1SharePhoto) {
      this.previewPhoto = param1SharePhoto;
    }
    
    public final Builder setVideo(ShareVideo param1ShareVideo) {
      if (param1ShareVideo == null)
        return this; 
      this.video = (new ShareVideo.Builder()).readFrom(param1ShareVideo).build();
      return this;
    }
    
    public final void setVideo$facebook_common_release(ShareVideo param1ShareVideo) {
      this.video = param1ShareVideo;
    }
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\026\020\003\032\b\022\004\022\0020\0050\0048\006X\004¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/share/model/ShareVideoContent$Companion;", "", "()V", "CREATOR", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/share/model/ShareVideoContent;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\021\n\000\n\002\020\b\n\002\b\002*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\020\020\003\032\0020\0022\006\020\004\032\0020\005H\026J\035\020\006\032\n\022\006\022\004\030\0010\0020\0072\006\020\b\032\0020\tH\026¢\006\002\020\n¨\006\013"}, d2 = {"com/facebook/share/model/ShareVideoContent$Companion$CREATOR$1", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/share/model/ShareVideoContent;", "createFromParcel", "parcel", "Landroid/os/Parcel;", "newArray", "", "size", "", "(I)[Lcom/facebook/share/model/ShareVideoContent;", "facebook-common_release"}, k = 1, mv = {1, 5, 1})
  public static final class ShareVideoContent$Companion$CREATOR$1 implements Parcelable.Creator<ShareVideoContent> {
    public ShareVideoContent createFromParcel(Parcel param1Parcel) {
      m.f(param1Parcel, "parcel");
      return new ShareVideoContent(param1Parcel);
    }
    
    public ShareVideoContent[] newArray(int param1Int) {
      return new ShareVideoContent[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\share\model\ShareVideoContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */