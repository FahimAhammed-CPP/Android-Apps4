package com.facebook.login;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import com.facebook.AccessToken;
import com.facebook.AccessTokenSource;
import com.facebook.FacebookActivity;
import com.facebook.FacebookException;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphRequestAsyncTask;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.appevents.InternalAppEventsLogger;
import com.facebook.common.R;
import com.facebook.devicerequests.internal.DeviceRequestsHelper;
import com.facebook.internal.FetchedAppSettingsManager;
import com.facebook.internal.SmartLoginOption;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceAuthDialog extends DialogFragment {
  private static final String DEVICE_LOGIN_ENDPOINT = "device/login";
  
  private static final String DEVICE_LOGIN_STATUS_ENDPOINT = "device/login_status";
  
  private static final int LOGIN_ERROR_SUBCODE_AUTHORIZATION_DECLINED = 1349173;
  
  private static final int LOGIN_ERROR_SUBCODE_AUTHORIZATION_PENDING = 1349174;
  
  private static final int LOGIN_ERROR_SUBCODE_CODE_EXPIRED = 1349152;
  
  private static final int LOGIN_ERROR_SUBCODE_EXCESSIVE_POLLING = 1349172;
  
  private static final String REQUEST_STATE_KEY = "request_state";
  
  private AtomicBoolean completed = new AtomicBoolean();
  
  private TextView confirmationCode;
  
  private volatile GraphRequestAsyncTask currentGraphRequestPoll;
  
  private volatile RequestState currentRequestState;
  
  private DeviceAuthMethodHandler deviceAuthMethodHandler;
  
  private TextView instructions;
  
  private boolean isBeingDestroyed = false;
  
  private boolean isRetry = false;
  
  private LoginClient.Request mRequest = null;
  
  private View progressBar;
  
  private volatile ScheduledFuture scheduledPoll;
  
  private void completeLogin(String paramString1, Utility.PermissionsLists paramPermissionsLists, String paramString2, Date paramDate1, Date paramDate2) {
    this.deviceAuthMethodHandler.g(paramString2, FacebookSdk.getApplicationId(), paramString1, paramPermissionsLists.getGrantedPermissions(), paramPermissionsLists.getDeclinedPermissions(), paramPermissionsLists.getExpiredPermissions(), AccessTokenSource.DEVICE_AUTH, paramDate1, null, paramDate2);
    getDialog().dismiss();
  }
  
  private GraphRequest getPollRequest() {
    Bundle bundle = new Bundle();
    bundle.putString("code", this.currentRequestState.e());
    return new GraphRequest(null, "device/login_status", bundle, HttpMethod.POST, new e(this));
  }
  
  private void onSuccess(String paramString, Long paramLong1, Long paramLong2) {
    Bundle bundle = new Bundle();
    bundle.putString("fields", "id,permissions,name");
    long l = paramLong1.longValue();
    Date date2 = null;
    if (l != 0L) {
      Date date = new Date((new Date()).getTime() + paramLong1.longValue() * 1000L);
    } else {
      paramLong1 = null;
    } 
    Date date1 = date2;
    if (paramLong2.longValue() != 0L) {
      date1 = date2;
      if (paramLong2 != null)
        date1 = new Date(paramLong2.longValue() * 1000L); 
    } 
    (new GraphRequest(new AccessToken(paramString, FacebookSdk.getApplicationId(), "0", null, null, null, null, (Date)paramLong1, null, date1), "me", bundle, HttpMethod.GET, new h(this, paramString, (Date)paramLong1, date1))).executeAsync();
  }
  
  private void poll() {
    this.currentRequestState.h((new Date()).getTime());
    this.currentGraphRequestPoll = getPollRequest().executeAsync();
  }
  
  private void presentConfirmation(String paramString1, Utility.PermissionsLists paramPermissionsLists, String paramString2, String paramString3, Date paramDate1, Date paramDate2) {
    String str1 = getResources().getString(R.string.com_facebook_smart_login_confirmation_title);
    String str3 = getResources().getString(R.string.com_facebook_smart_login_confirmation_continue_as);
    String str2 = getResources().getString(R.string.com_facebook_smart_login_confirmation_cancel);
    paramString3 = String.format(str3, new Object[] { paramString3 });
    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
    builder.setMessage(str1).setCancelable(true).setNegativeButton(paramString3, new g(this, paramString1, paramPermissionsLists, paramString2, paramDate1, paramDate2)).setPositiveButton(str2, new f(this));
    builder.create().show();
  }
  
  private void schedulePoll() {
    this.scheduledPoll = DeviceAuthMethodHandler.d().schedule(new d(this), this.currentRequestState.d(), TimeUnit.SECONDS);
  }
  
  private void setCurrentRequestState(RequestState paramRequestState) {
    this.currentRequestState = paramRequestState;
    this.confirmationCode.setText(paramRequestState.f());
    Bitmap bitmap = DeviceRequestsHelper.generateQRCode(paramRequestState.c());
    BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
    this.instructions.setCompoundDrawablesWithIntrinsicBounds(null, (Drawable)bitmapDrawable, null, null);
    this.confirmationCode.setVisibility(0);
    this.progressBar.setVisibility(8);
    if (!this.isRetry && DeviceRequestsHelper.startAdvertisementService(paramRequestState.f()))
      (new InternalAppEventsLogger(getContext())).logEventImplicitly("fb_smart_login_service"); 
    if (paramRequestState.k()) {
      schedulePoll();
      return;
    } 
    poll();
  }
  
  @Nullable
  Map<String, String> additionalDeviceInfo() {
    return null;
  }
  
  @LayoutRes
  protected int getLayoutResId(boolean paramBoolean) {
    return paramBoolean ? R.layout.com_facebook_smart_device_dialog_fragment : R.layout.com_facebook_device_auth_dialog_fragment;
  }
  
  protected View initializeContentView(boolean paramBoolean) {
    View view = getActivity().getLayoutInflater().inflate(getLayoutResId(paramBoolean), null);
    this.progressBar = view.findViewById(R.id.progress_bar);
    this.confirmationCode = (TextView)view.findViewById(R.id.confirmation_code);
    ((Button)view.findViewById(R.id.cancel_button)).setOnClickListener(new c(this));
    TextView textView = (TextView)view.findViewById(R.id.com_facebook_device_auth_instructions);
    this.instructions = textView;
    textView.setText((CharSequence)Html.fromHtml(getString(R.string.com_facebook_device_auth_instructions)));
    return view;
  }
  
  protected void onBackButtonPressed() {}
  
  protected void onCancel() {
    if (!this.completed.compareAndSet(false, true))
      return; 
    if (this.currentRequestState != null)
      DeviceRequestsHelper.cleanUpAdvertisementService(this.currentRequestState.f()); 
    DeviceAuthMethodHandler deviceAuthMethodHandler = this.deviceAuthMethodHandler;
    if (deviceAuthMethodHandler != null)
      deviceAuthMethodHandler.e(); 
    getDialog().dismiss();
  }
  
  @NonNull
  public Dialog onCreateDialog(Bundle paramBundle) {
    boolean bool;
    a a = new a(this, (Context)getActivity(), R.style.com_facebook_auth_dialog);
    if (DeviceRequestsHelper.isAvailable() && !this.isRetry) {
      bool = true;
    } else {
      bool = false;
    } 
    a.setContentView(initializeContentView(bool));
    return a;
  }
  
  @Nullable
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    View view = super.onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
    this.deviceAuthMethodHandler = (DeviceAuthMethodHandler)((LoginFragment)((FacebookActivity)getActivity()).getCurrentFragment()).getLoginClient().getCurrentHandler();
    if (paramBundle != null) {
      RequestState requestState = (RequestState)paramBundle.getParcelable("request_state");
      if (requestState != null)
        setCurrentRequestState(requestState); 
    } 
    return view;
  }
  
  public void onDestroyView() {
    this.isBeingDestroyed = true;
    this.completed.set(true);
    super.onDestroyView();
    if (this.currentGraphRequestPoll != null)
      this.currentGraphRequestPoll.cancel(true); 
    if (this.scheduledPoll != null)
      this.scheduledPoll.cancel(true); 
    this.progressBar = null;
    this.confirmationCode = null;
    this.instructions = null;
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    super.onDismiss(paramDialogInterface);
    if (!this.isBeingDestroyed)
      onCancel(); 
  }
  
  protected void onError(FacebookException paramFacebookException) {
    if (!this.completed.compareAndSet(false, true))
      return; 
    if (this.currentRequestState != null)
      DeviceRequestsHelper.cleanUpAdvertisementService(this.currentRequestState.f()); 
    this.deviceAuthMethodHandler.f((Exception)paramFacebookException);
    getDialog().dismiss();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    if (this.currentRequestState != null)
      paramBundle.putParcelable("request_state", this.currentRequestState); 
  }
  
  public void startLogin(LoginClient.Request paramRequest) {
    this.mRequest = paramRequest;
    Bundle bundle = new Bundle();
    bundle.putString("scope", TextUtils.join(",", paramRequest.getPermissions()));
    String str2 = paramRequest.getDeviceRedirectUriString();
    if (str2 != null)
      bundle.putString("redirect_uri", str2); 
    String str1 = paramRequest.getDeviceAuthTargetUserId();
    if (str1 != null)
      bundle.putString("target_user_id", str1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Validate.hasAppID());
    stringBuilder.append("|");
    stringBuilder.append(Validate.hasClientToken());
    bundle.putString("access_token", stringBuilder.toString());
    bundle.putString("device_info", DeviceRequestsHelper.getDeviceInfo(additionalDeviceInfo()));
    (new GraphRequest(null, "device/login", bundle, HttpMethod.POST, new b(this))).executeAsync();
  }
  
  private static class RequestState implements Parcelable {
    public static final Parcelable.Creator<RequestState> CREATOR = new a();
    
    private String b;
    
    private String c;
    
    private String d;
    
    private long e;
    
    private long f;
    
    RequestState() {}
    
    protected RequestState(Parcel param1Parcel) {
      this.b = param1Parcel.readString();
      this.c = param1Parcel.readString();
      this.d = param1Parcel.readString();
      this.e = param1Parcel.readLong();
      this.f = param1Parcel.readLong();
    }
    
    public String c() {
      return this.b;
    }
    
    public long d() {
      return this.e;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String e() {
      return this.d;
    }
    
    public String f() {
      return this.c;
    }
    
    public void g(long param1Long) {
      this.e = param1Long;
    }
    
    public void h(long param1Long) {
      this.f = param1Long;
    }
    
    public void i(String param1String) {
      this.d = param1String;
    }
    
    public void j(String param1String) {
      this.c = param1String;
      this.b = String.format(Locale.ENGLISH, "https://facebook.com/device?user_code=%1$s&qr=1", new Object[] { param1String });
    }
    
    public boolean k() {
      long l = this.f;
      boolean bool = false;
      if (l == 0L)
        return false; 
      if ((new Date()).getTime() - this.f - this.e * 1000L < 0L)
        bool = true; 
      return bool;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.b);
      param1Parcel.writeString(this.c);
      param1Parcel.writeString(this.d);
      param1Parcel.writeLong(this.e);
      param1Parcel.writeLong(this.f);
    }
    
    static final class a implements Parcelable.Creator<RequestState> {
      public DeviceAuthDialog.RequestState a(Parcel param2Parcel) {
        return new DeviceAuthDialog.RequestState(param2Parcel);
      }
      
      public DeviceAuthDialog.RequestState[] b(int param2Int) {
        return new DeviceAuthDialog.RequestState[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<RequestState> {
    public DeviceAuthDialog.RequestState a(Parcel param1Parcel) {
      return new DeviceAuthDialog.RequestState(param1Parcel);
    }
    
    public DeviceAuthDialog.RequestState[] b(int param1Int) {
      return new DeviceAuthDialog.RequestState[param1Int];
    }
  }
  
  class a extends Dialog {
    a(DeviceAuthDialog this$0, Context param1Context, int param1Int) {
      super(param1Context, param1Int);
    }
    
    public void onBackPressed() {
      this.b.onBackButtonPressed();
      super.onBackPressed();
    }
  }
  
  class b implements GraphRequest.Callback {
    b(DeviceAuthDialog this$0) {}
    
    public void onCompleted(GraphResponse param1GraphResponse) {
      if (this.a.isBeingDestroyed)
        return; 
      if (param1GraphResponse.getError() != null) {
        this.a.onError(param1GraphResponse.getError().getException());
        return;
      } 
      JSONObject jSONObject = param1GraphResponse.getJSONObject();
      DeviceAuthDialog.RequestState requestState = new DeviceAuthDialog.RequestState();
      try {
        requestState.j(jSONObject.getString("user_code"));
        requestState.i(jSONObject.getString("code"));
        requestState.g(jSONObject.getLong("interval"));
        this.a.setCurrentRequestState(requestState);
        return;
      } catch (JSONException jSONException) {
        this.a.onError(new FacebookException((Throwable)jSONException));
        return;
      } 
    }
  }
  
  class c implements View.OnClickListener {
    c(DeviceAuthDialog this$0) {}
    
    public void onClick(View param1View) {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        return;
      } finally {
        param1View = null;
        CrashShieldHandler.handleThrowable((Throwable)param1View, this);
      } 
    }
  }
  
  class d implements Runnable {
    d(DeviceAuthDialog this$0) {}
    
    public void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        return;
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  class e implements GraphRequest.Callback {
    e(DeviceAuthDialog this$0) {}
    
    public void onCompleted(GraphResponse param1GraphResponse) {
      DeviceAuthDialog deviceAuthDialog;
      if (this.a.completed.get())
        return; 
      FacebookRequestError facebookRequestError = param1GraphResponse.getError();
      if (facebookRequestError != null) {
        int i = facebookRequestError.getSubErrorCode();
        if (i != 1349152) {
          switch (i) {
            default:
              this.a.onError(param1GraphResponse.getError().getException());
              return;
            case 1349173:
              this.a.onCancel();
              return;
            case 1349172:
            case 1349174:
              break;
          } 
          this.a.schedulePoll();
          return;
        } 
        if (this.a.currentRequestState != null)
          DeviceRequestsHelper.cleanUpAdvertisementService(this.a.currentRequestState.f()); 
        if (this.a.mRequest != null) {
          deviceAuthDialog = this.a;
          deviceAuthDialog.startLogin(deviceAuthDialog.mRequest);
          return;
        } 
        this.a.onCancel();
        return;
      } 
      try {
        JSONObject jSONObject = deviceAuthDialog.getJSONObject();
        this.a.onSuccess(jSONObject.getString("access_token"), Long.valueOf(jSONObject.getLong("expires_in")), Long.valueOf(jSONObject.optLong("data_access_expiration_time")));
        return;
      } catch (JSONException jSONException) {
        this.a.onError(new FacebookException((Throwable)jSONException));
        return;
      } 
    }
  }
  
  class f implements DialogInterface.OnClickListener {
    f(DeviceAuthDialog this$0) {}
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      View view = this.b.initializeContentView(false);
      this.b.getDialog().setContentView(view);
      DeviceAuthDialog deviceAuthDialog = this.b;
      deviceAuthDialog.startLogin(deviceAuthDialog.mRequest);
    }
  }
  
  class g implements DialogInterface.OnClickListener {
    g(DeviceAuthDialog this$0, String param1String1, Utility.PermissionsLists param1PermissionsLists, String param1String2, Date param1Date1, Date param1Date2) {}
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.g.completeLogin(this.b, this.c, this.d, this.e, this.f);
    }
  }
  
  class h implements GraphRequest.Callback {
    h(DeviceAuthDialog this$0, String param1String, Date param1Date1, Date param1Date2) {}
    
    public void onCompleted(GraphResponse param1GraphResponse) {
      if (this.d.completed.get())
        return; 
      if (param1GraphResponse.getError() != null) {
        this.d.onError(param1GraphResponse.getError().getException());
        return;
      } 
      try {
        JSONObject jSONObject = param1GraphResponse.getJSONObject();
        String str1 = jSONObject.getString("id");
        Utility.PermissionsLists permissionsLists = Utility.handlePermissionResponse(jSONObject);
        String str2 = jSONObject.getString("name");
        DeviceRequestsHelper.cleanUpAdvertisementService(this.d.currentRequestState.f());
        if (FetchedAppSettingsManager.getAppSettingsWithoutQuery(FacebookSdk.getApplicationId()).getSmartLoginOptions().contains(SmartLoginOption.RequireConfirm) && !this.d.isRetry) {
          DeviceAuthDialog.access$902(this.d, true);
          this.d.presentConfirmation(str1, permissionsLists, this.a, str2, this.b, this.c);
          return;
        } 
        this.d.completeLogin(str1, permissionsLists, this.a, this.b, this.c);
        return;
      } catch (JSONException jSONException) {
        this.d.onError(new FacebookException((Throwable)jSONException));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\login\DeviceAuthDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */