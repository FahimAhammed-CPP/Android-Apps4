package com.facebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.facebook.internal.Utility;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.m;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\020\002\n\000\n\002\020\013\n\002\b\006\030\000 \0262\0020\001:\002\026\027B\027\b\000\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\006\020\017\032\0020\020J\006\020\021\032\0020\022J\034\020\023\032\0020\0202\b\020\024\032\004\030\0010\b2\b\020\t\032\004\030\0010\bH\002J\032\020\f\032\0020\0202\b\020\t\032\004\030\0010\b2\006\020\025\032\0020\022H\002R\016\020\004\032\0020\005X\004¢\006\002\n\000R(\020\t\032\004\030\0010\b2\b\020\007\032\004\030\0010\b8F@FX\016¢\006\f\032\004\b\n\020\013\"\004\b\f\020\rR\020\020\016\032\004\030\0010\bX\016¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\030"}, d2 = {"Lcom/facebook/AuthenticationTokenManager;", "", "localBroadcastManager", "Landroidx/localbroadcastmanager/content/LocalBroadcastManager;", "authenticationTokenCache", "Lcom/facebook/AuthenticationTokenCache;", "(Landroidx/localbroadcastmanager/content/LocalBroadcastManager;Lcom/facebook/AuthenticationTokenCache;)V", "value", "Lcom/facebook/AuthenticationToken;", "currentAuthenticationToken", "getCurrentAuthenticationToken", "()Lcom/facebook/AuthenticationToken;", "setCurrentAuthenticationToken", "(Lcom/facebook/AuthenticationToken;)V", "currentAuthenticationTokenField", "currentAuthenticationTokenChanged", "", "loadCurrentAuthenticationToken", "", "sendCurrentAuthenticationTokenChangedBroadcastIntent", "oldAuthenticationToken", "saveToCache", "Companion", "CurrentAuthenticationTokenChangedBroadcastReceiver", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AuthenticationTokenManager {
  public static final String ACTION_CURRENT_AUTHENTICATION_TOKEN_CHANGED = "com.facebook.sdk.ACTION_CURRENT_AUTHENTICATION_TOKEN_CHANGED";
  
  public static final Companion Companion = new Companion(null);
  
  public static final String EXTRA_NEW_AUTHENTICATION_TOKEN = "com.facebook.sdk.EXTRA_NEW_AUTHENTICATION_TOKEN";
  
  public static final String EXTRA_OLD_AUTHENTICATION_TOKEN = "com.facebook.sdk.EXTRA_OLD_AUTHENTICATION_TOKEN";
  
  public static final String SHARED_PREFERENCES_NAME = "com.facebook.AuthenticationTokenManager.SharedPreferences";
  
  public static final String TAG = "AuthenticationTokenManager";
  
  private static AuthenticationTokenManager instanceField;
  
  private final AuthenticationTokenCache authenticationTokenCache;
  
  private AuthenticationToken currentAuthenticationTokenField;
  
  private final LocalBroadcastManager localBroadcastManager;
  
  public AuthenticationTokenManager(LocalBroadcastManager paramLocalBroadcastManager, AuthenticationTokenCache paramAuthenticationTokenCache) {
    this.localBroadcastManager = paramLocalBroadcastManager;
    this.authenticationTokenCache = paramAuthenticationTokenCache;
  }
  
  public static final AuthenticationTokenManager getInstance() {
    return Companion.getInstance();
  }
  
  private final void sendCurrentAuthenticationTokenChangedBroadcastIntent(AuthenticationToken paramAuthenticationToken1, AuthenticationToken paramAuthenticationToken2) {
    Intent intent = new Intent(FacebookSdk.getApplicationContext(), CurrentAuthenticationTokenChangedBroadcastReceiver.class);
    intent.setAction("com.facebook.sdk.ACTION_CURRENT_AUTHENTICATION_TOKEN_CHANGED");
    intent.putExtra("com.facebook.sdk.EXTRA_OLD_AUTHENTICATION_TOKEN", (Parcelable)paramAuthenticationToken1);
    intent.putExtra("com.facebook.sdk.EXTRA_NEW_AUTHENTICATION_TOKEN", (Parcelable)paramAuthenticationToken2);
    this.localBroadcastManager.sendBroadcast(intent);
  }
  
  private final void setCurrentAuthenticationToken(AuthenticationToken paramAuthenticationToken, boolean paramBoolean) {
    AuthenticationToken authenticationToken = getCurrentAuthenticationToken();
    this.currentAuthenticationTokenField = paramAuthenticationToken;
    if (paramBoolean)
      if (paramAuthenticationToken != null) {
        this.authenticationTokenCache.save(paramAuthenticationToken);
      } else {
        this.authenticationTokenCache.clear();
        Utility.clearFacebookCookies(FacebookSdk.getApplicationContext());
      }  
    if (!Utility.areObjectsEqual(authenticationToken, paramAuthenticationToken))
      sendCurrentAuthenticationTokenChangedBroadcastIntent(authenticationToken, paramAuthenticationToken); 
  }
  
  public final void currentAuthenticationTokenChanged() {
    sendCurrentAuthenticationTokenChangedBroadcastIntent(getCurrentAuthenticationToken(), getCurrentAuthenticationToken());
  }
  
  public final AuthenticationToken getCurrentAuthenticationToken() {
    return this.currentAuthenticationTokenField;
  }
  
  public final boolean loadCurrentAuthenticationToken() {
    AuthenticationToken authenticationToken = this.authenticationTokenCache.load();
    if (authenticationToken != null) {
      setCurrentAuthenticationToken(authenticationToken, false);
      return true;
    } 
    return false;
  }
  
  public final void setCurrentAuthenticationToken(AuthenticationToken paramAuthenticationToken) {
    setCurrentAuthenticationToken(paramAuthenticationToken, true);
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\013\032\0020\nH\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\004XT¢\006\002\n\000R\020\020\t\032\004\030\0010\nX\016¢\006\002\n\000¨\006\f"}, d2 = {"Lcom/facebook/AuthenticationTokenManager$Companion;", "", "()V", "ACTION_CURRENT_AUTHENTICATION_TOKEN_CHANGED", "", "EXTRA_NEW_AUTHENTICATION_TOKEN", "EXTRA_OLD_AUTHENTICATION_TOKEN", "SHARED_PREFERENCES_NAME", "TAG", "instanceField", "Lcom/facebook/AuthenticationTokenManager;", "getInstance", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    public final AuthenticationTokenManager getInstance() {
      // Byte code:
      //   0: invokestatic access$getInstanceField$cp : ()Lcom/facebook/AuthenticationTokenManager;
      //   3: astore_1
      //   4: aload_1
      //   5: ifnonnull -> 62
      //   8: aload_0
      //   9: monitorenter
      //   10: invokestatic access$getInstanceField$cp : ()Lcom/facebook/AuthenticationTokenManager;
      //   13: astore_2
      //   14: aload_2
      //   15: astore_1
      //   16: aload_2
      //   17: ifnonnull -> 53
      //   20: invokestatic getApplicationContext : ()Landroid/content/Context;
      //   23: invokestatic getInstance : (Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;
      //   26: astore_1
      //   27: aload_1
      //   28: ldc 'LocalBroadcastManager.ge…tance(applicationContext)'
      //   30: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
      //   33: new com/facebook/AuthenticationTokenManager
      //   36: dup
      //   37: aload_1
      //   38: new com/facebook/AuthenticationTokenCache
      //   41: dup
      //   42: invokespecial <init> : ()V
      //   45: invokespecial <init> : (Landroidx/localbroadcastmanager/content/LocalBroadcastManager;Lcom/facebook/AuthenticationTokenCache;)V
      //   48: astore_1
      //   49: aload_1
      //   50: invokestatic access$setInstanceField$cp : (Lcom/facebook/AuthenticationTokenManager;)V
      //   53: aload_0
      //   54: monitorexit
      //   55: aload_1
      //   56: areturn
      //   57: astore_1
      //   58: aload_0
      //   59: monitorexit
      //   60: aload_1
      //   61: athrow
      //   62: aload_1
      //   63: areturn
      // Exception table:
      //   from	to	target	type
      //   10	14	57	finally
      //   20	53	57	finally
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\030\0002\0020\001B\005¢\006\002\020\002J\030\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\bH\026¨\006\t"}, d2 = {"Lcom/facebook/AuthenticationTokenManager$CurrentAuthenticationTokenChangedBroadcastReceiver;", "Landroid/content/BroadcastReceiver;", "()V", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class CurrentAuthenticationTokenChangedBroadcastReceiver extends BroadcastReceiver {
    public void onReceive(Context param1Context, Intent param1Intent) {
      m.f(param1Context, "context");
      m.f(param1Intent, "intent");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\AuthenticationTokenManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */