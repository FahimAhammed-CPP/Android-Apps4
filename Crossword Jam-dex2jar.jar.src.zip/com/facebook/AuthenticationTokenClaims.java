package com.facebook;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import androidx.annotation.VisibleForTesting;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.g0;
import kotlin.d0.d.l;
import kotlin.d0.d.m;
import kotlin.k0.d;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(d1 = {"\000\\\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\007\n\002\020\t\n\002\b\t\n\002\020\036\n\002\b\002\n\002\020$\n\002\020\b\n\002\b\006\n\002\030\002\n\002\b\023\n\002\020\"\n\002\b\b\n\002\020\013\n\000\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\004\030\000 L2\0020\001:\001LB\027\b\027\022\006\020\002\032\0020\003\022\006\020\004\032\0020\003¢\006\002\020\005B\002\b\027\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\b\032\0020\003\022\006\020\t\032\0020\003\022\006\020\n\032\0020\013\022\006\020\f\032\0020\013\022\006\020\r\032\0020\003\022\n\b\002\020\016\032\004\030\0010\003\022\n\b\002\020\017\032\004\030\0010\003\022\n\b\002\020\020\032\004\030\0010\003\022\n\b\002\020\021\032\004\030\0010\003\022\n\b\002\020\022\032\004\030\0010\003\022\n\b\002\020\023\032\004\030\0010\003\022\020\b\002\020\024\032\n\022\004\022\0020\003\030\0010\025\022\n\b\002\020\026\032\004\030\0010\003\022\026\b\002\020\027\032\020\022\004\022\0020\003\022\004\022\0020\031\030\0010\030\022\026\b\002\020\032\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030\022\026\b\002\020\033\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030\022\n\b\002\020\034\032\004\030\0010\003\022\n\b\002\020\035\032\004\030\0010\003¢\006\002\020\036B\017\b\020\022\006\020\037\032\0020 ¢\006\002\020!J\b\020;\032\0020\031H\026J\023\020<\032\0020=2\b\020>\032\004\030\0010?H\002J\b\020@\032\0020\031H\026J\030\020A\032\0020=2\006\020B\032\0020C2\006\020\004\032\0020\003H\002J\b\020D\032\0020\003H\007J\r\020E\032\0020CH\001¢\006\002\bFJ\b\020G\032\0020\003H\026J\030\020H\032\0020I2\006\020J\032\0020 2\006\020K\032\0020\031H\026R\021\020\b\032\0020\003¢\006\b\n\000\032\004\b\"\020#R\023\020\022\032\004\030\0010\003¢\006\b\n\000\032\004\b$\020#R\021\020\n\032\0020\013¢\006\b\n\000\032\004\b%\020&R\023\020\021\032\004\030\0010\003¢\006\b\n\000\032\004\b'\020#R\023\020\017\032\004\030\0010\003¢\006\b\n\000\032\004\b(\020#R\021\020\f\032\0020\013¢\006\b\n\000\032\004\b)\020&R\021\020\007\032\0020\003¢\006\b\n\000\032\004\b*\020#R\021\020\006\032\0020\003¢\006\b\n\000\032\004\b+\020#R\023\020\020\032\004\030\0010\003¢\006\b\n\000\032\004\b,\020#R\023\020\016\032\004\030\0010\003¢\006\b\n\000\032\004\b-\020#R\021\020\t\032\0020\003¢\006\b\n\000\032\004\b.\020#R\023\020\023\032\004\030\0010\003¢\006\b\n\000\032\004\b/\020#R\021\020\r\032\0020\003¢\006\b\n\000\032\004\b0\020#R\037\020\027\032\020\022\004\022\0020\003\022\004\022\0020\031\030\0010\030¢\006\b\n\000\032\004\b1\0202R\023\020\026\032\004\030\0010\003¢\006\b\n\000\032\004\b3\020#R\031\020\024\032\n\022\004\022\0020\003\030\00104¢\006\b\n\000\032\004\b5\0206R\023\020\034\032\004\030\0010\003¢\006\b\n\000\032\004\b7\020#R\037\020\032\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030¢\006\b\n\000\032\004\b8\0202R\023\020\035\032\004\030\0010\003¢\006\b\n\000\032\004\b9\020#R\037\020\033\032\020\022\004\022\0020\003\022\004\022\0020\003\030\0010\030¢\006\b\n\000\032\004\b:\0202¨\006M"}, d2 = {"Lcom/facebook/AuthenticationTokenClaims;", "Landroid/os/Parcelable;", "encodedClaims", "", "expectedNonce", "(Ljava/lang/String;Ljava/lang/String;)V", "jti", "iss", "aud", "nonce", "exp", "", "iat", "sub", "name", "givenName", "middleName", "familyName", "email", "picture", "userFriends", "", "userBirthday", "userAgeRange", "", "", "userHometown", "userLocation", "userGender", "userLink", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Collection;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V", "parcel", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "getAud", "()Ljava/lang/String;", "getEmail", "getExp", "()J", "getFamilyName", "getGivenName", "getIat", "getIss", "getJti", "getMiddleName", "getName", "getNonce", "getPicture", "getSub", "getUserAgeRange", "()Ljava/util/Map;", "getUserBirthday", "", "getUserFriends", "()Ljava/util/Set;", "getUserGender", "getUserHometown", "getUserLink", "getUserLocation", "describeContents", "equals", "", "other", "", "hashCode", "isValidClaims", "claimsJson", "Lorg/json/JSONObject;", "toEnCodedString", "toJSONObject", "toJSONObject$facebook_core_release", "toString", "writeToParcel", "", "dest", "flags", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AuthenticationTokenClaims implements Parcelable {
  public static final Parcelable.Creator<AuthenticationTokenClaims> CREATOR;
  
  public static final Companion Companion = new Companion(null);
  
  public static final String JSON_KEY_AUD = "aud";
  
  public static final String JSON_KEY_EMAIL = "email";
  
  public static final String JSON_KEY_EXP = "exp";
  
  public static final String JSON_KEY_FAMILY_NAME = "family_name";
  
  public static final String JSON_KEY_GIVEN_NAME = "given_name";
  
  public static final String JSON_KEY_IAT = "iat";
  
  public static final String JSON_KEY_ISS = "iss";
  
  public static final String JSON_KEY_JIT = "jti";
  
  public static final String JSON_KEY_MIDDLE_NAME = "middle_name";
  
  public static final String JSON_KEY_NAME = "name";
  
  public static final String JSON_KEY_NONCE = "nonce";
  
  public static final String JSON_KEY_PICTURE = "picture";
  
  public static final String JSON_KEY_SUB = "sub";
  
  public static final String JSON_KEY_USER_AGE_RANGE = "user_age_range";
  
  public static final String JSON_KEY_USER_BIRTHDAY = "user_birthday";
  
  public static final String JSON_KEY_USER_FRIENDS = "user_friends";
  
  public static final String JSON_KEY_USER_GENDER = "user_gender";
  
  public static final String JSON_KEY_USER_HOMETOWN = "user_hometown";
  
  public static final String JSON_KEY_USER_LINK = "user_link";
  
  public static final String JSON_KEY_USER_LOCATION = "user_location";
  
  public static final long MAX_TIME_SINCE_TOKEN_ISSUED = 600000L;
  
  private final String aud;
  
  private final String email;
  
  private final long exp;
  
  private final String familyName;
  
  private final String givenName;
  
  private final long iat;
  
  private final String iss;
  
  private final String jti;
  
  private final String middleName;
  
  private final String name;
  
  private final String nonce;
  
  private final String picture;
  
  private final String sub;
  
  private final Map<String, Integer> userAgeRange;
  
  private final String userBirthday;
  
  private final Set<String> userFriends;
  
  private final String userGender;
  
  private final Map<String, String> userHometown;
  
  private final String userLink;
  
  private final Map<String, String> userLocation;
  
  static {
    CREATOR = new AuthenticationTokenClaims$Companion$CREATOR$1();
  }
  
  public AuthenticationTokenClaims(Parcel paramParcel) {
    this.jti = Validate.notNullOrEmpty(paramParcel.readString(), "jti");
    this.iss = Validate.notNullOrEmpty(paramParcel.readString(), "iss");
    this.aud = Validate.notNullOrEmpty(paramParcel.readString(), "aud");
    this.nonce = Validate.notNullOrEmpty(paramParcel.readString(), "nonce");
    this.exp = paramParcel.readLong();
    this.iat = paramParcel.readLong();
    this.sub = Validate.notNullOrEmpty(paramParcel.readString(), "sub");
    this.name = paramParcel.readString();
    this.givenName = paramParcel.readString();
    this.middleName = paramParcel.readString();
    this.familyName = paramParcel.readString();
    this.email = paramParcel.readString();
    this.picture = paramParcel.readString();
    ArrayList<?> arrayList = paramParcel.createStringArrayList();
    Map<?, ?> map = null;
    if (arrayList != null) {
      Set<?> set = Collections.unmodifiableSet(new HashSet(arrayList));
    } else {
      arrayList = null;
    } 
    this.userFriends = (Set)arrayList;
    this.userBirthday = paramParcel.readString();
    HashMap<?, ?> hashMap2 = paramParcel.readHashMap(l.a.getClass().getClassLoader());
    HashMap<?, ?> hashMap1 = hashMap2;
    if (!(hashMap2 instanceof HashMap))
      hashMap1 = null; 
    if (hashMap1 != null) {
      Map<?, ?> map1 = Collections.unmodifiableMap(hashMap1);
    } else {
      hashMap1 = null;
    } 
    this.userAgeRange = (Map)hashMap1;
    g0 g0 = g0.a;
    hashMap2 = paramParcel.readHashMap(g0.getClass().getClassLoader());
    hashMap1 = hashMap2;
    if (!(hashMap2 instanceof HashMap))
      hashMap1 = null; 
    if (hashMap1 != null) {
      Map<?, ?> map1 = Collections.unmodifiableMap(hashMap1);
    } else {
      hashMap1 = null;
    } 
    this.userHometown = (Map)hashMap1;
    hashMap2 = paramParcel.readHashMap(g0.getClass().getClassLoader());
    hashMap1 = hashMap2;
    if (!(hashMap2 instanceof HashMap))
      hashMap1 = null; 
    if (hashMap1 != null)
      map = Collections.unmodifiableMap(hashMap1); 
    this.userLocation = (Map)map;
    this.userGender = paramParcel.readString();
    this.userLink = paramParcel.readString();
  }
  
  public AuthenticationTokenClaims(String paramString1, String paramString2) {
    Validate.notEmpty(paramString1, "encodedClaims");
    byte[] arrayOfByte = Base64.decode(paramString1, 8);
    m.e(arrayOfByte, "decodedBytes");
    JSONObject jSONObject = new JSONObject(new String(arrayOfByte, d.a));
    if (isValidClaims(jSONObject, paramString2)) {
      Set<?> set;
      Map<?, ?> map3;
      Map<?, ?> map2;
      String str1;
      Map<?, ?> map1;
      String str2 = jSONObject.getString("jti");
      m.e(str2, "jsonObj.getString(JSON_KEY_JIT)");
      this.jti = str2;
      str2 = jSONObject.getString("iss");
      m.e(str2, "jsonObj.getString(JSON_KEY_ISS)");
      this.iss = str2;
      str2 = jSONObject.getString("aud");
      m.e(str2, "jsonObj.getString(JSON_KEY_AUD)");
      this.aud = str2;
      str2 = jSONObject.getString("nonce");
      m.e(str2, "jsonObj.getString(JSON_KEY_NONCE)");
      this.nonce = str2;
      this.exp = jSONObject.getLong("exp");
      this.iat = jSONObject.getLong("iat");
      str2 = jSONObject.getString("sub");
      m.e(str2, "jsonObj.getString(JSON_KEY_SUB)");
      this.sub = str2;
      Companion companion = Companion;
      this.name = companion.getNullableString$facebook_core_release(jSONObject, "name");
      this.givenName = companion.getNullableString$facebook_core_release(jSONObject, "given_name");
      this.middleName = companion.getNullableString$facebook_core_release(jSONObject, "middle_name");
      this.familyName = companion.getNullableString$facebook_core_release(jSONObject, "family_name");
      this.email = companion.getNullableString$facebook_core_release(jSONObject, "email");
      this.picture = companion.getNullableString$facebook_core_release(jSONObject, "picture");
      JSONArray jSONArray = jSONObject.optJSONArray("user_friends");
      paramString2 = null;
      if (jSONArray == null) {
        jSONArray = null;
      } else {
        set = Collections.unmodifiableSet(Utility.jsonArrayToSet(jSONArray));
      } 
      this.userFriends = (Set)set;
      this.userBirthday = companion.getNullableString$facebook_core_release(jSONObject, "user_birthday");
      JSONObject jSONObject3 = jSONObject.optJSONObject("user_age_range");
      if (jSONObject3 == null) {
        jSONObject3 = null;
      } else {
        map3 = Collections.unmodifiableMap(Utility.convertJSONObjectToHashMap(jSONObject3));
      } 
      this.userAgeRange = (Map)map3;
      JSONObject jSONObject2 = jSONObject.optJSONObject("user_hometown");
      if (jSONObject2 == null) {
        jSONObject2 = null;
      } else {
        map2 = Collections.unmodifiableMap(Utility.convertJSONObjectToStringMap(jSONObject2));
      } 
      this.userHometown = (Map)map2;
      JSONObject jSONObject1 = jSONObject.optJSONObject("user_location");
      if (jSONObject1 == null) {
        str1 = paramString2;
      } else {
        map1 = Collections.unmodifiableMap(Utility.convertJSONObjectToStringMap((JSONObject)str1));
      } 
      this.userLocation = (Map)map1;
      this.userGender = companion.getNullableString$facebook_core_release(jSONObject, "user_gender");
      this.userLink = companion.getNullableString$facebook_core_release(jSONObject, "user_link");
      return;
    } 
    throw new IllegalArgumentException("Invalid claims".toString());
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, null, null, null, null, null, null, null, null, null, null, null, null, null, 1048448, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, null, null, null, null, null, null, null, null, null, null, null, null, 1048320, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, null, null, null, null, null, null, null, null, null, null, null, 1048064, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, null, null, null, null, null, null, null, null, null, null, 1047552, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, null, null, null, null, null, null, null, null, null, 1046528, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, null, null, null, null, null, null, null, null, 1044480, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, null, null, null, null, null, null, null, 1040384, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, null, null, null, null, null, null, 1032192, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, null, null, null, null, null, 1015808, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, null, null, null, null, 983040, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, null, null, null, 917504, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, paramMap2, null, null, 786432, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2, String paramString13) {
    this(paramString1, paramString2, paramString3, paramString4, paramLong1, paramLong2, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramCollection, paramString12, paramMap, paramMap1, paramMap2, paramString13, null, 524288, null);
  }
  
  @VisibleForTesting(otherwise = 2)
  public AuthenticationTokenClaims(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, Collection<String> paramCollection, String paramString12, Map<String, Integer> paramMap, Map<String, String> paramMap1, Map<String, String> paramMap2, String paramString13, String paramString14) {
    Map<?, ?> map;
    Validate.notEmpty(paramString1, "jti");
    Validate.notEmpty(paramString2, "iss");
    Validate.notEmpty(paramString3, "aud");
    Validate.notEmpty(paramString4, "nonce");
    Validate.notEmpty(paramString5, "sub");
    this.jti = paramString1;
    this.iss = paramString2;
    this.aud = paramString3;
    this.nonce = paramString4;
    this.exp = paramLong1;
    this.iat = paramLong2;
    this.sub = paramString5;
    this.name = paramString6;
    this.givenName = paramString7;
    this.middleName = paramString8;
    this.familyName = paramString9;
    this.email = paramString10;
    this.picture = paramString11;
    paramString2 = null;
    if (paramCollection != null) {
      Set<?> set = Collections.unmodifiableSet(new HashSet(paramCollection));
    } else {
      paramString1 = null;
    } 
    this.userFriends = (Set<String>)paramString1;
    this.userBirthday = paramString12;
    if (paramMap != null) {
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap));
    } else {
      paramString1 = null;
    } 
    this.userAgeRange = (Map<String, Integer>)paramString1;
    if (paramMap1 != null) {
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap1));
    } else {
      paramString1 = null;
    } 
    this.userHometown = (Map<String, String>)paramString1;
    paramString1 = paramString2;
    if (paramMap2 != null)
      map = Collections.unmodifiableMap(new HashMap<Object, Object>(paramMap2)); 
    this.userLocation = (Map)map;
    this.userGender = paramString13;
    this.userLink = paramString14;
  }
  
  public static final AuthenticationTokenClaims createFromJSONObject$facebook_core_release(JSONObject paramJSONObject) throws JSONException {
    return Companion.createFromJSONObject$facebook_core_release(paramJSONObject);
  }
  
  private final boolean isValidClaims(JSONObject paramJSONObject, String paramString) {
    boolean bool;
    if (paramJSONObject == null)
      return false; 
    String str = paramJSONObject.optString("jti");
    m.e(str, "jti");
    if (str.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return false; 
    try {
      str = paramJSONObject.optString("iss");
      m.e(str, "iss");
      if (str.length() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        if ((m.a((new URL(str)).getHost(), "facebook.com") ^ true) != 0) {
          boolean bool1 = m.a((new URL(str)).getHost(), "www.facebook.com");
          if ((bool1 ^ true) != 0)
            return false; 
        } 
        str = paramJSONObject.optString("aud");
        m.e(str, "aud");
        if (str.length() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          if ((m.a(str, FacebookSdk.getApplicationId()) ^ true) != 0)
            return false; 
          long l1 = paramJSONObject.optLong("exp");
          long l2 = 1000L;
          Date date = new Date(l1 * l2);
          if ((new Date()).after(date))
            return false; 
          date = new Date(paramJSONObject.optLong("iat") * l2 + 600000L);
          if ((new Date()).after(date))
            return false; 
          String str2 = paramJSONObject.optString("sub");
          m.e(str2, "sub");
          if (str2.length() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool)
            return false; 
          String str1 = paramJSONObject.optString("nonce");
          m.e(str1, "nonce");
          if (str1.length() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          if (!bool)
            return !((m.a(str1, paramString) ^ true) != 0); 
        } 
      } 
      return false;
    } catch (MalformedURLException malformedURLException) {
      return false;
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof AuthenticationTokenClaims))
      return false; 
    String str = this.jti;
    paramObject = paramObject;
    return (m.a(str, ((AuthenticationTokenClaims)paramObject).jti) && m.a(this.iss, ((AuthenticationTokenClaims)paramObject).iss) && m.a(this.aud, ((AuthenticationTokenClaims)paramObject).aud) && m.a(this.nonce, ((AuthenticationTokenClaims)paramObject).nonce) && this.exp == ((AuthenticationTokenClaims)paramObject).exp && this.iat == ((AuthenticationTokenClaims)paramObject).iat && m.a(this.sub, ((AuthenticationTokenClaims)paramObject).sub) && m.a(this.name, ((AuthenticationTokenClaims)paramObject).name) && m.a(this.givenName, ((AuthenticationTokenClaims)paramObject).givenName) && m.a(this.middleName, ((AuthenticationTokenClaims)paramObject).middleName) && m.a(this.familyName, ((AuthenticationTokenClaims)paramObject).familyName) && m.a(this.email, ((AuthenticationTokenClaims)paramObject).email) && m.a(this.picture, ((AuthenticationTokenClaims)paramObject).picture) && m.a(this.userFriends, ((AuthenticationTokenClaims)paramObject).userFriends) && m.a(this.userBirthday, ((AuthenticationTokenClaims)paramObject).userBirthday) && m.a(this.userAgeRange, ((AuthenticationTokenClaims)paramObject).userAgeRange) && m.a(this.userHometown, ((AuthenticationTokenClaims)paramObject).userHometown) && m.a(this.userLocation, ((AuthenticationTokenClaims)paramObject).userLocation) && m.a(this.userGender, ((AuthenticationTokenClaims)paramObject).userGender) && m.a(this.userLink, ((AuthenticationTokenClaims)paramObject).userLink));
  }
  
  public final String getAud() {
    return this.aud;
  }
  
  public final String getEmail() {
    return this.email;
  }
  
  public final long getExp() {
    return this.exp;
  }
  
  public final String getFamilyName() {
    return this.familyName;
  }
  
  public final String getGivenName() {
    return this.givenName;
  }
  
  public final long getIat() {
    return this.iat;
  }
  
  public final String getIss() {
    return this.iss;
  }
  
  public final String getJti() {
    return this.jti;
  }
  
  public final String getMiddleName() {
    return this.middleName;
  }
  
  public final String getName() {
    return this.name;
  }
  
  public final String getNonce() {
    return this.nonce;
  }
  
  public final String getPicture() {
    return this.picture;
  }
  
  public final String getSub() {
    return this.sub;
  }
  
  public final Map<String, Integer> getUserAgeRange() {
    return this.userAgeRange;
  }
  
  public final String getUserBirthday() {
    return this.userBirthday;
  }
  
  public final Set<String> getUserFriends() {
    return this.userFriends;
  }
  
  public final String getUserGender() {
    return this.userGender;
  }
  
  public final Map<String, String> getUserHometown() {
    return this.userHometown;
  }
  
  public final String getUserLink() {
    return this.userLink;
  }
  
  public final Map<String, String> getUserLocation() {
    return this.userLocation;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    byte b5;
    byte b6;
    byte b7;
    byte b8;
    byte b9;
    byte b10;
    byte b11;
    byte b12;
    int j = this.jti.hashCode();
    int k = this.iss.hashCode();
    int m = this.aud.hashCode();
    int n = this.nonce.hashCode();
    int i1 = Long.valueOf(this.exp).hashCode();
    int i2 = Long.valueOf(this.iat).hashCode();
    int i3 = this.sub.hashCode();
    String str3 = this.name;
    int i = 0;
    if (str3 != null) {
      b1 = str3.hashCode();
    } else {
      b1 = 0;
    } 
    str3 = this.givenName;
    if (str3 != null) {
      b2 = str3.hashCode();
    } else {
      b2 = 0;
    } 
    str3 = this.middleName;
    if (str3 != null) {
      b3 = str3.hashCode();
    } else {
      b3 = 0;
    } 
    str3 = this.familyName;
    if (str3 != null) {
      b4 = str3.hashCode();
    } else {
      b4 = 0;
    } 
    str3 = this.email;
    if (str3 != null) {
      b5 = str3.hashCode();
    } else {
      b5 = 0;
    } 
    str3 = this.picture;
    if (str3 != null) {
      b6 = str3.hashCode();
    } else {
      b6 = 0;
    } 
    Set<String> set = this.userFriends;
    if (set != null) {
      b7 = set.hashCode();
    } else {
      b7 = 0;
    } 
    String str2 = this.userBirthday;
    if (str2 != null) {
      b8 = str2.hashCode();
    } else {
      b8 = 0;
    } 
    Map<String, Integer> map1 = this.userAgeRange;
    if (map1 != null) {
      b9 = map1.hashCode();
    } else {
      b9 = 0;
    } 
    Map<String, String> map = this.userHometown;
    if (map != null) {
      b10 = map.hashCode();
    } else {
      b10 = 0;
    } 
    map = this.userLocation;
    if (map != null) {
      b11 = map.hashCode();
    } else {
      b11 = 0;
    } 
    String str1 = this.userGender;
    if (str1 != null) {
      b12 = str1.hashCode();
    } else {
      b12 = 0;
    } 
    str1 = this.userLink;
    if (str1 != null)
      i = str1.hashCode(); 
    return (((((((((((((((((((527 + j) * 31 + k) * 31 + m) * 31 + n) * 31 + i1) * 31 + i2) * 31 + i3) * 31 + b1) * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + b8) * 31 + b9) * 31 + b10) * 31 + b11) * 31 + b12) * 31 + i;
  }
  
  @VisibleForTesting(otherwise = 2)
  public final String toEnCodedString() {
    String str2 = toString();
    Charset charset = d.a;
    Objects.requireNonNull(str2, "null cannot be cast to non-null type java.lang.String");
    byte[] arrayOfByte = str2.getBytes(charset);
    m.e(arrayOfByte, "(this as java.lang.String).getBytes(charset)");
    String str1 = Base64.encodeToString(arrayOfByte, 8);
    m.e(str1, "Base64.encodeToString(cl…Array(), Base64.URL_SAFE)");
    return str1;
  }
  
  @VisibleForTesting(otherwise = 2)
  public final JSONObject toJSONObject$facebook_core_release() {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("jti", this.jti);
    jSONObject.put("iss", this.iss);
    jSONObject.put("aud", this.aud);
    jSONObject.put("nonce", this.nonce);
    jSONObject.put("exp", this.exp);
    jSONObject.put("iat", this.iat);
    String str = this.sub;
    if (str != null)
      jSONObject.put("sub", str); 
    str = this.name;
    if (str != null)
      jSONObject.put("name", str); 
    str = this.givenName;
    if (str != null)
      jSONObject.put("given_name", str); 
    str = this.middleName;
    if (str != null)
      jSONObject.put("middle_name", str); 
    str = this.familyName;
    if (str != null)
      jSONObject.put("family_name", str); 
    str = this.email;
    if (str != null)
      jSONObject.put("email", str); 
    str = this.picture;
    if (str != null)
      jSONObject.put("picture", str); 
    if (this.userFriends != null)
      jSONObject.put("user_friends", new JSONArray(this.userFriends)); 
    str = this.userBirthday;
    if (str != null)
      jSONObject.put("user_birthday", str); 
    if (this.userAgeRange != null)
      jSONObject.put("user_age_range", new JSONObject(this.userAgeRange)); 
    if (this.userHometown != null)
      jSONObject.put("user_hometown", new JSONObject(this.userHometown)); 
    if (this.userLocation != null)
      jSONObject.put("user_location", new JSONObject(this.userLocation)); 
    str = this.userGender;
    if (str != null)
      jSONObject.put("user_gender", str); 
    str = this.userLink;
    if (str != null)
      jSONObject.put("user_link", str); 
    return jSONObject;
  }
  
  public String toString() {
    String str = toJSONObject$facebook_core_release().toString();
    m.e(str, "claimsJsonObject.toString()");
    return str;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    m.f(paramParcel, "dest");
    paramParcel.writeString(this.jti);
    paramParcel.writeString(this.iss);
    paramParcel.writeString(this.aud);
    paramParcel.writeString(this.nonce);
    paramParcel.writeLong(this.exp);
    paramParcel.writeLong(this.iat);
    paramParcel.writeString(this.sub);
    paramParcel.writeString(this.name);
    paramParcel.writeString(this.givenName);
    paramParcel.writeString(this.middleName);
    paramParcel.writeString(this.familyName);
    paramParcel.writeString(this.email);
    paramParcel.writeString(this.picture);
    if (this.userFriends == null) {
      paramParcel.writeStringList(null);
    } else {
      paramParcel.writeStringList(new ArrayList<String>(this.userFriends));
    } 
    paramParcel.writeString(this.userBirthday);
    paramParcel.writeMap(this.userAgeRange);
    paramParcel.writeMap(this.userHometown);
    paramParcel.writeMap(this.userLocation);
    paramParcel.writeString(this.userGender);
    paramParcel.writeString(this.userLink);
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\024\n\002\020\t\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\025\020\035\032\0020\0052\006\020\036\032\0020\037H\001¢\006\002\b J\033\020!\032\004\030\0010\007*\0020\0372\006\020\"\032\0020\007H\000¢\006\002\b#R\026\020\003\032\b\022\004\022\0020\0050\0048\006X\004¢\006\002\n\000R\016\020\006\032\0020\007XT¢\006\002\n\000R\016\020\b\032\0020\007XT¢\006\002\n\000R\016\020\t\032\0020\007XT¢\006\002\n\000R\016\020\n\032\0020\007XT¢\006\002\n\000R\016\020\013\032\0020\007XT¢\006\002\n\000R\016\020\f\032\0020\007XT¢\006\002\n\000R\016\020\r\032\0020\007XT¢\006\002\n\000R\016\020\016\032\0020\007XT¢\006\002\n\000R\016\020\017\032\0020\007XT¢\006\002\n\000R\016\020\020\032\0020\007XT¢\006\002\n\000R\016\020\021\032\0020\007XT¢\006\002\n\000R\016\020\022\032\0020\007XT¢\006\002\n\000R\016\020\023\032\0020\007XT¢\006\002\n\000R\016\020\024\032\0020\007XT¢\006\002\n\000R\016\020\025\032\0020\007XT¢\006\002\n\000R\016\020\026\032\0020\007XT¢\006\002\n\000R\016\020\027\032\0020\007XT¢\006\002\n\000R\016\020\030\032\0020\007XT¢\006\002\n\000R\016\020\031\032\0020\007XT¢\006\002\n\000R\016\020\032\032\0020\007XT¢\006\002\n\000R\016\020\033\032\0020\034XT¢\006\002\n\000¨\006$"}, d2 = {"Lcom/facebook/AuthenticationTokenClaims$Companion;", "", "()V", "CREATOR", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/AuthenticationTokenClaims;", "JSON_KEY_AUD", "", "JSON_KEY_EMAIL", "JSON_KEY_EXP", "JSON_KEY_FAMILY_NAME", "JSON_KEY_GIVEN_NAME", "JSON_KEY_IAT", "JSON_KEY_ISS", "JSON_KEY_JIT", "JSON_KEY_MIDDLE_NAME", "JSON_KEY_NAME", "JSON_KEY_NONCE", "JSON_KEY_PICTURE", "JSON_KEY_SUB", "JSON_KEY_USER_AGE_RANGE", "JSON_KEY_USER_BIRTHDAY", "JSON_KEY_USER_FRIENDS", "JSON_KEY_USER_GENDER", "JSON_KEY_USER_HOMETOWN", "JSON_KEY_USER_LINK", "JSON_KEY_USER_LOCATION", "MAX_TIME_SINCE_TOKEN_ISSUED", "", "createFromJSONObject", "jsonObject", "Lorg/json/JSONObject;", "createFromJSONObject$facebook_core_release", "getNullableString", "name", "getNullableString$facebook_core_release", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    public final AuthenticationTokenClaims createFromJSONObject$facebook_core_release(JSONObject param1JSONObject) throws JSONException {
      List<String> list;
      Map<String, Integer> map;
      Map<String, String> map1;
      m.f(param1JSONObject, "jsonObject");
      String str1 = param1JSONObject.getString("jti");
      String str2 = param1JSONObject.getString("iss");
      String str3 = param1JSONObject.getString("aud");
      String str4 = param1JSONObject.getString("nonce");
      long l1 = param1JSONObject.getLong("exp");
      long l2 = param1JSONObject.getLong("iat");
      String str5 = param1JSONObject.getString("sub");
      String str6 = getNullableString$facebook_core_release(param1JSONObject, "name");
      String str7 = getNullableString$facebook_core_release(param1JSONObject, "given_name");
      String str8 = getNullableString$facebook_core_release(param1JSONObject, "middle_name");
      String str9 = getNullableString$facebook_core_release(param1JSONObject, "family_name");
      String str10 = getNullableString$facebook_core_release(param1JSONObject, "email");
      String str11 = getNullableString$facebook_core_release(param1JSONObject, "picture");
      JSONArray jSONArray = param1JSONObject.optJSONArray("user_friends");
      String str12 = getNullableString$facebook_core_release(param1JSONObject, "user_birthday");
      JSONObject jSONObject1 = param1JSONObject.optJSONObject("user_age_range");
      JSONObject jSONObject2 = param1JSONObject.optJSONObject("user_hometown");
      JSONObject jSONObject3 = param1JSONObject.optJSONObject("user_location");
      String str13 = getNullableString$facebook_core_release(param1JSONObject, "user_gender");
      String str14 = getNullableString$facebook_core_release(param1JSONObject, "user_link");
      m.e(str1, "jti");
      m.e(str2, "iss");
      m.e(str3, "aud");
      m.e(str4, "nonce");
      m.e(str5, "sub");
      Map<String, String> map2 = null;
      if (jSONArray == null) {
        param1JSONObject = null;
      } else {
        list = Utility.jsonArrayToStringList(jSONArray);
      } 
      if (jSONObject1 == null) {
        jSONObject1 = null;
      } else {
        map = Utility.convertJSONObjectToHashMap(jSONObject1);
      } 
      if (jSONObject2 == null) {
        jSONObject2 = null;
      } else {
        map1 = Utility.convertJSONObjectToStringMap(jSONObject2);
      } 
      if (jSONObject3 != null)
        map2 = Utility.convertJSONObjectToStringMap(jSONObject3); 
      return new AuthenticationTokenClaims(str1, str2, str3, str4, l1, l2, str5, str6, str7, str8, str9, str10, str11, list, str12, map, map1, map2, str13, str14);
    }
    
    public final String getNullableString$facebook_core_release(JSONObject param1JSONObject, String param1String) {
      m.f(param1JSONObject, "$this$getNullableString");
      m.f(param1String, "name");
      return param1JSONObject.has(param1String) ? param1JSONObject.getString(param1String) : null;
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\021\n\000\n\002\020\b\n\002\b\002*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\020\020\003\032\0020\0022\006\020\004\032\0020\005H\026J\035\020\006\032\n\022\006\022\004\030\0010\0020\0072\006\020\b\032\0020\tH\026¢\006\002\020\n¨\006\013"}, d2 = {"com/facebook/AuthenticationTokenClaims$Companion$CREATOR$1", "Landroid/os/Parcelable$Creator;", "Lcom/facebook/AuthenticationTokenClaims;", "createFromParcel", "source", "Landroid/os/Parcel;", "newArray", "", "size", "", "(I)[Lcom/facebook/AuthenticationTokenClaims;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class AuthenticationTokenClaims$Companion$CREATOR$1 implements Parcelable.Creator<AuthenticationTokenClaims> {
    public AuthenticationTokenClaims createFromParcel(Parcel param1Parcel) {
      m.f(param1Parcel, "source");
      return new AuthenticationTokenClaims(param1Parcel);
    }
    
    public AuthenticationTokenClaims[] newArray(int param1Int) {
      return new AuthenticationTokenClaims[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\AuthenticationTokenClaims.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */