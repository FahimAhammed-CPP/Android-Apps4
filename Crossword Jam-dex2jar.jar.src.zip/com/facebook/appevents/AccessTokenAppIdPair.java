package com.facebook.appevents;

import androidx.annotation.RestrictTo;
import com.facebook.AccessToken;
import com.facebook.FacebookSdk;
import com.facebook.internal.Utility;
import java.io.ObjectStreamException;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.d0.d.g;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\006\n\002\020\013\n\000\n\002\020\000\n\000\n\002\020\b\n\002\b\004\b\007\030\000 \0232\0020\001:\002\023\024B\017\b\026\022\006\020\002\032\0020\003¢\006\002\020\004B\027\022\b\020\005\032\004\030\0010\006\022\006\020\007\032\0020\006¢\006\002\020\bJ\023\020\f\032\0020\r2\b\020\016\032\004\030\0010\017H\002J\b\020\020\032\0020\021H\026J\b\020\022\032\0020\017H\002R\023\020\005\032\004\030\0010\006¢\006\b\n\000\032\004\b\t\020\nR\021\020\007\032\0020\006¢\006\b\n\000\032\004\b\013\020\n¨\006\025"}, d2 = {"Lcom/facebook/appevents/AccessTokenAppIdPair;", "Ljava/io/Serializable;", "accessToken", "Lcom/facebook/AccessToken;", "(Lcom/facebook/AccessToken;)V", "accessTokenString", "", "applicationId", "(Ljava/lang/String;Ljava/lang/String;)V", "getAccessTokenString", "()Ljava/lang/String;", "getApplicationId", "equals", "", "o", "", "hashCode", "", "writeReplace", "Companion", "SerializationProxyV1", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class AccessTokenAppIdPair implements Serializable {
  public static final Companion Companion = new Companion(null);
  
  private static final long serialVersionUID = 1L;
  
  private final String accessTokenString;
  
  private final String applicationId;
  
  public AccessTokenAppIdPair(AccessToken paramAccessToken) {
    this(paramAccessToken.getToken(), FacebookSdk.getApplicationId());
  }
  
  public AccessTokenAppIdPair(String paramString1, String paramString2) {
    this.applicationId = paramString2;
    paramString2 = paramString1;
    if (Utility.isNullOrEmpty(paramString1))
      paramString2 = null; 
    this.accessTokenString = paramString2;
  }
  
  private final Object writeReplace() throws ObjectStreamException {
    return new SerializationProxyV1(this.accessTokenString, this.applicationId);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof AccessTokenAppIdPair;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (Utility.areObjectsEqual(((AccessTokenAppIdPair)paramObject).accessTokenString, this.accessTokenString)) {
      bool = bool1;
      if (Utility.areObjectsEqual(((AccessTokenAppIdPair)paramObject).applicationId, this.applicationId))
        bool = true; 
    } 
    return bool;
  }
  
  public final String getAccessTokenString() {
    return this.accessTokenString;
  }
  
  public final String getApplicationId() {
    return this.applicationId;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.accessTokenString;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool ^ this.applicationId.hashCode();
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/appevents/AccessTokenAppIdPair$Companion;", "", "()V", "serialVersionUID", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\020\000\n\002\b\002\b\000\030\000 \b2\0020\001:\001\bB\027\022\b\020\002\032\004\030\0010\003\022\006\020\004\032\0020\003¢\006\002\020\005J\b\020\006\032\0020\007H\002R\020\020\002\032\004\030\0010\003X\004¢\006\002\n\000R\016\020\004\032\0020\003X\004¢\006\002\n\000¨\006\t"}, d2 = {"Lcom/facebook/appevents/AccessTokenAppIdPair$SerializationProxyV1;", "Ljava/io/Serializable;", "accessTokenString", "", "appId", "(Ljava/lang/String;Ljava/lang/String;)V", "readResolve", "", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class SerializationProxyV1 implements Serializable {
    public static final Companion Companion = new Companion(null);
    
    private static final long serialVersionUID = -2488473066578201069L;
    
    private final String accessTokenString;
    
    private final String appId;
    
    public SerializationProxyV1(String param1String1, String param1String2) {
      this.accessTokenString = param1String1;
      this.appId = param1String2;
    }
    
    private final Object readResolve() throws ObjectStreamException {
      return new AccessTokenAppIdPair(this.accessTokenString, this.appId);
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/appevents/AccessTokenAppIdPair$SerializationProxyV1$Companion;", "", "()V", "serialVersionUID", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Lcom/facebook/appevents/AccessTokenAppIdPair$SerializationProxyV1$Companion;", "", "()V", "serialVersionUID", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\appevents\AccessTokenAppIdPair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */