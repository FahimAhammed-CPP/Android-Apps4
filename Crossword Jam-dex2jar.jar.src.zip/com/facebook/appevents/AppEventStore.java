package com.facebook.appevents;

import android.content.Context;
import com.facebook.FacebookSdk;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.m;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\bÁ\002\030\0002\0020\001:\001\022B\007\b\002¢\006\002\020\002J\030\020\006\032\0020\0072\006\020\b\032\0020\t2\006\020\n\032\0020\013H\007J\020\020\006\032\0020\0072\006\020\f\032\0020\rH\007J\b\020\016\032\0020\017H\007J\027\020\020\032\0020\0072\b\020\f\032\004\030\0010\017H\001¢\006\002\b\021R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004X\004¢\006\002\n\000¨\006\023"}, d2 = {"Lcom/facebook/appevents/AppEventStore;", "", "()V", "PERSISTED_EVENTS_FILENAME", "", "TAG", "persistEvents", "", "accessTokenAppIdPair", "Lcom/facebook/appevents/AccessTokenAppIdPair;", "appEvents", "Lcom/facebook/appevents/SessionEventsState;", "eventsToPersist", "Lcom/facebook/appevents/AppEventCollection;", "readAndClearStore", "Lcom/facebook/appevents/PersistedEvents;", "saveEventsToDisk", "saveEventsToDisk$facebook_core_release", "MovedClassObjectInputStream", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AppEventStore {
  public static final AppEventStore INSTANCE = new AppEventStore();
  
  private static final String PERSISTED_EVENTS_FILENAME = "AppEventsLogger.persistedevents";
  
  private static final String TAG;
  
  static {
    String str = AppEventStore.class.getName();
    m.e(str, "AppEventStore::class.java.name");
    TAG = str;
  }
  
  public static final void persistEvents(AccessTokenAppIdPair paramAccessTokenAppIdPair, SessionEventsState paramSessionEventsState) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'accessTokenAppIdPair'
    //   20: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_1
    //   24: ldc 'appEvents'
    //   26: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   29: invokestatic assertIsNotMainThread : ()V
    //   32: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   35: astore_3
    //   36: aload_3
    //   37: aload_0
    //   38: aload_1
    //   39: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   42: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   45: aload_3
    //   46: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   49: ldc com/facebook/appevents/AppEventStore
    //   51: monitorexit
    //   52: return
    //   53: astore_0
    //   54: aload_0
    //   55: ldc com/facebook/appevents/AppEventStore
    //   57: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   60: ldc com/facebook/appevents/AppEventStore
    //   62: monitorexit
    //   63: return
    //   64: astore_0
    //   65: ldc com/facebook/appevents/AppEventStore
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	64	finally
    //   17	49	53	finally
    //   54	60	64	finally
  }
  
  public static final void persistEvents(AppEventCollection paramAppEventCollection) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_1
    //   9: iload_1
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'eventsToPersist'
    //   20: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: invokestatic assertIsNotMainThread : ()V
    //   26: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   29: astore_2
    //   30: aload_0
    //   31: invokevirtual keySet : ()Ljava/util/Set;
    //   34: invokeinterface iterator : ()Ljava/util/Iterator;
    //   39: astore_3
    //   40: aload_3
    //   41: invokeinterface hasNext : ()Z
    //   46: ifeq -> 100
    //   49: aload_3
    //   50: invokeinterface next : ()Ljava/lang/Object;
    //   55: checkcast com/facebook/appevents/AccessTokenAppIdPair
    //   58: astore #4
    //   60: aload_0
    //   61: aload #4
    //   63: invokevirtual get : (Lcom/facebook/appevents/AccessTokenAppIdPair;)Lcom/facebook/appevents/SessionEventsState;
    //   66: astore #5
    //   68: aload #5
    //   70: ifnull -> 87
    //   73: aload_2
    //   74: aload #4
    //   76: aload #5
    //   78: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   81: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   84: goto -> 40
    //   87: new java/lang/IllegalStateException
    //   90: dup
    //   91: ldc 'Required value was null.'
    //   93: invokevirtual toString : ()Ljava/lang/String;
    //   96: invokespecial <init> : (Ljava/lang/String;)V
    //   99: athrow
    //   100: aload_2
    //   101: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   104: ldc com/facebook/appevents/AppEventStore
    //   106: monitorexit
    //   107: return
    //   108: astore_0
    //   109: aload_0
    //   110: ldc com/facebook/appevents/AppEventStore
    //   112: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   115: ldc com/facebook/appevents/AppEventStore
    //   117: monitorexit
    //   118: return
    //   119: astore_0
    //   120: ldc com/facebook/appevents/AppEventStore
    //   122: monitorexit
    //   123: aload_0
    //   124: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	119	finally
    //   17	40	108	finally
    //   40	68	108	finally
    //   73	84	108	finally
    //   87	100	108	finally
    //   100	104	108	finally
    //   109	115	119	finally
  }
  
  public static final PersistedEvents readAndClearStore() {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_0
    //   9: iload_0
    //   10: ifeq -> 18
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: aconst_null
    //   17: areturn
    //   18: invokestatic assertIsNotMainThread : ()V
    //   21: invokestatic getApplicationContext : ()Landroid/content/Context;
    //   24: astore #4
    //   26: aload #4
    //   28: ldc 'AppEventsLogger.persistedevents'
    //   30: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   33: astore_1
    //   34: aload_1
    //   35: ldc 'context.openFileInput(PERSISTED_EVENTS_FILENAME)'
    //   37: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   40: new com/facebook/appevents/AppEventStore$MovedClassObjectInputStream
    //   43: dup
    //   44: new java/io/BufferedInputStream
    //   47: dup
    //   48: aload_1
    //   49: invokespecial <init> : (Ljava/io/InputStream;)V
    //   52: invokespecial <init> : (Ljava/io/InputStream;)V
    //   55: astore_2
    //   56: aload_2
    //   57: astore_1
    //   58: aload_2
    //   59: invokevirtual readObject : ()Ljava/lang/Object;
    //   62: astore_3
    //   63: aload_3
    //   64: ifnull -> 110
    //   67: aload_2
    //   68: astore_1
    //   69: aload_3
    //   70: checkcast com/facebook/appevents/PersistedEvents
    //   73: astore_3
    //   74: aload_2
    //   75: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   78: aload #4
    //   80: ldc 'AppEventsLogger.persistedevents'
    //   82: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   85: invokevirtual delete : ()Z
    //   88: pop
    //   89: aload_3
    //   90: astore_1
    //   91: goto -> 238
    //   94: astore_1
    //   95: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   98: ldc 'Got unexpected exception when removing events file: '
    //   100: aload_1
    //   101: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   104: pop
    //   105: aload_3
    //   106: astore_1
    //   107: goto -> 238
    //   110: aload_2
    //   111: astore_1
    //   112: new java/lang/NullPointerException
    //   115: dup
    //   116: ldc 'null cannot be cast to non-null type com.facebook.appevents.PersistedEvents'
    //   118: invokespecial <init> : (Ljava/lang/String;)V
    //   121: athrow
    //   122: astore_3
    //   123: goto -> 135
    //   126: astore_2
    //   127: aconst_null
    //   128: astore_1
    //   129: goto -> 181
    //   132: astore_3
    //   133: aconst_null
    //   134: astore_2
    //   135: aload_2
    //   136: astore_1
    //   137: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   140: ldc 'Got unexpected exception while reading events: '
    //   142: aload_3
    //   143: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   146: pop
    //   147: aload_2
    //   148: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   151: aload #4
    //   153: ldc 'AppEventsLogger.persistedevents'
    //   155: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   158: invokevirtual delete : ()Z
    //   161: pop
    //   162: goto -> 292
    //   165: astore_1
    //   166: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   169: astore_2
    //   170: aload_2
    //   171: ldc 'Got unexpected exception when removing events file: '
    //   173: aload_1
    //   174: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   177: pop
    //   178: goto -> 292
    //   181: aload_1
    //   182: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   185: aload #4
    //   187: ldc 'AppEventsLogger.persistedevents'
    //   189: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   192: invokevirtual delete : ()Z
    //   195: pop
    //   196: goto -> 210
    //   199: astore_1
    //   200: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   203: ldc 'Got unexpected exception when removing events file: '
    //   205: aload_1
    //   206: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   209: pop
    //   210: aload_2
    //   211: athrow
    //   212: aload_2
    //   213: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   216: aload #4
    //   218: ldc 'AppEventsLogger.persistedevents'
    //   220: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   223: invokevirtual delete : ()Z
    //   226: pop
    //   227: goto -> 292
    //   230: astore_1
    //   231: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   234: astore_2
    //   235: goto -> 170
    //   238: aload_1
    //   239: astore_2
    //   240: aload_1
    //   241: ifnonnull -> 252
    //   244: new com/facebook/appevents/PersistedEvents
    //   247: dup
    //   248: invokespecial <init> : ()V
    //   251: astore_2
    //   252: ldc com/facebook/appevents/AppEventStore
    //   254: monitorexit
    //   255: aload_2
    //   256: areturn
    //   257: astore_1
    //   258: aload_1
    //   259: ldc com/facebook/appevents/AppEventStore
    //   261: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   264: ldc com/facebook/appevents/AppEventStore
    //   266: monitorexit
    //   267: aconst_null
    //   268: areturn
    //   269: astore_1
    //   270: ldc com/facebook/appevents/AppEventStore
    //   272: monitorexit
    //   273: aload_1
    //   274: athrow
    //   275: astore_1
    //   276: goto -> 287
    //   279: astore_1
    //   280: goto -> 212
    //   283: astore_2
    //   284: goto -> 181
    //   287: aconst_null
    //   288: astore_2
    //   289: goto -> 212
    //   292: aconst_null
    //   293: astore_1
    //   294: goto -> 238
    // Exception table:
    //   from	to	target	type
    //   3	9	269	finally
    //   18	26	257	finally
    //   26	56	275	java/io/FileNotFoundException
    //   26	56	132	java/lang/Exception
    //   26	56	126	finally
    //   58	63	279	java/io/FileNotFoundException
    //   58	63	122	java/lang/Exception
    //   58	63	283	finally
    //   69	74	279	java/io/FileNotFoundException
    //   69	74	122	java/lang/Exception
    //   69	74	283	finally
    //   74	78	257	finally
    //   78	89	94	java/lang/Exception
    //   78	89	257	finally
    //   95	105	257	finally
    //   112	122	279	java/io/FileNotFoundException
    //   112	122	122	java/lang/Exception
    //   112	122	283	finally
    //   137	147	283	finally
    //   147	151	257	finally
    //   151	162	165	java/lang/Exception
    //   151	162	257	finally
    //   166	170	257	finally
    //   170	178	257	finally
    //   181	185	257	finally
    //   185	196	199	java/lang/Exception
    //   185	196	257	finally
    //   200	210	257	finally
    //   210	212	257	finally
    //   212	216	257	finally
    //   216	227	230	java/lang/Exception
    //   216	227	257	finally
    //   231	235	257	finally
    //   244	252	257	finally
    //   258	264	269	finally
  }
  
  public static final void saveEventsToDisk$facebook_core_release(PersistedEvents paramPersistedEvents) {
    if (CrashShieldHandler.isObjectCrashing(AppEventStore.class))
      return; 
    Exception exception = null;
    try {
      Exception exception1;
      Context context = FacebookSdk.getApplicationContext();
    } finally {
      paramPersistedEvents = null;
      CrashShieldHandler.handleThrowable((Throwable)paramPersistedEvents, AppEventStore.class);
    } 
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\b\002\030\000 \0072\0020\001:\001\007B\017\022\b\020\002\032\004\030\0010\003¢\006\002\020\004J\b\020\005\032\0020\006H\024¨\006\b"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream;", "Ljava/io/ObjectInputStream;", "inputStream", "Ljava/io/InputStream;", "(Ljava/io/InputStream;)V", "readClassDescriptor", "Ljava/io/ObjectStreamClass;", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class MovedClassObjectInputStream extends ObjectInputStream {
    static {
      new Companion(null);
    }
    
    public MovedClassObjectInputStream(InputStream param1InputStream) {
      super(param1InputStream);
    }
    
    protected ObjectStreamClass readClassDescriptor() throws IOException, ClassNotFoundException {
      ObjectStreamClass objectStreamClass1;
      ObjectStreamClass objectStreamClass2 = super.readClassDescriptor();
      m.e(objectStreamClass2, "resultClassDescriptor");
      if (m.a(objectStreamClass2.getName(), "com.facebook.appevents.AppEventsLogger$AccessTokenAppIdPair$SerializationProxyV1")) {
        objectStreamClass1 = ObjectStreamClass.lookup(AccessTokenAppIdPair.SerializationProxyV1.class);
      } else {
        objectStreamClass1 = objectStreamClass2;
        if (m.a(objectStreamClass2.getName(), "com.facebook.appevents.AppEventsLogger$AppEvent$SerializationProxyV2"))
          objectStreamClass1 = ObjectStreamClass.lookup(AppEvent.SerializationProxyV2.class); 
      } 
      m.e(objectStreamClass1, "resultClassDescriptor");
      return objectStreamClass1;
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream$Companion;", "", "()V", "ACCESS_TOKEN_APP_ID_PAIR_SERIALIZATION_PROXY_V1_CLASS_NAME", "", "APP_EVENT_SERIALIZATION_PROXY_V1_CLASS_NAME", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream$Companion;", "", "()V", "ACCESS_TOKEN_APP_ID_PAIR_SERIALIZATION_PROXY_V1_CLASS_NAME", "", "APP_EVENT_SERIALIZATION_PROXY_V1_CLASS_NAME", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\appevents\AppEventStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */