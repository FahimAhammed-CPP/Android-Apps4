package com.facebook.appevents.iap;

import android.content.Context;
import androidx.annotation.RestrictTo;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import kotlin.Metadata;
import kotlin.d0.d.m;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\005\032\0020\006H\002J\020\020\007\032\0020\0062\006\020\b\032\0020\tH\007R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\n"}, d2 = {"Lcom/facebook/appevents/iap/InAppPurchaseAutoLogger;", "", "()V", "BILLING_CLIENT_PURCHASE_NAME", "", "logPurchase", "", "startIapLogging", "context", "Landroid/content/Context;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class InAppPurchaseAutoLogger {
  private static final String BILLING_CLIENT_PURCHASE_NAME = "com.android.billingclient.api.Purchase";
  
  public static final InAppPurchaseAutoLogger INSTANCE = new InAppPurchaseAutoLogger();
  
  private final void logPurchase() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      InAppPurchaseBillingClientWrapper.Companion companion = InAppPurchaseBillingClientWrapper.Companion;
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public static final void startIapLogging(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(InAppPurchaseAutoLogger.class))
      return; 
    try {
      m.f(paramContext, "context");
      if (InAppPurchaseUtils.getClass("com.android.billingclient.api.Purchase") == null)
        return; 
      InAppPurchaseBillingClientWrapper.Companion companion = InAppPurchaseBillingClientWrapper.Companion;
      return;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, InAppPurchaseAutoLogger.class);
    } 
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class a implements Runnable {
    public static final a b = new a();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        return;
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class b implements Runnable {
    public static final b b = new b();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        return;
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\facebook\appevents\iap\InAppPurchaseAutoLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */