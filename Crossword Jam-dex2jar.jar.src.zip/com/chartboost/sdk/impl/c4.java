package com.chartboost.sdk.impl;

import android.os.Build;
import com.chartboost.sdk.internal.Model.CBError;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.d0.c.l;
import kotlin.d0.d.m;
import kotlin.w;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(bv = {}, d1 = {"\000L\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\013\n\002\030\002\n\002\b\004\030\0002\0020\001B\037\022\006\020\r\032\0020\f\022\006\020\022\032\0020\021\022\006\020\027\032\0020\026¢\006\004\b\030\020\031J3\020\013\032\0020\t2\006\020\003\032\0020\0022!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\026J;\020\013\032\0020\t2\006\020\003\032\0020\0022\006\020\r\032\0020\f2!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\002J;\020\013\032\0020\t2\006\020\016\032\0020\0022\006\020\020\032\0020\0172!\020\n\032\035\022\023\022\0210\005¢\006\f\b\006\022\b\b\007\022\004\b\b(\b\022\004\022\0020\t0\004H\002J \020\013\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0172\006\020\n\032\0020\024H\002J\020\020\013\032\0020\0252\006\020\003\032\0020\002H\002¨\006\032"}, d2 = {"Lcom/chartboost/sdk/impl/c4;", "Lcom/chartboost/sdk/impl/g;", "Lcom/chartboost/sdk/impl/p3;", "params", "Lkotlin/Function1;", "Lcom/chartboost/sdk/impl/q3;", "Lkotlin/ParameterName;", "name", "result", "", "callback", "a", "Lcom/chartboost/sdk/impl/g3;", "impressionAdType", "loaderParams", "Lcom/chartboost/sdk/impl/k;", "openRTBAdUnit", "Lcom/chartboost/sdk/impl/n2;", "downloader", "openRTB", "Lcom/chartboost/sdk/impl/l0;", "", "Lcom/chartboost/sdk/impl/y3;", "openRTBAdUnitParser", "<init>", "(Lcom/chartboost/sdk/impl/g3;Lcom/chartboost/sdk/impl/n2;Lcom/chartboost/sdk/impl/y3;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class c4 implements g {
  public final g3 a;
  
  public final n2 b;
  
  public final y3 c;
  
  public c4(g3 paramg3, n2 paramn2, y3 paramy3) {
    this.a = paramg3;
    this.b = paramn2;
    this.c = paramy3;
  }
  
  public static final void a(l paraml, p3 paramp3, k paramk, c4 paramc4, boolean paramBoolean) {
    m.f(paraml, "$callback");
    m.f(paramp3, "$loaderParams");
    m.f(paramk, "$openRTBAdUnit");
    m.f(paramc4, "this$0");
    if (paramBoolean) {
      paraml.invoke(new q3(paramp3.a(), paramk, null, 0L, 0L, 24, null));
      return;
    } 
    r2.d((r5)new h2("cache_asset_download_error", CBError.CBImpressionError.ASSETS_DOWNLOAD_FAILURE.name(), paramc4.a.b(), paramp3.a().d()));
    paraml.invoke(new q3(paramp3.a(), null, new CBError(CBError.b.c, "Error parsing response"), 0L, 0L, 26, null));
  }
  
  public final void a(n2 paramn2, k paramk, l0 paraml0) {
    Map map = paramk.d();
    AtomicInteger atomicInteger = new AtomicInteger();
    paramn2.a(g4.c, map, atomicInteger, paraml0, this.a.b());
  }
  
  public final void a(p3 paramp3, g3 paramg3, l<? super q3, w> paraml) {
    if (Build.VERSION.SDK_INT < 21) {
      paraml.invoke(new q3(paramp3.a(), null, new CBError(CBError.b.d, "No ad found"), 0L, 0L, 26, null));
      return;
    } 
    if (!a(paramp3)) {
      r2.d((r5)new h2("cache_bid_response_parsing_error", "Invalid bid response", paramg3.b(), paramp3.a().d()));
      paraml.invoke(new q3(paramp3.a(), null, new CBError(CBError.b.d, "Error parsing response"), 0L, 0L, 26, null));
      return;
    } 
    try {
      String str = paramp3.a().c();
      if (str != null) {
        JSONObject jSONObject = new JSONObject(str);
      } else {
        str = null;
      } 
      y3 y31 = this.c;
      try {
        k k = y31.a(paramg3, (JSONObject)str);
        a(paramp3, k, paraml);
        return;
      } catch (JSONException null) {}
    } catch (JSONException jSONException) {}
    r2.d((r5)new h2("cache_bid_response_parsing_error", jSONException.toString(), paramg3.b(), paramp3.a().d()));
    paraml.invoke(new q3(paramp3.a(), null, new CBError(CBError.b.c, "Error parsing response"), 0L, 0L, 26, null));
  }
  
  public final void a(p3 paramp3, k paramk, l<? super q3, w> paraml) {
    a(this.b, paramk, (l0)new s7(paraml, paramp3, paramk, this));
  }
  
  public void a(p3 paramp3, l<? super q3, w> paraml) {
    m.f(paramp3, "params");
    m.f(paraml, "callback");
    a(paramp3, this.a, paraml);
  }
  
  public final boolean a(p3 paramp3) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual a : ()Lcom/chartboost/sdk/impl/h0;
    //   4: invokevirtual d : ()Ljava/lang/String;
    //   7: invokeinterface length : ()I
    //   12: istore_2
    //   13: iconst_0
    //   14: istore #4
    //   16: iload_2
    //   17: ifle -> 25
    //   20: iconst_1
    //   21: istore_2
    //   22: goto -> 27
    //   25: iconst_0
    //   26: istore_2
    //   27: iload #4
    //   29: istore_3
    //   30: iload_2
    //   31: ifeq -> 83
    //   34: aload_1
    //   35: invokevirtual a : ()Lcom/chartboost/sdk/impl/h0;
    //   38: invokevirtual c : ()Ljava/lang/String;
    //   41: astore_1
    //   42: aload_1
    //   43: ifnull -> 72
    //   46: aload_1
    //   47: invokeinterface length : ()I
    //   52: ifle -> 60
    //   55: iconst_1
    //   56: istore_2
    //   57: goto -> 62
    //   60: iconst_0
    //   61: istore_2
    //   62: iload_2
    //   63: iconst_1
    //   64: if_icmpne -> 72
    //   67: iconst_1
    //   68: istore_2
    //   69: goto -> 74
    //   72: iconst_0
    //   73: istore_2
    //   74: iload #4
    //   76: istore_3
    //   77: iload_2
    //   78: ifeq -> 83
    //   81: iconst_1
    //   82: istore_3
    //   83: iload_3
    //   84: ireturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */