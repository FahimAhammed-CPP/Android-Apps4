package com.chartboost.sdk.impl;

import kotlin.Metadata;
import kotlin.d0.d.m;

@Metadata(bv = {}, d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\020\016\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\002\b\016\b\b\030\0002\0020\001B!\022\b\020\t\032\004\030\0010\002\022\006\020\r\032\0020\007\022\006\020\021\032\0020\002¢\006\004\b\023\020\024J\t\020\003\032\0020\002HÖ\001J\t\020\005\032\0020\004HÖ\001J\023\020\b\032\0020\0072\b\020\006\032\004\030\0010\001HÖ\003R\031\020\t\032\004\030\0010\0028\006¢\006\f\n\004\b\t\020\n\032\004\b\013\020\fR\027\020\r\032\0020\0078\006¢\006\f\n\004\b\r\020\016\032\004\b\017\020\020R\027\020\021\032\0020\0028\006¢\006\f\n\004\b\021\020\n\032\004\b\022\020\f¨\006\025"}, d2 = {"Lcom/chartboost/sdk/impl/e2;", "", "", "toString", "", "hashCode", "other", "", "equals", "configVariant", "Ljava/lang/String;", "a", "()Ljava/lang/String;", "webViewEnabled", "Z", "b", "()Z", "webViewVersion", "c", "<init>", "(Ljava/lang/String;ZLjava/lang/String;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class e2 {
  public final String a;
  
  public final boolean b;
  
  public final String c;
  
  public e2(String paramString1, boolean paramBoolean, String paramString2) {
    this.a = paramString1;
    this.b = paramBoolean;
    this.c = paramString2;
  }
  
  public final String a() {
    return this.a;
  }
  
  public final boolean b() {
    return this.b;
  }
  
  public final String c() {
    return this.c;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof e2))
      return false; 
    paramObject = paramObject;
    return !m.a(this.a, ((e2)paramObject).a) ? false : ((this.b != ((e2)paramObject).b) ? false : (!!m.a(this.c, ((e2)paramObject).c)));
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ConfigurationBodyFields(configVariant=");
    stringBuilder.append(this.a);
    stringBuilder.append(", webViewEnabled=");
    stringBuilder.append(this.b);
    stringBuilder.append(", webViewVersion=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */