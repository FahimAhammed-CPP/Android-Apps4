package com.chartboost.sdk.impl;

import com.chartboost.sdk.privacy.model.DataUseConsent;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class b3 {
  public JSONObject a(List<DataUseConsent> paramList) {
    JSONObject jSONObject = new JSONObject();
    for (DataUseConsent dataUseConsent : paramList) {
      String str = dataUseConsent.getPrivacyStandard();
      Object object = dataUseConsent.getConsent();
      try {
        jSONObject.put(str, object);
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      } 
    } 
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\b3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */