package com.chartboost.sdk.impl;

public class f1 {
  public final int a;
  
  public final byte[] b;
  
  public f1(int paramInt, byte[] paramArrayOfbyte) {
    this.a = paramInt;
    this.b = paramArrayOfbyte;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */