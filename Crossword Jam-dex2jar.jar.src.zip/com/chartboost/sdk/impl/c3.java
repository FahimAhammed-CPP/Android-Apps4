package com.chartboost.sdk.impl;

import androidx.annotation.NonNull;
import com.chartboost.sdk.privacy.model.DataUseConsent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class c3 {
  public final l4 a;
  
  public c3(l4 paraml4) {
    this.a = paraml4;
  }
  
  public List<DataUseConsent> a(b5.b paramb) {
    HashMap<String, DataUseConsent> hashMap = this.a.a();
    List<DataUseConsent> list = a(hashMap);
    ArrayList<DataUseConsent> arrayList = new ArrayList();
    HashSet<String> hashSet = b(paramb);
    if (hashSet != null) {
      for (DataUseConsent dataUseConsent : list) {
        if (a(hashSet, dataUseConsent))
          arrayList.add(dataUseConsent); 
      } 
    } else {
      if (hashMap.containsKey("us_privacy"))
        arrayList.add(hashMap.get("us_privacy")); 
      if (hashMap.containsKey("coppa"))
        arrayList.add(hashMap.get("coppa")); 
    } 
    return arrayList;
  }
  
  public final List<DataUseConsent> a(HashMap<String, DataUseConsent> paramHashMap) {
    paramHashMap = new HashMap<String, DataUseConsent>(paramHashMap);
    paramHashMap.remove("gdpr");
    return new ArrayList<DataUseConsent>(paramHashMap.values());
  }
  
  public final boolean a(@NonNull HashSet<String> paramHashSet, @NonNull DataUseConsent paramDataUseConsent) {
    if (paramHashSet.contains(paramDataUseConsent.getPrivacyStandard()))
      return true; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DataUseConsent ");
    stringBuilder.append(paramDataUseConsent.getPrivacyStandard());
    stringBuilder.append(" is not whitelisted.");
    r3.e("Chartboost", stringBuilder.toString());
    return false;
  }
  
  public final HashSet<String> b(b5.b paramb) {
    return (paramb != null) ? paramb.a() : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */