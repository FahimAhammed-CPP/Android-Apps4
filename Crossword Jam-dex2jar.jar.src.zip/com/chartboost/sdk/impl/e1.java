package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;

public class e1<T> {
  public final T a;
  
  public final CBError b;
  
  public e1(T paramT, CBError paramCBError) {
    this.a = paramT;
    this.b = paramCBError;
  }
  
  public static <T> e1<T> a(CBError paramCBError) {
    return new e1<T>(null, paramCBError);
  }
  
  public static <T> e1<T> a(T paramT) {
    return new e1<T>(paramT, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */