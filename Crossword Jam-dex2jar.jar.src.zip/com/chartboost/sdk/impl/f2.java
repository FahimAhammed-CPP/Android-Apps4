package com.chartboost.sdk.impl;

import kotlin.Metadata;

@Metadata(bv = {}, d1 = {"\000\020\n\002\030\002\n\002\020\020\n\002\020\b\n\002\b\013\b\001\030\0002\b\022\004\022\0020\0000\001B\021\b\002\022\006\020\003\032\0020\002¢\006\004\b\007\020\bR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\004\032\004\b\005\020\006j\002\b\tj\002\b\nj\002\b\013j\002\b\f¨\006\r"}, d2 = {"Lcom/chartboost/sdk/impl/f2;", "", "", "value", "I", "b", "()I", "<init>", "(Ljava/lang/String;II)V", "CONNECTION_UNKNOWN", "CONNECTION_ERROR", "CONNECTION_WIFI", "CONNECTION_MOBILE", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public enum f2 {
  b(-1),
  c(0),
  d(1),
  e(2);
  
  public final int a;
  
  f2(int paramInt1) {
    this.a = paramInt1;
  }
  
  public final int b() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\f2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */