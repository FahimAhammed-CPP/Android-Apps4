package com.chartboost.sdk.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class c2 {
  public static final byte[] a = new byte[0];
  
  public static int a(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    long l = b(paramInputStream, paramOutputStream);
    return (l > 2147483647L) ? -1 : (int)l;
  }
  
  public static long a(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt) throws IOException {
    return a(paramInputStream, paramOutputStream, new byte[paramInt]);
  }
  
  public static long a(InputStream paramInputStream, OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
    long l = 0L;
    while (true) {
      int i = paramInputStream.read(paramArrayOfbyte);
      if (-1 != i) {
        paramOutputStream.write(paramArrayOfbyte, 0, i);
        l += i;
        continue;
      } 
      return l;
    } 
  }
  
  public static byte[] a(InputStream paramInputStream) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      a(paramInputStream, byteArrayOutputStream);
      return byteArrayOutputStream.toByteArray();
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  public static long b(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    return a(paramInputStream, paramOutputStream, 8192);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */