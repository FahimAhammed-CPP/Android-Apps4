package com.chartboost.sdk.impl;

import android.content.SharedPreferences;
import java.util.UUID;

public class e5 {
  public final SharedPreferences a;
  
  public String b;
  
  public long c = 0L;
  
  public int d = 0;
  
  public int e = 0;
  
  public int f = 0;
  
  public int g = 0;
  
  public e5(SharedPreferences paramSharedPreferences) {
    this.a = paramSharedPreferences;
    this.d = f();
  }
  
  public void a() {
    this.b = b();
    this.c = System.currentTimeMillis();
    this.e = 0;
    this.f = 0;
    this.g = 0;
    this.d++;
    g();
  }
  
  public void a(g3 paramg3) {
    int i = a.a[paramg3.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3)
          return; 
        this.g++;
        return;
      } 
      this.f++;
      return;
    } 
    this.e++;
  }
  
  public int b(g3 paramg3) {
    int i = a.a[paramg3.ordinal()];
    return (i != 1) ? ((i != 2) ? ((i != 3) ? 0 : this.g) : this.f) : this.e;
  }
  
  public final String b() {
    String str1 = UUID.randomUUID().toString();
    String str2 = z0.a(str1);
    return (str2 != null) ? str2 : str1;
  }
  
  public int c() {
    return this.d;
  }
  
  public long d() {
    return System.currentTimeMillis() - this.c;
  }
  
  public String e() {
    return this.b;
  }
  
  public final int f() {
    SharedPreferences sharedPreferences = this.a;
    return (sharedPreferences != null) ? sharedPreferences.getInt("session_key", 0) : -1;
  }
  
  public final void g() {
    SharedPreferences sharedPreferences = this.a;
    if (sharedPreferences != null) {
      SharedPreferences.Editor editor = sharedPreferences.edit();
      if (editor != null)
        editor.putInt("session_key", this.d).apply(); 
    } 
  }
  
  public f5 h() {
    return new f5(e(), d(), c(), b(g3.e), b(g3.d), b(g3.c));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */