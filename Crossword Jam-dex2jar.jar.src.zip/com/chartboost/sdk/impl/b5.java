package com.chartboost.sdk.impl;

import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b5 {
  public final String A;
  
  public final String B;
  
  public final String C;
  
  public final a D;
  
  public b E;
  
  public String F;
  
  public q5 G;
  
  public z5 H;
  
  public final String a;
  
  public final boolean b;
  
  public final boolean c;
  
  public final List<String> d;
  
  public final boolean e;
  
  public final boolean f;
  
  public final boolean g;
  
  public final boolean h;
  
  public final boolean i;
  
  public final boolean j;
  
  public final boolean k;
  
  public final boolean l;
  
  public final long m;
  
  public final int n;
  
  public final int o;
  
  public final int p;
  
  public final int q;
  
  public final List<String> r;
  
  public final boolean s;
  
  public final boolean t;
  
  public final boolean u;
  
  public final int v;
  
  public final boolean w;
  
  public final int x;
  
  public final boolean y;
  
  public final String z;
  
  public b5(JSONObject paramJSONObject) {
    this.a = paramJSONObject.optString("configVariant");
    this.b = paramJSONObject.optBoolean("prefetchDisable");
    this.c = paramJSONObject.optBoolean("publisherDisable");
    this.D = a.a(paramJSONObject);
    try {
      this.E = b.a(paramJSONObject);
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
    } 
    this.F = paramJSONObject.optString("publisherWarning", null);
    ArrayList<String> arrayList2 = new ArrayList();
    JSONArray jSONArray2 = paramJSONObject.optJSONArray("invalidateFolderList");
    if (jSONArray2 != null) {
      int m = jSONArray2.length();
      for (int k = 0; k < m; k++) {
        String str1 = jSONArray2.optString(k);
        if (!str1.isEmpty())
          arrayList2.add(str1); 
      } 
    } 
    this.d = Collections.unmodifiableList(arrayList2);
    JSONObject jSONObject2 = paramJSONObject.optJSONObject("trackingLevels");
    JSONObject jSONObject1 = jSONObject2;
    if (jSONObject2 == null)
      jSONObject1 = new JSONObject(); 
    this.e = jSONObject1.optBoolean("critical", true);
    this.l = jSONObject1.optBoolean("includeStackTrace", true);
    this.f = jSONObject1.optBoolean("error");
    this.g = jSONObject1.optBoolean("debug");
    this.h = jSONObject1.optBoolean("session");
    this.i = jSONObject1.optBoolean("system");
    this.j = jSONObject1.optBoolean("timing");
    this.k = jSONObject1.optBoolean("user");
    this.G = q5.a(paramJSONObject);
    jSONObject2 = paramJSONObject.optJSONObject("videoPreCaching");
    jSONObject1 = jSONObject2;
    if (jSONObject2 == null)
      jSONObject1 = new JSONObject(); 
    this.H = (new z5()).a(jSONObject1);
    this.m = paramJSONObject.optLong("getAdRetryBaseMs", 200L);
    this.n = paramJSONObject.optInt("getAdRetryMaxBackoffExponent", 3);
    jSONObject1 = paramJSONObject.optJSONObject("webview");
    paramJSONObject = jSONObject1;
    if (jSONObject1 == null)
      paramJSONObject = new JSONObject(); 
    this.o = paramJSONObject.optInt("cacheMaxBytes", 104857600);
    int i = 10;
    int j = paramJSONObject.optInt("cacheMaxUnits", 10);
    if (j > 0)
      i = j; 
    this.p = i;
    this.q = (int)TimeUnit.SECONDS.toDays(paramJSONObject.optInt("cacheTTLs", y0.a));
    ArrayList<String> arrayList1 = new ArrayList();
    JSONArray jSONArray1 = paramJSONObject.optJSONArray("directories");
    if (jSONArray1 != null) {
      j = jSONArray1.length();
      for (i = 0; i < j; i++) {
        String str1 = jSONArray1.optString(i);
        if (!str1.isEmpty())
          arrayList1.add(str1); 
      } 
    } 
    this.r = Collections.unmodifiableList(arrayList1);
    this.s = paramJSONObject.optBoolean("enabled", f());
    this.t = paramJSONObject.optBoolean("inplayEnabled", true);
    this.u = paramJSONObject.optBoolean("interstitialEnabled", true);
    i = paramJSONObject.optInt("invalidatePendingImpression", 3);
    if (i <= 0)
      i = 3; 
    this.v = i;
    this.w = paramJSONObject.optBoolean("lockOrientation", true);
    this.x = paramJSONObject.optInt("prefetchSession", 3);
    this.y = paramJSONObject.optBoolean("rewardVideoEnabled", true);
    String str = paramJSONObject.optString("version", "v2");
    this.z = str;
    this.A = String.format("%s/%s%s", new Object[] { "webview", str, "/interstitial/get" });
    this.B = String.format("%s/%s/%s", new Object[] { "webview", str, "prefetch" });
    this.C = String.format("%s/%s%s", new Object[] { "webview", str, "/reward/get" });
  }
  
  public static boolean f() {
    int[] arrayOfInt = new int[3];
    arrayOfInt[0] = 4;
    arrayOfInt[1] = 4;
    arrayOfInt[2] = 2;
    String str = c0.b().a();
    if (str != null) {
      if (str.length() <= 0)
        return false; 
      String[] arrayOfString = str.replaceAll("[^\\d.]", "").split("\\.");
      int i = 0;
      while (true) {
        if (i < arrayOfString.length && i < 3) {
          try {
            if (Integer.valueOf(arrayOfString[i]).intValue() > arrayOfInt[i])
              return true; 
            int j = Integer.valueOf(arrayOfString[i]).intValue();
            int k = arrayOfInt[i];
            if (j < k)
              return false; 
            i++;
          } catch (NumberFormatException numberFormatException) {
            return false;
          } 
          continue;
        } 
        return false;
      } 
    } 
    return false;
  }
  
  public a a() {
    return this.D;
  }
  
  public z5 b() {
    return this.H;
  }
  
  public boolean c() {
    return this.c;
  }
  
  public String d() {
    return this.F;
  }
  
  public q5 e() {
    return this.G;
  }
  
  public e2 g() {
    return new e2(this.a, this.s, this.z);
  }
  
  public static class a {
    public boolean a;
    
    public static a a(JSONObject param1JSONObject) {
      a a1 = new a();
      a1.a = param1JSONObject.optBoolean("bannerEnable", true);
      return a1;
    }
    
    public boolean a() {
      return this.a;
    }
  }
  
  public static class b {
    public HashSet<String> a;
    
    public static b a(JSONObject param1JSONObject) throws JSONException {
      b b1 = new b();
      HashSet<String> hashSet = new HashSet();
      hashSet.add("us_privacy");
      hashSet.add("coppa");
      JSONArray jSONArray = param1JSONObject.optJSONArray("privacyStandards");
      if (jSONArray != null) {
        int i = jSONArray.length();
        a(jSONArray, hashSet, i);
        a(hashSet, i);
      } 
      b1.a = hashSet;
      return b1;
    }
    
    public static void a(HashSet<String> param1HashSet, int param1Int) {
      if (param1Int == 0)
        param1HashSet.clear(); 
    }
    
    public static void a(@NonNull JSONArray param1JSONArray, HashSet<String> param1HashSet, int param1Int) throws JSONException {
      for (int i = 0; i < param1Int; i++)
        param1HashSet.add(param1JSONArray.getString(i)); 
    }
    
    public HashSet<String> a() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\b5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */