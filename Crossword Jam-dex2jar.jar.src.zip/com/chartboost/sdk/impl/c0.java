package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.appset.AppSet;
import com.google.android.gms.appset.AppSetIdInfo;
import com.google.android.gms.tasks.Task;

public class c0 {
  public static c0 b = new c0(new Handler(Looper.getMainLooper()));
  
  public final Handler a;
  
  public c0(Handler paramHandler) {
    this.a = paramHandler;
  }
  
  public static c0 b() {
    return b;
  }
  
  public Task<AppSetIdInfo> a(Context paramContext) {
    try {
      return AppSet.getClient(paramContext).getAppSetIdInfo();
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot retrieve appSetId client: ");
      stringBuilder.append(exception);
      Log.e("CBAndroid", stringBuilder.toString());
      return null;
    } 
  }
  
  public String a() {
    return Build.VERSION.RELEASE;
  }
  
  public boolean a(CharSequence paramCharSequence) {
    return TextUtils.isEmpty(paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */