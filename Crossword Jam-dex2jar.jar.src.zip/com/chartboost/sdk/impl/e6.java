package com.chartboost.sdk.impl;

public interface e6 {
  void a(b4 paramb4);
  
  void onDetachedFromWindow();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */