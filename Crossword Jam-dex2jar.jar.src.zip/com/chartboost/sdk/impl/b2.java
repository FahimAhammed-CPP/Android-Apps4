package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import kotlin.Metadata;

@Metadata(bv = {}, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\b\027\030\0002\0020\001BC\022\006\020\003\032\0020\002\022\b\020\005\032\004\030\0010\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b\022\006\020\013\032\0020\n\022\006\020\r\032\0020\f\022\b\020\016\032\004\030\0010\004¢\006\004\b\017\020\020¨\006\021"}, d2 = {"Lcom/chartboost/sdk/impl/b2;", "Lcom/chartboost/sdk/impl/d6;", "Landroid/content/Context;", "context", "", "html", "Lcom/chartboost/sdk/impl/j2;", "callback", "Lcom/chartboost/sdk/impl/e6;", "viewBaseCallback", "Lcom/chartboost/sdk/impl/o1;", "protocol", "Landroid/os/Handler;", "uiHandler", "baseExternalPathURL", "<init>", "(Landroid/content/Context;Ljava/lang/String;Lcom/chartboost/sdk/impl/j2;Lcom/chartboost/sdk/impl/e6;Lcom/chartboost/sdk/impl/o1;Landroid/os/Handler;Ljava/lang/String;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
@SuppressLint({"ViewConstructor"})
public class b2 extends d6 {
  public b2(Context paramContext, String paramString1, j2 paramj2, e6 parame6, o1 paramo1, Handler paramHandler, String paramString2) {
    super(paramContext, parame6);
    setFocusable(false);
    w2 w2 = w2.a();
    this.d = (RelativeLayout)w2.a(new RelativeLayout(paramContext));
    this.b = (r1)w2.a(new r1(paramContext));
    u5.a.a(paramContext);
    this.b.setWebViewClient((WebViewClient)w2.a(new i2(paramContext, paramj2)));
    p1 p1 = (p1)w2.a(new p1((View)this.d, null, paramo1, paramHandler));
    this.c = p1;
    this.b.setWebChromeClient((WebChromeClient)p1);
    try {
      WebView.setWebContentsDebuggingEnabled(false);
    } catch (RuntimeException runtimeException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception while enabling webview debugging ");
      stringBuilder.append(runtimeException);
      r3.e("CommonWebViewBase", stringBuilder.toString());
    } 
    if (paramString1 != null) {
      this.b.loadDataWithBaseURL(paramString2, paramString1, "text/html", "utf-8", null);
    } else {
      paramo1.b("Html is null");
    } 
    if (this.b.getSettings() != null)
      this.b.getSettings().setSupportZoom(false); 
    this.d.addView((View)this.b);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.b.setBackgroundColor(0);
    this.d.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\b2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */