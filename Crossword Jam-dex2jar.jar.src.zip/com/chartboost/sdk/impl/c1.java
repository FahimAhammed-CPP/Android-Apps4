package com.chartboost.sdk.impl;

import com.chartboost.sdk.internal.Model.CBError;
import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;

public class c1<T> {
  public final String a;
  
  public final String b;
  
  public final g4 c;
  
  public final AtomicInteger d;
  
  public final File e;
  
  public long f;
  
  public long g;
  
  public long h;
  
  public int i;
  
  public c1(String paramString1, String paramString2, g4 paramg4, File paramFile) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramg4;
    this.d = new AtomicInteger();
    this.e = paramFile;
    this.f = 0L;
    this.g = 0L;
    this.h = 0L;
    this.i = 0;
  }
  
  public d1 a() {
    return new d1(null, null, null);
  }
  
  public e1<T> a(f1 paramf1) {
    return e1.a((T)null);
  }
  
  public void a(CBError paramCBError, f1 paramf1) {}
  
  public void a(T paramT, f1 paramf1) {}
  
  public void a(String paramString, long paramLong) {}
  
  public boolean b() {
    return this.d.compareAndSet(0, -1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */