package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import androidx.core.os.HandlerCompat;
import kotlin.Metadata;
import kotlin.d0.d.m;
import kotlin.d0.d.o;
import kotlin.g;
import kotlin.h;

@Metadata(bv = {}, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\034\020\035R\032\020\003\032\0020\0028\026X\004¢\006\f\n\004\b\003\020\004\032\004\b\005\020\006R\033\020\f\032\0020\0078VX\002¢\006\f\n\004\b\b\020\t\032\004\b\n\020\013R\033\020\021\032\0020\r8VX\002¢\006\f\n\004\b\016\020\t\032\004\b\017\020\020R\033\020\026\032\0020\0228VX\002¢\006\f\n\004\b\023\020\t\032\004\b\024\020\025R\033\020\033\032\0020\0278VX\002¢\006\f\n\004\b\030\020\t\032\004\b\031\020\032¨\006\036"}, d2 = {"Lcom/chartboost/sdk/impl/e0;", "Lcom/chartboost/sdk/impl/d0;", "Landroid/content/Context;", "context", "Landroid/content/Context;", "getContext", "()Landroid/content/Context;", "Landroid/content/SharedPreferences;", "sharedPreferences$delegate", "Lkotlin/Lazy;", "b", "()Landroid/content/SharedPreferences;", "sharedPreferences", "Lcom/chartboost/sdk/impl/c0;", "android$delegate", "d", "()Lcom/chartboost/sdk/impl/c0;", "android", "Landroid/os/Handler;", "uiHandler$delegate", "c", "()Landroid/os/Handler;", "uiHandler", "Lcom/chartboost/sdk/impl/u0;", "base64Wrapper$delegate", "a", "()Lcom/chartboost/sdk/impl/u0;", "base64Wrapper", "<init>", "(Landroid/content/Context;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class e0 implements d0 {
  public final Context a;
  
  public final g b;
  
  public final g c;
  
  public final g d;
  
  public final g e;
  
  public e0(Context paramContext) {
    this.a = paramContext;
    this.b = h.b(new c(this));
    this.c = h.b(a.a);
    this.d = h.b(d.a);
    this.e = h.b(b.a);
  }
  
  public u0 a() {
    return (u0)this.e.getValue();
  }
  
  public SharedPreferences b() {
    Object object = this.b.getValue();
    m.e(object, "<get-sharedPreferences>(...)");
    return (SharedPreferences)object;
  }
  
  public Handler c() {
    return (Handler)this.d.getValue();
  }
  
  public c0 d() {
    Object object = this.c.getValue();
    m.e(object, "<get-android>(...)");
    return (c0)object;
  }
  
  public Context getContext() {
    return this.a;
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\003\020\002\032\n \001*\004\030\0010\0000\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lcom/chartboost/sdk/impl/c0;", "kotlin.jvm.PlatformType", "a", "()Lcom/chartboost/sdk/impl/c0;"}, k = 3, mv = {1, 6, 0})
  public static final class a extends o implements kotlin.d0.c.a<c0> {
    public static final a a = new a();
    
    public a() {
      super(0);
    }
    
    public final c0 a() {
      return c0.b();
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/chartboost/sdk/impl/u0;", "a", "()Lcom/chartboost/sdk/impl/u0;"}, k = 3, mv = {1, 6, 0})
  public static final class b extends o implements kotlin.d0.c.a<u0> {
    public static final b a = new b();
    
    public b() {
      super(0);
    }
    
    public final u0 a() {
      return new u0();
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\003\020\002\032\n \001*\004\030\0010\0000\000H\n¢\006\004\b\002\020\003"}, d2 = {"Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "a", "()Landroid/content/SharedPreferences;"}, k = 3, mv = {1, 6, 0})
  public static final class c extends o implements kotlin.d0.c.a<SharedPreferences> {
    public c(e0 param1e0) {
      super(0);
    }
    
    public final SharedPreferences a() {
      return this.a.getContext().getSharedPreferences("cbPrefs", 0);
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroid/os/Handler;", "a", "()Landroid/os/Handler;"}, k = 3, mv = {1, 6, 0})
  public static final class d extends o implements kotlin.d0.c.a<Handler> {
    public static final d a = new d();
    
    public d() {
      super(0);
    }
    
    public final Handler a() {
      Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());
      m.e(handler, "createAsync(Looper.getMainLooper())");
      return handler;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */