package com.chartboost.sdk.impl;

import android.os.Handler;
import com.chartboost.sdk.Mediation;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Metadata;
import kotlin.d0.c.v;
import kotlin.d0.d.o;
import kotlin.g;
import kotlin.h;

@Metadata(bv = {}, d1 = {"\000`\n\002\030\002\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\030\000*\004\b\000\020\0012\0020\002Bc\022\006\020\034\032\0020\033\022H\020&\032D\022@\022>\022\004\022\0020\037\022\004\022\0020 \022\004\022\0020!\022\n\022\b\022\004\022\0020\0130\n\022\004\022\0020\"\022\004\022\0020#\022\004\022\0020$\022\004\022\0020%\022\004\022\0028\0000\0360\035\022\b\020\006\032\004\030\0010\005¢\006\004\b'\020(J\r\020\003\032\0028\000¢\006\004\b\003\020\004R\031\020\006\032\004\030\0010\0058\006¢\006\f\n\004\b\006\020\007\032\004\b\b\020\tR!\020\020\032\b\022\004\022\0020\0130\n8FX\002¢\006\f\n\004\b\f\020\r\032\004\b\016\020\017R\033\020\025\032\0020\0218BX\002¢\006\f\n\004\b\022\020\r\032\004\b\023\020\024R\033\020\032\032\0020\0268BX\002¢\006\f\n\004\b\027\020\r\032\004\b\030\020\031¨\006)"}, d2 = {"Lcom/chartboost/sdk/impl/d;", "T", "", "a", "()Ljava/lang/Object;", "Lcom/chartboost/sdk/Mediation;", "mediation", "Lcom/chartboost/sdk/Mediation;", "d", "()Lcom/chartboost/sdk/Mediation;", "Ljava/util/concurrent/atomic/AtomicReference;", "Lcom/chartboost/sdk/impl/b5;", "sdkConfig$delegate", "Lkotlin/Lazy;", "e", "()Ljava/util/concurrent/atomic/AtomicReference;", "sdkConfig", "Lcom/chartboost/sdk/impl/z1;", "dependencyContainer$delegate", "c", "()Lcom/chartboost/sdk/impl/z1;", "dependencyContainer", "Lcom/chartboost/sdk/impl/p;", "adUnitManagerModule$delegate", "b", "()Lcom/chartboost/sdk/impl/p;", "adUnitManagerModule", "Lcom/chartboost/sdk/impl/j;", "adTypeTraits", "Lkotlin/Function0;", "Lkotlin/Function8;", "Lcom/chartboost/sdk/impl/m;", "Lcom/chartboost/sdk/impl/s;", "Landroid/os/Handler;", "Ljava/util/concurrent/ScheduledExecutorService;", "Lcom/chartboost/sdk/impl/b;", "Lcom/chartboost/sdk/impl/e5;", "Lcom/chartboost/sdk/impl/u0;", "get", "<init>", "(Lcom/chartboost/sdk/impl/j;Lkotlin/jvm/functions/Function0;Lcom/chartboost/sdk/Mediation;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class d<T> {
  public final kotlin.d0.c.a<v<m, s, Handler, AtomicReference<b5>, ScheduledExecutorService, b, e5, u0, T>> a;
  
  public final Mediation b;
  
  public final g c;
  
  public final g d;
  
  public final m e;
  
  public final s f;
  
  public final Handler g;
  
  public final g h;
  
  public final ScheduledExecutorService i;
  
  public final e5 j;
  
  public final u0 k;
  
  public final b l;
  
  public d(j paramj, kotlin.d0.c.a<? extends v<? super m, ? super s, ? super Handler, ? super AtomicReference<b5>, ? super ScheduledExecutorService, ? super b, ? super e5, ? super u0, ? extends T>> parama, Mediation paramMediation) {
    this.a = (kotlin.d0.c.a)parama;
    this.b = paramMediation;
    this.c = h.b(b.a);
    this.d = h.b(new a(this, paramj));
    this.e = b().b();
    this.f = b().c();
    this.g = c().a().c();
    this.h = h.b(new c(this));
    this.i = c().f().a();
    this.j = c().e().j();
    this.k = c().a().a();
    this.l = (new c(c().a())).a();
  }
  
  public final T a() {
    return (T)((v)this.a.invoke()).invoke(this.e, this.f, this.g, e(), this.i, this.l, this.j, this.k);
  }
  
  public final p b() {
    return (p)this.d.getValue();
  }
  
  public final z1 c() {
    return (z1)this.c.getValue();
  }
  
  public final Mediation d() {
    return this.b;
  }
  
  public final AtomicReference<b5> e() {
    return (AtomicReference<b5>)this.h.getValue();
  }
  
  @Metadata(bv = {}, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\002\032\0020\001\"\004\b\000\020\000H\n¢\006\004\b\002\020\003"}, d2 = {"T", "Lcom/chartboost/sdk/impl/p;", "a", "()Lcom/chartboost/sdk/impl/p;"}, k = 3, mv = {1, 6, 0})
  public static final class a extends o implements kotlin.d0.c.a<p> {
    public a(d<T> param1d, j param1j) {
      super(0);
    }
    
    public final p a() {
      return new p(d.a(this.a).b(), d.a(this.a).c(), d.a(this.a).a(), d.a(this.a).e(), d.a(this.a).f(), this.b, d.a(this.a).i(), this.a.d());
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\002\032\0020\001\"\004\b\000\020\000H\n¢\006\004\b\002\020\003"}, d2 = {"T", "Lcom/chartboost/sdk/impl/z1;", "a", "()Lcom/chartboost/sdk/impl/z1;"}, k = 3, mv = {1, 6, 0})
  public static final class b extends o implements kotlin.d0.c.a<z1> {
    public static final b a = new b();
    
    public b() {
      super(0);
    }
    
    public final z1 a() {
      return z1.k;
    }
  }
  
  @Metadata(bv = {}, d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\b\022\004\022\0020\0020\001\"\004\b\000\020\000H\n¢\006\004\b\003\020\004"}, d2 = {"T", "Ljava/util/concurrent/atomic/AtomicReference;", "Lcom/chartboost/sdk/impl/b5;", "a", "()Ljava/util/concurrent/atomic/AtomicReference;"}, k = 3, mv = {1, 6, 0})
  public static final class c extends o implements kotlin.d0.c.a<AtomicReference<b5>> {
    public c(d<T> param1d) {
      super(0);
    }
    
    public final AtomicReference<b5> a() {
      return d.a(this.a).e().g();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */