package com.chartboost.sdk.impl;

import android.os.Handler;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

public class f0 {
  public final Handler a;
  
  public f0(Handler paramHandler) {
    this.a = paramHandler;
  }
  
  public void a(g0 paramg0, com.chartboost.sdk.internal.Model.a parama, Runnable paramRunnable) {
    a(paramg0, parama, paramRunnable, false);
  }
  
  public void a(g0 paramg0, com.chartboost.sdk.internal.Model.a parama, Runnable paramRunnable, n1 paramn1) {
    a(paramg0, parama, paramRunnable, true, paramn1);
  }
  
  public void a(g0 paramg0, com.chartboost.sdk.internal.Model.a parama, Runnable paramRunnable, boolean paramBoolean) {
    AnimationSet animationSet = new AnimationSet(true);
    animationSet.addAnimation((Animation)new AlphaAnimation(1.0F, 1.0F));
    if (parama != null) {
      e4 e4 = parama.z;
      if (e4 != null) {
        AnimationSet animationSet9;
        ScaleAnimation scaleAnimation3;
        AnimationSet animationSet8;
        TranslateAnimation translateAnimation6;
        AnimationSet animationSet7;
        TranslateAnimation translateAnimation5;
        AnimationSet animationSet6;
        TranslateAnimation translateAnimation4;
        AnimationSet animationSet5;
        TranslateAnimation translateAnimation3;
        AnimationSet animationSet4;
        z2 z22;
        ScaleAnimation scaleAnimation2;
        TranslateAnimation translateAnimation2;
        AnimationSet animationSet3;
        z2 z21;
        ScaleAnimation scaleAnimation1;
        TranslateAnimation translateAnimation1;
        AnimationSet animationSet2;
        AlphaAnimation alphaAnimation;
        AnimationSet animationSet1;
        e4 e41;
        View view = e4.getContentView();
        if (view == null) {
          if (paramRunnable != null)
            paramRunnable.run(); 
          r3.a("AnimationManager", "Transition of impression canceled due to lack of view");
          return;
        } 
        j3 j3 = parama.a;
        if (j3 == j3.d || j3 == j3.c)
          e41 = parama.z; 
        float f1 = e41.getWidth();
        float f2 = e41.getHeight();
        switch (b.a[paramg0.ordinal()]) {
          default:
            animationSet9 = animationSet;
            break;
          case 8:
            if (paramBoolean) {
              ScaleAnimation scaleAnimation = new ScaleAnimation(0.6F, 1.1F, 0.6F, 1.1F, 1, 0.5F, 1, 0.5F);
              f1 = (float)500L;
              f2 = 0.6F * f1;
              scaleAnimation.setDuration(Math.round(f2));
              scaleAnimation.setStartOffset(0L);
              scaleAnimation.setFillAfter(true);
              animationSet.addAnimation((Animation)scaleAnimation);
              scaleAnimation = new ScaleAnimation(1.0F, 0.81818175F, 1.0F, 0.81818175F, 1, 0.5F, 1, 0.5F);
              scaleAnimation.setDuration(Math.round(0.19999999F * f1));
              scaleAnimation.setStartOffset(Math.round(f2));
              scaleAnimation.setFillAfter(true);
              animationSet.addAnimation((Animation)scaleAnimation);
              scaleAnimation = new ScaleAnimation(1.0F, 1.1111112F, 1.0F, 1.1111112F, 1, 0.5F, 1, 0.5F);
              scaleAnimation.setDuration(Math.round(0.099999964F * f1));
              scaleAnimation.setStartOffset(Math.round(f1 * 0.8F));
              scaleAnimation.setFillAfter(true);
              animationSet.addAnimation((Animation)scaleAnimation);
              AnimationSet animationSet10 = animationSet;
              break;
            } 
            scaleAnimation3 = new ScaleAnimation(1.0F, 0.0F, 1.0F, 0.0F, 1, 0.5F, 1, 0.5F);
            scaleAnimation3.setDuration(500L);
            scaleAnimation3.setStartOffset(0L);
            scaleAnimation3.setFillAfter(true);
            animationSet.addAnimation((Animation)scaleAnimation3);
            animationSet8 = animationSet;
            break;
          case 7:
            if (paramBoolean) {
              f2 = -f1;
            } else {
              f2 = 0.0F;
            } 
            if (paramBoolean) {
              f1 = 0.0F;
            } else {
              f1 = -f1;
            } 
            translateAnimation6 = new TranslateAnimation(f2, f1, 0.0F, 0.0F);
            translateAnimation6.setDuration(500L);
            translateAnimation6.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation6);
            animationSet7 = animationSet;
            break;
          case 6:
            if (paramBoolean) {
              f2 = f1;
            } else {
              f2 = 0.0F;
            } 
            if (paramBoolean)
              f1 = 0.0F; 
            translateAnimation5 = new TranslateAnimation(f2, f1, 0.0F, 0.0F);
            translateAnimation5.setDuration(500L);
            translateAnimation5.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation5);
            animationSet6 = animationSet;
            break;
          case 5:
            if (paramBoolean) {
              f1 = -f2;
            } else {
              f1 = 0.0F;
            } 
            if (paramBoolean) {
              f2 = 0.0F;
            } else {
              f2 = -f2;
            } 
            translateAnimation4 = new TranslateAnimation(0.0F, 0.0F, f1, f2);
            translateAnimation4.setDuration(500L);
            translateAnimation4.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation4);
            animationSet5 = animationSet;
            break;
          case 4:
            if (paramBoolean) {
              f1 = f2;
            } else {
              f1 = 0.0F;
            } 
            if (paramBoolean)
              f2 = 0.0F; 
            translateAnimation3 = new TranslateAnimation(0.0F, 0.0F, f1, f2);
            translateAnimation3.setDuration(500L);
            translateAnimation3.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation3);
            animationSet4 = animationSet;
            break;
          case 3:
            if (paramBoolean) {
              z22 = new z2(-60.0F, 0.0F, f1 / 2.0F, f2 / 2.0F, true);
            } else {
              z22 = new z2(0.0F, 60.0F, f1 / 2.0F, f2 / 2.0F, true);
            } 
            z22.setDuration(500L);
            z22.setFillAfter(true);
            animationSet.addAnimation((Animation)z22);
            if (paramBoolean) {
              scaleAnimation2 = new ScaleAnimation(0.4F, 1.0F, 0.4F, 1.0F);
            } else {
              scaleAnimation2 = new ScaleAnimation(1.0F, 0.4F, 1.0F, 0.4F);
            } 
            scaleAnimation2.setDuration(500L);
            scaleAnimation2.setFillAfter(true);
            animationSet.addAnimation((Animation)scaleAnimation2);
            if (paramBoolean) {
              translateAnimation2 = new TranslateAnimation(-f1 * 0.4F, 0.0F, f2 * 0.3F, 0.0F);
            } else {
              translateAnimation2 = new TranslateAnimation(0.0F, f1, 0.0F, f2 * 0.3F);
            } 
            translateAnimation2.setDuration(500L);
            translateAnimation2.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation2);
            animationSet3 = animationSet;
            break;
          case 2:
            if (paramBoolean) {
              z21 = new z2(-60.0F, 0.0F, f1 / 2.0F, f2 / 2.0F, false);
            } else {
              z21 = new z2(0.0F, 60.0F, f1 / 2.0F, f2 / 2.0F, false);
            } 
            z21.setDuration(500L);
            z21.setFillAfter(true);
            animationSet.addAnimation((Animation)z21);
            if (paramBoolean) {
              scaleAnimation1 = new ScaleAnimation(0.4F, 1.0F, 0.4F, 1.0F);
            } else {
              scaleAnimation1 = new ScaleAnimation(1.0F, 0.4F, 1.0F, 0.4F);
            } 
            scaleAnimation1.setDuration(500L);
            scaleAnimation1.setFillAfter(true);
            animationSet.addAnimation((Animation)scaleAnimation1);
            if (paramBoolean) {
              translateAnimation1 = new TranslateAnimation(f1 * 0.3F, 0.0F, -f2 * 0.4F, 0.0F);
            } else {
              translateAnimation1 = new TranslateAnimation(0.0F, f1 * 0.3F, 0.0F, f2);
            } 
            translateAnimation1.setDuration(500L);
            translateAnimation1.setFillAfter(true);
            animationSet.addAnimation((Animation)translateAnimation1);
            animationSet2 = animationSet;
            break;
          case 1:
            if (paramBoolean) {
              alphaAnimation = new AlphaAnimation(0.0F, 1.0F);
            } else {
              alphaAnimation = new AlphaAnimation(1.0F, 0.0F);
            } 
            alphaAnimation.setDuration(500L);
            alphaAnimation.setFillAfter(true);
            animationSet = new AnimationSet(true);
            animationSet.addAnimation((Animation)alphaAnimation);
            animationSet1 = animationSet;
            break;
        } 
        if (paramg0 == g0.i) {
          if (paramRunnable != null)
            paramRunnable.run(); 
          return;
        } 
        if (paramRunnable != null)
          this.a.postDelayed(paramRunnable, 500L); 
        e41.startAnimation((Animation)animationSet1);
        return;
      } 
    } 
    r3.a("AnimationManager", "Transition of impression canceled due to lack of container");
    if (paramRunnable != null)
      paramRunnable.run(); 
  }
  
  public final void a(g0 paramg0, com.chartboost.sdk.internal.Model.a parama, Runnable paramRunnable, boolean paramBoolean, n1 paramn1) {
    if (paramg0 == g0.i) {
      if (paramRunnable != null)
        paramRunnable.run(); 
      return;
    } 
    if (parama != null) {
      e4 e4 = parama.z;
      if (e4 != null) {
        View view = e4.getContentView();
        if (view == null) {
          paramn1.e(parama);
          r3.a("AnimationManager", "Transition of impression canceled due to lack of view");
          return;
        } 
        ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
        if (viewTreeObserver.isAlive())
          viewTreeObserver.addOnGlobalLayoutListener(new a(this, view, paramg0, parama, paramRunnable, paramBoolean)); 
        return;
      } 
    } 
    r3.a("AnimationManager", "Transition of impression canceled due to lack of container");
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(f0 this$0, View param1View, g0 param1g0, com.chartboost.sdk.internal.Model.a param1a, Runnable param1Runnable, boolean param1Boolean) {}
    
    public void onGlobalLayout() {
      this.a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
      this.f.a(this.b, this.c, this.d, this.e);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */