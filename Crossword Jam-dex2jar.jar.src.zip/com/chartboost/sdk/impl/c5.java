package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.Log;
import com.chartboost.sdk.callbacks.StartCallback;
import com.chartboost.sdk.events.StartError;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Metadata;
import kotlin.d0.d.m;
import kotlin.k0.h;
import org.json.JSONObject;

@Metadata(bv = {}, d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\006\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\007\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\001\022\006\020\"\032\0020!\022\006\020$\032\0020#\022\006\020&\032\0020%\022\006\020(\032\0020'\022\f\020+\032\b\022\004\022\0020*0)\022\006\020-\032\0020,\022\006\020/\032\0020.\022\006\0201\032\00200\022\006\0203\032\00202\022\006\0205\032\00204\022\006\0207\032\00206\022\006\0209\032\00208\022\006\020;\032\0020:\022\006\020=\032\0020<\022\006\020?\032\0020>¢\006\004\b@\020AJ\036\020\b\032\0020\0072\006\020\003\032\0020\0022\006\020\004\032\0020\0022\006\020\006\032\0020\005J\020\020\b\032\0020\0072\006\020\n\032\0020\tH\026J\020\020\b\032\0020\0072\006\020\013\032\0020\002H\026J\030\020\b\032\0020\0072\006\020\003\032\0020\0022\006\020\004\032\0020\002H\002J\b\020\f\032\0020\007H\002J\b\020\b\032\0020\007H\002J\b\020\r\032\0020\007H\002J\022\020\017\032\0020\0072\b\020\016\032\004\030\0010\tH\002J\b\020\021\032\0020\020H\002J\b\020\017\032\0020\007H\002J\b\020\022\032\0020\007H\002J\b\020\023\032\0020\007H\002J\b\020\024\032\0020\007H\002J\b\020\025\032\0020\007H\002J\b\020\026\032\0020\007H\002J\b\020\027\032\0020\007H\002J\b\020\030\032\0020\007H\002J\022\020\b\032\0020\0072\b\020\032\032\004\030\0010\031H\002R\"\020\033\032\0020\0208\006@\006X\016¢\006\022\n\004\b\033\020\034\032\004\b\035\020\036\"\004\b\037\020 ¨\006B"}, d2 = {"Lcom/chartboost/sdk/impl/c5;", "Lcom/chartboost/sdk/impl/d2;", "", "appId", "appSignature", "Lcom/chartboost/sdk/callbacks/StartCallback;", "onStarted", "", "a", "Lorg/json/JSONObject;", "configJson", "errorMsg", "f", "g", "config", "b", "", "c", "k", "j", "l", "m", "h", "e", "i", "Lcom/chartboost/sdk/events/StartError;", "error", "isSDKInitialized", "Z", "d", "()Z", "setSDKInitialized", "(Z)V", "Landroid/content/Context;", "context", "Landroid/content/SharedPreferences;", "sharedPreferences", "Landroid/os/Handler;", "uiHandler", "Lcom/chartboost/sdk/impl/h4;", "privacyApi", "Ljava/util/concurrent/atomic/AtomicReference;", "Lcom/chartboost/sdk/impl/b5;", "sdkConfig", "Lcom/chartboost/sdk/impl/f4;", "prefetcher", "Lcom/chartboost/sdk/impl/n2;", "downloader", "Lcom/chartboost/sdk/impl/e5;", "session", "Lcom/chartboost/sdk/impl/x5;", "videoCachePolicy", "Lcom/chartboost/sdk/impl/b6;", "videoRepository", "Lcom/chartboost/sdk/impl/n3;", "initInstallRequest", "Lcom/chartboost/sdk/impl/m3;", "initConfigRequest", "Lcom/chartboost/sdk/impl/h1;", "reachability", "Lcom/chartboost/sdk/impl/m4;", "providerInstallerHelper", "Lcom/chartboost/sdk/impl/a1;", "identity", "<init>", "(Landroid/content/Context;Landroid/content/SharedPreferences;Landroid/os/Handler;Lcom/chartboost/sdk/impl/h4;Ljava/util/concurrent/atomic/AtomicReference;Lcom/chartboost/sdk/impl/f4;Lcom/chartboost/sdk/impl/n2;Lcom/chartboost/sdk/impl/e5;Lcom/chartboost/sdk/impl/x5;Lcom/chartboost/sdk/impl/b6;Lcom/chartboost/sdk/impl/n3;Lcom/chartboost/sdk/impl/m3;Lcom/chartboost/sdk/impl/h1;Lcom/chartboost/sdk/impl/m4;Lcom/chartboost/sdk/impl/a1;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class c5 implements d2 {
  public final Context a;
  
  public final SharedPreferences b;
  
  public final Handler c;
  
  public final h4 d;
  
  public final AtomicReference<b5> e;
  
  public final f4 f;
  
  public final n2 g;
  
  public final e5 h;
  
  public final x5 i;
  
  public final b6 j;
  
  public final n3 k;
  
  public final m3 l;
  
  public final h1 m;
  
  public final m4 n;
  
  public final a1 o;
  
  public boolean p;
  
  public final h q;
  
  public final ConcurrentLinkedQueue<AtomicReference<StartCallback>> r;
  
  public boolean s;
  
  public c5(Context paramContext, SharedPreferences paramSharedPreferences, Handler paramHandler, h4 paramh4, AtomicReference<b5> paramAtomicReference, f4 paramf4, n2 paramn2, e5 parame5, x5 paramx5, b6 paramb6, n3 paramn3, m3 paramm3, h1 paramh1, m4 paramm4, a1 parama1) {
    this.a = paramContext;
    this.b = paramSharedPreferences;
    this.c = paramHandler;
    this.d = paramh4;
    this.e = paramAtomicReference;
    this.f = paramf4;
    this.g = paramn2;
    this.h = parame5;
    this.i = paramx5;
    this.j = paramb6;
    this.k = paramn3;
    this.l = paramm3;
    this.m = paramh1;
    this.n = paramm4;
    this.o = parama1;
    this.q = new h("[a-f0-9]+");
    this.r = new ConcurrentLinkedQueue<AtomicReference<StartCallback>>();
  }
  
  public static final void a(StartCallback paramStartCallback, StartError paramStartError) {
    paramStartCallback.onStartCompleted(paramStartError);
  }
  
  public final void a() {
    if (this.d.a("coppa") == null && !this.p)
      Log.w("SdkInitializer", "COPPA is not set. If this app is child directed, please use ´addDataUseConsent(android.content.Context, com.chartboost.sdk.Privacy.model.COPPA)´ to set the correct value."); 
  }
  
  public final void a(StartError paramStartError) {
    if (z4.a) {
      d3 d3 = this.o.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SetId: ");
      stringBuilder.append(d3.c());
      stringBuilder.append(" scope:");
      stringBuilder.append(d3.d());
      stringBuilder.append(" Tracking state: ");
      stringBuilder.append(d3.e());
      stringBuilder.append(" Identifiers: ");
      stringBuilder.append(d3.b());
      z4.a(stringBuilder.toString());
    } 
    Iterator<AtomicReference<StartCallback>> iterator = this.r.iterator();
    while (iterator.hasNext()) {
      StartCallback startCallback = ((AtomicReference<StartCallback>)iterator.next()).getAndSet(null);
      if (startCallback != null)
        this.c.post((Runnable)new x6(startCallback, paramStartError)); 
    } 
    this.r.clear();
    this.s = false;
  }
  
  public void a(String paramString) {
    m.f(paramString, "errorMsg");
    if (this.h.c() == 0) {
      StartError startError;
      if (this.m.e()) {
        startError = new StartError(StartError.Code.SERVER_ERROR, new Exception(paramString));
      } else {
        startError = new StartError(StartError.Code.NETWORK_FAILURE, new Exception((String)startError));
      } 
      a(startError);
      return;
    } 
    b();
  }
  
  public final void a(String paramString1, String paramString2) {
    if (!x0.a(this.a)) {
      r3.b("SdkInitializer", "Permissions not set correctly");
      a(new StartError(StartError.Code.INVALID_CREDENTIALS, new Exception("Permissions not set correctly")));
      return;
    } 
    int i = paramString1.length();
    boolean bool = true;
    if (i == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0) {
      if (paramString2.length() == 0) {
        i = bool;
      } else {
        i = 0;
      } 
      if (i == 0 && paramString1.length() == 24 && paramString2.length() == 40 && this.q.b(paramString1) && this.q.b(paramString2)) {
        this.n.a();
        this.g.b();
        if (c()) {
          f();
          return;
        } 
        g();
        return;
      } 
    } 
    r3.b("SdkInitializer", "AppId or AppSignature is invalid. Please pass a valid id's");
    a(new StartError(StartError.Code.INVALID_CREDENTIALS, new Exception("AppId or AppSignature is invalid. Please pass a valid id's")));
  }
  
  public final void a(String paramString1, String paramString2, StartCallback paramStartCallback) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ldc_w 'appId'
    //   6: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   9: aload_2
    //   10: ldc_w 'appSignature'
    //   13: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   16: aload_3
    //   17: ldc_w 'onStarted'
    //   20: invokestatic f : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_0
    //   24: getfield r : Ljava/util/concurrent/ConcurrentLinkedQueue;
    //   27: new java/util/concurrent/atomic/AtomicReference
    //   30: dup
    //   31: aload_3
    //   32: invokespecial <init> : (Ljava/lang/Object;)V
    //   35: invokevirtual add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: aload_0
    //   40: getfield s : Z
    //   43: ifeq -> 57
    //   46: ldc 'SdkInitializer'
    //   48: ldc_w 'Initialization already in progress'
    //   51: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
    //   54: aload_0
    //   55: monitorexit
    //   56: return
    //   57: aload_0
    //   58: iconst_1
    //   59: putfield s : Z
    //   62: aload_0
    //   63: invokevirtual k : ()V
    //   66: aload_0
    //   67: getfield p : Z
    //   70: ifne -> 82
    //   73: aload_0
    //   74: aload_1
    //   75: aload_2
    //   76: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)V
    //   79: goto -> 86
    //   82: aload_0
    //   83: invokevirtual f : ()V
    //   86: aload_0
    //   87: invokevirtual a : ()V
    //   90: goto -> 140
    //   93: astore_1
    //   94: new java/lang/StringBuilder
    //   97: dup
    //   98: invokespecial <init> : ()V
    //   101: astore_2
    //   102: aload_2
    //   103: ldc_w 'Cannot initialize Chartboost sdk due to internal error '
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload_2
    //   111: aload_1
    //   112: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: ldc 'SdkInitializer'
    //   118: aload_2
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   125: aload_0
    //   126: new com/chartboost/sdk/events/StartError
    //   129: dup
    //   130: getstatic com/chartboost/sdk/events/StartError$Code.INTERNAL : Lcom/chartboost/sdk/events/StartError$Code;
    //   133: aload_1
    //   134: invokespecial <init> : (Lcom/chartboost/sdk/events/StartError$Code;Ljava/lang/Exception;)V
    //   137: invokevirtual a : (Lcom/chartboost/sdk/events/StartError;)V
    //   140: aload_0
    //   141: monitorexit
    //   142: return
    //   143: astore_1
    //   144: aload_0
    //   145: monitorexit
    //   146: aload_1
    //   147: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	143	finally
    //   23	54	93	java/lang/Exception
    //   23	54	143	finally
    //   57	79	93	java/lang/Exception
    //   57	79	143	finally
    //   82	86	93	java/lang/Exception
    //   82	86	143	finally
    //   86	90	93	java/lang/Exception
    //   86	90	143	finally
    //   94	140	143	finally
  }
  
  public void a(JSONObject paramJSONObject) {
    m.f(paramJSONObject, "configJson");
    b(paramJSONObject);
    b();
  }
  
  public final void b() {
    l();
    m();
    h();
    j();
  }
  
  public final void b(JSONObject paramJSONObject) {
    if (paramJSONObject != null && x0.a(this.e, paramJSONObject))
      this.b.edit().putString("config", paramJSONObject.toString()).apply(); 
  }
  
  public final boolean c() {
    String str = this.b.getString("config", "");
    return (str != null && str.length() > 0);
  }
  
  public final boolean d() {
    return this.p;
  }
  
  public final void e() {
    if (this.e.get() != null && ((b5)this.e.get()).d() != null) {
      String str = ((b5)this.e.get()).d();
      m.e(str, "sdkConfig.get().publisherWarning");
      r3.e("SdkInitializer", str);
    } 
  }
  
  public final void f() {
    a((StartError)null);
    this.p = true;
    g();
  }
  
  public final void g() {
    this.l.a(this);
  }
  
  public final void h() {
    e();
    b5 b5 = this.e.get();
    if (b5 != null)
      this.d.a(b5.E); 
    this.k.a();
    i();
  }
  
  public final void i() {
    this.f.b();
  }
  
  public final void j() {
    if (!this.p) {
      a((StartError)null);
      this.p = true;
    } 
  }
  
  public final void k() {
    if (this.h.e() == null) {
      this.h.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Current session count: ");
      stringBuilder.append(this.h.c());
      r3.c("SdkInitializer", stringBuilder.toString());
    } 
  }
  
  public final void l() {
    q5 q5 = (q5)this.e.get();
    m.e(q5, "sdkConfig.get()");
    q5 = ((b5)q5).e();
    if (q5 != null)
      r2.a(q5); 
  }
  
  public final void m() {
    z5 z5 = (z5)this.e.get();
    m.e(z5, "sdkConfig.get()");
    z5 = ((b5)z5).b();
    if (z5 != null) {
      this.i.c(z5.b());
      this.i.b(z5.c());
      this.i.c(z5.d());
      this.i.d(z5.e());
      this.i.e(z5.d());
      this.i.f(z5.g());
      this.i.a(z5.a());
    } 
    this.j.d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\c5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */