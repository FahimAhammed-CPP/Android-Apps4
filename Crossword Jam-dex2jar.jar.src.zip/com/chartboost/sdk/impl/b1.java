package com.chartboost.sdk.impl;

import org.json.JSONException;
import org.json.JSONObject;

public class b1 {
  public static a a(String paramString, Object paramObject) {
    return new a(paramString, paramObject);
  }
  
  public static JSONObject a(JSONObject paramJSONObject, String... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      String str = paramVarArgs[i];
      if (paramJSONObject == null)
        return paramJSONObject; 
      paramJSONObject = paramJSONObject.optJSONObject(str);
    } 
    return paramJSONObject;
  }
  
  public static JSONObject a(a... paramVarArgs) {
    JSONObject jSONObject = new JSONObject();
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      a a1 = paramVarArgs[i];
      a(jSONObject, a1.a, a1.b);
    } 
    return jSONObject;
  }
  
  public static void a(JSONObject paramJSONObject, String paramString, Object paramObject) {
    try {
      paramJSONObject.put(paramString, paramObject);
      return;
    } catch (JSONException jSONException) {
      paramObject = new StringBuilder();
      paramObject.append("put (");
      paramObject.append(paramString);
      paramObject.append(")");
      paramObject.append(jSONException.toString());
      r3.b("CBJSON", paramObject.toString());
      return;
    } 
  }
  
  public static class a {
    public final String a;
    
    public final Object b;
    
    public a(String param1String, Object param1Object) {
      this.a = param1String;
      this.b = param1Object;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */