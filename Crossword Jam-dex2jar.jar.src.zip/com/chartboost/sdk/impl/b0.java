package com.chartboost.sdk.impl;

import android.text.TextUtils;
import android.util.Base64;
import com.chartboost.sdk.Analytics;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Metadata;
import kotlin.d0.d.g0;
import kotlin.d0.d.m;
import kotlin.k0.d;
import kotlin.l;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(bv = {}, d1 = {"\000X\n\002\030\002\n\002\020\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\020\t\n\000\n\002\020\002\n\002\b\t\n\002\030\002\n\000\n\002\020\013\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\037\022\006\020\037\032\0020\036\022\006\020!\032\0020 \022\006\020#\032\0020\"¢\006\004\b$\020%J6\020\r\032\0020\f2\006\020\003\032\0020\0022\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\t\032\0020\0022\006\020\013\032\0020\nJ^\020\r\032\0020\f2\006\020\016\032\0020\0022\006\020\017\032\0020\0022\006\020\t\032\0020\0022\006\020\020\032\0020\0022\006\020\021\032\0020\0022\b\020\022\032\004\030\0010\0022\b\020\023\032\004\030\0010\0022\b\020\024\032\004\030\0010\0022\b\020\025\032\004\030\0010\0022\006\020\027\032\0020\026J\b\020\r\032\0020\030H\002J\034\020\032\032\0020\0312\b\020\022\032\004\030\0010\0022\b\020\023\032\004\030\0010\002H\002J\034\020\r\032\0020\0312\b\020\024\032\004\030\0010\0022\b\020\025\032\004\030\0010\002H\002J\020\020\r\032\0020\0332\006\020\020\032\0020\002H\002J\020\020\r\032\0020\f2\006\020\034\032\0020\031H\002J\020\020\r\032\0020\f2\006\020\034\032\0020\035H\002¨\006&"}, d2 = {"Lcom/chartboost/sdk/impl/b0;", "", "", "eventLabel", "Lcom/chartboost/sdk/Analytics$LevelType;", "type", "", "mainLevel", "subLevel", "description", "", "timestamp", "", "a", "productID", "title", "price", "currency", "purchaseData", "purchaseSignature", "userID", "purchaseToken", "Lcom/chartboost/sdk/Analytics$IAPType;", "iapType", "", "Lorg/json/JSONObject;", "b", "", "requestData", "Lorg/json/JSONArray;", "Lcom/chartboost/sdk/impl/c5;", "sdkInitializer", "Lcom/chartboost/sdk/impl/g1;", "networkService", "Lcom/chartboost/sdk/impl/t4;", "requestBodyBuilder", "<init>", "(Lcom/chartboost/sdk/impl/c5;Lcom/chartboost/sdk/impl/g1;Lcom/chartboost/sdk/impl/t4;)V", "Chartboost-9.2.1_productionRelease"}, k = 1, mv = {1, 6, 0})
public final class b0 {
  public final c5 a;
  
  public final g1 b;
  
  public final t4 c;
  
  public b0(c5 paramc5, g1 paramg1, t4 paramt4) {
    this.a = paramc5;
    this.b = paramg1;
    this.c = paramt4;
  }
  
  public final float a(String paramString) {
    try {
      Matcher matcher = Pattern.compile("(\\d+\\.\\d+)|(\\d+)").matcher(paramString);
      matcher.find();
      String str = matcher.group();
      if (TextUtils.isEmpty(str)) {
        r3.b("AnalyticsApi", "Invalid price object");
        return -1.0F;
      } 
      m.e(str, "result");
      return Float.parseFloat(str);
    } catch (IllegalStateException illegalStateException) {
      r3.b("AnalyticsApi", "Invalid price object");
      return -1.0F;
    } 
  }
  
  public final JSONObject a(String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #4
    //   3: aload_1
    //   4: ifnull -> 24
    //   7: aload_1
    //   8: invokeinterface length : ()I
    //   13: ifne -> 19
    //   16: goto -> 24
    //   19: iconst_0
    //   20: istore_3
    //   21: goto -> 26
    //   24: iconst_1
    //   25: istore_3
    //   26: iload_3
    //   27: ifne -> 99
    //   30: aload_2
    //   31: ifnull -> 46
    //   34: iload #4
    //   36: istore_3
    //   37: aload_2
    //   38: invokeinterface length : ()I
    //   43: ifne -> 48
    //   46: iconst_1
    //   47: istore_3
    //   48: iload_3
    //   49: ifeq -> 55
    //   52: goto -> 99
    //   55: new org/json/JSONObject
    //   58: dup
    //   59: invokespecial <init> : ()V
    //   62: astore #5
    //   64: aload #5
    //   66: ldc 'userID'
    //   68: aload_1
    //   69: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   72: pop
    //   73: aload #5
    //   75: ldc 'purchaseToken'
    //   77: aload_2
    //   78: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   81: pop
    //   82: aload #5
    //   84: ldc 'type'
    //   86: getstatic com/chartboost/sdk/Analytics$IAPType.AMAZON : Lcom/chartboost/sdk/Analytics$IAPType;
    //   89: invokevirtual ordinal : ()I
    //   92: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   95: pop
    //   96: aload #5
    //   98: areturn
    //   99: ldc 'AnalyticsApi'
    //   101: ldc 'Null object is passed for for amazon user id or amazon purchase token'
    //   103: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   106: new org/json/JSONObject
    //   109: dup
    //   110: invokespecial <init> : ()V
    //   113: areturn
  }
  
  public final void a(String paramString1, Analytics.LevelType paramLevelType, int paramInt1, int paramInt2, String paramString2, long paramLong) {
    boolean bool1;
    boolean bool2;
    m.f(paramString1, "eventLabel");
    m.f(paramLevelType, "type");
    m.f(paramString2, "description");
    try {
      if (!a()) {
        r3.b("AnalyticsApi", "You need call Chartboost.startWithAppId() before tracking in-app purchases");
        return;
      } 
      bool1 = paramString1.length();
      bool2 = true;
      if (bool1 == 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1 != 0) {
        r3.b("AnalyticsApi", "Invalid value: event label cannot be empty or null");
        return;
      } 
    } catch (Exception exception) {
      r3.b("AnalyticsApi", exception.toString());
      return;
    } 
    if (paramInt1 < 0 || paramInt2 < 0) {
      r3.b("AnalyticsApi", "Invalid value: Level number should be > 0");
      return;
    } 
    if (paramString2.length() == 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      r3.b("AnalyticsApi", "Invalid value: description cannot be empty or null");
      return;
    } 
    JSONArray jSONArray = new JSONArray();
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("event_label", exception);
    jSONObject.put("event_field", paramLevelType.getLevelType());
    jSONObject.put("main_level", paramInt1);
    jSONObject.put("sub_level", paramInt2);
    jSONObject.put("description", paramString2);
    jSONObject.put("timestamp", paramLong);
    jSONObject.put("data_type", "level_info");
    jSONArray.put(jSONObject);
    a(jSONArray);
  }
  
  public final void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, Analytics.IAPType paramIAPType) {
    JSONObject jSONObject1;
    float f;
    m.f(paramString1, "productID");
    m.f(paramString2, "title");
    m.f(paramString3, "description");
    m.f(paramString4, "price");
    m.f(paramString5, "currency");
    m.f(paramIAPType, "iapType");
    try {
      if (!a()) {
        r3.b("AnalyticsApi", "You need call Chartboost.startWithAppId() before tracking in-app purchases");
        return;
      } 
      f = a(paramString4);
      if (f == -1.0F) {
        i = 1;
      } else {
        i = 0;
      } 
    } catch (Exception exception) {
      r3.b("AnalyticsApi", exception.toString());
      return;
    } 
    if (i)
      return; 
    int i = a.a[paramIAPType.ordinal()];
    if (i != 1) {
      if (i == 2) {
        jSONObject1 = a(paramString8, paramString9);
      } else {
        throw new l();
      } 
    } else {
      jSONObject1 = b(paramString6, paramString7);
    } 
    if (jSONObject1.length() == 0) {
      r3.b("AnalyticsApi", "Error while parsing the receipt to a JSON Object, ");
      return;
    } 
    String str2 = jSONObject1.toString();
    m.e(str2, "receipt.toString()");
    byte[] arrayOfByte = str2.getBytes(d.a);
    m.e(arrayOfByte, "this as java.lang.String).getBytes(charset)");
    String str1 = Base64.encodeToString(arrayOfByte, 2);
    JSONObject jSONObject2 = new JSONObject();
    jSONObject2.put("localized-title", paramString2);
    jSONObject2.put("localized-description", paramString3);
    jSONObject2.put("price", Float.valueOf(f));
    jSONObject2.put("currency", paramString5);
    jSONObject2.put("productID", exception);
    jSONObject2.put("receipt", str1);
    a(jSONObject2);
  }
  
  public final void a(JSONArray paramJSONArray) {
    i1 i1 = new i1("https://live.chartboost.com", "/post-install-event/tracking", this.c.a(), g4.d, "tracking", null);
    i1.a("track_info", paramJSONArray);
    i1.n = true;
    this.b.a((c1)i1);
  }
  
  public final void a(JSONObject paramJSONObject) {
    g0 g0 = g0.a;
    String str = String.format(Locale.US, "%s%s", Arrays.copyOf(new Object[] { "/post-install-event/", "iap" }, 2));
    m.e(str, "format(locale, format, *args)");
    i1 i1 = new i1("https://live.chartboost.com", str, this.c.a(), g4.d, "iap", null);
    i1.a("iap", paramJSONObject);
    i1.n = true;
    this.b.a((c1)i1);
  }
  
  public final boolean a() {
    return this.a.d();
  }
  
  public final JSONObject b(String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #4
    //   3: aload_1
    //   4: ifnull -> 24
    //   7: aload_1
    //   8: invokeinterface length : ()I
    //   13: ifne -> 19
    //   16: goto -> 24
    //   19: iconst_0
    //   20: istore_3
    //   21: goto -> 26
    //   24: iconst_1
    //   25: istore_3
    //   26: iload_3
    //   27: ifne -> 101
    //   30: aload_2
    //   31: ifnull -> 46
    //   34: iload #4
    //   36: istore_3
    //   37: aload_2
    //   38: invokeinterface length : ()I
    //   43: ifne -> 48
    //   46: iconst_1
    //   47: istore_3
    //   48: iload_3
    //   49: ifeq -> 55
    //   52: goto -> 101
    //   55: new org/json/JSONObject
    //   58: dup
    //   59: invokespecial <init> : ()V
    //   62: astore #5
    //   64: aload #5
    //   66: ldc_w 'purchaseData'
    //   69: aload_1
    //   70: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   73: pop
    //   74: aload #5
    //   76: ldc_w 'purchaseSignature'
    //   79: aload_2
    //   80: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   83: pop
    //   84: aload #5
    //   86: ldc 'type'
    //   88: getstatic com/chartboost/sdk/Analytics$IAPType.GOOGLE_PLAY : Lcom/chartboost/sdk/Analytics$IAPType;
    //   91: invokevirtual ordinal : ()I
    //   94: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   97: pop
    //   98: aload #5
    //   100: areturn
    //   101: ldc 'AnalyticsApi'
    //   103: ldc_w 'Null object is passed for for purchase data or purchase signature'
    //   106: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   109: new org/json/JSONObject
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */