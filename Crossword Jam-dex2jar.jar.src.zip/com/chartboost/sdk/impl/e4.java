package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.chartboost.sdk.internal.Model.a;

@SuppressLint({"ViewConstructor"})
public class e4 extends RelativeLayout {
  public d6 a;
  
  public final a b;
  
  public e4(Context paramContext, a parama) {
    super(paramContext);
    this.b = parama;
  }
  
  public void a() {}
  
  public boolean b() {
    d6 d61 = this.a;
    return (d61 != null && d61.getVisibility() == 0);
  }
  
  public void c() {
    if (this.a == null) {
      d6 d61 = this.b.l();
      this.a = d61;
      if (d61 != null) {
        addView((View)d61, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
        this.a.a(false, this.b);
      } 
    } 
  }
  
  public View getContentView() {
    return (View)this.a;
  }
  
  public a getImpression() {
    return this.b;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    performClick();
    return true;
  }
  
  public boolean performClick() {
    super.performClick();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\impl\e4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */