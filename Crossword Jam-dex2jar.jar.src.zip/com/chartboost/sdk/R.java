package com.chartboost.sdk;

public final class R {
  public static final class anim {
    public static final int fragment_fast_out_extra_slow_in = 2130771996;
  }
  
  public static final class animator {
    public static final int fragment_close_enter = 2130837507;
    
    public static final int fragment_close_exit = 2130837508;
    
    public static final int fragment_fade_enter = 2130837509;
    
    public static final int fragment_fade_exit = 2130837510;
    
    public static final int fragment_open_enter = 2130837511;
    
    public static final int fragment_open_exit = 2130837512;
  }
  
  public static final class attr {
    public static final int alpha = 2130968663;
    
    public static final int buttonSize = 2130968725;
    
    public static final int circleCrop = 2130968772;
    
    public static final int colorScheme = 2130968804;
    
    public static final int coordinatorLayoutStyle = 2130968845;
    
    public static final int elevation = 2130968905;
    
    public static final int font = 2130968954;
    
    public static final int fontProviderAuthority = 2130968956;
    
    public static final int fontProviderCerts = 2130968957;
    
    public static final int fontProviderFetchStrategy = 2130968958;
    
    public static final int fontProviderFetchTimeout = 2130968959;
    
    public static final int fontProviderPackage = 2130968960;
    
    public static final int fontProviderQuery = 2130968961;
    
    public static final int fontProviderSystemFontFamily = 2130968962;
    
    public static final int fontStyle = 2130968963;
    
    public static final int fontVariationSettings = 2130968964;
    
    public static final int fontWeight = 2130968965;
    
    public static final int imageAspectRatio = 2130968997;
    
    public static final int imageAspectRatioAdjust = 2130968998;
    
    public static final int keylines = 2130969023;
    
    public static final int lStar = 2130969024;
    
    public static final int layout_anchor = 2130969031;
    
    public static final int layout_anchorGravity = 2130969032;
    
    public static final int layout_behavior = 2130969033;
    
    public static final int layout_dodgeInsetEdges = 2130969082;
    
    public static final int layout_insetEdge = 2130969092;
    
    public static final int layout_keyline = 2130969093;
    
    public static final int location = 2130969118;
    
    public static final int nestedScrollViewStyle = 2130969170;
    
    public static final int queryPatterns = 2130969221;
    
    public static final int scopeUris = 2130969244;
    
    public static final int shortcutMatchRequired = 2130969266;
    
    public static final int size = 2130969289;
    
    public static final int statusBarBackground = 2130969316;
    
    public static final int ttcIndex = 2130969447;
  }
  
  public static final class color {
    public static final int androidx_core_ripple_material_light = 2131099683;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131099684;
    
    public static final int common_google_signin_btn_text_dark = 2131099756;
    
    public static final int common_google_signin_btn_text_dark_default = 2131099757;
    
    public static final int common_google_signin_btn_text_dark_disabled = 2131099758;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131099759;
    
    public static final int common_google_signin_btn_text_dark_pressed = 2131099760;
    
    public static final int common_google_signin_btn_text_light = 2131099761;
    
    public static final int common_google_signin_btn_text_light_default = 2131099762;
    
    public static final int common_google_signin_btn_text_light_disabled = 2131099763;
    
    public static final int common_google_signin_btn_text_light_focused = 2131099764;
    
    public static final int common_google_signin_btn_text_light_pressed = 2131099765;
    
    public static final int common_google_signin_btn_tint = 2131099766;
    
    public static final int notification_action_color_filter = 2131099913;
    
    public static final int notification_icon_bg_color = 2131099914;
    
    public static final int notification_material_background_media_default_color = 2131099915;
    
    public static final int primary_text_default_material_dark = 2131099920;
    
    public static final int ripple_material_light = 2131099925;
    
    public static final int secondary_text_default_material_dark = 2131099926;
    
    public static final int secondary_text_default_material_light = 2131099927;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131165335;
    
    public static final int compat_button_inset_vertical_material = 2131165336;
    
    public static final int compat_button_padding_horizontal_material = 2131165337;
    
    public static final int compat_button_padding_vertical_material = 2131165338;
    
    public static final int compat_control_corner_material = 2131165339;
    
    public static final int compat_notification_large_icon_max_height = 2131165340;
    
    public static final int compat_notification_large_icon_max_width = 2131165341;
    
    public static final int notification_action_icon_size = 2131165522;
    
    public static final int notification_action_text_size = 2131165523;
    
    public static final int notification_big_circle_margin = 2131165524;
    
    public static final int notification_content_margin_start = 2131165525;
    
    public static final int notification_large_icon_height = 2131165526;
    
    public static final int notification_large_icon_width = 2131165527;
    
    public static final int notification_main_column_padding_top = 2131165528;
    
    public static final int notification_media_narrow_margin = 2131165529;
    
    public static final int notification_right_icon_size = 2131165530;
    
    public static final int notification_right_side_padding_top = 2131165531;
    
    public static final int notification_small_icon_background_padding = 2131165532;
    
    public static final int notification_small_icon_size_as_large = 2131165533;
    
    public static final int notification_subtext_size = 2131165534;
    
    public static final int notification_top_pad = 2131165535;
    
    public static final int notification_top_pad_large_text = 2131165536;
  }
  
  public static final class drawable {
    public static final int common_full_open_on_phone = 2131231037;
    
    public static final int common_google_signin_btn_icon_dark = 2131231038;
    
    public static final int common_google_signin_btn_icon_dark_focused = 2131231039;
    
    public static final int common_google_signin_btn_icon_dark_normal = 2131231040;
    
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131231041;
    
    public static final int common_google_signin_btn_icon_disabled = 2131231042;
    
    public static final int common_google_signin_btn_icon_light = 2131231043;
    
    public static final int common_google_signin_btn_icon_light_focused = 2131231044;
    
    public static final int common_google_signin_btn_icon_light_normal = 2131231045;
    
    public static final int common_google_signin_btn_icon_light_normal_background = 2131231046;
    
    public static final int common_google_signin_btn_text_dark = 2131231047;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131231048;
    
    public static final int common_google_signin_btn_text_dark_normal = 2131231049;
    
    public static final int common_google_signin_btn_text_dark_normal_background = 2131231050;
    
    public static final int common_google_signin_btn_text_disabled = 2131231051;
    
    public static final int common_google_signin_btn_text_light = 2131231052;
    
    public static final int common_google_signin_btn_text_light_focused = 2131231053;
    
    public static final int common_google_signin_btn_text_light_normal = 2131231054;
    
    public static final int common_google_signin_btn_text_light_normal_background = 2131231055;
    
    public static final int googleg_disabled_color_18 = 2131231083;
    
    public static final int googleg_standard_color_18 = 2131231084;
    
    public static final int notification_action_background = 2131231420;
    
    public static final int notification_bg = 2131231421;
    
    public static final int notification_bg_low = 2131231422;
    
    public static final int notification_bg_low_normal = 2131231423;
    
    public static final int notification_bg_low_pressed = 2131231424;
    
    public static final int notification_bg_normal = 2131231425;
    
    public static final int notification_bg_normal_pressed = 2131231426;
    
    public static final int notification_icon_background = 2131231427;
    
    public static final int notification_template_icon_bg = 2131231428;
    
    public static final int notification_template_icon_low_bg = 2131231429;
    
    public static final int notification_tile_bg = 2131231430;
    
    public static final int notify_panel_notification_icon_bg = 2131231431;
  }
  
  public static final class id {
    public static final int LEADERBOARD = 2131361801;
    
    public static final int MEDIUM = 2131361802;
    
    public static final int STANDARD = 2131361809;
    
    public static final int accessibility_action_clickable_span = 2131361812;
    
    public static final int accessibility_custom_action_0 = 2131361813;
    
    public static final int accessibility_custom_action_1 = 2131361814;
    
    public static final int accessibility_custom_action_10 = 2131361815;
    
    public static final int accessibility_custom_action_11 = 2131361816;
    
    public static final int accessibility_custom_action_12 = 2131361817;
    
    public static final int accessibility_custom_action_13 = 2131361818;
    
    public static final int accessibility_custom_action_14 = 2131361819;
    
    public static final int accessibility_custom_action_15 = 2131361820;
    
    public static final int accessibility_custom_action_16 = 2131361821;
    
    public static final int accessibility_custom_action_17 = 2131361822;
    
    public static final int accessibility_custom_action_18 = 2131361823;
    
    public static final int accessibility_custom_action_19 = 2131361824;
    
    public static final int accessibility_custom_action_2 = 2131361825;
    
    public static final int accessibility_custom_action_20 = 2131361826;
    
    public static final int accessibility_custom_action_21 = 2131361827;
    
    public static final int accessibility_custom_action_22 = 2131361828;
    
    public static final int accessibility_custom_action_23 = 2131361829;
    
    public static final int accessibility_custom_action_24 = 2131361830;
    
    public static final int accessibility_custom_action_25 = 2131361831;
    
    public static final int accessibility_custom_action_26 = 2131361832;
    
    public static final int accessibility_custom_action_27 = 2131361833;
    
    public static final int accessibility_custom_action_28 = 2131361834;
    
    public static final int accessibility_custom_action_29 = 2131361835;
    
    public static final int accessibility_custom_action_3 = 2131361836;
    
    public static final int accessibility_custom_action_30 = 2131361837;
    
    public static final int accessibility_custom_action_31 = 2131361838;
    
    public static final int accessibility_custom_action_4 = 2131361839;
    
    public static final int accessibility_custom_action_5 = 2131361840;
    
    public static final int accessibility_custom_action_6 = 2131361841;
    
    public static final int accessibility_custom_action_7 = 2131361842;
    
    public static final int accessibility_custom_action_8 = 2131361843;
    
    public static final int accessibility_custom_action_9 = 2131361844;
    
    public static final int action0 = 2131361845;
    
    public static final int action_container = 2131361856;
    
    public static final int action_divider = 2131361858;
    
    public static final int action_image = 2131361859;
    
    public static final int action_text = 2131361866;
    
    public static final int actions = 2131361867;
    
    public static final int adjust_height = 2131361874;
    
    public static final int adjust_width = 2131361875;
    
    public static final int all = 2131361920;
    
    public static final int async = 2131361951;
    
    public static final int auto = 2131361952;
    
    public static final int blocking = 2131361968;
    
    public static final int bottom = 2131361971;
    
    public static final int cancel_action = 2131361987;
    
    public static final int center = 2131361990;
    
    public static final int center_horizontal = 2131361991;
    
    public static final int center_vertical = 2131361992;
    
    public static final int chronometer = 2131361997;
    
    public static final int clip_horizontal = 2131361998;
    
    public static final int clip_vertical = 2131361999;
    
    public static final int dark = 2131362044;
    
    public static final int dialog_button = 2131362060;
    
    public static final int end = 2131362084;
    
    public static final int end_padder = 2131362086;
    
    public static final int fill = 2131362099;
    
    public static final int fill_horizontal = 2131362100;
    
    public static final int fill_vertical = 2131362101;
    
    public static final int forever = 2131362108;
    
    public static final int fragment_container_view_tag = 2131362109;
    
    public static final int icon = 2131362229;
    
    public static final int icon_group = 2131362230;
    
    public static final int icon_only = 2131362231;
    
    public static final int info = 2131362242;
    
    public static final int italic = 2131362267;
    
    public static final int left = 2131362279;
    
    public static final int light = 2131362283;
    
    public static final int line1 = 2131362284;
    
    public static final int line3 = 2131362285;
    
    public static final int media_actions = 2131362461;
    
    public static final int media_controller_compat_view_tag = 2131362462;
    
    public static final int none = 2131362490;
    
    public static final int normal = 2131362491;
    
    public static final int notification_background = 2131362496;
    
    public static final int notification_main_column = 2131362497;
    
    public static final int notification_main_column_container = 2131362498;
    
    public static final int right = 2131362547;
    
    public static final int right_icon = 2131362548;
    
    public static final int right_side = 2131362549;
    
    public static final int special_effects_controller_view_tag = 2131362596;
    
    public static final int standard = 2131362608;
    
    public static final int start = 2131362609;
    
    public static final int status_bar_latest_event_content = 2131362616;
    
    public static final int tag_accessibility_actions = 2131362627;
    
    public static final int tag_accessibility_clickable_spans = 2131362628;
    
    public static final int tag_accessibility_heading = 2131362629;
    
    public static final int tag_accessibility_pane_title = 2131362630;
    
    public static final int tag_on_apply_window_listener = 2131362631;
    
    public static final int tag_on_receive_content_listener = 2131362632;
    
    public static final int tag_on_receive_content_mime_types = 2131362633;
    
    public static final int tag_screen_reader_focusable = 2131362634;
    
    public static final int tag_state_description = 2131362635;
    
    public static final int tag_transition_group = 2131362636;
    
    public static final int tag_unhandled_key_event_manager = 2131362637;
    
    public static final int tag_unhandled_key_listeners = 2131362638;
    
    public static final int tag_window_insets_animation_callback = 2131362639;
    
    public static final int text = 2131362640;
    
    public static final int text2 = 2131362642;
    
    public static final int time = 2131362655;
    
    public static final int title = 2131362657;
    
    public static final int top = 2131362662;
    
    public static final int view_tree_lifecycle_owner = 2131362689;
    
    public static final int view_tree_saved_state_registry_owner = 2131362690;
    
    public static final int view_tree_view_model_store_owner = 2131362691;
    
    public static final int visible_removing_fragment_view_tag = 2131362693;
    
    public static final int wide = 2131362698;
  }
  
  public static final class integer {
    public static final int cancel_button_image_alpha = 2131427336;
    
    public static final int google_play_services_version = 2131427346;
    
    public static final int status_bar_notification_info_maxnum = 2131427357;
  }
  
  public static final class layout {
    public static final int custom_dialog = 2131558458;
    
    public static final int notification_action = 2131558581;
    
    public static final int notification_action_tombstone = 2131558582;
    
    public static final int notification_media_action = 2131558583;
    
    public static final int notification_media_cancel_action = 2131558584;
    
    public static final int notification_template_big_media = 2131558585;
    
    public static final int notification_template_big_media_custom = 2131558586;
    
    public static final int notification_template_big_media_narrow = 2131558587;
    
    public static final int notification_template_big_media_narrow_custom = 2131558588;
    
    public static final int notification_template_custom_big = 2131558589;
    
    public static final int notification_template_icon_group = 2131558590;
    
    public static final int notification_template_lines_media = 2131558591;
    
    public static final int notification_template_media = 2131558592;
    
    public static final int notification_template_media_custom = 2131558593;
    
    public static final int notification_template_part_chronometer = 2131558594;
    
    public static final int notification_template_part_time = 2131558595;
  }
  
  public static final class string {
    public static final int common_google_play_services_enable_button = 2131886237;
    
    public static final int common_google_play_services_enable_text = 2131886238;
    
    public static final int common_google_play_services_enable_title = 2131886239;
    
    public static final int common_google_play_services_install_button = 2131886240;
    
    public static final int common_google_play_services_install_text = 2131886241;
    
    public static final int common_google_play_services_install_title = 2131886242;
    
    public static final int common_google_play_services_notification_channel_name = 2131886243;
    
    public static final int common_google_play_services_notification_ticker = 2131886244;
    
    public static final int common_google_play_services_unknown_issue = 2131886245;
    
    public static final int common_google_play_services_unsupported_text = 2131886246;
    
    public static final int common_google_play_services_update_button = 2131886247;
    
    public static final int common_google_play_services_update_text = 2131886248;
    
    public static final int common_google_play_services_update_title = 2131886249;
    
    public static final int common_google_play_services_updating_text = 2131886250;
    
    public static final int common_google_play_services_wear_update_text = 2131886251;
    
    public static final int common_open_on_phone = 2131886252;
    
    public static final int common_signin_button_text = 2131886253;
    
    public static final int common_signin_button_text_long = 2131886254;
    
    public static final int status_bar_notification_info_overflow = 2131886553;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131951953;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131951954;
    
    public static final int TextAppearance_Compat_Notification_Info_Media = 2131951955;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131951956;
    
    public static final int TextAppearance_Compat_Notification_Line2_Media = 2131951957;
    
    public static final int TextAppearance_Compat_Notification_Media = 2131951958;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131951959;
    
    public static final int TextAppearance_Compat_Notification_Time_Media = 2131951960;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131951961;
    
    public static final int TextAppearance_Compat_Notification_Title_Media = 2131951962;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952135;
    
    public static final int Widget_Compat_NotificationActionText = 2131952136;
    
    public static final int Widget_Support_CoordinatorLayout = 2131952183;
  }
  
  public static final class styleable {
    public static final int[] Banner = new int[] { 2130969118, 2130969289 };
    
    public static final int Banner_location = 0;
    
    public static final int Banner_size = 1;
    
    public static final int[] Capability = new int[] { 2130969221, 2130969266 };
    
    public static final int Capability_queryPatterns = 0;
    
    public static final int Capability_shortcutMatchRequired = 1;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968663, 2130969024 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CoordinatorLayout = new int[] { 2130969023, 2130969316 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130969031, 2130969032, 2130969033, 2130969082, 2130969092, 2130969093 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130968956, 2130968957, 2130968958, 2130968959, 2130968960, 2130968961, 2130968962 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968954, 2130968963, 2130968964, 2130968965, 2130969447 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int[] FragmentContainerView = new int[] { 16842755, 16842961 };
    
    public static final int FragmentContainerView_android_name = 0;
    
    public static final int FragmentContainerView_android_tag = 1;
    
    public static final int Fragment_android_id = 1;
    
    public static final int Fragment_android_name = 0;
    
    public static final int Fragment_android_tag = 2;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LoadingImageView = new int[] { 2130968772, 2130968997, 2130968998 };
    
    public static final int LoadingImageView_circleCrop = 0;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    
    public static final int[] SignInButton = new int[] { 2130968725, 2130968804, 2130969244 };
    
    public static final int SignInButton_buttonSize = 0;
    
    public static final int SignInButton_colorScheme = 1;
    
    public static final int SignInButton_scopeUris = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\chartboost\sdk\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */