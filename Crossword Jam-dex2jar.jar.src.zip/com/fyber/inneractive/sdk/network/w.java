package com.fyber.inneractive.sdk.network;

import android.os.Handler;
import android.os.Looper;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.m;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class w {
  public static final ThreadFactory g = new a();
  
  public BlockingQueue<a0<?>> a = new PriorityBlockingQueue<a0<?>>(100, new d(null));
  
  public volatile boolean b = false;
  
  public final Handler c = new Handler(Looper.getMainLooper());
  
  public final ThreadPoolExecutor d = new ThreadPoolExecutor(6, 6, 1000L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(100), g);
  
  public final Runnable e = new b(this);
  
  public o0 f = new o0();
  
  public final j a(a0<?> parama0, a<?> parama) throws Exception {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface f : ()Z
    //   6: ifne -> 36
    //   9: aload_2
    //   10: ifnull -> 126
    //   13: aload_2
    //   14: getfield a : Ljava/lang/String;
    //   17: astore_2
    //   18: goto -> 21
    //   21: aload_0
    //   22: aload_1
    //   23: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;)V
    //   26: aload_1
    //   27: aload_2
    //   28: invokeinterface a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/network/j;
    //   33: astore_2
    //   34: aload_2
    //   35: areturn
    //   36: aconst_null
    //   37: areturn
    //   38: astore_1
    //   39: ldc 'failed sending network request'
    //   41: aload_1
    //   42: iconst_0
    //   43: anewarray java/lang/Object
    //   46: invokestatic a : (Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
    //   49: aload_1
    //   50: athrow
    //   51: astore_2
    //   52: goto -> 60
    //   55: astore_2
    //   56: goto -> 60
    //   59: astore_2
    //   60: ldc 'failed sending network request'
    //   62: aload_2
    //   63: iconst_0
    //   64: anewarray java/lang/Object
    //   67: invokestatic a : (Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
    //   70: aload_0
    //   71: aload_1
    //   72: invokevirtual e : (Lcom/fyber/inneractive/sdk/network/a0;)Z
    //   75: ifeq -> 87
    //   78: new com/fyber/inneractive/sdk/network/w0
    //   81: dup
    //   82: aload_2
    //   83: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   86: athrow
    //   87: new com/fyber/inneractive/sdk/network/v0
    //   90: dup
    //   91: aload_2
    //   92: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   95: athrow
    //   96: astore_2
    //   97: ldc 'failed sending network request but will retry'
    //   99: aload_2
    //   100: iconst_0
    //   101: anewarray java/lang/Object
    //   104: invokestatic a : (Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
    //   107: aload_0
    //   108: aload_1
    //   109: invokevirtual e : (Lcom/fyber/inneractive/sdk/network/a0;)Z
    //   112: ifeq -> 117
    //   115: aload_2
    //   116: athrow
    //   117: new com/fyber/inneractive/sdk/network/v0
    //   120: dup
    //   121: aload_2
    //   122: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   125: athrow
    //   126: ldc ''
    //   128: astore_2
    //   129: goto -> 21
    // Exception table:
    //   from	to	target	type
    //   0	9	96	com/fyber/inneractive/sdk/network/w0
    //   0	9	59	java/net/UnknownHostException
    //   0	9	55	com/fyber/inneractive/sdk/network/b
    //   0	9	51	java/net/SocketTimeoutException
    //   0	9	38	java/lang/Exception
    //   13	18	96	com/fyber/inneractive/sdk/network/w0
    //   13	18	59	java/net/UnknownHostException
    //   13	18	55	com/fyber/inneractive/sdk/network/b
    //   13	18	51	java/net/SocketTimeoutException
    //   13	18	38	java/lang/Exception
    //   21	34	96	com/fyber/inneractive/sdk/network/w0
    //   21	34	59	java/net/UnknownHostException
    //   21	34	55	com/fyber/inneractive/sdk/network/b
    //   21	34	51	java/net/SocketTimeoutException
    //   21	34	38	java/lang/Exception
  }
  
  public final <T> z a(a0<T> parama0, j paramj) throws Exception {
    if (paramj != null)
      try {
        if (!parama0.f()) {
          int i = paramj.a;
          if (i == 200 || (i >= 300 && i < 304))
            return parama0.a(paramj, paramj.d, i); 
          if (i == 304) {
            parama0.a(null, (Exception)new f(), false);
            return null;
          } 
          parama0.a(null, (Exception)new p0(paramj.a, paramj.b), false);
          return null;
        } 
      } catch (w0 w0) {
        IAlog.a("failed parsing network request but will retry", (Throwable)w0, new Object[0]);
        if (e(parama0))
          throw w0; 
        throw new v0(w0);
      } catch (Exception exception) {
        IAlog.a("failed parsing network request", exception, new Object[0]);
        throw exception;
      }  
    return null;
  }
  
  public final void a(a0<?> parama0) throws b {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface j : ()Lcom/fyber/inneractive/sdk/config/global/s;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 119
    //   11: aload_1
    //   12: ldc com/fyber/inneractive/sdk/config/global/features/k
    //   14: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   17: checkcast com/fyber/inneractive/sdk/config/global/features/k
    //   20: astore_1
    //   21: aload_1
    //   22: ifnull -> 119
    //   25: iconst_0
    //   26: istore_3
    //   27: aload_1
    //   28: ldc 'should_use_is_network_connected'
    //   30: iconst_0
    //   31: invokevirtual a : (Ljava/lang/String;Z)Z
    //   34: ifeq -> 119
    //   37: getstatic com/fyber/inneractive/sdk/util/l.a : Landroid/app/Application;
    //   40: ldc 'connectivity'
    //   42: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   45: checkcast android/net/ConnectivityManager
    //   48: astore_1
    //   49: aload_1
    //   50: ifnull -> 124
    //   53: aload_1
    //   54: invokevirtual getActiveNetworkInfo : ()Landroid/net/NetworkInfo;
    //   57: astore_1
    //   58: goto -> 61
    //   61: iload_3
    //   62: istore_2
    //   63: ldc 'android.permission.ACCESS_NETWORK_STATE'
    //   65: invokestatic b : (Ljava/lang/String;)Z
    //   68: ifeq -> 104
    //   71: iload_3
    //   72: istore_2
    //   73: aload_1
    //   74: ifnull -> 104
    //   77: aload_1
    //   78: invokevirtual isConnectedOrConnecting : ()Z
    //   81: istore #4
    //   83: iload_3
    //   84: istore_2
    //   85: iload #4
    //   87: ifeq -> 104
    //   90: goto -> 102
    //   93: ldc 'Error retrieved when trying to get the network state - Perhaps you forgot to declare android.permission.ACCESS_NETWORK_STATE in your Android manifest file.'
    //   95: iconst_0
    //   96: anewarray java/lang/Object
    //   99: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   102: iconst_1
    //   103: istore_2
    //   104: iload_2
    //   105: ifeq -> 109
    //   108: return
    //   109: new com/fyber/inneractive/sdk/network/b
    //   112: dup
    //   113: ldc 'No network connection'
    //   115: invokespecial <init> : (Ljava/lang/String;)V
    //   118: athrow
    //   119: return
    //   120: astore_1
    //   121: goto -> 93
    //   124: aconst_null
    //   125: astore_1
    //   126: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   37	49	120	finally
    //   53	58	120	finally
    //   63	71	120	finally
    //   77	83	120	finally
  }
  
  public final <T> void a(a0<T> parama0, j paramj, z paramz) {
    try {
      if (!parama0.f() && parama0.c() != null && paramz != null && paramj != null && paramj.a == 200) {
        parama0.a(paramz, parama0.c(), paramj.e);
        return;
      } 
    } catch (Exception exception) {
      IAlog.a("Failed cache network response data", exception, new Object[0]);
    } 
  }
  
  public final <T> void a(a0<T> parama0, z paramz) {
    try {
      if (!parama0.f() && paramz != null) {
        parama0.a(paramz.a, null, false);
        return;
      } 
    } catch (Exception exception) {
      IAlog.a("failed notifying the listener request complete", exception, new Object[0]);
      parama0.a(null, exception, false);
    } 
  }
  
  public final void b(a0<?> parama0) {
    try {
      parama0.b();
    } catch (Exception exception) {}
    parama0.a(n0.DONE);
  }
  
  public void c(a0<?> parama0) {
    this.a.offer(parama0);
    parama0.a(n0.QUEUED);
  }
  
  public final <T> void d(a0<T> parama0) {
    o0 o01 = this.f;
    o01.getClass();
    String str = parama0.e();
    r0 r0 = (r0)o01.a.get(str);
    if (r0 != null) {
      Runnable runnable = r0.d;
      m.b.removeCallbacks(runnable);
    } 
    o01.a.remove(str);
  }
  
  public boolean e(a0<?> parama0) {
    if (parama0.l()) {
      parama0.a(n0.QUEUED_FOR_RETRY);
      long l = parama0.r();
      IAlog.d("retryNetworkRequest queue up in main thread - %s with delay of %d", new Object[] { parama0.getClass().getName(), Long.valueOf(l) });
      this.c.postDelayed(new c(this, parama0), l);
      return true;
    } 
    return false;
  }
  
  public class a implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(100);
    
    public Thread newThread(Runnable param1Runnable) {
      return new Thread(param1Runnable, String.format(Locale.ENGLISH, "FyberMarketplace-Network-%02d", new Object[] { Integer.valueOf(this.a.getAndIncrement()) }));
    }
  }
  
  public class b implements Runnable {
    public b(w this$0) {}
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lcom/fyber/inneractive/sdk/network/w;
      //   4: astore #9
      //   6: aload #9
      //   8: invokevirtual getClass : ()Ljava/lang/Class;
      //   11: pop
      //   12: bipush #10
      //   14: invokestatic setThreadPriority : (I)V
      //   17: aload #9
      //   19: getfield b : Z
      //   22: ifeq -> 507
      //   25: aconst_null
      //   26: astore #8
      //   28: aconst_null
      //   29: astore #6
      //   31: aload #9
      //   33: getfield a : Ljava/util/concurrent/BlockingQueue;
      //   36: invokeinterface take : ()Ljava/lang/Object;
      //   41: checkcast com/fyber/inneractive/sdk/network/a0
      //   44: astore #7
      //   46: goto -> 66
      //   49: aload #9
      //   51: getfield b : Z
      //   54: ifne -> 63
      //   57: invokestatic currentThread : ()Ljava/lang/Thread;
      //   60: invokevirtual interrupt : ()V
      //   63: aconst_null
      //   64: astore #7
      //   66: aload #7
      //   68: ifnull -> 17
      //   71: aload #7
      //   73: invokeinterface f : ()Z
      //   78: ifne -> 17
      //   81: aload #7
      //   83: getstatic com/fyber/inneractive/sdk/network/n0.RUNNING : Lcom/fyber/inneractive/sdk/network/n0;
      //   86: invokeinterface a : (Lcom/fyber/inneractive/sdk/network/n0;)V
      //   91: aload #7
      //   93: invokeinterface j : ()Lcom/fyber/inneractive/sdk/config/global/s;
      //   98: ifnull -> 130
      //   101: aload #7
      //   103: invokeinterface j : ()Lcom/fyber/inneractive/sdk/config/global/s;
      //   108: ldc com/fyber/inneractive/sdk/config/global/features/k
      //   110: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
      //   113: checkcast com/fyber/inneractive/sdk/config/global/features/k
      //   116: ldc 'should_add_request_watchdog'
      //   118: iconst_0
      //   119: invokevirtual a : (Ljava/lang/String;Z)Z
      //   122: ifeq -> 130
      //   125: iconst_1
      //   126: istore_1
      //   127: goto -> 132
      //   130: iconst_0
      //   131: istore_1
      //   132: iload_1
      //   133: ifeq -> 281
      //   136: aload #9
      //   138: getfield f : Lcom/fyber/inneractive/sdk/network/o0;
      //   141: astore #5
      //   143: invokestatic currentThread : ()Ljava/lang/Thread;
      //   146: astore #10
      //   148: aload #5
      //   150: invokevirtual getClass : ()Ljava/lang/Class;
      //   153: pop
      //   154: aload #7
      //   156: invokeinterface j : ()Lcom/fyber/inneractive/sdk/config/global/s;
      //   161: astore #11
      //   163: sipush #500
      //   166: istore_2
      //   167: iload_2
      //   168: istore_1
      //   169: aload #11
      //   171: ifnull -> 204
      //   174: aload #11
      //   176: ldc com/fyber/inneractive/sdk/config/global/features/k
      //   178: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
      //   181: checkcast com/fyber/inneractive/sdk/config/global/features/k
      //   184: ldc 'watchdog_buffer_time_ms'
      //   186: invokevirtual b : (Ljava/lang/String;)Ljava/lang/Integer;
      //   189: astore #11
      //   191: iload_2
      //   192: istore_1
      //   193: aload #11
      //   195: ifnull -> 204
      //   198: aload #11
      //   200: invokevirtual intValue : ()I
      //   203: istore_1
      //   204: aload #7
      //   206: invokeinterface k : ()Lcom/fyber/inneractive/sdk/network/q0;
      //   211: astore #11
      //   213: new com/fyber/inneractive/sdk/network/r0
      //   216: dup
      //   217: aload #7
      //   219: aload #10
      //   221: aload #11
      //   223: getfield a : I
      //   226: aload #11
      //   228: getfield b : I
      //   231: iadd
      //   232: iload_1
      //   233: iadd
      //   234: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/a0;Ljava/lang/Thread;I)V
      //   237: astore #10
      //   239: aload #5
      //   241: getfield a : Ljava/util/concurrent/ConcurrentHashMap;
      //   244: aload #7
      //   246: invokeinterface e : ()Ljava/lang/String;
      //   251: aload #10
      //   253: invokevirtual putIfAbsent : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   256: pop
      //   257: aload #10
      //   259: getfield d : Ljava/lang/Runnable;
      //   262: astore #5
      //   264: aload #10
      //   266: getfield c : I
      //   269: i2l
      //   270: lstore_3
      //   271: getstatic com/fyber/inneractive/sdk/util/m.b : Landroid/os/Handler;
      //   274: aload #5
      //   276: lload_3
      //   277: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
      //   280: pop
      //   281: aload #7
      //   283: invokeinterface f : ()Z
      //   288: ifne -> 337
      //   291: aload #7
      //   293: invokeinterface c : ()Ljava/lang/String;
      //   298: ifnull -> 337
      //   301: aload #7
      //   303: invokeinterface h : ()Lcom/fyber/inneractive/sdk/network/a;
      //   308: astore #5
      //   310: goto -> 340
      //   313: astore #5
      //   315: ldc 'failed fetching cache data'
      //   317: aload #5
      //   319: iconst_0
      //   320: anewarray java/lang/Object
      //   323: invokestatic a : (Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
      //   326: aload #7
      //   328: aconst_null
      //   329: aload #5
      //   331: iconst_1
      //   332: invokeinterface a : (Ljava/lang/Object;Ljava/lang/Exception;Z)V
      //   337: aconst_null
      //   338: astore #5
      //   340: aload #5
      //   342: ifnull -> 377
      //   345: aload #5
      //   347: getfield b : Ljava/lang/Object;
      //   350: ifnull -> 377
      //   353: aload #7
      //   355: invokeinterface f : ()Z
      //   360: ifne -> 377
      //   363: aload #7
      //   365: aload #5
      //   367: getfield b : Ljava/lang/Object;
      //   370: aconst_null
      //   371: iconst_1
      //   372: invokeinterface a : (Ljava/lang/Object;Ljava/lang/Exception;Z)V
      //   377: aload #9
      //   379: aload #7
      //   381: aload #5
      //   383: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;Lcom/fyber/inneractive/sdk/network/a;)Lcom/fyber/inneractive/sdk/network/j;
      //   386: astore #10
      //   388: aload #9
      //   390: aload #7
      //   392: aload #10
      //   394: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;Lcom/fyber/inneractive/sdk/network/j;)Lcom/fyber/inneractive/sdk/network/z;
      //   397: astore #5
      //   399: aload #5
      //   401: astore #6
      //   403: aload #9
      //   405: aload #7
      //   407: aload #10
      //   409: aload #5
      //   411: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;Lcom/fyber/inneractive/sdk/network/j;Lcom/fyber/inneractive/sdk/network/z;)V
      //   414: goto -> 481
      //   417: astore #8
      //   419: goto -> 435
      //   422: goto -> 481
      //   425: astore #5
      //   427: goto -> 455
      //   430: astore #8
      //   432: aconst_null
      //   433: astore #5
      //   435: aload #5
      //   437: astore #6
      //   439: aload #7
      //   441: aconst_null
      //   442: aload #8
      //   444: iconst_0
      //   445: invokeinterface a : (Ljava/lang/Object;Ljava/lang/Exception;Z)V
      //   450: goto -> 481
      //   453: astore #5
      //   455: aload #9
      //   457: aload #7
      //   459: aload #6
      //   461: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;Lcom/fyber/inneractive/sdk/network/z;)V
      //   464: aload #9
      //   466: aload #7
      //   468: invokevirtual b : (Lcom/fyber/inneractive/sdk/network/a0;)V
      //   471: aload #9
      //   473: aload #7
      //   475: invokevirtual d : (Lcom/fyber/inneractive/sdk/network/a0;)V
      //   478: aload #5
      //   480: athrow
      //   481: aload #9
      //   483: aload #7
      //   485: aload #5
      //   487: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/a0;Lcom/fyber/inneractive/sdk/network/z;)V
      //   490: aload #9
      //   492: aload #7
      //   494: invokevirtual b : (Lcom/fyber/inneractive/sdk/network/a0;)V
      //   497: aload #9
      //   499: aload #7
      //   501: invokevirtual d : (Lcom/fyber/inneractive/sdk/network/a0;)V
      //   504: goto -> 17
      //   507: return
      //   508: astore #5
      //   510: goto -> 49
      //   513: astore #5
      //   515: aload #8
      //   517: astore #5
      //   519: goto -> 481
      //   522: astore #6
      //   524: goto -> 422
      // Exception table:
      //   from	to	target	type
      //   31	46	508	java/lang/InterruptedException
      //   281	310	313	java/lang/Exception
      //   377	399	513	com/fyber/inneractive/sdk/network/w0
      //   377	399	430	java/lang/Exception
      //   377	399	425	finally
      //   403	414	522	com/fyber/inneractive/sdk/network/w0
      //   403	414	417	java/lang/Exception
      //   403	414	453	finally
      //   439	450	453	finally
    }
  }
  
  public class c implements Runnable {
    public c(w this$0, a0 param1a0) {}
    
    public void run() {
      IAlog.d("retryNetworkRequest pre-execute - %s", new Object[] { this.a.getClass().getName() });
      this.b.c(this.a);
    }
  }
  
  public static class d implements Comparator<a0> {
    public d() {}
    
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      return param1Object1.g().ordinal() - param1Object2.g().ordinal();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\network\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */