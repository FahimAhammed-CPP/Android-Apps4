package com.fyber.inneractive.sdk.mraid;

public abstract class u {
  public abstract String a();
  
  public String toString() {
    String str2 = a();
    String str1 = "";
    if (str2 != null)
      str1 = str2.replaceAll("[^a-zA-Z0-9_,:\\s\\{\\}\\'\\\"]", ""); 
    return str1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mrai\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */