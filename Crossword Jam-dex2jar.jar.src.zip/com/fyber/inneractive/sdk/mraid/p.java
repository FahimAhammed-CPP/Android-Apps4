package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class p extends b {
  public p(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    boolean bool;
    Map<String, String> map = this.b;
    if (map != null && map.containsKey("allowOrientationChange") && "false".equals(this.b.get("allowOrientationChange"))) {
      bool = false;
    } else {
      bool = true;
    } 
    String str = this.b.get("forceOrientation");
    this.c.setOrientationProperties(bool, str);
  }
  
  public boolean b() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */