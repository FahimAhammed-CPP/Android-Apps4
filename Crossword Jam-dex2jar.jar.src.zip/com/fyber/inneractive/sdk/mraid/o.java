package com.fyber.inneractive.sdk.mraid;

import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.q;
import com.fyber.inneractive.sdk.web.d;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.g;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class o extends b {
  public o(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    int k = a("w");
    int j = a("h");
    int i = a("offsetX");
    int n = a("offsetY");
    boolean bool = "true".equals(this.b.get("allowOffscreen"));
    String str = this.b.get("customClosePosition");
    int m = k;
    if (k <= 0)
      m = this.c.c0; 
    int i1 = j;
    if (j <= 0)
      i1 = this.c.d0; 
    i i2 = this.c;
    g g = ((d)i2).b;
    if (g == null)
      return; 
    try {
      RelativeLayout.LayoutParams layoutParams;
      ViewGroup viewGroup = (ViewGroup)g.getRootView().findViewById(16908290);
      i2.U = viewGroup;
      if (viewGroup == null) {
        IAlog.e("Couldn't find content in the view tree", new Object[0]);
        i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
        return;
      } 
      if (i2.R == i.d.DISABLED)
        return; 
      b0 b02 = i2.Q;
      if (b02 != b0.DEFAULT && b02 != b0.RESIZED) {
        i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
        return;
      } 
      if (m < 0 && i1 < 0) {
        i2.a(g.RESIZE, "Creative size passed to resize() was invalid.");
        return;
      } 
      i2.c(false);
      i.h h = i2.S;
      if (h == i.h.ALWAYS_VISIBLE || (!i2.a0 && h != i.h.ALWAYS_HIDDEN))
        i2.d(true); 
      i2.e(false);
      i2.h0 = l.b(i1);
      i2.g0 = l.b(m);
      int i3 = i;
      k = n;
      if (!bool) {
        k = i + m - i2.c0;
        j = i;
        if (k > 0)
          j = i - k; 
        i = j;
        if (j < 0)
          i = 0; 
        k = n + i1 - i2.d0;
        j = n;
        if (k > 0)
          j = n - k; 
        i3 = i;
        k = j;
        if (j < 0) {
          k = 0;
          i3 = i;
        } 
      } 
      ViewGroup.LayoutParams layoutParams1 = ((d)i2).b.getLayoutParams();
      if (layoutParams1 instanceof RelativeLayout.LayoutParams) {
        int[] arrayOfInt;
        ViewGroup.LayoutParams layoutParams2 = null;
        layoutParams1 = layoutParams2;
        if (i3 == 0) {
          layoutParams1 = layoutParams2;
          if (k == 0) {
            arrayOfInt = new int[1];
            arrayOfInt[0] = 13;
          } 
        } 
        layoutParams = q.a(l.b(m), l.b(i1), arrayOfInt);
        layoutParams.leftMargin = i3;
        layoutParams.topMargin = k;
        ((d)i2).b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      } else if (layoutParams instanceof FrameLayout.LayoutParams) {
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(l.b(m), l.b(i1), 17);
        ((d)i2).b.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      } 
      b0 b01 = i2.Q;
      b0 b03 = b0.RESIZED;
      if (b01 != b03) {
        i2.Q = b03;
        i2.a((u)new z(b03));
        i = i2.g0;
        if (i != -1 && i2.h0 != -1)
          i2.a(new t(l.c(i), l.c(i2.h0))); 
      } 
      i2.a(g.RESIZE);
      d0 d0 = ((d)i2).g;
      if (d0 != null) {
        ((i.f)d0).b(i2);
        return;
      } 
    } catch (Exception exception) {
      IAlog.e("Couldn't find content in the view tree", new Object[0]);
      i2.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
    } 
  }
  
  public boolean b() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */