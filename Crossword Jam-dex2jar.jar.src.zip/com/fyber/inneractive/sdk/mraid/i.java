package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.k0;
import java.util.Map;

public class i extends b {
  public i(Map<String, String> paramMap, com.fyber.inneractive.sdk.web.i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    this.c.a(g.GET_DEFAULT_POSITION, "Unsupported action getDefaultPosition");
  }
  
  public boolean b() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */