package com.fyber.inneractive.sdk.mraid;

import android.content.Context;
import android.content.Intent;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.i;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import java.util.Map;

public class d extends a {
  public d(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.inneractive");
    paramContext.startActivity(paramIntent);
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Lcom/fyber/inneractive/sdk/web/i;
    //   4: astore_3
    //   5: aload_0
    //   6: getfield b : Ljava/util/Map;
    //   9: astore #5
    //   11: aload_3
    //   12: invokevirtual m : ()Landroid/content/Context;
    //   15: astore #4
    //   17: new android/content/Intent
    //   20: dup
    //   21: ldc 'android.intent.action.INSERT'
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: ldc 'vnd.android.cursor.item/event'
    //   28: invokevirtual setType : (Ljava/lang/String;)Landroid/content/Intent;
    //   31: invokestatic a : (Landroid/content/Intent;)Z
    //   34: istore_2
    //   35: iconst_1
    //   36: istore_1
    //   37: iload_2
    //   38: ifeq -> 279
    //   41: aload_3
    //   42: aload #5
    //   44: invokevirtual a : (Ljava/util/Map;)Ljava/util/Map;
    //   47: astore #6
    //   49: new android/content/Intent
    //   52: dup
    //   53: ldc 'android.intent.action.INSERT'
    //   55: invokespecial <init> : (Ljava/lang/String;)V
    //   58: ldc 'vnd.android.cursor.item/event'
    //   60: invokevirtual setType : (Ljava/lang/String;)Landroid/content/Intent;
    //   63: astore #5
    //   65: aload #6
    //   67: checkcast java/util/HashMap
    //   70: astore #6
    //   72: aload #6
    //   74: invokevirtual keySet : ()Ljava/util/Set;
    //   77: invokeinterface iterator : ()Ljava/util/Iterator;
    //   82: astore #7
    //   84: aload #7
    //   86: invokeinterface hasNext : ()Z
    //   91: ifeq -> 185
    //   94: aload #7
    //   96: invokeinterface next : ()Ljava/lang/Object;
    //   101: checkcast java/lang/String
    //   104: astore #8
    //   106: aload #6
    //   108: aload #8
    //   110: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   113: astore #9
    //   115: aload #9
    //   117: instanceof java/lang/Long
    //   120: ifeq -> 142
    //   123: aload #5
    //   125: aload #8
    //   127: aload #9
    //   129: checkcast java/lang/Long
    //   132: invokevirtual longValue : ()J
    //   135: invokevirtual putExtra : (Ljava/lang/String;J)Landroid/content/Intent;
    //   138: pop
    //   139: goto -> 84
    //   142: aload #9
    //   144: instanceof java/lang/Integer
    //   147: ifeq -> 169
    //   150: aload #5
    //   152: aload #8
    //   154: aload #9
    //   156: checkcast java/lang/Integer
    //   159: invokevirtual intValue : ()I
    //   162: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   165: pop
    //   166: goto -> 84
    //   169: aload #5
    //   171: aload #8
    //   173: aload #9
    //   175: checkcast java/lang/String
    //   178: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   181: pop
    //   182: goto -> 84
    //   185: aload #5
    //   187: ldc 268435456
    //   189: invokevirtual setFlags : (I)Landroid/content/Intent;
    //   192: pop
    //   193: aload #4
    //   195: aload #5
    //   197: invokestatic safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6 : (Landroid/content/Context;Landroid/content/Intent;)V
    //   200: goto -> 299
    //   203: ldc 'Failed to create calendar event.'
    //   205: iconst_0
    //   206: anewarray java/lang/Object
    //   209: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   212: aload_3
    //   213: getstatic com/fyber/inneractive/sdk/mraid/g.CREATE_CALENDAR_EVENT : Lcom/fyber/inneractive/sdk/mraid/g;
    //   216: ldc 'could not create calendar event'
    //   218: invokevirtual a : (Lcom/fyber/inneractive/sdk/mraid/g;Ljava/lang/String;)V
    //   221: goto -> 297
    //   224: astore #4
    //   226: ldc 'invalid parameters for create calendar '
    //   228: iconst_1
    //   229: anewarray java/lang/Object
    //   232: dup
    //   233: iconst_0
    //   234: aload #4
    //   236: invokevirtual getMessage : ()Ljava/lang/String;
    //   239: aastore
    //   240: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   243: aload_3
    //   244: getstatic com/fyber/inneractive/sdk/mraid/g.CREATE_CALENDAR_EVENT : Lcom/fyber/inneractive/sdk/mraid/g;
    //   247: aload #4
    //   249: invokevirtual getMessage : ()Ljava/lang/String;
    //   252: invokevirtual a : (Lcom/fyber/inneractive/sdk/mraid/g;Ljava/lang/String;)V
    //   255: goto -> 297
    //   258: ldc 'There is no calendar app installed!'
    //   260: iconst_0
    //   261: anewarray java/lang/Object
    //   264: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   267: aload_3
    //   268: getstatic com/fyber/inneractive/sdk/mraid/g.CREATE_CALENDAR_EVENT : Lcom/fyber/inneractive/sdk/mraid/g;
    //   271: ldc 'Action is unsupported on this device - no calendar app installed'
    //   273: invokevirtual a : (Lcom/fyber/inneractive/sdk/mraid/g;Ljava/lang/String;)V
    //   276: goto -> 297
    //   279: ldc 'createCalendarEvent supported for devices post-ICS'
    //   281: iconst_0
    //   282: anewarray java/lang/Object
    //   285: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   288: aload_3
    //   289: getstatic com/fyber/inneractive/sdk/mraid/g.CREATE_CALENDAR_EVENT : Lcom/fyber/inneractive/sdk/mraid/g;
    //   292: ldc 'Action is unsupported on this device (need Android version Ice Cream Sandwich or above)'
    //   294: invokevirtual a : (Lcom/fyber/inneractive/sdk/mraid/g;Ljava/lang/String;)V
    //   297: iconst_0
    //   298: istore_1
    //   299: iload_1
    //   300: ifeq -> 321
    //   303: aload_3
    //   304: getfield g : Lcom/fyber/inneractive/sdk/web/d0;
    //   307: astore_3
    //   308: aload_3
    //   309: ifnull -> 321
    //   312: aload_3
    //   313: checkcast com/fyber/inneractive/sdk/web/i$f
    //   316: invokeinterface c : ()V
    //   321: return
    //   322: astore #4
    //   324: goto -> 258
    //   327: astore #4
    //   329: goto -> 203
    // Exception table:
    //   from	to	target	type
    //   41	84	322	android/content/ActivityNotFoundException
    //   41	84	224	java/lang/IllegalArgumentException
    //   41	84	327	java/lang/Exception
    //   84	139	322	android/content/ActivityNotFoundException
    //   84	139	224	java/lang/IllegalArgumentException
    //   84	139	327	java/lang/Exception
    //   142	166	322	android/content/ActivityNotFoundException
    //   142	166	224	java/lang/IllegalArgumentException
    //   142	166	327	java/lang/Exception
    //   169	182	322	android/content/ActivityNotFoundException
    //   169	182	224	java/lang/IllegalArgumentException
    //   169	182	327	java/lang/Exception
    //   185	200	322	android/content/ActivityNotFoundException
    //   185	200	224	java/lang/IllegalArgumentException
    //   185	200	327	java/lang/Exception
  }
  
  public String c() {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */