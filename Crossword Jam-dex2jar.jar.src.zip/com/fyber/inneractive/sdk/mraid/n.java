package com.fyber.inneractive.sdk.mraid;

import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.web.d;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.i;
import java.util.Map;

public class n extends a {
  public n(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    String str = this.b.get("uri");
    if (str != null && !"".equals(str)) {
      d0 d0 = ((d)this.c).g;
      if (d0 != null) {
        ((i.f)d0).a(str);
        return;
      } 
    } else {
      this.c.a(g.PLAY_VIDEO, "Video can't be played with null or empty URL");
    } 
  }
  
  public String c() {
    return this.b.get("uri");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */