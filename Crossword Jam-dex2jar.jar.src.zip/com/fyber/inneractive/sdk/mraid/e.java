package com.fyber.inneractive.sdk.mraid;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import android.window.OnBackInvokedCallback;
import com.fyber.inneractive.sdk.R;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.q;
import com.fyber.inneractive.sdk.web.d;
import com.fyber.inneractive.sdk.web.d0;
import com.fyber.inneractive.sdk.web.g;
import com.fyber.inneractive.sdk.web.h;
import com.fyber.inneractive.sdk.web.i;
import com.fyber.inneractive.sdk.web.m;
import com.fyber.inneractive.sdk.web.n;
import com.safedk.android.internal.partials.FyberNetworkBridge;
import java.util.Map;

public class e extends a {
  public e(Map<String, String> paramMap, i parami, k0 paramk0) {
    super(paramMap, parami, paramk0);
  }
  
  public void a() {
    int j = a("w");
    int k = a("h");
    String str = this.b.get("url");
    boolean bool1 = "true".equals(this.b.get("shouldUseCustomClose"));
    boolean bool2 = "true".equals(this.b.get("lockOrientation"));
    int i = j;
    if (j <= 0)
      i = -1; 
    j = k;
    if (k <= 0)
      j = -1; 
    i i1 = this.c;
    if (((d)i1).b == null)
      return; 
    if (i1.R == i.d.DISABLED)
      return; 
    if (i1.Q != b0.DEFAULT)
      return; 
    if (str != null && !URLUtil.isValidUrl(str)) {
      i1.a(g.EXPAND, "URL passed to expand() was invalid.");
      return;
    } 
    try {
      ViewGroup viewGroup = (ViewGroup)((d)i1).b.getRootView().findViewById(16908290);
      i1.U = viewGroup;
      if (viewGroup == null) {
        IAlog.e("Couldn't find content in the view tree", new Object[0]);
        i1.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
        return;
      } 
      if (Build.VERSION.SDK_INT >= 33) {
        i1.p0 = (OnBackInvokedCallback)new m(i1);
        if (i1.m() instanceof Activity)
          ((Activity)i1.m()).getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, i1.p0); 
      } 
      i1.a0 = bool1;
      d0 d02 = ((d)i1).g;
      if (d02 != null)
        ((i.f)d02).a(i1, bool1); 
      i1.e(bool2);
      if (i1.h0 >= 0)
        i1.h0 = l.b(j); 
      if (i1.g0 >= 0)
        i1.g0 = l.b(i); 
      g g = ((d)i1).b;
      if (str != null) {
        g = new g(i1.m());
        i1.V = g;
        g.setId(R.id.inneractive_webview_mraid);
        FyberNetworkBridge.webviewLoadUrl((WebView)i1.V, str);
        i1.V.setWebChromeClient((WebChromeClient)((d)i1).c);
        i1.V.setWebViewClient((WebViewClient)((d)i1).d);
        g = i1.V;
        g.setOnKeyListener((View.OnKeyListener)new n(i1));
      } else {
        ViewGroup viewGroup1 = (ViewGroup)g.getParent();
        if (viewGroup1 != null) {
          int i2 = viewGroup1.getChildCount();
          for (k = 0; k < i2 && viewGroup1.getChildAt(k) != ((d)i1).b; k++);
          i1.j0 = k;
          q.a((View)i1.k0);
          RelativeLayout.LayoutParams layoutParams1 = q.a(((d)i1).b.getWidth(), ((d)i1).b.getHeight(), new int[] { 13 });
          viewGroup1.addView((View)i1.k0, k, (ViewGroup.LayoutParams)layoutParams1);
          viewGroup1.removeView((View)((d)i1).b);
        } 
      } 
      float f = i1.b0;
      int m = (int)(50.0F * f + 0.5F);
      int n = i;
      k = j;
      if (j >= 0) {
        n = i;
        k = j;
        if (i >= 0) {
          k = (int)(i * f);
          j = (int)(j * f);
          i = k;
          if (k < m)
            i = m; 
          n = i;
          k = j;
          if (j < m) {
            k = m;
            n = i;
          } 
        } 
      } 
      View view = new View(i1.m());
      view.setBackgroundColor(i1.m().getResources().getColor(R.color.ia_mraid_expanded_dimmed_bk));
      view.setOnTouchListener((View.OnTouchListener)new h(i1));
      i1.m0.addView(view, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      q.a((View)g);
      i1.l0.addView((View)g, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      q.a((View)i1.l0);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n, k);
      layoutParams.addRule(13);
      i1.m0.addView((View)i1.l0, (ViewGroup.LayoutParams)layoutParams);
      q.a((View)i1.m0);
      i1.U.addView((View)i1.m0, new ViewGroup.LayoutParams(-1, -1));
      if (!g.hasFocus())
        g.requestFocus(); 
      i.h h = i1.S;
      if (h == i.h.ALWAYS_VISIBLE || (!i1.a0 && h != i.h.ALWAYS_HIDDEN))
        i1.d(true); 
      b0 b0 = b0.EXPANDED;
      i1.Q = b0;
      i1.a((u)new z(b0));
      i = i1.g0;
      if (i != -1 && i1.h0 != -1)
        i1.a(new t(l.c(i), l.c(i1.h0))); 
      i1.a(g.EXPAND);
      if (i1.m() != null) {
        i = (int)i1.m().getResources().getDimension(R.dimen.identifier_padding);
        g g1 = ((d)i1).b;
        if (g1 != null) {
          RelativeLayout relativeLayout = (RelativeLayout)g1.findViewById(R.id.ia_identifier_overlay);
          if (relativeLayout != null)
            relativeLayout.setPadding(i, 0, 0, i); 
        } 
      } 
      d0 d01 = ((d)i1).g;
      if (d01 != null) {
        ((i.f)d01).a(i1);
        return;
      } 
    } catch (Exception exception) {
      IAlog.e("Couldn't find content in the view tree", new Object[0]);
      i1.a(g.RESIZE, "Ad can be resized only if it's state is default or resized.");
    } 
  }
  
  public String c() {
    return this.b.get("url");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\mraid\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */