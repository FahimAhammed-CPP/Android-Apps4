package com.fyber.inneractive.sdk.config.remote;

public class a implements d, c {
  public String a;
  
  public String b;
  
  public f c;
  
  public j d;
  
  public b e;
  
  public k f;
  
  public String g;
  
  public j a() {
    return this.d;
  }
  
  public String b() {
    return this.g;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */