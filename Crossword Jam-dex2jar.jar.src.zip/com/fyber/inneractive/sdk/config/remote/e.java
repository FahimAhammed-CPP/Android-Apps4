package com.fyber.inneractive.sdk.config.remote;

import com.fyber.inneractive.sdk.external.InvalidAppIdException;
import java.util.List;
import org.json.JSONObject;

public class e {
  public a a;
  
  public List<h> b = null;
  
  public String c;
  
  public String d;
  
  public static e a(JSONObject paramJSONObject) throws InvalidAppIdException {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aload_0
    //   4: ldc 'updateHash'
    //   6: aconst_null
    //   7: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   10: astore_3
    //   11: aload_3
    //   12: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   15: ifeq -> 20
    //   18: aconst_null
    //   19: areturn
    //   20: new com/fyber/inneractive/sdk/config/remote/e
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #8
    //   29: aload #8
    //   31: aload_3
    //   32: putfield c : Ljava/lang/String;
    //   35: aload_0
    //   36: ldc 'app'
    //   38: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   41: astore #6
    //   43: aload #6
    //   45: ifnonnull -> 53
    //   48: iconst_m1
    //   49: istore_1
    //   50: goto -> 62
    //   53: aload #6
    //   55: ldc 'id'
    //   57: iconst_m1
    //   58: invokevirtual optInt : (Ljava/lang/String;I)I
    //   61: istore_1
    //   62: ldc 'isActive'
    //   64: astore #5
    //   66: iload_1
    //   67: iconst_m1
    //   68: if_icmpne -> 76
    //   71: aconst_null
    //   72: astore_3
    //   73: goto -> 183
    //   76: new com/fyber/inneractive/sdk/config/remote/a
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore_3
    //   84: aload_3
    //   85: iload_1
    //   86: invokestatic valueOf : (I)Ljava/lang/String;
    //   89: putfield a : Ljava/lang/String;
    //   92: aload_3
    //   93: aload #6
    //   95: ldc 'publisherId'
    //   97: aconst_null
    //   98: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   101: putfield b : Ljava/lang/String;
    //   104: aload_3
    //   105: aload #6
    //   107: ldc 'monitor'
    //   109: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   112: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/f;
    //   115: putfield c : Lcom/fyber/inneractive/sdk/config/remote/f;
    //   118: aload_3
    //   119: aload #6
    //   121: ldc 'video'
    //   123: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   126: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/j;
    //   129: putfield d : Lcom/fyber/inneractive/sdk/config/remote/j;
    //   132: aload_3
    //   133: aload #6
    //   135: ldc 'display'
    //   137: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   140: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/b;
    //   143: putfield e : Lcom/fyber/inneractive/sdk/config/remote/b;
    //   146: aload_3
    //   147: aload #6
    //   149: ldc 'viewability'
    //   151: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   154: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/k;
    //   157: putfield f : Lcom/fyber/inneractive/sdk/config/remote/k;
    //   160: aload_3
    //   161: aload #6
    //   163: ldc 'isActive'
    //   165: aconst_null
    //   166: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   169: putfield g : Ljava/lang/String;
    //   172: aload #6
    //   174: ldc 'native'
    //   176: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   179: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/g;
    //   182: pop
    //   183: aload_3
    //   184: ifnonnull -> 189
    //   187: aconst_null
    //   188: areturn
    //   189: aload #8
    //   191: aload_3
    //   192: putfield a : Lcom/fyber/inneractive/sdk/config/remote/a;
    //   195: new java/util/ArrayList
    //   198: dup
    //   199: invokespecial <init> : ()V
    //   202: astore #9
    //   204: aload_0
    //   205: ldc 'spots'
    //   207: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   210: astore_3
    //   211: aload_3
    //   212: ifnull -> 637
    //   215: iconst_0
    //   216: istore_1
    //   217: aload #5
    //   219: astore_0
    //   220: iload_1
    //   221: aload_3
    //   222: invokevirtual length : ()I
    //   225: if_icmpge -> 637
    //   228: aload_3
    //   229: iload_1
    //   230: invokevirtual optJSONObject : (I)Lorg/json/JSONObject;
    //   233: astore #5
    //   235: aload #5
    //   237: ifnonnull -> 243
    //   240: goto -> 262
    //   243: aload #5
    //   245: ldc 'id'
    //   247: aload #4
    //   249: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   252: astore #7
    //   254: aload #7
    //   256: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   259: ifeq -> 279
    //   262: aload_0
    //   263: astore #5
    //   265: aload #4
    //   267: astore_0
    //   268: aload #4
    //   270: astore #6
    //   272: aload #5
    //   274: astore #4
    //   276: goto -> 607
    //   279: new com/fyber/inneractive/sdk/config/remote/h
    //   282: dup
    //   283: invokespecial <init> : ()V
    //   286: astore #6
    //   288: aload #6
    //   290: aload #7
    //   292: putfield a : Ljava/lang/String;
    //   295: aload #6
    //   297: aload #5
    //   299: aload_0
    //   300: aload #4
    //   302: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   305: putfield b : Ljava/lang/String;
    //   308: aload #6
    //   310: aload #5
    //   312: ldc 'display'
    //   314: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   317: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/b;
    //   320: putfield c : Lcom/fyber/inneractive/sdk/config/remote/b;
    //   323: aload #6
    //   325: aload #5
    //   327: ldc 'monitor'
    //   329: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   332: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/f;
    //   335: putfield d : Lcom/fyber/inneractive/sdk/config/remote/f;
    //   338: aload #5
    //   340: ldc 'native'
    //   342: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   345: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/g;
    //   348: pop
    //   349: aload #6
    //   351: aload #5
    //   353: ldc 'video'
    //   355: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   358: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/j;
    //   361: putfield e : Lcom/fyber/inneractive/sdk/config/remote/j;
    //   364: aload #6
    //   366: aload #5
    //   368: ldc 'viewability'
    //   370: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   373: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/k;
    //   376: putfield f : Lcom/fyber/inneractive/sdk/config/remote/k;
    //   379: aload #5
    //   381: ldc 'units'
    //   383: invokevirtual optJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   386: astore #7
    //   388: aload #7
    //   390: ifnull -> 577
    //   393: aload #7
    //   395: invokevirtual length : ()I
    //   398: ifne -> 404
    //   401: goto -> 577
    //   404: new java/util/ArrayList
    //   407: dup
    //   408: invokespecial <init> : ()V
    //   411: astore #5
    //   413: iconst_0
    //   414: istore_2
    //   415: aload #7
    //   417: astore #4
    //   419: iload_2
    //   420: aload #4
    //   422: invokevirtual length : ()I
    //   425: if_icmpge -> 569
    //   428: aload #4
    //   430: iload_2
    //   431: invokevirtual optJSONObject : (I)Lorg/json/JSONObject;
    //   434: astore #7
    //   436: aload #7
    //   438: ifnull -> 562
    //   441: new com/fyber/inneractive/sdk/config/remote/i
    //   444: dup
    //   445: invokespecial <init> : ()V
    //   448: astore #10
    //   450: aload #10
    //   452: aload #7
    //   454: ldc 'id'
    //   456: aconst_null
    //   457: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   460: putfield a : Ljava/lang/String;
    //   463: aload #10
    //   465: aload #7
    //   467: ldc 'spotId'
    //   469: aconst_null
    //   470: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   473: putfield b : Ljava/lang/String;
    //   476: aload #10
    //   478: aload #7
    //   480: ldc 'display'
    //   482: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   485: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/b;
    //   488: putfield c : Lcom/fyber/inneractive/sdk/config/remote/b;
    //   491: aload #10
    //   493: aload #7
    //   495: ldc 'monitor'
    //   497: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   500: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/f;
    //   503: putfield d : Lcom/fyber/inneractive/sdk/config/remote/f;
    //   506: aload #10
    //   508: aload #7
    //   510: ldc 'native'
    //   512: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   515: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/g;
    //   518: putfield e : Lcom/fyber/inneractive/sdk/config/remote/g;
    //   521: aload #10
    //   523: aload #7
    //   525: ldc 'video'
    //   527: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   530: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/j;
    //   533: putfield f : Lcom/fyber/inneractive/sdk/config/remote/j;
    //   536: aload #10
    //   538: aload #7
    //   540: ldc 'viewability'
    //   542: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   545: invokestatic a : (Lorg/json/JSONObject;)Lcom/fyber/inneractive/sdk/config/remote/k;
    //   548: putfield g : Lcom/fyber/inneractive/sdk/config/remote/k;
    //   551: aload #5
    //   553: aload #10
    //   555: invokevirtual add : (Ljava/lang/Object;)Z
    //   558: pop
    //   559: goto -> 562
    //   562: iload_2
    //   563: iconst_1
    //   564: iadd
    //   565: istore_2
    //   566: goto -> 419
    //   569: aload_0
    //   570: astore #4
    //   572: aconst_null
    //   573: astore_0
    //   574: goto -> 600
    //   577: aload_0
    //   578: astore #5
    //   580: aload #4
    //   582: astore_0
    //   583: new java/util/ArrayList
    //   586: dup
    //   587: invokespecial <init> : ()V
    //   590: astore #7
    //   592: aload #5
    //   594: astore #4
    //   596: aload #7
    //   598: astore #5
    //   600: aload #6
    //   602: aload #5
    //   604: putfield g : Ljava/util/List;
    //   607: aload #6
    //   609: ifnull -> 620
    //   612: aload #9
    //   614: aload #6
    //   616: invokevirtual add : (Ljava/lang/Object;)Z
    //   619: pop
    //   620: iload_1
    //   621: iconst_1
    //   622: iadd
    //   623: istore_1
    //   624: aload #4
    //   626: astore #5
    //   628: aload_0
    //   629: astore #4
    //   631: aload #5
    //   633: astore_0
    //   634: goto -> 220
    //   637: aload #8
    //   639: aload #9
    //   641: putfield b : Ljava/util/List;
    //   644: aload #8
    //   646: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */