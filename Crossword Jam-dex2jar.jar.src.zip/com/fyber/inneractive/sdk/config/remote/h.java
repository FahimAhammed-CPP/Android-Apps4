package com.fyber.inneractive.sdk.config.remote;

import java.util.List;

public class h implements d, c {
  public String a;
  
  public String b;
  
  public b c;
  
  public f d;
  
  public j e;
  
  public k f;
  
  public List<i> g = null;
  
  public j a() {
    return this.e;
  }
  
  public String b() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */