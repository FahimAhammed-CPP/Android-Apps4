package com.fyber.inneractive.sdk.config.remote;

import com.fyber.inneractive.sdk.config.enums.Orientation;
import com.fyber.inneractive.sdk.config.enums.Skip;
import com.fyber.inneractive.sdk.config.enums.TapAction;
import com.fyber.inneractive.sdk.config.enums.UnitDisplayType;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class j {
  public Boolean a;
  
  public Integer b;
  
  public Integer c;
  
  public Skip d;
  
  public Boolean e;
  
  public TapAction f;
  
  public Orientation g;
  
  public Integer h;
  
  public Integer i;
  
  public UnitDisplayType j;
  
  public List<Integer> k = new ArrayList<Integer>();
  
  public static j a(JSONObject paramJSONObject) {
    Integer integer2 = null;
    if (paramJSONObject == null)
      return null; 
    j j1 = new j();
    Integer integer6 = Integer.valueOf(paramJSONObject.optInt("maxBitrate", -2147483648));
    Integer integer5 = Integer.valueOf(paramJSONObject.optInt("minBitrate", -2147483648));
    Integer integer4 = Integer.valueOf(paramJSONObject.optInt("pivotBitrate", -2147483648));
    Integer integer3 = Integer.valueOf(paramJSONObject.optInt("padding", -2147483648));
    Integer integer1 = integer6;
    if (integer6.intValue() == Integer.MIN_VALUE)
      integer1 = null; 
    j1.b = integer1;
    integer1 = integer5;
    if (integer5.intValue() == Integer.MIN_VALUE)
      integer1 = null; 
    j1.c = integer1;
    j1.d = Skip.fromValue(Integer.valueOf(paramJSONObject.optInt("skip", -2147483648)));
    if (paramJSONObject.has("muted")) {
      Boolean bool = Boolean.valueOf(paramJSONObject.optBoolean("muted", true));
    } else {
      integer1 = null;
    } 
    j1.e = (Boolean)integer1;
    if (paramJSONObject.has("autoPlay")) {
      Boolean bool = Boolean.valueOf(paramJSONObject.optBoolean("autoPlay", true));
    } else {
      integer1 = null;
    } 
    j1.a = (Boolean)integer1;
    j1.g = Orientation.fromValue(paramJSONObject.optString("orientation"));
    j1.f = TapAction.fromValue(paramJSONObject.optString("tap"));
    integer1 = integer4;
    if (integer4.intValue() == Integer.MIN_VALUE)
      integer1 = null; 
    j1.h = integer1;
    if (integer3.intValue() == Integer.MIN_VALUE) {
      integer1 = integer2;
    } else {
      integer1 = integer3;
    } 
    j1.i = integer1;
    j1.j = UnitDisplayType.fromValue(paramJSONObject.optString("unitDisplayType"));
    JSONArray jSONArray = paramJSONObject.optJSONArray("filterApi");
    if (jSONArray != null)
      for (int i = 0; i < jSONArray.length(); i++) {
        int k = jSONArray.optInt(i, -2147483648);
        if (k != Integer.MIN_VALUE)
          j1.k.add(Integer.valueOf(k)); 
      }  
    return j1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */