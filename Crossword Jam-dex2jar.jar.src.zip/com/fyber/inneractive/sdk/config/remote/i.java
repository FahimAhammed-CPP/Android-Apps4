package com.fyber.inneractive.sdk.config.remote;

public class i implements d {
  public String a;
  
  public String b;
  
  public b c;
  
  public f d;
  
  public g e;
  
  public j f;
  
  public k g;
  
  public j a() {
    return this.f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\config\remote\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */