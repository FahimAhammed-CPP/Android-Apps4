package com.fyber.inneractive.sdk.util;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class i<T> {
  public final Queue<T> a = new ConcurrentLinkedQueue<T>();
  
  public a<T> b;
  
  public i(int paramInt, a<T> parama) {
    for (int j = 0; j < paramInt; j++)
      this.a.offer(parama.a()); 
    this.b = parama;
  }
  
  public T a() {
    T t2 = this.a.poll();
    T t1 = t2;
    if (t2 == null)
      t1 = this.b.a(); 
    return t1;
  }
  
  public static interface a<TT> {
    TT a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sd\\util\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */