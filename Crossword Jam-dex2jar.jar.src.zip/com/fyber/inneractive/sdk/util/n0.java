package com.fyber.inneractive.sdk.util;

import com.fyber.inneractive.sdk.config.f;

public class n0 {
  public static boolean a(String paramString) {
    int i = f.a;
    String str = System.getProperty("ia.testEnvironmentConfiguration.response");
    return (str != null && str.trim().length() > 0 && paramString != null && paramString.toLowerCase().startsWith("fyberInternalTesting".toLowerCase()) && paramString.contains("crash"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sd\\util\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */