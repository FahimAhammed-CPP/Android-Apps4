package com.fyber.inneractive.sdk.util;

public class l0 {
  public int a;
  
  public int b;
  
  public l0(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (l0.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.a != ((l0)paramObject).a) ? false : ((this.b == ((l0)paramObject).b));
    } 
    return false;
  }
  
  public int hashCode() {
    return this.a * 31 + this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sd\\util\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */