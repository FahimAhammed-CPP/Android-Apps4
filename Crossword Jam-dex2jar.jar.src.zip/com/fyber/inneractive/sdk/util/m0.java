package com.fyber.inneractive.sdk.util;

public class m0 {
  public static String a(String paramString, int paramInt) {
    String str = paramString;
    if (paramInt > 0) {
      if (paramString.length() <= paramInt)
        return paramString; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString.substring(0, paramInt - 3));
      stringBuilder.append("...");
      str = stringBuilder.toString();
    } 
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sd\\util\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */