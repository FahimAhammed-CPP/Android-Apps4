package com.fyber.inneractive.sdk.activities;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.fyber.inneractive.sdk.R;
import com.fyber.inneractive.sdk.click.d;
import com.fyber.inneractive.sdk.click.f;
import com.fyber.inneractive.sdk.click.g;
import com.fyber.inneractive.sdk.click.h;
import com.fyber.inneractive.sdk.click.j;
import com.fyber.inneractive.sdk.click.l;
import com.fyber.inneractive.sdk.ignite.k;
import com.fyber.inneractive.sdk.network.r;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.e;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.n0;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.FyberNetworkBridge;
import com.safedk.android.utils.Logger;
import java.util.Arrays;

public class c extends WebViewClient {
  public c(InneractiveInternalBrowserActivity paramInneractiveInternalBrowserActivity) {}
  
  public static void a(c paramc, com.fyber.inneractive.sdk.click.b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/fyber/inneractive/sdk/activities/InneractiveInternalBrowserActivity;
    //   4: getfield b : Lcom/fyber/inneractive/sdk/flow/o;
    //   7: astore #5
    //   9: aload #5
    //   11: ifnull -> 24
    //   14: aload #5
    //   16: getfield a : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   19: astore #4
    //   21: goto -> 27
    //   24: aconst_null
    //   25: astore #4
    //   27: aload #5
    //   29: ifnull -> 42
    //   32: aload #5
    //   34: invokevirtual d : ()Lcom/fyber/inneractive/sdk/response/e;
    //   37: astore #5
    //   39: goto -> 45
    //   42: aconst_null
    //   43: astore #5
    //   45: aload_0
    //   46: getfield a : Lcom/fyber/inneractive/sdk/activities/InneractiveInternalBrowserActivity;
    //   49: getfield b : Lcom/fyber/inneractive/sdk/flow/o;
    //   52: astore_0
    //   53: aload_0
    //   54: ifnull -> 74
    //   57: aload_0
    //   58: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   61: astore_0
    //   62: aload_0
    //   63: ifnull -> 74
    //   66: aload_0
    //   67: invokevirtual c : ()Lorg/json/JSONArray;
    //   70: astore_0
    //   71: goto -> 76
    //   74: aconst_null
    //   75: astore_0
    //   76: new com/fyber/inneractive/sdk/network/q$a
    //   79: dup
    //   80: getstatic com/fyber/inneractive/sdk/network/p.FYBER_SUCCESS_CLICK : Lcom/fyber/inneractive/sdk/network/p;
    //   83: aload #4
    //   85: aload #5
    //   87: aload_0
    //   88: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   91: astore_0
    //   92: new org/json/JSONObject
    //   95: dup
    //   96: invokespecial <init> : ()V
    //   99: astore #4
    //   101: aload_1
    //   102: getfield e : J
    //   105: lstore_2
    //   106: lload_2
    //   107: lconst_0
    //   108: lcmp
    //   109: ifeq -> 150
    //   112: lload_2
    //   113: invokestatic valueOf : (J)Ljava/lang/Long;
    //   116: astore #5
    //   118: aload #4
    //   120: ldc 'time_passed'
    //   122: aload #5
    //   124: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   127: pop
    //   128: goto -> 150
    //   131: ldc 'Got exception adding param to json object: %s, %s'
    //   133: iconst_2
    //   134: anewarray java/lang/Object
    //   137: dup
    //   138: iconst_0
    //   139: ldc 'time_passed'
    //   141: aastore
    //   142: dup
    //   143: iconst_1
    //   144: aload #5
    //   146: aastore
    //   147: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   150: new org/json/JSONArray
    //   153: dup
    //   154: invokespecial <init> : ()V
    //   157: astore #5
    //   159: aload_1
    //   160: getfield f : Ljava/util/List;
    //   163: invokeinterface iterator : ()Ljava/util/Iterator;
    //   168: astore_1
    //   169: aload_1
    //   170: invokeinterface hasNext : ()Z
    //   175: ifeq -> 261
    //   178: aload_1
    //   179: invokeinterface next : ()Ljava/lang/Object;
    //   184: checkcast com/fyber/inneractive/sdk/click/i
    //   187: astore #7
    //   189: new org/json/JSONObject
    //   192: dup
    //   193: invokespecial <init> : ()V
    //   196: astore #6
    //   198: aload #6
    //   200: ldc 'url'
    //   202: aload #7
    //   204: getfield a : Ljava/lang/String;
    //   207: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   210: pop
    //   211: aload #6
    //   213: ldc 'success'
    //   215: aload #7
    //   217: getfield b : Z
    //   220: invokevirtual put : (Ljava/lang/String;Z)Lorg/json/JSONObject;
    //   223: pop
    //   224: aload #6
    //   226: ldc 'opened_by'
    //   228: aload #7
    //   230: getfield c : Lcom/fyber/inneractive/sdk/click/l$d;
    //   233: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   236: pop
    //   237: aload #6
    //   239: ldc 'reason'
    //   241: aload #7
    //   243: getfield d : Ljava/lang/String;
    //   246: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   249: pop
    //   250: aload #5
    //   252: aload #6
    //   254: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   257: pop
    //   258: goto -> 169
    //   261: aload #4
    //   263: ldc 'urls'
    //   265: aload #5
    //   267: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   270: pop
    //   271: goto -> 293
    //   274: ldc 'Got exception adding param to json object: %s, %s'
    //   276: iconst_2
    //   277: anewarray java/lang/Object
    //   280: dup
    //   281: iconst_0
    //   282: ldc 'urls'
    //   284: aastore
    //   285: dup
    //   286: iconst_1
    //   287: aload #5
    //   289: aastore
    //   290: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   293: getstatic com/fyber/inneractive/sdk/util/e.VIDEO_CTA : Lcom/fyber/inneractive/sdk/util/e;
    //   296: astore_1
    //   297: aload #4
    //   299: ldc 'origin'
    //   301: aload_1
    //   302: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   305: pop
    //   306: goto -> 327
    //   309: ldc 'Got exception adding param to json object: %s, %s'
    //   311: iconst_2
    //   312: anewarray java/lang/Object
    //   315: dup
    //   316: iconst_0
    //   317: ldc 'origin'
    //   319: aastore
    //   320: dup
    //   321: iconst_1
    //   322: aload_1
    //   323: aastore
    //   324: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   327: aload_0
    //   328: getfield f : Lorg/json/JSONArray;
    //   331: aload #4
    //   333: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   336: pop
    //   337: aload_0
    //   338: aconst_null
    //   339: invokevirtual a : (Ljava/lang/String;)V
    //   342: return
    //   343: astore #6
    //   345: goto -> 131
    //   348: astore #7
    //   350: goto -> 250
    //   353: astore_1
    //   354: goto -> 274
    //   357: astore #5
    //   359: goto -> 309
    // Exception table:
    //   from	to	target	type
    //   118	128	343	java/lang/Exception
    //   198	250	348	java/lang/Exception
    //   261	271	353	java/lang/Exception
    //   297	306	357	java/lang/Exception
  }
  
  public void onLoadResource(WebView paramWebView, String paramString) {
    super.onLoadResource(paramWebView, paramString);
    CreativeInfoManager.onResourceLoaded("com.inneractive", paramWebView, paramString);
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/activities/c;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
    CreativeInfoManager.onWebViewPageFinished("com.inneractive", paramWebView, paramString);
    safedk_c_onPageFinished_7c2389d98177df77b81a99a51a661979(paramWebView, paramString);
  }
  
  public void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap) {
    super.onPageStarted(paramWebView, paramString, paramBitmap);
    this.a.g.setImageDrawable(l.d(R.drawable.ia_ib_unright_arrow));
  }
  
  public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2) {
    IAlog.e("Received Error on WebViewClient: Code: %d, Description: %s, failingUrl: %s", new Object[] { Integer.valueOf(paramInt), paramString1, paramString2 });
  }
  
  public boolean onRenderProcessGone(WebView paramWebView, RenderProcessGoneDetail paramRenderProcessGoneDetail) {
    r.a("WebViewRendererProcessGone", "Web view renderer process has gone. Web view destroyed", null, null);
    this.a.finish();
    return true;
  }
  
  public void safedk_c_onPageFinished_7c2389d98177df77b81a99a51a661979(WebView paramWebView, String paramString) {
    Drawable drawable1;
    Drawable drawable2;
    super.onPageFinished(paramWebView, paramString);
    if (paramWebView.canGoBack()) {
      drawable2 = l.d(R.drawable.ia_ib_left_arrow);
    } else {
      drawable2 = l.d(R.drawable.ia_ib_unleft_arrow);
    } 
    this.a.f.setImageDrawable(drawable2);
    if (paramWebView.canGoForward()) {
      drawable1 = l.d(R.drawable.ia_ib_right_arrow);
    } else {
      drawable1 = l.d(R.drawable.ia_ib_unright_arrow);
    } 
    this.a.g.setImageDrawable(drawable1);
  }
  
  public boolean safedk_c_shouldOverrideUrlLoading_6df0856fc7f848aa819f0d15805de208(WebView paramWebView, String paramString) {
    String str;
    if (TextUtils.isEmpty(paramString))
      return false; 
    if (n0.a(paramString)) {
      FyberNetworkBridge.webviewLoadUrl(this.a.e, "chrome://crash");
      return true;
    } 
    a a = new a(this);
    e e = e.VIDEO_CTA;
    paramWebView = null;
    f f = new f(a, null, e);
    l l = new l(false);
    d d = new d();
    g g = new g();
    j j = new j();
    if (!TextUtils.isEmpty(paramString))
      str = Uri.parse(paramString).getScheme(); 
    h h = new h(str, false);
    l.h.addAll(Arrays.asList(new com.fyber.inneractive.sdk.click.a[] { (com.fyber.inneractive.sdk.click.a)f, (com.fyber.inneractive.sdk.click.a)d, (com.fyber.inneractive.sdk.click.a)g, (com.fyber.inneractive.sdk.click.a)j, (com.fyber.inneractive.sdk.click.a)h }));
    l.a(this.a.getApplicationContext(), paramString, new b(this), null, false, k.NONE, "");
    return paramString.startsWith("http") ^ true;
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, WebResourceRequest paramWebResourceRequest) {
    return CreativeInfoManager.onWebViewResponseWithHeaders("com.inneractive", paramWebView, paramWebResourceRequest, super.shouldInterceptRequest(paramWebView, paramWebResourceRequest));
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, String paramString) {
    return CreativeInfoManager.onWebViewResponse("com.inneractive", paramWebView, paramString, super.shouldInterceptRequest(paramWebView, paramString));
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/activities/c;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
    boolean bool = safedk_c_shouldOverrideUrlLoading_6df0856fc7f848aa819f0d15805de208(paramWebView, paramString);
    CreativeInfoManager.onOverrideUrlLoading("com.inneractive", paramWebView, paramString, bool);
    return bool;
  }
  
  public class a implements f.a {
    public a(c this$0) {}
    
    public void a(com.fyber.inneractive.sdk.click.b param1b, k0 param1k0, e param1e) {
      c.a(this.a, param1b);
    }
  }
  
  public class b implements l.b {
    public b(c this$0) {}
    
    public void a(com.fyber.inneractive.sdk.click.b param1b) {
      if (param1b != null && param1b.a != l.d.FAILED) {
        c.a(this.a, param1b);
        this.a.a.finish();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\activities\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */