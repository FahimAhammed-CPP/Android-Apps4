package com.fyber.inneractive.sdk.protobuf;

public interface e1 {}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */