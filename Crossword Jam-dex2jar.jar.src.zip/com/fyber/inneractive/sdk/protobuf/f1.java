package com.fyber.inneractive.sdk.protobuf;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

public final class f1 {
  public static final Class<?> a;
  
  public static final k1<?, ?> b = a(false);
  
  public static final k1<?, ?> c = a(true);
  
  public static final k1<?, ?> d = (k1<?, ?>)new m1();
  
  public static int a(int paramInt, Object paramObject, d1 paramd1) {
    if (paramObject instanceof b0) {
      paramObject = paramObject;
      return l.b(paramInt) + l.a((b0)paramObject);
    } 
    paramObject = paramObject;
    paramInt = l.b(paramInt);
    int i = ((a)paramObject).getSerializedSize(paramd1);
    return paramInt + l.c(i) + i;
  }
  
  public static int a(int paramInt, List<i> paramList) {
    int j = paramList.size();
    int i = 0;
    if (j == 0)
      return 0; 
    j *= l.b(paramInt);
    paramInt = i;
    i = j;
    while (paramInt < paramList.size()) {
      i += l.a(paramList.get(paramInt));
      paramInt++;
    } 
    return i;
  }
  
  public static int a(int paramInt, List<o0> paramList, d1 paramd1) {
    int k = paramList.size();
    int i = 0;
    if (k == 0)
      return 0; 
    int j = 0;
    while (i < k) {
      j += l.a(paramInt, paramList.get(i), paramd1);
      i++;
    } 
    return j;
  }
  
  public static int a(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    return (i == 0) ? 0 : (paramBoolean ? (l.b(paramInt) + l.c(i) + i) : (i * l.a(paramInt, true)));
  }
  
  public static int a(List<Integer> paramList) {
    x<Integer> x;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof x) {
      x = (x)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(x.e(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(((Integer)x.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static k1<?, ?> a(boolean paramBoolean) {
    Exception exception;
    try {
      Class<?> clazz = Class.forName("com.google.protobuf.UnknownFieldSetSchema");
    } finally {
      exception = null;
    } 
    try {
      return exception.getConstructor(new Class[] { boolean.class }).newInstance(new Object[] { Boolean.valueOf(paramBoolean) });
    } finally {
      exception = null;
    } 
  }
  
  public static <UT, UB> UB a(int paramInt1, int paramInt2, UB paramUB, k1<UT, UB> paramk1) {
    UB uB = paramUB;
    if (paramUB == null)
      uB = (UB)paramk1.a(); 
    paramk1.b(uB, paramInt1, paramInt2);
    return uB;
  }
  
  public static <UT, UB> UB a(int paramInt, List<Integer> paramList, y.d<?> paramd, UB paramUB, k1<UT, UB> paramk1) {
    if (paramd == null)
      return paramUB; 
    int k = paramList.size();
    int i = 0;
    int j = 0;
    while (i < k) {
      int m = ((Integer)paramList.get(i)).intValue();
      if (paramd.a(m) != null) {
        if (i != j)
          paramList.set(j, Integer.valueOf(m)); 
        j++;
      } else {
        UB uB = paramUB;
        if (paramUB == null)
          uB = (UB)paramk1.a(); 
        paramk1.b(uB, paramInt, m);
        paramUB = uB;
      } 
      i++;
    } 
    if (j != k)
      paramList.subList(j, k).clear(); 
    return paramUB;
  }
  
  public static <UT, UB> UB a(int paramInt, List<Integer> paramList, y.e parame, UB paramUB, k1<UT, UB> paramk1) {
    UB uB;
    if (parame == null)
      return paramUB; 
    if (paramList instanceof java.util.RandomAccess) {
      int k = paramList.size();
      int i = 0;
      int j = 0;
      while (i < k) {
        int m = ((Integer)paramList.get(i)).intValue();
        if (parame.a(m)) {
          if (i != j)
            paramList.set(j, Integer.valueOf(m)); 
          j++;
        } else {
          UB uB1 = paramUB;
          if (paramUB == null)
            uB1 = (UB)paramk1.a(); 
          paramk1.b(uB1, paramInt, m);
          paramUB = uB1;
        } 
        i++;
      } 
      uB = paramUB;
      if (j != k) {
        paramList.subList(j, k).clear();
        return paramUB;
      } 
    } else {
      Iterator<Integer> iterator = paramList.iterator();
      while (true) {
        uB = paramUB;
        if (iterator.hasNext()) {
          int i = ((Integer)iterator.next()).intValue();
          if (!parame.a(i)) {
            UB uB1 = paramUB;
            if (paramUB == null)
              uB1 = (UB)paramk1.a(); 
            paramk1.b(uB1, paramInt, i);
            iterator.remove();
            paramUB = uB1;
          } 
          continue;
        } 
        break;
      } 
    } 
    return uB;
  }
  
  public static void a(int paramInt, List<i> paramList, s1 params1) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      for (int i = 0; i < paramList.size(); i++)
        m.a.b(paramInt, paramList.get(i)); 
    } 
  }
  
  public static void a(int paramInt, List<?> paramList, s1 params1, d1 paramd1) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i;
      for (i = 0; i < paramList.size(); i++)
        m.a(paramInt, paramList.get(i), paramd1); 
    } 
  }
  
  public static void a(int paramInt, List<Boolean> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Boolean)paramList.get(paramInt)).booleanValue();
          Logger logger = l.b;
          i++;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.a((byte)((Boolean)paramList.get(paramInt)).booleanValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.b(paramInt, ((Boolean)paramList.get(i)).booleanValue());
          i++;
        } 
      } 
    } 
  }
  
  public static boolean a(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2)));
  }
  
  public static int b(int paramInt, List<?> paramList) {
    int k = paramList.size();
    int i = 0;
    byte b = 0;
    if (k == 0)
      return 0; 
    int j = l.b(paramInt) * k;
    paramInt = j;
    if (paramList instanceof d0) {
      paramList = paramList;
      paramInt = j;
      i = b;
      while (true) {
        j = paramInt;
        if (i < k) {
          Object object = paramList.a(i);
          if (object instanceof i) {
            j = l.a((i)object);
          } else {
            j = l.a((String)object);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } else {
      while (true) {
        j = paramInt;
        if (i < k) {
          Object object = paramList.get(i);
          if (object instanceof i) {
            j = l.a((i)object);
          } else {
            j = l.a((String)object);
          } 
          paramInt += j;
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  public static int b(int paramInt, List<?> paramList, d1 paramd1) {
    int j = paramList.size();
    int i = 0;
    if (j == 0)
      return 0; 
    paramInt = l.b(paramInt) * j;
    while (i < j) {
      Object object = paramList.get(i);
      if (object instanceof b0) {
        paramInt += l.a((b0)object);
      } else {
        int k = ((a)object).getSerializedSize(paramd1);
        paramInt += l.c(k) + k;
      } 
      i++;
    } 
    return paramInt;
  }
  
  public static int b(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = a(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static int b(List<?> paramList) {
    return paramList.size() * 4;
  }
  
  public static void b(int paramInt, List<String> paramList, s1 params1) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      boolean bool = paramList instanceof d0;
      int i = 0;
      byte b = 0;
      if (bool) {
        d0 d0 = (d0)paramList;
        for (i = b; i < paramList.size(); i++) {
          Object object = d0.a(i);
          if (object instanceof String) {
            m.a.b(paramInt, (String)object);
          } else {
            m.a.b(paramInt, (i)object);
          } 
        } 
      } else {
        while (i < paramList.size()) {
          m.a.b(paramInt, paramList.get(i));
          i++;
        } 
      } 
    } 
  }
  
  public static void b(int paramInt, List<?> paramList, s1 params1, d1 paramd1) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i;
      for (i = 0; i < paramList.size(); i++) {
        Object object = paramList.get(i);
        m.a.b(paramInt, (o0)object, paramd1);
      } 
    } 
  }
  
  public static void b(int paramInt, List<Double> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Double)paramList.get(paramInt)).doubleValue();
          Logger logger = l.b;
          i += 8;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++) {
          l l = m.a;
          double d = ((Double)paramList.get(paramInt)).doubleValue();
          l.getClass();
          l.c(Double.doubleToRawLongBits(d));
        } 
      } else {
        while (i < paramList.size()) {
          l l = m.a;
          double d = ((Double)paramList.get(i)).doubleValue();
          l.getClass();
          l.f(paramInt, Double.doubleToRawLongBits(d));
          i++;
        } 
      } 
    } 
  }
  
  public static int c(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    if (paramBoolean) {
      i *= 4;
      return l.b(paramInt) + l.c(i) + i;
    } 
    return i * l.b(paramInt, 0);
  }
  
  public static int c(List<?> paramList) {
    return paramList.size() * 8;
  }
  
  public static void c(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.a(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.f(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.h(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int d(int paramInt, List<?> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    if (paramBoolean) {
      i *= 8;
      return l.b(paramInt) + l.c(i) + i;
    } 
    return i * l.a(paramInt, 0L);
  }
  
  public static int d(List<Integer> paramList) {
    x<Integer> x;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof x) {
      x = (x)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(x.e(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(((Integer)x.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void d(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Integer)paramList.get(paramInt)).intValue();
          Logger logger = l.b;
          i += 4;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.e(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.g(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int e(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = d(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static int e(List<Long> paramList) {
    f0<Long> f0;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof f0) {
      f0 = (f0)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(f0.d(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(((Long)f0.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void e(int paramInt, List<Long> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Long)paramList.get(paramInt)).longValue();
          Logger logger = l.b;
          i += 8;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.c(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.f(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int f(int paramInt, List<Long> paramList, boolean paramBoolean) {
    if (paramList.size() == 0)
      return 0; 
    int i = e(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(i) + i) : (i + paramList.size() * l.b(paramInt));
  }
  
  public static int f(List<Integer> paramList) {
    x<Integer> x;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof x) {
      x = (x)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.c(l.d(x.e(j)));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.c(l.d(((Integer)x.get(j)).intValue()));
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void f(int paramInt, List<Float> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Float)paramList.get(paramInt)).floatValue();
          Logger logger = l.b;
          i += 4;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++) {
          l l = m.a;
          float f = ((Float)paramList.get(paramInt)).floatValue();
          l.getClass();
          l.e(Float.floatToRawIntBits(f));
        } 
      } else {
        while (i < paramList.size()) {
          l l = m.a;
          float f = ((Float)paramList.get(i)).floatValue();
          l.getClass();
          l.g(paramInt, Float.floatToRawIntBits(f));
          i++;
        } 
      } 
    } 
  }
  
  public static int g(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = f(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static int g(List<Long> paramList) {
    f0<Long> f0;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof f0) {
      f0 = (f0)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(l.b(f0.d(j)));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(l.b(((Long)f0.get(j)).longValue()));
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void g(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.a(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.f(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.h(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int h(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = g(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static int h(List<Integer> paramList) {
    x<Integer> x;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof x) {
      x = (x)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.c(x.e(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.c(((Integer)x.get(j)).intValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void h(int paramInt, List<Long> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.a(((Long)paramList.get(paramInt)).longValue());
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.d(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.g(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int i(int paramInt, List<Integer> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = h(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static int i(List<Long> paramList) {
    f0<Long> f0;
    int k = paramList.size();
    int i = 0;
    int j = 0;
    if (k == 0)
      return 0; 
    if (paramList instanceof f0) {
      f0 = (f0)paramList;
      int m = 0;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(f0.d(j));
          j++;
          continue;
        } 
        break;
      } 
    } else {
      int m = 0;
      j = i;
      while (true) {
        i = m;
        if (j < k) {
          m += l.a(((Long)f0.get(j)).longValue());
          j++;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  public static void i(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Integer)paramList.get(paramInt)).intValue();
          Logger logger = l.b;
          i += 4;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.e(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.g(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static int j(int paramInt, List<Long> paramList, boolean paramBoolean) {
    int i = paramList.size();
    if (i == 0)
      return 0; 
    int j = i(paramList);
    return paramBoolean ? (l.b(paramInt) + l.c(j) + j) : (j + i * l.b(paramInt));
  }
  
  public static void j(int paramInt, List<Long> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          ((Long)paramList.get(paramInt)).longValue();
          Logger logger = l.b;
          i += 8;
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.c(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.f(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void k(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.c(l.d(((Integer)paramList.get(paramInt)).intValue()));
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.g(l.d(((Integer)paramList.get(paramInt)).intValue())); 
      } else {
        while (i < paramList.size()) {
          m.a.j(paramInt, l.d(((Integer)paramList.get(i)).intValue()));
          i++;
        } 
      } 
    } 
  }
  
  public static void l(int paramInt, List<Long> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.a(l.b(((Long)paramList.get(paramInt)).longValue()));
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.d(l.b(((Long)paramList.get(paramInt)).longValue())); 
      } else {
        while (i < paramList.size()) {
          m.a.g(paramInt, l.b(((Long)paramList.get(i)).longValue()));
          i++;
        } 
      } 
    } 
  }
  
  public static void m(int paramInt, List<Integer> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.c(((Integer)paramList.get(paramInt)).intValue());
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.g(((Integer)paramList.get(paramInt)).intValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.j(paramInt, ((Integer)paramList.get(i)).intValue());
          i++;
        } 
      } 
    } 
  }
  
  public static void n(int paramInt, List<Long> paramList, s1 params1, boolean paramBoolean) throws IOException {
    if (paramList != null && !paramList.isEmpty()) {
      m m = (m)params1;
      m.getClass();
      int i = 0;
      boolean bool = false;
      if (paramBoolean) {
        m.a.i(paramInt, 2);
        paramInt = 0;
        i = paramInt;
        while (paramInt < paramList.size()) {
          i += l.a(((Long)paramList.get(paramInt)).longValue());
          paramInt++;
        } 
        m.a.g(i);
        for (paramInt = bool; paramInt < paramList.size(); paramInt++)
          m.a.d(((Long)paramList.get(paramInt)).longValue()); 
      } else {
        while (i < paramList.size()) {
          m.a.g(paramInt, ((Long)paramList.get(i)).longValue());
          i++;
        } 
      } 
    } 
  }
  
  static {
    Exception exception;
    try {
      Class<?> clazz = Class.forName("com.google.protobuf.GeneratedMessageV3");
    } finally {
      exception = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */