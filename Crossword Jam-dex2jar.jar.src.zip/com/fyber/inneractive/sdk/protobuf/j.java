package com.fyber.inneractive.sdk.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public abstract class j {
  public int a;
  
  public int b = 100;
  
  public int c = Integer.MAX_VALUE;
  
  public k d;
  
  public j() {}
  
  public static long a(long paramLong) {
    return -(paramLong & 0x1L) ^ paramLong >>> 1L;
  }
  
  public static j a(InputStream paramInputStream) {
    byte[] arrayOfByte;
    if (paramInputStream == null) {
      arrayOfByte = y.b;
      return a(arrayOfByte, 0, arrayOfByte.length, false);
    } 
    return new c((InputStream)arrayOfByte, 4096);
  }
  
  public static j a(ByteBuffer paramByteBuffer, boolean paramBoolean) {
    if (paramByteBuffer.hasArray())
      return a(paramByteBuffer.array(), paramByteBuffer.arrayOffset() + paramByteBuffer.position(), paramByteBuffer.remaining(), paramBoolean); 
    if (paramByteBuffer.isDirect() && p1.f)
      return new d(paramByteBuffer, paramBoolean); 
    int i = paramByteBuffer.remaining();
    byte[] arrayOfByte = new byte[i];
    paramByteBuffer.duplicate().get(arrayOfByte);
    return a(arrayOfByte, 0, i, true);
  }
  
  public static j a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) {
    b b = new b(paramArrayOfbyte, paramInt1, paramInt2, paramBoolean);
    try {
      b.d(paramInt2);
      return b;
    } catch (z z) {
      throw new IllegalArgumentException(z);
    } 
  }
  
  public static int b(int paramInt) {
    return -(paramInt & 0x1) ^ paramInt >>> 1;
  }
  
  public abstract int a();
  
  public abstract void a(int paramInt) throws z;
  
  public abstract void a(int paramInt, o0.a parama, q paramq) throws IOException;
  
  public abstract void a(o0.a parama, q paramq) throws IOException;
  
  public abstract int b();
  
  public abstract void c(int paramInt);
  
  public abstract boolean c() throws IOException;
  
  public abstract int d(int paramInt) throws z;
  
  public abstract boolean d() throws IOException;
  
  public abstract i e() throws IOException;
  
  public abstract boolean e(int paramInt) throws IOException;
  
  public abstract double f() throws IOException;
  
  public abstract int g() throws IOException;
  
  public abstract int h() throws IOException;
  
  public abstract long i() throws IOException;
  
  public abstract float j() throws IOException;
  
  public abstract int k() throws IOException;
  
  public abstract long l() throws IOException;
  
  public abstract int m() throws IOException;
  
  public abstract int n() throws IOException;
  
  public abstract long o() throws IOException;
  
  public abstract int p() throws IOException;
  
  public abstract long q() throws IOException;
  
  public abstract String r() throws IOException;
  
  public abstract String s() throws IOException;
  
  public abstract int t() throws IOException;
  
  public abstract int u() throws IOException;
  
  public abstract long v() throws IOException;
  
  public static final class b extends j {
    public final byte[] e;
    
    public final boolean f;
    
    public int g;
    
    public int h;
    
    public int i;
    
    public int j;
    
    public int k;
    
    public int l = Integer.MAX_VALUE;
    
    public b(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, boolean param1Boolean) {
      super(null);
      this.e = param1ArrayOfbyte;
      this.g = param1Int2 + param1Int1;
      this.i = param1Int1;
      this.j = param1Int1;
      this.f = param1Boolean;
    }
    
    public long A() throws IOException {
      long l = 0L;
      for (int i = 0; i < 64; i += 7) {
        byte b1 = w();
        l |= (b1 & Byte.MAX_VALUE) << i;
        if ((b1 & 0x80) == 0)
          return l; 
      } 
      throw z.e();
    }
    
    public final void B() {
      int i = this.g + this.h;
      this.g = i;
      int k = i - this.j;
      int m = this.l;
      if (k > m) {
        k -= m;
        this.h = k;
        this.g = i - k;
        return;
      } 
      this.h = 0;
    }
    
    public int a() {
      int i = this.l;
      return (i == Integer.MAX_VALUE) ? -1 : (i - b());
    }
    
    public void a(int param1Int) throws z {
      if (this.k == param1Int)
        return; 
      throw z.a();
    }
    
    public void a(int param1Int, o0.a param1a, q param1q) throws IOException {
      int i = this.a;
      if (i < this.b) {
        this.a = i + 1;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(r1.a(param1Int, 4));
        this.a--;
        return;
      } 
      throw z.h();
    }
    
    public void a(o0.a param1a, q param1q) throws IOException {
      int i = m();
      if (this.a < this.b) {
        i = d(i);
        this.a++;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(0);
        this.a--;
        this.l = i;
        B();
        return;
      } 
      throw z.h();
    }
    
    public int b() {
      return this.i - this.j;
    }
    
    public void c(int param1Int) {
      this.l = param1Int;
      B();
    }
    
    public boolean c() throws IOException {
      return (this.i == this.g);
    }
    
    public int d(int param1Int) throws z {
      if (param1Int >= 0) {
        param1Int += b();
        int i = this.l;
        if (param1Int <= i) {
          this.l = param1Int;
          B();
          return i;
        } 
        throw z.i();
      } 
      throw z.f();
    }
    
    public boolean d() throws IOException {
      return (z() != 0L);
    }
    
    public i e() throws IOException {
      int i = m();
      if (i > 0) {
        int k = this.g;
        int m = this.i;
        if (i <= k - m) {
          i i1 = i.a(this.e, m, i);
          this.i += i;
          return i1;
        } 
      } 
      if (i == 0)
        return i.b; 
      if (i > 0) {
        int m = this.g;
        int k = this.i;
        if (i <= m - k) {
          i += k;
          this.i = i;
          byte[] arrayOfByte = Arrays.copyOfRange(this.e, k, i);
          i i1 = i.b;
          return (i)new i.h(arrayOfByte);
        } 
      } 
      if (i <= 0) {
        if (i == 0) {
          byte[] arrayOfByte = y.b;
          i i1 = i.b;
          return (i)new i.h(arrayOfByte);
        } 
        throw z.f();
      } 
      throw z.i();
    }
    
    public boolean e(int param1Int) throws IOException {
      int i = r1.a;
      int k = param1Int & 0x7;
      boolean bool = false;
      i = 0;
      if (k != 0) {
        if (k != 1) {
          if (k != 2) {
            if (k != 3) {
              if (k != 4) {
                if (k == 5) {
                  f(4);
                  return true;
                } 
                throw z.d();
              } 
              return false;
            } 
            do {
              i = t();
            } while (i != 0 && e(i));
            a(r1.a(param1Int >>> 3, 4));
            return true;
          } 
          f(m());
          return true;
        } 
        f(8);
        return true;
      } 
      param1Int = bool;
      if (this.g - this.i >= 10) {
        for (param1Int = i; param1Int < 10; param1Int++) {
          byte[] arrayOfByte = this.e;
          i = this.i;
          this.i = i + 1;
          if (arrayOfByte[i] >= 0)
            return true; 
        } 
        throw z.e();
      } 
      while (param1Int < 10) {
        if (w() >= 0)
          return true; 
        param1Int++;
      } 
      throw z.e();
    }
    
    public double f() throws IOException {
      return Double.longBitsToDouble(y());
    }
    
    public void f(int param1Int) throws IOException {
      if (param1Int >= 0) {
        int i = this.g;
        int k = this.i;
        if (param1Int <= i - k) {
          this.i = k + param1Int;
          return;
        } 
      } 
      if (param1Int < 0)
        throw z.f(); 
      throw z.i();
    }
    
    public int g() throws IOException {
      return m();
    }
    
    public int h() throws IOException {
      return x();
    }
    
    public long i() throws IOException {
      return y();
    }
    
    public float j() throws IOException {
      return Float.intBitsToFloat(x());
    }
    
    public int k() throws IOException {
      return m();
    }
    
    public long l() throws IOException {
      return z();
    }
    
    public int m() throws IOException {
      int k = this.i;
      int i = this.g;
      if (i != k) {
        byte[] arrayOfByte = this.e;
        int m = k + 1;
        k = arrayOfByte[k];
        if (k >= 0) {
          this.i = m;
          return k;
        } 
        if (i - m >= 9) {
          i = m + 1;
          k ^= arrayOfByte[m] << 7;
          if (k < 0) {
            m = k ^ 0xFFFFFF80;
          } else {
            m = i + 1;
            k ^= arrayOfByte[i] << 14;
            if (k >= 0) {
              k ^= 0x3F80;
              i = m;
              m = k;
            } else {
              i = m + 1;
              m = k ^ arrayOfByte[m] << 21;
              if (m < 0) {
                m ^= 0xFFE03F80;
              } else {
                int n = i + 1;
                byte b1 = arrayOfByte[i];
                k = m ^ b1 << 28 ^ 0xFE03F80;
                m = k;
                i = n;
                if (b1 < 0) {
                  int i1 = n + 1;
                  m = k;
                  i = i1;
                  if (arrayOfByte[n] < 0) {
                    n = i1 + 1;
                    m = k;
                    i = n;
                    if (arrayOfByte[i1] < 0) {
                      i1 = n + 1;
                      m = k;
                      i = i1;
                      if (arrayOfByte[n] < 0) {
                        n = i1 + 1;
                        m = k;
                        i = n;
                        if (arrayOfByte[i1] < 0) {
                          i = n + 1;
                          m = k;
                          if (arrayOfByte[n] < 0)
                            return (int)A(); 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          this.i = i;
          return m;
        } 
      } 
      return (int)A();
    }
    
    public int n() throws IOException {
      return x();
    }
    
    public long o() throws IOException {
      return y();
    }
    
    public int p() throws IOException {
      return j.b(m());
    }
    
    public long q() throws IOException {
      return j.a(z());
    }
    
    public String r() throws IOException {
      int i = m();
      if (i > 0) {
        int k = this.g;
        int m = this.i;
        if (i <= k - m) {
          String str = new String(this.e, m, i, y.a);
          this.i += i;
          return str;
        } 
      } 
      if (i == 0)
        return ""; 
      if (i < 0)
        throw z.f(); 
      throw z.i();
    }
    
    public String s() throws IOException {
      int i = m();
      if (i > 0) {
        int k = this.g;
        int m = this.i;
        if (i <= k - m) {
          byte[] arrayOfByte = this.e;
          String str = q1.a.a(arrayOfByte, m, i);
          this.i += i;
          return str;
        } 
      } 
      if (i == 0)
        return ""; 
      if (i <= 0)
        throw z.f(); 
      throw z.i();
    }
    
    public int t() throws IOException {
      if (c()) {
        this.k = 0;
        return 0;
      } 
      int i = m();
      this.k = i;
      int k = r1.a;
      if (i >>> 3 != 0)
        return i; 
      throw z.b();
    }
    
    public int u() throws IOException {
      return m();
    }
    
    public long v() throws IOException {
      return z();
    }
    
    public byte w() throws IOException {
      int i = this.i;
      if (i != this.g) {
        byte[] arrayOfByte = this.e;
        this.i = i + 1;
        return arrayOfByte[i];
      } 
      throw z.i();
    }
    
    public int x() throws IOException {
      int i = this.i;
      if (this.g - i >= 4) {
        byte[] arrayOfByte = this.e;
        this.i = i + 4;
        byte b1 = arrayOfByte[i];
        byte b2 = arrayOfByte[i + 1];
        byte b3 = arrayOfByte[i + 2];
        return (arrayOfByte[i + 3] & 0xFF) << 24 | b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
      } 
      throw z.i();
    }
    
    public long y() throws IOException {
      int i = this.i;
      if (this.g - i >= 8) {
        byte[] arrayOfByte = this.e;
        this.i = i + 8;
        long l1 = arrayOfByte[i];
        long l2 = arrayOfByte[i + 1];
        long l3 = arrayOfByte[i + 2];
        long l4 = arrayOfByte[i + 3];
        long l5 = arrayOfByte[i + 4];
        long l6 = arrayOfByte[i + 5];
        long l7 = arrayOfByte[i + 6];
        return (arrayOfByte[i + 7] & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
      } 
      throw z.i();
    }
    
    public long z() throws IOException {
      int m = this.i;
      int i = this.g;
      if (i == m)
        return A(); 
      byte[] arrayOfByte = this.e;
      int k = m + 1;
      m = arrayOfByte[m];
      if (m >= 0) {
        this.i = k;
        return m;
      } 
      if (i - k < 9)
        return A(); 
      i = k + 1;
      m ^= arrayOfByte[k] << 7;
      if (m < 0) {
        k = m ^ 0xFFFFFF80;
      } else {
        long l1;
        k = i + 1;
        m ^= arrayOfByte[i] << 14;
        if (m >= 0) {
          l1 = (m ^ 0x3F80);
          i = k;
        } else {
          i = k + 1;
          k = m ^ arrayOfByte[k] << 21;
          if (k < 0) {
            k ^= 0xFFE03F80;
          } else {
            long l2 = k;
            k = i + 1;
            long l3 = l2 ^ arrayOfByte[i] << 28L;
            if (l3 >= 0L) {
              l2 = 266354560L;
              i = k;
            } else {
              i = k + 1;
              l2 = l3 ^ arrayOfByte[k] << 35L;
              if (l2 < 0L) {
                l3 = -34093383808L;
              } else {
                k = i + 1;
                l3 = l2 ^ arrayOfByte[i] << 42L;
                if (l3 >= 0L) {
                  l2 = 4363953127296L;
                  i = k;
                } else {
                  i = k + 1;
                  l2 = l3 ^ arrayOfByte[k] << 49L;
                  if (l2 < 0L) {
                    l3 = -558586000294016L;
                  } else {
                    k = i + 1;
                    l2 = l2 ^ arrayOfByte[i] << 56L ^ 0xFE03F80FE03F80L;
                    if (l2 < 0L) {
                      i = k + 1;
                      if (arrayOfByte[k] < 0L)
                        return A(); 
                    } else {
                      i = k;
                    } 
                    this.i = i;
                    return l2;
                  } 
                  l2 ^= l3;
                } 
                l2 = l3 ^ l2;
              } 
              l2 ^= l3;
            } 
            l2 = l3 ^ l2;
          } 
          l1 = k;
        } 
        this.i = i;
        return l1;
      } 
      long l = k;
    }
  }
  
  public static final class c extends j {
    public final InputStream e;
    
    public final byte[] f;
    
    public int g;
    
    public int h;
    
    public int i;
    
    public int j;
    
    public int k;
    
    public int l = Integer.MAX_VALUE;
    
    public c(InputStream param1InputStream, int param1Int) {
      super(null);
      y.a(param1InputStream, "input");
      this.e = param1InputStream;
      this.f = new byte[param1Int];
      this.g = 0;
      this.i = 0;
      this.k = 0;
    }
    
    public long A() throws IOException {
      long l = 0L;
      for (int i = 0; i < 64; i += 7) {
        byte b = w();
        l |= (b & Byte.MAX_VALUE) << i;
        if ((b & 0x80) == 0)
          return l; 
      } 
      throw z.e();
    }
    
    public final void B() {
      int i = this.g + this.h;
      this.g = i;
      int k = this.k + i;
      int m = this.l;
      if (k > m) {
        k -= m;
        this.h = k;
        this.g = i - k;
        return;
      } 
      this.h = 0;
    }
    
    public int a() {
      int i = this.l;
      return (i == Integer.MAX_VALUE) ? -1 : (i - this.k + this.i);
    }
    
    public void a(int param1Int) throws z {
      if (this.j == param1Int)
        return; 
      throw z.a();
    }
    
    public void a(int param1Int, o0.a param1a, q param1q) throws IOException {
      int i = this.a;
      if (i < this.b) {
        this.a = i + 1;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(r1.a(param1Int, 4));
        this.a--;
        return;
      } 
      throw z.h();
    }
    
    public void a(o0.a param1a, q param1q) throws IOException {
      int i = m();
      if (this.a < this.b) {
        i = d(i);
        this.a++;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(0);
        this.a--;
        this.l = i;
        B();
        return;
      } 
      throw z.h();
    }
    
    public final byte[] a(int param1Int, boolean param1Boolean) throws IOException {
      byte[] arrayOfByte2 = f(param1Int);
      if (arrayOfByte2 != null) {
        byte[] arrayOfByte = arrayOfByte2;
        if (param1Boolean)
          arrayOfByte = (byte[])arrayOfByte2.clone(); 
        return arrayOfByte;
      } 
      int k = this.i;
      int m = this.g;
      int i = m - k;
      this.k += m;
      this.i = 0;
      this.g = 0;
      List<byte[]> list = g(param1Int - i);
      byte[] arrayOfByte1 = new byte[param1Int];
      System.arraycopy(this.f, k, arrayOfByte1, 0, i);
      Iterator<byte[]> iterator = ((ArrayList)list).iterator();
      for (param1Int = i; iterator.hasNext(); param1Int += arrayOfByte.length) {
        byte[] arrayOfByte = iterator.next();
        System.arraycopy(arrayOfByte, 0, arrayOfByte1, param1Int, arrayOfByte.length);
      } 
      return arrayOfByte1;
    }
    
    public int b() {
      return this.k + this.i;
    }
    
    public void c(int param1Int) {
      this.l = param1Int;
      B();
    }
    
    public boolean c() throws IOException {
      return (this.i == this.g && !j(1));
    }
    
    public int d(int param1Int) throws z {
      if (param1Int >= 0) {
        param1Int += this.k + this.i;
        int i = this.l;
        if (param1Int <= i) {
          this.l = param1Int;
          B();
          return i;
        } 
        throw z.i();
      } 
      throw z.f();
    }
    
    public boolean d() throws IOException {
      return (z() != 0L);
    }
    
    public i e() throws IOException {
      int k = m();
      int i = this.g;
      int m = this.i;
      if (k <= i - m && k > 0) {
        i i2 = i.a(this.f, m, k);
        this.i += k;
        return i2;
      } 
      if (k == 0)
        return i.b; 
      byte[] arrayOfByte = f(k);
      if (arrayOfByte != null) {
        i i2 = i.b;
        return i.a(arrayOfByte, 0, arrayOfByte.length);
      } 
      m = this.i;
      int n = this.g;
      i = n - m;
      this.k += n;
      this.i = 0;
      this.g = 0;
      List<byte[]> list = g(k - i);
      arrayOfByte = new byte[k];
      System.arraycopy(this.f, m, arrayOfByte, 0, i);
      for (byte[] arrayOfByte1 : list) {
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, i, arrayOfByte1.length);
        i += arrayOfByte1.length;
      } 
      i i1 = i.b;
      return (i)new i.h(arrayOfByte);
    }
    
    public boolean e(int param1Int) throws IOException {
      int i = r1.a;
      int k = param1Int & 0x7;
      boolean bool = false;
      i = 0;
      if (k != 0) {
        if (k != 1) {
          if (k != 2) {
            if (k != 3) {
              if (k != 4) {
                if (k == 5) {
                  i(4);
                  return true;
                } 
                throw z.d();
              } 
              return false;
            } 
            do {
              i = t();
            } while (i != 0 && e(i));
            a(r1.a(param1Int >>> 3, 4));
            return true;
          } 
          i(m());
          return true;
        } 
        i(8);
        return true;
      } 
      param1Int = bool;
      if (this.g - this.i >= 10) {
        for (param1Int = i; param1Int < 10; param1Int++) {
          byte[] arrayOfByte = this.f;
          i = this.i;
          this.i = i + 1;
          if (arrayOfByte[i] >= 0)
            return true; 
        } 
        throw z.e();
      } 
      while (param1Int < 10) {
        if (w() >= 0)
          return true; 
        param1Int++;
      } 
      throw z.e();
    }
    
    public double f() throws IOException {
      return Double.longBitsToDouble(y());
    }
    
    public final byte[] f(int param1Int) throws IOException {
      if (param1Int == 0)
        return y.b; 
      if (param1Int >= 0) {
        int i = this.k;
        int k = this.i;
        int m = i + k + param1Int;
        if (m - this.c <= 0) {
          int n = this.l;
          if (m <= n) {
            i = this.g - k;
            k = param1Int - i;
            if (k < 4096 || k <= this.e.available()) {
              byte[] arrayOfByte = new byte[param1Int];
              System.arraycopy(this.f, this.i, arrayOfByte, 0, i);
              this.k += this.g;
              this.i = 0;
              this.g = 0;
              while (i < param1Int) {
                k = this.e.read(arrayOfByte, i, param1Int - i);
                if (k != -1) {
                  this.k += k;
                  i += k;
                  continue;
                } 
                throw z.i();
              } 
              return arrayOfByte;
            } 
            return null;
          } 
          i(n - i - k);
          throw z.i();
        } 
        throw new z("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
      } 
      throw z.f();
    }
    
    public int g() throws IOException {
      return m();
    }
    
    public final List<byte[]> g(int param1Int) throws IOException {
      ArrayList<byte[]> arrayList = new ArrayList();
      while (param1Int > 0) {
        int k = Math.min(param1Int, 4096);
        byte[] arrayOfByte = new byte[k];
        int i = 0;
        while (i < k) {
          int m = this.e.read(arrayOfByte, i, k - i);
          if (m != -1) {
            this.k += m;
            i += m;
            continue;
          } 
          throw z.i();
        } 
        param1Int -= k;
        arrayList.add(arrayOfByte);
      } 
      return (List<byte[]>)arrayList;
    }
    
    public int h() throws IOException {
      return x();
    }
    
    public final void h(int param1Int) throws IOException {
      if (!j(param1Int)) {
        if (param1Int > this.c - this.k - this.i)
          throw new z("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit."); 
        throw z.i();
      } 
    }
    
    public long i() throws IOException {
      return y();
    }
    
    public void i(int param1Int) throws IOException {
      int i = this.g;
      int k = this.i;
      i -= k;
      if (param1Int <= i && param1Int >= 0) {
        this.i = k + param1Int;
        return;
      } 
      if (param1Int >= 0) {
        int m = this.k;
        int n = m + k;
        int i1 = this.l;
        if (n + param1Int <= i1) {
          this.k = n;
          this.g = 0;
          this.i = 0;
          while (true) {
            if (i < param1Int)
              try {
                InputStream inputStream = this.e;
                long l1 = (param1Int - i);
                long l2 = inputStream.skip(l1);
              } finally {
                this.k += i;
                B();
              }  
            this.k += i;
            B();
            if (i < param1Int) {
              k = this.g;
              i = k - this.i;
              this.i = k;
              h(1);
              while (true) {
                m = param1Int - i;
                k = this.g;
                if (m > k) {
                  i += k;
                  this.i = k;
                  h(1);
                  continue;
                } 
                this.i = m;
                break;
              } 
            } 
            return;
          } 
        } 
        i(i1 - m - k);
        throw z.i();
      } 
      throw z.f();
    }
    
    public float j() throws IOException {
      return Float.intBitsToFloat(x());
    }
    
    public final boolean j(int param1Int) throws IOException {
      int i = this.i;
      int k = this.g;
      if (i + param1Int > k) {
        int m = this.c;
        int n = this.k;
        if (param1Int > m - n - i)
          return false; 
        if (n + i + param1Int > this.l)
          return false; 
        if (i > 0) {
          if (k > i) {
            byte[] arrayOfByte1 = this.f;
            System.arraycopy(arrayOfByte1, i, arrayOfByte1, 0, k - i);
          } 
          this.k += i;
          this.g -= i;
          this.i = 0;
        } 
        InputStream inputStream = this.e;
        byte[] arrayOfByte = this.f;
        i = this.g;
        i = inputStream.read(arrayOfByte, i, Math.min(arrayOfByte.length - i, this.c - this.k - i));
        if (i != 0 && i >= -1 && i <= this.f.length) {
          if (i > 0) {
            this.g += i;
            B();
            return (this.g >= param1Int) ? true : j(param1Int);
          } 
          return false;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(this.e.getClass());
        stringBuilder1.append("#read(byte[]) returned invalid result: ");
        stringBuilder1.append(i);
        stringBuilder1.append("\nThe InputStream implementation is buggy.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("refillBuffer() called when ");
      stringBuilder.append(param1Int);
      stringBuilder.append(" bytes were already available in buffer");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public int k() throws IOException {
      return m();
    }
    
    public long l() throws IOException {
      return z();
    }
    
    public int m() throws IOException {
      int k = this.i;
      int i = this.g;
      if (i != k) {
        byte[] arrayOfByte = this.f;
        int m = k + 1;
        k = arrayOfByte[k];
        if (k >= 0) {
          this.i = m;
          return k;
        } 
        if (i - m >= 9) {
          i = m + 1;
          k ^= arrayOfByte[m] << 7;
          if (k < 0) {
            m = k ^ 0xFFFFFF80;
          } else {
            m = i + 1;
            k ^= arrayOfByte[i] << 14;
            if (k >= 0) {
              k ^= 0x3F80;
              i = m;
              m = k;
            } else {
              i = m + 1;
              m = k ^ arrayOfByte[m] << 21;
              if (m < 0) {
                m ^= 0xFFE03F80;
              } else {
                int n = i + 1;
                byte b = arrayOfByte[i];
                k = m ^ b << 28 ^ 0xFE03F80;
                m = k;
                i = n;
                if (b < 0) {
                  int i1 = n + 1;
                  m = k;
                  i = i1;
                  if (arrayOfByte[n] < 0) {
                    n = i1 + 1;
                    m = k;
                    i = n;
                    if (arrayOfByte[i1] < 0) {
                      i1 = n + 1;
                      m = k;
                      i = i1;
                      if (arrayOfByte[n] < 0) {
                        n = i1 + 1;
                        m = k;
                        i = n;
                        if (arrayOfByte[i1] < 0) {
                          i = n + 1;
                          m = k;
                          if (arrayOfByte[n] < 0)
                            return (int)A(); 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          this.i = i;
          return m;
        } 
      } 
      return (int)A();
    }
    
    public int n() throws IOException {
      return x();
    }
    
    public long o() throws IOException {
      return y();
    }
    
    public int p() throws IOException {
      return j.b(m());
    }
    
    public long q() throws IOException {
      return j.a(z());
    }
    
    public String r() throws IOException {
      int i = m();
      if (i > 0) {
        int k = this.g;
        int m = this.i;
        if (i <= k - m) {
          String str = new String(this.f, m, i, y.a);
          this.i += i;
          return str;
        } 
      } 
      if (i == 0)
        return ""; 
      if (i <= this.g) {
        h(i);
        String str = new String(this.f, this.i, i, y.a);
        this.i += i;
        return str;
      } 
      return new String(a(i, false), y.a);
    }
    
    public String s() throws IOException {
      byte[] arrayOfByte;
      int k = m();
      int i = this.i;
      int m = this.g;
      if (k <= m - i && k > 0) {
        arrayOfByte = this.f;
        this.i = i + k;
      } else {
        if (k == 0)
          return ""; 
        if (k <= m) {
          h(k);
          arrayOfByte = this.f;
          this.i = k + 0;
        } else {
          arrayOfByte = a(k, false);
        } 
        i = 0;
      } 
      return q1.a.a(arrayOfByte, i, k);
    }
    
    public int t() throws IOException {
      if (c()) {
        this.j = 0;
        return 0;
      } 
      int i = m();
      this.j = i;
      int k = r1.a;
      if (i >>> 3 != 0)
        return i; 
      throw z.b();
    }
    
    public int u() throws IOException {
      return m();
    }
    
    public long v() throws IOException {
      return z();
    }
    
    public byte w() throws IOException {
      if (this.i == this.g)
        h(1); 
      byte[] arrayOfByte = this.f;
      int i = this.i;
      this.i = i + 1;
      return arrayOfByte[i];
    }
    
    public int x() throws IOException {
      int k = this.i;
      int i = k;
      if (this.g - k < 4) {
        h(4);
        i = this.i;
      } 
      byte[] arrayOfByte = this.f;
      this.i = i + 4;
      k = arrayOfByte[i];
      byte b1 = arrayOfByte[i + 1];
      byte b2 = arrayOfByte[i + 2];
      return (arrayOfByte[i + 3] & 0xFF) << 24 | k & 0xFF | (b1 & 0xFF) << 8 | (b2 & 0xFF) << 16;
    }
    
    public long y() throws IOException {
      int k = this.i;
      int i = k;
      if (this.g - k < 8) {
        h(8);
        i = this.i;
      } 
      byte[] arrayOfByte = this.f;
      this.i = i + 8;
      long l1 = arrayOfByte[i];
      long l2 = arrayOfByte[i + 1];
      long l3 = arrayOfByte[i + 2];
      long l4 = arrayOfByte[i + 3];
      long l5 = arrayOfByte[i + 4];
      long l6 = arrayOfByte[i + 5];
      long l7 = arrayOfByte[i + 6];
      return (arrayOfByte[i + 7] & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
    }
    
    public long z() throws IOException {
      int m = this.i;
      int i = this.g;
      if (i == m)
        return A(); 
      byte[] arrayOfByte = this.f;
      int k = m + 1;
      m = arrayOfByte[m];
      if (m >= 0) {
        this.i = k;
        return m;
      } 
      if (i - k < 9)
        return A(); 
      i = k + 1;
      m ^= arrayOfByte[k] << 7;
      if (m < 0) {
        k = m ^ 0xFFFFFF80;
      } else {
        long l1;
        k = i + 1;
        m ^= arrayOfByte[i] << 14;
        if (m >= 0) {
          l1 = (m ^ 0x3F80);
          i = k;
        } else {
          i = k + 1;
          k = m ^ arrayOfByte[k] << 21;
          if (k < 0) {
            k ^= 0xFFE03F80;
          } else {
            long l2 = k;
            k = i + 1;
            long l3 = l2 ^ arrayOfByte[i] << 28L;
            if (l3 >= 0L) {
              l2 = 266354560L;
              i = k;
            } else {
              i = k + 1;
              l2 = l3 ^ arrayOfByte[k] << 35L;
              if (l2 < 0L) {
                l3 = -34093383808L;
              } else {
                k = i + 1;
                l3 = l2 ^ arrayOfByte[i] << 42L;
                if (l3 >= 0L) {
                  l2 = 4363953127296L;
                  i = k;
                } else {
                  i = k + 1;
                  l2 = l3 ^ arrayOfByte[k] << 49L;
                  if (l2 < 0L) {
                    l3 = -558586000294016L;
                  } else {
                    k = i + 1;
                    l2 = l2 ^ arrayOfByte[i] << 56L ^ 0xFE03F80FE03F80L;
                    if (l2 < 0L) {
                      i = k + 1;
                      if (arrayOfByte[k] < 0L)
                        return A(); 
                    } else {
                      i = k;
                    } 
                    this.i = i;
                    return l2;
                  } 
                  l2 ^= l3;
                } 
                l2 = l3 ^ l2;
              } 
              l2 ^= l3;
            } 
            l2 = l3 ^ l2;
          } 
          l1 = k;
        } 
        this.i = i;
        return l1;
      } 
      long l = k;
    }
  }
  
  public static final class d extends j {
    public final ByteBuffer e;
    
    public final boolean f;
    
    public final long g;
    
    public long h;
    
    public long i;
    
    public long j;
    
    public int k;
    
    public int l;
    
    public int m = Integer.MAX_VALUE;
    
    public d(ByteBuffer param1ByteBuffer, boolean param1Boolean) {
      super(null);
      this.e = param1ByteBuffer;
      long l = p1.a(param1ByteBuffer);
      this.g = l;
      this.h = param1ByteBuffer.limit() + l;
      l += param1ByteBuffer.position();
      this.i = l;
      this.j = l;
      this.f = param1Boolean;
    }
    
    public long A() throws IOException {
      long l = 0L;
      for (int i = 0; i < 64; i += 7) {
        byte b = w();
        l |= (b & Byte.MAX_VALUE) << i;
        if ((b & 0x80) == 0)
          return l; 
      } 
      throw z.e();
    }
    
    public final void B() {
      long l = this.h + this.k;
      this.h = l;
      int i = (int)(l - this.j);
      int k = this.m;
      if (i > k) {
        i -= k;
        this.k = i;
        this.h = l - i;
        return;
      } 
      this.k = 0;
    }
    
    public final int C() {
      return (int)(this.h - this.i);
    }
    
    public int a() {
      int i = this.m;
      return (i == Integer.MAX_VALUE) ? -1 : (i - b());
    }
    
    public void a(int param1Int) throws z {
      if (this.l == param1Int)
        return; 
      throw z.a();
    }
    
    public void a(int param1Int, o0.a param1a, q param1q) throws IOException {
      int i = this.a;
      if (i < this.b) {
        this.a = i + 1;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(r1.a(param1Int, 4));
        this.a--;
        return;
      } 
      throw z.h();
    }
    
    public void a(o0.a param1a, q param1q) throws IOException {
      int i = m();
      if (this.a < this.b) {
        i = d(i);
        this.a++;
        ((GeneratedMessageLite.b)param1a).a(this, param1q);
        a(0);
        this.a--;
        this.m = i;
        B();
        return;
      } 
      throw z.h();
    }
    
    public int b() {
      return (int)(this.i - this.j);
    }
    
    public final int b(long param1Long) {
      return (int)(param1Long - this.g);
    }
    
    public void c(int param1Int) {
      this.m = param1Int;
      B();
    }
    
    public boolean c() throws IOException {
      return (this.i == this.h);
    }
    
    public int d(int param1Int) throws z {
      if (param1Int >= 0) {
        param1Int += b();
        int i = this.m;
        if (param1Int <= i) {
          this.m = param1Int;
          B();
          return i;
        } 
        throw z.i();
      } 
      throw z.f();
    }
    
    public boolean d() throws IOException {
      return (z() != 0L);
    }
    
    public i e() throws IOException {
      int i = m();
      if (i > 0 && i <= C()) {
        byte[] arrayOfByte = new byte[i];
        long l1 = this.i;
        long l2 = i;
        p1.e.a(l1, arrayOfByte, 0L, l2);
        this.i += l2;
        i i1 = i.b;
        return (i)new i.h(arrayOfByte);
      } 
      if (i == 0)
        return i.b; 
      if (i < 0)
        throw z.f(); 
      throw z.i();
    }
    
    public boolean e(int param1Int) throws IOException {
      int i = r1.a;
      int k = param1Int & 0x7;
      boolean bool = false;
      i = 0;
      if (k != 0) {
        if (k != 1) {
          if (k != 2) {
            if (k != 3) {
              if (k != 4) {
                if (k == 5) {
                  f(4);
                  return true;
                } 
                throw z.d();
              } 
              return false;
            } 
            do {
              i = t();
            } while (i != 0 && e(i));
            a(r1.a(param1Int >>> 3, 4));
            return true;
          } 
          f(m());
          return true;
        } 
        f(8);
        return true;
      } 
      param1Int = bool;
      if (C() >= 10) {
        for (param1Int = i; param1Int < 10; param1Int++) {
          long l = this.i;
          this.i = 1L + l;
          if (p1.e.a(l) >= 0)
            return true; 
        } 
        throw z.e();
      } 
      while (param1Int < 10) {
        if (w() >= 0)
          return true; 
        param1Int++;
      } 
      throw z.e();
    }
    
    public double f() throws IOException {
      return Double.longBitsToDouble(y());
    }
    
    public void f(int param1Int) throws IOException {
      if (param1Int >= 0 && param1Int <= C()) {
        this.i += param1Int;
        return;
      } 
      if (param1Int < 0)
        throw z.f(); 
      throw z.i();
    }
    
    public int g() throws IOException {
      return m();
    }
    
    public int h() throws IOException {
      return x();
    }
    
    public long i() throws IOException {
      return y();
    }
    
    public float j() throws IOException {
      return Float.intBitsToFloat(x());
    }
    
    public int k() throws IOException {
      return m();
    }
    
    public long l() throws IOException {
      return z();
    }
    
    public int m() throws IOException {
      long l = this.i;
      if (this.h != l) {
        long l1 = l + 1L;
        p1.d d1 = p1.e;
        byte b = d1.a(l);
        if (b >= 0) {
          this.i = l1;
          return b;
        } 
        if (this.h - l1 >= 9L) {
          l = l1 + 1L;
          int i = b ^ d1.a(l1) << 7;
          if (i < 0) {
            i ^= 0xFFFFFF80;
          } else {
            l1 = l + 1L;
            i ^= d1.a(l) << 14;
            if (i >= 0) {
              i ^= 0x3F80;
              l = l1;
            } else {
              l = l1 + 1L;
              i ^= d1.a(l1) << 21;
              if (i < 0) {
                i ^= 0xFFE03F80;
              } else {
                l1 = l + 1L;
                byte b1 = d1.a(l);
                int k = i ^ b1 << 28 ^ 0xFE03F80;
                i = k;
                l = l1;
                if (b1 < 0) {
                  long l2 = l1 + 1L;
                  i = k;
                  l = l2;
                  if (d1.a(l1) < 0) {
                    l1 = l2 + 1L;
                    i = k;
                    l = l1;
                    if (d1.a(l2) < 0) {
                      l2 = l1 + 1L;
                      i = k;
                      l = l2;
                      if (d1.a(l1) < 0) {
                        l1 = l2 + 1L;
                        i = k;
                        l = l1;
                        if (d1.a(l2) < 0) {
                          l = l1 + 1L;
                          i = k;
                          if (d1.a(l1) < 0)
                            return (int)A(); 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          this.i = l;
          return i;
        } 
      } 
      return (int)A();
    }
    
    public int n() throws IOException {
      return x();
    }
    
    public long o() throws IOException {
      return y();
    }
    
    public int p() throws IOException {
      return j.b(m());
    }
    
    public long q() throws IOException {
      return j.a(z());
    }
    
    public String r() throws IOException {
      int i = m();
      if (i > 0 && i <= C()) {
        byte[] arrayOfByte = new byte[i];
        long l1 = this.i;
        long l2 = i;
        p1.e.a(l1, arrayOfByte, 0L, l2);
        String str = new String(arrayOfByte, y.a);
        this.i += l2;
        return str;
      } 
      if (i == 0)
        return ""; 
      if (i < 0)
        throw z.f(); 
      throw z.i();
    }
    
    public String s() throws IOException {
      int i = m();
      if (i > 0 && i <= C()) {
        String str;
        int k = b(this.i);
        ByteBuffer byteBuffer = this.e;
        q1.b b = q1.a;
        b.getClass();
        if (byteBuffer.hasArray()) {
          int m = byteBuffer.arrayOffset();
          str = b.a(byteBuffer.array(), m + k, i);
        } else if (str.isDirect()) {
          str = b.b((ByteBuffer)str, k, i);
        } else {
          str = b.a((ByteBuffer)str, k, i);
        } 
        this.i += i;
        return str;
      } 
      if (i == 0)
        return ""; 
      if (i <= 0)
        throw z.f(); 
      throw z.i();
    }
    
    public int t() throws IOException {
      if (c()) {
        this.l = 0;
        return 0;
      } 
      int i = m();
      this.l = i;
      int k = r1.a;
      if (i >>> 3 != 0)
        return i; 
      throw z.b();
    }
    
    public int u() throws IOException {
      return m();
    }
    
    public long v() throws IOException {
      return z();
    }
    
    public byte w() throws IOException {
      long l = this.i;
      if (l != this.h) {
        this.i = 1L + l;
        return p1.e.a(l);
      } 
      throw z.i();
    }
    
    public int x() throws IOException {
      long l = this.i;
      if (this.h - l >= 4L) {
        this.i = 4L + l;
        p1.d d1 = p1.e;
        byte b1 = d1.a(l);
        byte b2 = d1.a(1L + l);
        byte b3 = d1.a(2L + l);
        return (d1.a(l + 3L) & 0xFF) << 24 | b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16;
      } 
      throw z.i();
    }
    
    public long y() throws IOException {
      long l = this.i;
      if (this.h - l >= 8L) {
        this.i = 8L + l;
        p1.d d1 = p1.e;
        long l1 = d1.a(l);
        long l2 = d1.a(1L + l);
        long l3 = d1.a(2L + l);
        long l4 = d1.a(3L + l);
        long l5 = d1.a(4L + l);
        long l6 = d1.a(5L + l);
        long l7 = d1.a(6L + l);
        return (d1.a(l + 7L) & 0xFFL) << 56L | l1 & 0xFFL | (l2 & 0xFFL) << 8L | (l3 & 0xFFL) << 16L | (l4 & 0xFFL) << 24L | (l5 & 0xFFL) << 32L | (l6 & 0xFFL) << 40L | (l7 & 0xFFL) << 48L;
      } 
      throw z.i();
    }
    
    public long z() throws IOException {
      long l1 = this.i;
      if (this.h == l1)
        return A(); 
      long l2 = l1 + 1L;
      p1.d d1 = p1.e;
      byte b = d1.a(l1);
      if (b >= 0) {
        this.i = l2;
        return b;
      } 
      if (this.h - l2 < 9L)
        return A(); 
      l1 = l2 + 1L;
      int i = b ^ d1.a(l2) << 7;
      if (i < 0) {
        i ^= 0xFFFFFF80;
        l2 = l1;
      } else {
        l2 = l1 + 1L;
        i ^= d1.a(l1) << 14;
        if (i >= 0) {
          l1 = (i ^ 0x3F80);
        } else {
          l1 = l2 + 1L;
          i ^= d1.a(l2) << 21;
          if (i < 0) {
            i ^= 0xFFE03F80;
            l2 = l1;
          } else {
            long l = i;
            l2 = l1 + 1L;
            l1 = l ^ d1.a(l1) << 28L;
            if (l1 >= 0L) {
              l = 266354560L;
            } else {
              l = l2 + 1L;
              long l3 = l1 ^ d1.a(l2) << 35L;
              if (l3 < 0L) {
                l2 = -34093383808L;
                l1 = l;
                l = l2;
                l2 = l3;
              } else {
                l2 = l + 1L;
                l = l3 ^ d1.a(l) << 42L;
                if (l >= 0L) {
                  l3 = 4363953127296L;
                  l1 = l;
                  l = l3;
                } else {
                  l1 = l2 + 1L;
                  l2 = l ^ d1.a(l2) << 49L;
                  if (l2 < 0L) {
                    l = -558586000294016L;
                  } else {
                    l3 = l1 + 1L;
                    l = l2 ^ d1.a(l1) << 56L ^ 0xFE03F80FE03F80L;
                    l1 = l;
                    l2 = l3;
                    if (l < 0L) {
                      if (d1.a(l3) < 0L)
                        return A(); 
                      l2 = 1L + l3;
                      l1 = l;
                    } 
                    this.i = l2;
                    return l1;
                  } 
                  l = l2 ^ l;
                  l2 = l1;
                  l1 = l;
                } 
                l1 ^= l;
              } 
              l = l2 ^ l;
              l2 = l1;
              l1 = l;
            } 
            l1 ^= l;
          } 
          l1 = i;
        } 
        this.i = l2;
        return l1;
      } 
      l1 = i;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\protobuf\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */