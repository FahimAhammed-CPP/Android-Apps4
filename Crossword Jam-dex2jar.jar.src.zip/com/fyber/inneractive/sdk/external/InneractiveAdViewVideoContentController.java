package com.fyber.inneractive.sdk.external;

import com.fyber.inneractive.sdk.flow.e0;
import com.fyber.inneractive.sdk.renderers.m;
import java.lang.ref.WeakReference;

public class InneractiveAdViewVideoContentController extends e0 {
  public boolean canControl(InneractiveAdSpot paramInneractiveAdSpot) {
    return (paramInneractiveAdSpot.getAdContent() instanceof com.fyber.inneractive.sdk.flow.d0);
  }
  
  public void pauseVideo() {}
  
  public void playVideo() {}
  
  public void setControlledRenderer(m paramm) {
    new WeakReference<m>(paramm);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\external\InneractiveAdViewVideoContentController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */