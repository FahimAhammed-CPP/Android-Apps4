package com.fyber.inneractive.sdk.response;

import android.util.Xml;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.b0;
import java.io.IOException;
import java.io.StringReader;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class h {
  public boolean a = false;
  
  public String b;
  
  public h(String paramString) throws Exception {
    try {
      a(paramString);
      this.a = true;
      IAlog.a("parser: Parsing finished. parser is ready", new Object[0]);
      return;
    } catch (Exception exception) {
      IAlog.b("Error parsing Ad XML: %s", new Object[] { exception.getMessage() });
      throw exception;
    } 
  }
  
  public final void a(String paramString) throws XmlPullParserException, IOException {
    IAlog.a("Start reading Response", new Object[0]);
    XmlPullParser xmlPullParser = Xml.newPullParser();
    xmlPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
    xmlPullParser.setInput(new StringReader(paramString));
    xmlPullParser.nextTag();
    xmlPullParser.require(2, null, "tns:Response");
    while (xmlPullParser.next() != 3) {
      if (xmlPullParser.getEventType() != 2)
        continue; 
      boolean bool = xmlPullParser.getName().equals("tns:Ad");
      int i = 1;
      if (bool) {
        xmlPullParser.require(2, null, "tns:Ad");
        IAlog.a("Start reading Ad", new Object[0]);
        if (xmlPullParser.next() == 4) {
          paramString = xmlPullParser.getText();
          xmlPullParser.nextTag();
        } else {
          IAlog.e("No text: %s", new Object[] { xmlPullParser.getName() });
          paramString = "";
        } 
        paramString = paramString.trim();
        IAlog.d("Ad content: %s", new Object[] { paramString });
        if (paramString == null) {
          paramString = null;
        } else {
          paramString = b0.f.a(paramString);
        } 
        this.b = paramString;
        continue;
      } 
      if (xmlPullParser.getEventType() == 2) {
        while (i) {
          int j = xmlPullParser.next();
          if (j != 2) {
            if (j != 3)
              continue; 
            i--;
            continue;
          } 
          i++;
        } 
        continue;
      } 
      throw new IllegalStateException();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */