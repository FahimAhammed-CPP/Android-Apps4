package com.fyber.inneractive.sdk.response;

import com.fyber.inneractive.sdk.model.vast.s;
import java.util.List;

public interface i {
  List<String> a(s params);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */