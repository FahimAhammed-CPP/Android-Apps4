package com.fyber.inneractive.sdk.response;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.enums.UnitDisplayType;
import com.fyber.inneractive.sdk.external.ImpressionData;
import com.fyber.inneractive.sdk.network.l;
import com.fyber.inneractive.sdk.network.m;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.j;
import com.fyber.inneractive.sdk.util.q;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class k implements j {
  public final m a;
  
  public k(m paramm) {
    this.a = paramm;
  }
  
  public String a() {
    return this.a.d().toString();
  }
  
  public final String a(Map<String, String> paramMap, l paraml) {
    String str2 = paraml.key.toLowerCase();
    String str1 = paramMap.get(str2);
    IAlog.d("%s%s extracted from response header: %s", new Object[] { IAlog.a(this), str2, str1 });
    int i = IAlog.a;
    IAlog.a(1, null, "%s %s : %s", new Object[] { "RESPONSE_HEADER", str2, str1 });
    return str1;
  }
  
  public void a(b paramb) {
    long l;
    paramb.a.B = false;
    IAConfigManager.M.x.e = false;
    ImpressionData impressionData = new ImpressionData();
    Map<String, String> map = this.a.p();
    String str18 = a(map, l.RETURNED_AD_TYPE);
    a(map, l.ERROR_CODE);
    String str24 = a(map, l.SESSION_ID);
    String str19 = a(map, l.CONTENT_ID);
    a(map, l.PUBLISHER_ID);
    String str20 = a(map, l.WIDTH);
    String str21 = a(map, l.HEIGHT);
    String str13 = a(map, l.SDK_IMPRESSION_URL);
    String str14 = a(map, l.SDK_CLICK_URL);
    String str26 = a(map, l.AD_TIMEOUT);
    String str15 = a(map, l.AD_COMPLETION_URL);
    paramb.b = a(map, l.AD_UNIT_ID);
    a(map, l.AD_UNIT_TYPE);
    String str16 = a(map, l.AD_UNIT_DISPLAY_TYPE);
    String str25 = a(map, l.AD_NETWORK);
    String str22 = a(map, l.AD_NETWORK_ID);
    String str9 = a(map, l.CREATIVE_ID);
    String str10 = a(map, l.AD_DOMAIN);
    String str23 = a(map, l.APP_BUNDLE);
    String str11 = a(map, l.CAMPAIGN_ID);
    String str1 = a(map, l.CPM_VALUE);
    String str2 = a(map, l.CPM_CURRENCY);
    impressionData.setCpmValue(str1);
    impressionData.setCurrency(str2);
    String str17 = a(map, l.BANNER_MRC_PERCENT);
    String str12 = a(map, l.BANNER_MRC_DURATION);
    str2 = a(map, l.BANNER_MRC_IMPRESSION_URL);
    String str3 = a(map, l.INTERSTITIAL_SKIP_MODE);
    String str4 = a(map, l.IGNITE_INSTALL_URL);
    String str5 = a(map, l.IGNITE_MODE);
    String str6 = a(map, l.APP_BUNDLE_LAUNCHER);
    String str7 = a(map, l.BRAND_BIDDER_SHOW_ENDCARD);
    String str8 = a(map, l.BRAND_BIDDER_CTA_TEXT);
    str1 = a(map, l.MRAID_VIDEO_SIGNAL);
    if (paramb.b())
      paramb.a.p = map; 
    e e6 = paramb.a;
    e6.getClass();
    try {
      l = Long.parseLong(str26);
    } catch (NumberFormatException numberFormatException) {
      l = 20L;
    } 
    e6.b = l;
    e6.a = e6.c + TimeUnit.MINUTES.toMillis(l);
    impressionData.setImpressionId(str24);
    impressionData.setDemandSource(str25);
    e e5 = paramb.a;
    e5.d = str19;
    e5.getClass();
    paramb.a.y = str23;
    if (!TextUtils.isEmpty(str22))
      impressionData.setDemandId(Long.valueOf(str22)); 
    if (!TextUtils.isEmpty(str18))
      paramb.a.g = Integer.valueOf(str18).intValue(); 
    if (!TextUtils.isEmpty(str20))
      paramb.a.e = Integer.valueOf(str20).intValue(); 
    if (!TextUtils.isEmpty(str21))
      paramb.a.f = Integer.valueOf(str21).intValue(); 
    e e4 = paramb.a;
    e4.k = str13;
    e4.l = str14;
    e4.o = str15;
    e4.m = paramb.b;
    try {
      e4.n = UnitDisplayType.fromValue(str16);
    } catch (IllegalArgumentException illegalArgumentException) {
      paramb.a.n = UnitDisplayType.INTERSTITIAL;
    } 
    if (!TextUtils.isEmpty(str9))
      impressionData.setCreativeId(str9); 
    if (!TextUtils.isEmpty(str10))
      impressionData.setAdvertiserDomain(str10); 
    if (!TextUtils.isEmpty(str11))
      impressionData.setCampaignId(str11); 
    impressionData.setCountry(j.g());
    e e3 = paramb.a;
    e3.r = impressionData;
    boolean bool = false;
    e3.t = q.a(str17, 0);
    e e2 = paramb.a;
    float f2 = -1.0F;
    float f1 = f2;
    if (!TextUtils.isEmpty(str12))
      try {
        f1 = Float.parseFloat(str12);
      } catch (NumberFormatException numberFormatException) {
        f1 = f2;
      }  
    e2.u = f1;
    e2 = paramb.a;
    e2.v = str2;
    e2.w = q.a(str3, -1);
    if (!TextUtils.isEmpty(str4))
      paramb.a.E = str4; 
    if (!TextUtils.isEmpty(str5))
      paramb.a.a(com.fyber.inneractive.sdk.ignite.k.a(str5)); 
    if (!TextUtils.isEmpty(str6))
      paramb.a.G = str6; 
    if (!TextUtils.isEmpty(str7))
      paramb.a.C = str7; 
    if (!TextUtils.isEmpty(str8))
      paramb.a.D = str8; 
    e e1 = paramb.a;
    if ("1".equals(str1) || Boolean.parseBoolean(str1))
      bool = true; 
    e1.H = bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */