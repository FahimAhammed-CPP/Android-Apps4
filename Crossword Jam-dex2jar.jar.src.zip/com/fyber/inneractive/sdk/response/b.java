package com.fyber.inneractive.sdk.response;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.config.a;
import com.fyber.inneractive.sdk.config.a0;
import com.fyber.inneractive.sdk.network.m;
import com.fyber.inneractive.sdk.util.IAlog;

public abstract class b {
  public e a;
  
  public String b;
  
  public j c;
  
  public boolean d = true;
  
  public abstract e a();
  
  public e a(String paramString) throws Exception {
    boolean bool;
    if (paramString != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.d = bool;
    e e1 = this.a;
    e1.getClass();
    e1.c = System.currentTimeMillis();
    this.c.a(this);
    String str = this.c.a();
    this.a.h = str;
    a0 a0 = a.b(this.b);
    IAlog.a("%sGot unit config for unitId: %s from config manager", new Object[] { IAlog.a(this), this.b });
    IAlog.a("%s%s", new Object[] { IAlog.a(this), a0 });
    if (this.d) {
      a(paramString, a0);
    } else if ((this instanceof com.fyber.inneractive.sdk.dv.e ^ true) != 0) {
      h h = new h(str);
      if (h.a) {
        String str1 = h.b;
        if (str1 != null && !TextUtils.isEmpty(str1.trim())) {
          a(str1, a0);
        } else {
          throw new Exception("empty ad content detected. failing fast.");
        } 
      } 
    } else {
      a(str, a0);
    } 
    return this.a;
  }
  
  public void a(m paramm) {
    this.a = a();
  }
  
  public abstract void a(String paramString, a0 parama0) throws Exception;
  
  public abstract boolean b();
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */