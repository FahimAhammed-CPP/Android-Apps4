package com.fyber.inneractive.sdk.response;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.config.a0;
import com.fyber.inneractive.sdk.config.f;
import com.fyber.inneractive.sdk.util.b0;
import com.fyber.inneractive.sdk.util.l;
import java.io.IOException;

public class c extends b {
  public e a() {
    f f = new f();
    this.a = f;
    return f;
  }
  
  public void a(String paramString, a0 parama0) throws IOException {
    f f = (f)this.a;
    if (paramString == null) {
      paramString = null;
    } else {
      paramString = b0.g.a(paramString);
    } 
    int i = f.a;
    String str2 = System.getProperty("ia.testEnvironmentConfiguration.assetResponse");
    String str1 = paramString;
    if (!TextUtils.isEmpty(str2)) {
      str2 = l.c(str2);
      str1 = paramString;
      if (!TextUtils.isEmpty(str2))
        str1 = str2; 
    } 
    f.I = str1;
  }
  
  public boolean b() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */