package com.fyber.inneractive.sdk.response;

import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.external.InneractiveAdRequest;
import com.fyber.inneractive.sdk.external.InneractiveErrorCode;

public class f extends e {
  public String I;
  
  public InneractiveErrorCode a(InneractiveAdRequest paramInneractiveAdRequest) {
    return null;
  }
  
  public InneractiveErrorCode a(InneractiveAdRequest paramInneractiveAdRequest, s params) {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */