package com.fyber.inneractive.sdk.response;

import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.external.InneractiveAdRequest;
import com.fyber.inneractive.sdk.external.InneractiveErrorCode;
import com.fyber.inneractive.sdk.measurement.f;
import com.fyber.inneractive.sdk.model.vast.b;
import com.fyber.inneractive.sdk.model.vast.f;
import com.fyber.inneractive.sdk.model.vast.n;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class g extends e {
  public long I;
  
  public b J;
  
  public Map<n, com.fyber.inneractive.sdk.flow.vast.g> K = new LinkedHashMap<n, com.fyber.inneractive.sdk.flow.vast.g>();
  
  public List<f> L = new ArrayList<f>();
  
  public final List<f> M = new ArrayList<f>();
  
  public LinkedHashMap<String, String> N = new LinkedHashMap<String, String>();
  
  public InneractiveErrorCode a(InneractiveAdRequest paramInneractiveAdRequest) {
    return a(null, null);
  }
  
  public InneractiveErrorCode a(InneractiveAdRequest paramInneractiveAdRequest, s params) {
    // Byte code:
    //   0: new com/fyber/inneractive/sdk/flow/vast/k
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #10
    //   9: aload_0
    //   10: getfield i : Ljava/lang/String;
    //   13: astore #5
    //   15: ldc 'VastErrorInvalidFile'
    //   17: aload #5
    //   19: invokevirtual equals : (Ljava/lang/Object;)Z
    //   22: ifeq -> 101
    //   25: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.SERVER_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   28: astore #8
    //   30: getstatic com/fyber/inneractive/sdk/network/o.VAST_ERROR_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/network/o;
    //   33: astore #7
    //   35: aload #8
    //   37: astore #5
    //   39: aload #7
    //   41: astore #6
    //   43: aload_0
    //   44: getfield j : Ljava/lang/String;
    //   47: ifnull -> 83
    //   50: new com/fyber/inneractive/sdk/network/q$b
    //   53: dup
    //   54: invokespecial <init> : ()V
    //   57: ldc 'exception'
    //   59: aload_0
    //   60: getfield j : Ljava/lang/String;
    //   63: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/fyber/inneractive/sdk/network/q$b;
    //   66: astore #9
    //   68: aload #8
    //   70: astore #5
    //   72: aload #7
    //   74: astore #6
    //   76: aload #9
    //   78: astore #7
    //   80: goto -> 86
    //   83: aconst_null
    //   84: astore #7
    //   86: aload #5
    //   88: astore #8
    //   90: aload #6
    //   92: astore #5
    //   94: aload #8
    //   96: astore #6
    //   98: goto -> 552
    //   101: ldc 'ErrorNoCompatibleMediaFile'
    //   103: aload #5
    //   105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   108: ifeq -> 425
    //   111: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.SERVER_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   114: astore #8
    //   116: getstatic com/fyber/inneractive/sdk/network/o.VAST_ERROR_NO_COMPATIBLE_MEDIA_FILE : Lcom/fyber/inneractive/sdk/network/o;
    //   119: astore #7
    //   121: aload_0
    //   122: getfield K : Ljava/util/Map;
    //   125: astore #11
    //   127: aload #8
    //   129: astore #5
    //   131: aload #7
    //   133: astore #6
    //   135: aload #11
    //   137: ifnull -> 83
    //   140: aload #11
    //   142: invokeinterface keySet : ()Ljava/util/Set;
    //   147: astore #12
    //   149: aload #8
    //   151: astore #5
    //   153: aload #7
    //   155: astore #6
    //   157: aload #12
    //   159: ifnull -> 83
    //   162: aload #8
    //   164: astore #5
    //   166: aload #7
    //   168: astore #6
    //   170: aload #12
    //   172: invokeinterface size : ()I
    //   177: ifle -> 83
    //   180: new com/fyber/inneractive/sdk/network/q$b
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore #9
    //   189: new org/json/JSONArray
    //   192: dup
    //   193: invokespecial <init> : ()V
    //   196: astore #6
    //   198: aload #12
    //   200: invokeinterface iterator : ()Ljava/util/Iterator;
    //   205: astore #12
    //   207: aload #12
    //   209: invokeinterface hasNext : ()Z
    //   214: ifeq -> 400
    //   217: aload #12
    //   219: invokeinterface next : ()Ljava/lang/Object;
    //   224: checkcast com/fyber/inneractive/sdk/model/vast/n
    //   227: astore #15
    //   229: aload #11
    //   231: aload #15
    //   233: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   238: checkcast com/fyber/inneractive/sdk/flow/vast/g
    //   241: astore #13
    //   243: new org/json/JSONObject
    //   246: dup
    //   247: invokespecial <init> : ()V
    //   250: astore #14
    //   252: aload #14
    //   254: ldc 'url'
    //   256: aload #15
    //   258: getfield g : Ljava/lang/String;
    //   261: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   264: pop
    //   265: aload #14
    //   267: ldc 'bitrate'
    //   269: aload #15
    //   271: getfield e : Ljava/lang/Integer;
    //   274: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   277: pop
    //   278: aload #15
    //   280: getfield d : Ljava/lang/String;
    //   283: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   286: ifeq -> 296
    //   289: ldc 'na'
    //   291: astore #5
    //   293: goto -> 303
    //   296: aload #15
    //   298: getfield d : Ljava/lang/String;
    //   301: astore #5
    //   303: aload #14
    //   305: ldc 'mime'
    //   307: aload #5
    //   309: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   312: pop
    //   313: aload #14
    //   315: ldc 'delivery'
    //   317: aload #15
    //   319: getfield a : Ljava/lang/String;
    //   322: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   325: pop
    //   326: aload #13
    //   328: getfield a : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   331: astore #5
    //   333: aload #5
    //   335: ifnull -> 1468
    //   338: aload #5
    //   340: getfield value : I
    //   343: istore_3
    //   344: goto -> 347
    //   347: aload #14
    //   349: ldc 'reason'
    //   351: iload_3
    //   352: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   355: pop
    //   356: aload #14
    //   358: ldc 'required_value'
    //   360: aload #13
    //   362: getfield b : Ljava/lang/Object;
    //   365: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   368: pop
    //   369: aload #6
    //   371: aload #14
    //   373: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   376: pop
    //   377: goto -> 207
    //   380: ldc 'VastResponseValidator: Failed converting media file data to Extra data json!'
    //   382: iconst_0
    //   383: anewarray java/lang/Object
    //   386: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   389: aload #8
    //   391: astore #5
    //   393: aload #7
    //   395: astore #6
    //   397: goto -> 83
    //   400: aload #9
    //   402: ldc 'media_files'
    //   404: aload #6
    //   406: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/fyber/inneractive/sdk/network/q$b;
    //   409: pop
    //   410: aload #8
    //   412: astore #5
    //   414: aload #7
    //   416: astore #6
    //   418: aload #9
    //   420: astore #7
    //   422: goto -> 86
    //   425: ldc 'VastErrorTooManyWrappers'
    //   427: aload #5
    //   429: invokevirtual equals : (Ljava/lang/Object;)Z
    //   432: ifeq -> 474
    //   435: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.SERVER_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   438: astore #5
    //   440: getstatic com/fyber/inneractive/sdk/network/o.VAST_ERROR_TOO_MANY_WRAPPERS : Lcom/fyber/inneractive/sdk/network/o;
    //   443: astore #6
    //   445: new com/fyber/inneractive/sdk/network/q$b
    //   448: dup
    //   449: invokespecial <init> : ()V
    //   452: ldc 'max'
    //   454: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   457: getfield i : Lcom/fyber/inneractive/sdk/config/s;
    //   460: getfield c : I
    //   463: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   466: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/fyber/inneractive/sdk/network/q$b;
    //   469: astore #7
    //   471: goto -> 86
    //   474: ldc 'ErrorNoMediaFiles'
    //   476: aload #5
    //   478: invokevirtual equals : (Ljava/lang/Object;)Z
    //   481: ifeq -> 497
    //   484: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.SERVER_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   487: astore #5
    //   489: getstatic com/fyber/inneractive/sdk/network/o.VAST_ERROR_NO_MEDIA_FILES : Lcom/fyber/inneractive/sdk/network/o;
    //   492: astore #6
    //   494: goto -> 83
    //   497: ldc 'ErrorConfigurationMismatch'
    //   499: aload #5
    //   501: invokevirtual equals : (Ljava/lang/Object;)Z
    //   504: ifeq -> 520
    //   507: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.ERROR_CONFIGURATION_MISMATCH : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   510: astore #5
    //   512: getstatic com/fyber/inneractive/sdk/network/o.INTERNAL_CONFIG_MISMATCH : Lcom/fyber/inneractive/sdk/network/o;
    //   515: astore #6
    //   517: goto -> 83
    //   520: ldc 'VastErrorUnsecure'
    //   522: aload #5
    //   524: invokevirtual equals : (Ljava/lang/Object;)Z
    //   527: ifeq -> 543
    //   530: getstatic com/fyber/inneractive/sdk/external/InneractiveErrorCode.SERVER_INVALID_RESPONSE : Lcom/fyber/inneractive/sdk/external/InneractiveErrorCode;
    //   533: astore #5
    //   535: getstatic com/fyber/inneractive/sdk/network/o.VAST_ERROR_UNSECURE_URL : Lcom/fyber/inneractive/sdk/network/o;
    //   538: astore #6
    //   540: goto -> 83
    //   543: aconst_null
    //   544: astore #5
    //   546: aconst_null
    //   547: astore #6
    //   549: aconst_null
    //   550: astore #7
    //   552: aload #5
    //   554: ifnull -> 628
    //   557: aload_2
    //   558: ifnonnull -> 567
    //   561: aconst_null
    //   562: astore #8
    //   564: goto -> 573
    //   567: aload_2
    //   568: invokevirtual c : ()Lorg/json/JSONArray;
    //   571: astore #8
    //   573: new com/fyber/inneractive/sdk/network/q$a
    //   576: dup
    //   577: aload_0
    //   578: invokespecial <init> : (Lcom/fyber/inneractive/sdk/response/e;)V
    //   581: astore #9
    //   583: aload #9
    //   585: aload #5
    //   587: putfield b : Lcom/fyber/inneractive/sdk/network/o;
    //   590: aload #9
    //   592: aload_1
    //   593: putfield a : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   596: aload #9
    //   598: aload #8
    //   600: putfield d : Lorg/json/JSONArray;
    //   603: aload #7
    //   605: ifnull -> 622
    //   608: aload #9
    //   610: getfield f : Lorg/json/JSONArray;
    //   613: aload #7
    //   615: getfield a : Lorg/json/JSONObject;
    //   618: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   621: pop
    //   622: aload #9
    //   624: aconst_null
    //   625: invokevirtual a : (Ljava/lang/String;)V
    //   628: aload_0
    //   629: getfield L : Ljava/util/List;
    //   632: astore #7
    //   634: aload #7
    //   636: ifnull -> 1052
    //   639: aload #7
    //   641: invokeinterface size : ()I
    //   646: ifle -> 1052
    //   649: getstatic com/fyber/inneractive/sdk/network/p.VAST_EVENT_COMPANION_FILTERED : Lcom/fyber/inneractive/sdk/network/p;
    //   652: astore #8
    //   654: aload_2
    //   655: ifnonnull -> 664
    //   658: aconst_null
    //   659: astore #5
    //   661: goto -> 670
    //   664: aload_2
    //   665: invokevirtual c : ()Lorg/json/JSONArray;
    //   668: astore #5
    //   670: new com/fyber/inneractive/sdk/network/q$a
    //   673: dup
    //   674: aload #8
    //   676: aload_1
    //   677: aload_0
    //   678: aload #5
    //   680: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   683: astore #8
    //   685: new org/json/JSONObject
    //   688: dup
    //   689: invokespecial <init> : ()V
    //   692: astore #9
    //   694: new org/json/JSONArray
    //   697: dup
    //   698: invokespecial <init> : ()V
    //   701: astore #11
    //   703: aload #7
    //   705: invokeinterface iterator : ()Ljava/util/Iterator;
    //   710: astore #12
    //   712: aload #12
    //   714: invokeinterface hasNext : ()Z
    //   719: ifeq -> 1000
    //   722: aload #12
    //   724: invokeinterface next : ()Ljava/lang/Object;
    //   729: checkcast com/fyber/inneractive/sdk/model/vast/f
    //   732: astore #13
    //   734: aload #13
    //   736: invokevirtual getClass : ()Ljava/lang/Class;
    //   739: pop
    //   740: new org/json/JSONObject
    //   743: dup
    //   744: invokespecial <init> : ()V
    //   747: astore #7
    //   749: aload #7
    //   751: ldc_w 'w'
    //   754: aload #13
    //   756: getfield a : Ljava/lang/Integer;
    //   759: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   762: pop
    //   763: aload #7
    //   765: ldc_w 'h'
    //   768: aload #13
    //   770: getfield b : Ljava/lang/Integer;
    //   773: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   776: pop
    //   777: aload #7
    //   779: ldc_w 'ctr'
    //   782: aload #13
    //   784: getfield g : Ljava/lang/String;
    //   787: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   790: pop
    //   791: aload #7
    //   793: ldc_w 'clt'
    //   796: aload #13
    //   798: getfield h : Ljava/util/List;
    //   801: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   804: pop
    //   805: aload #13
    //   807: getfield f : Ljava/lang/String;
    //   810: astore #5
    //   812: aload #5
    //   814: ifnull -> 1473
    //   817: aload #7
    //   819: ldc_w 'content'
    //   822: aload #5
    //   824: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   827: pop
    //   828: ldc_w 'HTMLResource'
    //   831: astore #5
    //   833: goto -> 836
    //   836: aload #13
    //   838: getfield d : Lcom/fyber/inneractive/sdk/model/vast/i;
    //   841: astore #14
    //   843: aload #14
    //   845: ifnull -> 884
    //   848: aload #7
    //   850: ldc_w 'content'
    //   853: aload #14
    //   855: getfield b : Ljava/lang/String;
    //   858: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   861: pop
    //   862: aload #7
    //   864: ldc_w 'creativeType'
    //   867: aload #13
    //   869: getfield d : Lcom/fyber/inneractive/sdk/model/vast/i;
    //   872: getfield a : Ljava/lang/String;
    //   875: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   878: pop
    //   879: ldc_w 'StaticResource'
    //   882: astore #5
    //   884: aload #13
    //   886: getfield e : Ljava/lang/String;
    //   889: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   892: ifne -> 914
    //   895: aload #7
    //   897: ldc_w 'content'
    //   900: aload #13
    //   902: getfield e : Ljava/lang/String;
    //   905: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   908: pop
    //   909: ldc_w 'iFrameResource'
    //   912: astore #5
    //   914: aload #5
    //   916: ifnull -> 930
    //   919: aload #7
    //   921: ldc_w 'type'
    //   924: aload #5
    //   926: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   929: pop
    //   930: aload #13
    //   932: getfield i : Lcom/fyber/inneractive/sdk/flow/vast/d$a;
    //   935: astore #13
    //   937: aload #7
    //   939: astore #5
    //   941: aload #13
    //   943: ifnull -> 989
    //   946: aload #7
    //   948: ldc 'reason'
    //   950: aload #13
    //   952: getfield a : I
    //   955: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   958: pop
    //   959: aload #7
    //   961: astore #5
    //   963: goto -> 989
    //   966: astore #5
    //   968: ldc_w 'Failed creating Companion json object: %s'
    //   971: iconst_1
    //   972: anewarray java/lang/Object
    //   975: dup
    //   976: iconst_0
    //   977: aload #5
    //   979: invokevirtual getMessage : ()Ljava/lang/String;
    //   982: aastore
    //   983: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   986: aconst_null
    //   987: astore #5
    //   989: aload #11
    //   991: aload #5
    //   993: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   996: pop
    //   997: goto -> 712
    //   1000: aload #9
    //   1002: ldc_w 'companion_data'
    //   1005: aload #11
    //   1007: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1010: pop
    //   1011: goto -> 1035
    //   1014: ldc_w 'Got exception adding param to json object: %s, %s'
    //   1017: iconst_2
    //   1018: anewarray java/lang/Object
    //   1021: dup
    //   1022: iconst_0
    //   1023: ldc_w 'companion_data'
    //   1026: aastore
    //   1027: dup
    //   1028: iconst_1
    //   1029: aload #11
    //   1031: aastore
    //   1032: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1035: aload #8
    //   1037: getfield f : Lorg/json/JSONArray;
    //   1040: aload #9
    //   1042: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   1045: pop
    //   1046: aload #8
    //   1048: aconst_null
    //   1049: invokevirtual a : (Ljava/lang/String;)V
    //   1052: aload_0
    //   1053: getfield J : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   1056: astore #5
    //   1058: aload #5
    //   1060: ifnull -> 1075
    //   1063: aload #5
    //   1065: getfield g : Ljava/util/PriorityQueue;
    //   1068: invokevirtual size : ()I
    //   1071: istore_3
    //   1072: goto -> 1077
    //   1075: iconst_0
    //   1076: istore_3
    //   1077: aload_0
    //   1078: getfield L : Ljava/util/List;
    //   1081: astore #5
    //   1083: aload #5
    //   1085: ifnull -> 1100
    //   1088: aload #5
    //   1090: invokeinterface size : ()I
    //   1095: istore #4
    //   1097: goto -> 1103
    //   1100: iconst_0
    //   1101: istore #4
    //   1103: getstatic com/fyber/inneractive/sdk/network/p.NUMBER_OF_COMPANIONS : Lcom/fyber/inneractive/sdk/network/p;
    //   1106: astore #7
    //   1108: aload_2
    //   1109: ifnonnull -> 1118
    //   1112: aconst_null
    //   1113: astore #5
    //   1115: goto -> 1124
    //   1118: aload_2
    //   1119: invokevirtual c : ()Lorg/json/JSONArray;
    //   1122: astore #5
    //   1124: new com/fyber/inneractive/sdk/network/q$a
    //   1127: dup
    //   1128: aload #7
    //   1130: aload_1
    //   1131: aload_0
    //   1132: aload #5
    //   1134: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   1137: astore #5
    //   1139: new org/json/JSONObject
    //   1142: dup
    //   1143: invokespecial <init> : ()V
    //   1146: astore #7
    //   1148: iload_3
    //   1149: iload #4
    //   1151: iadd
    //   1152: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1155: astore #8
    //   1157: aload #7
    //   1159: ldc_w 'number_of_endcards'
    //   1162: aload #8
    //   1164: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1167: pop
    //   1168: goto -> 1192
    //   1171: ldc_w 'Got exception adding param to json object: %s, %s'
    //   1174: iconst_2
    //   1175: anewarray java/lang/Object
    //   1178: dup
    //   1179: iconst_0
    //   1180: ldc_w 'number_of_endcards'
    //   1183: aastore
    //   1184: dup
    //   1185: iconst_1
    //   1186: aload #8
    //   1188: aastore
    //   1189: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1192: aload #5
    //   1194: getfield f : Lorg/json/JSONArray;
    //   1197: aload #7
    //   1199: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   1202: pop
    //   1203: aload #5
    //   1205: aconst_null
    //   1206: invokevirtual a : (Ljava/lang/String;)V
    //   1209: aload_0
    //   1210: getfield J : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   1213: ifnull -> 1442
    //   1216: new com/fyber/inneractive/sdk/flow/vast/j
    //   1219: dup
    //   1220: aload #10
    //   1222: aload_0
    //   1223: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/k;Lcom/fyber/inneractive/sdk/response/g;)V
    //   1226: astore #9
    //   1228: aload #9
    //   1230: invokevirtual size : ()I
    //   1233: ifle -> 1442
    //   1236: new org/json/JSONObject
    //   1239: dup
    //   1240: invokespecial <init> : ()V
    //   1243: astore #5
    //   1245: new org/json/JSONArray
    //   1248: dup
    //   1249: invokespecial <init> : ()V
    //   1252: astore #7
    //   1254: getstatic com/fyber/inneractive/sdk/network/p.OMID_VAST_DETECTION : Lcom/fyber/inneractive/sdk/network/p;
    //   1257: astore #8
    //   1259: aload_2
    //   1260: ifnonnull -> 1268
    //   1263: aconst_null
    //   1264: astore_2
    //   1265: goto -> 1273
    //   1268: aload_2
    //   1269: invokevirtual c : ()Lorg/json/JSONArray;
    //   1272: astore_2
    //   1273: new com/fyber/inneractive/sdk/network/q$a
    //   1276: dup
    //   1277: aload #8
    //   1279: aload_1
    //   1280: aload_0
    //   1281: aload_2
    //   1282: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   1285: astore #8
    //   1287: aload #9
    //   1289: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1292: astore #9
    //   1294: aload #9
    //   1296: invokeinterface hasNext : ()Z
    //   1301: ifeq -> 1390
    //   1304: aload #9
    //   1306: invokeinterface next : ()Ljava/lang/Object;
    //   1311: checkcast com/fyber/inneractive/sdk/measurement/f
    //   1314: astore #10
    //   1316: aload #10
    //   1318: invokevirtual getClass : ()Ljava/lang/Class;
    //   1321: pop
    //   1322: new org/json/JSONObject
    //   1325: dup
    //   1326: invokespecial <init> : ()V
    //   1329: astore_2
    //   1330: aload_2
    //   1331: ldc_w 'success'
    //   1334: aload #10
    //   1336: invokevirtual b : ()Z
    //   1339: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1342: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1345: pop
    //   1346: aload_2
    //   1347: astore_1
    //   1348: aload #10
    //   1350: invokevirtual b : ()Z
    //   1353: ifne -> 1376
    //   1356: aload_2
    //   1357: ldc_w 'error_reason'
    //   1360: aload #10
    //   1362: invokevirtual a : ()Ljava/lang/String;
    //   1365: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1368: pop
    //   1369: aload_2
    //   1370: astore_1
    //   1371: goto -> 1376
    //   1374: aconst_null
    //   1375: astore_1
    //   1376: aload_1
    //   1377: ifnull -> 1294
    //   1380: aload #7
    //   1382: aload_1
    //   1383: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   1386: pop
    //   1387: goto -> 1294
    //   1390: aload #5
    //   1392: ldc_w 'verifications'
    //   1395: aload #7
    //   1397: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1400: pop
    //   1401: goto -> 1425
    //   1404: ldc_w 'Got exception adding param to json object: %s, %s'
    //   1407: iconst_2
    //   1408: anewarray java/lang/Object
    //   1411: dup
    //   1412: iconst_0
    //   1413: ldc_w 'verifications'
    //   1416: aastore
    //   1417: dup
    //   1418: iconst_1
    //   1419: aload #7
    //   1421: aastore
    //   1422: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1425: aload #8
    //   1427: getfield f : Lorg/json/JSONArray;
    //   1430: aload #5
    //   1432: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   1435: pop
    //   1436: aload #8
    //   1438: aconst_null
    //   1439: invokevirtual a : (Ljava/lang/String;)V
    //   1442: aload #6
    //   1444: areturn
    //   1445: astore #5
    //   1447: goto -> 380
    //   1450: astore #5
    //   1452: goto -> 1014
    //   1455: astore #9
    //   1457: goto -> 1171
    //   1460: astore_1
    //   1461: goto -> 1374
    //   1464: astore_1
    //   1465: goto -> 1404
    //   1468: iconst_0
    //   1469: istore_3
    //   1470: goto -> 347
    //   1473: aconst_null
    //   1474: astore #5
    //   1476: goto -> 836
    // Exception table:
    //   from	to	target	type
    //   229	289	1445	org/json/JSONException
    //   296	303	1445	org/json/JSONException
    //   303	333	1445	org/json/JSONException
    //   338	344	1445	org/json/JSONException
    //   347	377	1445	org/json/JSONException
    //   749	812	966	org/json/JSONException
    //   817	828	966	org/json/JSONException
    //   836	843	966	org/json/JSONException
    //   848	879	966	org/json/JSONException
    //   884	909	966	org/json/JSONException
    //   919	930	966	org/json/JSONException
    //   930	937	966	org/json/JSONException
    //   946	959	966	org/json/JSONException
    //   1000	1011	1450	java/lang/Exception
    //   1157	1168	1455	java/lang/Exception
    //   1330	1346	1460	org/json/JSONException
    //   1348	1369	1460	org/json/JSONException
    //   1390	1401	1464	java/lang/Exception
  }
  
  public List<f> d() {
    return this.M;
  }
  
  public b e() {
    return this.J;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\response\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */