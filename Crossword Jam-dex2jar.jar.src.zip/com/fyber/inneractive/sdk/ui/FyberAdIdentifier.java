package com.fyber.inneractive.sdk.ui;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.util.Property;
import android.view.View;
import android.widget.ImageView;
import com.fyber.inneractive.sdk.R;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;

public class FyberAdIdentifier implements View.OnClickListener {
  public ImageView a;
  
  public View b;
  
  public Corner c = Corner.BOTTOM_LEFT;
  
  public boolean d = false;
  
  public Animator e;
  
  public float f = 0.0F;
  
  public ClickListener g;
  
  public Bitmap h;
  
  public static boolean a(FyberAdIdentifier paramFyberAdIdentifier) {
    Corner corner = paramFyberAdIdentifier.c;
    return (corner == Corner.TOP_LEFT || corner == Corner.BOTTOM_LEFT);
  }
  
  public FyberAdIdentifier a(ClickListener paramClickListener) {
    this.g = paramClickListener;
    return this;
  }
  
  public final void a() {
    this.d = false;
    this.b.setTranslationX(0.0F);
    this.a.setImageResource(R.drawable.fyber_info_button);
    Animator animator = this.e;
    if (animator != null) {
      animator.removeAllListeners();
      this.e = null;
    } 
  }
  
  public void onClick(View paramView) {
    Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/ui/FyberAdIdentifier;->onClick(Landroid/view/View;)V");
    CreativeInfoManager.onViewClicked("com.inneractive", paramView);
    safedk_FyberAdIdentifier_onClick_dd54f480d38e69db907196f8e63ce2cd(paramView);
  }
  
  public void safedk_FyberAdIdentifier_onClick_dd54f480d38e69db907196f8e63ce2cd(View paramView) {
    AnimatorSet animatorSet;
    if (paramView.getId() == this.a.getId()) {
      if (this.e != null)
        return; 
      animatorSet = new AnimatorSet();
      ObjectAnimator objectAnimator1 = ObjectAnimator.ofFloat(this.a, View.ROTATION_X, new float[] { 90.0F });
      ObjectAnimator objectAnimator4 = ObjectAnimator.ofInt(this.a, "imageAlpha", new int[] { 255, 25 });
      AnimatorSet animatorSet2 = new AnimatorSet();
      animatorSet2.playTogether(new Animator[] { (Animator)objectAnimator1, (Animator)objectAnimator4 });
      animatorSet2.addListener((Animator.AnimatorListener)new c(this, animatorSet));
      animatorSet2.setDuration(225L);
      this.e = (Animator)animatorSet2;
      animatorSet2.start();
      ImageView imageView = this.a;
      Property property1 = View.ROTATION_X;
      float f = 0.0F;
      ObjectAnimator objectAnimator3 = ObjectAnimator.ofFloat(imageView, property1, new float[] { 0.0F });
      ObjectAnimator objectAnimator5 = ObjectAnimator.ofInt(this.a, "imageAlpha", new int[] { 25, 255 });
      AnimatorSet animatorSet1 = new AnimatorSet();
      animatorSet1.playTogether(new Animator[] { (Animator)objectAnimator3, (Animator)objectAnimator5 });
      animatorSet1.setDuration(225L);
      View view = this.b;
      Property property2 = View.TRANSLATION_X;
      if (this.d)
        f = this.f; 
      ObjectAnimator objectAnimator2 = ObjectAnimator.ofFloat(view, property2, new float[] { f });
      objectAnimator2.setDuration(450L);
      animatorSet.setDuration(450L);
      animatorSet.playTogether(new Animator[] { (Animator)objectAnimator2, (Animator)animatorSet1 });
      animatorSet.addListener((Animator.AnimatorListener)new d(this));
      return;
    } 
    if (animatorSet.getId() == this.b.getId() && this.g != null) {
      a();
      this.g.a();
    } 
  }
  
  public static interface ClickListener {
    void a();
  }
  
  public enum Corner {
    BOTTOM_LEFT, BOTTOM_RIGHT, TOP_LEFT, TOP_RIGHT;
    
    static {
      Corner corner1 = new Corner("TOP_LEFT", 0);
      TOP_LEFT = corner1;
      Corner corner2 = new Corner("TOP_RIGHT", 1);
      TOP_RIGHT = corner2;
      Corner corner3 = new Corner("BOTTOM_LEFT", 2);
      BOTTOM_LEFT = corner3;
      Corner corner4 = new Corner("BOTTOM_RIGHT", 3);
      BOTTOM_RIGHT = corner4;
      $VALUES = new Corner[] { corner1, corner2, corner3, corner4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sd\\ui\FyberAdIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */