package com.fyber.inneractive.sdk;

public final class R {
  public static final class attr {
    public static final int adSize = 2130968615;
    
    public static final int adSizes = 2130968616;
    
    public static final int adUnitId = 2130968617;
    
    public static final int alpha = 2130968663;
    
    public static final int buttonSize = 2130968725;
    
    public static final int circleCrop = 2130968772;
    
    public static final int colorScheme = 2130968804;
    
    public static final int coordinatorLayoutStyle = 2130968845;
    
    public static final int font = 2130968954;
    
    public static final int fontProviderAuthority = 2130968956;
    
    public static final int fontProviderCerts = 2130968957;
    
    public static final int fontProviderFetchStrategy = 2130968958;
    
    public static final int fontProviderFetchTimeout = 2130968959;
    
    public static final int fontProviderPackage = 2130968960;
    
    public static final int fontProviderQuery = 2130968961;
    
    public static final int fontStyle = 2130968963;
    
    public static final int fontVariationSettings = 2130968964;
    
    public static final int fontWeight = 2130968965;
    
    public static final int imageAspectRatio = 2130968997;
    
    public static final int imageAspectRatioAdjust = 2130968998;
    
    public static final int keylines = 2130969023;
    
    public static final int layout_anchor = 2130969031;
    
    public static final int layout_anchorGravity = 2130969032;
    
    public static final int layout_behavior = 2130969033;
    
    public static final int layout_dodgeInsetEdges = 2130969082;
    
    public static final int layout_insetEdge = 2130969092;
    
    public static final int layout_keyline = 2130969093;
    
    public static final int scopeUris = 2130969244;
    
    public static final int statusBarBackground = 2130969316;
    
    public static final int ttcIndex = 2130969447;
  }
  
  public static final class bool {
    public static final int enable_system_alarm_service_default = 2131034117;
    
    public static final int enable_system_job_service_default = 2131034119;
    
    public static final int workmanager_test_configuration = 2131034121;
  }
  
  public static final class color {
    public static final int blank_background = 2131099715;
    
    public static final int browser_actions_bg_grey = 2131099724;
    
    public static final int browser_actions_divider_color = 2131099725;
    
    public static final int browser_actions_text_color = 2131099726;
    
    public static final int browser_actions_title_color = 2131099727;
    
    public static final int close_rewarded_button_background_color = 2131099734;
    
    public static final int close_rewarded_button_color = 2131099735;
    
    public static final int close_rewarded_dialog_background = 2131099736;
    
    public static final int close_rewarded_sub_title_color = 2131099737;
    
    public static final int close_rewarded_title_color = 2131099738;
    
    public static final int common_google_signin_btn_text_dark = 2131099756;
    
    public static final int common_google_signin_btn_text_dark_default = 2131099757;
    
    public static final int common_google_signin_btn_text_dark_disabled = 2131099758;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131099759;
    
    public static final int common_google_signin_btn_text_dark_pressed = 2131099760;
    
    public static final int common_google_signin_btn_text_light = 2131099761;
    
    public static final int common_google_signin_btn_text_light_default = 2131099762;
    
    public static final int common_google_signin_btn_text_light_disabled = 2131099763;
    
    public static final int common_google_signin_btn_text_light_focused = 2131099764;
    
    public static final int common_google_signin_btn_text_light_pressed = 2131099765;
    
    public static final int common_google_signin_btn_tint = 2131099766;
    
    public static final int fyber_accent = 2131099789;
    
    public static final int fyber_identifier_bg_color = 2131099790;
    
    public static final int fyber_white = 2131099791;
    
    public static final int ia_endcard_background = 2131099800;
    
    public static final int ia_endcard_gray = 2131099801;
    
    public static final int ia_fullscreen_background = 2131099802;
    
    public static final int ia_mraid_expanded_dimmed_bk = 2131099803;
    
    public static final int ia_overlay_bg_color = 2131099804;
    
    public static final int ia_overlay_stroke_color = 2131099805;
    
    public static final int ia_video_background_color = 2131099806;
    
    public static final int ia_video_overlay_stroke = 2131099807;
    
    public static final int ia_video_overlay_text = 2131099808;
    
    public static final int ia_video_overlay_text_background = 2131099809;
    
    public static final int ia_video_overlay_text_background_pressed = 2131099810;
    
    public static final int ia_video_overlay_text_shadow = 2131099811;
    
    public static final int ia_video_progressbar = 2131099812;
    
    public static final int ia_video_progressbar_background = 2131099813;
    
    public static final int ia_video_progressbar_green = 2131099814;
    
    public static final int ia_video_transparent_overlay = 2131099815;
    
    public static final int notification_action_color_filter = 2131099913;
    
    public static final int notification_icon_bg_color = 2131099914;
    
    public static final int ripple_material_light = 2131099925;
    
    public static final int secondary_text_default_material_light = 2131099927;
    
    public static final int transparent_background = 2131099940;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131165313;
    
    public static final int browser_actions_context_menu_min_padding = 2131165314;
    
    public static final int compat_button_inset_horizontal_material = 2131165335;
    
    public static final int compat_button_inset_vertical_material = 2131165336;
    
    public static final int compat_button_padding_horizontal_material = 2131165337;
    
    public static final int compat_button_padding_vertical_material = 2131165338;
    
    public static final int compat_control_corner_material = 2131165339;
    
    public static final int compat_notification_large_icon_max_height = 2131165340;
    
    public static final int compat_notification_large_icon_max_width = 2131165341;
    
    public static final int ia_bg_corner_radius = 2131165417;
    
    public static final int ia_button_padding_lateral = 2131165418;
    
    public static final int ia_endcard_button_margin_bottom = 2131165419;
    
    public static final int ia_endcard_button_padding_vertical = 2131165420;
    
    public static final int ia_endcard_hand_margin_button = 2131165421;
    
    public static final int ia_endcard_overlay_button_height_large = 2131165422;
    
    public static final int ia_endcard_overlay_button_height_medium = 2131165423;
    
    public static final int ia_endcard_overlay_button_width_large = 2131165424;
    
    public static final int ia_endcard_overlay_button_width_medium = 2131165425;
    
    public static final int ia_identifier_overlay_margin_bottom = 2131165426;
    
    public static final int ia_identifier_overlay_margin_left = 2131165427;
    
    public static final int ia_image_control_padding = 2131165428;
    
    public static final int ia_image_control_size = 2131165429;
    
    public static final int ia_inner_drawable_padding = 2131165430;
    
    public static final int ia_overlay_control_margin = 2131165431;
    
    public static final int ia_overlay_stroke_width = 2131165432;
    
    public static final int ia_play_button_size = 2131165433;
    
    public static final int ia_progress_bar_height = 2131165434;
    
    public static final int ia_round_control_padding = 2131165435;
    
    public static final int ia_round_control_size = 2131165436;
    
    public static final int ia_round_control_size_clickable = 2131165437;
    
    public static final int ia_round_overlay_radius = 2131165438;
    
    public static final int ia_video_control_margin = 2131165439;
    
    public static final int ia_video_overlay_button_width = 2131165440;
    
    public static final int ia_video_overlay_cta_button_height = 2131165441;
    
    public static final int ia_video_overlay_cta_button_margin = 2131165442;
    
    public static final int ia_video_overlay_cta_button_padding = 2131165443;
    
    public static final int ia_video_overlay_cta_button_width = 2131165444;
    
    public static final int ia_video_overlay_margin_bottom = 2131165445;
    
    public static final int ia_video_overlay_text_large = 2131165446;
    
    public static final int ia_video_overlay_text_large_for_cta = 2131165447;
    
    public static final int ia_video_overlay_text_large_plus = 2131165448;
    
    public static final int ia_video_overlay_text_small = 2131165449;
    
    public static final int ia_video_text_padding = 2131165450;
    
    public static final int identifier_image_height = 2131165451;
    
    public static final int identifier_image_width = 2131165452;
    
    public static final int identifier_layout_height = 2131165453;
    
    public static final int identifier_layout_width = 2131165454;
    
    public static final int identifier_padding = 2131165455;
    
    public static final int identifier_text_height = 2131165456;
    
    public static final int identifier_text_text_size = 2131165457;
    
    public static final int identifier_text_width = 2131165458;
    
    public static final int notification_action_icon_size = 2131165522;
    
    public static final int notification_action_text_size = 2131165523;
    
    public static final int notification_big_circle_margin = 2131165524;
    
    public static final int notification_content_margin_start = 2131165525;
    
    public static final int notification_large_icon_height = 2131165526;
    
    public static final int notification_large_icon_width = 2131165527;
    
    public static final int notification_main_column_padding_top = 2131165528;
    
    public static final int notification_media_narrow_margin = 2131165529;
    
    public static final int notification_right_icon_size = 2131165530;
    
    public static final int notification_right_side_padding_top = 2131165531;
    
    public static final int notification_small_icon_background_padding = 2131165532;
    
    public static final int notification_small_icon_size_as_large = 2131165533;
    
    public static final int notification_subtext_size = 2131165534;
    
    public static final int notification_top_pad = 2131165535;
    
    public static final int notification_top_pad_large_text = 2131165536;
  }
  
  public static final class drawable {
    public static final int bg_circle_overlay = 2131230959;
    
    public static final int bg_green = 2131230960;
    
    public static final int bg_green_medium = 2131230961;
    
    public static final int bg_green_playstore = 2131230962;
    
    public static final int bg_text_overlay = 2131230963;
    
    public static final int circular_progress = 2131230981;
    
    public static final int circular_progress_background = 2131230982;
    
    public static final int common_full_open_on_phone = 2131231037;
    
    public static final int common_google_signin_btn_icon_dark = 2131231038;
    
    public static final int common_google_signin_btn_icon_dark_focused = 2131231039;
    
    public static final int common_google_signin_btn_icon_dark_normal = 2131231040;
    
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131231041;
    
    public static final int common_google_signin_btn_icon_disabled = 2131231042;
    
    public static final int common_google_signin_btn_icon_light = 2131231043;
    
    public static final int common_google_signin_btn_icon_light_focused = 2131231044;
    
    public static final int common_google_signin_btn_icon_light_normal = 2131231045;
    
    public static final int common_google_signin_btn_icon_light_normal_background = 2131231046;
    
    public static final int common_google_signin_btn_text_dark = 2131231047;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131231048;
    
    public static final int common_google_signin_btn_text_dark_normal = 2131231049;
    
    public static final int common_google_signin_btn_text_dark_normal_background = 2131231050;
    
    public static final int common_google_signin_btn_text_disabled = 2131231051;
    
    public static final int common_google_signin_btn_text_light = 2131231052;
    
    public static final int common_google_signin_btn_text_light_focused = 2131231053;
    
    public static final int common_google_signin_btn_text_light_normal = 2131231054;
    
    public static final int common_google_signin_btn_text_light_normal_background = 2131231055;
    
    public static final int fyber_clip_drawable = 2131231076;
    
    public static final int fyber_info_button = 2131231077;
    
    public static final int fyber_logo_green = 2131231078;
    
    public static final int fyber_logo_white = 2131231079;
    
    public static final int googleg_disabled_color_18 = 2131231083;
    
    public static final int googleg_standard_color_18 = 2131231084;
    
    public static final int ia_circle_overlay_bg = 2131231098;
    
    public static final int ia_close = 2131231099;
    
    public static final int ia_collapse = 2131231100;
    
    public static final int ia_expand = 2131231101;
    
    public static final int ia_ib_background = 2131231102;
    
    public static final int ia_ib_close = 2131231103;
    
    public static final int ia_ib_left_arrow = 2131231104;
    
    public static final int ia_ib_refresh = 2131231105;
    
    public static final int ia_ib_right_arrow = 2131231106;
    
    public static final int ia_ib_unleft_arrow = 2131231107;
    
    public static final int ia_ib_unright_arrow = 2131231108;
    
    public static final int ia_mute = 2131231109;
    
    public static final int ia_play = 2131231110;
    
    public static final int ia_progress_bar_drawable = 2131231111;
    
    public static final int ia_round_overlay_bg = 2131231112;
    
    public static final int ia_round_overlay_bg_fyber = 2131231113;
    
    public static final int ia_round_overlay_bg_with_close = 2131231114;
    
    public static final int ia_sel_expand_collapse = 2131231115;
    
    public static final int ia_sel_mute = 2131231116;
    
    public static final int ia_sel_mute_w = 2131231117;
    
    public static final int ia_unmute = 2131231118;
    
    public static final int notification_action_background = 2131231420;
    
    public static final int notification_bg = 2131231421;
    
    public static final int notification_bg_low = 2131231422;
    
    public static final int notification_bg_low_normal = 2131231423;
    
    public static final int notification_bg_low_pressed = 2131231424;
    
    public static final int notification_bg_normal = 2131231425;
    
    public static final int notification_bg_normal_pressed = 2131231426;
    
    public static final int notification_icon_background = 2131231427;
    
    public static final int notification_template_icon_bg = 2131231428;
    
    public static final int notification_template_icon_low_bg = 2131231429;
    
    public static final int notification_tile_bg = 2131231430;
    
    public static final int notify_panel_notification_icon_bg = 2131231431;
    
    public static final int outline_skip_next_white_18dp = 2131231433;
    
    public static final int outline_volume_off_white_18dp = 2131231434;
    
    public static final int outline_volume_up_white_18dp = 2131231435;
    
    public static final int white_hand = 2131231451;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131361812;
    
    public static final int accessibility_custom_action_0 = 2131361813;
    
    public static final int accessibility_custom_action_1 = 2131361814;
    
    public static final int accessibility_custom_action_10 = 2131361815;
    
    public static final int accessibility_custom_action_11 = 2131361816;
    
    public static final int accessibility_custom_action_12 = 2131361817;
    
    public static final int accessibility_custom_action_13 = 2131361818;
    
    public static final int accessibility_custom_action_14 = 2131361819;
    
    public static final int accessibility_custom_action_15 = 2131361820;
    
    public static final int accessibility_custom_action_16 = 2131361821;
    
    public static final int accessibility_custom_action_17 = 2131361822;
    
    public static final int accessibility_custom_action_18 = 2131361823;
    
    public static final int accessibility_custom_action_19 = 2131361824;
    
    public static final int accessibility_custom_action_2 = 2131361825;
    
    public static final int accessibility_custom_action_20 = 2131361826;
    
    public static final int accessibility_custom_action_21 = 2131361827;
    
    public static final int accessibility_custom_action_22 = 2131361828;
    
    public static final int accessibility_custom_action_23 = 2131361829;
    
    public static final int accessibility_custom_action_24 = 2131361830;
    
    public static final int accessibility_custom_action_25 = 2131361831;
    
    public static final int accessibility_custom_action_26 = 2131361832;
    
    public static final int accessibility_custom_action_27 = 2131361833;
    
    public static final int accessibility_custom_action_28 = 2131361834;
    
    public static final int accessibility_custom_action_29 = 2131361835;
    
    public static final int accessibility_custom_action_3 = 2131361836;
    
    public static final int accessibility_custom_action_30 = 2131361837;
    
    public static final int accessibility_custom_action_31 = 2131361838;
    
    public static final int accessibility_custom_action_4 = 2131361839;
    
    public static final int accessibility_custom_action_5 = 2131361840;
    
    public static final int accessibility_custom_action_6 = 2131361841;
    
    public static final int accessibility_custom_action_7 = 2131361842;
    
    public static final int accessibility_custom_action_8 = 2131361843;
    
    public static final int accessibility_custom_action_9 = 2131361844;
    
    public static final int action_container = 2131361856;
    
    public static final int action_divider = 2131361858;
    
    public static final int action_image = 2131361859;
    
    public static final int action_text = 2131361866;
    
    public static final int actions = 2131361867;
    
    public static final int adjust_height = 2131361874;
    
    public static final int adjust_width = 2131361875;
    
    public static final int async = 2131361951;
    
    public static final int auto = 2131361952;
    
    public static final int blocking = 2131361968;
    
    public static final int bottom = 2131361971;
    
    public static final int browser_actions_header_text = 2131361977;
    
    public static final int browser_actions_menu_item_icon = 2131361978;
    
    public static final int browser_actions_menu_item_text = 2131361979;
    
    public static final int browser_actions_menu_items = 2131361980;
    
    public static final int browser_actions_menu_view = 2131361981;
    
    public static final int chronometer = 2131361997;
    
    public static final int close_button = 2131362012;
    
    public static final int close_button_container = 2131362013;
    
    public static final int container_click_progress = 2131362031;
    
    public static final int dark = 2131362044;
    
    public static final int dialog_button = 2131362060;
    
    public static final int end = 2131362084;
    
    public static final int forever = 2131362108;
    
    public static final int fyber_identifier_image = 2131362116;
    
    public static final int fyber_identifier_text = 2131362117;
    
    public static final int hand_animation = 2131362125;
    
    public static final int ia_ad_content = 2131362198;
    
    public static final int ia_b_end_card_call_to_action = 2131362199;
    
    public static final int ia_buffering_overlay = 2131362200;
    
    public static final int ia_click_overlay = 2131362201;
    
    public static final int ia_clickable_close_button = 2131362202;
    
    public static final int ia_close_button_background_item = 2131362203;
    
    public static final int ia_cta_container = 2131362204;
    
    public static final int ia_default_endcard_video_overlay = 2131362205;
    
    public static final int ia_endcard_tv_app_info_button = 2131362206;
    
    public static final int ia_endcard_video_overlay = 2131362207;
    
    public static final int ia_fl_close_button = 2131362208;
    
    public static final int ia_identifier_overlay = 2131362209;
    
    public static final int ia_iv_close_button = 2131362210;
    
    public static final int ia_iv_expand_collapse_button = 2131362211;
    
    public static final int ia_iv_last_frame = 2131362212;
    
    public static final int ia_iv_mute_button = 2131362213;
    
    public static final int ia_iv_mute_button_new = 2131362214;
    
    public static final int ia_iv_play_button = 2131362215;
    
    public static final int ia_iv_skip = 2131362216;
    
    public static final int ia_paused_video_overlay = 2131362217;
    
    public static final int ia_texture_view_host = 2131362218;
    
    public static final int ia_tv_app_info_button = 2131362219;
    
    public static final int ia_tv_call_to_action = 2131362220;
    
    public static final int ia_tv_close_button = 2131362221;
    
    public static final int ia_tv_remaining_time = 2131362222;
    
    public static final int ia_tv_skip = 2131362223;
    
    public static final int ia_tv_skip_left = 2131362224;
    
    public static final int ia_video_controls_overlay = 2131362225;
    
    public static final int ia_video_progressbar = 2131362226;
    
    public static final int ia_video_progressbar_new = 2131362227;
    
    public static final int icon = 2131362229;
    
    public static final int icon_group = 2131362230;
    
    public static final int icon_only = 2131362231;
    
    public static final int info = 2131362242;
    
    public static final int inn_texture_view = 2131362244;
    
    public static final int inneractive_vast_endcard_gif = 2131362245;
    
    public static final int inneractive_vast_endcard_html = 2131362246;
    
    public static final int inneractive_vast_endcard_iframe = 2131362247;
    
    public static final int inneractive_vast_endcard_static = 2131362248;
    
    public static final int inneractive_webview_internal_browser = 2131362249;
    
    public static final int inneractive_webview_mraid = 2131362250;
    
    public static final int inneractive_webview_report_ad = 2131362251;
    
    public static final int inneractive_webview_vast_endcard = 2131362252;
    
    public static final int inneractive_webview_vast_vpaid = 2131362253;
    
    public static final int internal_store_content = 2131362261;
    
    public static final int italic = 2131362267;
    
    public static final int keep_watching_button = 2131362272;
    
    public static final int left = 2131362279;
    
    public static final int light = 2131362283;
    
    public static final int line1 = 2131362284;
    
    public static final int line3 = 2131362285;
    
    public static final int mraid_video_view = 2131362473;
    
    public static final int none = 2131362490;
    
    public static final int normal = 2131362491;
    
    public static final int notification_background = 2131362496;
    
    public static final int notification_main_column = 2131362497;
    
    public static final int notification_main_column_container = 2131362498;
    
    public static final int right = 2131362547;
    
    public static final int right_icon = 2131362548;
    
    public static final int right_side = 2131362549;
    
    public static final int skip_dialog_sub_title_textview = 2131362585;
    
    public static final int skip_dialog_title_textview = 2131362586;
    
    public static final int standard = 2131362608;
    
    public static final int start = 2131362609;
    
    public static final int tag_accessibility_actions = 2131362627;
    
    public static final int tag_accessibility_clickable_spans = 2131362628;
    
    public static final int tag_accessibility_heading = 2131362629;
    
    public static final int tag_accessibility_pane_title = 2131362630;
    
    public static final int tag_screen_reader_focusable = 2131362634;
    
    public static final int tag_transition_group = 2131362636;
    
    public static final int tag_unhandled_key_event_manager = 2131362637;
    
    public static final int tag_unhandled_key_listeners = 2131362638;
    
    public static final int text = 2131362640;
    
    public static final int text2 = 2131362642;
    
    public static final int time = 2131362655;
    
    public static final int title = 2131362657;
    
    public static final int top = 2131362662;
    
    public static final int wide = 2131362698;
  }
  
  public static final class integer {
    public static final int google_play_services_version = 2131427346;
    
    public static final int ia_ib_button_size_dp = 2131427348;
    
    public static final int ia_ib_toolbar_height_dp = 2131427349;
    
    public static final int status_bar_notification_info_maxnum = 2131427357;
  }
  
  public static final class layout {
    public static final int activity_internal_store_webpage = 2131558428;
    
    public static final int browser_actions_context_menu_page = 2131558447;
    
    public static final int browser_actions_context_menu_row = 2131558448;
    
    public static final int custom_dialog = 2131558458;
    
    public static final int fyber_ad_identifier_layout = 2131558476;
    
    public static final int fyber_ad_identifier_relative_layout = 2131558477;
    
    public static final int ia_buffering_overlay = 2131558497;
    
    public static final int ia_click_overlay = 2131558498;
    
    public static final int ia_default_video_end_card = 2131558499;
    
    public static final int ia_fullscreen_activity = 2131558500;
    
    public static final int ia_rich_media_video = 2131558501;
    
    public static final int ia_video_view = 2131558502;
    
    public static final int ia_video_view_new_design = 2131558503;
    
    public static final int notification_action = 2131558581;
    
    public static final int notification_action_tombstone = 2131558582;
    
    public static final int notification_template_custom_big = 2131558589;
    
    public static final int notification_template_icon_group = 2131558590;
    
    public static final int notification_template_part_chronometer = 2131558594;
    
    public static final int notification_template_part_time = 2131558595;
    
    public static final int skip_rewarded_dialog = 2131558603;
    
    public static final int video_overlay = 2131558607;
  }
  
  public static final class string {
    public static final int ad_identifier = 2131886110;
    
    public static final int common_google_play_services_enable_button = 2131886237;
    
    public static final int common_google_play_services_enable_text = 2131886238;
    
    public static final int common_google_play_services_enable_title = 2131886239;
    
    public static final int common_google_play_services_install_button = 2131886240;
    
    public static final int common_google_play_services_install_text = 2131886241;
    
    public static final int common_google_play_services_install_title = 2131886242;
    
    public static final int common_google_play_services_notification_channel_name = 2131886243;
    
    public static final int common_google_play_services_notification_ticker = 2131886244;
    
    public static final int common_google_play_services_unknown_issue = 2131886245;
    
    public static final int common_google_play_services_unsupported_text = 2131886246;
    
    public static final int common_google_play_services_update_button = 2131886247;
    
    public static final int common_google_play_services_update_text = 2131886248;
    
    public static final int common_google_play_services_update_title = 2131886249;
    
    public static final int common_google_play_services_updating_text = 2131886250;
    
    public static final int common_google_play_services_wear_update_text = 2131886251;
    
    public static final int common_open_on_phone = 2131886252;
    
    public static final int common_signin_button_text = 2131886253;
    
    public static final int common_signin_button_text_long = 2131886254;
    
    public static final int ia_str_video_error = 2131886408;
    
    public static final int ia_video_app_info_text = 2131886409;
    
    public static final int ia_video_before_skip_format = 2131886410;
    
    public static final int ia_video_install_now_text = 2131886411;
    
    public static final int ia_video_instant_install_text = 2131886412;
    
    public static final int ia_video_skip_text = 2131886413;
    
    public static final int offline_notification_text = 2131886495;
    
    public static final int offline_notification_title = 2131886496;
    
    public static final int offline_opt_in_confirm = 2131886497;
    
    public static final int offline_opt_in_confirmation = 2131886498;
    
    public static final int offline_opt_in_decline = 2131886499;
    
    public static final int offline_opt_in_message = 2131886500;
    
    public static final int offline_opt_in_title = 2131886501;
    
    public static final int s1 = 2131886529;
    
    public static final int s2 = 2131886530;
    
    public static final int s3 = 2131886531;
    
    public static final int s4 = 2131886532;
    
    public static final int s5 = 2131886533;
    
    public static final int s6 = 2131886534;
    
    public static final int s7 = 2131886535;
    
    public static final int skip_rewarded_dialog_close_button = 2131886545;
    
    public static final int skip_rewarded_dialog_keep_watching = 2131886546;
    
    public static final int skip_rewarded_dialog_sub_title = 2131886547;
    
    public static final int skip_rewarded_dialog_title = 2131886548;
    
    public static final int status_bar_notification_info_overflow = 2131886553;
  }
  
  public static final class style {
    public static final int InneractiveAppTheme_Home = 2131951853;
    
    public static final int TextAppearance_Compat_Notification = 2131951953;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131951954;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131951956;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131951959;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131951961;
    
    public static final int Theme_IAPTheme = 2131952018;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952135;
    
    public static final int Widget_Compat_NotificationActionText = 2131952136;
    
    public static final int Widget_Support_CoordinatorLayout = 2131952183;
    
    public static final int ia_bottom_left_overlay = 2131952222;
    
    public static final int ia_bottom_right_overlay = 2131952223;
    
    public static final int ia_expand_collapse_button_style = 2131952224;
    
    public static final int ia_identifier_banner_overlay_style = 2131952225;
    
    public static final int ia_identifier_overlay_style = 2131952226;
    
    public static final int ia_mute_button_style = 2131952227;
    
    public static final int ia_play_button_style = 2131952228;
    
    public static final int ia_top_left_overlay = 2131952229;
    
    public static final int ia_top_right_overlay = 2131952230;
    
    public static final int ia_tv_app_info_btn_style = 2131952231;
    
    public static final int ia_tv_call_to_action_style = 2131952232;
    
    public static final int ia_tv_remaining_time_style = 2131952233;
    
    public static final int ia_tv_skip_style = 2131952234;
    
    public static final int ia_video_overlay_text_view = 2131952235;
    
    public static final int ia_video_progressbar_style = 2131952236;
    
    public static final int ia_video_progressbar_style_new = 2131952237;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130968615, 2130968616, 2130968617 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968663, 2130969024 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CoordinatorLayout = new int[] { 2130969023, 2130969316 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130969031, 2130969032, 2130969033, 2130969082, 2130969092, 2130969093 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130968956, 2130968957, 2130968958, 2130968959, 2130968960, 2130968961, 2130968962 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968954, 2130968963, 2130968964, 2130968965, 2130969447 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LoadingImageView = new int[] { 2130968772, 2130968997, 2130968998 };
    
    public static final int LoadingImageView_circleCrop = 0;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    
    public static final int[] SignInButton = new int[] { 2130968725, 2130968804, 2130969244 };
    
    public static final int SignInButton_buttonSize = 0;
    
    public static final int SignInButton_colorScheme = 1;
    
    public static final int SignInButton_scopeUris = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */