package com.fyber.inneractive.sdk.flow.vast;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.measurement.f;
import com.fyber.inneractive.sdk.model.vast.b;
import com.fyber.inneractive.sdk.model.vast.c;
import com.fyber.inneractive.sdk.model.vast.e;
import com.fyber.inneractive.sdk.model.vast.f;
import com.fyber.inneractive.sdk.model.vast.g;
import com.fyber.inneractive.sdk.model.vast.h;
import com.fyber.inneractive.sdk.model.vast.i;
import com.fyber.inneractive.sdk.model.vast.n;
import com.fyber.inneractive.sdk.model.vast.r;
import com.fyber.inneractive.sdk.model.vast.s;
import com.fyber.inneractive.sdk.model.vast.u;
import com.fyber.inneractive.sdk.response.i;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.x;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class d {
  public int a = -1;
  
  public int b = -1;
  
  public int c = -1;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public Map<n, g> f = new LinkedHashMap<n, g>();
  
  public List<f> g = new ArrayList<f>();
  
  public final List<f> h = new ArrayList<f>();
  
  public final List<f> i = new ArrayList<f>();
  
  public b a(com.fyber.inneractive.sdk.model.vast.d paramd, List<com.fyber.inneractive.sdk.model.vast.d> paramList, String paramString) throws i {
    IAlog.a("%sprocess started", new Object[] { "VastProcessor: " });
    if (paramd != null && paramd.c != null) {
      int i = l.e();
      int j = l.d();
      b b = new b(new h(this.c, i, j), new f(i, j));
      b.a = paramString;
      List list = ((e)paramd.c).c;
      if (list != null && !list.isEmpty()) {
        if (paramList != null) {
          Iterator<com.fyber.inneractive.sdk.model.vast.d> iterator = paramList.iterator();
          while (iterator.hasNext()) {
            u u = ((com.fyber.inneractive.sdk.model.vast.d)iterator.next()).b;
            if (u != null)
              a(b, (e)u, true); 
          } 
        } 
        a(b, (e)paramd.c, false);
        if (b.d.size() == 0) {
          if (this.f.size() == 0)
            throw new i("ErrorNoMediaFiles", "No media files exist after merge"); 
          throw new i("ErrorNoCompatibleMediaFile", "No compatible media files after filtering");
        } 
        if (IAlog.a == 2) {
          IAlog.d("%sLogging merged model media files: ", new Object[] { "VastProcessor: " });
          Iterator<?> iterator = (new ArrayList(b.d)).iterator();
          for (i = 0; iterator.hasNext(); i++) {
            IAlog.d("%s(%d) %s", new Object[] { "VastProcessor: ", Integer.valueOf(i), iterator.next() });
          } 
        } 
        if (IAlog.a == 2) {
          IAlog.d("%sLogging merged model companion ads: ", new Object[] { "VastProcessor: " });
          ArrayList arrayList = new ArrayList(b.g);
          if (arrayList.size() > 0) {
            Iterator<c> iterator = arrayList.iterator();
            for (i = 0; iterator.hasNext(); i++) {
              IAlog.d("%s(%d) %s", new Object[] { "VastProcessor: ", Integer.valueOf(i), ((c)iterator.next()).a() });
            } 
          } else {
            IAlog.d("%sNo companion ads found!", new Object[] { "VastProcessor: " });
          } 
        } 
        return b;
      } 
      throw new i("ErrorNoMediaFiles", "Empty inline with no creatives");
    } 
    IAlog.a("%sno inline found", new Object[] { "VastProcessor: " });
    throw new i("ErrorNoMediaFiles", "Empty inline ad found");
  }
  
  public final void a(b paramb, e parame, boolean paramBoolean) {
    // Byte code:
    //   0: ldc '%sprocessing ad element: %s'
    //   2: iconst_2
    //   3: anewarray java/lang/Object
    //   6: dup
    //   7: iconst_0
    //   8: ldc 'VastProcessor: '
    //   10: aastore
    //   11: dup
    //   12: iconst_1
    //   13: aload_2
    //   14: aastore
    //   15: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   18: aload_2
    //   19: getfield b : Ljava/util/List;
    //   22: astore #7
    //   24: aload #7
    //   26: ifnull -> 92
    //   29: aload #7
    //   31: invokeinterface iterator : ()Ljava/util/Iterator;
    //   36: astore #7
    //   38: aload #7
    //   40: invokeinterface hasNext : ()Z
    //   45: ifeq -> 92
    //   48: aload #7
    //   50: invokeinterface next : ()Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: astore #8
    //   60: ldc '%sadding impression url: %s'
    //   62: iconst_2
    //   63: anewarray java/lang/Object
    //   66: dup
    //   67: iconst_0
    //   68: ldc 'VastProcessor: '
    //   70: aastore
    //   71: dup
    //   72: iconst_1
    //   73: aload #8
    //   75: aastore
    //   76: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   79: aload_0
    //   80: aload_1
    //   81: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_IMPRESSION : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   84: aload #8
    //   86: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/model/vast/s;Ljava/lang/String;)V
    //   89: goto -> 38
    //   92: aload_2
    //   93: getfield a : Ljava/lang/String;
    //   96: astore #7
    //   98: aload #7
    //   100: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   103: ifne -> 134
    //   106: ldc '%sadding error url: %s'
    //   108: iconst_2
    //   109: anewarray java/lang/Object
    //   112: dup
    //   113: iconst_0
    //   114: ldc 'VastProcessor: '
    //   116: aastore
    //   117: dup
    //   118: iconst_1
    //   119: aload #7
    //   121: aastore
    //   122: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   125: aload_1
    //   126: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_ERROR : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   129: aload #7
    //   131: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/s;Ljava/lang/String;)V
    //   134: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   137: getfield J : Lcom/fyber/inneractive/sdk/measurement/a;
    //   140: ifnull -> 316
    //   143: aload_2
    //   144: getfield d : Ljava/util/List;
    //   147: invokeinterface iterator : ()Ljava/util/Iterator;
    //   152: astore #7
    //   154: aload #7
    //   156: invokeinterface hasNext : ()Z
    //   161: ifeq -> 316
    //   164: aload #7
    //   166: invokeinterface next : ()Ljava/lang/Object;
    //   171: checkcast com/fyber/inneractive/sdk/measurement/f
    //   174: astore #8
    //   176: aload #8
    //   178: invokevirtual b : ()Z
    //   181: ifeq -> 199
    //   184: aload_1
    //   185: getfield e : Ljava/util/List;
    //   188: aload #8
    //   190: invokeinterface add : (Ljava/lang/Object;)Z
    //   195: pop
    //   196: goto -> 154
    //   199: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_VERIFICATION_NOT_EXECUTED : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   202: astore #9
    //   204: aload #9
    //   206: ifnull -> 258
    //   209: aload #8
    //   211: getfield c : Ljava/util/Map;
    //   214: astore #10
    //   216: aload #10
    //   218: ifnonnull -> 224
    //   221: goto -> 258
    //   224: aload #10
    //   226: aload #9
    //   228: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   233: checkcast java/util/List
    //   236: astore #10
    //   238: aload #10
    //   240: ifnonnull -> 246
    //   243: goto -> 258
    //   246: aload #10
    //   248: invokeinterface size : ()I
    //   253: istore #4
    //   255: goto -> 261
    //   258: iconst_0
    //   259: istore #4
    //   261: iload #4
    //   263: ifle -> 301
    //   266: getstatic com/fyber/inneractive/sdk/measurement/g.VERIFICATION_NOT_SUPPORTED : Lcom/fyber/inneractive/sdk/measurement/g;
    //   269: astore #10
    //   271: new com/fyber/inneractive/sdk/measurement/e
    //   274: dup
    //   275: aload #8
    //   277: aload #8
    //   279: aload #9
    //   281: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/s;)Ljava/util/List;
    //   284: aload #10
    //   286: invokespecial <init> : (Lcom/fyber/inneractive/sdk/measurement/f;Ljava/util/List;Lcom/fyber/inneractive/sdk/measurement/g;)V
    //   289: iconst_1
    //   290: anewarray com/fyber/inneractive/sdk/model/vast/s
    //   293: dup
    //   294: iconst_0
    //   295: aload #9
    //   297: aastore
    //   298: invokestatic a : (Lcom/fyber/inneractive/sdk/response/i;[Lcom/fyber/inneractive/sdk/model/vast/s;)V
    //   301: aload_0
    //   302: getfield i : Ljava/util/List;
    //   305: aload #8
    //   307: invokeinterface add : (Ljava/lang/Object;)Z
    //   312: pop
    //   313: goto -> 154
    //   316: aload_2
    //   317: getfield e : Lcom/fyber/inneractive/sdk/model/vast/k;
    //   320: astore #7
    //   322: aload #7
    //   324: ifnull -> 333
    //   327: aload_1
    //   328: aload #7
    //   330: putfield f : Lcom/fyber/inneractive/sdk/model/vast/k;
    //   333: aload_2
    //   334: getfield c : Ljava/util/List;
    //   337: invokeinterface iterator : ()Ljava/util/Iterator;
    //   342: astore #7
    //   344: aload #7
    //   346: invokeinterface hasNext : ()Z
    //   351: ifeq -> 1251
    //   354: aload #7
    //   356: invokeinterface next : ()Ljava/lang/Object;
    //   361: checkcast com/fyber/inneractive/sdk/model/vast/j
    //   364: astore #8
    //   366: aload #8
    //   368: getfield a : Lcom/fyber/inneractive/sdk/model/vast/m;
    //   371: astore #9
    //   373: aload #9
    //   375: ifnull -> 1156
    //   378: aload #9
    //   380: getfield a : Ljava/util/List;
    //   383: astore_2
    //   384: aload_2
    //   385: ifnull -> 917
    //   388: aload_1
    //   389: aload_2
    //   390: invokeinterface size : ()I
    //   395: putfield j : I
    //   398: aload_2
    //   399: invokeinterface iterator : ()Ljava/util/Iterator;
    //   404: astore #10
    //   406: aload #10
    //   408: invokeinterface hasNext : ()Z
    //   413: ifeq -> 917
    //   416: aload #10
    //   418: invokeinterface next : ()Ljava/lang/Object;
    //   423: checkcast com/fyber/inneractive/sdk/model/vast/n
    //   426: astore #11
    //   428: aload #11
    //   430: getfield a : Ljava/lang/String;
    //   433: astore_2
    //   434: getstatic com/fyber/inneractive/sdk/model/vast/o.progressive : Lcom/fyber/inneractive/sdk/model/vast/o;
    //   437: astore #12
    //   439: aload_2
    //   440: aload #12
    //   442: getfield mValue : Ljava/lang/String;
    //   445: invokevirtual equals : (Ljava/lang/Object;)Z
    //   448: istore #6
    //   450: aconst_null
    //   451: astore_2
    //   452: iload #6
    //   454: ifne -> 476
    //   457: new com/fyber/inneractive/sdk/flow/vast/g
    //   460: dup
    //   461: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSUPPORTED_DELIVERY : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   464: aload #12
    //   466: getfield mValue : Ljava/lang/String;
    //   469: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   472: astore_2
    //   473: goto -> 783
    //   476: aload_0
    //   477: getfield b : I
    //   480: iconst_m1
    //   481: if_icmple -> 490
    //   484: iconst_1
    //   485: istore #4
    //   487: goto -> 493
    //   490: iconst_0
    //   491: istore #4
    //   493: iload #4
    //   495: ifeq -> 602
    //   498: aload #11
    //   500: getfield e : Ljava/lang/Integer;
    //   503: astore #12
    //   505: aload #12
    //   507: ifnull -> 602
    //   510: aload #12
    //   512: invokevirtual intValue : ()I
    //   515: ifeq -> 602
    //   518: aload #11
    //   520: getfield e : Ljava/lang/Integer;
    //   523: invokevirtual intValue : ()I
    //   526: istore #4
    //   528: aload_0
    //   529: getfield a : I
    //   532: istore #5
    //   534: iload #4
    //   536: iload #5
    //   538: if_icmpge -> 560
    //   541: new com/fyber/inneractive/sdk/flow/vast/g
    //   544: dup
    //   545: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.BITRATE_NOT_IN_RANGE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   548: iload #5
    //   550: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   553: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   556: astore_2
    //   557: goto -> 783
    //   560: aload #11
    //   562: getfield e : Ljava/lang/Integer;
    //   565: invokevirtual intValue : ()I
    //   568: istore #4
    //   570: aload_0
    //   571: getfield b : I
    //   574: istore #5
    //   576: iload #4
    //   578: iload #5
    //   580: if_icmple -> 602
    //   583: new com/fyber/inneractive/sdk/flow/vast/g
    //   586: dup
    //   587: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.BITRATE_NOT_IN_RANGE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   590: iload #5
    //   592: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   595: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   598: astore_2
    //   599: goto -> 783
    //   602: aload #11
    //   604: getfield d : Ljava/lang/String;
    //   607: invokestatic a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/model/vast/p;
    //   610: getstatic com/fyber/inneractive/sdk/model/vast/p.UNKNOWN : Lcom/fyber/inneractive/sdk/model/vast/p;
    //   613: if_acmpeq -> 622
    //   616: iconst_1
    //   617: istore #4
    //   619: goto -> 625
    //   622: iconst_0
    //   623: istore #4
    //   625: iload #4
    //   627: ifne -> 645
    //   630: new com/fyber/inneractive/sdk/flow/vast/g
    //   633: dup
    //   634: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSUPPORTED_MIME_TYPE : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   637: aconst_null
    //   638: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   641: astore_2
    //   642: goto -> 783
    //   645: aload_0
    //   646: getfield d : Z
    //   649: ifeq -> 686
    //   652: aload #11
    //   654: getfield b : Ljava/lang/Integer;
    //   657: invokevirtual intValue : ()I
    //   660: aload #11
    //   662: getfield c : Ljava/lang/Integer;
    //   665: invokevirtual intValue : ()I
    //   668: if_icmplt -> 686
    //   671: new com/fyber/inneractive/sdk/flow/vast/g
    //   674: dup
    //   675: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.VERTICAL_VIDEO_EXPECTED : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   678: aconst_null
    //   679: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   682: astore_2
    //   683: goto -> 642
    //   686: aload #11
    //   688: getfield f : Ljava/lang/String;
    //   691: astore #12
    //   693: aload #12
    //   695: ifnull -> 731
    //   698: aload_0
    //   699: getfield e : Z
    //   702: ifeq -> 731
    //   705: aload #12
    //   707: ldc_w 'VPAID'
    //   710: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   713: ifeq -> 731
    //   716: new com/fyber/inneractive/sdk/flow/vast/g
    //   719: dup
    //   720: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.FILTERED_BY_APP_OR_UNIT : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   723: aconst_null
    //   724: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   727: astore_2
    //   728: goto -> 642
    //   731: aload #11
    //   733: getfield g : Ljava/lang/String;
    //   736: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   739: ifeq -> 757
    //   742: new com/fyber/inneractive/sdk/flow/vast/g
    //   745: dup
    //   746: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.NO_CONTENT : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   749: aconst_null
    //   750: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   753: astore_2
    //   754: goto -> 642
    //   757: aload #11
    //   759: getfield g : Ljava/lang/String;
    //   762: invokestatic f : (Ljava/lang/String;)Z
    //   765: ifne -> 783
    //   768: new com/fyber/inneractive/sdk/flow/vast/g
    //   771: dup
    //   772: getstatic com/fyber/inneractive/sdk/flow/vast/g$a.UNSECURED_VIDEO_URL : Lcom/fyber/inneractive/sdk/flow/vast/g$a;
    //   775: aconst_null
    //   776: invokespecial <init> : (Lcom/fyber/inneractive/sdk/flow/vast/g$a;Ljava/lang/Object;)V
    //   779: astore_2
    //   780: goto -> 642
    //   783: aload_2
    //   784: ifnull -> 862
    //   787: ldc_w '%smedia file filtered!: %s'
    //   790: iconst_2
    //   791: anewarray java/lang/Object
    //   794: dup
    //   795: iconst_0
    //   796: ldc 'VastProcessor: '
    //   798: aastore
    //   799: dup
    //   800: iconst_1
    //   801: aload #11
    //   803: aastore
    //   804: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   807: ldc_w '%s-- %s'
    //   810: iconst_2
    //   811: anewarray java/lang/Object
    //   814: dup
    //   815: iconst_0
    //   816: ldc 'VastProcessor: '
    //   818: aastore
    //   819: dup
    //   820: iconst_1
    //   821: aload #11
    //   823: aastore
    //   824: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   827: ldc_w '%s-- %s'
    //   830: iconst_2
    //   831: anewarray java/lang/Object
    //   834: dup
    //   835: iconst_0
    //   836: ldc 'VastProcessor: '
    //   838: aastore
    //   839: dup
    //   840: iconst_1
    //   841: aload_2
    //   842: aastore
    //   843: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   846: aload_0
    //   847: getfield f : Ljava/util/Map;
    //   850: aload #11
    //   852: aload_2
    //   853: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   858: pop
    //   859: goto -> 406
    //   862: ldc_w '%sadding media file: %s'
    //   865: iconst_2
    //   866: anewarray java/lang/Object
    //   869: dup
    //   870: iconst_0
    //   871: ldc 'VastProcessor: '
    //   873: aastore
    //   874: dup
    //   875: iconst_1
    //   876: aload #11
    //   878: aastore
    //   879: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   882: aload_1
    //   883: getfield d : Ljava/util/PriorityQueue;
    //   886: aload #11
    //   888: invokevirtual add : (Ljava/lang/Object;)Z
    //   891: pop
    //   892: aload_1
    //   893: getfield k : Ljava/util/List;
    //   896: aload #11
    //   898: invokeinterface add : (Ljava/lang/Object;)Z
    //   903: pop
    //   904: aload_1
    //   905: aload_1
    //   906: getfield i : I
    //   909: iconst_1
    //   910: iadd
    //   911: putfield i : I
    //   914: goto -> 406
    //   917: aload #9
    //   919: getfield d : Ljava/util/List;
    //   922: astore_2
    //   923: aload_2
    //   924: ifnull -> 967
    //   927: aload_2
    //   928: invokeinterface iterator : ()Ljava/util/Iterator;
    //   933: astore_2
    //   934: aload_2
    //   935: invokeinterface hasNext : ()Z
    //   940: ifeq -> 967
    //   943: aload_2
    //   944: invokeinterface next : ()Ljava/lang/Object;
    //   949: checkcast java/lang/String
    //   952: astore #10
    //   954: aload_0
    //   955: aload_1
    //   956: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_CLICK : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   959: aload #10
    //   961: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/model/vast/s;Ljava/lang/String;)V
    //   964: goto -> 934
    //   967: aload #9
    //   969: getfield b : Ljava/util/List;
    //   972: astore_2
    //   973: aload_2
    //   974: ifnull -> 1036
    //   977: aload_2
    //   978: invokeinterface iterator : ()Ljava/util/Iterator;
    //   983: astore_2
    //   984: aload_2
    //   985: invokeinterface hasNext : ()Z
    //   990: ifeq -> 1036
    //   993: aload_2
    //   994: invokeinterface next : ()Ljava/lang/Object;
    //   999: checkcast com/fyber/inneractive/sdk/model/vast/r
    //   1002: astore #10
    //   1004: aload #10
    //   1006: getfield a : Ljava/lang/String;
    //   1009: invokestatic a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/model/vast/s;
    //   1012: astore #11
    //   1014: aload #11
    //   1016: getstatic com/fyber/inneractive/sdk/model/vast/s.UNKNOWN : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   1019: if_acmpeq -> 984
    //   1022: aload_1
    //   1023: aload #11
    //   1025: aload #10
    //   1027: getfield b : Ljava/lang/String;
    //   1030: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/s;Ljava/lang/String;)V
    //   1033: goto -> 984
    //   1036: aload #9
    //   1038: getfield c : Ljava/lang/String;
    //   1041: astore_2
    //   1042: aload_2
    //   1043: ifnull -> 1051
    //   1046: aload_1
    //   1047: aload_2
    //   1048: putfield b : Ljava/lang/String;
    //   1051: aload #9
    //   1053: getfield e : Ljava/lang/String;
    //   1056: astore_2
    //   1057: aload_2
    //   1058: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1061: ifeq -> 1067
    //   1064: goto -> 1156
    //   1067: aload_2
    //   1068: ldc_w ':'
    //   1071: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1074: astore #9
    //   1076: aload #9
    //   1078: ifnull -> 1156
    //   1081: aload #9
    //   1083: arraylength
    //   1084: iconst_3
    //   1085: if_icmple -> 1091
    //   1088: goto -> 1156
    //   1091: aload #9
    //   1093: arraylength
    //   1094: iconst_1
    //   1095: if_icmpne -> 1106
    //   1098: aload_2
    //   1099: invokestatic parseInt : (Ljava/lang/String;)I
    //   1102: pop
    //   1103: goto -> 1156
    //   1106: aload #9
    //   1108: arraylength
    //   1109: iconst_2
    //   1110: if_icmpne -> 1132
    //   1113: aload #9
    //   1115: iconst_1
    //   1116: aaload
    //   1117: invokestatic parseInt : (Ljava/lang/String;)I
    //   1120: pop
    //   1121: aload #9
    //   1123: iconst_0
    //   1124: aaload
    //   1125: invokestatic parseInt : (Ljava/lang/String;)I
    //   1128: pop
    //   1129: goto -> 1156
    //   1132: aload #9
    //   1134: iconst_2
    //   1135: aaload
    //   1136: invokestatic parseInt : (Ljava/lang/String;)I
    //   1139: pop
    //   1140: aload #9
    //   1142: iconst_1
    //   1143: aaload
    //   1144: invokestatic parseInt : (Ljava/lang/String;)I
    //   1147: pop
    //   1148: aload #9
    //   1150: iconst_0
    //   1151: aaload
    //   1152: invokestatic parseInt : (Ljava/lang/String;)I
    //   1155: pop
    //   1156: aload #8
    //   1158: getfield b : Ljava/util/List;
    //   1161: astore_2
    //   1162: aload_2
    //   1163: ifnull -> 344
    //   1166: aload_2
    //   1167: invokeinterface iterator : ()Ljava/util/Iterator;
    //   1172: astore_2
    //   1173: aload_2
    //   1174: invokeinterface hasNext : ()Z
    //   1179: ifeq -> 344
    //   1182: aload_2
    //   1183: invokeinterface next : ()Ljava/lang/Object;
    //   1188: checkcast com/fyber/inneractive/sdk/model/vast/f
    //   1191: astore #8
    //   1193: aload_0
    //   1194: aload_1
    //   1195: aload #8
    //   1197: iload_3
    //   1198: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/b;Lcom/fyber/inneractive/sdk/model/vast/f;Z)V
    //   1201: goto -> 1173
    //   1204: astore #9
    //   1206: ldc_w 'Failed processing companion ad: %s error = %s'
    //   1209: iconst_2
    //   1210: anewarray java/lang/Object
    //   1213: dup
    //   1214: iconst_0
    //   1215: aload #8
    //   1217: aastore
    //   1218: dup
    //   1219: iconst_1
    //   1220: aload #9
    //   1222: invokevirtual getMessage : ()Ljava/lang/String;
    //   1225: aastore
    //   1226: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1229: aload #8
    //   1231: aload #9
    //   1233: putfield i : Lcom/fyber/inneractive/sdk/flow/vast/d$a;
    //   1236: aload_0
    //   1237: getfield g : Ljava/util/List;
    //   1240: aload #8
    //   1242: invokeinterface add : (Ljava/lang/Object;)Z
    //   1247: pop
    //   1248: goto -> 1173
    //   1251: return
    //   1252: astore_2
    //   1253: goto -> 1156
    // Exception table:
    //   from	to	target	type
    //   1098	1103	1252	java/lang/NumberFormatException
    //   1113	1129	1252	java/lang/NumberFormatException
    //   1132	1156	1252	java/lang/NumberFormatException
    //   1193	1201	1204	com/fyber/inneractive/sdk/flow/vast/d$a
  }
  
  public void a(b paramb, f paramf, boolean paramBoolean) throws a {
    List<String> list = paramf.h;
    if (list != null) {
      if (paramBoolean)
        this.h.add(paramf); 
      Iterator<String> iterator = list.iterator();
      while (iterator.hasNext()) {
        if (x.f(iterator.next()))
          continue; 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Found non secure click tracking url for companion: ");
        stringBuilder1.append(paramf);
        throw new a(this, stringBuilder1.toString(), 0);
      } 
    } 
    String str = paramf.g;
    if (x.f(str)) {
      boolean bool1;
      Integer integer1 = paramf.a;
      Integer integer2 = paramf.b;
      boolean bool2 = true;
      if (integer1 != null && integer2 != null && integer1.intValue() >= 100 && integer2.intValue() >= 100) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        StringBuilder stringBuilder2;
        String str1 = paramf.c;
        List<r> list1 = paramf.j;
        if (list1 != null)
          for (r r : list1) {
            if (x.f(r.b))
              continue; 
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Found non secure tracking event: ");
            stringBuilder2.append(r);
            throw new a(this, stringBuilder2.toString(), 0);
          }  
        bool1 = bool2;
        if (TextUtils.isEmpty(paramf.e)) {
          bool1 = bool2;
          if (TextUtils.isEmpty(paramf.f))
            if (paramf.d != null) {
              bool1 = bool2;
            } else {
              bool1 = false;
            }  
        } 
        if (bool1) {
          String str2 = paramf.e;
          if (x.f(str2)) {
            i i = paramf.d;
            if (i != null) {
              h h = h.a(i.a);
              if (h != null) {
                a((b)stringBuilder2, g.Static, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, i.b, h);
              } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Found invalid creative type:");
                stringBuilder2.append(i.a);
                throw new a(this, stringBuilder2.toString(), 0);
              } 
            } 
            if (!TextUtils.isEmpty(str2))
              a((b)stringBuilder2, g.Iframe, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, str2, null); 
            String str3 = paramf.f;
            if (!TextUtils.isEmpty(str3))
              a((b)stringBuilder2, g.Html, paramBoolean, integer1.intValue(), integer2.intValue(), str1, str, list, list1, str3, null); 
            return;
          } 
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Found non secure iframe url:");
          stringBuilder2.append(str2);
          throw new a(this, stringBuilder2.toString(), 0);
        } 
        throw new a(this, "None sources of companion avaliable", 0);
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Incompatible size: ");
      stringBuilder1.append(integer1);
      stringBuilder1.append(",");
      stringBuilder1.append(integer2);
      throw new a(this, stringBuilder1.toString(), 16);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Found non secure click through url: ");
    stringBuilder.append(str);
    throw new a(this, stringBuilder.toString(), 0);
  }
  
  public void a(b paramb, g paramg, boolean paramBoolean, int paramInt1, int paramInt2, String paramString1, String paramString2, List<String> paramList, List<r> paramList1, String paramString3, h paramh) {
    c c = new c(paramg, paramInt1, paramInt2, paramString1);
    c.g = paramString2;
    if (paramList1 != null)
      for (r r : paramList1)
        c.a(s.a(r.a), r.b);  
    if (paramList != null)
      for (String paramString2 : paramList)
        c.a(s.EVENT_CLICK, paramString2);  
    a(c, paramBoolean);
    c.f = paramString3;
    c.b = paramh;
    paramb.g.add(c);
    paramb.l.add(c);
  }
  
  public final void a(i parami, s params, String paramString) throws i {
    if (x.f(paramString)) {
      ((b)parami).a(params, paramString);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("found unsecure tracking event: ");
    stringBuilder.append(params.e());
    throw new i("VastErrorUnsecure", stringBuilder.toString());
  }
  
  public boolean a(c paramc, boolean paramBoolean) {
    boolean bool2 = this.h.isEmpty();
    boolean bool1 = false;
    boolean bool = false;
    if (!bool2) {
      f f;
      List<f> list = null;
      if (paramBoolean) {
        list = this.h;
        f = list.remove(list.size() - 1);
      } 
      String str = paramc.e;
      Iterator<f> iterator = this.h.iterator();
      paramBoolean = bool;
      while (iterator.hasNext()) {
        f f1 = iterator.next();
        str1 = f1.c;
        if ((str != null && str.equals(str1)) || (str1 == null && paramc.c == f1.a.intValue() && paramc.d == f1.b.intValue())) {
          List list1 = f1.h;
          if (list1 != null)
            for (String str1 : list1) {
              if (x.f(str1))
                paramc.a(s.EVENT_CLICK, str1); 
            }  
          paramBoolean = true;
        } 
      } 
      bool1 = paramBoolean;
      if (f != null) {
        this.h.add(f);
        bool1 = paramBoolean;
      } 
    } 
    return bool1;
  }
  
  public class a extends Exception {
    public int a;
    
    public a(d this$0, String param1String, int param1Int) {
      super(param1String);
      this.a = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */