package com.fyber.inneractive.sdk.flow.vast;

import android.view.View;
import java.util.Comparator;

public class a {
  public boolean a = false;
  
  public View b = null;
  
  public boolean c = false;
  
  public int d;
  
  public String e;
  
  public a f = a.HIGH;
  
  public void a() {
    this.b = null;
    this.a = false;
  }
  
  public void a(View paramView) {
    this.b = paramView;
  }
  
  public enum a {
    HIGH, LOW;
    
    static {
      a a1 = new a("HIGH", 0);
      HIGH = a1;
      a a2 = new a("LOW", 1);
      LOW = a2;
      $VALUES = new a[] { a1, a2 };
    }
  }
  
  public static class b implements Comparator<a> {
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      return ((a)param1Object1).f.ordinal() - ((a)param1Object2).f.ordinal();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */