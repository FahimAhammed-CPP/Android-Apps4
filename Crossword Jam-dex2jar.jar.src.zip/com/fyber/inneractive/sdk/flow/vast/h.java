package com.fyber.inneractive.sdk.flow.vast;

import android.text.TextUtils;
import com.fyber.inneractive.sdk.model.vast.n;
import com.fyber.inneractive.sdk.model.vast.p;
import java.util.Comparator;

public class h implements Comparator<n> {
  public int a;
  
  public int b;
  
  public int c;
  
  public h(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  public final Integer a(String paramString) {
    p p = p.a(paramString);
    return (p == p.MEDIA_TYPE_MP4) ? Integer.valueOf(3) : ((p == p.MEDIA_TYPE_3GPP) ? Integer.valueOf(2) : ((p == p.MEDIA_TYPE_WEBM) ? Integer.valueOf(1) : Integer.valueOf(-1)));
  }
  
  public int compare(Object paramObject1, Object paramObject2) {
    int m;
    n n1 = (n)paramObject1;
    paramObject1 = paramObject2;
    boolean bool1 = TextUtils.equals("VPAID", ((n)paramObject1).f);
    boolean bool = false;
    if (bool1)
      return -1; 
    if (TextUtils.equals("VPAID", n1.f))
      return 1; 
    paramObject2 = n1.e;
    if (paramObject2 == null) {
      i = 0;
    } else {
      i = paramObject2.intValue();
    } 
    paramObject2 = ((n)paramObject1).e;
    if (paramObject2 == null) {
      j = 0;
    } else {
      j = paramObject2.intValue();
    } 
    int k = this.a;
    if (j > k && i <= k)
      return -1; 
    if (i > k && j <= k)
      return 1; 
    k = a(((n)paramObject1).d).compareTo(a(n1.d));
    if (k != 0)
      return k; 
    if (i < j)
      return 1; 
    if (i > j)
      return -1; 
    paramObject2 = n1.b;
    if (paramObject2 == null) {
      i = 0;
    } else {
      i = paramObject2.intValue();
    } 
    paramObject2 = n1.c;
    if (paramObject2 == null) {
      j = 0;
    } else {
      j = paramObject2.intValue();
    } 
    paramObject2 = ((n)paramObject1).b;
    if (paramObject2 == null) {
      k = 0;
    } else {
      k = paramObject2.intValue();
    } 
    paramObject1 = ((n)paramObject1).c;
    if (paramObject1 == null) {
      m = 0;
    } else {
      m = paramObject1.intValue();
    } 
    int n = this.b * this.c;
    int j = Math.abs(i * j - n);
    k = Math.abs(k * m - n);
    if (j < k)
      return -1; 
    int i = bool;
    return (j > k) ? 1 : i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */