package com.fyber.inneractive.sdk.flow.vast;

public class g {
  public a a;
  
  public Object b;
  
  public g(a parama, Object paramObject) {
    this.a = parama;
    this.b = paramObject;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Media File inc error::  type = ");
    stringBuilder.append(this.a);
    stringBuilder.append(" expected value = ");
    stringBuilder.append(this.b);
    return stringBuilder.toString();
  }
  
  public enum a {
    BITRATE_NOT_IN_RANGE, FILTERED_BY_APP_OR_UNIT, NO_CONTENT, UNSECURED_VIDEO_URL, UNSUPPORTED_DELIVERY, UNSUPPORTED_MIME_TYPE, VERTICAL_VIDEO_EXPECTED;
    
    public int value;
    
    static {
      a a1 = new a("BITRATE_NOT_IN_RANGE", 0, 1);
      BITRATE_NOT_IN_RANGE = a1;
      a a2 = new a("UNSUPPORTED_MIME_TYPE", 1, 2);
      UNSUPPORTED_MIME_TYPE = a2;
      a a3 = new a("UNSUPPORTED_DELIVERY", 2, 3);
      UNSUPPORTED_DELIVERY = a3;
      a a4 = new a("UNSECURED_VIDEO_URL", 3, 4);
      UNSECURED_VIDEO_URL = a4;
      a a5 = new a("VERTICAL_VIDEO_EXPECTED", 4, 5);
      VERTICAL_VIDEO_EXPECTED = a5;
      a a6 = new a("FILTERED_BY_APP_OR_UNIT", 5, 6);
      FILTERED_BY_APP_OR_UNIT = a6;
      a a7 = new a("NO_CONTENT", 6, 7);
      NO_CONTENT = a7;
      $VALUES = new a[] { a1, a2, a3, a4, a5, a6, a7 };
    }
    
    a(int param1Int1) {
      this.value = param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */