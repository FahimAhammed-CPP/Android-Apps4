package com.fyber.inneractive.sdk.flow.vast;

import com.fyber.inneractive.sdk.config.b0;
import com.fyber.inneractive.sdk.config.enums.UnitDisplayType;

public class b {
  public final UnitDisplayType a;
  
  public final boolean b;
  
  public final int c;
  
  public final int d;
  
  public final b0 e;
  
  public b(UnitDisplayType paramUnitDisplayType, boolean paramBoolean, int paramInt1, int paramInt2, b0 paramb0) {
    this.a = paramUnitDisplayType;
    this.b = paramBoolean;
    this.c = paramInt1;
    this.d = paramInt2;
    this.e = paramb0;
  }
  
  public int a() {
    return this.d;
  }
  
  public b0 b() {
    return this.e;
  }
  
  public UnitDisplayType c() {
    return this.a;
  }
  
  public int d() {
    return this.c;
  }
  
  public boolean e() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */