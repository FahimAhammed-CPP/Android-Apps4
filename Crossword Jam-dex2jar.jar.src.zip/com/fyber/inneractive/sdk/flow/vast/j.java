package com.fyber.inneractive.sdk.flow.vast;

import com.fyber.inneractive.sdk.measurement.f;
import com.fyber.inneractive.sdk.response.g;
import java.util.ArrayList;

public class j extends ArrayList<f> {
  public j(k paramk, g paramg) {
    addAll(paramg.e().c());
    addAll(paramg.d());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */