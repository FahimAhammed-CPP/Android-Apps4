package com.fyber.inneractive.sdk.flow.vast;

import com.fyber.inneractive.sdk.player.controller.c;
import com.fyber.inneractive.sdk.web.c0;

public class e extends a {
  public final c g;
  
  public e(c paramc) {
    this.g = paramc;
    a(paramc.a());
  }
  
  public void a() {
    this.b = null;
    this.a = false;
    c c1 = this.g;
    c0 c0 = c1.a;
    if (c0 != null) {
      c0.c();
      c1.a = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\flow\vast\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */