package com.fyber.inneractive.sdk.web;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceAPI;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceCallback;
import com.fyber.inneractive.sdk.activities.InternalStoreWebpageActivity;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.global.features.p;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.flow.n;
import com.fyber.inneractive.sdk.flow.o;
import com.fyber.inneractive.sdk.ignite.i;
import com.fyber.inneractive.sdk.ignite.j;
import com.fyber.inneractive.sdk.ignite.k;
import com.fyber.inneractive.sdk.ignite.n;
import com.fyber.inneractive.sdk.network.o;
import com.fyber.inneractive.sdk.network.p;
import com.fyber.inneractive.sdk.network.r;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.a0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.m;
import com.fyber.inneractive.sdk.util.q;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.FyberNetworkBridge;
import com.safedk.android.utils.Logger;
import java.lang.ref.WeakReference;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class t implements n {
  public boolean A = false;
  
  public boolean B;
  
  public boolean C = false;
  
  public boolean D = false;
  
  public final WebViewClient E = new a(this);
  
  public final WebView a;
  
  public final com.fyber.inneractive.sdk.ignite.c b;
  
  public final String c;
  
  public k d;
  
  public final String e;
  
  public final String f;
  
  public final String g;
  
  public final j h;
  
  public g i;
  
  public String j = "invalid_task_id";
  
  public String k;
  
  public boolean l = false;
  
  public s m;
  
  public long n = 10L;
  
  public long o;
  
  public Runnable p;
  
  public WeakReference<InternalStoreWebpageActivity> q;
  
  public boolean r = false;
  
  public boolean s = false;
  
  public final AtomicInteger t = new AtomicInteger(0);
  
  public final AtomicBoolean u = new AtomicBoolean(false);
  
  public final AtomicBoolean v = new AtomicBoolean(false);
  
  public boolean w = false;
  
  public boolean x = false;
  
  public boolean y = false;
  
  public boolean z = false;
  
  public t(v paramv) {
    this.c = paramv.a;
    this.d = paramv.b;
    this.e = paramv.c;
    this.m = paramv.d;
    this.f = paramv.e;
    this.g = paramv.f;
    this.h = paramv.g;
    com.fyber.inneractive.sdk.ignite.c c1 = IAConfigManager.d();
    this.b = c1;
    c1.a(this);
    this.a = new WebView((Context)l.a());
  }
  
  public void a() {
    this.y = true;
    this.D = false;
    this.b.i.remove(this);
    this.i = null;
    IAlog.a("destroy internalStoreWebpageController", new Object[0]);
  }
  
  public void a(String paramString) {
    this.z = true;
    if (this.j.equals(paramString)) {
      this.b.b();
      f("onInstallStart();");
    } 
  }
  
  public void a(String paramString, int paramInt, double paramDouble) {
    if (this.j.equals(paramString)) {
      if (paramInt != 0) {
        if (paramInt != 1)
          return; 
        f("onInstallationProgress();");
        return;
      } 
      f(String.format("onDownloadProgress(%f);", new Object[] { Double.valueOf(paramDouble) }));
    } 
  }
  
  public void a(String paramString, i parami) {
    com.fyber.inneractive.sdk.ignite.c c1 = this.b;
    if (!c1.j) {
      j j1 = this.h;
      if (j1 != null) {
        c1.j = true;
        o o = o.IGNITE_FLOW_FAILED_TO_START;
        String str = parami.e();
        ((n.a)j1).a(o, null, str, null);
      } 
    } 
  }
  
  public void a(String paramString1, String paramString2) {
    if (paramString1 != null && paramString2 != null && paramString2.equals(this.c))
      this.j = paramString1; 
  }
  
  public void a(String paramString1, String paramString2, String paramString3) {
    if (!this.v.get())
      return; 
    if (paramString2 != null && (paramString2.equals(i.NOT_CONNECTED.e()) || paramString2.equals(i.SESSION_EXPIRED.e()))) {
      if (this.t.getAndIncrement() < 2) {
        this.b.a(new d(this, paramString1));
        return;
      } 
      if (!this.b.e())
        a((String)null, i.FAILED_TO_BIND_SERVICE); 
    } 
  }
  
  public final void b() {
    this.b.b();
    f("onInstallationFailed();");
  }
  
  public void b(String paramString) {}
  
  public void b(String paramString1, String paramString2, String paramString3) {
    if (!this.D)
      return; 
    boolean bool = false;
    this.z = false;
    if (this.j.equals(paramString1)) {
      this.b.b();
      if (!this.v.get() && !TextUtils.isEmpty(paramString2) && !TextUtils.isEmpty(paramString2) && paramString2.equals("App already installed")) {
        f("onInstallationSuccess();");
        this.A = true;
        return;
      } 
    } 
    if ((paramString2 != null && (paramString2.equals(i.NOT_CONNECTED.e()) || paramString2.equals(i.SESSION_EXPIRED.e()))) || !this.b.d()) {
      if (this.t.getAndIncrement() < 2) {
        this.b.a(new c(this, paramString2, paramString3));
      } else {
        b();
        if (!this.b.e())
          a((String)null, i.FAILED_TO_BIND_SERVICE); 
        bool = true;
      } 
    } else {
      if (!TextUtils.equals(paramString2, i.DOWNLOAD_IS_CANCELLED.e()))
        b(); 
      bool = true;
    } 
    if (bool) {
      k k1 = this.d;
      if (k1 != null) {
        j j1 = this.h;
        o o = o.IGNITE_FLOW_FAILED_TO_INSTALL_APP;
        ((n.a)j1).a(o, paramString2, paramString3, k1);
      } 
    } 
  }
  
  public void c(String paramString) {
    this.z = false;
    this.A = true;
    if (this.j.equals(paramString)) {
      this.b.b();
      f("onInstallationSuccess();");
    } 
  }
  
  public void d(String paramString) {}
  
  public void e(String paramString) {
    if (paramString != null) {
      this.v.set(true);
      this.u.set(false);
      com.fyber.inneractive.sdk.ignite.c c1 = this.b;
      e e = new e(this);
      if (c1.d() && !c1.f()) {
        try {
          IIgniteServiceAPI iIgniteServiceAPI = c1.b;
          Bundle bundle = c1.g;
          c1.h.getClass();
          iIgniteServiceAPI.cancel(paramString, bundle, (IIgniteServiceCallback)new com.fyber.inneractive.sdk.ignite.b(e));
        } catch (Exception exception) {
          IAlog.a("Failed to cancel task", new Object[0]);
          e.a(false);
        } 
      } else {
        for (n n1 : c1.i) {
          if (n1 != null) {
            i i;
            if (c1.f()) {
              i = i.SESSION_EXPIRED;
            } else {
              i = i.NOT_CONNECTED;
            } 
            n1.a(null, i.e(), null);
          } 
        } 
      } 
      m.b.postDelayed(new f(this), 2500L);
      j j1 = this.h;
      if (j1 != null && !this.r) {
        k k1 = this.d;
        if (k1 != null) {
          this.r = true;
          p p = p.IGNITE_FLOW_CANCEL_INSTALL_CLICKED;
          ((n.a)j1).a(p, k1);
        } 
      } 
    } 
  }
  
  public void f(String paramString) {
    m.b.post(new b(this, paramString));
  }
  
  public void g(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      this.k = paramString;
      WebSettings webSettings = this.a.getSettings();
      webSettings.setJavaScriptEnabled(true);
      webSettings.setUseWideViewPort(true);
      this.a.setInitialScale(1);
      this.a.setBackgroundColor(-1);
      this.a.setWebViewClient(this.E);
      WebView webView = this.a;
      webView.setLongClickable(false);
      webView.setOnLongClickListener((View.OnLongClickListener)new a0());
      this.a.addJavascriptInterface(new h(this), "nativeInterface");
      FyberNetworkBridge.webviewLoadUrl(this.a, paramString);
      s s1 = this.m;
      if (s1 != null) {
        byte b1;
        TimeUnit timeUnit = TimeUnit.SECONDS;
        Integer integer = ((p)s1.a(p.class)).b("load_timeout");
        byte b3 = 10;
        if (integer != null) {
          b1 = integer.intValue();
        } else {
          b1 = 10;
        } 
        byte b2 = b3;
        if (b1 < 30)
          if (b1 <= 2) {
            b2 = b3;
          } else {
            b2 = b1;
          }  
        long l = timeUnit.toMillis(b2);
        this.n = l;
        IAlog.a("InternalStoreWebpageController: Starting load timeout with %d", new Object[] { Long.valueOf(l) });
      } 
      this.o = System.currentTimeMillis();
      u u = new u(this);
      this.p = (Runnable)u;
      m.b.postDelayed((Runnable)u, this.n);
    } 
  }
  
  public class a extends WebViewClient {
    public a(t this$0) {}
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.inneractive", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      CreativeInfoManager.onWebViewPageFinished("com.inneractive", param1WebView, param1String);
    }
    
    public boolean onRenderProcessGone(WebView param1WebView, RenderProcessGoneDetail param1RenderProcessGoneDetail) {
      Activity activity = (Activity)q.a(this.a.q);
      if (activity != null)
        activity.finish(); 
      m.b.postDelayed(new a(this), 1000L);
      return true;
    }
    
    public boolean safedk_t$a_shouldOverrideUrlLoading_a14487aa48c134a55915d4d6cd04a5cc(WebView param1WebView, String param1String) {
      Runnable runnable;
      if (param1String.endsWith("success")) {
        t t1 = this.a;
        runnable = t1.p;
        if (runnable != null) {
          m.b.removeCallbacks(runnable);
          t1.p = null;
        } 
        t1 = this.a;
        t1.getClass();
        IAlog.a("%sInternalStoreWebpageController: onWebviewLoaded - load took %d msec", new Object[] { IAlog.a(t1), Long.valueOf(System.currentTimeMillis() - this.a.o) });
        t.e(this.a, true);
        return true;
      } 
      if (runnable.startsWith("exit")) {
        Activity activity = (Activity)q.a(this.a.q);
        if (activity == null)
          return true; 
        try {
          String str1;
          Uri uri = Uri.parse((String)runnable);
          String str2 = uri.getQueryParameter("target");
          boolean bool = TextUtils.equals("mail", uri.getAuthority());
          if (bool) {
            str1 = "android.intent.action.SENDTO";
          } else {
            str1 = "android.intent.action.VIEW";
          } 
          Intent intent2 = new Intent(str1, Uri.parse(str2));
          Intent intent1 = intent2;
          return true;
        } finally {
          param1WebView = null;
          r.a((Throwable)param1WebView, null, null);
        } 
      } 
      return false;
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.inneractive", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.inneractive", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/web/t$a;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
      boolean bool = safedk_t$a_shouldOverrideUrlLoading_a14487aa48c134a55915d4d6cd04a5cc(param1WebView, param1String);
      CreativeInfoManager.onOverrideUrlLoading("com.inneractive", param1WebView, param1String, bool);
      return bool;
    }
    
    public class a implements Runnable {
      public a(t.a this$0) {}
      
      public void run() {
        t t = this.a.a;
        if (!t.y)
          t.g(t.k); 
      }
    }
  }
  
  public class a implements Runnable {
    public a(t this$0) {}
    
    public void run() {
      t t = this.a.a;
      if (!t.y)
        t.g(t.k); 
    }
  }
  
  public class b implements Runnable {
    public b(t this$0, String param1String) {}
    
    public void run() {
      IAlog.a("injecting JS: %s", new Object[] { this.a });
      try {
        if (this.a != null) {
          WebView webView = this.b.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("javascript:");
          stringBuilder.append(this.a);
          FyberNetworkBridge.webviewLoadUrl(webView, stringBuilder.toString());
          return;
        } 
      } catch (Exception exception) {
        IAlog.a("Failed to inject JS", new Object[0]);
      } 
    }
  }
  
  public class c implements com.fyber.inneractive.sdk.ignite.h {
    public c(t this$0, String param1String1, String param1String2) {}
    
    public void a() {
      this.c.b();
      t t1 = this.c;
      j j = t1.h;
      o o = o.IGNITE_FLOW_FAILED_TO_INSTALL_APP;
      String str1 = this.a;
      String str2 = this.b;
      k k = t1.d;
      ((n.a)j).a(o, str1, str2, k);
    }
    
    public void b() {
      t t1 = this.c;
      t1.b.a(t1.c, new com.fyber.inneractive.sdk.ignite.c.d(t1.f, t1.d, ((n.a)t1.h).a));
      this.c.f("onShowInstallStarted();");
    }
  }
  
  public class d implements com.fyber.inneractive.sdk.ignite.h {
    public d(t this$0, String param1String) {}
    
    public void a() {}
    
    public void b() {
      this.b.e(this.a);
    }
  }
  
  public class e implements com.fyber.inneractive.sdk.ignite.g.b {
    public e(t this$0) {}
    
    public void a(boolean param1Boolean) {
      if (this.a.u.compareAndSet(false, true)) {
        t t1 = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCancelResult(");
        stringBuilder.append(param1Boolean);
        stringBuilder.append(");");
        t1.f(stringBuilder.toString());
        this.a.v.set(false);
      } 
    }
  }
  
  public class f implements Runnable {
    public f(t this$0) {}
    
    public void run() {
      if (this.a.u.compareAndSet(false, true)) {
        this.a.f("onCancelResult(true);");
        this.a.v.set(false);
      } 
    }
  }
  
  public static interface g {}
  
  public class h {
    public h(t this$0) {}
    
    public static void safedk_Application_startActivity_1baa8fbf075affc453c08de2ba4a507f(Application param1Application, Intent param1Intent) {
      Logger.d("SafeDK-Special|SafeDK: Call> Landroid/app/Application;->startActivity(Landroid/content/Intent;)V");
      if (param1Intent == null)
        return; 
      BrandSafetyUtils.detectAdClick(param1Intent, "com.inneractive");
      param1Application.startActivity(param1Intent);
    }
    
    @JavascriptInterface
    public void onBackButtonPressed() {
      WeakReference<InternalStoreWebpageActivity> weakReference = this.a.q;
      if (weakReference != null && weakReference.get() != null)
        ((InternalStoreWebpageActivity)this.a.q.get()).finish(); 
    }
    
    @JavascriptInterface
    public void onCancelButtonPressed() {
      k k;
      t t2 = this.a;
      if (t2.B) {
        k = k.TRUE_SINGLE_TAP;
      } else {
        k = k.SINGLE_TAP;
      } 
      t2.d = k;
      t2.e(t2.j);
      t t1 = this.a;
      if (t1.h != null && !t1.r && t1.d != null) {
        t.b(t1, true);
        t t3 = this.a;
        j j = t3.h;
        p p = p.IGNITE_FLOW_CANCEL_INSTALL_CLICKED;
        k k1 = t3.d;
        ((n.a)j).a(p, k1);
      } 
    }
    
    @JavascriptInterface
    public void onInstallButtonPressed() {
      k k;
      t t2 = this.a;
      if (t2.B) {
        k = k.TRUE_SINGLE_TAP;
      } else {
        k = k.SINGLE_TAP;
      } 
      t2.d = k;
      t2.b.a(t2.c, new com.fyber.inneractive.sdk.ignite.c.d(t2.f, k, ((n.a)t2.h).a));
      t t1 = this.a;
      if (t1.h != null && !t1.s && t1.d != null) {
        t.a(t1, true);
        t t3 = this.a;
        j j = t3.h;
        p p = p.IGNITE_FLOW_INSTALL_CLICKED;
        k k1 = t3.d;
        ((n.a)j).a(p, k1);
      } 
    }
    
    @JavascriptInterface
    public void onNavigatedInsideStorePage() {
      t.c(this.a, true);
    }
    
    @JavascriptInterface
    public void onNavigatedToMainPage() {
      t.c(this.a, false);
    }
    
    @JavascriptInterface
    public void onOpenButtonPressed() {
      if (!TextUtils.isEmpty(this.a.c)) {
        Intent intent;
        if (!TextUtils.isEmpty(this.a.g)) {
          intent = new Intent("android.intent.action.MAIN");
          t t1 = this.a;
          intent.setClassName(t1.c, t1.g);
        } else {
          intent = l.a.getPackageManager().getLaunchIntentForPackage(this.a.c);
        } 
        if (intent != null) {
          intent.setFlags(268435456);
          try {
            safedk_Application_startActivity_1baa8fbf075affc453c08de2ba4a507f(l.a, intent);
            return;
          } catch (Exception exception) {
            j j = this.a.h;
            if (j != null) {
              String str1 = exception.getClass().getSimpleName();
              String str2 = exception.getMessage();
              n n = ((n.a)j).a;
              r.a(str1, str2, ((o)n).a, ((o)n).b);
              return;
            } 
          } 
        } else {
          t t1 = this.a;
          t1.getClass();
          IAlog.e("%sPackage %s not found", new Object[] { IAlog.a(t1), this.a.c });
          return;
        } 
      } else {
        t t1 = this.a;
        t1.getClass();
        IAlog.e("%smPackageName is null", new Object[] { IAlog.a(t1) });
      } 
    }
    
    @JavascriptInterface
    public void onTransitionEnded() {
      t.d(this.a, false);
    }
    
    @JavascriptInterface
    public void onTransitionStarting() {
      t.d(this.a, true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\web\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */