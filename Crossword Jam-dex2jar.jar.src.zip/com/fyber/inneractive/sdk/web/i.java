package com.fyber.inneractive.sdk.web;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.window.OnBackInvokedCallback;
import androidx.annotation.RequiresApi;
import com.fyber.inneractive.sdk.R;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.enums.Orientation;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.external.InneractiveUnitController;
import com.fyber.inneractive.sdk.flow.o;
import com.fyber.inneractive.sdk.mraid.b0;
import com.fyber.inneractive.sdk.mraid.c0;
import com.fyber.inneractive.sdk.mraid.t;
import com.fyber.inneractive.sdk.mraid.u;
import com.fyber.inneractive.sdk.mraid.v;
import com.fyber.inneractive.sdk.mraid.w;
import com.fyber.inneractive.sdk.mraid.y;
import com.fyber.inneractive.sdk.mraid.z;
import com.fyber.inneractive.sdk.network.i0;
import com.fyber.inneractive.sdk.network.n0;
import com.fyber.inneractive.sdk.network.u;
import com.fyber.inneractive.sdk.ui.IAcloseButton;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.m;
import com.fyber.inneractive.sdk.util.q;
import com.iab.omid.library.fyber.adsession.AdSession;
import com.iab.omid.library.fyber.adsession.Partner;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.utils.Logger;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public abstract class i<T extends i.f> extends c0<T> {
  public static final String[] q0 = new String[] { "yyyy-MM-dd'T'HH:mm:ssZZZZZ", "yyyy-MM-dd'T'HH:mmZZZZZ" };
  
  public b0 Q = b0.HIDDEN;
  
  public final d R;
  
  public final h S;
  
  public g T;
  
  public ViewGroup U;
  
  public g V;
  
  public boolean W = false;
  
  public int X;
  
  public i Y;
  
  public IAcloseButton Z;
  
  public boolean a0;
  
  public float b0;
  
  public int c0 = -1;
  
  public int d0 = -1;
  
  public int e0 = -1;
  
  public int f0 = -1;
  
  public int g0 = -1;
  
  public int h0 = -1;
  
  public Orientation i0 = Orientation.NONE;
  
  public int j0;
  
  public FrameLayout k0;
  
  public FrameLayout l0;
  
  public RelativeLayout m0;
  
  public int n0;
  
  public int o0;
  
  public OnBackInvokedCallback p0;
  
  public i(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, g paramg, d paramd, h paramh, com.fyber.inneractive.sdk.measurement.a parama) {
    super(paramContext, paramBoolean1, paramBoolean2, paramg);
    this.K = parama;
    this.T = paramg;
    this.R = paramd;
    this.S = paramh;
  }
  
  public final Map<String, String> a(URI paramURI) throws UnsupportedEncodingException {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>();
    String str = paramURI.getRawQuery();
    if (str != null && str.length() > 0)
      for (String str1 : str.split("&")) {
        int j = str1.indexOf("=");
        if (j > 0) {
          str = URLDecoder.decode(str1.substring(0, j), "UTF-8");
        } else {
          str = str1;
        } 
        if (j > 0) {
          int k = str1.length();
          if (k > ++j) {
            str1 = URLDecoder.decode(str1.substring(j), "UTF-8");
            continue;
          } 
        } 
        str1 = null;
        continue;
        linkedHashMap.put(str, SYNTHETIC_LOCAL_VARIABLE_6);
      }  
    return (Map)linkedHashMap;
  }
  
  public final Map<String, Object> a(Map<String, String> paramMap) throws Exception {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void a() {
    m.b.post((Runnable)new k(this));
  }
  
  public void a(Context paramContext, boolean paramBoolean) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    WindowManager windowManager = (WindowManager)IAConfigManager.M.v.a().getSystemService("window");
    if (Build.VERSION.SDK_INT >= 17) {
      windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
    } else {
      windowManager.getDefaultDisplay().getMetrics(displayMetrics);
    } 
    this.b0 = displayMetrics.density;
    int m = com.fyber.inneractive.sdk.util.l.a(paramContext);
    int n = com.fyber.inneractive.sdk.util.l.a(paramContext, m);
    int j = displayMetrics.widthPixels;
    int i1 = displayMetrics.heightPixels;
    double d1 = j;
    double d2 = 160.0D / displayMetrics.densityDpi;
    j = (int)(d1 * d2);
    int k = (int)(i1 * d2);
    g g1 = ((d)this).b;
    if (g1 != null && g1.getScaleX() != 1.0F && ((d)this).b.getScaleY() != 1.0F) {
      j = ((d)this).b.getWidthDp();
      k = ((d)this).b.getHeightDp();
      i1 = com.fyber.inneractive.sdk.util.l.b(((d)this).b.getHeightDp());
      this.e0 = this.c0;
      this.f0 = (int)((i1 - m - n) * 160.0D / displayMetrics.densityDpi);
    } else {
      d2 = 160.0D / displayMetrics.densityDpi;
      this.e0 = (int)(d1 * d2);
      this.f0 = (int)((i1 - m - n) * d2);
    } 
    if (this.c0 != j || this.d0 != k) {
      this.c0 = j;
      this.d0 = k;
      if (paramBoolean) {
        a((u)new y(j, k));
        a((u)new w(this.e0, this.f0));
        a((u)new v(0, 0, this.e0, this.f0));
        j = this.g0;
        if (j > 0 && this.h0 > 0) {
          a((u)new t(com.fyber.inneractive.sdk.util.l.c(j), com.fyber.inneractive.sdk.util.l.c(this.h0)));
          return;
        } 
        g1 = ((d)this).b;
        if (g1 != null && g1.getWidth() > 0 && ((d)this).b.getHeight() > 0)
          a((u)new t(com.fyber.inneractive.sdk.util.l.c(((d)this).b.getWidth()), com.fyber.inneractive.sdk.util.l.c(((d)this).b.getHeight()))); 
      } 
    } 
  }
  
  public void a(View paramView) {
    com.fyber.inneractive.sdk.measurement.a.a a = this.L;
    if (a != null) {
      com.fyber.inneractive.sdk.measurement.tracker.c c = (com.fyber.inneractive.sdk.measurement.tracker.c)a;
      c.getClass();
      try {
        AdSession adSession = c.a;
      } finally {
        paramView = null;
      } 
    } 
  }
  
  public void a(View paramView, com.fyber.inneractive.sdk.measurement.tracker.c.c paramc) {
    if (paramView != null) {
      com.fyber.inneractive.sdk.measurement.a.a a = this.L;
      if (a != null) {
        com.fyber.inneractive.sdk.measurement.tracker.c c1 = (com.fyber.inneractive.sdk.measurement.tracker.c)a;
        c1.getClass();
        try {
          AdSession adSession = c1.a;
        } finally {
          paramView = null;
        } 
      } 
    } 
  }
  
  public final void a(com.fyber.inneractive.sdk.mraid.g paramg) {
    // Byte code:
    //   0: getstatic com/fyber/inneractive/sdk/network/p.BANNER_RESIZE_EXPAND : Lcom/fyber/inneractive/sdk/network/p;
    //   3: astore #4
    //   5: aload_0
    //   6: getfield u : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   9: astore #5
    //   11: aload_0
    //   12: getfield v : Lcom/fyber/inneractive/sdk/flow/o;
    //   15: astore_2
    //   16: aload_2
    //   17: ifnull -> 28
    //   20: aload_2
    //   21: invokevirtual d : ()Lcom/fyber/inneractive/sdk/response/e;
    //   24: astore_2
    //   25: goto -> 30
    //   28: aconst_null
    //   29: astore_2
    //   30: aload_0
    //   31: getfield v : Lcom/fyber/inneractive/sdk/flow/o;
    //   34: astore_3
    //   35: aload_3
    //   36: ifnull -> 56
    //   39: aload_3
    //   40: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   43: astore_3
    //   44: aload_3
    //   45: ifnull -> 56
    //   48: aload_3
    //   49: invokevirtual c : ()Lorg/json/JSONArray;
    //   52: astore_3
    //   53: goto -> 58
    //   56: aconst_null
    //   57: astore_3
    //   58: new com/fyber/inneractive/sdk/network/q$a
    //   61: dup
    //   62: aload #4
    //   64: aload #5
    //   66: aload_2
    //   67: aload_3
    //   68: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   71: iconst_2
    //   72: anewarray java/lang/Object
    //   75: dup
    //   76: iconst_0
    //   77: ldc_w 'action'
    //   80: aastore
    //   81: dup
    //   82: iconst_1
    //   83: aload_1
    //   84: invokevirtual e : ()Ljava/lang/String;
    //   87: aastore
    //   88: invokevirtual a : ([Ljava/lang/Object;)Lcom/fyber/inneractive/sdk/network/q$a;
    //   91: aconst_null
    //   92: invokevirtual a : (Ljava/lang/String;)V
    //   95: return
  }
  
  public void a(com.fyber.inneractive.sdk.mraid.g paramg, String paramString) {
    String str = paramg.e();
    g g1 = ((d)this).b;
    if (g1 != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("window.mraidbridge.fireErrorEvent('");
      stringBuilder.append(str);
      stringBuilder.append("', '");
      stringBuilder.append(paramString);
      stringBuilder.append("');");
      g1.a(stringBuilder.toString());
    } 
  }
  
  public final void a(String paramString) {
    (new File(Environment.getExternalStorageDirectory(), "Pictures")).mkdirs();
    o o = ((d)this).v;
    if (o != null) {
      s s = o.c;
    } else {
      o = null;
    } 
    i0 i0 = new i0(new c(this), paramString, (s)o);
    IAConfigManager.M.s.a.offer(i0);
    i0.a(n0.QUEUED);
  }
  
  public void a(boolean paramBoolean) {
    a((u)new c0(paramBoolean));
    super.a(paramBoolean);
  }
  
  public boolean a(WebView paramWebView, String paramString) {
    IAlog.a("%shandle url for: %s webView = %s", new Object[] { IAlog.a(this), paramString, paramWebView });
    if (this.Q == b0.EXPANDED && !TextUtils.isEmpty(paramString) && paramWebView.equals(this.V) && !this.W) {
      this.W = true;
      return false;
    } 
    return super.a(paramWebView, paramString);
  }
  
  public void b() {
    m.b.post((Runnable)new l(this));
  }
  
  public void b(String paramString) {
    g g1 = ((d)this).b;
    if (g1 != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("window.mraidbridge.nativeCallComplete('");
      stringBuilder.append(paramString);
      stringBuilder.append("');");
      g1.a(stringBuilder.toString());
    } 
  }
  
  public void b(boolean paramBoolean) {
    m.b.post((Runnable)new l(this));
    g g1 = this.V;
    if (g1 != null && g1.getParent() != null && this.V.getParent() instanceof ViewGroup) {
      ((ViewGroup)this.V.getParent()).removeView((View)this.V);
      this.V = null;
    } 
    u();
    ((d)this).a = false;
    if (Build.VERSION.SDK_INT >= 33)
      v(); 
    super.b(paramBoolean);
  }
  
  public final Date c(String paramString) {
    Date date = null;
    int j = 0;
    while (true) {
      String[] arrayOfString = q0;
      if (j < arrayOfString.length) {
        try {
          Date date1 = (new SimpleDateFormat(arrayOfString[j], Locale.getDefault())).parse(paramString);
          date = date1;
          if (date1 != null)
            return date1; 
        } catch (ParseException parseException) {}
        j++;
        continue;
      } 
      return date;
    } 
  }
  
  public void c(boolean paramBoolean) {
    this.a0 = paramBoolean;
    d0 d0 = ((d)this).g;
    if (d0 != null)
      ((f)d0).a(this, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    if (this.U == null)
      return; 
    if (paramBoolean) {
      int j = com.fyber.inneractive.sdk.util.l.b(35);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(j, j);
      layoutParams.addRule(10);
      layoutParams.addRule(11);
      layoutParams.rightMargin = com.fyber.inneractive.sdk.util.l.b(10);
      layoutParams.topMargin = com.fyber.inneractive.sdk.util.l.b(10);
      if (this.Z == null) {
        IAcloseButton iAcloseButton = new IAcloseButton(m(), j, true);
        this.Z = iAcloseButton;
        iAcloseButton.setOnClickListener(new a(this));
      } 
      q.a((View)this.Z);
      this.m0.addView((View)this.Z, (ViewGroup.LayoutParams)layoutParams);
    } else {
      this.m0.removeView((View)this.Z);
    } 
    d0 d0 = ((d)this).g;
    if (d0 != null)
      ((f)d0).a(this, paramBoolean); 
    this.a0 = paramBoolean ^ true;
  }
  
  public final void e(boolean paramBoolean) {
    Context context = m();
    try {
      Activity activity = (Activity)context;
      if (activity != null) {
        if (paramBoolean && activity.getResources() != null && activity.getResources().getConfiguration() != null) {
          activity.setRequestedOrientation((activity.getResources().getConfiguration()).orientation);
          return;
        } 
        activity.setRequestedOrientation(this.X);
        return;
      } 
    } catch (Exception exception) {
      IAlog.a("Failed to modify the device orientation.", new Object[0]);
    } 
  }
  
  public k0 f() {
    if (this.Q == b0.EXPANDED) {
      g g2 = this.V;
      if (g2 != null)
        return g2.getLastClickedLocation(); 
    } 
    g g1 = ((d)this).b;
    return (g1 != null) ? g1.getLastClickedLocation() : k0.a();
  }
  
  public void g() {
    com.fyber.inneractive.sdk.measurement.a a = this.K;
    if (a != null) {
      com.fyber.inneractive.sdk.measurement.tracker.a a1;
      g g1 = ((d)this).b;
      o o = ((d)this).v;
      com.fyber.inneractive.sdk.measurement.b b = (com.fyber.inneractive.sdk.measurement.b)a;
      b.getClass();
      boolean bool = false;
      IAlog.a("omsdk initMraidSession", new Object[0]);
      if (b.e == null) {
        IAlog.a("omsdk partner is null", new Object[0]);
        o = null;
      } else {
        com.fyber.inneractive.sdk.measurement.tracker.b b1;
        boolean bool1 = bool;
        if (o != null) {
          bool1 = bool;
          if (o.d() != null) {
            bool1 = bool;
            if ((o.d()).H)
              bool1 = true; 
          } 
        } 
        com.fyber.inneractive.sdk.measurement.tracker.d d1 = b.f;
        Partner partner = b.e;
        d1.getClass();
        if (bool1) {
          b1 = new com.fyber.inneractive.sdk.measurement.tracker.b(partner, (WebView)g1, o);
        } else {
          a1 = new com.fyber.inneractive.sdk.measurement.tracker.a(partner, (WebView)g1, (o)b1);
        } 
        a1.a((WebView)g1);
      } 
      this.L = (com.fyber.inneractive.sdk.measurement.a.a)a1;
    } 
    super.g();
  }
  
  public void h() {
    byte b;
    super.h();
    this.Q = b0.LOADING;
    Context context = m();
    if (context instanceof Activity) {
      b = ((Activity)context).getRequestedOrientation();
    } else {
      b = -1;
    } 
    this.X = b;
    IAConfigManager iAConfigManager = IAConfigManager.M;
    this.l0 = new FrameLayout(iAConfigManager.v.a());
    this.m0 = new RelativeLayout(iAConfigManager.v.a());
    FrameLayout frameLayout = new FrameLayout(iAConfigManager.v.a());
    frameLayout.setBackgroundColor(-858993460);
    this.k0 = frameLayout;
    a(context, false);
    ((d)this).b.setOnKeyListener(new b(this));
  }
  
  public void l() {
    g g1 = ((d)this).b;
    if (g1 != null)
      g1.a("window.mraidbridge.fireReadyEvent();"); 
  }
  
  public Context m() {
    g g1 = ((d)this).b;
    return (g1 != null) ? g1.getContext() : null;
  }
  
  public boolean p() {
    return (this.Q == b0.EXPANDED);
  }
  
  public boolean q() {
    g g1 = this.T;
    return (g1 != null && g1.equals(g.INTERSTITIAL));
  }
  
  public void s() {
    g g2;
    this.W = false;
    b0 b02 = this.Q;
    b0 b01 = b0.EXPANDED;
    if (b02 == b01 || b02 == b0.RESIZED) {
      d(false);
      g2 = ((d)this).b;
      if (g2 != null) {
        b0 b03 = this.Q;
        if (b03 == b01) {
          u();
          ViewGroup viewGroup = (ViewGroup)this.k0.getParent();
          if (viewGroup != null) {
            viewGroup.addView((View)((d)this).b, this.j0, (ViewGroup.LayoutParams)q.a(this.n0, this.o0, new int[] { 13 }));
            viewGroup.removeView((View)this.k0);
            viewGroup.invalidate();
            ((d)this).b.requestLayout();
          } 
          this.g0 = this.n0;
          this.h0 = this.o0;
        } else if (b03 == b0.RESIZED) {
          this.g0 = this.n0;
          this.h0 = this.o0;
          ViewGroup.LayoutParams layoutParams = g2.getLayoutParams();
          if (layoutParams instanceof RelativeLayout.LayoutParams) {
            ((d)this).b.setLayoutParams((ViewGroup.LayoutParams)q.a(this.n0, this.o0, new int[] { 13 }));
          } else if (layoutParams instanceof FrameLayout.LayoutParams) {
            ((d)this).b.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(this.n0, this.o0, 17));
          } 
        } 
      } 
      this.Q = b0.DEFAULT;
      e(false);
      a((u)new z(this.Q));
    } else if (g2 == b0.DEFAULT) {
      g g3 = ((d)this).b;
      if (g3 != null)
        g3.setVisibility(4); 
      b0 b03 = b0.HIDDEN;
      this.Q = b03;
      a((u)new z(b03));
    } 
    g g1 = ((d)this).b;
    if (g1 != null) {
      RelativeLayout relativeLayout = (RelativeLayout)g1.findViewById(R.id.ia_identifier_overlay);
      if (relativeLayout != null)
        relativeLayout.setPadding(0, 0, 0, 0); 
    } 
    d0 d0 = ((d)this).g;
    if (d0 != null)
      ((f)d0).a(this, this.Q); 
    if (Build.VERSION.SDK_INT >= 33)
      v(); 
  }
  
  public void setAdDefaultSize(int paramInt1, int paramInt2) {
    this.n0 = paramInt1;
    this.o0 = paramInt2;
    this.g0 = paramInt1;
    this.h0 = paramInt2;
  }
  
  public void setOrientationProperties(boolean paramBoolean, String paramString) {
    if ("portrait".equals(paramString)) {
      this.i0 = Orientation.PORTRAIT;
    } else if ("landscape".equals(paramString)) {
      this.i0 = Orientation.LANDSCAPE;
    } else {
      this.i0 = Orientation.NONE;
    } 
    d0 d0 = ((d)this).g;
    if (d0 != null)
      ((f)d0).a(this, paramBoolean, this.i0); 
  }
  
  public void setResizeProperties() {}
  
  public boolean t() {
    return (this.Q == b0.RESIZED);
  }
  
  public final void u() {
    FrameLayout frameLayout = this.l0;
    if (frameLayout != null && this.m0 != null) {
      frameLayout.removeAllViewsInLayout();
      this.m0.removeAllViewsInLayout();
      ViewGroup viewGroup = this.U;
      if (viewGroup != null)
        viewGroup.removeView((View)this.m0); 
    } 
  }
  
  @RequiresApi(api = 33)
  public final void v() {
    try {
      if (m() instanceof Activity && this.p0 != null) {
        ((Activity)m()).getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.p0);
        this.p0 = null;
        return;
      } 
    } catch (Exception exception) {
      IAlog.e("failed to unregisterOnBackInvokedCallback with error: %s", new Object[] { exception.getMessage() });
    } 
  }
  
  public class a implements View.OnClickListener {
    public a(i this$0) {}
    
    public void onClick(View param1View) {
      Logger.d("Fyber|SafeDK: Execution> Lcom/fyber/inneractive/sdk/web/i$a;->onClick(Landroid/view/View;)V");
      CreativeInfoManager.onViewClicked("com.inneractive", param1View);
      safedk_i$a_onClick_b80d27761e381fb0aae147f729b48083(param1View);
    }
    
    public void safedk_i$a_onClick_b80d27761e381fb0aae147f729b48083(View param1View) {
      this.a.s();
    }
  }
  
  public class b implements View.OnKeyListener {
    public b(i this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (param1Int == 4) {
        bool1 = bool2;
        if (this.a.p()) {
          IAlog.d("back button pressed while ad is expanded, ad will be collapsed.", new Object[0]);
          this.a.s();
          bool1 = true;
        } 
      } 
      return bool1;
    }
  }
  
  public class c implements u<String> {
    public c(i this$0) {}
    
    public void a(Object param1Object, Exception param1Exception, boolean param1Boolean) {
      param1Object = param1Object;
      if (param1Exception == null && !TextUtils.isEmpty((CharSequence)param1Object)) {
        i i1 = this.a;
        if (i1.m() != null) {
          param1Object = new i.e(i1, (String)param1Object, null);
          MediaScannerConnection mediaScannerConnection = new MediaScannerConnection(i1.m().getApplicationContext(), (MediaScannerConnection.MediaScannerConnectionClient)param1Object);
          ((i.e)param1Object).b = mediaScannerConnection;
          mediaScannerConnection.connect();
          return;
        } 
      } else {
        m.b.post((Runnable)new p(this));
      } 
    }
  }
  
  public enum d {
    DISABLED, ENABLED;
    
    static {
      d d1 = new d("ENABLED", 0);
      ENABLED = d1;
      d d2 = new d("DISABLED", 1);
      DISABLED = d2;
      $VALUES = new d[] { d1, d2 };
    }
  }
  
  public class e implements MediaScannerConnection.MediaScannerConnectionClient {
    public final String a;
    
    public MediaScannerConnection b;
    
    public e(i this$0, String param1String1, String param1String2) {
      this.a = param1String1;
    }
    
    public void onMediaScannerConnected() {
      MediaScannerConnection mediaScannerConnection = this.b;
      if (mediaScannerConnection != null)
        mediaScannerConnection.scanFile(this.a, null); 
    }
    
    public void onScanCompleted(String param1String, Uri param1Uri) {
      MediaScannerConnection mediaScannerConnection = this.b;
      if (mediaScannerConnection != null)
        mediaScannerConnection.disconnect(); 
    }
  }
  
  public static interface f extends d0 {
    void a(InneractiveUnitController.AdDisplayError param1AdDisplayError);
    
    void a(i param1i);
    
    void a(i param1i, b0 param1b0);
    
    void a(i param1i, boolean param1Boolean);
    
    void a(i param1i, boolean param1Boolean, Orientation param1Orientation);
    
    boolean a(String param1String);
    
    void b(i param1i);
    
    void c();
  }
  
  public enum g {
    INLINE, INTERSTITIAL;
    
    static {
      g g1 = new g("INLINE", 0);
      INLINE = g1;
      g g2 = new g("INTERSTITIAL", 1);
      INTERSTITIAL = g2;
      $VALUES = new g[] { g1, g2 };
    }
  }
  
  public enum h {
    AD_CONTROLLED, ALWAYS_HIDDEN, ALWAYS_VISIBLE;
    
    static {
      h h1 = new h("ALWAYS_VISIBLE", 0);
      ALWAYS_VISIBLE = h1;
      h h2 = new h("ALWAYS_HIDDEN", 1);
      ALWAYS_HIDDEN = h2;
      h h3 = new h("AD_CONTROLLED", 2);
      AD_CONTROLLED = h3;
      $VALUES = new h[] { h1, h2, h3 };
    }
  }
  
  public class i extends BroadcastReceiver {
    public Context a;
    
    public int b = -1;
    
    public i(i this$0) {}
    
    public void a() {
      try {
        i i1 = this.c;
        i1.getClass();
        IAlog.a("%sunregister screen broadcast receiver called", new Object[] { IAlog.a(i1) });
        return;
      } finally {
        Exception exception = null;
      } 
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      int j;
      if (this.a != null) {
        j = 1;
      } else {
        j = 0;
      } 
      if (!j)
        return; 
      if ("android.intent.action.CONFIGURATION_CHANGED".equals(param1Intent.getAction())) {
        j = ((WindowManager)IAConfigManager.M.v.a().getSystemService("window")).getDefaultDisplay().getRotation();
        if (j != this.b) {
          this.b = j;
          i i1 = this.c;
          g g = ((d)i1).b;
          if (g != null)
            g.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)new j(i1, param1Context)); 
        } 
      } 
    }
  }
  
  public class j implements d.d {
    public com.fyber.inneractive.sdk.mraid.a a;
    
    public j(i this$0, com.fyber.inneractive.sdk.mraid.a param1a, k0 param1k0) {
      this.a = param1a;
    }
    
    public String a() {
      return this.a.c();
    }
    
    public void b() {
      com.fyber.inneractive.sdk.mraid.a a1 = this.a;
      if (a1 != null)
        a1.d(); 
    }
    
    public String c() {
      return ((com.fyber.inneractive.sdk.mraid.b)this.a).a;
    }
    
    public void d() {
      com.fyber.inneractive.sdk.measurement.a.a a1 = this.b.L;
      if (a1 != null)
        a1.b(); 
      this.a.a();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("action = ");
      stringBuilder.append(((com.fyber.inneractive.sdk.mraid.b)this.a).a);
      stringBuilder.append(" url = ");
      stringBuilder.append(this.a.c());
      return stringBuilder.toString();
    }
  }
  
  public static interface k extends f {
    void a();
  }
  
  public static abstract class l implements f {
    public void a(boolean param1Boolean) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\web\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */