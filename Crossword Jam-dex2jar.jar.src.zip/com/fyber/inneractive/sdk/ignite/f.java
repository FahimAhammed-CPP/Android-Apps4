package com.fyber.inneractive.sdk.ignite;

import com.fyber.inneractive.sdk.network.u;
import com.fyber.inneractive.sdk.util.IAlog;

public class f implements u<String> {
  public f(c paramc, String paramString) {}
  
  public void a(Object paramObject, Exception paramException, boolean paramBoolean) {
    paramObject = paramObject;
    IAlog.a("Hit Request: Hitting URL finished: %s", new Object[] { this.a });
    if (paramException == null) {
      IAlog.a("Hit Request: Hitting URL response code: %s", new Object[] { paramObject });
      return;
    } 
    IAlog.a("Hit Request: Hitting URL failed: %s", new Object[] { paramException });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */