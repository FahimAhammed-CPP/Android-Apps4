package com.fyber.inneractive.sdk.ignite;

import android.os.RemoteException;
import com.digitalturbine.ignite.cl.aidl.IIgniteServiceCallback;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.web.t;

public class b extends IIgniteServiceCallback.Stub {
  public final g.b a;
  
  public b(g.b paramb) {
    this.a = paramb;
  }
  
  public void onError(String paramString) throws RemoteException {
    IAlog.a("CancelTaskCallback onError %s", new Object[] { paramString });
    ((t.e)this.a).a(false);
  }
  
  public void onProgress(String paramString) throws RemoteException {
    IAlog.a("CancelTaskCallback onProgress %s", new Object[] { paramString });
  }
  
  public void onScheduled(String paramString) throws RemoteException {
    IAlog.a("CancelTaskCallback onScheduled %s", new Object[] { paramString });
  }
  
  public void onStart(String paramString) throws RemoteException {
    IAlog.a("CancelTaskCallback onStart %s", new Object[] { paramString });
  }
  
  public void onSuccess(String paramString) throws RemoteException {
    IAlog.a("CancelTaskCallback onSuccess %s", new Object[] { paramString });
    ((t.e)this.a).a(true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\ignite\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */