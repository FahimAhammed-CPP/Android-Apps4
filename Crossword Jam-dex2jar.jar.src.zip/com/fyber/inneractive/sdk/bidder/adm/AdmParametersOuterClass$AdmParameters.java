package com.fyber.inneractive.sdk.bidder.adm;

import com.fyber.inneractive.sdk.protobuf.GeneratedMessageLite;
import com.fyber.inneractive.sdk.protobuf.i;
import com.fyber.inneractive.sdk.protobuf.j;
import com.fyber.inneractive.sdk.protobuf.p0;
import com.fyber.inneractive.sdk.protobuf.q;
import com.fyber.inneractive.sdk.protobuf.w0;
import com.fyber.inneractive.sdk.protobuf.y;
import com.fyber.inneractive.sdk.protobuf.z;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class AdmParametersOuterClass$AdmParameters extends GeneratedMessageLite<AdmParametersOuterClass$AdmParameters, AdmParametersOuterClass$AdmParameters.c> {
  public static final int ABEXPERIMENTS_FIELD_NUMBER = 33;
  
  public static final int ADCOMPLETIONURL_FIELD_NUMBER = 24;
  
  public static final int ADDOMAIN_FIELD_NUMBER = 29;
  
  public static final int ADDURATION_FIELD_NUMBER = 25;
  
  public static final int ADEXPIRATIONINTERVAL_FIELD_NUMBER = 13;
  
  public static final int ADHEIGHT_FIELD_NUMBER = 5;
  
  public static final int ADNETWORKID_FIELD_NUMBER = 12;
  
  public static final int ADNETWORKNAME_FIELD_NUMBER = 11;
  
  public static final int ADTYPE_FIELD_NUMBER = 14;
  
  public static final int ADUNITDISPLAYTYPE_FIELD_NUMBER = 8;
  
  public static final int ADUNITID_FIELD_NUMBER = 6;
  
  public static final int ADUNITTYPE_FIELD_NUMBER = 7;
  
  public static final int ADVERTISEDAPPID_FIELD_NUMBER = 18;
  
  public static final int ADWIDTH_FIELD_NUMBER = 4;
  
  public static final int APPBUNDLEID_FIELD_NUMBER = 23;
  
  public static final int BRANDBIDDERCTATEXT_FIELD_NUMBER = 40;
  
  public static final int BRANDBIDDERDONTSHOWENDCARD_FIELD_NUMBER = 39;
  
  public static final int CAMPAIGNID_FIELD_NUMBER = 31;
  
  public static final int CONTENTID_FIELD_NUMBER = 9;
  
  public static final int CREATIVEID_FIELD_NUMBER = 30;
  
  public static final int CREATIVETYPE_FIELD_NUMBER = 26;
  
  private static final AdmParametersOuterClass$AdmParameters DEFAULT_INSTANCE;
  
  public static final int ERRORMESSAGE_FIELD_NUMBER = 3;
  
  public static final int IGNITEINSTALLURL_FIELD_NUMBER = 36;
  
  public static final int IGNITELAUNCHERACTIVITY_FIELD_NUMBER = 37;
  
  public static final int IGNITEMODE_FIELD_NUMBER = 35;
  
  public static final int MARKUPURL_FIELD_NUMBER = 1;
  
  public static final int MRAIDVIDEOOMSIGNAL_FIELD_NUMBER = 41;
  
  public static final int MRCDATA_FIELD_NUMBER = 32;
  
  private static volatile w0<AdmParametersOuterClass$AdmParameters> PARSER;
  
  public static final int PRICINGVALUE_FIELD_NUMBER = 28;
  
  public static final int PUBLISHERID_FIELD_NUMBER = 10;
  
  public static final int SDKCLICKURL_FIELD_NUMBER = 16;
  
  public static final int SDKIMPRESSIONURL_FIELD_NUMBER = 15;
  
  public static final int SESSIONID_FIELD_NUMBER = 2;
  
  public static final int SKADNETWORKDATA_FIELD_NUMBER = 27;
  
  public static final int SKIPMODE_FIELD_NUMBER = 22;
  
  public static final int SKOVERLAYDATA_FIELD_NUMBER = 38;
  
  public static final int SPOTID_FIELD_NUMBER = 34;
  
  public static final int STORECTATEXT_FIELD_NUMBER = 21;
  
  public static final int STOREEVENTURL_FIELD_NUMBER = 20;
  
  public static final int STOREURLTYPE_FIELD_NUMBER = 19;
  
  public static final int STOREURL_FIELD_NUMBER = 17;
  
  private y.j<Experiment> abExperiments_ = GeneratedMessageLite.emptyProtobufList();
  
  private String adCompletionUrl_ = "";
  
  private String adDomain_ = "";
  
  private int adDuration_;
  
  private int adExpirationInterval_;
  
  private int adHeight_;
  
  private long adNetworkId_;
  
  private String adNetworkName_ = "";
  
  private int adType_;
  
  private int adUnitDisplayType_;
  
  private String adUnitId_ = "";
  
  private int adUnitType_;
  
  private int adWidth_;
  
  private String advertisedAppId_ = "";
  
  private String appBundleId_ = "";
  
  private int bitField0_;
  
  private int bitField1_;
  
  private String brandBidderCtaText_ = "";
  
  private boolean brandBidderDontShowEndcard_;
  
  private String campaignId_ = "";
  
  private long contentId_;
  
  private String creativeId_ = "";
  
  private String creativeType_ = "";
  
  private String errorMessage_ = "";
  
  private String igniteInstallUrl_ = "";
  
  private String igniteLauncherActivity_ = "";
  
  private int igniteMode_;
  
  private String markupUrl_ = "";
  
  private boolean mraidVideoOMSignal_;
  
  private MRCData mrcData_;
  
  private double pricingValue_;
  
  private long publisherId_;
  
  private String sdkClickUrl_ = "";
  
  private String sdkImpressionUrl_ = "";
  
  private String sessionId_ = "";
  
  private SKAdNetworkData skAdNetworkData_;
  
  private SKOverlayData skOverlayData_;
  
  private boolean skipMode_;
  
  private long spotId_;
  
  private String storeCTAText_ = "";
  
  private String storeEventUrl_ = "";
  
  private int storeUrlType_;
  
  private String storeUrl_ = "";
  
  static {
    AdmParametersOuterClass$AdmParameters admParametersOuterClass$AdmParameters = new AdmParametersOuterClass$AdmParameters();
    DEFAULT_INSTANCE = admParametersOuterClass$AdmParameters;
    GeneratedMessageLite.registerDefaultInstance(AdmParametersOuterClass$AdmParameters.class, admParametersOuterClass$AdmParameters);
  }
  
  private void addAbExperiments(int paramInt, Experiment paramExperiment) {
    paramExperiment.getClass();
    ensureAbExperimentsIsMutable();
    this.abExperiments_.add(paramInt, paramExperiment);
  }
  
  private void addAbExperiments(Experiment paramExperiment) {
    paramExperiment.getClass();
    ensureAbExperimentsIsMutable();
    this.abExperiments_.add(paramExperiment);
  }
  
  private void addAllAbExperiments(Iterable<? extends Experiment> paramIterable) {
    ensureAbExperimentsIsMutable();
    com.fyber.inneractive.sdk.protobuf.a.addAll(paramIterable, (List)this.abExperiments_);
  }
  
  private void clearAbExperiments() {
    this.abExperiments_ = GeneratedMessageLite.emptyProtobufList();
  }
  
  private void clearAdCompletionUrl() {
    this.bitField0_ &= 0xFFEFFFFF;
    this.adCompletionUrl_ = getDefaultInstance().getAdCompletionUrl();
  }
  
  private void clearAdDomain() {
    this.bitField0_ &= 0xFDFFFFFF;
    this.adDomain_ = getDefaultInstance().getAdDomain();
  }
  
  private void clearAdDuration() {
    this.bitField0_ &= 0xFFDFFFFF;
    this.adDuration_ = 0;
  }
  
  private void clearAdExpirationInterval() {
    this.bitField0_ &= 0xFFFFFBFF;
    this.adExpirationInterval_ = 0;
  }
  
  private void clearAdHeight() {
    this.bitField0_ &= 0xFFFFFFEF;
    this.adHeight_ = 0;
  }
  
  private void clearAdNetworkId() {
    this.bitField0_ &= 0xFFFFFDFF;
    this.adNetworkId_ = 0L;
  }
  
  private void clearAdNetworkName() {
    this.bitField0_ &= 0xFFFFFEFF;
    this.adNetworkName_ = getDefaultInstance().getAdNetworkName();
  }
  
  private void clearAdType() {
    this.adType_ = 0;
  }
  
  private void clearAdUnitDisplayType() {
    this.adUnitDisplayType_ = 0;
  }
  
  private void clearAdUnitId() {
    this.bitField0_ &= 0xFFFFFFDF;
    this.adUnitId_ = getDefaultInstance().getAdUnitId();
  }
  
  private void clearAdUnitType() {
    this.adUnitType_ = 0;
  }
  
  private void clearAdWidth() {
    this.bitField0_ &= 0xFFFFFFF7;
    this.adWidth_ = 0;
  }
  
  private void clearAdvertisedAppId() {
    this.bitField0_ &= 0xFFFFBFFF;
    this.advertisedAppId_ = getDefaultInstance().getAdvertisedAppId();
  }
  
  private void clearAppBundleId() {
    this.bitField0_ &= 0xFFF7FFFF;
    this.appBundleId_ = getDefaultInstance().getAppBundleId();
  }
  
  private void clearBrandBidderCtaText() {
    this.bitField1_ &= 0xFFFFFFF7;
    this.brandBidderCtaText_ = getDefaultInstance().getBrandBidderCtaText();
  }
  
  private void clearBrandBidderDontShowEndcard() {
    this.bitField1_ &= 0xFFFFFFFB;
    this.brandBidderDontShowEndcard_ = false;
  }
  
  private void clearCampaignId() {
    this.bitField0_ &= 0xF7FFFFFF;
    this.campaignId_ = getDefaultInstance().getCampaignId();
  }
  
  private void clearContentId() {
    this.bitField0_ &= 0xFFFFFFBF;
    this.contentId_ = 0L;
  }
  
  private void clearCreativeId() {
    this.bitField0_ &= 0xFBFFFFFF;
    this.creativeId_ = getDefaultInstance().getCreativeId();
  }
  
  private void clearCreativeType() {
    this.bitField0_ &= 0xFFBFFFFF;
    this.creativeType_ = getDefaultInstance().getCreativeType();
  }
  
  private void clearErrorMessage() {
    this.bitField0_ &= 0xFFFFFFFB;
    this.errorMessage_ = getDefaultInstance().getErrorMessage();
  }
  
  private void clearIgniteInstallUrl() {
    this.bitField0_ &= Integer.MAX_VALUE;
    this.igniteInstallUrl_ = getDefaultInstance().getIgniteInstallUrl();
  }
  
  private void clearIgniteLauncherActivity() {
    this.bitField1_ &= 0xFFFFFFFE;
    this.igniteLauncherActivity_ = getDefaultInstance().getIgniteLauncherActivity();
  }
  
  private void clearIgniteMode() {
    this.bitField0_ &= 0xBFFFFFFF;
    this.igniteMode_ = 0;
  }
  
  private void clearMarkupUrl() {
    this.bitField0_ &= 0xFFFFFFFE;
    this.markupUrl_ = getDefaultInstance().getMarkupUrl();
  }
  
  private void clearMraidVideoOMSignal() {
    this.bitField1_ &= 0xFFFFFFEF;
    this.mraidVideoOMSignal_ = false;
  }
  
  private void clearMrcData() {
    this.mrcData_ = null;
    this.bitField0_ &= 0xEFFFFFFF;
  }
  
  private void clearPricingValue() {
    this.bitField0_ &= 0xFEFFFFFF;
    this.pricingValue_ = 0.0D;
  }
  
  private void clearPublisherId() {
    this.bitField0_ &= 0xFFFFFF7F;
    this.publisherId_ = 0L;
  }
  
  private void clearSdkClickUrl() {
    this.bitField0_ &= 0xFFFFEFFF;
    this.sdkClickUrl_ = getDefaultInstance().getSdkClickUrl();
  }
  
  private void clearSdkImpressionUrl() {
    this.bitField0_ &= 0xFFFFF7FF;
    this.sdkImpressionUrl_ = getDefaultInstance().getSdkImpressionUrl();
  }
  
  private void clearSessionId() {
    this.bitField0_ &= 0xFFFFFFFD;
    this.sessionId_ = getDefaultInstance().getSessionId();
  }
  
  private void clearSkAdNetworkData() {
    this.skAdNetworkData_ = null;
    this.bitField0_ &= 0xFF7FFFFF;
  }
  
  private void clearSkOverlayData() {
    this.skOverlayData_ = null;
    this.bitField1_ &= 0xFFFFFFFD;
  }
  
  private void clearSkipMode() {
    this.bitField0_ &= 0xFFFBFFFF;
    this.skipMode_ = false;
  }
  
  private void clearSpotId() {
    this.bitField0_ &= 0xDFFFFFFF;
    this.spotId_ = 0L;
  }
  
  private void clearStoreCTAText() {
    this.bitField0_ &= 0xFFFDFFFF;
    this.storeCTAText_ = getDefaultInstance().getStoreCTAText();
  }
  
  private void clearStoreEventUrl() {
    this.bitField0_ &= 0xFFFEFFFF;
    this.storeEventUrl_ = getDefaultInstance().getStoreEventUrl();
  }
  
  private void clearStoreUrl() {
    this.bitField0_ &= 0xFFFFDFFF;
    this.storeUrl_ = getDefaultInstance().getStoreUrl();
  }
  
  private void clearStoreUrlType() {
    this.bitField0_ &= 0xFFFF7FFF;
    this.storeUrlType_ = 0;
  }
  
  private void ensureAbExperimentsIsMutable() {
    y.j<Experiment> j1 = this.abExperiments_;
    if (!j1.d())
      this.abExperiments_ = GeneratedMessageLite.mutableCopy(j1); 
  }
  
  public static AdmParametersOuterClass$AdmParameters getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  private void mergeMrcData(MRCData paramMRCData) {
    paramMRCData.getClass();
    MRCData mRCData = this.mrcData_;
    if (mRCData != null && mRCData != MRCData.getDefaultInstance()) {
      MRCData.a a = MRCData.newBuilder(this.mrcData_);
      a.c();
      a.a(a.b, paramMRCData);
      this.mrcData_ = (MRCData)a.b();
    } else {
      this.mrcData_ = paramMRCData;
    } 
    this.bitField0_ |= 0x10000000;
  }
  
  private void mergeSkAdNetworkData(SKAdNetworkData paramSKAdNetworkData) {
    paramSKAdNetworkData.getClass();
    SKAdNetworkData sKAdNetworkData = this.skAdNetworkData_;
    if (sKAdNetworkData != null && sKAdNetworkData != SKAdNetworkData.getDefaultInstance()) {
      SKAdNetworkData.a a = SKAdNetworkData.newBuilder(this.skAdNetworkData_);
      a.c();
      a.a(a.b, paramSKAdNetworkData);
      this.skAdNetworkData_ = (SKAdNetworkData)a.b();
    } else {
      this.skAdNetworkData_ = paramSKAdNetworkData;
    } 
    this.bitField0_ |= 0x800000;
  }
  
  private void mergeSkOverlayData(SKOverlayData paramSKOverlayData) {
    paramSKOverlayData.getClass();
    SKOverlayData sKOverlayData = this.skOverlayData_;
    if (sKOverlayData != null && sKOverlayData != SKOverlayData.getDefaultInstance()) {
      SKOverlayData.a a = SKOverlayData.newBuilder(this.skOverlayData_);
      a.c();
      a.a(a.b, paramSKOverlayData);
      this.skOverlayData_ = (SKOverlayData)a.b();
    } else {
      this.skOverlayData_ = paramSKOverlayData;
    } 
    this.bitField1_ |= 0x2;
  }
  
  public static c newBuilder() {
    return (c)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static c newBuilder(AdmParametersOuterClass$AdmParameters paramAdmParametersOuterClass$AdmParameters) {
    return (c)DEFAULT_INSTANCE.createBuilder(paramAdmParametersOuterClass$AdmParameters);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseDelimitedFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(i parami) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(i parami, q paramq) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, parami, paramq);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(j paramj) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(j paramj, q paramq) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramj, paramq);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(InputStream paramInputStream) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(InputStream paramInputStream, q paramq) throws IOException {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramq);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(ByteBuffer paramByteBuffer) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(ByteBuffer paramByteBuffer, q paramq) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramq);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(byte[] paramArrayOfbyte) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static AdmParametersOuterClass$AdmParameters parseFrom(byte[] paramArrayOfbyte, q paramq) throws z {
    return (AdmParametersOuterClass$AdmParameters)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramq);
  }
  
  public static w0<AdmParametersOuterClass$AdmParameters> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void removeAbExperiments(int paramInt) {
    ensureAbExperimentsIsMutable();
    this.abExperiments_.remove(paramInt);
  }
  
  private void setAbExperiments(int paramInt, Experiment paramExperiment) {
    paramExperiment.getClass();
    ensureAbExperimentsIsMutable();
    this.abExperiments_.set(paramInt, paramExperiment);
  }
  
  private void setAdCompletionUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x100000;
    this.adCompletionUrl_ = paramString;
  }
  
  private void setAdCompletionUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.adCompletionUrl_ = parami.i();
    this.bitField0_ |= 0x100000;
  }
  
  private void setAdDomain(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x2000000;
    this.adDomain_ = paramString;
  }
  
  private void setAdDomainBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.adDomain_ = parami.i();
    this.bitField0_ |= 0x2000000;
  }
  
  private void setAdDuration(int paramInt) {
    this.bitField0_ |= 0x200000;
    this.adDuration_ = paramInt;
  }
  
  private void setAdExpirationInterval(int paramInt) {
    this.bitField0_ |= 0x400;
    this.adExpirationInterval_ = paramInt;
  }
  
  private void setAdHeight(int paramInt) {
    this.bitField0_ |= 0x10;
    this.adHeight_ = paramInt;
  }
  
  private void setAdNetworkId(long paramLong) {
    this.bitField0_ |= 0x200;
    this.adNetworkId_ = paramLong;
  }
  
  private void setAdNetworkName(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x100;
    this.adNetworkName_ = paramString;
  }
  
  private void setAdNetworkNameBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.adNetworkName_ = parami.i();
    this.bitField0_ |= 0x100;
  }
  
  private void setAdType(a parama) {
    this.adType_ = parama.a();
  }
  
  private void setAdTypeValue(int paramInt) {
    this.adType_ = paramInt;
  }
  
  private void setAdUnitDisplayType(g paramg) {
    this.adUnitDisplayType_ = paramg.a();
  }
  
  private void setAdUnitDisplayTypeValue(int paramInt) {
    this.adUnitDisplayType_ = paramInt;
  }
  
  private void setAdUnitId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x20;
    this.adUnitId_ = paramString;
  }
  
  private void setAdUnitIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.adUnitId_ = parami.i();
    this.bitField0_ |= 0x20;
  }
  
  private void setAdUnitType(b paramb) {
    this.adUnitType_ = paramb.a();
  }
  
  private void setAdUnitTypeValue(int paramInt) {
    this.adUnitType_ = paramInt;
  }
  
  private void setAdWidth(int paramInt) {
    this.bitField0_ |= 0x8;
    this.adWidth_ = paramInt;
  }
  
  private void setAdvertisedAppId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x4000;
    this.advertisedAppId_ = paramString;
  }
  
  private void setAdvertisedAppIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.advertisedAppId_ = parami.i();
    this.bitField0_ |= 0x4000;
  }
  
  private void setAppBundleId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x80000;
    this.appBundleId_ = paramString;
  }
  
  private void setAppBundleIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.appBundleId_ = parami.i();
    this.bitField0_ |= 0x80000;
  }
  
  private void setBrandBidderCtaText(String paramString) {
    paramString.getClass();
    this.bitField1_ |= 0x8;
    this.brandBidderCtaText_ = paramString;
  }
  
  private void setBrandBidderCtaTextBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.brandBidderCtaText_ = parami.i();
    this.bitField1_ |= 0x8;
  }
  
  private void setBrandBidderDontShowEndcard(boolean paramBoolean) {
    this.bitField1_ |= 0x4;
    this.brandBidderDontShowEndcard_ = paramBoolean;
  }
  
  private void setCampaignId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x8000000;
    this.campaignId_ = paramString;
  }
  
  private void setCampaignIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.campaignId_ = parami.i();
    this.bitField0_ |= 0x8000000;
  }
  
  private void setContentId(long paramLong) {
    this.bitField0_ |= 0x40;
    this.contentId_ = paramLong;
  }
  
  private void setCreativeId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x4000000;
    this.creativeId_ = paramString;
  }
  
  private void setCreativeIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.creativeId_ = parami.i();
    this.bitField0_ |= 0x4000000;
  }
  
  private void setCreativeType(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x400000;
    this.creativeType_ = paramString;
  }
  
  private void setCreativeTypeBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.creativeType_ = parami.i();
    this.bitField0_ |= 0x400000;
  }
  
  private void setErrorMessage(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x4;
    this.errorMessage_ = paramString;
  }
  
  private void setErrorMessageBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.errorMessage_ = parami.i();
    this.bitField0_ |= 0x4;
  }
  
  private void setIgniteInstallUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= Integer.MIN_VALUE;
    this.igniteInstallUrl_ = paramString;
  }
  
  private void setIgniteInstallUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.igniteInstallUrl_ = parami.i();
    this.bitField0_ |= Integer.MIN_VALUE;
  }
  
  private void setIgniteLauncherActivity(String paramString) {
    paramString.getClass();
    this.bitField1_ |= 0x1;
    this.igniteLauncherActivity_ = paramString;
  }
  
  private void setIgniteLauncherActivityBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.igniteLauncherActivity_ = parami.i();
    this.bitField1_ |= 0x1;
  }
  
  private void setIgniteMode(f paramf) {
    this.igniteMode_ = paramf.a();
    this.bitField0_ |= 0x40000000;
  }
  
  private void setIgniteModeValue(int paramInt) {
    this.bitField0_ |= 0x40000000;
    this.igniteMode_ = paramInt;
  }
  
  private void setMarkupUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x1;
    this.markupUrl_ = paramString;
  }
  
  private void setMarkupUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.markupUrl_ = parami.i();
    this.bitField0_ |= 0x1;
  }
  
  private void setMraidVideoOMSignal(boolean paramBoolean) {
    this.bitField1_ |= 0x10;
    this.mraidVideoOMSignal_ = paramBoolean;
  }
  
  private void setMrcData(MRCData paramMRCData) {
    paramMRCData.getClass();
    this.mrcData_ = paramMRCData;
    this.bitField0_ |= 0x10000000;
  }
  
  private void setPricingValue(double paramDouble) {
    this.bitField0_ |= 0x1000000;
    this.pricingValue_ = paramDouble;
  }
  
  private void setPublisherId(long paramLong) {
    this.bitField0_ |= 0x80;
    this.publisherId_ = paramLong;
  }
  
  private void setSdkClickUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x1000;
    this.sdkClickUrl_ = paramString;
  }
  
  private void setSdkClickUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.sdkClickUrl_ = parami.i();
    this.bitField0_ |= 0x1000;
  }
  
  private void setSdkImpressionUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x800;
    this.sdkImpressionUrl_ = paramString;
  }
  
  private void setSdkImpressionUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.sdkImpressionUrl_ = parami.i();
    this.bitField0_ |= 0x800;
  }
  
  private void setSessionId(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x2;
    this.sessionId_ = paramString;
  }
  
  private void setSessionIdBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.sessionId_ = parami.i();
    this.bitField0_ |= 0x2;
  }
  
  private void setSkAdNetworkData(SKAdNetworkData paramSKAdNetworkData) {
    paramSKAdNetworkData.getClass();
    this.skAdNetworkData_ = paramSKAdNetworkData;
    this.bitField0_ |= 0x800000;
  }
  
  private void setSkOverlayData(SKOverlayData paramSKOverlayData) {
    paramSKOverlayData.getClass();
    this.skOverlayData_ = paramSKOverlayData;
    this.bitField1_ |= 0x2;
  }
  
  private void setSkipMode(boolean paramBoolean) {
    this.bitField0_ |= 0x40000;
    this.skipMode_ = paramBoolean;
  }
  
  private void setSpotId(long paramLong) {
    this.bitField0_ |= 0x20000000;
    this.spotId_ = paramLong;
  }
  
  private void setStoreCTAText(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x20000;
    this.storeCTAText_ = paramString;
  }
  
  private void setStoreCTATextBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.storeCTAText_ = parami.i();
    this.bitField0_ |= 0x20000;
  }
  
  private void setStoreEventUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x10000;
    this.storeEventUrl_ = paramString;
  }
  
  private void setStoreEventUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.storeEventUrl_ = parami.i();
    this.bitField0_ |= 0x10000;
  }
  
  private void setStoreUrl(String paramString) {
    paramString.getClass();
    this.bitField0_ |= 0x2000;
    this.storeUrl_ = paramString;
  }
  
  private void setStoreUrlBytes(i parami) {
    com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(parami);
    this.storeUrl_ = parami.i();
    this.bitField0_ |= 0x2000;
  }
  
  private void setStoreUrlType(d paramd) {
    this.storeUrlType_ = paramd.a();
    this.bitField0_ |= 0x8000;
  }
  
  private void setStoreUrlTypeValue(int paramInt) {
    this.bitField0_ |= 0x8000;
    this.storeUrlType_ = paramInt;
  }
  
  public final Object dynamicMethod(GeneratedMessageLite.f paramf, Object<AdmParametersOuterClass$AdmParameters> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic com/fyber/inneractive/sdk/bidder/adm/a.a : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 444, 2 -> 436, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters
    //   77: monitorenter
    //   78: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
    //   91: dup
    //   92: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters;
    //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
    //   103: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters;
    //   119: areturn
    //   120: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters;
    //   123: ldc_w ' ) ))  ለ ለለဋဋለ\\f\\b\\f\\tဃ\\nဃለ\\b\\fဃ\\t\\rင\\n\\fለለ\\fለ\\rለဌለለဇለለဋለဉကለለለ ဉ!"ဃ#ဌ$ለ%ለ &ဉ!'ဇ"(ለ#)ဇ$'
    //   126: bipush #44
    //   128: anewarray java/lang/Object
    //   131: dup
    //   132: iconst_0
    //   133: ldc_w 'bitField0_'
    //   136: aastore
    //   137: dup
    //   138: iconst_1
    //   139: ldc_w 'bitField1_'
    //   142: aastore
    //   143: dup
    //   144: iconst_2
    //   145: ldc_w 'markupUrl_'
    //   148: aastore
    //   149: dup
    //   150: iconst_3
    //   151: ldc_w 'sessionId_'
    //   154: aastore
    //   155: dup
    //   156: iconst_4
    //   157: ldc_w 'errorMessage_'
    //   160: aastore
    //   161: dup
    //   162: iconst_5
    //   163: ldc_w 'adWidth_'
    //   166: aastore
    //   167: dup
    //   168: bipush #6
    //   170: ldc_w 'adHeight_'
    //   173: aastore
    //   174: dup
    //   175: bipush #7
    //   177: ldc_w 'adUnitId_'
    //   180: aastore
    //   181: dup
    //   182: bipush #8
    //   184: ldc_w 'adUnitType_'
    //   187: aastore
    //   188: dup
    //   189: bipush #9
    //   191: ldc_w 'adUnitDisplayType_'
    //   194: aastore
    //   195: dup
    //   196: bipush #10
    //   198: ldc_w 'contentId_'
    //   201: aastore
    //   202: dup
    //   203: bipush #11
    //   205: ldc_w 'publisherId_'
    //   208: aastore
    //   209: dup
    //   210: bipush #12
    //   212: ldc_w 'adNetworkName_'
    //   215: aastore
    //   216: dup
    //   217: bipush #13
    //   219: ldc_w 'adNetworkId_'
    //   222: aastore
    //   223: dup
    //   224: bipush #14
    //   226: ldc_w 'adExpirationInterval_'
    //   229: aastore
    //   230: dup
    //   231: bipush #15
    //   233: ldc_w 'adType_'
    //   236: aastore
    //   237: dup
    //   238: bipush #16
    //   240: ldc_w 'sdkImpressionUrl_'
    //   243: aastore
    //   244: dup
    //   245: bipush #17
    //   247: ldc_w 'sdkClickUrl_'
    //   250: aastore
    //   251: dup
    //   252: bipush #18
    //   254: ldc_w 'storeUrl_'
    //   257: aastore
    //   258: dup
    //   259: bipush #19
    //   261: ldc_w 'advertisedAppId_'
    //   264: aastore
    //   265: dup
    //   266: bipush #20
    //   268: ldc_w 'storeUrlType_'
    //   271: aastore
    //   272: dup
    //   273: bipush #21
    //   275: ldc_w 'storeEventUrl_'
    //   278: aastore
    //   279: dup
    //   280: bipush #22
    //   282: ldc_w 'storeCTAText_'
    //   285: aastore
    //   286: dup
    //   287: bipush #23
    //   289: ldc_w 'skipMode_'
    //   292: aastore
    //   293: dup
    //   294: bipush #24
    //   296: ldc_w 'appBundleId_'
    //   299: aastore
    //   300: dup
    //   301: bipush #25
    //   303: ldc_w 'adCompletionUrl_'
    //   306: aastore
    //   307: dup
    //   308: bipush #26
    //   310: ldc_w 'adDuration_'
    //   313: aastore
    //   314: dup
    //   315: bipush #27
    //   317: ldc_w 'creativeType_'
    //   320: aastore
    //   321: dup
    //   322: bipush #28
    //   324: ldc_w 'skAdNetworkData_'
    //   327: aastore
    //   328: dup
    //   329: bipush #29
    //   331: ldc_w 'pricingValue_'
    //   334: aastore
    //   335: dup
    //   336: bipush #30
    //   338: ldc_w 'adDomain_'
    //   341: aastore
    //   342: dup
    //   343: bipush #31
    //   345: ldc_w 'creativeId_'
    //   348: aastore
    //   349: dup
    //   350: bipush #32
    //   352: ldc_w 'campaignId_'
    //   355: aastore
    //   356: dup
    //   357: bipush #33
    //   359: ldc_w 'mrcData_'
    //   362: aastore
    //   363: dup
    //   364: bipush #34
    //   366: ldc_w 'abExperiments_'
    //   369: aastore
    //   370: dup
    //   371: bipush #35
    //   373: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment
    //   375: aastore
    //   376: dup
    //   377: bipush #36
    //   379: ldc_w 'spotId_'
    //   382: aastore
    //   383: dup
    //   384: bipush #37
    //   386: ldc_w 'igniteMode_'
    //   389: aastore
    //   390: dup
    //   391: bipush #38
    //   393: ldc_w 'igniteInstallUrl_'
    //   396: aastore
    //   397: dup
    //   398: bipush #39
    //   400: ldc_w 'igniteLauncherActivity_'
    //   403: aastore
    //   404: dup
    //   405: bipush #40
    //   407: ldc_w 'skOverlayData_'
    //   410: aastore
    //   411: dup
    //   412: bipush #41
    //   414: ldc_w 'brandBidderDontShowEndcard_'
    //   417: aastore
    //   418: dup
    //   419: bipush #42
    //   421: ldc_w 'brandBidderCtaText_'
    //   424: aastore
    //   425: dup
    //   426: bipush #43
    //   428: ldc_w 'mraidVideoOMSignal_'
    //   431: aastore
    //   432: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   435: areturn
    //   436: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$c
    //   439: dup
    //   440: invokespecial <init> : ()V
    //   443: areturn
    //   444: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters
    //   447: dup
    //   448: invokespecial <init> : ()V
    //   451: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public Experiment getAbExperiments(int paramInt) {
    return this.abExperiments_.get(paramInt);
  }
  
  public int getAbExperimentsCount() {
    return this.abExperiments_.size();
  }
  
  public List<Experiment> getAbExperimentsList() {
    return (List<Experiment>)this.abExperiments_;
  }
  
  public e getAbExperimentsOrBuilder(int paramInt) {
    return this.abExperiments_.get(paramInt);
  }
  
  public List<? extends e> getAbExperimentsOrBuilderList() {
    return (List)this.abExperiments_;
  }
  
  public String getAdCompletionUrl() {
    return this.adCompletionUrl_;
  }
  
  public i getAdCompletionUrlBytes() {
    return i.a(this.adCompletionUrl_);
  }
  
  public String getAdDomain() {
    return this.adDomain_;
  }
  
  public i getAdDomainBytes() {
    return i.a(this.adDomain_);
  }
  
  public int getAdDuration() {
    return this.adDuration_;
  }
  
  public int getAdExpirationInterval() {
    return this.adExpirationInterval_;
  }
  
  public int getAdHeight() {
    return this.adHeight_;
  }
  
  public long getAdNetworkId() {
    return this.adNetworkId_;
  }
  
  public String getAdNetworkName() {
    return this.adNetworkName_;
  }
  
  public i getAdNetworkNameBytes() {
    return i.a(this.adNetworkName_);
  }
  
  public a getAdType() {
    a a2 = a.a(this.adType_);
    a a1 = a2;
    if (a2 == null)
      a1 = a.UNRECOGNIZED; 
    return a1;
  }
  
  public int getAdTypeValue() {
    return this.adType_;
  }
  
  public g getAdUnitDisplayType() {
    g g2 = g.a(this.adUnitDisplayType_);
    g g1 = g2;
    if (g2 == null)
      g1 = g.UNRECOGNIZED; 
    return g1;
  }
  
  public int getAdUnitDisplayTypeValue() {
    return this.adUnitDisplayType_;
  }
  
  public String getAdUnitId() {
    return this.adUnitId_;
  }
  
  public i getAdUnitIdBytes() {
    return i.a(this.adUnitId_);
  }
  
  public b getAdUnitType() {
    b b2 = b.a(this.adUnitType_);
    b b1 = b2;
    if (b2 == null)
      b1 = b.UNRECOGNIZED; 
    return b1;
  }
  
  public int getAdUnitTypeValue() {
    return this.adUnitType_;
  }
  
  public int getAdWidth() {
    return this.adWidth_;
  }
  
  public String getAdvertisedAppId() {
    return this.advertisedAppId_;
  }
  
  public i getAdvertisedAppIdBytes() {
    return i.a(this.advertisedAppId_);
  }
  
  public String getAppBundleId() {
    return this.appBundleId_;
  }
  
  public i getAppBundleIdBytes() {
    return i.a(this.appBundleId_);
  }
  
  public String getBrandBidderCtaText() {
    return this.brandBidderCtaText_;
  }
  
  public i getBrandBidderCtaTextBytes() {
    return i.a(this.brandBidderCtaText_);
  }
  
  public boolean getBrandBidderDontShowEndcard() {
    return this.brandBidderDontShowEndcard_;
  }
  
  public String getCampaignId() {
    return this.campaignId_;
  }
  
  public i getCampaignIdBytes() {
    return i.a(this.campaignId_);
  }
  
  public long getContentId() {
    return this.contentId_;
  }
  
  public String getCreativeId() {
    return this.creativeId_;
  }
  
  public i getCreativeIdBytes() {
    return i.a(this.creativeId_);
  }
  
  public String getCreativeType() {
    return this.creativeType_;
  }
  
  public i getCreativeTypeBytes() {
    return i.a(this.creativeType_);
  }
  
  public String getErrorMessage() {
    return this.errorMessage_;
  }
  
  public i getErrorMessageBytes() {
    return i.a(this.errorMessage_);
  }
  
  public String getIgniteInstallUrl() {
    return this.igniteInstallUrl_;
  }
  
  public i getIgniteInstallUrlBytes() {
    return i.a(this.igniteInstallUrl_);
  }
  
  public String getIgniteLauncherActivity() {
    return this.igniteLauncherActivity_;
  }
  
  public i getIgniteLauncherActivityBytes() {
    return i.a(this.igniteLauncherActivity_);
  }
  
  public f getIgniteMode() {
    f f2 = f.a(this.igniteMode_);
    f f1 = f2;
    if (f2 == null)
      f1 = f.UNRECOGNIZED; 
    return f1;
  }
  
  public int getIgniteModeValue() {
    return this.igniteMode_;
  }
  
  public String getMarkupUrl() {
    return this.markupUrl_;
  }
  
  public i getMarkupUrlBytes() {
    return i.a(this.markupUrl_);
  }
  
  public boolean getMraidVideoOMSignal() {
    return this.mraidVideoOMSignal_;
  }
  
  public MRCData getMrcData() {
    MRCData mRCData2 = this.mrcData_;
    MRCData mRCData1 = mRCData2;
    if (mRCData2 == null)
      mRCData1 = MRCData.getDefaultInstance(); 
    return mRCData1;
  }
  
  public double getPricingValue() {
    return this.pricingValue_;
  }
  
  public long getPublisherId() {
    return this.publisherId_;
  }
  
  public String getSdkClickUrl() {
    return this.sdkClickUrl_;
  }
  
  public i getSdkClickUrlBytes() {
    return i.a(this.sdkClickUrl_);
  }
  
  public String getSdkImpressionUrl() {
    return this.sdkImpressionUrl_;
  }
  
  public i getSdkImpressionUrlBytes() {
    return i.a(this.sdkImpressionUrl_);
  }
  
  public String getSessionId() {
    return this.sessionId_;
  }
  
  public i getSessionIdBytes() {
    return i.a(this.sessionId_);
  }
  
  public SKAdNetworkData getSkAdNetworkData() {
    SKAdNetworkData sKAdNetworkData2 = this.skAdNetworkData_;
    SKAdNetworkData sKAdNetworkData1 = sKAdNetworkData2;
    if (sKAdNetworkData2 == null)
      sKAdNetworkData1 = SKAdNetworkData.getDefaultInstance(); 
    return sKAdNetworkData1;
  }
  
  public SKOverlayData getSkOverlayData() {
    SKOverlayData sKOverlayData2 = this.skOverlayData_;
    SKOverlayData sKOverlayData1 = sKOverlayData2;
    if (sKOverlayData2 == null)
      sKOverlayData1 = SKOverlayData.getDefaultInstance(); 
    return sKOverlayData1;
  }
  
  public boolean getSkipMode() {
    return this.skipMode_;
  }
  
  public long getSpotId() {
    return this.spotId_;
  }
  
  public String getStoreCTAText() {
    return this.storeCTAText_;
  }
  
  public i getStoreCTATextBytes() {
    return i.a(this.storeCTAText_);
  }
  
  public String getStoreEventUrl() {
    return this.storeEventUrl_;
  }
  
  public i getStoreEventUrlBytes() {
    return i.a(this.storeEventUrl_);
  }
  
  public String getStoreUrl() {
    return this.storeUrl_;
  }
  
  public i getStoreUrlBytes() {
    return i.a(this.storeUrl_);
  }
  
  public d getStoreUrlType() {
    d d1;
    int i = this.storeUrlType_;
    if (i != 0) {
      if (i != 1) {
        d1 = null;
      } else {
        d1 = d.AUTOMATIC;
      } 
    } else {
      d1 = d.MANUAL;
    } 
    d d2 = d1;
    if (d1 == null)
      d2 = d.UNRECOGNIZED; 
    return d2;
  }
  
  public int getStoreUrlTypeValue() {
    return this.storeUrlType_;
  }
  
  public boolean hasAdCompletionUrl() {
    return ((this.bitField0_ & 0x100000) != 0);
  }
  
  public boolean hasAdDomain() {
    return ((this.bitField0_ & 0x2000000) != 0);
  }
  
  public boolean hasAdDuration() {
    return ((this.bitField0_ & 0x200000) != 0);
  }
  
  public boolean hasAdExpirationInterval() {
    return ((this.bitField0_ & 0x400) != 0);
  }
  
  public boolean hasAdHeight() {
    return ((this.bitField0_ & 0x10) != 0);
  }
  
  public boolean hasAdNetworkId() {
    return ((this.bitField0_ & 0x200) != 0);
  }
  
  public boolean hasAdNetworkName() {
    return ((this.bitField0_ & 0x100) != 0);
  }
  
  public boolean hasAdUnitId() {
    return ((this.bitField0_ & 0x20) != 0);
  }
  
  public boolean hasAdWidth() {
    return ((this.bitField0_ & 0x8) != 0);
  }
  
  public boolean hasAdvertisedAppId() {
    return ((this.bitField0_ & 0x4000) != 0);
  }
  
  public boolean hasAppBundleId() {
    return ((this.bitField0_ & 0x80000) != 0);
  }
  
  public boolean hasBrandBidderCtaText() {
    return ((this.bitField1_ & 0x8) != 0);
  }
  
  public boolean hasBrandBidderDontShowEndcard() {
    return ((this.bitField1_ & 0x4) != 0);
  }
  
  public boolean hasCampaignId() {
    return ((this.bitField0_ & 0x8000000) != 0);
  }
  
  public boolean hasContentId() {
    return ((this.bitField0_ & 0x40) != 0);
  }
  
  public boolean hasCreativeId() {
    return ((this.bitField0_ & 0x4000000) != 0);
  }
  
  public boolean hasCreativeType() {
    return ((this.bitField0_ & 0x400000) != 0);
  }
  
  public boolean hasErrorMessage() {
    return ((this.bitField0_ & 0x4) != 0);
  }
  
  public boolean hasIgniteInstallUrl() {
    return ((this.bitField0_ & Integer.MIN_VALUE) != 0);
  }
  
  public boolean hasIgniteLauncherActivity() {
    return ((this.bitField1_ & 0x1) != 0);
  }
  
  public boolean hasIgniteMode() {
    return ((this.bitField0_ & 0x40000000) != 0);
  }
  
  public boolean hasMarkupUrl() {
    return ((this.bitField0_ & 0x1) != 0);
  }
  
  public boolean hasMraidVideoOMSignal() {
    return ((this.bitField1_ & 0x10) != 0);
  }
  
  public boolean hasMrcData() {
    return ((this.bitField0_ & 0x10000000) != 0);
  }
  
  public boolean hasPricingValue() {
    return ((this.bitField0_ & 0x1000000) != 0);
  }
  
  public boolean hasPublisherId() {
    return ((this.bitField0_ & 0x80) != 0);
  }
  
  public boolean hasSdkClickUrl() {
    return ((this.bitField0_ & 0x1000) != 0);
  }
  
  public boolean hasSdkImpressionUrl() {
    return ((this.bitField0_ & 0x800) != 0);
  }
  
  public boolean hasSessionId() {
    return ((this.bitField0_ & 0x2) != 0);
  }
  
  public boolean hasSkAdNetworkData() {
    return ((this.bitField0_ & 0x800000) != 0);
  }
  
  public boolean hasSkOverlayData() {
    return ((this.bitField1_ & 0x2) != 0);
  }
  
  public boolean hasSkipMode() {
    return ((this.bitField0_ & 0x40000) != 0);
  }
  
  public boolean hasSpotId() {
    return ((this.bitField0_ & 0x20000000) != 0);
  }
  
  public boolean hasStoreCTAText() {
    return ((this.bitField0_ & 0x20000) != 0);
  }
  
  public boolean hasStoreEventUrl() {
    return ((this.bitField0_ & 0x10000) != 0);
  }
  
  public boolean hasStoreUrl() {
    return ((this.bitField0_ & 0x2000) != 0);
  }
  
  public boolean hasStoreUrlType() {
    return ((this.bitField0_ & 0x8000) != 0);
  }
  
  public static final class Experiment extends GeneratedMessageLite<Experiment, Experiment.a> implements e {
    private static final Experiment DEFAULT_INSTANCE;
    
    public static final int IDENTIFIER_FIELD_NUMBER = 1;
    
    private static volatile w0<Experiment> PARSER;
    
    public static final int VARIANT_FIELD_NUMBER = 2;
    
    private int bitField0_;
    
    private String identifier_ = "";
    
    private String variant_ = "";
    
    static {
      Experiment experiment = new Experiment();
      DEFAULT_INSTANCE = experiment;
      GeneratedMessageLite.registerDefaultInstance(Experiment.class, experiment);
    }
    
    private void clearIdentifier() {
      this.bitField0_ &= 0xFFFFFFFE;
      this.identifier_ = getDefaultInstance().getIdentifier();
    }
    
    private void clearVariant() {
      this.bitField0_ &= 0xFFFFFFFD;
      this.variant_ = getDefaultInstance().getVariant();
    }
    
    public static Experiment getDefaultInstance() {
      return DEFAULT_INSTANCE;
    }
    
    public static a newBuilder() {
      return (a)DEFAULT_INSTANCE.createBuilder();
    }
    
    public static a newBuilder(Experiment param1Experiment) {
      return (a)DEFAULT_INSTANCE.createBuilder(param1Experiment);
    }
    
    public static Experiment parseDelimitedFrom(InputStream param1InputStream) throws IOException {
      return (Experiment)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static Experiment parseDelimitedFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (Experiment)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static Experiment parseFrom(i param1i) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i);
    }
    
    public static Experiment parseFrom(i param1i, q param1q) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i, param1q);
    }
    
    public static Experiment parseFrom(j param1j) throws IOException {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j);
    }
    
    public static Experiment parseFrom(j param1j, q param1q) throws IOException {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j, param1q);
    }
    
    public static Experiment parseFrom(InputStream param1InputStream) throws IOException {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static Experiment parseFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static Experiment parseFrom(ByteBuffer param1ByteBuffer) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer);
    }
    
    public static Experiment parseFrom(ByteBuffer param1ByteBuffer, q param1q) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer, param1q);
    }
    
    public static Experiment parseFrom(byte[] param1ArrayOfbyte) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte);
    }
    
    public static Experiment parseFrom(byte[] param1ArrayOfbyte, q param1q) throws z {
      return (Experiment)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte, param1q);
    }
    
    public static w0<Experiment> parser() {
      return DEFAULT_INSTANCE.getParserForType();
    }
    
    private void setIdentifier(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x1;
      this.identifier_ = param1String;
    }
    
    private void setIdentifierBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.identifier_ = param1i.i();
      this.bitField0_ |= 0x1;
    }
    
    private void setVariant(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x2;
      this.variant_ = param1String;
    }
    
    private void setVariantBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.variant_ = param1i.i();
      this.bitField0_ |= 0x2;
    }
    
    public final Object dynamicMethod(GeneratedMessageLite.f param1f, Object<Experiment> param1Object1, Object param1Object2) {
      // Byte code:
      //   0: getstatic com/fyber/inneractive/sdk/bidder/adm/a.a : [I
      //   3: aload_1
      //   4: invokevirtual ordinal : ()I
      //   7: iaload
      //   8: tableswitch default -> 52, 1 -> 156, 2 -> 148, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
      //   52: new java/lang/UnsupportedOperationException
      //   55: dup
      //   56: invokespecial <init> : ()V
      //   59: athrow
      //   60: aconst_null
      //   61: areturn
      //   62: iconst_1
      //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
      //   66: areturn
      //   67: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   70: astore_1
      //   71: aload_1
      //   72: ifnonnull -> 114
      //   75: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment
      //   77: monitorenter
      //   78: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   81: astore_2
      //   82: aload_2
      //   83: astore_1
      //   84: aload_2
      //   85: ifnonnull -> 103
      //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
      //   91: dup
      //   92: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment;
      //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
      //   98: astore_1
      //   99: aload_1
      //   100: putstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   103: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment
      //   105: monitorexit
      //   106: aload_1
      //   107: areturn
      //   108: astore_1
      //   109: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment
      //   111: monitorexit
      //   112: aload_1
      //   113: athrow
      //   114: aload_1
      //   115: areturn
      //   116: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment;
      //   119: areturn
      //   120: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment;
      //   123: ldc '     ለ ለ'
      //   125: iconst_3
      //   126: anewarray java/lang/Object
      //   129: dup
      //   130: iconst_0
      //   131: ldc 'bitField0_'
      //   133: aastore
      //   134: dup
      //   135: iconst_1
      //   136: ldc 'identifier_'
      //   138: aastore
      //   139: dup
      //   140: iconst_2
      //   141: ldc 'variant_'
      //   143: aastore
      //   144: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
      //   147: areturn
      //   148: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment$a
      //   151: dup
      //   152: invokespecial <init> : ()V
      //   155: areturn
      //   156: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$Experiment
      //   159: dup
      //   160: invokespecial <init> : ()V
      //   163: areturn
      // Exception table:
      //   from	to	target	type
      //   78	82	108	finally
      //   88	103	108	finally
      //   103	106	108	finally
      //   109	112	108	finally
    }
    
    public String getIdentifier() {
      return this.identifier_;
    }
    
    public i getIdentifierBytes() {
      return i.a(this.identifier_);
    }
    
    public String getVariant() {
      return this.variant_;
    }
    
    public i getVariantBytes() {
      return i.a(this.variant_);
    }
    
    public boolean hasIdentifier() {
      return ((this.bitField0_ & 0x1) != 0);
    }
    
    public boolean hasVariant() {
      return ((this.bitField0_ & 0x2) != 0);
    }
    
    public static final class a extends GeneratedMessageLite.b<Experiment, a> implements AdmParametersOuterClass$AdmParameters.e {
      public a() {
        super(AdmParametersOuterClass$AdmParameters.Experiment.DEFAULT_INSTANCE);
      }
    }
  }
  
  public static final class a extends GeneratedMessageLite.b<Experiment, Experiment.a> implements e {
    public a() {
      super(AdmParametersOuterClass$AdmParameters.Experiment.DEFAULT_INSTANCE);
    }
  }
  
  public static final class MRCData extends GeneratedMessageLite<MRCData, MRCData.a> {
    private static final MRCData DEFAULT_INSTANCE;
    
    private static volatile w0<MRCData> PARSER;
    
    public static final int PIXELDURATION_FIELD_NUMBER = 2;
    
    public static final int PIXELIMPRESSIONURL_FIELD_NUMBER = 3;
    
    public static final int PIXELPERCENT_FIELD_NUMBER = 1;
    
    private int bitField0_;
    
    private int pixelDuration_;
    
    private String pixelImpressionUrl_ = "";
    
    private int pixelPercent_;
    
    static {
      MRCData mRCData = new MRCData();
      DEFAULT_INSTANCE = mRCData;
      GeneratedMessageLite.registerDefaultInstance(MRCData.class, mRCData);
    }
    
    private void clearPixelDuration() {
      this.bitField0_ &= 0xFFFFFFFD;
      this.pixelDuration_ = 0;
    }
    
    private void clearPixelImpressionUrl() {
      this.bitField0_ &= 0xFFFFFFFB;
      this.pixelImpressionUrl_ = getDefaultInstance().getPixelImpressionUrl();
    }
    
    private void clearPixelPercent() {
      this.bitField0_ &= 0xFFFFFFFE;
      this.pixelPercent_ = 0;
    }
    
    public static MRCData getDefaultInstance() {
      return DEFAULT_INSTANCE;
    }
    
    public static a newBuilder() {
      return (a)DEFAULT_INSTANCE.createBuilder();
    }
    
    public static a newBuilder(MRCData param1MRCData) {
      return (a)DEFAULT_INSTANCE.createBuilder(param1MRCData);
    }
    
    public static MRCData parseDelimitedFrom(InputStream param1InputStream) throws IOException {
      return (MRCData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static MRCData parseDelimitedFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (MRCData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static MRCData parseFrom(i param1i) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i);
    }
    
    public static MRCData parseFrom(i param1i, q param1q) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i, param1q);
    }
    
    public static MRCData parseFrom(j param1j) throws IOException {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j);
    }
    
    public static MRCData parseFrom(j param1j, q param1q) throws IOException {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j, param1q);
    }
    
    public static MRCData parseFrom(InputStream param1InputStream) throws IOException {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static MRCData parseFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static MRCData parseFrom(ByteBuffer param1ByteBuffer) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer);
    }
    
    public static MRCData parseFrom(ByteBuffer param1ByteBuffer, q param1q) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer, param1q);
    }
    
    public static MRCData parseFrom(byte[] param1ArrayOfbyte) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte);
    }
    
    public static MRCData parseFrom(byte[] param1ArrayOfbyte, q param1q) throws z {
      return (MRCData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte, param1q);
    }
    
    public static w0<MRCData> parser() {
      return DEFAULT_INSTANCE.getParserForType();
    }
    
    private void setPixelDuration(int param1Int) {
      this.bitField0_ |= 0x2;
      this.pixelDuration_ = param1Int;
    }
    
    private void setPixelImpressionUrl(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x4;
      this.pixelImpressionUrl_ = param1String;
    }
    
    private void setPixelImpressionUrlBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.pixelImpressionUrl_ = param1i.i();
      this.bitField0_ |= 0x4;
    }
    
    private void setPixelPercent(int param1Int) {
      this.bitField0_ |= 0x1;
      this.pixelPercent_ = param1Int;
    }
    
    public final Object dynamicMethod(GeneratedMessageLite.f param1f, Object<MRCData> param1Object1, Object param1Object2) {
      // Byte code:
      //   0: getstatic com/fyber/inneractive/sdk/bidder/adm/a.a : [I
      //   3: aload_1
      //   4: invokevirtual ordinal : ()I
      //   7: iaload
      //   8: tableswitch default -> 52, 1 -> 161, 2 -> 153, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
      //   52: new java/lang/UnsupportedOperationException
      //   55: dup
      //   56: invokespecial <init> : ()V
      //   59: athrow
      //   60: aconst_null
      //   61: areturn
      //   62: iconst_1
      //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
      //   66: areturn
      //   67: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   70: astore_1
      //   71: aload_1
      //   72: ifnonnull -> 114
      //   75: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData
      //   77: monitorenter
      //   78: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   81: astore_2
      //   82: aload_2
      //   83: astore_1
      //   84: aload_2
      //   85: ifnonnull -> 103
      //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
      //   91: dup
      //   92: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData;
      //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
      //   98: astore_1
      //   99: aload_1
      //   100: putstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   103: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData
      //   105: monitorexit
      //   106: aload_1
      //   107: areturn
      //   108: astore_1
      //   109: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData
      //   111: monitorexit
      //   112: aload_1
      //   113: athrow
      //   114: aload_1
      //   115: areturn
      //   116: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData;
      //   119: areturn
      //   120: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData;
      //   123: ldc '     ဋ ဋለ'
      //   125: iconst_4
      //   126: anewarray java/lang/Object
      //   129: dup
      //   130: iconst_0
      //   131: ldc 'bitField0_'
      //   133: aastore
      //   134: dup
      //   135: iconst_1
      //   136: ldc 'pixelPercent_'
      //   138: aastore
      //   139: dup
      //   140: iconst_2
      //   141: ldc 'pixelDuration_'
      //   143: aastore
      //   144: dup
      //   145: iconst_3
      //   146: ldc 'pixelImpressionUrl_'
      //   148: aastore
      //   149: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
      //   152: areturn
      //   153: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData$a
      //   156: dup
      //   157: invokespecial <init> : ()V
      //   160: areturn
      //   161: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$MRCData
      //   164: dup
      //   165: invokespecial <init> : ()V
      //   168: areturn
      // Exception table:
      //   from	to	target	type
      //   78	82	108	finally
      //   88	103	108	finally
      //   103	106	108	finally
      //   109	112	108	finally
    }
    
    public int getPixelDuration() {
      return this.pixelDuration_;
    }
    
    public String getPixelImpressionUrl() {
      return this.pixelImpressionUrl_;
    }
    
    public i getPixelImpressionUrlBytes() {
      return i.a(this.pixelImpressionUrl_);
    }
    
    public int getPixelPercent() {
      return this.pixelPercent_;
    }
    
    public boolean hasPixelDuration() {
      return ((this.bitField0_ & 0x2) != 0);
    }
    
    public boolean hasPixelImpressionUrl() {
      return ((this.bitField0_ & 0x4) != 0);
    }
    
    public boolean hasPixelPercent() {
      return ((this.bitField0_ & 0x1) != 0);
    }
    
    public static final class a extends GeneratedMessageLite.b<MRCData, a> {
      public a() {
        super(AdmParametersOuterClass$AdmParameters.MRCData.DEFAULT_INSTANCE);
      }
    }
  }
  
  public static final class a extends GeneratedMessageLite.b<MRCData, MRCData.a> {
    public a() {
      super(AdmParametersOuterClass$AdmParameters.MRCData.DEFAULT_INSTANCE);
    }
  }
  
  public static final class SKAdNetworkData extends GeneratedMessageLite<SKAdNetworkData, SKAdNetworkData.a> {
    private static final SKAdNetworkData DEFAULT_INSTANCE;
    
    private static volatile w0<SKAdNetworkData> PARSER;
    
    public static final int SKADNBUNDLE_FIELD_NUMBER = 4;
    
    public static final int SKADNCAMPIGN_FIELD_NUMBER = 3;
    
    public static final int SKADNETWORKID_FIELD_NUMBER = 2;
    
    public static final int SKADNID_FIELD_NUMBER = 5;
    
    public static final int SKADNIMPID_FIELD_NUMBER = 6;
    
    public static final int SKADNIMPSIGNATURE_FIELD_NUMBER = 10;
    
    public static final int SKADNIMPTIMESTAMP_FIELD_NUMBER = 9;
    
    public static final int SKADNSIGNATURE_FIELD_NUMBER = 11;
    
    public static final int SKADNSOURCEAPP_FIELD_NUMBER = 7;
    
    public static final int SKADNTIMESTAMP_FIELD_NUMBER = 8;
    
    public static final int SKADNVERSION_FIELD_NUMBER = 1;
    
    private int bitField0_;
    
    private String skAdNetworkId_ = "";
    
    private String skAdnBundle_ = "";
    
    private String skAdnCampign_ = "";
    
    private String skAdnId_ = "";
    
    private String skAdnImpId_ = "";
    
    private String skAdnImpSignature_ = "";
    
    private long skAdnImpTimestamp_;
    
    private String skAdnSignature_ = "";
    
    private long skAdnSourceApp_;
    
    private long skAdnTimestamp_;
    
    private String skAdnVersion_ = "";
    
    static {
      SKAdNetworkData sKAdNetworkData = new SKAdNetworkData();
      DEFAULT_INSTANCE = sKAdNetworkData;
      GeneratedMessageLite.registerDefaultInstance(SKAdNetworkData.class, sKAdNetworkData);
    }
    
    private void clearSkAdNetworkId() {
      this.bitField0_ &= 0xFFFFFFFD;
      this.skAdNetworkId_ = getDefaultInstance().getSkAdNetworkId();
    }
    
    private void clearSkAdnBundle() {
      this.bitField0_ &= 0xFFFFFFF7;
      this.skAdnBundle_ = getDefaultInstance().getSkAdnBundle();
    }
    
    private void clearSkAdnCampign() {
      this.bitField0_ &= 0xFFFFFFFB;
      this.skAdnCampign_ = getDefaultInstance().getSkAdnCampign();
    }
    
    private void clearSkAdnId() {
      this.bitField0_ &= 0xFFFFFFEF;
      this.skAdnId_ = getDefaultInstance().getSkAdnId();
    }
    
    private void clearSkAdnImpId() {
      this.bitField0_ &= 0xFFFFFFDF;
      this.skAdnImpId_ = getDefaultInstance().getSkAdnImpId();
    }
    
    private void clearSkAdnImpSignature() {
      this.bitField0_ &= 0xFFFFFDFF;
      this.skAdnImpSignature_ = getDefaultInstance().getSkAdnImpSignature();
    }
    
    private void clearSkAdnImpTimestamp() {
      this.bitField0_ &= 0xFFFFFEFF;
      this.skAdnImpTimestamp_ = 0L;
    }
    
    private void clearSkAdnSignature() {
      this.bitField0_ &= 0xFFFFFBFF;
      this.skAdnSignature_ = getDefaultInstance().getSkAdnSignature();
    }
    
    private void clearSkAdnSourceApp() {
      this.bitField0_ &= 0xFFFFFFBF;
      this.skAdnSourceApp_ = 0L;
    }
    
    private void clearSkAdnTimestamp() {
      this.bitField0_ &= 0xFFFFFF7F;
      this.skAdnTimestamp_ = 0L;
    }
    
    private void clearSkAdnVersion() {
      this.bitField0_ &= 0xFFFFFFFE;
      this.skAdnVersion_ = getDefaultInstance().getSkAdnVersion();
    }
    
    public static SKAdNetworkData getDefaultInstance() {
      return DEFAULT_INSTANCE;
    }
    
    public static a newBuilder() {
      return (a)DEFAULT_INSTANCE.createBuilder();
    }
    
    public static a newBuilder(SKAdNetworkData param1SKAdNetworkData) {
      return (a)DEFAULT_INSTANCE.createBuilder(param1SKAdNetworkData);
    }
    
    public static SKAdNetworkData parseDelimitedFrom(InputStream param1InputStream) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static SKAdNetworkData parseDelimitedFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static SKAdNetworkData parseFrom(i param1i) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i);
    }
    
    public static SKAdNetworkData parseFrom(i param1i, q param1q) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i, param1q);
    }
    
    public static SKAdNetworkData parseFrom(j param1j) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j);
    }
    
    public static SKAdNetworkData parseFrom(j param1j, q param1q) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j, param1q);
    }
    
    public static SKAdNetworkData parseFrom(InputStream param1InputStream) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static SKAdNetworkData parseFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static SKAdNetworkData parseFrom(ByteBuffer param1ByteBuffer) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer);
    }
    
    public static SKAdNetworkData parseFrom(ByteBuffer param1ByteBuffer, q param1q) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer, param1q);
    }
    
    public static SKAdNetworkData parseFrom(byte[] param1ArrayOfbyte) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte);
    }
    
    public static SKAdNetworkData parseFrom(byte[] param1ArrayOfbyte, q param1q) throws z {
      return (SKAdNetworkData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte, param1q);
    }
    
    public static w0<SKAdNetworkData> parser() {
      return DEFAULT_INSTANCE.getParserForType();
    }
    
    private void setSkAdNetworkId(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x2;
      this.skAdNetworkId_ = param1String;
    }
    
    private void setSkAdNetworkIdBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdNetworkId_ = param1i.i();
      this.bitField0_ |= 0x2;
    }
    
    private void setSkAdnBundle(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x8;
      this.skAdnBundle_ = param1String;
    }
    
    private void setSkAdnBundleBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnBundle_ = param1i.i();
      this.bitField0_ |= 0x8;
    }
    
    private void setSkAdnCampign(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x4;
      this.skAdnCampign_ = param1String;
    }
    
    private void setSkAdnCampignBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnCampign_ = param1i.i();
      this.bitField0_ |= 0x4;
    }
    
    private void setSkAdnId(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x10;
      this.skAdnId_ = param1String;
    }
    
    private void setSkAdnIdBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnId_ = param1i.i();
      this.bitField0_ |= 0x10;
    }
    
    private void setSkAdnImpId(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x20;
      this.skAdnImpId_ = param1String;
    }
    
    private void setSkAdnImpIdBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnImpId_ = param1i.i();
      this.bitField0_ |= 0x20;
    }
    
    private void setSkAdnImpSignature(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x200;
      this.skAdnImpSignature_ = param1String;
    }
    
    private void setSkAdnImpSignatureBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnImpSignature_ = param1i.i();
      this.bitField0_ |= 0x200;
    }
    
    private void setSkAdnImpTimestamp(long param1Long) {
      this.bitField0_ |= 0x100;
      this.skAdnImpTimestamp_ = param1Long;
    }
    
    private void setSkAdnSignature(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x400;
      this.skAdnSignature_ = param1String;
    }
    
    private void setSkAdnSignatureBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnSignature_ = param1i.i();
      this.bitField0_ |= 0x400;
    }
    
    private void setSkAdnSourceApp(long param1Long) {
      this.bitField0_ |= 0x40;
      this.skAdnSourceApp_ = param1Long;
    }
    
    private void setSkAdnTimestamp(long param1Long) {
      this.bitField0_ |= 0x80;
      this.skAdnTimestamp_ = param1Long;
    }
    
    private void setSkAdnVersion(String param1String) {
      param1String.getClass();
      this.bitField0_ |= 0x1;
      this.skAdnVersion_ = param1String;
    }
    
    private void setSkAdnVersionBytes(i param1i) {
      com.fyber.inneractive.sdk.protobuf.a.checkByteStringIsUtf8(param1i);
      this.skAdnVersion_ = param1i.i();
      this.bitField0_ |= 0x1;
    }
    
    public final Object dynamicMethod(GeneratedMessageLite.f param1f, Object<SKAdNetworkData> param1Object1, Object param1Object2) {
      // Byte code:
      //   0: getstatic com/fyber/inneractive/sdk/bidder/adm/a.a : [I
      //   3: aload_1
      //   4: invokevirtual ordinal : ()I
      //   7: iaload
      //   8: tableswitch default -> 52, 1 -> 221, 2 -> 213, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
      //   52: new java/lang/UnsupportedOperationException
      //   55: dup
      //   56: invokespecial <init> : ()V
      //   59: athrow
      //   60: aconst_null
      //   61: areturn
      //   62: iconst_1
      //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
      //   66: areturn
      //   67: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   70: astore_1
      //   71: aload_1
      //   72: ifnonnull -> 114
      //   75: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData
      //   77: monitorenter
      //   78: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   81: astore_2
      //   82: aload_2
      //   83: astore_1
      //   84: aload_2
      //   85: ifnonnull -> 103
      //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
      //   91: dup
      //   92: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData;
      //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
      //   98: astore_1
      //   99: aload_1
      //   100: putstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   103: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData
      //   105: monitorexit
      //   106: aload_1
      //   107: areturn
      //   108: astore_1
      //   109: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData
      //   111: monitorexit
      //   112: aload_1
      //   113: athrow
      //   114: aload_1
      //   115: areturn
      //   116: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData;
      //   119: areturn
      //   120: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData;
      //   123: ldc_w '     ለ ለለለለለဃ\\bဃ\\tတ\\b\\nለ\\tለ\\n'
      //   126: bipush #12
      //   128: anewarray java/lang/Object
      //   131: dup
      //   132: iconst_0
      //   133: ldc_w 'bitField0_'
      //   136: aastore
      //   137: dup
      //   138: iconst_1
      //   139: ldc_w 'skAdnVersion_'
      //   142: aastore
      //   143: dup
      //   144: iconst_2
      //   145: ldc_w 'skAdNetworkId_'
      //   148: aastore
      //   149: dup
      //   150: iconst_3
      //   151: ldc_w 'skAdnCampign_'
      //   154: aastore
      //   155: dup
      //   156: iconst_4
      //   157: ldc_w 'skAdnBundle_'
      //   160: aastore
      //   161: dup
      //   162: iconst_5
      //   163: ldc_w 'skAdnId_'
      //   166: aastore
      //   167: dup
      //   168: bipush #6
      //   170: ldc_w 'skAdnImpId_'
      //   173: aastore
      //   174: dup
      //   175: bipush #7
      //   177: ldc_w 'skAdnSourceApp_'
      //   180: aastore
      //   181: dup
      //   182: bipush #8
      //   184: ldc_w 'skAdnTimestamp_'
      //   187: aastore
      //   188: dup
      //   189: bipush #9
      //   191: ldc_w 'skAdnImpTimestamp_'
      //   194: aastore
      //   195: dup
      //   196: bipush #10
      //   198: ldc_w 'skAdnImpSignature_'
      //   201: aastore
      //   202: dup
      //   203: bipush #11
      //   205: ldc_w 'skAdnSignature_'
      //   208: aastore
      //   209: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
      //   212: areturn
      //   213: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData$a
      //   216: dup
      //   217: invokespecial <init> : ()V
      //   220: areturn
      //   221: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKAdNetworkData
      //   224: dup
      //   225: invokespecial <init> : ()V
      //   228: areturn
      // Exception table:
      //   from	to	target	type
      //   78	82	108	finally
      //   88	103	108	finally
      //   103	106	108	finally
      //   109	112	108	finally
    }
    
    public String getSkAdNetworkId() {
      return this.skAdNetworkId_;
    }
    
    public i getSkAdNetworkIdBytes() {
      return i.a(this.skAdNetworkId_);
    }
    
    public String getSkAdnBundle() {
      return this.skAdnBundle_;
    }
    
    public i getSkAdnBundleBytes() {
      return i.a(this.skAdnBundle_);
    }
    
    public String getSkAdnCampign() {
      return this.skAdnCampign_;
    }
    
    public i getSkAdnCampignBytes() {
      return i.a(this.skAdnCampign_);
    }
    
    public String getSkAdnId() {
      return this.skAdnId_;
    }
    
    public i getSkAdnIdBytes() {
      return i.a(this.skAdnId_);
    }
    
    public String getSkAdnImpId() {
      return this.skAdnImpId_;
    }
    
    public i getSkAdnImpIdBytes() {
      return i.a(this.skAdnImpId_);
    }
    
    public String getSkAdnImpSignature() {
      return this.skAdnImpSignature_;
    }
    
    public i getSkAdnImpSignatureBytes() {
      return i.a(this.skAdnImpSignature_);
    }
    
    public long getSkAdnImpTimestamp() {
      return this.skAdnImpTimestamp_;
    }
    
    public String getSkAdnSignature() {
      return this.skAdnSignature_;
    }
    
    public i getSkAdnSignatureBytes() {
      return i.a(this.skAdnSignature_);
    }
    
    public long getSkAdnSourceApp() {
      return this.skAdnSourceApp_;
    }
    
    public long getSkAdnTimestamp() {
      return this.skAdnTimestamp_;
    }
    
    public String getSkAdnVersion() {
      return this.skAdnVersion_;
    }
    
    public i getSkAdnVersionBytes() {
      return i.a(this.skAdnVersion_);
    }
    
    public boolean hasSkAdNetworkId() {
      return ((this.bitField0_ & 0x2) != 0);
    }
    
    public boolean hasSkAdnBundle() {
      return ((this.bitField0_ & 0x8) != 0);
    }
    
    public boolean hasSkAdnCampign() {
      return ((this.bitField0_ & 0x4) != 0);
    }
    
    public boolean hasSkAdnId() {
      return ((this.bitField0_ & 0x10) != 0);
    }
    
    public boolean hasSkAdnImpId() {
      return ((this.bitField0_ & 0x20) != 0);
    }
    
    public boolean hasSkAdnImpSignature() {
      return ((this.bitField0_ & 0x200) != 0);
    }
    
    public boolean hasSkAdnImpTimestamp() {
      return ((this.bitField0_ & 0x100) != 0);
    }
    
    public boolean hasSkAdnSignature() {
      return ((this.bitField0_ & 0x400) != 0);
    }
    
    public boolean hasSkAdnSourceApp() {
      return ((this.bitField0_ & 0x40) != 0);
    }
    
    public boolean hasSkAdnTimestamp() {
      return ((this.bitField0_ & 0x80) != 0);
    }
    
    public boolean hasSkAdnVersion() {
      return ((this.bitField0_ & 0x1) != 0);
    }
    
    public static final class a extends GeneratedMessageLite.b<SKAdNetworkData, a> {
      public a() {
        super(AdmParametersOuterClass$AdmParameters.SKAdNetworkData.DEFAULT_INSTANCE);
      }
    }
  }
  
  public static final class a extends GeneratedMessageLite.b<SKAdNetworkData, SKAdNetworkData.a> {
    public a() {
      super(AdmParametersOuterClass$AdmParameters.SKAdNetworkData.DEFAULT_INSTANCE);
    }
  }
  
  public static final class SKOverlayData extends GeneratedMessageLite<SKOverlayData, SKOverlayData.a> {
    private static final SKOverlayData DEFAULT_INSTANCE;
    
    private static volatile w0<SKOverlayData> PARSER;
    
    public static final int SKOVERLAYAUTOCLOSE_FIELD_NUMBER = 4;
    
    public static final int SKOVERLAYDELAY_FIELD_NUMBER = 2;
    
    public static final int SKOVERLAYDISMISSIBLE_FIELD_NUMBER = 5;
    
    public static final int SKOVERLAYENDCARDDELAY_FIELD_NUMBER = 6;
    
    public static final int SKOVERLAYENDCARD_FIELD_NUMBER = 3;
    
    public static final int SKOVERLAYPOSITION_FIELD_NUMBER = 1;
    
    private int bitField0_;
    
    private int skOverlayAutoclose_;
    
    private int skOverlayDelay_;
    
    private int skOverlayDismissible_;
    
    private int skOverlayEndcardDelay_;
    
    private int skOverlayEndcard_;
    
    private int skOverlayPosition_;
    
    static {
      SKOverlayData sKOverlayData = new SKOverlayData();
      DEFAULT_INSTANCE = sKOverlayData;
      GeneratedMessageLite.registerDefaultInstance(SKOverlayData.class, sKOverlayData);
    }
    
    private void clearSkOverlayAutoclose() {
      this.bitField0_ &= 0xFFFFFFF7;
      this.skOverlayAutoclose_ = 0;
    }
    
    private void clearSkOverlayDelay() {
      this.bitField0_ &= 0xFFFFFFFD;
      this.skOverlayDelay_ = 0;
    }
    
    private void clearSkOverlayDismissible() {
      this.bitField0_ &= 0xFFFFFFEF;
      this.skOverlayDismissible_ = 0;
    }
    
    private void clearSkOverlayEndcard() {
      this.bitField0_ &= 0xFFFFFFFB;
      this.skOverlayEndcard_ = 0;
    }
    
    private void clearSkOverlayEndcardDelay() {
      this.bitField0_ &= 0xFFFFFFDF;
      this.skOverlayEndcardDelay_ = 0;
    }
    
    private void clearSkOverlayPosition() {
      this.bitField0_ &= 0xFFFFFFFE;
      this.skOverlayPosition_ = 0;
    }
    
    public static SKOverlayData getDefaultInstance() {
      return DEFAULT_INSTANCE;
    }
    
    public static a newBuilder() {
      return (a)DEFAULT_INSTANCE.createBuilder();
    }
    
    public static a newBuilder(SKOverlayData param1SKOverlayData) {
      return (a)DEFAULT_INSTANCE.createBuilder(param1SKOverlayData);
    }
    
    public static SKOverlayData parseDelimitedFrom(InputStream param1InputStream) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static SKOverlayData parseDelimitedFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static SKOverlayData parseFrom(i param1i) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i);
    }
    
    public static SKOverlayData parseFrom(i param1i, q param1q) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1i, param1q);
    }
    
    public static SKOverlayData parseFrom(j param1j) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j);
    }
    
    public static SKOverlayData parseFrom(j param1j, q param1q) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1j, param1q);
    }
    
    public static SKOverlayData parseFrom(InputStream param1InputStream) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream);
    }
    
    public static SKOverlayData parseFrom(InputStream param1InputStream, q param1q) throws IOException {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1InputStream, param1q);
    }
    
    public static SKOverlayData parseFrom(ByteBuffer param1ByteBuffer) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer);
    }
    
    public static SKOverlayData parseFrom(ByteBuffer param1ByteBuffer, q param1q) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ByteBuffer, param1q);
    }
    
    public static SKOverlayData parseFrom(byte[] param1ArrayOfbyte) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte);
    }
    
    public static SKOverlayData parseFrom(byte[] param1ArrayOfbyte, q param1q) throws z {
      return (SKOverlayData)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, param1ArrayOfbyte, param1q);
    }
    
    public static w0<SKOverlayData> parser() {
      return DEFAULT_INSTANCE.getParserForType();
    }
    
    private void setSkOverlayAutoclose(int param1Int) {
      this.bitField0_ |= 0x8;
      this.skOverlayAutoclose_ = param1Int;
    }
    
    private void setSkOverlayDelay(int param1Int) {
      this.bitField0_ |= 0x2;
      this.skOverlayDelay_ = param1Int;
    }
    
    private void setSkOverlayDismissible(int param1Int) {
      this.bitField0_ |= 0x10;
      this.skOverlayDismissible_ = param1Int;
    }
    
    private void setSkOverlayEndcard(int param1Int) {
      this.bitField0_ |= 0x4;
      this.skOverlayEndcard_ = param1Int;
    }
    
    private void setSkOverlayEndcardDelay(int param1Int) {
      this.bitField0_ |= 0x20;
      this.skOverlayEndcardDelay_ = param1Int;
    }
    
    private void setSkOverlayPosition(int param1Int) {
      this.bitField0_ |= 0x1;
      this.skOverlayPosition_ = param1Int;
    }
    
    public final Object dynamicMethod(GeneratedMessageLite.f param1f, Object<SKOverlayData> param1Object1, Object param1Object2) {
      // Byte code:
      //   0: getstatic com/fyber/inneractive/sdk/bidder/adm/a.a : [I
      //   3: aload_1
      //   4: invokevirtual ordinal : ()I
      //   7: iaload
      //   8: tableswitch default -> 52, 1 -> 178, 2 -> 170, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
      //   52: new java/lang/UnsupportedOperationException
      //   55: dup
      //   56: invokespecial <init> : ()V
      //   59: athrow
      //   60: aconst_null
      //   61: areturn
      //   62: iconst_1
      //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
      //   66: areturn
      //   67: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   70: astore_1
      //   71: aload_1
      //   72: ifnonnull -> 114
      //   75: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData
      //   77: monitorenter
      //   78: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   81: astore_2
      //   82: aload_2
      //   83: astore_1
      //   84: aload_2
      //   85: ifnonnull -> 103
      //   88: new com/fyber/inneractive/sdk/protobuf/GeneratedMessageLite$c
      //   91: dup
      //   92: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData;
      //   95: invokespecial <init> : (Lcom/fyber/inneractive/sdk/protobuf/GeneratedMessageLite;)V
      //   98: astore_1
      //   99: aload_1
      //   100: putstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.PARSER : Lcom/fyber/inneractive/sdk/protobuf/w0;
      //   103: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData
      //   105: monitorexit
      //   106: aload_1
      //   107: areturn
      //   108: astore_1
      //   109: ldc com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData
      //   111: monitorexit
      //   112: aload_1
      //   113: athrow
      //   114: aload_1
      //   115: areturn
      //   116: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData;
      //   119: areturn
      //   120: getstatic com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData.DEFAULT_INSTANCE : Lcom/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData;
      //   123: ldc '     ဋ ငဋဋဋင'
      //   125: bipush #7
      //   127: anewarray java/lang/Object
      //   130: dup
      //   131: iconst_0
      //   132: ldc 'bitField0_'
      //   134: aastore
      //   135: dup
      //   136: iconst_1
      //   137: ldc 'skOverlayPosition_'
      //   139: aastore
      //   140: dup
      //   141: iconst_2
      //   142: ldc 'skOverlayDelay_'
      //   144: aastore
      //   145: dup
      //   146: iconst_3
      //   147: ldc 'skOverlayEndcard_'
      //   149: aastore
      //   150: dup
      //   151: iconst_4
      //   152: ldc 'skOverlayAutoclose_'
      //   154: aastore
      //   155: dup
      //   156: iconst_5
      //   157: ldc 'skOverlayDismissible_'
      //   159: aastore
      //   160: dup
      //   161: bipush #6
      //   163: ldc 'skOverlayEndcardDelay_'
      //   165: aastore
      //   166: invokestatic newMessageInfo : (Lcom/fyber/inneractive/sdk/protobuf/o0;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
      //   169: areturn
      //   170: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData$a
      //   173: dup
      //   174: invokespecial <init> : ()V
      //   177: areturn
      //   178: new com/fyber/inneractive/sdk/bidder/adm/AdmParametersOuterClass$AdmParameters$SKOverlayData
      //   181: dup
      //   182: invokespecial <init> : ()V
      //   185: areturn
      // Exception table:
      //   from	to	target	type
      //   78	82	108	finally
      //   88	103	108	finally
      //   103	106	108	finally
      //   109	112	108	finally
    }
    
    public int getSkOverlayAutoclose() {
      return this.skOverlayAutoclose_;
    }
    
    public int getSkOverlayDelay() {
      return this.skOverlayDelay_;
    }
    
    public int getSkOverlayDismissible() {
      return this.skOverlayDismissible_;
    }
    
    public int getSkOverlayEndcard() {
      return this.skOverlayEndcard_;
    }
    
    public int getSkOverlayEndcardDelay() {
      return this.skOverlayEndcardDelay_;
    }
    
    public int getSkOverlayPosition() {
      return this.skOverlayPosition_;
    }
    
    public boolean hasSkOverlayAutoclose() {
      return ((this.bitField0_ & 0x8) != 0);
    }
    
    public boolean hasSkOverlayDelay() {
      return ((this.bitField0_ & 0x2) != 0);
    }
    
    public boolean hasSkOverlayDismissible() {
      return ((this.bitField0_ & 0x10) != 0);
    }
    
    public boolean hasSkOverlayEndcard() {
      return ((this.bitField0_ & 0x4) != 0);
    }
    
    public boolean hasSkOverlayEndcardDelay() {
      return ((this.bitField0_ & 0x20) != 0);
    }
    
    public boolean hasSkOverlayPosition() {
      return ((this.bitField0_ & 0x1) != 0);
    }
    
    public static final class a extends GeneratedMessageLite.b<SKOverlayData, a> {
      public a() {
        super(AdmParametersOuterClass$AdmParameters.SKOverlayData.DEFAULT_INSTANCE);
      }
    }
  }
  
  public static final class a extends GeneratedMessageLite.b<SKOverlayData, SKOverlayData.a> {
    public a() {
      super(AdmParametersOuterClass$AdmParameters.SKOverlayData.DEFAULT_INSTANCE);
    }
  }
  
  public enum a implements y.c {
    DV360, HTML, MRAID, OTHER, UNRECOGNIZED, VAST;
    
    public static final int DV360_VALUE = 15;
    
    public static final int HTML_VALUE = 4;
    
    public static final int MRAID_VALUE = 6;
    
    public static final int OTHER_VALUE = 0;
    
    public static final int VAST_VALUE = 8;
    
    private static final y.d<a> internalValueMap;
    
    private final int value;
    
    static {
      a a1 = new a("OTHER", 0, 0);
      OTHER = a1;
      a a2 = new a("HTML", 1, 4);
      HTML = a2;
      a a3 = new a("MRAID", 2, 6);
      MRAID = a3;
      a a4 = new a("VAST", 3, 8);
      VAST = a4;
      a a5 = new a("DV360", 4, 15);
      DV360 = a5;
      a a6 = new a("UNRECOGNIZED", 5, -1);
      UNRECOGNIZED = a6;
      $VALUES = new a[] { a1, a2, a3, a4, a5, a6 };
      internalValueMap = new a();
    }
    
    a(int param1Int1) {
      this.value = param1Int1;
    }
    
    public static a a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 4) ? ((param1Int != 6) ? ((param1Int != 8) ? ((param1Int != 15) ? null : DV360) : VAST) : MRAID) : HTML) : OTHER;
    }
    
    public final int a() {
      if (this != UNRECOGNIZED)
        return this.value; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    public class a implements y.d<a> {
      public y.c a(int param2Int) {
        return AdmParametersOuterClass$AdmParameters.a.a(param2Int);
      }
    }
  }
  
  public class a implements y.d<a> {
    public y.c a(int param1Int) {
      return AdmParametersOuterClass$AdmParameters.a.a(param1Int);
    }
  }
  
  public enum b implements y.c {
    DISPLAY, UNRECOGNIZED, VIDEO, VIDEOANDDISPLAY;
    
    public static final int DISPLAY_VALUE = 0;
    
    public static final int VIDEOANDDISPLAY_VALUE = 2;
    
    public static final int VIDEO_VALUE = 1;
    
    private static final y.d<b> internalValueMap;
    
    private final int value;
    
    static {
      b b1 = new b("DISPLAY", 0, 0);
      DISPLAY = b1;
      b b2 = new b("VIDEO", 1, 1);
      VIDEO = b2;
      b b3 = new b("VIDEOANDDISPLAY", 2, 2);
      VIDEOANDDISPLAY = b3;
      b b4 = new b("UNRECOGNIZED", 3, -1);
      UNRECOGNIZED = b4;
      $VALUES = new b[] { b1, b2, b3, b4 };
      internalValueMap = new a();
    }
    
    b(int param1Int1) {
      this.value = param1Int1;
    }
    
    public static b a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? null : VIDEOANDDISPLAY) : VIDEO) : DISPLAY;
    }
    
    public final int a() {
      if (this != UNRECOGNIZED)
        return this.value; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    public class a implements y.d<b> {
      public y.c a(int param2Int) {
        return AdmParametersOuterClass$AdmParameters.b.a(param2Int);
      }
    }
  }
  
  public class a implements y.d<b> {
    public y.c a(int param1Int) {
      return AdmParametersOuterClass$AdmParameters.b.a(param1Int);
    }
  }
  
  public static final class c extends GeneratedMessageLite.b<AdmParametersOuterClass$AdmParameters, c> {
    public c() {
      super(AdmParametersOuterClass$AdmParameters.DEFAULT_INSTANCE);
    }
  }
  
  public enum d implements y.c {
    AUTOMATIC, MANUAL, UNRECOGNIZED;
    
    public static final int AUTOMATIC_VALUE = 1;
    
    public static final int MANUAL_VALUE = 0;
    
    private static final y.d<d> internalValueMap;
    
    private final int value;
    
    static {
      d d1 = new d("MANUAL", 0, 0);
      MANUAL = d1;
      d d2 = new d("AUTOMATIC", 1, 1);
      AUTOMATIC = d2;
      d d3 = new d("UNRECOGNIZED", 2, -1);
      UNRECOGNIZED = d3;
      $VALUES = new d[] { d1, d2, d3 };
      internalValueMap = new a();
    }
    
    d(int param1Int1) {
      this.value = param1Int1;
    }
    
    public final int a() {
      if (this != UNRECOGNIZED)
        return this.value; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    public class a implements y.d<d> {
      public y.c a(int param2Int) {
        return (param2Int != 0) ? ((param2Int != 1) ? null : AdmParametersOuterClass$AdmParameters.d.AUTOMATIC) : AdmParametersOuterClass$AdmParameters.d.MANUAL;
      }
    }
  }
  
  public class a implements y.d<d> {
    public y.c a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? null : AdmParametersOuterClass$AdmParameters.d.AUTOMATIC) : AdmParametersOuterClass$AdmParameters.d.MANUAL;
    }
  }
  
  public static interface e extends p0 {}
  
  public enum f implements y.c {
    NONE, SINGLETAP, TRUESINGLETAP, UNRECOGNIZED;
    
    public static final int NONE_VALUE = 0;
    
    public static final int SINGLETAP_VALUE = 1;
    
    public static final int TRUESINGLETAP_VALUE = 2;
    
    private static final y.d<f> internalValueMap;
    
    private final int value;
    
    static {
      f f1 = new f("NONE", 0, 0);
      NONE = f1;
      f f2 = new f("SINGLETAP", 1, 1);
      SINGLETAP = f2;
      f f3 = new f("TRUESINGLETAP", 2, 2);
      TRUESINGLETAP = f3;
      f f4 = new f("UNRECOGNIZED", 3, -1);
      UNRECOGNIZED = f4;
      $VALUES = new f[] { f1, f2, f3, f4 };
      internalValueMap = new a();
    }
    
    f(int param1Int1) {
      this.value = param1Int1;
    }
    
    public static f a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? null : TRUESINGLETAP) : SINGLETAP) : NONE;
    }
    
    public final int a() {
      if (this != UNRECOGNIZED)
        return this.value; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    public class a implements y.d<f> {
      public y.c a(int param2Int) {
        return AdmParametersOuterClass$AdmParameters.f.a(param2Int);
      }
    }
  }
  
  public class a implements y.d<f> {
    public y.c a(int param1Int) {
      return AdmParametersOuterClass$AdmParameters.f.a(param1Int);
    }
  }
  
  public enum g implements y.c {
    BANNER, INTERSTITIAL, MRECT, REWARDED, UNITDISPLAYTYPEUNKNOWN, UNRECOGNIZED;
    
    public static final int BANNER_VALUE = 1;
    
    public static final int INTERSTITIAL_VALUE = 2;
    
    public static final int MRECT_VALUE = 4;
    
    public static final int REWARDED_VALUE = 3;
    
    public static final int UNITDISPLAYTYPEUNKNOWN_VALUE = 0;
    
    private static final y.d<g> internalValueMap;
    
    private final int value;
    
    static {
      g g1 = new g("UNITDISPLAYTYPEUNKNOWN", 0, 0);
      UNITDISPLAYTYPEUNKNOWN = g1;
      g g2 = new g("BANNER", 1, 1);
      BANNER = g2;
      g g3 = new g("INTERSTITIAL", 2, 2);
      INTERSTITIAL = g3;
      g g4 = new g("REWARDED", 3, 3);
      REWARDED = g4;
      g g5 = new g("MRECT", 4, 4);
      MRECT = g5;
      g g6 = new g("UNRECOGNIZED", 5, -1);
      UNRECOGNIZED = g6;
      $VALUES = new g[] { g1, g2, g3, g4, g5, g6 };
      internalValueMap = new a();
    }
    
    g(int param1Int1) {
      this.value = param1Int1;
    }
    
    public static g a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? ((param1Int != 3) ? ((param1Int != 4) ? null : MRECT) : REWARDED) : INTERSTITIAL) : BANNER) : UNITDISPLAYTYPEUNKNOWN;
    }
    
    public final int a() {
      if (this != UNRECOGNIZED)
        return this.value; 
      throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
    
    public class a implements y.d<g> {
      public y.c a(int param2Int) {
        return AdmParametersOuterClass$AdmParameters.g.a(param2Int);
      }
    }
  }
  
  public class a implements y.d<g> {
    public y.c a(int param1Int) {
      return AdmParametersOuterClass$AdmParameters.g.a(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\bidder\adm\AdmParametersOuterClass$AdmParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */