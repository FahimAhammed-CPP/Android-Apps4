package com.fyber.inneractive.sdk.player.exoplayer2.extractor.ts;

import android.util.SparseArray;
import com.fyber.inneractive.sdk.player.exoplayer2.extractor.h;
import com.fyber.inneractive.sdk.player.exoplayer2.util.k;
import com.fyber.inneractive.sdk.player.exoplayer2.util.r;
import java.util.Collections;
import java.util.List;

public interface v {
  void a();
  
  void a(k paramk, boolean paramBoolean);
  
  void a(r paramr, h paramh, d paramd);
  
  public static final class a {
    public final String a;
    
    public final byte[] b;
    
    public a(String param1String, int param1Int, byte[] param1ArrayOfbyte) {
      this.a = param1String;
      this.b = param1ArrayOfbyte;
    }
  }
  
  public static final class b {
    public final String a;
    
    public final List<v.a> b;
    
    public final byte[] c;
    
    public b(int param1Int, String param1String, List<v.a> param1List, byte[] param1ArrayOfbyte) {
      List<v.a> list;
      this.a = param1String;
      if (param1List == null) {
        list = Collections.emptyList();
      } else {
        list = Collections.unmodifiableList(param1List);
      } 
      this.b = list;
      this.c = param1ArrayOfbyte;
    }
  }
  
  public static interface c {
    SparseArray<v> a();
    
    v a(int param1Int, v.b param1b);
  }
  
  public static final class d {
    public final String a;
    
    public final int b;
    
    public final int c;
    
    public int d;
    
    public String e;
    
    public d(int param1Int1, int param1Int2, int param1Int3) {
      String str;
      if (param1Int1 != Integer.MIN_VALUE) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Int1);
        stringBuilder.append("/");
        str = stringBuilder.toString();
      } else {
        str = "";
      } 
      this.a = str;
      this.b = param1Int2;
      this.c = param1Int3;
      this.d = Integer.MIN_VALUE;
    }
    
    public void a() {
      int i = this.d;
      if (i == Integer.MIN_VALUE) {
        i = this.b;
      } else {
        i += this.c;
      } 
      this.d = i;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append(this.d);
      this.e = stringBuilder.toString();
    }
    
    public String b() {
      if (this.d != Integer.MIN_VALUE)
        return this.e; 
      throw new IllegalStateException("generateNewId() must be called before retrieving ids.");
    }
    
    public int c() {
      int i = this.d;
      if (i != Integer.MIN_VALUE)
        return i; 
      throw new IllegalStateException("generateNewId() must be called before retrieving ids.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\extractor\ts\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */