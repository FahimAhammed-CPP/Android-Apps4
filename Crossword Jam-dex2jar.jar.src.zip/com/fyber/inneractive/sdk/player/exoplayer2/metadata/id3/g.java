package com.fyber.inneractive.sdk.player.exoplayer2.metadata.id3;

import android.util.Log;
import com.fyber.inneractive.sdk.player.exoplayer2.util.k;
import com.fyber.inneractive.sdk.player.exoplayer2.util.u;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public final class g {
  public static final int b = u.a("ID3");
  
  public final a a;
  
  public g() {
    this(null);
  }
  
  public g(a parama) {
    this.a = parama;
  }
  
  public static int a(int paramInt) {
    return (paramInt == 0 || paramInt == 3) ? 1 : 2;
  }
  
  public static int a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    int i = b(paramArrayOfbyte, paramInt1);
    if (paramInt2 != 0) {
      paramInt1 = i;
      if (paramInt2 == 3)
        return i; 
      while (paramInt1 < paramArrayOfbyte.length - 1) {
        if (paramInt1 % 2 == 0 && paramArrayOfbyte[paramInt1 + 1] == 0)
          return paramInt1; 
        paramInt1 = b(paramArrayOfbyte, paramInt1 + 1);
      } 
      return paramArrayOfbyte.length;
    } 
    return i;
  }
  
  public static a a(k paramk, int paramInt1, int paramInt2) throws UnsupportedEncodingException {
    String str1;
    int i = paramk.l();
    String str2 = b(i);
    int j = paramInt1 - 1;
    byte[] arrayOfByte = new byte[j];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, j);
    paramk.b += j;
    if (paramInt2 == 2) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("image/");
      stringBuilder.append((new String(arrayOfByte, 0, 3, "ISO-8859-1")).toLowerCase(Locale.US));
      String str = stringBuilder.toString();
      str1 = str;
      if (str.equals("image/jpg"))
        str1 = "image/jpeg"; 
      paramInt1 = 2;
    } else {
      paramInt1 = b(arrayOfByte, 0);
      str1 = (new String(arrayOfByte, 0, paramInt1, "ISO-8859-1")).toLowerCase(Locale.US);
      if (str1.indexOf('/') == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("image/");
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } 
    } 
    paramInt2 = arrayOfByte[paramInt1 + 1];
    paramInt1 += 2;
    int m = a(arrayOfByte, paramInt1, i);
    return new a(str1, new String(arrayOfByte, paramInt1, m - paramInt1, str2), paramInt2 & 0xFF, Arrays.copyOfRange(arrayOfByte, m + a(i), j));
  }
  
  public static b a(k paramk, int paramInt, String paramString) {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new b(paramString, arrayOfByte);
  }
  
  public static c a(k paramk, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, a parama) throws UnsupportedEncodingException {
    int i = paramk.b;
    int j = b(paramk.a, i);
    String str = new String(paramk.a, i, j - i, "ISO-8859-1");
    paramk.e(j + 1);
    j = paramk.c();
    int m = paramk.c();
    long l1 = paramk.m();
    if (l1 == 4294967295L)
      l1 = -1L; 
    long l2 = paramk.m();
    if (l2 == 4294967295L)
      l2 = -1L; 
    ArrayList<h> arrayList = new ArrayList();
    while (paramk.b < i + paramInt1) {
      h h = a(paramInt2, paramk, paramBoolean, paramInt3, parama);
      if (h != null)
        arrayList.add(h); 
    } 
    h[] arrayOfH = new h[arrayList.size()];
    arrayList.toArray(arrayOfH);
    return new c(str, j, m, l1, l2, arrayOfH);
  }
  
  public static e a(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 4)
      return null; 
    int i = paramk.l();
    String str4 = b(i);
    byte[] arrayOfByte1 = new byte[3];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte1, 0, 3);
    paramk.b += 3;
    String str2 = new String(arrayOfByte1, 0, 3);
    paramInt -= 4;
    byte[] arrayOfByte2 = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte2, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte2, 0, i);
    String str3 = new String(arrayOfByte2, 0, j, str4);
    j += a(i);
    if (j < paramInt) {
      str1 = new String(arrayOfByte2, j, a(arrayOfByte2, j, i) - j, str4);
    } else {
      str1 = "";
    } 
    return new e(str2, str3, str1);
  }
  
  public static h a(int paramInt1, k paramk, boolean paramBoolean, int paramInt2, a parama) {
    b b;
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    int n = paramk.l();
    int i1 = paramk.l();
    int i2 = paramk.l();
    if (paramInt1 >= 3) {
      bool4 = paramk.l();
    } else {
      bool4 = false;
    } 
    if (paramInt1 == 4) {
      j = paramk.o();
      i = j;
      if (!paramBoolean)
        i = (j >> 24 & 0xFF) << 21 | j & 0xFF | (j >> 8 & 0xFF) << 7 | (j >> 16 & 0xFF) << 14; 
    } else if (paramInt1 == 3) {
      i = paramk.o();
    } else {
      i = paramk.n();
    } 
    if (paramInt1 >= 3) {
      bool3 = paramk.q();
    } else {
      bool3 = false;
    } 
    if (n == 0 && i1 == 0 && i2 == 0 && !bool4 && i == 0 && !bool3) {
      paramk.e(paramk.c);
      return null;
    } 
    int i3 = paramk.b + i;
    if (i3 > paramk.c) {
      Log.w("Id3Decoder", "Frame size exceeds remaining tag data");
      paramk.e(paramk.c);
      return null;
    } 
    if (parama != null) {
      if (n == 67 && i1 == 79 && i2 == 77 && (bool4 == 77 || paramInt1 == 2)) {
        j = 1;
      } else {
        j = 0;
      } 
      if (!j) {
        paramk.e(i3);
        return null;
      } 
    } 
    if (paramInt1 == 3) {
      if ((bool3 & 0x80) != 0) {
        j = 1;
      } else {
        j = 0;
      } 
      if ((bool3 & 0x40) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool3 & 0x20) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      m = bool1;
      boolean bool = false;
      bool1 = bool2;
      bool3 = j;
      bool2 = bool;
    } else if (paramInt1 == 4) {
      boolean bool;
      if ((bool3 & 0x40) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool3 & 0x8) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if ((bool3 & 0x4) != 0) {
        m = 1;
      } else {
        m = 0;
      } 
      if ((bool3 & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool3 & true) != 0) {
        j = 1;
        bool3 = bool2;
        bool2 = bool;
      } else {
        j = 0;
        bool3 = bool2;
        bool2 = bool;
      } 
    } else {
      bool1 = false;
      j = 0;
      bool3 = false;
      m = 0;
      bool2 = false;
    } 
    if (bool3 || m) {
      Log.w("Id3Decoder", "Skipping unsupported compressed or encrypted frame");
      paramk.e(i3);
      return null;
    } 
    int m = i;
    if (bool1) {
      m = i - 1;
      paramk.f(1);
    } 
    int i = m;
    if (j) {
      i = m - 4;
      paramk.f(4);
    } 
    int j = i;
    if (bool2)
      j = f(paramk, i); 
    if (n == 84 && i1 == 88 && i2 == 88 && (paramInt1 == 2 || bool4 == 88))
      try {
        j j1 = d(paramk, j);
        if (j1 == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to decode frame: id=");
          stringBuilder.append(a(paramInt1, n, i1, i2, bool4));
          stringBuilder.append(", frameSize=");
          stringBuilder.append(j);
          Log.w("Id3Decoder", stringBuilder.toString());
        } 
        return (h)j1;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        Log.w("Id3Decoder", "Unsupported character encoding");
        return null;
      } finally {
        paramk.e(i3);
      }  
    if (n == 84) {
      j j1 = b(paramk, j, a(paramInt1, n, i1, i2, bool4));
    } else if (n == 87 && i1 == 88 && i2 == 88 && (paramInt1 == 2 || bool4 == 88)) {
      k k1 = e(paramk, j);
    } else if (n == 87) {
      k k1 = c(paramk, j, a(paramInt1, n, i1, i2, bool4));
    } else if (n == 80 && i1 == 82 && i2 == 73 && bool4 == 86) {
      i i4 = c(paramk, j);
    } else if (n == 71 && i1 == 69 && i2 == 79 && (bool4 == 66 || paramInt1 == 2)) {
      f f = b(paramk, j);
    } else if ((paramInt1 == 2) ? (n == 80 && i1 == 73 && i2 == 67) : (n == 65 && i1 == 80 && i2 == 73 && bool4 == 67)) {
      a a1 = a(paramk, j, paramInt1);
    } else {
      e e;
      if (n == 67 && i1 == 79 && i2 == 77 && (bool4 == 77 || paramInt1 == 2)) {
        e = a(paramk, j);
      } else {
        c c;
        if (n == 67 && i1 == 72 && i2 == 65 && bool4 == 80) {
          c = a(paramk, j, paramInt1, paramBoolean, paramInt2, (a)e);
        } else if (n == 67 && i1 == 84 && i2 == 79 && bool4 == 67) {
          d d = b(paramk, j, paramInt1, paramBoolean, paramInt2, (a)c);
        } else {
          b = a(paramk, j, a(paramInt1, n, i1, i2, bool4));
        } 
      } 
    } 
    if (b == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to decode frame: id=");
      stringBuilder.append(a(paramInt1, n, i1, i2, bool4));
      stringBuilder.append(", frameSize=");
      stringBuilder.append(j);
      Log.w("Id3Decoder", stringBuilder.toString());
    } 
    paramk.e(i3);
    return (h)b;
  }
  
  public static String a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    return (paramInt1 == 2) ? String.format(Locale.US, "%c%c%c", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) }) : String.format(Locale.US, "%c%c%c%c", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), Integer.valueOf(paramInt5) });
  }
  
  public static boolean a(k paramk, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : I
    //   4: istore #8
    //   6: aload_0
    //   7: invokevirtual a : ()I
    //   10: istore #4
    //   12: iconst_1
    //   13: istore #7
    //   15: iload #4
    //   17: iload_2
    //   18: if_icmplt -> 347
    //   21: iload_1
    //   22: iconst_3
    //   23: if_icmplt -> 47
    //   26: aload_0
    //   27: invokevirtual c : ()I
    //   30: istore #4
    //   32: aload_0
    //   33: invokevirtual m : ()J
    //   36: lstore #9
    //   38: aload_0
    //   39: invokevirtual q : ()I
    //   42: istore #6
    //   44: goto -> 67
    //   47: aload_0
    //   48: invokevirtual n : ()I
    //   51: istore #4
    //   53: aload_0
    //   54: invokevirtual n : ()I
    //   57: istore #5
    //   59: iload #5
    //   61: i2l
    //   62: lstore #9
    //   64: iconst_0
    //   65: istore #6
    //   67: iload #4
    //   69: ifne -> 92
    //   72: lload #9
    //   74: lconst_0
    //   75: lcmp
    //   76: ifne -> 92
    //   79: iload #6
    //   81: ifne -> 92
    //   84: aload_0
    //   85: iload #8
    //   87: invokevirtual e : (I)V
    //   90: iconst_1
    //   91: ireturn
    //   92: lload #9
    //   94: lstore #11
    //   96: iload_1
    //   97: iconst_4
    //   98: if_icmpne -> 175
    //   101: lload #9
    //   103: lstore #11
    //   105: iload_3
    //   106: ifne -> 175
    //   109: ldc2_w 8421504
    //   112: lload #9
    //   114: land
    //   115: lconst_0
    //   116: lcmp
    //   117: ifeq -> 128
    //   120: aload_0
    //   121: iload #8
    //   123: invokevirtual e : (I)V
    //   126: iconst_0
    //   127: ireturn
    //   128: lload #9
    //   130: bipush #24
    //   132: lshr
    //   133: ldc2_w 255
    //   136: land
    //   137: bipush #21
    //   139: lshl
    //   140: lload #9
    //   142: ldc2_w 255
    //   145: land
    //   146: lload #9
    //   148: bipush #8
    //   150: lshr
    //   151: ldc2_w 255
    //   154: land
    //   155: bipush #7
    //   157: lshl
    //   158: lor
    //   159: lload #9
    //   161: bipush #16
    //   163: lshr
    //   164: ldc2_w 255
    //   167: land
    //   168: bipush #14
    //   170: lshl
    //   171: lor
    //   172: lor
    //   173: lstore #11
    //   175: iload_1
    //   176: iconst_4
    //   177: if_icmpne -> 215
    //   180: iload #6
    //   182: bipush #64
    //   184: iand
    //   185: ifeq -> 194
    //   188: iconst_1
    //   189: istore #4
    //   191: goto -> 197
    //   194: iconst_0
    //   195: istore #4
    //   197: iload #4
    //   199: istore #5
    //   201: iload #6
    //   203: iconst_1
    //   204: iand
    //   205: ifeq -> 257
    //   208: iload #7
    //   210: istore #5
    //   212: goto -> 278
    //   215: iload_1
    //   216: iconst_3
    //   217: if_icmpne -> 271
    //   220: iload #6
    //   222: bipush #32
    //   224: iand
    //   225: ifeq -> 234
    //   228: iconst_1
    //   229: istore #4
    //   231: goto -> 237
    //   234: iconst_0
    //   235: istore #4
    //   237: iload #4
    //   239: istore #5
    //   241: iload #6
    //   243: sipush #128
    //   246: iand
    //   247: ifeq -> 257
    //   250: iload #7
    //   252: istore #5
    //   254: goto -> 278
    //   257: iconst_0
    //   258: istore #6
    //   260: iload #5
    //   262: istore #4
    //   264: iload #6
    //   266: istore #5
    //   268: goto -> 278
    //   271: iconst_0
    //   272: istore #4
    //   274: iload #4
    //   276: istore #5
    //   278: iload #4
    //   280: istore #6
    //   282: iload #5
    //   284: ifeq -> 293
    //   287: iload #4
    //   289: iconst_4
    //   290: iadd
    //   291: istore #6
    //   293: lload #11
    //   295: iload #6
    //   297: i2l
    //   298: lcmp
    //   299: ifge -> 310
    //   302: aload_0
    //   303: iload #8
    //   305: invokevirtual e : (I)V
    //   308: iconst_0
    //   309: ireturn
    //   310: aload_0
    //   311: invokevirtual a : ()I
    //   314: istore #4
    //   316: iload #4
    //   318: i2l
    //   319: lload #11
    //   321: lcmp
    //   322: ifge -> 333
    //   325: aload_0
    //   326: iload #8
    //   328: invokevirtual e : (I)V
    //   331: iconst_0
    //   332: ireturn
    //   333: lload #11
    //   335: l2i
    //   336: istore #4
    //   338: aload_0
    //   339: iload #4
    //   341: invokevirtual f : (I)V
    //   344: goto -> 6
    //   347: aload_0
    //   348: iload #8
    //   350: invokevirtual e : (I)V
    //   353: iconst_1
    //   354: ireturn
    //   355: astore #13
    //   357: aload_0
    //   358: iload #8
    //   360: invokevirtual e : (I)V
    //   363: aload #13
    //   365: athrow
    // Exception table:
    //   from	to	target	type
    //   6	12	355	finally
    //   26	44	355	finally
    //   47	59	355	finally
    //   310	316	355	finally
    //   338	344	355	finally
  }
  
  public static int b(byte[] paramArrayOfbyte, int paramInt) {
    while (paramInt < paramArrayOfbyte.length) {
      if (paramArrayOfbyte[paramInt] == 0)
        return paramInt; 
      paramInt++;
    } 
    return paramArrayOfbyte.length;
  }
  
  public static d b(k paramk, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, a parama) throws UnsupportedEncodingException {
    boolean bool1;
    boolean bool2;
    int j = paramk.b;
    int i = b(paramk.a, j);
    String str = new String(paramk.a, j, i - j, "ISO-8859-1");
    paramk.e(i + 1);
    int m = paramk.l();
    i = 0;
    if ((m & 0x2) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((m & 0x1) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    m = paramk.l();
    String[] arrayOfString = new String[m];
    while (i < m) {
      int n = paramk.b;
      int i1 = b(paramk.a, n);
      arrayOfString[i] = new String(paramk.a, n, i1 - n, "ISO-8859-1");
      paramk.e(i1 + 1);
      i++;
    } 
    ArrayList<h> arrayList = new ArrayList();
    while (paramk.b < j + paramInt1) {
      h h = a(paramInt2, paramk, paramBoolean, paramInt3, parama);
      if (h != null)
        arrayList.add(h); 
    } 
    h[] arrayOfH = new h[arrayList.size()];
    arrayList.toArray(arrayOfH);
    return new d(str, bool1, bool2, arrayOfString, arrayOfH);
  }
  
  public static f b(k paramk, int paramInt) throws UnsupportedEncodingException {
    int i = paramk.l();
    String str2 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = b(arrayOfByte, 0);
    String str1 = new String(arrayOfByte, 0, j, "ISO-8859-1");
    int m = a(arrayOfByte, ++j, i);
    String str3 = new String(arrayOfByte, j, m - j, str2);
    j = m + a(i);
    m = a(arrayOfByte, j, i);
    return new f(str1, str3, new String(arrayOfByte, j, m - j, str2), Arrays.copyOfRange(arrayOfByte, m + a(i), paramInt));
  }
  
  public static j b(k paramk, int paramInt, String paramString) throws UnsupportedEncodingException {
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new j(paramString, null, new String(arrayOfByte, 0, a(arrayOfByte, 0, i), str));
  }
  
  public static String b(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? "ISO-8859-1" : "UTF-8") : "UTF-16BE") : "UTF-16";
  }
  
  public static i c(k paramk, int paramInt) throws UnsupportedEncodingException {
    byte[] arrayOfByte1;
    byte[] arrayOfByte2 = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte2, 0, paramInt);
    paramk.b += paramInt;
    int i = b(arrayOfByte2, 0);
    String str = new String(arrayOfByte2, 0, i, "ISO-8859-1");
    if (++i < paramInt) {
      arrayOfByte1 = Arrays.copyOfRange(arrayOfByte2, i, paramInt);
    } else {
      arrayOfByte1 = new byte[0];
    } 
    return new i(str, arrayOfByte1);
  }
  
  public static k c(k paramk, int paramInt, String paramString) throws UnsupportedEncodingException {
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    return new k(paramString, null, new String(arrayOfByte, 0, b(arrayOfByte, 0), "ISO-8859-1"));
  }
  
  public static j d(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str3 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte, 0, i);
    String str2 = new String(arrayOfByte, 0, j, str3);
    j += a(i);
    if (j < paramInt) {
      str1 = new String(arrayOfByte, j, a(arrayOfByte, j, i) - j, str3);
    } else {
      str1 = "";
    } 
    return new j("TXXX", str2, str1);
  }
  
  public static k e(k paramk, int paramInt) throws UnsupportedEncodingException {
    String str1;
    if (paramInt < 1)
      return null; 
    int i = paramk.l();
    String str2 = b(i);
    byte[] arrayOfByte = new byte[--paramInt];
    System.arraycopy(paramk.a, paramk.b, arrayOfByte, 0, paramInt);
    paramk.b += paramInt;
    int j = a(arrayOfByte, 0, i);
    str2 = new String(arrayOfByte, 0, j, str2);
    i = j + a(i);
    if (i < paramInt) {
      str1 = new String(arrayOfByte, i, b(arrayOfByte, i) - i, "ISO-8859-1");
    } else {
      str1 = "";
    } 
    return new k("WXXX", str2, str1);
  }
  
  public static int f(k paramk, int paramInt) {
    byte[] arrayOfByte = paramk.a;
    int i = paramk.b;
    while (true) {
      int j = i + 1;
      if (j < paramInt) {
        int m = paramInt;
        if ((arrayOfByte[i] & 0xFF) == 255) {
          m = paramInt;
          if (arrayOfByte[j] == 0) {
            System.arraycopy(arrayOfByte, i + 2, arrayOfByte, j, paramInt - i - 2);
            m = paramInt - 1;
          } 
        } 
        i = j;
        paramInt = m;
        continue;
      } 
      return paramInt;
    } 
  }
  
  public com.fyber.inneractive.sdk.player.exoplayer2.metadata.a a(byte[] paramArrayOfbyte, int paramInt) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #10
    //   9: new com/fyber/inneractive/sdk/player/exoplayer2/util/k
    //   12: dup
    //   13: aload_1
    //   14: iload_2
    //   15: invokespecial <init> : ([BI)V
    //   18: astore #11
    //   20: aload #11
    //   22: invokevirtual a : ()I
    //   25: istore_2
    //   26: bipush #10
    //   28: istore #5
    //   30: iconst_0
    //   31: istore #9
    //   33: iload_2
    //   34: bipush #10
    //   36: if_icmpge -> 53
    //   39: ldc 'Id3Decoder'
    //   41: ldc_w 'Data too short to be an ID3 tag'
    //   44: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   47: pop
    //   48: aconst_null
    //   49: astore_1
    //   50: goto -> 370
    //   53: aload #11
    //   55: invokevirtual n : ()I
    //   58: istore_2
    //   59: iload_2
    //   60: getstatic com/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g.b : I
    //   63: if_icmpeq -> 101
    //   66: new java/lang/StringBuilder
    //   69: dup
    //   70: invokespecial <init> : ()V
    //   73: astore_1
    //   74: aload_1
    //   75: ldc_w 'Unexpected first three bytes of ID3 tag header: '
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload_1
    //   83: iload_2
    //   84: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   87: pop
    //   88: ldc 'Id3Decoder'
    //   90: aload_1
    //   91: invokevirtual toString : ()Ljava/lang/String;
    //   94: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   97: pop
    //   98: goto -> 48
    //   101: aload #11
    //   103: invokevirtual l : ()I
    //   106: istore #6
    //   108: aload #11
    //   110: iconst_1
    //   111: invokevirtual f : (I)V
    //   114: aload #11
    //   116: invokevirtual l : ()I
    //   119: istore #7
    //   121: aload #11
    //   123: invokevirtual k : ()I
    //   126: istore #4
    //   128: iload #6
    //   130: iconst_2
    //   131: if_icmpne -> 168
    //   134: iload #7
    //   136: bipush #64
    //   138: iand
    //   139: ifeq -> 147
    //   142: iconst_1
    //   143: istore_3
    //   144: goto -> 149
    //   147: iconst_0
    //   148: istore_3
    //   149: iload #4
    //   151: istore_2
    //   152: iload_3
    //   153: ifeq -> 294
    //   156: ldc 'Id3Decoder'
    //   158: ldc_w 'Skipped ID3 tag with majorVersion=2 and undefined compression scheme'
    //   161: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   164: pop
    //   165: goto -> 48
    //   168: iload #6
    //   170: iconst_3
    //   171: if_icmpne -> 218
    //   174: iload #7
    //   176: bipush #64
    //   178: iand
    //   179: ifeq -> 187
    //   182: iconst_1
    //   183: istore_3
    //   184: goto -> 189
    //   187: iconst_0
    //   188: istore_3
    //   189: iload #4
    //   191: istore_2
    //   192: iload_3
    //   193: ifeq -> 294
    //   196: aload #11
    //   198: invokevirtual c : ()I
    //   201: istore_2
    //   202: aload #11
    //   204: iload_2
    //   205: invokevirtual f : (I)V
    //   208: iload #4
    //   210: iload_2
    //   211: iconst_4
    //   212: iadd
    //   213: isub
    //   214: istore_2
    //   215: goto -> 294
    //   218: iload #6
    //   220: iconst_4
    //   221: if_icmpne -> 334
    //   224: iload #7
    //   226: bipush #64
    //   228: iand
    //   229: ifeq -> 237
    //   232: iconst_1
    //   233: istore_2
    //   234: goto -> 239
    //   237: iconst_0
    //   238: istore_2
    //   239: iload #4
    //   241: istore_3
    //   242: iload_2
    //   243: ifeq -> 265
    //   246: aload #11
    //   248: invokevirtual k : ()I
    //   251: istore_2
    //   252: aload #11
    //   254: iload_2
    //   255: iconst_4
    //   256: isub
    //   257: invokevirtual f : (I)V
    //   260: iload #4
    //   262: iload_2
    //   263: isub
    //   264: istore_3
    //   265: iload #7
    //   267: bipush #16
    //   269: iand
    //   270: ifeq -> 279
    //   273: iconst_1
    //   274: istore #4
    //   276: goto -> 282
    //   279: iconst_0
    //   280: istore #4
    //   282: iload_3
    //   283: istore_2
    //   284: iload #4
    //   286: ifeq -> 294
    //   289: iload_3
    //   290: bipush #10
    //   292: isub
    //   293: istore_2
    //   294: iload #6
    //   296: iconst_4
    //   297: if_icmpge -> 315
    //   300: iload #7
    //   302: sipush #128
    //   305: iand
    //   306: ifeq -> 315
    //   309: iconst_1
    //   310: istore #8
    //   312: goto -> 318
    //   315: iconst_0
    //   316: istore #8
    //   318: new com/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$b
    //   321: dup
    //   322: iload #6
    //   324: iload #8
    //   326: iload_2
    //   327: invokespecial <init> : (IZI)V
    //   330: astore_1
    //   331: goto -> 370
    //   334: new java/lang/StringBuilder
    //   337: dup
    //   338: invokespecial <init> : ()V
    //   341: astore_1
    //   342: aload_1
    //   343: ldc_w 'Skipped ID3 tag with unsupported majorVersion='
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: aload_1
    //   351: iload #6
    //   353: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   356: pop
    //   357: ldc 'Id3Decoder'
    //   359: aload_1
    //   360: invokevirtual toString : ()Ljava/lang/String;
    //   363: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   366: pop
    //   367: goto -> 48
    //   370: aload_1
    //   371: ifnonnull -> 376
    //   374: aconst_null
    //   375: areturn
    //   376: aload #11
    //   378: getfield b : I
    //   381: istore #6
    //   383: iload #5
    //   385: istore_2
    //   386: aload_1
    //   387: getfield a : I
    //   390: iconst_2
    //   391: if_icmpne -> 397
    //   394: bipush #6
    //   396: istore_2
    //   397: aload_1
    //   398: getfield c : I
    //   401: istore #4
    //   403: iload #4
    //   405: istore_3
    //   406: aload_1
    //   407: getfield b : Z
    //   410: ifeq -> 421
    //   413: aload #11
    //   415: iload #4
    //   417: invokestatic f : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;I)I
    //   420: istore_3
    //   421: aload #11
    //   423: iload #6
    //   425: iload_3
    //   426: iadd
    //   427: invokevirtual d : (I)V
    //   430: iload #9
    //   432: istore #8
    //   434: aload #11
    //   436: aload_1
    //   437: getfield a : I
    //   440: iload_2
    //   441: iconst_0
    //   442: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IIZ)Z
    //   445: ifne -> 514
    //   448: aload_1
    //   449: getfield a : I
    //   452: iconst_4
    //   453: if_icmpne -> 473
    //   456: aload #11
    //   458: iconst_4
    //   459: iload_2
    //   460: iconst_1
    //   461: invokestatic a : (Lcom/fyber/inneractive/sdk/player/exoplayer2/util/k;IIZ)Z
    //   464: ifeq -> 473
    //   467: iconst_1
    //   468: istore #8
    //   470: goto -> 514
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: astore #10
    //   482: aload #10
    //   484: ldc_w 'Failed to validate ID3 tag with majorVersion='
    //   487: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   490: pop
    //   491: aload #10
    //   493: aload_1
    //   494: getfield a : I
    //   497: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   500: pop
    //   501: ldc 'Id3Decoder'
    //   503: aload #10
    //   505: invokevirtual toString : ()Ljava/lang/String;
    //   508: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   511: pop
    //   512: aconst_null
    //   513: areturn
    //   514: aload #11
    //   516: invokevirtual a : ()I
    //   519: iload_2
    //   520: if_icmplt -> 557
    //   523: aload_1
    //   524: getfield a : I
    //   527: aload #11
    //   529: iload #8
    //   531: iload_2
    //   532: aload_0
    //   533: getfield a : Lcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$a;
    //   536: invokestatic a : (ILcom/fyber/inneractive/sdk/player/exoplayer2/util/k;ZILcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/g$a;)Lcom/fyber/inneractive/sdk/player/exoplayer2/metadata/id3/h;
    //   539: astore #12
    //   541: aload #12
    //   543: ifnull -> 514
    //   546: aload #10
    //   548: aload #12
    //   550: invokevirtual add : (Ljava/lang/Object;)Z
    //   553: pop
    //   554: goto -> 514
    //   557: new com/fyber/inneractive/sdk/player/exoplayer2/metadata/a
    //   560: dup
    //   561: aload #10
    //   563: invokespecial <init> : (Ljava/util/List;)V
    //   566: areturn
  }
  
  public static interface a {}
  
  public static final class b {
    public final int a;
    
    public final boolean b;
    
    public final int c;
    
    public b(int param1Int1, boolean param1Boolean, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Boolean;
      this.c = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\player\exoplayer2\metadata\id3\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */