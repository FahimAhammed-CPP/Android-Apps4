package com.fyber.inneractive.sdk.player.controller;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Application;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.fyber.inneractive.sdk.R;
import com.fyber.inneractive.sdk.config.IAConfigManager;
import com.fyber.inneractive.sdk.config.a0;
import com.fyber.inneractive.sdk.config.b0;
import com.fyber.inneractive.sdk.config.c0;
import com.fyber.inneractive.sdk.config.enums.Skip;
import com.fyber.inneractive.sdk.config.f0;
import com.fyber.inneractive.sdk.config.global.features.d;
import com.fyber.inneractive.sdk.config.global.features.r;
import com.fyber.inneractive.sdk.config.global.s;
import com.fyber.inneractive.sdk.config.i;
import com.fyber.inneractive.sdk.flow.vast.e;
import com.fyber.inneractive.sdk.measurement.d;
import com.fyber.inneractive.sdk.model.vast.g;
import com.fyber.inneractive.sdk.model.vast.s;
import com.fyber.inneractive.sdk.player.e;
import com.fyber.inneractive.sdk.player.enums.VideoClickOrigin;
import com.fyber.inneractive.sdk.player.ui.d;
import com.fyber.inneractive.sdk.player.ui.f;
import com.fyber.inneractive.sdk.player.ui.i;
import com.fyber.inneractive.sdk.player.ui.l;
import com.fyber.inneractive.sdk.player.ui.m;
import com.fyber.inneractive.sdk.response.i;
import com.fyber.inneractive.sdk.util.IAlog;
import com.fyber.inneractive.sdk.util.k0;
import com.fyber.inneractive.sdk.util.l;
import com.fyber.inneractive.sdk.util.m;
import com.fyber.inneractive.sdk.web.c0;
import com.fyber.inneractive.sdk.web.d0;
import com.iab.omid.library.fyber.adsession.AdSession;
import com.iab.omid.library.fyber.adsession.FriendlyObstructionPurpose;

public abstract class k<ListenerT extends u> implements b<ListenerT>, g.f, g.e, i {
  public Skip A = null;
  
  public boolean B = false;
  
  public com.fyber.inneractive.sdk.player.b a;
  
  public b0 b;
  
  public s c;
  
  public l d;
  
  public g.g e;
  
  public int f = 0;
  
  public ListenerT g;
  
  public boolean h = false;
  
  public float i = -0.1F;
  
  public Runnable j;
  
  public boolean k;
  
  public boolean l = false;
  
  public Application.ActivityLifecycleCallbacks m;
  
  public boolean n;
  
  public boolean o = false;
  
  public Bitmap p = null;
  
  public AsyncTask<?, ?, ?> q = null;
  
  public boolean r = false;
  
  public boolean s = false;
  
  public boolean t = false;
  
  public boolean u = false;
  
  public boolean v = false;
  
  public com.fyber.inneractive.sdk.ignite.k w = com.fyber.inneractive.sdk.ignite.k.NONE;
  
  public f x;
  
  public String y;
  
  public boolean z;
  
  public k(com.fyber.inneractive.sdk.player.b paramb, l paraml, b0 paramb0, s params, boolean paramBoolean1, Skip paramSkip, String paramString, boolean paramBoolean2) {
    this.A = paramSkip;
    this.a = paramb;
    this.b = paramb0;
    this.c = params;
    this.d = paraml;
    this.n = paramBoolean1;
    this.y = paramString;
    this.z = paramBoolean2;
    paraml.setListener(this);
    i();
    new GestureDetector(paraml.getContext(), (GestureDetector.OnGestureListener)new a(this));
  }
  
  public k(com.fyber.inneractive.sdk.player.b paramb, l paraml, b0 paramb0, s params, boolean paramBoolean1, String paramString, boolean paramBoolean2) {
    this(paramb, paraml, paramb0, params, paramBoolean1, null, paramString, paramBoolean2);
  }
  
  public static boolean a(k paramk) {
    return (paramk.c() != null && ((com.fyber.inneractive.sdk.flow.vast.a)paramk.c()).c);
  }
  
  public void A() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   4: iconst_0
    //   5: invokevirtual a : (Z)V
    //   8: aload_0
    //   9: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   12: iconst_0
    //   13: invokevirtual c : (Z)V
    //   16: aload_0
    //   17: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   20: astore_2
    //   21: new com/fyber/inneractive/sdk/player/ui/c
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore_3
    //   29: aload_3
    //   30: iconst_0
    //   31: putfield b : Z
    //   34: aload_2
    //   35: new com/fyber/inneractive/sdk/player/ui/b
    //   38: dup
    //   39: aload_3
    //   40: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/ui/c;)V
    //   43: invokevirtual d : (Lcom/fyber/inneractive/sdk/player/ui/b;)V
    //   46: aload_0
    //   47: invokevirtual j : ()V
    //   50: aload_0
    //   51: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   54: ifnull -> 201
    //   57: aload_0
    //   58: invokevirtual B : ()Z
    //   61: ifeq -> 201
    //   64: aload_0
    //   65: getfield h : Z
    //   68: ifne -> 201
    //   71: aload_0
    //   72: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   75: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   78: invokevirtual d : ()I
    //   81: istore_1
    //   82: aload_0
    //   83: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   86: astore_2
    //   87: iload_1
    //   88: aload_2
    //   89: checkcast com/fyber/inneractive/sdk/player/e
    //   92: getfield A : Lcom/fyber/inneractive/sdk/config/b0;
    //   95: aload_2
    //   96: invokestatic a : (Lcom/fyber/inneractive/sdk/player/b;)I
    //   99: invokestatic a : (ILcom/fyber/inneractive/sdk/config/b0;I)Z
    //   102: ifeq -> 201
    //   105: aload_0
    //   106: getfield f : I
    //   109: ifgt -> 127
    //   112: aload_0
    //   113: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   116: iconst_1
    //   117: invokevirtual d : (Z)V
    //   120: aload_0
    //   121: invokevirtual n : ()V
    //   124: goto -> 201
    //   127: aload_0
    //   128: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   131: astore_2
    //   132: aload_2
    //   133: ifnull -> 173
    //   136: aload_2
    //   137: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 173
    //   145: aload_2
    //   146: invokevirtual d : ()I
    //   149: sipush #1000
    //   152: idiv
    //   153: istore_1
    //   154: aload_0
    //   155: getfield f : I
    //   158: iload_1
    //   159: if_icmplt -> 173
    //   162: aload_0
    //   163: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   166: iconst_0
    //   167: invokevirtual d : (Z)V
    //   170: goto -> 201
    //   173: aload_0
    //   174: getfield s : Z
    //   177: ifne -> 201
    //   180: aload_0
    //   181: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   184: iconst_1
    //   185: invokevirtual d : (Z)V
    //   188: aload_0
    //   189: aload_0
    //   190: getfield f : I
    //   193: invokevirtual c : (I)V
    //   196: aload_0
    //   197: iconst_1
    //   198: putfield s : Z
    //   201: aload_0
    //   202: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   205: astore_2
    //   206: aload_2
    //   207: ifnull -> 228
    //   210: aload_0
    //   211: getfield k : Z
    //   214: ifne -> 228
    //   217: aload_0
    //   218: iconst_1
    //   219: putfield k : Z
    //   222: aload_2
    //   223: invokeinterface l : ()V
    //   228: aload_0
    //   229: iconst_0
    //   230: putfield o : Z
    //   233: aload_0
    //   234: iconst_0
    //   235: putfield t : Z
    //   238: return
  }
  
  public abstract boolean B();
  
  public void C() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   4: astore #4
    //   6: aconst_null
    //   7: astore #6
    //   9: aload #4
    //   11: ifnull -> 29
    //   14: aload #4
    //   16: ldc com/fyber/inneractive/sdk/config/global/features/r
    //   18: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   21: checkcast com/fyber/inneractive/sdk/config/global/features/r
    //   24: astore #4
    //   26: goto -> 32
    //   29: aconst_null
    //   30: astore #4
    //   32: iconst_1
    //   33: istore_3
    //   34: aload #4
    //   36: ifnull -> 51
    //   39: aload #4
    //   41: ldc 'show_cta'
    //   43: iconst_1
    //   44: invokevirtual a : (Ljava/lang/String;Z)Z
    //   47: istore_2
    //   48: goto -> 53
    //   51: iconst_1
    //   52: istore_2
    //   53: aload_0
    //   54: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   57: astore #4
    //   59: aload #4
    //   61: ifnull -> 75
    //   64: aload_0
    //   65: aload #4
    //   67: invokeinterface q : ()Lcom/fyber/inneractive/sdk/ignite/k;
    //   72: putfield w : Lcom/fyber/inneractive/sdk/ignite/k;
    //   75: aload_0
    //   76: getfield w : Lcom/fyber/inneractive/sdk/ignite/k;
    //   79: astore #7
    //   81: aload #7
    //   83: getstatic com/fyber/inneractive/sdk/ignite/k.NONE : Lcom/fyber/inneractive/sdk/ignite/k;
    //   86: if_acmpeq -> 94
    //   89: iload_3
    //   90: istore_2
    //   91: goto -> 94
    //   94: aload_0
    //   95: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   98: astore #8
    //   100: aload #8
    //   102: getfield k : Landroid/widget/TextView;
    //   105: ifnull -> 364
    //   108: iconst_0
    //   109: istore_1
    //   110: iload_2
    //   111: ifeq -> 156
    //   114: aload #8
    //   116: getfield K : Lcom/fyber/inneractive/sdk/config/global/s;
    //   119: astore #4
    //   121: aload #4
    //   123: ifnull -> 156
    //   126: aload #4
    //   128: ldc com/fyber/inneractive/sdk/config/global/features/r
    //   130: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   133: ifnull -> 156
    //   136: aload #8
    //   138: getfield K : Lcom/fyber/inneractive/sdk/config/global/s;
    //   141: ldc com/fyber/inneractive/sdk/config/global/features/r
    //   143: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   146: checkcast com/fyber/inneractive/sdk/config/global/features/r
    //   149: invokevirtual c : ()Z
    //   152: istore_3
    //   153: goto -> 158
    //   156: iconst_0
    //   157: istore_3
    //   158: aload #8
    //   160: getfield k : Landroid/widget/TextView;
    //   163: iload_3
    //   164: invokevirtual setAllCaps : (Z)V
    //   167: aload #8
    //   169: getfield K : Lcom/fyber/inneractive/sdk/config/global/s;
    //   172: astore #4
    //   174: aload #4
    //   176: ifnull -> 194
    //   179: aload #4
    //   181: ldc com/fyber/inneractive/sdk/config/global/features/d
    //   183: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   186: checkcast com/fyber/inneractive/sdk/config/global/features/d
    //   189: astore #5
    //   191: goto -> 197
    //   194: aconst_null
    //   195: astore #5
    //   197: aload #6
    //   199: astore #4
    //   201: aload #5
    //   203: ifnull -> 252
    //   206: aload #5
    //   208: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   211: getfield p : Ljava/lang/String;
    //   214: invokevirtual e : (Ljava/lang/String;)V
    //   217: aload #5
    //   219: getfield e : Lcom/fyber/inneractive/sdk/model/vast/a;
    //   222: astore #5
    //   224: aload #6
    //   226: astore #4
    //   228: aload #5
    //   230: ifnull -> 252
    //   233: aload #6
    //   235: astore #4
    //   237: aload #5
    //   239: getfield d : Z
    //   242: ifeq -> 252
    //   245: aload #5
    //   247: getfield a : Ljava/lang/String;
    //   250: astore #4
    //   252: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   255: getfield E : Lcom/fyber/inneractive/sdk/ignite/c;
    //   258: invokevirtual d : ()Z
    //   261: ifeq -> 286
    //   264: aload #7
    //   266: invokevirtual e : ()Z
    //   269: ifeq -> 286
    //   272: aload #8
    //   274: getfield k : Landroid/widget/TextView;
    //   277: getstatic com/fyber/inneractive/sdk/R$string.ia_video_instant_install_text : I
    //   280: invokevirtual setText : (I)V
    //   283: goto -> 318
    //   286: aload #4
    //   288: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   291: ifne -> 307
    //   294: aload #8
    //   296: getfield k : Landroid/widget/TextView;
    //   299: aload #4
    //   301: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   304: goto -> 318
    //   307: aload #8
    //   309: getfield k : Landroid/widget/TextView;
    //   312: getstatic com/fyber/inneractive/sdk/R$string.ia_video_install_now_text : I
    //   315: invokevirtual setText : (I)V
    //   318: aload #8
    //   320: getfield N : Ljava/lang/String;
    //   323: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   326: ifne -> 342
    //   329: aload #8
    //   331: getfield k : Landroid/widget/TextView;
    //   334: aload #8
    //   336: getfield N : Ljava/lang/String;
    //   339: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   342: aload #8
    //   344: getfield k : Landroid/widget/TextView;
    //   347: astore #4
    //   349: iload_2
    //   350: ifeq -> 356
    //   353: goto -> 358
    //   356: iconst_4
    //   357: istore_1
    //   358: aload #4
    //   360: iload_1
    //   361: invokevirtual setVisibility : (I)V
    //   364: return
  }
  
  public void D() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   4: astore #10
    //   6: aload #10
    //   8: ifnull -> 63
    //   11: aload #10
    //   13: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   16: astore #10
    //   18: aload #10
    //   20: ifnull -> 37
    //   23: aload #10
    //   25: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   28: getstatic com/fyber/inneractive/sdk/player/enums/b.Completed : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   31: invokevirtual equals : (Ljava/lang/Object;)Z
    //   34: ifne -> 44
    //   37: aload_0
    //   38: getfield t : Z
    //   41: ifeq -> 63
    //   44: aload_0
    //   45: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   48: getfield i : Lcom/fyber/inneractive/sdk/measurement/d;
    //   51: astore #10
    //   53: aload #10
    //   55: ifnull -> 63
    //   58: aload #10
    //   60: invokevirtual a : ()V
    //   63: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   66: astore #14
    //   68: aload #14
    //   70: getfield u : Lcom/fyber/inneractive/sdk/config/j;
    //   73: getfield b : Lcom/fyber/inneractive/sdk/config/i;
    //   76: ldc_w 'endcard'
    //   79: invokevirtual a : (Ljava/lang/String;)Lcom/fyber/inneractive/sdk/config/g;
    //   82: astore #10
    //   84: iconst_0
    //   85: istore #9
    //   87: iconst_0
    //   88: istore #7
    //   90: aload #10
    //   92: ldc_w 'dsos'
    //   95: iconst_0
    //   96: invokevirtual a : (Ljava/lang/String;Z)Z
    //   99: istore #8
    //   101: aload_0
    //   102: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   105: astore #10
    //   107: aload #10
    //   109: ifnull -> 144
    //   112: aload #10
    //   114: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   117: astore #10
    //   119: aload #10
    //   121: ifnull -> 144
    //   124: aload #10
    //   126: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   129: getstatic com/fyber/inneractive/sdk/player/enums/b.Completed : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   132: invokevirtual equals : (Ljava/lang/Object;)Z
    //   135: ifeq -> 144
    //   138: iconst_1
    //   139: istore #5
    //   141: goto -> 147
    //   144: iconst_0
    //   145: istore #5
    //   147: iload #5
    //   149: ifne -> 180
    //   152: aload_0
    //   153: getfield t : Z
    //   156: ifeq -> 164
    //   159: iload #8
    //   161: ifeq -> 180
    //   164: aload_0
    //   165: getfield u : Z
    //   168: ifeq -> 174
    //   171: goto -> 180
    //   174: iconst_0
    //   175: istore #5
    //   177: goto -> 183
    //   180: iconst_1
    //   181: istore #5
    //   183: iload #5
    //   185: ifeq -> 1453
    //   188: aload_0
    //   189: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   192: astore #10
    //   194: aconst_null
    //   195: astore #12
    //   197: aconst_null
    //   198: astore #13
    //   200: aload #10
    //   202: ifnull -> 215
    //   205: aload #10
    //   207: invokevirtual c : ()Landroid/view/View;
    //   210: astore #10
    //   212: goto -> 218
    //   215: aconst_null
    //   216: astore #10
    //   218: aload #10
    //   220: ifnull -> 229
    //   223: iconst_1
    //   224: istore #5
    //   226: goto -> 232
    //   229: iconst_0
    //   230: istore #5
    //   232: aload_0
    //   233: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   236: invokevirtual d : ()V
    //   239: aload_0
    //   240: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   243: astore #11
    //   245: aload #11
    //   247: ifnull -> 265
    //   250: aload #11
    //   252: ldc com/fyber/inneractive/sdk/config/global/features/r
    //   254: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   257: checkcast com/fyber/inneractive/sdk/config/global/features/r
    //   260: astore #11
    //   262: goto -> 268
    //   265: aconst_null
    //   266: astore #11
    //   268: iload #5
    //   270: ifeq -> 721
    //   273: aload #10
    //   275: instanceof com/fyber/inneractive/sdk/web/g
    //   278: ifeq -> 438
    //   281: aload_0
    //   282: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   285: astore #12
    //   287: aload #12
    //   289: ifnull -> 317
    //   292: aload #12
    //   294: checkcast com/fyber/inneractive/sdk/player/e
    //   297: getfield B : Lcom/fyber/inneractive/sdk/flow/k;
    //   300: astore #12
    //   302: aload #12
    //   304: ifnull -> 317
    //   307: aload #12
    //   309: getfield m : Lcom/fyber/inneractive/sdk/player/controller/c;
    //   312: astore #12
    //   314: goto -> 320
    //   317: aconst_null
    //   318: astore #12
    //   320: aload #12
    //   322: ifnull -> 398
    //   325: new com/fyber/inneractive/sdk/player/controller/o
    //   328: dup
    //   329: aload_0
    //   330: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/controller/k;)V
    //   333: astore #14
    //   335: aload #12
    //   337: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   340: astore #15
    //   342: aload #15
    //   344: ifnull -> 354
    //   347: aload #15
    //   349: aload #14
    //   351: invokevirtual setListener : (Lcom/fyber/inneractive/sdk/web/d0;)V
    //   354: aload #12
    //   356: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   359: astore #14
    //   361: aload #14
    //   363: ifnull -> 380
    //   366: aload #12
    //   368: getfield c : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   371: invokestatic a : (Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;)Z
    //   374: pop
    //   375: aload #14
    //   377: invokevirtual o : ()V
    //   380: aload #12
    //   382: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   385: astore #14
    //   387: aload #14
    //   389: ifnull -> 398
    //   392: aload #14
    //   394: iconst_1
    //   395: invokevirtual a : (Z)V
    //   398: aload #12
    //   400: ifnull -> 438
    //   403: aload #12
    //   405: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   408: astore #12
    //   410: aload #12
    //   412: ifnull -> 429
    //   415: aload #12
    //   417: invokevirtual p : ()Z
    //   420: ifeq -> 429
    //   423: iconst_1
    //   424: istore #5
    //   426: goto -> 432
    //   429: iconst_0
    //   430: istore #5
    //   432: iload #5
    //   434: ifeq -> 438
    //   437: return
    //   438: aload_0
    //   439: invokevirtual l : ()V
    //   442: aload_0
    //   443: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   446: iconst_0
    //   447: invokevirtual b : (Z)V
    //   450: aload_0
    //   451: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   454: getfield j : Landroid/view/ViewGroup;
    //   457: astore #12
    //   459: aload #12
    //   461: ifnull -> 470
    //   464: aload #12
    //   466: iconst_4
    //   467: invokevirtual setVisibility : (I)V
    //   470: aload_0
    //   471: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   474: iconst_0
    //   475: invokevirtual c : (Z)V
    //   478: aload_0
    //   479: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   482: astore #14
    //   484: aload_0
    //   485: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   488: astore #12
    //   490: aload #12
    //   492: ifnull -> 505
    //   495: aload #12
    //   497: invokevirtual d : ()Lcom/fyber/inneractive/sdk/model/vast/c;
    //   500: astore #12
    //   502: goto -> 508
    //   505: aconst_null
    //   506: astore #12
    //   508: new com/fyber/inneractive/sdk/player/ui/c
    //   511: dup
    //   512: invokespecial <init> : ()V
    //   515: astore #15
    //   517: aload #15
    //   519: iconst_1
    //   520: putfield b : Z
    //   523: aload #15
    //   525: aload #10
    //   527: putfield g : Landroid/view/View;
    //   530: aload #12
    //   532: ifnull -> 542
    //   535: aload #12
    //   537: getfield a : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   540: astore #13
    //   542: aload #15
    //   544: aload #13
    //   546: putfield h : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   549: aload #11
    //   551: ifnull -> 568
    //   554: aload #11
    //   556: invokevirtual c : ()Z
    //   559: ifeq -> 568
    //   562: iconst_1
    //   563: istore #8
    //   565: goto -> 571
    //   568: iconst_0
    //   569: istore #8
    //   571: aload #15
    //   573: iload #8
    //   575: putfield c : Z
    //   578: aload_0
    //   579: aload #11
    //   581: invokevirtual b : (Lcom/fyber/inneractive/sdk/config/global/features/r;)Lcom/fyber/inneractive/sdk/config/global/features/r$c;
    //   584: astore #12
    //   586: aload_0
    //   587: aload #11
    //   589: invokevirtual a : (Lcom/fyber/inneractive/sdk/config/global/features/r;)I
    //   592: istore #5
    //   594: aload #15
    //   596: aload #12
    //   598: putfield i : Lcom/fyber/inneractive/sdk/config/global/features/r$c;
    //   601: aload #15
    //   603: iload #5
    //   605: putfield j : I
    //   608: iload #7
    //   610: istore #5
    //   612: aload_0
    //   613: aload #11
    //   615: invokevirtual d : (Lcom/fyber/inneractive/sdk/config/global/features/r;)Z
    //   618: ifeq -> 669
    //   621: aload_0
    //   622: invokevirtual c : ()Lcom/fyber/inneractive/sdk/flow/vast/e;
    //   625: astore #12
    //   627: aload #12
    //   629: ifnull -> 654
    //   632: aload #12
    //   634: getfield a : Z
    //   637: ifeq -> 654
    //   640: aload #12
    //   642: getfield b : Landroid/view/View;
    //   645: ifnull -> 654
    //   648: iconst_1
    //   649: istore #6
    //   651: goto -> 657
    //   654: iconst_0
    //   655: istore #6
    //   657: iload #7
    //   659: istore #5
    //   661: iload #6
    //   663: ifne -> 669
    //   666: iconst_1
    //   667: istore #5
    //   669: aload_0
    //   670: aload #11
    //   672: invokevirtual c : (Lcom/fyber/inneractive/sdk/config/global/features/r;)I
    //   675: istore #6
    //   677: iload #5
    //   679: ifeq -> 692
    //   682: aload #15
    //   684: iload #6
    //   686: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   689: putfield f : Ljava/lang/Integer;
    //   692: aload #14
    //   694: new com/fyber/inneractive/sdk/player/ui/b
    //   697: dup
    //   698: aload #15
    //   700: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/ui/c;)V
    //   703: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/ui/b;)V
    //   706: aload_0
    //   707: getstatic com/fyber/inneractive/sdk/model/vast/g.Other : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   710: iconst_1
    //   711: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/g;I)V
    //   714: aload #10
    //   716: invokevirtual requestFocus : ()Z
    //   719: pop
    //   720: return
    //   721: aload_0
    //   722: getfield z : Z
    //   725: ifne -> 747
    //   728: aload_0
    //   729: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   732: astore #10
    //   734: aload #10
    //   736: ifnull -> 747
    //   739: aload #10
    //   741: invokeinterface k : ()V
    //   746: return
    //   747: aload_0
    //   748: getfield x : Lcom/fyber/inneractive/sdk/player/ui/f;
    //   751: ifnull -> 764
    //   754: aload_0
    //   755: iconst_1
    //   756: invokevirtual h : (Z)Landroid/graphics/Bitmap;
    //   759: astore #10
    //   761: goto -> 788
    //   764: aload_0
    //   765: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   768: astore #10
    //   770: aload #10
    //   772: ifnull -> 785
    //   775: aload #10
    //   777: getfield l : Landroid/graphics/Bitmap;
    //   780: astore #10
    //   782: goto -> 788
    //   785: aconst_null
    //   786: astore #10
    //   788: aload #10
    //   790: ifnull -> 802
    //   793: aload_0
    //   794: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   797: aload #10
    //   799: invokevirtual setLastFrameBitmap : (Landroid/graphics/Bitmap;)V
    //   802: aload_0
    //   803: invokevirtual c : ()Lcom/fyber/inneractive/sdk/flow/vast/e;
    //   806: astore #10
    //   808: aload #10
    //   810: ifnull -> 835
    //   813: aload #10
    //   815: getfield a : Z
    //   818: ifeq -> 835
    //   821: aload #10
    //   823: getfield b : Landroid/view/View;
    //   826: ifnull -> 835
    //   829: iconst_1
    //   830: istore #5
    //   832: goto -> 838
    //   835: iconst_0
    //   836: istore #5
    //   838: iload #5
    //   840: ifeq -> 975
    //   843: aload #10
    //   845: getfield g : Lcom/fyber/inneractive/sdk/player/controller/c;
    //   848: astore #13
    //   850: new com/fyber/inneractive/sdk/player/controller/o
    //   853: dup
    //   854: aload_0
    //   855: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/controller/k;)V
    //   858: astore #12
    //   860: aload #13
    //   862: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   865: astore #13
    //   867: aload #13
    //   869: ifnull -> 879
    //   872: aload #13
    //   874: aload #12
    //   876: invokevirtual setListener : (Lcom/fyber/inneractive/sdk/web/d0;)V
    //   879: aload_0
    //   880: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   883: astore #12
    //   885: new com/fyber/inneractive/sdk/player/ui/c
    //   888: dup
    //   889: invokespecial <init> : ()V
    //   892: astore #13
    //   894: aload #13
    //   896: iconst_1
    //   897: putfield b : Z
    //   900: aload #13
    //   902: aload #10
    //   904: getfield b : Landroid/view/View;
    //   907: putfield g : Landroid/view/View;
    //   910: getstatic com/fyber/inneractive/sdk/model/vast/g.FMP_End_Card : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   913: astore #10
    //   915: aload #13
    //   917: aload #10
    //   919: putfield h : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   922: aload_0
    //   923: aload #11
    //   925: invokevirtual d : (Lcom/fyber/inneractive/sdk/config/global/features/r;)Z
    //   928: istore #8
    //   930: aload_0
    //   931: aload #11
    //   933: invokevirtual c : (Lcom/fyber/inneractive/sdk/config/global/features/r;)I
    //   936: istore #5
    //   938: iload #8
    //   940: ifeq -> 953
    //   943: aload #13
    //   945: iload #5
    //   947: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   950: putfield f : Ljava/lang/Integer;
    //   953: aload #12
    //   955: new com/fyber/inneractive/sdk/player/ui/b
    //   958: dup
    //   959: aload #13
    //   961: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/ui/c;)V
    //   964: invokevirtual a : (Lcom/fyber/inneractive/sdk/player/ui/b;)V
    //   967: aload_0
    //   968: aload #10
    //   970: iconst_1
    //   971: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/g;I)V
    //   974: return
    //   975: aload_0
    //   976: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   979: iconst_1
    //   980: invokevirtual b : (Z)V
    //   983: aload_0
    //   984: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   987: iconst_0
    //   988: invokevirtual c : (Z)V
    //   991: new com/fyber/inneractive/sdk/player/ui/c
    //   994: dup
    //   995: invokespecial <init> : ()V
    //   998: astore #13
    //   1000: aload #13
    //   1002: aload_0
    //   1003: getfield z : Z
    //   1006: putfield b : Z
    //   1009: aload #11
    //   1011: ifnull -> 1028
    //   1014: aload #11
    //   1016: invokevirtual c : ()Z
    //   1019: ifeq -> 1028
    //   1022: iconst_1
    //   1023: istore #8
    //   1025: goto -> 1031
    //   1028: iconst_0
    //   1029: istore #8
    //   1031: aload #13
    //   1033: iload #8
    //   1035: putfield c : Z
    //   1038: aload_0
    //   1039: getfield y : Ljava/lang/String;
    //   1042: astore #10
    //   1044: aload #10
    //   1046: ifnull -> 1052
    //   1049: goto -> 1118
    //   1052: aload_0
    //   1053: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   1056: astore #10
    //   1058: aload #10
    //   1060: ifnull -> 1115
    //   1063: aload #10
    //   1065: ldc com/fyber/inneractive/sdk/config/global/features/d
    //   1067: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   1070: checkcast com/fyber/inneractive/sdk/config/global/features/d
    //   1073: astore #10
    //   1075: aload #10
    //   1077: aload #14
    //   1079: getfield p : Ljava/lang/String;
    //   1082: invokevirtual e : (Ljava/lang/String;)V
    //   1085: aload #10
    //   1087: getfield e : Lcom/fyber/inneractive/sdk/model/vast/a;
    //   1090: astore #10
    //   1092: aload #10
    //   1094: ifnull -> 1115
    //   1097: aload #10
    //   1099: getfield d : Z
    //   1102: ifeq -> 1115
    //   1105: aload #10
    //   1107: getfield a : Ljava/lang/String;
    //   1110: astore #10
    //   1112: goto -> 1118
    //   1115: aconst_null
    //   1116: astore #10
    //   1118: aload #13
    //   1120: aload #10
    //   1122: putfield e : Ljava/lang/String;
    //   1125: aload_0
    //   1126: aload #11
    //   1128: invokevirtual d : (Lcom/fyber/inneractive/sdk/config/global/features/r;)Z
    //   1131: istore #8
    //   1133: aload_0
    //   1134: aload #11
    //   1136: invokevirtual c : (Lcom/fyber/inneractive/sdk/config/global/features/r;)I
    //   1139: istore #5
    //   1141: iload #8
    //   1143: ifeq -> 1156
    //   1146: aload #13
    //   1148: iload #5
    //   1150: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1153: putfield f : Ljava/lang/Integer;
    //   1156: aload_0
    //   1157: aload #11
    //   1159: invokevirtual b : (Lcom/fyber/inneractive/sdk/config/global/features/r;)Lcom/fyber/inneractive/sdk/config/global/features/r$c;
    //   1162: astore #10
    //   1164: aload_0
    //   1165: aload #11
    //   1167: invokevirtual a : (Lcom/fyber/inneractive/sdk/config/global/features/r;)I
    //   1170: istore #5
    //   1172: aload #13
    //   1174: aload #10
    //   1176: putfield i : Lcom/fyber/inneractive/sdk/config/global/features/r$c;
    //   1179: aload #13
    //   1181: iload #5
    //   1183: putfield j : I
    //   1186: aload_0
    //   1187: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   1190: astore #10
    //   1192: aload #10
    //   1194: ifnull -> 1213
    //   1197: aload #10
    //   1199: ldc_w com/fyber/inneractive/sdk/config/global/features/i
    //   1202: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   1205: checkcast com/fyber/inneractive/sdk/config/global/features/i
    //   1208: astore #10
    //   1210: goto -> 1216
    //   1213: aconst_null
    //   1214: astore #10
    //   1216: aload #10
    //   1218: ifnull -> 1295
    //   1221: aload #13
    //   1223: aload #10
    //   1225: ldc_w 'should_show_hand'
    //   1228: iconst_0
    //   1229: invokevirtual a : (Ljava/lang/String;Z)Z
    //   1232: putfield a : Z
    //   1235: ldc2_w 1.2999999523162842
    //   1238: dstore_1
    //   1239: aload #10
    //   1241: ldc_w 'scale_up_to'
    //   1244: invokevirtual a : (Ljava/lang/String;)Ljava/lang/Double;
    //   1247: astore #10
    //   1249: aload #10
    //   1251: ifnull -> 1260
    //   1254: aload #10
    //   1256: invokevirtual doubleValue : ()D
    //   1259: dstore_1
    //   1260: dload_1
    //   1261: d2f
    //   1262: fstore #4
    //   1264: fload #4
    //   1266: ldc_w 1.7
    //   1269: fcmpl
    //   1270: ifgt -> 1285
    //   1273: fload #4
    //   1275: fstore_3
    //   1276: fload #4
    //   1278: ldc_w 1.1
    //   1281: fcmpg
    //   1282: ifge -> 1289
    //   1285: ldc_w 1.3
    //   1288: fstore_3
    //   1289: aload #13
    //   1291: fload_3
    //   1292: putfield d : F
    //   1295: aload_0
    //   1296: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   1299: astore #10
    //   1301: iload #9
    //   1303: istore #8
    //   1305: aload #10
    //   1307: ifnull -> 1333
    //   1310: iload #9
    //   1312: istore #8
    //   1314: aload #10
    //   1316: aload_0
    //   1317: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   1320: aload_0
    //   1321: getfield w : Lcom/fyber/inneractive/sdk/ignite/k;
    //   1324: invokevirtual a : (Lcom/fyber/inneractive/sdk/config/global/s;Lcom/fyber/inneractive/sdk/ignite/k;)Z
    //   1327: ifeq -> 1333
    //   1330: iconst_1
    //   1331: istore #8
    //   1333: aload #13
    //   1335: iload #8
    //   1337: putfield l : Z
    //   1340: aload_0
    //   1341: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   1344: astore #11
    //   1346: aload #12
    //   1348: astore #10
    //   1350: aload #11
    //   1352: ifnull -> 1368
    //   1355: aload #11
    //   1357: ldc_w com/fyber/inneractive/sdk/config/global/features/n
    //   1360: invokevirtual a : (Ljava/lang/Class;)Lcom/fyber/inneractive/sdk/config/global/features/h;
    //   1363: checkcast com/fyber/inneractive/sdk/config/global/features/n
    //   1366: astore #10
    //   1368: aload #10
    //   1370: ifnull -> 1383
    //   1373: aload #10
    //   1375: invokevirtual c : ()Ljava/lang/String;
    //   1378: astore #10
    //   1380: goto -> 1398
    //   1383: aload_0
    //   1384: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   1387: invokevirtual getContext : ()Landroid/content/Context;
    //   1390: getstatic com/fyber/inneractive/sdk/R$string.ia_video_app_info_text : I
    //   1393: invokevirtual getString : (I)Ljava/lang/String;
    //   1396: astore #10
    //   1398: aload #13
    //   1400: aload #10
    //   1402: putfield m : Ljava/lang/String;
    //   1405: aload_0
    //   1406: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   1409: astore #10
    //   1411: aload #10
    //   1413: ifnull -> 1428
    //   1416: aload #13
    //   1418: aload #10
    //   1420: invokeinterface q : ()Lcom/fyber/inneractive/sdk/ignite/k;
    //   1425: putfield k : Lcom/fyber/inneractive/sdk/ignite/k;
    //   1428: aload_0
    //   1429: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   1432: new com/fyber/inneractive/sdk/player/ui/b
    //   1435: dup
    //   1436: aload #13
    //   1438: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/ui/c;)V
    //   1441: invokevirtual d : (Lcom/fyber/inneractive/sdk/player/ui/b;)V
    //   1444: aload_0
    //   1445: getstatic com/fyber/inneractive/sdk/model/vast/g.Default_End_Card : Lcom/fyber/inneractive/sdk/model/vast/g;
    //   1448: iconst_1
    //   1449: invokevirtual a : (Lcom/fyber/inneractive/sdk/model/vast/g;I)V
    //   1452: return
    //   1453: aload_0
    //   1454: getfield t : Z
    //   1457: ifeq -> 1482
    //   1460: iload #8
    //   1462: ifeq -> 1482
    //   1465: aload_0
    //   1466: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   1469: iconst_0
    //   1470: invokevirtual b : (Z)V
    //   1473: aload_0
    //   1474: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   1477: iconst_0
    //   1478: invokevirtual c : (Z)V
    //   1481: return
    //   1482: aload_0
    //   1483: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   1486: iconst_1
    //   1487: invokevirtual c : (Z)V
    //   1490: return
  }
  
  public void E() {
    l l1 = this.d;
    if (l1.u != null)
      l1.setMuteButtonState(t()); 
  }
  
  public final int a(r paramr) {
    char c2 = 'Ǵ';
    char c1 = c2;
    if (paramr != null) {
      char c;
      Integer integer = paramr.b("endcard_animation_duration");
      if (integer != null) {
        c = integer.intValue();
      } else {
        c = 'Ǵ';
      } 
      c1 = c2;
      if (c >= 'Ǵ') {
        if (c > 'ஸ')
          return 500; 
        c1 = c;
      } 
    } 
    return c1;
  }
  
  public void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   4: astore #10
    //   6: aload #10
    //   8: ifnull -> 650
    //   11: aload #10
    //   13: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_0
    //   21: invokevirtual r : ()F
    //   24: fstore_2
    //   25: aload_0
    //   26: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   29: astore #10
    //   31: aload #10
    //   33: ifnull -> 116
    //   36: aload #10
    //   38: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   41: astore #10
    //   43: aload #10
    //   45: ifnull -> 116
    //   48: aload #10
    //   50: invokevirtual j : ()Z
    //   53: ifeq -> 116
    //   56: aload_0
    //   57: getfield i : F
    //   60: fstore_3
    //   61: fload_2
    //   62: fload_3
    //   63: fcmpl
    //   64: ifeq -> 112
    //   67: fload_2
    //   68: fconst_0
    //   69: fcmpl
    //   70: istore_1
    //   71: iload_1
    //   72: ifle -> 96
    //   75: fload_3
    //   76: fconst_0
    //   77: fcmpl
    //   78: iflt -> 96
    //   81: aload_0
    //   82: invokevirtual t : ()Z
    //   85: ifeq -> 96
    //   88: aload_0
    //   89: iconst_1
    //   90: invokevirtual j : (Z)V
    //   93: goto -> 112
    //   96: iload_1
    //   97: ifne -> 112
    //   100: aload_0
    //   101: invokevirtual t : ()Z
    //   104: ifne -> 112
    //   107: aload_0
    //   108: iconst_1
    //   109: invokevirtual g : (Z)V
    //   112: aload_0
    //   113: invokevirtual E : ()V
    //   116: aload_0
    //   117: fload_2
    //   118: putfield i : F
    //   121: aload_0
    //   122: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   125: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   128: invokevirtual d : ()I
    //   131: istore #5
    //   133: aload_0
    //   134: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   137: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   140: invokevirtual c : ()I
    //   143: istore #6
    //   145: iload #6
    //   147: sipush #1000
    //   150: idiv
    //   151: istore #7
    //   153: iload #5
    //   155: sipush #1000
    //   158: idiv
    //   159: istore #8
    //   161: iload #8
    //   163: iload #7
    //   165: isub
    //   166: istore #4
    //   168: iload #4
    //   170: iflt -> 199
    //   173: iload #4
    //   175: istore_1
    //   176: aload_0
    //   177: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   180: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   183: invokevirtual j : ()Z
    //   186: ifne -> 201
    //   189: iload #4
    //   191: istore_1
    //   192: iload #6
    //   194: iload #5
    //   196: if_icmpne -> 201
    //   199: iconst_0
    //   200: istore_1
    //   201: aload_0
    //   202: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   205: astore #10
    //   207: aload #10
    //   209: getfield n : Landroid/widget/TextView;
    //   212: ifnonnull -> 224
    //   215: aload #10
    //   217: getfield w : Lcom/fyber/inneractive/sdk/ui/IAsmoothProgressBar;
    //   220: ifnonnull -> 224
    //   223: return
    //   224: aload #10
    //   226: iload_1
    //   227: invokestatic toString : (I)Ljava/lang/String;
    //   230: invokevirtual setRemainingTime : (Ljava/lang/String;)V
    //   233: aload_0
    //   234: getfield f : I
    //   237: iload #8
    //   239: if_icmpge -> 351
    //   242: aload_0
    //   243: invokevirtual B : ()Z
    //   246: ifeq -> 340
    //   249: aload_0
    //   250: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   253: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   256: invokevirtual d : ()I
    //   259: istore #4
    //   261: aload_0
    //   262: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   265: astore #10
    //   267: iload #4
    //   269: aload #10
    //   271: checkcast com/fyber/inneractive/sdk/player/e
    //   274: getfield A : Lcom/fyber/inneractive/sdk/config/b0;
    //   277: aload #10
    //   279: invokestatic a : (Lcom/fyber/inneractive/sdk/player/b;)I
    //   282: invokestatic a : (ILcom/fyber/inneractive/sdk/config/b0;I)Z
    //   285: ifeq -> 340
    //   288: aload_0
    //   289: getfield h : Z
    //   292: ifne -> 340
    //   295: aload_0
    //   296: getfield f : I
    //   299: istore #4
    //   301: iload #7
    //   303: iload #4
    //   305: if_icmpge -> 320
    //   308: aload_0
    //   309: iload #4
    //   311: iload #7
    //   313: isub
    //   314: invokevirtual c : (I)V
    //   317: goto -> 329
    //   320: aload_0
    //   321: iconst_0
    //   322: putfield f : I
    //   325: aload_0
    //   326: invokevirtual n : ()V
    //   329: aload_0
    //   330: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   333: iconst_1
    //   334: invokevirtual d : (Z)V
    //   337: goto -> 364
    //   340: aload_0
    //   341: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   344: iconst_0
    //   345: invokevirtual d : (Z)V
    //   348: goto -> 364
    //   351: aload_0
    //   352: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   355: iconst_0
    //   356: invokevirtual d : (Z)V
    //   359: aload_0
    //   360: iload_1
    //   361: invokevirtual c : (I)V
    //   364: aload_0
    //   365: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   368: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   371: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   374: getstatic com/fyber/inneractive/sdk/player/enums/b.Paused : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   377: if_acmpeq -> 628
    //   380: aload_0
    //   381: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   384: astore #10
    //   386: aload #10
    //   388: getfield w : Lcom/fyber/inneractive/sdk/ui/IAsmoothProgressBar;
    //   391: ifnonnull -> 397
    //   394: goto -> 562
    //   397: aload #10
    //   399: getfield F : Ljava/lang/Runnable;
    //   402: astore #11
    //   404: aload #11
    //   406: ifnull -> 423
    //   409: aload #10
    //   411: aload #11
    //   413: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   416: pop
    //   417: aload #10
    //   419: aconst_null
    //   420: putfield F : Ljava/lang/Runnable;
    //   423: iload #8
    //   425: sipush #1000
    //   428: imul
    //   429: istore #4
    //   431: aload #10
    //   433: getfield w : Lcom/fyber/inneractive/sdk/ui/IAsmoothProgressBar;
    //   436: iload #4
    //   438: invokevirtual setMax : (I)V
    //   441: iload #4
    //   443: iload_1
    //   444: sipush #1000
    //   447: imul
    //   448: isub
    //   449: istore #9
    //   451: iload #9
    //   453: sipush #1000
    //   456: iadd
    //   457: istore_1
    //   458: aload #10
    //   460: iload_1
    //   461: putfield E : I
    //   464: iload #9
    //   466: sipush #200
    //   469: iadd
    //   470: istore #9
    //   472: iload_1
    //   473: ifle -> 562
    //   476: iload_1
    //   477: iload #4
    //   479: if_icmple -> 485
    //   482: goto -> 562
    //   485: aload #10
    //   487: getfield D : I
    //   490: istore #4
    //   492: iload #9
    //   494: iload #4
    //   496: if_icmpge -> 516
    //   499: iload #4
    //   501: ifle -> 516
    //   504: aload #10
    //   506: getfield w : Lcom/fyber/inneractive/sdk/ui/IAsmoothProgressBar;
    //   509: iload_1
    //   510: invokevirtual setProgress : (I)V
    //   513: goto -> 562
    //   516: aload #10
    //   518: iload #9
    //   520: putfield D : I
    //   523: aload #10
    //   525: getfield w : Lcom/fyber/inneractive/sdk/ui/IAsmoothProgressBar;
    //   528: iload #9
    //   530: invokevirtual setProgress : (I)V
    //   533: new com/fyber/inneractive/sdk/player/ui/n
    //   536: dup
    //   537: aload #10
    //   539: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/ui/l;)V
    //   542: astore #11
    //   544: aload #10
    //   546: aload #11
    //   548: putfield F : Ljava/lang/Runnable;
    //   551: aload #10
    //   553: aload #11
    //   555: ldc2_w 200
    //   558: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   561: pop
    //   562: aload_0
    //   563: invokevirtual q : ()I
    //   566: istore_1
    //   567: iload #8
    //   569: iload_1
    //   570: if_icmple -> 628
    //   573: iload #7
    //   575: iload_1
    //   576: if_icmple -> 628
    //   579: aload_0
    //   580: getfield b : Lcom/fyber/inneractive/sdk/config/b0;
    //   583: astore #10
    //   585: aload #10
    //   587: ifnull -> 628
    //   590: aload #10
    //   592: checkcast com/fyber/inneractive/sdk/config/a0
    //   595: getfield f : Lcom/fyber/inneractive/sdk/config/c0;
    //   598: astore #10
    //   600: aload #10
    //   602: ifnull -> 628
    //   605: aload #10
    //   607: getfield j : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   610: getstatic com/fyber/inneractive/sdk/config/enums/UnitDisplayType.REWARDED : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   613: if_acmpne -> 628
    //   616: aload_0
    //   617: invokevirtual n : ()V
    //   620: aload_0
    //   621: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   624: iconst_1
    //   625: invokevirtual d : (Z)V
    //   628: aload_0
    //   629: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   632: astore #10
    //   634: aload #10
    //   636: ifnull -> 650
    //   639: aload #10
    //   641: iload #5
    //   643: iload #6
    //   645: invokeinterface onProgress : (II)V
    //   650: return
  }
  
  public final void a(int paramInt1, int paramInt2) {
    Bitmap bitmap = this.p;
    if ((bitmap == null || bitmap.getWidth() != paramInt1 || this.p.getHeight() != paramInt2) && paramInt2 > 0) {
      if (paramInt1 <= 0)
        return; 
      AsyncTask<?, ?, ?> asyncTask = this.q;
      if (asyncTask != null)
        asyncTask.cancel(true); 
      this.p = null;
      asyncTask = new b(this);
      this.q = asyncTask;
      asyncTask.executeOnExecutor(m.a, (Object[])new Integer[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    } 
  }
  
  public void a(int paramInt, k0 paramk0) {
    com.fyber.inneractive.sdk.player.b b1;
    com.fyber.inneractive.sdk.player.b b2;
    i i1;
    ListenerT listenerT;
    IAlog.a("onClicked called with %d", new Object[] { Integer.valueOf(paramInt) });
    switch (paramInt) {
      default:
        return;
      case 10:
        a(f0.b.APP_INFO.value);
        a(false, VideoClickOrigin.APP_INFO, paramk0);
        return;
      case 9:
        b1 = this.a;
        if (b1 != null && !((d)this.d).h) {
          b1.k = true;
          i(false);
          return;
        } 
        return;
      case 8:
        a(f0.b.COMPANION.value);
        a(true, VideoClickOrigin.COMPANION, (k0)b1);
        return;
      case 7:
        a((k0)b1);
        return;
      case 6:
        c(true);
        return;
      case 5:
        w();
        return;
      case 4:
        a(f0.b.COMPANION.value);
        b2 = this.a;
        if (b2 != null) {
          i1 = (i)b2.d();
        } else {
          i1 = null;
        } 
        if (i1 != null && ((com.fyber.inneractive.sdk.model.vast.c)i1).a == g.Static) {
          String str2 = ((com.fyber.inneractive.sdk.model.vast.c)i1).g;
          com.fyber.inneractive.sdk.player.b b3 = this.a;
          String str1 = str2;
          if (b3 != null) {
            b3.a(i1, VideoClickOrigin.COMPANION, new s[] { s.EVENT_CLICK });
            str1 = str2;
          } 
        } else {
          b2 = null;
        } 
        m();
        listenerT = this.g;
        if (listenerT != null) {
          listenerT.a((String)b2, (k0)b1, null, false);
          return;
        } 
        return;
      case 3:
        a(f0.b.CTA_BUTTON.value);
        a(false, VideoClickOrigin.CTA, (k0)b1);
        return;
      case 2:
        y();
        return;
      case 1:
        break;
    } 
    if (t()) {
      j(true);
      com.fyber.inneractive.sdk.player.b b3 = this.a;
      if (b3 != null) {
        VideoClickOrigin videoClickOrigin = VideoClickOrigin.MUTE;
        s s1 = s.EVENT_UNMUTE;
        e e1 = (e)b3;
        e1.a((i)e1.x, videoClickOrigin, new s[] { s1 });
      } 
    } else {
      g(true);
      com.fyber.inneractive.sdk.player.b b3 = this.a;
      if (b3 != null) {
        VideoClickOrigin videoClickOrigin = VideoClickOrigin.MUTE;
        s s1 = s.EVENT_MUTE;
        e e1 = (e)b3;
        e1.a((i)e1.x, videoClickOrigin, new s[] { s1 });
      } 
    } 
    E();
  }
  
  public void a(long paramLong) {
    boolean bool;
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      View view = b1.c();
    } else {
      b1 = null;
    } 
    l l1 = this.d;
    if (b1 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    ObjectAnimator objectAnimator = l1.L;
    if (objectAnimator != null) {
      if (objectAnimator.getDuration() <= paramLong) {
        ViewGroup viewGroup1 = l1.z;
        if (viewGroup1 != null)
          l1.a((View)viewGroup1.getParent(), 4); 
        l1.L.start();
        l1.L.addListener((Animator.AnimatorListener)new m(l1));
      } else {
        l1.M = true;
        l1.L = null;
        ViewGroup viewGroup1 = l1.z;
        if (viewGroup1 != null && viewGroup1.getParent() != null)
          ((View)l1.z.getParent()).setOnTouchListener(null); 
      } 
      if (bool) {
        View view = l1.y;
        if (view != null) {
          view.setVisibility(0);
          return;
        } 
      } 
      ViewGroup viewGroup = l1.z;
      if (viewGroup != null)
        viewGroup.setVisibility(0); 
    } 
  }
  
  public void a(Bitmap paramBitmap) {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null && g1.e != com.fyber.inneractive.sdk.player.enums.b.Completed) {
        this.d.a(b1.k);
        this.d.b(true);
        this.d.setLastFrameBitmap(paramBitmap);
      } 
    } 
  }
  
  public void a(g paramg, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 477
    //   11: aload #4
    //   13: checkcast com/fyber/inneractive/sdk/player/e
    //   16: astore #5
    //   18: aload #5
    //   20: invokevirtual getClass : ()Ljava/lang/Class;
    //   23: pop
    //   24: ldc_w 'notifyCompanionDisplayed'
    //   27: iconst_0
    //   28: anewarray java/lang/Object
    //   31: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   34: getstatic com/fyber/inneractive/sdk/player/e$b.a : [I
    //   37: aload_1
    //   38: invokevirtual ordinal : ()I
    //   41: iaload
    //   42: istore_3
    //   43: iload_3
    //   44: iconst_1
    //   45: if_icmpeq -> 377
    //   48: iload_3
    //   49: iconst_2
    //   50: if_icmpeq -> 220
    //   53: aload #5
    //   55: invokevirtual c : ()Landroid/view/View;
    //   58: ifnull -> 477
    //   61: aload #5
    //   63: getfield B : Lcom/fyber/inneractive/sdk/flow/k;
    //   66: astore_1
    //   67: aload_1
    //   68: ifnull -> 477
    //   71: aload_1
    //   72: getfield g : Z
    //   75: ifne -> 477
    //   78: aload #5
    //   80: getfield x : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   83: getfield h : Lcom/fyber/inneractive/sdk/model/vast/c;
    //   86: astore_1
    //   87: aload_1
    //   88: ifnull -> 477
    //   91: aload #5
    //   93: aload_1
    //   94: getstatic com/fyber/inneractive/sdk/player/enums/VideoClickOrigin.COMPANION : Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;
    //   97: iconst_1
    //   98: anewarray com/fyber/inneractive/sdk/model/vast/s
    //   101: dup
    //   102: iconst_0
    //   103: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_CREATIVE_VIEW : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   106: aastore
    //   107: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;[Lcom/fyber/inneractive/sdk/model/vast/s;)V
    //   110: aload #5
    //   112: getfield B : Lcom/fyber/inneractive/sdk/flow/k;
    //   115: astore #4
    //   117: aload #4
    //   119: getfield g : Z
    //   122: ifne -> 213
    //   125: getstatic com/fyber/inneractive/sdk/network/p.VAST_COMPANION_DISPLAYED : Lcom/fyber/inneractive/sdk/network/p;
    //   128: astore #5
    //   130: aload #4
    //   132: getfield b : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   135: astore #6
    //   137: aload #4
    //   139: getfield c : Lcom/fyber/inneractive/sdk/response/g;
    //   142: astore #7
    //   144: aload #4
    //   146: getfield d : Lcom/fyber/inneractive/sdk/config/global/s;
    //   149: astore_1
    //   150: aload_1
    //   151: ifnonnull -> 159
    //   154: aconst_null
    //   155: astore_1
    //   156: goto -> 164
    //   159: aload_1
    //   160: invokevirtual c : ()Lorg/json/JSONArray;
    //   163: astore_1
    //   164: new com/fyber/inneractive/sdk/network/q$a
    //   167: dup
    //   168: aload #5
    //   170: aload #6
    //   172: aload #7
    //   174: aload_1
    //   175: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   178: astore_1
    //   179: aload_1
    //   180: iconst_2
    //   181: anewarray java/lang/Object
    //   184: dup
    //   185: iconst_0
    //   186: ldc_w 'companion_data'
    //   189: aastore
    //   190: dup
    //   191: iconst_1
    //   192: aload #4
    //   194: getfield e : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   197: getfield h : Lcom/fyber/inneractive/sdk/model/vast/c;
    //   200: invokevirtual a : ()Lorg/json/JSONObject;
    //   203: aastore
    //   204: invokevirtual a : ([Ljava/lang/Object;)Lcom/fyber/inneractive/sdk/network/q$a;
    //   207: pop
    //   208: aload_1
    //   209: aconst_null
    //   210: invokevirtual a : (Ljava/lang/String;)V
    //   213: aload #4
    //   215: iconst_1
    //   216: putfield g : Z
    //   219: return
    //   220: aload #5
    //   222: getfield B : Lcom/fyber/inneractive/sdk/flow/k;
    //   225: astore_1
    //   226: aload_1
    //   227: ifnull -> 477
    //   230: aload_1
    //   231: getfield l : Lcom/fyber/inneractive/sdk/flow/vast/c;
    //   234: astore #4
    //   236: aload #4
    //   238: ifnull -> 477
    //   241: aload #4
    //   243: iconst_1
    //   244: putfield c : Z
    //   247: aload_1
    //   248: getfield b : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   251: astore #5
    //   253: aload_1
    //   254: getfield c : Lcom/fyber/inneractive/sdk/response/g;
    //   257: astore #6
    //   259: aload_1
    //   260: getfield d : Lcom/fyber/inneractive/sdk/config/global/s;
    //   263: astore #7
    //   265: aload #4
    //   267: iload_2
    //   268: putfield d : I
    //   271: aload #4
    //   273: getfield g : Lcom/fyber/inneractive/sdk/player/controller/c;
    //   276: getfield a : Lcom/fyber/inneractive/sdk/web/c0;
    //   279: astore_1
    //   280: aload_1
    //   281: instanceof com/fyber/inneractive/sdk/web/c
    //   284: ifeq -> 307
    //   287: aload_1
    //   288: checkcast com/fyber/inneractive/sdk/web/c
    //   291: getfield Q : Lcom/fyber/inneractive/sdk/web/b;
    //   294: astore_1
    //   295: aload_1
    //   296: ifnull -> 307
    //   299: aload_1
    //   300: getfield b : Ljava/lang/String;
    //   303: astore_1
    //   304: goto -> 309
    //   307: aconst_null
    //   308: astore_1
    //   309: aload #4
    //   311: aload_1
    //   312: putfield e : Ljava/lang/String;
    //   315: aload #4
    //   317: getfield h : Z
    //   320: ifne -> 477
    //   323: getstatic com/fyber/inneractive/sdk/network/p.FMP_COMPANION_SUCCESSFULLY_SHOWN : Lcom/fyber/inneractive/sdk/network/p;
    //   326: astore #8
    //   328: aload #7
    //   330: ifnonnull -> 338
    //   333: aconst_null
    //   334: astore_1
    //   335: goto -> 344
    //   338: aload #7
    //   340: invokevirtual c : ()Lorg/json/JSONArray;
    //   343: astore_1
    //   344: new com/fyber/inneractive/sdk/network/q$a
    //   347: dup
    //   348: aload #8
    //   350: aload #5
    //   352: aload #6
    //   354: aload_1
    //   355: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   358: astore_1
    //   359: aload #4
    //   361: aload_1
    //   362: invokevirtual a : (Lcom/fyber/inneractive/sdk/network/q$a;)V
    //   365: aload_1
    //   366: aconst_null
    //   367: invokevirtual a : (Ljava/lang/String;)V
    //   370: aload #4
    //   372: iconst_1
    //   373: putfield h : Z
    //   376: return
    //   377: aload #5
    //   379: getfield C : Z
    //   382: ifne -> 477
    //   385: getstatic com/fyber/inneractive/sdk/network/p.VAST_DEFAULT_COMPANION_DISPLAYED : Lcom/fyber/inneractive/sdk/network/p;
    //   388: astore #6
    //   390: aload #5
    //   392: getfield g : Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;
    //   395: astore #7
    //   397: aload #5
    //   399: getfield f : Lcom/fyber/inneractive/sdk/flow/d0;
    //   402: astore #4
    //   404: aload #4
    //   406: ifnull -> 421
    //   409: aload #4
    //   411: getfield b : Lcom/fyber/inneractive/sdk/response/e;
    //   414: checkcast com/fyber/inneractive/sdk/response/g
    //   417: astore_1
    //   418: goto -> 423
    //   421: aconst_null
    //   422: astore_1
    //   423: aload #4
    //   425: ifnull -> 450
    //   428: aload #4
    //   430: getfield c : Lcom/fyber/inneractive/sdk/config/global/s;
    //   433: astore #4
    //   435: aload #4
    //   437: ifnull -> 450
    //   440: aload #4
    //   442: invokevirtual c : ()Lorg/json/JSONArray;
    //   445: astore #4
    //   447: goto -> 453
    //   450: aconst_null
    //   451: astore #4
    //   453: new com/fyber/inneractive/sdk/network/q$a
    //   456: dup
    //   457: aload #6
    //   459: aload #7
    //   461: aload_1
    //   462: aload #4
    //   464: invokespecial <init> : (Lcom/fyber/inneractive/sdk/network/p;Lcom/fyber/inneractive/sdk/external/InneractiveAdRequest;Lcom/fyber/inneractive/sdk/response/e;Lorg/json/JSONArray;)V
    //   467: aconst_null
    //   468: invokevirtual a : (Ljava/lang/String;)V
    //   471: aload #5
    //   473: iconst_1
    //   474: putfield C : Z
    //   477: return
  }
  
  public void a(c paramc) {
    o o = new o(this);
    c0 c0 = paramc.a;
    if (c0 != null)
      c0.setListener((d0)o); 
  }
  
  public void a(ListenerT paramListenerT) {
    this.g = paramListenerT;
  }
  
  public void a(com.fyber.inneractive.sdk.player.enums.b paramb) {
    IAlog.a("%sonPlayerStateChanged with %s", new Object[] { IAlog.a(this), paramb });
    a(paramb, true);
  }
  
  public final void a(com.fyber.inneractive.sdk.player.enums.b paramb, boolean paramBoolean) {
    switch (c.a[paramb.ordinal()]) {
      default:
        return;
      case 6:
        if (this.r) {
          c(false);
          return;
        } 
        return;
      case 5:
        if (this.r || (!this.z && !this.v)) {
          this.v = true;
          v();
          if (paramBoolean) {
            ListenerT listenerT = this.g;
            if (listenerT != null) {
              listenerT.onCompleted();
              return;
            } 
          } 
        } 
        return;
      case 4:
        x();
        return;
      case 3:
        if (this.r) {
          A();
          return;
        } 
        return;
      case 2:
        if (this.r) {
          this.d.a(true);
          this.d.c(false);
          Runnable runnable = this.j;
          if (runnable == null) {
            if (runnable == null)
              this.j = (Runnable)new l(this); 
            int j = o();
            IAlog.a("%s Starting buffering timeout with %d", new Object[] { IAlog.a(this), Integer.valueOf(j) });
            this.d.postDelayed(this.j, j);
            return;
          } 
        } 
        return;
      case 1:
        break;
    } 
    if (this.r) {
      this.d.b(true);
      D();
      z();
    } 
  }
  
  public abstract void a(k0 paramk0);
  
  public void a(Exception paramException) {}
  
  public final void a(String paramString) {
    f0 f0 = IAConfigManager.M.x;
    b0 b01 = this.b;
    if (b01 != null) {
      c0 c0 = ((a0)b01).f;
      if (c0 != null)
        f0.a(c0.j, "LAST_VAST_CLICKED_TYPE", paramString); 
    } 
  }
  
  public void a(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Z
    //   4: iload_1
    //   5: if_icmpne -> 9
    //   8: return
    //   9: aload_0
    //   10: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 447
    //   18: aload_2
    //   19: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   22: ifnonnull -> 26
    //   25: return
    //   26: ldc_w '%sonVisibilityChanged: %s my video view is%s'
    //   29: iconst_3
    //   30: anewarray java/lang/Object
    //   33: dup
    //   34: iconst_0
    //   35: aload_0
    //   36: invokestatic a : (Ljava/lang/Object;)Ljava/lang/String;
    //   39: aastore
    //   40: dup
    //   41: iconst_1
    //   42: iload_1
    //   43: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   46: aastore
    //   47: dup
    //   48: iconst_2
    //   49: aload_0
    //   50: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   53: aastore
    //   54: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   57: iload_1
    //   58: ifeq -> 318
    //   61: aload_0
    //   62: iconst_1
    //   63: putfield r : Z
    //   66: aload_0
    //   67: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   70: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   73: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   76: astore_2
    //   77: aload_2
    //   78: getstatic com/fyber/inneractive/sdk/player/enums/b.Completed : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: ifne -> 246
    //   87: aload_0
    //   88: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   91: invokevirtual f : ()Z
    //   94: ifeq -> 100
    //   97: goto -> 246
    //   100: aload_2
    //   101: getstatic com/fyber/inneractive/sdk/player/enums/b.Error : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   104: invokevirtual equals : (Ljava/lang/Object;)Z
    //   107: ifne -> 240
    //   110: aload_2
    //   111: getstatic com/fyber/inneractive/sdk/player/enums/b.Idle : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   114: invokevirtual equals : (Ljava/lang/Object;)Z
    //   117: ifeq -> 131
    //   120: aload_0
    //   121: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   124: invokevirtual getClass : ()Ljava/lang/Class;
    //   127: pop
    //   128: goto -> 240
    //   131: aload_2
    //   132: getstatic com/fyber/inneractive/sdk/player/enums/b.Start_in_progress : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   135: if_acmpeq -> 145
    //   138: aload_2
    //   139: getstatic com/fyber/inneractive/sdk/player/enums/b.Playing : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   142: if_acmpne -> 149
    //   145: aload_0
    //   146: invokevirtual A : ()V
    //   149: aload_0
    //   150: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   153: astore_2
    //   154: aload_2
    //   155: getfield q : Z
    //   158: ifne -> 200
    //   161: aload_2
    //   162: checkcast com/fyber/inneractive/sdk/player/e
    //   165: astore_3
    //   166: getstatic com/fyber/inneractive/sdk/player/enums/VideoClickOrigin.InvalidOrigin : Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;
    //   169: astore #4
    //   171: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_CREATIVE_VIEW : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   174: astore #5
    //   176: aload_3
    //   177: aload_3
    //   178: getfield x : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   181: aload #4
    //   183: iconst_1
    //   184: anewarray com/fyber/inneractive/sdk/model/vast/s
    //   187: dup
    //   188: iconst_0
    //   189: aload #5
    //   191: aastore
    //   192: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;[Lcom/fyber/inneractive/sdk/model/vast/s;)V
    //   195: aload_2
    //   196: iconst_1
    //   197: putfield q : Z
    //   200: aload_0
    //   201: invokevirtual k : ()Z
    //   204: pop
    //   205: aload_0
    //   206: getfield m : Landroid/app/Application$ActivityLifecycleCallbacks;
    //   209: ifnonnull -> 447
    //   212: getstatic com/fyber/inneractive/sdk/util/l.a : Landroid/app/Application;
    //   215: astore_2
    //   216: aload_2
    //   217: ifnull -> 447
    //   220: new com/fyber/inneractive/sdk/player/controller/m
    //   223: dup
    //   224: aload_0
    //   225: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/controller/k;)V
    //   228: astore_3
    //   229: aload_0
    //   230: aload_3
    //   231: putfield m : Landroid/app/Application$ActivityLifecycleCallbacks;
    //   234: aload_2
    //   235: aload_3
    //   236: invokevirtual registerActivityLifecycleCallbacks : (Landroid/app/Application$ActivityLifecycleCallbacks;)V
    //   239: return
    //   240: aload_0
    //   241: iconst_0
    //   242: invokevirtual c : (Z)V
    //   245: return
    //   246: aload_0
    //   247: getfield v : Z
    //   250: ifne -> 284
    //   253: aload_0
    //   254: iconst_1
    //   255: putfield v : Z
    //   258: aload_0
    //   259: getfield B : Z
    //   262: ifne -> 284
    //   265: aload_0
    //   266: invokevirtual v : ()V
    //   269: aload_0
    //   270: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   273: astore_2
    //   274: aload_2
    //   275: ifnull -> 284
    //   278: aload_2
    //   279: invokeinterface onCompleted : ()V
    //   284: aload_0
    //   285: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   288: astore_2
    //   289: aload_2
    //   290: ifnull -> 447
    //   293: aload_2
    //   294: getfield G : Lcom/fyber/inneractive/sdk/util/t0;
    //   297: ifnull -> 447
    //   300: ldc_w 'Autoclick resumed'
    //   303: iconst_0
    //   304: anewarray java/lang/Object
    //   307: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   310: aload_2
    //   311: getfield G : Lcom/fyber/inneractive/sdk/util/t0;
    //   314: invokevirtual b : ()V
    //   317: return
    //   318: aload_0
    //   319: iconst_0
    //   320: putfield r : Z
    //   323: aload_0
    //   324: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   327: astore_2
    //   328: aload_2
    //   329: ifnull -> 443
    //   332: aload_2
    //   333: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   336: astore_2
    //   337: aload_2
    //   338: ifnull -> 443
    //   341: aload_2
    //   342: getfield d : Lcom/fyber/inneractive/sdk/player/controller/g$g;
    //   345: astore_2
    //   346: aload_2
    //   347: ifnull -> 443
    //   350: aload_2
    //   351: aload_0
    //   352: getfield e : Lcom/fyber/inneractive/sdk/player/controller/g$g;
    //   355: invokevirtual equals : (Ljava/lang/Object;)Z
    //   358: ifeq -> 443
    //   361: ldc_w '%sonVisibilityChanged pausing video'
    //   364: iconst_1
    //   365: anewarray java/lang/Object
    //   368: dup
    //   369: iconst_0
    //   370: aload_0
    //   371: invokestatic a : (Ljava/lang/Object;)Ljava/lang/String;
    //   374: aastore
    //   375: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   378: aload_0
    //   379: invokevirtual pauseVideo : ()V
    //   382: aload_0
    //   383: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   386: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   389: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   392: getstatic com/fyber/inneractive/sdk/player/enums/b.Completed : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   395: if_acmpeq -> 414
    //   398: aload_0
    //   399: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   402: astore_2
    //   403: aload_2
    //   404: ifnull -> 443
    //   407: aload_2
    //   408: invokevirtual f : ()Z
    //   411: ifeq -> 443
    //   414: aload_0
    //   415: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   418: astore_2
    //   419: aload_2
    //   420: getfield G : Lcom/fyber/inneractive/sdk/util/t0;
    //   423: ifnull -> 443
    //   426: ldc_w 'Autoclick paused'
    //   429: iconst_0
    //   430: anewarray java/lang/Object
    //   433: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   436: aload_2
    //   437: getfield G : Lcom/fyber/inneractive/sdk/util/t0;
    //   440: invokevirtual a : ()V
    //   443: aload_0
    //   444: invokevirtual l : ()V
    //   447: return
  }
  
  public boolean a(boolean paramBoolean, VideoClickOrigin paramVideoClickOrigin, k0 paramk0) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual m : ()V
    //   4: aload_0
    //   5: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   8: astore #6
    //   10: iconst_1
    //   11: istore #4
    //   13: aload #6
    //   15: ifnull -> 279
    //   18: iload_1
    //   19: ifeq -> 113
    //   22: aload_0
    //   23: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   26: astore #5
    //   28: aload #5
    //   30: ifnull -> 279
    //   33: aload #5
    //   35: checkcast com/fyber/inneractive/sdk/player/e
    //   38: getfield x : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   41: astore #5
    //   43: aload #5
    //   45: ifnull -> 58
    //   48: aload #5
    //   50: getfield b : Ljava/lang/String;
    //   53: astore #5
    //   55: goto -> 61
    //   58: aconst_null
    //   59: astore #5
    //   61: aload #6
    //   63: aload #5
    //   65: aload_3
    //   66: aconst_null
    //   67: iconst_1
    //   68: invokeinterface a : (Ljava/lang/String;Lcom/fyber/inneractive/sdk/util/k0;Lcom/fyber/inneractive/sdk/web/b$a;Z)Lcom/fyber/inneractive/sdk/util/x$a;
    //   73: pop
    //   74: aload_0
    //   75: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   78: astore #5
    //   80: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_CLICK : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   83: astore_3
    //   84: aload #5
    //   86: checkcast com/fyber/inneractive/sdk/player/e
    //   89: astore #5
    //   91: aload #5
    //   93: aload #5
    //   95: getfield x : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   98: aload_2
    //   99: iconst_1
    //   100: anewarray com/fyber/inneractive/sdk/model/vast/s
    //   103: dup
    //   104: iconst_0
    //   105: aload_3
    //   106: aastore
    //   107: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;[Lcom/fyber/inneractive/sdk/model/vast/s;)V
    //   110: goto -> 279
    //   113: aload_2
    //   114: getstatic com/fyber/inneractive/sdk/player/enums/VideoClickOrigin.VIDEO : Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;
    //   117: if_acmpne -> 128
    //   120: getstatic com/fyber/inneractive/sdk/util/e.VIDEO_CLICK : Lcom/fyber/inneractive/sdk/util/e;
    //   123: astore #5
    //   125: goto -> 148
    //   128: aload_2
    //   129: getstatic com/fyber/inneractive/sdk/player/enums/VideoClickOrigin.APP_INFO : Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;
    //   132: if_acmpne -> 143
    //   135: getstatic com/fyber/inneractive/sdk/util/e.VIDEO_APP_INFO : Lcom/fyber/inneractive/sdk/util/e;
    //   138: astore #5
    //   140: goto -> 148
    //   143: getstatic com/fyber/inneractive/sdk/util/e.VIDEO_CTA : Lcom/fyber/inneractive/sdk/util/e;
    //   146: astore #5
    //   148: aload #6
    //   150: aload_3
    //   151: aload #5
    //   153: invokeinterface a : (Lcom/fyber/inneractive/sdk/util/k0;Lcom/fyber/inneractive/sdk/util/e;)Lcom/fyber/inneractive/sdk/util/x$a;
    //   158: astore_3
    //   159: aload_0
    //   160: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   163: astore #6
    //   165: aload #6
    //   167: ifnull -> 263
    //   170: getstatic com/fyber/inneractive/sdk/model/vast/s.EVENT_CLICK : Lcom/fyber/inneractive/sdk/model/vast/s;
    //   173: astore #5
    //   175: aload #6
    //   177: checkcast com/fyber/inneractive/sdk/player/e
    //   180: astore #6
    //   182: aload #6
    //   184: aload #6
    //   186: getfield x : Lcom/fyber/inneractive/sdk/model/vast/b;
    //   189: aload_2
    //   190: iconst_1
    //   191: anewarray com/fyber/inneractive/sdk/model/vast/s
    //   194: dup
    //   195: iconst_0
    //   196: aload #5
    //   198: aastore
    //   199: invokevirtual a : (Lcom/fyber/inneractive/sdk/response/i;Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;[Lcom/fyber/inneractive/sdk/model/vast/s;)V
    //   202: aload_0
    //   203: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   206: getfield i : Lcom/fyber/inneractive/sdk/measurement/d;
    //   209: astore #5
    //   211: aload #5
    //   213: ifnull -> 263
    //   216: aload #5
    //   218: getfield c : Lcom/iab/omid/library/fyber/adsession/media/MediaEvents;
    //   221: ifnull -> 263
    //   224: ldc_w '%s click'
    //   227: iconst_1
    //   228: anewarray java/lang/Object
    //   231: dup
    //   232: iconst_0
    //   233: ldc_w 'OMVideo'
    //   236: aastore
    //   237: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   240: aload #5
    //   242: getfield c : Lcom/iab/omid/library/fyber/adsession/media/MediaEvents;
    //   245: getstatic com/iab/omid/library/fyber/adsession/media/InteractionType.CLICK : Lcom/iab/omid/library/fyber/adsession/media/InteractionType;
    //   248: invokevirtual adUserInteraction : (Lcom/iab/omid/library/fyber/adsession/media/InteractionType;)V
    //   251: goto -> 263
    //   254: astore #6
    //   256: aload #5
    //   258: aload #6
    //   260: invokevirtual a : (Ljava/lang/Throwable;)V
    //   263: aload_3
    //   264: getfield a : Lcom/fyber/inneractive/sdk/util/x$d;
    //   267: getstatic com/fyber/inneractive/sdk/util/x$d.FAILED : Lcom/fyber/inneractive/sdk/util/x$d;
    //   270: if_acmpeq -> 279
    //   273: iload #4
    //   275: istore_1
    //   276: goto -> 281
    //   279: iconst_0
    //   280: istore_1
    //   281: aload_2
    //   282: getstatic com/fyber/inneractive/sdk/player/enums/VideoClickOrigin.VIDEO : Lcom/fyber/inneractive/sdk/player/enums/VideoClickOrigin;
    //   285: if_acmpne -> 298
    //   288: aload_0
    //   289: getstatic com/fyber/inneractive/sdk/config/f0$b.VIDEO : Lcom/fyber/inneractive/sdk/config/f0$b;
    //   292: getfield value : Ljava/lang/String;
    //   295: invokevirtual a : (Ljava/lang/String;)V
    //   298: iload_1
    //   299: ireturn
    // Exception table:
    //   from	to	target	type
    //   240	251	254	finally
  }
  
  public final r.c b(r paramr) {
    if (paramr != null) {
      String str = paramr.a("endcard_animation_type", r.f.mKey);
      for (r.c c : r.c.values()) {
        if (str.equalsIgnoreCase(c.mKey))
          return c; 
      } 
      return r.c.NONE;
    } 
    return r.f;
  }
  
  public void b() {}
  
  public final int c(r paramr) {
    byte b2 = 3;
    byte b1 = b2;
    if (paramr != null) {
      byte b3;
      Integer integer = paramr.b("autoClickDelay");
      if (integer != null) {
        b3 = integer.intValue();
      } else {
        b3 = 3;
      } 
      b1 = b2;
      if (b3 >= 0) {
        if (b3 > 10)
          return 3; 
        b1 = b3;
      } 
    } 
    return b1;
  }
  
  public e c() {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    com.fyber.inneractive.sdk.flow.vast.c c2 = null;
    com.fyber.inneractive.sdk.flow.vast.c c1 = c2;
    if (b1 != null) {
      com.fyber.inneractive.sdk.flow.k k1 = ((e)b1).B;
      c1 = c2;
      if (k1 != null)
        c1 = k1.l; 
    } 
    return (e)c1;
  }
  
  public final void c(int paramInt) {
    if (this.d != null) {
      String str;
      d d;
      s s1 = this.c;
      s s2 = null;
      if (s1 != null) {
        d = (d)s1.a(d.class);
      } else {
        d = null;
      } 
      s1 = s2;
      if (d != null) {
        d.e(IAConfigManager.M.p);
        com.fyber.inneractive.sdk.model.vast.a a = d.e;
        s1 = s2;
        if (a != null) {
          s1 = s2;
          if (a.d)
            str = a.c; 
        } 
      } 
      if (TextUtils.isEmpty(this.y) && str != null) {
        this.d.setSkipText(str.replaceFirst("\\[TIME\\]", Integer.toString(paramInt)));
        return;
      } 
      this.d.setSkipText(String.valueOf(paramInt));
    } 
  }
  
  public void c(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lcom/fyber/inneractive/sdk/config/b0;
    //   4: astore #6
    //   6: iconst_1
    //   7: istore_3
    //   8: aload #6
    //   10: ifnull -> 44
    //   13: aload #6
    //   15: checkcast com/fyber/inneractive/sdk/config/a0
    //   18: getfield f : Lcom/fyber/inneractive/sdk/config/c0;
    //   21: astore #6
    //   23: aload #6
    //   25: ifnull -> 44
    //   28: aload #6
    //   30: getfield j : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   33: getstatic com/fyber/inneractive/sdk/config/enums/UnitDisplayType.REWARDED : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   36: if_acmpne -> 44
    //   39: iconst_1
    //   40: istore_2
    //   41: goto -> 46
    //   44: iconst_0
    //   45: istore_2
    //   46: invokestatic isCurrentUserAChild : ()Z
    //   49: ifeq -> 137
    //   52: iload_2
    //   53: ifeq -> 137
    //   56: aload_0
    //   57: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   60: ifnull -> 137
    //   63: aload_0
    //   64: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   67: astore #6
    //   69: aload #6
    //   71: ifnull -> 137
    //   74: aload #6
    //   76: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   79: astore #6
    //   81: aload #6
    //   83: ifnull -> 137
    //   86: aload #6
    //   88: invokevirtual c : ()I
    //   91: sipush #1000
    //   94: idiv
    //   95: istore #4
    //   97: aload_0
    //   98: invokevirtual q : ()I
    //   101: istore #5
    //   103: iload_3
    //   104: istore_2
    //   105: aload_0
    //   106: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   109: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   112: invokevirtual d : ()I
    //   115: sipush #1000
    //   118: idiv
    //   119: iload #4
    //   121: isub
    //   122: ifle -> 139
    //   125: iload #4
    //   127: iload #5
    //   129: if_icmpge -> 137
    //   132: iload_3
    //   133: istore_2
    //   134: goto -> 139
    //   137: iconst_0
    //   138: istore_2
    //   139: iload_2
    //   140: ifeq -> 177
    //   143: new com/fyber/inneractive/sdk/player/controller/t
    //   146: dup
    //   147: aload_0
    //   148: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   151: invokevirtual getContext : ()Landroid/content/Context;
    //   154: aload_0
    //   155: invokevirtual p : ()Lcom/fyber/inneractive/sdk/config/global/features/c;
    //   158: new com/fyber/inneractive/sdk/player/controller/n
    //   161: dup
    //   162: aload_0
    //   163: iload_1
    //   164: invokespecial <init> : (Lcom/fyber/inneractive/sdk/player/controller/k;Z)V
    //   167: invokespecial <init> : (Landroid/content/Context;Lcom/fyber/inneractive/sdk/config/global/features/c;Lcom/fyber/inneractive/sdk/player/controller/t$c;)V
    //   170: getfield c : Landroid/app/Dialog;
    //   173: invokevirtual show : ()V
    //   176: return
    //   177: aload_0
    //   178: iload_1
    //   179: invokevirtual f : (Z)V
    //   182: return
  }
  
  public void d(boolean paramBoolean) {
    IAlog.a("%sinitUI", new Object[] { IAlog.a(this) });
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      if (b1.b == null)
        return; 
      this.d.setUnitConfig(this.b);
      l l1 = this.d;
      int j = this.a.b.h();
      int m = this.a.b.g();
      boolean bool = this.n;
      l1.r = j;
      l1.s = m;
      l1.t = bool;
      if (this.a.b.h() > 0 && this.a.b.g() > 0)
        a(this.a.b.h(), this.a.b.g()); 
      if (B()) {
        this.f = s();
      } else {
        this.d.d(false);
      } 
      if (!paramBoolean) {
        a(this.a.b.c());
        a(this.a.b.e, false);
      } 
      E();
    } 
  }
  
  public boolean d() {
    return this.z;
  }
  
  public final boolean d(r paramr) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramr != null) {
      bool1 = bool2;
      if (paramr.a("shouldEnableEndCardAutoClick", false))
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void destroy() {
    Application.ActivityLifecycleCallbacks activityLifecycleCallbacks = this.m;
    if (activityLifecycleCallbacks != null) {
      Application application = l.a;
      if (application != null)
        application.unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks); 
    } 
    IAlog.a("%sdestroy called", new Object[] { IAlog.a(this) });
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null) {
        g1.b.remove(this);
        this.a.b.c.remove(this);
      } 
    } 
    l();
    j();
    AsyncTask<?, ?, ?> asyncTask = this.q;
    if (asyncTask != null)
      asyncTask.cancel(true); 
    this.g = null;
  }
  
  public void e(boolean paramBoolean) {}
  
  public boolean e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   4: astore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: aload #4
    //   10: ifnonnull -> 15
    //   13: iconst_0
    //   14: ireturn
    //   15: aload_0
    //   16: getfield h : Z
    //   19: ifne -> 151
    //   22: aload #4
    //   24: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   27: ifnull -> 35
    //   30: iconst_1
    //   31: istore_1
    //   32: goto -> 37
    //   35: iconst_0
    //   36: istore_1
    //   37: iload_1
    //   38: ifeq -> 151
    //   41: aload_0
    //   42: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   45: astore #4
    //   47: aload #4
    //   49: ifnull -> 94
    //   52: aload #4
    //   54: getfield o : Landroid/widget/TextView;
    //   57: astore #5
    //   59: aload #5
    //   61: ifnull -> 88
    //   64: aload #5
    //   66: invokevirtual getVisibility : ()I
    //   69: ifne -> 88
    //   72: aload #4
    //   74: getfield o : Landroid/widget/TextView;
    //   77: invokevirtual isEnabled : ()Z
    //   80: ifeq -> 88
    //   83: iconst_1
    //   84: istore_1
    //   85: goto -> 90
    //   88: iconst_0
    //   89: istore_1
    //   90: iload_1
    //   91: ifne -> 151
    //   94: aload_0
    //   95: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   98: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   101: invokevirtual d : ()I
    //   104: istore_1
    //   105: aload_0
    //   106: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   109: astore #4
    //   111: iload_3
    //   112: istore_2
    //   113: iload_1
    //   114: aload #4
    //   116: checkcast com/fyber/inneractive/sdk/player/e
    //   119: getfield A : Lcom/fyber/inneractive/sdk/config/b0;
    //   122: aload #4
    //   124: invokestatic a : (Lcom/fyber/inneractive/sdk/player/b;)I
    //   127: invokestatic a : (ILcom/fyber/inneractive/sdk/config/b0;I)Z
    //   130: ifeq -> 153
    //   133: iload_3
    //   134: istore_2
    //   135: aload_0
    //   136: getfield h : Z
    //   139: ifne -> 153
    //   142: iload_3
    //   143: istore_2
    //   144: aload_0
    //   145: getfield f : I
    //   148: ifne -> 153
    //   151: iconst_1
    //   152: istore_2
    //   153: iload_2
    //   154: ireturn
  }
  
  public void f() {
    IAlog.a("%sonVideoViewDetachedFromWindow", new Object[] { IAlog.a(this) });
    l();
  }
  
  public final void f(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_1
    //   2: putfield t : Z
    //   5: getstatic com/fyber/inneractive/sdk/config/IAConfigManager.M : Lcom/fyber/inneractive/sdk/config/IAConfigManager;
    //   8: getfield x : Lcom/fyber/inneractive/sdk/config/f0;
    //   11: astore #6
    //   13: iload_1
    //   14: ifeq -> 64
    //   17: aload #6
    //   19: ifnull -> 64
    //   22: aload_0
    //   23: getfield b : Lcom/fyber/inneractive/sdk/config/b0;
    //   26: astore #7
    //   28: aload #7
    //   30: ifnull -> 64
    //   33: aload #7
    //   35: checkcast com/fyber/inneractive/sdk/config/a0
    //   38: getfield f : Lcom/fyber/inneractive/sdk/config/c0;
    //   41: astore #7
    //   43: aload #7
    //   45: ifnull -> 64
    //   48: aload #6
    //   50: aload #7
    //   52: getfield j : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   55: ldc_w 'LAST_VAST_SKIPED'
    //   58: ldc_w '1'
    //   61: invokevirtual a : (Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;Ljava/lang/String;Ljava/lang/String;)V
    //   64: aload_0
    //   65: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   68: astore #6
    //   70: iconst_0
    //   71: istore_2
    //   72: aload #6
    //   74: ifnull -> 166
    //   77: aload #6
    //   79: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   82: astore #6
    //   84: aload #6
    //   86: ifnull -> 166
    //   89: aload #6
    //   91: invokevirtual m : ()V
    //   94: aload_0
    //   95: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   98: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   101: invokevirtual k : ()V
    //   104: iload_1
    //   105: ifeq -> 166
    //   108: aload_0
    //   109: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   112: getfield i : Lcom/fyber/inneractive/sdk/measurement/d;
    //   115: astore #6
    //   117: aload #6
    //   119: ifnull -> 166
    //   122: aload #6
    //   124: getfield c : Lcom/iab/omid/library/fyber/adsession/media/MediaEvents;
    //   127: ifnull -> 166
    //   130: ldc_w '%s skipped'
    //   133: iconst_1
    //   134: anewarray java/lang/Object
    //   137: dup
    //   138: iconst_0
    //   139: ldc_w 'OMVideo'
    //   142: aastore
    //   143: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   146: aload #6
    //   148: getfield c : Lcom/iab/omid/library/fyber/adsession/media/MediaEvents;
    //   151: invokevirtual skipped : ()V
    //   154: goto -> 166
    //   157: astore #7
    //   159: aload #6
    //   161: aload #7
    //   163: invokevirtual a : (Ljava/lang/Throwable;)V
    //   166: aload_0
    //   167: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   170: invokevirtual f : ()Z
    //   173: ifne -> 349
    //   176: aload_0
    //   177: getfield d : Lcom/fyber/inneractive/sdk/player/ui/l;
    //   180: iconst_0
    //   181: invokevirtual a : (Z)V
    //   184: aload_0
    //   185: invokevirtual j : ()V
    //   188: aload_0
    //   189: invokevirtual D : ()V
    //   192: aload_0
    //   193: iconst_0
    //   194: putfield k : Z
    //   197: aload_0
    //   198: iconst_1
    //   199: putfield h : Z
    //   202: aload_0
    //   203: getfield b : Lcom/fyber/inneractive/sdk/config/b0;
    //   206: astore #6
    //   208: aload #6
    //   210: ifnull -> 349
    //   213: aload #6
    //   215: checkcast com/fyber/inneractive/sdk/config/a0
    //   218: getfield f : Lcom/fyber/inneractive/sdk/config/c0;
    //   221: astore #6
    //   223: aload #6
    //   225: ifnull -> 349
    //   228: aload #6
    //   230: getfield j : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   233: getstatic com/fyber/inneractive/sdk/config/enums/UnitDisplayType.REWARDED : Lcom/fyber/inneractive/sdk/config/enums/UnitDisplayType;
    //   236: if_acmpne -> 349
    //   239: aload_0
    //   240: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   243: astore #6
    //   245: aload #6
    //   247: ifnull -> 349
    //   250: aload_0
    //   251: getfield t : Z
    //   254: ifeq -> 342
    //   257: aload_0
    //   258: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   261: astore #7
    //   263: aload #7
    //   265: ifnull -> 342
    //   268: aload #7
    //   270: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   273: astore #7
    //   275: aload #7
    //   277: ifnull -> 342
    //   280: aload #7
    //   282: invokevirtual c : ()I
    //   285: istore_3
    //   286: aload #7
    //   288: invokevirtual d : ()I
    //   291: istore #5
    //   293: aload_0
    //   294: invokevirtual q : ()I
    //   297: istore #4
    //   299: iload #5
    //   301: iload_3
    //   302: isub
    //   303: ifle -> 316
    //   306: iload_3
    //   307: iload #4
    //   309: sipush #1000
    //   312: imul
    //   313: if_icmplt -> 318
    //   316: iconst_1
    //   317: istore_2
    //   318: iload_2
    //   319: ifeq -> 334
    //   322: aload_0
    //   323: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   326: invokeinterface onCompleted : ()V
    //   331: goto -> 349
    //   334: aload_0
    //   335: iconst_1
    //   336: putfield B : Z
    //   339: goto -> 349
    //   342: aload #6
    //   344: invokeinterface onCompleted : ()V
    //   349: aload_0
    //   350: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   353: ifnull -> 417
    //   356: aload_0
    //   357: getfield f : I
    //   360: ifle -> 407
    //   363: aload_0
    //   364: getfield h : Z
    //   367: ifne -> 407
    //   370: aload_0
    //   371: getfield a : Lcom/fyber/inneractive/sdk/player/b;
    //   374: astore #6
    //   376: aload #6
    //   378: ifnull -> 417
    //   381: aload #6
    //   383: getfield b : Lcom/fyber/inneractive/sdk/player/controller/g;
    //   386: astore #6
    //   388: aload #6
    //   390: ifnull -> 417
    //   393: aload #6
    //   395: getfield e : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   398: getstatic com/fyber/inneractive/sdk/player/enums/b.Completed : Lcom/fyber/inneractive/sdk/player/enums/b;
    //   401: invokevirtual equals : (Ljava/lang/Object;)Z
    //   404: ifeq -> 417
    //   407: aload_0
    //   408: getfield g : Lcom/fyber/inneractive/sdk/player/controller/u;
    //   411: iload_1
    //   412: invokeinterface a : (Z)V
    //   417: aload_0
    //   418: invokevirtual l : ()V
    //   421: return
    // Exception table:
    //   from	to	target	type
    //   146	154	157	finally
  }
  
  public void g() {
    if (!this.r)
      return; 
    if (!this.l) {
      this.l = true;
      this.d.b(false);
    } 
  }
  
  public void g(boolean paramBoolean) {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null)
        g1.b(paramBoolean); 
    } 
    this.d.setMuteButtonState(true);
  }
  
  public Bitmap h(boolean paramBoolean) {
    if (this.p != null) {
      com.fyber.inneractive.sdk.player.b b1 = this.a;
      if (b1 != null) {
        boolean bool;
        g g1 = b1.b;
        if (g1 == null)
          return null; 
        if (this.o)
          return b1.l; 
        TextureView textureView = g1.j;
        String str = IAlog.a(this);
        if (textureView != null && textureView.isAvailable()) {
          bool = true;
        } else {
          bool = false;
        } 
        IAlog.a("%sSave snapshot entered: tv = %s avail = %s", new Object[] { str, textureView, Boolean.valueOf(bool) });
        if (textureView != null && textureView.isAvailable())
          try {
            IAlog.d("creating bitmap on object - %s", new Object[] { this.p });
            null = textureView.getBitmap(this.p);
            if (this.d.getVideoWidth() > 0 && this.d.getVideoHeight() > 0) {
              this.p = null;
              a(this.d.getVideoWidth(), this.d.getVideoHeight());
            } 
            if (paramBoolean) {
              com.fyber.inneractive.sdk.util.c c = new com.fyber.inneractive.sdk.util.c();
              c.c = 20;
              c.d = 1;
              c.a = null.getWidth();
              c.b = null.getHeight();
              this.a.a(com.fyber.inneractive.sdk.util.b.a(this.d.getContext(), null, c));
              this.o = true;
            } else {
              this.a.a(null);
            } 
            IAlog.d("%ssave snapshot succeeded", new Object[] { IAlog.a(this) });
            return this.a.l;
          } catch (Exception exception) {
            IAlog.d("%ssave snapshot failed with exception", new Object[] { IAlog.a(this) });
          }  
      } 
    } 
    return null;
  }
  
  public void h() {
    l l2 = this.d;
    if (l2 != null)
      l2.j(); 
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null && b1.b != null) {
      f f1 = this.x;
      if (f1 != null) {
        f1.invalidate();
        this.x.requestLayout();
      } 
    } 
    l l1 = this.d;
    if (l1 != null) {
      l1.invalidate();
      this.d.requestLayout();
    } 
  }
  
  public void i() {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null) {
        if (!g1.b.contains(this))
          g1.b.add(this); 
        g1 = this.a.b;
        if (!g1.c.contains(this))
          g1.c.add(this); 
      } 
    } 
  }
  
  public void i(boolean paramBoolean) {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      if (!b1.k) {
        D();
        return;
      } 
      if (paramBoolean) {
        g g1 = b1.b;
        if (g1 != null) {
          g1.a(0, true);
          return;
        } 
      } 
      b1.e();
    } 
  }
  
  public final void j() {
    Runnable runnable = this.j;
    if (runnable != null) {
      this.d.removeCallbacks(runnable);
      this.j = null;
    } 
  }
  
  public void j(boolean paramBoolean) {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null)
        g1.d(paramBoolean); 
    } 
    this.d.setMuteButtonState(false);
  }
  
  public boolean k() {
    if (this.x == null) {
      f f2 = new f(this.d);
      this.x = f2;
      com.fyber.inneractive.sdk.player.b b3 = this.a;
      if (b3 != null) {
        d d = b3.i;
        if (d != null) {
          View[] arrayOfView = this.d.getTrackingFriendlyView();
          AdSession adSession = d.a;
          if (adSession != null)
            try {
              adSession.registerAdView((View)f2);
            } finally {
              f2 = null;
            }  
          if (d.a != null && arrayOfView != null) {
            int m = arrayOfView.length;
            for (int j = 0; j < m; j++) {
              View view = arrayOfView[j];
              if (view != null)
                try {
                  d.a.addFriendlyObstruction(view, FriendlyObstructionPurpose.VIDEO_CONTROLS, null);
                } finally {
                  view = null;
                }  
            } 
          } 
          arrayOfView = this.d.getTrackingFriendlyViewObstructionPurposeOther();
          if (d.a != null) {
            int m = arrayOfView.length;
            for (int j = 0; j < m; j++) {
              View view = arrayOfView[j];
              if (view != null)
                try {
                  d.a.addFriendlyObstruction(view, FriendlyObstructionPurpose.OTHER, null);
                } finally {
                  view = null;
                }  
            } 
          } 
        } 
      } 
    } 
    IAlog.a("%sconnectToTextureView called %s", new Object[] { IAlog.a(this), this.d.getTextureHost() });
    if (this.x != null && this.d.getTextureHost().equals(this.x.getParent())) {
      IAlog.a("%sconnectToTextureView called but already connected", new Object[] { IAlog.a(this) });
      return true;
    } 
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null) {
        f f2 = this.x;
        TextureView textureView = g1.j;
        if (textureView != f2) {
          if (textureView != null)
            textureView.setSurfaceTextureListener(null); 
          g1.j = (TextureView)f2;
          if (g1.m == null)
            g1.m = (TextureView.SurfaceTextureListener)new f(g1); 
          if (f2 != null)
            f2.setSurfaceTextureListener(g1.m); 
          if (g1.k != null) {
            IAlog.a("%scalling setSurfaceTexture with cached texture", new Object[] { IAlog.a(g1) });
            if (g1.j.getSurfaceTexture() == null || !g1.j.getSurfaceTexture().equals(g1.k)) {
              IAlog.a("%scalling setSurfaceTexture with cached texture success", new Object[] { IAlog.a(g1) });
              g1.j.setSurfaceTexture(g1.k);
            } else {
              IAlog.a("%scalling setSurfaceTexture with cached texture failed", new Object[] { IAlog.a(g1) });
            } 
          } 
        } 
      } 
    } 
    f f1 = this.x;
    if (f1 != null)
      f1.setId(R.id.inn_texture_view); 
    IAlog.a("%supdateView adding texture to parent", new Object[] { IAlog.a(this) });
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
    layoutParams.setMargins(0, 0, 0, 0);
    layoutParams.gravity = 17;
    if (this.x.getParent() == null)
      this.d.getTextureHost().addView((View)this.x, (ViewGroup.LayoutParams)layoutParams); 
    this.l = false;
    q q = new q(this);
    this.e = (g.g)q;
    com.fyber.inneractive.sdk.player.b b2 = this.a;
    if (b2 != null) {
      g g1 = b2.b;
      if (g1 != null)
        g1.d = (g.g)q; 
    } 
    return true;
  }
  
  public void l() {
    if (this.x != null) {
      boolean bool;
      IAlog.a("%sdestroyTextureView", new Object[] { IAlog.a(this) });
      if (this.p != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        Bitmap bitmap = h(false);
        if (bitmap != null) {
          this.d.setLastFrameBitmap(bitmap);
          this.d.b(true);
        } 
      } 
    } 
  }
  
  public final void m() {
    l l1 = this.d;
    if (l1 != null) {
      l1.g();
      l1.H = true;
    } 
  }
  
  public void n() {
    if (B()) {
      String str;
      d d;
      s s1 = this.c;
      s s2 = null;
      if (s1 != null) {
        d = (d)s1.a(d.class);
      } else {
        d = null;
      } 
      s1 = s2;
      if (d != null) {
        d.e(IAConfigManager.M.p);
        com.fyber.inneractive.sdk.model.vast.a a = d.e;
        s1 = s2;
        if (a != null) {
          s1 = s2;
          if (a.d)
            str = a.b; 
        } 
      } 
      if (TextUtils.isEmpty(this.y) && str != null) {
        this.d.setSkipText(str);
      } else {
        l l1 = this.d;
        l1.setSkipText(l1.getContext().getString(R.string.ia_video_skip_text));
      } 
      this.d.c();
      this.f = 0;
      ListenerT listenerT = this.g;
      if (listenerT != null)
        listenerT.e(); 
    } 
  }
  
  public abstract int o();
  
  public com.fyber.inneractive.sdk.config.global.features.c p() {
    boolean bool;
    s s1 = this.c;
    if (s1 != null && s1.a(com.fyber.inneractive.sdk.config.global.features.c.class) != null && (this.c.a(com.fyber.inneractive.sdk.config.global.features.c.class)).c.size() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? (com.fyber.inneractive.sdk.config.global.features.c)this.c.a(com.fyber.inneractive.sdk.config.global.features.c.class) : null;
  }
  
  public void pauseVideo() {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    if (b1 != null) {
      g g1 = b1.b;
      if (g1 != null)
        if (g1.e != com.fyber.inneractive.sdk.player.enums.b.Paused) {
          IAlog.a("%spauseVideo %s", new Object[] { IAlog.a(this), this.d });
          TextureView textureView = this.a.b.j;
          if (textureView != null && textureView.getParent() != null && textureView.getParent().equals(this.d.getTextureHost())) {
            this.a.b.k();
            return;
          } 
        } else {
          IAlog.a("%spauseVideo called in bad state! %s", new Object[] { IAlog.a(this), this.a.b.e });
        }  
    } 
  }
  
  public int q() {
    byte b1;
    i i1 = IAConfigManager.M.u.b;
    String str = Integer.toString(30);
    if (i1.a.containsKey("max_rv_tsec"))
      str = (String)i1.a.get("max_rv_tsec"); 
    try {
      b1 = Integer.parseInt(str);
    } finally {
      str = null;
    } 
  }
  
  public final float r() {
    try {
      return j;
    } finally {
      Exception exception = null;
    } 
  }
  
  public abstract int s();
  
  public boolean t() {
    com.fyber.inneractive.sdk.player.b b1 = this.a;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (b1 != null) {
      g g1 = b1.b;
      bool1 = bool2;
      if (g1 != null) {
        if (g1.i())
          return true; 
        bool1 = bool2;
        if (r() == 0.0F)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public abstract void u();
  
  public void v() {
    if (!this.d.f()) {
      this.d.a(false);
      j();
      D();
      this.k = false;
      this.h = true;
    } 
  }
  
  public abstract void w();
  
  public void x() {
    j();
    this.d.a(false);
    D();
  }
  
  public abstract void y();
  
  public void z() {}
  
  public class a extends GestureDetector.SimpleOnGestureListener {
    public a(k this$0) {}
    
    public boolean onSingleTapConfirmed(MotionEvent param1MotionEvent) {
      return true;
    }
  }
  
  public class b extends AsyncTask<Integer, Void, Bitmap> {
    public b(k this$0) {}
    
    public Object doInBackground(Object[] param1ArrayOfObject) {
      Bitmap bitmap;
      Integer[] arrayOfInteger1 = (Integer[])param1ArrayOfObject;
      int i = arrayOfInteger1[0].intValue();
      int j = arrayOfInteger1[1].intValue();
      this.a.getClass();
      Application application = l.a;
      Integer[] arrayOfInteger2 = null;
      Integer[] arrayOfInteger3 = null;
      arrayOfInteger1 = arrayOfInteger3;
      if (application != null) {
        arrayOfInteger1 = arrayOfInteger3;
        if (application.getResources() != null) {
          if (application.getResources().getDisplayMetrics() == null)
            return null; 
          DisplayMetrics displayMetrics = application.getResources().getDisplayMetrics();
          arrayOfInteger1 = arrayOfInteger2;
          try {
            Bitmap bitmap1 = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
            bitmap = bitmap1;
            return bitmap;
          } finally {
            arrayOfInteger2 = null;
          } 
        } 
      } 
      return bitmap;
    }
    
    public void onPostExecute(Object param1Object) {
      param1Object = param1Object;
      super.onPostExecute(param1Object);
      k k1 = this.a;
      k1.p = (Bitmap)param1Object;
      k1.q = null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\fyber\inneractive\sdk\player\controller\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */