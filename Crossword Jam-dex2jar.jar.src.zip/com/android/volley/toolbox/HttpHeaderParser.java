package com.android.volley.toolbox;

import com.android.volley.Cache;
import com.android.volley.Header;
import com.android.volley.NetworkResponse;
import com.android.volley.VolleyLog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

public class HttpHeaderParser {
  private static final String DEFAULT_CONTENT_CHARSET = "ISO-8859-1";
  
  static final String HEADER_CONTENT_TYPE = "Content-Type";
  
  private static final String RFC1123_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";
  
  static String formatEpochAsRfc1123(long paramLong) {
    return newRfc1123Formatter().format(new Date(paramLong));
  }
  
  private static SimpleDateFormat newRfc1123Formatter() {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    return simpleDateFormat;
  }
  
  public static Cache.Entry parseCacheHeaders(NetworkResponse paramNetworkResponse) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore #13
    //   5: aload_0
    //   6: getfield headers : Ljava/util/Map;
    //   9: astore #15
    //   11: aload #15
    //   13: ldc 'Date'
    //   15: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   20: checkcast java/lang/String
    //   23: astore #16
    //   25: aload #16
    //   27: ifnull -> 40
    //   30: aload #16
    //   32: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   35: lstore #7
    //   37: goto -> 43
    //   40: lconst_0
    //   41: lstore #7
    //   43: aload #15
    //   45: ldc 'Cache-Control'
    //   47: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   52: checkcast java/lang/String
    //   55: astore #16
    //   57: iconst_0
    //   58: istore_1
    //   59: iconst_0
    //   60: istore_2
    //   61: aload #16
    //   63: ifnull -> 235
    //   66: aload #16
    //   68: ldc ','
    //   70: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   73: astore #16
    //   75: iconst_0
    //   76: istore_1
    //   77: lconst_0
    //   78: lstore #5
    //   80: lconst_0
    //   81: lstore_3
    //   82: iload_2
    //   83: aload #16
    //   85: arraylength
    //   86: if_icmpge -> 230
    //   89: aload #16
    //   91: iload_2
    //   92: aaload
    //   93: invokevirtual trim : ()Ljava/lang/String;
    //   96: astore #17
    //   98: aload #17
    //   100: ldc 'no-cache'
    //   102: invokevirtual equals : (Ljava/lang/Object;)Z
    //   105: ifne -> 228
    //   108: aload #17
    //   110: ldc 'no-store'
    //   112: invokevirtual equals : (Ljava/lang/Object;)Z
    //   115: ifeq -> 121
    //   118: goto -> 228
    //   121: aload #17
    //   123: ldc 'max-age='
    //   125: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   128: ifeq -> 149
    //   131: aload #17
    //   133: bipush #8
    //   135: invokevirtual substring : (I)Ljava/lang/String;
    //   138: invokestatic parseLong : (Ljava/lang/String;)J
    //   141: lstore #9
    //   143: lload_3
    //   144: lstore #11
    //   146: goto -> 214
    //   149: aload #17
    //   151: ldc 'stale-while-revalidate='
    //   153: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   156: ifeq -> 178
    //   159: aload #17
    //   161: bipush #23
    //   163: invokevirtual substring : (I)Ljava/lang/String;
    //   166: invokestatic parseLong : (Ljava/lang/String;)J
    //   169: lstore #11
    //   171: lload #5
    //   173: lstore #9
    //   175: goto -> 214
    //   178: aload #17
    //   180: ldc 'must-revalidate'
    //   182: invokevirtual equals : (Ljava/lang/Object;)Z
    //   185: ifne -> 205
    //   188: lload #5
    //   190: lstore #9
    //   192: lload_3
    //   193: lstore #11
    //   195: aload #17
    //   197: ldc 'proxy-revalidate'
    //   199: invokevirtual equals : (Ljava/lang/Object;)Z
    //   202: ifeq -> 214
    //   205: iconst_1
    //   206: istore_1
    //   207: lload_3
    //   208: lstore #11
    //   210: lload #5
    //   212: lstore #9
    //   214: iload_2
    //   215: iconst_1
    //   216: iadd
    //   217: istore_2
    //   218: lload #9
    //   220: lstore #5
    //   222: lload #11
    //   224: lstore_3
    //   225: goto -> 82
    //   228: aconst_null
    //   229: areturn
    //   230: iconst_1
    //   231: istore_2
    //   232: goto -> 242
    //   235: iconst_0
    //   236: istore_2
    //   237: lconst_0
    //   238: lstore #5
    //   240: lconst_0
    //   241: lstore_3
    //   242: aload #15
    //   244: ldc 'Expires'
    //   246: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   251: checkcast java/lang/String
    //   254: astore #16
    //   256: aload #16
    //   258: ifnull -> 271
    //   261: aload #16
    //   263: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   266: lstore #11
    //   268: goto -> 274
    //   271: lconst_0
    //   272: lstore #11
    //   274: aload #15
    //   276: ldc 'Last-Modified'
    //   278: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   283: checkcast java/lang/String
    //   286: astore #16
    //   288: aload #16
    //   290: ifnull -> 303
    //   293: aload #16
    //   295: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   298: lstore #9
    //   300: goto -> 306
    //   303: lconst_0
    //   304: lstore #9
    //   306: aload #15
    //   308: ldc 'ETag'
    //   310: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   315: checkcast java/lang/String
    //   318: astore #16
    //   320: iload_2
    //   321: ifeq -> 372
    //   324: lload #13
    //   326: lload #5
    //   328: ldc2_w 1000
    //   331: lmul
    //   332: ladd
    //   333: lstore #5
    //   335: iload_1
    //   336: ifeq -> 345
    //   339: lload #5
    //   341: lstore_3
    //   342: goto -> 359
    //   345: lload_3
    //   346: invokestatic signum : (J)I
    //   349: pop
    //   350: lload_3
    //   351: ldc2_w 1000
    //   354: lmul
    //   355: lload #5
    //   357: ladd
    //   358: lstore_3
    //   359: lload_3
    //   360: lstore #11
    //   362: lload #5
    //   364: lstore_3
    //   365: lload #11
    //   367: lstore #5
    //   369: goto -> 407
    //   372: lconst_0
    //   373: lstore #5
    //   375: lload #7
    //   377: lconst_0
    //   378: lcmp
    //   379: ifle -> 405
    //   382: lload #11
    //   384: lload #7
    //   386: lcmp
    //   387: iflt -> 405
    //   390: lload #13
    //   392: lload #11
    //   394: lload #7
    //   396: lsub
    //   397: ladd
    //   398: lstore_3
    //   399: lload_3
    //   400: lstore #5
    //   402: goto -> 407
    //   405: lconst_0
    //   406: lstore_3
    //   407: new com/android/volley/Cache$Entry
    //   410: dup
    //   411: invokespecial <init> : ()V
    //   414: astore #17
    //   416: aload #17
    //   418: aload_0
    //   419: getfield data : [B
    //   422: putfield data : [B
    //   425: aload #17
    //   427: aload #16
    //   429: putfield etag : Ljava/lang/String;
    //   432: aload #17
    //   434: lload_3
    //   435: putfield softTtl : J
    //   438: aload #17
    //   440: lload #5
    //   442: putfield ttl : J
    //   445: aload #17
    //   447: lload #7
    //   449: putfield serverDate : J
    //   452: aload #17
    //   454: lload #9
    //   456: putfield lastModified : J
    //   459: aload #17
    //   461: aload #15
    //   463: putfield responseHeaders : Ljava/util/Map;
    //   466: aload #17
    //   468: aload_0
    //   469: getfield allHeaders : Ljava/util/List;
    //   472: putfield allResponseHeaders : Ljava/util/List;
    //   475: aload #17
    //   477: areturn
    //   478: astore #17
    //   480: lload #5
    //   482: lstore #9
    //   484: lload_3
    //   485: lstore #11
    //   487: goto -> 214
    // Exception table:
    //   from	to	target	type
    //   131	143	478	java/lang/Exception
    //   159	171	478	java/lang/Exception
  }
  
  public static String parseCharset(Map<String, String> paramMap) {
    return parseCharset(paramMap, "ISO-8859-1");
  }
  
  public static String parseCharset(Map<String, String> paramMap, String paramString) {
    String str = paramMap.get("Content-Type");
    if (str != null) {
      String[] arrayOfString = str.split(";");
      for (int i = 1; i < arrayOfString.length; i++) {
        String[] arrayOfString1 = arrayOfString[i].trim().split("=");
        if (arrayOfString1.length == 2 && arrayOfString1[0].equals("charset"))
          return arrayOfString1[1]; 
      } 
    } 
    return paramString;
  }
  
  public static long parseDateAsEpoch(String paramString) {
    try {
      return newRfc1123Formatter().parse(paramString).getTime();
    } catch (ParseException parseException) {
      VolleyLog.e(parseException, "Unable to parse dateStr: %s, falling back to 0", new Object[] { paramString });
      return 0L;
    } 
  }
  
  static List<Header> toAllHeaderList(Map<String, String> paramMap) {
    ArrayList<Header> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, String> entry : paramMap.entrySet())
      arrayList.add(new Header((String)entry.getKey(), (String)entry.getValue())); 
    return arrayList;
  }
  
  static Map<String, String> toHeaderMap(List<Header> paramList) {
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (Header header : paramList)
      treeMap.put(header.getName(), header.getValue()); 
    return (Map)treeMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\android\volley\toolbox\HttpHeaderParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */