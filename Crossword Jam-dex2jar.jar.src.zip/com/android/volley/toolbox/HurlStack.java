package com.android.volley.toolbox;

import com.android.volley.AuthFailureError;
import com.android.volley.Header;
import com.android.volley.Request;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.safedk.android.internal.partials.VolleyNetworkBridge;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

public class HurlStack extends BaseHttpStack {
  private static final int HTTP_CONTINUE = 100;
  
  private final SSLSocketFactory mSslSocketFactory;
  
  private final UrlRewriter mUrlRewriter;
  
  public HurlStack() {
    this(null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter) {
    this(paramUrlRewriter, null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter, SSLSocketFactory paramSSLSocketFactory) {
    this.mUrlRewriter = paramUrlRewriter;
    this.mSslSocketFactory = paramSSLSocketFactory;
  }
  
  private static void addBody(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest, byte[] paramArrayOfbyte) throws IOException, AuthFailureError {
    paramHttpURLConnection.setDoOutput(true);
    paramHttpURLConnection.addRequestProperty("Content-Type", paramRequest.getBodyContentType());
    DataOutputStream dataOutputStream = new DataOutputStream(VolleyNetworkBridge.urlConnectionGetOutputStream(paramHttpURLConnection));
    dataOutputStream.write(paramArrayOfbyte);
    dataOutputStream.close();
  }
  
  private static void addBodyIfExists(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) throws IOException, AuthFailureError {
    byte[] arrayOfByte = paramRequest.getBody();
    if (arrayOfByte != null)
      addBody(paramHttpURLConnection, paramRequest, arrayOfByte); 
  }
  
  static List<Header> convertHeaders(Map<String, List<String>> paramMap) {
    ArrayList<Header> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, List<String>> entry : paramMap.entrySet()) {
      if (entry.getKey() != null)
        for (String str : entry.getValue())
          arrayList.add(new Header((String)entry.getKey(), str));  
    } 
    return arrayList;
  }
  
  private static boolean hasResponseBody(int paramInt1, int paramInt2) {
    return (paramInt1 != 4 && (100 > paramInt2 || paramInt2 >= 200) && paramInt2 != 204 && paramInt2 != 304);
  }
  
  private static InputStream inputStreamFromConnection(HttpURLConnection paramHttpURLConnection) {
    try {
      return VolleyNetworkBridge.urlConnectionGetInputStream(paramHttpURLConnection);
    } catch (IOException iOException) {
      return paramHttpURLConnection.getErrorStream();
    } 
  }
  
  private HttpURLConnection openConnection(URL paramURL, Request<?> paramRequest) throws IOException {
    HttpURLConnection httpURLConnection = createConnection(paramURL);
    int i = paramRequest.getTimeoutMs();
    httpURLConnection.setConnectTimeout(i);
    httpURLConnection.setReadTimeout(i);
    httpURLConnection.setUseCaches(false);
    httpURLConnection.setDoInput(true);
    if ("https".equals(paramURL.getProtocol())) {
      SSLSocketFactory sSLSocketFactory = this.mSslSocketFactory;
      if (sSLSocketFactory != null)
        ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(sSLSocketFactory); 
    } 
    return httpURLConnection;
  }
  
  static void setConnectionParametersForRequest(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) throws IOException, AuthFailureError {
    switch (paramRequest.getMethod()) {
      default:
        throw new IllegalStateException("Unknown method type.");
      case 7:
        paramHttpURLConnection.setRequestMethod("PATCH");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 6:
        paramHttpURLConnection.setRequestMethod("TRACE");
        return;
      case 5:
        paramHttpURLConnection.setRequestMethod("OPTIONS");
        return;
      case 4:
        paramHttpURLConnection.setRequestMethod("HEAD");
        return;
      case 3:
        paramHttpURLConnection.setRequestMethod("DELETE");
        return;
      case 2:
        paramHttpURLConnection.setRequestMethod("PUT");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 1:
        paramHttpURLConnection.setRequestMethod("POST");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 0:
        paramHttpURLConnection.setRequestMethod("GET");
        return;
      case -1:
        break;
    } 
    byte[] arrayOfByte = paramRequest.getPostBody();
    if (arrayOfByte != null) {
      paramHttpURLConnection.setRequestMethod("POST");
      addBody(paramHttpURLConnection, paramRequest, arrayOfByte);
    } 
  }
  
  protected HttpURLConnection createConnection(URL paramURL) throws IOException {
    HttpURLConnection httpURLConnection = (HttpURLConnection)FirebasePerfUrlConnection.instrument(paramURL.openConnection());
    httpURLConnection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
    return httpURLConnection;
  }
  
  public HttpResponse executeRequest(Request<?> paramRequest, Map<String, String> paramMap) throws IOException, AuthFailureError {
    StringBuilder stringBuilder;
    String str2 = paramRequest.getUrl();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(paramRequest.getHeaders());
    hashMap.putAll(paramMap);
    UrlRewriter urlRewriter = this.mUrlRewriter;
    String str1 = str2;
    if (urlRewriter != null) {
      str1 = urlRewriter.rewriteUrl(str2);
      if (str1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("URL blocked by rewriter: ");
        stringBuilder.append(str2);
        throw new IOException(stringBuilder.toString());
      } 
    } 
    HttpURLConnection httpURLConnection = openConnection(new URL(str1), (Request<?>)stringBuilder);
    for (String str : hashMap.keySet())
      httpURLConnection.addRequestProperty(str, (String)hashMap.get(str)); 
    setConnectionParametersForRequest(httpURLConnection, (Request<?>)stringBuilder);
    int i = VolleyNetworkBridge.httpUrlConnectionGetResponseCode(httpURLConnection);
    if (i != -1)
      return !hasResponseBody(stringBuilder.getMethod(), i) ? new HttpResponse(i, convertHeaders(httpURLConnection.getHeaderFields())) : new HttpResponse(i, convertHeaders(httpURLConnection.getHeaderFields()), httpURLConnection.getContentLength(), inputStreamFromConnection(httpURLConnection)); 
    throw new IOException("Could not retrieve response code from HttpUrlConnection.");
  }
  
  public static interface UrlRewriter {
    String rewriteUrl(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\android\volley\toolbox\HurlStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */