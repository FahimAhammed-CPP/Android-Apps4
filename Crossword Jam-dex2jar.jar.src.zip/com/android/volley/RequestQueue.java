package com.android.volley;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class RequestQueue {
  private static final int DEFAULT_NETWORK_THREAD_POOL_SIZE = 4;
  
  private final Cache mCache;
  
  private CacheDispatcher mCacheDispatcher;
  
  private final PriorityBlockingQueue<Request<?>> mCacheQueue = new PriorityBlockingQueue<Request<?>>();
  
  private final Set<Request<?>> mCurrentRequests = new HashSet<Request<?>>();
  
  private final ResponseDelivery mDelivery;
  
  private final NetworkDispatcher[] mDispatchers;
  
  private final List<RequestFinishedListener> mFinishedListeners = new ArrayList<RequestFinishedListener>();
  
  private final Network mNetwork;
  
  private final PriorityBlockingQueue<Request<?>> mNetworkQueue = new PriorityBlockingQueue<Request<?>>();
  
  private final AtomicInteger mSequenceGenerator = new AtomicInteger();
  
  public RequestQueue(Cache paramCache, Network paramNetwork) {
    this(paramCache, paramNetwork, 4);
  }
  
  public RequestQueue(Cache paramCache, Network paramNetwork, int paramInt) {
    this(paramCache, paramNetwork, paramInt, (ResponseDelivery)new ExecutorDelivery(new Handler(Looper.getMainLooper())));
  }
  
  public RequestQueue(Cache paramCache, Network paramNetwork, int paramInt, ResponseDelivery paramResponseDelivery) {
    this.mCache = paramCache;
    this.mNetwork = paramNetwork;
    this.mDispatchers = new NetworkDispatcher[paramInt];
    this.mDelivery = paramResponseDelivery;
  }
  
  public <T> Request<T> add(Request<T> paramRequest) {
    paramRequest.setRequestQueue(this);
    synchronized (this.mCurrentRequests) {
      this.mCurrentRequests.add(paramRequest);
      paramRequest.setSequence(getSequenceNumber());
      paramRequest.addMarker("add-to-queue");
      if (!paramRequest.shouldCache()) {
        this.mNetworkQueue.add(paramRequest);
        return paramRequest;
      } 
      this.mCacheQueue.add(paramRequest);
      return paramRequest;
    } 
  }
  
  public <T> void addRequestFinishedListener(RequestFinishedListener<T> paramRequestFinishedListener) {
    synchronized (this.mFinishedListeners) {
      this.mFinishedListeners.add(paramRequestFinishedListener);
      return;
    } 
  }
  
  public void cancelAll(RequestFilter paramRequestFilter) {
    synchronized (this.mCurrentRequests) {
      for (Request<?> request : this.mCurrentRequests) {
        if (paramRequestFilter.apply(request))
          request.cancel(); 
      } 
      return;
    } 
  }
  
  public void cancelAll(final Object tag) {
    if (tag != null) {
      cancelAll(new RequestFilter() {
            public boolean apply(Request<?> param1Request) {
              return (param1Request.getTag() == tag);
            }
          });
      return;
    } 
    throw new IllegalArgumentException("Cannot cancelAll with a null tag");
  }
  
  <T> void finish(Request<T> paramRequest) {
    synchronized (this.mCurrentRequests) {
      this.mCurrentRequests.remove(paramRequest);
      synchronized (this.mFinishedListeners) {
        Iterator<RequestFinishedListener> iterator = this.mFinishedListeners.iterator();
        while (iterator.hasNext())
          ((RequestFinishedListener<T>)iterator.next()).onRequestFinished(paramRequest); 
        return;
      } 
    } 
  }
  
  public Cache getCache() {
    return this.mCache;
  }
  
  public int getSequenceNumber() {
    return this.mSequenceGenerator.incrementAndGet();
  }
  
  public <T> void removeRequestFinishedListener(RequestFinishedListener<T> paramRequestFinishedListener) {
    synchronized (this.mFinishedListeners) {
      this.mFinishedListeners.remove(paramRequestFinishedListener);
      return;
    } 
  }
  
  public void start() {
    stop();
    CacheDispatcher cacheDispatcher = new CacheDispatcher(this.mCacheQueue, this.mNetworkQueue, this.mCache, this.mDelivery);
    this.mCacheDispatcher = cacheDispatcher;
    cacheDispatcher.start();
    for (int i = 0; i < this.mDispatchers.length; i++) {
      NetworkDispatcher networkDispatcher = new NetworkDispatcher(this.mNetworkQueue, this.mNetwork, this.mCache, this.mDelivery);
      this.mDispatchers[i] = networkDispatcher;
      networkDispatcher.start();
    } 
  }
  
  public void stop() {
    CacheDispatcher cacheDispatcher = this.mCacheDispatcher;
    if (cacheDispatcher != null)
      cacheDispatcher.quit(); 
    for (NetworkDispatcher networkDispatcher : this.mDispatchers) {
      if (networkDispatcher != null)
        networkDispatcher.quit(); 
    } 
  }
  
  public static interface RequestFilter {
    boolean apply(Request<?> param1Request);
  }
  
  public static interface RequestFinishedListener<T> {
    void onRequestFinished(Request<T> param1Request);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\android\volley\RequestQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */