package com.android.volley;

public class ServerError extends VolleyError {
  public ServerError() {}
  
  public ServerError(NetworkResponse paramNetworkResponse) {
    super(paramNetworkResponse);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\com\android\volley\ServerError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */