package appmire.be.flutterjailbreakdetection;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;
import com.scottyab.rootbeer.b;
import io.flutter.embedding.engine.j.a;
import kotlin.Metadata;
import kotlin.d0.d.m;
import m.a.c.a.k;
import m.a.c.a.l;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\030\0002\0020\0012\0020\002B\005¢\006\002\020\003J\b\020\b\032\0020\tH\002J\020\020\n\032\0020\0132\006\020\f\032\0020\rH\026J\020\020\016\032\0020\0132\006\020\f\032\0020\rH\026J\030\020\017\032\0020\0132\006\020\020\032\0020\0212\006\020\022\032\0020\023H\026R\016\020\004\032\0020\005X.¢\006\002\n\000R\016\020\006\032\0020\007X.¢\006\002\n\000¨\006\024"}, d2 = {"Lappmire/be/flutterjailbreakdetection/FlutterJailbreakDetectionPlugin;", "Lio/flutter/embedding/engine/plugins/FlutterPlugin;", "Lio/flutter/plugin/common/MethodChannel$MethodCallHandler;", "()V", "channel", "Lio/flutter/plugin/common/MethodChannel;", "context", "Landroid/content/Context;", "isDevMode", "", "onAttachedToEngine", "", "binding", "Lio/flutter/embedding/engine/plugins/FlutterPlugin$FlutterPluginBinding;", "onDetachedFromEngine", "onMethodCall", "call", "Lio/flutter/plugin/common/MethodCall;", "result", "Lio/flutter/plugin/common/MethodChannel$Result;", "flutter_jailbreak_detection_release"}, k = 1, mv = {1, 6, 0}, xi = 48)
public final class a implements a, l.c {
  private Context b;
  
  private l c;
  
  private final boolean a() {
    Context context = this.b;
    if (context != null) {
      ContentResolver contentResolver = context.getContentResolver();
      boolean bool = false;
      if (Settings.Secure.getInt(contentResolver, "development_settings_enabled", 0) != 0)
        bool = true; 
      return bool;
    } 
    m.v("context");
    throw null;
  }
  
  public void onAttachedToEngine(a.b paramb) {
    m.f(paramb, "binding");
    this.c = new l(paramb.b(), "flutter_jailbreak_detection");
    Context context = paramb.a();
    m.e(context, "binding.applicationContext");
    this.b = context;
    l l1 = this.c;
    if (l1 != null) {
      l1.e(this);
      return;
    } 
    m.v("channel");
    throw null;
  }
  
  public void onDetachedFromEngine(a.b paramb) {
    m.f(paramb, "binding");
    l l1 = this.c;
    if (l1 != null) {
      l1.e(null);
      return;
    } 
    m.v("channel");
    throw null;
  }
  
  public void onMethodCall(k paramk, l.d paramd) {
    Context context;
    m.f(paramk, "call");
    m.f(paramd, "result");
    if (paramk.a.equals("jailbroken")) {
      context = this.b;
      if (context != null) {
        paramd.a(Boolean.valueOf((new b(context)).n()));
        return;
      } 
      m.v("context");
      throw null;
    } 
    if (((k)context).a.equals("developerMode")) {
      paramd.a(Boolean.valueOf(a()));
      return;
    } 
    paramd.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\appmire\be\flutterjailbreakdetection\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */