package androidx.window.layout;

import androidx.annotation.RestrictTo;
import androidx.window.core.ExperimentalWindowApi;
import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\bg\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\003H'¨\006\005"}, d2 = {"Landroidx/window/layout/WindowMetricsCalculatorDecorator;", "", "decorate", "Landroidx/window/layout/WindowMetricsCalculator;", "calculator", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
@RestrictTo({RestrictTo.Scope.TESTS})
@ExperimentalWindowApi
public interface WindowMetricsCalculatorDecorator {
  @RestrictTo({RestrictTo.Scope.TESTS})
  @ExperimentalWindowApi
  WindowMetricsCalculator decorate(WindowMetricsCalculator paramWindowMetricsCalculator);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\window\layout\WindowMetricsCalculatorDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */