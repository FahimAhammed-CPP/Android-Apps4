package androidx.window.layout;

import android.app.Activity;
import kotlin.Metadata;

@Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\002\b`\030\0002\0020\001:\001\fJ\020\020\002\032\0020\0032\006\020\004\032\0020\005H&J\020\020\006\032\0020\0032\006\020\004\032\0020\005H&J\020\020\007\032\0020\0032\006\020\b\032\0020\tH&J\b\020\n\032\0020\013H&¨\006\r"}, d2 = {"Landroidx/window/layout/ExtensionInterfaceCompat;", "", "onWindowLayoutChangeListenerAdded", "", "activity", "Landroid/app/Activity;", "onWindowLayoutChangeListenerRemoved", "setExtensionCallback", "extensionCallback", "Landroidx/window/layout/ExtensionInterfaceCompat$ExtensionCallbackInterface;", "validateExtensionInterface", "", "ExtensionCallbackInterface", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public interface ExtensionInterfaceCompat {
  void onWindowLayoutChangeListenerAdded(Activity paramActivity);
  
  void onWindowLayoutChangeListenerRemoved(Activity paramActivity);
  
  void setExtensionCallback(ExtensionCallbackInterface paramExtensionCallbackInterface);
  
  boolean validateExtensionInterface();
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bf\030\0002\0020\001J\030\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\007H&¨\006\b"}, d2 = {"Landroidx/window/layout/ExtensionInterfaceCompat$ExtensionCallbackInterface;", "", "onWindowLayoutChanged", "", "activity", "Landroid/app/Activity;", "newLayout", "Landroidx/window/layout/WindowLayoutInfo;", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static interface ExtensionCallbackInterface {
    void onWindowLayoutChanged(Activity param1Activity, WindowLayoutInfo param1WindowLayoutInfo);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\window\layout\ExtensionInterfaceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */