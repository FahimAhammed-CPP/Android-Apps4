package androidx.window.layout;

import android.app.Activity;
import androidx.core.util.Consumer;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.a0.d;
import kotlin.a0.j.b;
import kotlin.a0.k.a.f;
import kotlin.a0.k.a.l;
import kotlin.d0.c.p;
import kotlin.d0.d.g;
import kotlin.d0.d.m;
import kotlin.p;
import kotlin.w;
import kotlinx.coroutines.d3.e;
import kotlinx.coroutines.d3.f;
import kotlinx.coroutines.d3.g;
import kotlinx.coroutines.d3.h;
import kotlinx.coroutines.e3.b;
import kotlinx.coroutines.e3.c;
import kotlinx.coroutines.e3.d;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\b\000\030\000 \f2\0020\001:\001\fB\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\026\020\007\032\b\022\004\022\0020\t0\b2\006\020\n\032\0020\013H\026R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\r"}, d2 = {"Landroidx/window/layout/WindowInfoTrackerImpl;", "Landroidx/window/layout/WindowInfoTracker;", "windowMetricsCalculator", "Landroidx/window/layout/WindowMetricsCalculator;", "windowBackend", "Landroidx/window/layout/WindowBackend;", "(Landroidx/window/layout/WindowMetricsCalculator;Landroidx/window/layout/WindowBackend;)V", "windowLayoutInfo", "Lkotlinx/coroutines/flow/Flow;", "Landroidx/window/layout/WindowLayoutInfo;", "activity", "Landroid/app/Activity;", "Companion", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class WindowInfoTrackerImpl implements WindowInfoTracker {
  private static final int BUFFER_CAPACITY = 10;
  
  public static final Companion Companion = new Companion(null);
  
  private final WindowBackend windowBackend;
  
  private final WindowMetricsCalculator windowMetricsCalculator;
  
  public WindowInfoTrackerImpl(WindowMetricsCalculator paramWindowMetricsCalculator, WindowBackend paramWindowBackend) {
    this.windowMetricsCalculator = paramWindowMetricsCalculator;
    this.windowBackend = paramWindowBackend;
  }
  
  public b<WindowLayoutInfo> windowLayoutInfo(Activity paramActivity) {
    m.f(paramActivity, "activity");
    return d.a(new WindowInfoTrackerImpl$windowLayoutInfo$1(paramActivity, null));
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/window/layout/WindowInfoTrackerImpl$Companion;", "", "()V", "BUFFER_CAPACITY", "", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\002\030\002\n\002\030\002\020\000\032\0020\001*\b\022\004\022\0020\0030\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/flow/FlowCollector;", "Landroidx/window/layout/WindowLayoutInfo;"}, k = 3, mv = {1, 5, 1}, xi = 48)
  @f(c = "androidx.window.layout.WindowInfoTrackerImpl$windowLayoutInfo$1", f = "WindowInfoTrackerImpl.kt", l = {54, 55}, m = "invokeSuspend")
  static final class WindowInfoTrackerImpl$windowLayoutInfo$1 extends l implements p<c<? super WindowLayoutInfo>, d<? super w>, Object> {
    Object L$1;
    
    Object L$2;
    
    int label;
    
    WindowInfoTrackerImpl$windowLayoutInfo$1(Activity param1Activity, d<? super WindowInfoTrackerImpl$windowLayoutInfo$1> param1d) {
      super(2, param1d);
    }
    
    private static final void invokeSuspend$lambda-0(f param1f, WindowLayoutInfo param1WindowLayoutInfo) {
      m.e(param1WindowLayoutInfo, "info");
      param1f.a(param1WindowLayoutInfo);
    }
    
    public final d<w> create(Object param1Object, d<?> param1d) {
      WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$1 = new WindowInfoTrackerImpl$windowLayoutInfo$1(this.$activity, (d)param1d);
      windowInfoTrackerImpl$windowLayoutInfo$1.L$0 = param1Object;
      return (d<w>)windowInfoTrackerImpl$windowLayoutInfo$1;
    }
    
    public final Object invoke(c<? super WindowLayoutInfo> param1c, d<? super w> param1d) {
      return ((WindowInfoTrackerImpl$windowLayoutInfo$1)create(param1c, param1d)).invokeSuspend(w.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object1;
      WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$1;
      Object object2 = b.c();
      int i = this.label;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            g g = (g)this.L$2;
            Consumer consumer = (Consumer)this.L$1;
            c c = (c)this.L$0;
            object1 = consumer;
            try {
              p.b(param1Object);
              param1Object = g;
              object1 = consumer;
              windowInfoTrackerImpl$windowLayoutInfo$1 = this;
            } finally {
              consumer = null;
            } 
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          g g = (g)this.L$2;
          Consumer consumer1 = (Consumer)this.L$1;
          c c = (c)this.L$0;
          object1 = consumer1;
          p.b(param1Object);
          WindowInfoTrackerImpl$windowLayoutInfo$1 windowInfoTrackerImpl$windowLayoutInfo$11 = this;
          object1 = consumer1;
          windowInfoTrackerImpl$windowLayoutInfo$1 = windowInfoTrackerImpl$windowLayoutInfo$11;
          Object object = param1Object;
          Consumer consumer2 = (Consumer)object1;
          param1Object = windowInfoTrackerImpl$windowLayoutInfo$1;
        } 
      } else {
        p.b(param1Object);
        c c = (c)this.L$0;
        f f = h.b(10, e.c, null, 4, null);
        param1Object = new c(f);
        WindowInfoTrackerImpl.this.windowBackend.registerLayoutChangeCallback(this.$activity, (Executor)a.b, (Consumer)param1Object);
        object1 = param1Object;
        g g = f.iterator();
        object1 = param1Object;
        param1Object = g;
        windowInfoTrackerImpl$windowLayoutInfo$1 = this;
        Object object = param1Object;
      } 
      WindowInfoTrackerImpl.this.windowBackend.unregisterLayoutChangeCallback((Consumer)object1);
      throw windowInfoTrackerImpl$windowLayoutInfo$1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\window\layout\WindowInfoTrackerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */