package androidx.window.embedding;

import android.app.Activity;
import androidx.annotation.GuardedBy;
import androidx.annotation.VisibleForTesting;
import androidx.core.util.Consumer;
import androidx.window.core.ExperimentalWindowApi;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.d0.d.g;
import kotlin.d0.d.m;
import kotlin.w;
import kotlin.y.s;

@Metadata(d1 = {"\000^\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\"\n\000\n\002\020\013\n\000\n\002\020\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020 \n\002\030\002\n\002\b\t\b\001\030\000 )2\0020\001:\003)*+B\021\b\007\022\b\020\002\032\004\030\0010\003¢\006\002\020\004J\016\020\024\032\b\022\004\022\0020\0230\025H\026J\b\020\026\032\0020\027H\026J\020\020\030\032\0020\0312\006\020\032\032\0020\023H\026J,\020\033\032\0020\0312\006\020\034\032\0020\0352\006\020\036\032\0020\0372\022\020 \032\016\022\n\022\b\022\004\022\0020#0\"0!H\026J\026\020$\032\0020\0312\f\020%\032\b\022\004\022\0020\0230\025H\026J\020\020&\032\0020\0312\006\020\032\032\0020\023H\026J\034\020'\032\0020\0312\022\020(\032\016\022\n\022\b\022\004\022\0020#0\"0!H\026R \020\002\032\004\030\0010\0038\006@\006X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\004R\"\020\b\032\b\022\004\022\0020\n0\t8\006X\004¢\006\016\n\000\022\004\b\013\020\f\032\004\b\r\020\016R\022\020\017\032\0060\020R\0020\000X\004¢\006\002\n\000R\024\020\021\032\b\022\004\022\0020\0230\022X\004¢\006\002\n\000¨\006,"}, d2 = {"Landroidx/window/embedding/ExtensionEmbeddingBackend;", "Landroidx/window/embedding/EmbeddingBackend;", "embeddingExtension", "Landroidx/window/embedding/EmbeddingInterfaceCompat;", "(Landroidx/window/embedding/EmbeddingInterfaceCompat;)V", "getEmbeddingExtension", "()Landroidx/window/embedding/EmbeddingInterfaceCompat;", "setEmbeddingExtension", "splitChangeCallbacks", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Landroidx/window/embedding/ExtensionEmbeddingBackend$SplitListenerWrapper;", "getSplitChangeCallbacks$annotations", "()V", "getSplitChangeCallbacks", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "splitInfoEmbeddingCallback", "Landroidx/window/embedding/ExtensionEmbeddingBackend$EmbeddingCallbackImpl;", "splitRules", "Ljava/util/concurrent/CopyOnWriteArraySet;", "Landroidx/window/embedding/EmbeddingRule;", "getSplitRules", "", "isSplitSupported", "", "registerRule", "", "rule", "registerSplitListenerForActivity", "activity", "Landroid/app/Activity;", "executor", "Ljava/util/concurrent/Executor;", "callback", "Landroidx/core/util/Consumer;", "", "Landroidx/window/embedding/SplitInfo;", "setSplitRules", "rules", "unregisterRule", "unregisterSplitListenerForActivity", "consumer", "Companion", "EmbeddingCallbackImpl", "SplitListenerWrapper", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
@ExperimentalWindowApi
public final class ExtensionEmbeddingBackend implements EmbeddingBackend {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG = "EmbeddingBackend";
  
  private static volatile ExtensionEmbeddingBackend globalInstance;
  
  private static final ReentrantLock globalLock = new ReentrantLock();
  
  @GuardedBy("globalLock")
  @VisibleForTesting
  private EmbeddingInterfaceCompat embeddingExtension;
  
  private final CopyOnWriteArrayList<SplitListenerWrapper> splitChangeCallbacks;
  
  private final EmbeddingCallbackImpl splitInfoEmbeddingCallback;
  
  private final CopyOnWriteArraySet<EmbeddingRule> splitRules;
  
  @VisibleForTesting
  public ExtensionEmbeddingBackend(EmbeddingInterfaceCompat paramEmbeddingInterfaceCompat) {
    this.embeddingExtension = paramEmbeddingInterfaceCompat;
    EmbeddingCallbackImpl embeddingCallbackImpl = new EmbeddingCallbackImpl();
    this.splitInfoEmbeddingCallback = embeddingCallbackImpl;
    this.splitChangeCallbacks = new CopyOnWriteArrayList<SplitListenerWrapper>();
    EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
    if (embeddingInterfaceCompat != null)
      embeddingInterfaceCompat.setEmbeddingCallback(embeddingCallbackImpl); 
    this.splitRules = new CopyOnWriteArraySet<EmbeddingRule>();
  }
  
  public final EmbeddingInterfaceCompat getEmbeddingExtension() {
    return this.embeddingExtension;
  }
  
  public final CopyOnWriteArrayList<SplitListenerWrapper> getSplitChangeCallbacks() {
    return this.splitChangeCallbacks;
  }
  
  public Set<EmbeddingRule> getSplitRules() {
    return this.splitRules;
  }
  
  public boolean isSplitSupported() {
    return (this.embeddingExtension != null);
  }
  
  public void registerRule(EmbeddingRule paramEmbeddingRule) {
    m.f(paramEmbeddingRule, "rule");
    if (!this.splitRules.contains(paramEmbeddingRule)) {
      this.splitRules.add(paramEmbeddingRule);
      EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
      if (embeddingInterfaceCompat == null)
        return; 
      embeddingInterfaceCompat.setSplitRules(this.splitRules);
    } 
  }
  
  public void registerSplitListenerForActivity(Activity paramActivity, Executor paramExecutor, Consumer<List<SplitInfo>> paramConsumer) {
    m.f(paramActivity, "activity");
    m.f(paramExecutor, "executor");
    m.f(paramConsumer, "callback");
    ReentrantLock reentrantLock = globalLock;
    reentrantLock.lock();
    try {
      if (getEmbeddingExtension() == null) {
        paramConsumer.accept(s.h());
        return;
      } 
      SplitListenerWrapper splitListenerWrapper = new SplitListenerWrapper(paramActivity, paramExecutor, paramConsumer);
      getSplitChangeCallbacks().add(splitListenerWrapper);
      if (this.splitInfoEmbeddingCallback.getLastInfo() != null) {
        List<SplitInfo> list = this.splitInfoEmbeddingCallback.getLastInfo();
        m.c(list);
        splitListenerWrapper.accept(list);
      } else {
        splitListenerWrapper.accept(s.h());
      } 
      w w = w.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void setEmbeddingExtension(EmbeddingInterfaceCompat paramEmbeddingInterfaceCompat) {
    this.embeddingExtension = paramEmbeddingInterfaceCompat;
  }
  
  public void setSplitRules(Set<? extends EmbeddingRule> paramSet) {
    m.f(paramSet, "rules");
    this.splitRules.clear();
    this.splitRules.addAll(paramSet);
    EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
    if (embeddingInterfaceCompat == null)
      return; 
    embeddingInterfaceCompat.setSplitRules(this.splitRules);
  }
  
  public void unregisterRule(EmbeddingRule paramEmbeddingRule) {
    m.f(paramEmbeddingRule, "rule");
    if (this.splitRules.contains(paramEmbeddingRule)) {
      this.splitRules.remove(paramEmbeddingRule);
      EmbeddingInterfaceCompat embeddingInterfaceCompat = this.embeddingExtension;
      if (embeddingInterfaceCompat == null)
        return; 
      embeddingInterfaceCompat.setSplitRules(this.splitRules);
    } 
  }
  
  public void unregisterSplitListenerForActivity(Consumer<List<SplitInfo>> paramConsumer) {
    m.f(paramConsumer, "consumer");
    ReentrantLock reentrantLock = globalLock;
    reentrantLock.lock();
    try {
      for (SplitListenerWrapper splitListenerWrapper : getSplitChangeCallbacks()) {
        if (m.a(splitListenerWrapper.getCallback(), paramConsumer)) {
          getSplitChangeCallbacks().remove(splitListenerWrapper);
          break;
        } 
      } 
      w w = w.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  @Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\006\020\t\032\0020\006J\n\020\n\032\004\030\0010\013H\002J\027\020\f\032\0020\r2\b\020\016\032\004\030\0010\017H\007¢\006\002\020\020R\016\020\003\032\0020\004XT¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000¨\006\021"}, d2 = {"Landroidx/window/embedding/ExtensionEmbeddingBackend$Companion;", "", "()V", "TAG", "", "globalInstance", "Landroidx/window/embedding/ExtensionEmbeddingBackend;", "globalLock", "Ljava/util/concurrent/locks/ReentrantLock;", "getInstance", "initAndVerifyEmbeddingExtension", "Landroidx/window/embedding/EmbeddingInterfaceCompat;", "isExtensionVersionSupported", "", "extensionVersion", "", "(Ljava/lang/Integer;)Z", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    private final EmbeddingInterfaceCompat initAndVerifyEmbeddingExtension() {
      try {
        EmbeddingCompat.Companion companion = EmbeddingCompat.Companion;
        if (isExtensionVersionSupported(companion.getExtensionApiLevel()) && companion.isEmbeddingAvailable())
          return (EmbeddingInterfaceCompat)new EmbeddingCompat(); 
      } finally {
        Exception exception = null;
      } 
    }
    
    public final ExtensionEmbeddingBackend getInstance() {
      if (ExtensionEmbeddingBackend.globalInstance == null) {
        ReentrantLock reentrantLock = ExtensionEmbeddingBackend.globalLock;
        reentrantLock.lock();
        try {
          if (ExtensionEmbeddingBackend.globalInstance == null)
            ExtensionEmbeddingBackend.globalInstance = new ExtensionEmbeddingBackend(ExtensionEmbeddingBackend.Companion.initAndVerifyEmbeddingExtension()); 
          w w = w.a;
        } finally {
          reentrantLock.unlock();
        } 
      } 
      ExtensionEmbeddingBackend extensionEmbeddingBackend = ExtensionEmbeddingBackend.globalInstance;
      m.c(extensionEmbeddingBackend);
      return extensionEmbeddingBackend;
    }
    
    @VisibleForTesting
    public final boolean isExtensionVersionSupported(Integer param1Integer) {
      boolean bool = false;
      if (param1Integer == null)
        return false; 
      if (param1Integer.intValue() >= 1)
        bool = true; 
      return bool;
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\b\004\030\0002\0020\001B\005¢\006\002\020\002J\026\020\n\032\0020\0132\f\020\f\032\b\022\004\022\0020\0050\004H\026R\"\020\003\032\n\022\004\022\0020\005\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\t¨\006\r"}, d2 = {"Landroidx/window/embedding/ExtensionEmbeddingBackend$EmbeddingCallbackImpl;", "Landroidx/window/embedding/EmbeddingInterfaceCompat$EmbeddingCallbackInterface;", "(Landroidx/window/embedding/ExtensionEmbeddingBackend;)V", "lastInfo", "", "Landroidx/window/embedding/SplitInfo;", "getLastInfo", "()Ljava/util/List;", "setLastInfo", "(Ljava/util/List;)V", "onSplitInfoChanged", "", "splitInfo", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public final class EmbeddingCallbackImpl implements EmbeddingInterfaceCompat.EmbeddingCallbackInterface {
    private List<SplitInfo> lastInfo;
    
    public final List<SplitInfo> getLastInfo() {
      return this.lastInfo;
    }
    
    public void onSplitInfoChanged(List<SplitInfo> param1List) {
      m.f(param1List, "splitInfo");
      this.lastInfo = param1List;
      Iterator<ExtensionEmbeddingBackend.SplitListenerWrapper> iterator = ExtensionEmbeddingBackend.this.getSplitChangeCallbacks().iterator();
      while (iterator.hasNext())
        ((ExtensionEmbeddingBackend.SplitListenerWrapper)iterator.next()).accept(param1List); 
    }
    
    public final void setLastInfo(List<SplitInfo> param1List) {
      this.lastInfo = param1List;
    }
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020 \n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\b\000\030\0002\0020\001B)\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\022\020\006\032\016\022\n\022\b\022\004\022\0020\t0\b0\007¢\006\002\020\nJ\024\020\016\032\0020\0172\f\020\020\032\b\022\004\022\0020\t0\bR\016\020\002\032\0020\003X\004¢\006\002\n\000R\035\020\006\032\016\022\n\022\b\022\004\022\0020\t0\b0\007¢\006\b\n\000\032\004\b\013\020\fR\016\020\004\032\0020\005X\004¢\006\002\n\000R\026\020\r\032\n\022\004\022\0020\t\030\0010\bX\016¢\006\002\n\000¨\006\021"}, d2 = {"Landroidx/window/embedding/ExtensionEmbeddingBackend$SplitListenerWrapper;", "", "activity", "Landroid/app/Activity;", "executor", "Ljava/util/concurrent/Executor;", "callback", "Landroidx/core/util/Consumer;", "", "Landroidx/window/embedding/SplitInfo;", "(Landroid/app/Activity;Ljava/util/concurrent/Executor;Landroidx/core/util/Consumer;)V", "getCallback", "()Landroidx/core/util/Consumer;", "lastValue", "accept", "", "splitInfoList", "window_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class SplitListenerWrapper {
    private final Activity activity;
    
    private final Consumer<List<SplitInfo>> callback;
    
    private final Executor executor;
    
    private List<SplitInfo> lastValue;
    
    public SplitListenerWrapper(Activity param1Activity, Executor param1Executor, Consumer<List<SplitInfo>> param1Consumer) {
      this.activity = param1Activity;
      this.executor = param1Executor;
      this.callback = param1Consumer;
    }
    
    private static final void accept$lambda-1(SplitListenerWrapper param1SplitListenerWrapper, List param1List) {
      m.f(param1SplitListenerWrapper, "this$0");
      m.f(param1List, "$splitsWithActivity");
      param1SplitListenerWrapper.getCallback().accept(param1List);
    }
    
    public final void accept(List<SplitInfo> param1List) {
      m.f(param1List, "splitInfoList");
      ArrayList<SplitInfo> arrayList = new ArrayList();
      for (SplitInfo splitInfo : param1List) {
        if (((SplitInfo)splitInfo).contains(this.activity))
          arrayList.add(splitInfo); 
      } 
      if (m.a(arrayList, this.lastValue))
        return; 
      this.lastValue = arrayList;
      this.executor.execute((Runnable)new f(this, arrayList));
    }
    
    public final Consumer<List<SplitInfo>> getCallback() {
      return this.callback;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\window\embedding\ExtensionEmbeddingBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */