package androidx.window.java.layout;

import android.app.Activity;
import androidx.core.util.Consumer;
import androidx.window.layout.WindowInfoTracker;
import androidx.window.layout.WindowLayoutInfo;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.a0.d;
import kotlin.a0.g;
import kotlin.a0.j.b;
import kotlin.a0.k.a.f;
import kotlin.a0.k.a.l;
import kotlin.d0.c.p;
import kotlin.d0.d.m;
import kotlin.p;
import kotlin.w;
import kotlinx.coroutines.e3.b;
import kotlinx.coroutines.e3.c;
import kotlinx.coroutines.h;
import kotlinx.coroutines.l0;
import kotlinx.coroutines.m0;
import kotlinx.coroutines.q1;
import kotlinx.coroutines.y1;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020%\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\004\030\0002\0020\001B\r\022\006\020\002\032\0020\001¢\006\002\020\003J2\020\n\032\0020\013\"\004\b\000\020\f2\006\020\r\032\0020\0162\f\020\017\032\b\022\004\022\002H\f0\0062\f\020\020\032\b\022\004\022\002H\f0\021H\002J$\020\022\032\0020\0132\006\020\023\032\0020\0242\006\020\r\032\0020\0162\f\020\017\032\b\022\004\022\0020\0250\006J\024\020\026\032\0020\0132\n\020\017\032\006\022\002\b\0030\006H\002J\024\020\027\032\0020\0132\f\020\017\032\b\022\004\022\0020\0250\006J\027\020\030\032\b\022\004\022\0020\0250\0212\006\020\023\032\0020\024H\001R\036\020\004\032\022\022\b\022\006\022\002\b\0030\006\022\004\022\0020\0070\005X\004¢\006\002\n\000R\016\020\b\032\0020\tX\004¢\006\002\n\000R\016\020\002\032\0020\001X\004¢\006\002\n\000¨\006\031"}, d2 = {"Landroidx/window/java/layout/WindowInfoTrackerCallbackAdapter;", "Landroidx/window/layout/WindowInfoTracker;", "tracker", "(Landroidx/window/layout/WindowInfoTracker;)V", "consumerToJobMap", "", "Landroidx/core/util/Consumer;", "Lkotlinx/coroutines/Job;", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "addListener", "", "T", "executor", "Ljava/util/concurrent/Executor;", "consumer", "flow", "Lkotlinx/coroutines/flow/Flow;", "addWindowLayoutInfoListener", "activity", "Landroid/app/Activity;", "Landroidx/window/layout/WindowLayoutInfo;", "removeListener", "removeWindowLayoutInfoListener", "windowLayoutInfo", "window-java_release"}, k = 1, mv = {1, 5, 1}, xi = 48)
public final class WindowInfoTrackerCallbackAdapter implements WindowInfoTracker {
  private final Map<Consumer<?>, y1> consumerToJobMap;
  
  private final ReentrantLock lock;
  
  private final WindowInfoTracker tracker;
  
  public WindowInfoTrackerCallbackAdapter(WindowInfoTracker paramWindowInfoTracker) {
    this.tracker = paramWindowInfoTracker;
    this.lock = new ReentrantLock();
    this.consumerToJobMap = new LinkedHashMap<Consumer<?>, y1>();
  }
  
  private final <T> void addListener(Executor paramExecutor, Consumer<T> paramConsumer, b<? extends T> paramb) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      if (this.consumerToJobMap.get(paramConsumer) == null) {
        l0 l0 = m0.a((g)q1.a(paramExecutor));
        this.consumerToJobMap.put(paramConsumer, h.c(l0, null, null, new WindowInfoTrackerCallbackAdapter$addListener$1$1(paramb, paramConsumer, null), 3, null));
      } 
      w w = w.a;
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  private final void removeListener(Consumer<?> paramConsumer) {
    ReentrantLock reentrantLock = this.lock;
    reentrantLock.lock();
    try {
      y1 y12 = this.consumerToJobMap.get(paramConsumer);
      if (y12 != null)
        y1.a.a(y12, null, 1, null); 
      y1 y11 = this.consumerToJobMap.remove(paramConsumer);
      return;
    } finally {
      reentrantLock.unlock();
    } 
  }
  
  public final void addWindowLayoutInfoListener(Activity paramActivity, Executor paramExecutor, Consumer<WindowLayoutInfo> paramConsumer) {
    m.f(paramActivity, "activity");
    m.f(paramExecutor, "executor");
    m.f(paramConsumer, "consumer");
    addListener(paramExecutor, paramConsumer, this.tracker.windowLayoutInfo(paramActivity));
  }
  
  public final void removeWindowLayoutInfoListener(Consumer<WindowLayoutInfo> paramConsumer) {
    m.f(paramConsumer, "consumer");
    removeListener(paramConsumer);
  }
  
  public b<WindowLayoutInfo> windowLayoutInfo(Activity paramActivity) {
    m.f(paramActivity, "activity");
    return this.tracker.windowLayoutInfo(paramActivity);
  }
  
  @Metadata(d1 = {"\000\f\n\000\n\002\020\002\n\000\n\002\030\002\020\000\032\0020\001\"\004\b\000\020\002*\0020\003H@"}, d2 = {"<anonymous>", "", "T", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 5, 1}, xi = 48)
  @f(c = "androidx.window.java.layout.WindowInfoTrackerCallbackAdapter$addListener$1$1", f = "WindowInfoTrackerCallbackAdapter.kt", l = {96}, m = "invokeSuspend")
  static final class WindowInfoTrackerCallbackAdapter$addListener$1$1 extends l implements p<l0, d<? super w>, Object> {
    int label;
    
    WindowInfoTrackerCallbackAdapter$addListener$1$1(b<? extends T> param1b, Consumer<T> param1Consumer, d<? super WindowInfoTrackerCallbackAdapter$addListener$1$1> param1d) {
      super(2, param1d);
    }
    
    public final d<w> create(Object param1Object, d<?> param1d) {
      return (d<w>)new WindowInfoTrackerCallbackAdapter$addListener$1$1(this.$flow, this.$consumer, (d)param1d);
    }
    
    public final Object invoke(l0 param1l0, d<? super w> param1d) {
      return ((WindowInfoTrackerCallbackAdapter$addListener$1$1)create(param1l0, param1d)).invokeSuspend(w.a);
    }
    
    public final Object invokeSuspend(Object<T> param1Object) {
      Object object = b.c();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = (Object<T>)this.$flow;
        WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 = new WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(this.$consumer);
        this.label = 1;
        if (param1Object.a(windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1, (d)this) == object)
          return object; 
      } 
      return w.a;
    }
    
    @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 implements c<T> {
      public WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(Consumer param1Consumer) {}
      
      public Object emit(T param1T, d<? super w> param1d) {
        this.$consumer$inlined.accept(param1T);
        return w.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 implements c<T> {
    public WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(Consumer param1Consumer) {}
    
    public Object emit(T param1T, d<? super w> param1d) {
      this.$consumer$inlined.accept(param1T);
      return w.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\window\java\layout\WindowInfoTrackerCallbackAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */