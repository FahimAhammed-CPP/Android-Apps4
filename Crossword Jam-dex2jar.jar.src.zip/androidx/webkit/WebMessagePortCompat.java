package androidx.webkit;

import android.os.Handler;
import android.webkit.WebMessagePort;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.lang.reflect.InvocationHandler;

public abstract class WebMessagePortCompat {
  public abstract void close();
  
  @NonNull
  @RequiresApi(23)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public abstract WebMessagePort getFrameworkPort();
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public abstract InvocationHandler getInvocationHandler();
  
  public abstract void postMessage(@NonNull WebMessageCompat paramWebMessageCompat);
  
  public abstract void setWebMessageCallback(@Nullable Handler paramHandler, @NonNull WebMessageCallbackCompat paramWebMessageCallbackCompat);
  
  public abstract void setWebMessageCallback(@NonNull WebMessageCallbackCompat paramWebMessageCallbackCompat);
  
  public static abstract class WebMessageCallbackCompat {
    public void onMessage(@NonNull WebMessagePortCompat param1WebMessagePortCompat, @Nullable WebMessageCompat param1WebMessageCompat) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\webkit\WebMessagePortCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */