package androidx.webkit.internal;

import android.annotation.SuppressLint;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewRenderProcess;
import androidx.webkit.WebViewRenderProcessClient;
import java.lang.reflect.InvocationHandler;
import java.util.concurrent.Executor;
import org.chromium.support_lib_boundary.WebViewRendererClientBoundaryInterface;

public class WebViewRenderProcessClientAdapter implements WebViewRendererClientBoundaryInterface {
  private static final String[] sSupportedFeatures = new String[] { "WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE" };
  
  private final Executor mExecutor;
  
  private final WebViewRenderProcessClient mWebViewRenderProcessClient;
  
  @SuppressLint({"LambdaLast"})
  public WebViewRenderProcessClientAdapter(@Nullable Executor paramExecutor, @Nullable WebViewRenderProcessClient paramWebViewRenderProcessClient) {
    this.mExecutor = paramExecutor;
    this.mWebViewRenderProcessClient = paramWebViewRenderProcessClient;
  }
  
  @NonNull
  public final String[] getSupportedFeatures() {
    return sSupportedFeatures;
  }
  
  @Nullable
  public WebViewRenderProcessClient getWebViewRenderProcessClient() {
    return this.mWebViewRenderProcessClient;
  }
  
  public final void onRendererResponsive(@NonNull final WebView view, @NonNull InvocationHandler paramInvocationHandler) {
    final WebViewRenderProcessImpl rendererObject = WebViewRenderProcessImpl.forInvocationHandler(paramInvocationHandler);
    final WebViewRenderProcessClient client = this.mWebViewRenderProcessClient;
    Executor executor = this.mExecutor;
    if (executor == null) {
      webViewRenderProcessClient.onRenderProcessResponsive(view, (WebViewRenderProcess)webViewRenderProcessImpl);
      return;
    } 
    executor.execute(new Runnable() {
          public void run() {
            client.onRenderProcessResponsive(view, rendererObject);
          }
        });
  }
  
  public final void onRendererUnresponsive(@NonNull final WebView view, @NonNull InvocationHandler paramInvocationHandler) {
    final WebViewRenderProcessImpl rendererObject = WebViewRenderProcessImpl.forInvocationHandler(paramInvocationHandler);
    final WebViewRenderProcessClient client = this.mWebViewRenderProcessClient;
    Executor executor = this.mExecutor;
    if (executor == null) {
      webViewRenderProcessClient.onRenderProcessUnresponsive(view, (WebViewRenderProcess)webViewRenderProcessImpl);
      return;
    } 
    executor.execute(new Runnable() {
          public void run() {
            client.onRenderProcessUnresponsive(view, rendererObject);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\webkit\internal\WebViewRenderProcessClientAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */