package androidx.slidingpanelayout;

public final class R {
  public static final class attr {
    public static final int alpha = 2130968663;
    
    public static final int font = 2130968954;
    
    public static final int fontProviderAuthority = 2130968956;
    
    public static final int fontProviderCerts = 2130968957;
    
    public static final int fontProviderFetchStrategy = 2130968958;
    
    public static final int fontProviderFetchTimeout = 2130968959;
    
    public static final int fontProviderPackage = 2130968960;
    
    public static final int fontProviderQuery = 2130968961;
    
    public static final int fontStyle = 2130968963;
    
    public static final int fontVariationSettings = 2130968964;
    
    public static final int fontWeight = 2130968965;
    
    public static final int ttcIndex = 2130969447;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131099913;
    
    public static final int notification_icon_bg_color = 2131099914;
    
    public static final int ripple_material_light = 2131099925;
    
    public static final int secondary_text_default_material_light = 2131099927;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131165335;
    
    public static final int compat_button_inset_vertical_material = 2131165336;
    
    public static final int compat_button_padding_horizontal_material = 2131165337;
    
    public static final int compat_button_padding_vertical_material = 2131165338;
    
    public static final int compat_control_corner_material = 2131165339;
    
    public static final int compat_notification_large_icon_max_height = 2131165340;
    
    public static final int compat_notification_large_icon_max_width = 2131165341;
    
    public static final int notification_action_icon_size = 2131165522;
    
    public static final int notification_action_text_size = 2131165523;
    
    public static final int notification_big_circle_margin = 2131165524;
    
    public static final int notification_content_margin_start = 2131165525;
    
    public static final int notification_large_icon_height = 2131165526;
    
    public static final int notification_large_icon_width = 2131165527;
    
    public static final int notification_main_column_padding_top = 2131165528;
    
    public static final int notification_media_narrow_margin = 2131165529;
    
    public static final int notification_right_icon_size = 2131165530;
    
    public static final int notification_right_side_padding_top = 2131165531;
    
    public static final int notification_small_icon_background_padding = 2131165532;
    
    public static final int notification_small_icon_size_as_large = 2131165533;
    
    public static final int notification_subtext_size = 2131165534;
    
    public static final int notification_top_pad = 2131165535;
    
    public static final int notification_top_pad_large_text = 2131165536;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131231420;
    
    public static final int notification_bg = 2131231421;
    
    public static final int notification_bg_low = 2131231422;
    
    public static final int notification_bg_low_normal = 2131231423;
    
    public static final int notification_bg_low_pressed = 2131231424;
    
    public static final int notification_bg_normal = 2131231425;
    
    public static final int notification_bg_normal_pressed = 2131231426;
    
    public static final int notification_icon_background = 2131231427;
    
    public static final int notification_template_icon_bg = 2131231428;
    
    public static final int notification_template_icon_low_bg = 2131231429;
    
    public static final int notification_tile_bg = 2131231430;
    
    public static final int notify_panel_notification_icon_bg = 2131231431;
  }
  
  public static final class id {
    public static final int action_container = 2131361856;
    
    public static final int action_divider = 2131361858;
    
    public static final int action_image = 2131361859;
    
    public static final int action_text = 2131361866;
    
    public static final int actions = 2131361867;
    
    public static final int async = 2131361951;
    
    public static final int blocking = 2131361968;
    
    public static final int chronometer = 2131361997;
    
    public static final int forever = 2131362108;
    
    public static final int icon = 2131362229;
    
    public static final int icon_group = 2131362230;
    
    public static final int info = 2131362242;
    
    public static final int italic = 2131362267;
    
    public static final int line1 = 2131362284;
    
    public static final int line3 = 2131362285;
    
    public static final int normal = 2131362491;
    
    public static final int notification_background = 2131362496;
    
    public static final int notification_main_column = 2131362497;
    
    public static final int notification_main_column_container = 2131362498;
    
    public static final int right_icon = 2131362548;
    
    public static final int right_side = 2131362549;
    
    public static final int tag_transition_group = 2131362636;
    
    public static final int tag_unhandled_key_event_manager = 2131362637;
    
    public static final int tag_unhandled_key_listeners = 2131362638;
    
    public static final int text = 2131362640;
    
    public static final int text2 = 2131362642;
    
    public static final int time = 2131362655;
    
    public static final int title = 2131362657;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131427357;
  }
  
  public static final class layout {
    public static final int notification_action = 2131558581;
    
    public static final int notification_action_tombstone = 2131558582;
    
    public static final int notification_template_custom_big = 2131558589;
    
    public static final int notification_template_icon_group = 2131558590;
    
    public static final int notification_template_part_chronometer = 2131558594;
    
    public static final int notification_template_part_time = 2131558595;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131886553;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131951953;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131951954;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131951956;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131951959;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131951961;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952135;
    
    public static final int Widget_Compat_NotificationActionText = 2131952136;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968663, 2130969024 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] FontFamily = new int[] { 2130968956, 2130968957, 2130968958, 2130968959, 2130968960, 2130968961, 2130968962 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968954, 2130968963, 2130968964, 2130968965, 2130969447 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\slidingpanelayout\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */