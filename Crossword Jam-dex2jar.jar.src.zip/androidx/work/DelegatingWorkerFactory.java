package androidx.work;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DelegatingWorkerFactory extends WorkerFactory {
  private static final String TAG = Logger.tagWithPrefix("DelegatingWkrFctry");
  
  private final List<WorkerFactory> mFactories = new CopyOnWriteArrayList<WorkerFactory>();
  
  public final void addFactory(@NonNull WorkerFactory paramWorkerFactory) {
    this.mFactories.add(paramWorkerFactory);
  }
  
  @Nullable
  public final ListenableWorker createWorker(@NonNull Context paramContext, @NonNull String paramString, @NonNull WorkerParameters paramWorkerParameters) {
    for (WorkerFactory workerFactory : this.mFactories) {
      try {
      
      } finally {
        paramString = String.format("Unable to instantiate a ListenableWorker (%s)", new Object[] { paramString });
        Logger.get().error(TAG, paramString, new Throwable[] { (Throwable)paramContext });
      } 
    } 
    return null;
  }
  
  @NonNull
  @VisibleForTesting
  List<WorkerFactory> getFactories() {
    return this.mFactories;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\work\DelegatingWorkerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */