package androidx.work.impl.model;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@Entity(foreignKeys = {@ForeignKey(childColumns = {"work_spec_id"}, entity = WorkSpec.class, onDelete = 5, onUpdate = 5, parentColumns = {"id"})})
public class SystemIdInfo {
  @ColumnInfo(name = "system_id")
  public final int systemId;
  
  @NonNull
  @ColumnInfo(name = "work_spec_id")
  @PrimaryKey
  public final String workSpecId;
  
  public SystemIdInfo(@NonNull String paramString, int paramInt) {
    this.workSpecId = paramString;
    this.systemId = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SystemIdInfo))
      return false; 
    paramObject = paramObject;
    return (this.systemId != ((SystemIdInfo)paramObject).systemId) ? false : this.workSpecId.equals(((SystemIdInfo)paramObject).workSpecId);
  }
  
  public int hashCode() {
    return this.workSpecId.hashCode() * 31 + this.systemId;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\work\impl\model\SystemIdInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */