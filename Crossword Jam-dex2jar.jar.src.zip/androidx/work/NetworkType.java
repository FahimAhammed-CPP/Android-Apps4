package androidx.work;

import androidx.annotation.RequiresApi;

public enum NetworkType {
  CONNECTED, METERED, NOT_REQUIRED, NOT_ROAMING, TEMPORARILY_UNMETERED, UNMETERED;
  
  static {
    NetworkType networkType1 = new NetworkType("NOT_REQUIRED", 0);
    NOT_REQUIRED = networkType1;
    NetworkType networkType2 = new NetworkType("CONNECTED", 1);
    CONNECTED = networkType2;
    NetworkType networkType3 = new NetworkType("UNMETERED", 2);
    UNMETERED = networkType3;
    NetworkType networkType4 = new NetworkType("NOT_ROAMING", 3);
    NOT_ROAMING = networkType4;
    NetworkType networkType5 = new NetworkType("METERED", 4);
    METERED = networkType5;
    NetworkType networkType6 = new NetworkType("TEMPORARILY_UNMETERED", 5);
    TEMPORARILY_UNMETERED = networkType6;
    $VALUES = new NetworkType[] { networkType1, networkType2, networkType3, networkType4, networkType5, networkType6 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\work\NetworkType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */