package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.a0.d;
import kotlin.a0.g;
import kotlin.a0.j.b;
import kotlin.a0.k.a.f;
import kotlin.a0.k.a.l;
import kotlin.d0.c.p;
import kotlin.d0.d.m;
import kotlin.p;
import kotlin.w;
import kotlinx.coroutines.h;
import kotlinx.coroutines.l0;
import kotlinx.coroutines.y1;

@Metadata(bv = {1, 0, 3}, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\006\b&\030\0002\0020\001B\t\b\000¢\006\004\b\020\020\021J4\020\b\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002ø\001\000¢\006\004\b\b\020\tJ4\020\n\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002ø\001\000¢\006\004\b\n\020\tJ4\020\013\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002ø\001\000¢\006\004\b\013\020\tR\026\020\017\032\0020\f8 @ X \004¢\006\006\032\004\b\r\020\016\002\004\n\002\b\031¨\006\022"}, d2 = {"Landroidx/lifecycle/LifecycleCoroutineScope;", "Lkotlinx/coroutines/l0;", "Lkotlin/Function2;", "Lkotlin/a0/d;", "Lkotlin/w;", "", "block", "Lkotlinx/coroutines/y1;", "launchWhenCreated", "(Lkotlin/d0/c/p;)Lkotlinx/coroutines/y1;", "launchWhenStarted", "launchWhenResumed", "Landroidx/lifecycle/Lifecycle;", "getLifecycle$lifecycle_runtime_ktx_release", "()Landroidx/lifecycle/Lifecycle;", "lifecycle", "<init>", "()V", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 1, 15})
public abstract class LifecycleCoroutineScope implements l0 {
  public abstract Lifecycle getLifecycle$lifecycle_runtime_ktx_release();
  
  public final y1 launchWhenCreated(p<? super l0, ? super d<? super w>, ? extends Object> paramp) {
    m.f(paramp, "block");
    return h.c(this, null, null, new LifecycleCoroutineScope$launchWhenCreated$1(paramp, null), 3, null);
  }
  
  public final y1 launchWhenResumed(p<? super l0, ? super d<? super w>, ? extends Object> paramp) {
    m.f(paramp, "block");
    return h.c(this, null, null, new LifecycleCoroutineScope$launchWhenResumed$1(paramp, null), 3, null);
  }
  
  public final y1 launchWhenStarted(p<? super l0, ? super d<? super w>, ? extends Object> paramp) {
    m.f(paramp, "block");
    return h.c(this, null, null, new LifecycleCoroutineScope$launchWhenStarted$1(paramp, null), 3, null);
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\020\004\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Lkotlinx/coroutines/l0;", "Lkotlin/w;", "invoke", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  @f(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenCreated$1", f = "Lifecycle.kt", l = {74}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenCreated$1 extends l implements p<l0, d<? super w>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenCreated$1(p param1p, d param1d) {
      super(2, param1d);
    }
    
    public final d<w> create(Object param1Object, d<?> param1d) {
      m.f(param1d, "completion");
      return (d<w>)new LifecycleCoroutineScope$launchWhenCreated$1(this.$block, param1d);
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LifecycleCoroutineScope$launchWhenCreated$1)create(param1Object1, (d)param1Object2)).invokeSuspend(w.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = b.c();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_runtime_ktx_release();
        p p1 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenCreated((Lifecycle)param1Object, p1, (d)this) == object)
          return object; 
      } 
      return w.a;
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\020\004\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Lkotlinx/coroutines/l0;", "Lkotlin/w;", "invoke", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  @f(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenResumed$1", f = "Lifecycle.kt", l = {99}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenResumed$1 extends l implements p<l0, d<? super w>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenResumed$1(p param1p, d param1d) {
      super(2, param1d);
    }
    
    public final d<w> create(Object param1Object, d<?> param1d) {
      m.f(param1d, "completion");
      return (d<w>)new LifecycleCoroutineScope$launchWhenResumed$1(this.$block, param1d);
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LifecycleCoroutineScope$launchWhenResumed$1)create(param1Object1, (d)param1Object2)).invokeSuspend(w.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = b.c();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_runtime_ktx_release();
        p p1 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenResumed((Lifecycle)param1Object, p1, (d)this) == object)
          return object; 
      } 
      return w.a;
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\020\004\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Lkotlinx/coroutines/l0;", "Lkotlin/w;", "invoke", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  @f(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenStarted$1", f = "Lifecycle.kt", l = {87}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenStarted$1 extends l implements p<l0, d<? super w>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenStarted$1(p param1p, d param1d) {
      super(2, param1d);
    }
    
    public final d<w> create(Object param1Object, d<?> param1d) {
      m.f(param1d, "completion");
      return (d<w>)new LifecycleCoroutineScope$launchWhenStarted$1(this.$block, param1d);
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LifecycleCoroutineScope$launchWhenStarted$1)create(param1Object1, (d)param1Object2)).invokeSuspend(w.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = b.c();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_runtime_ktx_release();
        p p1 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenStarted((Lifecycle)param1Object, p1, (d)this) == object)
          return object; 
      } 
      return w.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */