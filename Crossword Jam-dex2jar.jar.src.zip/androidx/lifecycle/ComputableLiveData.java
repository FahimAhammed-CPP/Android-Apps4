package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import androidx.arch.core.executor.ArchTaskExecutor;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public abstract class ComputableLiveData<T> {
  final AtomicBoolean mComputing = new AtomicBoolean(false);
  
  final Executor mExecutor;
  
  final AtomicBoolean mInvalid = new AtomicBoolean(true);
  
  @VisibleForTesting
  final Runnable mInvalidationRunnable = new Runnable() {
      @MainThread
      public void run() {
        boolean bool = ComputableLiveData.this.mLiveData.hasActiveObservers();
        if (ComputableLiveData.this.mInvalid.compareAndSet(false, true) && bool) {
          ComputableLiveData computableLiveData = ComputableLiveData.this;
          computableLiveData.mExecutor.execute(computableLiveData.mRefreshRunnable);
        } 
      }
    };
  
  final LiveData<T> mLiveData;
  
  @VisibleForTesting
  final Runnable mRefreshRunnable = new Runnable() {
      @WorkerThread
      public void run() {
        boolean bool;
        do {
          null = ComputableLiveData.this.mComputing;
          bool = false;
          if (!null.compareAndSet(false, true))
            continue; 
          null = null;
          bool = false;
          try {
            while (ComputableLiveData.this.mInvalid.compareAndSet(true, false)) {
              null = ComputableLiveData.this.compute();
              bool = true;
            } 
            if (bool)
              ComputableLiveData.this.mLiveData.postValue(null); 
          } finally {
            ComputableLiveData.this.mComputing.set(false);
          } 
        } while (bool && ComputableLiveData.this.mInvalid.get());
      }
    };
  
  public ComputableLiveData() {
    this(ArchTaskExecutor.getIOThreadExecutor());
  }
  
  public ComputableLiveData(@NonNull Executor paramExecutor) {
    this.mExecutor = paramExecutor;
    this.mLiveData = new LiveData<T>() {
        protected void onActive() {
          ComputableLiveData computableLiveData = ComputableLiveData.this;
          computableLiveData.mExecutor.execute(computableLiveData.mRefreshRunnable);
        }
      };
  }
  
  @WorkerThread
  protected abstract T compute();
  
  @NonNull
  public LiveData<T> getLiveData() {
    return this.mLiveData;
  }
  
  public void invalidate() {
    ArchTaskExecutor.getInstance().executeOnMainThread(this.mInvalidationRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\lifecycle\ComputableLiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */