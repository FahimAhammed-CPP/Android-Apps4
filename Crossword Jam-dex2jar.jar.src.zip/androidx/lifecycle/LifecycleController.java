package androidx.lifecycle;

import androidx.annotation.MainThread;
import kotlin.Metadata;
import kotlin.d0.d.m;
import kotlinx.coroutines.y1;

@Metadata(bv = {1, 0, 3}, d1 = {"\0006\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\b\001\030\0002\0020\001B'\022\006\020\020\032\0020\017\022\006\020\023\032\0020\022\022\006\020\n\032\0020\t\022\006\020\003\032\0020\002¢\006\004\b\025\020\026J\030\020\005\032\0020\0042\006\020\003\032\0020\002H\b¢\006\004\b\005\020\006J\017\020\007\032\0020\004H\007¢\006\004\b\007\020\bR\026\020\n\032\0020\t8\002@\002X\004¢\006\006\n\004\b\n\020\013R\026\020\r\032\0020\f8\002@\002X\004¢\006\006\n\004\b\r\020\016R\026\020\020\032\0020\0178\002@\002X\004¢\006\006\n\004\b\020\020\021R\026\020\023\032\0020\0228\002@\002X\004¢\006\006\n\004\b\023\020\024¨\006\027"}, d2 = {"Landroidx/lifecycle/LifecycleController;", "", "Lkotlinx/coroutines/y1;", "parentJob", "Lkotlin/w;", "handleDestroy", "(Lkotlinx/coroutines/y1;)V", "finish", "()V", "Landroidx/lifecycle/DispatchQueue;", "dispatchQueue", "Landroidx/lifecycle/DispatchQueue;", "Landroidx/lifecycle/LifecycleEventObserver;", "observer", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/Lifecycle;", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "Landroidx/lifecycle/Lifecycle$State;", "minState", "Landroidx/lifecycle/Lifecycle$State;", "<init>", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/DispatchQueue;Lkotlinx/coroutines/y1;)V", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 1, 15})
@MainThread
public final class LifecycleController {
  private final DispatchQueue dispatchQueue;
  
  private final Lifecycle lifecycle;
  
  private final Lifecycle.State minState;
  
  private final LifecycleEventObserver observer;
  
  public LifecycleController(Lifecycle paramLifecycle, Lifecycle.State paramState, DispatchQueue paramDispatchQueue, y1 paramy1) {
    this.lifecycle = paramLifecycle;
    this.minState = paramState;
    this.dispatchQueue = paramDispatchQueue;
    LifecycleController$observer$1 lifecycleController$observer$1 = new LifecycleController$observer$1(paramy1);
    this.observer = lifecycleController$observer$1;
    if (paramLifecycle.getCurrentState() == Lifecycle.State.DESTROYED) {
      y1.a.a(paramy1, null, 1, null);
      finish();
      return;
    } 
    paramLifecycle.addObserver((LifecycleObserver)lifecycleController$observer$1);
  }
  
  private final void handleDestroy(y1 paramy1) {
    y1.a.a(paramy1, null, 1, null);
    finish();
  }
  
  @MainThread
  public final void finish() {
    this.lifecycle.removeObserver((LifecycleObserver)this.observer);
    this.dispatchQueue.finish();
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\020\007\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/Lifecycle$Event;", "<anonymous parameter 1>", "Lkotlin/w;", "onStateChanged", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  static final class LifecycleController$observer$1 implements LifecycleEventObserver {
    LifecycleController$observer$1(y1 param1y1) {}
    
    public final void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      LifecycleController lifecycleController;
      m.f(param1LifecycleOwner, "source");
      m.f(param1Event, "<anonymous parameter 1>");
      Lifecycle lifecycle2 = param1LifecycleOwner.getLifecycle();
      m.e(lifecycle2, "source.lifecycle");
      if (lifecycle2.getCurrentState() == Lifecycle.State.DESTROYED) {
        lifecycleController = LifecycleController.this;
        y1.a.a(this.$parentJob, null, 1, null);
        lifecycleController.finish();
        return;
      } 
      Lifecycle lifecycle1 = lifecycleController.getLifecycle();
      m.e(lifecycle1, "source.lifecycle");
      if (lifecycle1.getCurrentState().compareTo(LifecycleController.this.minState) < 0) {
        LifecycleController.this.dispatchQueue.pause();
        return;
      } 
      LifecycleController.this.dispatchQueue.resume();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\lifecycle\LifecycleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */