package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.a0.d;
import kotlin.a0.g;
import kotlin.a0.h;
import kotlin.a0.j.b;
import kotlin.a0.k.a.h;
import kotlin.d0.c.a;
import kotlin.d0.c.l;
import kotlin.d0.d.k;
import kotlin.d0.d.m;
import kotlin.d0.d.o;
import kotlin.o;
import kotlin.p;
import kotlin.w;
import kotlinx.coroutines.c1;
import kotlinx.coroutines.g0;
import kotlinx.coroutines.k2;
import kotlinx.coroutines.n;
import kotlinx.coroutines.o;

@Metadata(bv = {1, 0, 3}, d1 = {"\000*\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\020\013\n\000\n\002\030\002\n\002\b\004\0325\020\006\032\0028\000\"\004\b\000\020\000*\0020\0012\006\020\003\032\0020\0022\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\006\020\007\032-\020\b\032\0028\000\"\004\b\000\020\000*\0020\0012\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\b\020\t\032-\020\n\032\0028\000\"\004\b\000\020\000*\0020\0012\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\n\020\t\032-\020\013\032\0028\000\"\004\b\000\020\000*\0020\0012\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\013\020\t\0325\020\006\032\0028\000\"\004\b\000\020\000*\0020\f2\006\020\003\032\0020\0022\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\006\020\r\032-\020\b\032\0028\000\"\004\b\000\020\000*\0020\f2\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\b\020\016\032-\020\n\032\0028\000\"\004\b\000\020\000*\0020\f2\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\n\020\016\032-\020\013\032\0028\000\"\004\b\000\020\000*\0020\f2\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\013\020\016\0325\020\017\032\0028\000\"\004\b\000\020\000*\0020\0012\006\020\003\032\0020\0022\016\b\004\020\005\032\b\022\004\022\0028\0000\004HHø\001\000¢\006\004\b\017\020\007\032C\020\024\032\0028\000\"\004\b\000\020\000*\0020\0012\006\020\003\032\0020\0022\006\020\021\032\0020\0202\006\020\023\032\0020\0222\f\020\005\032\b\022\004\022\0028\0000\004H@ø\001\000¢\006\004\b\024\020\025\002\004\n\002\b\031¨\006\026"}, d2 = {"R", "Landroidx/lifecycle/Lifecycle;", "Landroidx/lifecycle/Lifecycle$State;", "state", "Lkotlin/Function0;", "block", "withStateAtLeast", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;Lkotlin/d0/c/a;Lkotlin/a0/d;)Ljava/lang/Object;", "withCreated", "(Landroidx/lifecycle/Lifecycle;Lkotlin/d0/c/a;Lkotlin/a0/d;)Ljava/lang/Object;", "withStarted", "withResumed", "Landroidx/lifecycle/LifecycleOwner;", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$State;Lkotlin/d0/c/a;Lkotlin/a0/d;)Ljava/lang/Object;", "(Landroidx/lifecycle/LifecycleOwner;Lkotlin/d0/c/a;Lkotlin/a0/d;)Ljava/lang/Object;", "withStateAtLeastUnchecked", "", "dispatchNeeded", "Lkotlinx/coroutines/g0;", "lifecycleDispatcher", "suspendWithStateAtLeastUnchecked", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;ZLkotlinx/coroutines/g0;Lkotlin/d0/c/a;Lkotlin/a0/d;)Ljava/lang/Object;", "lifecycle-runtime-ktx_release"}, k = 2, mv = {1, 1, 15})
public final class WithLifecycleStateKt {
  public static final <R> Object suspendWithStateAtLeastUnchecked(Lifecycle paramLifecycle, Lifecycle.State paramState, boolean paramBoolean, g0 paramg0, a<? extends R> parama, d<? super R> paramd) {
    o o = new o(b.b(paramd), 1);
    o.A();
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 = new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1((n)o, paramLifecycle, paramState, parama, paramBoolean, paramg0);
    if (paramBoolean) {
      paramg0.dispatch((g)h.b, new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2(withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, paramLifecycle, paramState, parama, paramBoolean, paramg0));
    } else {
      paramLifecycle.addObserver((LifecycleObserver)withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1);
    } 
    o.b(new WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3(withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, paramLifecycle, paramState, parama, paramBoolean, paramg0));
    Object object = o.x();
    if (object == b.c())
      h.c(paramd); 
    return object;
  }
  
  public static final <R> Object withCreated(Lifecycle paramLifecycle, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle.State state = Lifecycle.State.CREATED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  public static final <R> Object withCreated(LifecycleOwner paramLifecycleOwner, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    m.e(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.CREATED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  private static final Object withCreated$$forInline(Lifecycle paramLifecycle, a parama, d paramd) {
    Lifecycle.State state = Lifecycle.State.CREATED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  private static final Object withCreated$$forInline(LifecycleOwner paramLifecycleOwner, a parama, d paramd) {
    m.e(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.CREATED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withResumed(Lifecycle paramLifecycle, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle.State state = Lifecycle.State.RESUMED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  public static final <R> Object withResumed(LifecycleOwner paramLifecycleOwner, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    m.e(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.RESUMED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  private static final Object withResumed$$forInline(Lifecycle paramLifecycle, a parama, d paramd) {
    Lifecycle.State state = Lifecycle.State.RESUMED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  private static final Object withResumed$$forInline(LifecycleOwner paramLifecycleOwner, a parama, d paramd) {
    m.e(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.RESUMED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withStarted(Lifecycle paramLifecycle, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle.State state = Lifecycle.State.STARTED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  public static final <R> Object withStarted(LifecycleOwner paramLifecycleOwner, a<? extends R> parama, d<? super R> paramd) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    m.e(lifecycle, "lifecycle");
    Lifecycle.State state = Lifecycle.State.STARTED;
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (lifecycle.getCurrentState().compareTo(state) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(lifecycle, state, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  private static final Object withStarted$$forInline(Lifecycle paramLifecycle, a parama, d paramd) {
    Lifecycle.State state = Lifecycle.State.STARTED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  private static final Object withStarted$$forInline(LifecycleOwner paramLifecycleOwner, a parama, d paramd) {
    m.e(paramLifecycleOwner.getLifecycle(), "lifecycle");
    Lifecycle.State state = Lifecycle.State.STARTED;
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  public static final <R> Object withStateAtLeast(Lifecycle paramLifecycle, Lifecycle.State paramState, a<? extends R> parama, d<? super R> paramd) {
    boolean bool;
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      k2 k2 = c1.c().V();
      boolean bool1 = k2.isDispatchNeeded(paramd.getContext());
      if (!bool1)
        if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
          if (paramLifecycle.getCurrentState().compareTo(paramState) >= 0)
            return parama.invoke(); 
        } else {
          throw new LifecycleDestroyedException();
        }  
      return suspendWithStateAtLeastUnchecked(paramLifecycle, paramState, bool1, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final <R> Object withStateAtLeast(LifecycleOwner paramLifecycleOwner, Lifecycle.State paramState, a<? extends R> parama, d<? super R> paramd) {
    boolean bool;
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    m.e(lifecycle, "lifecycle");
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      k2 k2 = c1.c().V();
      boolean bool1 = k2.isDispatchNeeded(paramd.getContext());
      if (!bool1)
        if (lifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
          if (lifecycle.getCurrentState().compareTo(paramState) >= 0)
            return parama.invoke(); 
        } else {
          throw new LifecycleDestroyedException();
        }  
      return suspendWithStateAtLeastUnchecked(lifecycle, paramState, bool1, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  private static final Object withStateAtLeast$$forInline(Lifecycle paramLifecycle, Lifecycle.State paramState, a parama, d paramd) {
    boolean bool;
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      c1.c().V();
      k.c(3);
      throw new NullPointerException();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  private static final Object withStateAtLeast$$forInline(LifecycleOwner paramLifecycleOwner, Lifecycle.State paramState, a parama, d paramd) {
    boolean bool;
    m.e(paramLifecycleOwner.getLifecycle(), "lifecycle");
    if (paramState.compareTo(Lifecycle.State.CREATED) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      c1.c().V();
      k.c(3);
      throw new NullPointerException();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("target state must be CREATED or greater, found ");
    stringBuilder.append(paramState);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final <R> Object withStateAtLeastUnchecked(Lifecycle paramLifecycle, Lifecycle.State paramState, a<? extends R> parama, d<? super R> paramd) {
    k2 k2 = c1.c().V();
    boolean bool = k2.isDispatchNeeded(paramd.getContext());
    if (!bool)
      if (paramLifecycle.getCurrentState() != Lifecycle.State.DESTROYED) {
        if (paramLifecycle.getCurrentState().compareTo(paramState) >= 0)
          return parama.invoke(); 
      } else {
        throw new LifecycleDestroyedException();
      }  
    return suspendWithStateAtLeastUnchecked(paramLifecycle, paramState, bool, (g0)k2, new WithLifecycleStateKt$withStateAtLeastUnchecked$2(parama), paramd);
  }
  
  private static final Object withStateAtLeastUnchecked$$forInline(Lifecycle paramLifecycle, Lifecycle.State paramState, a parama, d paramd) {
    c1.c().V();
    k.c(3);
    throw new NullPointerException();
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t¸\006\000"}, d2 = {"androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/Lifecycle$Event;", "event", "Lkotlin/w;", "onStateChanged", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V", "lifecycle-runtime-ktx_release"}, k = 1, mv = {1, 1, 15})
  public static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 implements LifecycleEventObserver {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1(n param1n, Lifecycle param1Lifecycle, Lifecycle.State param1State, a param1a, boolean param1Boolean, g0 param1g0) {}
    
    public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      n n1;
      m.f(param1LifecycleOwner, "source");
      m.f(param1Event, "event");
      if (param1Event == Lifecycle.Event.upTo(this.$state$inlined)) {
        this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this);
        n1 = this.$co;
        Object object = this.$block$inlined;
      } 
      if (n1 == Lifecycle.Event.ON_DESTROY) {
        this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this);
        n n2 = this.$co;
        LifecycleDestroyedException lifecycleDestroyedException = new LifecycleDestroyedException();
        o.a a1 = o.c;
        Object object = p.a((Throwable)lifecycleDestroyedException);
        o.b(object);
        n2.resumeWith(object);
      } 
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\004\020\005\032\0020\001\"\004\b\000\020\000H\n¢\006\004\b\002\020\003¨\006\004"}, d2 = {"R", "Lkotlin/w;", "run", "()V", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$1", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2 implements Runnable {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$2(WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 param1WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, Lifecycle param1Lifecycle, Lifecycle.State param1State, a param1a, boolean param1Boolean, g0 param1g0) {}
    
    public final void run() {
      this.$this_suspendWithStateAtLeastUnchecked$inlined.addObserver((LifecycleObserver)this.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\020\n\000\n\002\020\003\n\000\n\002\030\002\n\002\b\004\020\007\032\0020\003\"\004\b\000\020\0002\b\020\002\032\004\030\0010\001H\n¢\006\004\b\004\020\005¨\006\006"}, d2 = {"R", "", "it", "Lkotlin/w;", "invoke", "(Ljava/lang/Throwable;)V", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$2", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  static final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 extends o implements l<Throwable, w> {
    WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3(WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 param1WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1, Lifecycle param1Lifecycle, Lifecycle.State param1State, a param1a, boolean param1Boolean, g0 param1g0) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      g0 g01 = this.$lifecycleDispatcher$inlined;
      h h = h.b;
      if (g01.isDispatchNeeded((g)h)) {
        this.$lifecycleDispatcher$inlined.dispatch((g)h, new Runnable() {
              public final void run() {
                WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 = WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this;
                withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.$observer);
              }
            });
        return;
      } 
      this.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)this.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\004\020\005\032\0020\001\"\004\b\000\020\000H\n¢\006\004\b\002\020\003¨\006\004"}, d2 = {"R", "Lkotlin/w;", "run", "()V", "androidx/lifecycle/WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$2$1", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  static final class null implements Runnable {
    public final void run() {
      WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3 = WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.this;
      withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.$this_suspendWithStateAtLeastUnchecked$inlined.removeObserver((LifecycleObserver)withLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$3.$observer);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\004\n\002\b\004\020\003\032\0028\000\"\004\b\000\020\000H\n¢\006\004\b\001\020\002"}, d2 = {"R", "invoke", "()Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 1, 15})
  public static final class WithLifecycleStateKt$withStateAtLeastUnchecked$2 extends o implements a<R> {
    public WithLifecycleStateKt$withStateAtLeastUnchecked$2(a param1a) {
      super(0);
    }
    
    public final R invoke() {
      return (R)this.$block.invoke();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\lifecycle\WithLifecycleStateKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */