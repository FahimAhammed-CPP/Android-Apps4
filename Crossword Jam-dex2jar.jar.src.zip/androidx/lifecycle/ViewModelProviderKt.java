package androidx.lifecycle;

import androidx.annotation.MainThread;
import kotlin.Metadata;
import kotlin.d0.d.m;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\003\032 \020\003\032\0028\000\"\n\b\000\020\001\030\001*\0020\000*\0020\002H\b¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/ViewModel;", "VM", "Landroidx/lifecycle/ViewModelProvider;", "get", "(Landroidx/lifecycle/ViewModelProvider;)Landroidx/lifecycle/ViewModel;", "lifecycle-viewmodel-ktx_release"}, k = 2, mv = {1, 1, 15})
public final class ViewModelProviderKt {
  @MainThread
  private static final <VM extends ViewModel> VM get(ViewModelProvider paramViewModelProvider) {
    m.k(4, "VM");
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\lifecycle\ViewModelProviderKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */