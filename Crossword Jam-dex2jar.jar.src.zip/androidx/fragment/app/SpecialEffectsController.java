package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.os.CancellationSignal;
import androidx.core.view.ViewCompat;
import androidx.fragment.R;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

abstract class SpecialEffectsController {
  private final ViewGroup mContainer;
  
  boolean mIsContainerPostponed = false;
  
  boolean mOperationDirectionIsPop = false;
  
  final ArrayList<Operation> mPendingOperations = new ArrayList<Operation>();
  
  final ArrayList<Operation> mRunningOperations = new ArrayList<Operation>();
  
  SpecialEffectsController(@NonNull ViewGroup paramViewGroup) {
    this.mContainer = paramViewGroup;
  }
  
  private void enqueue(@NonNull Operation.State paramState, @NonNull Operation.LifecycleImpact paramLifecycleImpact, @NonNull FragmentStateManager paramFragmentStateManager) {
    synchronized (this.mPendingOperations) {
      CancellationSignal cancellationSignal = new CancellationSignal();
      Operation operation = findPendingOperation(paramFragmentStateManager.getFragment());
      if (operation != null) {
        operation.mergeWith(paramState, paramLifecycleImpact);
        return;
      } 
      final FragmentStateManagerOperation operation = new FragmentStateManagerOperation(paramState, paramLifecycleImpact, paramFragmentStateManager, cancellationSignal);
      this.mPendingOperations.add(fragmentStateManagerOperation);
      fragmentStateManagerOperation.addCompletionListener(new Runnable() {
            public void run() {
              if (SpecialEffectsController.this.mPendingOperations.contains(operation))
                operation.getFinalState().applyState((operation.getFragment()).mView); 
            }
          });
      fragmentStateManagerOperation.addCompletionListener(new Runnable() {
            public void run() {
              SpecialEffectsController.this.mPendingOperations.remove(operation);
              SpecialEffectsController.this.mRunningOperations.remove(operation);
            }
          });
      return;
    } 
  }
  
  @Nullable
  private Operation findPendingOperation(@NonNull Fragment paramFragment) {
    for (Operation operation : this.mPendingOperations) {
      if (operation.getFragment().equals(paramFragment) && !operation.isCanceled())
        return operation; 
    } 
    return null;
  }
  
  @Nullable
  private Operation findRunningOperation(@NonNull Fragment paramFragment) {
    for (Operation operation : this.mRunningOperations) {
      if (operation.getFragment().equals(paramFragment) && !operation.isCanceled())
        return operation; 
    } 
    return null;
  }
  
  @NonNull
  static SpecialEffectsController getOrCreateController(@NonNull ViewGroup paramViewGroup, @NonNull FragmentManager paramFragmentManager) {
    return getOrCreateController(paramViewGroup, paramFragmentManager.getSpecialEffectsControllerFactory());
  }
  
  @NonNull
  static SpecialEffectsController getOrCreateController(@NonNull ViewGroup paramViewGroup, @NonNull SpecialEffectsControllerFactory paramSpecialEffectsControllerFactory) {
    int i = R.id.special_effects_controller_view_tag;
    Object object = paramViewGroup.getTag(i);
    if (object instanceof SpecialEffectsController)
      return (SpecialEffectsController)object; 
    SpecialEffectsController specialEffectsController = paramSpecialEffectsControllerFactory.createController(paramViewGroup);
    paramViewGroup.setTag(i, specialEffectsController);
    return specialEffectsController;
  }
  
  private void updateFinalState() {
    for (Operation operation : this.mPendingOperations) {
      if (operation.getLifecycleImpact() == Operation.LifecycleImpact.ADDING)
        operation.mergeWith(Operation.State.from(operation.getFragment().requireView().getVisibility()), Operation.LifecycleImpact.NONE); 
    } 
  }
  
  void enqueueAdd(@NonNull Operation.State paramState, @NonNull FragmentStateManager paramFragmentStateManager) {
    if (FragmentManager.isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
      stringBuilder.append(paramFragmentStateManager.getFragment());
      stringBuilder.toString();
    } 
    enqueue(paramState, Operation.LifecycleImpact.ADDING, paramFragmentStateManager);
  }
  
  void enqueueHide(@NonNull FragmentStateManager paramFragmentStateManager) {
    if (FragmentManager.isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
      stringBuilder.append(paramFragmentStateManager.getFragment());
      stringBuilder.toString();
    } 
    enqueue(Operation.State.GONE, Operation.LifecycleImpact.NONE, paramFragmentStateManager);
  }
  
  void enqueueRemove(@NonNull FragmentStateManager paramFragmentStateManager) {
    if (FragmentManager.isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
      stringBuilder.append(paramFragmentStateManager.getFragment());
      stringBuilder.toString();
    } 
    enqueue(Operation.State.REMOVED, Operation.LifecycleImpact.REMOVING, paramFragmentStateManager);
  }
  
  void enqueueShow(@NonNull FragmentStateManager paramFragmentStateManager) {
    if (FragmentManager.isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
      stringBuilder.append(paramFragmentStateManager.getFragment());
      stringBuilder.toString();
    } 
    enqueue(Operation.State.VISIBLE, Operation.LifecycleImpact.NONE, paramFragmentStateManager);
  }
  
  abstract void executeOperations(@NonNull List<Operation> paramList, boolean paramBoolean);
  
  void executePendingOperations() {
    if (this.mIsContainerPostponed)
      return; 
    if (!ViewCompat.isAttachedToWindow((View)this.mContainer)) {
      forceCompleteAllOperations();
      this.mOperationDirectionIsPop = false;
      return;
    } 
    synchronized (this.mPendingOperations) {
      if (!this.mPendingOperations.isEmpty()) {
        ArrayList<Operation> arrayList = new ArrayList<Operation>(this.mRunningOperations);
        this.mRunningOperations.clear();
        for (Operation operation : arrayList) {
          if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(operation);
            stringBuilder.toString();
          } 
          operation.cancel();
          if (!operation.isComplete())
            this.mRunningOperations.add(operation); 
        } 
        updateFinalState();
        arrayList = new ArrayList<Operation>(this.mPendingOperations);
        this.mPendingOperations.clear();
        this.mRunningOperations.addAll(arrayList);
        Iterator<Operation> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((Operation)iterator.next()).onStart(); 
        executeOperations(arrayList, this.mOperationDirectionIsPop);
        this.mOperationDirectionIsPop = false;
      } 
      return;
    } 
  }
  
  void forceCompleteAllOperations() {
    boolean bool = ViewCompat.isAttachedToWindow((View)this.mContainer);
    synchronized (this.mPendingOperations) {
      updateFinalState();
      Iterator<Operation> iterator = this.mPendingOperations.iterator();
      while (iterator.hasNext())
        ((Operation)iterator.next()).onStart(); 
      for (Operation operation : new ArrayList(this.mRunningOperations)) {
        if (FragmentManager.isLoggingEnabled(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.mContainer);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling running operation ");
          stringBuilder.append(operation);
          stringBuilder.toString();
        } 
        operation.cancel();
      } 
      for (Operation operation : new ArrayList(this.mPendingOperations)) {
        if (FragmentManager.isLoggingEnabled(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.mContainer);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling pending operation ");
          stringBuilder.append(operation);
          stringBuilder.toString();
        } 
        operation.cancel();
      } 
      return;
    } 
  }
  
  void forcePostponedExecutePendingOperations() {
    if (this.mIsContainerPostponed) {
      this.mIsContainerPostponed = false;
      executePendingOperations();
    } 
  }
  
  @Nullable
  Operation.LifecycleImpact getAwaitingCompletionLifecycleImpact(@NonNull FragmentStateManager paramFragmentStateManager) {
    Operation operation2 = findPendingOperation(paramFragmentStateManager.getFragment());
    if (operation2 != null)
      return operation2.getLifecycleImpact(); 
    Operation operation1 = findRunningOperation(paramFragmentStateManager.getFragment());
    return (operation1 != null) ? operation1.getLifecycleImpact() : null;
  }
  
  @NonNull
  public ViewGroup getContainer() {
    return this.mContainer;
  }
  
  void markPostponedState() {
    synchronized (this.mPendingOperations) {
      updateFinalState();
      this.mIsContainerPostponed = false;
      int i = this.mPendingOperations.size() - 1;
      while (true) {
        if (i >= 0) {
          Operation operation = this.mPendingOperations.get(i);
          Operation.State state1 = Operation.State.from((operation.getFragment()).mView);
          Operation.State state2 = operation.getFinalState();
          Operation.State state3 = Operation.State.VISIBLE;
          if (state2 == state3 && state1 != state3) {
            this.mIsContainerPostponed = operation.getFragment().isPostponed();
          } else {
            i--;
            continue;
          } 
        } 
        return;
      } 
    } 
  }
  
  void updateOperationDirection(boolean paramBoolean) {
    this.mOperationDirectionIsPop = paramBoolean;
  }
  
  private static class FragmentStateManagerOperation extends Operation {
    @NonNull
    private final FragmentStateManager mFragmentStateManager;
    
    FragmentStateManagerOperation(@NonNull SpecialEffectsController.Operation.State param1State, @NonNull SpecialEffectsController.Operation.LifecycleImpact param1LifecycleImpact, @NonNull FragmentStateManager param1FragmentStateManager, @NonNull CancellationSignal param1CancellationSignal) {
      super(param1State, param1LifecycleImpact, param1FragmentStateManager.getFragment(), param1CancellationSignal);
      this.mFragmentStateManager = param1FragmentStateManager;
    }
    
    public void complete() {
      super.complete();
      this.mFragmentStateManager.moveToExpectedState();
    }
    
    void onStart() {
      Fragment fragment = this.mFragmentStateManager.getFragment();
      View view = fragment.mView.findFocus();
      if (view != null) {
        fragment.setFocusedView(view);
        if (FragmentManager.isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("requestFocus: Saved focused view ");
          stringBuilder.append(view);
          stringBuilder.append(" for Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.toString();
        } 
      } 
      if (getLifecycleImpact() == SpecialEffectsController.Operation.LifecycleImpact.ADDING) {
        view = getFragment().requireView();
        if (view.getParent() == null) {
          this.mFragmentStateManager.addViewToContainer();
          view.setAlpha(0.0F);
        } 
        if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
          view.setVisibility(4); 
        view.setAlpha(fragment.getPostOnViewCreatedAlpha());
      } 
    }
  }
  
  static class Operation {
    @NonNull
    private final List<Runnable> mCompletionListeners = new ArrayList<Runnable>();
    
    @NonNull
    private State mFinalState;
    
    @NonNull
    private final Fragment mFragment;
    
    private boolean mIsCanceled = false;
    
    private boolean mIsComplete = false;
    
    @NonNull
    private LifecycleImpact mLifecycleImpact;
    
    @NonNull
    private final HashSet<CancellationSignal> mSpecialEffectsSignals = new HashSet<CancellationSignal>();
    
    Operation(@NonNull State param1State, @NonNull LifecycleImpact param1LifecycleImpact, @NonNull Fragment param1Fragment, @NonNull CancellationSignal param1CancellationSignal) {
      this.mFinalState = param1State;
      this.mLifecycleImpact = param1LifecycleImpact;
      this.mFragment = param1Fragment;
      param1CancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() {
            public void onCancel() {
              SpecialEffectsController.Operation.this.cancel();
            }
          });
    }
    
    final void addCompletionListener(@NonNull Runnable param1Runnable) {
      this.mCompletionListeners.add(param1Runnable);
    }
    
    final void cancel() {
      if (isCanceled())
        return; 
      this.mIsCanceled = true;
      if (this.mSpecialEffectsSignals.isEmpty()) {
        complete();
        return;
      } 
      Iterator<?> iterator = (new ArrayList(this.mSpecialEffectsSignals)).iterator();
      while (iterator.hasNext())
        ((CancellationSignal)iterator.next()).cancel(); 
    }
    
    @CallSuper
    public void complete() {
      if (this.mIsComplete)
        return; 
      if (FragmentManager.isLoggingEnabled(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        stringBuilder.toString();
      } 
      this.mIsComplete = true;
      Iterator<Runnable> iterator = this.mCompletionListeners.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void completeSpecialEffect(@NonNull CancellationSignal param1CancellationSignal) {
      if (this.mSpecialEffectsSignals.remove(param1CancellationSignal) && this.mSpecialEffectsSignals.isEmpty())
        complete(); 
    }
    
    @NonNull
    public State getFinalState() {
      return this.mFinalState;
    }
    
    @NonNull
    public final Fragment getFragment() {
      return this.mFragment;
    }
    
    @NonNull
    LifecycleImpact getLifecycleImpact() {
      return this.mLifecycleImpact;
    }
    
    final boolean isCanceled() {
      return this.mIsCanceled;
    }
    
    final boolean isComplete() {
      return this.mIsComplete;
    }
    
    public final void markStartedSpecialEffect(@NonNull CancellationSignal param1CancellationSignal) {
      onStart();
      this.mSpecialEffectsSignals.add(param1CancellationSignal);
    }
    
    final void mergeWith(@NonNull State param1State, @NonNull LifecycleImpact param1LifecycleImpact) {
      int i = SpecialEffectsController.null.$SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$LifecycleImpact[param1LifecycleImpact.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          if (this.mFinalState != State.REMOVED) {
            if (FragmentManager.isLoggingEnabled(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.mFragment);
              stringBuilder.append(" mFinalState = ");
              stringBuilder.append(this.mFinalState);
              stringBuilder.append(" -> ");
              stringBuilder.append(param1State);
              stringBuilder.append(". ");
              stringBuilder.toString();
            } 
            this.mFinalState = param1State;
            return;
          } 
        } else {
          if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.mFragment);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(this.mFinalState);
            stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
            stringBuilder.append(this.mLifecycleImpact);
            stringBuilder.append(" to REMOVING.");
            stringBuilder.toString();
          } 
          this.mFinalState = State.REMOVED;
          this.mLifecycleImpact = LifecycleImpact.REMOVING;
          return;
        } 
      } else if (this.mFinalState == State.REMOVED) {
        if (FragmentManager.isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: For fragment ");
          stringBuilder.append(this.mFragment);
          stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
          stringBuilder.append(this.mLifecycleImpact);
          stringBuilder.append(" to ADDING.");
          stringBuilder.toString();
        } 
        this.mFinalState = State.VISIBLE;
        this.mLifecycleImpact = LifecycleImpact.ADDING;
      } 
    }
    
    void onStart() {}
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Operation ");
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFinalState = ");
      stringBuilder.append(this.mFinalState);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mLifecycleImpact = ");
      stringBuilder.append(this.mLifecycleImpact);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFragment = ");
      stringBuilder.append(this.mFragment);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    enum LifecycleImpact {
      ADDING, NONE, REMOVING;
      
      static {
        LifecycleImpact lifecycleImpact1 = new LifecycleImpact("NONE", 0);
        NONE = lifecycleImpact1;
        LifecycleImpact lifecycleImpact2 = new LifecycleImpact("ADDING", 1);
        ADDING = lifecycleImpact2;
        LifecycleImpact lifecycleImpact3 = new LifecycleImpact("REMOVING", 2);
        REMOVING = lifecycleImpact3;
        $VALUES = new LifecycleImpact[] { lifecycleImpact1, lifecycleImpact2, lifecycleImpact3 };
      }
    }
    
    enum State {
      GONE, INVISIBLE, REMOVED, VISIBLE;
      
      static {
        State state1 = new State("REMOVED", 0);
        REMOVED = state1;
        State state2 = new State("VISIBLE", 1);
        VISIBLE = state2;
        State state3 = new State("GONE", 2);
        GONE = state3;
        State state4 = new State("INVISIBLE", 3);
        INVISIBLE = state4;
        $VALUES = new State[] { state1, state2, state3, state4 };
      }
      
      @NonNull
      static State from(int param2Int) {
        if (param2Int != 0) {
          if (param2Int != 4) {
            if (param2Int == 8)
              return GONE; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown visibility ");
            stringBuilder.append(param2Int);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          return INVISIBLE;
        } 
        return VISIBLE;
      }
      
      @NonNull
      static State from(@NonNull View param2View) {
        return (param2View.getAlpha() == 0.0F && param2View.getVisibility() == 0) ? INVISIBLE : from(param2View.getVisibility());
      }
      
      void applyState(@NonNull View param2View) {
        int i = SpecialEffectsController.null.$SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State[ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i != 4)
                return; 
              if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param2View);
                stringBuilder.append(" to INVISIBLE");
                stringBuilder.toString();
              } 
              param2View.setVisibility(4);
              return;
            } 
            if (FragmentManager.isLoggingEnabled(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" to GONE");
              stringBuilder.toString();
            } 
            param2View.setVisibility(8);
            return;
          } 
          if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" to VISIBLE");
            stringBuilder.toString();
          } 
          param2View.setVisibility(0);
          return;
        } 
        ViewGroup viewGroup = (ViewGroup)param2View.getParent();
        if (viewGroup != null) {
          if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Removing view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" from container ");
            stringBuilder.append(viewGroup);
            stringBuilder.toString();
          } 
          viewGroup.removeView(param2View);
        } 
      }
    }
  }
  
  class null implements CancellationSignal.OnCancelListener {
    public void onCancel() {
      this.this$0.cancel();
    }
  }
  
  enum LifecycleImpact {
    ADDING, NONE, REMOVING;
    
    static {
      LifecycleImpact lifecycleImpact1 = new LifecycleImpact("NONE", 0);
      NONE = lifecycleImpact1;
      LifecycleImpact lifecycleImpact2 = new LifecycleImpact("ADDING", 1);
      ADDING = lifecycleImpact2;
      LifecycleImpact lifecycleImpact3 = new LifecycleImpact("REMOVING", 2);
      REMOVING = lifecycleImpact3;
      $VALUES = new LifecycleImpact[] { lifecycleImpact1, lifecycleImpact2, lifecycleImpact3 };
    }
  }
  
  enum State {
    GONE, INVISIBLE, REMOVED, VISIBLE;
    
    static {
      State state1 = new State("REMOVED", 0);
      REMOVED = state1;
      State state2 = new State("VISIBLE", 1);
      VISIBLE = state2;
      State state3 = new State("GONE", 2);
      GONE = state3;
      State state4 = new State("INVISIBLE", 3);
      INVISIBLE = state4;
      $VALUES = new State[] { state1, state2, state3, state4 };
    }
    
    @NonNull
    static State from(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 4) {
          if (param1Int == 8)
            return GONE; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown visibility ");
          stringBuilder.append(param1Int);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        return INVISIBLE;
      } 
      return VISIBLE;
    }
    
    @NonNull
    static State from(@NonNull View param1View) {
      return (param1View.getAlpha() == 0.0F && param1View.getVisibility() == 0) ? INVISIBLE : from(param1View.getVisibility());
    }
    
    void applyState(@NonNull View param1View) {
      int i = SpecialEffectsController.null.$SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State[ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4)
              return; 
            if (FragmentManager.isLoggingEnabled(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param1View);
              stringBuilder.append(" to INVISIBLE");
              stringBuilder.toString();
            } 
            param1View.setVisibility(4);
            return;
          } 
          if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" to GONE");
            stringBuilder.toString();
          } 
          param1View.setVisibility(8);
          return;
        } 
        if (FragmentManager.isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Setting view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" to VISIBLE");
          stringBuilder.toString();
        } 
        param1View.setVisibility(0);
        return;
      } 
      ViewGroup viewGroup = (ViewGroup)param1View.getParent();
      if (viewGroup != null) {
        if (FragmentManager.isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Removing view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" from container ");
          stringBuilder.append(viewGroup);
          stringBuilder.toString();
        } 
        viewGroup.removeView(param1View);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\fragment\app\SpecialEffectsController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */