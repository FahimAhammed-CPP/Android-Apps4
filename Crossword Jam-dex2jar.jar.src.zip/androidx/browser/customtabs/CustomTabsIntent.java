package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.annotation.AnimRes;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.app.BundleCompat;
import androidx.core.content.ContextCompat;
import com.safedk.android.utils.Logger;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

public final class CustomTabsIntent {
  public static final int COLOR_SCHEME_DARK = 2;
  
  public static final int COLOR_SCHEME_LIGHT = 1;
  
  private static final int COLOR_SCHEME_MAX = 2;
  
  public static final int COLOR_SCHEME_SYSTEM = 0;
  
  public static final String EXTRA_ACTION_BUTTON_BUNDLE = "android.support.customtabs.extra.ACTION_BUTTON_BUNDLE";
  
  public static final String EXTRA_CLOSE_BUTTON_ICON = "android.support.customtabs.extra.CLOSE_BUTTON_ICON";
  
  public static final String EXTRA_COLOR_SCHEME = "androidx.browser.customtabs.extra.COLOR_SCHEME";
  
  public static final String EXTRA_COLOR_SCHEME_PARAMS = "androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS";
  
  @Deprecated
  public static final String EXTRA_DEFAULT_SHARE_MENU_ITEM = "android.support.customtabs.extra.SHARE_MENU_ITEM";
  
  public static final String EXTRA_ENABLE_INSTANT_APPS = "android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS";
  
  public static final String EXTRA_ENABLE_URLBAR_HIDING = "android.support.customtabs.extra.ENABLE_URLBAR_HIDING";
  
  public static final String EXTRA_EXIT_ANIMATION_BUNDLE = "android.support.customtabs.extra.EXIT_ANIMATION_BUNDLE";
  
  public static final String EXTRA_MENU_ITEMS = "android.support.customtabs.extra.MENU_ITEMS";
  
  public static final String EXTRA_NAVIGATION_BAR_COLOR = "androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR";
  
  public static final String EXTRA_NAVIGATION_BAR_DIVIDER_COLOR = "androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR";
  
  public static final String EXTRA_REMOTEVIEWS = "android.support.customtabs.extra.EXTRA_REMOTEVIEWS";
  
  public static final String EXTRA_REMOTEVIEWS_CLICKED_ID = "android.support.customtabs.extra.EXTRA_REMOTEVIEWS_CLICKED_ID";
  
  public static final String EXTRA_REMOTEVIEWS_PENDINGINTENT = "android.support.customtabs.extra.EXTRA_REMOTEVIEWS_PENDINGINTENT";
  
  public static final String EXTRA_REMOTEVIEWS_VIEW_IDS = "android.support.customtabs.extra.EXTRA_REMOTEVIEWS_VIEW_IDS";
  
  public static final String EXTRA_SECONDARY_TOOLBAR_COLOR = "android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR";
  
  public static final String EXTRA_SESSION = "android.support.customtabs.extra.SESSION";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String EXTRA_SESSION_ID = "android.support.customtabs.extra.SESSION_ID";
  
  public static final String EXTRA_SHARE_STATE = "androidx.browser.customtabs.extra.SHARE_STATE";
  
  public static final String EXTRA_TINT_ACTION_BUTTON = "android.support.customtabs.extra.TINT_ACTION_BUTTON";
  
  public static final String EXTRA_TITLE_VISIBILITY_STATE = "android.support.customtabs.extra.TITLE_VISIBILITY";
  
  public static final String EXTRA_TOOLBAR_COLOR = "android.support.customtabs.extra.TOOLBAR_COLOR";
  
  public static final String EXTRA_TOOLBAR_ITEMS = "android.support.customtabs.extra.TOOLBAR_ITEMS";
  
  private static final String EXTRA_USER_OPT_OUT_FROM_CUSTOM_TABS = "android.support.customtabs.extra.user_opt_out";
  
  public static final String KEY_DESCRIPTION = "android.support.customtabs.customaction.DESCRIPTION";
  
  public static final String KEY_ICON = "android.support.customtabs.customaction.ICON";
  
  public static final String KEY_ID = "android.support.customtabs.customaction.ID";
  
  public static final String KEY_MENU_ITEM_TITLE = "android.support.customtabs.customaction.MENU_ITEM_TITLE";
  
  public static final String KEY_PENDING_INTENT = "android.support.customtabs.customaction.PENDING_INTENT";
  
  private static final int MAX_TOOLBAR_ITEMS = 5;
  
  public static final int NO_TITLE = 0;
  
  public static final int SHARE_STATE_DEFAULT = 0;
  
  private static final int SHARE_STATE_MAX = 2;
  
  public static final int SHARE_STATE_OFF = 2;
  
  public static final int SHARE_STATE_ON = 1;
  
  public static final int SHOW_PAGE_TITLE = 1;
  
  public static final int TOOLBAR_ACTION_BUTTON_ID = 0;
  
  @NonNull
  public final Intent intent;
  
  @Nullable
  public final Bundle startAnimationBundle;
  
  CustomTabsIntent(@NonNull Intent paramIntent, @Nullable Bundle paramBundle) {
    this.intent = paramIntent;
    this.startAnimationBundle = paramBundle;
  }
  
  @NonNull
  public static CustomTabColorSchemeParams getColorSchemeParams(@NonNull Intent paramIntent, int paramInt) {
    if (paramInt >= 0 && paramInt <= 2 && paramInt != 0) {
      Bundle bundle = paramIntent.getExtras();
      if (bundle == null)
        return CustomTabColorSchemeParams.fromBundle(null); 
      CustomTabColorSchemeParams customTabColorSchemeParams = CustomTabColorSchemeParams.fromBundle(bundle);
      SparseArray sparseArray = bundle.getSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS");
      if (sparseArray != null) {
        Bundle bundle1 = (Bundle)sparseArray.get(paramInt);
        if (bundle1 != null)
          return CustomTabColorSchemeParams.fromBundle(bundle1).withDefaults(customTabColorSchemeParams); 
      } 
      return customTabColorSchemeParams;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid colorScheme: ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static int getMaxToolbarItems() {
    return 5;
  }
  
  public static void safedk_ContextCompat_startActivity_f482d8446b01c5580049a261a99b538c(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroidx/core/content/ContextCompat;->startActivity(Landroid/content/Context;Landroid/content/Intent;Landroid/os/Bundle;)V");
    if (paramIntent == null)
      return; 
    ContextCompat.startActivity(paramContext, paramIntent, paramBundle);
  }
  
  @NonNull
  public static Intent setAlwaysUseBrowserUI(@Nullable Intent paramIntent) {
    Intent intent = paramIntent;
    if (paramIntent == null)
      intent = new Intent("android.intent.action.VIEW"); 
    intent.addFlags(268435456);
    intent.putExtra("android.support.customtabs.extra.user_opt_out", true);
    return intent;
  }
  
  public static boolean shouldAlwaysUseBrowserUI(@NonNull Intent paramIntent) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramIntent.getBooleanExtra("android.support.customtabs.extra.user_opt_out", false)) {
      bool1 = bool2;
      if ((paramIntent.getFlags() & 0x10000000) != 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void launchUrl(@NonNull Context paramContext, @NonNull Uri paramUri) {
    this.intent.setData(paramUri);
    safedk_ContextCompat_startActivity_f482d8446b01c5580049a261a99b538c(paramContext, this.intent, this.startAnimationBundle);
  }
  
  public static final class Builder {
    @Nullable
    private ArrayList<Bundle> mActionButtons;
    
    @Nullable
    private SparseArray<Bundle> mColorSchemeParamBundles;
    
    private final CustomTabColorSchemeParams.Builder mDefaultColorSchemeBuilder = new CustomTabColorSchemeParams.Builder();
    
    @Nullable
    private Bundle mDefaultColorSchemeBundle;
    
    private boolean mInstantAppsEnabled = true;
    
    private final Intent mIntent = new Intent("android.intent.action.VIEW");
    
    @Nullable
    private ArrayList<Bundle> mMenuItems;
    
    private int mShareState = 0;
    
    @Nullable
    private Bundle mStartAnimationBundle;
    
    public Builder() {}
    
    public Builder(@Nullable CustomTabsSession param1CustomTabsSession) {
      if (param1CustomTabsSession != null)
        setSession(param1CustomTabsSession); 
    }
    
    private void setSessionParameters(@Nullable IBinder param1IBinder, @Nullable PendingIntent param1PendingIntent) {
      Bundle bundle = new Bundle();
      BundleCompat.putBinder(bundle, "android.support.customtabs.extra.SESSION", param1IBinder);
      if (param1PendingIntent != null)
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)param1PendingIntent); 
      this.mIntent.putExtras(bundle);
    }
    
    @Deprecated
    @NonNull
    public Builder addDefaultShareMenuItem() {
      setShareState(1);
      return this;
    }
    
    @NonNull
    public Builder addMenuItem(@NonNull String param1String, @NonNull PendingIntent param1PendingIntent) {
      if (this.mMenuItems == null)
        this.mMenuItems = new ArrayList<Bundle>(); 
      Bundle bundle = new Bundle();
      bundle.putString("android.support.customtabs.customaction.MENU_ITEM_TITLE", param1String);
      bundle.putParcelable("android.support.customtabs.customaction.PENDING_INTENT", (Parcelable)param1PendingIntent);
      this.mMenuItems.add(bundle);
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder addToolbarItem(int param1Int, @NonNull Bitmap param1Bitmap, @NonNull String param1String, @NonNull PendingIntent param1PendingIntent) throws IllegalStateException {
      if (this.mActionButtons == null)
        this.mActionButtons = new ArrayList<Bundle>(); 
      if (this.mActionButtons.size() < 5) {
        Bundle bundle = new Bundle();
        bundle.putInt("android.support.customtabs.customaction.ID", param1Int);
        bundle.putParcelable("android.support.customtabs.customaction.ICON", (Parcelable)param1Bitmap);
        bundle.putString("android.support.customtabs.customaction.DESCRIPTION", param1String);
        bundle.putParcelable("android.support.customtabs.customaction.PENDING_INTENT", (Parcelable)param1PendingIntent);
        this.mActionButtons.add(bundle);
        return this;
      } 
      throw new IllegalStateException("Exceeded maximum toolbar item count of 5");
    }
    
    @NonNull
    public CustomTabsIntent build() {
      if (!this.mIntent.hasExtra("android.support.customtabs.extra.SESSION"))
        setSessionParameters(null, null); 
      ArrayList<Bundle> arrayList = this.mMenuItems;
      if (arrayList != null)
        this.mIntent.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", arrayList); 
      arrayList = this.mActionButtons;
      if (arrayList != null)
        this.mIntent.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", arrayList); 
      this.mIntent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.mInstantAppsEnabled);
      this.mIntent.putExtras(this.mDefaultColorSchemeBuilder.build().toBundle());
      Bundle bundle = this.mDefaultColorSchemeBundle;
      if (bundle != null)
        this.mIntent.putExtras(bundle); 
      if (this.mColorSchemeParamBundles != null) {
        bundle = new Bundle();
        bundle.putSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS", this.mColorSchemeParamBundles);
        this.mIntent.putExtras(bundle);
      } 
      this.mIntent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", this.mShareState);
      return new CustomTabsIntent(this.mIntent, this.mStartAnimationBundle);
    }
    
    @Deprecated
    @NonNull
    public Builder enableUrlBarHiding() {
      this.mIntent.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", true);
      return this;
    }
    
    @NonNull
    public Builder setActionButton(@NonNull Bitmap param1Bitmap, @NonNull String param1String, @NonNull PendingIntent param1PendingIntent) {
      return setActionButton(param1Bitmap, param1String, param1PendingIntent, false);
    }
    
    @NonNull
    public Builder setActionButton(@NonNull Bitmap param1Bitmap, @NonNull String param1String, @NonNull PendingIntent param1PendingIntent, boolean param1Boolean) {
      Bundle bundle = new Bundle();
      bundle.putInt("android.support.customtabs.customaction.ID", 0);
      bundle.putParcelable("android.support.customtabs.customaction.ICON", (Parcelable)param1Bitmap);
      bundle.putString("android.support.customtabs.customaction.DESCRIPTION", param1String);
      bundle.putParcelable("android.support.customtabs.customaction.PENDING_INTENT", (Parcelable)param1PendingIntent);
      this.mIntent.putExtra("android.support.customtabs.extra.ACTION_BUTTON_BUNDLE", bundle);
      this.mIntent.putExtra("android.support.customtabs.extra.TINT_ACTION_BUTTON", param1Boolean);
      return this;
    }
    
    @NonNull
    public Builder setCloseButtonIcon(@NonNull Bitmap param1Bitmap) {
      this.mIntent.putExtra("android.support.customtabs.extra.CLOSE_BUTTON_ICON", (Parcelable)param1Bitmap);
      return this;
    }
    
    @NonNull
    public Builder setColorScheme(int param1Int) {
      if (param1Int >= 0 && param1Int <= 2) {
        this.mIntent.putExtra("androidx.browser.customtabs.extra.COLOR_SCHEME", param1Int);
        return this;
      } 
      throw new IllegalArgumentException("Invalid value for the colorScheme argument");
    }
    
    @NonNull
    public Builder setColorSchemeParams(int param1Int, @NonNull CustomTabColorSchemeParams param1CustomTabColorSchemeParams) {
      if (param1Int >= 0 && param1Int <= 2 && param1Int != 0) {
        if (this.mColorSchemeParamBundles == null)
          this.mColorSchemeParamBundles = new SparseArray(); 
        this.mColorSchemeParamBundles.put(param1Int, param1CustomTabColorSchemeParams.toBundle());
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid colorScheme: ");
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    @NonNull
    public Builder setDefaultColorSchemeParams(@NonNull CustomTabColorSchemeParams param1CustomTabColorSchemeParams) {
      this.mDefaultColorSchemeBundle = param1CustomTabColorSchemeParams.toBundle();
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setDefaultShareMenuItemEnabled(boolean param1Boolean) {
      if (param1Boolean) {
        setShareState(1);
        return this;
      } 
      setShareState(2);
      return this;
    }
    
    @NonNull
    public Builder setExitAnimations(@NonNull Context param1Context, @AnimRes int param1Int1, @AnimRes int param1Int2) {
      Bundle bundle = ActivityOptionsCompat.makeCustomAnimation(param1Context, param1Int1, param1Int2).toBundle();
      this.mIntent.putExtra("android.support.customtabs.extra.EXIT_ANIMATION_BUNDLE", bundle);
      return this;
    }
    
    @NonNull
    public Builder setInstantAppsEnabled(boolean param1Boolean) {
      this.mInstantAppsEnabled = param1Boolean;
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setNavigationBarColor(@ColorInt int param1Int) {
      this.mDefaultColorSchemeBuilder.setNavigationBarColor(param1Int);
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setNavigationBarDividerColor(@ColorInt int param1Int) {
      this.mDefaultColorSchemeBuilder.setNavigationBarDividerColor(param1Int);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public Builder setPendingSession(@NonNull CustomTabsSession.PendingSession param1PendingSession) {
      setSessionParameters(null, param1PendingSession.getId());
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setSecondaryToolbarColor(@ColorInt int param1Int) {
      this.mDefaultColorSchemeBuilder.setSecondaryToolbarColor(param1Int);
      return this;
    }
    
    @NonNull
    public Builder setSecondaryToolbarViews(@NonNull RemoteViews param1RemoteViews, @Nullable int[] param1ArrayOfint, @Nullable PendingIntent param1PendingIntent) {
      this.mIntent.putExtra("android.support.customtabs.extra.EXTRA_REMOTEVIEWS", (Parcelable)param1RemoteViews);
      this.mIntent.putExtra("android.support.customtabs.extra.EXTRA_REMOTEVIEWS_VIEW_IDS", param1ArrayOfint);
      this.mIntent.putExtra("android.support.customtabs.extra.EXTRA_REMOTEVIEWS_PENDINGINTENT", (Parcelable)param1PendingIntent);
      return this;
    }
    
    @NonNull
    public Builder setSession(@NonNull CustomTabsSession param1CustomTabsSession) {
      this.mIntent.setPackage(param1CustomTabsSession.getComponentName().getPackageName());
      setSessionParameters(param1CustomTabsSession.getBinder(), param1CustomTabsSession.getId());
      return this;
    }
    
    @NonNull
    public Builder setShareState(int param1Int) {
      if (param1Int >= 0 && param1Int <= 2) {
        this.mShareState = param1Int;
        if (param1Int == 1) {
          this.mIntent.putExtra("android.support.customtabs.extra.SHARE_MENU_ITEM", true);
          return this;
        } 
        if (param1Int == 2) {
          this.mIntent.putExtra("android.support.customtabs.extra.SHARE_MENU_ITEM", false);
          return this;
        } 
        this.mIntent.removeExtra("android.support.customtabs.extra.SHARE_MENU_ITEM");
        return this;
      } 
      throw new IllegalArgumentException("Invalid value for the shareState argument");
    }
    
    @NonNull
    public Builder setShowTitle(boolean param1Boolean) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    @NonNull
    public Builder setStartAnimations(@NonNull Context param1Context, @AnimRes int param1Int1, @AnimRes int param1Int2) {
      this.mStartAnimationBundle = ActivityOptionsCompat.makeCustomAnimation(param1Context, param1Int1, param1Int2).toBundle();
      return this;
    }
    
    @Deprecated
    @NonNull
    public Builder setToolbarColor(@ColorInt int param1Int) {
      this.mDefaultColorSchemeBuilder.setToolbarColor(param1Int);
      return this;
    }
    
    @NonNull
    public Builder setUrlBarHidingEnabled(boolean param1Boolean) {
      this.mIntent.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", param1Boolean);
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface ColorScheme {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface ShareState {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\browser\customtabs\CustomTabsIntent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */