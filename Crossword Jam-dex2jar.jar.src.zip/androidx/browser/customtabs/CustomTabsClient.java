package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import i.a.a.a;
import i.a.a.b;
import java.util.ArrayList;
import java.util.List;

public class CustomTabsClient {
  private static final String TAG = "CustomTabsClient";
  
  private final Context mApplicationContext;
  
  private final b mService;
  
  private final ComponentName mServiceComponentName;
  
  CustomTabsClient(b paramb, ComponentName paramComponentName, Context paramContext) {
    this.mService = paramb;
    this.mServiceComponentName = paramComponentName;
    this.mApplicationContext = paramContext;
  }
  
  public static boolean bindCustomTabsService(@NonNull Context paramContext, @Nullable String paramString, @NonNull CustomTabsServiceConnection paramCustomTabsServiceConnection) {
    paramCustomTabsServiceConnection.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, (ServiceConnection)paramCustomTabsServiceConnection, 33);
  }
  
  public static boolean bindCustomTabsServicePreservePriority(@NonNull Context paramContext, @Nullable String paramString, @NonNull CustomTabsServiceConnection paramCustomTabsServiceConnection) {
    paramCustomTabsServiceConnection.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, (ServiceConnection)paramCustomTabsServiceConnection, 1);
  }
  
  public static boolean connectAndInitialize(@NonNull final Context applicationContext, @NonNull String paramString) {
    if (paramString == null)
      return false; 
    applicationContext = applicationContext.getApplicationContext();
    CustomTabsServiceConnection customTabsServiceConnection = new CustomTabsServiceConnection() {
        public final void onCustomTabsServiceConnected(@NonNull ComponentName param1ComponentName, @NonNull CustomTabsClient param1CustomTabsClient) {
          param1CustomTabsClient.warmup(0L);
          applicationContext.unbindService((ServiceConnection)this);
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {}
      };
    try {
      return bindCustomTabsService(applicationContext, paramString, customTabsServiceConnection);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  private a.a createCallbackWrapper(@Nullable final CustomTabsCallback callback) {
    return new a.a() {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        
        public void extraCallback(final String callbackName, final Bundle args) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.extraCallback(callbackName, args);
                }
              });
        }
        
        public Bundle extraCallbackWithResult(@NonNull String param1String, @Nullable Bundle param1Bundle) throws RemoteException {
          CustomTabsCallback customTabsCallback = callback;
          return (customTabsCallback == null) ? null : customTabsCallback.extraCallbackWithResult(param1String, param1Bundle);
        }
        
        public void onMessageChannelReady(final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onMessageChannelReady(extras);
                }
              });
        }
        
        public void onNavigationEvent(final int navigationEvent, final Bundle extras) {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onNavigationEvent(navigationEvent, extras);
                }
              });
        }
        
        public void onPostMessage(final String message, final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onPostMessage(message, extras);
                }
              });
        }
        
        public void onRelationshipValidationResult(final int relation, final Uri requestedOrigin, final boolean result, @Nullable final Bundle extras) throws RemoteException {
          if (callback == null)
            return; 
          this.mHandler.post(new Runnable() {
                public void run() {
                  callback.onRelationshipValidationResult(relation, requestedOrigin, result, extras);
                }
              });
        }
      };
  }
  
  private static PendingIntent createSessionId(Context paramContext, int paramInt) {
    return PendingIntent.getActivity(paramContext, paramInt, new Intent(), 67108864);
  }
  
  @Nullable
  public static String getPackageName(@NonNull Context paramContext, @Nullable List<String> paramList) {
    return getPackageName(paramContext, paramList, false);
  }
  
  @Nullable
  public static String getPackageName(@NonNull Context paramContext, @Nullable List<String> paramList, boolean paramBoolean) {
    List<String> list1;
    PackageManager packageManager = paramContext.getPackageManager();
    if (paramList == null) {
      list1 = new ArrayList();
    } else {
      list1 = paramList;
    } 
    Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse("http://"));
    List<String> list2 = list1;
    if (!paramBoolean) {
      ResolveInfo resolveInfo = packageManager.resolveActivity(intent2, 0);
      list2 = list1;
      if (resolveInfo != null) {
        String str = resolveInfo.activityInfo.packageName;
        list2 = new ArrayList<String>(list1.size() + 1);
        list2.add(str);
        if (paramList != null)
          list2.addAll(paramList); 
      } 
    } 
    Intent intent1 = new Intent("android.support.customtabs.action.CustomTabsService");
    for (String str : list2) {
      intent1.setPackage(str);
      if (packageManager.resolveService(intent1, 0) != null)
        return str; 
    } 
    if (Build.VERSION.SDK_INT >= 30)
      Log.w("CustomTabsClient", "Unable to find any Custom Tabs packages, you may need to add a <queries> element to your manifest. See the docs for CustomTabsClient#getPackageName."); 
    return null;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static CustomTabsSession.PendingSession newPendingSession(@NonNull Context paramContext, @Nullable CustomTabsCallback paramCustomTabsCallback, int paramInt) {
    return new CustomTabsSession.PendingSession(paramCustomTabsCallback, createSessionId(paramContext, paramInt));
  }
  
  @Nullable
  private CustomTabsSession newSessionInternal(@Nullable CustomTabsCallback paramCustomTabsCallback, @Nullable PendingIntent paramPendingIntent) {
    a.a a = createCallbackWrapper(paramCustomTabsCallback);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.mService.newSessionWithExtras((a)a, bundle);
        return !bool1 ? null : new CustomTabsSession(this.mService, (a)a, this.mServiceComponentName, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.mService.newSession((a)remoteException);
    return !bool ? null : new CustomTabsSession(this.mService, (a)remoteException, this.mServiceComponentName, paramPendingIntent);
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public CustomTabsSession attachSession(@NonNull CustomTabsSession.PendingSession paramPendingSession) {
    return newSessionInternal(paramPendingSession.getCallback(), paramPendingSession.getId());
  }
  
  @Nullable
  public Bundle extraCommand(@NonNull String paramString, @Nullable Bundle paramBundle) {
    try {
      return this.mService.extraCommand(paramString, paramBundle);
    } catch (RemoteException remoteException) {
      return null;
    } 
  }
  
  @Nullable
  public CustomTabsSession newSession(@Nullable CustomTabsCallback paramCustomTabsCallback) {
    return newSessionInternal(paramCustomTabsCallback, null);
  }
  
  @Nullable
  public CustomTabsSession newSession(@Nullable CustomTabsCallback paramCustomTabsCallback, int paramInt) {
    return newSessionInternal(paramCustomTabsCallback, createSessionId(this.mApplicationContext, paramInt));
  }
  
  public boolean warmup(long paramLong) {
    try {
      return this.mService.warmup(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\browser\customtabs\CustomTabsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */