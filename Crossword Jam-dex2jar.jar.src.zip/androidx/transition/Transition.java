package androidx.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.InflateException;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.collection.ArrayMap;
import androidx.collection.LongSparseArray;
import androidx.collection.SimpleArrayMap;
import androidx.core.content.res.TypedArrayUtils;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import org.xmlpull.v1.XmlPullParser;

public abstract class Transition implements Cloneable {
  static final boolean DBG = false;
  
  private static final int[] DEFAULT_MATCH_ORDER = new int[] { 2, 1, 3, 4 };
  
  private static final String LOG_TAG = "Transition";
  
  private static final int MATCH_FIRST = 1;
  
  public static final int MATCH_ID = 3;
  
  private static final String MATCH_ID_STR = "id";
  
  public static final int MATCH_INSTANCE = 1;
  
  private static final String MATCH_INSTANCE_STR = "instance";
  
  public static final int MATCH_ITEM_ID = 4;
  
  private static final String MATCH_ITEM_ID_STR = "itemId";
  
  private static final int MATCH_LAST = 4;
  
  public static final int MATCH_NAME = 2;
  
  private static final String MATCH_NAME_STR = "name";
  
  private static final PathMotion STRAIGHT_PATH_MOTION = new PathMotion() {
      public Path getPath(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
        Path path = new Path();
        path.moveTo(param1Float1, param1Float2);
        path.lineTo(param1Float3, param1Float4);
        return path;
      }
    };
  
  private static ThreadLocal<ArrayMap<Animator, AnimationInfo>> sRunningAnimators = new ThreadLocal<ArrayMap<Animator, AnimationInfo>>();
  
  private ArrayList<Animator> mAnimators = new ArrayList<Animator>();
  
  boolean mCanRemoveViews = false;
  
  ArrayList<Animator> mCurrentAnimators = new ArrayList<Animator>();
  
  long mDuration = -1L;
  
  private TransitionValuesMaps mEndValues = new TransitionValuesMaps();
  
  private ArrayList<TransitionValues> mEndValuesList;
  
  private boolean mEnded = false;
  
  private EpicenterCallback mEpicenterCallback;
  
  private TimeInterpolator mInterpolator = null;
  
  private ArrayList<TransitionListener> mListeners = null;
  
  private int[] mMatchOrder = DEFAULT_MATCH_ORDER;
  
  private String mName = getClass().getName();
  
  private ArrayMap<String, String> mNameOverrides;
  
  private int mNumInstances = 0;
  
  TransitionSet mParent = null;
  
  private PathMotion mPathMotion = STRAIGHT_PATH_MOTION;
  
  private boolean mPaused = false;
  
  TransitionPropagation mPropagation;
  
  private ViewGroup mSceneRoot = null;
  
  private long mStartDelay = -1L;
  
  private TransitionValuesMaps mStartValues = new TransitionValuesMaps();
  
  private ArrayList<TransitionValues> mStartValuesList;
  
  private ArrayList<View> mTargetChildExcludes = null;
  
  private ArrayList<View> mTargetExcludes = null;
  
  private ArrayList<Integer> mTargetIdChildExcludes = null;
  
  private ArrayList<Integer> mTargetIdExcludes = null;
  
  ArrayList<Integer> mTargetIds = new ArrayList<Integer>();
  
  private ArrayList<String> mTargetNameExcludes = null;
  
  private ArrayList<String> mTargetNames = null;
  
  private ArrayList<Class> mTargetTypeChildExcludes = null;
  
  private ArrayList<Class> mTargetTypeExcludes = null;
  
  private ArrayList<Class> mTargetTypes = null;
  
  ArrayList<View> mTargets = new ArrayList<View>();
  
  public Transition() {}
  
  public Transition(Context paramContext, AttributeSet paramAttributeSet) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, Styleable.TRANSITION);
    XmlResourceParser xmlResourceParser = (XmlResourceParser)paramAttributeSet;
    long l = TypedArrayUtils.getNamedInt(typedArray, (XmlPullParser)xmlResourceParser, "duration", 1, -1);
    if (l >= 0L)
      setDuration(l); 
    l = TypedArrayUtils.getNamedInt(typedArray, (XmlPullParser)xmlResourceParser, "startDelay", 2, -1);
    if (l > 0L)
      setStartDelay(l); 
    int i = TypedArrayUtils.getNamedResourceId(typedArray, (XmlPullParser)xmlResourceParser, "interpolator", 0, 0);
    if (i > 0)
      setInterpolator((TimeInterpolator)AnimationUtils.loadInterpolator(paramContext, i)); 
    String str = TypedArrayUtils.getNamedString(typedArray, (XmlPullParser)xmlResourceParser, "matchOrder", 3);
    if (str != null)
      setMatchOrder(parseMatchOrder(str)); 
    typedArray.recycle();
  }
  
  private void addUnmatched(ArrayMap<View, TransitionValues> paramArrayMap1, ArrayMap<View, TransitionValues> paramArrayMap2) {
    int j;
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < paramArrayMap1.size()) {
        TransitionValues transitionValues = (TransitionValues)paramArrayMap1.valueAt(i);
        if (isValidTarget(transitionValues.view)) {
          this.mStartValuesList.add(transitionValues);
          this.mEndValuesList.add(null);
        } 
        i++;
        continue;
      } 
      break;
    } 
    while (j < paramArrayMap2.size()) {
      TransitionValues transitionValues = (TransitionValues)paramArrayMap2.valueAt(j);
      if (isValidTarget(transitionValues.view)) {
        this.mEndValuesList.add(transitionValues);
        this.mStartValuesList.add(null);
      } 
      j++;
    } 
  }
  
  private static void addViewValues(TransitionValuesMaps paramTransitionValuesMaps, View paramView, TransitionValues paramTransitionValues) {
    paramTransitionValuesMaps.mViewValues.put(paramView, paramTransitionValues);
    int i = paramView.getId();
    if (i >= 0)
      if (paramTransitionValuesMaps.mIdValues.indexOfKey(i) >= 0) {
        paramTransitionValuesMaps.mIdValues.put(i, null);
      } else {
        paramTransitionValuesMaps.mIdValues.put(i, paramView);
      }  
    String str = ViewCompat.getTransitionName(paramView);
    if (str != null)
      if (paramTransitionValuesMaps.mNameValues.containsKey(str)) {
        paramTransitionValuesMaps.mNameValues.put(str, null);
      } else {
        paramTransitionValuesMaps.mNameValues.put(str, paramView);
      }  
    if (paramView.getParent() instanceof ListView) {
      ListView listView = (ListView)paramView.getParent();
      if (listView.getAdapter().hasStableIds()) {
        long l = listView.getItemIdAtPosition(listView.getPositionForView(paramView));
        if (paramTransitionValuesMaps.mItemIdValues.indexOfKey(l) >= 0) {
          paramView = (View)paramTransitionValuesMaps.mItemIdValues.get(l);
          if (paramView != null) {
            ViewCompat.setHasTransientState(paramView, false);
            paramTransitionValuesMaps.mItemIdValues.put(l, null);
            return;
          } 
        } else {
          ViewCompat.setHasTransientState(paramView, true);
          paramTransitionValuesMaps.mItemIdValues.put(l, paramView);
        } 
      } 
    } 
  }
  
  private static boolean alreadyContains(int[] paramArrayOfint, int paramInt) {
    int j = paramArrayOfint[paramInt];
    for (int i = 0; i < paramInt; i++) {
      if (paramArrayOfint[i] == j)
        return true; 
    } 
    return false;
  }
  
  private void captureHierarchy(View paramView, boolean paramBoolean) {
    if (paramView == null)
      return; 
    int i = paramView.getId();
    ArrayList<Integer> arrayList2 = this.mTargetIdExcludes;
    if (arrayList2 != null && arrayList2.contains(Integer.valueOf(i)))
      return; 
    ArrayList<View> arrayList1 = this.mTargetExcludes;
    if (arrayList1 != null && arrayList1.contains(paramView))
      return; 
    ArrayList<Class> arrayList = this.mTargetTypeExcludes;
    byte b = 0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        if (((Class)this.mTargetTypeExcludes.get(j)).isInstance(paramView))
          return; 
      } 
    } 
    if (paramView.getParent() instanceof ViewGroup) {
      TransitionValues transitionValues = new TransitionValues();
      transitionValues.view = paramView;
      if (paramBoolean) {
        captureStartValues(transitionValues);
      } else {
        captureEndValues(transitionValues);
      } 
      transitionValues.mTargetedTransitions.add(this);
      capturePropagationValues(transitionValues);
      if (paramBoolean) {
        addViewValues(this.mStartValues, paramView, transitionValues);
      } else {
        addViewValues(this.mEndValues, paramView, transitionValues);
      } 
    } 
    if (paramView instanceof ViewGroup) {
      ArrayList<Integer> arrayList5 = this.mTargetIdChildExcludes;
      if (arrayList5 != null && arrayList5.contains(Integer.valueOf(i)))
        return; 
      ArrayList<View> arrayList4 = this.mTargetChildExcludes;
      if (arrayList4 != null && arrayList4.contains(paramView))
        return; 
      ArrayList<Class> arrayList3 = this.mTargetTypeChildExcludes;
      if (arrayList3 != null) {
        i = arrayList3.size();
        for (int k = 0; k < i; k++) {
          if (((Class)this.mTargetTypeChildExcludes.get(k)).isInstance(paramView))
            return; 
        } 
      } 
      ViewGroup viewGroup = (ViewGroup)paramView;
      for (int j = b; j < viewGroup.getChildCount(); j++)
        captureHierarchy(viewGroup.getChildAt(j), paramBoolean); 
    } 
  }
  
  private ArrayList<Integer> excludeId(ArrayList<Integer> paramArrayList, int paramInt, boolean paramBoolean) {
    ArrayList<Integer> arrayList = paramArrayList;
    if (paramInt > 0) {
      if (paramBoolean)
        return ArrayListManager.add(paramArrayList, Integer.valueOf(paramInt)); 
      arrayList = ArrayListManager.remove(paramArrayList, Integer.valueOf(paramInt));
    } 
    return arrayList;
  }
  
  private static <T> ArrayList<T> excludeObject(ArrayList<T> paramArrayList, T paramT, boolean paramBoolean) {
    ArrayList<T> arrayList = paramArrayList;
    if (paramT != null) {
      if (paramBoolean)
        return ArrayListManager.add(paramArrayList, paramT); 
      arrayList = ArrayListManager.remove(paramArrayList, paramT);
    } 
    return arrayList;
  }
  
  private ArrayList<Class> excludeType(ArrayList<Class> paramArrayList, Class<?> paramClass, boolean paramBoolean) {
    ArrayList<Class> arrayList = paramArrayList;
    if (paramClass != null) {
      if (paramBoolean)
        return ArrayListManager.add(paramArrayList, paramClass); 
      arrayList = ArrayListManager.remove(paramArrayList, paramClass);
    } 
    return arrayList;
  }
  
  private ArrayList<View> excludeView(ArrayList<View> paramArrayList, View paramView, boolean paramBoolean) {
    ArrayList<View> arrayList = paramArrayList;
    if (paramView != null) {
      if (paramBoolean)
        return ArrayListManager.add(paramArrayList, paramView); 
      arrayList = ArrayListManager.remove(paramArrayList, paramView);
    } 
    return arrayList;
  }
  
  private static ArrayMap<Animator, AnimationInfo> getRunningAnimators() {
    ArrayMap<Animator, AnimationInfo> arrayMap2 = sRunningAnimators.get();
    ArrayMap<Animator, AnimationInfo> arrayMap1 = arrayMap2;
    if (arrayMap2 == null) {
      arrayMap1 = new ArrayMap();
      sRunningAnimators.set(arrayMap1);
    } 
    return arrayMap1;
  }
  
  private static boolean isValidMatch(int paramInt) {
    return (paramInt >= 1 && paramInt <= 4);
  }
  
  private static boolean isValueChanged(TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2, String paramString) {
    paramTransitionValues1 = (TransitionValues)paramTransitionValues1.values.get(paramString);
    paramTransitionValues2 = (TransitionValues)paramTransitionValues2.values.get(paramString);
    int i = 1;
    if (paramTransitionValues1 == null && paramTransitionValues2 == null)
      return false; 
    if (paramTransitionValues1 != null) {
      if (paramTransitionValues2 == null)
        return true; 
      i = true ^ paramTransitionValues1.equals(paramTransitionValues2);
    } 
    return i;
  }
  
  private void matchIds(ArrayMap<View, TransitionValues> paramArrayMap1, ArrayMap<View, TransitionValues> paramArrayMap2, SparseArray<View> paramSparseArray1, SparseArray<View> paramSparseArray2) {
    int j = paramSparseArray1.size();
    int i;
    for (i = 0; i < j; i++) {
      View view = (View)paramSparseArray1.valueAt(i);
      if (view != null && isValidTarget(view)) {
        View view1 = (View)paramSparseArray2.get(paramSparseArray1.keyAt(i));
        if (view1 != null && isValidTarget(view1)) {
          TransitionValues transitionValues1 = (TransitionValues)paramArrayMap1.get(view);
          TransitionValues transitionValues2 = (TransitionValues)paramArrayMap2.get(view1);
          if (transitionValues1 != null && transitionValues2 != null) {
            this.mStartValuesList.add(transitionValues1);
            this.mEndValuesList.add(transitionValues2);
            paramArrayMap1.remove(view);
            paramArrayMap2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void matchInstances(ArrayMap<View, TransitionValues> paramArrayMap1, ArrayMap<View, TransitionValues> paramArrayMap2) {
    for (int i = paramArrayMap1.size() - 1; i >= 0; i--) {
      View view = (View)paramArrayMap1.keyAt(i);
      if (view != null && isValidTarget(view)) {
        TransitionValues transitionValues = (TransitionValues)paramArrayMap2.remove(view);
        if (transitionValues != null) {
          View view1 = transitionValues.view;
          if (view1 != null && isValidTarget(view1)) {
            TransitionValues transitionValues1 = (TransitionValues)paramArrayMap1.removeAt(i);
            this.mStartValuesList.add(transitionValues1);
            this.mEndValuesList.add(transitionValues);
          } 
        } 
      } 
    } 
  }
  
  private void matchItemIds(ArrayMap<View, TransitionValues> paramArrayMap1, ArrayMap<View, TransitionValues> paramArrayMap2, LongSparseArray<View> paramLongSparseArray1, LongSparseArray<View> paramLongSparseArray2) {
    int j = paramLongSparseArray1.size();
    int i;
    for (i = 0; i < j; i++) {
      View view = (View)paramLongSparseArray1.valueAt(i);
      if (view != null && isValidTarget(view)) {
        View view1 = (View)paramLongSparseArray2.get(paramLongSparseArray1.keyAt(i));
        if (view1 != null && isValidTarget(view1)) {
          TransitionValues transitionValues1 = (TransitionValues)paramArrayMap1.get(view);
          TransitionValues transitionValues2 = (TransitionValues)paramArrayMap2.get(view1);
          if (transitionValues1 != null && transitionValues2 != null) {
            this.mStartValuesList.add(transitionValues1);
            this.mEndValuesList.add(transitionValues2);
            paramArrayMap1.remove(view);
            paramArrayMap2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void matchNames(ArrayMap<View, TransitionValues> paramArrayMap1, ArrayMap<View, TransitionValues> paramArrayMap2, ArrayMap<String, View> paramArrayMap3, ArrayMap<String, View> paramArrayMap4) {
    int j = paramArrayMap3.size();
    int i;
    for (i = 0; i < j; i++) {
      View view = (View)paramArrayMap3.valueAt(i);
      if (view != null && isValidTarget(view)) {
        View view1 = (View)paramArrayMap4.get(paramArrayMap3.keyAt(i));
        if (view1 != null && isValidTarget(view1)) {
          TransitionValues transitionValues1 = (TransitionValues)paramArrayMap1.get(view);
          TransitionValues transitionValues2 = (TransitionValues)paramArrayMap2.get(view1);
          if (transitionValues1 != null && transitionValues2 != null) {
            this.mStartValuesList.add(transitionValues1);
            this.mEndValuesList.add(transitionValues2);
            paramArrayMap1.remove(view);
            paramArrayMap2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void matchStartAndEnd(TransitionValuesMaps paramTransitionValuesMaps1, TransitionValuesMaps paramTransitionValuesMaps2) {
    ArrayMap<View, TransitionValues> arrayMap1 = new ArrayMap((SimpleArrayMap)paramTransitionValuesMaps1.mViewValues);
    ArrayMap<View, TransitionValues> arrayMap2 = new ArrayMap((SimpleArrayMap)paramTransitionValuesMaps2.mViewValues);
    int i = 0;
    while (true) {
      int[] arrayOfInt = this.mMatchOrder;
      if (i < arrayOfInt.length) {
        int j = arrayOfInt[i];
        if (j != 1) {
          if (j != 2) {
            if (j != 3) {
              if (j == 4)
                matchItemIds(arrayMap1, arrayMap2, paramTransitionValuesMaps1.mItemIdValues, paramTransitionValuesMaps2.mItemIdValues); 
            } else {
              matchIds(arrayMap1, arrayMap2, paramTransitionValuesMaps1.mIdValues, paramTransitionValuesMaps2.mIdValues);
            } 
          } else {
            matchNames(arrayMap1, arrayMap2, paramTransitionValuesMaps1.mNameValues, paramTransitionValuesMaps2.mNameValues);
          } 
        } else {
          matchInstances(arrayMap1, arrayMap2);
        } 
        i++;
        continue;
      } 
      addUnmatched(arrayMap1, arrayMap2);
      return;
    } 
  }
  
  private static int[] parseMatchOrder(String paramString) {
    StringBuilder stringBuilder;
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    int[] arrayOfInt = new int[stringTokenizer.countTokens()];
    for (int i = 0; stringTokenizer.hasMoreTokens(); i++) {
      String str = stringTokenizer.nextToken().trim();
      if ("id".equalsIgnoreCase(str)) {
        arrayOfInt[i] = 3;
      } else if ("instance".equalsIgnoreCase(str)) {
        arrayOfInt[i] = 1;
      } else if ("name".equalsIgnoreCase(str)) {
        arrayOfInt[i] = 2;
      } else if ("itemId".equalsIgnoreCase(str)) {
        arrayOfInt[i] = 4;
      } else {
        int[] arrayOfInt1;
        if (str.isEmpty()) {
          arrayOfInt1 = new int[arrayOfInt.length - 1];
          System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, i);
          i--;
          arrayOfInt = arrayOfInt1;
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown match type in matchOrder: '");
          stringBuilder.append((String)arrayOfInt1);
          stringBuilder.append("'");
          throw new InflateException(stringBuilder.toString());
        } 
      } 
    } 
    return (int[])stringBuilder;
  }
  
  private void runAnimator(Animator paramAnimator, final ArrayMap<Animator, AnimationInfo> runningAnimators) {
    if (paramAnimator != null) {
      paramAnimator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator param1Animator) {
              runningAnimators.remove(param1Animator);
              Transition.this.mCurrentAnimators.remove(param1Animator);
            }
            
            public void onAnimationStart(Animator param1Animator) {
              Transition.this.mCurrentAnimators.add(param1Animator);
            }
          });
      animate(paramAnimator);
    } 
  }
  
  @NonNull
  public Transition addListener(@NonNull TransitionListener paramTransitionListener) {
    if (this.mListeners == null)
      this.mListeners = new ArrayList<TransitionListener>(); 
    this.mListeners.add(paramTransitionListener);
    return this;
  }
  
  @NonNull
  public Transition addTarget(@IdRes int paramInt) {
    if (paramInt != 0)
      this.mTargetIds.add(Integer.valueOf(paramInt)); 
    return this;
  }
  
  @NonNull
  public Transition addTarget(@NonNull View paramView) {
    this.mTargets.add(paramView);
    return this;
  }
  
  @NonNull
  public Transition addTarget(@NonNull Class paramClass) {
    if (this.mTargetTypes == null)
      this.mTargetTypes = new ArrayList<Class<?>>(); 
    this.mTargetTypes.add(paramClass);
    return this;
  }
  
  @NonNull
  public Transition addTarget(@NonNull String paramString) {
    if (this.mTargetNames == null)
      this.mTargetNames = new ArrayList<String>(); 
    this.mTargetNames.add(paramString);
    return this;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void animate(Animator paramAnimator) {
    if (paramAnimator == null) {
      end();
      return;
    } 
    if (getDuration() >= 0L)
      paramAnimator.setDuration(getDuration()); 
    if (getStartDelay() >= 0L)
      paramAnimator.setStartDelay(getStartDelay()); 
    if (getInterpolator() != null)
      paramAnimator.setInterpolator(getInterpolator()); 
    paramAnimator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            Transition.this.end();
            param1Animator.removeListener((Animator.AnimatorListener)this);
          }
        });
    paramAnimator.start();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void cancel() {
    int i;
    for (i = this.mCurrentAnimators.size() - 1; i >= 0; i--)
      ((Animator)this.mCurrentAnimators.get(i)).cancel(); 
    ArrayList<TransitionListener> arrayList = this.mListeners;
    if (arrayList != null && arrayList.size() > 0) {
      arrayList = (ArrayList<TransitionListener>)this.mListeners.clone();
      int j = arrayList.size();
      for (i = 0; i < j; i++)
        ((TransitionListener)arrayList.get(i)).onTransitionCancel(this); 
    } 
  }
  
  public abstract void captureEndValues(@NonNull TransitionValues paramTransitionValues);
  
  void capturePropagationValues(TransitionValues paramTransitionValues) {
    if (this.mPropagation != null && !paramTransitionValues.values.isEmpty()) {
      String[] arrayOfString = this.mPropagation.getPropagationProperties();
      if (arrayOfString == null)
        return; 
      byte b = 0;
      int i = 0;
      while (true) {
        if (i < arrayOfString.length) {
          if (!paramTransitionValues.values.containsKey(arrayOfString[i])) {
            i = b;
            break;
          } 
          i++;
          continue;
        } 
        i = 1;
        break;
      } 
      if (i == 0)
        this.mPropagation.captureValues(paramTransitionValues); 
    } 
  }
  
  public abstract void captureStartValues(@NonNull TransitionValues paramTransitionValues);
  
  void captureValues(ViewGroup paramViewGroup, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: invokevirtual clearValues : (Z)V
    //   5: aload_0
    //   6: getfield mTargetIds : Ljava/util/ArrayList;
    //   9: invokevirtual size : ()I
    //   12: istore_3
    //   13: iconst_0
    //   14: istore #5
    //   16: iload_3
    //   17: ifgt -> 30
    //   20: aload_0
    //   21: getfield mTargets : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: ifle -> 71
    //   30: aload_0
    //   31: getfield mTargetNames : Ljava/util/ArrayList;
    //   34: astore #7
    //   36: aload #7
    //   38: ifnull -> 49
    //   41: aload #7
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifeq -> 71
    //   49: aload_0
    //   50: getfield mTargetTypes : Ljava/util/ArrayList;
    //   53: astore #7
    //   55: aload #7
    //   57: ifnull -> 80
    //   60: aload #7
    //   62: invokevirtual isEmpty : ()Z
    //   65: ifeq -> 71
    //   68: goto -> 80
    //   71: aload_0
    //   72: aload_1
    //   73: iload_2
    //   74: invokespecial captureHierarchy : (Landroid/view/View;Z)V
    //   77: goto -> 314
    //   80: iconst_0
    //   81: istore_3
    //   82: iload_3
    //   83: aload_0
    //   84: getfield mTargetIds : Ljava/util/ArrayList;
    //   87: invokevirtual size : ()I
    //   90: if_icmpge -> 205
    //   93: aload_1
    //   94: aload_0
    //   95: getfield mTargetIds : Ljava/util/ArrayList;
    //   98: iload_3
    //   99: invokevirtual get : (I)Ljava/lang/Object;
    //   102: checkcast java/lang/Integer
    //   105: invokevirtual intValue : ()I
    //   108: invokevirtual findViewById : (I)Landroid/view/View;
    //   111: astore #7
    //   113: aload #7
    //   115: ifnull -> 198
    //   118: new androidx/transition/TransitionValues
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: astore #8
    //   127: aload #8
    //   129: aload #7
    //   131: putfield view : Landroid/view/View;
    //   134: iload_2
    //   135: ifeq -> 147
    //   138: aload_0
    //   139: aload #8
    //   141: invokevirtual captureStartValues : (Landroidx/transition/TransitionValues;)V
    //   144: goto -> 153
    //   147: aload_0
    //   148: aload #8
    //   150: invokevirtual captureEndValues : (Landroidx/transition/TransitionValues;)V
    //   153: aload #8
    //   155: getfield mTargetedTransitions : Ljava/util/ArrayList;
    //   158: aload_0
    //   159: invokevirtual add : (Ljava/lang/Object;)Z
    //   162: pop
    //   163: aload_0
    //   164: aload #8
    //   166: invokevirtual capturePropagationValues : (Landroidx/transition/TransitionValues;)V
    //   169: iload_2
    //   170: ifeq -> 187
    //   173: aload_0
    //   174: getfield mStartValues : Landroidx/transition/TransitionValuesMaps;
    //   177: aload #7
    //   179: aload #8
    //   181: invokestatic addViewValues : (Landroidx/transition/TransitionValuesMaps;Landroid/view/View;Landroidx/transition/TransitionValues;)V
    //   184: goto -> 198
    //   187: aload_0
    //   188: getfield mEndValues : Landroidx/transition/TransitionValuesMaps;
    //   191: aload #7
    //   193: aload #8
    //   195: invokestatic addViewValues : (Landroidx/transition/TransitionValuesMaps;Landroid/view/View;Landroidx/transition/TransitionValues;)V
    //   198: iload_3
    //   199: iconst_1
    //   200: iadd
    //   201: istore_3
    //   202: goto -> 82
    //   205: iconst_0
    //   206: istore_3
    //   207: iload_3
    //   208: aload_0
    //   209: getfield mTargets : Ljava/util/ArrayList;
    //   212: invokevirtual size : ()I
    //   215: if_icmpge -> 314
    //   218: aload_0
    //   219: getfield mTargets : Ljava/util/ArrayList;
    //   222: iload_3
    //   223: invokevirtual get : (I)Ljava/lang/Object;
    //   226: checkcast android/view/View
    //   229: astore_1
    //   230: new androidx/transition/TransitionValues
    //   233: dup
    //   234: invokespecial <init> : ()V
    //   237: astore #7
    //   239: aload #7
    //   241: aload_1
    //   242: putfield view : Landroid/view/View;
    //   245: iload_2
    //   246: ifeq -> 258
    //   249: aload_0
    //   250: aload #7
    //   252: invokevirtual captureStartValues : (Landroidx/transition/TransitionValues;)V
    //   255: goto -> 264
    //   258: aload_0
    //   259: aload #7
    //   261: invokevirtual captureEndValues : (Landroidx/transition/TransitionValues;)V
    //   264: aload #7
    //   266: getfield mTargetedTransitions : Ljava/util/ArrayList;
    //   269: aload_0
    //   270: invokevirtual add : (Ljava/lang/Object;)Z
    //   273: pop
    //   274: aload_0
    //   275: aload #7
    //   277: invokevirtual capturePropagationValues : (Landroidx/transition/TransitionValues;)V
    //   280: iload_2
    //   281: ifeq -> 297
    //   284: aload_0
    //   285: getfield mStartValues : Landroidx/transition/TransitionValuesMaps;
    //   288: aload_1
    //   289: aload #7
    //   291: invokestatic addViewValues : (Landroidx/transition/TransitionValuesMaps;Landroid/view/View;Landroidx/transition/TransitionValues;)V
    //   294: goto -> 307
    //   297: aload_0
    //   298: getfield mEndValues : Landroidx/transition/TransitionValuesMaps;
    //   301: aload_1
    //   302: aload #7
    //   304: invokestatic addViewValues : (Landroidx/transition/TransitionValuesMaps;Landroid/view/View;Landroidx/transition/TransitionValues;)V
    //   307: iload_3
    //   308: iconst_1
    //   309: iadd
    //   310: istore_3
    //   311: goto -> 207
    //   314: iload_2
    //   315: ifne -> 453
    //   318: aload_0
    //   319: getfield mNameOverrides : Landroidx/collection/ArrayMap;
    //   322: astore_1
    //   323: aload_1
    //   324: ifnull -> 453
    //   327: aload_1
    //   328: invokevirtual size : ()I
    //   331: istore #6
    //   333: new java/util/ArrayList
    //   336: dup
    //   337: iload #6
    //   339: invokespecial <init> : (I)V
    //   342: astore_1
    //   343: iconst_0
    //   344: istore_3
    //   345: iload #5
    //   347: istore #4
    //   349: iload_3
    //   350: iload #6
    //   352: if_icmpge -> 392
    //   355: aload_0
    //   356: getfield mNameOverrides : Landroidx/collection/ArrayMap;
    //   359: iload_3
    //   360: invokevirtual keyAt : (I)Ljava/lang/Object;
    //   363: checkcast java/lang/String
    //   366: astore #7
    //   368: aload_1
    //   369: aload_0
    //   370: getfield mStartValues : Landroidx/transition/TransitionValuesMaps;
    //   373: getfield mNameValues : Landroidx/collection/ArrayMap;
    //   376: aload #7
    //   378: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   381: invokevirtual add : (Ljava/lang/Object;)Z
    //   384: pop
    //   385: iload_3
    //   386: iconst_1
    //   387: iadd
    //   388: istore_3
    //   389: goto -> 345
    //   392: iload #4
    //   394: iload #6
    //   396: if_icmpge -> 453
    //   399: aload_1
    //   400: iload #4
    //   402: invokevirtual get : (I)Ljava/lang/Object;
    //   405: checkcast android/view/View
    //   408: astore #7
    //   410: aload #7
    //   412: ifnull -> 444
    //   415: aload_0
    //   416: getfield mNameOverrides : Landroidx/collection/ArrayMap;
    //   419: iload #4
    //   421: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   424: checkcast java/lang/String
    //   427: astore #8
    //   429: aload_0
    //   430: getfield mStartValues : Landroidx/transition/TransitionValuesMaps;
    //   433: getfield mNameValues : Landroidx/collection/ArrayMap;
    //   436: aload #8
    //   438: aload #7
    //   440: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   443: pop
    //   444: iload #4
    //   446: iconst_1
    //   447: iadd
    //   448: istore #4
    //   450: goto -> 392
    //   453: return
  }
  
  void clearValues(boolean paramBoolean) {
    if (paramBoolean) {
      this.mStartValues.mViewValues.clear();
      this.mStartValues.mIdValues.clear();
      this.mStartValues.mItemIdValues.clear();
      return;
    } 
    this.mEndValues.mViewValues.clear();
    this.mEndValues.mIdValues.clear();
    this.mEndValues.mItemIdValues.clear();
  }
  
  public Transition clone() {
    try {
      Transition transition = (Transition)super.clone();
      transition.mAnimators = new ArrayList<Animator>();
      transition.mStartValues = new TransitionValuesMaps();
      transition.mEndValues = new TransitionValuesMaps();
      transition.mStartValuesList = null;
      transition.mEndValuesList = null;
      return transition;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      return null;
    } 
  }
  
  @Nullable
  public Animator createAnimator(@NonNull ViewGroup paramViewGroup, @Nullable TransitionValues paramTransitionValues1, @Nullable TransitionValues paramTransitionValues2) {
    return null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void createAnimators(ViewGroup paramViewGroup, TransitionValuesMaps paramTransitionValuesMaps1, TransitionValuesMaps paramTransitionValuesMaps2, ArrayList<TransitionValues> paramArrayList1, ArrayList<TransitionValues> paramArrayList2) {
    Object object;
    ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
    SparseIntArray sparseIntArray = new SparseIntArray();
    int j = paramArrayList1.size();
    long l = Long.MAX_VALUE;
    int i = 0;
    while (i < j) {
      TransitionValues transitionValues2 = paramArrayList1.get(i);
      TransitionValues transitionValues1 = paramArrayList2.get(i);
      TransitionValues transitionValues3 = transitionValues2;
      if (transitionValues2 != null) {
        transitionValues3 = transitionValues2;
        if (!transitionValues2.mTargetedTransitions.contains(this))
          transitionValues3 = null; 
      } 
      TransitionValues transitionValues4 = transitionValues1;
      if (transitionValues1 != null) {
        transitionValues4 = transitionValues1;
        if (!transitionValues1.mTargetedTransitions.contains(this))
          transitionValues4 = null; 
      } 
      if (transitionValues3 != null || transitionValues4 != null) {
        int m;
        if (transitionValues3 == null || transitionValues4 == null || isTransitionRequired(transitionValues3, transitionValues4)) {
          m = 1;
        } else {
          m = 0;
        } 
        if (m) {
          Animator animator = createAnimator(paramViewGroup, transitionValues3, transitionValues4);
          if (animator != null) {
            TransitionValues transitionValues;
            View view;
            if (transitionValues4 != null) {
              View view1 = transitionValues4.view;
              String[] arrayOfString = getTransitionProperties();
              if (view1 != null && arrayOfString != null && arrayOfString.length > 0) {
                TransitionValues transitionValues5 = new TransitionValues();
                transitionValues5.view = view1;
                transitionValues2 = (TransitionValues)paramTransitionValuesMaps2.mViewValues.get(view1);
                m = i;
                if (transitionValues2 != null) {
                  int i1 = 0;
                  while (true) {
                    m = i;
                    if (i1 < arrayOfString.length) {
                      transitionValues5.values.put(arrayOfString[i1], transitionValues2.values.get(arrayOfString[i1]));
                      i1++;
                      continue;
                    } 
                    break;
                  } 
                } 
                i = m;
                int n = arrayMap.size();
                m = 0;
                while (true) {
                  if (m < n) {
                    AnimationInfo animationInfo = (AnimationInfo)arrayMap.get(arrayMap.keyAt(m));
                    if (animationInfo.mValues != null && animationInfo.mView == view1 && animationInfo.mName.equals(getName()) && animationInfo.mValues.equals(transitionValues5)) {
                      animator = null;
                      TransitionValues transitionValues6 = transitionValues5;
                      break;
                    } 
                    m++;
                    continue;
                  } 
                  transitionValues2 = transitionValues5;
                  break;
                } 
              } else {
                transitionValues2 = null;
              } 
              Animator animator2 = animator;
              transitionValues = transitionValues2;
              Animator animator1 = animator2;
              view = view1;
            } else {
              view = transitionValues3.view;
              TransitionValues transitionValues5 = null;
              transitionValues2 = transitionValues;
              transitionValues = transitionValues5;
            } 
            Object object2 = object;
            m = i;
            if (transitionValues2 != null) {
              TransitionPropagation transitionPropagation = this.mPropagation;
              object2 = object;
              if (transitionPropagation != null) {
                long l1 = transitionPropagation.getStartDelay(paramViewGroup, this, transitionValues3, transitionValues4);
                sparseIntArray.put(this.mAnimators.size(), (int)l1);
                l1 = Math.min(l1, object);
              } 
              arrayMap.put(transitionValues2, new AnimationInfo(view, getName(), this, ViewUtils.getWindowId((View)paramViewGroup), transitionValues));
              this.mAnimators.add(transitionValues2);
              m = i;
            } 
            continue;
          } 
        } 
      } 
      Object object1 = object;
      int k = i;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_7 + 1;
      object = SYNTHETIC_LOCAL_VARIABLE_12;
    } 
    if (object != 0L)
      for (i = 0; i < sparseIntArray.size(); i++) {
        int k = sparseIntArray.keyAt(i);
        Animator animator = this.mAnimators.get(k);
        animator.setStartDelay(sparseIntArray.valueAt(i) - object + animator.getStartDelay());
      }  
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void end() {
    int i = this.mNumInstances - 1;
    this.mNumInstances = i;
    if (i == 0) {
      ArrayList<TransitionListener> arrayList = this.mListeners;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<TransitionListener>)this.mListeners.clone();
        int j = arrayList.size();
        for (i = 0; i < j; i++)
          ((TransitionListener)arrayList.get(i)).onTransitionEnd(this); 
      } 
      for (i = 0; i < this.mStartValues.mItemIdValues.size(); i++) {
        View view = (View)this.mStartValues.mItemIdValues.valueAt(i);
        if (view != null)
          ViewCompat.setHasTransientState(view, false); 
      } 
      for (i = 0; i < this.mEndValues.mItemIdValues.size(); i++) {
        View view = (View)this.mEndValues.mItemIdValues.valueAt(i);
        if (view != null)
          ViewCompat.setHasTransientState(view, false); 
      } 
      this.mEnded = true;
    } 
  }
  
  @NonNull
  public Transition excludeChildren(@IdRes int paramInt, boolean paramBoolean) {
    this.mTargetIdChildExcludes = excludeId(this.mTargetIdChildExcludes, paramInt, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeChildren(@NonNull View paramView, boolean paramBoolean) {
    this.mTargetChildExcludes = excludeView(this.mTargetChildExcludes, paramView, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeChildren(@NonNull Class paramClass, boolean paramBoolean) {
    this.mTargetTypeChildExcludes = excludeType(this.mTargetTypeChildExcludes, paramClass, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeTarget(@IdRes int paramInt, boolean paramBoolean) {
    this.mTargetIdExcludes = excludeId(this.mTargetIdExcludes, paramInt, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeTarget(@NonNull View paramView, boolean paramBoolean) {
    this.mTargetExcludes = excludeView(this.mTargetExcludes, paramView, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeTarget(@NonNull Class paramClass, boolean paramBoolean) {
    this.mTargetTypeExcludes = excludeType(this.mTargetTypeExcludes, paramClass, paramBoolean);
    return this;
  }
  
  @NonNull
  public Transition excludeTarget(@NonNull String paramString, boolean paramBoolean) {
    this.mTargetNameExcludes = excludeObject(this.mTargetNameExcludes, paramString, paramBoolean);
    return this;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  void forceToEnd(ViewGroup paramViewGroup) {
    ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
    int i = arrayMap.size();
    if (paramViewGroup != null) {
      WindowIdImpl windowIdImpl = ViewUtils.getWindowId((View)paramViewGroup);
      while (--i >= 0) {
        AnimationInfo animationInfo = (AnimationInfo)arrayMap.valueAt(i);
        if (animationInfo.mView != null && windowIdImpl != null && windowIdImpl.equals(animationInfo.mWindowId))
          ((Animator)arrayMap.keyAt(i)).end(); 
        i--;
      } 
    } 
  }
  
  public long getDuration() {
    return this.mDuration;
  }
  
  @Nullable
  public Rect getEpicenter() {
    EpicenterCallback epicenterCallback = this.mEpicenterCallback;
    return (epicenterCallback == null) ? null : epicenterCallback.onGetEpicenter(this);
  }
  
  @Nullable
  public EpicenterCallback getEpicenterCallback() {
    return this.mEpicenterCallback;
  }
  
  @Nullable
  public TimeInterpolator getInterpolator() {
    return this.mInterpolator;
  }
  
  TransitionValues getMatchedTransitionValues(View paramView, boolean paramBoolean) {
    TransitionValues transitionValues;
    int j;
    ArrayList<TransitionValues> arrayList;
    TransitionSet transitionSet = this.mParent;
    if (transitionSet != null)
      return transitionSet.getMatchedTransitionValues(paramView, paramBoolean); 
    if (paramBoolean) {
      arrayList = this.mStartValuesList;
    } else {
      arrayList = this.mEndValuesList;
    } 
    View view = null;
    if (arrayList == null)
      return null; 
    int k = arrayList.size();
    byte b = -1;
    int i = 0;
    while (true) {
      j = b;
      if (i < k) {
        TransitionValues transitionValues1 = arrayList.get(i);
        if (transitionValues1 == null)
          return null; 
        if (transitionValues1.view == paramView) {
          j = i;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    paramView = view;
    if (j >= 0) {
      ArrayList<TransitionValues> arrayList1;
      if (paramBoolean) {
        arrayList1 = this.mEndValuesList;
      } else {
        arrayList1 = this.mStartValuesList;
      } 
      transitionValues = arrayList1.get(j);
    } 
    return transitionValues;
  }
  
  @NonNull
  public String getName() {
    return this.mName;
  }
  
  @NonNull
  public PathMotion getPathMotion() {
    return this.mPathMotion;
  }
  
  @Nullable
  public TransitionPropagation getPropagation() {
    return this.mPropagation;
  }
  
  public long getStartDelay() {
    return this.mStartDelay;
  }
  
  @NonNull
  public List<Integer> getTargetIds() {
    return this.mTargetIds;
  }
  
  @Nullable
  public List<String> getTargetNames() {
    return this.mTargetNames;
  }
  
  @Nullable
  public List<Class> getTargetTypes() {
    return this.mTargetTypes;
  }
  
  @NonNull
  public List<View> getTargets() {
    return this.mTargets;
  }
  
  @Nullable
  public String[] getTransitionProperties() {
    return null;
  }
  
  @Nullable
  public TransitionValues getTransitionValues(@NonNull View paramView, boolean paramBoolean) {
    TransitionValuesMaps transitionValuesMaps;
    TransitionSet transitionSet = this.mParent;
    if (transitionSet != null)
      return transitionSet.getTransitionValues(paramView, paramBoolean); 
    if (paramBoolean) {
      transitionValuesMaps = this.mStartValues;
    } else {
      transitionValuesMaps = this.mEndValues;
    } 
    return (TransitionValues)transitionValuesMaps.mViewValues.get(paramView);
  }
  
  public boolean isTransitionRequired(@Nullable TransitionValues paramTransitionValues1, @Nullable TransitionValues paramTransitionValues2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #6
    //   3: iload #6
    //   5: istore #5
    //   7: aload_1
    //   8: ifnull -> 120
    //   11: iload #6
    //   13: istore #5
    //   15: aload_2
    //   16: ifnull -> 120
    //   19: aload_0
    //   20: invokevirtual getTransitionProperties : ()[Ljava/lang/String;
    //   23: astore #7
    //   25: aload #7
    //   27: ifnull -> 69
    //   30: aload #7
    //   32: arraylength
    //   33: istore #4
    //   35: iconst_0
    //   36: istore_3
    //   37: iload #6
    //   39: istore #5
    //   41: iload_3
    //   42: iload #4
    //   44: if_icmpge -> 120
    //   47: aload_1
    //   48: aload_2
    //   49: aload #7
    //   51: iload_3
    //   52: aaload
    //   53: invokestatic isValueChanged : (Landroidx/transition/TransitionValues;Landroidx/transition/TransitionValues;Ljava/lang/String;)Z
    //   56: ifeq -> 62
    //   59: goto -> 117
    //   62: iload_3
    //   63: iconst_1
    //   64: iadd
    //   65: istore_3
    //   66: goto -> 37
    //   69: aload_1
    //   70: getfield values : Ljava/util/Map;
    //   73: invokeinterface keySet : ()Ljava/util/Set;
    //   78: invokeinterface iterator : ()Ljava/util/Iterator;
    //   83: astore #7
    //   85: iload #6
    //   87: istore #5
    //   89: aload #7
    //   91: invokeinterface hasNext : ()Z
    //   96: ifeq -> 120
    //   99: aload_1
    //   100: aload_2
    //   101: aload #7
    //   103: invokeinterface next : ()Ljava/lang/Object;
    //   108: checkcast java/lang/String
    //   111: invokestatic isValueChanged : (Landroidx/transition/TransitionValues;Landroidx/transition/TransitionValues;Ljava/lang/String;)Z
    //   114: ifeq -> 85
    //   117: iconst_1
    //   118: istore #5
    //   120: iload #5
    //   122: ireturn
  }
  
  boolean isValidTarget(View paramView) {
    int i = paramView.getId();
    ArrayList<Integer> arrayList2 = this.mTargetIdExcludes;
    if (arrayList2 != null && arrayList2.contains(Integer.valueOf(i)))
      return false; 
    ArrayList<View> arrayList1 = this.mTargetExcludes;
    if (arrayList1 != null && arrayList1.contains(paramView))
      return false; 
    ArrayList<Class> arrayList = this.mTargetTypeExcludes;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        if (((Class)this.mTargetTypeExcludes.get(j)).isInstance(paramView))
          return false; 
      } 
    } 
    if (this.mTargetNameExcludes != null && ViewCompat.getTransitionName(paramView) != null && this.mTargetNameExcludes.contains(ViewCompat.getTransitionName(paramView)))
      return false; 
    if (this.mTargetIds.size() == 0 && this.mTargets.size() == 0) {
      arrayList = this.mTargetTypes;
      if (arrayList == null || arrayList.isEmpty()) {
        ArrayList<String> arrayList3 = this.mTargetNames;
        if (arrayList3 == null || arrayList3.isEmpty())
          return true; 
      } 
    } 
    if (!this.mTargetIds.contains(Integer.valueOf(i))) {
      if (this.mTargets.contains(paramView))
        return true; 
      ArrayList<String> arrayList3 = this.mTargetNames;
      if (arrayList3 != null && arrayList3.contains(ViewCompat.getTransitionName(paramView)))
        return true; 
      if (this.mTargetTypes != null)
        for (int j = 0; j < this.mTargetTypes.size(); j++) {
          if (((Class)this.mTargetTypes.get(j)).isInstance(paramView))
            return true; 
        }  
      return false;
    } 
    return true;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void pause(View paramView) {
    if (!this.mEnded) {
      ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
      int i = arrayMap.size();
      WindowIdImpl windowIdImpl = ViewUtils.getWindowId(paramView);
      while (--i >= 0) {
        AnimationInfo animationInfo = (AnimationInfo)arrayMap.valueAt(i);
        if (animationInfo.mView != null && windowIdImpl.equals(animationInfo.mWindowId))
          AnimatorUtils.pause((Animator)arrayMap.keyAt(i)); 
        i--;
      } 
      ArrayList<TransitionListener> arrayList = this.mListeners;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<TransitionListener>)this.mListeners.clone();
        int j = arrayList.size();
        for (i = 0; i < j; i++)
          ((TransitionListener)arrayList.get(i)).onTransitionPause(this); 
      } 
      this.mPaused = true;
    } 
  }
  
  void playTransition(ViewGroup paramViewGroup) {
    this.mStartValuesList = new ArrayList<TransitionValues>();
    this.mEndValuesList = new ArrayList<TransitionValues>();
    matchStartAndEnd(this.mStartValues, this.mEndValues);
    ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
    int i = arrayMap.size();
    WindowIdImpl windowIdImpl = ViewUtils.getWindowId((View)paramViewGroup);
    while (--i >= 0) {
      Animator animator = (Animator)arrayMap.keyAt(i);
      if (animator != null) {
        AnimationInfo animationInfo = (AnimationInfo)arrayMap.get(animator);
        if (animationInfo != null && animationInfo.mView != null && windowIdImpl.equals(animationInfo.mWindowId)) {
          boolean bool;
          TransitionValues transitionValues1 = animationInfo.mValues;
          View view = animationInfo.mView;
          TransitionValues transitionValues2 = getTransitionValues(view, true);
          TransitionValues transitionValues3 = getMatchedTransitionValues(view, true);
          if ((transitionValues2 != null || transitionValues3 != null) && animationInfo.mTransition.isTransitionRequired(transitionValues1, transitionValues3)) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool)
            if (animator.isRunning() || animator.isStarted()) {
              animator.cancel();
            } else {
              arrayMap.remove(animator);
            }  
        } 
      } 
      i--;
    } 
    createAnimators(paramViewGroup, this.mStartValues, this.mEndValues, this.mStartValuesList, this.mEndValuesList);
    runAnimators();
  }
  
  @NonNull
  public Transition removeListener(@NonNull TransitionListener paramTransitionListener) {
    ArrayList<TransitionListener> arrayList = this.mListeners;
    if (arrayList == null)
      return this; 
    arrayList.remove(paramTransitionListener);
    if (this.mListeners.size() == 0)
      this.mListeners = null; 
    return this;
  }
  
  @NonNull
  public Transition removeTarget(@IdRes int paramInt) {
    if (paramInt != 0)
      this.mTargetIds.remove(Integer.valueOf(paramInt)); 
    return this;
  }
  
  @NonNull
  public Transition removeTarget(@NonNull View paramView) {
    this.mTargets.remove(paramView);
    return this;
  }
  
  @NonNull
  public Transition removeTarget(@NonNull Class paramClass) {
    ArrayList<Class> arrayList = this.mTargetTypes;
    if (arrayList != null)
      arrayList.remove(paramClass); 
    return this;
  }
  
  @NonNull
  public Transition removeTarget(@NonNull String paramString) {
    ArrayList<String> arrayList = this.mTargetNames;
    if (arrayList != null)
      arrayList.remove(paramString); 
    return this;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void resume(View paramView) {
    if (this.mPaused) {
      if (!this.mEnded) {
        ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
        int i = arrayMap.size();
        WindowIdImpl windowIdImpl = ViewUtils.getWindowId(paramView);
        while (--i >= 0) {
          AnimationInfo animationInfo = (AnimationInfo)arrayMap.valueAt(i);
          if (animationInfo.mView != null && windowIdImpl.equals(animationInfo.mWindowId))
            AnimatorUtils.resume((Animator)arrayMap.keyAt(i)); 
          i--;
        } 
        ArrayList<TransitionListener> arrayList = this.mListeners;
        if (arrayList != null && arrayList.size() > 0) {
          arrayList = (ArrayList<TransitionListener>)this.mListeners.clone();
          int j = arrayList.size();
          for (i = 0; i < j; i++)
            ((TransitionListener)arrayList.get(i)).onTransitionResume(this); 
        } 
      } 
      this.mPaused = false;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void runAnimators() {
    start();
    ArrayMap<Animator, AnimationInfo> arrayMap = getRunningAnimators();
    for (Animator animator : this.mAnimators) {
      if (arrayMap.containsKey(animator)) {
        start();
        runAnimator(animator, arrayMap);
      } 
    } 
    this.mAnimators.clear();
    end();
  }
  
  void setCanRemoveViews(boolean paramBoolean) {
    this.mCanRemoveViews = paramBoolean;
  }
  
  @NonNull
  public Transition setDuration(long paramLong) {
    this.mDuration = paramLong;
    return this;
  }
  
  public void setEpicenterCallback(@Nullable EpicenterCallback paramEpicenterCallback) {
    this.mEpicenterCallback = paramEpicenterCallback;
  }
  
  @NonNull
  public Transition setInterpolator(@Nullable TimeInterpolator paramTimeInterpolator) {
    this.mInterpolator = paramTimeInterpolator;
    return this;
  }
  
  public void setMatchOrder(int... paramVarArgs) {
    if (paramVarArgs == null || paramVarArgs.length == 0) {
      this.mMatchOrder = DEFAULT_MATCH_ORDER;
      return;
    } 
    int i = 0;
    while (i < paramVarArgs.length) {
      if (isValidMatch(paramVarArgs[i])) {
        if (!alreadyContains(paramVarArgs, i)) {
          i++;
          continue;
        } 
        throw new IllegalArgumentException("matches contains a duplicate value");
      } 
      throw new IllegalArgumentException("matches contains invalid value");
    } 
    this.mMatchOrder = (int[])paramVarArgs.clone();
  }
  
  public void setPathMotion(@Nullable PathMotion paramPathMotion) {
    if (paramPathMotion == null) {
      this.mPathMotion = STRAIGHT_PATH_MOTION;
      return;
    } 
    this.mPathMotion = paramPathMotion;
  }
  
  public void setPropagation(@Nullable TransitionPropagation paramTransitionPropagation) {
    this.mPropagation = paramTransitionPropagation;
  }
  
  Transition setSceneRoot(ViewGroup paramViewGroup) {
    this.mSceneRoot = paramViewGroup;
    return this;
  }
  
  @NonNull
  public Transition setStartDelay(long paramLong) {
    this.mStartDelay = paramLong;
    return this;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void start() {
    if (this.mNumInstances == 0) {
      ArrayList<TransitionListener> arrayList = this.mListeners;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<TransitionListener>)this.mListeners.clone();
        int j = arrayList.size();
        for (int i = 0; i < j; i++)
          ((TransitionListener)arrayList.get(i)).onTransitionStart(this); 
      } 
      this.mEnded = false;
    } 
    this.mNumInstances++;
  }
  
  public String toString() {
    return toString("");
  }
  
  String toString(String paramString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload #4
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #4
    //   18: aload_0
    //   19: invokevirtual getClass : ()Ljava/lang/Class;
    //   22: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: pop
    //   29: aload #4
    //   31: ldc_w '@'
    //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: pop
    //   38: aload #4
    //   40: aload_0
    //   41: invokevirtual hashCode : ()I
    //   44: invokestatic toHexString : (I)Ljava/lang/String;
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: aload #4
    //   53: ldc_w ': '
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #4
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: astore #4
    //   67: aload #4
    //   69: astore_1
    //   70: aload_0
    //   71: getfield mDuration : J
    //   74: ldc2_w -1
    //   77: lcmp
    //   78: ifeq -> 126
    //   81: new java/lang/StringBuilder
    //   84: dup
    //   85: invokespecial <init> : ()V
    //   88: astore_1
    //   89: aload_1
    //   90: aload #4
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload_1
    //   97: ldc_w 'dur('
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload_1
    //   105: aload_0
    //   106: getfield mDuration : J
    //   109: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_1
    //   114: ldc_w ') '
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: aload_1
    //   122: invokevirtual toString : ()Ljava/lang/String;
    //   125: astore_1
    //   126: aload_1
    //   127: astore #4
    //   129: aload_0
    //   130: getfield mStartDelay : J
    //   133: ldc2_w -1
    //   136: lcmp
    //   137: ifeq -> 191
    //   140: new java/lang/StringBuilder
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: astore #4
    //   149: aload #4
    //   151: aload_1
    //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: pop
    //   156: aload #4
    //   158: ldc_w 'dly('
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload #4
    //   167: aload_0
    //   168: getfield mStartDelay : J
    //   171: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload #4
    //   177: ldc_w ') '
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: aload #4
    //   186: invokevirtual toString : ()Ljava/lang/String;
    //   189: astore #4
    //   191: aload #4
    //   193: astore_1
    //   194: aload_0
    //   195: getfield mInterpolator : Landroid/animation/TimeInterpolator;
    //   198: ifnull -> 246
    //   201: new java/lang/StringBuilder
    //   204: dup
    //   205: invokespecial <init> : ()V
    //   208: astore_1
    //   209: aload_1
    //   210: aload #4
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: pop
    //   216: aload_1
    //   217: ldc_w 'interp('
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: pop
    //   224: aload_1
    //   225: aload_0
    //   226: getfield mInterpolator : Landroid/animation/TimeInterpolator;
    //   229: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload_1
    //   234: ldc_w ') '
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: pop
    //   241: aload_1
    //   242: invokevirtual toString : ()Ljava/lang/String;
    //   245: astore_1
    //   246: aload_0
    //   247: getfield mTargetIds : Ljava/util/ArrayList;
    //   250: invokevirtual size : ()I
    //   253: ifgt -> 269
    //   256: aload_1
    //   257: astore #4
    //   259: aload_0
    //   260: getfield mTargets : Ljava/util/ArrayList;
    //   263: invokevirtual size : ()I
    //   266: ifle -> 552
    //   269: new java/lang/StringBuilder
    //   272: dup
    //   273: invokespecial <init> : ()V
    //   276: astore #4
    //   278: aload #4
    //   280: aload_1
    //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   284: pop
    //   285: aload #4
    //   287: ldc_w 'tgts('
    //   290: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: pop
    //   294: aload #4
    //   296: invokevirtual toString : ()Ljava/lang/String;
    //   299: astore_1
    //   300: aload_0
    //   301: getfield mTargetIds : Ljava/util/ArrayList;
    //   304: invokevirtual size : ()I
    //   307: istore_2
    //   308: iconst_0
    //   309: istore_3
    //   310: aload_1
    //   311: astore #4
    //   313: iload_2
    //   314: ifle -> 412
    //   317: iconst_0
    //   318: istore_2
    //   319: aload_1
    //   320: astore #4
    //   322: iload_2
    //   323: aload_0
    //   324: getfield mTargetIds : Ljava/util/ArrayList;
    //   327: invokevirtual size : ()I
    //   330: if_icmpge -> 412
    //   333: aload_1
    //   334: astore #4
    //   336: iload_2
    //   337: ifle -> 372
    //   340: new java/lang/StringBuilder
    //   343: dup
    //   344: invokespecial <init> : ()V
    //   347: astore #4
    //   349: aload #4
    //   351: aload_1
    //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   355: pop
    //   356: aload #4
    //   358: ldc_w ', '
    //   361: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   364: pop
    //   365: aload #4
    //   367: invokevirtual toString : ()Ljava/lang/String;
    //   370: astore #4
    //   372: new java/lang/StringBuilder
    //   375: dup
    //   376: invokespecial <init> : ()V
    //   379: astore_1
    //   380: aload_1
    //   381: aload #4
    //   383: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   386: pop
    //   387: aload_1
    //   388: aload_0
    //   389: getfield mTargetIds : Ljava/util/ArrayList;
    //   392: iload_2
    //   393: invokevirtual get : (I)Ljava/lang/Object;
    //   396: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   399: pop
    //   400: aload_1
    //   401: invokevirtual toString : ()Ljava/lang/String;
    //   404: astore_1
    //   405: iload_2
    //   406: iconst_1
    //   407: iadd
    //   408: istore_2
    //   409: goto -> 319
    //   412: aload #4
    //   414: astore_1
    //   415: aload_0
    //   416: getfield mTargets : Ljava/util/ArrayList;
    //   419: invokevirtual size : ()I
    //   422: ifle -> 520
    //   425: iload_3
    //   426: istore_2
    //   427: aload #4
    //   429: astore_1
    //   430: iload_2
    //   431: aload_0
    //   432: getfield mTargets : Ljava/util/ArrayList;
    //   435: invokevirtual size : ()I
    //   438: if_icmpge -> 520
    //   441: aload #4
    //   443: astore_1
    //   444: iload_2
    //   445: ifle -> 476
    //   448: new java/lang/StringBuilder
    //   451: dup
    //   452: invokespecial <init> : ()V
    //   455: astore_1
    //   456: aload_1
    //   457: aload #4
    //   459: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   462: pop
    //   463: aload_1
    //   464: ldc_w ', '
    //   467: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   470: pop
    //   471: aload_1
    //   472: invokevirtual toString : ()Ljava/lang/String;
    //   475: astore_1
    //   476: new java/lang/StringBuilder
    //   479: dup
    //   480: invokespecial <init> : ()V
    //   483: astore #4
    //   485: aload #4
    //   487: aload_1
    //   488: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   491: pop
    //   492: aload #4
    //   494: aload_0
    //   495: getfield mTargets : Ljava/util/ArrayList;
    //   498: iload_2
    //   499: invokevirtual get : (I)Ljava/lang/Object;
    //   502: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   505: pop
    //   506: aload #4
    //   508: invokevirtual toString : ()Ljava/lang/String;
    //   511: astore #4
    //   513: iload_2
    //   514: iconst_1
    //   515: iadd
    //   516: istore_2
    //   517: goto -> 427
    //   520: new java/lang/StringBuilder
    //   523: dup
    //   524: invokespecial <init> : ()V
    //   527: astore #4
    //   529: aload #4
    //   531: aload_1
    //   532: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   535: pop
    //   536: aload #4
    //   538: ldc_w ')'
    //   541: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   544: pop
    //   545: aload #4
    //   547: invokevirtual toString : ()Ljava/lang/String;
    //   550: astore #4
    //   552: aload #4
    //   554: areturn
  }
  
  private static class AnimationInfo {
    String mName;
    
    Transition mTransition;
    
    TransitionValues mValues;
    
    View mView;
    
    WindowIdImpl mWindowId;
    
    AnimationInfo(View param1View, String param1String, Transition param1Transition, WindowIdImpl param1WindowIdImpl, TransitionValues param1TransitionValues) {
      this.mView = param1View;
      this.mName = param1String;
      this.mValues = param1TransitionValues;
      this.mWindowId = param1WindowIdImpl;
      this.mTransition = param1Transition;
    }
  }
  
  private static class ArrayListManager {
    static <T> ArrayList<T> add(ArrayList<T> param1ArrayList, T param1T) {
      ArrayList<T> arrayList = param1ArrayList;
      if (param1ArrayList == null)
        arrayList = new ArrayList<T>(); 
      if (!arrayList.contains(param1T))
        arrayList.add(param1T); 
      return arrayList;
    }
    
    static <T> ArrayList<T> remove(ArrayList<T> param1ArrayList, T param1T) {
      ArrayList<T> arrayList = param1ArrayList;
      if (param1ArrayList != null) {
        param1ArrayList.remove(param1T);
        arrayList = param1ArrayList;
        if (param1ArrayList.isEmpty())
          arrayList = null; 
      } 
      return arrayList;
    }
  }
  
  public static abstract class EpicenterCallback {
    public abstract Rect onGetEpicenter(@NonNull Transition param1Transition);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface MatchOrder {}
  
  public static interface TransitionListener {
    void onTransitionCancel(@NonNull Transition param1Transition);
    
    void onTransitionEnd(@NonNull Transition param1Transition);
    
    void onTransitionPause(@NonNull Transition param1Transition);
    
    void onTransitionResume(@NonNull Transition param1Transition);
    
    void onTransitionStart(@NonNull Transition param1Transition);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\transition\Transition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */