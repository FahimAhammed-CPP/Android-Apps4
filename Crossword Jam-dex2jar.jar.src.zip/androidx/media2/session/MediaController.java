package androidx.media2.session;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.Surface;
import androidx.annotation.GuardedBy;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Pair;
import androidx.media.AudioAttributesCompat;
import androidx.media2.common.MediaItem;
import androidx.media2.common.MediaMetadata;
import androidx.media2.common.Rating;
import androidx.media2.common.SessionPlayer;
import androidx.media2.common.SubtitleData;
import androidx.media2.common.VideoSize;
import androidx.versionedparcelable.VersionedParcelable;
import j.d.b.e.a.a;
import java.io.Closeable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;

public class MediaController implements Closeable {
  private static final String TAG = "MediaController";
  
  @GuardedBy("mLock")
  boolean mClosed;
  
  @GuardedBy("mLock")
  private final List<Pair<ControllerCallback, Executor>> mExtraControllerCallbacks = new ArrayList<Pair<ControllerCallback, Executor>>();
  
  @GuardedBy("mLock")
  MediaControllerImpl mImpl;
  
  final Object mLock = new Object();
  
  final ControllerCallback mPrimaryCallback;
  
  final Executor mPrimaryCallbackExecutor;
  
  Long mTimeDiff;
  
  MediaController(@NonNull Context paramContext, @NonNull MediaSessionCompat.Token paramToken, @Nullable Bundle paramBundle, @Nullable Executor paramExecutor, @Nullable ControllerCallback paramControllerCallback) {
    Objects.requireNonNull(paramContext, "context shouldn't be null");
    Objects.requireNonNull(paramToken, "token shouldn't be null");
    this.mPrimaryCallback = paramControllerCallback;
    this.mPrimaryCallbackExecutor = paramExecutor;
    SessionToken.createSessionToken(paramContext, paramToken, (SessionToken.OnSessionTokenCreatedListener)new a(this, paramContext, paramBundle));
  }
  
  MediaController(@NonNull Context paramContext, @NonNull SessionToken paramSessionToken, @Nullable Bundle paramBundle, @Nullable Executor paramExecutor, @Nullable ControllerCallback paramControllerCallback) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: new java/lang/Object
    //   7: dup
    //   8: invokespecial <init> : ()V
    //   11: astore #6
    //   13: aload_0
    //   14: aload #6
    //   16: putfield mLock : Ljava/lang/Object;
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mExtraControllerCallbacks : Ljava/util/List;
    //   30: aload_1
    //   31: ldc 'context shouldn't be null'
    //   33: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   36: pop
    //   37: aload_2
    //   38: ldc 'token shouldn't be null'
    //   40: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    //   43: pop
    //   44: aload_0
    //   45: aload #5
    //   47: putfield mPrimaryCallback : Landroidx/media2/session/MediaController$ControllerCallback;
    //   50: aload_0
    //   51: aload #4
    //   53: putfield mPrimaryCallbackExecutor : Ljava/util/concurrent/Executor;
    //   56: aload #6
    //   58: monitorenter
    //   59: aload_0
    //   60: aload_0
    //   61: aload_1
    //   62: aload_2
    //   63: aload_3
    //   64: invokevirtual createImpl : (Landroid/content/Context;Landroidx/media2/session/SessionToken;Landroid/os/Bundle;)Landroidx/media2/session/MediaController$MediaControllerImpl;
    //   67: putfield mImpl : Landroidx/media2/session/MediaController$MediaControllerImpl;
    //   70: aload #6
    //   72: monitorexit
    //   73: return
    //   74: astore_1
    //   75: aload #6
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   59	73	74	finally
    //   75	78	74	finally
  }
  
  private static a<SessionResult> createDisconnectedFuture() {
    return SessionResult.createFutureWithResult(-100);
  }
  
  @NonNull
  public a<SessionResult> addPlaylistItem(@IntRange(from = 0L) int paramInt, @NonNull String paramString) {
    if (paramInt >= 0) {
      if (!TextUtils.isEmpty(paramString))
        return isConnected() ? getImpl().addPlaylistItem(paramInt, paramString) : createDisconnectedFuture(); 
      throw new IllegalArgumentException("mediaId shouldn't be empty");
    } 
    throw new IllegalArgumentException("index shouldn't be negative");
  }
  
  @NonNull
  public a<SessionResult> adjustVolume(int paramInt1, int paramInt2) {
    return isConnected() ? getImpl().adjustVolume(paramInt1, paramInt2) : createDisconnectedFuture();
  }
  
  public void close() {
    try {
      synchronized (this.mLock) {
        if (this.mClosed)
          return; 
        this.mClosed = true;
        MediaControllerImpl mediaControllerImpl = this.mImpl;
        if (mediaControllerImpl != null) {
          mediaControllerImpl.close();
          return;
        } 
      } 
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  MediaControllerImpl createImpl(@NonNull Context paramContext, @NonNull SessionToken paramSessionToken, @Nullable Bundle paramBundle) {
    return (MediaControllerImpl)(paramSessionToken.isLegacySession() ? new MediaControllerImplLegacy(paramContext, this, paramSessionToken) : new MediaControllerImplBase(paramContext, this, paramSessionToken, paramBundle));
  }
  
  @NonNull
  public a<SessionResult> deselectTrack(@NonNull SessionPlayer.TrackInfo paramTrackInfo) {
    Objects.requireNonNull(paramTrackInfo, "TrackInfo shouldn't be null");
    return isConnected() ? getImpl().deselectTrack(paramTrackInfo) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> fastForward() {
    return isConnected() ? getImpl().fastForward() : createDisconnectedFuture();
  }
  
  @Nullable
  public SessionCommandGroup getAllowedCommands() {
    return !isConnected() ? null : getImpl().getAllowedCommands();
  }
  
  public long getBufferedPosition() {
    return isConnected() ? getImpl().getBufferedPosition() : Long.MIN_VALUE;
  }
  
  public int getBufferingState() {
    return isConnected() ? getImpl().getBufferingState() : 0;
  }
  
  @Nullable
  public SessionToken getConnectedToken() {
    return isConnected() ? getImpl().getConnectedToken() : null;
  }
  
  @Nullable
  public MediaItem getCurrentMediaItem() {
    return isConnected() ? getImpl().getCurrentMediaItem() : null;
  }
  
  public int getCurrentMediaItemIndex() {
    return isConnected() ? getImpl().getCurrentMediaItemIndex() : -1;
  }
  
  public long getCurrentPosition() {
    return isConnected() ? getImpl().getCurrentPosition() : Long.MIN_VALUE;
  }
  
  public long getDuration() {
    return isConnected() ? getImpl().getDuration() : Long.MIN_VALUE;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public List<Pair<ControllerCallback, Executor>> getExtraControllerCallbacks() {
    synchronized (this.mLock) {
      return new ArrayList<Pair<ControllerCallback, Executor>>(this.mExtraControllerCallbacks);
    } 
  }
  
  MediaControllerImpl getImpl() {
    synchronized (this.mLock) {
      return this.mImpl;
    } 
  }
  
  public int getNextMediaItemIndex() {
    return isConnected() ? getImpl().getNextMediaItemIndex() : -1;
  }
  
  @Nullable
  public PlaybackInfo getPlaybackInfo() {
    return isConnected() ? getImpl().getPlaybackInfo() : null;
  }
  
  public float getPlaybackSpeed() {
    return isConnected() ? getImpl().getPlaybackSpeed() : 0.0F;
  }
  
  public int getPlayerState() {
    return isConnected() ? getImpl().getPlayerState() : 0;
  }
  
  @Nullable
  public List<MediaItem> getPlaylist() {
    return isConnected() ? getImpl().getPlaylist() : null;
  }
  
  @Nullable
  public MediaMetadata getPlaylistMetadata() {
    return isConnected() ? getImpl().getPlaylistMetadata() : null;
  }
  
  public int getPreviousMediaItemIndex() {
    return isConnected() ? getImpl().getPreviousMediaItemIndex() : -1;
  }
  
  public int getRepeatMode() {
    return isConnected() ? getImpl().getRepeatMode() : 0;
  }
  
  @Nullable
  public SessionPlayer.TrackInfo getSelectedTrack(int paramInt) {
    return isConnected() ? getImpl().getSelectedTrack(paramInt) : null;
  }
  
  @Nullable
  public PendingIntent getSessionActivity() {
    return isConnected() ? getImpl().getSessionActivity() : null;
  }
  
  public int getShuffleMode() {
    return isConnected() ? getImpl().getShuffleMode() : 0;
  }
  
  @NonNull
  public List<SessionPlayer.TrackInfo> getTracks() {
    return isConnected() ? getImpl().getTracks() : Collections.emptyList();
  }
  
  @NonNull
  public VideoSize getVideoSize() {
    return isConnected() ? getImpl().getVideoSize() : new VideoSize(0, 0);
  }
  
  public boolean isConnected() {
    MediaControllerImpl mediaControllerImpl = getImpl();
    return (mediaControllerImpl != null && mediaControllerImpl.isConnected());
  }
  
  @NonNull
  public a<SessionResult> movePlaylistItem(@IntRange(from = 0L) int paramInt1, @IntRange(from = 0L) int paramInt2) {
    if (paramInt1 >= 0 && paramInt2 >= 0)
      return isConnected() ? getImpl().movePlaylistItem(paramInt1, paramInt2) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("indexes shouldn't be negative");
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void notifyAllControllerCallbacks(@NonNull final ControllerCallbackRunnable callbackRunnable) {
    notifyPrimaryControllerCallback(callbackRunnable);
    for (Pair<ControllerCallback, Executor> pair : getExtraControllerCallbacks()) {
      final ControllerCallback callback = (ControllerCallback)pair.first;
      Executor executor = (Executor)pair.second;
      if (controllerCallback == null) {
        Log.e("MediaController", "notifyAllControllerCallbacks: mExtraControllerCallbacks contains a null ControllerCallback! Ignoring.");
        continue;
      } 
      if (executor == null) {
        Log.e("MediaController", "notifyAllControllerCallbacks: mExtraControllerCallbacks contains a null Executor! Ignoring.");
        continue;
      } 
      executor.execute(new Runnable() {
            public void run() {
              callbackRunnable.run(callback);
            }
          });
    } 
  }
  
  void notifyPrimaryControllerCallback(@NonNull final ControllerCallbackRunnable callbackRunnable) {
    if (this.mPrimaryCallback != null) {
      Executor executor = this.mPrimaryCallbackExecutor;
      if (executor != null)
        executor.execute(new Runnable() {
              public void run() {
                callbackRunnable.run(MediaController.this.mPrimaryCallback);
              }
            }); 
    } 
  }
  
  @NonNull
  public a<SessionResult> pause() {
    return isConnected() ? getImpl().pause() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> play() {
    return isConnected() ? getImpl().play() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> prepare() {
    return isConnected() ? getImpl().prepare() : createDisconnectedFuture();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void registerExtraCallback(@NonNull Executor paramExecutor, @NonNull ControllerCallback paramControllerCallback) {
    Objects.requireNonNull(paramExecutor, "executor shouldn't be null");
    Objects.requireNonNull(paramControllerCallback, "callback shouldn't be null");
    boolean bool = false;
    synchronized (this.mLock) {
      boolean bool1;
      Iterator<Pair<ControllerCallback, Executor>> iterator = this.mExtraControllerCallbacks.iterator();
      while (true) {
        bool1 = bool;
        if (iterator.hasNext()) {
          if (((Pair)iterator.next()).first == paramControllerCallback) {
            bool1 = true;
            break;
          } 
          continue;
        } 
        break;
      } 
      if (!bool1)
        this.mExtraControllerCallbacks.add(new Pair(paramControllerCallback, paramExecutor)); 
      if (bool1)
        Log.w("MediaController", "registerExtraCallback: the callback already exists"); 
      return;
    } 
  }
  
  @NonNull
  public a<SessionResult> removePlaylistItem(@IntRange(from = 0L) int paramInt) {
    if (paramInt >= 0)
      return isConnected() ? getImpl().removePlaylistItem(paramInt) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("index shouldn't be negative");
  }
  
  @NonNull
  public a<SessionResult> replacePlaylistItem(@IntRange(from = 0L) int paramInt, @NonNull String paramString) {
    if (paramInt >= 0) {
      if (!TextUtils.isEmpty(paramString))
        return isConnected() ? getImpl().replacePlaylistItem(paramInt, paramString) : createDisconnectedFuture(); 
      throw new IllegalArgumentException("mediaId shouldn't be empty");
    } 
    throw new IllegalArgumentException("index shouldn't be negative");
  }
  
  @NonNull
  public a<SessionResult> rewind() {
    return isConnected() ? getImpl().rewind() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> seekTo(long paramLong) {
    return isConnected() ? getImpl().seekTo(paramLong) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> selectTrack(@NonNull SessionPlayer.TrackInfo paramTrackInfo) {
    Objects.requireNonNull(paramTrackInfo, "TrackInfo shouldn't be null");
    return isConnected() ? getImpl().selectTrack(paramTrackInfo) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> sendCustomCommand(@NonNull SessionCommand paramSessionCommand, @Nullable Bundle paramBundle) {
    Objects.requireNonNull(paramSessionCommand, "command shouldn't be null");
    if (paramSessionCommand.getCommandCode() == 0)
      return isConnected() ? getImpl().sendCustomCommand(paramSessionCommand, paramBundle) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("command should be a custom command");
  }
  
  @NonNull
  public a<SessionResult> setMediaItem(@NonNull String paramString) {
    if (!TextUtils.isEmpty(paramString))
      return isConnected() ? getImpl().setMediaItem(paramString) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("mediaId shouldn't be empty");
  }
  
  @NonNull
  public a<SessionResult> setMediaUri(@NonNull Uri paramUri, @Nullable Bundle paramBundle) {
    Objects.requireNonNull(paramUri, "mediaUri shouldn't be null");
    return isConnected() ? getImpl().setMediaUri(paramUri, paramBundle) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> setPlaybackSpeed(float paramFloat) {
    if (paramFloat != 0.0F)
      return isConnected() ? getImpl().setPlaybackSpeed(paramFloat) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("speed must not be zero");
  }
  
  @NonNull
  public a<SessionResult> setPlaylist(@NonNull List<String> paramList, @Nullable MediaMetadata paramMediaMetadata) {
    StringBuilder stringBuilder;
    Objects.requireNonNull(paramList, "list shouldn't be null");
    int i = 0;
    while (i < paramList.size()) {
      if (!TextUtils.isEmpty(paramList.get(i))) {
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("list shouldn't contain empty id, index=");
      stringBuilder.append(i);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return isConnected() ? getImpl().setPlaylist((List<String>)stringBuilder, paramMediaMetadata) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> setRating(@NonNull String paramString, @NonNull Rating paramRating) {
    Objects.requireNonNull(paramString, "mediaId shouldn't be null");
    if (!TextUtils.isEmpty(paramString)) {
      Objects.requireNonNull(paramRating, "rating shouldn't be null");
      return isConnected() ? getImpl().setRating(paramString, paramRating) : createDisconnectedFuture();
    } 
    throw new IllegalArgumentException("mediaId shouldn't be empty");
  }
  
  @NonNull
  public a<SessionResult> setRepeatMode(int paramInt) {
    return isConnected() ? getImpl().setRepeatMode(paramInt) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> setShuffleMode(int paramInt) {
    return isConnected() ? getImpl().setShuffleMode(paramInt) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> setSurface(@Nullable Surface paramSurface) {
    return isConnected() ? getImpl().setSurface(paramSurface) : createDisconnectedFuture();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void setTimeDiff(Long paramLong) {
    this.mTimeDiff = paramLong;
  }
  
  @NonNull
  public a<SessionResult> setVolumeTo(int paramInt1, int paramInt2) {
    return isConnected() ? getImpl().setVolumeTo(paramInt1, paramInt2) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> skipBackward() {
    return isConnected() ? getImpl().skipBackward() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> skipForward() {
    return isConnected() ? getImpl().skipForward() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> skipToNextPlaylistItem() {
    return isConnected() ? getImpl().skipToNextItem() : createDisconnectedFuture();
  }
  
  @NonNull
  public a<SessionResult> skipToPlaylistItem(@IntRange(from = 0L) int paramInt) {
    if (paramInt >= 0)
      return isConnected() ? getImpl().skipToPlaylistItem(paramInt) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("index shouldn't be negative");
  }
  
  @NonNull
  public a<SessionResult> skipToPreviousPlaylistItem() {
    return isConnected() ? getImpl().skipToPreviousItem() : createDisconnectedFuture();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void unregisterExtraCallback(@NonNull ControllerCallback paramControllerCallback) {
    Objects.requireNonNull(paramControllerCallback, "callback shouldn't be null");
    boolean bool = false;
    synchronized (this.mLock) {
      int i = this.mExtraControllerCallbacks.size() - 1;
      while (true) {
        boolean bool1 = bool;
        if (i >= 0)
          if (((Pair)this.mExtraControllerCallbacks.get(i)).first == paramControllerCallback) {
            this.mExtraControllerCallbacks.remove(i);
            bool1 = true;
          } else {
            i--;
            continue;
          }  
        if (!bool1)
          Log.w("MediaController", "unregisterExtraCallback: no such callback found"); 
        return;
      } 
    } 
  }
  
  @NonNull
  public a<SessionResult> updatePlaylistMetadata(@Nullable MediaMetadata paramMediaMetadata) {
    return isConnected() ? getImpl().updatePlaylistMetadata(paramMediaMetadata) : createDisconnectedFuture();
  }
  
  public static final class Builder extends BuilderBase<MediaController, Builder, ControllerCallback> {
    public Builder(@NonNull Context param1Context) {
      super(param1Context);
    }
    
    @NonNull
    public MediaController build() {
      SessionToken sessionToken = this.mToken;
      if (sessionToken != null || this.mCompatToken != null)
        return (sessionToken != null) ? new MediaController(this.mContext, sessionToken, this.mConnectionHints, this.mCallbackExecutor, this.mCallback) : new MediaController(this.mContext, this.mCompatToken, this.mConnectionHints, this.mCallbackExecutor, this.mCallback); 
      throw new IllegalArgumentException("token and compat token shouldn't be both null");
    }
    
    @NonNull
    public Builder setConnectionHints(@NonNull Bundle param1Bundle) {
      return super.setConnectionHints(param1Bundle);
    }
    
    @NonNull
    public Builder setControllerCallback(@NonNull Executor param1Executor, @NonNull MediaController.ControllerCallback param1ControllerCallback) {
      return super.setControllerCallback(param1Executor, param1ControllerCallback);
    }
    
    @NonNull
    public Builder setSessionCompatToken(@NonNull MediaSessionCompat.Token param1Token) {
      return super.setSessionCompatToken(param1Token);
    }
    
    @NonNull
    public Builder setSessionToken(@NonNull SessionToken param1SessionToken) {
      return super.setSessionToken(param1SessionToken);
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  static abstract class BuilderBase<T extends MediaController, U extends BuilderBase<T, U, C>, C extends ControllerCallback> {
    MediaController.ControllerCallback mCallback;
    
    Executor mCallbackExecutor;
    
    MediaSessionCompat.Token mCompatToken;
    
    Bundle mConnectionHints;
    
    final Context mContext;
    
    SessionToken mToken;
    
    BuilderBase(@NonNull Context param1Context) {
      Objects.requireNonNull(param1Context, "context shouldn't be null");
      this.mContext = param1Context;
    }
    
    @NonNull
    abstract T build();
    
    @NonNull
    public U setConnectionHints(@NonNull Bundle param1Bundle) {
      Objects.requireNonNull(param1Bundle, "connectionHints shouldn't be null");
      if (!MediaUtils.doesBundleHaveCustomParcelable(param1Bundle)) {
        this.mConnectionHints = new Bundle(param1Bundle);
        return (U)this;
      } 
      throw new IllegalArgumentException("connectionHints shouldn't contain any custom parcelables");
    }
    
    @NonNull
    U setControllerCallback(@NonNull Executor param1Executor, @NonNull C param1C) {
      Objects.requireNonNull(param1Executor, "executor shouldn't be null");
      Objects.requireNonNull(param1C, "callback shouldn't be null");
      this.mCallbackExecutor = param1Executor;
      this.mCallback = (MediaController.ControllerCallback)param1C;
      return (U)this;
    }
    
    @NonNull
    U setSessionCompatToken(@NonNull MediaSessionCompat.Token param1Token) {
      Objects.requireNonNull(param1Token, "compatToken shouldn't be null");
      this.mCompatToken = param1Token;
      this.mToken = null;
      return (U)this;
    }
    
    @NonNull
    U setSessionToken(@NonNull SessionToken param1SessionToken) {
      Objects.requireNonNull(param1SessionToken, "token shouldn't be null");
      this.mToken = param1SessionToken;
      this.mCompatToken = null;
      return (U)this;
    }
  }
  
  public static abstract class ControllerCallback {
    public void onAllowedCommandsChanged(@NonNull MediaController param1MediaController, @NonNull SessionCommandGroup param1SessionCommandGroup) {}
    
    public void onBufferingStateChanged(@NonNull MediaController param1MediaController, @NonNull MediaItem param1MediaItem, int param1Int) {}
    
    public void onConnected(@NonNull MediaController param1MediaController, @NonNull SessionCommandGroup param1SessionCommandGroup) {}
    
    public void onCurrentMediaItemChanged(@NonNull MediaController param1MediaController, @Nullable MediaItem param1MediaItem) {}
    
    @NonNull
    public SessionResult onCustomCommand(@NonNull MediaController param1MediaController, @NonNull SessionCommand param1SessionCommand, @Nullable Bundle param1Bundle) {
      return new SessionResult(-6);
    }
    
    public void onDisconnected(@NonNull MediaController param1MediaController) {}
    
    public void onPlaybackCompleted(@NonNull MediaController param1MediaController) {}
    
    public void onPlaybackInfoChanged(@NonNull MediaController param1MediaController, @NonNull MediaController.PlaybackInfo param1PlaybackInfo) {}
    
    public void onPlaybackSpeedChanged(@NonNull MediaController param1MediaController, float param1Float) {}
    
    public void onPlayerStateChanged(@NonNull MediaController param1MediaController, int param1Int) {}
    
    public void onPlaylistChanged(@NonNull MediaController param1MediaController, @Nullable List<MediaItem> param1List, @Nullable MediaMetadata param1MediaMetadata) {}
    
    public void onPlaylistMetadataChanged(@NonNull MediaController param1MediaController, @Nullable MediaMetadata param1MediaMetadata) {}
    
    public void onRepeatModeChanged(@NonNull MediaController param1MediaController, int param1Int) {}
    
    public void onSeekCompleted(@NonNull MediaController param1MediaController, long param1Long) {}
    
    public int onSetCustomLayout(@NonNull MediaController param1MediaController, @NonNull List<MediaSession.CommandButton> param1List) {
      return -6;
    }
    
    public void onShuffleModeChanged(@NonNull MediaController param1MediaController, int param1Int) {}
    
    public void onSubtitleData(@NonNull MediaController param1MediaController, @NonNull MediaItem param1MediaItem, @NonNull SessionPlayer.TrackInfo param1TrackInfo, @NonNull SubtitleData param1SubtitleData) {}
    
    public void onTrackDeselected(@NonNull MediaController param1MediaController, @NonNull SessionPlayer.TrackInfo param1TrackInfo) {}
    
    public void onTrackSelected(@NonNull MediaController param1MediaController, @NonNull SessionPlayer.TrackInfo param1TrackInfo) {}
    
    public void onTracksChanged(@NonNull MediaController param1MediaController, @NonNull List<SessionPlayer.TrackInfo> param1List) {}
    
    @Deprecated
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public void onVideoSizeChanged(@NonNull MediaController param1MediaController, @NonNull MediaItem param1MediaItem, @NonNull VideoSize param1VideoSize) {}
    
    public void onVideoSizeChanged(@NonNull MediaController param1MediaController, @NonNull VideoSize param1VideoSize) {}
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static interface ControllerCallbackRunnable {
    void run(@NonNull MediaController.ControllerCallback param1ControllerCallback);
  }
  
  static interface MediaControllerImpl extends Closeable {
    a<SessionResult> addPlaylistItem(int param1Int, @NonNull String param1String);
    
    a<SessionResult> adjustVolume(int param1Int1, int param1Int2);
    
    a<SessionResult> deselectTrack(SessionPlayer.TrackInfo param1TrackInfo);
    
    a<SessionResult> fastForward();
    
    @Nullable
    SessionCommandGroup getAllowedCommands();
    
    @Nullable
    MediaBrowserCompat getBrowserCompat();
    
    long getBufferedPosition();
    
    int getBufferingState();
    
    @Nullable
    SessionToken getConnectedToken();
    
    @NonNull
    Context getContext();
    
    MediaItem getCurrentMediaItem();
    
    int getCurrentMediaItemIndex();
    
    long getCurrentPosition();
    
    long getDuration();
    
    int getNextMediaItemIndex();
    
    @Nullable
    MediaController.PlaybackInfo getPlaybackInfo();
    
    float getPlaybackSpeed();
    
    int getPlayerState();
    
    @Nullable
    List<MediaItem> getPlaylist();
    
    @Nullable
    MediaMetadata getPlaylistMetadata();
    
    int getPreviousMediaItemIndex();
    
    int getRepeatMode();
    
    @Nullable
    SessionPlayer.TrackInfo getSelectedTrack(int param1Int);
    
    @Nullable
    PendingIntent getSessionActivity();
    
    int getShuffleMode();
    
    @NonNull
    List<SessionPlayer.TrackInfo> getTracks();
    
    @NonNull
    VideoSize getVideoSize();
    
    boolean isConnected();
    
    a<SessionResult> movePlaylistItem(int param1Int1, int param1Int2);
    
    a<SessionResult> pause();
    
    a<SessionResult> play();
    
    a<SessionResult> prepare();
    
    a<SessionResult> removePlaylistItem(int param1Int);
    
    a<SessionResult> replacePlaylistItem(int param1Int, @NonNull String param1String);
    
    a<SessionResult> rewind();
    
    a<SessionResult> seekTo(long param1Long);
    
    a<SessionResult> selectTrack(SessionPlayer.TrackInfo param1TrackInfo);
    
    a<SessionResult> sendCustomCommand(@NonNull SessionCommand param1SessionCommand, @Nullable Bundle param1Bundle);
    
    a<SessionResult> setMediaItem(@NonNull String param1String);
    
    a<SessionResult> setMediaUri(@NonNull Uri param1Uri, @Nullable Bundle param1Bundle);
    
    a<SessionResult> setPlaybackSpeed(float param1Float);
    
    a<SessionResult> setPlaylist(@NonNull List<String> param1List, @Nullable MediaMetadata param1MediaMetadata);
    
    a<SessionResult> setRating(@NonNull String param1String, @NonNull Rating param1Rating);
    
    a<SessionResult> setRepeatMode(int param1Int);
    
    a<SessionResult> setShuffleMode(int param1Int);
    
    a<SessionResult> setSurface(@Nullable Surface param1Surface);
    
    a<SessionResult> setVolumeTo(int param1Int1, int param1Int2);
    
    a<SessionResult> skipBackward();
    
    a<SessionResult> skipForward();
    
    a<SessionResult> skipToNextItem();
    
    a<SessionResult> skipToPlaylistItem(int param1Int);
    
    a<SessionResult> skipToPreviousItem();
    
    a<SessionResult> updatePlaylistMetadata(@Nullable MediaMetadata param1MediaMetadata);
  }
  
  public static final class PlaybackInfo implements VersionedParcelable {
    public static final int PLAYBACK_TYPE_LOCAL = 1;
    
    public static final int PLAYBACK_TYPE_REMOTE = 2;
    
    AudioAttributesCompat mAudioAttrsCompat;
    
    int mControlType;
    
    int mCurrentVolume;
    
    int mMaxVolume;
    
    int mPlaybackType;
    
    PlaybackInfo() {}
    
    PlaybackInfo(int param1Int1, AudioAttributesCompat param1AudioAttributesCompat, int param1Int2, int param1Int3, int param1Int4) {
      this.mPlaybackType = param1Int1;
      this.mAudioAttrsCompat = param1AudioAttributesCompat;
      this.mControlType = param1Int2;
      this.mMaxVolume = param1Int3;
      this.mCurrentVolume = param1Int4;
    }
    
    static PlaybackInfo createPlaybackInfo(int param1Int1, AudioAttributesCompat param1AudioAttributesCompat, int param1Int2, int param1Int3, int param1Int4) {
      return new PlaybackInfo(param1Int1, param1AudioAttributesCompat, param1Int2, param1Int3, param1Int4);
    }
    
    public boolean equals(@Nullable Object param1Object) {
      boolean bool = param1Object instanceof PlaybackInfo;
      boolean bool1 = false;
      if (!bool)
        return false; 
      param1Object = param1Object;
      bool = bool1;
      if (this.mPlaybackType == ((PlaybackInfo)param1Object).mPlaybackType) {
        bool = bool1;
        if (this.mControlType == ((PlaybackInfo)param1Object).mControlType) {
          bool = bool1;
          if (this.mMaxVolume == ((PlaybackInfo)param1Object).mMaxVolume) {
            bool = bool1;
            if (this.mCurrentVolume == ((PlaybackInfo)param1Object).mCurrentVolume) {
              bool = bool1;
              if (ObjectsCompat.equals(this.mAudioAttrsCompat, ((PlaybackInfo)param1Object).mAudioAttrsCompat))
                bool = true; 
            } 
          } 
        } 
      } 
      return bool;
    }
    
    @Nullable
    public AudioAttributesCompat getAudioAttributes() {
      return this.mAudioAttrsCompat;
    }
    
    public int getControlType() {
      return this.mControlType;
    }
    
    public int getCurrentVolume() {
      return this.mCurrentVolume;
    }
    
    public int getMaxVolume() {
      return this.mMaxVolume;
    }
    
    public int getPlaybackType() {
      return this.mPlaybackType;
    }
    
    public int hashCode() {
      return ObjectsCompat.hash(new Object[] { Integer.valueOf(this.mPlaybackType), Integer.valueOf(this.mControlType), Integer.valueOf(this.mMaxVolume), Integer.valueOf(this.mCurrentVolume), this.mAudioAttrsCompat });
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface VolumeDirection {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface VolumeFlags {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\MediaController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */