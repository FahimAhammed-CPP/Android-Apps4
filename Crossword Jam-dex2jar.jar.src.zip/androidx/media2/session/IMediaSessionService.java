package androidx.media2.session;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import androidx.versionedparcelable.ParcelImpl;

public interface IMediaSessionService extends IInterface {
  void connect(IMediaController paramIMediaController, ParcelImpl paramParcelImpl) throws RemoteException;
  
  public static class Default implements IMediaSessionService {
    public IBinder asBinder() {
      return null;
    }
    
    public void connect(IMediaController param1IMediaController, ParcelImpl param1ParcelImpl) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IMediaSessionService {
    private static final String DESCRIPTOR = "androidx.media2.session.IMediaSessionService";
    
    static final int TRANSACTION_connect = 1;
    
    public Stub() {
      attachInterface(this, "androidx.media2.session.IMediaSessionService");
    }
    
    public static IMediaSessionService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.media2.session.IMediaSessionService");
      return (iInterface != null && iInterface instanceof IMediaSessionService) ? (IMediaSessionService)iInterface : new Proxy(param1IBinder);
    }
    
    public static IMediaSessionService getDefaultImpl() {
      return Proxy.sDefaultImpl;
    }
    
    public static boolean setDefaultImpl(IMediaSessionService param1IMediaSessionService) {
      if (Proxy.sDefaultImpl == null) {
        if (param1IMediaSessionService != null) {
          Proxy.sDefaultImpl = param1IMediaSessionService;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 1598968902)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Parcel2.writeString("androidx.media2.session.IMediaSessionService");
        return true;
      } 
      param1Parcel1.enforceInterface("androidx.media2.session.IMediaSessionService");
      IMediaController iMediaController = IMediaController.Stub.asInterface(param1Parcel1.readStrongBinder());
      if (param1Parcel1.readInt() != 0) {
        ParcelImpl parcelImpl = (ParcelImpl)ParcelImpl.CREATOR.createFromParcel(param1Parcel1);
      } else {
        param1Parcel1 = null;
      } 
      connect(iMediaController, (ParcelImpl)param1Parcel1);
      return true;
    }
    
    private static class Proxy implements IMediaSessionService {
      public static IMediaSessionService sDefaultImpl;
      
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void connect(IMediaController param2IMediaController, ParcelImpl param2ParcelImpl) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel.writeInterfaceToken("androidx.media2.session.IMediaSessionService");
          if (param2IMediaController != null) {
            iBinder = param2IMediaController.asBinder();
          } else {
            iBinder = null;
          } 
          parcel.writeStrongBinder(iBinder);
          if (param2ParcelImpl != null) {
            parcel.writeInt(1);
            param2ParcelImpl.writeToParcel(parcel, 0);
          } else {
            parcel.writeInt(0);
          } 
          if (!this.mRemote.transact(1, parcel, null, 1) && IMediaSessionService.Stub.getDefaultImpl() != null) {
            IMediaSessionService.Stub.getDefaultImpl().connect(param2IMediaController, param2ParcelImpl);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "androidx.media2.session.IMediaSessionService";
      }
    }
  }
  
  private static class Proxy implements IMediaSessionService {
    public static IMediaSessionService sDefaultImpl;
    
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void connect(IMediaController param1IMediaController, ParcelImpl param1ParcelImpl) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel.writeInterfaceToken("androidx.media2.session.IMediaSessionService");
        if (param1IMediaController != null) {
          iBinder = param1IMediaController.asBinder();
        } else {
          iBinder = null;
        } 
        parcel.writeStrongBinder(iBinder);
        if (param1ParcelImpl != null) {
          parcel.writeInt(1);
          param1ParcelImpl.writeToParcel(parcel, 0);
        } else {
          parcel.writeInt(0);
        } 
        if (!this.mRemote.transact(1, parcel, null, 1) && IMediaSessionService.Stub.getDefaultImpl() != null) {
          IMediaSessionService.Stub.getDefaultImpl().connect(param1IMediaController, param1ParcelImpl);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "androidx.media2.session.IMediaSessionService";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\IMediaSessionService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */