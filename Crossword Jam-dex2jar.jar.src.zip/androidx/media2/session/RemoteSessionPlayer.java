package androidx.media2.session;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.media2.common.SessionPlayer;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.concurrent.Future;

public abstract class RemoteSessionPlayer extends SessionPlayer {
  public static final int VOLUME_CONTROL_ABSOLUTE = 2;
  
  public static final int VOLUME_CONTROL_FIXED = 0;
  
  public static final int VOLUME_CONTROL_RELATIVE = 1;
  
  @NonNull
  public abstract Future<SessionPlayer.PlayerResult> adjustVolume(int paramInt);
  
  public abstract int getMaxVolume();
  
  public abstract int getVolume();
  
  public abstract int getVolumeControlType();
  
  @NonNull
  public abstract Future<SessionPlayer.PlayerResult> setVolume(int paramInt);
  
  public static class Callback extends SessionPlayer.PlayerCallback {
    public void onVolumeChanged(@NonNull RemoteSessionPlayer param1RemoteSessionPlayer, int param1Int) {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface VolumeControlType {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\RemoteSessionPlayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */