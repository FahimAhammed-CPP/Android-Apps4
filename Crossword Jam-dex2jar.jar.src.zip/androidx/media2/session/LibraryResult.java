package androidx.media2.session;

import android.os.SystemClock;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.media2.common.MediaItem;
import androidx.media2.common.ParcelImplListSlice;
import androidx.versionedparcelable.CustomVersionedParcelable;
import j.d.b.e.a.a;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

public class LibraryResult extends CustomVersionedParcelable implements RemoteResult {
  long mCompletionTime;
  
  MediaItem mItem;
  
  List<MediaItem> mItemList;
  
  ParcelImplListSlice mItemListSlice;
  
  MediaLibraryService.LibraryParams mParams;
  
  MediaItem mParcelableItem;
  
  int mResultCode;
  
  LibraryResult() {}
  
  public LibraryResult(int paramInt) {
    this(paramInt, null, null, null);
  }
  
  public LibraryResult(int paramInt, @Nullable MediaItem paramMediaItem, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    this(paramInt, paramMediaItem, null, paramLibraryParams);
  }
  
  private LibraryResult(int paramInt, @Nullable MediaItem paramMediaItem, @Nullable List<MediaItem> paramList, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    this.mResultCode = paramInt;
    this.mCompletionTime = SystemClock.elapsedRealtime();
    this.mItem = paramMediaItem;
    this.mItemList = paramList;
    this.mParams = paramLibraryParams;
  }
  
  public LibraryResult(int paramInt, @Nullable List<MediaItem> paramList, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    this(paramInt, null, paramList, paramLibraryParams);
  }
  
  static a<LibraryResult> createFutureWithResult(int paramInt) {
    ResolvableFuture resolvableFuture = ResolvableFuture.create();
    resolvableFuture.set(new LibraryResult(paramInt));
    return (a<LibraryResult>)resolvableFuture;
  }
  
  public long getCompletionTime() {
    return this.mCompletionTime;
  }
  
  @Nullable
  public MediaLibraryService.LibraryParams getLibraryParams() {
    return this.mParams;
  }
  
  @Nullable
  public MediaItem getMediaItem() {
    return this.mItem;
  }
  
  @Nullable
  public List<MediaItem> getMediaItems() {
    return this.mItemList;
  }
  
  public int getResultCode() {
    return this.mResultCode;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void onPostParceling() {
    this.mItem = this.mParcelableItem;
    this.mItemList = MediaUtils.convertParcelImplListSliceToMediaItemList(this.mItemListSlice);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void onPreParceling(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mItem : Landroidx/media2/common/MediaItem;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 39
    //   9: aload_2
    //   10: monitorenter
    //   11: aload_0
    //   12: getfield mParcelableItem : Landroidx/media2/common/MediaItem;
    //   15: ifnonnull -> 29
    //   18: aload_0
    //   19: aload_0
    //   20: getfield mItem : Landroidx/media2/common/MediaItem;
    //   23: invokestatic upcastForPreparceling : (Landroidx/media2/common/MediaItem;)Landroidx/media2/common/MediaItem;
    //   26: putfield mParcelableItem : Landroidx/media2/common/MediaItem;
    //   29: aload_2
    //   30: monitorexit
    //   31: goto -> 39
    //   34: astore_3
    //   35: aload_2
    //   36: monitorexit
    //   37: aload_3
    //   38: athrow
    //   39: aload_0
    //   40: getfield mItemList : Ljava/util/List;
    //   43: astore_2
    //   44: aload_2
    //   45: ifnull -> 76
    //   48: aload_2
    //   49: monitorenter
    //   50: aload_0
    //   51: getfield mItemListSlice : Landroidx/media2/common/ParcelImplListSlice;
    //   54: ifnonnull -> 68
    //   57: aload_0
    //   58: aload_0
    //   59: getfield mItemList : Ljava/util/List;
    //   62: invokestatic convertMediaItemListToParcelImplListSlice : (Ljava/util/List;)Landroidx/media2/common/ParcelImplListSlice;
    //   65: putfield mItemListSlice : Landroidx/media2/common/ParcelImplListSlice;
    //   68: aload_2
    //   69: monitorexit
    //   70: return
    //   71: astore_3
    //   72: aload_2
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    //   76: return
    // Exception table:
    //   from	to	target	type
    //   11	29	34	finally
    //   29	31	34	finally
    //   35	37	34	finally
    //   50	68	71	finally
    //   68	70	71	finally
    //   72	74	71	finally
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface ResultCode {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\LibraryResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */