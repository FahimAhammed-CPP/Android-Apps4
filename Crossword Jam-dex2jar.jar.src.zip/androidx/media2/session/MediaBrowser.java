package androidx.media2.session;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import j.d.b.e.a.a;
import java.util.concurrent.Executor;

public class MediaBrowser extends MediaController {
  static final boolean DEBUG = Log.isLoggable("MediaBrowser", 3);
  
  static final String TAG = "MediaBrowser";
  
  MediaBrowser(@NonNull Context paramContext, @NonNull MediaSessionCompat.Token paramToken, @Nullable Bundle paramBundle, @Nullable Executor paramExecutor, @Nullable BrowserCallback paramBrowserCallback) {
    super(paramContext, paramToken, paramBundle, paramExecutor, paramBrowserCallback);
  }
  
  MediaBrowser(@NonNull Context paramContext, @NonNull SessionToken paramSessionToken, @Nullable Bundle paramBundle, @Nullable Executor paramExecutor, @Nullable BrowserCallback paramBrowserCallback) {
    super(paramContext, paramSessionToken, paramBundle, paramExecutor, paramBrowserCallback);
  }
  
  private static a<LibraryResult> createDisconnectedFuture() {
    return LibraryResult.createFutureWithResult(-100);
  }
  
  MediaBrowserImpl createImpl(@NonNull Context paramContext, @NonNull SessionToken paramSessionToken, @Nullable Bundle paramBundle) {
    return (MediaBrowserImpl)(paramSessionToken.isLegacySession() ? new MediaBrowserImplLegacy(paramContext, this, paramSessionToken) : new MediaBrowserImplBase(paramContext, this, paramSessionToken, paramBundle));
  }
  
  @NonNull
  public a<LibraryResult> getChildren(@NonNull String paramString, @IntRange(from = 0L) int paramInt1, @IntRange(from = 1L) int paramInt2, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramInt1 >= 0) {
        if (paramInt2 >= 1)
          return isConnected() ? getImpl().getChildren(paramString, paramInt1, paramInt2, paramLibraryParams) : createDisconnectedFuture(); 
        throw new IllegalArgumentException("pageSize shouldn't be less than 1");
      } 
      throw new IllegalArgumentException("page shouldn't be negative");
    } 
    throw new IllegalArgumentException("parentId shouldn't be empty");
  }
  
  MediaBrowserImpl getImpl() {
    return (MediaBrowserImpl)super.getImpl();
  }
  
  @NonNull
  public a<LibraryResult> getItem(@NonNull String paramString) {
    if (!TextUtils.isEmpty(paramString))
      return isConnected() ? getImpl().getItem(paramString) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("mediaId shouldn't be empty");
  }
  
  @NonNull
  public a<LibraryResult> getLibraryRoot(@Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    return isConnected() ? getImpl().getLibraryRoot(paramLibraryParams) : createDisconnectedFuture();
  }
  
  @NonNull
  public a<LibraryResult> getSearchResult(@NonNull String paramString, @IntRange(from = 0L) int paramInt1, @IntRange(from = 1L) int paramInt2, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramInt1 >= 0) {
        if (paramInt2 >= 1)
          return isConnected() ? getImpl().getSearchResult(paramString, paramInt1, paramInt2, paramLibraryParams) : createDisconnectedFuture(); 
        throw new IllegalArgumentException("pageSize shouldn't be less than 1");
      } 
      throw new IllegalArgumentException("page shouldn't be negative");
    } 
    throw new IllegalArgumentException("query shouldn't be empty");
  }
  
  void notifyBrowserCallback(final BrowserCallbackRunnable callbackRunnable) {
    if (this.mPrimaryCallback != null) {
      Executor executor = this.mPrimaryCallbackExecutor;
      if (executor != null)
        executor.execute(new Runnable() {
              public void run() {
                callbackRunnable.run((MediaBrowser.BrowserCallback)MediaBrowser.this.mPrimaryCallback);
              }
            }); 
    } 
  }
  
  @NonNull
  public a<LibraryResult> search(@NonNull String paramString, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    if (!TextUtils.isEmpty(paramString))
      return isConnected() ? getImpl().search(paramString, paramLibraryParams) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("query shouldn't be empty");
  }
  
  @NonNull
  public a<LibraryResult> subscribe(@NonNull String paramString, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    if (!TextUtils.isEmpty(paramString))
      return isConnected() ? getImpl().subscribe(paramString, paramLibraryParams) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("parentId shouldn't be empty");
  }
  
  @NonNull
  public a<LibraryResult> unsubscribe(@NonNull String paramString) {
    if (!TextUtils.isEmpty(paramString))
      return isConnected() ? getImpl().unsubscribe(paramString) : createDisconnectedFuture(); 
    throw new IllegalArgumentException("parentId shouldn't be empty");
  }
  
  public static class BrowserCallback extends MediaController.ControllerCallback {
    public void onChildrenChanged(@NonNull MediaBrowser param1MediaBrowser, @NonNull String param1String, @IntRange(from = 0L) int param1Int, @Nullable MediaLibraryService.LibraryParams param1LibraryParams) {}
    
    public void onSearchResultChanged(@NonNull MediaBrowser param1MediaBrowser, @NonNull String param1String, @IntRange(from = 0L) int param1Int, @Nullable MediaLibraryService.LibraryParams param1LibraryParams) {}
  }
  
  static interface BrowserCallbackRunnable {
    void run(@NonNull MediaBrowser.BrowserCallback param1BrowserCallback);
  }
  
  public static final class Builder extends MediaController.BuilderBase<MediaBrowser, Builder, BrowserCallback> {
    public Builder(@NonNull Context param1Context) {
      super(param1Context);
    }
    
    @NonNull
    public MediaBrowser build() {
      SessionToken sessionToken = this.mToken;
      if (sessionToken != null || this.mCompatToken != null)
        return (sessionToken != null) ? new MediaBrowser(this.mContext, this.mToken, this.mConnectionHints, this.mCallbackExecutor, (MediaBrowser.BrowserCallback)this.mCallback) : new MediaBrowser(this.mContext, this.mCompatToken, this.mConnectionHints, this.mCallbackExecutor, (MediaBrowser.BrowserCallback)this.mCallback); 
      throw new IllegalArgumentException("token and compat token shouldn't be both null");
    }
    
    @NonNull
    public Builder setConnectionHints(@NonNull Bundle param1Bundle) {
      return super.setConnectionHints(param1Bundle);
    }
    
    @NonNull
    public Builder setControllerCallback(@NonNull Executor param1Executor, @NonNull MediaBrowser.BrowserCallback param1BrowserCallback) {
      return super.setControllerCallback(param1Executor, param1BrowserCallback);
    }
    
    @NonNull
    public Builder setSessionCompatToken(@NonNull MediaSessionCompat.Token param1Token) {
      return super.setSessionCompatToken(param1Token);
    }
    
    @NonNull
    public Builder setSessionToken(@NonNull SessionToken param1SessionToken) {
      return super.setSessionToken(param1SessionToken);
    }
  }
  
  static interface MediaBrowserImpl extends MediaController.MediaControllerImpl {
    a<LibraryResult> getChildren(@NonNull String param1String, int param1Int1, int param1Int2, @Nullable MediaLibraryService.LibraryParams param1LibraryParams);
    
    a<LibraryResult> getItem(@NonNull String param1String);
    
    a<LibraryResult> getLibraryRoot(@Nullable MediaLibraryService.LibraryParams param1LibraryParams);
    
    a<LibraryResult> getSearchResult(@NonNull String param1String, int param1Int1, int param1Int2, @Nullable MediaLibraryService.LibraryParams param1LibraryParams);
    
    a<LibraryResult> search(@NonNull String param1String, @Nullable MediaLibraryService.LibraryParams param1LibraryParams);
    
    a<LibraryResult> subscribe(@NonNull String param1String, @Nullable MediaLibraryService.LibraryParams param1LibraryParams);
    
    a<LibraryResult> unsubscribe(@NonNull String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\MediaBrowser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */