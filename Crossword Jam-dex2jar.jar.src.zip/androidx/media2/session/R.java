package androidx.media2.session;

public final class R {
  public static final class drawable {
    public static final int media_session_service_notification_ic_music_note = 2131231316;
    
    public static final int media_session_service_notification_ic_pause = 2131231317;
    
    public static final int media_session_service_notification_ic_play = 2131231318;
    
    public static final int media_session_service_notification_ic_skip_to_next = 2131231319;
    
    public static final int media_session_service_notification_ic_skip_to_previous = 2131231320;
  }
  
  public static final class string {
    public static final int default_notification_channel_name = 2131886296;
    
    public static final int pause_button_content_description = 2131886508;
    
    public static final int play_button_content_description = 2131886515;
    
    public static final int skip_to_next_item_button_content_description = 2131886549;
    
    public static final int skip_to_previous_item_button_content_description = 2131886550;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */