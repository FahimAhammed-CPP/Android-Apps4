package androidx.media2.session;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.media.MediaBrowserCompat;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.media2.common.MediaItem;
import androidx.media2.common.MediaMetadata;
import j.d.b.e.a.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

class MediaBrowserImplLegacy extends MediaControllerImplLegacy implements MediaBrowser.MediaBrowserImpl {
  private static final String TAG = "MB2ImplLegacy";
  
  @GuardedBy("mLock")
  final HashMap<MediaLibraryService.LibraryParams, MediaBrowserCompat> mBrowserCompats = new HashMap<MediaLibraryService.LibraryParams, MediaBrowserCompat>();
  
  @GuardedBy("mLock")
  private final HashMap<String, List<SubscribeCallback>> mSubscribeCallbacks = new HashMap<String, List<SubscribeCallback>>();
  
  MediaBrowserImplLegacy(@NonNull Context paramContext, MediaBrowser paramMediaBrowser, @NonNull SessionToken paramSessionToken) {
    super(paramContext, paramMediaBrowser, paramSessionToken);
  }
  
  private static Bundle createOptions(@Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    return (paramLibraryParams == null || paramLibraryParams.getExtras() == null) ? new Bundle() : new Bundle(paramLibraryParams.getExtras());
  }
  
  private static Bundle createOptions(@Nullable MediaLibraryService.LibraryParams paramLibraryParams, int paramInt1, int paramInt2) {
    Bundle bundle = createOptions(paramLibraryParams);
    bundle.putInt("android.media.browse.extra.PAGE", paramInt1);
    bundle.putInt("android.media.browse.extra.PAGE_SIZE", paramInt2);
    return bundle;
  }
  
  private MediaBrowserCompat getBrowserCompat(MediaLibraryService.LibraryParams paramLibraryParams) {
    synchronized (this.mLock) {
      return this.mBrowserCompats.get(paramLibraryParams);
    } 
  }
  
  private static Bundle getExtras(@Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    return (paramLibraryParams != null) ? paramLibraryParams.getExtras() : null;
  }
  
  public void close() {
    synchronized (this.mLock) {
      Iterator<MediaBrowserCompat> iterator = this.mBrowserCompats.values().iterator();
      while (iterator.hasNext())
        ((MediaBrowserCompat)iterator.next()).disconnect(); 
      this.mBrowserCompats.clear();
      super.close();
      return;
    } 
  }
  
  MediaItem createRootMediaItem(@NonNull MediaBrowserCompat paramMediaBrowserCompat) {
    MediaMetadata mediaMetadata = (new MediaMetadata.Builder()).putString("android.media.metadata.MEDIA_ID", paramMediaBrowserCompat.getRoot()).putLong("androidx.media2.metadata.BROWSABLE", 0L).putLong("androidx.media2.metadata.PLAYABLE", 0L).setExtras(paramMediaBrowserCompat.getExtras()).build();
    return (new MediaItem.Builder()).setMetadata(mediaMetadata).build();
  }
  
  public a<LibraryResult> getChildren(@NonNull String paramString, int paramInt1, int paramInt2, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    ResolvableFuture<LibraryResult> resolvableFuture = ResolvableFuture.create();
    mediaBrowserCompat.subscribe(paramString, createOptions(paramLibraryParams, paramInt1, paramInt2), new GetChildrenCallback(resolvableFuture, paramString));
    return (a<LibraryResult>)resolvableFuture;
  }
  
  public a<LibraryResult> getItem(@NonNull String paramString) {
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    final ResolvableFuture result = ResolvableFuture.create();
    mediaBrowserCompat.getItem(paramString, new MediaBrowserCompat.ItemCallback() {
          public void onError(@NonNull String param1String) {
            MediaBrowserImplLegacy.this.mHandler.post(new Runnable() {
                  public void run() {
                    result.set(new LibraryResult(-1));
                  }
                });
          }
          
          public void onItemLoaded(final MediaBrowserCompat.MediaItem item) {
            MediaBrowserImplLegacy.this.mHandler.post(new Runnable() {
                  public void run() {
                    MediaBrowserCompat.MediaItem mediaItem = item;
                    if (mediaItem != null) {
                      result.set(new LibraryResult(0, MediaUtils.convertToMediaItem(mediaItem), null));
                      return;
                    } 
                    result.set(new LibraryResult(-3));
                  }
                });
          }
        });
    return (a<LibraryResult>)resolvableFuture;
  }
  
  public a<LibraryResult> getLibraryRoot(@Nullable final MediaLibraryService.LibraryParams params) {
    final ResolvableFuture result = ResolvableFuture.create();
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat(params);
    if (mediaBrowserCompat != null) {
      resolvableFuture.set(new LibraryResult(0, createRootMediaItem(mediaBrowserCompat), null));
      return (a<LibraryResult>)resolvableFuture;
    } 
    this.mHandler.post(new Runnable() {
          public void run() {
            Bundle bundle = MediaUtils.convertToRootHints(params);
            null = new MediaBrowserCompat(MediaBrowserImplLegacy.this.getContext(), MediaBrowserImplLegacy.this.getConnectedToken().getComponentName(), new MediaBrowserImplLegacy.GetLibraryRootCallback(result, params), bundle);
            synchronized (MediaBrowserImplLegacy.this.mLock) {
              MediaBrowserImplLegacy.this.mBrowserCompats.put(params, null);
              null.connect();
              return;
            } 
          }
        });
    return (a<LibraryResult>)resolvableFuture;
  }
  
  @NonNull
  MediaBrowser getMediaBrowser() {
    return (MediaBrowser)this.mInstance;
  }
  
  public a<LibraryResult> getSearchResult(@NonNull String paramString, int paramInt1, int paramInt2, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    final ResolvableFuture future = ResolvableFuture.create();
    mediaBrowserCompat.search(paramString, createOptions(paramLibraryParams, paramInt1, paramInt2), new MediaBrowserCompat.SearchCallback() {
          public void onError(@NonNull String param1String, Bundle param1Bundle) {
            MediaBrowserImplLegacy.this.mHandler.post(new Runnable() {
                  public void run() {
                    future.set(new LibraryResult(-1));
                  }
                });
          }
          
          public void onSearchResult(@NonNull String param1String, Bundle param1Bundle, @NonNull final List<MediaBrowserCompat.MediaItem> items) {
            MediaBrowserImplLegacy.this.mHandler.post(new Runnable() {
                  public void run() {
                    List<MediaItem> list = MediaUtils.convertMediaItemListToMediaItemList(items);
                    future.set(new LibraryResult(0, list, null));
                  }
                });
          }
        });
    return (a<LibraryResult>)resolvableFuture;
  }
  
  public a<LibraryResult> search(@NonNull String paramString, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    mediaBrowserCompat.search(paramString, getExtras(paramLibraryParams), new MediaBrowserCompat.SearchCallback() {
          public void onError(@NonNull final String query, Bundle param1Bundle) {
            MediaBrowserImplLegacy.this.getMediaBrowser().notifyBrowserCallback(new MediaBrowser.BrowserCallbackRunnable() {
                  public void run(@NonNull MediaBrowser.BrowserCallback param2BrowserCallback) {
                    param2BrowserCallback.onSearchResultChanged(MediaBrowserImplLegacy.this.getMediaBrowser(), query, 0, null);
                  }
                });
          }
          
          public void onSearchResult(@NonNull final String query, Bundle param1Bundle, @NonNull final List<MediaBrowserCompat.MediaItem> items) {
            MediaBrowserImplLegacy.this.getMediaBrowser().notifyBrowserCallback(new MediaBrowser.BrowserCallbackRunnable() {
                  public void run(@NonNull MediaBrowser.BrowserCallback param2BrowserCallback) {
                    param2BrowserCallback.onSearchResultChanged(MediaBrowserImplLegacy.this.getMediaBrowser(), query, items.size(), null);
                  }
                });
          }
        });
    return LibraryResult.createFutureWithResult(0);
  }
  
  public a<LibraryResult> subscribe(@NonNull String paramString, @Nullable MediaLibraryService.LibraryParams paramLibraryParams) {
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    ResolvableFuture<LibraryResult> resolvableFuture = ResolvableFuture.create();
    SubscribeCallback subscribeCallback = new SubscribeCallback(resolvableFuture);
    synchronized (this.mLock) {
      List<SubscribeCallback> list2 = this.mSubscribeCallbacks.get(paramString);
      List<SubscribeCallback> list1 = list2;
      if (list2 == null) {
        list1 = new ArrayList();
        this.mSubscribeCallbacks.put(paramString, list1);
      } 
      list1.add(subscribeCallback);
      mediaBrowserCompat.subscribe(paramString, createOptions(paramLibraryParams), subscribeCallback);
      return (a<LibraryResult>)resolvableFuture;
    } 
  }
  
  public a<LibraryResult> unsubscribe(@NonNull String paramString) {
    List<MediaBrowserCompat.SubscriptionCallback> list;
    MediaBrowserCompat mediaBrowserCompat = getBrowserCompat();
    if (mediaBrowserCompat == null)
      return LibraryResult.createFutureWithResult(-100); 
    synchronized (this.mLock) {
      list = (List)this.mSubscribeCallbacks.get(paramString);
      if (list == null)
        return LibraryResult.createFutureWithResult(-3); 
    } 
    int i;
    for (i = 0; i < list.size(); i++)
      mediaBrowserCompat.unsubscribe(paramString, list.get(i)); 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return LibraryResult.createFutureWithResult(0);
  }
  
  private class GetChildrenCallback extends MediaBrowserCompat.SubscriptionCallback {
    final ResolvableFuture<LibraryResult> mFuture;
    
    final String mParentId;
    
    GetChildrenCallback(ResolvableFuture<LibraryResult> param1ResolvableFuture, String param1String) {
      this.mFuture = param1ResolvableFuture;
      this.mParentId = param1String;
    }
    
    private void onChildrenLoadedInternal(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List) {
      if (TextUtils.isEmpty(param1String)) {
        Log.w("MB2ImplLegacy", "GetChildrenCallback.onChildrenLoaded(): Ignoring empty parentId");
        return;
      } 
      MediaBrowserCompat mediaBrowserCompat = MediaBrowserImplLegacy.this.getBrowserCompat();
      if (mediaBrowserCompat == null) {
        this.mFuture.set(new LibraryResult(-100));
        return;
      } 
      mediaBrowserCompat.unsubscribe(this.mParentId, this);
      ArrayList<MediaItem> arrayList = new ArrayList();
      if (param1List == null) {
        this.mFuture.set(new LibraryResult(-1));
        return;
      } 
      for (int i = 0; i < param1List.size(); i++)
        arrayList.add(MediaUtils.convertToMediaItem(param1List.get(i))); 
      this.mFuture.set(new LibraryResult(0, arrayList, null));
    }
    
    private void onErrorInternal() {
      this.mFuture.set(new LibraryResult(-1));
    }
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List) {
      onChildrenLoadedInternal(param1String, param1List);
    }
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List, @NonNull Bundle param1Bundle) {
      onChildrenLoadedInternal(param1String, param1List);
    }
    
    public void onError(@NonNull String param1String) {
      onErrorInternal();
    }
    
    public void onError(@NonNull String param1String, @NonNull Bundle param1Bundle) {
      onErrorInternal();
    }
  }
  
  private class GetLibraryRootCallback extends MediaBrowserCompat.ConnectionCallback {
    final MediaLibraryService.LibraryParams mParams;
    
    final ResolvableFuture<LibraryResult> mResult;
    
    GetLibraryRootCallback(ResolvableFuture<LibraryResult> param1ResolvableFuture, MediaLibraryService.LibraryParams param1LibraryParams) {
      this.mResult = param1ResolvableFuture;
      this.mParams = param1LibraryParams;
    }
    
    public void onConnected() {
      synchronized (MediaBrowserImplLegacy.this.mLock) {
        MediaBrowserCompat mediaBrowserCompat = MediaBrowserImplLegacy.this.mBrowserCompats.get(this.mParams);
        if (mediaBrowserCompat == null) {
          this.mResult.set(new LibraryResult(-1));
          return;
        } 
        this.mResult.set(new LibraryResult(0, MediaBrowserImplLegacy.this.createRootMediaItem(mediaBrowserCompat), MediaUtils.convertToLibraryParams(MediaBrowserImplLegacy.this.mContext, mediaBrowserCompat.getExtras())));
        return;
      } 
    }
    
    public void onConnectionFailed() {
      this.mResult.set(new LibraryResult(-3));
      MediaBrowserImplLegacy.this.close();
    }
    
    public void onConnectionSuspended() {
      onConnectionFailed();
    }
  }
  
  private class SubscribeCallback extends MediaBrowserCompat.SubscriptionCallback {
    final ResolvableFuture<LibraryResult> mFuture;
    
    SubscribeCallback(ResolvableFuture<LibraryResult> param1ResolvableFuture) {
      this.mFuture = param1ResolvableFuture;
    }
    
    private void onChildrenLoadedInternal(@NonNull final String parentId, @Nullable List<MediaBrowserCompat.MediaItem> param1List) {
      if (TextUtils.isEmpty(parentId)) {
        Log.w("MB2ImplLegacy", "SubscribeCallback.onChildrenLoaded(): Ignoring empty parentId");
        return;
      } 
      MediaBrowserCompat mediaBrowserCompat = MediaBrowserImplLegacy.this.getBrowserCompat();
      if (mediaBrowserCompat == null)
        return; 
      if (param1List != null) {
        final int itemCount = param1List.size();
        final MediaLibraryService.LibraryParams params = MediaUtils.convertToLibraryParams(MediaBrowserImplLegacy.this.mContext, mediaBrowserCompat.getNotifyChildrenChangedOptions());
        MediaBrowserImplLegacy.this.getMediaBrowser().notifyBrowserCallback(new MediaBrowser.BrowserCallbackRunnable() {
              public void run(@NonNull MediaBrowser.BrowserCallback param2BrowserCallback) {
                param2BrowserCallback.onChildrenChanged(MediaBrowserImplLegacy.this.getMediaBrowser(), parentId, itemCount, params);
              }
            });
        this.mFuture.set(new LibraryResult(0));
      } 
    }
    
    private void onErrorInternal() {
      this.mFuture.set(new LibraryResult(-1));
    }
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List) {
      onChildrenLoadedInternal(param1String, param1List);
    }
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List, @NonNull Bundle param1Bundle) {
      onChildrenLoadedInternal(param1String, param1List);
    }
    
    public void onError(@NonNull String param1String) {
      onErrorInternal();
    }
    
    public void onError(@NonNull String param1String, @NonNull Bundle param1Bundle) {
      onErrorInternal();
    }
  }
  
  class null implements MediaBrowser.BrowserCallbackRunnable {
    public void run(@NonNull MediaBrowser.BrowserCallback param1BrowserCallback) {
      param1BrowserCallback.onChildrenChanged(MediaBrowserImplLegacy.this.getMediaBrowser(), parentId, itemCount, params);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\MediaBrowserImplLegacy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */