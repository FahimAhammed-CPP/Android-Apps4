package androidx.media2.session;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.ObjectsCompat;
import androidx.media.MediaSessionManager;
import androidx.media2.common.MediaItem;
import androidx.media2.common.MediaMetadata;
import androidx.media2.common.MediaParcelUtils;
import androidx.media2.common.Rating;
import androidx.media2.common.SessionPlayer;
import androidx.media2.common.SubtitleData;
import androidx.media2.common.VideoSize;
import androidx.versionedparcelable.ParcelImpl;
import androidx.versionedparcelable.VersionedParcelable;
import j.d.b.e.a.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

class MediaSessionStub extends IMediaSession.Stub {
  static final boolean DEBUG = Log.isLoggable("MediaSessionStub", 3);
  
  private static final boolean RETHROW_EXCEPTION = true;
  
  private static final String TAG = "MediaSessionStub";
  
  static final SparseArray<SessionCommand> sCommandsForOnCommandRequest = new SparseArray();
  
  final ConnectedControllersManager<IBinder> mConnectedControllersManager;
  
  final Object mLock = new Object();
  
  final WeakReference<MediaSession.MediaSessionImpl> mSessionImpl;
  
  private final MediaSessionManager mSessionManager;
  
  static {
    for (SessionCommand sessionCommand : (new SessionCommandGroup.Builder()).addAllPlayerCommands(2).addAllVolumeCommands(2).build().getCommands())
      sCommandsForOnCommandRequest.append(sessionCommand.getCommandCode(), sessionCommand); 
  }
  
  MediaSessionStub(MediaSession.MediaSessionImpl paramMediaSessionImpl) {
    this.mSessionImpl = new WeakReference<MediaSession.MediaSessionImpl>(paramMediaSessionImpl);
    this.mSessionManager = MediaSessionManager.getSessionManager(paramMediaSessionImpl.getContext());
    this.mConnectedControllersManager = new ConnectedControllersManager(paramMediaSessionImpl);
  }
  
  private void dispatchSessionTask(@NonNull IMediaController paramIMediaController, int paramInt1, int paramInt2, @NonNull SessionTask paramSessionTask) {
    dispatchSessionTaskInternal(paramIMediaController, paramInt1, null, paramInt2, paramSessionTask);
  }
  
  private void dispatchSessionTask(@NonNull IMediaController paramIMediaController, int paramInt, @NonNull SessionCommand paramSessionCommand, @NonNull SessionTask paramSessionTask) {
    dispatchSessionTaskInternal(paramIMediaController, paramInt, paramSessionCommand, 0, paramSessionTask);
  }
  
  private void dispatchSessionTaskInternal(@NonNull IMediaController paramIMediaController, final int seq, @Nullable final SessionCommand sessionCommand, final int commandCode, @NonNull final SessionTask task) {
    long l = Binder.clearCallingIdentity();
    try {
      final MediaSession.MediaSessionImpl sessionImpl = this.mSessionImpl.get();
      if (mediaSessionImpl == null || mediaSessionImpl.isClosed())
        return; 
      final MediaSession.ControllerInfo controller = this.mConnectedControllersManager.getController(paramIMediaController.asBinder());
      if (controllerInfo == null)
        return; 
      mediaSessionImpl.getCallbackExecutor().execute(new Runnable() {
            public void run() {
              // Byte code:
              //   0: aload_0
              //   1: getfield this$0 : Landroidx/media2/session/MediaSessionStub;
              //   4: getfield mConnectedControllersManager : Landroidx/media2/session/ConnectedControllersManager;
              //   7: aload_0
              //   8: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   11: invokevirtual isConnected : (Landroidx/media2/session/MediaSession$ControllerInfo;)Z
              //   14: ifne -> 18
              //   17: return
              //   18: aload_0
              //   19: getfield val$sessionCommand : Landroidx/media2/session/SessionCommand;
              //   22: astore_3
              //   23: aload_3
              //   24: ifnull -> 137
              //   27: aload_0
              //   28: getfield this$0 : Landroidx/media2/session/MediaSessionStub;
              //   31: getfield mConnectedControllersManager : Landroidx/media2/session/ConnectedControllersManager;
              //   34: aload_0
              //   35: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   38: aload_3
              //   39: invokevirtual isAllowedCommand : (Landroidx/media2/session/MediaSession$ControllerInfo;Landroidx/media2/session/SessionCommand;)Z
              //   42: ifne -> 117
              //   45: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   48: ifeq -> 103
              //   51: new java/lang/StringBuilder
              //   54: dup
              //   55: invokespecial <init> : ()V
              //   58: astore_3
              //   59: aload_3
              //   60: ldc 'Command ('
              //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   65: pop
              //   66: aload_3
              //   67: aload_0
              //   68: getfield val$sessionCommand : Landroidx/media2/session/SessionCommand;
              //   71: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   74: pop
              //   75: aload_3
              //   76: ldc ') from '
              //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   81: pop
              //   82: aload_3
              //   83: aload_0
              //   84: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   87: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   90: pop
              //   91: aload_3
              //   92: ldc ' isn't allowed.'
              //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   97: pop
              //   98: aload_3
              //   99: invokevirtual toString : ()Ljava/lang/String;
              //   102: pop
              //   103: aload_0
              //   104: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   107: aload_0
              //   108: getfield val$seq : I
              //   111: bipush #-4
              //   113: invokestatic sendSessionResult : (Landroidx/media2/session/MediaSession$ControllerInfo;II)V
              //   116: return
              //   117: getstatic androidx/media2/session/MediaSessionStub.sCommandsForOnCommandRequest : Landroid/util/SparseArray;
              //   120: aload_0
              //   121: getfield val$sessionCommand : Landroidx/media2/session/SessionCommand;
              //   124: invokevirtual getCommandCode : ()I
              //   127: invokevirtual get : (I)Ljava/lang/Object;
              //   130: checkcast androidx/media2/session/SessionCommand
              //   133: astore_3
              //   134: goto -> 244
              //   137: aload_0
              //   138: getfield this$0 : Landroidx/media2/session/MediaSessionStub;
              //   141: getfield mConnectedControllersManager : Landroidx/media2/session/ConnectedControllersManager;
              //   144: aload_0
              //   145: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   148: aload_0
              //   149: getfield val$commandCode : I
              //   152: invokevirtual isAllowedCommand : (Landroidx/media2/session/MediaSession$ControllerInfo;I)Z
              //   155: ifne -> 230
              //   158: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   161: ifeq -> 216
              //   164: new java/lang/StringBuilder
              //   167: dup
              //   168: invokespecial <init> : ()V
              //   171: astore_3
              //   172: aload_3
              //   173: ldc 'Command ('
              //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   178: pop
              //   179: aload_3
              //   180: aload_0
              //   181: getfield val$commandCode : I
              //   184: invokevirtual append : (I)Ljava/lang/StringBuilder;
              //   187: pop
              //   188: aload_3
              //   189: ldc ') from '
              //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   194: pop
              //   195: aload_3
              //   196: aload_0
              //   197: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   200: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   203: pop
              //   204: aload_3
              //   205: ldc ' isn't allowed.'
              //   207: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   210: pop
              //   211: aload_3
              //   212: invokevirtual toString : ()Ljava/lang/String;
              //   215: pop
              //   216: aload_0
              //   217: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   220: aload_0
              //   221: getfield val$seq : I
              //   224: bipush #-4
              //   226: invokestatic sendSessionResult : (Landroidx/media2/session/MediaSession$ControllerInfo;II)V
              //   229: return
              //   230: getstatic androidx/media2/session/MediaSessionStub.sCommandsForOnCommandRequest : Landroid/util/SparseArray;
              //   233: aload_0
              //   234: getfield val$commandCode : I
              //   237: invokevirtual get : (I)Ljava/lang/Object;
              //   240: checkcast androidx/media2/session/SessionCommand
              //   243: astore_3
              //   244: aload_3
              //   245: ifnull -> 382
              //   248: aload_0
              //   249: getfield val$sessionImpl : Landroidx/media2/session/MediaSession$MediaSessionImpl;
              //   252: invokeinterface getCallback : ()Landroidx/media2/session/MediaSession$SessionCallback;
              //   257: aload_0
              //   258: getfield val$sessionImpl : Landroidx/media2/session/MediaSession$MediaSessionImpl;
              //   261: invokeinterface getInstance : ()Landroidx/media2/session/MediaSession;
              //   266: aload_0
              //   267: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   270: aload_3
              //   271: invokevirtual onCommandRequest : (Landroidx/media2/session/MediaSession;Landroidx/media2/session/MediaSession$ControllerInfo;Landroidx/media2/session/SessionCommand;)I
              //   274: istore_1
              //   275: iload_1
              //   276: ifeq -> 382
              //   279: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   282: ifeq -> 369
              //   285: new java/lang/StringBuilder
              //   288: dup
              //   289: invokespecial <init> : ()V
              //   292: astore #4
              //   294: aload #4
              //   296: ldc 'Command ('
              //   298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   301: pop
              //   302: aload #4
              //   304: aload_3
              //   305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   308: pop
              //   309: aload #4
              //   311: ldc ') from '
              //   313: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   316: pop
              //   317: aload #4
              //   319: aload_0
              //   320: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   323: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   326: pop
              //   327: aload #4
              //   329: ldc ' was rejected by '
              //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   334: pop
              //   335: aload #4
              //   337: aload_0
              //   338: getfield this$0 : Landroidx/media2/session/MediaSessionStub;
              //   341: getfield mSessionImpl : Ljava/lang/ref/WeakReference;
              //   344: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   347: pop
              //   348: aload #4
              //   350: ldc ', code='
              //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   355: pop
              //   356: aload #4
              //   358: iload_1
              //   359: invokevirtual append : (I)Ljava/lang/StringBuilder;
              //   362: pop
              //   363: aload #4
              //   365: invokevirtual toString : ()Ljava/lang/String;
              //   368: pop
              //   369: aload_0
              //   370: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   373: aload_0
              //   374: getfield val$seq : I
              //   377: iload_1
              //   378: invokestatic sendSessionResult : (Landroidx/media2/session/MediaSession$ControllerInfo;II)V
              //   381: return
              //   382: aload_0
              //   383: getfield val$task : Landroidx/media2/session/MediaSessionStub$SessionTask;
              //   386: astore_3
              //   387: aload_3
              //   388: instanceof androidx/media2/session/MediaSessionStub$SessionPlayerTask
              //   391: ifeq -> 471
              //   394: aload_3
              //   395: checkcast androidx/media2/session/MediaSessionStub$SessionPlayerTask
              //   398: aload_0
              //   399: getfield val$sessionImpl : Landroidx/media2/session/MediaSession$MediaSessionImpl;
              //   402: aload_0
              //   403: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   406: invokeinterface run : (Landroidx/media2/session/MediaSession$MediaSessionImpl;Landroidx/media2/session/MediaSession$ControllerInfo;)Lj/d/b/e/a/a;
              //   411: astore_3
              //   412: aload_3
              //   413: ifnull -> 435
              //   416: aload_3
              //   417: new androidx/media2/session/MediaSessionStub$1$1
              //   420: dup
              //   421: aload_0
              //   422: aload_3
              //   423: invokespecial <init> : (Landroidx/media2/session/MediaSessionStub$1;Lj/d/b/e/a/a;)V
              //   426: getstatic androidx/media2/session/MediaUtils.DIRECT_EXECUTOR : Ljava/util/concurrent/Executor;
              //   429: invokeinterface addListener : (Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
              //   434: return
              //   435: new java/lang/StringBuilder
              //   438: dup
              //   439: invokespecial <init> : ()V
              //   442: astore_3
              //   443: aload_3
              //   444: ldc 'SessionPlayer has returned null, commandCode='
              //   446: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   449: pop
              //   450: aload_3
              //   451: aload_0
              //   452: getfield val$commandCode : I
              //   455: invokevirtual append : (I)Ljava/lang/StringBuilder;
              //   458: pop
              //   459: new java/lang/RuntimeException
              //   462: dup
              //   463: aload_3
              //   464: invokevirtual toString : ()Ljava/lang/String;
              //   467: invokespecial <init> : (Ljava/lang/String;)V
              //   470: athrow
              //   471: aload_3
              //   472: instanceof androidx/media2/session/MediaSessionStub$SessionCallbackTask
              //   475: istore_2
              //   476: iload_2
              //   477: ifeq -> 639
              //   480: aload_3
              //   481: checkcast androidx/media2/session/MediaSessionStub$SessionCallbackTask
              //   484: aload_0
              //   485: getfield val$sessionImpl : Landroidx/media2/session/MediaSession$MediaSessionImpl;
              //   488: aload_0
              //   489: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   492: invokeinterface run : (Landroidx/media2/session/MediaSession$MediaSessionImpl;Landroidx/media2/session/MediaSession$ControllerInfo;)Ljava/lang/Object;
              //   497: astore_3
              //   498: aload_3
              //   499: ifnull -> 603
              //   502: aload_3
              //   503: instanceof java/lang/Integer
              //   506: ifeq -> 528
              //   509: aload_0
              //   510: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   513: aload_0
              //   514: getfield val$seq : I
              //   517: aload_3
              //   518: checkcast java/lang/Integer
              //   521: invokevirtual intValue : ()I
              //   524: invokestatic sendSessionResult : (Landroidx/media2/session/MediaSession$ControllerInfo;II)V
              //   527: return
              //   528: aload_3
              //   529: instanceof androidx/media2/session/SessionResult
              //   532: ifeq -> 551
              //   535: aload_0
              //   536: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   539: aload_0
              //   540: getfield val$seq : I
              //   543: aload_3
              //   544: checkcast androidx/media2/session/SessionResult
              //   547: invokestatic sendSessionResult : (Landroidx/media2/session/MediaSession$ControllerInfo;ILandroidx/media2/session/SessionResult;)V
              //   550: return
              //   551: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   554: ifne -> 558
              //   557: return
              //   558: new java/lang/StringBuilder
              //   561: dup
              //   562: invokespecial <init> : ()V
              //   565: astore #4
              //   567: aload #4
              //   569: ldc 'Unexpected return type '
              //   571: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   574: pop
              //   575: aload #4
              //   577: aload_3
              //   578: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   581: pop
              //   582: aload #4
              //   584: ldc '. Fix bug'
              //   586: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   589: pop
              //   590: new java/lang/RuntimeException
              //   593: dup
              //   594: aload #4
              //   596: invokevirtual toString : ()Ljava/lang/String;
              //   599: invokespecial <init> : (Ljava/lang/String;)V
              //   602: athrow
              //   603: new java/lang/StringBuilder
              //   606: dup
              //   607: invokespecial <init> : ()V
              //   610: astore_3
              //   611: aload_3
              //   612: ldc 'SessionCallback has returned null, commandCode='
              //   614: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   617: pop
              //   618: aload_3
              //   619: aload_0
              //   620: getfield val$commandCode : I
              //   623: invokevirtual append : (I)Ljava/lang/StringBuilder;
              //   626: pop
              //   627: new java/lang/RuntimeException
              //   630: dup
              //   631: aload_3
              //   632: invokevirtual toString : ()Ljava/lang/String;
              //   635: invokespecial <init> : (Ljava/lang/String;)V
              //   638: athrow
              //   639: aload_3
              //   640: instanceof androidx/media2/session/MediaSessionStub$LibrarySessionCallbackTask
              //   643: ifeq -> 808
              //   646: aload_3
              //   647: checkcast androidx/media2/session/MediaSessionStub$LibrarySessionCallbackTask
              //   650: aload_0
              //   651: getfield val$sessionImpl : Landroidx/media2/session/MediaSession$MediaSessionImpl;
              //   654: checkcast androidx/media2/session/MediaLibraryService$MediaLibrarySession$MediaLibrarySessionImpl
              //   657: aload_0
              //   658: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   661: invokeinterface run : (Landroidx/media2/session/MediaLibraryService$MediaLibrarySession$MediaLibrarySessionImpl;Landroidx/media2/session/MediaSession$ControllerInfo;)Ljava/lang/Object;
              //   666: astore_3
              //   667: aload_3
              //   668: ifnull -> 772
              //   671: aload_3
              //   672: instanceof java/lang/Integer
              //   675: ifeq -> 697
              //   678: aload_0
              //   679: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   682: aload_0
              //   683: getfield val$seq : I
              //   686: aload_3
              //   687: checkcast java/lang/Integer
              //   690: invokevirtual intValue : ()I
              //   693: invokestatic sendLibraryResult : (Landroidx/media2/session/MediaSession$ControllerInfo;II)V
              //   696: return
              //   697: aload_3
              //   698: instanceof androidx/media2/session/LibraryResult
              //   701: ifeq -> 720
              //   704: aload_0
              //   705: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   708: aload_0
              //   709: getfield val$seq : I
              //   712: aload_3
              //   713: checkcast androidx/media2/session/LibraryResult
              //   716: invokestatic sendLibraryResult : (Landroidx/media2/session/MediaSession$ControllerInfo;ILandroidx/media2/session/LibraryResult;)V
              //   719: return
              //   720: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   723: ifne -> 727
              //   726: return
              //   727: new java/lang/StringBuilder
              //   730: dup
              //   731: invokespecial <init> : ()V
              //   734: astore #4
              //   736: aload #4
              //   738: ldc 'Unexpected return type '
              //   740: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   743: pop
              //   744: aload #4
              //   746: aload_3
              //   747: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   750: pop
              //   751: aload #4
              //   753: ldc '. Fix bug'
              //   755: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   758: pop
              //   759: new java/lang/RuntimeException
              //   762: dup
              //   763: aload #4
              //   765: invokevirtual toString : ()Ljava/lang/String;
              //   768: invokespecial <init> : (Ljava/lang/String;)V
              //   771: athrow
              //   772: new java/lang/StringBuilder
              //   775: dup
              //   776: invokespecial <init> : ()V
              //   779: astore_3
              //   780: aload_3
              //   781: ldc 'LibrarySessionCallback has returned null, commandCode='
              //   783: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   786: pop
              //   787: aload_3
              //   788: aload_0
              //   789: getfield val$commandCode : I
              //   792: invokevirtual append : (I)Ljava/lang/StringBuilder;
              //   795: pop
              //   796: new java/lang/RuntimeException
              //   799: dup
              //   800: aload_3
              //   801: invokevirtual toString : ()Ljava/lang/String;
              //   804: invokespecial <init> : (Ljava/lang/String;)V
              //   807: athrow
              //   808: getstatic androidx/media2/session/MediaSessionStub.DEBUG : Z
              //   811: ifne -> 815
              //   814: return
              //   815: new java/lang/StringBuilder
              //   818: dup
              //   819: invokespecial <init> : ()V
              //   822: astore_3
              //   823: aload_3
              //   824: ldc 'Unknown task '
              //   826: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   829: pop
              //   830: aload_3
              //   831: aload_0
              //   832: getfield val$task : Landroidx/media2/session/MediaSessionStub$SessionTask;
              //   835: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
              //   838: pop
              //   839: aload_3
              //   840: ldc '. Fix bug'
              //   842: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   845: pop
              //   846: new java/lang/RuntimeException
              //   849: dup
              //   850: aload_3
              //   851: invokevirtual toString : ()Ljava/lang/String;
              //   854: invokespecial <init> : (Ljava/lang/String;)V
              //   857: athrow
              //   858: astore_3
              //   859: aload_3
              //   860: athrow
              //   861: astore_3
              //   862: new java/lang/StringBuilder
              //   865: dup
              //   866: invokespecial <init> : ()V
              //   869: astore #4
              //   871: aload #4
              //   873: ldc 'Exception in '
              //   875: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   878: pop
              //   879: aload #4
              //   881: aload_0
              //   882: getfield val$controller : Landroidx/media2/session/MediaSession$ControllerInfo;
              //   885: invokevirtual toString : ()Ljava/lang/String;
              //   888: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   891: pop
              //   892: ldc 'MediaSessionStub'
              //   894: aload #4
              //   896: invokevirtual toString : ()Ljava/lang/String;
              //   899: aload_3
              //   900: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   903: pop
              //   904: return
              // Exception table:
              //   from	to	target	type
              //   248	275	861	android/os/RemoteException
              //   248	275	858	java/lang/Exception
              //   279	369	861	android/os/RemoteException
              //   279	369	858	java/lang/Exception
              //   369	381	861	android/os/RemoteException
              //   369	381	858	java/lang/Exception
              //   382	412	861	android/os/RemoteException
              //   382	412	858	java/lang/Exception
              //   416	434	861	android/os/RemoteException
              //   416	434	858	java/lang/Exception
              //   435	471	861	android/os/RemoteException
              //   435	471	858	java/lang/Exception
              //   471	476	861	android/os/RemoteException
              //   471	476	858	java/lang/Exception
              //   480	498	861	android/os/RemoteException
              //   480	498	858	java/lang/Exception
              //   502	527	861	android/os/RemoteException
              //   502	527	858	java/lang/Exception
              //   528	550	861	android/os/RemoteException
              //   528	550	858	java/lang/Exception
              //   551	557	861	android/os/RemoteException
              //   551	557	858	java/lang/Exception
              //   558	603	861	android/os/RemoteException
              //   558	603	858	java/lang/Exception
              //   603	639	861	android/os/RemoteException
              //   603	639	858	java/lang/Exception
              //   639	667	861	android/os/RemoteException
              //   639	667	858	java/lang/Exception
              //   671	696	861	android/os/RemoteException
              //   671	696	858	java/lang/Exception
              //   697	719	861	android/os/RemoteException
              //   697	719	858	java/lang/Exception
              //   720	726	861	android/os/RemoteException
              //   720	726	858	java/lang/Exception
              //   727	772	861	android/os/RemoteException
              //   727	772	858	java/lang/Exception
              //   772	808	861	android/os/RemoteException
              //   772	808	858	java/lang/Exception
              //   808	814	861	android/os/RemoteException
              //   808	814	858	java/lang/Exception
              //   815	858	861	android/os/RemoteException
              //   815	858	858	java/lang/Exception
            }
          });
      return;
    } finally {
      Binder.restoreCallingIdentity(l);
    } 
  }
  
  static void sendLibraryResult(@NonNull MediaSession.ControllerInfo paramControllerInfo, int paramInt1, int paramInt2) {
    sendLibraryResult(paramControllerInfo, paramInt1, new LibraryResult(paramInt2));
  }
  
  static void sendLibraryResult(@NonNull MediaSession.ControllerInfo paramControllerInfo, int paramInt, @NonNull LibraryResult paramLibraryResult) {
    try {
      paramControllerInfo.getControllerCb().onLibraryResult(paramInt, paramLibraryResult);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in ");
      stringBuilder.append(paramControllerInfo.toString());
      Log.w("MediaSessionStub", stringBuilder.toString(), (Throwable)remoteException);
      return;
    } 
  }
  
  static void sendPlayerResult(@NonNull MediaSession.ControllerInfo paramControllerInfo, int paramInt, @NonNull SessionPlayer.PlayerResult paramPlayerResult) {
    try {
      paramControllerInfo.getControllerCb().onPlayerResult(paramInt, paramPlayerResult);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in ");
      stringBuilder.append(paramControllerInfo.toString());
      Log.w("MediaSessionStub", stringBuilder.toString(), (Throwable)remoteException);
      return;
    } 
  }
  
  static void sendSessionResult(@NonNull MediaSession.ControllerInfo paramControllerInfo, int paramInt1, int paramInt2) {
    sendSessionResult(paramControllerInfo, paramInt1, new SessionResult(paramInt2));
  }
  
  static void sendSessionResult(@NonNull MediaSession.ControllerInfo paramControllerInfo, int paramInt, @NonNull SessionResult paramSessionResult) {
    try {
      paramControllerInfo.getControllerCb().onSessionResult(paramInt, paramSessionResult);
      return;
    } catch (RemoteException remoteException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in ");
      stringBuilder.append(paramControllerInfo.toString());
      Log.w("MediaSessionStub", stringBuilder.toString(), (Throwable)remoteException);
      return;
    } 
  }
  
  public void addPlaylistItem(IMediaController paramIMediaController, int paramInt1, final int index, final String mediaId) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10013, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (TextUtils.isEmpty(mediaId)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("addPlaylistItem(): Ignoring empty mediaId from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return SessionPlayer.PlayerResult.createFuture(-3);
            } 
            MediaItem mediaItem = MediaSessionStub.this.convertMediaItemOnExecutor((MediaSession.MediaSessionImpl)stringBuilder, param1ControllerInfo, mediaId);
            return (mediaItem == null) ? SessionPlayer.PlayerResult.createFuture(-3) : stringBuilder.addPlaylistItem(index, mediaItem);
          }
        });
  }
  
  public void adjustVolume(IMediaController paramIMediaController, int paramInt1, final int direction, final int flags) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 30001, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            param1MediaSessionImpl.getSessionCompat().getController().adjustVolume(direction, flags);
            return Integer.valueOf(0);
          }
        });
  }
  
  public void connect(IMediaController paramIMediaController, int paramInt, ParcelImpl paramParcelImpl) throws RuntimeException {
    if (paramIMediaController != null) {
      if (paramParcelImpl == null)
        return; 
      int i = Binder.getCallingUid();
      paramInt = Binder.getCallingPid();
      long l = Binder.clearCallingIdentity();
      ConnectionRequest connectionRequest = (ConnectionRequest)MediaParcelUtils.fromParcelable(paramParcelImpl);
      if (paramInt == 0)
        paramInt = connectionRequest.getPid(); 
      try {
        connect(paramIMediaController, connectionRequest.getVersion(), connectionRequest.getPackageName(), paramInt, i, connectionRequest.getConnectionHints());
        return;
      } finally {
        Binder.restoreCallingIdentity(l);
      } 
    } 
  }
  
  void connect(final IMediaController caller, int paramInt1, String paramString, int paramInt2, int paramInt3, @Nullable Bundle paramBundle) {
    MediaSessionManager.RemoteUserInfo remoteUserInfo = new MediaSessionManager.RemoteUserInfo(paramString, paramInt2, paramInt3);
    final MediaSession.ControllerInfo controllerInfo = new MediaSession.ControllerInfo(remoteUserInfo, paramInt1, this.mSessionManager.isTrustedForMediaControl(remoteUserInfo), new Controller2Cb(caller), paramBundle);
    final MediaSession.MediaSessionImpl sessionImpl = this.mSessionImpl.get();
    if (mediaSessionImpl != null) {
      if (mediaSessionImpl.isClosed())
        return; 
      mediaSessionImpl.getCallbackExecutor().execute(new Runnable() {
            public void run() {
              boolean bool;
              if (sessionImpl.isClosed())
                return; 
              IBinder iBinder = ((MediaSessionStub.Controller2Cb)controllerInfo.getControllerCb()).getCallbackBinder();
              SessionCommandGroup sessionCommandGroup = sessionImpl.getCallback().onConnect(sessionImpl.getInstance(), controllerInfo);
              if (sessionCommandGroup != null || controllerInfo.isTrusted()) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool) {
                if (MediaSessionStub.DEBUG) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Accepting connection, controllerInfo=");
                  stringBuilder.append(controllerInfo);
                  stringBuilder.append(" allowedCommands=");
                  stringBuilder.append(sessionCommandGroup);
                  stringBuilder.toString();
                } 
                null = sessionCommandGroup;
                if (sessionCommandGroup == null)
                  null = new SessionCommandGroup(); 
                synchronized (MediaSessionStub.this.mLock) {
                  if (MediaSessionStub.this.mConnectedControllersManager.isConnected(controllerInfo)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Controller ");
                    stringBuilder.append(controllerInfo);
                    stringBuilder.append(" has sent connection request multiple times");
                    Log.w("MediaSessionStub", stringBuilder.toString());
                  } 
                  MediaSessionStub.this.mConnectedControllersManager.addController(iBinder, controllerInfo, null);
                  SequencedFutureManager sequencedFutureManager = MediaSessionStub.this.mConnectedControllersManager.getSequencedFutureManager(controllerInfo);
                  ConnectionResult connectionResult = new ConnectionResult(MediaSessionStub.this, sessionImpl, null);
                  if (sessionImpl.isClosed())
                    return; 
                  try {
                    caller.onConnected(sequencedFutureManager.obtainNextSequenceNumber(), MediaParcelUtils.toParcelable((VersionedParcelable)connectionResult));
                  } catch (RemoteException remoteException) {}
                  sessionImpl.getCallback().onPostConnect(sessionImpl.getInstance(), controllerInfo);
                  return;
                } 
              } 
              if (MediaSessionStub.DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Rejecting connection, controllerInfo=");
                stringBuilder.append(controllerInfo);
                stringBuilder.toString();
              } 
              try {
                caller.onDisconnected(0);
                return;
              } catch (RemoteException remoteException) {
                return;
              } 
            }
          });
    } 
  }
  
  @Nullable
  MediaItem convertMediaItemOnExecutor(MediaSession.MediaSessionImpl paramMediaSessionImpl, MediaSession.ControllerInfo paramControllerInfo, String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    MediaItem mediaItem = paramMediaSessionImpl.getCallback().onCreateMediaItem(paramMediaSessionImpl.getInstance(), paramControllerInfo, paramString);
    if (mediaItem == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("onCreateMediaItem(mediaId=");
      stringBuilder1.append(paramString);
      stringBuilder1.append(") returned null. Ignoring");
      Log.w("MediaSessionStub", stringBuilder1.toString());
      return mediaItem;
    } 
    if (mediaItem.getMetadata() != null && TextUtils.equals(paramString, mediaItem.getMetadata().getString("android.media.metadata.MEDIA_ID")))
      return mediaItem; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onCreateMediaItem(mediaId=");
    stringBuilder.append(paramString);
    stringBuilder.append("): media ID in the returned media item should match");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public void deselectTrack(IMediaController paramIMediaController, int paramInt, final ParcelImpl trackInfoParcel) {
    if (paramIMediaController != null) {
      if (trackInfoParcel == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 11002, new SessionPlayerTask() {
            public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              SessionPlayer.TrackInfo trackInfo = (SessionPlayer.TrackInfo)MediaParcelUtils.fromParcelable(trackInfoParcel);
              return (trackInfo == null) ? SessionPlayer.PlayerResult.createFuture(-3) : param1MediaSessionImpl.deselectTrack(trackInfo);
            }
          });
    } 
  }
  
  public void fastForward(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 40000, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return Integer.valueOf(param1MediaSessionImpl.getCallback().onFastForward(param1MediaSessionImpl.getInstance(), param1ControllerInfo));
          }
        });
  }
  
  public void getChildren(IMediaController paramIMediaController, int paramInt1, final String parentId, final int page, final int pageSize, final ParcelImpl libraryParams) throws RuntimeException {
    if (paramIMediaController != null) {
      if (libraryParams == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt1, 50003, new LibrarySessionCallbackTask<LibraryResult>() {
            public LibraryResult run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              if (TextUtils.isEmpty(parentId)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getChildren(): Ignoring empty parentId from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              int i = page;
              if (i < 0) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getChildren(): Ignoring negative page from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              int j = pageSize;
              if (j < 1) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getChildren(): Ignoring pageSize less than 1 from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              return stringBuilder.onGetChildrenOnExecutor(param1ControllerInfo, parentId, i, j, (MediaLibraryService.LibraryParams)MediaParcelUtils.fromParcelable(libraryParams));
            }
          });
    } 
  }
  
  ConnectedControllersManager<IBinder> getConnectedControllersManager() {
    return this.mConnectedControllersManager;
  }
  
  public void getItem(IMediaController paramIMediaController, int paramInt, final String mediaId) throws RuntimeException {
    dispatchSessionTask(paramIMediaController, paramInt, 50004, new LibrarySessionCallbackTask<LibraryResult>() {
          public LibraryResult run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (TextUtils.isEmpty(mediaId)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("getItem(): Ignoring empty mediaId from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return new LibraryResult(-3);
            } 
            return stringBuilder.onGetItemOnExecutor(param1ControllerInfo, mediaId);
          }
        });
  }
  
  public void getLibraryRoot(IMediaController paramIMediaController, int paramInt, final ParcelImpl libraryParams) throws RuntimeException {
    if (paramIMediaController != null) {
      if (libraryParams == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 50000, new LibrarySessionCallbackTask<LibraryResult>() {
            public LibraryResult run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              return param1MediaLibrarySessionImpl.onGetLibraryRootOnExecutor(param1ControllerInfo, (MediaLibraryService.LibraryParams)MediaParcelUtils.fromParcelable(libraryParams));
            }
          });
    } 
  }
  
  public void getSearchResult(IMediaController paramIMediaController, int paramInt1, final String query, final int page, final int pageSize, final ParcelImpl libraryParams) {
    if (paramIMediaController != null) {
      if (libraryParams == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt1, 50006, new LibrarySessionCallbackTask<LibraryResult>() {
            public LibraryResult run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              if (TextUtils.isEmpty(query)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getSearchResult(): Ignoring empty query from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              int i = page;
              if (i < 0) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getSearchResult(): Ignoring negative page from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              int j = pageSize;
              if (j < 1) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("getSearchResult(): Ignoring pageSize less than 1 from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return new LibraryResult(-3);
              } 
              return stringBuilder.onGetSearchResultOnExecutor(param1ControllerInfo, query, i, j, (MediaLibraryService.LibraryParams)MediaParcelUtils.fromParcelable(libraryParams));
            }
          });
    } 
  }
  
  public void movePlaylistItem(IMediaController paramIMediaController, int paramInt1, final int fromIndex, final int toIndex) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10019, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.movePlaylistItem(fromIndex, toIndex);
          }
        });
  }
  
  public void onControllerResult(IMediaController paramIMediaController, int paramInt, ParcelImpl paramParcelImpl) {
    if (paramIMediaController != null) {
      if (paramParcelImpl == null)
        return; 
      long l = Binder.clearCallingIdentity();
      try {
        SequencedFutureManager sequencedFutureManager = this.mConnectedControllersManager.getSequencedFutureManager(paramIMediaController.asBinder());
        if (sequencedFutureManager == null)
          return; 
        sequencedFutureManager.setFutureResult(paramInt, MediaParcelUtils.fromParcelable(paramParcelImpl));
        return;
      } finally {
        Binder.restoreCallingIdentity(l);
      } 
    } 
  }
  
  public void onCustomCommand(IMediaController paramIMediaController, int paramInt, ParcelImpl paramParcelImpl, final Bundle args) {
    if (paramIMediaController != null) {
      if (paramParcelImpl == null)
        return; 
      final SessionCommand sessionCommand = (SessionCommand)MediaParcelUtils.fromParcelable(paramParcelImpl);
      dispatchSessionTask(paramIMediaController, paramInt, sessionCommand, new SessionCallbackTask<SessionResult>() {
            public SessionResult run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              SessionResult sessionResult = param1MediaSessionImpl.getCallback().onCustomCommand(param1MediaSessionImpl.getInstance(), param1ControllerInfo, sessionCommand, args);
              if (sessionResult != null)
                return sessionResult; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SessionCallback#onCustomCommand has returned null, command=");
              stringBuilder.append(sessionCommand);
              throw new RuntimeException(stringBuilder.toString());
            }
          });
    } 
  }
  
  public void pause(IMediaController paramIMediaController, int paramInt) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10001, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.pause();
          }
        });
  }
  
  public void play(IMediaController paramIMediaController, int paramInt) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10000, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.play();
          }
        });
  }
  
  public void prepare(IMediaController paramIMediaController, int paramInt) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10002, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.prepare();
          }
        });
  }
  
  public void release(IMediaController paramIMediaController, int paramInt) throws RemoteException {
    if (paramIMediaController == null)
      return; 
    long l = Binder.clearCallingIdentity();
    try {
      this.mConnectedControllersManager.removeController(paramIMediaController.asBinder());
      return;
    } finally {
      Binder.restoreCallingIdentity(l);
    } 
  }
  
  public void removePlaylistItem(IMediaController paramIMediaController, int paramInt1, final int index) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10014, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.removePlaylistItem(index);
          }
        });
  }
  
  public void replacePlaylistItem(IMediaController paramIMediaController, int paramInt1, final int index, final String mediaId) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10015, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (TextUtils.isEmpty(mediaId)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("replacePlaylistItem(): Ignoring empty mediaId from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return SessionPlayer.PlayerResult.createFuture(-3);
            } 
            MediaItem mediaItem = MediaSessionStub.this.convertMediaItemOnExecutor((MediaSession.MediaSessionImpl)stringBuilder, param1ControllerInfo, mediaId);
            return (mediaItem == null) ? SessionPlayer.PlayerResult.createFuture(-3) : stringBuilder.replacePlaylistItem(index, mediaItem);
          }
        });
  }
  
  public void rewind(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 40001, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return Integer.valueOf(param1MediaSessionImpl.getCallback().onRewind(param1MediaSessionImpl.getInstance(), param1ControllerInfo));
          }
        });
  }
  
  public void search(IMediaController paramIMediaController, int paramInt, final String query, final ParcelImpl libraryParams) {
    if (paramIMediaController != null) {
      if (libraryParams == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 50005, new LibrarySessionCallbackTask<Integer>() {
            public Integer run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              if (TextUtils.isEmpty(query)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("search(): Ignoring empty query from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return Integer.valueOf(-3);
              } 
              return Integer.valueOf(stringBuilder.onSearchOnExecutor(param1ControllerInfo, query, (MediaLibraryService.LibraryParams)MediaParcelUtils.fromParcelable(libraryParams)));
            }
          });
    } 
  }
  
  public void seekTo(IMediaController paramIMediaController, int paramInt, final long pos) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10003, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.seekTo(pos);
          }
        });
  }
  
  public void selectTrack(IMediaController paramIMediaController, int paramInt, final ParcelImpl trackInfoParcel) {
    if (paramIMediaController != null) {
      if (trackInfoParcel == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 11001, new SessionPlayerTask() {
            public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              SessionPlayer.TrackInfo trackInfo = (SessionPlayer.TrackInfo)MediaParcelUtils.fromParcelable(trackInfoParcel);
              return (trackInfo == null) ? SessionPlayer.PlayerResult.createFuture(-3) : param1MediaSessionImpl.selectTrack(trackInfo);
            }
          });
    } 
  }
  
  public void setMediaItem(IMediaController paramIMediaController, int paramInt, final String mediaId) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10018, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (TextUtils.isEmpty(mediaId)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("setMediaItem(): Ignoring empty mediaId from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return SessionPlayer.PlayerResult.createFuture(-3);
            } 
            MediaItem mediaItem = MediaSessionStub.this.convertMediaItemOnExecutor((MediaSession.MediaSessionImpl)stringBuilder, param1ControllerInfo, mediaId);
            return (mediaItem == null) ? SessionPlayer.PlayerResult.createFuture(-3) : stringBuilder.setMediaItem(mediaItem);
          }
        });
  }
  
  public void setMediaUri(IMediaController paramIMediaController, int paramInt, final Uri uri, final Bundle extras) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 40011, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (uri == null) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("setMediaUri(): Ignoring null uri from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return Integer.valueOf(-3);
            } 
            return Integer.valueOf(stringBuilder.getCallback().onSetMediaUri(stringBuilder.getInstance(), param1ControllerInfo, uri, extras));
          }
        });
  }
  
  public void setPlaybackSpeed(IMediaController paramIMediaController, int paramInt, final float speed) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10004, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.setPlaybackSpeed(speed);
          }
        });
  }
  
  public void setPlaylist(IMediaController paramIMediaController, int paramInt, final List<String> playlist, final ParcelImpl metadata) {
    if (paramIMediaController != null) {
      if (metadata == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 10006, new SessionPlayerTask() {
            public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              if (playlist == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("setPlaylist(): Ignoring null playlist from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return SessionPlayer.PlayerResult.createFuture(-3);
              } 
              ArrayList<MediaItem> arrayList = new ArrayList();
              for (int i = 0; i < playlist.size(); i++) {
                MediaItem mediaItem = MediaSessionStub.this.convertMediaItemOnExecutor((MediaSession.MediaSessionImpl)stringBuilder, param1ControllerInfo, playlist.get(i));
                if (mediaItem != null)
                  arrayList.add(mediaItem); 
              } 
              return stringBuilder.setPlaylist(arrayList, (MediaMetadata)MediaParcelUtils.fromParcelable(metadata));
            }
          });
    } 
  }
  
  public void setRating(IMediaController paramIMediaController, int paramInt, final String mediaId, ParcelImpl paramParcelImpl) {
    if (paramIMediaController != null) {
      if (paramParcelImpl == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 40010, new SessionCallbackTask<Integer>() {
            public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              boolean bool = TextUtils.isEmpty(mediaId);
              Integer integer = Integer.valueOf(-3);
              if (bool) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("setRating(): Ignoring empty mediaId from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return integer;
              } 
              if (rating == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("setRating(): Ignoring null rating from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return integer;
              } 
              return Integer.valueOf(stringBuilder.getCallback().onSetRating(stringBuilder.getInstance(), param1ControllerInfo, mediaId, rating));
            }
          });
    } 
  }
  
  public void setRepeatMode(IMediaController paramIMediaController, int paramInt1, final int repeatMode) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10011, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.setRepeatMode(repeatMode);
          }
        });
  }
  
  public void setShuffleMode(IMediaController paramIMediaController, int paramInt1, final int shuffleMode) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10010, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.setShuffleMode(shuffleMode);
          }
        });
  }
  
  public void setSurface(IMediaController paramIMediaController, int paramInt, final Surface surface) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 11000, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.setSurface(surface);
          }
        });
  }
  
  public void setVolumeTo(IMediaController paramIMediaController, int paramInt1, final int value, final int flags) throws RuntimeException {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 30000, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            param1MediaSessionImpl.getSessionCompat().getController().setVolumeTo(value, flags);
            return Integer.valueOf(0);
          }
        });
  }
  
  public void skipBackward(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 40003, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return Integer.valueOf(param1MediaSessionImpl.getCallback().onSkipBackward(param1MediaSessionImpl.getInstance(), param1ControllerInfo));
          }
        });
  }
  
  public void skipForward(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 40002, new SessionCallbackTask<Integer>() {
          public Integer run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return Integer.valueOf(param1MediaSessionImpl.getCallback().onSkipForward(param1MediaSessionImpl.getInstance(), param1ControllerInfo));
          }
        });
  }
  
  public void skipToNextItem(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10009, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.skipToNextItem();
          }
        });
  }
  
  public void skipToPlaylistItem(IMediaController paramIMediaController, int paramInt1, final int index) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt1, 10007, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            int i = index;
            if (i < 0) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("skipToPlaylistItem(): Ignoring negative index from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return SessionPlayer.PlayerResult.createFuture(-3);
            } 
            return stringBuilder.skipToPlaylistItem(i);
          }
        });
  }
  
  public void skipToPreviousItem(IMediaController paramIMediaController, int paramInt) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10008, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.skipToPreviousItem();
          }
        });
  }
  
  public void subscribe(IMediaController paramIMediaController, int paramInt, final String parentId, final ParcelImpl libraryParams) {
    if (paramIMediaController != null) {
      if (libraryParams == null)
        return; 
      dispatchSessionTask(paramIMediaController, paramInt, 50001, new LibrarySessionCallbackTask<Integer>() {
            public Integer run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
              StringBuilder stringBuilder;
              if (TextUtils.isEmpty(parentId)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("subscribe(): Ignoring empty parentId from ");
                stringBuilder.append(param1ControllerInfo);
                Log.w("MediaSessionStub", stringBuilder.toString());
                return Integer.valueOf(-3);
              } 
              return Integer.valueOf(stringBuilder.onSubscribeOnExecutor(param1ControllerInfo, parentId, (MediaLibraryService.LibraryParams)MediaParcelUtils.fromParcelable(libraryParams)));
            }
          });
    } 
  }
  
  public void unsubscribe(IMediaController paramIMediaController, int paramInt, final String parentId) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 50002, new LibrarySessionCallbackTask<Integer>() {
          public Integer run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            StringBuilder stringBuilder;
            if (TextUtils.isEmpty(parentId)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("unsubscribe(): Ignoring empty parentId from ");
              stringBuilder.append(param1ControllerInfo);
              Log.w("MediaSessionStub", stringBuilder.toString());
              return Integer.valueOf(-3);
            } 
            return Integer.valueOf(stringBuilder.onUnsubscribeOnExecutor(param1ControllerInfo, parentId));
          }
        });
  }
  
  public void updatePlaylistMetadata(IMediaController paramIMediaController, int paramInt, final ParcelImpl metadata) {
    if (paramIMediaController == null)
      return; 
    dispatchSessionTask(paramIMediaController, paramInt, 10017, new SessionPlayerTask() {
          public a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) {
            return param1MediaSessionImpl.updatePlaylistMetadata((MediaMetadata)MediaParcelUtils.fromParcelable(metadata));
          }
        });
  }
  
  final class Controller2Cb extends MediaSession.ControllerCb {
    private final IMediaController mIControllerCallback;
    
    Controller2Cb(IMediaController param1IMediaController) {
      this.mIControllerCallback = param1IMediaController;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || param1Object.getClass() != Controller2Cb.class)
        return false; 
      param1Object = param1Object;
      return ObjectsCompat.equals(getCallbackBinder(), param1Object.getCallbackBinder());
    }
    
    @NonNull
    IBinder getCallbackBinder() {
      return this.mIControllerCallback.asBinder();
    }
    
    public int hashCode() {
      return ObjectsCompat.hash(new Object[] { getCallbackBinder() });
    }
    
    void onAllowedCommandsChanged(int param1Int, @NonNull SessionCommandGroup param1SessionCommandGroup) throws RemoteException {
      this.mIControllerCallback.onAllowedCommandsChanged(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)param1SessionCommandGroup));
    }
    
    void onBufferingStateChanged(int param1Int1, @NonNull MediaItem param1MediaItem, int param1Int2, long param1Long1, long param1Long2, long param1Long3) throws RemoteException {
      this.mIControllerCallback.onBufferingStateChanged(param1Int1, MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaItem), param1Int2, param1Long1, param1Long2, param1Long3);
    }
    
    void onChildrenChanged(int param1Int1, @NonNull String param1String, int param1Int2, MediaLibraryService.LibraryParams param1LibraryParams) throws RemoteException {
      this.mIControllerCallback.onChildrenChanged(param1Int1, param1String, param1Int2, MediaParcelUtils.toParcelable((VersionedParcelable)param1LibraryParams));
    }
    
    void onCurrentMediaItemChanged(int param1Int1, MediaItem param1MediaItem, int param1Int2, int param1Int3, int param1Int4) throws RemoteException {
      this.mIControllerCallback.onCurrentMediaItemChanged(param1Int1, MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaItem), param1Int2, param1Int3, param1Int4);
    }
    
    void onDisconnected(int param1Int) throws RemoteException {
      this.mIControllerCallback.onDisconnected(param1Int);
    }
    
    void onLibraryResult(int param1Int, LibraryResult param1LibraryResult) throws RemoteException {
      LibraryResult libraryResult = param1LibraryResult;
      if (param1LibraryResult == null)
        libraryResult = new LibraryResult(-1); 
      this.mIControllerCallback.onLibraryResult(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)libraryResult));
    }
    
    void onPlaybackCompleted(int param1Int) throws RemoteException {
      this.mIControllerCallback.onPlaybackCompleted(param1Int);
    }
    
    void onPlaybackInfoChanged(int param1Int, @NonNull MediaController.PlaybackInfo param1PlaybackInfo) throws RemoteException {
      this.mIControllerCallback.onPlaybackInfoChanged(param1Int, MediaParcelUtils.toParcelable(param1PlaybackInfo));
    }
    
    void onPlaybackSpeedChanged(int param1Int, long param1Long1, long param1Long2, float param1Float) throws RemoteException {
      this.mIControllerCallback.onPlaybackSpeedChanged(param1Int, param1Long1, param1Long2, param1Float);
    }
    
    void onPlayerChanged(int param1Int, @Nullable SessionPlayer param1SessionPlayer1, @Nullable MediaController.PlaybackInfo param1PlaybackInfo1, @NonNull SessionPlayer param1SessionPlayer2, @NonNull MediaController.PlaybackInfo param1PlaybackInfo2) throws RemoteException {
      if (param1SessionPlayer1 == null)
        return; 
      if ((MediaSession.MediaSessionImpl)MediaSessionStub.this.mSessionImpl.get() == null)
        return; 
      List list = param1SessionPlayer1.getPlaylist();
      List<MediaItem> list1 = param1SessionPlayer2.getPlaylist();
      if (!ObjectsCompat.equals(list, list1)) {
        onPlaylistChanged(param1Int, list1, param1SessionPlayer2.getPlaylistMetadata(), param1SessionPlayer2.getCurrentMediaItemIndex(), param1SessionPlayer2.getPreviousMediaItemIndex(), param1SessionPlayer2.getNextMediaItemIndex());
      } else {
        MediaMetadata mediaMetadata1 = param1SessionPlayer1.getPlaylistMetadata();
        MediaMetadata mediaMetadata2 = param1SessionPlayer2.getPlaylistMetadata();
        if (!ObjectsCompat.equals(mediaMetadata1, mediaMetadata2))
          onPlaylistMetadataChanged(param1Int, mediaMetadata2); 
      } 
      MediaItem mediaItem1 = param1SessionPlayer1.getCurrentMediaItem();
      MediaItem mediaItem2 = param1SessionPlayer2.getCurrentMediaItem();
      if (!ObjectsCompat.equals(mediaItem1, mediaItem2))
        onCurrentMediaItemChanged(param1Int, mediaItem2, param1SessionPlayer2.getCurrentMediaItemIndex(), param1SessionPlayer2.getPreviousMediaItemIndex(), param1SessionPlayer2.getNextMediaItemIndex()); 
      int i = param1SessionPlayer2.getRepeatMode();
      if (param1SessionPlayer1.getRepeatMode() != i)
        onRepeatModeChanged(param1Int, i, param1SessionPlayer2.getCurrentMediaItemIndex(), param1SessionPlayer2.getPreviousMediaItemIndex(), param1SessionPlayer2.getNextMediaItemIndex()); 
      i = param1SessionPlayer2.getShuffleMode();
      if (param1SessionPlayer1.getShuffleMode() != i)
        onShuffleModeChanged(param1Int, i, param1SessionPlayer2.getCurrentMediaItemIndex(), param1SessionPlayer2.getPreviousMediaItemIndex(), param1SessionPlayer2.getNextMediaItemIndex()); 
      long l1 = SystemClock.elapsedRealtime();
      long l2 = param1SessionPlayer2.getCurrentPosition();
      onPlayerStateChanged(param1Int, l1, l2, param1SessionPlayer2.getPlayerState());
      mediaItem1 = param1SessionPlayer2.getCurrentMediaItem();
      if (mediaItem1 != null)
        onBufferingStateChanged(param1Int, mediaItem1, param1SessionPlayer2.getBufferingState(), param1SessionPlayer2.getBufferedPosition(), SystemClock.elapsedRealtime(), param1SessionPlayer2.getCurrentPosition()); 
      float f = param1SessionPlayer2.getPlaybackSpeed();
      if (f != param1SessionPlayer1.getPlaybackSpeed())
        onPlaybackSpeedChanged(param1Int, l1, l2, f); 
      if (!ObjectsCompat.equals(param1PlaybackInfo1, param1PlaybackInfo2))
        onPlaybackInfoChanged(param1Int, param1PlaybackInfo2); 
    }
    
    void onPlayerResult(int param1Int, @Nullable SessionPlayer.PlayerResult param1PlayerResult) throws RemoteException {
      onSessionResult(param1Int, SessionResult.from(param1PlayerResult));
    }
    
    void onPlayerStateChanged(int param1Int1, long param1Long1, long param1Long2, int param1Int2) throws RemoteException {
      this.mIControllerCallback.onPlayerStateChanged(param1Int1, param1Long1, param1Long2, param1Int2);
    }
    
    void onPlaylistChanged(int param1Int1, @NonNull List<MediaItem> param1List, MediaMetadata param1MediaMetadata, int param1Int2, int param1Int3, int param1Int4) throws RemoteException {
      MediaSession.ControllerInfo controllerInfo = MediaSessionStub.this.mConnectedControllersManager.getController(getCallbackBinder());
      if (MediaSessionStub.this.mConnectedControllersManager.isAllowedCommand(controllerInfo, 10005)) {
        this.mIControllerCallback.onPlaylistChanged(param1Int1, MediaUtils.convertMediaItemListToParcelImplListSlice(param1List), MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaMetadata), param1Int2, param1Int3, param1Int4);
        return;
      } 
      if (MediaSessionStub.this.mConnectedControllersManager.isAllowedCommand(controllerInfo, 10012))
        this.mIControllerCallback.onPlaylistMetadataChanged(param1Int1, MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaMetadata)); 
    }
    
    void onPlaylistMetadataChanged(int param1Int, MediaMetadata param1MediaMetadata) throws RemoteException {
      MediaSession.ControllerInfo controllerInfo = MediaSessionStub.this.mConnectedControllersManager.getController(getCallbackBinder());
      if (MediaSessionStub.this.mConnectedControllersManager.isAllowedCommand(controllerInfo, 10012))
        this.mIControllerCallback.onPlaylistMetadataChanged(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaMetadata)); 
    }
    
    void onRepeatModeChanged(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) throws RemoteException {
      this.mIControllerCallback.onRepeatModeChanged(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
    }
    
    void onSearchResultChanged(int param1Int1, @NonNull String param1String, int param1Int2, MediaLibraryService.LibraryParams param1LibraryParams) throws RemoteException {
      this.mIControllerCallback.onSearchResultChanged(param1Int1, param1String, param1Int2, MediaParcelUtils.toParcelable((VersionedParcelable)param1LibraryParams));
    }
    
    void onSeekCompleted(int param1Int, long param1Long1, long param1Long2, long param1Long3) throws RemoteException {
      this.mIControllerCallback.onSeekCompleted(param1Int, param1Long1, param1Long2, param1Long3);
    }
    
    void onSessionResult(int param1Int, @Nullable SessionResult param1SessionResult) throws RemoteException {
      SessionResult sessionResult = param1SessionResult;
      if (param1SessionResult == null)
        sessionResult = new SessionResult(-1, null); 
      this.mIControllerCallback.onSessionResult(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)sessionResult));
    }
    
    void onShuffleModeChanged(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) throws RemoteException {
      this.mIControllerCallback.onShuffleModeChanged(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
    }
    
    void onSubtitleData(int param1Int, @NonNull MediaItem param1MediaItem, @NonNull SessionPlayer.TrackInfo param1TrackInfo, @NonNull SubtitleData param1SubtitleData) throws RemoteException {
      ParcelImpl parcelImpl1 = MediaParcelUtils.toParcelable((VersionedParcelable)param1MediaItem);
      ParcelImpl parcelImpl2 = MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo);
      ParcelImpl parcelImpl3 = MediaParcelUtils.toParcelable((VersionedParcelable)param1SubtitleData);
      this.mIControllerCallback.onSubtitleData(param1Int, parcelImpl1, parcelImpl2, parcelImpl3);
    }
    
    void onTrackDeselected(int param1Int, SessionPlayer.TrackInfo param1TrackInfo) throws RemoteException {
      this.mIControllerCallback.onTrackDeselected(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo));
    }
    
    void onTrackSelected(int param1Int, SessionPlayer.TrackInfo param1TrackInfo) throws RemoteException {
      this.mIControllerCallback.onTrackSelected(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo));
    }
    
    void onTracksChanged(int param1Int, List<SessionPlayer.TrackInfo> param1List, SessionPlayer.TrackInfo param1TrackInfo1, SessionPlayer.TrackInfo param1TrackInfo2, SessionPlayer.TrackInfo param1TrackInfo3, SessionPlayer.TrackInfo param1TrackInfo4) throws RemoteException {
      param1List = MediaParcelUtils.toParcelableList(param1List);
      this.mIControllerCallback.onTrackInfoChanged(param1Int, param1List, MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo1), MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo2), MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo3), MediaParcelUtils.toParcelable((VersionedParcelable)param1TrackInfo4));
    }
    
    void onVideoSizeChanged(int param1Int, @NonNull VideoSize param1VideoSize) throws RemoteException {
      ParcelImpl parcelImpl = MediaParcelUtils.toParcelable((VersionedParcelable)param1VideoSize);
      MediaItem mediaItem = (new MediaItem.Builder()).build();
      this.mIControllerCallback.onVideoSizeChanged(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)mediaItem), parcelImpl);
    }
    
    void sendCustomCommand(int param1Int, @NonNull SessionCommand param1SessionCommand, Bundle param1Bundle) throws RemoteException {
      this.mIControllerCallback.onCustomCommand(param1Int, MediaParcelUtils.toParcelable((VersionedParcelable)param1SessionCommand), param1Bundle);
    }
    
    void setCustomLayout(int param1Int, @NonNull List<MediaSession.CommandButton> param1List) throws RemoteException {
      this.mIControllerCallback.onSetCustomLayout(param1Int, MediaUtils.convertCommandButtonListToParcelImplList(param1List));
    }
  }
  
  private static interface LibrarySessionCallbackTask<T> extends SessionTask {
    T run(MediaLibraryService.MediaLibrarySession.MediaLibrarySessionImpl param1MediaLibrarySessionImpl, MediaSession.ControllerInfo param1ControllerInfo) throws RemoteException;
  }
  
  private static interface SessionCallbackTask<T> extends SessionTask {
    T run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) throws RemoteException;
  }
  
  private static interface SessionPlayerTask extends SessionTask {
    a<SessionPlayer.PlayerResult> run(MediaSession.MediaSessionImpl param1MediaSessionImpl, MediaSession.ControllerInfo param1ControllerInfo) throws RemoteException;
  }
  
  private static interface SessionTask {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\session\MediaSessionStub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */