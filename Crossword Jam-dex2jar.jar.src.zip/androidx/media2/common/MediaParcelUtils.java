package androidx.media2.common;

import android.annotation.SuppressLint;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.versionedparcelable.ParcelImpl;
import androidx.versionedparcelable.ParcelUtils;
import androidx.versionedparcelable.VersionedParcelable;
import java.util.ArrayList;
import java.util.List;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class MediaParcelUtils {
  public static final String TAG = "MediaParcelUtils";
  
  @Nullable
  public static <T extends VersionedParcelable> T fromParcelable(@NonNull ParcelImpl paramParcelImpl) {
    return (T)ParcelUtils.fromParcelable((Parcelable)paramParcelImpl);
  }
  
  @NonNull
  public static <T extends VersionedParcelable> List<T> fromParcelableList(@NonNull List<ParcelImpl> paramList) {
    ArrayList<T> arrayList = new ArrayList();
    for (int i = 0; i < paramList.size(); i++)
      arrayList.add(fromParcelable(paramList.get(i))); 
    return arrayList;
  }
  
  @NonNull
  public static ParcelImpl toParcelable(@Nullable VersionedParcelable paramVersionedParcelable) {
    return (paramVersionedParcelable instanceof MediaItem) ? new MediaItemParcelImpl((MediaItem)paramVersionedParcelable) : (ParcelImpl)ParcelUtils.toParcelable(paramVersionedParcelable);
  }
  
  @NonNull
  public static List<ParcelImpl> toParcelableList(@NonNull List<? extends VersionedParcelable> paramList) {
    ArrayList<ParcelImpl> arrayList = new ArrayList();
    for (int i = 0; i < paramList.size(); i++)
      arrayList.add(toParcelable(paramList.get(i))); 
    return arrayList;
  }
  
  @SuppressLint({"RestrictedApi"})
  private static class MediaItemParcelImpl extends ParcelImpl {
    private final MediaItem mItem;
    
    MediaItemParcelImpl(MediaItem param1MediaItem) {
      super((VersionedParcelable)new MediaItem(param1MediaItem));
      this.mItem = param1MediaItem;
    }
    
    public MediaItem getVersionedParcel() {
      return this.mItem;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\common\MediaParcelUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */