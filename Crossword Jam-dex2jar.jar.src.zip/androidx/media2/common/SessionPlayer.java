package androidx.media2.common;

import android.media.MediaFormat;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.Surface;
import androidx.annotation.CallSuper;
import androidx.annotation.GuardedBy;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.core.util.Pair;
import androidx.media.AudioAttributesCompat;
import androidx.versionedparcelable.CustomVersionedParcelable;
import j.d.b.e.a.a;
import java.io.Closeable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.Executor;

public abstract class SessionPlayer implements Closeable {
  public static final int BUFFERING_STATE_BUFFERING_AND_PLAYABLE = 1;
  
  public static final int BUFFERING_STATE_BUFFERING_AND_STARVED = 2;
  
  public static final int BUFFERING_STATE_COMPLETE = 3;
  
  public static final int BUFFERING_STATE_UNKNOWN = 0;
  
  public static final int INVALID_ITEM_INDEX = -1;
  
  public static final int PLAYER_STATE_ERROR = 3;
  
  public static final int PLAYER_STATE_IDLE = 0;
  
  public static final int PLAYER_STATE_PAUSED = 1;
  
  public static final int PLAYER_STATE_PLAYING = 2;
  
  public static final int REPEAT_MODE_ALL = 2;
  
  public static final int REPEAT_MODE_GROUP = 3;
  
  public static final int REPEAT_MODE_NONE = 0;
  
  public static final int REPEAT_MODE_ONE = 1;
  
  public static final int SHUFFLE_MODE_ALL = 1;
  
  public static final int SHUFFLE_MODE_GROUP = 2;
  
  public static final int SHUFFLE_MODE_NONE = 0;
  
  private static final String TAG = "SessionPlayer";
  
  public static final long UNKNOWN_TIME = -9223372036854775808L;
  
  @GuardedBy("mLock")
  private final List<Pair<PlayerCallback, Executor>> mCallbacks = new ArrayList<Pair<PlayerCallback, Executor>>();
  
  private final Object mLock = new Object();
  
  @NonNull
  public abstract a<PlayerResult> addPlaylistItem(int paramInt, @NonNull MediaItem paramMediaItem);
  
  @CallSuper
  public void close() {
    synchronized (this.mLock) {
      this.mCallbacks.clear();
      return;
    } 
  }
  
  @NonNull
  public a<PlayerResult> deselectTrack(@NonNull TrackInfo paramTrackInfo) {
    throw new UnsupportedOperationException("deselectTrack is not implemented");
  }
  
  @Nullable
  public abstract AudioAttributesCompat getAudioAttributes();
  
  public abstract long getBufferedPosition();
  
  public abstract int getBufferingState();
  
  @NonNull
  protected final List<Pair<PlayerCallback, Executor>> getCallbacks() {
    null = new ArrayList();
    synchronized (this.mLock) {
      null.addAll(this.mCallbacks);
      return null;
    } 
  }
  
  @Nullable
  public abstract MediaItem getCurrentMediaItem();
  
  @IntRange(from = -1L)
  public abstract int getCurrentMediaItemIndex();
  
  public abstract long getCurrentPosition();
  
  public abstract long getDuration();
  
  @IntRange(from = -1L)
  public abstract int getNextMediaItemIndex();
  
  public abstract float getPlaybackSpeed();
  
  public abstract int getPlayerState();
  
  @Nullable
  public abstract List<MediaItem> getPlaylist();
  
  @Nullable
  public abstract MediaMetadata getPlaylistMetadata();
  
  @IntRange(from = -1L)
  public abstract int getPreviousMediaItemIndex();
  
  public abstract int getRepeatMode();
  
  @Nullable
  public TrackInfo getSelectedTrack(int paramInt) {
    throw new UnsupportedOperationException("getSelectedTrack is not implemented");
  }
  
  public abstract int getShuffleMode();
  
  @NonNull
  public List<TrackInfo> getTracks() {
    throw new UnsupportedOperationException("getTracks is not implemented");
  }
  
  @NonNull
  public VideoSize getVideoSize() {
    throw new UnsupportedOperationException("getVideoSize is not implemented");
  }
  
  @NonNull
  public a<PlayerResult> movePlaylistItem(@IntRange(from = 0L) int paramInt1, @IntRange(from = 0L) int paramInt2) {
    throw new UnsupportedOperationException("movePlaylistItem is not implemented");
  }
  
  @NonNull
  public abstract a<PlayerResult> pause();
  
  @NonNull
  public abstract a<PlayerResult> play();
  
  @NonNull
  public abstract a<PlayerResult> prepare();
  
  public final void registerPlayerCallback(@NonNull Executor paramExecutor, @NonNull PlayerCallback paramPlayerCallback) {
    Objects.requireNonNull(paramExecutor, "executor shouldn't be null");
    Objects.requireNonNull(paramPlayerCallback, "callback shouldn't be null");
    synchronized (this.mLock) {
      for (Pair<PlayerCallback, Executor> pair : this.mCallbacks) {
        if (pair.first == paramPlayerCallback && pair.second != null) {
          Log.w("SessionPlayer", "callback is already added. Ignoring.");
          return;
        } 
      } 
      this.mCallbacks.add(new Pair(paramPlayerCallback, paramExecutor));
      return;
    } 
  }
  
  @NonNull
  public abstract a<PlayerResult> removePlaylistItem(@IntRange(from = 0L) int paramInt);
  
  @NonNull
  public abstract a<PlayerResult> replacePlaylistItem(int paramInt, @NonNull MediaItem paramMediaItem);
  
  @NonNull
  public abstract a<PlayerResult> seekTo(long paramLong);
  
  @NonNull
  public a<PlayerResult> selectTrack(@NonNull TrackInfo paramTrackInfo) {
    throw new UnsupportedOperationException("selectTrack is not implemented");
  }
  
  @NonNull
  public abstract a<PlayerResult> setAudioAttributes(@NonNull AudioAttributesCompat paramAudioAttributesCompat);
  
  @NonNull
  public abstract a<PlayerResult> setMediaItem(@NonNull MediaItem paramMediaItem);
  
  @NonNull
  public abstract a<PlayerResult> setPlaybackSpeed(float paramFloat);
  
  @NonNull
  public abstract a<PlayerResult> setPlaylist(@NonNull List<MediaItem> paramList, @Nullable MediaMetadata paramMediaMetadata);
  
  @NonNull
  public abstract a<PlayerResult> setRepeatMode(int paramInt);
  
  @NonNull
  public abstract a<PlayerResult> setShuffleMode(int paramInt);
  
  @NonNull
  public a<PlayerResult> setSurface(@Nullable Surface paramSurface) {
    throw new UnsupportedOperationException("setSurface is not implemented");
  }
  
  @NonNull
  public abstract a<PlayerResult> skipToNextPlaylistItem();
  
  @NonNull
  public abstract a<PlayerResult> skipToPlaylistItem(@IntRange(from = 0L) int paramInt);
  
  @NonNull
  public abstract a<PlayerResult> skipToPreviousPlaylistItem();
  
  public final void unregisterPlayerCallback(@NonNull PlayerCallback paramPlayerCallback) {
    Objects.requireNonNull(paramPlayerCallback, "callback shouldn't be null");
    synchronized (this.mLock) {
      for (int i = this.mCallbacks.size() - 1;; i--) {
        if (i >= 0) {
          if (((Pair)this.mCallbacks.get(i)).first == paramPlayerCallback)
            this.mCallbacks.remove(i); 
        } else {
          return;
        } 
      } 
    } 
  }
  
  @NonNull
  public abstract a<PlayerResult> updatePlaylistMetadata(@Nullable MediaMetadata paramMediaMetadata);
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface BuffState {}
  
  public static abstract class PlayerCallback {
    public void onAudioAttributesChanged(@NonNull SessionPlayer param1SessionPlayer, @Nullable AudioAttributesCompat param1AudioAttributesCompat) {}
    
    public void onBufferingStateChanged(@NonNull SessionPlayer param1SessionPlayer, @Nullable MediaItem param1MediaItem, int param1Int) {}
    
    public void onCurrentMediaItemChanged(@NonNull SessionPlayer param1SessionPlayer, @Nullable MediaItem param1MediaItem) {}
    
    public void onPlaybackCompleted(@NonNull SessionPlayer param1SessionPlayer) {}
    
    public void onPlaybackSpeedChanged(@NonNull SessionPlayer param1SessionPlayer, float param1Float) {}
    
    public void onPlayerStateChanged(@NonNull SessionPlayer param1SessionPlayer, int param1Int) {}
    
    public void onPlaylistChanged(@NonNull SessionPlayer param1SessionPlayer, @Nullable List<MediaItem> param1List, @Nullable MediaMetadata param1MediaMetadata) {}
    
    public void onPlaylistMetadataChanged(@NonNull SessionPlayer param1SessionPlayer, @Nullable MediaMetadata param1MediaMetadata) {}
    
    public void onRepeatModeChanged(@NonNull SessionPlayer param1SessionPlayer, int param1Int) {}
    
    public void onSeekCompleted(@NonNull SessionPlayer param1SessionPlayer, long param1Long) {}
    
    public void onShuffleModeChanged(@NonNull SessionPlayer param1SessionPlayer, int param1Int) {}
    
    public void onSubtitleData(@NonNull SessionPlayer param1SessionPlayer, @NonNull MediaItem param1MediaItem, @NonNull SessionPlayer.TrackInfo param1TrackInfo, @NonNull SubtitleData param1SubtitleData) {}
    
    public void onTrackDeselected(@NonNull SessionPlayer param1SessionPlayer, @NonNull SessionPlayer.TrackInfo param1TrackInfo) {}
    
    public void onTrackSelected(@NonNull SessionPlayer param1SessionPlayer, @NonNull SessionPlayer.TrackInfo param1TrackInfo) {}
    
    public void onTracksChanged(@NonNull SessionPlayer param1SessionPlayer, @NonNull List<SessionPlayer.TrackInfo> param1List) {}
    
    public void onVideoSizeChanged(@NonNull SessionPlayer param1SessionPlayer, @NonNull VideoSize param1VideoSize) {}
  }
  
  public static class PlayerResult implements BaseResult {
    private final long mCompletionTime;
    
    private final MediaItem mItem;
    
    private final int mResultCode;
    
    public PlayerResult(int param1Int, @Nullable MediaItem param1MediaItem) {
      this(param1Int, param1MediaItem, SystemClock.elapsedRealtime());
    }
    
    private PlayerResult(int param1Int, @Nullable MediaItem param1MediaItem, long param1Long) {
      this.mResultCode = param1Int;
      this.mItem = param1MediaItem;
      this.mCompletionTime = param1Long;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static a<PlayerResult> createFuture(int param1Int) {
      ResolvableFuture resolvableFuture = ResolvableFuture.create();
      resolvableFuture.set(new PlayerResult(param1Int, null));
      return (a<PlayerResult>)resolvableFuture;
    }
    
    public long getCompletionTime() {
      return this.mCompletionTime;
    }
    
    @Nullable
    public MediaItem getMediaItem() {
      return this.mItem;
    }
    
    public int getResultCode() {
      return this.mResultCode;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public static @interface ResultCode {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface ResultCode {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface PlayerState {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface RepeatMode {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ShuffleMode {}
  
  public static class TrackInfo extends CustomVersionedParcelable {
    private static final String KEY_IS_FORMAT_NULL = "androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_FORMAT_NULL";
    
    private static final String KEY_IS_SELECTABLE = "androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_SELECTABLE";
    
    public static final int MEDIA_TRACK_TYPE_AUDIO = 2;
    
    public static final int MEDIA_TRACK_TYPE_METADATA = 5;
    
    public static final int MEDIA_TRACK_TYPE_SUBTITLE = 4;
    
    public static final int MEDIA_TRACK_TYPE_UNKNOWN = 0;
    
    public static final int MEDIA_TRACK_TYPE_VIDEO = 1;
    
    @Nullable
    MediaFormat mFormat;
    
    int mId;
    
    boolean mIsSelectable;
    
    private final Object mLock = new Object();
    
    Bundle mParcelableExtras;
    
    int mTrackType;
    
    TrackInfo() {}
    
    public TrackInfo(int param1Int1, int param1Int2, @Nullable MediaFormat param1MediaFormat) {
      this(param1Int1, param1Int2, param1MediaFormat, false);
    }
    
    public TrackInfo(int param1Int1, int param1Int2, @Nullable MediaFormat param1MediaFormat, boolean param1Boolean) {
      this.mId = param1Int1;
      this.mTrackType = param1Int2;
      this.mFormat = param1MediaFormat;
      this.mIsSelectable = param1Boolean;
    }
    
    private static void putIntValueToBundle(String param1String, MediaFormat param1MediaFormat, Bundle param1Bundle) {
      if (param1MediaFormat.containsKey(param1String))
        param1Bundle.putInt(param1String, param1MediaFormat.getInteger(param1String)); 
    }
    
    private static void putStringValueToBundle(String param1String, MediaFormat param1MediaFormat, Bundle param1Bundle) {
      if (param1MediaFormat.containsKey(param1String))
        param1Bundle.putString(param1String, param1MediaFormat.getString(param1String)); 
    }
    
    private static void setIntValueToMediaFormat(String param1String, MediaFormat param1MediaFormat, Bundle param1Bundle) {
      if (param1Bundle.containsKey(param1String))
        param1MediaFormat.setInteger(param1String, param1Bundle.getInt(param1String)); 
    }
    
    private static void setStringValueToMediaFormat(String param1String, MediaFormat param1MediaFormat, Bundle param1Bundle) {
      if (param1Bundle.containsKey(param1String))
        param1MediaFormat.setString(param1String, param1Bundle.getString(param1String)); 
    }
    
    public boolean equals(@Nullable Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof TrackInfo))
        return false; 
      param1Object = param1Object;
      return (this.mId == ((TrackInfo)param1Object).mId);
    }
    
    @Nullable
    public MediaFormat getFormat() {
      return this.mFormat;
    }
    
    public int getId() {
      return this.mId;
    }
    
    @NonNull
    public Locale getLanguage() {
      String str;
      MediaFormat mediaFormat1 = this.mFormat;
      if (mediaFormat1 != null) {
        String str1 = mediaFormat1.getString("language");
      } else {
        mediaFormat1 = null;
      } 
      MediaFormat mediaFormat2 = mediaFormat1;
      if (mediaFormat1 == null)
        str = "und"; 
      return new Locale(str);
    }
    
    public int getTrackType() {
      return this.mTrackType;
    }
    
    public int hashCode() {
      return this.mId;
    }
    
    public boolean isSelectable() {
      return this.mIsSelectable;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public void onPostParceling() {
      Bundle bundle = this.mParcelableExtras;
      if (bundle != null && !bundle.getBoolean("androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_FORMAT_NULL")) {
        MediaFormat mediaFormat = new MediaFormat();
        this.mFormat = mediaFormat;
        setStringValueToMediaFormat("language", mediaFormat, this.mParcelableExtras);
        setStringValueToMediaFormat("mime", this.mFormat, this.mParcelableExtras);
        setIntValueToMediaFormat("is-forced-subtitle", this.mFormat, this.mParcelableExtras);
        setIntValueToMediaFormat("is-autoselect", this.mFormat, this.mParcelableExtras);
        setIntValueToMediaFormat("is-default", this.mFormat, this.mParcelableExtras);
      } 
      bundle = this.mParcelableExtras;
      if (bundle == null || !bundle.containsKey("androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_SELECTABLE")) {
        int i = this.mTrackType;
        boolean bool = true;
        if (i == 1)
          bool = false; 
        this.mIsSelectable = bool;
        return;
      } 
      this.mIsSelectable = this.mParcelableExtras.getBoolean("androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_SELECTABLE");
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public void onPreParceling(boolean param1Boolean) {
      synchronized (this.mLock) {
        Bundle bundle = new Bundle();
        this.mParcelableExtras = bundle;
        if (this.mFormat == null) {
          param1Boolean = true;
        } else {
          param1Boolean = false;
        } 
        bundle.putBoolean("androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_FORMAT_NULL", param1Boolean);
        MediaFormat mediaFormat = this.mFormat;
        if (mediaFormat != null) {
          putStringValueToBundle("language", mediaFormat, this.mParcelableExtras);
          putStringValueToBundle("mime", this.mFormat, this.mParcelableExtras);
          putIntValueToBundle("is-forced-subtitle", this.mFormat, this.mParcelableExtras);
          putIntValueToBundle("is-autoselect", this.mFormat, this.mParcelableExtras);
          putIntValueToBundle("is-default", this.mFormat, this.mParcelableExtras);
        } 
        this.mParcelableExtras.putBoolean("androidx.media2.common.SessionPlayer.TrackInfo.KEY_IS_SELECTABLE", this.mIsSelectable);
        return;
      } 
    }
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(128);
      stringBuilder.append(getClass().getName());
      stringBuilder.append('#');
      stringBuilder.append(this.mId);
      stringBuilder.append('{');
      int i = this.mTrackType;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i != 5) {
              stringBuilder.append("UNKNOWN");
            } else {
              stringBuilder.append("METADATA");
            } 
          } else {
            stringBuilder.append("SUBTITLE");
          } 
        } else {
          stringBuilder.append("AUDIO");
        } 
      } else {
        stringBuilder.append("VIDEO");
      } 
      stringBuilder.append(", ");
      stringBuilder.append(this.mFormat);
      stringBuilder.append(", isSelectable=");
      stringBuilder.append(this.mIsSelectable);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static @interface MediaTrackType {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface MediaTrackType {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media2\common\SessionPlayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */