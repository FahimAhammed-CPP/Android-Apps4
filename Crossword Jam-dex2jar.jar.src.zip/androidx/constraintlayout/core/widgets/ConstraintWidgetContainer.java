package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int myCounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private int pass;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  HashSet<ConstraintWidget> widgetsToAdd = new HashSet<ConstraintWidget>();
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(int paramInt1, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt2) {
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    if (paramConstraintWidget.getVisibility() == 8 || paramConstraintWidget instanceof Guideline || paramConstraintWidget instanceof Barrier) {
      paramMeasure.measuredWidth = 0;
      paramMeasure.measuredHeight = 0;
      return false;
    } 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt2;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramMeasure.horizontalBehavior;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramMeasure.verticalBehavior == dimensionBehaviour2) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt1 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramInt2 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = paramInt1;
    if (paramInt1 != 0) {
      i = paramInt1;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        i = paramInt1;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          i = paramInt1;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (paramInt2 != 0 && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            i = 0;
          } 
        } 
      } 
    } 
    paramInt1 = paramInt2;
    if (paramInt2 != 0) {
      paramInt1 = paramInt2;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt1 = paramInt2;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt1 = paramInt2;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt1 = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      i = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt1 = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt1 == 0) {
        dimensionBehaviour1 = paramMeasure.verticalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt1 = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = dimensionBehaviour2;
        paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (i == 0) {
        dimensionBehaviour1 = paramMeasure.horizontalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt1 = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = dimensionBehaviour2;
        if (paramConstraintWidget.getDimensionRatioSide() == -1) {
          paramMeasure.verticalDimension = (int)(paramInt1 / paramConstraintWidget.getDimensionRatio());
        } else {
          paramMeasure.verticalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
        } 
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool = optimizeFor(64);
    addToSolver(paramLinearSystem, bool);
    int k = this.mChildren.size();
    int i = 0;
    int j = i;
    while (i < k) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        j = 1; 
      i++;
    } 
    if (j != 0)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    this.widgetsToAdd.clear();
    for (i = 0; i < k; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        if (constraintWidget instanceof VirtualLayout) {
          this.widgetsToAdd.add(constraintWidget);
        } else {
          constraintWidget.addToSolver(paramLinearSystem, bool);
        }  
    } 
    while (this.widgetsToAdd.size() > 0) {
      i = this.widgetsToAdd.size();
      for (VirtualLayout virtualLayout : this.widgetsToAdd) {
        if (virtualLayout.contains(this.widgetsToAdd)) {
          virtualLayout.addToSolver(paramLinearSystem, bool);
          this.widgetsToAdd.remove(virtualLayout);
          break;
        } 
      } 
      if (i == this.widgetsToAdd.size()) {
        Iterator<ConstraintWidget> iterator = this.widgetsToAdd.iterator();
        while (iterator.hasNext())
          ((ConstraintWidget)iterator.next()).addToSolver(paramLinearSystem, bool); 
        this.widgetsToAdd.clear();
      } 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool);
      } 
    } else {
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour[] arrayOfDimensionBehaviour = constraintWidget.mListDimensionBehaviors;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[1];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool);
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<Guideline> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)constraintWidget;
        if (guideline.getOrientation() == 0)
          arrayList.add(guideline); 
      } 
    } 
    return arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<Guideline> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)constraintWidget;
        if (guideline.getOrientation() == 1)
          arrayList.add(guideline); 
      } 
    } 
    return arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #8
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: astore #17
    //   53: aload #17
    //   55: iconst_1
    //   56: aaload
    //   57: astore #16
    //   59: aload #17
    //   61: iconst_0
    //   62: aaload
    //   63: astore #17
    //   65: aload_0
    //   66: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   69: astore #18
    //   71: aload #18
    //   73: ifnull -> 88
    //   76: aload #18
    //   78: aload #18
    //   80: getfield layouts : J
    //   83: lconst_1
    //   84: ladd
    //   85: putfield layouts : J
    //   88: aload_0
    //   89: getfield pass : I
    //   92: ifne -> 274
    //   95: aload_0
    //   96: getfield mOptimizationLevel : I
    //   99: iconst_1
    //   100: invokestatic enabled : (II)Z
    //   103: ifeq -> 274
    //   106: aload_0
    //   107: aload_0
    //   108: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   111: invokestatic solvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V
    //   114: iconst_0
    //   115: istore_1
    //   116: iload_1
    //   117: iload #8
    //   119: if_icmpge -> 274
    //   122: aload_0
    //   123: getfield mChildren : Ljava/util/ArrayList;
    //   126: iload_1
    //   127: invokevirtual get : (I)Ljava/lang/Object;
    //   130: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   133: astore #18
    //   135: aload #18
    //   137: invokevirtual isMeasureRequested : ()Z
    //   140: ifeq -> 267
    //   143: aload #18
    //   145: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   148: ifne -> 267
    //   151: aload #18
    //   153: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   156: ifne -> 267
    //   159: aload #18
    //   161: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   164: ifne -> 267
    //   167: aload #18
    //   169: invokevirtual isInVirtualLayout : ()Z
    //   172: ifne -> 267
    //   175: aload #18
    //   177: iconst_0
    //   178: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   181: astore #19
    //   183: aload #18
    //   185: iconst_1
    //   186: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   189: astore #20
    //   191: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   194: astore #21
    //   196: aload #19
    //   198: aload #21
    //   200: if_acmpne -> 234
    //   203: aload #18
    //   205: getfield mMatchConstraintDefaultWidth : I
    //   208: iconst_1
    //   209: if_icmpeq -> 234
    //   212: aload #20
    //   214: aload #21
    //   216: if_acmpne -> 234
    //   219: aload #18
    //   221: getfield mMatchConstraintDefaultHeight : I
    //   224: iconst_1
    //   225: if_icmpeq -> 234
    //   228: iconst_1
    //   229: istore #4
    //   231: goto -> 237
    //   234: iconst_0
    //   235: istore #4
    //   237: iload #4
    //   239: ifne -> 267
    //   242: new androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure
    //   245: dup
    //   246: invokespecial <init> : ()V
    //   249: astore #19
    //   251: iconst_0
    //   252: aload #18
    //   254: aload_0
    //   255: getfield mMeasurer : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   258: aload #19
    //   260: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   263: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   266: pop
    //   267: iload_1
    //   268: iconst_1
    //   269: iadd
    //   270: istore_1
    //   271: goto -> 116
    //   274: iload #8
    //   276: iconst_2
    //   277: if_icmple -> 411
    //   280: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   283: astore #18
    //   285: aload #17
    //   287: aload #18
    //   289: if_acmpeq -> 299
    //   292: aload #16
    //   294: aload #18
    //   296: if_acmpne -> 411
    //   299: aload_0
    //   300: getfield mOptimizationLevel : I
    //   303: sipush #1024
    //   306: invokestatic enabled : (II)Z
    //   309: ifeq -> 411
    //   312: aload_0
    //   313: aload_0
    //   314: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   317: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   320: ifeq -> 411
    //   323: iload_2
    //   324: istore_1
    //   325: aload #17
    //   327: aload #18
    //   329: if_acmpne -> 364
    //   332: iload_2
    //   333: aload_0
    //   334: invokevirtual getWidth : ()I
    //   337: if_icmpge -> 359
    //   340: iload_2
    //   341: ifle -> 359
    //   344: aload_0
    //   345: iload_2
    //   346: invokevirtual setWidth : (I)V
    //   349: aload_0
    //   350: iconst_1
    //   351: putfield mWidthMeasuredTooSmall : Z
    //   354: iload_2
    //   355: istore_1
    //   356: goto -> 364
    //   359: aload_0
    //   360: invokevirtual getWidth : ()I
    //   363: istore_1
    //   364: iload_3
    //   365: istore_2
    //   366: aload #16
    //   368: aload #18
    //   370: if_acmpne -> 405
    //   373: iload_3
    //   374: aload_0
    //   375: invokevirtual getHeight : ()I
    //   378: if_icmpge -> 400
    //   381: iload_3
    //   382: ifle -> 400
    //   385: aload_0
    //   386: iload_3
    //   387: invokevirtual setHeight : (I)V
    //   390: aload_0
    //   391: iconst_1
    //   392: putfield mHeightMeasuredTooSmall : Z
    //   395: iload_3
    //   396: istore_2
    //   397: goto -> 405
    //   400: aload_0
    //   401: invokevirtual getHeight : ()I
    //   404: istore_2
    //   405: iconst_1
    //   406: istore #9
    //   408: goto -> 418
    //   411: iload_2
    //   412: istore_1
    //   413: iconst_0
    //   414: istore #9
    //   416: iload_3
    //   417: istore_2
    //   418: aload_0
    //   419: bipush #64
    //   421: invokevirtual optimizeFor : (I)Z
    //   424: ifne -> 445
    //   427: aload_0
    //   428: sipush #128
    //   431: invokevirtual optimizeFor : (I)Z
    //   434: ifeq -> 440
    //   437: goto -> 445
    //   440: iconst_0
    //   441: istore_3
    //   442: goto -> 447
    //   445: iconst_1
    //   446: istore_3
    //   447: aload_0
    //   448: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   451: astore #18
    //   453: aload #18
    //   455: iconst_0
    //   456: putfield graphOptimizer : Z
    //   459: aload #18
    //   461: iconst_0
    //   462: putfield newgraphOptimizer : Z
    //   465: aload_0
    //   466: getfield mOptimizationLevel : I
    //   469: ifeq -> 482
    //   472: iload_3
    //   473: ifeq -> 482
    //   476: aload #18
    //   478: iconst_1
    //   479: putfield newgraphOptimizer : Z
    //   482: aload_0
    //   483: getfield mChildren : Ljava/util/ArrayList;
    //   486: astore #18
    //   488: aload_0
    //   489: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   492: astore #19
    //   494: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   497: astore #20
    //   499: aload #19
    //   501: aload #20
    //   503: if_acmpeq -> 523
    //   506: aload_0
    //   507: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   510: aload #20
    //   512: if_acmpne -> 518
    //   515: goto -> 523
    //   518: iconst_0
    //   519: istore_3
    //   520: goto -> 525
    //   523: iconst_1
    //   524: istore_3
    //   525: aload_0
    //   526: invokespecial resetChains : ()V
    //   529: iconst_0
    //   530: istore #4
    //   532: iload #4
    //   534: iload #8
    //   536: if_icmpge -> 578
    //   539: aload_0
    //   540: getfield mChildren : Ljava/util/ArrayList;
    //   543: iload #4
    //   545: invokevirtual get : (I)Ljava/lang/Object;
    //   548: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   551: astore #19
    //   553: aload #19
    //   555: instanceof androidx/constraintlayout/core/widgets/WidgetContainer
    //   558: ifeq -> 569
    //   561: aload #19
    //   563: checkcast androidx/constraintlayout/core/widgets/WidgetContainer
    //   566: invokevirtual layout : ()V
    //   569: iload #4
    //   571: iconst_1
    //   572: iadd
    //   573: istore #4
    //   575: goto -> 532
    //   578: aload_0
    //   579: bipush #64
    //   581: invokevirtual optimizeFor : (I)Z
    //   584: istore #15
    //   586: iconst_0
    //   587: istore #4
    //   589: iconst_1
    //   590: istore #10
    //   592: iload #10
    //   594: ifeq -> 1615
    //   597: iload #4
    //   599: iconst_1
    //   600: iadd
    //   601: istore #7
    //   603: iload #10
    //   605: istore #11
    //   607: aload_0
    //   608: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   611: invokevirtual reset : ()V
    //   614: iload #10
    //   616: istore #11
    //   618: aload_0
    //   619: invokespecial resetChains : ()V
    //   622: iload #10
    //   624: istore #11
    //   626: aload_0
    //   627: aload_0
    //   628: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   631: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   634: iconst_0
    //   635: istore #4
    //   637: iload #4
    //   639: iload #8
    //   641: if_icmpge -> 676
    //   644: iload #10
    //   646: istore #11
    //   648: aload_0
    //   649: getfield mChildren : Ljava/util/ArrayList;
    //   652: iload #4
    //   654: invokevirtual get : (I)Ljava/lang/Object;
    //   657: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   660: aload_0
    //   661: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   664: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   667: iload #4
    //   669: iconst_1
    //   670: iadd
    //   671: istore #4
    //   673: goto -> 637
    //   676: iload #10
    //   678: istore #11
    //   680: aload_0
    //   681: aload_0
    //   682: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   685: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/core/LinearSystem;)Z
    //   688: istore #10
    //   690: iload #10
    //   692: istore #11
    //   694: aload_0
    //   695: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   698: astore #19
    //   700: aload #19
    //   702: ifnull -> 755
    //   705: iload #10
    //   707: istore #11
    //   709: aload #19
    //   711: invokevirtual get : ()Ljava/lang/Object;
    //   714: ifnull -> 755
    //   717: iload #10
    //   719: istore #11
    //   721: aload_0
    //   722: aload_0
    //   723: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   726: invokevirtual get : ()Ljava/lang/Object;
    //   729: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   732: aload_0
    //   733: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   736: aload_0
    //   737: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   740: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   743: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   746: iload #10
    //   748: istore #11
    //   750: aload_0
    //   751: aconst_null
    //   752: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   755: iload #10
    //   757: istore #11
    //   759: aload_0
    //   760: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   763: astore #19
    //   765: aload #19
    //   767: ifnull -> 820
    //   770: iload #10
    //   772: istore #11
    //   774: aload #19
    //   776: invokevirtual get : ()Ljava/lang/Object;
    //   779: ifnull -> 820
    //   782: iload #10
    //   784: istore #11
    //   786: aload_0
    //   787: aload_0
    //   788: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   791: invokevirtual get : ()Ljava/lang/Object;
    //   794: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   797: aload_0
    //   798: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   801: aload_0
    //   802: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   805: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   808: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   811: iload #10
    //   813: istore #11
    //   815: aload_0
    //   816: aconst_null
    //   817: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   820: iload #10
    //   822: istore #11
    //   824: aload_0
    //   825: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   828: astore #19
    //   830: aload #19
    //   832: ifnull -> 885
    //   835: iload #10
    //   837: istore #11
    //   839: aload #19
    //   841: invokevirtual get : ()Ljava/lang/Object;
    //   844: ifnull -> 885
    //   847: iload #10
    //   849: istore #11
    //   851: aload_0
    //   852: aload_0
    //   853: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   856: invokevirtual get : ()Ljava/lang/Object;
    //   859: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   862: aload_0
    //   863: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   866: aload_0
    //   867: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   870: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   873: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   876: iload #10
    //   878: istore #11
    //   880: aload_0
    //   881: aconst_null
    //   882: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   885: iload #10
    //   887: istore #11
    //   889: aload_0
    //   890: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   893: astore #19
    //   895: aload #19
    //   897: ifnull -> 950
    //   900: iload #10
    //   902: istore #11
    //   904: aload #19
    //   906: invokevirtual get : ()Ljava/lang/Object;
    //   909: ifnull -> 950
    //   912: iload #10
    //   914: istore #11
    //   916: aload_0
    //   917: aload_0
    //   918: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   921: invokevirtual get : ()Ljava/lang/Object;
    //   924: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   927: aload_0
    //   928: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   931: aload_0
    //   932: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   935: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   938: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   941: iload #10
    //   943: istore #11
    //   945: aload_0
    //   946: aconst_null
    //   947: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   950: iload #10
    //   952: istore #11
    //   954: iload #10
    //   956: ifeq -> 1025
    //   959: iload #10
    //   961: istore #11
    //   963: aload_0
    //   964: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   967: invokevirtual minimize : ()V
    //   970: iload #10
    //   972: istore #11
    //   974: goto -> 1025
    //   977: astore #19
    //   979: aload #19
    //   981: invokevirtual printStackTrace : ()V
    //   984: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   987: astore #20
    //   989: new java/lang/StringBuilder
    //   992: dup
    //   993: invokespecial <init> : ()V
    //   996: astore #21
    //   998: aload #21
    //   1000: ldc_w 'EXCEPTION : '
    //   1003: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: aload #21
    //   1009: aload #19
    //   1011: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1014: pop
    //   1015: aload #20
    //   1017: aload #21
    //   1019: invokevirtual toString : ()Ljava/lang/String;
    //   1022: invokevirtual println : (Ljava/lang/String;)V
    //   1025: iload #11
    //   1027: ifeq -> 1046
    //   1030: aload_0
    //   1031: aload_0
    //   1032: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1035: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1038: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/core/LinearSystem;[Z)Z
    //   1041: istore #10
    //   1043: goto -> 1099
    //   1046: aload_0
    //   1047: aload_0
    //   1048: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1051: iload #15
    //   1053: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1056: iconst_0
    //   1057: istore #4
    //   1059: iload #4
    //   1061: iload #8
    //   1063: if_icmpge -> 1096
    //   1066: aload_0
    //   1067: getfield mChildren : Ljava/util/ArrayList;
    //   1070: iload #4
    //   1072: invokevirtual get : (I)Ljava/lang/Object;
    //   1075: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1078: aload_0
    //   1079: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1082: iload #15
    //   1084: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1087: iload #4
    //   1089: iconst_1
    //   1090: iadd
    //   1091: istore #4
    //   1093: goto -> 1059
    //   1096: iconst_0
    //   1097: istore #10
    //   1099: iload_3
    //   1100: ifeq -> 1327
    //   1103: iload #7
    //   1105: bipush #8
    //   1107: if_icmpge -> 1327
    //   1110: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1113: iconst_2
    //   1114: baload
    //   1115: ifeq -> 1327
    //   1118: iconst_0
    //   1119: istore #5
    //   1121: iconst_0
    //   1122: istore #4
    //   1124: iconst_0
    //   1125: istore #6
    //   1127: iload #5
    //   1129: iload #8
    //   1131: if_icmpge -> 1193
    //   1134: aload_0
    //   1135: getfield mChildren : Ljava/util/ArrayList;
    //   1138: iload #5
    //   1140: invokevirtual get : (I)Ljava/lang/Object;
    //   1143: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1146: astore #19
    //   1148: iload #6
    //   1150: aload #19
    //   1152: getfield mX : I
    //   1155: aload #19
    //   1157: invokevirtual getWidth : ()I
    //   1160: iadd
    //   1161: invokestatic max : (II)I
    //   1164: istore #6
    //   1166: iload #4
    //   1168: aload #19
    //   1170: getfield mY : I
    //   1173: aload #19
    //   1175: invokevirtual getHeight : ()I
    //   1178: iadd
    //   1179: invokestatic max : (II)I
    //   1182: istore #4
    //   1184: iload #5
    //   1186: iconst_1
    //   1187: iadd
    //   1188: istore #5
    //   1190: goto -> 1127
    //   1193: aload_0
    //   1194: getfield mMinWidth : I
    //   1197: iload #6
    //   1199: invokestatic max : (II)I
    //   1202: istore #5
    //   1204: aload_0
    //   1205: getfield mMinHeight : I
    //   1208: iload #4
    //   1210: invokestatic max : (II)I
    //   1213: istore #4
    //   1215: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1218: astore #19
    //   1220: iload #9
    //   1222: istore #12
    //   1224: iload #10
    //   1226: istore #11
    //   1228: aload #17
    //   1230: aload #19
    //   1232: if_acmpne -> 1272
    //   1235: iload #9
    //   1237: istore #12
    //   1239: iload #10
    //   1241: istore #11
    //   1243: aload_0
    //   1244: invokevirtual getWidth : ()I
    //   1247: iload #5
    //   1249: if_icmpge -> 1272
    //   1252: aload_0
    //   1253: iload #5
    //   1255: invokevirtual setWidth : (I)V
    //   1258: aload_0
    //   1259: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1262: iconst_0
    //   1263: aload #19
    //   1265: aastore
    //   1266: iconst_1
    //   1267: istore #12
    //   1269: iconst_1
    //   1270: istore #11
    //   1272: iload #12
    //   1274: istore #9
    //   1276: iload #11
    //   1278: istore #10
    //   1280: aload #16
    //   1282: aload #19
    //   1284: if_acmpne -> 1327
    //   1287: iload #12
    //   1289: istore #9
    //   1291: iload #11
    //   1293: istore #10
    //   1295: aload_0
    //   1296: invokevirtual getHeight : ()I
    //   1299: iload #4
    //   1301: if_icmpge -> 1327
    //   1304: aload_0
    //   1305: iload #4
    //   1307: invokevirtual setHeight : (I)V
    //   1310: aload_0
    //   1311: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1314: iconst_1
    //   1315: aload #19
    //   1317: aastore
    //   1318: iconst_1
    //   1319: istore #9
    //   1321: iconst_1
    //   1322: istore #10
    //   1324: goto -> 1327
    //   1327: aload_0
    //   1328: getfield mMinWidth : I
    //   1331: aload_0
    //   1332: invokevirtual getWidth : ()I
    //   1335: invokestatic max : (II)I
    //   1338: istore #4
    //   1340: iload #4
    //   1342: aload_0
    //   1343: invokevirtual getWidth : ()I
    //   1346: if_icmple -> 1370
    //   1349: aload_0
    //   1350: iload #4
    //   1352: invokevirtual setWidth : (I)V
    //   1355: aload_0
    //   1356: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1359: iconst_0
    //   1360: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1363: aastore
    //   1364: iconst_1
    //   1365: istore #9
    //   1367: iconst_1
    //   1368: istore #10
    //   1370: aload_0
    //   1371: getfield mMinHeight : I
    //   1374: aload_0
    //   1375: invokevirtual getHeight : ()I
    //   1378: invokestatic max : (II)I
    //   1381: istore #4
    //   1383: iload #4
    //   1385: aload_0
    //   1386: invokevirtual getHeight : ()I
    //   1389: if_icmple -> 1417
    //   1392: aload_0
    //   1393: iload #4
    //   1395: invokevirtual setHeight : (I)V
    //   1398: aload_0
    //   1399: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1402: iconst_1
    //   1403: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1406: aastore
    //   1407: iconst_1
    //   1408: istore #9
    //   1410: iload #9
    //   1412: istore #10
    //   1414: goto -> 1417
    //   1417: iload #9
    //   1419: istore #14
    //   1421: iload #10
    //   1423: istore #12
    //   1425: iload #9
    //   1427: ifne -> 1587
    //   1430: aload_0
    //   1431: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1434: iconst_0
    //   1435: aaload
    //   1436: astore #19
    //   1438: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1441: astore #20
    //   1443: iload #9
    //   1445: istore #13
    //   1447: iload #10
    //   1449: istore #11
    //   1451: aload #19
    //   1453: aload #20
    //   1455: if_acmpne -> 1512
    //   1458: iload #9
    //   1460: istore #13
    //   1462: iload #10
    //   1464: istore #11
    //   1466: iload_1
    //   1467: ifle -> 1512
    //   1470: iload #9
    //   1472: istore #13
    //   1474: iload #10
    //   1476: istore #11
    //   1478: aload_0
    //   1479: invokevirtual getWidth : ()I
    //   1482: iload_1
    //   1483: if_icmple -> 1512
    //   1486: aload_0
    //   1487: iconst_1
    //   1488: putfield mWidthMeasuredTooSmall : Z
    //   1491: aload_0
    //   1492: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1495: iconst_0
    //   1496: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1499: aastore
    //   1500: aload_0
    //   1501: iload_1
    //   1502: invokevirtual setWidth : (I)V
    //   1505: iconst_1
    //   1506: istore #13
    //   1508: iload #13
    //   1510: istore #11
    //   1512: iload #13
    //   1514: istore #14
    //   1516: iload #11
    //   1518: istore #12
    //   1520: aload_0
    //   1521: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1524: iconst_1
    //   1525: aaload
    //   1526: aload #20
    //   1528: if_acmpne -> 1587
    //   1531: iload #13
    //   1533: istore #14
    //   1535: iload #11
    //   1537: istore #12
    //   1539: iload_2
    //   1540: ifle -> 1587
    //   1543: iload #13
    //   1545: istore #14
    //   1547: iload #11
    //   1549: istore #12
    //   1551: aload_0
    //   1552: invokevirtual getHeight : ()I
    //   1555: iload_2
    //   1556: if_icmple -> 1587
    //   1559: aload_0
    //   1560: iconst_1
    //   1561: putfield mHeightMeasuredTooSmall : Z
    //   1564: aload_0
    //   1565: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1568: iconst_1
    //   1569: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1572: aastore
    //   1573: aload_0
    //   1574: iload_2
    //   1575: invokevirtual setHeight : (I)V
    //   1578: iconst_1
    //   1579: istore #10
    //   1581: iconst_1
    //   1582: istore #9
    //   1584: goto -> 1595
    //   1587: iload #14
    //   1589: istore #9
    //   1591: iload #12
    //   1593: istore #10
    //   1595: iload #7
    //   1597: bipush #8
    //   1599: if_icmple -> 1608
    //   1602: iconst_0
    //   1603: istore #10
    //   1605: goto -> 1608
    //   1608: iload #7
    //   1610: istore #4
    //   1612: goto -> 592
    //   1615: aload_0
    //   1616: aload #18
    //   1618: putfield mChildren : Ljava/util/ArrayList;
    //   1621: iload #9
    //   1623: ifeq -> 1644
    //   1626: aload_0
    //   1627: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1630: astore #18
    //   1632: aload #18
    //   1634: iconst_0
    //   1635: aload #17
    //   1637: aastore
    //   1638: aload #18
    //   1640: iconst_1
    //   1641: aload #16
    //   1643: aastore
    //   1644: aload_0
    //   1645: aload_0
    //   1646: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1649: invokevirtual getCache : ()Landroidx/constraintlayout/core/Cache;
    //   1652: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/core/Cache;)V
    //   1655: return
    // Exception table:
    //   from	to	target	type
    //   607	614	977	java/lang/Exception
    //   618	622	977	java/lang/Exception
    //   626	634	977	java/lang/Exception
    //   648	667	977	java/lang/Exception
    //   680	690	977	java/lang/Exception
    //   694	700	977	java/lang/Exception
    //   709	717	977	java/lang/Exception
    //   721	746	977	java/lang/Exception
    //   750	755	977	java/lang/Exception
    //   759	765	977	java/lang/Exception
    //   774	782	977	java/lang/Exception
    //   786	811	977	java/lang/Exception
    //   815	820	977	java/lang/Exception
    //   824	830	977	java/lang/Exception
    //   839	847	977	java/lang/Exception
    //   851	876	977	java/lang/Exception
    //   880	885	977	java/lang/Exception
    //   889	895	977	java/lang/Exception
    //   904	912	977	java/lang/Exception
    //   916	941	977	java/lang/Exception
    //   945	950	977	java/lang/Exception
    //   963	970	977	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setPass(int paramInt) {
    this.pass = paramInt;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public boolean updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool1 = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.updateFromSolver(paramLinearSystem, bool1);
      if (constraintWidget.hasDimensionOverride())
        bool = true; 
      i++;
    } 
    return bool;
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */