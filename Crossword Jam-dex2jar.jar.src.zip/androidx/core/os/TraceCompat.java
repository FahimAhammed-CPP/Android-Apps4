package androidx.core.os;

import android.os.Build;
import android.os.Trace;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.lang.reflect.Method;

@Deprecated
public final class TraceCompat {
  private static final String TAG = "TraceCompat";
  
  private static Method sAsyncTraceBeginMethod;
  
  private static Method sAsyncTraceEndMethod;
  
  private static Method sIsTagEnabledMethod;
  
  private static Method sTraceCounterMethod;
  
  private static long sTraceTagApp;
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 18 && i < 29)
      try {
        sTraceTagApp = Trace.class.getField("TRACE_TAG_APP").getLong(null);
        Class<long> clazz = long.class;
        sIsTagEnabledMethod = Trace.class.getMethod("isTagEnabled", new Class[] { clazz });
        Class<int> clazz1 = int.class;
        sAsyncTraceBeginMethod = Trace.class.getMethod("asyncTraceBegin", new Class[] { clazz, String.class, clazz1 });
        sAsyncTraceEndMethod = Trace.class.getMethod("asyncTraceEnd", new Class[] { clazz, String.class, clazz1 });
        sTraceCounterMethod = Trace.class.getMethod("traceCounter", new Class[] { clazz, String.class, clazz1 });
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void beginAsyncSection(@NonNull String paramString, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      Api29Impl.beginAsyncSection(paramString, paramInt);
      return;
    } 
    if (i >= 18)
      try {
        sAsyncTraceBeginMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void beginSection(@NonNull String paramString) {
    if (Build.VERSION.SDK_INT >= 18)
      Api18Impl.beginSection(paramString); 
  }
  
  public static void endAsyncSection(@NonNull String paramString, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      Api29Impl.endAsyncSection(paramString, paramInt);
      return;
    } 
    if (i >= 18)
      try {
        sAsyncTraceEndMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void endSection() {
    if (Build.VERSION.SDK_INT >= 18)
      Api18Impl.endSection(); 
  }
  
  public static boolean isEnabled() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29)
      return Api29Impl.isEnabled(); 
    if (i >= 18)
      try {
        return ((Boolean)sIsTagEnabledMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp) })).booleanValue();
      } catch (Exception exception) {
        return false;
      }  
    return false;
  }
  
  public static void setCounter(@NonNull String paramString, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      Api29Impl.setCounter(paramString, paramInt);
      return;
    } 
    if (i >= 18)
      try {
        sTraceCounterMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  @RequiresApi(18)
  static class Api18Impl {
    @DoNotInline
    static void beginSection(String param1String) {
      Trace.beginSection(param1String);
    }
    
    @DoNotInline
    static void endSection() {
      Trace.endSection();
    }
  }
  
  @RequiresApi(29)
  static class Api29Impl {
    @DoNotInline
    static void beginAsyncSection(String param1String, int param1Int) {
      Trace.beginAsyncSection(param1String, param1Int);
    }
    
    @DoNotInline
    static void endAsyncSection(String param1String, int param1Int) {
      Trace.endAsyncSection(param1String, param1Int);
    }
    
    @DoNotInline
    static boolean isEnabled() {
      return Trace.isEnabled();
    }
    
    @DoNotInline
    static void setCounter(String param1String, long param1Long) {
      Trace.setCounter(param1String, param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\os\TraceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */