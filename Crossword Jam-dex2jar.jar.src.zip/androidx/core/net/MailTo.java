package androidx.core.net;

import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.Preconditions;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MailTo {
  private static final String BCC = "bcc";
  
  private static final String BODY = "body";
  
  private static final String CC = "cc";
  
  private static final String MAILTO = "mailto";
  
  public static final String MAILTO_SCHEME = "mailto:";
  
  private static final String SUBJECT = "subject";
  
  private static final String TO = "to";
  
  private HashMap<String, String> mHeaders = new HashMap<String, String>();
  
  public static boolean isMailTo(@Nullable Uri paramUri) {
    return (paramUri != null && "mailto".equals(paramUri.getScheme()));
  }
  
  public static boolean isMailTo(@Nullable String paramString) {
    return (paramString != null && paramString.startsWith("mailto:"));
  }
  
  @NonNull
  public static MailTo parse(@NonNull Uri paramUri) throws ParseException {
    return parse(paramUri.toString());
  }
  
  @NonNull
  public static MailTo parse(@NonNull String paramString) throws ParseException {
    Preconditions.checkNotNull(paramString);
    if (isMailTo(paramString)) {
      int i = paramString.indexOf('#');
      String str1 = paramString;
      if (i != -1)
        str1 = paramString.substring(0, i); 
      i = str1.indexOf('?');
      if (i == -1) {
        paramString = Uri.decode(str1.substring(7));
        str1 = null;
      } else {
        paramString = Uri.decode(str1.substring(7, i));
        str1 = str1.substring(i + 1);
      } 
      MailTo mailTo = new MailTo();
      if (str1 != null) {
        String[] arrayOfString = str1.split("&");
        int j = arrayOfString.length;
        for (i = 0; i < j; i++) {
          String[] arrayOfString1 = arrayOfString[i].split("=", 2);
          if (arrayOfString1.length != 0) {
            String str = Uri.decode(arrayOfString1[0]).toLowerCase(Locale.ROOT);
            if (arrayOfString1.length > 1) {
              String str3 = Uri.decode(arrayOfString1[1]);
            } else {
              arrayOfString1 = null;
            } 
            mailTo.mHeaders.put(str, (String)arrayOfString1);
          } 
        } 
      } 
      String str2 = mailTo.getTo();
      str1 = paramString;
      if (str2 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString);
        stringBuilder.append(", ");
        stringBuilder.append(str2);
        str1 = stringBuilder.toString();
      } 
      mailTo.mHeaders.put("to", str1);
      return mailTo;
    } 
    throw new ParseException("Not a mailto scheme");
  }
  
  @Nullable
  public String getBcc() {
    return this.mHeaders.get("bcc");
  }
  
  @Nullable
  public String getBody() {
    return this.mHeaders.get("body");
  }
  
  @Nullable
  public String getCc() {
    return this.mHeaders.get("cc");
  }
  
  @Nullable
  public Map<String, String> getHeaders() {
    return this.mHeaders;
  }
  
  @Nullable
  public String getSubject() {
    return this.mHeaders.get("subject");
  }
  
  @Nullable
  public String getTo() {
    return this.mHeaders.get("to");
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("mailto:");
    stringBuilder.append('?');
    for (Map.Entry<String, String> entry : this.mHeaders.entrySet()) {
      stringBuilder.append(Uri.encode((String)entry.getKey()));
      stringBuilder.append('=');
      stringBuilder.append(Uri.encode((String)entry.getValue()));
      stringBuilder.append('&');
    } 
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\net\MailTo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */