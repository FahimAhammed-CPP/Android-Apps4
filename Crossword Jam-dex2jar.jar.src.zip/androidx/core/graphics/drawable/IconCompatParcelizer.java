package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.annotation.RestrictTo;
import androidx.versionedparcelable.VersionedParcel;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public class IconCompatParcelizer {
  public static IconCompat read(VersionedParcel paramVersionedParcel) {
    IconCompat iconCompat = new IconCompat();
    iconCompat.mType = paramVersionedParcel.readInt(iconCompat.mType, 1);
    iconCompat.mData = paramVersionedParcel.readByteArray(iconCompat.mData, 2);
    iconCompat.mParcelable = paramVersionedParcel.readParcelable(iconCompat.mParcelable, 3);
    iconCompat.mInt1 = paramVersionedParcel.readInt(iconCompat.mInt1, 4);
    iconCompat.mInt2 = paramVersionedParcel.readInt(iconCompat.mInt2, 5);
    iconCompat.mTintList = (ColorStateList)paramVersionedParcel.readParcelable((Parcelable)iconCompat.mTintList, 6);
    iconCompat.mTintModeStr = paramVersionedParcel.readString(iconCompat.mTintModeStr, 7);
    iconCompat.mString1 = paramVersionedParcel.readString(iconCompat.mString1, 8);
    iconCompat.onPostParceling();
    return iconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, VersionedParcel paramVersionedParcel) {
    paramVersionedParcel.setSerializationFlags(true, true);
    paramIconCompat.onPreParceling(paramVersionedParcel.isStream());
    int i = paramIconCompat.mType;
    if (-1 != i)
      paramVersionedParcel.writeInt(i, 1); 
    byte[] arrayOfByte = paramIconCompat.mData;
    if (arrayOfByte != null)
      paramVersionedParcel.writeByteArray(arrayOfByte, 2); 
    Parcelable parcelable = paramIconCompat.mParcelable;
    if (parcelable != null)
      paramVersionedParcel.writeParcelable(parcelable, 3); 
    i = paramIconCompat.mInt1;
    if (i != 0)
      paramVersionedParcel.writeInt(i, 4); 
    i = paramIconCompat.mInt2;
    if (i != 0)
      paramVersionedParcel.writeInt(i, 5); 
    ColorStateList colorStateList = paramIconCompat.mTintList;
    if (colorStateList != null)
      paramVersionedParcel.writeParcelable((Parcelable)colorStateList, 6); 
    String str2 = paramIconCompat.mTintModeStr;
    if (str2 != null)
      paramVersionedParcel.writeString(str2, 7); 
    String str1 = paramIconCompat.mString1;
    if (str1 != null)
      paramVersionedParcel.writeString(str1, 8); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */