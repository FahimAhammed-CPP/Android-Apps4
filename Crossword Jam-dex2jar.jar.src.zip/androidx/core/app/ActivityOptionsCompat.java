package androidx.core.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.Pair;

public class ActivityOptionsCompat {
  public static final String EXTRA_USAGE_TIME_REPORT = "android.activity.usage_time";
  
  public static final String EXTRA_USAGE_TIME_REPORT_PACKAGES = "android.usage_time_packages";
  
  @NonNull
  public static ActivityOptionsCompat makeBasic() {
    return (Build.VERSION.SDK_INT >= 23) ? new ActivityOptionsCompatImpl(Api23Impl.makeBasic()) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeClipRevealAnimation(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (Build.VERSION.SDK_INT >= 23) ? new ActivityOptionsCompatImpl(Api23Impl.makeClipRevealAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4)) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeCustomAnimation(@NonNull Context paramContext, int paramInt1, int paramInt2) {
    return (Build.VERSION.SDK_INT >= 16) ? new ActivityOptionsCompatImpl(Api16Impl.makeCustomAnimation(paramContext, paramInt1, paramInt2)) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeScaleUpAnimation(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (Build.VERSION.SDK_INT >= 16) ? new ActivityOptionsCompatImpl(Api16Impl.makeScaleUpAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4)) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeSceneTransitionAnimation(@NonNull Activity paramActivity, @NonNull View paramView, @NonNull String paramString) {
    return (Build.VERSION.SDK_INT >= 21) ? new ActivityOptionsCompatImpl(Api21Impl.makeSceneTransitionAnimation(paramActivity, paramView, paramString)) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeSceneTransitionAnimation(@NonNull Activity paramActivity, @Nullable Pair<View, String>... paramVarArgs) {
    if (Build.VERSION.SDK_INT >= 21) {
      Pair[] arrayOfPair = null;
      if (paramVarArgs != null) {
        Pair[] arrayOfPair1 = new Pair[paramVarArgs.length];
        int i = 0;
        while (true) {
          arrayOfPair = arrayOfPair1;
          if (i < paramVarArgs.length) {
            arrayOfPair1[i] = Pair.create((paramVarArgs[i]).first, (paramVarArgs[i]).second);
            i++;
            continue;
          } 
          break;
        } 
      } 
      return new ActivityOptionsCompatImpl(Api21Impl.makeSceneTransitionAnimation(paramActivity, (Pair<View, String>[])arrayOfPair));
    } 
    return new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeTaskLaunchBehind() {
    return (Build.VERSION.SDK_INT >= 21) ? new ActivityOptionsCompatImpl(Api21Impl.makeTaskLaunchBehind()) : new ActivityOptionsCompat();
  }
  
  @NonNull
  public static ActivityOptionsCompat makeThumbnailScaleUpAnimation(@NonNull View paramView, @NonNull Bitmap paramBitmap, int paramInt1, int paramInt2) {
    return (Build.VERSION.SDK_INT >= 16) ? new ActivityOptionsCompatImpl(Api16Impl.makeThumbnailScaleUpAnimation(paramView, paramBitmap, paramInt1, paramInt2)) : new ActivityOptionsCompat();
  }
  
  @Nullable
  public Rect getLaunchBounds() {
    return null;
  }
  
  public void requestUsageTimeReport(@NonNull PendingIntent paramPendingIntent) {}
  
  @NonNull
  public ActivityOptionsCompat setLaunchBounds(@Nullable Rect paramRect) {
    return this;
  }
  
  @Nullable
  public Bundle toBundle() {
    return null;
  }
  
  public void update(@NonNull ActivityOptionsCompat paramActivityOptionsCompat) {}
  
  @RequiresApi(16)
  private static class ActivityOptionsCompatImpl extends ActivityOptionsCompat {
    private final ActivityOptions mActivityOptions;
    
    ActivityOptionsCompatImpl(ActivityOptions param1ActivityOptions) {
      this.mActivityOptions = param1ActivityOptions;
    }
    
    public Rect getLaunchBounds() {
      return (Build.VERSION.SDK_INT < 24) ? null : ActivityOptionsCompat.Api24Impl.getLaunchBounds(this.mActivityOptions);
    }
    
    public void requestUsageTimeReport(@NonNull PendingIntent param1PendingIntent) {
      if (Build.VERSION.SDK_INT >= 23)
        ActivityOptionsCompat.Api23Impl.requestUsageTimeReport(this.mActivityOptions, param1PendingIntent); 
    }
    
    @NonNull
    public ActivityOptionsCompat setLaunchBounds(@Nullable Rect param1Rect) {
      return (Build.VERSION.SDK_INT < 24) ? this : new ActivityOptionsCompatImpl(ActivityOptionsCompat.Api24Impl.setLaunchBounds(this.mActivityOptions, param1Rect));
    }
    
    public Bundle toBundle() {
      return this.mActivityOptions.toBundle();
    }
    
    public void update(@NonNull ActivityOptionsCompat param1ActivityOptionsCompat) {
      if (param1ActivityOptionsCompat instanceof ActivityOptionsCompatImpl) {
        param1ActivityOptionsCompat = param1ActivityOptionsCompat;
        this.mActivityOptions.update(((ActivityOptionsCompatImpl)param1ActivityOptionsCompat).mActivityOptions);
      } 
    }
  }
  
  @RequiresApi(16)
  static class Api16Impl {
    @DoNotInline
    static ActivityOptions makeCustomAnimation(Context param1Context, int param1Int1, int param1Int2) {
      return ActivityOptions.makeCustomAnimation(param1Context, param1Int1, param1Int2);
    }
    
    @DoNotInline
    static ActivityOptions makeScaleUpAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return ActivityOptions.makeScaleUpAnimation(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    @DoNotInline
    static ActivityOptions makeThumbnailScaleUpAnimation(View param1View, Bitmap param1Bitmap, int param1Int1, int param1Int2) {
      return ActivityOptions.makeThumbnailScaleUpAnimation(param1View, param1Bitmap, param1Int1, param1Int2);
    }
  }
  
  @RequiresApi(21)
  static class Api21Impl {
    @DoNotInline
    static ActivityOptions makeSceneTransitionAnimation(Activity param1Activity, View param1View, String param1String) {
      return ActivityOptions.makeSceneTransitionAnimation(param1Activity, param1View, param1String);
    }
    
    @SafeVarargs
    @DoNotInline
    static ActivityOptions makeSceneTransitionAnimation(Activity param1Activity, Pair<View, String>... param1VarArgs) {
      return ActivityOptions.makeSceneTransitionAnimation(param1Activity, (Pair[])param1VarArgs);
    }
    
    @DoNotInline
    static ActivityOptions makeTaskLaunchBehind() {
      return ActivityOptions.makeTaskLaunchBehind();
    }
  }
  
  @RequiresApi(23)
  static class Api23Impl {
    @DoNotInline
    static ActivityOptions makeBasic() {
      return ActivityOptions.makeBasic();
    }
    
    @DoNotInline
    static ActivityOptions makeClipRevealAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return ActivityOptions.makeClipRevealAnimation(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    @DoNotInline
    static void requestUsageTimeReport(ActivityOptions param1ActivityOptions, PendingIntent param1PendingIntent) {
      param1ActivityOptions.requestUsageTimeReport(param1PendingIntent);
    }
  }
  
  @RequiresApi(24)
  static class Api24Impl {
    @DoNotInline
    static Rect getLaunchBounds(ActivityOptions param1ActivityOptions) {
      return param1ActivityOptions.getLaunchBounds();
    }
    
    @DoNotInline
    static ActivityOptions setLaunchBounds(ActivityOptions param1ActivityOptions, Rect param1Rect) {
      return param1ActivityOptions.setLaunchBounds(param1Rect);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\app\ActivityOptionsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */