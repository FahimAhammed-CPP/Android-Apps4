package androidx.core.view;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContentInfo;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OnReceiveContentListener;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.annotation.DoNotInline;
import androidx.annotation.FloatRange;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.Px;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.collection.SimpleArrayMap;
import androidx.core.R;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.core.view.accessibility.AccessibilityNodeProviderCompat;
import androidx.core.view.accessibility.AccessibilityViewCommand;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class ViewCompat {
  private static final int[] ACCESSIBILITY_ACTIONS_RESOURCE_IDS;
  
  public static final int ACCESSIBILITY_LIVE_REGION_ASSERTIVE = 2;
  
  public static final int ACCESSIBILITY_LIVE_REGION_NONE = 0;
  
  public static final int ACCESSIBILITY_LIVE_REGION_POLITE = 1;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_AUTO = 0;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO = 2;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS = 4;
  
  public static final int IMPORTANT_FOR_ACCESSIBILITY_YES = 1;
  
  @Deprecated
  public static final int LAYER_TYPE_HARDWARE = 2;
  
  @Deprecated
  public static final int LAYER_TYPE_NONE = 0;
  
  @Deprecated
  public static final int LAYER_TYPE_SOFTWARE = 1;
  
  public static final int LAYOUT_DIRECTION_INHERIT = 2;
  
  public static final int LAYOUT_DIRECTION_LOCALE = 3;
  
  public static final int LAYOUT_DIRECTION_LTR = 0;
  
  public static final int LAYOUT_DIRECTION_RTL = 1;
  
  @Deprecated
  public static final int MEASURED_HEIGHT_STATE_SHIFT = 16;
  
  @Deprecated
  public static final int MEASURED_SIZE_MASK = 16777215;
  
  @Deprecated
  public static final int MEASURED_STATE_MASK = -16777216;
  
  @Deprecated
  public static final int MEASURED_STATE_TOO_SMALL = 16777216;
  
  private static final OnReceiveContentViewBehavior NO_OP_ON_RECEIVE_CONTENT_VIEW_BEHAVIOR;
  
  @Deprecated
  public static final int OVER_SCROLL_ALWAYS = 0;
  
  @Deprecated
  public static final int OVER_SCROLL_IF_CONTENT_SCROLLS = 1;
  
  @Deprecated
  public static final int OVER_SCROLL_NEVER = 2;
  
  public static final int SCROLL_AXIS_HORIZONTAL = 1;
  
  public static final int SCROLL_AXIS_NONE = 0;
  
  public static final int SCROLL_AXIS_VERTICAL = 2;
  
  public static final int SCROLL_INDICATOR_BOTTOM = 2;
  
  public static final int SCROLL_INDICATOR_END = 32;
  
  public static final int SCROLL_INDICATOR_LEFT = 4;
  
  public static final int SCROLL_INDICATOR_RIGHT = 8;
  
  public static final int SCROLL_INDICATOR_START = 16;
  
  public static final int SCROLL_INDICATOR_TOP = 1;
  
  private static final String TAG = "ViewCompat";
  
  public static final int TYPE_NON_TOUCH = 1;
  
  public static final int TYPE_TOUCH = 0;
  
  private static boolean sAccessibilityDelegateCheckFailed;
  
  private static Field sAccessibilityDelegateField;
  
  private static final AccessibilityPaneVisibilityManager sAccessibilityPaneVisibilityManager;
  
  private static Method sChildrenDrawingOrderMethod;
  
  private static Method sDispatchFinishTemporaryDetach;
  
  private static Method sDispatchStartTemporaryDetach;
  
  private static Field sMinHeightField;
  
  private static boolean sMinHeightFieldFetched;
  
  private static Field sMinWidthField;
  
  private static boolean sMinWidthFieldFetched;
  
  private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);
  
  private static boolean sTempDetachBound;
  
  private static ThreadLocal<Rect> sThreadLocalRect;
  
  private static WeakHashMap<View, String> sTransitionNameMap;
  
  private static WeakHashMap<View, ViewPropertyAnimatorCompat> sViewPropertyAnimatorMap = null;
  
  static {
    sAccessibilityDelegateCheckFailed = false;
    ACCESSIBILITY_ACTIONS_RESOURCE_IDS = new int[] { 
        R.id.accessibility_custom_action_0, R.id.accessibility_custom_action_1, R.id.accessibility_custom_action_2, R.id.accessibility_custom_action_3, R.id.accessibility_custom_action_4, R.id.accessibility_custom_action_5, R.id.accessibility_custom_action_6, R.id.accessibility_custom_action_7, R.id.accessibility_custom_action_8, R.id.accessibility_custom_action_9, 
        R.id.accessibility_custom_action_10, R.id.accessibility_custom_action_11, R.id.accessibility_custom_action_12, R.id.accessibility_custom_action_13, R.id.accessibility_custom_action_14, R.id.accessibility_custom_action_15, R.id.accessibility_custom_action_16, R.id.accessibility_custom_action_17, R.id.accessibility_custom_action_18, R.id.accessibility_custom_action_19, 
        R.id.accessibility_custom_action_20, R.id.accessibility_custom_action_21, R.id.accessibility_custom_action_22, R.id.accessibility_custom_action_23, R.id.accessibility_custom_action_24, R.id.accessibility_custom_action_25, R.id.accessibility_custom_action_26, R.id.accessibility_custom_action_27, R.id.accessibility_custom_action_28, R.id.accessibility_custom_action_29, 
        R.id.accessibility_custom_action_30, R.id.accessibility_custom_action_31 };
    NO_OP_ON_RECEIVE_CONTENT_VIEW_BEHAVIOR = (OnReceiveContentViewBehavior)d.a;
    sAccessibilityPaneVisibilityManager = new AccessibilityPaneVisibilityManager();
  }
  
  private static AccessibilityViewProperty<Boolean> accessibilityHeadingProperty() {
    return new AccessibilityViewProperty<Boolean>(R.id.tag_accessibility_heading, Boolean.class, 28) {
        @RequiresApi(28)
        Boolean frameworkGet(View param1View) {
          return Boolean.valueOf(ViewCompat.Api28Impl.isAccessibilityHeading(param1View));
        }
        
        @RequiresApi(28)
        void frameworkSet(View param1View, Boolean param1Boolean) {
          ViewCompat.Api28Impl.setAccessibilityHeading(param1View, param1Boolean.booleanValue());
        }
        
        boolean shouldUpdate(Boolean param1Boolean1, Boolean param1Boolean2) {
          return booleanNullToFalseEquals(param1Boolean1, param1Boolean2) ^ true;
        }
      };
  }
  
  public static int addAccessibilityAction(@NonNull View paramView, @NonNull CharSequence paramCharSequence, @NonNull AccessibilityViewCommand paramAccessibilityViewCommand) {
    int i = getAvailableActionIdFromResources(paramView, paramCharSequence);
    if (i != -1)
      addAccessibilityAction(paramView, new AccessibilityNodeInfoCompat.AccessibilityActionCompat(i, paramCharSequence, paramAccessibilityViewCommand)); 
    return i;
  }
  
  private static void addAccessibilityAction(@NonNull View paramView, @NonNull AccessibilityNodeInfoCompat.AccessibilityActionCompat paramAccessibilityActionCompat) {
    if (Build.VERSION.SDK_INT >= 21) {
      ensureAccessibilityDelegateCompat(paramView);
      removeActionWithId(paramAccessibilityActionCompat.getId(), paramView);
      getActionList(paramView).add(paramAccessibilityActionCompat);
      notifyViewAccessibilityStateChangedIfNeeded(paramView, 0);
    } 
  }
  
  public static void addKeyboardNavigationClusters(@NonNull View paramView, @NonNull Collection<View> paramCollection, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.addKeyboardNavigationClusters(paramView, paramCollection, paramInt); 
  }
  
  public static void addOnUnhandledKeyEventListener(@NonNull View paramView, @NonNull OnUnhandledKeyEventListenerCompat paramOnUnhandledKeyEventListenerCompat) {
    if (Build.VERSION.SDK_INT >= 28) {
      Api28Impl.addOnUnhandledKeyEventListener(paramView, paramOnUnhandledKeyEventListenerCompat);
      return;
    } 
    int i = R.id.tag_unhandled_key_listeners;
    ArrayList<OnUnhandledKeyEventListenerCompat> arrayList2 = (ArrayList)paramView.getTag(i);
    ArrayList<OnUnhandledKeyEventListenerCompat> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      paramView.setTag(i, arrayList1);
    } 
    arrayList1.add(paramOnUnhandledKeyEventListenerCompat);
    if (arrayList1.size() == 1)
      UnhandledKeyEventManager.registerListeningView(paramView); 
  }
  
  @NonNull
  public static ViewPropertyAnimatorCompat animate(@NonNull View paramView) {
    if (sViewPropertyAnimatorMap == null)
      sViewPropertyAnimatorMap = new WeakHashMap<View, ViewPropertyAnimatorCompat>(); 
    ViewPropertyAnimatorCompat viewPropertyAnimatorCompat2 = sViewPropertyAnimatorMap.get(paramView);
    ViewPropertyAnimatorCompat viewPropertyAnimatorCompat1 = viewPropertyAnimatorCompat2;
    if (viewPropertyAnimatorCompat2 == null) {
      viewPropertyAnimatorCompat1 = new ViewPropertyAnimatorCompat(paramView);
      sViewPropertyAnimatorMap.put(paramView, viewPropertyAnimatorCompat1);
    } 
    return viewPropertyAnimatorCompat1;
  }
  
  private static void bindTempDetach() {
    try {
      sDispatchStartTemporaryDetach = View.class.getDeclaredMethod("dispatchStartTemporaryDetach", new Class[0]);
      sDispatchFinishTemporaryDetach = View.class.getDeclaredMethod("dispatchFinishTemporaryDetach", new Class[0]);
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("ViewCompat", "Couldn't find method", noSuchMethodException);
    } 
    sTempDetachBound = true;
  }
  
  @Deprecated
  public static boolean canScrollHorizontally(View paramView, int paramInt) {
    return paramView.canScrollHorizontally(paramInt);
  }
  
  @Deprecated
  public static boolean canScrollVertically(View paramView, int paramInt) {
    return paramView.canScrollVertically(paramInt);
  }
  
  public static void cancelDragAndDrop(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 24)
      Api24Impl.cancelDragAndDrop(paramView); 
  }
  
  @Deprecated
  public static int combineMeasuredStates(int paramInt1, int paramInt2) {
    return View.combineMeasuredStates(paramInt1, paramInt2);
  }
  
  private static void compatOffsetLeftAndRight(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0) {
      tickleInvalidationFlag(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        tickleInvalidationFlag((View)viewParent); 
    } 
  }
  
  private static void compatOffsetTopAndBottom(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0) {
      tickleInvalidationFlag(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        tickleInvalidationFlag((View)viewParent); 
    } 
  }
  
  @NonNull
  public static WindowInsetsCompat computeSystemWindowInsets(@NonNull View paramView, @NonNull WindowInsetsCompat paramWindowInsetsCompat, @NonNull Rect paramRect) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.computeSystemWindowInsets(paramView, paramWindowInsetsCompat, paramRect) : paramWindowInsetsCompat;
  }
  
  @NonNull
  public static WindowInsetsCompat dispatchApplyWindowInsets(@NonNull View paramView, @NonNull WindowInsetsCompat paramWindowInsetsCompat) {
    if (Build.VERSION.SDK_INT >= 21) {
      WindowInsets windowInsets = paramWindowInsetsCompat.toWindowInsets();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = Api20Impl.dispatchApplyWindowInsets(paramView, windowInsets);
        if (!windowInsets1.equals(windowInsets))
          return WindowInsetsCompat.toWindowInsetsCompat(windowInsets1, paramView); 
      } 
    } 
    return paramWindowInsetsCompat;
  }
  
  public static void dispatchFinishTemporaryDetach(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 24) {
      Api24Impl.dispatchFinishTemporaryDetach(paramView);
      return;
    } 
    if (!sTempDetachBound)
      bindTempDetach(); 
    Method method = sDispatchFinishTemporaryDetach;
    if (method != null)
      try {
        method.invoke(paramView, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
    exception.onFinishTemporaryDetach();
  }
  
  public static boolean dispatchNestedFling(@NonNull View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.dispatchNestedFling(paramView, paramFloat1, paramFloat2, paramBoolean) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean) : false);
  }
  
  public static boolean dispatchNestedPreFling(@NonNull View paramView, float paramFloat1, float paramFloat2) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.dispatchNestedPreFling(paramView, paramFloat1, paramFloat2) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).dispatchNestedPreFling(paramFloat1, paramFloat2) : false);
  }
  
  public static boolean dispatchNestedPreScroll(@NonNull View paramView, int paramInt1, int paramInt2, @Nullable int[] paramArrayOfint1, @Nullable int[] paramArrayOfint2) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.dispatchNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2) : false);
  }
  
  public static boolean dispatchNestedPreScroll(@NonNull View paramView, int paramInt1, int paramInt2, @Nullable int[] paramArrayOfint1, @Nullable int[] paramArrayOfint2, int paramInt3) {
    return (paramView instanceof NestedScrollingChild2) ? ((NestedScrollingChild2)paramView).dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3) : ((paramInt3 == 0) ? dispatchNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2) : false);
  }
  
  public static void dispatchNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable int[] paramArrayOfint1, int paramInt5, @NonNull int[] paramArrayOfint2) {
    if (paramView instanceof NestedScrollingChild3) {
      ((NestedScrollingChild3)paramView).dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
      return;
    } 
    dispatchNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5);
  }
  
  public static boolean dispatchNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable int[] paramArrayOfint) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.dispatchNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint) : false);
  }
  
  public static boolean dispatchNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable int[] paramArrayOfint, int paramInt5) {
    return (paramView instanceof NestedScrollingChild2) ? ((NestedScrollingChild2)paramView).dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5) : ((paramInt5 == 0) ? dispatchNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint) : false);
  }
  
  public static void dispatchStartTemporaryDetach(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 24) {
      Api24Impl.dispatchStartTemporaryDetach(paramView);
      return;
    } 
    if (!sTempDetachBound)
      bindTempDetach(); 
    Method method = sDispatchStartTemporaryDetach;
    if (method != null)
      try {
        method.invoke(paramView, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
    exception.onStartTemporaryDetach();
  }
  
  @UiThread
  static boolean dispatchUnhandledKeyEventBeforeCallback(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : UnhandledKeyEventManager.at(paramView).dispatch(paramView, paramKeyEvent);
  }
  
  @UiThread
  static boolean dispatchUnhandledKeyEventBeforeHierarchy(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : UnhandledKeyEventManager.at(paramView).preDispatch(paramKeyEvent);
  }
  
  public static void enableAccessibleClickableSpanSupport(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 19)
      ensureAccessibilityDelegateCompat(paramView); 
  }
  
  static void ensureAccessibilityDelegateCompat(@NonNull View paramView) {
    AccessibilityDelegateCompat accessibilityDelegateCompat2 = getAccessibilityDelegate(paramView);
    AccessibilityDelegateCompat accessibilityDelegateCompat1 = accessibilityDelegateCompat2;
    if (accessibilityDelegateCompat2 == null)
      accessibilityDelegateCompat1 = new AccessibilityDelegateCompat(); 
    setAccessibilityDelegate(paramView, accessibilityDelegateCompat1);
  }
  
  public static int generateViewId() {
    if (Build.VERSION.SDK_INT >= 17)
      return Api17Impl.generateViewId(); 
    while (true) {
      AtomicInteger atomicInteger = sNextGeneratedId;
      int k = atomicInteger.get();
      int j = k + 1;
      int i = j;
      if (j > 16777215)
        i = 1; 
      if (atomicInteger.compareAndSet(k, i))
        return k; 
    } 
  }
  
  @Nullable
  public static AccessibilityDelegateCompat getAccessibilityDelegate(@NonNull View paramView) {
    View.AccessibilityDelegate accessibilityDelegate = getAccessibilityDelegateInternal(paramView);
    return (accessibilityDelegate == null) ? null : ((accessibilityDelegate instanceof AccessibilityDelegateCompat.AccessibilityDelegateAdapter) ? ((AccessibilityDelegateCompat.AccessibilityDelegateAdapter)accessibilityDelegate).mCompat : new AccessibilityDelegateCompat(accessibilityDelegate));
  }
  
  @Nullable
  private static View.AccessibilityDelegate getAccessibilityDelegateInternal(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? Api29Impl.getAccessibilityDelegate(paramView) : getAccessibilityDelegateThroughReflection(paramView);
  }
  
  @Nullable
  private static View.AccessibilityDelegate getAccessibilityDelegateThroughReflection(@NonNull View paramView) {
    // Byte code:
    //   0: getstatic androidx/core/view/ViewCompat.sAccessibilityDelegateCheckFailed : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic androidx/core/view/ViewCompat.sAccessibilityDelegateField : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 42
    //   14: ldc_w android/view/View
    //   17: ldc_w 'mAccessibilityDelegate'
    //   20: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   23: astore_1
    //   24: aload_1
    //   25: putstatic androidx/core/view/ViewCompat.sAccessibilityDelegateField : Ljava/lang/reflect/Field;
    //   28: aload_1
    //   29: iconst_1
    //   30: invokevirtual setAccessible : (Z)V
    //   33: goto -> 42
    //   36: iconst_1
    //   37: putstatic androidx/core/view/ViewCompat.sAccessibilityDelegateCheckFailed : Z
    //   40: aconst_null
    //   41: areturn
    //   42: getstatic androidx/core/view/ViewCompat.sAccessibilityDelegateField : Ljava/lang/reflect/Field;
    //   45: aload_0
    //   46: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   49: astore_0
    //   50: aload_0
    //   51: instanceof android/view/View$AccessibilityDelegate
    //   54: ifeq -> 64
    //   57: aload_0
    //   58: checkcast android/view/View$AccessibilityDelegate
    //   61: astore_0
    //   62: aload_0
    //   63: areturn
    //   64: aconst_null
    //   65: areturn
    //   66: iconst_1
    //   67: putstatic androidx/core/view/ViewCompat.sAccessibilityDelegateCheckFailed : Z
    //   70: aconst_null
    //   71: areturn
    //   72: astore_0
    //   73: goto -> 36
    //   76: astore_0
    //   77: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   14	33	72	finally
    //   42	62	76	finally
  }
  
  public static int getAccessibilityLiveRegion(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.getAccessibilityLiveRegion(paramView) : 0;
  }
  
  @Nullable
  public static AccessibilityNodeProviderCompat getAccessibilityNodeProvider(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      AccessibilityNodeProvider accessibilityNodeProvider = Api16Impl.getAccessibilityNodeProvider(paramView);
      if (accessibilityNodeProvider != null)
        return new AccessibilityNodeProviderCompat(accessibilityNodeProvider); 
    } 
    return null;
  }
  
  @Nullable
  @UiThread
  public static CharSequence getAccessibilityPaneTitle(@NonNull View paramView) {
    return paneTitleProperty().get(paramView);
  }
  
  private static List<AccessibilityNodeInfoCompat.AccessibilityActionCompat> getActionList(View paramView) {
    int i = R.id.tag_accessibility_actions;
    ArrayList<AccessibilityNodeInfoCompat.AccessibilityActionCompat> arrayList2 = (ArrayList)paramView.getTag(i);
    ArrayList<AccessibilityNodeInfoCompat.AccessibilityActionCompat> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      paramView.setTag(i, arrayList1);
    } 
    return arrayList1;
  }
  
  @Deprecated
  public static float getAlpha(View paramView) {
    return paramView.getAlpha();
  }
  
  private static int getAvailableActionIdFromResources(View paramView, @NonNull CharSequence paramCharSequence) {
    List<AccessibilityNodeInfoCompat.AccessibilityActionCompat> list = getActionList(paramView);
    int i;
    for (i = 0; i < list.size(); i++) {
      if (TextUtils.equals(paramCharSequence, ((AccessibilityNodeInfoCompat.AccessibilityActionCompat)list.get(i)).getLabel()))
        return ((AccessibilityNodeInfoCompat.AccessibilityActionCompat)list.get(i)).getId(); 
    } 
    int j = -1;
    i = 0;
    while (true) {
      int[] arrayOfInt = ACCESSIBILITY_ACTIONS_RESOURCE_IDS;
      if (i < arrayOfInt.length && j == -1) {
        int n = arrayOfInt[i];
        int m = 0;
        int k = 1;
        while (m < list.size()) {
          byte b;
          if (((AccessibilityNodeInfoCompat.AccessibilityActionCompat)list.get(m)).getId() != n) {
            b = 1;
          } else {
            b = 0;
          } 
          k &= b;
          m++;
        } 
        if (k != 0)
          j = n; 
        i++;
        continue;
      } 
      break;
    } 
    return j;
  }
  
  @Nullable
  public static ColorStateList getBackgroundTintList(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getBackgroundTintList(paramView) : ((paramView instanceof TintableBackgroundView) ? ((TintableBackgroundView)paramView).getSupportBackgroundTintList() : null);
  }
  
  @Nullable
  public static PorterDuff.Mode getBackgroundTintMode(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getBackgroundTintMode(paramView) : ((paramView instanceof TintableBackgroundView) ? ((TintableBackgroundView)paramView).getSupportBackgroundTintMode() : null);
  }
  
  @Nullable
  public static Rect getClipBounds(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 18) ? Api18Impl.getClipBounds(paramView) : null;
  }
  
  @Nullable
  public static Display getDisplay(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getDisplay(paramView) : (isAttachedToWindow(paramView) ? ((WindowManager)paramView.getContext().getSystemService("window")).getDefaultDisplay() : null);
  }
  
  public static float getElevation(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getElevation(paramView) : 0.0F;
  }
  
  private static Rect getEmptyTempRect() {
    if (sThreadLocalRect == null)
      sThreadLocalRect = new ThreadLocal<Rect>(); 
    Rect rect2 = sThreadLocalRect.get();
    Rect rect1 = rect2;
    if (rect2 == null) {
      rect1 = new Rect();
      sThreadLocalRect.set(rect1);
    } 
    rect1.setEmpty();
    return rect1;
  }
  
  private static OnReceiveContentViewBehavior getFallback(@NonNull View paramView) {
    return (paramView instanceof OnReceiveContentViewBehavior) ? (OnReceiveContentViewBehavior)paramView : NO_OP_ON_RECEIVE_CONTENT_VIEW_BEHAVIOR;
  }
  
  public static boolean getFitsSystemWindows(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getFitsSystemWindows(paramView) : false;
  }
  
  public static int getImportantForAccessibility(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getImportantForAccessibility(paramView) : 0;
  }
  
  @SuppressLint({"InlinedApi"})
  public static int getImportantForAutofill(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.getImportantForAutofill(paramView) : 0;
  }
  
  public static int getLabelFor(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getLabelFor(paramView) : 0;
  }
  
  @Deprecated
  public static int getLayerType(View paramView) {
    return paramView.getLayerType();
  }
  
  public static int getLayoutDirection(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getLayoutDirection(paramView) : 0;
  }
  
  @Deprecated
  @Nullable
  public static Matrix getMatrix(View paramView) {
    return paramView.getMatrix();
  }
  
  @Deprecated
  public static int getMeasuredHeightAndState(View paramView) {
    return paramView.getMeasuredHeightAndState();
  }
  
  @Deprecated
  public static int getMeasuredState(View paramView) {
    return paramView.getMeasuredState();
  }
  
  @Deprecated
  public static int getMeasuredWidthAndState(View paramView) {
    return paramView.getMeasuredWidthAndState();
  }
  
  public static int getMinimumHeight(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 16)
      return Api16Impl.getMinimumHeight(paramView); 
    if (!sMinHeightFieldFetched) {
      try {
        Field field1 = View.class.getDeclaredField("mMinHeight");
        sMinHeightField = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      sMinHeightFieldFetched = true;
    } 
    Field field = sMinHeightField;
    if (field != null)
      try {
        return ((Integer)field.get(paramView)).intValue();
      } catch (Exception exception) {} 
    return 0;
  }
  
  public static int getMinimumWidth(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 16)
      return Api16Impl.getMinimumWidth(paramView); 
    if (!sMinWidthFieldFetched) {
      try {
        Field field1 = View.class.getDeclaredField("mMinWidth");
        sMinWidthField = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      sMinWidthFieldFetched = true;
    } 
    Field field = sMinWidthField;
    if (field != null)
      try {
        return ((Integer)field.get(paramView)).intValue();
      } catch (Exception exception) {} 
    return 0;
  }
  
  public static int getNextClusterForwardId(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.getNextClusterForwardId(paramView) : -1;
  }
  
  @Nullable
  public static String[] getOnReceiveContentMimeTypes(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 31) ? Api31Impl.getReceiveContentMimeTypes(paramView) : (String[])paramView.getTag(R.id.tag_on_receive_content_mime_types);
  }
  
  @Deprecated
  public static int getOverScrollMode(View paramView) {
    return paramView.getOverScrollMode();
  }
  
  @Px
  public static int getPaddingEnd(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getPaddingEnd(paramView) : paramView.getPaddingRight();
  }
  
  @Px
  public static int getPaddingStart(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getPaddingStart(paramView) : paramView.getPaddingLeft();
  }
  
  @Nullable
  public static ViewParent getParentForAccessibility(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getParentForAccessibility(paramView) : paramView.getParent();
  }
  
  @Deprecated
  public static float getPivotX(View paramView) {
    return paramView.getPivotX();
  }
  
  @Deprecated
  public static float getPivotY(View paramView) {
    return paramView.getPivotY();
  }
  
  @Nullable
  public static WindowInsetsCompat getRootWindowInsets(@NonNull View paramView) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 23) ? Api23Impl.getRootWindowInsets(paramView) : ((i >= 21) ? Api21Impl.getRootWindowInsets(paramView) : null);
  }
  
  @Deprecated
  public static float getRotation(View paramView) {
    return paramView.getRotation();
  }
  
  @Deprecated
  public static float getRotationX(View paramView) {
    return paramView.getRotationX();
  }
  
  @Deprecated
  public static float getRotationY(View paramView) {
    return paramView.getRotationY();
  }
  
  @Deprecated
  public static float getScaleX(View paramView) {
    return paramView.getScaleX();
  }
  
  @Deprecated
  public static float getScaleY(View paramView) {
    return paramView.getScaleY();
  }
  
  public static int getScrollIndicators(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 23) ? Api23Impl.getScrollIndicators(paramView) : 0;
  }
  
  @Nullable
  @UiThread
  public static CharSequence getStateDescription(@NonNull View paramView) {
    return stateDescriptionProperty().get(paramView);
  }
  
  @NonNull
  public static List<Rect> getSystemGestureExclusionRects(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? Api29Impl.getSystemGestureExclusionRects(paramView) : Collections.emptyList();
  }
  
  @Nullable
  public static String getTransitionName(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return Api21Impl.getTransitionName(paramView); 
    WeakHashMap<View, String> weakHashMap = sTransitionNameMap;
    return (weakHashMap == null) ? null : weakHashMap.get(paramView);
  }
  
  @Deprecated
  public static float getTranslationX(View paramView) {
    return paramView.getTranslationX();
  }
  
  @Deprecated
  public static float getTranslationY(View paramView) {
    return paramView.getTranslationY();
  }
  
  public static float getTranslationZ(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getTranslationZ(paramView) : 0.0F;
  }
  
  @Deprecated
  @Nullable
  public static WindowInsetsControllerCompat getWindowInsetsController(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 30)
      return Api30Impl.getWindowInsetsController(paramView); 
    Context context = paramView.getContext();
    while (true) {
      boolean bool = context instanceof ContextWrapper;
      Context context1 = null;
      if (bool) {
        WindowInsetsControllerCompat windowInsetsControllerCompat;
        if (context instanceof Activity) {
          Window window = ((Activity)context).getWindow();
          context = context1;
          if (window != null)
            windowInsetsControllerCompat = WindowCompat.getInsetsController(window, paramView); 
          return windowInsetsControllerCompat;
        } 
        Context context2 = ((ContextWrapper)windowInsetsControllerCompat).getBaseContext();
        continue;
      } 
      return null;
    } 
  }
  
  @Deprecated
  public static int getWindowSystemUiVisibility(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.getWindowSystemUiVisibility(paramView) : 0;
  }
  
  @Deprecated
  public static float getX(View paramView) {
    return paramView.getX();
  }
  
  @Deprecated
  public static float getY(View paramView) {
    return paramView.getY();
  }
  
  public static float getZ(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getZ(paramView) : 0.0F;
  }
  
  public static boolean hasAccessibilityDelegate(@NonNull View paramView) {
    return (getAccessibilityDelegateInternal(paramView) != null);
  }
  
  public static boolean hasExplicitFocusable(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.hasExplicitFocusable(paramView) : paramView.hasFocusable();
  }
  
  public static boolean hasNestedScrollingParent(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.hasNestedScrollingParent(paramView) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).hasNestedScrollingParent() : false);
  }
  
  public static boolean hasNestedScrollingParent(@NonNull View paramView, int paramInt) {
    if (paramView instanceof NestedScrollingChild2) {
      ((NestedScrollingChild2)paramView).hasNestedScrollingParent(paramInt);
    } else if (paramInt == 0) {
      return hasNestedScrollingParent(paramView);
    } 
    return false;
  }
  
  public static boolean hasOnClickListeners(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 15) ? Api15Impl.hasOnClickListeners(paramView) : false;
  }
  
  public static boolean hasOverlappingRendering(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.hasOverlappingRendering(paramView) : true;
  }
  
  public static boolean hasTransientState(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.hasTransientState(paramView) : false;
  }
  
  @UiThread
  public static boolean isAccessibilityHeading(@NonNull View paramView) {
    Boolean bool = accessibilityHeadingProperty().get(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  public static boolean isAttachedToWindow(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.isAttachedToWindow(paramView) : ((paramView.getWindowToken() != null));
  }
  
  public static boolean isFocusedByDefault(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.isFocusedByDefault(paramView) : false;
  }
  
  public static boolean isImportantForAccessibility(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.isImportantForAccessibility(paramView) : true;
  }
  
  public static boolean isImportantForAutofill(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.isImportantForAutofill(paramView) : true;
  }
  
  public static boolean isInLayout(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 18) ? Api18Impl.isInLayout(paramView) : false;
  }
  
  public static boolean isKeyboardNavigationCluster(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.isKeyboardNavigationCluster(paramView) : false;
  }
  
  public static boolean isLaidOut(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.isLaidOut(paramView) : ((paramView.getWidth() > 0 && paramView.getHeight() > 0));
  }
  
  public static boolean isLayoutDirectionResolved(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.isLayoutDirectionResolved(paramView) : false;
  }
  
  public static boolean isNestedScrollingEnabled(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.isNestedScrollingEnabled(paramView) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).isNestedScrollingEnabled() : false);
  }
  
  @Deprecated
  public static boolean isOpaque(View paramView) {
    return paramView.isOpaque();
  }
  
  public static boolean isPaddingRelative(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.isPaddingRelative(paramView) : false;
  }
  
  @UiThread
  public static boolean isScreenReaderFocusable(@NonNull View paramView) {
    Boolean bool = screenReaderFocusableProperty().get(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  @Deprecated
  public static void jumpDrawablesToCurrentState(View paramView) {
    paramView.jumpDrawablesToCurrentState();
  }
  
  @Nullable
  public static View keyboardNavigationClusterSearch(@NonNull View paramView1, @Nullable View paramView2, int paramInt) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.keyboardNavigationClusterSearch(paramView1, paramView2, paramInt) : null;
  }
  
  @RequiresApi(19)
  static void notifyViewAccessibilityStateChangedIfNeeded(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (getAccessibilityPaneTitle(paramView) != null && paramView.isShown() && paramView.getWindowVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = getAccessibilityLiveRegion(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      Api19Impl.setContentChangeTypes(accessibilityEvent, paramInt);
      if (bool) {
        accessibilityEvent.getText().add(getAccessibilityPaneTitle(paramView));
        setViewImportanceForAccessibilityIfNeeded(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      Api19Impl.setContentChangeTypes(accessibilityEvent1, paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(getAccessibilityPaneTitle(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null) {
      ViewParent viewParent = paramView.getParent();
      try {
        Api19Impl.notifySubtreeAccessibilityStateChanged(viewParent, paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      } 
    } 
  }
  
  public static void offsetLeftAndRight(@NonNull View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetLeftAndRight(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = getEmptyTempRect();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      compatOffsetLeftAndRight(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      compatOffsetLeftAndRight(paramView, paramInt);
    } 
  }
  
  public static void offsetTopAndBottom(@NonNull View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetTopAndBottom(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = getEmptyTempRect();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      compatOffsetTopAndBottom(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      compatOffsetTopAndBottom(paramView, paramInt);
    } 
  }
  
  @NonNull
  public static WindowInsetsCompat onApplyWindowInsets(@NonNull View paramView, @NonNull WindowInsetsCompat paramWindowInsetsCompat) {
    if (Build.VERSION.SDK_INT >= 21) {
      WindowInsets windowInsets = paramWindowInsetsCompat.toWindowInsets();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = Api20Impl.onApplyWindowInsets(paramView, windowInsets);
        if (!windowInsets1.equals(windowInsets))
          return WindowInsetsCompat.toWindowInsetsCompat(windowInsets1, paramView); 
      } 
    } 
    return paramWindowInsetsCompat;
  }
  
  @Deprecated
  public static void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    paramView.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public static void onInitializeAccessibilityNodeInfo(@NonNull View paramView, @NonNull AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    paramView.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfoCompat.unwrap());
  }
  
  @Deprecated
  public static void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    paramView.onPopulateAccessibilityEvent(paramAccessibilityEvent);
  }
  
  private static AccessibilityViewProperty<CharSequence> paneTitleProperty() {
    return new AccessibilityViewProperty<CharSequence>(R.id.tag_accessibility_pane_title, CharSequence.class, 8, 28) {
        @RequiresApi(28)
        CharSequence frameworkGet(View param1View) {
          return ViewCompat.Api28Impl.getAccessibilityPaneTitle(param1View);
        }
        
        @RequiresApi(28)
        void frameworkSet(View param1View, CharSequence param1CharSequence) {
          ViewCompat.Api28Impl.setAccessibilityPaneTitle(param1View, param1CharSequence);
        }
        
        boolean shouldUpdate(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
          return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
        }
      };
  }
  
  public static boolean performAccessibilityAction(@NonNull View paramView, int paramInt, @Nullable Bundle paramBundle) {
    return (Build.VERSION.SDK_INT >= 16) ? Api16Impl.performAccessibilityAction(paramView, paramInt, paramBundle) : false;
  }
  
  @Nullable
  public static ContentInfoCompat performReceiveContent(@NonNull View paramView, @NonNull ContentInfoCompat paramContentInfoCompat) {
    if (Log.isLoggable("ViewCompat", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("performReceiveContent: ");
      stringBuilder.append(paramContentInfoCompat);
      stringBuilder.append(", view=");
      stringBuilder.append(paramView.getClass().getSimpleName());
      stringBuilder.append("[");
      stringBuilder.append(paramView.getId());
      stringBuilder.append("]");
      stringBuilder.toString();
    } 
    if (Build.VERSION.SDK_INT >= 31)
      return Api31Impl.performReceiveContent(paramView, paramContentInfoCompat); 
    OnReceiveContentListener onReceiveContentListener = (OnReceiveContentListener)paramView.getTag(R.id.tag_on_receive_content_listener);
    if (onReceiveContentListener != null) {
      paramContentInfoCompat = onReceiveContentListener.onReceiveContent(paramView, paramContentInfoCompat);
      return (paramContentInfoCompat == null) ? null : getFallback(paramView).onReceiveContent(paramContentInfoCompat);
    } 
    return getFallback(paramView).onReceiveContent(paramContentInfoCompat);
  }
  
  public static void postInvalidateOnAnimation(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.postInvalidateOnAnimation(paramView);
      return;
    } 
    paramView.postInvalidate();
  }
  
  public static void postInvalidateOnAnimation(@NonNull View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.postInvalidateOnAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    paramView.postInvalidate(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void postOnAnimation(@NonNull View paramView, @NonNull Runnable paramRunnable) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.postOnAnimation(paramView, paramRunnable);
      return;
    } 
    paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay());
  }
  
  @SuppressLint({"LambdaLast"})
  public static void postOnAnimationDelayed(@NonNull View paramView, @NonNull Runnable paramRunnable, long paramLong) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.postOnAnimationDelayed(paramView, paramRunnable, paramLong);
      return;
    } 
    paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay() + paramLong);
  }
  
  public static void removeAccessibilityAction(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21) {
      removeActionWithId(paramInt, paramView);
      notifyViewAccessibilityStateChangedIfNeeded(paramView, 0);
    } 
  }
  
  private static void removeActionWithId(int paramInt, View paramView) {
    List<AccessibilityNodeInfoCompat.AccessibilityActionCompat> list = getActionList(paramView);
    for (int i = 0; i < list.size(); i++) {
      if (((AccessibilityNodeInfoCompat.AccessibilityActionCompat)list.get(i)).getId() == paramInt) {
        list.remove(i);
        return;
      } 
    } 
  }
  
  public static void removeOnUnhandledKeyEventListener(@NonNull View paramView, @NonNull OnUnhandledKeyEventListenerCompat paramOnUnhandledKeyEventListenerCompat) {
    if (Build.VERSION.SDK_INT >= 28) {
      Api28Impl.removeOnUnhandledKeyEventListener(paramView, paramOnUnhandledKeyEventListenerCompat);
      return;
    } 
    ArrayList arrayList = (ArrayList)paramView.getTag(R.id.tag_unhandled_key_listeners);
    if (arrayList != null) {
      arrayList.remove(paramOnUnhandledKeyEventListenerCompat);
      if (arrayList.size() == 0)
        UnhandledKeyEventManager.unregisterListeningView(paramView); 
    } 
  }
  
  public static void replaceAccessibilityAction(@NonNull View paramView, @NonNull AccessibilityNodeInfoCompat.AccessibilityActionCompat paramAccessibilityActionCompat, @Nullable CharSequence paramCharSequence, @Nullable AccessibilityViewCommand paramAccessibilityViewCommand) {
    if (paramAccessibilityViewCommand == null && paramCharSequence == null) {
      removeAccessibilityAction(paramView, paramAccessibilityActionCompat.getId());
      return;
    } 
    addAccessibilityAction(paramView, paramAccessibilityActionCompat.createReplacementAction(paramCharSequence, paramAccessibilityViewCommand));
  }
  
  public static void requestApplyInsets(@NonNull View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      Api20Impl.requestApplyInsets(paramView);
      return;
    } 
    if (i >= 16)
      Api16Impl.requestFitSystemWindows(paramView); 
  }
  
  @NonNull
  public static <T extends View> T requireViewById(@NonNull View paramView, @IdRes int paramInt) {
    if (Build.VERSION.SDK_INT >= 28)
      return (T)Api28Impl.<View>requireViewById(paramView, paramInt); 
    paramView = paramView.findViewById(paramInt);
    if (paramView != null)
      return (T)paramView; 
    throw new IllegalArgumentException("ID does not reference a View inside this View");
  }
  
  @Deprecated
  public static int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3) {
    return View.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
  }
  
  public static boolean restoreDefaultFocus(@NonNull View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? Api26Impl.restoreDefaultFocus(paramView) : paramView.requestFocus();
  }
  
  public static void saveAttributeDataForStyleable(@NonNull View paramView, @SuppressLint({"ContextFirst"}) @NonNull Context paramContext, @NonNull int[] paramArrayOfint, @Nullable AttributeSet paramAttributeSet, @NonNull TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 29)
      Api29Impl.saveAttributeDataForStyleable(paramView, paramContext, paramArrayOfint, paramAttributeSet, paramTypedArray, paramInt1, paramInt2); 
  }
  
  private static AccessibilityViewProperty<Boolean> screenReaderFocusableProperty() {
    return new AccessibilityViewProperty<Boolean>(R.id.tag_screen_reader_focusable, Boolean.class, 28) {
        @RequiresApi(28)
        Boolean frameworkGet(@NonNull View param1View) {
          return Boolean.valueOf(ViewCompat.Api28Impl.isScreenReaderFocusable(param1View));
        }
        
        @RequiresApi(28)
        void frameworkSet(@NonNull View param1View, Boolean param1Boolean) {
          ViewCompat.Api28Impl.setScreenReaderFocusable(param1View, param1Boolean.booleanValue());
        }
        
        boolean shouldUpdate(Boolean param1Boolean1, Boolean param1Boolean2) {
          return booleanNullToFalseEquals(param1Boolean1, param1Boolean2) ^ true;
        }
      };
  }
  
  public static void setAccessibilityDelegate(@NonNull View paramView, @Nullable AccessibilityDelegateCompat paramAccessibilityDelegateCompat) {
    View.AccessibilityDelegate accessibilityDelegate;
    AccessibilityDelegateCompat accessibilityDelegateCompat = paramAccessibilityDelegateCompat;
    if (paramAccessibilityDelegateCompat == null) {
      accessibilityDelegateCompat = paramAccessibilityDelegateCompat;
      if (getAccessibilityDelegateInternal(paramView) instanceof AccessibilityDelegateCompat.AccessibilityDelegateAdapter)
        accessibilityDelegateCompat = new AccessibilityDelegateCompat(); 
    } 
    if (accessibilityDelegateCompat == null) {
      paramAccessibilityDelegateCompat = null;
    } else {
      accessibilityDelegate = accessibilityDelegateCompat.getBridge();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  @UiThread
  public static void setAccessibilityHeading(@NonNull View paramView, boolean paramBoolean) {
    accessibilityHeadingProperty().set(paramView, Boolean.valueOf(paramBoolean));
  }
  
  public static void setAccessibilityLiveRegion(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 19)
      Api19Impl.setAccessibilityLiveRegion(paramView, paramInt); 
  }
  
  @UiThread
  public static void setAccessibilityPaneTitle(@NonNull View paramView, @Nullable CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 19) {
      paneTitleProperty().set(paramView, paramCharSequence);
      if (paramCharSequence != null) {
        sAccessibilityPaneVisibilityManager.addAccessibilityPane(paramView);
        return;
      } 
      sAccessibilityPaneVisibilityManager.removeAccessibilityPane(paramView);
    } 
  }
  
  @Deprecated
  public static void setActivated(View paramView, boolean paramBoolean) {
    paramView.setActivated(paramBoolean);
  }
  
  @Deprecated
  public static void setAlpha(View paramView, @FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    paramView.setAlpha(paramFloat);
  }
  
  public static void setAutofillHints(@NonNull View paramView, @Nullable String... paramVarArgs) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setAutofillHints(paramView, paramVarArgs); 
  }
  
  public static void setBackground(@NonNull View paramView, @Nullable Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 16) {
      Api16Impl.setBackground(paramView, paramDrawable);
      return;
    } 
    paramView.setBackgroundDrawable(paramDrawable);
  }
  
  public static void setBackgroundTintList(@NonNull View paramView, @Nullable ColorStateList paramColorStateList) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      Api21Impl.setBackgroundTintList(paramView, paramColorStateList);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (Api21Impl.getBackgroundTintList(paramView) != null || Api21Impl.getBackgroundTintMode(paramView) != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          Api16Impl.setBackground(paramView, drawable);
          return;
        } 
      } 
    } else if (paramView instanceof TintableBackgroundView) {
      ((TintableBackgroundView)paramView).setSupportBackgroundTintList((ColorStateList)drawable);
    } 
  }
  
  public static void setBackgroundTintMode(@NonNull View paramView, @Nullable PorterDuff.Mode paramMode) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      Api21Impl.setBackgroundTintMode(paramView, paramMode);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (Api21Impl.getBackgroundTintList(paramView) != null || Api21Impl.getBackgroundTintMode(paramView) != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          Api16Impl.setBackground(paramView, drawable);
          return;
        } 
      } 
    } else if (paramView instanceof TintableBackgroundView) {
      ((TintableBackgroundView)paramView).setSupportBackgroundTintMode((PorterDuff.Mode)drawable);
    } 
  }
  
  @Deprecated
  @SuppressLint({"BanUncheckedReflection"})
  public static void setChildrenDrawingOrderEnabled(ViewGroup paramViewGroup, boolean paramBoolean) {
    if (sChildrenDrawingOrderMethod == null) {
      try {
        sChildrenDrawingOrderMethod = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("ViewCompat", "Unable to find childrenDrawingOrderEnabled", noSuchMethodException);
      } 
      sChildrenDrawingOrderMethod.setAccessible(true);
    } 
    try {
      sChildrenDrawingOrderMethod.invoke(paramViewGroup, new Object[] { Boolean.valueOf(paramBoolean) });
      return;
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", illegalAccessException);
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", illegalArgumentException);
      return;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("ViewCompat", "Unable to invoke childrenDrawingOrderEnabled", invocationTargetException);
      return;
    } 
  }
  
  public static void setClipBounds(@NonNull View paramView, @Nullable Rect paramRect) {
    if (Build.VERSION.SDK_INT >= 18)
      Api18Impl.setClipBounds(paramView, paramRect); 
  }
  
  public static void setElevation(@NonNull View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.setElevation(paramView, paramFloat); 
  }
  
  @Deprecated
  public static void setFitsSystemWindows(View paramView, boolean paramBoolean) {
    paramView.setFitsSystemWindows(paramBoolean);
  }
  
  public static void setFocusedByDefault(@NonNull View paramView, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setFocusedByDefault(paramView, paramBoolean); 
  }
  
  public static void setHasTransientState(@NonNull View paramView, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 16)
      Api16Impl.setHasTransientState(paramView, paramBoolean); 
  }
  
  @UiThread
  public static void setImportantForAccessibility(@NonNull View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      Api16Impl.setImportantForAccessibility(paramView, paramInt);
      return;
    } 
    if (i >= 16) {
      i = paramInt;
      if (paramInt == 4)
        i = 2; 
      Api16Impl.setImportantForAccessibility(paramView, i);
    } 
  }
  
  public static void setImportantForAutofill(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setImportantForAutofill(paramView, paramInt); 
  }
  
  public static void setKeyboardNavigationCluster(@NonNull View paramView, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setKeyboardNavigationCluster(paramView, paramBoolean); 
  }
  
  public static void setLabelFor(@NonNull View paramView, @IdRes int paramInt) {
    if (Build.VERSION.SDK_INT >= 17)
      Api17Impl.setLabelFor(paramView, paramInt); 
  }
  
  public static void setLayerPaint(@NonNull View paramView, @Nullable Paint paramPaint) {
    if (Build.VERSION.SDK_INT >= 17) {
      Api17Impl.setLayerPaint(paramView, paramPaint);
      return;
    } 
    paramView.setLayerType(paramView.getLayerType(), paramPaint);
    paramView.invalidate();
  }
  
  @Deprecated
  public static void setLayerType(View paramView, int paramInt, Paint paramPaint) {
    paramView.setLayerType(paramInt, paramPaint);
  }
  
  public static void setLayoutDirection(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 17)
      Api17Impl.setLayoutDirection(paramView, paramInt); 
  }
  
  public static void setNestedScrollingEnabled(@NonNull View paramView, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 21) {
      Api21Impl.setNestedScrollingEnabled(paramView, paramBoolean);
      return;
    } 
    if (paramView instanceof NestedScrollingChild)
      ((NestedScrollingChild)paramView).setNestedScrollingEnabled(paramBoolean); 
  }
  
  public static void setNextClusterForwardId(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setNextClusterForwardId(paramView, paramInt); 
  }
  
  public static void setOnApplyWindowInsetsListener(@NonNull View paramView, @Nullable OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.setOnApplyWindowInsetsListener(paramView, paramOnApplyWindowInsetsListener); 
  }
  
  public static void setOnReceiveContentListener(@NonNull View paramView, @Nullable String[] paramArrayOfString, @Nullable OnReceiveContentListener paramOnReceiveContentListener) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #31
    //   5: if_icmplt -> 15
    //   8: aload_0
    //   9: aload_1
    //   10: aload_2
    //   11: invokestatic setOnReceiveContentListener : (Landroid/view/View;[Ljava/lang/String;Landroidx/core/view/OnReceiveContentListener;)V
    //   14: return
    //   15: aload_1
    //   16: ifnull -> 27
    //   19: aload_1
    //   20: astore #8
    //   22: aload_1
    //   23: arraylength
    //   24: ifne -> 30
    //   27: aconst_null
    //   28: astore #8
    //   30: iconst_0
    //   31: istore #5
    //   33: aload_2
    //   34: ifnull -> 59
    //   37: aload #8
    //   39: ifnull -> 48
    //   42: iconst_1
    //   43: istore #7
    //   45: goto -> 51
    //   48: iconst_0
    //   49: istore #7
    //   51: iload #7
    //   53: ldc_w 'When the listener is set, MIME types must also be set'
    //   56: invokestatic checkArgument : (ZLjava/lang/Object;)V
    //   59: aload #8
    //   61: ifnull -> 144
    //   64: aload #8
    //   66: arraylength
    //   67: istore #6
    //   69: iconst_0
    //   70: istore_3
    //   71: iload #5
    //   73: istore #4
    //   75: iload_3
    //   76: iload #6
    //   78: if_icmpge -> 107
    //   81: aload #8
    //   83: iload_3
    //   84: aaload
    //   85: ldc_w '*'
    //   88: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   91: ifeq -> 100
    //   94: iconst_1
    //   95: istore #4
    //   97: goto -> 107
    //   100: iload_3
    //   101: iconst_1
    //   102: iadd
    //   103: istore_3
    //   104: goto -> 71
    //   107: new java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: astore_1
    //   115: aload_1
    //   116: ldc_w 'A MIME type set here must not start with *: '
    //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: aload_1
    //   124: aload #8
    //   126: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: pop
    //   133: iload #4
    //   135: iconst_1
    //   136: ixor
    //   137: aload_1
    //   138: invokevirtual toString : ()Ljava/lang/String;
    //   141: invokestatic checkArgument : (ZLjava/lang/Object;)V
    //   144: aload_0
    //   145: getstatic androidx/core/R$id.tag_on_receive_content_mime_types : I
    //   148: aload #8
    //   150: invokevirtual setTag : (ILjava/lang/Object;)V
    //   153: aload_0
    //   154: getstatic androidx/core/R$id.tag_on_receive_content_listener : I
    //   157: aload_2
    //   158: invokevirtual setTag : (ILjava/lang/Object;)V
    //   161: return
  }
  
  @Deprecated
  public static void setOverScrollMode(View paramView, int paramInt) {
    paramView.setOverScrollMode(paramInt);
  }
  
  public static void setPaddingRelative(@NonNull View paramView, @Px int paramInt1, @Px int paramInt2, @Px int paramInt3, @Px int paramInt4) {
    if (Build.VERSION.SDK_INT >= 17) {
      Api17Impl.setPaddingRelative(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    paramView.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public static void setPivotX(View paramView, float paramFloat) {
    paramView.setPivotX(paramFloat);
  }
  
  @Deprecated
  public static void setPivotY(View paramView, float paramFloat) {
    paramView.setPivotY(paramFloat);
  }
  
  public static void setPointerIcon(@NonNull View paramView, @Nullable PointerIconCompat paramPointerIconCompat) {
    if (Build.VERSION.SDK_INT >= 24) {
      if (paramPointerIconCompat != null) {
        Object object = paramPointerIconCompat.getPointerIcon();
      } else {
        paramPointerIconCompat = null;
      } 
      Api24Impl.setPointerIcon(paramView, (PointerIcon)paramPointerIconCompat);
    } 
  }
  
  @Deprecated
  public static void setRotation(View paramView, float paramFloat) {
    paramView.setRotation(paramFloat);
  }
  
  @Deprecated
  public static void setRotationX(View paramView, float paramFloat) {
    paramView.setRotationX(paramFloat);
  }
  
  @Deprecated
  public static void setRotationY(View paramView, float paramFloat) {
    paramView.setRotationY(paramFloat);
  }
  
  @Deprecated
  public static void setSaveFromParentEnabled(View paramView, boolean paramBoolean) {
    paramView.setSaveFromParentEnabled(paramBoolean);
  }
  
  @Deprecated
  public static void setScaleX(View paramView, float paramFloat) {
    paramView.setScaleX(paramFloat);
  }
  
  @Deprecated
  public static void setScaleY(View paramView, float paramFloat) {
    paramView.setScaleY(paramFloat);
  }
  
  @UiThread
  public static void setScreenReaderFocusable(@NonNull View paramView, boolean paramBoolean) {
    screenReaderFocusableProperty().set(paramView, Boolean.valueOf(paramBoolean));
  }
  
  public static void setScrollIndicators(@NonNull View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23)
      Api23Impl.setScrollIndicators(paramView, paramInt); 
  }
  
  public static void setScrollIndicators(@NonNull View paramView, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 23)
      Api23Impl.setScrollIndicators(paramView, paramInt1, paramInt2); 
  }
  
  @UiThread
  public static void setStateDescription(@NonNull View paramView, @Nullable CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 19)
      stateDescriptionProperty().set(paramView, paramCharSequence); 
  }
  
  public static void setSystemGestureExclusionRects(@NonNull View paramView, @NonNull List<Rect> paramList) {
    if (Build.VERSION.SDK_INT >= 29)
      Api29Impl.setSystemGestureExclusionRects(paramView, paramList); 
  }
  
  public static void setTooltipText(@NonNull View paramView, @Nullable CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setTooltipText(paramView, paramCharSequence); 
  }
  
  public static void setTransitionName(@NonNull View paramView, @Nullable String paramString) {
    if (Build.VERSION.SDK_INT >= 21) {
      Api21Impl.setTransitionName(paramView, paramString);
      return;
    } 
    if (sTransitionNameMap == null)
      sTransitionNameMap = new WeakHashMap<View, String>(); 
    sTransitionNameMap.put(paramView, paramString);
  }
  
  @Deprecated
  public static void setTranslationX(View paramView, float paramFloat) {
    paramView.setTranslationX(paramFloat);
  }
  
  @Deprecated
  public static void setTranslationY(View paramView, float paramFloat) {
    paramView.setTranslationY(paramFloat);
  }
  
  public static void setTranslationZ(@NonNull View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.setTranslationZ(paramView, paramFloat); 
  }
  
  private static void setViewImportanceForAccessibilityIfNeeded(View paramView) {
    if (getImportantForAccessibility(paramView) == 0)
      setImportantForAccessibility(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (getImportantForAccessibility((View)viewParent) == 4) {
        setImportantForAccessibility(paramView, 2);
        return;
      } 
    } 
  }
  
  public static void setWindowInsetsAnimationCallback(@NonNull View paramView, @Nullable WindowInsetsAnimationCompat.Callback paramCallback) {
    WindowInsetsAnimationCompat.setCallback(paramView, paramCallback);
  }
  
  @Deprecated
  public static void setX(View paramView, float paramFloat) {
    paramView.setX(paramFloat);
  }
  
  @Deprecated
  public static void setY(View paramView, float paramFloat) {
    paramView.setY(paramFloat);
  }
  
  public static void setZ(@NonNull View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.setZ(paramView, paramFloat); 
  }
  
  public static boolean startDragAndDrop(@NonNull View paramView, @Nullable ClipData paramClipData, @NonNull View.DragShadowBuilder paramDragShadowBuilder, @Nullable Object paramObject, int paramInt) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.startDragAndDrop(paramView, paramClipData, paramDragShadowBuilder, paramObject, paramInt) : paramView.startDrag(paramClipData, paramDragShadowBuilder, paramObject, paramInt);
  }
  
  public static boolean startNestedScroll(@NonNull View paramView, int paramInt) {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.startNestedScroll(paramView, paramInt) : ((paramView instanceof NestedScrollingChild) ? ((NestedScrollingChild)paramView).startNestedScroll(paramInt) : false);
  }
  
  public static boolean startNestedScroll(@NonNull View paramView, int paramInt1, int paramInt2) {
    return (paramView instanceof NestedScrollingChild2) ? ((NestedScrollingChild2)paramView).startNestedScroll(paramInt1, paramInt2) : ((paramInt2 == 0) ? startNestedScroll(paramView, paramInt1) : false);
  }
  
  private static AccessibilityViewProperty<CharSequence> stateDescriptionProperty() {
    return new AccessibilityViewProperty<CharSequence>(R.id.tag_state_description, CharSequence.class, 64, 30) {
        @RequiresApi(30)
        CharSequence frameworkGet(View param1View) {
          return ViewCompat.Api30Impl.getStateDescription(param1View);
        }
        
        @RequiresApi(30)
        void frameworkSet(View param1View, CharSequence param1CharSequence) {
          ViewCompat.Api30Impl.setStateDescription(param1View, param1CharSequence);
        }
        
        boolean shouldUpdate(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
          return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
        }
      };
  }
  
  public static void stopNestedScroll(@NonNull View paramView) {
    if (Build.VERSION.SDK_INT >= 21) {
      Api21Impl.stopNestedScroll(paramView);
      return;
    } 
    if (paramView instanceof NestedScrollingChild)
      ((NestedScrollingChild)paramView).stopNestedScroll(); 
  }
  
  public static void stopNestedScroll(@NonNull View paramView, int paramInt) {
    if (paramView instanceof NestedScrollingChild2) {
      ((NestedScrollingChild2)paramView).stopNestedScroll(paramInt);
      return;
    } 
    if (paramInt == 0)
      stopNestedScroll(paramView); 
  }
  
  private static void tickleInvalidationFlag(View paramView) {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }
  
  public static void updateDragShadow(@NonNull View paramView, @NonNull View.DragShadowBuilder paramDragShadowBuilder) {
    if (Build.VERSION.SDK_INT >= 24)
      Api24Impl.updateDragShadow(paramView, paramDragShadowBuilder); 
  }
  
  static class AccessibilityPaneVisibilityManager implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private final WeakHashMap<View, Boolean> mPanesToVisible = new WeakHashMap<View, Boolean>();
    
    @RequiresApi(19)
    private void checkPaneVisibility(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        ViewCompat.notifyViewAccessibilityStateChangedIfNeeded(param1View, b);
        this.mPanesToVisible.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    @RequiresApi(19)
    private void registerForLayoutCallback(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    @RequiresApi(19)
    private void unregisterForLayoutCallback(View param1View) {
      ViewCompat.Api16Impl.removeOnGlobalLayoutListener(param1View.getViewTreeObserver(), this);
    }
    
    @RequiresApi(19)
    void addAccessibilityPane(View param1View) {
      boolean bool;
      WeakHashMap<View, Boolean> weakHashMap = this.mPanesToVisible;
      if (param1View.isShown() && param1View.getWindowVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      weakHashMap.put(param1View, Boolean.valueOf(bool));
      param1View.addOnAttachStateChangeListener(this);
      if (ViewCompat.Api19Impl.isAttachedToWindow(param1View))
        registerForLayoutCallback(param1View); 
    }
    
    @RequiresApi(19)
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.mPanesToVisible.entrySet())
          checkPaneVisibility((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    @RequiresApi(19)
    public void onViewAttachedToWindow(View param1View) {
      registerForLayoutCallback(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
    
    @RequiresApi(19)
    void removeAccessibilityPane(View param1View) {
      this.mPanesToVisible.remove(param1View);
      param1View.removeOnAttachStateChangeListener(this);
      unregisterForLayoutCallback(param1View);
    }
  }
  
  static abstract class AccessibilityViewProperty<T> {
    private final int mContentChangeType;
    
    private final int mFrameworkMinimumSdk;
    
    private final int mTagKey;
    
    private final Class<T> mType;
    
    AccessibilityViewProperty(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    AccessibilityViewProperty(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.mTagKey = param1Int1;
      this.mType = param1Class;
      this.mContentChangeType = param1Int2;
      this.mFrameworkMinimumSdk = param1Int3;
    }
    
    private boolean extrasAvailable() {
      return (Build.VERSION.SDK_INT >= 19);
    }
    
    private boolean frameworkAvailable() {
      return (Build.VERSION.SDK_INT >= this.mFrameworkMinimumSdk);
    }
    
    boolean booleanNullToFalseEquals(Boolean param1Boolean1, Boolean param1Boolean2) {
      boolean bool1;
      boolean bool2;
      if (param1Boolean1 != null && param1Boolean1.booleanValue()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (param1Boolean2 != null && param1Boolean2.booleanValue()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      return (bool1 == bool2);
    }
    
    abstract T frameworkGet(View param1View);
    
    abstract void frameworkSet(View param1View, T param1T);
    
    T get(View param1View) {
      if (frameworkAvailable())
        return frameworkGet(param1View); 
      if (extrasAvailable()) {
        Object object = param1View.getTag(this.mTagKey);
        if (this.mType.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
    
    void set(View param1View, T param1T) {
      if (frameworkAvailable()) {
        frameworkSet(param1View, param1T);
        return;
      } 
      if (extrasAvailable() && shouldUpdate(get(param1View), param1T)) {
        ViewCompat.ensureAccessibilityDelegateCompat(param1View);
        param1View.setTag(this.mTagKey, param1T);
        ViewCompat.notifyViewAccessibilityStateChangedIfNeeded(param1View, this.mContentChangeType);
      } 
    }
    
    boolean shouldUpdate(T param1T1, T param1T2) {
      return param1T2.equals(param1T1) ^ true;
    }
  }
  
  @RequiresApi(15)
  static class Api15Impl {
    @DoNotInline
    static boolean hasOnClickListeners(@NonNull View param1View) {
      return param1View.hasOnClickListeners();
    }
  }
  
  @RequiresApi(16)
  static class Api16Impl {
    @DoNotInline
    static AccessibilityNodeProvider getAccessibilityNodeProvider(View param1View) {
      return param1View.getAccessibilityNodeProvider();
    }
    
    @DoNotInline
    static boolean getFitsSystemWindows(View param1View) {
      return param1View.getFitsSystemWindows();
    }
    
    @DoNotInline
    static int getImportantForAccessibility(View param1View) {
      return param1View.getImportantForAccessibility();
    }
    
    @DoNotInline
    static int getMinimumHeight(View param1View) {
      return param1View.getMinimumHeight();
    }
    
    @DoNotInline
    static int getMinimumWidth(View param1View) {
      return param1View.getMinimumWidth();
    }
    
    @DoNotInline
    static ViewParent getParentForAccessibility(View param1View) {
      return param1View.getParentForAccessibility();
    }
    
    @DoNotInline
    static int getWindowSystemUiVisibility(View param1View) {
      return param1View.getWindowSystemUiVisibility();
    }
    
    @DoNotInline
    static boolean hasOverlappingRendering(View param1View) {
      return param1View.hasOverlappingRendering();
    }
    
    @DoNotInline
    static boolean hasTransientState(View param1View) {
      return param1View.hasTransientState();
    }
    
    @DoNotInline
    static boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return param1View.performAccessibilityAction(param1Int, param1Bundle);
    }
    
    @DoNotInline
    static void postInvalidateOnAnimation(View param1View) {
      param1View.postInvalidateOnAnimation();
    }
    
    @DoNotInline
    static void postInvalidateOnAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateOnAnimation(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    @DoNotInline
    static void postOnAnimation(View param1View, Runnable param1Runnable) {
      param1View.postOnAnimation(param1Runnable);
    }
    
    @DoNotInline
    static void postOnAnimationDelayed(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postOnAnimationDelayed(param1Runnable, param1Long);
    }
    
    @DoNotInline
    static void removeOnGlobalLayoutListener(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
    
    @DoNotInline
    static void requestFitSystemWindows(View param1View) {
      param1View.requestFitSystemWindows();
    }
    
    @DoNotInline
    static void setBackground(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    @DoNotInline
    static void setHasTransientState(View param1View, boolean param1Boolean) {
      param1View.setHasTransientState(param1Boolean);
    }
    
    @DoNotInline
    static void setImportantForAccessibility(View param1View, int param1Int) {
      param1View.setImportantForAccessibility(param1Int);
    }
  }
  
  @RequiresApi(17)
  static class Api17Impl {
    @DoNotInline
    static int generateViewId() {
      return View.generateViewId();
    }
    
    @DoNotInline
    static Display getDisplay(@NonNull View param1View) {
      return param1View.getDisplay();
    }
    
    @DoNotInline
    static int getLabelFor(View param1View) {
      return param1View.getLabelFor();
    }
    
    @DoNotInline
    static int getLayoutDirection(View param1View) {
      return param1View.getLayoutDirection();
    }
    
    @DoNotInline
    static int getPaddingEnd(View param1View) {
      return param1View.getPaddingEnd();
    }
    
    @DoNotInline
    static int getPaddingStart(View param1View) {
      return param1View.getPaddingStart();
    }
    
    @DoNotInline
    static boolean isPaddingRelative(View param1View) {
      return param1View.isPaddingRelative();
    }
    
    @DoNotInline
    static void setLabelFor(View param1View, int param1Int) {
      param1View.setLabelFor(param1Int);
    }
    
    @DoNotInline
    static void setLayerPaint(View param1View, Paint param1Paint) {
      param1View.setLayerPaint(param1Paint);
    }
    
    @DoNotInline
    static void setLayoutDirection(View param1View, int param1Int) {
      param1View.setLayoutDirection(param1Int);
    }
    
    @DoNotInline
    static void setPaddingRelative(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.setPaddingRelative(param1Int1, param1Int2, param1Int3, param1Int4);
    }
  }
  
  @RequiresApi(18)
  static class Api18Impl {
    @DoNotInline
    static Rect getClipBounds(@NonNull View param1View) {
      return param1View.getClipBounds();
    }
    
    @DoNotInline
    static boolean isInLayout(@NonNull View param1View) {
      return param1View.isInLayout();
    }
    
    @DoNotInline
    static void setClipBounds(@NonNull View param1View, Rect param1Rect) {
      param1View.setClipBounds(param1Rect);
    }
  }
  
  @RequiresApi(19)
  static class Api19Impl {
    @DoNotInline
    static int getAccessibilityLiveRegion(View param1View) {
      return param1View.getAccessibilityLiveRegion();
    }
    
    @DoNotInline
    static boolean isAttachedToWindow(@NonNull View param1View) {
      return param1View.isAttachedToWindow();
    }
    
    @DoNotInline
    static boolean isLaidOut(@NonNull View param1View) {
      return param1View.isLaidOut();
    }
    
    @DoNotInline
    static boolean isLayoutDirectionResolved(@NonNull View param1View) {
      return param1View.isLayoutDirectionResolved();
    }
    
    @DoNotInline
    static void notifySubtreeAccessibilityStateChanged(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.notifySubtreeAccessibilityStateChanged(param1View1, param1View2, param1Int);
    }
    
    @DoNotInline
    static void setAccessibilityLiveRegion(View param1View, int param1Int) {
      param1View.setAccessibilityLiveRegion(param1Int);
    }
    
    @DoNotInline
    static void setContentChangeTypes(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
  
  @RequiresApi(20)
  static class Api20Impl {
    @DoNotInline
    static WindowInsets dispatchApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      return param1View.dispatchApplyWindowInsets(param1WindowInsets);
    }
    
    @DoNotInline
    static WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      return param1View.onApplyWindowInsets(param1WindowInsets);
    }
    
    @DoNotInline
    static void requestApplyInsets(View param1View) {
      param1View.requestApplyInsets();
    }
  }
  
  @RequiresApi(21)
  private static class Api21Impl {
    @DoNotInline
    static void callCompatInsetAnimationCallback(@NonNull WindowInsets param1WindowInsets, @NonNull View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(R.id.tag_window_insets_animation_callback);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    @DoNotInline
    static WindowInsetsCompat computeSystemWindowInsets(@NonNull View param1View, @NonNull WindowInsetsCompat param1WindowInsetsCompat, @NonNull Rect param1Rect) {
      WindowInsets windowInsets = param1WindowInsetsCompat.toWindowInsets();
      if (windowInsets != null)
        return WindowInsetsCompat.toWindowInsetsCompat(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1WindowInsetsCompat;
    }
    
    @DoNotInline
    static boolean dispatchNestedFling(@NonNull View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1View.dispatchNestedFling(param1Float1, param1Float2, param1Boolean);
    }
    
    @DoNotInline
    static boolean dispatchNestedPreFling(@NonNull View param1View, float param1Float1, float param1Float2) {
      return param1View.dispatchNestedPreFling(param1Float1, param1Float2);
    }
    
    @DoNotInline
    static boolean dispatchNestedPreScroll(View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      return param1View.dispatchNestedPreScroll(param1Int1, param1Int2, param1ArrayOfint1, param1ArrayOfint2);
    }
    
    @DoNotInline
    static boolean dispatchNestedScroll(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int[] param1ArrayOfint) {
      return param1View.dispatchNestedScroll(param1Int1, param1Int2, param1Int3, param1Int4, param1ArrayOfint);
    }
    
    @DoNotInline
    static ColorStateList getBackgroundTintList(View param1View) {
      return param1View.getBackgroundTintList();
    }
    
    @DoNotInline
    static PorterDuff.Mode getBackgroundTintMode(View param1View) {
      return param1View.getBackgroundTintMode();
    }
    
    @DoNotInline
    static float getElevation(View param1View) {
      return param1View.getElevation();
    }
    
    @DoNotInline
    @Nullable
    public static WindowInsetsCompat getRootWindowInsets(@NonNull View param1View) {
      return WindowInsetsCompat.Api21ReflectionHolder.getRootWindowInsets(param1View);
    }
    
    @DoNotInline
    static String getTransitionName(View param1View) {
      return param1View.getTransitionName();
    }
    
    @DoNotInline
    static float getTranslationZ(View param1View) {
      return param1View.getTranslationZ();
    }
    
    @DoNotInline
    static float getZ(@NonNull View param1View) {
      return param1View.getZ();
    }
    
    @DoNotInline
    static boolean hasNestedScrollingParent(View param1View) {
      return param1View.hasNestedScrollingParent();
    }
    
    @DoNotInline
    static boolean isImportantForAccessibility(View param1View) {
      return param1View.isImportantForAccessibility();
    }
    
    @DoNotInline
    static boolean isNestedScrollingEnabled(View param1View) {
      return param1View.isNestedScrollingEnabled();
    }
    
    @DoNotInline
    static void setBackgroundTintList(View param1View, ColorStateList param1ColorStateList) {
      param1View.setBackgroundTintList(param1ColorStateList);
    }
    
    @DoNotInline
    static void setBackgroundTintMode(View param1View, PorterDuff.Mode param1Mode) {
      param1View.setBackgroundTintMode(param1Mode);
    }
    
    @DoNotInline
    static void setElevation(View param1View, float param1Float) {
      param1View.setElevation(param1Float);
    }
    
    @DoNotInline
    static void setNestedScrollingEnabled(View param1View, boolean param1Boolean) {
      param1View.setNestedScrollingEnabled(param1Boolean);
    }
    
    @DoNotInline
    static void setOnApplyWindowInsetsListener(@NonNull final View v, @Nullable final OnApplyWindowInsetsListener listener) {
      if (Build.VERSION.SDK_INT < 30)
        v.setTag(R.id.tag_on_apply_window_listener, listener); 
      if (listener == null) {
        v.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)v.getTag(R.id.tag_window_insets_animation_callback));
        return;
      } 
      v.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            WindowInsetsCompat mLastInsets = null;
            
            public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
              WindowInsetsCompat windowInsetsCompat2 = WindowInsetsCompat.toWindowInsetsCompat(param2WindowInsets, param2View);
              int i = Build.VERSION.SDK_INT;
              if (i < 30) {
                ViewCompat.Api21Impl.callCompatInsetAnimationCallback(param2WindowInsets, v);
                if (windowInsetsCompat2.equals(this.mLastInsets))
                  return listener.onApplyWindowInsets(param2View, windowInsetsCompat2).toWindowInsets(); 
              } 
              this.mLastInsets = windowInsetsCompat2;
              WindowInsetsCompat windowInsetsCompat1 = listener.onApplyWindowInsets(param2View, windowInsetsCompat2);
              if (i >= 30)
                return windowInsetsCompat1.toWindowInsets(); 
              ViewCompat.requestApplyInsets(param2View);
              return windowInsetsCompat1.toWindowInsets();
            }
          });
    }
    
    @DoNotInline
    static void setTransitionName(View param1View, String param1String) {
      param1View.setTransitionName(param1String);
    }
    
    @DoNotInline
    static void setTranslationZ(View param1View, float param1Float) {
      param1View.setTranslationZ(param1Float);
    }
    
    @DoNotInline
    static void setZ(@NonNull View param1View, float param1Float) {
      param1View.setZ(param1Float);
    }
    
    @DoNotInline
    static boolean startNestedScroll(View param1View, int param1Int) {
      return param1View.startNestedScroll(param1Int);
    }
    
    @DoNotInline
    static void stopNestedScroll(View param1View) {
      param1View.stopNestedScroll();
    }
  }
  
  class null implements View.OnApplyWindowInsetsListener {
    WindowInsetsCompat mLastInsets = null;
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      WindowInsetsCompat windowInsetsCompat2 = WindowInsetsCompat.toWindowInsetsCompat(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        ViewCompat.Api21Impl.callCompatInsetAnimationCallback(param1WindowInsets, v);
        if (windowInsetsCompat2.equals(this.mLastInsets))
          return listener.onApplyWindowInsets(param1View, windowInsetsCompat2).toWindowInsets(); 
      } 
      this.mLastInsets = windowInsetsCompat2;
      WindowInsetsCompat windowInsetsCompat1 = listener.onApplyWindowInsets(param1View, windowInsetsCompat2);
      if (i >= 30)
        return windowInsetsCompat1.toWindowInsets(); 
      ViewCompat.requestApplyInsets(param1View);
      return windowInsetsCompat1.toWindowInsets();
    }
  }
  
  @RequiresApi(23)
  private static class Api23Impl {
    @Nullable
    public static WindowInsetsCompat getRootWindowInsets(@NonNull View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      WindowInsetsCompat windowInsetsCompat = WindowInsetsCompat.toWindowInsetsCompat(windowInsets);
      windowInsetsCompat.setRootWindowInsets(windowInsetsCompat);
      windowInsetsCompat.copyRootViewBounds(param1View.getRootView());
      return windowInsetsCompat;
    }
    
    @DoNotInline
    static int getScrollIndicators(@NonNull View param1View) {
      return param1View.getScrollIndicators();
    }
    
    @DoNotInline
    static void setScrollIndicators(@NonNull View param1View, int param1Int) {
      param1View.setScrollIndicators(param1Int);
    }
    
    @DoNotInline
    static void setScrollIndicators(@NonNull View param1View, int param1Int1, int param1Int2) {
      param1View.setScrollIndicators(param1Int1, param1Int2);
    }
  }
  
  @RequiresApi(24)
  static class Api24Impl {
    @DoNotInline
    static void cancelDragAndDrop(@NonNull View param1View) {
      param1View.cancelDragAndDrop();
    }
    
    @DoNotInline
    static void dispatchFinishTemporaryDetach(View param1View) {
      param1View.dispatchFinishTemporaryDetach();
    }
    
    @DoNotInline
    static void dispatchStartTemporaryDetach(View param1View) {
      param1View.dispatchStartTemporaryDetach();
    }
    
    @DoNotInline
    static void setPointerIcon(@NonNull View param1View, PointerIcon param1PointerIcon) {
      param1View.setPointerIcon(param1PointerIcon);
    }
    
    @DoNotInline
    static boolean startDragAndDrop(@NonNull View param1View, @Nullable ClipData param1ClipData, @NonNull View.DragShadowBuilder param1DragShadowBuilder, @Nullable Object param1Object, int param1Int) {
      return param1View.startDragAndDrop(param1ClipData, param1DragShadowBuilder, param1Object, param1Int);
    }
    
    @DoNotInline
    static void updateDragShadow(@NonNull View param1View, @NonNull View.DragShadowBuilder param1DragShadowBuilder) {
      param1View.updateDragShadow(param1DragShadowBuilder);
    }
  }
  
  @RequiresApi(26)
  static class Api26Impl {
    @DoNotInline
    static void addKeyboardNavigationClusters(@NonNull View param1View, Collection<View> param1Collection, int param1Int) {
      param1View.addKeyboardNavigationClusters(param1Collection, param1Int);
    }
    
    @DoNotInline
    static int getImportantForAutofill(View param1View) {
      return param1View.getImportantForAutofill();
    }
    
    @DoNotInline
    static int getNextClusterForwardId(@NonNull View param1View) {
      return param1View.getNextClusterForwardId();
    }
    
    @DoNotInline
    static boolean hasExplicitFocusable(@NonNull View param1View) {
      return param1View.hasExplicitFocusable();
    }
    
    @DoNotInline
    static boolean isFocusedByDefault(@NonNull View param1View) {
      return param1View.isFocusedByDefault();
    }
    
    @DoNotInline
    static boolean isImportantForAutofill(View param1View) {
      return param1View.isImportantForAutofill();
    }
    
    @DoNotInline
    static boolean isKeyboardNavigationCluster(@NonNull View param1View) {
      return param1View.isKeyboardNavigationCluster();
    }
    
    @DoNotInline
    static View keyboardNavigationClusterSearch(@NonNull View param1View1, View param1View2, int param1Int) {
      return param1View1.keyboardNavigationClusterSearch(param1View2, param1Int);
    }
    
    @DoNotInline
    static boolean restoreDefaultFocus(@NonNull View param1View) {
      return param1View.restoreDefaultFocus();
    }
    
    @DoNotInline
    static void setAutofillHints(@NonNull View param1View, String... param1VarArgs) {
      param1View.setAutofillHints(param1VarArgs);
    }
    
    @DoNotInline
    static void setFocusedByDefault(@NonNull View param1View, boolean param1Boolean) {
      param1View.setFocusedByDefault(param1Boolean);
    }
    
    @DoNotInline
    static void setImportantForAutofill(View param1View, int param1Int) {
      param1View.setImportantForAutofill(param1Int);
    }
    
    @DoNotInline
    static void setKeyboardNavigationCluster(@NonNull View param1View, boolean param1Boolean) {
      param1View.setKeyboardNavigationCluster(param1Boolean);
    }
    
    @DoNotInline
    static void setNextClusterForwardId(View param1View, int param1Int) {
      param1View.setNextClusterForwardId(param1Int);
    }
    
    @DoNotInline
    static void setTooltipText(@NonNull View param1View, CharSequence param1CharSequence) {
      param1View.setTooltipText(param1CharSequence);
    }
  }
  
  @RequiresApi(28)
  static class Api28Impl {
    @DoNotInline
    static void addOnUnhandledKeyEventListener(@NonNull View param1View, @NonNull ViewCompat.OnUnhandledKeyEventListenerCompat param1OnUnhandledKeyEventListenerCompat) {
      int i = R.id.tag_unhandled_key_listeners;
      SimpleArrayMap simpleArrayMap2 = (SimpleArrayMap)param1View.getTag(i);
      SimpleArrayMap simpleArrayMap1 = simpleArrayMap2;
      if (simpleArrayMap2 == null) {
        simpleArrayMap1 = new SimpleArrayMap();
        param1View.setTag(i, simpleArrayMap1);
      } 
      Objects.requireNonNull(param1OnUnhandledKeyEventListenerCompat);
      i i1 = new i(param1OnUnhandledKeyEventListenerCompat);
      simpleArrayMap1.put(param1OnUnhandledKeyEventListenerCompat, i1);
      param1View.addOnUnhandledKeyEventListener((View.OnUnhandledKeyEventListener)i1);
    }
    
    @DoNotInline
    static CharSequence getAccessibilityPaneTitle(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
    
    @DoNotInline
    static boolean isAccessibilityHeading(View param1View) {
      return param1View.isAccessibilityHeading();
    }
    
    @DoNotInline
    static boolean isScreenReaderFocusable(View param1View) {
      return param1View.isScreenReaderFocusable();
    }
    
    @DoNotInline
    static void removeOnUnhandledKeyEventListener(@NonNull View param1View, @NonNull ViewCompat.OnUnhandledKeyEventListenerCompat param1OnUnhandledKeyEventListenerCompat) {
      SimpleArrayMap simpleArrayMap = (SimpleArrayMap)param1View.getTag(R.id.tag_unhandled_key_listeners);
      if (simpleArrayMap == null)
        return; 
      View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)simpleArrayMap.get(param1OnUnhandledKeyEventListenerCompat);
      if (onUnhandledKeyEventListener != null)
        param1View.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener); 
    }
    
    @DoNotInline
    static <T> T requireViewById(View param1View, int param1Int) {
      return (T)param1View.requireViewById(param1Int);
    }
    
    @DoNotInline
    static void setAccessibilityHeading(View param1View, boolean param1Boolean) {
      param1View.setAccessibilityHeading(param1Boolean);
    }
    
    @DoNotInline
    static void setAccessibilityPaneTitle(View param1View, CharSequence param1CharSequence) {
      param1View.setAccessibilityPaneTitle(param1CharSequence);
    }
    
    @DoNotInline
    static void setScreenReaderFocusable(View param1View, boolean param1Boolean) {
      param1View.setScreenReaderFocusable(param1Boolean);
    }
  }
  
  @RequiresApi(29)
  private static class Api29Impl {
    @DoNotInline
    static View.AccessibilityDelegate getAccessibilityDelegate(View param1View) {
      return param1View.getAccessibilityDelegate();
    }
    
    @DoNotInline
    static List<Rect> getSystemGestureExclusionRects(View param1View) {
      return param1View.getSystemGestureExclusionRects();
    }
    
    @DoNotInline
    static void saveAttributeDataForStyleable(@NonNull View param1View, @NonNull Context param1Context, @NonNull int[] param1ArrayOfint, @Nullable AttributeSet param1AttributeSet, @NonNull TypedArray param1TypedArray, int param1Int1, int param1Int2) {
      param1View.saveAttributeDataForStyleable(param1Context, param1ArrayOfint, param1AttributeSet, param1TypedArray, param1Int1, param1Int2);
    }
    
    @DoNotInline
    static void setSystemGestureExclusionRects(View param1View, List<Rect> param1List) {
      param1View.setSystemGestureExclusionRects(param1List);
    }
  }
  
  @RequiresApi(30)
  private static class Api30Impl {
    @DoNotInline
    static CharSequence getStateDescription(View param1View) {
      return param1View.getStateDescription();
    }
    
    @Nullable
    public static WindowInsetsControllerCompat getWindowInsetsController(@NonNull View param1View) {
      WindowInsetsController windowInsetsController = param1View.getWindowInsetsController();
      return (windowInsetsController != null) ? WindowInsetsControllerCompat.toWindowInsetsControllerCompat(windowInsetsController) : null;
    }
    
    @DoNotInline
    static void setStateDescription(View param1View, CharSequence param1CharSequence) {
      param1View.setStateDescription(param1CharSequence);
    }
  }
  
  @RequiresApi(31)
  private static final class Api31Impl {
    @DoNotInline
    @Nullable
    public static String[] getReceiveContentMimeTypes(@NonNull View param1View) {
      return param1View.getReceiveContentMimeTypes();
    }
    
    @DoNotInline
    @Nullable
    public static ContentInfoCompat performReceiveContent(@NonNull View param1View, @NonNull ContentInfoCompat param1ContentInfoCompat) {
      ContentInfo contentInfo2 = param1ContentInfoCompat.toContentInfo();
      ContentInfo contentInfo1 = param1View.performReceiveContent(contentInfo2);
      return (contentInfo1 == null) ? null : ((contentInfo1 == contentInfo2) ? param1ContentInfoCompat : ContentInfoCompat.toContentInfoCompat(contentInfo1));
    }
    
    @DoNotInline
    public static void setOnReceiveContentListener(@NonNull View param1View, @Nullable String[] param1ArrayOfString, @Nullable OnReceiveContentListener param1OnReceiveContentListener) {
      if (param1OnReceiveContentListener == null) {
        param1View.setOnReceiveContentListener(param1ArrayOfString, null);
        return;
      } 
      param1View.setOnReceiveContentListener(param1ArrayOfString, new ViewCompat.OnReceiveContentListenerAdapter(param1OnReceiveContentListener));
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface FocusDirection {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface FocusRealDirection {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface FocusRelativeDirection {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface NestedScrollType {}
  
  @RequiresApi(31)
  private static final class OnReceiveContentListenerAdapter implements OnReceiveContentListener {
    @NonNull
    private final OnReceiveContentListener mJetpackListener;
    
    OnReceiveContentListenerAdapter(@NonNull OnReceiveContentListener param1OnReceiveContentListener) {
      this.mJetpackListener = param1OnReceiveContentListener;
    }
    
    @Nullable
    public ContentInfo onReceiveContent(@NonNull View param1View, @NonNull ContentInfo param1ContentInfo) {
      ContentInfoCompat contentInfoCompat2 = ContentInfoCompat.toContentInfoCompat(param1ContentInfo);
      ContentInfoCompat contentInfoCompat1 = this.mJetpackListener.onReceiveContent(param1View, contentInfoCompat2);
      return (contentInfoCompat1 == null) ? null : ((contentInfoCompat1 == contentInfoCompat2) ? param1ContentInfo : contentInfoCompat1.toContentInfo());
    }
  }
  
  public static interface OnUnhandledKeyEventListenerCompat {
    boolean onUnhandledKeyEvent(@NonNull View param1View, @NonNull KeyEvent param1KeyEvent);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface ScrollAxis {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface ScrollIndicators {}
  
  static class UnhandledKeyEventManager {
    private static final ArrayList<WeakReference<View>> sViewsWithListeners = new ArrayList<WeakReference<View>>();
    
    private SparseArray<WeakReference<View>> mCapturedKeys = null;
    
    private WeakReference<KeyEvent> mLastDispatchedPreViewKeyEvent = null;
    
    @Nullable
    private WeakHashMap<View, Boolean> mViewsContainingListeners = null;
    
    static UnhandledKeyEventManager at(View param1View) {
      int i = R.id.tag_unhandled_key_event_manager;
      UnhandledKeyEventManager unhandledKeyEventManager2 = (UnhandledKeyEventManager)param1View.getTag(i);
      UnhandledKeyEventManager unhandledKeyEventManager1 = unhandledKeyEventManager2;
      if (unhandledKeyEventManager2 == null) {
        unhandledKeyEventManager1 = new UnhandledKeyEventManager();
        param1View.setTag(i, unhandledKeyEventManager1);
      } 
      return unhandledKeyEventManager1;
    }
    
    @Nullable
    private View dispatchInOrder(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.mViewsContainingListeners;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = dispatchInOrder(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (onUnhandledKeyEvent(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> getCapturedKeys() {
      if (this.mCapturedKeys == null)
        this.mCapturedKeys = new SparseArray(); 
      return this.mCapturedKeys;
    }
    
    private boolean onUnhandledKeyEvent(@NonNull View param1View, @NonNull KeyEvent param1KeyEvent) {
      ArrayList<ViewCompat.OnUnhandledKeyEventListenerCompat> arrayList = (ArrayList)param1View.getTag(R.id.tag_unhandled_key_listeners);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((ViewCompat.OnUnhandledKeyEventListenerCompat)arrayList.get(i)).onUnhandledKeyEvent(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void recalcViewsWithUnhandled() {
      // Byte code:
      //   0: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   3: astore_3
      //   4: aload_0
      //   5: getfield mViewsContainingListeners : Ljava/util/WeakHashMap;
      //   8: astore_2
      //   9: aload_2
      //   10: ifnull -> 17
      //   13: aload_2
      //   14: invokevirtual clear : ()V
      //   17: getstatic androidx/core/view/ViewCompat$UnhandledKeyEventManager.sViewsWithListeners : Ljava/util/ArrayList;
      //   20: astore #4
      //   22: aload #4
      //   24: invokevirtual isEmpty : ()Z
      //   27: ifeq -> 31
      //   30: return
      //   31: aload #4
      //   33: monitorenter
      //   34: aload_0
      //   35: getfield mViewsContainingListeners : Ljava/util/WeakHashMap;
      //   38: ifnonnull -> 52
      //   41: aload_0
      //   42: new java/util/WeakHashMap
      //   45: dup
      //   46: invokespecial <init> : ()V
      //   49: putfield mViewsContainingListeners : Ljava/util/WeakHashMap;
      //   52: aload #4
      //   54: invokevirtual size : ()I
      //   57: iconst_1
      //   58: isub
      //   59: istore_1
      //   60: iload_1
      //   61: iflt -> 145
      //   64: getstatic androidx/core/view/ViewCompat$UnhandledKeyEventManager.sViewsWithListeners : Ljava/util/ArrayList;
      //   67: astore_2
      //   68: aload_2
      //   69: iload_1
      //   70: invokevirtual get : (I)Ljava/lang/Object;
      //   73: checkcast java/lang/ref/WeakReference
      //   76: invokevirtual get : ()Ljava/lang/Object;
      //   79: checkcast android/view/View
      //   82: astore #5
      //   84: aload #5
      //   86: ifnonnull -> 98
      //   89: aload_2
      //   90: iload_1
      //   91: invokevirtual remove : (I)Ljava/lang/Object;
      //   94: pop
      //   95: goto -> 155
      //   98: aload_0
      //   99: getfield mViewsContainingListeners : Ljava/util/WeakHashMap;
      //   102: aload #5
      //   104: aload_3
      //   105: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   108: pop
      //   109: aload #5
      //   111: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   114: astore_2
      //   115: aload_2
      //   116: instanceof android/view/View
      //   119: ifeq -> 155
      //   122: aload_0
      //   123: getfield mViewsContainingListeners : Ljava/util/WeakHashMap;
      //   126: aload_2
      //   127: checkcast android/view/View
      //   130: aload_3
      //   131: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   134: pop
      //   135: aload_2
      //   136: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   141: astore_2
      //   142: goto -> 115
      //   145: aload #4
      //   147: monitorexit
      //   148: return
      //   149: astore_2
      //   150: aload #4
      //   152: monitorexit
      //   153: aload_2
      //   154: athrow
      //   155: iload_1
      //   156: iconst_1
      //   157: isub
      //   158: istore_1
      //   159: goto -> 60
      // Exception table:
      //   from	to	target	type
      //   34	52	149	finally
      //   52	60	149	finally
      //   64	84	149	finally
      //   89	95	149	finally
      //   98	115	149	finally
      //   115	142	149	finally
      //   145	148	149	finally
      //   150	153	149	finally
    }
    
    static void registerListeningView(View param1View) {
      synchronized (sViewsWithListeners) {
        Iterator<WeakReference<View>> iterator = null.iterator();
        while (iterator.hasNext()) {
          if (((WeakReference<View>)iterator.next()).get() == param1View)
            return; 
        } 
        sViewsWithListeners.add(new WeakReference<View>(param1View));
        return;
      } 
    }
    
    static void unregisterListeningView(View param1View) {
      // Byte code:
      //   0: getstatic androidx/core/view/ViewCompat$UnhandledKeyEventManager.sViewsWithListeners : Ljava/util/ArrayList;
      //   3: astore_2
      //   4: aload_2
      //   5: monitorenter
      //   6: iconst_0
      //   7: istore_1
      //   8: getstatic androidx/core/view/ViewCompat$UnhandledKeyEventManager.sViewsWithListeners : Ljava/util/ArrayList;
      //   11: astore_3
      //   12: iload_1
      //   13: aload_3
      //   14: invokevirtual size : ()I
      //   17: if_icmpge -> 44
      //   20: aload_3
      //   21: iload_1
      //   22: invokevirtual get : (I)Ljava/lang/Object;
      //   25: checkcast java/lang/ref/WeakReference
      //   28: invokevirtual get : ()Ljava/lang/Object;
      //   31: aload_0
      //   32: if_acmpne -> 52
      //   35: aload_3
      //   36: iload_1
      //   37: invokevirtual remove : (I)Ljava/lang/Object;
      //   40: pop
      //   41: aload_2
      //   42: monitorexit
      //   43: return
      //   44: aload_2
      //   45: monitorexit
      //   46: return
      //   47: astore_0
      //   48: aload_2
      //   49: monitorexit
      //   50: aload_0
      //   51: athrow
      //   52: iload_1
      //   53: iconst_1
      //   54: iadd
      //   55: istore_1
      //   56: goto -> 8
      // Exception table:
      //   from	to	target	type
      //   8	43	47	finally
      //   44	46	47	finally
      //   48	50	47	finally
    }
    
    boolean dispatch(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        recalcViewsWithUnhandled(); 
      param1View = dispatchInOrder(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          getCapturedKeys().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean preDispatch(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.mLastDispatchedPreViewKeyEvent;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.mLastDispatchedPreViewKeyEvent = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = getCapturedKeys();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && ViewCompat.isAttachedToWindow(view))
          onUnhandledKeyEvent(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\view\ViewCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */