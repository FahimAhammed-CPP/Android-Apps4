package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.os.Build;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.lang.ref.WeakReference;

public final class ViewPropertyAnimatorCompat {
  static final int LISTENER_TAG_ID = 2113929216;
  
  Runnable mEndAction = null;
  
  int mOldLayerType = -1;
  
  Runnable mStartAction = null;
  
  private final WeakReference<View> mView;
  
  ViewPropertyAnimatorCompat(View paramView) {
    this.mView = new WeakReference<View>(paramView);
  }
  
  private void setListenerInternal(final View view, final ViewPropertyAnimatorListener listener) {
    if (listener != null) {
      view.animate().setListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
            public void onAnimationCancel(Animator param1Animator) {
              listener.onAnimationCancel(view);
            }
            
            public void onAnimationEnd(Animator param1Animator) {
              listener.onAnimationEnd(view);
            }
            
            public void onAnimationStart(Animator param1Animator) {
              listener.onAnimationStart(view);
            }
          });
      return;
    } 
    view.animate().setListener(null);
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat alpha(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat alphaBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().alphaBy(paramFloat); 
    return this;
  }
  
  public void cancel() {
    View view = this.mView.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long getDuration() {
    View view = this.mView.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  @Nullable
  public Interpolator getInterpolator() {
    View view = this.mView.get();
    return (view != null && Build.VERSION.SDK_INT >= 18) ? Api18Impl.getInterpolator(view.animate()) : null;
  }
  
  public long getStartDelay() {
    View view = this.mView.get();
    return (view != null) ? view.animate().getStartDelay() : 0L;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotation(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotation(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotationBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotationBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotationX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotationX(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotationXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotationXBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotationY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotationY(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat rotationYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().rotationYBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat scaleX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().scaleX(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat scaleXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().scaleXBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat scaleY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().scaleY(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat scaleYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().scaleYBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat setDuration(long paramLong) {
    View view = this.mView.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat setInterpolator(@Nullable Interpolator paramInterpolator) {
    View view = this.mView.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat setListener(@Nullable ViewPropertyAnimatorListener paramViewPropertyAnimatorListener) {
    View view = this.mView.get();
    if (view != null) {
      if (Build.VERSION.SDK_INT >= 16) {
        setListenerInternal(view, paramViewPropertyAnimatorListener);
        return this;
      } 
      view.setTag(2113929216, paramViewPropertyAnimatorListener);
      setListenerInternal(view, new ViewPropertyAnimatorListenerApi14(this));
    } 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat setStartDelay(long paramLong) {
    View view = this.mView.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat setUpdateListener(@Nullable ViewPropertyAnimatorUpdateListener paramViewPropertyAnimatorUpdateListener) {
    View view = this.mView.get();
    if (view != null && Build.VERSION.SDK_INT >= 19) {
      e e = null;
      if (paramViewPropertyAnimatorUpdateListener != null)
        e = new e(paramViewPropertyAnimatorUpdateListener, view); 
      Api19Impl.setUpdateListener(view.animate(), (ValueAnimator.AnimatorUpdateListener)e);
    } 
    return this;
  }
  
  public void start() {
    View view = this.mView.get();
    if (view != null)
      view.animate().start(); 
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationX(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().translationX(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationXBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().translationXBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationY(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationYBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().translationYBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationZ(float paramFloat) {
    View view = this.mView.get();
    if (view != null && Build.VERSION.SDK_INT >= 21)
      Api21Impl.translationZ(view.animate(), paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat translationZBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null && Build.VERSION.SDK_INT >= 21)
      Api21Impl.translationZBy(view.animate(), paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat withEndAction(@NonNull Runnable paramRunnable) {
    View view = this.mView.get();
    if (view != null) {
      if (Build.VERSION.SDK_INT >= 16) {
        Api16Impl.withEndAction(view.animate(), paramRunnable);
        return this;
      } 
      setListenerInternal(view, new ViewPropertyAnimatorListenerApi14(this));
      this.mEndAction = paramRunnable;
    } 
    return this;
  }
  
  @SuppressLint({"WrongConstant"})
  @NonNull
  public ViewPropertyAnimatorCompat withLayer() {
    View view = this.mView.get();
    if (view != null) {
      if (Build.VERSION.SDK_INT >= 16) {
        Api16Impl.withLayer(view.animate());
        return this;
      } 
      this.mOldLayerType = view.getLayerType();
      setListenerInternal(view, new ViewPropertyAnimatorListenerApi14(this));
    } 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat withStartAction(@NonNull Runnable paramRunnable) {
    View view = this.mView.get();
    if (view != null) {
      if (Build.VERSION.SDK_INT >= 16) {
        Api16Impl.withStartAction(view.animate(), paramRunnable);
        return this;
      } 
      setListenerInternal(view, new ViewPropertyAnimatorListenerApi14(this));
      this.mStartAction = paramRunnable;
    } 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat x(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().x(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat xBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().xBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat y(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().y(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat yBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null)
      view.animate().yBy(paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat z(float paramFloat) {
    View view = this.mView.get();
    if (view != null && Build.VERSION.SDK_INT >= 21)
      Api21Impl.z(view.animate(), paramFloat); 
    return this;
  }
  
  @NonNull
  public ViewPropertyAnimatorCompat zBy(float paramFloat) {
    View view = this.mView.get();
    if (view != null && Build.VERSION.SDK_INT >= 21)
      Api21Impl.zBy(view.animate(), paramFloat); 
    return this;
  }
  
  @RequiresApi(16)
  static class Api16Impl {
    @DoNotInline
    static ViewPropertyAnimator withEndAction(ViewPropertyAnimator param1ViewPropertyAnimator, Runnable param1Runnable) {
      return param1ViewPropertyAnimator.withEndAction(param1Runnable);
    }
    
    @DoNotInline
    static ViewPropertyAnimator withLayer(ViewPropertyAnimator param1ViewPropertyAnimator) {
      return param1ViewPropertyAnimator.withLayer();
    }
    
    @DoNotInline
    static ViewPropertyAnimator withStartAction(ViewPropertyAnimator param1ViewPropertyAnimator, Runnable param1Runnable) {
      return param1ViewPropertyAnimator.withStartAction(param1Runnable);
    }
  }
  
  @RequiresApi(18)
  static class Api18Impl {
    @DoNotInline
    static Interpolator getInterpolator(ViewPropertyAnimator param1ViewPropertyAnimator) {
      return (Interpolator)param1ViewPropertyAnimator.getInterpolator();
    }
  }
  
  @RequiresApi(19)
  static class Api19Impl {
    @DoNotInline
    static ViewPropertyAnimator setUpdateListener(ViewPropertyAnimator param1ViewPropertyAnimator, ValueAnimator.AnimatorUpdateListener param1AnimatorUpdateListener) {
      return param1ViewPropertyAnimator.setUpdateListener(param1AnimatorUpdateListener);
    }
  }
  
  @RequiresApi(21)
  static class Api21Impl {
    @DoNotInline
    static ViewPropertyAnimator translationZ(ViewPropertyAnimator param1ViewPropertyAnimator, float param1Float) {
      return param1ViewPropertyAnimator.translationZ(param1Float);
    }
    
    @DoNotInline
    static ViewPropertyAnimator translationZBy(ViewPropertyAnimator param1ViewPropertyAnimator, float param1Float) {
      return param1ViewPropertyAnimator.translationZBy(param1Float);
    }
    
    @DoNotInline
    static ViewPropertyAnimator z(ViewPropertyAnimator param1ViewPropertyAnimator, float param1Float) {
      return param1ViewPropertyAnimator.z(param1Float);
    }
    
    @DoNotInline
    static ViewPropertyAnimator zBy(ViewPropertyAnimator param1ViewPropertyAnimator, float param1Float) {
      return param1ViewPropertyAnimator.zBy(param1Float);
    }
  }
  
  static class ViewPropertyAnimatorListenerApi14 implements ViewPropertyAnimatorListener {
    boolean mAnimEndCalled;
    
    ViewPropertyAnimatorCompat mVpa;
    
    ViewPropertyAnimatorListenerApi14(ViewPropertyAnimatorCompat param1ViewPropertyAnimatorCompat) {
      this.mVpa = param1ViewPropertyAnimatorCompat;
    }
    
    public void onAnimationCancel(@NonNull View param1View) {
      Object object = param1View.getTag(2113929216);
      if (object instanceof ViewPropertyAnimatorListener) {
        object = object;
      } else {
        object = null;
      } 
      if (object != null)
        object.onAnimationCancel(param1View); 
    }
    
    @SuppressLint({"WrongConstant"})
    public void onAnimationEnd(@NonNull View param1View) {
      int i = this.mVpa.mOldLayerType;
      ViewPropertyAnimatorListener viewPropertyAnimatorListener = null;
      if (i > -1) {
        param1View.setLayerType(i, null);
        this.mVpa.mOldLayerType = -1;
      } 
      if (Build.VERSION.SDK_INT >= 16 || !this.mAnimEndCalled) {
        ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = this.mVpa;
        Runnable runnable = viewPropertyAnimatorCompat.mEndAction;
        if (runnable != null) {
          viewPropertyAnimatorCompat.mEndAction = null;
          runnable.run();
        } 
        Object object = param1View.getTag(2113929216);
        if (object instanceof ViewPropertyAnimatorListener)
          viewPropertyAnimatorListener = (ViewPropertyAnimatorListener)object; 
        if (viewPropertyAnimatorListener != null)
          viewPropertyAnimatorListener.onAnimationEnd(param1View); 
        this.mAnimEndCalled = true;
      } 
    }
    
    public void onAnimationStart(@NonNull View param1View) {
      this.mAnimEndCalled = false;
      int i = this.mVpa.mOldLayerType;
      ViewPropertyAnimatorListener viewPropertyAnimatorListener = null;
      if (i > -1)
        param1View.setLayerType(2, null); 
      ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = this.mVpa;
      Runnable runnable = viewPropertyAnimatorCompat.mStartAction;
      if (runnable != null) {
        viewPropertyAnimatorCompat.mStartAction = null;
        runnable.run();
      } 
      Object object = param1View.getTag(2113929216);
      if (object instanceof ViewPropertyAnimatorListener)
        viewPropertyAnimatorListener = (ViewPropertyAnimatorListener)object; 
      if (viewPropertyAnimatorListener != null)
        viewPropertyAnimatorListener.onAnimationStart(param1View); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\view\ViewPropertyAnimatorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */