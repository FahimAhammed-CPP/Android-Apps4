package androidx.core.view;

import android.os.Build;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.internal.view.SupportMenu;

public final class MenuCompat {
  public static void setGroupDividerEnabled(@NonNull Menu paramMenu, boolean paramBoolean) {
    if (paramMenu instanceof SupportMenu) {
      ((SupportMenu)paramMenu).setGroupDividerEnabled(paramBoolean);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 28)
      Api28Impl.setGroupDividerEnabled(paramMenu, paramBoolean); 
  }
  
  @Deprecated
  public static void setShowAsAction(MenuItem paramMenuItem, int paramInt) {
    paramMenuItem.setShowAsAction(paramInt);
  }
  
  @RequiresApi(28)
  static class Api28Impl {
    @DoNotInline
    static void setGroupDividerEnabled(Menu param1Menu, boolean param1Boolean) {
      param1Menu.setGroupDividerEnabled(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\view\MenuCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */