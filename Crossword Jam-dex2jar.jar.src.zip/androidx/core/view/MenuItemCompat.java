package androidx.core.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.internal.view.SupportMenuItem;

public final class MenuItemCompat {
  @Deprecated
  public static final int SHOW_AS_ACTION_ALWAYS = 2;
  
  @Deprecated
  public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW = 8;
  
  @Deprecated
  public static final int SHOW_AS_ACTION_IF_ROOM = 1;
  
  @Deprecated
  public static final int SHOW_AS_ACTION_NEVER = 0;
  
  @Deprecated
  public static final int SHOW_AS_ACTION_WITH_TEXT = 4;
  
  private static final String TAG = "MenuItemCompat";
  
  @Deprecated
  public static boolean collapseActionView(MenuItem paramMenuItem) {
    return paramMenuItem.collapseActionView();
  }
  
  @Deprecated
  public static boolean expandActionView(MenuItem paramMenuItem) {
    return paramMenuItem.expandActionView();
  }
  
  @Nullable
  public static ActionProvider getActionProvider(@NonNull MenuItem paramMenuItem) {
    if (paramMenuItem instanceof SupportMenuItem)
      return ((SupportMenuItem)paramMenuItem).getSupportActionProvider(); 
    Log.w("MenuItemCompat", "getActionProvider: item does not implement SupportMenuItem; returning null");
    return null;
  }
  
  @Deprecated
  public static View getActionView(MenuItem paramMenuItem) {
    return paramMenuItem.getActionView();
  }
  
  public static int getAlphabeticModifiers(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getAlphabeticModifiers() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getAlphabeticModifiers(paramMenuItem) : 0);
  }
  
  @Nullable
  public static CharSequence getContentDescription(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getContentDescription() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getContentDescription(paramMenuItem) : null);
  }
  
  @Nullable
  public static ColorStateList getIconTintList(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getIconTintList() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getIconTintList(paramMenuItem) : null);
  }
  
  @Nullable
  public static PorterDuff.Mode getIconTintMode(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getIconTintMode() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getIconTintMode(paramMenuItem) : null);
  }
  
  public static int getNumericModifiers(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getNumericModifiers() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getNumericModifiers(paramMenuItem) : 0);
  }
  
  @Nullable
  public static CharSequence getTooltipText(@NonNull MenuItem paramMenuItem) {
    return (paramMenuItem instanceof SupportMenuItem) ? ((SupportMenuItem)paramMenuItem).getTooltipText() : ((Build.VERSION.SDK_INT >= 26) ? Api26Impl.getTooltipText(paramMenuItem) : null);
  }
  
  @Deprecated
  public static boolean isActionViewExpanded(MenuItem paramMenuItem) {
    return paramMenuItem.isActionViewExpanded();
  }
  
  @Nullable
  public static MenuItem setActionProvider(@NonNull MenuItem paramMenuItem, @Nullable ActionProvider paramActionProvider) {
    if (paramMenuItem instanceof SupportMenuItem)
      return (MenuItem)((SupportMenuItem)paramMenuItem).setSupportActionProvider(paramActionProvider); 
    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
    return paramMenuItem;
  }
  
  @Deprecated
  public static MenuItem setActionView(MenuItem paramMenuItem, int paramInt) {
    return paramMenuItem.setActionView(paramInt);
  }
  
  @Deprecated
  public static MenuItem setActionView(MenuItem paramMenuItem, View paramView) {
    return paramMenuItem.setActionView(paramView);
  }
  
  public static void setAlphabeticShortcut(@NonNull MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setAlphabeticShortcut(paramChar, paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setAlphabeticShortcut(paramMenuItem, paramChar, paramInt); 
  }
  
  public static void setContentDescription(@NonNull MenuItem paramMenuItem, @Nullable CharSequence paramCharSequence) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setContentDescription(paramCharSequence);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setContentDescription(paramMenuItem, paramCharSequence); 
  }
  
  public static void setIconTintList(@NonNull MenuItem paramMenuItem, @Nullable ColorStateList paramColorStateList) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setIconTintList(paramColorStateList);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setIconTintList(paramMenuItem, paramColorStateList); 
  }
  
  public static void setIconTintMode(@NonNull MenuItem paramMenuItem, @Nullable PorterDuff.Mode paramMode) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setIconTintMode(paramMode);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setIconTintMode(paramMenuItem, paramMode); 
  }
  
  public static void setNumericShortcut(@NonNull MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setNumericShortcut(paramChar, paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setNumericShortcut(paramMenuItem, paramChar, paramInt); 
  }
  
  @Deprecated
  public static MenuItem setOnActionExpandListener(MenuItem paramMenuItem, final OnActionExpandListener listener) {
    return paramMenuItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
          public boolean onMenuItemActionCollapse(MenuItem param1MenuItem) {
            return listener.onMenuItemActionCollapse(param1MenuItem);
          }
          
          public boolean onMenuItemActionExpand(MenuItem param1MenuItem) {
            return listener.onMenuItemActionExpand(param1MenuItem);
          }
        });
  }
  
  public static void setShortcut(@NonNull MenuItem paramMenuItem, char paramChar1, char paramChar2, int paramInt1, int paramInt2) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setShortcut(paramChar1, paramChar2, paramInt1, paramInt2);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setShortcut(paramMenuItem, paramChar1, paramChar2, paramInt1, paramInt2); 
  }
  
  @Deprecated
  public static void setShowAsAction(MenuItem paramMenuItem, int paramInt) {
    paramMenuItem.setShowAsAction(paramInt);
  }
  
  public static void setTooltipText(@NonNull MenuItem paramMenuItem, @Nullable CharSequence paramCharSequence) {
    if (paramMenuItem instanceof SupportMenuItem) {
      ((SupportMenuItem)paramMenuItem).setTooltipText(paramCharSequence);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26)
      Api26Impl.setTooltipText(paramMenuItem, paramCharSequence); 
  }
  
  @RequiresApi(26)
  static class Api26Impl {
    @DoNotInline
    static int getAlphabeticModifiers(MenuItem param1MenuItem) {
      return param1MenuItem.getAlphabeticModifiers();
    }
    
    @DoNotInline
    static CharSequence getContentDescription(MenuItem param1MenuItem) {
      return param1MenuItem.getContentDescription();
    }
    
    @DoNotInline
    static ColorStateList getIconTintList(MenuItem param1MenuItem) {
      return param1MenuItem.getIconTintList();
    }
    
    @DoNotInline
    static PorterDuff.Mode getIconTintMode(MenuItem param1MenuItem) {
      return param1MenuItem.getIconTintMode();
    }
    
    @DoNotInline
    static int getNumericModifiers(MenuItem param1MenuItem) {
      return param1MenuItem.getNumericModifiers();
    }
    
    @DoNotInline
    static CharSequence getTooltipText(MenuItem param1MenuItem) {
      return param1MenuItem.getTooltipText();
    }
    
    @DoNotInline
    static MenuItem setAlphabeticShortcut(MenuItem param1MenuItem, char param1Char, int param1Int) {
      return param1MenuItem.setAlphabeticShortcut(param1Char, param1Int);
    }
    
    @DoNotInline
    static MenuItem setContentDescription(MenuItem param1MenuItem, CharSequence param1CharSequence) {
      return param1MenuItem.setContentDescription(param1CharSequence);
    }
    
    @DoNotInline
    static MenuItem setIconTintList(MenuItem param1MenuItem, ColorStateList param1ColorStateList) {
      return param1MenuItem.setIconTintList(param1ColorStateList);
    }
    
    @DoNotInline
    static MenuItem setIconTintMode(MenuItem param1MenuItem, PorterDuff.Mode param1Mode) {
      return param1MenuItem.setIconTintMode(param1Mode);
    }
    
    @DoNotInline
    static MenuItem setNumericShortcut(MenuItem param1MenuItem, char param1Char, int param1Int) {
      return param1MenuItem.setNumericShortcut(param1Char, param1Int);
    }
    
    @DoNotInline
    static MenuItem setShortcut(MenuItem param1MenuItem, char param1Char1, char param1Char2, int param1Int1, int param1Int2) {
      return param1MenuItem.setShortcut(param1Char1, param1Char2, param1Int1, param1Int2);
    }
    
    @DoNotInline
    static MenuItem setTooltipText(MenuItem param1MenuItem, CharSequence param1CharSequence) {
      return param1MenuItem.setTooltipText(param1CharSequence);
    }
  }
  
  @Deprecated
  public static interface OnActionExpandListener {
    boolean onMenuItemActionCollapse(MenuItem param1MenuItem);
    
    boolean onMenuItemActionExpand(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\view\MenuItemCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */