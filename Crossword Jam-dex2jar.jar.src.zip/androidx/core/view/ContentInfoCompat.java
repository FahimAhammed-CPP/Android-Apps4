package androidx.core.view;

import android.content.ClipData;
import android.content.ClipDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.ContentInfo;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.core.util.Preconditions;
import androidx.core.util.Predicate;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public final class ContentInfoCompat {
  public static final int FLAG_CONVERT_TO_PLAIN_TEXT = 1;
  
  public static final int SOURCE_APP = 0;
  
  public static final int SOURCE_AUTOFILL = 4;
  
  public static final int SOURCE_CLIPBOARD = 1;
  
  public static final int SOURCE_DRAG_AND_DROP = 3;
  
  public static final int SOURCE_INPUT_METHOD = 2;
  
  public static final int SOURCE_PROCESS_TEXT = 5;
  
  @NonNull
  private final Compat mCompat;
  
  ContentInfoCompat(@NonNull Compat paramCompat) {
    this.mCompat = paramCompat;
  }
  
  @NonNull
  static ClipData buildClipData(@NonNull ClipDescription paramClipDescription, @NonNull List<ClipData.Item> paramList) {
    ClipData clipData = new ClipData(new ClipDescription(paramClipDescription), paramList.get(0));
    for (int i = 1; i < paramList.size(); i++)
      clipData.addItem(paramList.get(i)); 
    return clipData;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  static String flagsToString(int paramInt) {
    return ((paramInt & 0x1) != 0) ? "FLAG_CONVERT_TO_PLAIN_TEXT" : String.valueOf(paramInt);
  }
  
  @NonNull
  static Pair<ClipData, ClipData> partition(@NonNull ClipData paramClipData, @NonNull Predicate<ClipData.Item> paramPredicate) {
    int i = 0;
    ArrayList<ClipData.Item> arrayList2 = null;
    ArrayList<ClipData.Item> arrayList1 = arrayList2;
    while (i < paramClipData.getItemCount()) {
      ClipData.Item item = paramClipData.getItemAt(i);
      if (paramPredicate.test(item)) {
        ArrayList<ClipData.Item> arrayList = arrayList2;
        if (arrayList2 == null)
          arrayList = new ArrayList(); 
        arrayList.add(item);
        arrayList2 = arrayList;
      } else {
        ArrayList<ClipData.Item> arrayList = arrayList1;
        if (arrayList1 == null)
          arrayList = new ArrayList<ClipData.Item>(); 
        arrayList.add(item);
        arrayList1 = arrayList;
      } 
      i++;
    } 
    return (arrayList2 == null) ? Pair.create(null, paramClipData) : ((arrayList1 == null) ? Pair.create(paramClipData, null) : Pair.create(buildClipData(paramClipData.getDescription(), arrayList2), buildClipData(paramClipData.getDescription(), arrayList1)));
  }
  
  @NonNull
  @RequiresApi(31)
  public static Pair<ContentInfo, ContentInfo> partition(@NonNull ContentInfo paramContentInfo, @NonNull Predicate<ClipData.Item> paramPredicate) {
    return Api31Impl.partition(paramContentInfo, paramPredicate);
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  static String sourceToString(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? String.valueOf(paramInt) : "SOURCE_PROCESS_TEXT") : "SOURCE_AUTOFILL") : "SOURCE_DRAG_AND_DROP") : "SOURCE_INPUT_METHOD") : "SOURCE_CLIPBOARD") : "SOURCE_APP";
  }
  
  @NonNull
  @RequiresApi(31)
  public static ContentInfoCompat toContentInfoCompat(@NonNull ContentInfo paramContentInfo) {
    return new ContentInfoCompat(new Compat31Impl(paramContentInfo));
  }
  
  @NonNull
  public ClipData getClip() {
    return this.mCompat.getClip();
  }
  
  @Nullable
  public Bundle getExtras() {
    return this.mCompat.getExtras();
  }
  
  public int getFlags() {
    return this.mCompat.getFlags();
  }
  
  @Nullable
  public Uri getLinkUri() {
    return this.mCompat.getLinkUri();
  }
  
  public int getSource() {
    return this.mCompat.getSource();
  }
  
  @NonNull
  public Pair<ContentInfoCompat, ContentInfoCompat> partition(@NonNull Predicate<ClipData.Item> paramPredicate) {
    ClipData clipData = this.mCompat.getClip();
    int i = clipData.getItemCount();
    ContentInfoCompat contentInfoCompat = null;
    if (i == 1) {
      boolean bool = paramPredicate.test(clipData.getItemAt(0));
      if (bool) {
        ContentInfoCompat contentInfoCompat1 = this;
      } else {
        paramPredicate = null;
      } 
      if (!bool)
        contentInfoCompat = this; 
      return Pair.create(paramPredicate, contentInfoCompat);
    } 
    Pair<ClipData, ClipData> pair = partition(clipData, paramPredicate);
    return (pair.first == null) ? Pair.create(null, this) : ((pair.second == null) ? Pair.create(this, null) : Pair.create((new Builder(this)).setClip((ClipData)pair.first).build(), (new Builder(this)).setClip((ClipData)pair.second).build()));
  }
  
  @NonNull
  @RequiresApi(31)
  public ContentInfo toContentInfo() {
    ContentInfo contentInfo = this.mCompat.getWrapped();
    Objects.requireNonNull(contentInfo);
    return contentInfo;
  }
  
  @NonNull
  public String toString() {
    return this.mCompat.toString();
  }
  
  @RequiresApi(31)
  private static final class Api31Impl {
    @DoNotInline
    @NonNull
    public static Pair<ContentInfo, ContentInfo> partition(@NonNull ContentInfo param1ContentInfo, @NonNull Predicate<ClipData.Item> param1Predicate) {
      ClipData clipData = param1ContentInfo.getClip();
      if (clipData.getItemCount() == 1) {
        boolean bool = param1Predicate.test(clipData.getItemAt(0));
        if (bool) {
          ContentInfo contentInfo = param1ContentInfo;
        } else {
          param1Predicate = null;
        } 
        if (bool)
          param1ContentInfo = null; 
        return Pair.create(param1Predicate, param1ContentInfo);
      } 
      Objects.requireNonNull(param1Predicate);
      Pair<ClipData, ClipData> pair = ContentInfoCompat.partition(clipData, (Predicate<ClipData.Item>)new j(param1Predicate));
      return (pair.first == null) ? Pair.create(null, param1ContentInfo) : ((pair.second == null) ? Pair.create(param1ContentInfo, null) : Pair.create((new ContentInfo.Builder(param1ContentInfo)).setClip((ClipData)pair.first).build(), (new ContentInfo.Builder(param1ContentInfo)).setClip((ClipData)pair.second).build()));
    }
  }
  
  public static final class Builder {
    @NonNull
    private final ContentInfoCompat.BuilderCompat mBuilderCompat;
    
    public Builder(@NonNull ClipData param1ClipData, int param1Int) {
      if (Build.VERSION.SDK_INT >= 31) {
        this.mBuilderCompat = new ContentInfoCompat.BuilderCompat31Impl(param1ClipData, param1Int);
        return;
      } 
      this.mBuilderCompat = new ContentInfoCompat.BuilderCompatImpl(param1ClipData, param1Int);
    }
    
    public Builder(@NonNull ContentInfoCompat param1ContentInfoCompat) {
      if (Build.VERSION.SDK_INT >= 31) {
        this.mBuilderCompat = new ContentInfoCompat.BuilderCompat31Impl(param1ContentInfoCompat);
        return;
      } 
      this.mBuilderCompat = new ContentInfoCompat.BuilderCompatImpl(param1ContentInfoCompat);
    }
    
    @NonNull
    public ContentInfoCompat build() {
      return this.mBuilderCompat.build();
    }
    
    @NonNull
    public Builder setClip(@NonNull ClipData param1ClipData) {
      this.mBuilderCompat.setClip(param1ClipData);
      return this;
    }
    
    @NonNull
    public Builder setExtras(@Nullable Bundle param1Bundle) {
      this.mBuilderCompat.setExtras(param1Bundle);
      return this;
    }
    
    @NonNull
    public Builder setFlags(int param1Int) {
      this.mBuilderCompat.setFlags(param1Int);
      return this;
    }
    
    @NonNull
    public Builder setLinkUri(@Nullable Uri param1Uri) {
      this.mBuilderCompat.setLinkUri(param1Uri);
      return this;
    }
    
    @NonNull
    public Builder setSource(int param1Int) {
      this.mBuilderCompat.setSource(param1Int);
      return this;
    }
  }
  
  private static interface BuilderCompat {
    @NonNull
    ContentInfoCompat build();
    
    void setClip(@NonNull ClipData param1ClipData);
    
    void setExtras(@Nullable Bundle param1Bundle);
    
    void setFlags(int param1Int);
    
    void setLinkUri(@Nullable Uri param1Uri);
    
    void setSource(int param1Int);
  }
  
  @RequiresApi(31)
  private static final class BuilderCompat31Impl implements BuilderCompat {
    @NonNull
    private final ContentInfo.Builder mPlatformBuilder;
    
    BuilderCompat31Impl(@NonNull ClipData param1ClipData, int param1Int) {
      this.mPlatformBuilder = new ContentInfo.Builder(param1ClipData, param1Int);
    }
    
    BuilderCompat31Impl(@NonNull ContentInfoCompat param1ContentInfoCompat) {
      this.mPlatformBuilder = new ContentInfo.Builder(param1ContentInfoCompat.toContentInfo());
    }
    
    @NonNull
    public ContentInfoCompat build() {
      return new ContentInfoCompat(new ContentInfoCompat.Compat31Impl(this.mPlatformBuilder.build()));
    }
    
    public void setClip(@NonNull ClipData param1ClipData) {
      this.mPlatformBuilder.setClip(param1ClipData);
    }
    
    public void setExtras(@Nullable Bundle param1Bundle) {
      this.mPlatformBuilder.setExtras(param1Bundle);
    }
    
    public void setFlags(int param1Int) {
      this.mPlatformBuilder.setFlags(param1Int);
    }
    
    public void setLinkUri(@Nullable Uri param1Uri) {
      this.mPlatformBuilder.setLinkUri(param1Uri);
    }
    
    public void setSource(int param1Int) {
      this.mPlatformBuilder.setSource(param1Int);
    }
  }
  
  private static final class BuilderCompatImpl implements BuilderCompat {
    @NonNull
    ClipData mClip;
    
    @Nullable
    Bundle mExtras;
    
    int mFlags;
    
    @Nullable
    Uri mLinkUri;
    
    int mSource;
    
    BuilderCompatImpl(@NonNull ClipData param1ClipData, int param1Int) {
      this.mClip = param1ClipData;
      this.mSource = param1Int;
    }
    
    BuilderCompatImpl(@NonNull ContentInfoCompat param1ContentInfoCompat) {
      this.mClip = param1ContentInfoCompat.getClip();
      this.mSource = param1ContentInfoCompat.getSource();
      this.mFlags = param1ContentInfoCompat.getFlags();
      this.mLinkUri = param1ContentInfoCompat.getLinkUri();
      this.mExtras = param1ContentInfoCompat.getExtras();
    }
    
    @NonNull
    public ContentInfoCompat build() {
      return new ContentInfoCompat(new ContentInfoCompat.CompatImpl(this));
    }
    
    public void setClip(@NonNull ClipData param1ClipData) {
      this.mClip = param1ClipData;
    }
    
    public void setExtras(@Nullable Bundle param1Bundle) {
      this.mExtras = param1Bundle;
    }
    
    public void setFlags(int param1Int) {
      this.mFlags = param1Int;
    }
    
    public void setLinkUri(@Nullable Uri param1Uri) {
      this.mLinkUri = param1Uri;
    }
    
    public void setSource(int param1Int) {
      this.mSource = param1Int;
    }
  }
  
  private static interface Compat {
    @NonNull
    ClipData getClip();
    
    @Nullable
    Bundle getExtras();
    
    int getFlags();
    
    @Nullable
    Uri getLinkUri();
    
    int getSource();
    
    @Nullable
    ContentInfo getWrapped();
  }
  
  @RequiresApi(31)
  private static final class Compat31Impl implements Compat {
    @NonNull
    private final ContentInfo mWrapped;
    
    Compat31Impl(@NonNull ContentInfo param1ContentInfo) {
      this.mWrapped = (ContentInfo)Preconditions.checkNotNull(param1ContentInfo);
    }
    
    @NonNull
    public ClipData getClip() {
      return this.mWrapped.getClip();
    }
    
    @Nullable
    public Bundle getExtras() {
      return this.mWrapped.getExtras();
    }
    
    public int getFlags() {
      return this.mWrapped.getFlags();
    }
    
    @Nullable
    public Uri getLinkUri() {
      return this.mWrapped.getLinkUri();
    }
    
    public int getSource() {
      return this.mWrapped.getSource();
    }
    
    @NonNull
    public ContentInfo getWrapped() {
      return this.mWrapped;
    }
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ContentInfoCompat{");
      stringBuilder.append(this.mWrapped);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
  
  private static final class CompatImpl implements Compat {
    @NonNull
    private final ClipData mClip;
    
    @Nullable
    private final Bundle mExtras;
    
    private final int mFlags;
    
    @Nullable
    private final Uri mLinkUri;
    
    private final int mSource;
    
    CompatImpl(ContentInfoCompat.BuilderCompatImpl param1BuilderCompatImpl) {
      this.mClip = (ClipData)Preconditions.checkNotNull(param1BuilderCompatImpl.mClip);
      this.mSource = Preconditions.checkArgumentInRange(param1BuilderCompatImpl.mSource, 0, 5, "source");
      this.mFlags = Preconditions.checkFlagsArgument(param1BuilderCompatImpl.mFlags, 1);
      this.mLinkUri = param1BuilderCompatImpl.mLinkUri;
      this.mExtras = param1BuilderCompatImpl.mExtras;
    }
    
    @NonNull
    public ClipData getClip() {
      return this.mClip;
    }
    
    @Nullable
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public int getFlags() {
      return this.mFlags;
    }
    
    @Nullable
    public Uri getLinkUri() {
      return this.mLinkUri;
    }
    
    public int getSource() {
      return this.mSource;
    }
    
    @Nullable
    public ContentInfo getWrapped() {
      return null;
    }
    
    @NonNull
    public String toString() {
      String str1;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ContentInfoCompat{clip=");
      stringBuilder.append(this.mClip.getDescription());
      stringBuilder.append(", source=");
      stringBuilder.append(ContentInfoCompat.sourceToString(this.mSource));
      stringBuilder.append(", flags=");
      stringBuilder.append(ContentInfoCompat.flagsToString(this.mFlags));
      Uri uri = this.mLinkUri;
      String str2 = "";
      if (uri == null) {
        str1 = "";
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(", hasLinkUri(");
        stringBuilder1.append(this.mLinkUri.toString().length());
        stringBuilder1.append(")");
        str1 = stringBuilder1.toString();
      } 
      stringBuilder.append(str1);
      if (this.mExtras == null) {
        str1 = str2;
      } else {
        str1 = ", hasExtras";
      } 
      stringBuilder.append(str1);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface Flags {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface Source {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\core\view\ContentInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */