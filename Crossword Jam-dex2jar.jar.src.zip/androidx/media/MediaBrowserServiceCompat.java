package androidx.media;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.service.media.MediaBrowserService;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.IMediaSession;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.collection.ArrayMap;
import androidx.core.app.BundleCompat;
import androidx.core.util.Pair;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public abstract class MediaBrowserServiceCompat extends Service {
  static final boolean DEBUG = Log.isLoggable("MBServiceCompat", 3);
  
  private static final float EPSILON = 1.0E-5F;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String KEY_MEDIA_ITEM = "media_item";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String KEY_SEARCH_RESULTS = "search_results";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final int RESULT_ERROR = -1;
  
  static final int RESULT_FLAG_ON_LOAD_ITEM_NOT_IMPLEMENTED = 2;
  
  static final int RESULT_FLAG_ON_SEARCH_NOT_IMPLEMENTED = 4;
  
  static final int RESULT_FLAG_OPTION_NOT_HANDLED = 1;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final int RESULT_OK = 0;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final int RESULT_PROGRESS_UPDATE = 1;
  
  public static final String SERVICE_INTERFACE = "android.media.browse.MediaBrowserService";
  
  static final String TAG = "MBServiceCompat";
  
  final ConnectionRecord mConnectionFromFwk = new ConnectionRecord("android.media.session.MediaController", -1, -1, null, null);
  
  final ArrayMap<IBinder, ConnectionRecord> mConnections = new ArrayMap();
  
  ConnectionRecord mCurConnection;
  
  final ServiceHandler mHandler = new ServiceHandler();
  
  private MediaBrowserServiceImpl mImpl;
  
  final ArrayList<ConnectionRecord> mPendingConnections = new ArrayList<ConnectionRecord>();
  
  MediaSessionCompat.Token mSession;
  
  void addSubscription(String paramString, ConnectionRecord paramConnectionRecord, IBinder paramIBinder, Bundle paramBundle) {
    List<Pair> list2 = (List)paramConnectionRecord.subscriptions.get(paramString);
    List<Pair> list1 = list2;
    if (list2 == null)
      list1 = new ArrayList(); 
    for (Pair pair : list1) {
      if (paramIBinder == pair.first && MediaBrowserCompatUtils.areSameOptions(paramBundle, (Bundle)pair.second))
        return; 
    } 
    list1.add(new Pair(paramIBinder, paramBundle));
    paramConnectionRecord.subscriptions.put(paramString, list1);
    performLoadChildren(paramString, paramConnectionRecord, paramBundle, null);
    this.mCurConnection = paramConnectionRecord;
    onSubscribe(paramString, paramBundle);
    this.mCurConnection = null;
  }
  
  List<MediaBrowserCompat.MediaItem> applyOptions(List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle) {
    if (paramList == null)
      return null; 
    int i = paramBundle.getInt("android.media.browse.extra.PAGE", -1);
    int m = paramBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if (i == -1 && m == -1)
      return paramList; 
    int k = m * i;
    int j = k + m;
    if (i < 0 || m < 1 || k >= paramList.size())
      return Collections.emptyList(); 
    i = j;
    if (j > paramList.size())
      i = paramList.size(); 
    return paramList.subList(k, i);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public void attachToBaseContext(Context paramContext) {
    attachBaseContext(paramContext);
  }
  
  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public final Bundle getBrowserRootHints() {
    return this.mImpl.getBrowserRootHints();
  }
  
  @NonNull
  public final MediaSessionManager.RemoteUserInfo getCurrentBrowserInfo() {
    return this.mImpl.getCurrentBrowserInfo();
  }
  
  @Nullable
  public MediaSessionCompat.Token getSessionToken() {
    return this.mSession;
  }
  
  boolean isValidPackage(String paramString, int paramInt) {
    if (paramString == null)
      return false; 
    String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      if (arrayOfString[paramInt].equals(paramString))
        return true; 
    } 
    return false;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public void notifyChildrenChanged(@NonNull MediaSessionManager.RemoteUserInfo paramRemoteUserInfo, @NonNull String paramString, @NonNull Bundle paramBundle) {
    if (paramRemoteUserInfo != null) {
      if (paramString != null) {
        if (paramBundle != null) {
          this.mImpl.notifyChildrenChanged(paramRemoteUserInfo, paramString, paramBundle);
          return;
        } 
        throw new IllegalArgumentException("options cannot be null in notifyChildrenChanged");
      } 
      throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
    } 
    throw new IllegalArgumentException("remoteUserInfo cannot be null in notifyChildrenChanged");
  }
  
  public void notifyChildrenChanged(@NonNull String paramString) {
    if (paramString != null) {
      this.mImpl.notifyChildrenChanged(paramString, null);
      return;
    } 
    throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
  }
  
  public void notifyChildrenChanged(@NonNull String paramString, @NonNull Bundle paramBundle) {
    if (paramString != null) {
      if (paramBundle != null) {
        this.mImpl.notifyChildrenChanged(paramString, paramBundle);
        return;
      } 
      throw new IllegalArgumentException("options cannot be null in notifyChildrenChanged");
    } 
    throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
  }
  
  public IBinder onBind(Intent paramIntent) {
    return this.mImpl.onBind(paramIntent);
  }
  
  public void onCreate() {
    super.onCreate();
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      this.mImpl = new MediaBrowserServiceImplApi28();
    } else if (i >= 26) {
      this.mImpl = new MediaBrowserServiceImplApi26();
    } else if (i >= 23) {
      this.mImpl = new MediaBrowserServiceImplApi23();
    } else if (i >= 21) {
      this.mImpl = new MediaBrowserServiceImplApi21();
    } else {
      this.mImpl = new MediaBrowserServiceImplBase();
    } 
    this.mImpl.onCreate();
  }
  
  public void onCustomAction(@NonNull String paramString, Bundle paramBundle, @NonNull Result<Bundle> paramResult) {
    paramResult.sendError(null);
  }
  
  @Nullable
  public abstract BrowserRoot onGetRoot(@NonNull String paramString, int paramInt, @Nullable Bundle paramBundle);
  
  public abstract void onLoadChildren(@NonNull String paramString, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult);
  
  public void onLoadChildren(@NonNull String paramString, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult, @NonNull Bundle paramBundle) {
    paramResult.setFlags(1);
    onLoadChildren(paramString, paramResult);
  }
  
  public void onLoadItem(String paramString, @NonNull Result<MediaBrowserCompat.MediaItem> paramResult) {
    paramResult.setFlags(2);
    paramResult.sendResult(null);
  }
  
  public void onSearch(@NonNull String paramString, Bundle paramBundle, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult) {
    paramResult.setFlags(4);
    paramResult.sendResult(null);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void onSubscribe(String paramString, Bundle paramBundle) {}
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void onUnsubscribe(String paramString) {}
  
  void performCustomAction(String paramString, Bundle paramBundle, ConnectionRecord paramConnectionRecord, final ResultReceiver receiver) {
    Result<Bundle> result = new Result<Bundle>(paramString) {
        void onErrorSent(@Nullable Bundle param1Bundle) {
          receiver.send(-1, param1Bundle);
        }
        
        void onProgressUpdateSent(@Nullable Bundle param1Bundle) {
          receiver.send(1, param1Bundle);
        }
        
        void onResultSent(@Nullable Bundle param1Bundle) {
          receiver.send(0, param1Bundle);
        }
      };
    this.mCurConnection = paramConnectionRecord;
    onCustomAction(paramString, paramBundle, result);
    this.mCurConnection = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onCustomAction must call detach() or sendResult() or sendError() before returning for action=");
    stringBuilder.append(paramString);
    stringBuilder.append(" extras=");
    stringBuilder.append(paramBundle);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void performLoadChildren(final String parentId, final ConnectionRecord connection, final Bundle subscribeOptions, final Bundle notifyChildrenChangedOptions) {
    Result<List<MediaBrowserCompat.MediaItem>> result = new Result<List<MediaBrowserCompat.MediaItem>>(parentId) {
        void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param1List) {
          StringBuilder stringBuilder1;
          List<MediaBrowserCompat.MediaItem> list;
          if (MediaBrowserServiceCompat.this.mConnections.get(connection.callbacks.asBinder()) != connection) {
            if (MediaBrowserServiceCompat.DEBUG) {
              stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Not sending onLoadChildren result for connection that has been disconnected. pkg=");
              stringBuilder1.append(connection.pkg);
              stringBuilder1.append(" id=");
              stringBuilder1.append(parentId);
              stringBuilder1.toString();
            } 
            return;
          } 
          StringBuilder stringBuilder2 = stringBuilder1;
          if ((getFlags() & 0x1) != 0)
            list = MediaBrowserServiceCompat.this.applyOptions((List<MediaBrowserCompat.MediaItem>)stringBuilder1, subscribeOptions); 
          try {
            connection.callbacks.onLoadChildren(parentId, list, subscribeOptions, notifyChildrenChangedOptions);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Calling onLoadChildren() failed for id=");
            stringBuilder.append(parentId);
            stringBuilder.append(" package=");
            stringBuilder.append(connection.pkg);
            Log.w("MBServiceCompat", stringBuilder.toString());
            return;
          } 
        }
      };
    this.mCurConnection = connection;
    if (subscribeOptions == null) {
      onLoadChildren(parentId, result);
    } else {
      onLoadChildren(parentId, result, subscribeOptions);
    } 
    this.mCurConnection = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadChildren must call detach() or sendResult() before returning for package=");
    stringBuilder.append(connection.pkg);
    stringBuilder.append(" id=");
    stringBuilder.append(parentId);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void performLoadItem(String paramString, ConnectionRecord paramConnectionRecord, final ResultReceiver receiver) {
    Result<MediaBrowserCompat.MediaItem> result = new Result<MediaBrowserCompat.MediaItem>(paramString) {
        void onResultSent(@Nullable MediaBrowserCompat.MediaItem param1MediaItem) {
          if ((getFlags() & 0x2) != 0) {
            receiver.send(-1, null);
            return;
          } 
          Bundle bundle = new Bundle();
          bundle.putParcelable("media_item", (Parcelable)param1MediaItem);
          receiver.send(0, bundle);
        }
      };
    this.mCurConnection = paramConnectionRecord;
    onLoadItem(paramString, result);
    this.mCurConnection = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadItem must call detach() or sendResult() before returning for id=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void performSearch(String paramString, Bundle paramBundle, ConnectionRecord paramConnectionRecord, final ResultReceiver receiver) {
    Result<List<MediaBrowserCompat.MediaItem>> result = new Result<List<MediaBrowserCompat.MediaItem>>(paramString) {
        void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param1List) {
          if ((getFlags() & 0x4) != 0 || param1List == null) {
            receiver.send(-1, null);
            return;
          } 
          Bundle bundle = new Bundle();
          bundle.putParcelableArray("search_results", (Parcelable[])param1List.toArray((Object[])new MediaBrowserCompat.MediaItem[0]));
          receiver.send(0, bundle);
        }
      };
    this.mCurConnection = paramConnectionRecord;
    onSearch(paramString, paramBundle, result);
    this.mCurConnection = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onSearch must call detach() or sendResult() before returning for query=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  boolean removeSubscription(String paramString, ConnectionRecord paramConnectionRecord, IBinder paramIBinder) {
    boolean bool2 = true;
    boolean bool3 = false;
    boolean bool1 = false;
    if (paramIBinder == null)
      try {
        paramIBinder = (IBinder)paramConnectionRecord.subscriptions.remove(paramString);
        if (paramIBinder != null) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        return bool1;
      } finally {
        this.mCurConnection = paramConnectionRecord;
        onUnsubscribe(paramString);
        this.mCurConnection = null;
      }  
    List list = paramConnectionRecord.subscriptions.get(paramString);
    bool2 = bool3;
    if (list != null) {
      Iterator iterator = list.iterator();
      while (iterator.hasNext()) {
        if (paramIBinder == ((Pair)iterator.next()).first) {
          iterator.remove();
          bool1 = true;
        } 
      } 
      bool2 = bool1;
      if (list.size() == 0) {
        paramConnectionRecord.subscriptions.remove(paramString);
        bool2 = bool1;
      } 
    } 
    this.mCurConnection = paramConnectionRecord;
    onUnsubscribe(paramString);
    this.mCurConnection = null;
    return bool2;
  }
  
  public void setSessionToken(MediaSessionCompat.Token paramToken) {
    if (paramToken != null) {
      if (this.mSession == null) {
        this.mSession = paramToken;
        this.mImpl.setSessionToken(paramToken);
        return;
      } 
      throw new IllegalStateException("The session token has already been set");
    } 
    throw new IllegalArgumentException("Session token may not be null");
  }
  
  public static final class BrowserRoot {
    public static final String EXTRA_OFFLINE = "android.service.media.extra.OFFLINE";
    
    public static final String EXTRA_RECENT = "android.service.media.extra.RECENT";
    
    public static final String EXTRA_SUGGESTED = "android.service.media.extra.SUGGESTED";
    
    @Deprecated
    public static final String EXTRA_SUGGESTION_KEYWORDS = "android.service.media.extra.SUGGESTION_KEYWORDS";
    
    private final Bundle mExtras;
    
    private final String mRootId;
    
    public BrowserRoot(@NonNull String param1String, @Nullable Bundle param1Bundle) {
      if (param1String != null) {
        this.mRootId = param1String;
        this.mExtras = param1Bundle;
        return;
      } 
      throw new IllegalArgumentException("The root id in BrowserRoot cannot be null. Use null for BrowserRoot instead");
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public String getRootId() {
      return this.mRootId;
    }
  }
  
  private class ConnectionRecord implements IBinder.DeathRecipient {
    public final MediaSessionManager.RemoteUserInfo browserInfo;
    
    public final MediaBrowserServiceCompat.ServiceCallbacks callbacks;
    
    public final int pid;
    
    public final String pkg;
    
    public MediaBrowserServiceCompat.BrowserRoot root;
    
    public final Bundle rootHints;
    
    public final HashMap<String, List<Pair<IBinder, Bundle>>> subscriptions = new HashMap<String, List<Pair<IBinder, Bundle>>>();
    
    public final int uid;
    
    ConnectionRecord(String param1String, int param1Int1, int param1Int2, Bundle param1Bundle, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      this.pkg = param1String;
      this.pid = param1Int1;
      this.uid = param1Int2;
      this.browserInfo = new MediaSessionManager.RemoteUserInfo(param1String, param1Int1, param1Int2);
      this.rootHints = param1Bundle;
      this.callbacks = param1ServiceCallbacks;
    }
    
    public void binderDied() {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = MediaBrowserServiceCompat.ConnectionRecord.this;
              MediaBrowserServiceCompat.this.mConnections.remove(connectionRecord.callbacks.asBinder());
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = this.this$1;
      MediaBrowserServiceCompat.this.mConnections.remove(connectionRecord.callbacks.asBinder());
    }
  }
  
  static interface MediaBrowserServiceImpl {
    Bundle getBrowserRootHints();
    
    MediaSessionManager.RemoteUserInfo getCurrentBrowserInfo();
    
    void notifyChildrenChanged(MediaSessionManager.RemoteUserInfo param1RemoteUserInfo, String param1String, Bundle param1Bundle);
    
    void notifyChildrenChanged(String param1String, Bundle param1Bundle);
    
    IBinder onBind(Intent param1Intent);
    
    void onCreate();
    
    void setSessionToken(MediaSessionCompat.Token param1Token);
  }
  
  @RequiresApi(21)
  class MediaBrowserServiceImplApi21 implements MediaBrowserServiceImpl {
    Messenger mMessenger;
    
    final List<Bundle> mRootExtrasList = new ArrayList<Bundle>();
    
    MediaBrowserService mServiceFwk;
    
    public Bundle getBrowserRootHints() {
      if (this.mMessenger == null)
        return null; 
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = MediaBrowserServiceCompat.this.mCurConnection;
      if (connectionRecord != null)
        return (connectionRecord.rootHints == null) ? null : new Bundle(MediaBrowserServiceCompat.this.mCurConnection.rootHints); 
      throw new IllegalStateException("This should be called inside of onGetRoot, onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
    
    public MediaSessionManager.RemoteUserInfo getCurrentBrowserInfo() {
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = MediaBrowserServiceCompat.this.mCurConnection;
      if (connectionRecord != null)
        return connectionRecord.browserInfo; 
      throw new IllegalStateException("This should be called inside of onGetRoot, onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
    
    public void notifyChildrenChanged(MediaSessionManager.RemoteUserInfo param1RemoteUserInfo, String param1String, Bundle param1Bundle) {
      notifyChildrenChangedForCompat(param1RemoteUserInfo, param1String, param1Bundle);
    }
    
    public void notifyChildrenChanged(String param1String, Bundle param1Bundle) {
      notifyChildrenChangedForFramework(param1String, param1Bundle);
      notifyChildrenChangedForCompat(param1String, param1Bundle);
    }
    
    void notifyChildrenChangedForCompat(final MediaSessionManager.RemoteUserInfo remoteUserInfo, final String parentId, final Bundle options) {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              for (int i = 0; i < MediaBrowserServiceCompat.this.mConnections.size(); i++) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.valueAt(i);
                if (connectionRecord.browserInfo.equals(remoteUserInfo))
                  MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.this.notifyChildrenChangedForCompatOnHandler(connectionRecord, parentId, options); 
              } 
            }
          });
    }
    
    void notifyChildrenChangedForCompat(final String parentId, final Bundle options) {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              for (IBinder iBinder : MediaBrowserServiceCompat.this.mConnections.keySet()) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
                MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.this.notifyChildrenChangedForCompatOnHandler(connectionRecord, parentId, options);
              } 
            }
          });
    }
    
    void notifyChildrenChangedForCompatOnHandler(MediaBrowserServiceCompat.ConnectionRecord param1ConnectionRecord, String param1String, Bundle param1Bundle) {
      List list = param1ConnectionRecord.subscriptions.get(param1String);
      if (list != null)
        for (Pair pair : list) {
          if (MediaBrowserCompatUtils.hasDuplicatedItems(param1Bundle, (Bundle)pair.second))
            MediaBrowserServiceCompat.this.performLoadChildren(param1String, param1ConnectionRecord, (Bundle)pair.second, param1Bundle); 
        }  
    }
    
    void notifyChildrenChangedForFramework(String param1String, Bundle param1Bundle) {
      this.mServiceFwk.notifyChildrenChanged(param1String);
    }
    
    public IBinder onBind(Intent param1Intent) {
      return this.mServiceFwk.onBind(param1Intent);
    }
    
    public void onCreate() {
      MediaBrowserServiceApi21 mediaBrowserServiceApi21 = new MediaBrowserServiceApi21((Context)MediaBrowserServiceCompat.this);
      this.mServiceFwk = mediaBrowserServiceApi21;
      mediaBrowserServiceApi21.onCreate();
    }
    
    public MediaBrowserServiceCompat.BrowserRoot onGetRoot(String param1String, int param1Int, Bundle param1Bundle) {
      byte b;
      MediaBrowserServiceCompat mediaBrowserServiceCompat2;
      if (param1Bundle != null && param1Bundle.getInt("extra_client_version", 0) != 0) {
        param1Bundle.remove("extra_client_version");
        this.mMessenger = new Messenger(MediaBrowserServiceCompat.this.mHandler);
        Bundle bundle = new Bundle();
        bundle.putInt("extra_service_version", 2);
        BundleCompat.putBinder(bundle, "extra_messenger", this.mMessenger.getBinder());
        MediaSessionCompat.Token token = MediaBrowserServiceCompat.this.mSession;
        if (token != null) {
          IBinder iBinder;
          IMediaSession iMediaSession = token.getExtraBinder();
          if (iMediaSession == null) {
            iMediaSession = null;
          } else {
            iBinder = iMediaSession.asBinder();
          } 
          BundleCompat.putBinder(bundle, "extra_session_binder", iBinder);
        } else {
          this.mRootExtrasList.add(bundle);
        } 
        b = param1Bundle.getInt("extra_calling_pid", -1);
        param1Bundle.remove("extra_calling_pid");
        mediaBrowserServiceCompat2 = (MediaBrowserServiceCompat)bundle;
      } else {
        b = -1;
        mediaBrowserServiceCompat2 = null;
      } 
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(param1String, b, param1Int, param1Bundle, null);
      MediaBrowserServiceCompat mediaBrowserServiceCompat3 = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat3.mCurConnection = connectionRecord;
      MediaBrowserServiceCompat.BrowserRoot browserRoot = mediaBrowserServiceCompat3.onGetRoot(param1String, param1Int, param1Bundle);
      MediaBrowserServiceCompat mediaBrowserServiceCompat1 = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat1.mCurConnection = null;
      if (browserRoot == null)
        return null; 
      if (this.mMessenger != null)
        mediaBrowserServiceCompat1.mPendingConnections.add(connectionRecord); 
      if (mediaBrowserServiceCompat2 == null) {
        Bundle bundle = browserRoot.getExtras();
      } else {
        mediaBrowserServiceCompat1 = mediaBrowserServiceCompat2;
        if (browserRoot.getExtras() != null) {
          mediaBrowserServiceCompat2.putAll(browserRoot.getExtras());
          mediaBrowserServiceCompat1 = mediaBrowserServiceCompat2;
        } 
      } 
      return new MediaBrowserServiceCompat.BrowserRoot(browserRoot.getRootId(), (Bundle)mediaBrowserServiceCompat1);
    }
    
    public void onLoadChildren(String param1String, final MediaBrowserServiceCompat.ResultWrapper<List<Parcel>> resultWrapper) {
      MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result = new MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>>(param1String) {
          public void detach() {
            resultWrapper.detach();
          }
          
          void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param2List) {
            if (param2List != null) {
              ArrayList<MediaBrowserCompat.MediaItem> arrayList = new ArrayList();
              Iterator<MediaBrowserCompat.MediaItem> iterator = param2List.iterator();
              while (true) {
                param2List = arrayList;
                if (iterator.hasNext()) {
                  MediaBrowserCompat.MediaItem mediaItem = iterator.next();
                  Parcel parcel = Parcel.obtain();
                  mediaItem.writeToParcel(parcel, 0);
                  arrayList.add(parcel);
                  continue;
                } 
                break;
              } 
            } else {
              param2List = null;
            } 
            resultWrapper.sendResult(param2List);
          }
        };
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat.mCurConnection = mediaBrowserServiceCompat.mConnectionFromFwk;
      mediaBrowserServiceCompat.onLoadChildren(param1String, result);
      MediaBrowserServiceCompat.this.mCurConnection = null;
    }
    
    public void setSessionToken(final MediaSessionCompat.Token token) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.this.setSessionTokenOnHandler(token);
            }
          });
    }
    
    void setSessionTokenOnHandler(MediaSessionCompat.Token param1Token) {
      if (!this.mRootExtrasList.isEmpty()) {
        IMediaSession iMediaSession = param1Token.getExtraBinder();
        if (iMediaSession != null) {
          Iterator<Bundle> iterator = this.mRootExtrasList.iterator();
          while (iterator.hasNext())
            BundleCompat.putBinder(iterator.next(), "extra_session_binder", iMediaSession.asBinder()); 
        } 
        this.mRootExtrasList.clear();
      } 
      this.mServiceFwk.setSessionToken((MediaSession.Token)param1Token.getToken());
    }
    
    @RequiresApi(21)
    class MediaBrowserServiceApi21 extends MediaBrowserService {
      MediaBrowserServiceApi21(Context param2Context) {
        attachBaseContext(param2Context);
      }
      
      @SuppressLint({"SyntheticAccessor"})
      public MediaBrowserService.BrowserRoot onGetRoot(String param2String, int param2Int, Bundle param2Bundle) {
        MediaSessionCompat.ensureClassLoader(param2Bundle);
        MediaBrowserServiceCompat.MediaBrowserServiceImplApi21 mediaBrowserServiceImplApi21 = MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.this;
        if (param2Bundle == null) {
          param2Bundle = null;
        } else {
          param2Bundle = new Bundle(param2Bundle);
        } 
        MediaBrowserServiceCompat.BrowserRoot browserRoot = mediaBrowserServiceImplApi21.onGetRoot(param2String, param2Int, param2Bundle);
        return (browserRoot == null) ? null : new MediaBrowserService.BrowserRoot(browserRoot.mRootId, browserRoot.mExtras);
      }
      
      public void onLoadChildren(String param2String, MediaBrowserService.Result<List<MediaBrowser.MediaItem>> param2Result) {
        MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.this.onLoadChildren(param2String, new MediaBrowserServiceCompat.ResultWrapper<List<Parcel>>(param2Result));
      }
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$1.setSessionTokenOnHandler(token);
    }
  }
  
  class null extends Result<List<MediaBrowserCompat.MediaItem>> {
    null(Object param1Object) {
      super(param1Object);
    }
    
    public void detach() {
      resultWrapper.detach();
    }
    
    void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param1List) {
      if (param1List != null) {
        ArrayList<MediaBrowserCompat.MediaItem> arrayList = new ArrayList();
        Iterator<MediaBrowserCompat.MediaItem> iterator = param1List.iterator();
        while (true) {
          param1List = arrayList;
          if (iterator.hasNext()) {
            MediaBrowserCompat.MediaItem mediaItem = iterator.next();
            Parcel parcel = Parcel.obtain();
            mediaItem.writeToParcel(parcel, 0);
            arrayList.add(parcel);
            continue;
          } 
          break;
        } 
      } else {
        param1List = null;
      } 
      resultWrapper.sendResult(param1List);
    }
  }
  
  class null implements Runnable {
    public void run() {
      for (IBinder iBinder : MediaBrowserServiceCompat.this.mConnections.keySet()) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
        this.this$1.notifyChildrenChangedForCompatOnHandler(connectionRecord, parentId, options);
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      for (int i = 0; i < MediaBrowserServiceCompat.this.mConnections.size(); i++) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.valueAt(i);
        if (connectionRecord.browserInfo.equals(remoteUserInfo))
          this.this$1.notifyChildrenChangedForCompatOnHandler(connectionRecord, parentId, options); 
      } 
    }
  }
  
  @RequiresApi(21)
  class MediaBrowserServiceApi21 extends MediaBrowserService {
    MediaBrowserServiceApi21(Context param1Context) {
      attachBaseContext(param1Context);
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public MediaBrowserService.BrowserRoot onGetRoot(String param1String, int param1Int, Bundle param1Bundle) {
      MediaSessionCompat.ensureClassLoader(param1Bundle);
      MediaBrowserServiceCompat.MediaBrowserServiceImplApi21 mediaBrowserServiceImplApi21 = this.this$1;
      if (param1Bundle == null) {
        param1Bundle = null;
      } else {
        param1Bundle = new Bundle(param1Bundle);
      } 
      MediaBrowserServiceCompat.BrowserRoot browserRoot = mediaBrowserServiceImplApi21.onGetRoot(param1String, param1Int, param1Bundle);
      return (browserRoot == null) ? null : new MediaBrowserService.BrowserRoot(browserRoot.mRootId, browserRoot.mExtras);
    }
    
    public void onLoadChildren(String param1String, MediaBrowserService.Result<List<MediaBrowser.MediaItem>> param1Result) {
      this.this$1.onLoadChildren(param1String, new MediaBrowserServiceCompat.ResultWrapper<List<Parcel>>(param1Result));
    }
  }
  
  @RequiresApi(23)
  class MediaBrowserServiceImplApi23 extends MediaBrowserServiceImplApi21 {
    public void onCreate() {
      MediaBrowserServiceApi23 mediaBrowserServiceApi23 = new MediaBrowserServiceApi23((Context)MediaBrowserServiceCompat.this);
      this.mServiceFwk = mediaBrowserServiceApi23;
      mediaBrowserServiceApi23.onCreate();
    }
    
    public void onLoadItem(String param1String, final MediaBrowserServiceCompat.ResultWrapper<Parcel> resultWrapper) {
      MediaBrowserServiceCompat.Result<MediaBrowserCompat.MediaItem> result = new MediaBrowserServiceCompat.Result<MediaBrowserCompat.MediaItem>(param1String) {
          public void detach() {
            resultWrapper.detach();
          }
          
          void onResultSent(@Nullable MediaBrowserCompat.MediaItem param2MediaItem) {
            if (param2MediaItem == null) {
              resultWrapper.sendResult(null);
              return;
            } 
            Parcel parcel = Parcel.obtain();
            param2MediaItem.writeToParcel(parcel, 0);
            resultWrapper.sendResult(parcel);
          }
        };
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat.mCurConnection = mediaBrowserServiceCompat.mConnectionFromFwk;
      mediaBrowserServiceCompat.onLoadItem(param1String, result);
      MediaBrowserServiceCompat.this.mCurConnection = null;
    }
    
    class MediaBrowserServiceApi23 extends MediaBrowserServiceCompat.MediaBrowserServiceImplApi21.MediaBrowserServiceApi21 {
      MediaBrowserServiceApi23(Context param2Context) {
        super(param2Context);
      }
      
      public void onLoadItem(String param2String, MediaBrowserService.Result<MediaBrowser.MediaItem> param2Result) {
        MediaBrowserServiceCompat.MediaBrowserServiceImplApi23.this.onLoadItem(param2String, new MediaBrowserServiceCompat.ResultWrapper<Parcel>(param2Result));
      }
    }
  }
  
  class null extends Result<MediaBrowserCompat.MediaItem> {
    null(Object param1Object) {
      super(param1Object);
    }
    
    public void detach() {
      resultWrapper.detach();
    }
    
    void onResultSent(@Nullable MediaBrowserCompat.MediaItem param1MediaItem) {
      if (param1MediaItem == null) {
        resultWrapper.sendResult(null);
        return;
      } 
      Parcel parcel = Parcel.obtain();
      param1MediaItem.writeToParcel(parcel, 0);
      resultWrapper.sendResult(parcel);
    }
  }
  
  class MediaBrowserServiceApi23 extends MediaBrowserServiceImplApi21.MediaBrowserServiceApi21 {
    MediaBrowserServiceApi23(Context param1Context) {
      super((MediaBrowserServiceCompat.MediaBrowserServiceImplApi21)MediaBrowserServiceCompat.this, param1Context);
    }
    
    public void onLoadItem(String param1String, MediaBrowserService.Result<MediaBrowser.MediaItem> param1Result) {
      this.this$1.onLoadItem(param1String, new MediaBrowserServiceCompat.ResultWrapper<Parcel>(param1Result));
    }
  }
  
  @RequiresApi(26)
  class MediaBrowserServiceImplApi26 extends MediaBrowserServiceImplApi23 {
    public Bundle getBrowserRootHints() {
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = mediaBrowserServiceCompat.mCurConnection;
      if (connectionRecord != null)
        return (connectionRecord == mediaBrowserServiceCompat.mConnectionFromFwk) ? this.mServiceFwk.getBrowserRootHints() : ((connectionRecord.rootHints == null) ? null : new Bundle(MediaBrowserServiceCompat.this.mCurConnection.rootHints)); 
      throw new IllegalStateException("This should be called inside of onGetRoot, onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
    
    void notifyChildrenChangedForFramework(String param1String, Bundle param1Bundle) {
      if (param1Bundle != null) {
        this.mServiceFwk.notifyChildrenChanged(param1String, param1Bundle);
        return;
      } 
      super.notifyChildrenChangedForFramework(param1String, param1Bundle);
    }
    
    public void onCreate() {
      MediaBrowserServiceApi26 mediaBrowserServiceApi26 = new MediaBrowserServiceApi26((Context)MediaBrowserServiceCompat.this);
      this.mServiceFwk = mediaBrowserServiceApi26;
      mediaBrowserServiceApi26.onCreate();
    }
    
    public void onLoadChildren(String param1String, final MediaBrowserServiceCompat.ResultWrapper<List<Parcel>> resultWrapper, final Bundle options) {
      MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result = new MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>>(param1String) {
          public void detach() {
            resultWrapper.detach();
          }
          
          void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param2List) {
            if (param2List == null) {
              resultWrapper.sendResult(null);
              return;
            } 
            List<MediaBrowserCompat.MediaItem> list = param2List;
            if ((getFlags() & 0x1) != 0)
              list = MediaBrowserServiceCompat.this.applyOptions(param2List, options); 
            param2List = new ArrayList<MediaBrowserCompat.MediaItem>();
            for (MediaBrowserCompat.MediaItem mediaItem : list) {
              Parcel parcel = Parcel.obtain();
              mediaItem.writeToParcel(parcel, 0);
              param2List.add(parcel);
            } 
            resultWrapper.sendResult(param2List);
          }
        };
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat.mCurConnection = mediaBrowserServiceCompat.mConnectionFromFwk;
      mediaBrowserServiceCompat.onLoadChildren(param1String, result, options);
      MediaBrowserServiceCompat.this.mCurConnection = null;
    }
    
    class MediaBrowserServiceApi26 extends MediaBrowserServiceCompat.MediaBrowserServiceImplApi23.MediaBrowserServiceApi23 {
      MediaBrowserServiceApi26(Context param2Context) {
        super(param2Context);
      }
      
      public void onLoadChildren(String param2String, MediaBrowserService.Result<List<MediaBrowser.MediaItem>> param2Result, Bundle param2Bundle) {
        MediaSessionCompat.ensureClassLoader(param2Bundle);
        MediaBrowserServiceCompat.MediaBrowserServiceImplApi26 mediaBrowserServiceImplApi26 = MediaBrowserServiceCompat.MediaBrowserServiceImplApi26.this;
        MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
        mediaBrowserServiceCompat.mCurConnection = mediaBrowserServiceCompat.mConnectionFromFwk;
        mediaBrowserServiceImplApi26.onLoadChildren(param2String, new MediaBrowserServiceCompat.ResultWrapper<List<Parcel>>(param2Result), param2Bundle);
        MediaBrowserServiceCompat.this.mCurConnection = null;
      }
    }
  }
  
  class null extends Result<List<MediaBrowserCompat.MediaItem>> {
    null(Object param1Object) {
      super(param1Object);
    }
    
    public void detach() {
      resultWrapper.detach();
    }
    
    void onResultSent(@Nullable List<MediaBrowserCompat.MediaItem> param1List) {
      if (param1List == null) {
        resultWrapper.sendResult(null);
        return;
      } 
      List<MediaBrowserCompat.MediaItem> list = param1List;
      if ((getFlags() & 0x1) != 0)
        list = MediaBrowserServiceCompat.this.applyOptions(param1List, options); 
      param1List = new ArrayList<MediaBrowserCompat.MediaItem>();
      for (MediaBrowserCompat.MediaItem mediaItem : list) {
        Parcel parcel = Parcel.obtain();
        mediaItem.writeToParcel(parcel, 0);
        param1List.add(parcel);
      } 
      resultWrapper.sendResult(param1List);
    }
  }
  
  class MediaBrowserServiceApi26 extends MediaBrowserServiceImplApi23.MediaBrowserServiceApi23 {
    MediaBrowserServiceApi26(Context param1Context) {
      super((MediaBrowserServiceCompat.MediaBrowserServiceImplApi23)MediaBrowserServiceCompat.this, param1Context);
    }
    
    public void onLoadChildren(String param1String, MediaBrowserService.Result<List<MediaBrowser.MediaItem>> param1Result, Bundle param1Bundle) {
      MediaSessionCompat.ensureClassLoader(param1Bundle);
      MediaBrowserServiceCompat.MediaBrowserServiceImplApi26 mediaBrowserServiceImplApi26 = this.this$1;
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat.mCurConnection = mediaBrowserServiceCompat.mConnectionFromFwk;
      mediaBrowserServiceImplApi26.onLoadChildren(param1String, new MediaBrowserServiceCompat.ResultWrapper<List<Parcel>>(param1Result), param1Bundle);
      MediaBrowserServiceCompat.this.mCurConnection = null;
    }
  }
  
  @RequiresApi(28)
  class MediaBrowserServiceImplApi28 extends MediaBrowserServiceImplApi26 {
    public MediaSessionManager.RemoteUserInfo getCurrentBrowserInfo() {
      MediaBrowserServiceCompat mediaBrowserServiceCompat = MediaBrowserServiceCompat.this;
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = mediaBrowserServiceCompat.mCurConnection;
      if (connectionRecord != null)
        return (connectionRecord == mediaBrowserServiceCompat.mConnectionFromFwk) ? new MediaSessionManager.RemoteUserInfo(this.mServiceFwk.getCurrentBrowserInfo()) : connectionRecord.browserInfo; 
      throw new IllegalStateException("This should be called inside of onGetRoot, onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
  }
  
  class MediaBrowserServiceImplBase implements MediaBrowserServiceImpl {
    private Messenger mMessenger;
    
    public Bundle getBrowserRootHints() {
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = MediaBrowserServiceCompat.this.mCurConnection;
      if (connectionRecord != null)
        return (connectionRecord.rootHints == null) ? null : new Bundle(MediaBrowserServiceCompat.this.mCurConnection.rootHints); 
      throw new IllegalStateException("This should be called inside of onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
    
    public MediaSessionManager.RemoteUserInfo getCurrentBrowserInfo() {
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = MediaBrowserServiceCompat.this.mCurConnection;
      if (connectionRecord != null)
        return connectionRecord.browserInfo; 
      throw new IllegalStateException("This should be called inside of onLoadChildren, onLoadItem, onSearch, or onCustomAction methods");
    }
    
    public void notifyChildrenChanged(@NonNull final MediaSessionManager.RemoteUserInfo remoteUserInfo, @NonNull final String parentId, final Bundle options) {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              for (int i = 0; i < MediaBrowserServiceCompat.this.mConnections.size(); i++) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.valueAt(i);
                if (connectionRecord.browserInfo.equals(remoteUserInfo)) {
                  MediaBrowserServiceCompat.MediaBrowserServiceImplBase.this.notifyChildrenChangedOnHandler(connectionRecord, parentId, options);
                  return;
                } 
              } 
            }
          });
    }
    
    public void notifyChildrenChanged(@NonNull final String parentId, final Bundle options) {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              for (IBinder iBinder : MediaBrowserServiceCompat.this.mConnections.keySet()) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
                MediaBrowserServiceCompat.MediaBrowserServiceImplBase.this.notifyChildrenChangedOnHandler(connectionRecord, parentId, options);
              } 
            }
          });
    }
    
    void notifyChildrenChangedOnHandler(MediaBrowserServiceCompat.ConnectionRecord param1ConnectionRecord, String param1String, Bundle param1Bundle) {
      List list = param1ConnectionRecord.subscriptions.get(param1String);
      if (list != null)
        for (Pair pair : list) {
          if (MediaBrowserCompatUtils.hasDuplicatedItems(param1Bundle, (Bundle)pair.second))
            MediaBrowserServiceCompat.this.performLoadChildren(param1String, param1ConnectionRecord, (Bundle)pair.second, param1Bundle); 
        }  
    }
    
    public IBinder onBind(Intent param1Intent) {
      return "android.media.browse.MediaBrowserService".equals(param1Intent.getAction()) ? this.mMessenger.getBinder() : null;
    }
    
    public void onCreate() {
      this.mMessenger = new Messenger(MediaBrowserServiceCompat.this.mHandler);
    }
    
    public void setSessionToken(final MediaSessionCompat.Token token) {
      MediaBrowserServiceCompat.this.mHandler.post(new Runnable() {
            public void run() {
              Iterator<MediaBrowserServiceCompat.ConnectionRecord> iterator = MediaBrowserServiceCompat.this.mConnections.values().iterator();
              while (true) {
                if (iterator.hasNext()) {
                  MediaBrowserServiceCompat.ConnectionRecord connectionRecord = iterator.next();
                  try {
                    connectionRecord.callbacks.onConnect(connectionRecord.root.getRootId(), token, connectionRecord.root.getExtras());
                  } catch (RemoteException remoteException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Connection for ");
                    stringBuilder.append(connectionRecord.pkg);
                    stringBuilder.append(" is no longer valid.");
                    Log.w("MBServiceCompat", stringBuilder.toString());
                    iterator.remove();
                  } 
                  continue;
                } 
                return;
              } 
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      Iterator<MediaBrowserServiceCompat.ConnectionRecord> iterator = MediaBrowserServiceCompat.this.mConnections.values().iterator();
      while (true) {
        if (iterator.hasNext()) {
          MediaBrowserServiceCompat.ConnectionRecord connectionRecord = iterator.next();
          try {
            connectionRecord.callbacks.onConnect(connectionRecord.root.getRootId(), token, connectionRecord.root.getExtras());
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Connection for ");
            stringBuilder.append(connectionRecord.pkg);
            stringBuilder.append(" is no longer valid.");
            Log.w("MBServiceCompat", stringBuilder.toString());
            iterator.remove();
          } 
          continue;
        } 
        return;
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      for (IBinder iBinder : MediaBrowserServiceCompat.this.mConnections.keySet()) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
        this.this$1.notifyChildrenChangedOnHandler(connectionRecord, parentId, options);
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      for (int i = 0; i < MediaBrowserServiceCompat.this.mConnections.size(); i++) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.valueAt(i);
        if (connectionRecord.browserInfo.equals(remoteUserInfo)) {
          this.this$1.notifyChildrenChangedOnHandler(connectionRecord, parentId, options);
          return;
        } 
      } 
    }
  }
  
  public static class Result<T> {
    private final Object mDebug;
    
    private boolean mDetachCalled;
    
    private int mFlags;
    
    private boolean mSendErrorCalled;
    
    private boolean mSendResultCalled;
    
    Result(Object param1Object) {
      this.mDebug = param1Object;
    }
    
    private void checkExtraFields(@Nullable Bundle param1Bundle) {
      if (param1Bundle == null)
        return; 
      if (param1Bundle.containsKey("android.media.browse.extra.DOWNLOAD_PROGRESS")) {
        float f = param1Bundle.getFloat("android.media.browse.extra.DOWNLOAD_PROGRESS");
        if (f >= -1.0E-5F && f <= 1.00001F)
          return; 
        throw new IllegalArgumentException("The value of the EXTRA_DOWNLOAD_PROGRESS field must be a float number within [0.0, 1.0]");
      } 
    }
    
    public void detach() {
      if (!this.mDetachCalled) {
        if (!this.mSendResultCalled) {
          if (!this.mSendErrorCalled) {
            this.mDetachCalled = true;
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("detach() called when sendError() had already been called for: ");
          stringBuilder2.append(this.mDebug);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("detach() called when sendResult() had already been called for: ");
        stringBuilder1.append(this.mDebug);
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach() called when detach() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    int getFlags() {
      return this.mFlags;
    }
    
    boolean isDone() {
      return (this.mDetachCalled || this.mSendResultCalled || this.mSendErrorCalled);
    }
    
    void onErrorSent(@Nullable Bundle param1Bundle) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("It is not supported to send an error for ");
      stringBuilder.append(this.mDebug);
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    void onProgressUpdateSent(@Nullable Bundle param1Bundle) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("It is not supported to send an interim update for ");
      stringBuilder.append(this.mDebug);
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    void onResultSent(@Nullable T param1T) {}
    
    public void sendError(@Nullable Bundle param1Bundle) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        this.mSendErrorCalled = true;
        onErrorSent(param1Bundle);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendError() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendProgressUpdate(@Nullable Bundle param1Bundle) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        checkExtraFields(param1Bundle);
        onProgressUpdateSent(param1Bundle);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendProgressUpdate() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendResult(@Nullable T param1T) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        this.mSendResultCalled = true;
        onResultSent(param1T);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendResult() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    void setFlags(int param1Int) {
      this.mFlags = param1Int;
    }
  }
  
  @RequiresApi(21)
  static class ResultWrapper<T> {
    MediaBrowserService.Result mResultFwk;
    
    ResultWrapper(MediaBrowserService.Result param1Result) {
      this.mResultFwk = param1Result;
    }
    
    public void detach() {
      this.mResultFwk.detach();
    }
    
    List<MediaBrowser.MediaItem> parcelListToItemList(List<Parcel> param1List) {
      if (param1List == null)
        return null; 
      ArrayList<MediaBrowser.MediaItem> arrayList = new ArrayList();
      for (Parcel parcel : param1List) {
        parcel.setDataPosition(0);
        arrayList.add((MediaBrowser.MediaItem)MediaBrowser.MediaItem.CREATOR.createFromParcel(parcel));
        parcel.recycle();
      } 
      return arrayList;
    }
    
    public void sendResult(T param1T) {
      if (param1T instanceof List) {
        this.mResultFwk.sendResult(parcelListToItemList((List<Parcel>)param1T));
        return;
      } 
      if (param1T instanceof Parcel) {
        Parcel parcel = (Parcel)param1T;
        parcel.setDataPosition(0);
        this.mResultFwk.sendResult(MediaBrowser.MediaItem.CREATOR.createFromParcel(parcel));
        parcel.recycle();
        return;
      } 
      this.mResultFwk.sendResult(null);
    }
  }
  
  private class ServiceBinderImpl {
    public void addSubscription(final String id, final IBinder token, final Bundle options, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              StringBuilder stringBuilder;
              IBinder iBinder = callbacks.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
              if (connectionRecord == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("addSubscription for callback that isn't registered id=");
                stringBuilder.append(id);
                Log.w("MBServiceCompat", stringBuilder.toString());
                return;
              } 
              MediaBrowserServiceCompat.this.addSubscription(id, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, token, options);
            }
          });
    }
    
    public void connect(final String pkg, final int pid, final int uid, final Bundle rootHints, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      if (MediaBrowserServiceCompat.this.isValidPackage(pkg, uid)) {
        MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
              public void run() {
                StringBuilder stringBuilder;
                IBinder iBinder = callbacks.asBinder();
                MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(pkg, pid, uid, rootHints, callbacks);
                MediaBrowserServiceCompat mediaBrowserServiceCompat1 = MediaBrowserServiceCompat.this;
                mediaBrowserServiceCompat1.mCurConnection = connectionRecord;
                MediaBrowserServiceCompat.BrowserRoot browserRoot = mediaBrowserServiceCompat1.onGetRoot(pkg, uid, rootHints);
                connectionRecord.root = browserRoot;
                MediaBrowserServiceCompat mediaBrowserServiceCompat2 = MediaBrowserServiceCompat.this;
                mediaBrowserServiceCompat2.mCurConnection = null;
                if (browserRoot == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No root for client ");
                  stringBuilder.append(pkg);
                  stringBuilder.append(" from service ");
                  stringBuilder.append(getClass().getName());
                  stringBuilder.toString();
                  try {
                    callbacks.onConnectFailed();
                    return;
                  } catch (RemoteException remoteException) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Calling onConnectFailed() failed. Ignoring. pkg=");
                    stringBuilder.append(pkg);
                    Log.w("MBServiceCompat", stringBuilder.toString());
                    return;
                  } 
                } 
                try {
                  mediaBrowserServiceCompat2.mConnections.put(stringBuilder, connectionRecord);
                  stringBuilder.linkToDeath(connectionRecord, 0);
                  if (MediaBrowserServiceCompat.this.mSession != null) {
                    callbacks.onConnect(connectionRecord.root.getRootId(), MediaBrowserServiceCompat.this.mSession, connectionRecord.root.getExtras());
                    return;
                  } 
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append("Calling onConnect() failed. Dropping client. pkg=");
                  stringBuilder1.append(pkg);
                  Log.w("MBServiceCompat", stringBuilder1.toString());
                  MediaBrowserServiceCompat.this.mConnections.remove(stringBuilder);
                } 
              }
            });
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Package/uid mismatch: uid=");
      stringBuilder.append(uid);
      stringBuilder.append(" package=");
      stringBuilder.append(pkg);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void disconnect(final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              IBinder iBinder = callbacks.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
              if (connectionRecord != null)
                connectionRecord.callbacks.asBinder().unlinkToDeath(connectionRecord, 0); 
            }
          });
    }
    
    public void getMediaItem(final String mediaId, final ResultReceiver receiver, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      if (!TextUtils.isEmpty(mediaId)) {
        if (receiver == null)
          return; 
        MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
              public void run() {
                StringBuilder stringBuilder;
                IBinder iBinder = callbacks.asBinder();
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
                if (connectionRecord == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("getMediaItem for callback that isn't registered id=");
                  stringBuilder.append(mediaId);
                  Log.w("MBServiceCompat", stringBuilder.toString());
                  return;
                } 
                MediaBrowserServiceCompat.this.performLoadItem(mediaId, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
              }
            });
      } 
    }
    
    public void registerCallbacks(final MediaBrowserServiceCompat.ServiceCallbacks callbacks, final String pkg, final int pid, final int uid, final Bundle rootHints) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              // Byte code:
              //   0: aload_0
              //   1: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
              //   4: invokeinterface asBinder : ()Landroid/os/IBinder;
              //   9: astore #4
              //   11: aload_0
              //   12: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
              //   15: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
              //   18: getfield mConnections : Landroidx/collection/ArrayMap;
              //   21: aload #4
              //   23: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
              //   26: pop
              //   27: aload_0
              //   28: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
              //   31: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
              //   34: getfield mPendingConnections : Ljava/util/ArrayList;
              //   37: invokevirtual iterator : ()Ljava/util/Iterator;
              //   40: astore #5
              //   42: aload #5
              //   44: invokeinterface hasNext : ()Z
              //   49: istore_1
              //   50: aconst_null
              //   51: astore_2
              //   52: aconst_null
              //   53: astore_3
              //   54: iload_1
              //   55: ifeq -> 146
              //   58: aload #5
              //   60: invokeinterface next : ()Ljava/lang/Object;
              //   65: checkcast androidx/media/MediaBrowserServiceCompat$ConnectionRecord
              //   68: astore #6
              //   70: aload #6
              //   72: getfield uid : I
              //   75: aload_0
              //   76: getfield val$uid : I
              //   79: if_icmpne -> 42
              //   82: aload_0
              //   83: getfield val$pkg : Ljava/lang/String;
              //   86: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
              //   89: ifne -> 101
              //   92: aload_3
              //   93: astore_2
              //   94: aload_0
              //   95: getfield val$pid : I
              //   98: ifgt -> 139
              //   101: new androidx/media/MediaBrowserServiceCompat$ConnectionRecord
              //   104: dup
              //   105: aload_0
              //   106: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
              //   109: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
              //   112: aload #6
              //   114: getfield pkg : Ljava/lang/String;
              //   117: aload #6
              //   119: getfield pid : I
              //   122: aload #6
              //   124: getfield uid : I
              //   127: aload_0
              //   128: getfield val$rootHints : Landroid/os/Bundle;
              //   131: aload_0
              //   132: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
              //   135: invokespecial <init> : (Landroidx/media/MediaBrowserServiceCompat;Ljava/lang/String;IILandroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;)V
              //   138: astore_2
              //   139: aload #5
              //   141: invokeinterface remove : ()V
              //   146: aload_2
              //   147: astore_3
              //   148: aload_2
              //   149: ifnonnull -> 187
              //   152: new androidx/media/MediaBrowserServiceCompat$ConnectionRecord
              //   155: dup
              //   156: aload_0
              //   157: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
              //   160: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
              //   163: aload_0
              //   164: getfield val$pkg : Ljava/lang/String;
              //   167: aload_0
              //   168: getfield val$pid : I
              //   171: aload_0
              //   172: getfield val$uid : I
              //   175: aload_0
              //   176: getfield val$rootHints : Landroid/os/Bundle;
              //   179: aload_0
              //   180: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
              //   183: invokespecial <init> : (Landroidx/media/MediaBrowserServiceCompat;Ljava/lang/String;IILandroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;)V
              //   186: astore_3
              //   187: aload_0
              //   188: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
              //   191: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
              //   194: getfield mConnections : Landroidx/collection/ArrayMap;
              //   197: aload #4
              //   199: aload_3
              //   200: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
              //   203: pop
              //   204: aload #4
              //   206: aload_3
              //   207: iconst_0
              //   208: invokeinterface linkToDeath : (Landroid/os/IBinder$DeathRecipient;I)V
              //   213: return
              //   214: ldc 'MBServiceCompat'
              //   216: ldc 'IBinder is already dead.'
              //   218: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
              //   221: pop
              //   222: return
              //   223: astore_2
              //   224: goto -> 214
              // Exception table:
              //   from	to	target	type
              //   204	213	223	android/os/RemoteException
            }
          });
    }
    
    public void removeSubscription(final String id, final IBinder token, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              StringBuilder stringBuilder;
              IBinder iBinder = callbacks.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
              if (connectionRecord == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("removeSubscription for callback that isn't registered id=");
                stringBuilder.append(id);
                Log.w("MBServiceCompat", stringBuilder.toString());
                return;
              } 
              if (!MediaBrowserServiceCompat.this.removeSubscription(id, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, token)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("removeSubscription called for ");
                stringBuilder.append(id);
                stringBuilder.append(" which is not subscribed");
                Log.w("MBServiceCompat", stringBuilder.toString());
              } 
            }
          });
    }
    
    public void search(final String query, final Bundle extras, final ResultReceiver receiver, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      if (!TextUtils.isEmpty(query)) {
        if (receiver == null)
          return; 
        MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
              public void run() {
                StringBuilder stringBuilder;
                IBinder iBinder = callbacks.asBinder();
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
                if (connectionRecord == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("search for callback that isn't registered query=");
                  stringBuilder.append(query);
                  Log.w("MBServiceCompat", stringBuilder.toString());
                  return;
                } 
                MediaBrowserServiceCompat.this.performSearch(query, extras, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
              }
            });
      } 
    }
    
    public void sendCustomAction(final String action, final Bundle extras, final ResultReceiver receiver, final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      if (!TextUtils.isEmpty(action)) {
        if (receiver == null)
          return; 
        MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
              public void run() {
                StringBuilder stringBuilder;
                IBinder iBinder = callbacks.asBinder();
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
                if (connectionRecord == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("sendCustomAction for callback that isn't registered action=");
                  stringBuilder.append(action);
                  stringBuilder.append(", extras=");
                  stringBuilder.append(extras);
                  Log.w("MBServiceCompat", stringBuilder.toString());
                  return;
                } 
                MediaBrowserServiceCompat.this.performCustomAction(action, extras, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
              }
            });
      } 
    }
    
    public void unregisterCallbacks(final MediaBrowserServiceCompat.ServiceCallbacks callbacks) {
      MediaBrowserServiceCompat.this.mHandler.postOrRun(new Runnable() {
            public void run() {
              IBinder iBinder = callbacks.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
              if (connectionRecord != null)
                iBinder.unlinkToDeath(connectionRecord, 0); 
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(pkg, pid, uid, rootHints, callbacks);
      MediaBrowserServiceCompat mediaBrowserServiceCompat1 = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat1.mCurConnection = connectionRecord;
      MediaBrowserServiceCompat.BrowserRoot browserRoot = mediaBrowserServiceCompat1.onGetRoot(pkg, uid, rootHints);
      connectionRecord.root = browserRoot;
      MediaBrowserServiceCompat mediaBrowserServiceCompat2 = MediaBrowserServiceCompat.this;
      mediaBrowserServiceCompat2.mCurConnection = null;
      if (browserRoot == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No root for client ");
        stringBuilder.append(pkg);
        stringBuilder.append(" from service ");
        stringBuilder.append(getClass().getName());
        stringBuilder.toString();
        try {
          callbacks.onConnectFailed();
          return;
        } catch (RemoteException remoteException) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Calling onConnectFailed() failed. Ignoring. pkg=");
          stringBuilder.append(pkg);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
      } 
      try {
        mediaBrowserServiceCompat2.mConnections.put(stringBuilder, connectionRecord);
        stringBuilder.linkToDeath(connectionRecord, 0);
        if (MediaBrowserServiceCompat.this.mSession != null) {
          callbacks.onConnect(connectionRecord.root.getRootId(), MediaBrowserServiceCompat.this.mSession, connectionRecord.root.getExtras());
          return;
        } 
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Calling onConnect() failed. Dropping client. pkg=");
        stringBuilder1.append(pkg);
        Log.w("MBServiceCompat", stringBuilder1.toString());
        MediaBrowserServiceCompat.this.mConnections.remove(stringBuilder);
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
      if (connectionRecord != null)
        connectionRecord.callbacks.asBinder().unlinkToDeath(connectionRecord, 0); 
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
      if (connectionRecord == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("addSubscription for callback that isn't registered id=");
        stringBuilder.append(id);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      MediaBrowserServiceCompat.this.addSubscription(id, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, token, options);
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
      if (connectionRecord == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription for callback that isn't registered id=");
        stringBuilder.append(id);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      if (!MediaBrowserServiceCompat.this.removeSubscription(id, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, token)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription called for ");
        stringBuilder.append(id);
        stringBuilder.append(" which is not subscribed");
        Log.w("MBServiceCompat", stringBuilder.toString());
      } 
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
      if (connectionRecord == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("getMediaItem for callback that isn't registered id=");
        stringBuilder.append(mediaId);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      MediaBrowserServiceCompat.this.performLoadItem(mediaId, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
    }
  }
  
  class null implements Runnable {
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
      //   4: invokeinterface asBinder : ()Landroid/os/IBinder;
      //   9: astore #4
      //   11: aload_0
      //   12: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
      //   15: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
      //   18: getfield mConnections : Landroidx/collection/ArrayMap;
      //   21: aload #4
      //   23: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   26: pop
      //   27: aload_0
      //   28: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
      //   31: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
      //   34: getfield mPendingConnections : Ljava/util/ArrayList;
      //   37: invokevirtual iterator : ()Ljava/util/Iterator;
      //   40: astore #5
      //   42: aload #5
      //   44: invokeinterface hasNext : ()Z
      //   49: istore_1
      //   50: aconst_null
      //   51: astore_2
      //   52: aconst_null
      //   53: astore_3
      //   54: iload_1
      //   55: ifeq -> 146
      //   58: aload #5
      //   60: invokeinterface next : ()Ljava/lang/Object;
      //   65: checkcast androidx/media/MediaBrowserServiceCompat$ConnectionRecord
      //   68: astore #6
      //   70: aload #6
      //   72: getfield uid : I
      //   75: aload_0
      //   76: getfield val$uid : I
      //   79: if_icmpne -> 42
      //   82: aload_0
      //   83: getfield val$pkg : Ljava/lang/String;
      //   86: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   89: ifne -> 101
      //   92: aload_3
      //   93: astore_2
      //   94: aload_0
      //   95: getfield val$pid : I
      //   98: ifgt -> 139
      //   101: new androidx/media/MediaBrowserServiceCompat$ConnectionRecord
      //   104: dup
      //   105: aload_0
      //   106: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
      //   109: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
      //   112: aload #6
      //   114: getfield pkg : Ljava/lang/String;
      //   117: aload #6
      //   119: getfield pid : I
      //   122: aload #6
      //   124: getfield uid : I
      //   127: aload_0
      //   128: getfield val$rootHints : Landroid/os/Bundle;
      //   131: aload_0
      //   132: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
      //   135: invokespecial <init> : (Landroidx/media/MediaBrowserServiceCompat;Ljava/lang/String;IILandroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;)V
      //   138: astore_2
      //   139: aload #5
      //   141: invokeinterface remove : ()V
      //   146: aload_2
      //   147: astore_3
      //   148: aload_2
      //   149: ifnonnull -> 187
      //   152: new androidx/media/MediaBrowserServiceCompat$ConnectionRecord
      //   155: dup
      //   156: aload_0
      //   157: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
      //   160: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
      //   163: aload_0
      //   164: getfield val$pkg : Ljava/lang/String;
      //   167: aload_0
      //   168: getfield val$pid : I
      //   171: aload_0
      //   172: getfield val$uid : I
      //   175: aload_0
      //   176: getfield val$rootHints : Landroid/os/Bundle;
      //   179: aload_0
      //   180: getfield val$callbacks : Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;
      //   183: invokespecial <init> : (Landroidx/media/MediaBrowserServiceCompat;Ljava/lang/String;IILandroid/os/Bundle;Landroidx/media/MediaBrowserServiceCompat$ServiceCallbacks;)V
      //   186: astore_3
      //   187: aload_0
      //   188: getfield this$1 : Landroidx/media/MediaBrowserServiceCompat$ServiceBinderImpl;
      //   191: getfield this$0 : Landroidx/media/MediaBrowserServiceCompat;
      //   194: getfield mConnections : Landroidx/collection/ArrayMap;
      //   197: aload #4
      //   199: aload_3
      //   200: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   203: pop
      //   204: aload #4
      //   206: aload_3
      //   207: iconst_0
      //   208: invokeinterface linkToDeath : (Landroid/os/IBinder$DeathRecipient;I)V
      //   213: return
      //   214: ldc 'MBServiceCompat'
      //   216: ldc 'IBinder is already dead.'
      //   218: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
      //   221: pop
      //   222: return
      //   223: astore_2
      //   224: goto -> 214
      // Exception table:
      //   from	to	target	type
      //   204	213	223	android/os/RemoteException
    }
  }
  
  class null implements Runnable {
    public void run() {
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.remove(iBinder);
      if (connectionRecord != null)
        iBinder.unlinkToDeath(connectionRecord, 0); 
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
      if (connectionRecord == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("search for callback that isn't registered query=");
        stringBuilder.append(query);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      MediaBrowserServiceCompat.this.performSearch(query, extras, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
    }
  }
  
  class null implements Runnable {
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = callbacks.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.this.mConnections.get(iBinder);
      if (connectionRecord == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("sendCustomAction for callback that isn't registered action=");
        stringBuilder.append(action);
        stringBuilder.append(", extras=");
        stringBuilder.append(extras);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      MediaBrowserServiceCompat.this.performCustomAction(action, extras, (MediaBrowserServiceCompat.ConnectionRecord)stringBuilder, receiver);
    }
  }
  
  private static interface ServiceCallbacks {
    IBinder asBinder();
    
    void onConnect(String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) throws RemoteException;
    
    void onConnectFailed() throws RemoteException;
    
    void onLoadChildren(String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle1, Bundle param1Bundle2) throws RemoteException;
  }
  
  private static class ServiceCallbacksCompat implements ServiceCallbacks {
    final Messenger mCallbacks;
    
    ServiceCallbacksCompat(Messenger param1Messenger) {
      this.mCallbacks = param1Messenger;
    }
    
    private void sendRequest(int param1Int, Bundle param1Bundle) throws RemoteException {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 2;
      message.setData(param1Bundle);
      this.mCallbacks.send(message);
    }
    
    public IBinder asBinder() {
      return this.mCallbacks.getBinder();
    }
    
    public void onConnect(String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) throws RemoteException {
      Bundle bundle = param1Bundle;
      if (param1Bundle == null)
        bundle = new Bundle(); 
      bundle.putInt("extra_service_version", 2);
      param1Bundle = new Bundle();
      param1Bundle.putString("data_media_item_id", param1String);
      param1Bundle.putParcelable("data_media_session_token", (Parcelable)param1Token);
      param1Bundle.putBundle("data_root_hints", bundle);
      sendRequest(1, param1Bundle);
    }
    
    public void onConnectFailed() throws RemoteException {
      sendRequest(2, null);
    }
    
    public void onLoadChildren(String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle1, Bundle param1Bundle2) throws RemoteException {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      bundle.putBundle("data_options", param1Bundle1);
      bundle.putBundle("data_notify_children_changed_options", param1Bundle2);
      if (param1List != null) {
        ArrayList<MediaBrowserCompat.MediaItem> arrayList;
        if (param1List instanceof ArrayList) {
          arrayList = (ArrayList)param1List;
        } else {
          arrayList = new ArrayList<MediaBrowserCompat.MediaItem>(param1List);
        } 
        bundle.putParcelableArrayList("data_media_item_list", arrayList);
      } 
      sendRequest(3, bundle);
    }
  }
  
  private final class ServiceHandler extends Handler {
    private final MediaBrowserServiceCompat.ServiceBinderImpl mServiceBinderImpl = new MediaBrowserServiceCompat.ServiceBinderImpl();
    
    public void handleMessage(Message param1Message) {
      StringBuilder stringBuilder;
      Bundle bundle1 = param1Message.getData();
      switch (param1Message.what) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unhandled message: ");
          stringBuilder.append(param1Message);
          stringBuilder.append("\n  Service version: ");
          stringBuilder.append(2);
          stringBuilder.append("\n  Client version: ");
          stringBuilder.append(param1Message.arg1);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        case 9:
          bundle2 = stringBuilder.getBundle("data_custom_action_extras");
          MediaSessionCompat.ensureClassLoader(bundle2);
          this.mServiceBinderImpl.sendCustomAction(stringBuilder.getString("data_custom_action"), bundle2, (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 8:
          bundle2 = stringBuilder.getBundle("data_search_extras");
          MediaSessionCompat.ensureClassLoader(bundle2);
          this.mServiceBinderImpl.search(stringBuilder.getString("data_search_query"), bundle2, (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 7:
          this.mServiceBinderImpl.unregisterCallbacks(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 6:
          bundle2 = stringBuilder.getBundle("data_root_hints");
          MediaSessionCompat.ensureClassLoader(bundle2);
          this.mServiceBinderImpl.registerCallbacks(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo), stringBuilder.getString("data_package_name"), stringBuilder.getInt("data_calling_pid"), stringBuilder.getInt("data_calling_uid"), bundle2);
          return;
        case 5:
          this.mServiceBinderImpl.getMediaItem(stringBuilder.getString("data_media_item_id"), (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 4:
          this.mServiceBinderImpl.removeSubscription(stringBuilder.getString("data_media_item_id"), BundleCompat.getBinder((Bundle)stringBuilder, "data_callback_token"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 3:
          bundle2 = stringBuilder.getBundle("data_options");
          MediaSessionCompat.ensureClassLoader(bundle2);
          this.mServiceBinderImpl.addSubscription(stringBuilder.getString("data_media_item_id"), BundleCompat.getBinder((Bundle)stringBuilder, "data_callback_token"), bundle2, new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 2:
          this.mServiceBinderImpl.disconnect(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 1:
          break;
      } 
      Bundle bundle2 = stringBuilder.getBundle("data_root_hints");
      MediaSessionCompat.ensureClassLoader(bundle2);
      this.mServiceBinderImpl.connect(stringBuilder.getString("data_package_name"), stringBuilder.getInt("data_calling_pid"), stringBuilder.getInt("data_calling_uid"), bundle2, new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
    }
    
    public void postOrRun(Runnable param1Runnable) {
      if (Thread.currentThread() == getLooper().getThread()) {
        param1Runnable.run();
        return;
      } 
      post(param1Runnable);
    }
    
    public boolean sendMessageAtTime(Message param1Message, long param1Long) {
      Bundle bundle = param1Message.getData();
      bundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      bundle.putInt("data_calling_uid", Binder.getCallingUid());
      int i = Binder.getCallingPid();
      if (i > 0) {
        bundle.putInt("data_calling_pid", i);
      } else if (!bundle.containsKey("data_calling_pid")) {
        bundle.putInt("data_calling_pid", -1);
      } 
      return super.sendMessageAtTime(param1Message, param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media\MediaBrowserServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */