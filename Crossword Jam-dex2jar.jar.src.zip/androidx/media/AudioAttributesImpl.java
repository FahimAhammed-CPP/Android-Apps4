package androidx.media;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.versionedparcelable.VersionedParcelable;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public interface AudioAttributesImpl extends VersionedParcelable {
  @Nullable
  Object getAudioAttributes();
  
  int getContentType();
  
  int getFlags();
  
  int getLegacyStreamType();
  
  int getRawLegacyStreamType();
  
  int getUsage();
  
  int getVolumeControlStream();
  
  public static interface Builder {
    @NonNull
    AudioAttributesImpl build();
    
    @NonNull
    Builder setContentType(int param1Int);
    
    @NonNull
    Builder setFlags(int param1Int);
    
    @NonNull
    Builder setLegacyStreamType(int param1Int);
    
    @NonNull
    Builder setUsage(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword Jam-dex2jar.jar!\androidx\media\AudioAttributesImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */