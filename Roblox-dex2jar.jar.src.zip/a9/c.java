package a9;

import android.content.Context;
import android.view.View;
import z8.h;

public class c extends a {
  public c(Context paramContext, String paramString1, String paramString2, int paramInt1, int paramInt2) {
    super(paramString1, paramContext, paramString2, paramInt1, paramInt2);
  }
  
  public void onClick(View paramView) {
    Context context = this.o;
    if (context != null)
      h.b(context); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a9\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */