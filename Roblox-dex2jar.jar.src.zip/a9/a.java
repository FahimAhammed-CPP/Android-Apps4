package a9;

import android.content.Context;
import android.text.style.ClickableSpan;

public abstract class a extends ClickableSpan {
  protected String n;
  
  protected Context o;
  
  private String p;
  
  private int q;
  
  private int r;
  
  public a(String paramString1, Context paramContext, String paramString2, int paramInt1, int paramInt2) {
    this.o = paramContext;
    this.n = paramString1;
    this.p = paramString2;
    this.q = paramInt1;
    this.r = paramInt2;
  }
  
  public String a() {
    return this.p;
  }
  
  public int b() {
    return this.r;
  }
  
  public int c() {
    return this.q;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a9\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */