package a9;

import android.content.Context;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import com.roblox.client.e0;
import com.roblox.client.q0;
import java.util.ArrayList;
import q7.a;
import z8.k;
import z8.l;

public class b {
  public static void a(Context paramContext, TextView paramTextView) {
    String str1 = paramContext.getString(e0.R2);
    String str2 = paramContext.getString(e0.M2);
    c(paramContext, paramTextView, a.c(paramContext, e0.w1, new Object[] { str1, str2 }), str1, str2);
  }
  
  public static void b(Context paramContext, TextView paramTextView) {
    String str1 = paramContext.getString(e0.R2);
    String str2 = paramContext.getString(e0.M2);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str1);
    stringBuilder.append(" - ");
    stringBuilder.append(str2);
    c(paramContext, paramTextView, stringBuilder.toString(), str1, str2);
  }
  
  public static void c(Context paramContext, TextView paramTextView, String paramString1, String paramString2, String paramString3) {
    int i = paramString1.indexOf(paramString2);
    int j = paramString2.length();
    int k = paramString1.indexOf(paramString3);
    int m = paramString3.length();
    e(paramTextView, paramString1, (a[])new d[] { new d(g(), paramContext, paramString2, i, i + j), new d(f(), paramContext, paramString3, k, k + m) });
  }
  
  static SpannableStringBuilder d(SpannableStringBuilder paramSpannableStringBuilder, String paramString, a... paramVarArgs) {
    ArrayList<a> arrayList = new ArrayList();
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      a a1 = paramVarArgs[i];
      try {
        if (paramString.contains(a1.a())) {
          int k = a1.c();
          int m = a1.b();
          arrayList.add(a1);
          if (!h(arrayList, paramString, k, m))
            paramSpannableStringBuilder.setSpan(a1, k, m, 33); 
        } 
      } catch (NullPointerException nullPointerException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NullPointer Exception in generateClickableString(): ");
        stringBuilder.append(nullPointerException.getMessage());
        k.b(stringBuilder.toString());
      } 
    } 
    return paramSpannableStringBuilder;
  }
  
  public static void e(TextView paramTextView, String paramString, a... paramVarArgs) {
    paramTextView.setText((CharSequence)d(new SpannableStringBuilder(paramString), paramString, paramVarArgs));
    paramTextView.setMovementMethod(LinkMovementMethod.getInstance());
  }
  
  private static String f() {
    if (l.g())
      return "https://game.qq.com/privacy_guide.shtml"; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(q0.j());
    stringBuilder.append("Info/Privacy?layout=null");
    return stringBuilder.toString();
  }
  
  private static String g() {
    if (l.g())
      return "https://game.qq.com/contract.shtml"; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(q0.j());
    stringBuilder.append("info/terms");
    return stringBuilder.toString();
  }
  
  private static boolean h(ArrayList<a> paramArrayList, String paramString, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramArrayList.size() - 1; i++) {
      ((a)paramArrayList.get(i)).a();
      int j = ((a)paramArrayList.get(i)).c();
      int k = ((a)paramArrayList.get(i)).b();
      if ((paramInt1 >= j && paramInt1 <= k) || (paramInt2 >= j && paramInt2 <= k))
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a9\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */