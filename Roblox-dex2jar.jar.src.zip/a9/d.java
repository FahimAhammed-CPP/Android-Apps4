package a9;

import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.view.View;
import com.roblox.client.RobloxWebActivity;
import com.roblox.client.e1;
import com.roblox.client.h0;

public class d extends a {
  private boolean s;
  
  private String t;
  
  protected long u = 0L;
  
  public d(String paramString1, Context paramContext, String paramString2, int paramInt1, int paramInt2) {
    this(paramString1, paramContext, paramString2, paramInt1, paramInt2, false, null);
  }
  
  public d(String paramString1, Context paramContext, String paramString2, int paramInt1, int paramInt2, boolean paramBoolean, String paramString3) {
    super(paramString1, paramContext, paramString2, paramInt1, paramInt2);
    this.s = paramBoolean;
    this.t = paramString3;
  }
  
  private String e() {
    String str = this.t;
    return (str != null) ? str : a();
  }
  
  private void f(Context paramContext, String paramString1, String paramString2) {
    Intent intent = new Intent(paramContext, RobloxWebActivity.class);
    intent.putExtra("URL_EXTRA", paramString1);
    intent.putExtra("TITLE_EXTRA", paramString2);
    paramContext.startActivity(intent);
  }
  
  protected boolean d() {
    return (this.o != null && this.n != null);
  }
  
  protected boolean g(String paramString) {
    h0.c(paramString, "span");
    long l = SystemClock.elapsedRealtime();
    if (l - this.u < 1000L)
      return false; 
    this.u = l;
    return true;
  }
  
  public void onClick(View paramView) {
    if (g("clickableSpan") && d()) {
      if (this.s) {
        e1.m(this.o, this.n);
        return;
      } 
      f(this.o, this.n, e());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a9\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */