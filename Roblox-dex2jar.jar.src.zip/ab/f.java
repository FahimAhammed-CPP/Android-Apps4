package ab;

class f extends e {
  public static int a(int paramInt1, int paramInt2) {
    int i = paramInt1;
    if (paramInt1 < paramInt2)
      i = paramInt2; 
    return i;
  }
  
  public static long b(long paramLong1, long paramLong2) {
    long l = paramLong1;
    if (paramLong1 < paramLong2)
      l = paramLong2; 
    return l;
  }
  
  public static int c(int paramInt1, int paramInt2) {
    int i = paramInt1;
    if (paramInt1 > paramInt2)
      i = paramInt2; 
    return i;
  }
  
  public static long d(long paramLong1, long paramLong2) {
    long l = paramLong1;
    if (paramLong1 > paramLong2)
      l = paramLong2; 
    return l;
  }
  
  public static int e(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 <= paramInt3)
      return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot coerce value to an empty range: maximum ");
    stringBuilder.append(paramInt3);
    stringBuilder.append(" is less than minimum ");
    stringBuilder.append(paramInt2);
    stringBuilder.append('.');
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static a f(int paramInt1, int paramInt2) {
    return a.q.a(paramInt1, paramInt2, -1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\ab\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */