package ab;

import java.util.NoSuchElementException;
import oa.t;

public final class b extends t {
  private final int n;
  
  private final int o;
  
  private boolean p;
  
  private int q;
  
  public b(int paramInt1, int paramInt2, int paramInt3) {
    this.n = paramInt3;
    this.o = paramInt2;
    boolean bool = true;
    if ((paramInt3 > 0) ? (paramInt1 <= paramInt2) : (paramInt1 >= paramInt2))
      bool = false; 
    this.p = bool;
    if (!bool)
      paramInt1 = paramInt2; 
    this.q = paramInt1;
  }
  
  public int a() {
    int i = this.q;
    if (i == this.o) {
      if (this.p) {
        this.p = false;
        return i;
      } 
      throw new NoSuchElementException();
    } 
    this.q = this.n + i;
    return i;
  }
  
  public boolean hasNext() {
    return this.p;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\ab\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */