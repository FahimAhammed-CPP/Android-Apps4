package ab;

import xa.b;

public final class c extends a {
  public static final a r = new a(null);
  
  private static final c s = new c(1, 0);
  
  public c(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2, 1);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof c)
      if (!isEmpty() || !((c)paramObject).isEmpty()) {
        int i = c();
        paramObject = paramObject;
        if (i == paramObject.c() && e() == paramObject.e())
          return true; 
      } else {
        return true;
      }  
    return false;
  }
  
  public int hashCode() {
    return isEmpty() ? -1 : (c() * 31 + e());
  }
  
  public boolean isEmpty() {
    return (c() > e());
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(c());
    stringBuilder.append("..");
    stringBuilder.append(e());
    return stringBuilder.toString();
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\ab\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */