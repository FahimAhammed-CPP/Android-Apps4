package ab;

import java.util.Iterator;
import oa.t;
import sa.c;
import xa.b;

public class a implements Iterable<Integer> {
  public static final a q = new a(null);
  
  private final int n;
  
  private final int o;
  
  private final int p;
  
  public a(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 != 0) {
      if (paramInt3 != Integer.MIN_VALUE) {
        this.n = paramInt1;
        this.o = c.b(paramInt1, paramInt2, paramInt3);
        this.p = paramInt3;
        return;
      } 
      throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
    } 
    throw new IllegalArgumentException("Step must be non-zero.");
  }
  
  public final int c() {
    return this.n;
  }
  
  public final int e() {
    return this.o;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof a)
      if (!isEmpty() || !((a)paramObject).isEmpty()) {
        int i = this.n;
        paramObject = paramObject;
        if (i == ((a)paramObject).n && this.o == ((a)paramObject).o && this.p == ((a)paramObject).p)
          return true; 
      } else {
        return true;
      }  
    return false;
  }
  
  public int hashCode() {
    return isEmpty() ? -1 : ((this.n * 31 + this.o) * 31 + this.p);
  }
  
  public final int i() {
    return this.p;
  }
  
  public boolean isEmpty() {
    if (this.p > 0) {
      if (this.n > this.o)
        return true; 
    } else if (this.n < this.o) {
      return true;
    } 
    return false;
  }
  
  public t k() {
    return new b(this.n, this.o, this.p);
  }
  
  public String toString() {
    int i;
    StringBuilder stringBuilder;
    if (this.p > 0) {
      stringBuilder = new StringBuilder();
      stringBuilder.append(this.n);
      stringBuilder.append("..");
      stringBuilder.append(this.o);
      stringBuilder.append(" step ");
      i = this.p;
    } else {
      stringBuilder = new StringBuilder();
      stringBuilder.append(this.n);
      stringBuilder.append(" downTo ");
      stringBuilder.append(this.o);
      stringBuilder.append(" step ");
      i = -this.p;
    } 
    stringBuilder.append(i);
    return stringBuilder.toString();
  }
  
  public static final class a {
    private a() {}
    
    public final a a(int param1Int1, int param1Int2, int param1Int3) {
      return new a(param1Int1, param1Int2, param1Int3);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\ab\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */