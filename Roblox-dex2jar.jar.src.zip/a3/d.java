package a3;

import com.google.android.gms.common.api.Status;
import d3.h;
import d3.i;
import d3.m;
import e3.m;
import f3.j;
import i3.a;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public final class d implements Runnable {
  private static final a p = new a("RevokeAccessOperation", new String[0]);
  
  private final String n;
  
  private final m o;
  
  public d(String paramString) {
    this.n = j.f(paramString);
    this.o = new m(null);
  }
  
  public static h a(String paramString) {
    if (paramString == null)
      return i.a((m)new Status(4), null); 
    d d1 = new d(paramString);
    (new Thread(d1)).start();
    return (h)d1.o;
  }
  
  public final void run() {
    Status status1 = Status.v;
    Status status2 = status1;
    Status status3 = status1;
    try {
      String str = this.n;
      status2 = status1;
      status3 = status1;
      StringBuilder stringBuilder = new StringBuilder();
      status2 = status1;
      status3 = status1;
      stringBuilder.append("https://accounts.google.com/o/oauth2/revoke?token=");
      status2 = status1;
      status3 = status1;
      stringBuilder.append(str);
      status2 = status1;
      status3 = status1;
      HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(stringBuilder.toString())).openConnection();
      status2 = status1;
      status3 = status1;
      httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
      status2 = status1;
      status3 = status1;
      int i = httpURLConnection.getResponseCode();
      if (i == 200) {
        status2 = status1;
        status3 = status1;
        status1 = Status.t;
      } else {
        status2 = status1;
        status3 = status1;
        p.b("Unable to revoke access!", new Object[0]);
      } 
      status2 = status1;
      status3 = status1;
      a a1 = p;
      status2 = status1;
      status3 = status1;
      stringBuilder = new StringBuilder();
      status2 = status1;
      status3 = status1;
      stringBuilder.append("Response Code: ");
      status2 = status1;
      status3 = status1;
      stringBuilder.append(i);
      status2 = status1;
      status3 = status1;
      a1.a(stringBuilder.toString(), new Object[0]);
    } catch (IOException iOException) {
      p.b("IOException when revoking access: ".concat(String.valueOf(iOException.toString())), new Object[0]);
      Status status = status3;
    } catch (Exception exception) {}
    this.o.g((m)exception);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */