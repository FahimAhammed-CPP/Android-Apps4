package a3;

import android.content.Context;
import android.os.Binder;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.a;
import com.google.android.gms.auth.api.signin.b;
import l3.n;

public final class t extends o {
  private final Context a;
  
  public t(Context paramContext) {
    this.a = paramContext;
  }
  
  private final void k() {
    if (n.a(this.a, Binder.getCallingUid()))
      return; 
    int i = Binder.getCallingUid();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Calling UID ");
    stringBuilder.append(i);
    stringBuilder.append(" is not Google Play services.");
    throw new SecurityException(stringBuilder.toString());
  }
  
  public final void A() {
    k();
    n.a(this.a).b();
  }
  
  public final void M() {
    k();
    b b1 = b.b(this.a);
    GoogleSignInAccount googleSignInAccount = b1.c();
    GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.y;
    if (googleSignInAccount != null)
      googleSignInOptions = b1.d(); 
    b b = a.a(this.a, googleSignInOptions);
    if (googleSignInAccount != null) {
      b.t();
      return;
    } 
    b.u();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */