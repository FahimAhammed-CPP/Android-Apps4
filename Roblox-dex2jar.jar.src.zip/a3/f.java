package a3;

import z2.a;

public final class f implements a {}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */