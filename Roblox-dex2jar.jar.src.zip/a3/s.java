package a3;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import s3.a;
import s3.m;

public final class s extends a {
  s(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.auth.api.signin.internal.ISignInService");
  }
  
  public final void m(r paramr, GoogleSignInOptions paramGoogleSignInOptions) throws RemoteException {
    Parcel parcel = h();
    m.d(parcel, paramr);
    m.c(parcel, (Parcelable)paramGoogleSignInOptions);
    k(103, parcel);
  }
  
  public final void z0(r paramr, GoogleSignInOptions paramGoogleSignInOptions) throws RemoteException {
    Parcel parcel = h();
    m.d(parcel, paramr);
    m.c(parcel, (Parcelable)paramGoogleSignInOptions);
    k(102, parcel);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */