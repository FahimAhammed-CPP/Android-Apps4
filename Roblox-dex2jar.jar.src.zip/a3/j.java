package a3;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import d3.m;

final class j extends c {
  j(k paramk) {}
  
  public final void s0(Status paramStatus) throws RemoteException {
    this.a.g((m)paramStatus);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */