package a3;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import f3.j;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

public class b {
  private static final Lock c = new ReentrantLock();
  
  private static b d;
  
  private final Lock a = new ReentrantLock();
  
  private final SharedPreferences b;
  
  b(Context paramContext) {
    this.b = paramContext.getSharedPreferences("com.google.android.gms.signin", 0);
  }
  
  public static b b(Context paramContext) {
    j.j(paramContext);
    Lock lock = c;
    lock.lock();
    try {
      if (d == null)
        d = new b(paramContext.getApplicationContext()); 
      return d;
    } finally {
      c.unlock();
    } 
  }
  
  private static final String i(String paramString1, String paramString2) {
    int i = String.valueOf(paramString2).length();
    StringBuilder stringBuilder = new StringBuilder(paramString1.length() + 1 + i);
    stringBuilder.append(paramString1);
    stringBuilder.append(":");
    stringBuilder.append(paramString2);
    return stringBuilder.toString();
  }
  
  public void a() {
    this.a.lock();
    try {
      this.b.edit().clear().apply();
      return;
    } finally {
      this.a.unlock();
    } 
  }
  
  public GoogleSignInAccount c() {
    String str = g("defaultGoogleSignInAccount");
    boolean bool = TextUtils.isEmpty(str);
    GoogleSignInAccount googleSignInAccount = null;
    if (bool)
      return null; 
    str = g(i("googleSignInAccount", str));
    if (str != null)
      try {
        return GoogleSignInAccount.H(str);
      } catch (JSONException jSONException) {
        return null;
      }  
    return (GoogleSignInAccount)jSONException;
  }
  
  public GoogleSignInOptions d() {
    String str = g("defaultGoogleSignInAccount");
    boolean bool = TextUtils.isEmpty(str);
    GoogleSignInOptions googleSignInOptions = null;
    if (bool)
      return null; 
    str = g(i("googleSignInOptions", str));
    if (str != null)
      try {
        return GoogleSignInOptions.F(str);
      } catch (JSONException jSONException) {
        return null;
      }  
    return (GoogleSignInOptions)jSONException;
  }
  
  public String e() {
    return g("refreshToken");
  }
  
  public void f(GoogleSignInAccount paramGoogleSignInAccount, GoogleSignInOptions paramGoogleSignInOptions) {
    j.j(paramGoogleSignInAccount);
    j.j(paramGoogleSignInOptions);
    h("defaultGoogleSignInAccount", paramGoogleSignInAccount.I());
    j.j(paramGoogleSignInAccount);
    j.j(paramGoogleSignInOptions);
    String str = paramGoogleSignInAccount.I();
    h(i("googleSignInAccount", str), paramGoogleSignInAccount.J());
    h(i("googleSignInOptions", str), paramGoogleSignInOptions.J());
  }
  
  protected final String g(String paramString) {
    this.a.lock();
    try {
      paramString = this.b.getString(paramString, null);
      return paramString;
    } finally {
      this.a.unlock();
    } 
  }
  
  protected final void h(String paramString1, String paramString2) {
    this.a.lock();
    try {
      this.b.edit().putString(paramString1, paramString2).apply();
      return;
    } finally {
      this.a.unlock();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */