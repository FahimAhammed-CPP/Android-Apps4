package a3;

import android.content.Context;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

public final class n {
  private static n d;
  
  final b a;
  
  GoogleSignInAccount b;
  
  GoogleSignInOptions c;
  
  private n(Context paramContext) {
    b b1 = b.b(paramContext);
    this.a = b1;
    this.b = b1.c();
    this.c = b1.d();
  }
  
  public static n a(Context paramContext) {
    // Byte code:
    //   0: ldc a3/n
    //   2: monitorenter
    //   3: aload_0
    //   4: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   7: invokestatic d : (Landroid/content/Context;)La3/n;
    //   10: astore_0
    //   11: ldc a3/n
    //   13: monitorexit
    //   14: aload_0
    //   15: areturn
    //   16: astore_0
    //   17: ldc a3/n
    //   19: monitorexit
    //   20: aload_0
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   3	11	16	finally
  }
  
  private static n d(Context paramContext) {
    // Byte code:
    //   0: ldc a3/n
    //   2: monitorenter
    //   3: getstatic a3/n.d : La3/n;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 16
    //   11: ldc a3/n
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: new a3/n
    //   19: dup
    //   20: aload_0
    //   21: invokespecial <init> : (Landroid/content/Context;)V
    //   24: astore_0
    //   25: aload_0
    //   26: putstatic a3/n.d : La3/n;
    //   29: ldc a3/n
    //   31: monitorexit
    //   32: aload_0
    //   33: areturn
    //   34: astore_0
    //   35: ldc a3/n
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	34	finally
    //   16	29	34	finally
  }
  
  public final void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : La3/b;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: aconst_null
    //   11: putfield b : Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;
    //   14: aload_0
    //   15: aconst_null
    //   16: putfield c : Lcom/google/android/gms/auth/api/signin/GoogleSignInOptions;
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	22	finally
  }
  
  public final void c(GoogleSignInOptions paramGoogleSignInOptions, GoogleSignInAccount paramGoogleSignInAccount) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : La3/b;
    //   6: aload_2
    //   7: aload_1
    //   8: invokevirtual f : (Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;Lcom/google/android/gms/auth/api/signin/GoogleSignInOptions;)V
    //   11: aload_0
    //   12: aload_2
    //   13: putfield b : Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;
    //   16: aload_0
    //   17: aload_1
    //   18: putfield c : Lcom/google/android/gms/auth/api/signin/GoogleSignInOptions;
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	24	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */