package a3;

import android.os.IInterface;
import android.os.RemoteException;

public interface p extends IInterface {
  void A() throws RemoteException;
  
  void M() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */