package a3;

import android.os.Parcel;
import android.os.RemoteException;
import s3.j;

public abstract class o extends j implements p {
  public o() {
    super("com.google.android.gms.auth.api.signin.internal.IRevocationService");
  }
  
  protected final boolean h(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      A();
      return true;
    } 
    M();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */