package a3;

import android.content.Context;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.c;
import d3.f;
import d3.h;
import d3.i;
import i3.a;
import java.util.Iterator;

public final class m {
  private static final a a = new a("GoogleSignInCommon", new String[0]);
  
  public static h a(f paramf, Context paramContext, boolean paramBoolean) {
    a.a("Revoking access", new Object[0]);
    String str = b.b(paramContext).e();
    c(paramContext);
    return (h)(paramBoolean ? d.a(str) : paramf.b(new k(paramf)));
  }
  
  public static h b(f paramf, Context paramContext, boolean paramBoolean) {
    a.a("Signing out", new Object[0]);
    c(paramContext);
    return (h)(paramBoolean ? i.b(Status.t, paramf) : paramf.b(new i(paramf)));
  }
  
  private static void c(Context paramContext) {
    n.a(paramContext).b();
    Iterator<f> iterator = f.c().iterator();
    while (iterator.hasNext())
      ((f)iterator.next()).f(); 
    c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */