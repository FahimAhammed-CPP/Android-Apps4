package a3;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;
import s3.j;
import s3.m;

public abstract class q extends j implements r {
  public q() {
    super("com.google.android.gms.auth.api.signin.internal.ISignInCallbacks");
  }
  
  protected final boolean h(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    Status status1;
    switch (paramInt1) {
      default:
        return false;
      case 103:
        status1 = (Status)m.a(paramParcel1, Status.CREATOR);
        m.b(paramParcel1);
        s0(status1);
        paramParcel2.writeNoException();
        return true;
      case 102:
        status1 = (Status)m.a(paramParcel1, Status.CREATOR);
        m.b(paramParcel1);
        g(status1);
        paramParcel2.writeNoException();
        return true;
      case 101:
        break;
    } 
    GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount)m.a(paramParcel1, GoogleSignInAccount.CREATOR);
    Status status2 = (Status)m.a(paramParcel1, Status.CREATOR);
    m.b(paramParcel1);
    u0(googleSignInAccount, status2);
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */