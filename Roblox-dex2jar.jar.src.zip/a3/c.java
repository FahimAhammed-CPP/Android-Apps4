package a3;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public class c extends q {
  public void g(Status paramStatus) throws RemoteException {
    throw new UnsupportedOperationException();
  }
  
  public void s0(Status paramStatus) throws RemoteException {
    throw new UnsupportedOperationException();
  }
  
  public void u0(GoogleSignInAccount paramGoogleSignInAccount, Status paramStatus) throws RemoteException {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */