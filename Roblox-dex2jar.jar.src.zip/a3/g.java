package a3;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.c;
import d3.f;
import f3.b;
import java.util.Iterator;
import s3.l;

public final class g extends c {
  private final GoogleSignInOptions I;
  
  public g(Context paramContext, Looper paramLooper, b paramb, GoogleSignInOptions paramGoogleSignInOptions, f.a parama, f.b paramb1) {
    super(paramContext, paramLooper, 91, paramb, parama, paramb1);
    GoogleSignInOptions.a a1;
    if (paramGoogleSignInOptions != null) {
      a1 = new GoogleSignInOptions.a(paramGoogleSignInOptions);
    } else {
      a1 = new GoogleSignInOptions.a();
    } 
    a1.e(l.a());
    if (!paramb.d().isEmpty()) {
      Iterator<Scope> iterator = paramb.d().iterator();
      while (iterator.hasNext())
        a1.d(iterator.next(), new Scope[0]); 
    } 
    this.I = a1.a();
  }
  
  protected final String E() {
    return "com.google.android.gms.auth.api.signin.internal.ISignInService";
  }
  
  protected final String F() {
    return "com.google.android.gms.auth.api.signin.service.START";
  }
  
  public final int g() {
    return 12451000;
  }
  
  public final GoogleSignInOptions m0() {
    return this.I;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a3\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */