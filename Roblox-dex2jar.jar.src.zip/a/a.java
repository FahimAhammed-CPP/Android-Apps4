package a;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface a extends IInterface {
  void o0(String paramString1, int paramInt, String paramString2, Notification paramNotification) throws RemoteException;
  
  public static abstract class a extends Binder implements a {
    public static a h(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.v4.app.INotificationSideChannel");
      return (iInterface != null && iInterface instanceof a) ? (a)iInterface : new a(param1IBinder);
    }
    
    public static a k() {
      return a.b;
    }
    
    private static class a implements a {
      public static a b;
      
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
      
      public void o0(String param2String1, int param2Int, String param2String2, Notification param2Notification) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
          parcel.writeString(param2String1);
          parcel.writeInt(param2Int);
          parcel.writeString(param2String2);
          if (param2Notification != null) {
            parcel.writeInt(1);
            param2Notification.writeToParcel(parcel, 0);
          } else {
            parcel.writeInt(0);
          } 
          if (!this.a.transact(1, parcel, null, 1) && a.a.k() != null) {
            a.a.k().o0(param2String1, param2Int, param2String2, param2Notification);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class a implements a {
    public static a b;
    
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
    
    public void o0(String param1String1, int param1Int, String param1String2, Notification param1Notification) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
        parcel.writeString(param1String1);
        parcel.writeInt(param1Int);
        parcel.writeString(param1String2);
        if (param1Notification != null) {
          parcel.writeInt(1);
          param1Notification.writeToParcel(parcel, 0);
        } else {
          parcel.writeInt(0);
        } 
        if (!this.a.transact(1, parcel, null, 1) && a.a.k() != null) {
          a.a.k().o0(param1String1, param1Int, param1String2, param1Notification);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */