package a4;

public final class t7 {
  private static t7 a;
  
  public static t7 a() {
    // Byte code:
    //   0: ldc a4/t7
    //   2: monitorenter
    //   3: getstatic a4/t7.a : La4/t7;
    //   6: ifnonnull -> 19
    //   9: new a4/t7
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic a4/t7.a : La4/t7;
    //   19: getstatic a4/t7.a : La4/t7;
    //   22: astore_0
    //   23: ldc a4/t7
    //   25: monitorexit
    //   26: aload_0
    //   27: areturn
    //   28: astore_0
    //   29: ldc a4/t7
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	28	finally
    //   19	23	28	finally
  }
  
  public static final boolean b() {
    return s7.a("mlkit-dev-profiling");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\t7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */