package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class v0 implements d<y> {
  static final v0 a = new v0();
  
  private static final c b;
  
  static {
    c.b b = c.a("errorCode");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */