package a4;

public @interface i8 {
  int zza();
  
  h8 zzb() default h8.n;
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\i8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */