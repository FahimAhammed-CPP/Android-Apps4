package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class h3 implements d<f6> {
  static final h3 a = new h3();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  static {
    c.b b = c.a("inferenceCommonLogEvent");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("smartReplies");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("resultStatus");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("suggestionsCount");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("blacklistErrorCode");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\h3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */