package a4;

final class t6 extends u6 {
  private static final t6 v = new t6("unusedTag");
  
  private t6(String paramString) {
    super("unusedTag", null);
  }
  
  public final void close() {}
  
  public final void e(long paramLong) {}
  
  public final void i(long paramLong) {}
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\t6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */