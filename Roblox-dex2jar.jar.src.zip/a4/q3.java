package a4;

import j5.a;
import j5.b;

public final class q3 implements a {
  public static final a a = new q3();
  
  public final void a(b<?> paramb) {
    paramb.a(b5.class, e2.a);
    paramb.a(o6.class, o3.a);
    paramb.a(c5.class, f2.a);
    paramb.a(f5.class, h2.a);
    paramb.a(d5.class, g2.a);
    paramb.a(e5.class, i2.a);
    paramb.a(h4.class, p1.a);
    paramb.a(g4.class, o1.a);
    paramb.a(p4.class, x1.a);
    paramb.a(k6.class, m3.a);
    paramb.a(e4.class, n1.a);
    paramb.a(d4.class, m1.a);
    paramb.a(m5.class, o2.a);
    paramb.a(r6.class, u1.a);
    paramb.a(n4.class, v1.a);
    paramb.a(l4.class, t1.a);
    paramb.a(n5.class, p2.a);
    paramb.a(g6.class, j3.a);
    paramb.a(i6.class, k3.a);
    paramb.a(k5.class, m2.a);
    paramb.a(q6.class, y0.a);
    paramb.a(l5.class, n2.a);
    paramb.a(o5.class, q2.a);
    paramb.a(r5.class, t2.a);
    paramb.a(q5.class, s2.a);
    paramb.a(p5.class, r2.a);
    paramb.a(w5.class, y2.a);
    paramb.a(x5.class, z2.a);
    paramb.a(z5.class, b3.a);
    paramb.a(y5.class, a3.a);
    paramb.a(j5.class, l2.a);
    paramb.a(a6.class, c3.a);
    paramb.a(b6.class, d3.a);
    paramb.a(c6.class, f3.a);
    paramb.a(d6.class, g3.a);
    paramb.a(f6.class, h3.a);
    paramb.a(e6.class, i3.a);
    paramb.a(v5.class, u2.a);
    paramb.a(w4.class, b2.a);
    paramb.a(t5.class, w2.a);
    paramb.a(s5.class, v2.a);
    paramb.a(u5.class, x2.a);
    paramb.a(j6.class, l3.a);
    paramb.a(p6.class, p3.a);
    paramb.a(v3.class, e1.a);
    paramb.a(t3.class, b1.a);
    paramb.a(s3.class, a1.a);
    paramb.a(u3.class, d1.a);
    paramb.a(x3.class, g1.a);
    paramb.a(w3.class, f1.a);
    paramb.a(y3.class, h1.a);
    paramb.a(z3.class, i1.a);
    paramb.a(a4.class, j1.a);
    paramb.a(b4.class, k1.a);
    paramb.a(c4.class, l1.a);
    paramb.a(y.class, v0.a);
    paramb.a(a0.class, x0.a);
    paramb.a(z.class, w0.a);
    paramb.a(u4.class, z1.a);
    paramb.a(i4.class, q1.a);
    paramb.a(h.class, d0.a);
    paramb.a(g.class, e0.a);
    paramb.a(j4.class, r1.a);
    paramb.a(j.class, f0.a);
    paramb.a(i.class, g0.a);
    paramb.a(n.class, j0.a);
    paramb.a(m.class, k0.a);
    paramb.a(l.class, h0.a);
    paramb.a(k.class, i0.a);
    paramb.a(p.class, l0.a);
    paramb.a(o.class, m0.a);
    paramb.a(r.class, n0.a);
    paramb.a(q.class, o0.a);
    paramb.a(x.class, t0.a);
    paramb.a(w.class, u0.a);
    paramb.a(t.class, p0.a);
    paramb.a(s.class, q0.a);
    paramb.a(v.class, r0.a);
    paramb.a(u.class, s0.a);
    paramb.a(l6.class, n3.a);
    paramb.a(t4.class, y1.a);
    paramb.a(x4.class, c2.a);
    paramb.a(r3.class, z0.a);
    paramb.a(o4.class, w1.a);
    paramb.a(v4.class, a2.a);
    paramb.a(k4.class, s1.a);
    paramb.a(i5.class, k2.a);
    paramb.a(h5.class, j2.a);
    paramb.a(f.class, c0.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\q3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */