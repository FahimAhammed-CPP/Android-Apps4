package a4;

import java.util.Iterator;

public abstract class b8<E> implements Iterator<E> {
  @Deprecated
  public final void remove() {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\b8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */