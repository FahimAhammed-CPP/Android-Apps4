package a4;

import java.util.HashMap;
import java.util.Map;

final class s7 {
  private static final Map<String, String> a = new HashMap<String, String>();
  
  static boolean a(String paramString) {
    t7.a();
    return Boolean.parseBoolean("");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\s7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */