package a4;

final class x7<E> extends h6<E> {
  private final z7<E> p;
  
  x7(z7<E> paramz7, int paramInt) {
    super(paramz7.size(), paramInt);
    this.p = paramz7;
  }
  
  protected final E a(int paramInt) {
    return this.p.get(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\x7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */