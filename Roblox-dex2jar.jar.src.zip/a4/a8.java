package a4;

final class a8<E> extends z7<E> {
  static final z7<Object> r = new a8(new Object[0], 0);
  
  final transient Object[] p;
  
  private final transient int q;
  
  a8(Object[] paramArrayOfObject, int paramInt) {
    this.p = paramArrayOfObject;
    this.q = paramInt;
  }
  
  final int c(Object[] paramArrayOfObject, int paramInt) {
    System.arraycopy(this.p, 0, paramArrayOfObject, 0, this.q);
    return this.q;
  }
  
  final int e() {
    return this.q;
  }
  
  public final E get(int paramInt) {
    f4.a(paramInt, this.q, "index");
    Object object = this.p[paramInt];
    object.getClass();
    return (E)object;
  }
  
  final int i() {
    return 0;
  }
  
  final Object[] k() {
    return this.p;
  }
  
  public final int size() {
    return this.q;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\a8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */