package a4;

public final class p7 {
  private static o7 a;
  
  public static f7 a(z6 paramz6) {
    // Byte code:
    //   0: ldc a4/p7
    //   2: monitorenter
    //   3: getstatic a4/p7.a : La4/o7;
    //   6: ifnonnull -> 20
    //   9: new a4/o7
    //   12: dup
    //   13: aconst_null
    //   14: invokespecial <init> : (La4/n7;)V
    //   17: putstatic a4/p7.a : La4/o7;
    //   20: getstatic a4/p7.a : La4/o7;
    //   23: aload_0
    //   24: invokevirtual b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   27: checkcast a4/f7
    //   30: astore_0
    //   31: ldc a4/p7
    //   33: monitorexit
    //   34: aload_0
    //   35: areturn
    //   36: astore_0
    //   37: ldc a4/p7
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	36	finally
    //   20	31	36	finally
  }
  
  public static f7 b(String paramString) {
    // Byte code:
    //   0: ldc a4/p7
    //   2: monitorenter
    //   3: ldc 'vision-common'
    //   5: invokestatic d : (Ljava/lang/String;)La4/y6;
    //   8: invokevirtual c : ()La4/z6;
    //   11: invokestatic a : (La4/z6;)La4/f7;
    //   14: astore_0
    //   15: ldc a4/p7
    //   17: monitorexit
    //   18: aload_0
    //   19: areturn
    //   20: astore_0
    //   21: ldc a4/p7
    //   23: monitorexit
    //   24: aload_0
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   3	15	20	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\p7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */