package a4;

public final class v3 {}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\v3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */