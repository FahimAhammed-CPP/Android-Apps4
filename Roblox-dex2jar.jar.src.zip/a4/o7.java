package a4;

import d6.e;
import d6.i;
import d6.n;

final class o7 extends e<z6, f7> {}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\o7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */