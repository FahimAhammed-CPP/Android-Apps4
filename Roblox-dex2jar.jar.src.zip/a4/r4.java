package a4;

public final class r4 {
  private Long a;
  
  private s4 b;
  
  private m4 c;
  
  private Integer d;
  
  private Integer e;
  
  private Integer f;
  
  private Integer g;
  
  public final r4 b(Long paramLong) {
    this.a = Long.valueOf(paramLong.longValue() & Long.MAX_VALUE);
    return this;
  }
  
  public final r4 c(Integer paramInteger) {
    this.d = Integer.valueOf(paramInteger.intValue() & Integer.MAX_VALUE);
    return this;
  }
  
  public final r4 d(m4 paramm4) {
    this.c = paramm4;
    return this;
  }
  
  public final r4 e(Integer paramInteger) {
    this.f = Integer.valueOf(paramInteger.intValue() & Integer.MAX_VALUE);
    return this;
  }
  
  public final r4 f(s4 params4) {
    this.b = params4;
    return this;
  }
  
  public final r4 g(Integer paramInteger) {
    this.e = Integer.valueOf(paramInteger.intValue() & Integer.MAX_VALUE);
    return this;
  }
  
  public final r4 h(Integer paramInteger) {
    this.g = Integer.valueOf(paramInteger.intValue() & Integer.MAX_VALUE);
    return this;
  }
  
  public final t4 j() {
    return new t4(this, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\r4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */