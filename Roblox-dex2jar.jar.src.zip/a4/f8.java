package a4;

import java.io.OutputStream;

final class f8 extends OutputStream {
  private long n = 0L;
  
  final long b() {
    return this.n;
  }
  
  public final void write(int paramInt) {
    this.n++;
  }
  
  public final void write(byte[] paramArrayOfbyte) {
    this.n += paramArrayOfbyte.length;
  }
  
  public final void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      int i = paramArrayOfbyte.length;
      if (paramInt1 <= i && paramInt2 >= 0) {
        paramInt1 += paramInt2;
        if (paramInt1 <= i && paramInt1 >= 0) {
          this.n += paramInt2;
          return;
        } 
      } 
    } 
    throw new IndexOutOfBoundsException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\f8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */