package a4;

public abstract class z6 {
  public static y6 d(String paramString) {
    w6 w6 = new w6();
    w6.d("vision-common");
    w6.a(true);
    w6.b(1);
    return w6;
  }
  
  public abstract int a();
  
  public abstract String b();
  
  public abstract boolean c();
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\z6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */