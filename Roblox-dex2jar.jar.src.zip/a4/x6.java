package a4;

final class x6 extends z6 {
  private final String a;
  
  private final boolean b;
  
  private final int c;
  
  public final int a() {
    return this.c;
  }
  
  public final String b() {
    return this.a;
  }
  
  public final boolean c() {
    return this.b;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof z6) {
      paramObject = paramObject;
      if (this.a.equals(paramObject.b()) && this.b == paramObject.c() && this.c == paramObject.a())
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    char c;
    int i = this.a.hashCode();
    if (true != this.b) {
      c = 'ӕ';
    } else {
      c = 'ӏ';
    } 
    return ((i ^ 0xF4243) * 1000003 ^ c) * 1000003 ^ this.c;
  }
  
  public final String toString() {
    String str = this.a;
    boolean bool = this.b;
    int i = this.c;
    StringBuilder stringBuilder = new StringBuilder(str.length() + 84);
    stringBuilder.append("MLKitLoggingOptions{libraryName=");
    stringBuilder.append(str);
    stringBuilder.append(", enableFirelog=");
    stringBuilder.append(bool);
    stringBuilder.append(", firelogEventType=");
    stringBuilder.append(i);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\x6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */