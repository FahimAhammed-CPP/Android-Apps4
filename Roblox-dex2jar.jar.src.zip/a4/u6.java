package a4;

import android.os.SystemClock;
import java.io.Closeable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class u6 implements Closeable {
  private static final Map<String, u6> u = new HashMap<String, u6>();
  
  private final String n;
  
  private int o;
  
  private double p;
  
  private long q;
  
  private long r;
  
  private long s = 2147483647L;
  
  private long t = -2147483648L;
  
  private u6(String paramString) {
    this.n = paramString;
  }
  
  private final void b() {
    this.o = 0;
    this.p = 0.0D;
    this.q = 0L;
    this.s = 2147483647L;
    this.t = -2147483648L;
  }
  
  public static long m() {
    return SystemClock.elapsedRealtimeNanos() / 1000L;
  }
  
  public static u6 y(String paramString) {
    t7.a();
    if (!t7.b())
      return t6.J(); 
    Map<String, u6> map = u;
    if (map.get("detectorTaskWithResource#run") == null)
      map.put("detectorTaskWithResource#run", new u6("detectorTaskWithResource#run")); 
    return map.get("detectorTaskWithResource#run");
  }
  
  public u6 c() {
    this.q = m();
    return this;
  }
  
  public void close() {
    long l = this.q;
    if (l != 0L) {
      i(l);
      return;
    } 
    throw new IllegalStateException("Did you forget to call start()?");
  }
  
  public void e(long paramLong) {
    long l1 = m();
    long l2 = this.r;
    if (l2 != 0L && l1 - l2 >= 1000000L)
      b(); 
    this.r = l1;
    this.o++;
    this.p += paramLong;
    this.s = Math.min(this.s, paramLong);
    this.t = Math.max(this.t, paramLong);
    if (this.o % 50 == 0) {
      String.format(Locale.US, "[%s] cur=%dus, counts=%d, min=%dus, max=%dus, avg=%dus", new Object[] { this.n, Long.valueOf(paramLong), Integer.valueOf(this.o), Long.valueOf(this.s), Long.valueOf(this.t), Integer.valueOf((int)(this.p / this.o)) });
      t7.a();
    } 
    if (this.o % 500 == 0)
      b(); 
  }
  
  public void i(long paramLong) {
    e(m() - paramLong);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a\\u6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */