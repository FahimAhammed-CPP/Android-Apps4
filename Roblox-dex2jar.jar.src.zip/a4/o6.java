package a4;

public final class o6 {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final String d;
  
  private final z7<String> e;
  
  private final String f;
  
  private final Boolean g;
  
  private final Boolean h;
  
  private final Boolean i;
  
  private final Integer j;
  
  @i8(zza = 8)
  public final z7<String> a() {
    return this.e;
  }
  
  @i8(zza = 10)
  public final Boolean b() {
    return this.g;
  }
  
  @i8(zza = 12)
  public final Boolean c() {
    return this.i;
  }
  
  @i8(zza = 11)
  public final Boolean d() {
    return this.h;
  }
  
  @i8(zza = 13)
  public final Integer e() {
    return this.j;
  }
  
  @i8(zza = 1)
  public final String f() {
    return this.a;
  }
  
  @i8(zza = 2)
  public final String g() {
    return this.b;
  }
  
  @i8(zza = 9)
  public final String h() {
    return this.f;
  }
  
  @i8(zza = 4)
  public final String i() {
    return this.c;
  }
  
  @i8(zza = 5)
  public final String j() {
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\o6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */