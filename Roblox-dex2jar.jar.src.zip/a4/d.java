package a4;

import i5.f;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

public final class d {
  private final Map<Class<?>, i5.d<?>> a;
  
  private final Map<Class<?>, f<?>> b;
  
  private final i5.d<Object> c;
  
  d(Map<Class<?>, i5.d<?>> paramMap, Map<Class<?>, f<?>> paramMap1, i5.d<Object> paramd) {
    this.a = paramMap;
    this.b = paramMap1;
    this.c = paramd;
  }
  
  public final byte[] a(Object paramObject) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      (new k8(byteArrayOutputStream, this.a, this.b, this.c)).h(paramObject);
    } catch (IOException iOException) {}
    return byteArrayOutputStream.toByteArray();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */