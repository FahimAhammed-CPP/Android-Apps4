package a4;

import android.os.SystemClock;

public final class r7 {
  public static void a(f7 paramf7, int paramInt1, int paramInt2, long paramLong, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    paramf7.b(b(paramInt1, paramInt2, paramLong, paramInt3, paramInt4, paramInt5, paramInt6), y4.G1);
  }
  
  private static q7 b(int paramInt1, int paramInt2, long paramLong, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    return new q7(paramInt1, paramInt2, paramInt5, paramInt3, paramInt4, SystemClock.elapsedRealtime() - paramLong, paramInt6);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\r7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */