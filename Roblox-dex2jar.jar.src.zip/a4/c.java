package a4;

import i5.d;
import i5.f;
import j5.b;
import java.util.HashMap;
import java.util.Map;

public final class c implements b<c> {
  private static final d<Object> d = b.a;
  
  private final Map<Class<?>, d<?>> a = new HashMap<Class<?>, d<?>>();
  
  private final Map<Class<?>, f<?>> b = new HashMap<Class<?>, f<?>>();
  
  private final d<Object> c = d;
  
  public final d b() {
    return new d(new HashMap<Class<?>, d<?>>(this.a), new HashMap<Class<?>, f<?>>(this.b), this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */