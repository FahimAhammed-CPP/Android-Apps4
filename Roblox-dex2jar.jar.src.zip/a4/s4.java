package a4;

public enum s4 implements g8 {
  o, p, q, r, s, t;
  
  private final int n;
  
  static {
    s4 s41 = new s4("SOURCE_UNKNOWN", 0, 0);
    o = s41;
    s4 s42 = new s4("BITMAP", 1, 1);
    p = s42;
    s4 s43 = new s4("BYTEARRAY", 2, 2);
    q = s43;
    s4 s44 = new s4("BYTEBUFFER", 3, 3);
    r = s44;
    s4 s45 = new s4("FILEPATH", 4, 4);
    s = s45;
    s4 s46 = new s4("ANDROID_MEDIA_IMAGE", 5, 5);
    t = s46;
    u = new s4[] { s41, s42, s43, s44, s45, s46 };
  }
  
  s4(int paramInt1) {
    this.n = paramInt1;
  }
  
  public final int zza() {
    return this.n;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\s4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */