package a4;

final class w6 extends y6 {
  private String a;
  
  private Boolean b;
  
  private Integer c;
  
  public final y6 a(boolean paramBoolean) {
    this.b = Boolean.TRUE;
    return this;
  }
  
  public final y6 b(int paramInt) {
    this.c = Integer.valueOf(1);
    return this;
  }
  
  public final z6 c() {
    String str2 = this.a;
    if (str2 != null) {
      Boolean bool = this.b;
      if (bool != null && this.c != null)
        return new x6(str2, bool.booleanValue(), this.c.intValue(), null); 
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    if (this.a == null)
      stringBuilder1.append(" libraryName"); 
    if (this.b == null)
      stringBuilder1.append(" enableFirelog"); 
    if (this.c == null)
      stringBuilder1.append(" firelogEventType"); 
    String str1 = String.valueOf(stringBuilder1);
    StringBuilder stringBuilder2 = new StringBuilder(str1.length() + 28);
    stringBuilder2.append("Missing required properties:");
    stringBuilder2.append(str1);
    throw new IllegalStateException(stringBuilder2.toString());
  }
  
  public final y6 d(String paramString) {
    this.a = "vision-common";
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\w6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */