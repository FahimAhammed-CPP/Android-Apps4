package a4;

import java.util.ListIterator;

public abstract class c8<E> extends b8<E> implements ListIterator<E> {
  @Deprecated
  public final void add(E paramE) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final void set(E paramE) {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\c8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */