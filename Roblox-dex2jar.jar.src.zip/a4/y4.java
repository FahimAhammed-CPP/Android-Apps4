package a4;

public enum y4 implements g8 {
  A, A0, A1, B, B0, B1, C, C0, C1, D, D0, D1, E, E0, E1, F, F0, F1, G, G0, G1, H, H0, H1, I, I0, I1, J, J0, J1, K, K0, K1, L, L0, L1, M, M0, M1, N, N0, N1, O, O0, O1, P, P0, P1, Q, Q0, Q1, R, R0, S, S0, T, T0, U, U0, V, V0, W, W0, X, X0, Y, Y0, Z, Z0, a0, a1, b0, b1, c0, c1, d0, d1, e0, e1, f0, f1, g0, g1, h0, h1, i0, i1, j0, j1, k0, k1, l0, l1, m0, m1, n0, n1, o, o0, o1, p, p0, p1, q, q0, q1, r, r0, r1, s, s0, s1, t, t0, t1, u, u0, u1, v, v0, v1, w, w0, w1, x, x0, x1, y, y0, y1, z, z0, z1;
  
  private final int n;
  
  static {
    y4 y41 = new y4("UNKNOWN_EVENT", 0, 0);
    o = y41;
    y4 y42 = new y4("ON_DEVICE_FACE_DETECT", 1, 1);
    p = y42;
    y4 y43 = new y4("ON_DEVICE_FACE_CREATE", 2, 2);
    q = y43;
    y4 y44 = new y4("ON_DEVICE_FACE_CLOSE", 3, 3);
    r = y44;
    y4 y45 = new y4("ON_DEVICE_FACE_LOAD", 4, 4);
    s = y45;
    y4 y46 = new y4("ON_DEVICE_TEXT_DETECT", 5, 11);
    t = y46;
    y4 y47 = new y4("ON_DEVICE_TEXT_CREATE", 6, 12);
    u = y47;
    y4 y48 = new y4("ON_DEVICE_TEXT_CLOSE", 7, 13);
    v = y48;
    y4 y49 = new y4("ON_DEVICE_BARCODE_DETECT", 8, 21);
    w = y49;
    y4 y410 = new y4("ON_DEVICE_BARCODE_CREATE", 9, 22);
    x = y410;
    y4 y411 = new y4("ON_DEVICE_BARCODE_CLOSE", 10, 23);
    y = y411;
    y4 y412 = new y4("ON_DEVICE_BARCODE_LOAD", 11, 24);
    z = y412;
    y4 y413 = new y4("ON_DEVICE_IMAGE_LABEL_DETECT", 12, 141);
    A = y413;
    y4 y414 = new y4("ON_DEVICE_IMAGE_LABEL_CREATE", 13, 142);
    B = y414;
    y4 y415 = new y4("ON_DEVICE_IMAGE_LABEL_CLOSE", 14, 143);
    C = y415;
    y4 y416 = new y4("ON_DEVICE_IMAGE_LABEL_LOAD", 15, 144);
    D = y416;
    y4 y417 = new y4("ON_DEVICE_SMART_REPLY_DETECT", 16, 151);
    E = y417;
    y4 y418 = new y4("ON_DEVICE_SMART_REPLY_CREATE", 17, 152);
    F = y418;
    y4 y419 = new y4("ON_DEVICE_SMART_REPLY_CLOSE", 18, 153);
    G = y419;
    y4 y420 = new y4("ON_DEVICE_SMART_REPLY_BLACKLIST_UPDATE", 19, 154);
    H = y420;
    y4 y421 = new y4("ON_DEVICE_LANGUAGE_IDENTIFICATION_DETECT", 20, 161);
    I = y421;
    y4 y422 = new y4("ON_DEVICE_LANGUAGE_IDENTIFICATION_CREATE", 21, 162);
    J = y422;
    y4 y423 = new y4("ON_DEVICE_LANGUAGE_IDENTIFICATION_LOAD", 22, 164);
    K = y423;
    y4 y424 = new y4("ON_DEVICE_LANGUAGE_IDENTIFICATION_CLOSE", 23, 163);
    L = y424;
    y4 y425 = new y4("ON_DEVICE_TRANSLATOR_TRANSLATE", 24, 171);
    M = y425;
    y4 y426 = new y4("ON_DEVICE_TRANSLATOR_CREATE", 25, 172);
    N = y426;
    y4 y427 = new y4("ON_DEVICE_TRANSLATOR_LOAD", 26, 173);
    O = y427;
    y4 y428 = new y4("ON_DEVICE_TRANSLATOR_CLOSE", 27, 174);
    P = y428;
    y4 y429 = new y4("ON_DEVICE_TRANSLATOR_DOWNLOAD", 28, 175);
    Q = y429;
    y4 y430 = new y4("ON_DEVICE_ENTITY_EXTRACTION_ANNOTATE", 29, 241);
    R = y430;
    y4 y431 = new y4("ON_DEVICE_ENTITY_EXTRACTION_CREATE", 30, 242);
    S = y431;
    y4 y432 = new y4("ON_DEVICE_ENTITY_EXTRACTION_LOAD", 31, 243);
    T = y432;
    y4 y433 = new y4("ON_DEVICE_ENTITY_EXTRACTION_CLOSE", 32, 244);
    U = y433;
    y4 y434 = new y4("ON_DEVICE_ENTITY_EXTRACTION_DOWNLOAD", 33, 245);
    V = y434;
    y4 y435 = new y4("ON_DEVICE_OBJECT_CREATE", 34, 191);
    W = y435;
    y4 y436 = new y4("ON_DEVICE_OBJECT_LOAD", 35, 192);
    X = y436;
    y4 y437 = new y4("ON_DEVICE_OBJECT_INFERENCE", 36, 193);
    Y = y437;
    y4 y438 = new y4("ON_DEVICE_OBJECT_CLOSE", 37, 194);
    Z = y438;
    y4 y439 = new y4("ON_DEVICE_DI_CREATE", 38, 311);
    a0 = y439;
    y4 y440 = new y4("ON_DEVICE_DI_LOAD", 39, 312);
    b0 = y440;
    y4 y441 = new y4("ON_DEVICE_DI_DOWNLOAD", 40, 313);
    c0 = y441;
    y4 y442 = new y4("ON_DEVICE_DI_RECOGNIZE", 41, 314);
    d0 = y442;
    y4 y443 = new y4("ON_DEVICE_DI_CLOSE", 42, 315);
    e0 = y443;
    y4 y444 = new y4("ON_DEVICE_POSE_CREATE", 43, 321);
    f0 = y444;
    y4 y445 = new y4("ON_DEVICE_POSE_LOAD", 44, 322);
    g0 = y445;
    y4 y446 = new y4("ON_DEVICE_POSE_INFERENCE", 45, 323);
    h0 = y446;
    y4 y447 = new y4("ON_DEVICE_POSE_CLOSE", 46, 324);
    i0 = y447;
    y4 y448 = new y4("ON_DEVICE_SEGMENTATION_CREATE", 47, 331);
    j0 = y448;
    y4 y449 = new y4("ON_DEVICE_SEGMENTATION_LOAD", 48, 332);
    k0 = y449;
    y4 y450 = new y4("ON_DEVICE_SEGMENTATION_INFERENCE", 49, 333);
    l0 = y450;
    y4 y451 = new y4("ON_DEVICE_SEGMENTATION_CLOSE", 50, 334);
    m0 = y451;
    y4 y452 = new y4("CUSTOM_OBJECT_CREATE", 51, 341);
    n0 = y452;
    y4 y453 = new y4("CUSTOM_OBJECT_LOAD", 52, 342);
    o0 = y453;
    y4 y454 = new y4("CUSTOM_OBJECT_INFERENCE", 53, 343);
    p0 = y454;
    y4 y455 = new y4("CUSTOM_OBJECT_CLOSE", 54, 344);
    q0 = y455;
    y4 y456 = new y4("CUSTOM_IMAGE_LABEL_CREATE", 55, 351);
    r0 = y456;
    y4 y457 = new y4("CUSTOM_IMAGE_LABEL_LOAD", 56, 352);
    s0 = y457;
    y4 y458 = new y4("CUSTOM_IMAGE_LABEL_DETECT", 57, 353);
    t0 = y458;
    y4 y459 = new y4("CUSTOM_IMAGE_LABEL_CLOSE", 58, 354);
    u0 = y459;
    y4 y460 = new y4("CLOUD_FACE_DETECT", 59, 31);
    v0 = y460;
    y4 y461 = new y4("CLOUD_FACE_CREATE", 60, 32);
    w0 = y461;
    y4 y462 = new y4("CLOUD_FACE_CLOSE", 61, 33);
    x0 = y462;
    y4 y463 = new y4("CLOUD_CROP_HINTS_CREATE", 62, 41);
    y0 = y463;
    y4 y464 = new y4("CLOUD_CROP_HINTS_DETECT", 63, 42);
    z0 = y464;
    y4 y465 = new y4("CLOUD_CROP_HINTS_CLOSE", 64, 43);
    A0 = y465;
    y4 y466 = new y4("CLOUD_DOCUMENT_TEXT_CREATE", 65, 51);
    B0 = y466;
    y4 y467 = new y4("CLOUD_DOCUMENT_TEXT_DETECT", 66, 52);
    C0 = y467;
    y4 y468 = new y4("CLOUD_DOCUMENT_TEXT_CLOSE", 67, 53);
    D0 = y468;
    y4 y469 = new y4("CLOUD_IMAGE_PROPERTIES_CREATE", 68, 61);
    E0 = y469;
    y4 y470 = new y4("CLOUD_IMAGE_PROPERTIES_DETECT", 69, 62);
    F0 = y470;
    y4 y471 = new y4("CLOUD_IMAGE_PROPERTIES_CLOSE", 70, 63);
    G0 = y471;
    y4 y472 = new y4("CLOUD_IMAGE_LABEL_CREATE", 71, 71);
    H0 = y472;
    y4 y473 = new y4("CLOUD_IMAGE_LABEL_DETECT", 72, 72);
    I0 = y473;
    y4 y474 = new y4("CLOUD_IMAGE_LABEL_CLOSE", 73, 73);
    J0 = y474;
    y4 y475 = new y4("CLOUD_LANDMARK_CREATE", 74, 81);
    K0 = y475;
    y4 y476 = new y4("CLOUD_LANDMARK_DETECT", 75, 82);
    L0 = y476;
    y4 y477 = new y4("CLOUD_LANDMARK_CLOSE", 76, 83);
    M0 = y477;
    y4 y478 = new y4("CLOUD_LOGO_CREATE", 77, 91);
    N0 = y478;
    y4 y479 = new y4("CLOUD_LOGO_DETECT", 78, 92);
    O0 = y479;
    y4 y480 = new y4("CLOUD_LOGO_CLOSE", 79, 93);
    P0 = y480;
    y4 y481 = new y4("CLOUD_SAFE_SEARCH_CREATE", 80, 111);
    Q0 = y481;
    y4 y482 = new y4("CLOUD_SAFE_SEARCH_DETECT", 81, 112);
    R0 = y482;
    y4 y483 = new y4("CLOUD_SAFE_SEARCH_CLOSE", 82, 113);
    S0 = y483;
    y4 y484 = new y4("CLOUD_TEXT_CREATE", 83, 121);
    T0 = y484;
    y4 y485 = new y4("CLOUD_TEXT_DETECT", 84, 122);
    U0 = y485;
    y4 y486 = new y4("CLOUD_TEXT_CLOSE", 85, 123);
    V0 = y486;
    y4 y487 = new y4("CLOUD_WEB_SEARCH_CREATE", 86, 131);
    W0 = y487;
    y4 y488 = new y4("CLOUD_WEB_SEARCH_DETECT", 87, 132);
    X0 = y488;
    y4 y489 = new y4("CLOUD_WEB_SEARCH_CLOSE", 88, 133);
    Y0 = y489;
    y4 y490 = new y4("CUSTOM_MODEL_RUN", 89, 102);
    Z0 = y490;
    y4 y491 = new y4("CUSTOM_MODEL_CREATE", 90, 103);
    a1 = y491;
    y4 y492 = new y4("CUSTOM_MODEL_CLOSE", 91, 104);
    b1 = y492;
    y4 y493 = new y4("CUSTOM_MODEL_LOAD", 92, 105);
    c1 = y493;
    y4 y494 = new y4("AUTOML_IMAGE_LABELING_RUN", 93, 181);
    d1 = y494;
    y4 y495 = new y4("AUTOML_IMAGE_LABELING_CREATE", 94, 182);
    e1 = y495;
    y4 y496 = new y4("AUTOML_IMAGE_LABELING_CLOSE", 95, 183);
    f1 = y496;
    y4 y497 = new y4("AUTOML_IMAGE_LABELING_LOAD", 96, 184);
    g1 = y497;
    y4 y498 = new y4("MODEL_DOWNLOAD", 97, 100);
    h1 = y498;
    y4 y499 = new y4("MODEL_UPDATE", 98, 101);
    i1 = y499;
    y4 y4100 = new y4("REMOTE_MODEL_IS_DOWNLOADED", 99, 251);
    j1 = y4100;
    y4 y4101 = new y4("REMOTE_MODEL_DELETE_ON_DEVICE", 100, 252);
    k1 = y4101;
    y4 y4102 = new y4("ACCELERATION_ANALYTICS", 101, 260);
    l1 = y4102;
    y4 y4103 = new y4("AGGREGATED_AUTO_ML_IMAGE_LABELING_INFERENCE", 102, 200);
    m1 = y4103;
    y4 y4104 = new y4("AGGREGATED_CUSTOM_MODEL_INFERENCE", 103, 201);
    n1 = y4104;
    y4 y4105 = new y4("AGGREGATED_ON_DEVICE_BARCODE_DETECTION", 104, 202);
    o1 = y4105;
    y4 y4106 = new y4("AGGREGATED_ON_DEVICE_FACE_DETECTION", 105, 203);
    p1 = y4106;
    y4 y4107 = new y4("AGGREGATED_ON_DEVICE_IMAGE_LABEL_DETECTION", 106, 204);
    q1 = y4107;
    y4 y4108 = new y4("AGGREGATED_ON_DEVICE_OBJECT_INFERENCE", 107, 205);
    r1 = y4108;
    y4 y4109 = new y4("AGGREGATED_ON_DEVICE_TEXT_DETECTION", 108, 206);
    s1 = y4109;
    y4 y4110 = new y4("AGGREGATED_ON_DEVICE_POSE_DETECTION", 109, 207);
    t1 = y4110;
    y4 y4111 = new y4("AGGREGATED_ON_DEVICE_SEGMENTATION", 110, 208);
    u1 = y4111;
    y4 y4112 = new y4("AGGREGATED_CUSTOM_OBJECT_INFERENCE", 111, 209);
    v1 = y4112;
    y4 y4113 = new y4("AGGREGATED_CUSTOM_IMAGE_LABEL_DETECTION", 112, 210);
    w1 = y4113;
    y4 y4114 = new y4("REMOTE_CONFIG_FETCH", 113, 271);
    x1 = y4114;
    y4 y4115 = new y4("REMOTE_CONFIG_ACTIVATE", 114, 272);
    y1 = y4115;
    y4 y4116 = new y4("REMOTE_CONFIG_LOAD", 115, 273);
    z1 = y4116;
    y4 y4117 = new y4("REMOTE_CONFIG_FRC_FETCH", 116, 281);
    A1 = y4117;
    y4 y4118 = new y4("INSTALLATION_ID_INIT", 117, 291);
    B1 = y4118;
    y4 y4119 = new y4("INSTALLATION_ID_REGISTER_NEW_ID", 118, 292);
    C1 = y4119;
    y4 y4120 = new y4("INSTALLATION_ID_REFRESH_TEMPORARY_TOKEN", 119, 293);
    D1 = y4120;
    y4 y4121 = new y4("INSTALLATION_ID_FIS_CREATE_INSTALLATION", 120, 301);
    E1 = y4121;
    y4 y4122 = new y4("INSTALLATION_ID_FIS_GENERATE_AUTH_TOKEN", 121, 302);
    F1 = y4122;
    y4 y4123 = new y4("INPUT_IMAGE_CONSTRUCTION", 122, 361);
    G1 = y4123;
    y4 y4124 = new y4("HANDLE_LEAKED", 123, 371);
    H1 = y4124;
    y4 y4125 = new y4("CAMERA_SOURCE", 124, 381);
    I1 = y4125;
    y4 y4126 = new y4("OPTIONAL_MODULE_IMAGE_LABELING", 125, 391);
    J1 = y4126;
    y4 y4127 = new y4("OPTIONAL_MODULE_LANGUAGE_ID", 126, 401);
    K1 = y4127;
    y4 y4128 = new y4("OPTIONAL_MODULE_NLCLASSIFIER", 127, 411);
    L1 = y4128;
    y4 y4129 = new y4("NLCLASSIFIER_CLIENT_LIBRARY", 128, 421);
    M1 = y4129;
    y4 y4130 = new y4("OPTIONAL_MODULE_FACE_DETECTION", 129, 441);
    N1 = y4130;
    y4 y4131 = new y4("ACCELERATION_ALLOWLIST_GET", 130, 431);
    O1 = y4131;
    y4 y4132 = new y4("ACCELERATION_ALLOWLIST_FETCH", 131, 432);
    P1 = y4132;
    y4 y4133 = new y4("ODML_IMAGE", 132, 442);
    Q1 = y4133;
    R1 = new y4[] { 
        y41, y42, y43, y44, y45, y46, y47, y48, y49, y410, 
        y411, y412, y413, y414, y415, y416, y417, y418, y419, y420, 
        y421, y422, y423, y424, y425, y426, y427, y428, y429, y430, 
        y431, y432, y433, y434, y435, y436, y437, y438, y439, y440, 
        y441, y442, y443, y444, y445, y446, y447, y448, y449, y450, 
        y451, y452, y453, y454, y455, y456, y457, y458, y459, y460, 
        y461, y462, y463, y464, y465, y466, y467, y468, y469, y470, 
        y471, y472, y473, y474, y475, y476, y477, y478, y479, y480, 
        y481, y482, y483, y484, y485, y486, y487, y488, y489, y490, 
        y491, y492, y493, y494, y495, y496, y497, y498, y499, y4100, 
        y4101, y4102, y4103, y4104, y4105, y4106, y4107, y4108, y4109, y4110, 
        y4111, y4112, y4113, y4114, y4115, y4116, y4117, y4118, y4119, y4120, 
        y4121, y4122, y4123, y4124, y4125, y4126, y4127, y4128, y4129, y4130, 
        y4131, y4132, y4133 };
  }
  
  y4(int paramInt1) {
    this.n = paramInt1;
  }
  
  public final int zza() {
    return this.n;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\y4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */