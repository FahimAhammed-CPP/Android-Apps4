package a4;

public final class e8 {
  private int a;
  
  private final h8 b = h8.n;
  
  public final e8 a(int paramInt) {
    this.a = paramInt;
    return this;
  }
  
  public final i8 b() {
    return new d8(this.a, this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\e8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */