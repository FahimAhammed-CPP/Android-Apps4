package a4;

import f3.j;
import java.io.UnsupportedEncodingException;
import k5.d;

public final class g7 {
  private final a5 a;
  
  private n6 b = new n6();
  
  private g7(a5 parama5, int paramInt) {
    this.a = parama5;
    t7.a();
  }
  
  public static g7 c(a5 parama5) {
    return new g7(parama5, 0);
  }
  
  public final String a() {
    o6 o6 = this.a.f().c();
    return (o6 != null && !g5.b(o6.j())) ? (String)j.j(o6.j()) : "NA";
  }
  
  public final byte[] b(int paramInt, boolean paramBoolean) {
    n6 n61 = this.b;
    if (paramInt == 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    n61.f(Boolean.valueOf(paramBoolean));
    this.b.e(Boolean.FALSE);
    this.a.e(this.b.l());
    try {
      t7.a();
      if (paramInt == 0) {
        b5 b51 = this.a.f();
        return (new d()).j(q3.a).k(true).i().a(b51).getBytes("utf-8");
      } 
      b5 b5 = this.a.f();
      c c = new c();
      q3.a.a(c);
      return c.b().a(b5);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new UnsupportedOperationException("Failed to covert logging to UTF-8 byte array", unsupportedEncodingException);
    } 
  }
  
  public final g7 d(y4 paramy4) {
    this.a.c(paramy4);
    return this;
  }
  
  public final g7 e(n6 paramn6) {
    this.b = paramn6;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\g7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */