package a4;

public final class a5 {
  private o6 a;
  
  private y4 b;
  
  private t4 c;
  
  public final a5 c(y4 paramy4) {
    this.b = paramy4;
    return this;
  }
  
  public final a5 d(t4 paramt4) {
    this.c = paramt4;
    return this;
  }
  
  public final a5 e(o6 paramo6) {
    this.a = paramo6;
    return this;
  }
  
  public final b5 f() {
    return new b5(this, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\a5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */