package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class e2 implements d<b5> {
  private static final c A;
  
  private static final c B;
  
  private static final c C;
  
  private static final c D;
  
  private static final c E;
  
  private static final c F;
  
  private static final c G;
  
  private static final c H;
  
  private static final c I;
  
  private static final c J;
  
  private static final c K;
  
  private static final c L;
  
  private static final c M;
  
  private static final c N;
  
  private static final c O;
  
  private static final c P;
  
  private static final c Q;
  
  private static final c R;
  
  private static final c S;
  
  private static final c T;
  
  private static final c U;
  
  private static final c V;
  
  private static final c W;
  
  private static final c X;
  
  private static final c Y;
  
  private static final c Z;
  
  static final e2 a = new e2();
  
  private static final c a0;
  
  private static final c b;
  
  private static final c b0;
  
  private static final c c;
  
  private static final c c0;
  
  private static final c d;
  
  private static final c d0;
  
  private static final c e;
  
  private static final c e0;
  
  private static final c f;
  
  private static final c f0;
  
  private static final c g;
  
  private static final c h;
  
  private static final c i;
  
  private static final c j;
  
  private static final c k;
  
  private static final c l;
  
  private static final c m;
  
  private static final c n;
  
  private static final c o;
  
  private static final c p;
  
  private static final c q;
  
  private static final c r;
  
  private static final c s;
  
  private static final c t;
  
  private static final c u;
  
  private static final c v;
  
  private static final c w;
  
  private static final c x;
  
  private static final c y;
  
  private static final c z;
  
  static {
    c.b b = c.a("systemInfo");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("eventName");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("isThickClient");
    e8 = new e8();
    e8.a(37);
    d = b.b(e8.b()).a();
    b = c.a("modelDownloadLogEvent");
    e8 = new e8();
    e8.a(3);
    e = b.b(e8.b()).a();
    b = c.a("customModelLoadLogEvent");
    e8 = new e8();
    e8.a(20);
    f = b.b(e8.b()).a();
    b = c.a("customModelInferenceLogEvent");
    e8 = new e8();
    e8.a(4);
    g = b.b(e8.b()).a();
    b = c.a("customModelCreateLogEvent");
    e8 = new e8();
    e8.a(29);
    h = b.b(e8.b()).a();
    b = c.a("onDeviceFaceDetectionLogEvent");
    e8 = new e8();
    e8.a(5);
    i = b.b(e8.b()).a();
    b = c.a("onDeviceFaceLoadLogEvent");
    e8 = new e8();
    e8.a(59);
    j = b.b(e8.b()).a();
    b = c.a("onDeviceTextDetectionLogEvent");
    e8 = new e8();
    e8.a(6);
    k = b.b(e8.b()).a();
    b = c.a("onDeviceBarcodeDetectionLogEvent");
    e8 = new e8();
    e8.a(7);
    l = b.b(e8.b()).a();
    b = c.a("onDeviceBarcodeLoadLogEvent");
    e8 = new e8();
    e8.a(58);
    m = b.b(e8.b()).a();
    b = c.a("onDeviceImageLabelCreateLogEvent");
    e8 = new e8();
    e8.a(48);
    n = b.b(e8.b()).a();
    b = c.a("onDeviceImageLabelLoadLogEvent");
    e8 = new e8();
    e8.a(49);
    o = b.b(e8.b()).a();
    b = c.a("onDeviceImageLabelDetectionLogEvent");
    e8 = new e8();
    e8.a(18);
    p = b.b(e8.b()).a();
    b = c.a("onDeviceObjectCreateLogEvent");
    e8 = new e8();
    e8.a(26);
    q = b.b(e8.b()).a();
    b = c.a("onDeviceObjectLoadLogEvent");
    e8 = new e8();
    e8.a(27);
    r = b.b(e8.b()).a();
    b = c.a("onDeviceObjectInferenceLogEvent");
    e8 = new e8();
    e8.a(28);
    s = b.b(e8.b()).a();
    b = c.a("onDevicePoseDetectionLogEvent");
    e8 = new e8();
    e8.a(44);
    t = b.b(e8.b()).a();
    b = c.a("onDeviceSegmentationLogEvent");
    e8 = new e8();
    e8.a(45);
    u = b.b(e8.b()).a();
    b = c.a("onDeviceSmartReplyLogEvent");
    e8 = new e8();
    e8.a(19);
    v = b.b(e8.b()).a();
    b = c.a("onDeviceLanguageIdentificationLogEvent");
    e8 = new e8();
    e8.a(21);
    w = b.b(e8.b()).a();
    b = c.a("onDeviceTranslationLogEvent");
    e8 = new e8();
    e8.a(22);
    x = b.b(e8.b()).a();
    b = c.a("cloudFaceDetectionLogEvent");
    e8 = new e8();
    e8.a(8);
    y = b.b(e8.b()).a();
    b = c.a("cloudCropHintDetectionLogEvent");
    e8 = new e8();
    e8.a(9);
    z = b.b(e8.b()).a();
    b = c.a("cloudDocumentTextDetectionLogEvent");
    e8 = new e8();
    e8.a(10);
    A = b.b(e8.b()).a();
    b = c.a("cloudImagePropertiesDetectionLogEvent");
    e8 = new e8();
    e8.a(11);
    B = b.b(e8.b()).a();
    b = c.a("cloudImageLabelDetectionLogEvent");
    e8 = new e8();
    e8.a(12);
    C = b.b(e8.b()).a();
    b = c.a("cloudLandmarkDetectionLogEvent");
    e8 = new e8();
    e8.a(13);
    D = b.b(e8.b()).a();
    b = c.a("cloudLogoDetectionLogEvent");
    e8 = new e8();
    e8.a(14);
    E = b.b(e8.b()).a();
    b = c.a("cloudSafeSearchDetectionLogEvent");
    e8 = new e8();
    e8.a(15);
    F = b.b(e8.b()).a();
    b = c.a("cloudTextDetectionLogEvent");
    e8 = new e8();
    e8.a(16);
    G = b.b(e8.b()).a();
    b = c.a("cloudWebSearchDetectionLogEvent");
    e8 = new e8();
    e8.a(17);
    H = b.b(e8.b()).a();
    b = c.a("automlImageLabelingCreateLogEvent");
    e8 = new e8();
    e8.a(23);
    I = b.b(e8.b()).a();
    b = c.a("automlImageLabelingLoadLogEvent");
    e8 = new e8();
    e8.a(24);
    J = b.b(e8.b()).a();
    b = c.a("automlImageLabelingInferenceLogEvent");
    e8 = new e8();
    e8.a(25);
    K = b.b(e8.b()).a();
    b = c.a("isModelDownloadedLogEvent");
    e8 = new e8();
    e8.a(39);
    L = b.b(e8.b()).a();
    b = c.a("deleteModelLogEvent");
    e8 = new e8();
    e8.a(40);
    M = b.b(e8.b()).a();
    b = c.a("aggregatedAutomlImageLabelingInferenceLogEvent");
    e8 = new e8();
    e8.a(30);
    N = b.b(e8.b()).a();
    b = c.a("aggregatedCustomModelInferenceLogEvent");
    e8 = new e8();
    e8.a(31);
    O = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceFaceDetectionLogEvent");
    e8 = new e8();
    e8.a(32);
    P = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceBarcodeDetectionLogEvent");
    e8 = new e8();
    e8.a(33);
    Q = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceImageLabelDetectionLogEvent");
    e8 = new e8();
    e8.a(34);
    R = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceObjectInferenceLogEvent");
    e8 = new e8();
    e8.a(35);
    S = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceTextDetectionLogEvent");
    e8 = new e8();
    e8.a(36);
    T = b.b(e8.b()).a();
    b = c.a("aggregatedOnDevicePoseDetectionLogEvent");
    e8 = new e8();
    e8.a(46);
    U = b.b(e8.b()).a();
    b = c.a("aggregatedOnDeviceSegmentationLogEvent");
    e8 = new e8();
    e8.a(47);
    V = b.b(e8.b()).a();
    b = c.a("remoteConfigLogEvent");
    e8 = new e8();
    e8.a(42);
    W = b.b(e8.b()).a();
    b = c.a("inputImageConstructionLogEvent");
    e8 = new e8();
    e8.a(50);
    X = b.b(e8.b()).a();
    b = c.a("leakedHandleEvent");
    e8 = new e8();
    e8.a(51);
    Y = b.b(e8.b()).a();
    b = c.a("cameraSourceLogEvent");
    e8 = new e8();
    e8.a(52);
    Z = b.b(e8.b()).a();
    b = c.a("imageLabelOptionalModuleLogEvent");
    e8 = new e8();
    e8.a(53);
    a0 = b.b(e8.b()).a();
    b = c.a("languageIdentificationOptionalModuleLogEvent");
    e8 = new e8();
    e8.a(54);
    b0 = b.b(e8.b()).a();
    b = c.a("faceDetectionOptionalModuleLogEvent");
    e8 = new e8();
    e8.a(60);
    c0 = b.b(e8.b()).a();
    b = c.a("nlClassifierOptionalModuleLogEvent");
    e8 = new e8();
    e8.a(55);
    d0 = b.b(e8.b()).a();
    b = c.a("nlClassifierClientLibraryLogEvent");
    e8 = new e8();
    e8.a(56);
    e0 = b.b(e8.b()).a();
    b = c.a("accelerationAllowlistLogEvent");
    e8 = new e8();
    e8.a(57);
    f0 = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\e2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */