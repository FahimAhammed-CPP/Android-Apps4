package a4;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class a7 implements e7 {
  final List<e7> a;
  
  public a7(Context paramContext, z6 paramz6) {
    ArrayList<e7> arrayList = new ArrayList();
    this.a = arrayList;
    if (paramz6.c())
      arrayList.add(new m7(paramContext, paramz6)); 
  }
  
  public final void a(g7 paramg7) {
    Iterator<e7> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((e7)iterator.next()).a(paramg7); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\a7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */