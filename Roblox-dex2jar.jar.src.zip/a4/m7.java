package a4;

import android.content.Context;
import com.google.android.datatransport.cct.a;
import e2.b;
import e2.c;
import e2.f;
import e2.g;
import g2.f;
import g2.t;
import g5.w;
import q5.b;

public final class m7 implements e7 {
  private b<f<byte[]>> a;
  
  private final b<f<byte[]>> b;
  
  private final z6 c;
  
  public m7(Context paramContext, z6 paramz6) {
    this.c = paramz6;
    a a = a.g;
    t.f(paramContext);
    g g = t.c().g((f)a);
    if (a.a().contains(b.b("json")))
      this.a = (b<f<byte[]>>)new w(new k7(g)); 
    this.b = (b<f<byte[]>>)new w(new l7(g));
  }
  
  static c<byte[]> b(z6 paramz6, g7 paramg7) {
    return c.e(paramg7.b(paramz6.a(), false));
  }
  
  public final void a(g7 paramg7) {
    if (this.c.a() == 0) {
      b<f<byte[]>> b1 = this.a;
      if (b1 != null)
        ((f)b1.get()).a(b(this.c, paramg7)); 
      return;
    } 
    ((f)this.b.get()).a(b(this.c, paramg7));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\m7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */