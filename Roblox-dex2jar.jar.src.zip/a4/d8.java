package a4;

import java.lang.annotation.Annotation;

final class d8 implements i8 {
  private final int a;
  
  private final h8 b;
  
  d8(int paramInt, h8 paramh8) {
    this.a = paramInt;
    this.b = paramh8;
  }
  
  public final Class<? extends Annotation> annotationType() {
    return (Class)i8.class;
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof i8))
      return false; 
    paramObject = paramObject;
    return (this.a == paramObject.zza() && this.b.equals(paramObject.zzb()));
  }
  
  public final int hashCode() {
    return (this.a ^ 0xDE0D66) + (this.b.hashCode() ^ 0x79AD669E);
  }
  
  public final String toString() {
    StringBuilder stringBuilder = new StringBuilder("@com.google.firebase.encoders.proto.Protobuf");
    stringBuilder.append("(tag=");
    stringBuilder.append(this.a);
    stringBuilder.append("intEncoding=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public final int zza() {
    return this.a;
  }
  
  public final h8 zzb() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\d8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */