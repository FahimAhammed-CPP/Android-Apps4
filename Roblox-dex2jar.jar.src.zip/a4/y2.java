package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class y2 implements d<w5> {
  static final y2 a = new y2();
  
  private static final c b;
  
  private static final c c;
  
  static {
    c.b b = c.a("detectorOptions");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("errorCode");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\y2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */