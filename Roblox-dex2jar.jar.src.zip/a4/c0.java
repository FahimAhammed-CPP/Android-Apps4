package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class c0 implements d<f> {
  static final c0 a = new c0();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  private static final c g;
  
  private static final c h;
  
  static {
    c.b b = c.a("durationMs");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("handledErrors");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("partiallyHandledErrors");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("unhandledErrors");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("modelNamespace");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
    b = c.a("delegateFilter");
    e8 = new e8();
    e8.a(6);
    g = b.b(e8.b()).a();
    b = c.a("httpResponseCode");
    e8 = new e8();
    e8.a(7);
    h = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */