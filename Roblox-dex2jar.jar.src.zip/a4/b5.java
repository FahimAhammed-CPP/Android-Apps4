package a4;

public final class b5 {
  private final o6 a;
  
  private final y4 b;
  
  private final t4 c;
  
  @i8(zza = 50)
  public final t4 a() {
    return this.c;
  }
  
  @i8(zza = 2)
  public final y4 b() {
    return this.b;
  }
  
  @i8(zza = 1)
  public final o6 c() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\b5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */