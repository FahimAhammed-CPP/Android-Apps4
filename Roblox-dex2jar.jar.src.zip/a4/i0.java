package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class i0 implements d<k> {
  static final i0 a = new i0();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  private static final c g;
  
  private static final c h;
  
  static {
    c.b b = c.a("errorCode");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("hasResult");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("isColdCall");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("imageInfo");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("options");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
    b = c.a("detectedBarcodeFormats");
    e8 = new e8();
    e8.a(6);
    g = b.b(e8.b()).a();
    b = c.a("detectedBarcodeValueTypes");
    e8 = new e8();
    e8.a(7);
    h = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */