package a4;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

public abstract class v7<E> extends AbstractCollection<E> implements Serializable {
  private static final Object[] n = new Object[0];
  
  @Deprecated
  public final boolean add(E paramE) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  abstract int c(Object[] paramArrayOfObject, int paramInt);
  
  @Deprecated
  public final void clear() {
    throw new UnsupportedOperationException();
  }
  
  abstract int e();
  
  abstract int i();
  
  abstract Object[] k();
  
  @Deprecated
  public final boolean remove(Object paramObject) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean removeAll(Collection<?> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean retainAll(Collection<?> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  public final Object[] toArray() {
    return toArray(n);
  }
  
  public final <T> T[] toArray(T[] paramArrayOfT) {
    T[] arrayOfT;
    Objects.requireNonNull(paramArrayOfT);
    int i = size();
    int j = paramArrayOfT.length;
    if (j < i) {
      Object[] arrayOfObject = k();
      if (arrayOfObject == null) {
        arrayOfObject = (Object[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), i);
      } else {
        return Arrays.copyOfRange(arrayOfObject, i(), e(), (Class)paramArrayOfT.getClass());
      } 
    } else {
      arrayOfT = paramArrayOfT;
      if (j > i) {
        paramArrayOfT[i] = null;
        arrayOfT = paramArrayOfT;
      } 
    } 
    c((Object[])arrayOfT, 0);
    return arrayOfT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\v7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */