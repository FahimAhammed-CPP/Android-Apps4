package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class g0 implements d<i> {
  static final g0 a = new g0();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  static {
    c.b b = c.a("errorCode");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("isColdCall");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("inputsFormats");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("outputFormats");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("options");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */