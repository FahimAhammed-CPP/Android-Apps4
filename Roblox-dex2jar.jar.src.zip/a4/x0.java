package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class x0 implements d<a0> {
  static final x0 a = new x0();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  static {
    c.b b = c.a("remoteModelOptions");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("localModelOptions");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("errorCodes");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("modelInitializationMs");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */