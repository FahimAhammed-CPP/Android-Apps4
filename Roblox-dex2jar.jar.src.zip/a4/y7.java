package a4;

import java.util.List;

final class y7 extends z7 {
  final transient int p;
  
  final transient int q;
  
  y7(z7 paramz7, int paramInt1, int paramInt2) {
    this.p = paramInt1;
    this.q = paramInt2;
  }
  
  final int e() {
    return this.r.i() + this.p + this.q;
  }
  
  public final Object get(int paramInt) {
    f4.a(paramInt, this.q, "index");
    return this.r.get(paramInt + this.p);
  }
  
  final int i() {
    return this.r.i() + this.p;
  }
  
  final Object[] k() {
    return this.r.k();
  }
  
  public final z7 m(int paramInt1, int paramInt2) {
    f4.c(paramInt1, paramInt2, this.q);
    z7 z71 = this.r;
    int i = this.p;
    return z71.m(paramInt1 + i, paramInt2 + i);
  }
  
  public final int size() {
    return this.q;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\y7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */