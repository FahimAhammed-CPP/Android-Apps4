package a4;

import java.util.logging.Logger;

final class e3 {
  private static final Logger a = Logger.getLogger(e3.class.getName());
  
  private static final d2 b = new d2(null);
  
  static boolean a(String paramString) {
    return (paramString == null || paramString.isEmpty());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\e3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */