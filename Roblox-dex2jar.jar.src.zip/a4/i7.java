package a4;

import java.util.Arrays;
import java.util.Objects;

class i7<E> extends u7<E> {
  Object[] a = new Object[4];
  
  int b = 0;
  
  boolean c;
  
  i7(int paramInt) {}
  
  private final void b(int paramInt) {
    Object[] arrayOfObject = this.a;
    int i = arrayOfObject.length;
    if (i < paramInt) {
      int j = i + (i >> 1) + 1;
      i = j;
      if (j < paramInt) {
        paramInt = Integer.highestOneBit(paramInt - 1);
        i = paramInt + paramInt;
      } 
      paramInt = i;
      if (i < 0)
        paramInt = Integer.MAX_VALUE; 
      this.a = Arrays.copyOf(arrayOfObject, paramInt);
      this.c = false;
      return;
    } 
    if (this.c) {
      this.a = (Object[])arrayOfObject.clone();
      this.c = false;
    } 
  }
  
  public final i7<E> a(E paramE) {
    Objects.requireNonNull(paramE);
    b(this.b + 1);
    Object[] arrayOfObject = this.a;
    int i = this.b;
    this.b = i + 1;
    arrayOfObject[i] = paramE;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\i7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */