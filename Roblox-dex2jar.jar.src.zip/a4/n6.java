package a4;

public final class n6 {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private z7<String> e;
  
  private String f;
  
  private Boolean g;
  
  private Boolean h;
  
  private Boolean i;
  
  private Integer j;
  
  public final n6 b(String paramString) {
    this.a = paramString;
    return this;
  }
  
  public final n6 c(String paramString) {
    this.b = paramString;
    return this;
  }
  
  public final n6 d(Integer paramInteger) {
    this.j = Integer.valueOf(paramInteger.intValue() & Integer.MAX_VALUE);
    return this;
  }
  
  public final n6 e(Boolean paramBoolean) {
    this.g = paramBoolean;
    return this;
  }
  
  public final n6 f(Boolean paramBoolean) {
    this.i = paramBoolean;
    return this;
  }
  
  public final n6 g(Boolean paramBoolean) {
    this.h = paramBoolean;
    return this;
  }
  
  public final n6 h(z7<String> paramz7) {
    this.e = paramz7;
    return this;
  }
  
  public final n6 i(String paramString) {
    this.f = paramString;
    return this;
  }
  
  public final n6 j(String paramString) {
    this.c = paramString;
    return this;
  }
  
  public final n6 k(String paramString) {
    this.d = paramString;
    return this;
  }
  
  public final o6 l() {
    return new o6(this, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\n6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */