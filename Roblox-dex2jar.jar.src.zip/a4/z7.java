package a4;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public abstract class z7<E> extends v7<E> implements List<E>, RandomAccess {
  private static final c8<Object> o = new x7(a8.r, 0);
  
  static <E> z7<E> n(Object[] paramArrayOfObject, int paramInt) {
    return (z7<E>)((paramInt == 0) ? a8.r : new a8<E>(paramArrayOfObject, paramInt));
  }
  
  public static <E> z7<E> o(E paramE) {
    Object[] arrayOfObject = new Object[1];
    int i = 0;
    arrayOfObject[0] = paramE;
    while (i) {
      if (arrayOfObject[i] != null) {
        i++;
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder(20);
      stringBuilder.append("at index ");
      stringBuilder.append(i);
      throw new NullPointerException(stringBuilder.toString());
    } 
    return n(arrayOfObject, 1);
  }
  
  @Deprecated
  public final void add(int paramInt, E paramE) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  int c(Object[] paramArrayOfObject, int paramInt) {
    int i = size();
    for (paramInt = 0; paramInt < i; paramInt++)
      paramArrayOfObject[paramInt] = get(paramInt); 
    return i;
  }
  
  public final boolean contains(Object paramObject) {
    return (indexOf(paramObject) >= 0);
  }
  
  public final boolean equals(Object paramObject) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: if_acmpne -> 7
    //   5: iconst_1
    //   6: ireturn
    //   7: aload_1
    //   8: instanceof java/util/List
    //   11: ifne -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: checkcast java/util/List
    //   20: astore #4
    //   22: aload_0
    //   23: invokeinterface size : ()I
    //   28: istore_3
    //   29: iload_3
    //   30: aload #4
    //   32: invokeinterface size : ()I
    //   37: if_icmpeq -> 43
    //   40: goto -> 14
    //   43: aload #4
    //   45: instanceof java/util/RandomAccess
    //   48: ifeq -> 89
    //   51: iconst_0
    //   52: istore_2
    //   53: iload_2
    //   54: iload_3
    //   55: if_icmpge -> 159
    //   58: aload_0
    //   59: iload_2
    //   60: invokeinterface get : (I)Ljava/lang/Object;
    //   65: aload #4
    //   67: iload_2
    //   68: invokeinterface get : (I)Ljava/lang/Object;
    //   73: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   76: ifne -> 82
    //   79: goto -> 14
    //   82: iload_2
    //   83: iconst_1
    //   84: iadd
    //   85: istore_2
    //   86: goto -> 53
    //   89: aload_0
    //   90: invokeinterface iterator : ()Ljava/util/Iterator;
    //   95: astore_1
    //   96: aload #4
    //   98: invokeinterface iterator : ()Ljava/util/Iterator;
    //   103: astore #4
    //   105: aload_1
    //   106: invokeinterface hasNext : ()Z
    //   111: ifeq -> 149
    //   114: aload #4
    //   116: invokeinterface hasNext : ()Z
    //   121: ifne -> 127
    //   124: goto -> 14
    //   127: aload_1
    //   128: invokeinterface next : ()Ljava/lang/Object;
    //   133: aload #4
    //   135: invokeinterface next : ()Ljava/lang/Object;
    //   140: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   143: ifne -> 105
    //   146: goto -> 14
    //   149: aload #4
    //   151: invokeinterface hasNext : ()Z
    //   156: ifne -> 14
    //   159: iconst_1
    //   160: ireturn
  }
  
  public final int hashCode() {
    int k = size();
    int j = 1;
    for (int i = 0; i < k; i++)
      j = j * 31 + get(i).hashCode(); 
    return j;
  }
  
  public final int indexOf(Object paramObject) {
    if (paramObject == null)
      return -1; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (paramObject.equals(get(i)))
        return i; 
    } 
    return -1;
  }
  
  public final int lastIndexOf(Object paramObject) {
    if (paramObject == null)
      return -1; 
    for (int i = size() - 1; i >= 0; i--) {
      if (paramObject.equals(get(i)))
        return i; 
    } 
    return -1;
  }
  
  public z7<E> m(int paramInt1, int paramInt2) {
    f4.c(paramInt1, paramInt2, size());
    paramInt2 -= paramInt1;
    return (paramInt2 == size()) ? this : ((paramInt2 == 0) ? a8.r : new y7(this, paramInt1, paramInt2));
  }
  
  public final c8<E> p(int paramInt) {
    f4.b(paramInt, size(), "index");
    return (c8<E>)(isEmpty() ? o : new x7<E>(this, paramInt));
  }
  
  @Deprecated
  public final E remove(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final E set(int paramInt, E paramE) {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\z7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */