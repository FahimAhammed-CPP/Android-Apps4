package a4;

public final class b0 extends a {
  public static boolean a(Object paramObject1, Object paramObject2) {
    null = false;
    if (paramObject1 != paramObject2)
      if (paramObject1 != null) {
        if (!paramObject1.equals(paramObject2))
          return false; 
      } else {
        return null;
      }  
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */