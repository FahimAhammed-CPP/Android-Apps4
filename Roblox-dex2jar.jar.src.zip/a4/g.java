package a4;

public final class g {
  public final boolean equals(Object paramObject) {
    throw null;
  }
  
  public final int hashCode() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */