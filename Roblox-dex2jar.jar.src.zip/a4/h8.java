package a4;

public enum h8 {
  n, o, p;
  
  static {
    h8 h81 = new h8("DEFAULT", 0);
    n = h81;
    h8 h82 = new h8("SIGNED", 1);
    o = h82;
    h8 h83 = new h8("FIXED", 2);
    p = h83;
    q = new h8[] { h81, h82, h83 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\h8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */