package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class l1 implements d<c4> {
  static final l1 a = new l1();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  static {
    c.b b = c.a("inferenceCommonLogEvent");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("options");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("imageInfo");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */