package a4;

public enum m4 implements g8 {
  o, p, q, r, s, t, u, v, w, x;
  
  private final int n;
  
  static {
    m4 m41 = new m4("UNKNOWN_FORMAT", 0, 0);
    o = m41;
    m4 m42 = new m4("NV16", 1, 1);
    p = m42;
    m4 m43 = new m4("NV21", 2, 2);
    q = m43;
    m4 m44 = new m4("YV12", 3, 3);
    r = m44;
    m4 m45 = new m4("YUV_420_888", 4, 7);
    s = m45;
    m4 m46 = new m4("JPEG", 5, 8);
    t = m46;
    m4 m47 = new m4("BITMAP", 6, 4);
    u = m47;
    m4 m48 = new m4("CM_SAMPLE_BUFFER_REF", 7, 5);
    v = m48;
    m4 m49 = new m4("UI_IMAGE", 8, 6);
    w = m49;
    m4 m410 = new m4("CV_PIXEL_BUFFER_REF", 9, 9);
    x = m410;
    y = new m4[] { m41, m42, m43, m44, m45, m46, m47, m48, m49, m410 };
  }
  
  m4(int paramInt1) {
    this.n = paramInt1;
  }
  
  public final int zza() {
    return this.n;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\m4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */