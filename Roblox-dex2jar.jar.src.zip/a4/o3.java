package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class o3 implements d<o6> {
  static final o3 a = new o3();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  private static final c g;
  
  private static final c h;
  
  private static final c i;
  
  private static final c j;
  
  private static final c k;
  
  private static final c l;
  
  private static final c m;
  
  private static final c n;
  
  static {
    c.b b = c.a("appId");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("appVersion");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("firebaseProjectId");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("mlSdkVersion");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("tfliteSchemaVersion");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
    b = c.a("gcmSenderId");
    e8 = new e8();
    e8.a(6);
    g = b.b(e8.b()).a();
    b = c.a("apiKey");
    e8 = new e8();
    e8.a(7);
    h = b.b(e8.b()).a();
    b = c.a("languages");
    e8 = new e8();
    e8.a(8);
    i = b.b(e8.b()).a();
    b = c.a("mlSdkInstanceId");
    e8 = new e8();
    e8.a(9);
    j = b.b(e8.b()).a();
    b = c.a("isClearcutClient");
    e8 = new e8();
    e8.a(10);
    k = b.b(e8.b()).a();
    b = c.a("isStandaloneMlkit");
    e8 = new e8();
    e8.a(11);
    l = b.b(e8.b()).a();
    b = c.a("isJsonLogging");
    e8 = new e8();
    e8.a(12);
    m = b.b(e8.b()).a();
    b = c.a("buildLevel");
    e8 = new e8();
    e8.a(13);
    n = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\o3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */