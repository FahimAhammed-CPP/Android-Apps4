package a4;

import i5.b;
import i5.c;
import i5.d;
import i5.e;
import i5.f;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Map;

final class k8 implements e {
  private static final Charset f = Charset.forName("UTF-8");
  
  private static final c g;
  
  private static final c h;
  
  private static final d<Map.Entry<Object, Object>> i = j8.a;
  
  private OutputStream a;
  
  private final Map<Class<?>, d<?>> b;
  
  private final Map<Class<?>, f<?>> c;
  
  private final d<Object> d;
  
  private final e e = new e(this);
  
  k8(OutputStream paramOutputStream, Map<Class<?>, d<?>> paramMap, Map<Class<?>, f<?>> paramMap1, d<Object> paramd) {
    this.a = paramOutputStream;
    this.b = paramMap;
    this.c = paramMap1;
    this.d = paramd;
  }
  
  private static int j(c paramc) {
    i8 i8 = (i8)paramc.c(i8.class);
    if (i8 != null)
      return i8.zza(); 
    throw new b("Field has no @Protobuf config");
  }
  
  private final <T> long k(d<T> paramd, T paramT) throws IOException {
    f8 f8 = new f8();
    try {
      OutputStream outputStream = this.a;
      this.a = f8;
    } finally {
      try {
        f8.close();
      } finally {
        paramT = null;
      } 
    } 
  }
  
  private static i8 l(c paramc) {
    i8 i8 = (i8)paramc.c(i8.class);
    if (i8 != null)
      return i8; 
    throw new b("Field has no @Protobuf config");
  }
  
  private final <T> k8 m(d<T> paramd, c paramc, T paramT, boolean paramBoolean) throws IOException {
    long l = k(paramd, paramT);
    if (paramBoolean && l == 0L)
      return this; 
    p(j(paramc) << 3 | 0x2);
    q(l);
    paramd.a(paramT, this);
    return this;
  }
  
  private final <T> k8 n(f<T> paramf, c paramc, T paramT, boolean paramBoolean) throws IOException {
    this.e.a(paramc, paramBoolean);
    paramf.a(paramT, this.e);
    return this;
  }
  
  private static ByteBuffer o(int paramInt) {
    return ByteBuffer.allocate(paramInt).order(ByteOrder.LITTLE_ENDIAN);
  }
  
  private final void p(int paramInt) throws IOException {
    while ((paramInt & 0xFFFFFF80) != 0L) {
      this.a.write(paramInt & 0x7F | 0x80);
      paramInt >>>= 7;
    } 
    this.a.write(paramInt & 0x7F);
  }
  
  private final void q(long paramLong) throws IOException {
    while ((0xFFFFFFFFFFFFFF80L & paramLong) != 0L) {
      this.a.write((int)paramLong & 0x7F | 0x80);
      paramLong >>>= 7L;
    } 
    this.a.write((int)paramLong & 0x7F);
  }
  
  final e b(c paramc, double paramDouble, boolean paramBoolean) throws IOException {
    if (paramBoolean && paramDouble == 0.0D)
      return this; 
    p(j(paramc) << 3 | 0x1);
    this.a.write(o(8).putDouble(paramDouble).array());
    return this;
  }
  
  final e c(c paramc, float paramFloat, boolean paramBoolean) throws IOException {
    if (paramBoolean && paramFloat == 0.0F)
      return this; 
    p(j(paramc) << 3 | 0x5);
    this.a.write(o(4).putFloat(paramFloat).array());
    return this;
  }
  
  public final e d(c paramc, Object paramObject) throws IOException {
    e(paramc, paramObject, true);
    return this;
  }
  
  final e e(c paramc, Object paramObject, boolean paramBoolean) throws IOException {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  final k8 f(c paramc, int paramInt, boolean paramBoolean) throws IOException {
    if (!paramBoolean || paramInt != 0) {
      i8 i8 = l(paramc);
      h8 h8 = h8.n;
      int i = i8.zzb().ordinal();
      if (i != 0) {
        if (i != 1) {
          if (i != 2)
            return this; 
          p(i8.zza() << 3 | 0x5);
          this.a.write(o(4).putInt(paramInt).array());
          return this;
        } 
        p(i8.zza() << 3);
        p(paramInt + paramInt ^ paramInt >> 31);
        return this;
      } 
      p(i8.zza() << 3);
      p(paramInt);
      return this;
    } 
    return this;
  }
  
  final k8 g(c paramc, long paramLong, boolean paramBoolean) throws IOException {
    if (!paramBoolean || paramLong != 0L) {
      i8 i8 = l(paramc);
      h8 h8 = h8.n;
      int i = i8.zzb().ordinal();
      if (i != 0) {
        if (i != 1) {
          if (i != 2)
            return this; 
          p(i8.zza() << 3 | 0x1);
          this.a.write(o(8).putLong(paramLong).array());
          return this;
        } 
        p(i8.zza() << 3);
        q(paramLong >> 63L ^ paramLong + paramLong);
        return this;
      } 
      p(i8.zza() << 3);
      q(paramLong);
      return this;
    } 
    return this;
  }
  
  final k8 h(Object paramObject) throws IOException {
    if (paramObject == null)
      return this; 
    d d1 = this.b.get(paramObject.getClass());
    if (d1 != null) {
      d1.a(paramObject, this);
      return this;
    } 
    paramObject = String.valueOf(paramObject.getClass());
    StringBuilder stringBuilder = new StringBuilder(paramObject.length() + 15);
    stringBuilder.append("No encoder for ");
    stringBuilder.append((String)paramObject);
    throw new b(stringBuilder.toString());
  }
  
  static {
    c.b b = c.a("key");
    e8 e8 = new e8();
    e8.a(1);
    g = b.b(e8.b()).a();
    b = c.a("value");
    e8 = new e8();
    e8.a(2);
    h = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\k8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */