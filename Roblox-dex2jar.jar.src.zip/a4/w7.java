package a4;

public final class w7<E> extends i7<E> {
  public w7() {
    super(4);
  }
  
  public final w7<E> c(E paramE) {
    a(paramE);
    return this;
  }
  
  public final z7<E> d() {
    this.c = true;
    return z7.n(this.a, this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\w7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */