package a4;

public final class t4 {
  private final Long a;
  
  private final s4 b;
  
  private final m4 c;
  
  private final Integer d;
  
  private final Integer e;
  
  private final Integer f;
  
  private final Integer g;
  
  @i8(zza = 3)
  public final m4 a() {
    return this.c;
  }
  
  @i8(zza = 2)
  public final s4 b() {
    return this.b;
  }
  
  @i8(zza = 4)
  public final Integer c() {
    return this.d;
  }
  
  @i8(zza = 6)
  public final Integer d() {
    return this.f;
  }
  
  @i8(zza = 5)
  public final Integer e() {
    return this.e;
  }
  
  @i8(zza = 7)
  public final Integer f() {
    return this.g;
  }
  
  @i8(zza = 1)
  public final Long g() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\t4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */