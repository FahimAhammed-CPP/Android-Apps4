package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class f0 implements d<j> {
  static final f0 a = new f0();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  static {
    c.b b = c.a("logEventKey");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("eventCount");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("inferenceDurationStats");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */