package a4;

import android.content.Context;
import android.os.SystemClock;
import d6.c;
import d6.g;
import d6.n;
import f3.g;
import h4.l;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public final class f7 {
  private static z7<String> j;
  
  private final String a;
  
  private final String b;
  
  private final e7 c;
  
  private final n d;
  
  private final l<String> e;
  
  private final l<String> f;
  
  private final String g;
  
  private final Map<y4, Long> h = new HashMap<y4, Long>();
  
  private final Map<y4, Object> i = new HashMap<y4, Object>();
  
  public f7(Context paramContext, n paramn, e7 parame7, String paramString) {
    this.a = paramContext.getPackageName();
    this.b = c.a(paramContext);
    this.d = paramn;
    this.c = parame7;
    this.g = paramString;
    this.e = g.a().b(new d7(paramString));
    g g = g.a();
    paramn.getClass();
    this.f = g.b(new c7(paramn));
  }
  
  private static z7<String> c() {
    // Byte code:
    //   0: ldc a4/f7
    //   2: monitorenter
    //   3: getstatic a4/f7.j : La4/z7;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 16
    //   11: ldc a4/f7
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: invokestatic getSystem : ()Landroid/content/res/Resources;
    //   19: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   22: invokestatic a : (Landroid/content/res/Configuration;)Lw0/e;
    //   25: astore_1
    //   26: new a4/w7
    //   29: dup
    //   30: invokespecial <init> : ()V
    //   33: astore_2
    //   34: iconst_0
    //   35: istore_0
    //   36: iload_0
    //   37: aload_1
    //   38: invokevirtual d : ()I
    //   41: if_icmpge -> 64
    //   44: aload_2
    //   45: aload_1
    //   46: iload_0
    //   47: invokevirtual c : (I)Ljava/util/Locale;
    //   50: invokestatic b : (Ljava/util/Locale;)Ljava/lang/String;
    //   53: invokevirtual c : (Ljava/lang/Object;)La4/w7;
    //   56: pop
    //   57: iload_0
    //   58: iconst_1
    //   59: iadd
    //   60: istore_0
    //   61: goto -> 36
    //   64: aload_2
    //   65: invokevirtual d : ()La4/z7;
    //   68: astore_1
    //   69: aload_1
    //   70: putstatic a4/f7.j : La4/z7;
    //   73: ldc a4/f7
    //   75: monitorexit
    //   76: aload_1
    //   77: areturn
    //   78: astore_1
    //   79: ldc a4/f7
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	78	finally
    //   16	34	78	finally
    //   36	57	78	finally
    //   64	73	78	finally
  }
  
  public final void b(q7 paramq7, y4 paramy4) {
    m4 m4;
    s4 s4;
    String str;
    long l1 = SystemClock.elapsedRealtime();
    if (this.h.get(paramy4) != null && l1 - ((Long)this.h.get(paramy4)).longValue() <= TimeUnit.SECONDS.toMillis(30L))
      return; 
    this.h.put(paramy4, Long.valueOf(l1));
    int i = paramq7.a;
    int j = paramq7.b;
    int k = paramq7.c;
    int m = paramq7.d;
    int i1 = paramq7.e;
    l1 = paramq7.f;
    int i2 = paramq7.g;
    r4 r4 = new r4();
    if (i != -1) {
      if (i != 35) {
        if (i != 842094169) {
          if (i != 16) {
            if (i != 17) {
              m4 = m4.o;
            } else {
              m4 = m4.q;
            } 
          } else {
            m4 = m4.p;
          } 
        } else {
          m4 = m4.r;
        } 
      } else {
        m4 = m4.s;
      } 
    } else {
      m4 = m4.u;
    } 
    r4.d(m4);
    if (j != 1) {
      if (j != 2) {
        if (j != 3) {
          if (j != 4) {
            s4 = s4.t;
          } else {
            s4 = s4.s;
          } 
        } else {
          s4 = s4.r;
        } 
      } else {
        s4 = s4.q;
      } 
    } else {
      s4 = s4.p;
    } 
    r4.f(s4);
    r4.c(Integer.valueOf(k));
    r4.e(Integer.valueOf(m));
    r4.g(Integer.valueOf(i1));
    r4.b(Long.valueOf(l1));
    r4.h(Integer.valueOf(i2));
    t4 t4 = r4.j();
    a5 a5 = new a5();
    a5.d(t4);
    g7 g7 = g7.c(a5);
    if (this.e.o()) {
      str = (String)this.e.k();
    } else {
      str = g.a().b(this.g);
    } 
    g.d().execute(new b7(this, g7, paramy4, str, null));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\f7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */