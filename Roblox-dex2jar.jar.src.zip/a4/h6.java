package a4;

import java.util.NoSuchElementException;

abstract class h6<E> extends c8<E> {
  private final int n;
  
  private int o;
  
  protected h6(int paramInt1, int paramInt2) {
    f4.b(paramInt2, paramInt1, "index");
    this.n = paramInt1;
    this.o = paramInt2;
  }
  
  protected abstract E a(int paramInt);
  
  public final boolean hasNext() {
    return (this.o < this.n);
  }
  
  public final boolean hasPrevious() {
    return (this.o > 0);
  }
  
  public final E next() {
    if (hasNext()) {
      int i = this.o;
      this.o = i + 1;
      return a(i);
    } 
    throw new NoSuchElementException();
  }
  
  public final int nextIndex() {
    return this.o;
  }
  
  public final E previous() {
    if (hasPrevious()) {
      int i = this.o - 1;
      this.o = i;
      return a(i);
    } 
    throw new NoSuchElementException();
  }
  
  public final int previousIndex() {
    return this.o - 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\h6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */