package a4;

public abstract class y6 {
  public abstract y6 a(boolean paramBoolean);
  
  public abstract y6 b(int paramInt);
  
  public abstract z6 c();
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\y6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */