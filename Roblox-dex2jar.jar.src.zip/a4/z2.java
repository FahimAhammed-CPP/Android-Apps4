package a4;

import i5.c;
import i5.d;
import java.io.IOException;

final class z2 implements d<x5> {
  static final z2 a = new z2();
  
  private static final c b;
  
  private static final c c;
  
  private static final c d;
  
  private static final c e;
  
  private static final c f;
  
  private static final c g;
  
  static {
    c.b b = c.a("detectorMode");
    e8 e8 = new e8();
    e8.a(1);
    b = b.b(e8.b()).a();
    b = c.a("multipleObjectsEnabled");
    e8 = new e8();
    e8.a(2);
    c = b.b(e8.b()).a();
    b = c.a("classificationEnabled");
    e8 = new e8();
    e8.a(3);
    d = b.b(e8.b()).a();
    b = c.a("maxPerObjectLabelCount");
    e8 = new e8();
    e8.a(4);
    e = b.b(e8.b()).a();
    b = c.a("classificationConfidenceThreshold");
    e8 = new e8();
    e8.a(5);
    f = b.b(e8.b()).a();
    b = c.a("customLocalModelOptions");
    e8 = new e8();
    e8.a(6);
    g = b.b(e8.b()).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a4\z2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */