package a0;

import android.media.Image;
import android.media.ImageWriter;
import android.os.Build;
import android.view.Surface;

public final class a {
  public static void a(ImageWriter paramImageWriter) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      b.a(paramImageWriter);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to call close() on API ");
    stringBuilder.append(i);
    stringBuilder.append(". Version 23 or higher required.");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public static Image b(ImageWriter paramImageWriter) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
      return b.b(paramImageWriter); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to call dequeueInputImage() on API ");
    stringBuilder.append(i);
    stringBuilder.append(". Version 23 or higher required.");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public static ImageWriter c(Surface paramSurface, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
      return b.c(paramSurface, paramInt); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to call newInstance(Surface, int) on API ");
    stringBuilder.append(i);
    stringBuilder.append(". Version 23 or higher required.");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public static ImageWriter d(Surface paramSurface, int paramInt1, int paramInt2) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29)
      return d.a(paramSurface, paramInt1, paramInt2); 
    if (i >= 26)
      return c.a(paramSurface, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to call newInstance(Surface, int, int) on API ");
    stringBuilder.append(i);
    stringBuilder.append(". Version 26 or higher required.");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public static void e(ImageWriter paramImageWriter, Image paramImage) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      b.d(paramImageWriter, paramImage);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unable to call queueInputImage() on API ");
    stringBuilder.append(i);
    stringBuilder.append(". Version 23 or higher required.");
    throw new RuntimeException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */