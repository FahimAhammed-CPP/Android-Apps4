package a0;

import android.media.ImageWriter;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import z0.h;

final class c {
  private static Method a;
  
  static {
    try {
      Class<int> clazz = int.class;
      a = ImageWriter.class.getMethod("newInstance", new Class[] { Surface.class, clazz, clazz });
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("ImageWriterCompatApi26", "Unable to initialize via reflection.", noSuchMethodException);
      return;
    } 
  }
  
  static ImageWriter a(Surface paramSurface, int paramInt1, int paramInt2) {
    int i = Build.VERSION.SDK_INT;
    InvocationTargetException invocationTargetException = null;
    if (i >= 26) {
      try {
        return (ImageWriter)h.f(a.invoke(null, new Object[] { paramSurface, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InvocationTargetException invocationTargetException1) {}
      invocationTargetException = invocationTargetException1;
    } 
    throw new RuntimeException("Unable to invoke newInstance(Surface, int, int) via reflection.", invocationTargetException);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */