package a0;

import android.media.Image;
import android.media.ImageWriter;
import android.view.Surface;

final class b {
  static void a(ImageWriter paramImageWriter) {
    paramImageWriter.close();
  }
  
  static Image b(ImageWriter paramImageWriter) {
    return paramImageWriter.dequeueInputImage();
  }
  
  static ImageWriter c(Surface paramSurface, int paramInt) {
    return ImageWriter.newInstance(paramSurface, paramInt);
  }
  
  static void d(ImageWriter paramImageWriter, Image paramImage) {
    paramImageWriter.queueInputImage(paramImage);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */