package a7;

import z6.d;
import z6.e;

public final class a extends d implements e {
  private final z6.a.b A;
  
  private final z6.a.f A0;
  
  private final z6.a.b A1;
  
  private final z6.a.f B;
  
  private final z6.a.f B0;
  
  private final z6.a.b B1;
  
  private final z6.a.f C;
  
  private final z6.a.b C0;
  
  private final z6.a.b C1;
  
  private final z6.a.c D;
  
  private final z6.a.b D0;
  
  private final z6.a.b D1;
  
  private final z6.a.c E;
  
  private final z6.a.b E0;
  
  private final z6.a.b E1;
  
  private final z6.a.c F;
  
  private final z6.a.b F0;
  
  private final z6.a.b F1;
  
  private final z6.a.f G;
  
  private final z6.a.b G0;
  
  private final z6.a.b G1;
  
  private final z6.a.f H;
  
  private final z6.a.d H0;
  
  private final z6.a.b H1;
  
  private final z6.a.c I;
  
  private final z6.a.b I0;
  
  private final z6.a.b I1;
  
  private final z6.a.f J;
  
  private final z6.a.b J0;
  
  private final z6.a.b J1;
  
  private final z6.a.f K;
  
  private final z6.a.b K0;
  
  private final z6.a.b K1;
  
  private final z6.a.c L;
  
  private final z6.a.b L0;
  
  private final z6.a.b L1;
  
  private final z6.a.c M;
  
  private final z6.a.b M0;
  
  private final z6.a.f M1;
  
  private final z6.a.b N;
  
  private final z6.a.b N0;
  
  private final z6.a.b N1;
  
  private final z6.a.c O;
  
  private final z6.a.c O0;
  
  private final z6.a.b O1;
  
  private final z6.a.f P;
  
  private final z6.a.b P0;
  
  private final z6.a.b P1;
  
  private final z6.a.c Q;
  
  private final z6.a.b Q0;
  
  private final z6.a.b Q1;
  
  private final z6.a.f R;
  
  private final z6.a.c R0;
  
  private final z6.a.b R1;
  
  private final z6.a.c S;
  
  private final z6.a.b S0;
  
  private final z6.a.b S1;
  
  private final z6.a.c T;
  
  private final z6.a.b T0;
  
  private final z6.a.b T1;
  
  private final z6.a.b U;
  
  private final z6.a.b U0;
  
  private final z6.a.b V;
  
  private final z6.a.b V0;
  
  private final z6.a.b W;
  
  private final z6.a.b W0;
  
  private final z6.a.b X;
  
  private final z6.a.b X0;
  
  private final z6.a.d Y;
  
  private final z6.a.b Y0;
  
  private final z6.a.b Z;
  
  private final z6.a.b Z0;
  
  private final z6.a.b a0;
  
  private final z6.a.b a1;
  
  private final z6.a.c b;
  
  private final z6.a.f b0;
  
  private final z6.a.b b1;
  
  private final z6.a.f c;
  
  private final z6.a.b c0;
  
  private final z6.a.b c1;
  
  private final z6.a.c d;
  
  private final z6.a.b d0;
  
  private final z6.a.b d1;
  
  private final z6.a.c e;
  
  private final z6.a.b e0;
  
  private final z6.a.b e1;
  
  private final z6.a.f f;
  
  private final z6.a.f f0;
  
  private final z6.a.b f1;
  
  private final z6.a.f g;
  
  private final z6.a.f g0;
  
  private final z6.a.b g1;
  
  private final z6.a.f h;
  
  private final z6.a.f h0;
  
  private final z6.a.b h1;
  
  private final z6.a.f i;
  
  private final z6.a.f i0;
  
  private final z6.a.b i1;
  
  private final z6.a.f j;
  
  private final z6.a.c j0;
  
  private final z6.a.b j1;
  
  private final z6.a.f k;
  
  private final z6.a.d k0;
  
  private final z6.a.d k1;
  
  private final z6.a.f l;
  
  private final z6.a.c l0;
  
  private final z6.a.b l1;
  
  private final z6.a.c m;
  
  private final z6.a.c m0;
  
  private final z6.a.b m1;
  
  private final z6.a.d n;
  
  private final z6.a.b n0;
  
  private final z6.a.f n1;
  
  private final z6.a.f o;
  
  private final z6.a.d o0;
  
  private final z6.a.b o1;
  
  private final z6.a.b p;
  
  private final z6.a.f p0;
  
  private final z6.a.b p1;
  
  private final z6.a.c q;
  
  private final z6.a.f q0;
  
  private final z6.a.b q1;
  
  private final z6.a.c r;
  
  private final z6.a.f r0;
  
  private final z6.a.b r1;
  
  private final z6.a.c s;
  
  private final z6.a.b s0;
  
  private final z6.a.b s1;
  
  private final z6.a.c t;
  
  private final z6.a.f t0;
  
  private final z6.a.b t1;
  
  private final z6.a.c u;
  
  private final z6.a.b u0;
  
  private final z6.a.c u1;
  
  private final z6.a.c v;
  
  private final z6.a.b v0;
  
  private final z6.a.b v1;
  
  private final z6.a.c w;
  
  private final z6.a.b w0;
  
  private final z6.a.b w1;
  
  private final z6.a.d x;
  
  private final z6.a.b x0;
  
  private final z6.a.b x1;
  
  private final z6.a.c y;
  
  private final z6.a.b y0;
  
  private final z6.a.b y1;
  
  private final z6.a.c z;
  
  private final z6.a.f z0;
  
  private final z6.a.b z1;
  
  public a() {
    Integer integer3 = Integer.valueOf(10);
    Integer integer1 = Integer.valueOf(0);
    z6.a.c c5 = new z6.a.c("InfluxThrottleRate", integer3, false);
    this.b = c5;
    n1("InfluxThrottleRate", (z6.a)c5);
    z6.a.f f3 = new z6.a.f("InfluxTcpHost", "ec2-54-165-151-168.compute-1.amazonaws.com", false);
    this.c = f3;
    n1("InfluxTcpHost", (z6.a)f3);
    z6.a.c c4 = new z6.a.c("InfluxTcpPort", Integer.valueOf(8094), false);
    this.d = c4;
    n1("InfluxTcpPort", (z6.a)c4);
    c4 = new z6.a.c("InfluxTcpTimeToLiveInSeconds", integer3, false);
    this.e = c4;
    n1("InfluxTcpTimeToLiveInSeconds", (z6.a)c4);
    z6.a.f f2 = new z6.a.f("SignalRPath", "notifications", false);
    this.f = f2;
    n1("SignalRPath", (z6.a)f2);
    f2 = new z6.a.f("SignalRSubdomain", "realtime", false);
    this.g = f2;
    n1("SignalRSubdomain", (z6.a)f2);
    f2 = new z6.a.f("SignalRUrl", null, false);
    this.h = f2;
    n1("SignalRUrl", (z6.a)f2);
    f2 = new z6.a.f("RobloxUrlsPattern", "(https?\\:\\/\\/)?(?:www\\.)?([a-z0-9\\-]{2,}\\.)*(((m|de|www|web|api|blog|wiki|help|corp|polls|bloxcon|developer|devforum|forum)\\.roblox\\.com|robloxlabs\\.com)|(www\\.shoproblox\\.com))((\\/[A-Za-z0-9-+&amp;@#\\/%?=~_|!:,.;]*)|(\\b|\\s))", false);
    this.i = f2;
    n1("RobloxUrlsPattern", (z6.a)f2);
    f2 = new z6.a.f("NotificationStreamPath", "notificationstream/embedded", false);
    this.j = f2;
    n1("NotificationStreamPath", (z6.a)f2);
    f2 = new z6.a.f("VisibleAgeStyleNativeShell", "all", false);
    this.k = f2;
    n1("VisibleAgeStyleNativeShell", (z6.a)f2);
    f2 = new z6.a.f("VisibleAgeStyleLuaApp", "all", false);
    this.l = f2;
    n1("VisibleAgeStyleLuaApp", (z6.a)f2);
    Integer integer2 = Integer.valueOf(5);
    z6.a.c c6 = new z6.a.c("NumberOfFailedLoginsBeforeResetPasswordMessage", integer2, false);
    this.m = c6;
    n1("NumberOfFailedLoginsBeforeResetPasswordMessage", (z6.a)c6);
    z6.a.d d2 = new z6.a.d("CatalogPromoAssetId", Long.valueOf(-1L), false);
    this.n = d2;
    n1("CatalogPromoAssetId", (z6.a)d2);
    z6.a.f f4 = new z6.a.f("CatalogPromoAssetLocalizationJson", null, false);
    this.o = f4;
    n1("CatalogPromoAssetLocalizationJson", (z6.a)f4);
    Boolean bool2 = Boolean.TRUE;
    z6.a.b b12 = new z6.a.b("AppRatingsEnabled", bool2, false);
    this.p = b12;
    n1("AppRatingsEnabled", (z6.a)b12);
    z6.a.c c10 = new z6.a.c("AppRatingsPlayTimeInMinutes", integer3, false);
    this.q = c10;
    n1("AppRatingsPlayTimeInMinutes", (z6.a)c10);
    Integer integer4 = Integer.valueOf(1);
    z6.a.c c18 = new z6.a.c("AppRatingsNumberOfFriendsForLaunch", integer4, false);
    this.r = c18;
    n1("AppRatingsNumberOfFriendsForLaunch", (z6.a)c18);
    c18 = new z6.a.c("AppRatingsLaunchCount", Integer.valueOf(3), false);
    this.s = c18;
    n1("AppRatingsLaunchCount", (z6.a)c18);
    z6.a.c c3 = new z6.a.c("AppRatingsDaysSinceFirstUse", integer2, false);
    this.t = c3;
    n1("AppRatingsDaysSinceFirstUse", (z6.a)c3);
    c3 = new z6.a.c("AppRatingsLaunchesUntilReminder", Integer.valueOf(4), false);
    this.u = c3;
    n1("AppRatingsLaunchesUntilReminder", (z6.a)c3);
    c3 = new z6.a.c("AppRatingsDaysUntilReminder", Integer.valueOf(6), false);
    this.v = c3;
    n1("AppRatingsDaysUntilReminder", (z6.a)c3);
    c3 = new z6.a.c("AppRatingsGamesPlayed", Integer.valueOf(7), false);
    this.w = c3;
    n1("AppRatingsGamesPlayed", (z6.a)c3);
    z6.a.d d1 = new z6.a.d("TimeBeforeWebViewRefreshInMs", Long.valueOf(180000L), false);
    this.x = d1;
    n1("TimeBeforeWebViewRefreshInMs", (z6.a)d1);
    z6.a.c c2 = new z6.a.c("EventStreamBatchSize", integer3, false);
    this.y = c2;
    n1("EventStreamBatchSize", (z6.a)c2);
    c2 = new z6.a.c("EventStreamBatchTimeInSecs", Integer.valueOf(60), false);
    this.z = c2;
    n1("EventStreamBatchTimeInSecs", (z6.a)c2);
    Boolean bool1 = Boolean.FALSE;
    z6.a.b b17 = new z6.a.b("EnableMarshallerAsync", bool1, false);
    this.A = b17;
    n1("EnableMarshallerAsync", (z6.a)b17);
    z6.a.f f15 = new z6.a.f("ReminderNotifTextWithUsernameFormat", "%1$s, play the most popular games on Roblox now!", false);
    this.B = f15;
    n1("ReminderNotifTextWithUsernameFormat", (z6.a)f15);
    f15 = new z6.a.f("ReminderNotifShortTextWithUsernameFormat", "%1$s, check out these top games!", false);
    this.C = f15;
    n1("ReminderNotifShortTextWithUsernameFormat", (z6.a)f15);
    z6.a.c c17 = new z6.a.c("LowDpiScalingThreshold", Integer.valueOf(320), false);
    this.D = c17;
    n1("LowDpiScalingThreshold", (z6.a)c17);
    c17 = new z6.a.c("MinFunCaptchaWidthInPx", Integer.valueOf(400), false);
    this.E = c17;
    n1("MinFunCaptchaWidthInPx", (z6.a)c17);
    c17 = new z6.a.c("MinFunCaptchaHeightInPx", Integer.valueOf(500), false);
    this.F = c17;
    n1("MinFunCaptchaHeightInPx", (z6.a)c17);
    z6.a.f f14 = new z6.a.f("CrashpadUploadToBacktraceUrl", "https://upload.crashes.rbxinfra.com/post", false);
    this.G = f14;
    n1("CrashpadUploadToBacktraceUrl", (z6.a)f14);
    f14 = new z6.a.f("CrashpadUploadToBacktraceAndroidPlayerToken", "3fd27180e359d21ab86e48526adecaf75bfb062c138eb23e847ef1ed906f9aaf", false);
    this.H = f14;
    n1("CrashpadUploadToBacktraceAndroidPlayerToken", (z6.a)f14);
    z6.a.c c16 = new z6.a.c("JavaCrashUploadToBacktracePercentage", integer3, false);
    this.I = c16;
    n1("JavaCrashUploadToBacktracePercentage", (z6.a)c16);
    z6.a.f f13 = new z6.a.f("JavaCrashUploadToBacktraceUrl", "https://upload.crashes.rbxinfra.com/post", false);
    this.J = f13;
    n1("JavaCrashUploadToBacktraceUrl", (z6.a)f13);
    f13 = new z6.a.f("JavaCrashUploadToBacktraceToken", "1d680abdb860308199d85e6e5b570e6990f0693c3f3a3628905f9157318fa0ea", false);
    this.K = f13;
    n1("JavaCrashUploadToBacktraceToken", (z6.a)f13);
    z6.a.c c15 = new z6.a.c("JavaANRUploadToBacktracePercentage", integer3, false);
    this.L = c15;
    n1("JavaANRUploadToBacktracePercentage", (z6.a)c15);
    c15 = new z6.a.c("JavaANRMaximumTimeout", Integer.valueOf(5000), false);
    this.M = c15;
    n1("JavaANRMaximumTimeout", (z6.a)c15);
    z6.a.b b16 = new z6.a.b("EnableJavaCrashDeobfuscateSupport", bool1, false);
    this.N = b16;
    n1("EnableJavaCrashDeobfuscateSupport", (z6.a)b16);
    z6.a.c c14 = new z6.a.c("PercentReportingByCountryCode", integer1, false);
    this.O = c14;
    n1("PercentReportingByCountryCode", (z6.a)c14);
    z6.a.f f12 = new z6.a.f("DeprecationNoticeDeadline", "", false);
    this.P = f12;
    n1("DeprecationNoticeDeadline", (z6.a)f12);
    z6.a.c c13 = new z6.a.c("MinSupportedAPILevel", integer1, false);
    this.Q = c13;
    n1("MinSupportedAPILevel", (z6.a)c13);
    z6.a.f f11 = new z6.a.f("MinSupportedOSVersion", "", false);
    this.R = f11;
    n1("MinSupportedOSVersion", (z6.a)f11);
    z6.a.c c12 = new z6.a.c("DefaultTapFilterLevel", integer1, false);
    this.S = c12;
    n1("DefaultTapFilterLevel", (z6.a)c12);
    c12 = new z6.a.c("SettingsValidIntervalInSecs", Integer.valueOf(864000), false);
    this.T = c12;
    n1("SettingsValidIntervalInSecs", (z6.a)c12);
    z6.a.b b15 = new z6.a.b("EnableSessionCheckAlwaysInMain", bool1, false);
    this.U = b15;
    n1("EnableSessionCheckAlwaysInMain", (z6.a)b15);
    b15 = new z6.a.b("EnableTencentLinkingFeature", bool2, false);
    this.V = b15;
    n1("EnableTencentLinkingFeature", (z6.a)b15);
    b15 = new z6.a.b("DisableLoadingOfRobuxUrlForTencentBuild", bool2, false);
    this.W = b15;
    n1("DisableLoadingOfRobuxUrlForTencentBuild", (z6.a)b15);
    b15 = new z6.a.b("EnableLoginApiMigration", bool1, false);
    this.X = b15;
    n1("EnableLoginApiMigration", (z6.a)b15);
    z6.a.d d7 = new z6.a.d("EnableGameOrientationWithDelayInMs", Long.valueOf(0L), false);
    this.Y = d7;
    n1("EnableGameOrientationWithDelayInMs", (z6.a)d7);
    z6.a.b b14 = new z6.a.b("EnableTencentWebHelpPage", bool1, false);
    this.Z = b14;
    n1("EnableTencentWebHelpPage", (z6.a)b14);
    b14 = new z6.a.b("EnableTencentMSDKNotice", bool1, false);
    this.a0 = b14;
    n1("EnableTencentMSDKNotice", (z6.a)b14);
    z6.a.f f10 = new z6.a.f("TencentMSDKNoticeActivityPath", "/act", false);
    this.b0 = f10;
    n1("TencentMSDKNoticeActivityPath", (z6.a)f10);
    z6.a.b b13 = new z6.a.b("EnableFetchAgreementRetryOnLogin", bool1, false);
    this.c0 = b13;
    n1("EnableFetchAgreementRetryOnLogin", (z6.a)b13);
    b13 = new z6.a.b("EnableAgreementIdReuseOnSignUp", bool1, false);
    this.d0 = b13;
    n1("EnableAgreementIdReuseOnSignUp", (z6.a)b13);
    b13 = new z6.a.b("EnableAppsFlyerFacebookTracking", bool1, false);
    this.e0 = b13;
    n1("EnableAppsFlyerFacebookTracking", (z6.a)b13);
    z6.a.f f9 = new z6.a.f("DefaultLuobuShareThumbnailsSize", "150x150", false);
    this.f0 = f9;
    n1("DefaultLuobuShareThumbnailsSize", (z6.a)f9);
    f9 = new z6.a.f("DefaultLuobuShareThumbnailsFormat", "Png", false);
    this.g0 = f9;
    n1("DefaultLuobuShareThumbnailsFormat", (z6.a)f9);
    f9 = new z6.a.f("DefaultLuobuHelpCenterThumbnailsSize", "75x75", false);
    this.h0 = f9;
    n1("DefaultLuobuHelpCenterThumbnailsSize", (z6.a)f9);
    f9 = new z6.a.f("DefaultLuobuHelpCenterThumbnailsFormat", "png", false);
    this.i0 = f9;
    n1("DefaultLuobuHelpCenterThumbnailsFormat", (z6.a)f9);
    z6.a.c c11 = new z6.a.c("LuobuShareThumbnailsRetryNumber", Integer.valueOf(3), false);
    this.j0 = c11;
    n1("LuobuShareThumbnailsRetryNumber", (z6.a)c11);
    z6.a.d d6 = new z6.a.d("RetryIntervalMs", Long.valueOf(500L), false);
    this.k0 = d6;
    n1("RetryIntervalMs", (z6.a)d6);
    z6.a.c c9 = new z6.a.c("LuobuThumbnailRetryBackoffMultiplier", integer4, false);
    this.l0 = c9;
    n1("LuobuThumbnailRetryBackoffMultiplier", (z6.a)c9);
    c9 = new z6.a.c("LuobuShareThumbnailsRetryTimeoutMs", Integer.valueOf(5000), false);
    this.m0 = c9;
    n1("LuobuShareThumbnailsRetryTimeoutMs", (z6.a)c9);
    z6.a.b b11 = new z6.a.b("TestCJVPayAPI", bool1, false);
    this.n0 = b11;
    n1("TestCJVPayAPI", (z6.a)b11);
    z6.a.d d5 = new z6.a.d("NativeTextBoxOpenUpdateWaitTimeMs", Long.valueOf(200L), false);
    this.o0 = d5;
    n1("NativeTextBoxOpenUpdateWaitTimeMs", (z6.a)d5);
    z6.a.f f8 = new z6.a.f("CustomLuobuCorpUrl", "https://roblox.qq.com/?webview=true0409", false);
    this.p0 = f8;
    n1("CustomLuobuCorpUrl", (z6.a)f8);
    f8 = new z6.a.f("ChannelIdsEnabledForStructureShare", "", false);
    this.q0 = f8;
    n1("ChannelIdsEnabledForStructureShare", (z6.a)f8);
    f8 = new z6.a.f("LuobuShareUrl", "https://luobu.qq.com/fx/a20210622fxy/index.html", false);
    this.r0 = f8;
    n1("LuobuShareUrl", (z6.a)f8);
    z6.a.b b10 = new z6.a.b("EnableLuobuSignupCheck", bool1, false);
    this.s0 = b10;
    n1("EnableLuobuSignupCheck", (z6.a)b10);
    z6.a.f f7 = new z6.a.f("LuobuAgeRatingInstructionUrl", "https://roblox.qq.com/m/m202106/newsDetail.html?newsid=14640697", false);
    this.t0 = f7;
    n1("LuobuAgeRatingInstructionUrl", (z6.a)f7);
    z6.a.b b9 = new z6.a.b("FFlagShouldDisableAdIds", bool1, false);
    this.u0 = b9;
    n1("FFlagShouldDisableAdIds", (z6.a)b9);
    b9 = new z6.a.b("FFlagDisableLuobuAutoLoginCheckImprovement2", bool1, false);
    this.v0 = b9;
    n1("FFlagDisableLuobuAutoLoginCheckImprovement2", (z6.a)b9);
    b9 = new z6.a.b("FFlagDisableLuobuTDMReport", bool1, false);
    this.w0 = b9;
    n1("FFlagDisableLuobuTDMReport", (z6.a)b9);
    b9 = new z6.a.b("FFlagShouldHandleNotificationSettingChanged", bool1, false);
    this.x0 = b9;
    n1("FFlagShouldHandleNotificationSettingChanged", (z6.a)b9);
    b9 = new z6.a.b("EnabledLuobuSignupSuspensionNotice", bool1, false);
    this.y0 = b9;
    n1("EnabledLuobuSignupSuspensionNotice", (z6.a)b9);
    z6.a.f f6 = new z6.a.f("LuobuSignupSuspensionNoticeUrl", "https://roblox.qq.com/m/m202106/newsDetail.html?newsid=15196933", false);
    this.z0 = f6;
    n1("LuobuSignupSuspensionNoticeUrl", (z6.a)f6);
    f6 = new z6.a.f("AndroidIAPList", "", false);
    this.A0 = f6;
    n1("AndroidIAPList", (z6.a)f6);
    f6 = new z6.a.f("AndroidIAPSubList", "", false);
    this.B0 = f6;
    n1("AndroidIAPSubList", (z6.a)f6);
    z6.a.b b8 = new z6.a.b("PreventDismissingForceUpgrade", bool1, false);
    this.C0 = b8;
    n1("PreventDismissingForceUpgrade", (z6.a)b8);
    b8 = new z6.a.b("FFlagRenameGameJoinFlow", bool1, false);
    this.D0 = b8;
    n1("FFlagRenameGameJoinFlow", (z6.a)b8);
    b8 = new z6.a.b("EnableBackgroundExperiment", bool1, false);
    this.E0 = b8;
    n1("EnableBackgroundExperiment", (z6.a)b8);
    b8 = new z6.a.b("EnableReadFromExternalSettingsFile", bool1, false);
    this.F0 = b8;
    n1("EnableReadFromExternalSettingsFile", (z6.a)b8);
    b8 = new z6.a.b("GrantPendingPurchaseIntervalEnabled", bool1, false);
    this.G0 = b8;
    n1("GrantPendingPurchaseIntervalEnabled", (z6.a)b8);
    z6.a.d d4 = new z6.a.d("GrantPendingPurchaseInterval", Long.valueOf(10L), false);
    this.H0 = d4;
    n1("GrantPendingPurchaseInterval", (z6.a)d4);
    z6.a.b b7 = new z6.a.b("ByPassUsernamePurchases", bool1, false);
    this.I0 = b7;
    n1("ByPassUsernamePurchases", (z6.a)b7);
    b7 = new z6.a.b("NativePurchaseWithUserId", bool1, false);
    this.J0 = b7;
    n1("NativePurchaseWithUserId", (z6.a)b7);
    b7 = new z6.a.b("NativePurchaseWithPayload", bool1, false);
    this.K0 = b7;
    n1("NativePurchaseWithPayload", (z6.a)b7);
    b7 = new z6.a.b("EnableMaquettesEnterDetection", bool1, false);
    this.L0 = b7;
    n1("EnableMaquettesEnterDetection", (z6.a)b7);
    b7 = new z6.a.b("FFlagGetApplicationExitReasonForAndroid", bool1, false);
    this.M0 = b7;
    n1("FFlagGetApplicationExitReasonForAndroid", (z6.a)b7);
    b7 = new z6.a.b("FFlagGetLowMemoryThresholdsForAndroid", bool1, false);
    this.N0 = b7;
    n1("FFlagGetLowMemoryThresholdsForAndroid", (z6.a)b7);
    z6.a.c c8 = new z6.a.c("MemoryInfoThresholdsMaxAndroidVersionAllowed", Integer.valueOf(33), false);
    this.O0 = c8;
    n1("MemoryInfoThresholdsMaxAndroidVersionAllowed", (z6.a)c8);
    z6.a.b b6 = new z6.a.b("EnableNewCoexperienceTelemetryAndroidV2", bool1, false);
    this.P0 = b6;
    n1("EnableNewCoexperienceTelemetryAndroidV2", (z6.a)b6);
    b6 = new z6.a.b("FFlagLuaExpLaunchFlowBegin", bool1, false);
    this.Q0 = b6;
    n1("FFlagLuaExpLaunchFlowBegin", (z6.a)b6);
    z6.a.c c7 = new z6.a.c("AndroidApplicationExitReasonNumEntriesToFetch", integer3, false);
    this.R0 = c7;
    n1("AndroidApplicationExitReasonNumEntriesToFetch", (z6.a)c7);
    z6.a.b b5 = new z6.a.b("UseWindowInsetsForWebView", bool1, false);
    this.S0 = b5;
    n1("UseWindowInsetsForWebView", (z6.a)b5);
    b5 = new z6.a.b("UseBrowserForYoutubeOnMaquettes", bool1, false);
    this.T0 = b5;
    n1("UseBrowserForYoutubeOnMaquettes", (z6.a)b5);
    b5 = new z6.a.b("AndroidSendCurrentOrientationAfterSoftwareInitiatedRotation", bool1, false);
    this.U0 = b5;
    n1("AndroidSendCurrentOrientationAfterSoftwareInitiatedRotation", (z6.a)b5);
    b5 = new z6.a.b("AndroidAudioManagerFixSpeakerBTLeak", bool1, false);
    this.V0 = b5;
    n1("AndroidAudioManagerFixSpeakerBTLeak", (z6.a)b5);
    b5 = new z6.a.b("AndroidNotchScreenSupportIXPExperiment", bool1, false);
    this.W0 = b5;
    n1("AndroidNotchScreenSupportIXPExperiment", (z6.a)b5);
    b5 = new z6.a.b("RemoveFriendshipSignalRReceiver", bool1, false);
    this.X0 = b5;
    n1("RemoveFriendshipSignalRReceiver", (z6.a)b5);
    b5 = new z6.a.b("AndroidANRChannels", bool1, false);
    this.Y0 = b5;
    n1("AndroidANRChannels", (z6.a)b5);
    b5 = new z6.a.b("AccessCookiesWithUrlAndroidEnabled", bool1, false);
    this.Z0 = b5;
    n1("AccessCookiesWithUrlAndroidEnabled", (z6.a)b5);
    b5 = new z6.a.b("EnableIrisGameJoinAndroid2", bool1, false);
    this.a1 = b5;
    n1("EnableIrisGameJoinAndroid2", (z6.a)b5);
    b5 = new z6.a.b("EnableCallNotificationHandler4", bool1, true);
    this.b1 = b5;
    n1("EnableCallNotificationHandler4", (z6.a)b5);
    b5 = new z6.a.b("DisablePauseSessionInCall2", bool1, false);
    this.c1 = b5;
    n1("DisablePauseSessionInCall2", (z6.a)b5);
    b5 = new z6.a.b("EnableSendrChatNotificationReply", bool1, true);
    this.d1 = b5;
    n1("EnableSendrChatNotificationReply", (z6.a)b5);
    b5 = new z6.a.b("EnableFlagRefactorStage3Dev", bool1, true);
    this.e1 = b5;
    n1("EnableFlagRefactorStage3Dev", (z6.a)b5);
    b5 = new z6.a.b("AndroidStartExperimentProtocolListeningAtStartup", bool1, false);
    this.f1 = b5;
    n1("AndroidStartExperimentProtocolListeningAtStartup", (z6.a)b5);
    b5 = new z6.a.b("ExperienceLaunchSingleSurface", bool1, false);
    this.g1 = b5;
    n1("ExperienceLaunchSingleSurface", (z6.a)b5);
    b5 = new z6.a.b("FixNullptrListener", bool1, true);
    this.h1 = b5;
    n1("FixNullptrListener", (z6.a)b5);
    b5 = new z6.a.b("MoveInputStatusUpdate", bool1, false);
    this.i1 = b5;
    n1("MoveInputStatusUpdate", (z6.a)b5);
    b5 = new z6.a.b("MoveInputStatusUpdateAsyncStrategy", bool1, false);
    this.j1 = b5;
    n1("MoveInputStatusUpdateAsyncStrategy", (z6.a)b5);
    z6.a.d d3 = new z6.a.d("MaquettesEditorActionBlackOutDurationInMillis", Long.valueOf(700L), false);
    this.k1 = d3;
    n1("MaquettesEditorActionBlackOutDurationInMillis", (z6.a)d3);
    z6.a.b b4 = new z6.a.b("EnableMaquettesKeyboardHeuristicFix", bool1, false);
    this.l1 = b4;
    n1("EnableMaquettesKeyboardHeuristicFix", (z6.a)b4);
    b4 = new z6.a.b("EnableDynamicBacktraceLogSize", bool1, false);
    this.m1 = b4;
    n1("EnableDynamicBacktraceLogSize", (z6.a)b4);
    z6.a.f f5 = new z6.a.f("BacktraceLogSize", "200", false);
    this.n1 = f5;
    n1("BacktraceLogSize", (z6.a)f5);
    z6.a.b b3 = new z6.a.b("EnableAndroidAutofillPhoneNumber", bool1, true);
    this.o1 = b3;
    n1("EnableAndroidAutofillPhoneNumber", (z6.a)b3);
    b3 = new z6.a.b("EnableSdk33PostNotifications", bool1, true);
    this.p1 = b3;
    n1("EnableSdk33PostNotifications", (z6.a)b3);
    b3 = new z6.a.b("EnableAndroidAutofillSMSOTP", bool1, true);
    this.q1 = b3;
    n1("EnableAndroidAutofillSMSOTP", (z6.a)b3);
    b3 = new z6.a.b("SingleSurfaceEnabledAndroid3", bool2, true);
    this.r1 = b3;
    n1("SingleSurfaceEnabledAndroid3", (z6.a)b3);
    b3 = new z6.a.b("AndroidFixSingleSurfaceAppNotchScreenSupportDisabled", bool1, false);
    this.s1 = b3;
    n1("AndroidFixSingleSurfaceAppNotchScreenSupportDisabled", (z6.a)b3);
    b3 = new z6.a.b("EnableAndroidRealtimeProtocolCheckV599", bool1, false);
    this.t1 = b3;
    n1("EnableAndroidRealtimeProtocolCheckV599", (z6.a)b3);
    z6.a.c c1 = new z6.a.c("EnableAndroidRealtimeProtocolHundredthPercentV599", integer1, false);
    this.u1 = c1;
    n1("EnableAndroidRealtimeProtocolHundredthPercentV599", (z6.a)c1);
    z6.a.b b2 = new z6.a.b("EnableAndroidRealtimeProtocolForAllV599", bool1, true);
    this.v1 = b2;
    n1("EnableAndroidRealtimeProtocolForAllV599", (z6.a)b2);
    b2 = new z6.a.b("RemoveUserThemeSignalRReceiver", bool1, false);
    this.w1 = b2;
    n1("RemoveUserThemeSignalRReceiver", (z6.a)b2);
    b2 = new z6.a.b("EnableAccessibilitySettingsEffectsAndroidWebView", bool1, false);
    this.x1 = b2;
    n1("EnableAccessibilitySettingsEffectsAndroidWebView", (z6.a)b2);
    b2 = new z6.a.b("EnablePushNotificationsPromptAndroid13", bool1, true);
    this.y1 = b2;
    n1("EnablePushNotificationsPromptAndroid13", (z6.a)b2);
    b2 = new z6.a.b("EnablePushNotificationSessionUtilsAndroid", bool1, true);
    this.z1 = b2;
    n1("EnablePushNotificationSessionUtilsAndroid", (z6.a)b2);
    b2 = new z6.a.b("DeregisterDisabledDeviceWhenNotificationReceived", bool1, true);
    this.A1 = b2;
    n1("DeregisterDisabledDeviceWhenNotificationReceived", (z6.a)b2);
    b2 = new z6.a.b("VersionSupportForMaquettes", bool1, true);
    this.B1 = b2;
    n1("VersionSupportForMaquettes", (z6.a)b2);
    b2 = new z6.a.b("EnableMaquettesForceKill", bool1, false);
    this.C1 = b2;
    n1("EnableMaquettesForceKill", (z6.a)b2);
    b2 = new z6.a.b("EnableDOMStorageForAngularWebviewCapabilitiy", bool1, false);
    this.D1 = b2;
    n1("EnableDOMStorageForAngularWebviewCapabilitiy", (z6.a)b2);
    b2 = new z6.a.b("FFlagEngineFlagsListeners", bool1, true);
    this.E1 = b2;
    n1("FFlagEngineFlagsListeners", (z6.a)b2);
    b2 = new z6.a.b("EnableBetterGranularityForAndroidExitReason", bool1, true);
    this.F1 = b2;
    n1("EnableBetterGranularityForAndroidExitReason", (z6.a)b2);
    b2 = new z6.a.b("RemoveProcessDeathFixInferredCrashTeardown", bool2, true);
    this.G1 = b2;
    n1("RemoveProcessDeathFixInferredCrashTeardown", (z6.a)b2);
    b2 = new z6.a.b("RefactorAndroidApplicationExitInfoParsing", bool1, true);
    this.H1 = b2;
    n1("RefactorAndroidApplicationExitInfoParsing", (z6.a)b2);
    b2 = new z6.a.b("FixInExperienceNotification2", bool1, false);
    this.I1 = b2;
    n1("FixInExperienceNotification2", (z6.a)b2);
    b2 = new z6.a.b("EnableBetterMaquettesDeviceNameForUserAgent", bool1, true);
    this.J1 = b2;
    n1("EnableBetterMaquettesDeviceNameForUserAgent", (z6.a)b2);
    b2 = new z6.a.b("AndroidDetectDeadCode", bool1, true);
    this.K1 = b2;
    n1("AndroidDetectDeadCode", (z6.a)b2);
    b2 = new z6.a.b("AndroidNotchExperimentAddGameBlockList", bool1, false);
    this.L1 = b2;
    n1("AndroidNotchExperimentAddGameBlockList", (z6.a)b2);
    z6.a.f f1 = new z6.a.f("AndroidNotchExperimentGameBlockList", "", false);
    this.M1 = f1;
    n1("AndroidNotchExperimentGameBlockList", (z6.a)f1);
    z6.a.b b1 = new z6.a.b("BalanceAppShellFragmentLinkingStartStop", bool1, false);
    this.N1 = b1;
    n1("BalanceAppShellFragmentLinkingStartStop", (z6.a)b1);
    b1 = new z6.a.b("RemoveRedundantLinkingProtocolCall", bool1, false);
    this.O1 = b1;
    n1("RemoveRedundantLinkingProtocolCall", (z6.a)b1);
    b1 = new z6.a.b("AndroidInitializeAndroidUpdateAdapter", bool1, true);
    this.P1 = b1;
    n1("AndroidInitializeAndroidUpdateAdapter", (z6.a)b1);
    b1 = new z6.a.b("RemoveDataModelNotificationGameLaunch", bool1, false);
    this.Q1 = b1;
    n1("RemoveDataModelNotificationGameLaunch", (z6.a)b1);
    b1 = new z6.a.b("CleanupHttpAgentOnRestart", bool1, true);
    this.R1 = b1;
    n1("CleanupHttpAgentOnRestart", (z6.a)b1);
    b1 = new z6.a.b("FFlagIrisJoinTime", bool1, false);
    this.S1 = b1;
    n1("FFlagIrisJoinTime", (z6.a)b1);
    b1 = new z6.a.b("AndroidAddBuildVariantToGlobalTags", bool1, true);
    this.T1 = b1;
    n1("AndroidAddBuildVariantToGlobalTags", (z6.a)b1);
  }
  
  public int A() {
    return ((Integer)this.M.g()).intValue();
  }
  
  public long A0() {
    return ((Long)this.k1.g()).longValue();
  }
  
  public String B() {
    return (String)this.f.g();
  }
  
  public boolean B0() {
    return this.A1.i().booleanValue();
  }
  
  public int C() {
    return ((Integer)this.O.g()).intValue();
  }
  
  public long C0() {
    return ((Long)this.o0.g()).longValue();
  }
  
  public boolean D() {
    return this.J0.i().booleanValue();
  }
  
  public boolean D0() {
    return this.G0.i().booleanValue();
  }
  
  public String E() {
    return (String)this.n1.g();
  }
  
  public int E0() {
    return ((Integer)this.F.g()).intValue();
  }
  
  public boolean F() {
    return this.q1.i().booleanValue();
  }
  
  public int F0() {
    return ((Integer)this.v.g()).intValue();
  }
  
  public boolean G() {
    return this.f1.i().booleanValue();
  }
  
  public long G0() {
    return ((Long)this.H0.g()).longValue();
  }
  
  public String H() {
    return (String)this.K.g();
  }
  
  public boolean H0() {
    return this.I0.i().booleanValue();
  }
  
  public boolean I() {
    return this.G1.i().booleanValue();
  }
  
  public boolean I0() {
    return this.e0.i().booleanValue();
  }
  
  public boolean J() {
    return this.J1.i().booleanValue();
  }
  
  public boolean J0() {
    return this.X.i().booleanValue();
  }
  
  public int K() {
    return ((Integer)this.E.g()).intValue();
  }
  
  public boolean K0() {
    return this.A.i().booleanValue();
  }
  
  public boolean L() {
    return this.g1.i().booleanValue();
  }
  
  public boolean L0() {
    return this.P1.i().booleanValue();
  }
  
  public boolean M() {
    return this.b1.i().booleanValue();
  }
  
  public int M0() {
    return ((Integer)this.e.g()).intValue();
  }
  
  public boolean N() {
    return this.v1.i().booleanValue();
  }
  
  public boolean N0() {
    return this.N1.i().booleanValue();
  }
  
  public boolean O() {
    return this.W0.i().booleanValue();
  }
  
  public boolean O0() {
    return this.m1.i().booleanValue();
  }
  
  public boolean P() {
    return this.T1.i().booleanValue();
  }
  
  public int P0() {
    return ((Integer)this.q.g()).intValue();
  }
  
  public String Q() {
    return (String)this.J.g();
  }
  
  public int Q0() {
    return ((Integer)this.d.g()).intValue();
  }
  
  public String R() {
    return (String)this.G.g();
  }
  
  public boolean R0() {
    return this.S0.i().booleanValue();
  }
  
  public int S() {
    return ((Integer)this.w.g()).intValue();
  }
  
  public String S0() {
    return (String)this.A0.g();
  }
  
  public boolean T() {
    return this.B1.i().booleanValue();
  }
  
  public boolean T0() {
    return this.O1.i().booleanValue();
  }
  
  public boolean U() {
    return this.C1.i().booleanValue();
  }
  
  public String U0() {
    return (String)this.M1.g();
  }
  
  public boolean V() {
    return this.Y0.i().booleanValue();
  }
  
  public boolean V0() {
    return this.w1.i().booleanValue();
  }
  
  public int W() {
    return ((Integer)this.b.g()).intValue();
  }
  
  public String W0() {
    return (String)this.j.g();
  }
  
  public boolean X() {
    return this.j1.i().booleanValue();
  }
  
  public boolean X0() {
    return this.l1.i().booleanValue();
  }
  
  public int Y() {
    return ((Integer)this.L.g()).intValue();
  }
  
  public long Y0() {
    return ((Long)this.x.g()).longValue();
  }
  
  public int Z() {
    return ((Integer)this.D.g()).intValue();
  }
  
  public boolean Z0() {
    return this.a1.i().booleanValue();
  }
  
  public boolean a() {
    return this.x1.i().booleanValue();
  }
  
  public boolean a0() {
    return this.z1.i().booleanValue();
  }
  
  public boolean a1() {
    return this.I1.i().booleanValue();
  }
  
  public int b() {
    return ((Integer)this.I.g()).intValue();
  }
  
  public int b0() {
    return ((Integer)this.y.g()).intValue();
  }
  
  public String b1() {
    return (String)this.H.g();
  }
  
  public int c() {
    return ((Integer)this.R0.g()).intValue();
  }
  
  public boolean c0() {
    return this.s1.i().booleanValue();
  }
  
  public String c1() {
    return (String)this.P.g();
  }
  
  public int d() {
    return ((Integer)this.S.g()).intValue();
  }
  
  public boolean d0() {
    return this.Q0.i().booleanValue();
  }
  
  public String e() {
    return (String)this.h.g();
  }
  
  public boolean e0() {
    return this.H1.i().booleanValue();
  }
  
  public boolean e1() {
    return this.K0.i().booleanValue();
  }
  
  public boolean f() {
    return this.R1.i().booleanValue();
  }
  
  public boolean f0() {
    return this.L1.i().booleanValue();
  }
  
  public boolean f1() {
    return this.N0.i().booleanValue();
  }
  
  public String g() {
    return (String)this.R.g();
  }
  
  public int g0() {
    return ((Integer)this.u1.g()).intValue();
  }
  
  public boolean g1() {
    return this.L0.i().booleanValue();
  }
  
  public boolean h() {
    return this.r1.i().booleanValue();
  }
  
  public boolean h0() {
    return this.D0.i().booleanValue();
  }
  
  public boolean h1() {
    return this.P0.i().booleanValue();
  }
  
  public boolean i() {
    return this.E1.i().booleanValue();
  }
  
  public boolean i0() {
    return this.p1.i().booleanValue();
  }
  
  public String i1() {
    return (String)this.B0.g();
  }
  
  public boolean j() {
    return this.U0.i().booleanValue();
  }
  
  public boolean j0() {
    return this.o1.i().booleanValue();
  }
  
  public boolean j1() {
    return this.F1.i().booleanValue();
  }
  
  public boolean k() {
    return this.T0.i().booleanValue();
  }
  
  public boolean k0() {
    return this.K1.i().booleanValue();
  }
  
  public boolean k1() {
    return this.S1.i().booleanValue();
  }
  
  public boolean l() {
    return this.d1.i().booleanValue();
  }
  
  public boolean l0() {
    return this.C0.i().booleanValue();
  }
  
  public boolean l1() {
    return this.U.i().booleanValue();
  }
  
  public boolean m() {
    return this.W.i().booleanValue();
  }
  
  public String m0() {
    return (String)this.g.g();
  }
  
  public boolean m1() {
    return this.t1.i().booleanValue();
  }
  
  public int n() {
    return ((Integer)this.t.g()).intValue();
  }
  
  public int n0() {
    return ((Integer)this.Q.g()).intValue();
  }
  
  public boolean o() {
    return this.e1.i().booleanValue();
  }
  
  public int o0() {
    return ((Integer)this.u.g()).intValue();
  }
  
  public long p() {
    return ((Long)this.n.g()).longValue();
  }
  
  public boolean p0() {
    return this.x0.i().booleanValue();
  }
  
  public boolean q() {
    return this.E0.i().booleanValue();
  }
  
  public boolean q0() {
    return this.u0.i().booleanValue();
  }
  
  public boolean r() {
    return this.y1.i().booleanValue();
  }
  
  public int r0() {
    return ((Integer)this.m.g()).intValue();
  }
  
  public boolean s() {
    return this.h1.i().booleanValue();
  }
  
  public boolean s0() {
    return this.c1.i().booleanValue();
  }
  
  public boolean t() {
    return this.Q1.i().booleanValue();
  }
  
  public String t0() {
    return (String)this.c.g();
  }
  
  public boolean u() {
    return this.p.i().booleanValue();
  }
  
  public boolean u0() {
    return this.Z0.i().booleanValue();
  }
  
  public String v() {
    return (String)this.l.g();
  }
  
  public int v0() {
    return ((Integer)this.O0.g()).intValue();
  }
  
  public long w() {
    return ((Long)this.Y.g()).longValue();
  }
  
  public String w0() {
    return (String)this.o.g();
  }
  
  public int x() {
    return ((Integer)this.s.g()).intValue();
  }
  
  public boolean x0() {
    return this.D1.i().booleanValue();
  }
  
  public int y() {
    return ((Integer)this.r.g()).intValue();
  }
  
  public boolean y0() {
    return this.N.i().booleanValue();
  }
  
  public int z() {
    return ((Integer)this.z.g()).intValue();
  }
  
  public boolean z0() {
    return this.i1.i().booleanValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a7\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */