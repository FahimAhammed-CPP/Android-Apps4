package a1;

import android.view.MotionEvent;

public final class j {
  public static boolean a(MotionEvent paramMotionEvent, int paramInt) {
    return ((paramMotionEvent.getSource() & paramInt) == paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */