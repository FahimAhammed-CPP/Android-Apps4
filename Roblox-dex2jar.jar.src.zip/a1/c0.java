package a1;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class c0 {
  public static final c0 b = l.b;
  
  private final l a;
  
  public c0(c0 paramc0) {
    if (paramc0 != null) {
      l l1 = paramc0.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l1 instanceof k) {
        this.a = new k(this, (k)l1);
      } else if (i >= 29 && l1 instanceof j) {
        this.a = new j(this, (j)l1);
      } else if (i >= 28 && l1 instanceof i) {
        this.a = new i(this, (i)l1);
      } else if (l1 instanceof h) {
        this.a = new h(this, (h)l1);
      } else if (l1 instanceof g) {
        this.a = new g(this, (g)l1);
      } else {
        this.a = new l(this);
      } 
      l1.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  private c0(WindowInsets paramWindowInsets) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new k(this, paramWindowInsets);
      return;
    } 
    if (i >= 29) {
      this.a = new j(this, paramWindowInsets);
      return;
    } 
    if (i >= 28) {
      this.a = new i(this, paramWindowInsets);
      return;
    } 
    this.a = new h(this, paramWindowInsets);
  }
  
  static s0.b n(s0.b paramb, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = Math.max(0, paramb.a - paramInt1);
    int j = Math.max(0, paramb.b - paramInt2);
    int k = Math.max(0, paramb.c - paramInt3);
    int m = Math.max(0, paramb.d - paramInt4);
    return (i == paramInt1 && j == paramInt2 && k == paramInt3 && m == paramInt4) ? paramb : s0.b.b(i, j, k, m);
  }
  
  public static c0 v(WindowInsets paramWindowInsets) {
    return w(paramWindowInsets, null);
  }
  
  public static c0 w(WindowInsets paramWindowInsets, View paramView) {
    c0 c01 = new c0((WindowInsets)z0.h.f(paramWindowInsets));
    if (paramView != null && paramView.isAttachedToWindow()) {
      c01.s(u.J(paramView));
      c01.d(paramView.getRootView());
    } 
    return c01;
  }
  
  @Deprecated
  public c0 a() {
    return this.a.a();
  }
  
  @Deprecated
  public c0 b() {
    return this.a.b();
  }
  
  @Deprecated
  public c0 c() {
    return this.a.c();
  }
  
  void d(View paramView) {
    this.a.d(paramView);
  }
  
  public d e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof c0))
      return false; 
    paramObject = paramObject;
    return z0.c.a(this.a, ((c0)paramObject).a);
  }
  
  public s0.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  public s0.b g() {
    return this.a.h();
  }
  
  @Deprecated
  public s0.b h() {
    return this.a.i();
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  @Deprecated
  public int i() {
    return (this.a.k()).d;
  }
  
  @Deprecated
  public int j() {
    return (this.a.k()).a;
  }
  
  @Deprecated
  public int k() {
    return (this.a.k()).c;
  }
  
  @Deprecated
  public int l() {
    return (this.a.k()).b;
  }
  
  public c0 m(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return this.a.m(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean o() {
    return this.a.n();
  }
  
  @Deprecated
  public c0 p(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (new b(this)).c(s0.b.b(paramInt1, paramInt2, paramInt3, paramInt4)).a();
  }
  
  void q(s0.b[] paramArrayOfb) {
    this.a.p(paramArrayOfb);
  }
  
  void r(s0.b paramb) {
    this.a.q(paramb);
  }
  
  void s(c0 paramc0) {
    this.a.r(paramc0);
  }
  
  void t(s0.b paramb) {
    this.a.s(paramb);
  }
  
  public WindowInsets u() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 30) {
      b = k.r;
      return;
    } 
  }
  
  static class a {
    private static Field a;
    
    private static Field b;
    
    private static Field c;
    
    private static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static c0 a(View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              c0 c0 = (new c0.b()).b(s0.b.c(rect)).c(s0.b.c((Rect)object)).a();
              c0.s(c0);
              c0.d(param1View.getRootView());
              return c0;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    private final c0.f a;
    
    public b() {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new c0.e();
        return;
      } 
      if (i >= 29) {
        this.a = new c0.d();
        return;
      } 
      this.a = new c0.c();
    }
    
    public b(c0 param1c0) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new c0.e(param1c0);
        return;
      } 
      if (i >= 29) {
        this.a = new c0.d(param1c0);
        return;
      } 
      this.a = new c0.c(param1c0);
    }
    
    public c0 a() {
      return this.a.b();
    }
    
    @Deprecated
    public b b(s0.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    public b c(s0.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  private static class c extends f {
    private static Field e;
    
    private static boolean f = false;
    
    private static Constructor<WindowInsets> g;
    
    private static boolean h = false;
    
    private WindowInsets c = h();
    
    private s0.b d;
    
    c() {}
    
    c(c0 param1c0) {}
    
    private static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    c0 b() {
      a();
      c0 c0 = c0.v(this.c);
      c0.q(this.b);
      c0.t(this.d);
      return c0;
    }
    
    void d(s0.b param1b) {
      this.d = param1b;
    }
    
    void f(s0.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  private static class d extends f {
    final WindowInsets.Builder c;
    
    d() {
      this.c = new WindowInsets.Builder();
    }
    
    d(c0 param1c0) {
      WindowInsets.Builder builder;
      WindowInsets windowInsets = param1c0.u();
      if (windowInsets != null) {
        builder = new WindowInsets.Builder(windowInsets);
      } else {
        builder = new WindowInsets.Builder();
      } 
      this.c = builder;
    }
    
    c0 b() {
      a();
      c0 c0 = c0.v(this.c.build());
      c0.q(this.b);
      return c0;
    }
    
    void c(s0.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    void d(s0.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    void e(s0.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    void f(s0.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    void g(s0.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  private static class e extends d {
    e() {}
    
    e(c0 param1c0) {
      super(param1c0);
    }
  }
  
  private static class f {
    private final c0 a;
    
    s0.b[] b;
    
    f() {
      this(new c0(null));
    }
    
    f(c0 param1c0) {
      this.a = param1c0;
    }
    
    protected final void a() {
      s0.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        s0.b b1 = arrayOfB[c0.m.b(1)];
        s0.b b2 = this.b[c0.m.b(2)];
        if (b1 != null && b2 != null) {
          f(s0.b.a(b1, b2));
        } else if (b1 != null) {
          f(b1);
        } else if (b2 != null) {
          f(b2);
        } 
        b1 = this.b[c0.m.b(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[c0.m.b(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[c0.m.b(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    c0 b() {
      throw null;
    }
    
    void c(s0.b param1b) {}
    
    void d(s0.b param1b) {
      throw null;
    }
    
    void e(s0.b param1b) {}
    
    void f(s0.b param1b) {
      throw null;
    }
    
    void g(s0.b param1b) {}
  }
  
  private static class g extends l {
    private static boolean h = false;
    
    private static Method i;
    
    private static Class<?> j;
    
    private static Class<?> k;
    
    private static Field l;
    
    private static Field m;
    
    final WindowInsets c;
    
    private s0.b[] d;
    
    private s0.b e = null;
    
    private c0 f;
    
    s0.b g;
    
    g(c0 param1c0, g param1g) {
      this(param1c0, new WindowInsets(param1g.c));
    }
    
    g(c0 param1c0, WindowInsets param1WindowInsets) {
      super(param1c0);
      this.c = param1WindowInsets;
    }
    
    @SuppressLint({"WrongConstant"})
    private s0.b t(int param1Int, boolean param1Boolean) {
      s0.b b1 = s0.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = s0.b.a(b1, u(i, param1Boolean)); 
      } 
      return b1;
    }
    
    private s0.b v() {
      c0 c01 = this.f;
      return (c01 != null) ? c01.h() : s0.b.e;
    }
    
    private s0.b w(View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          x(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && k != null) {
          if (l == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = m.get(object);
            Rect rect = (Rect)l.get(object);
            object = stringBuilder;
            if (rect != null)
              object = s0.b.c(rect); 
            return (s0.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
    
    @SuppressLint({"PrivateApi"})
    private static void x() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        j = Class.forName("android.view.ViewRootImpl");
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        k = clazz;
        l = clazz.getDeclaredField("mVisibleInsets");
        m = j.getDeclaredField("mAttachInfo");
        l.setAccessible(true);
        m.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    void d(View param1View) {
      s0.b b2 = w(param1View);
      s0.b b1 = b2;
      if (b2 == null)
        b1 = s0.b.e; 
      q(b1);
    }
    
    void e(c0 param1c0) {
      param1c0.s(this.f);
      param1c0.r(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    public s0.b g(int param1Int) {
      return t(param1Int, false);
    }
    
    final s0.b k() {
      if (this.e == null)
        this.e = s0.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    c0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      c0.b b1 = new c0.b(c0.v(this.c));
      b1.c(c0.n(k(), param1Int1, param1Int2, param1Int3, param1Int4));
      b1.b(c0.n(i(), param1Int1, param1Int2, param1Int3, param1Int4));
      return b1.a();
    }
    
    boolean o() {
      return this.c.isRound();
    }
    
    public void p(s0.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    void q(s0.b param1b) {
      this.g = param1b;
    }
    
    void r(c0 param1c0) {
      this.f = param1c0;
    }
    
    protected s0.b u(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        s0.b b1;
        c0 c01 = null;
        c0 c02 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  d d;
                  if (param1Int != 128)
                    return s0.b.e; 
                  c01 = this.f;
                  if (c01 != null) {
                    d = c01.e();
                  } else {
                    d = f();
                  } 
                  return (d != null) ? s0.b.b(d.b(), d.d(), d.c(), d.a()) : s0.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          s0.b[] arrayOfB = this.d;
          c01 = c02;
          if (arrayOfB != null)
            b1 = arrayOfB[c0.m.b(8)]; 
          if (b1 != null)
            return b1; 
          s0.b b3 = k();
          b1 = v();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return s0.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(s0.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return s0.b.b(0, 0, 0, param1Int); 
          } 
          return s0.b.e;
        } 
        if (param1Boolean) {
          b1 = v();
          s0.b b3 = i();
          return s0.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        s0.b b2 = k();
        c0 c03 = this.f;
        if (c03 != null)
          b1 = c03.h(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return s0.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? s0.b.b(0, Math.max((v()).b, (k()).b), 0, 0) : s0.b.b(0, (k()).b, 0, 0);
    }
  }
  
  private static class h extends g {
    private s0.b n = null;
    
    h(c0 param1c0, h param1h) {
      super(param1c0, param1h);
      this.n = param1h.n;
    }
    
    h(c0 param1c0, WindowInsets param1WindowInsets) {
      super(param1c0, param1WindowInsets);
    }
    
    c0 b() {
      return c0.v(this.c.consumeStableInsets());
    }
    
    c0 c() {
      return c0.v(this.c.consumeSystemWindowInsets());
    }
    
    final s0.b i() {
      if (this.n == null)
        this.n = s0.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.n;
    }
    
    boolean n() {
      return this.c.isConsumed();
    }
    
    public void s(s0.b param1b) {
      this.n = param1b;
    }
  }
  
  private static class i extends h {
    i(c0 param1c0, i param1i) {
      super(param1c0, param1i);
    }
    
    i(c0 param1c0, WindowInsets param1WindowInsets) {
      super(param1c0, param1WindowInsets);
    }
    
    c0 a() {
      return c0.v(this.c.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((c0.g)param1Object).c) && Objects.equals(this.g, ((c0.g)param1Object).g));
    }
    
    d f() {
      return d.e(this.c.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  private static class j extends i {
    private s0.b o = null;
    
    private s0.b p = null;
    
    private s0.b q = null;
    
    j(c0 param1c0, j param1j) {
      super(param1c0, param1j);
    }
    
    j(c0 param1c0, WindowInsets param1WindowInsets) {
      super(param1c0, param1WindowInsets);
    }
    
    s0.b h() {
      if (this.p == null)
        this.p = s0.b.d(this.c.getMandatorySystemGestureInsets()); 
      return this.p;
    }
    
    s0.b j() {
      if (this.o == null)
        this.o = s0.b.d(this.c.getSystemGestureInsets()); 
      return this.o;
    }
    
    s0.b l() {
      if (this.q == null)
        this.q = s0.b.d(this.c.getTappableElementInsets()); 
      return this.q;
    }
    
    c0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return c0.v(this.c.inset(param1Int1, param1Int2, param1Int3, param1Int4));
    }
    
    public void s(s0.b param1b) {}
  }
  
  private static class k extends j {
    static final c0 r = c0.v(WindowInsets.CONSUMED);
    
    k(c0 param1c0, k param1k) {
      super(param1c0, param1k);
    }
    
    k(c0 param1c0, WindowInsets param1WindowInsets) {
      super(param1c0, param1WindowInsets);
    }
    
    final void d(View param1View) {}
    
    public s0.b g(int param1Int) {
      return s0.b.d(this.c.getInsets(c0.n.a(param1Int)));
    }
  }
  
  private static class l {
    static final c0 b = (new c0.b()).a().a().b().c();
    
    final c0 a;
    
    l(c0 param1c0) {
      this.a = param1c0;
    }
    
    c0 a() {
      return this.a;
    }
    
    c0 b() {
      return this.a;
    }
    
    c0 c() {
      return this.a;
    }
    
    void d(View param1View) {}
    
    void e(c0 param1c0) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (o() == param1Object.o() && n() == param1Object.n() && z0.c.a(k(), param1Object.k()) && z0.c.a(i(), param1Object.i()) && z0.c.a(f(), param1Object.f()));
    }
    
    d f() {
      return null;
    }
    
    s0.b g(int param1Int) {
      return s0.b.e;
    }
    
    s0.b h() {
      return k();
    }
    
    public int hashCode() {
      return z0.c.b(new Object[] { Boolean.valueOf(o()), Boolean.valueOf(n()), k(), i(), f() });
    }
    
    s0.b i() {
      return s0.b.e;
    }
    
    s0.b j() {
      return k();
    }
    
    s0.b k() {
      return s0.b.e;
    }
    
    s0.b l() {
      return k();
    }
    
    c0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return b;
    }
    
    boolean n() {
      return false;
    }
    
    boolean o() {
      return false;
    }
    
    public void p(s0.b[] param1ArrayOfb) {}
    
    void q(s0.b param1b) {}
    
    void r(c0 param1c0) {}
    
    public void s(s0.b param1b) {}
  }
  
  public static final class m {
    public static int a() {
      return 128;
    }
    
    static int b(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
  }
  
  private static final class n {
    static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */