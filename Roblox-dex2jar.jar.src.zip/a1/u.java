package a1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class u {
  private static final AtomicInteger a = new AtomicInteger(1);
  
  private static WeakHashMap<View, y> b = null;
  
  private static Field c;
  
  private static boolean d = false;
  
  private static ThreadLocal<Rect> e;
  
  private static final int[] f = new int[] { 
      o0.c.b, o0.c.c, o0.c.n, o0.c.y, o0.c.B, o0.c.C, o0.c.D, o0.c.E, o0.c.F, o0.c.G, 
      o0.c.d, o0.c.e, o0.c.f, o0.c.g, o0.c.h, o0.c.i, o0.c.j, o0.c.k, o0.c.l, o0.c.m, 
      o0.c.o, o0.c.p, o0.c.q, o0.c.r, o0.c.s, o0.c.t, o0.c.u, o0.c.v, o0.c.w, o0.c.x, 
      o0.c.z, o0.c.A };
  
  private static final r g = new a();
  
  private static f h = new f();
  
  public static int A(View paramView) {
    return paramView.getImportantForAccessibility();
  }
  
  public static void A0(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  @SuppressLint({"InlinedApi"})
  public static int B(View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? paramView.getImportantForAutofill() : 0;
  }
  
  public static void B0(View paramView, t paramt) {
    if (Build.VERSION.SDK_INT >= 24) {
      if (paramt != null) {
        Object object = paramt.a();
      } else {
        paramt = null;
      } 
      paramView.setPointerIcon((PointerIcon)paramt);
    } 
  }
  
  public static int C(View paramView) {
    return paramView.getLayoutDirection();
  }
  
  public static void C0(View paramView, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.setScrollIndicators(paramInt1, paramInt2); 
  }
  
  public static int D(View paramView) {
    return paramView.getMinimumHeight();
  }
  
  public static void D0(View paramView, CharSequence paramCharSequence) {
    G0().g(paramView, paramCharSequence);
  }
  
  public static int E(View paramView) {
    return paramView.getMinimumWidth();
  }
  
  public static void E0(View paramView, String paramString) {
    paramView.setTransitionName(paramString);
  }
  
  public static String[] F(View paramView) {
    return (String[])paramView.getTag(o0.c.N);
  }
  
  private static void F0(View paramView) {
    if (A(paramView) == 0)
      x0(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (A((View)viewParent) == 4) {
        x0(paramView, 2);
        return;
      } 
    } 
  }
  
  static a G(View paramView) {
    a a2 = l(paramView);
    a a1 = a2;
    if (a2 == null)
      a1 = new a(); 
    o0(paramView, a1);
    return a1;
  }
  
  private static g<CharSequence> G0() {
    return new d(o0.c.P, CharSequence.class, 64, 30);
  }
  
  public static int H(View paramView) {
    return paramView.getPaddingEnd();
  }
  
  public static void H0(View paramView) {
    paramView.stopNestedScroll();
  }
  
  public static int I(View paramView) {
    return paramView.getPaddingStart();
  }
  
  private static void I0(View paramView) {
    float f1 = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f1);
    paramView.setTranslationY(f1);
  }
  
  public static c0 J(View paramView) {
    return (Build.VERSION.SDK_INT >= 23) ? i.a(paramView) : h.c(paramView);
  }
  
  public static final CharSequence K(View paramView) {
    return G0().f(paramView);
  }
  
  public static String L(View paramView) {
    return paramView.getTransitionName();
  }
  
  public static int M(View paramView) {
    return paramView.getWindowSystemUiVisibility();
  }
  
  public static float N(View paramView) {
    return paramView.getZ();
  }
  
  public static boolean O(View paramView) {
    return paramView.hasOnClickListeners();
  }
  
  public static boolean P(View paramView) {
    return paramView.hasOverlappingRendering();
  }
  
  public static boolean Q(View paramView) {
    return paramView.hasTransientState();
  }
  
  public static boolean R(View paramView) {
    Boolean bool = a().f(paramView);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public static boolean S(View paramView) {
    return paramView.isAttachedToWindow();
  }
  
  public static boolean T(View paramView) {
    return paramView.isLaidOut();
  }
  
  public static boolean U(View paramView) {
    return paramView.isNestedScrollingEnabled();
  }
  
  public static boolean V(View paramView) {
    return paramView.isPaddingRelative();
  }
  
  public static boolean W(View paramView) {
    Boolean bool = n0().f(paramView);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  static void X(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (p(paramView) != null && paramView.getVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = o(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      accessibilityEvent.setContentChangeTypes(paramInt);
      if (bool) {
        accessibilityEvent.getText().add(p(paramView));
        F0(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      accessibilityEvent1.setContentChangeTypes(paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(p(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null)
      try {
        paramView.getParent().notifySubtreeAccessibilityStateChanged(paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      }  
  }
  
  public static void Y(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23) {
      paramView.offsetLeftAndRight(paramInt);
      return;
    } 
    Rect rect = x();
    int i = 0;
    ViewParent viewParent = paramView.getParent();
    if (viewParent instanceof View) {
      View view = (View)viewParent;
      rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
      i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
    } 
    e(paramView, paramInt);
    if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
      ((View)viewParent).invalidate(rect); 
  }
  
  public static void Z(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23) {
      paramView.offsetTopAndBottom(paramInt);
      return;
    } 
    Rect rect = x();
    int i = 0;
    ViewParent viewParent = paramView.getParent();
    if (viewParent instanceof View) {
      View view = (View)viewParent;
      rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
      i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
    } 
    f(paramView, paramInt);
    if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
      ((View)viewParent).invalidate(rect); 
  }
  
  private static g<Boolean> a() {
    return new e(o0.c.J, Boolean.class, 28);
  }
  
  public static c0 a0(View paramView, c0 paramc0) {
    WindowInsets windowInsets = paramc0.u();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = paramView.onApplyWindowInsets(windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return c0.w(windowInsets1, paramView); 
    } 
    return paramc0;
  }
  
  public static int b(View paramView, CharSequence paramCharSequence, b1.f paramf) {
    int i = r(paramView);
    if (i != -1)
      c(paramView, new b1.c.a(i, paramCharSequence, paramf)); 
    return i;
  }
  
  public static void b0(View paramView, b1.c paramc) {
    paramView.onInitializeAccessibilityNodeInfo(paramc.x0());
  }
  
  private static void c(View paramView, b1.c.a parama) {
    G(paramView);
    j0(parama.b(), paramView);
    q(paramView).add(parama);
    X(paramView, 0);
  }
  
  private static g<CharSequence> c0() {
    return new c(o0.c.K, CharSequence.class, 8, 28);
  }
  
  public static y d(View paramView) {
    if (b == null)
      b = new WeakHashMap<View, y>(); 
    y y2 = b.get(paramView);
    y y1 = y2;
    if (y2 == null) {
      y1 = new y(paramView);
      b.put(paramView, y1);
    } 
    return y1;
  }
  
  public static boolean d0(View paramView, int paramInt, Bundle paramBundle) {
    return paramView.performAccessibilityAction(paramInt, paramBundle);
  }
  
  private static void e(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0) {
      I0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        I0((View)viewParent); 
    } 
  }
  
  public static c e0(View paramView, c paramc) {
    if (Log.isLoggable("ViewCompat", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("performReceiveContent: ");
      stringBuilder.append(paramc);
      stringBuilder.append(", view=");
      stringBuilder.append(paramView.getClass().getSimpleName());
      stringBuilder.append("[");
      stringBuilder.append(paramView.getId());
      stringBuilder.append("]");
      Log.d("ViewCompat", stringBuilder.toString());
    } 
    q q = (q)paramView.getTag(o0.c.M);
    if (q != null) {
      paramc = q.a(paramView, paramc);
      return (paramc == null) ? null : y(paramView).onReceiveContent(paramc);
    } 
    return y(paramView).onReceiveContent(paramc);
  }
  
  private static void f(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0) {
      I0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        I0((View)viewParent); 
    } 
  }
  
  public static void f0(View paramView) {
    paramView.postInvalidateOnAnimation();
  }
  
  public static c0 g(View paramView, c0 paramc0, Rect paramRect) {
    return h.b(paramView, paramc0, paramRect);
  }
  
  public static void g0(View paramView, Runnable paramRunnable) {
    paramView.postOnAnimation(paramRunnable);
  }
  
  public static c0 h(View paramView, c0 paramc0) {
    WindowInsets windowInsets = paramc0.u();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = paramView.dispatchApplyWindowInsets(windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return c0.w(windowInsets1, paramView); 
    } 
    return paramc0;
  }
  
  public static void h0(View paramView, Runnable paramRunnable, long paramLong) {
    paramView.postOnAnimationDelayed(paramRunnable, paramLong);
  }
  
  static boolean i(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : l.a(paramView).b(paramView, paramKeyEvent);
  }
  
  public static void i0(View paramView, int paramInt) {
    j0(paramInt, paramView);
    X(paramView, 0);
  }
  
  static boolean j(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : l.a(paramView).f(paramKeyEvent);
  }
  
  private static void j0(int paramInt, View paramView) {
    List<b1.c.a> list = q(paramView);
    for (int i = 0; i < list.size(); i++) {
      if (((b1.c.a)list.get(i)).b() == paramInt) {
        list.remove(i);
        return;
      } 
    } 
  }
  
  public static int k() {
    return View.generateViewId();
  }
  
  public static void k0(View paramView, b1.c.a parama, CharSequence paramCharSequence, b1.f paramf) {
    if (paramf == null && paramCharSequence == null) {
      i0(paramView, parama.b());
      return;
    } 
    c(paramView, parama.a(paramCharSequence, paramf));
  }
  
  public static a l(View paramView) {
    View.AccessibilityDelegate accessibilityDelegate = m(paramView);
    return (accessibilityDelegate == null) ? null : ((accessibilityDelegate instanceof a.a) ? ((a.a)accessibilityDelegate).a : new a(accessibilityDelegate));
  }
  
  public static void l0(View paramView) {
    paramView.requestApplyInsets();
  }
  
  private static View.AccessibilityDelegate m(View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? paramView.getAccessibilityDelegate() : n(paramView);
  }
  
  public static void m0(View paramView, @SuppressLint({"ContextFirst"}) Context paramContext, int[] paramArrayOfint, AttributeSet paramAttributeSet, TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 29)
      j.a(paramView, paramContext, paramArrayOfint, paramAttributeSet, paramTypedArray, paramInt1, paramInt2); 
  }
  
  private static View.AccessibilityDelegate n(View paramView) {
    // Byte code:
    //   0: getstatic a1/u.d : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic a1/u.c : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 41
    //   14: ldc android/view/View
    //   16: ldc_w 'mAccessibilityDelegate'
    //   19: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic a1/u.c : Ljava/lang/reflect/Field;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setAccessible : (Z)V
    //   32: goto -> 41
    //   35: iconst_1
    //   36: putstatic a1/u.d : Z
    //   39: aconst_null
    //   40: areturn
    //   41: getstatic a1/u.c : Ljava/lang/reflect/Field;
    //   44: aload_0
    //   45: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_0
    //   49: aload_0
    //   50: instanceof android/view/View$AccessibilityDelegate
    //   53: ifeq -> 63
    //   56: aload_0
    //   57: checkcast android/view/View$AccessibilityDelegate
    //   60: astore_0
    //   61: aload_0
    //   62: areturn
    //   63: aconst_null
    //   64: areturn
    //   65: iconst_1
    //   66: putstatic a1/u.d : Z
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: goto -> 35
    //   75: astore_0
    //   76: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   14	32	71	finally
    //   41	61	75	finally
  }
  
  private static g<Boolean> n0() {
    return new b(o0.c.O, Boolean.class, 28);
  }
  
  public static int o(View paramView) {
    return paramView.getAccessibilityLiveRegion();
  }
  
  public static void o0(View paramView, a parama) {
    View.AccessibilityDelegate accessibilityDelegate;
    a a1 = parama;
    if (parama == null) {
      a1 = parama;
      if (m(paramView) instanceof a.a)
        a1 = new a(); 
    } 
    if (a1 == null) {
      parama = null;
    } else {
      accessibilityDelegate = a1.d();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static CharSequence p(View paramView) {
    return c0().f(paramView);
  }
  
  public static void p0(View paramView, boolean paramBoolean) {
    a().g(paramView, Boolean.valueOf(paramBoolean));
  }
  
  private static List<b1.c.a> q(View paramView) {
    int i = o0.c.H;
    ArrayList<b1.c.a> arrayList2 = (ArrayList)paramView.getTag(i);
    ArrayList<b1.c.a> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      paramView.setTag(i, arrayList1);
    } 
    return arrayList1;
  }
  
  public static void q0(View paramView, int paramInt) {
    paramView.setAccessibilityLiveRegion(paramInt);
  }
  
  private static int r(View paramView) {
    List<b1.c.a> list = q(paramView);
    int i = 0;
    int j = -1;
    while (true) {
      int[] arrayOfInt = f;
      if (i < arrayOfInt.length && j == -1) {
        int n = arrayOfInt[i];
        int m = 0;
        int k = 1;
        while (m < list.size()) {
          byte b;
          if (((b1.c.a)list.get(m)).b() != n) {
            b = 1;
          } else {
            b = 0;
          } 
          k &= b;
          m++;
        } 
        if (k != 0)
          j = n; 
        i++;
        continue;
      } 
      break;
    } 
    return j;
  }
  
  public static void r0(View paramView, Drawable paramDrawable) {
    paramView.setBackground(paramDrawable);
  }
  
  public static ColorStateList s(View paramView) {
    return paramView.getBackgroundTintList();
  }
  
  public static void s0(View paramView, ColorStateList paramColorStateList) {
    int i = Build.VERSION.SDK_INT;
    paramView.setBackgroundTintList(paramColorStateList);
    if (i == 21) {
      Drawable drawable = paramView.getBackground();
      if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (drawable != null && i != 0) {
        if (drawable.isStateful())
          drawable.setState(paramView.getDrawableState()); 
        paramView.setBackground(drawable);
      } 
    } 
  }
  
  public static PorterDuff.Mode t(View paramView) {
    return paramView.getBackgroundTintMode();
  }
  
  public static void t0(View paramView, PorterDuff.Mode paramMode) {
    int i = Build.VERSION.SDK_INT;
    paramView.setBackgroundTintMode(paramMode);
    if (i == 21) {
      Drawable drawable = paramView.getBackground();
      if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (drawable != null && i != 0) {
        if (drawable.isStateful())
          drawable.setState(paramView.getDrawableState()); 
        paramView.setBackground(drawable);
      } 
    } 
  }
  
  public static Rect u(View paramView) {
    return paramView.getClipBounds();
  }
  
  public static void u0(View paramView, Rect paramRect) {
    paramView.setClipBounds(paramRect);
  }
  
  public static Display v(View paramView) {
    return paramView.getDisplay();
  }
  
  public static void v0(View paramView, float paramFloat) {
    paramView.setElevation(paramFloat);
  }
  
  public static float w(View paramView) {
    return paramView.getElevation();
  }
  
  public static void w0(View paramView, boolean paramBoolean) {
    paramView.setHasTransientState(paramBoolean);
  }
  
  private static Rect x() {
    if (e == null)
      e = new ThreadLocal<Rect>(); 
    Rect rect2 = e.get();
    Rect rect1 = rect2;
    if (rect2 == null) {
      rect1 = new Rect();
      e.set(rect1);
    } 
    rect1.setEmpty();
    return rect1;
  }
  
  public static void x0(View paramView, int paramInt) {
    paramView.setImportantForAccessibility(paramInt);
  }
  
  private static r y(View paramView) {
    return (paramView instanceof r) ? (r)paramView : g;
  }
  
  public static void y0(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setImportantForAutofill(paramInt); 
  }
  
  public static boolean z(View paramView) {
    return paramView.getFitsSystemWindows();
  }
  
  public static void z0(View paramView, p paramp) {
    h.d(paramView, paramp);
  }
  
  class a implements r {
    public c onReceiveContent(c param1c) {
      return param1c;
    }
  }
  
  class b extends g<Boolean> {
    b(u this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(param1View.isScreenReaderFocusable());
    }
    
    void j(View param1View, Boolean param1Boolean) {
      param1View.setScreenReaderFocusable(param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  class c extends g<CharSequence> {
    c(u this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      param1View.setAccessibilityPaneTitle(param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class d extends g<CharSequence> {
    d(u this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return param1View.getStateDescription();
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      param1View.setStateDescription(param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class e extends g<Boolean> {
    e(u this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(param1View.isAccessibilityHeading());
    }
    
    void j(View param1View, Boolean param1Boolean) {
      param1View.setAccessibilityHeading(param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  static class f implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private WeakHashMap<View, Boolean> n = new WeakHashMap<View, Boolean>();
    
    private void a(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.getVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        u.X(param1View, b);
        this.n.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    private void b(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.n.entrySet())
          a((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      b(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  static abstract class g<T> {
    private final int a;
    
    private final Class<T> b;
    
    private final int c;
    
    private final int d;
    
    g(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    g(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.d = param1Int2;
      this.c = param1Int3;
    }
    
    private boolean b() {
      return true;
    }
    
    private boolean c() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    boolean a(Boolean param1Boolean1, Boolean param1Boolean2) {
      boolean bool1;
      boolean bool2;
      boolean bool = false;
      if (param1Boolean1 == null) {
        bool1 = false;
      } else {
        bool1 = param1Boolean1.booleanValue();
      } 
      if (param1Boolean2 == null) {
        bool2 = false;
      } else {
        bool2 = param1Boolean2.booleanValue();
      } 
      if (bool1 == bool2)
        bool = true; 
      return bool;
    }
    
    abstract T d(View param1View);
    
    abstract void e(View param1View, T param1T);
    
    T f(View param1View) {
      if (c())
        return d(param1View); 
      if (b()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
    
    void g(View param1View, T param1T) {
      if (c()) {
        e(param1View, param1T);
        return;
      } 
      if (b() && h(f(param1View), param1T)) {
        u.G(param1View);
        param1View.setTag(this.a, param1T);
        u.X(param1View, this.d);
      } 
    }
    
    abstract boolean h(T param1T1, T param1T2);
  }
  
  private static class h {
    static void a(WindowInsets param1WindowInsets, View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(o0.c.S);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    static c0 b(View param1View, c0 param1c0, Rect param1Rect) {
      WindowInsets windowInsets = param1c0.u();
      if (windowInsets != null)
        return c0.w(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1c0;
    }
    
    public static c0 c(View param1View) {
      return c0.a.a(param1View);
    }
    
    static void d(View param1View, p param1p) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(o0.c.L, param1p); 
      if (param1p == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(o0.c.S));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1p));
    }
    
    class a implements View.OnApplyWindowInsetsListener {
      c0 a = null;
      
      a(u.h this$0, p param2p) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        c0 c02 = c0.w(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          u.h.a(param2WindowInsets, this.b);
          if (c02.equals(this.a))
            return this.c.a(param2View, c02).u(); 
        } 
        this.a = c02;
        c0 c01 = this.c.a(param2View, c02);
        if (i >= 30)
          return c01.u(); 
        u.l0(param2View);
        return c01.u();
      }
    }
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    c0 a = null;
    
    a(u this$0, p param1p) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      c0 c02 = c0.w(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        u.h.a(param1WindowInsets, this.b);
        if (c02.equals(this.a))
          return this.c.a(param1View, c02).u(); 
      } 
      this.a = c02;
      c0 c01 = this.c.a(param1View, c02);
      if (i >= 30)
        return c01.u(); 
      u.l0(param1View);
      return c01.u();
    }
  }
  
  private static class i {
    public static c0 a(View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      c0 c0 = c0.v(windowInsets);
      c0.s(c0);
      c0.d(param1View.getRootView());
      return c0;
    }
  }
  
  private static class j {
    static void a(View param1View, Context param1Context, int[] param1ArrayOfint, AttributeSet param1AttributeSet, TypedArray param1TypedArray, int param1Int1, int param1Int2) {
      param1View.saveAttributeDataForStyleable(param1Context, param1ArrayOfint, param1AttributeSet, param1TypedArray, param1Int1, param1Int2);
    }
  }
  
  public static interface k {
    boolean a(View param1View, KeyEvent param1KeyEvent);
  }
  
  static class l {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static l a(View param1View) {
      int i = o0.c.Q;
      l l2 = (l)param1View.getTag(i);
      l l1 = l2;
      if (l2 == null) {
        l1 = new l();
        param1View.setTag(i, l1);
      } 
      return l1;
    }
    
    private View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private boolean e(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<u.k> arrayList = (ArrayList)param1View.getTag(o0.c.R);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((u.k)arrayList.get(i)).a(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic a1/u$l.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic a1/u$l.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 149
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 149
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: aload_2
      //   148: athrow
      //   149: iload_1
      //   150: iconst_1
      //   151: isub
      //   152: istore_1
      //   153: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
    
    boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && u.S(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */