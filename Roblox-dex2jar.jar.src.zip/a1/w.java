package a1;

import android.view.ViewGroup;

public final class w {
  public static boolean a(ViewGroup paramViewGroup) {
    return paramViewGroup.isTransitionGroup();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */