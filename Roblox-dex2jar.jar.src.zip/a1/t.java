package a1;

import android.content.Context;
import android.os.Build;
import android.view.PointerIcon;

public final class t {
  private Object a;
  
  private t(Object paramObject) {
    this.a = paramObject;
  }
  
  public static t b(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 24) ? new t(PointerIcon.getSystemIcon(paramContext, paramInt)) : new t(null);
  }
  
  public Object a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */