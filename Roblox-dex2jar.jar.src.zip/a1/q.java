package a1;

import android.view.View;

public interface q {
  c a(View paramView, c paramc);
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */