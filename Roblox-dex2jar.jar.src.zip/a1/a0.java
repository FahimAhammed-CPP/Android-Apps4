package a1;

import android.view.View;

public class a0 implements z {
  public void onAnimationCancel(View paramView) {}
  
  public void onAnimationStart(View paramView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */