package a1;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class y {
  private WeakReference<View> a;
  
  Runnable b = null;
  
  Runnable c = null;
  
  int d = -1;
  
  y(View paramView) {
    this.a = new WeakReference<View>(paramView);
  }
  
  private void g(View paramView, z paramz) {
    if (paramz != null) {
      paramView.animate().setListener((Animator.AnimatorListener)new a(this, paramz, paramView));
      return;
    } 
    paramView.animate().setListener(null);
  }
  
  public y a(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  public void b() {
    View view = this.a.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long c() {
    View view = this.a.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  public y d(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  public y e(Interpolator paramInterpolator) {
    View view = this.a.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  public y f(z paramz) {
    View view = this.a.get();
    if (view != null)
      g(view, paramz); 
    return this;
  }
  
  public y h(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  public y i(b0 paramb0) {
    View view = this.a.get();
    if (view != null) {
      b b = null;
      if (paramb0 != null)
        b = new b(this, paramb0, view); 
      view.animate().setUpdateListener(b);
    } 
    return this;
  }
  
  public void j() {
    View view = this.a.get();
    if (view != null)
      view.animate().start(); 
  }
  
  public y k(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  class a extends AnimatorListenerAdapter {
    a(y this$0, z param1z, View param1View) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a.onAnimationCancel(this.b);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.onAnimationEnd(this.b);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.onAnimationStart(this.b);
    }
  }
  
  class b implements ValueAnimator.AnimatorUpdateListener {
    b(y this$0, b0 param1b0, View param1View) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */