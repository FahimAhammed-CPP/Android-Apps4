package a1;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;

public final class s implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View n;
  
  private ViewTreeObserver o;
  
  private final Runnable p;
  
  private s(View paramView, Runnable paramRunnable) {
    this.n = paramView;
    this.o = paramView.getViewTreeObserver();
    this.p = paramRunnable;
  }
  
  public static s a(View paramView, Runnable paramRunnable) {
    Objects.requireNonNull(paramView, "view == null");
    Objects.requireNonNull(paramRunnable, "runnable == null");
    s s1 = new s(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(s1);
    paramView.addOnAttachStateChangeListener(s1);
    return s1;
  }
  
  public void b() {
    if (this.o.isAlive()) {
      this.o.removeOnPreDrawListener(this);
    } else {
      this.n.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.n.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.p.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.o = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a1\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */