package a5;

import n4.a;

@Deprecated
public class a extends a {}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */