package aa;

import android.util.Log;
import com.roblox.universalapp.messagebus.Callback;
import com.roblox.universalapp.messagebus.Connection;
import com.roblox.universalapp.messagebus.MessageBus;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import z6.c;

public class b {
  private static b e;
  
  private static final AtomicInteger f = new AtomicInteger();
  
  private static final String g = MessageBus.getMessageId("Experimentation", "userLayerLoadingStatusChanged");
  
  private static final String h = MessageBus.getMessageId("Experimentation", "registerUserLayers");
  
  private static final String i = MessageBus.getMessageId("Experimentation", "initializeUserLayers");
  
  private static final String j = MessageBus.getMessageId("Experimentation", "getUserLayerVariablesRequest");
  
  private static final String k = MessageBus.getMessageId("Experimentation", "getUserLayerVariablesResponse");
  
  private final MessageBus a = MessageBus.c();
  
  private final ArrayList<Connection> b = new ArrayList<Connection>();
  
  private final ArrayList<String> c = new ArrayList<String>();
  
  private final Hashtable<String, JSONObject> d = new Hashtable<String, JSONObject>();
  
  private b() {
    h();
    i();
  }
  
  private void d() {
    for (String str : this.c) {
      try {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("layerName", str);
        this.a.e(j, jSONObject);
      } catch (JSONException jSONException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to construct getUserLayerVariables JSON due to: ");
        stringBuilder.append(jSONException.getMessage());
        Log.e("ExperimentProtocol", stringBuilder.toString());
      } 
    } 
  }
  
  private void g(long paramLong) {
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("userID", paramLong);
      this.a.e(i, jSONObject);
      return;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to construct initializeUserLayers JSON due to: ");
      stringBuilder.append(jSONException.getMessage());
      Log.e("ExperimentProtocol", stringBuilder.toString());
      return;
    } 
  }
  
  private void h() {
    Connection connection = this.a.i(k, new b(this));
    this.b.add(connection);
  }
  
  private void i() {
    Connection connection = this.a.i(g, new a(this));
    this.b.add(connection);
  }
  
  private void k(String[] paramArrayOfString) {
    this.c.addAll(Arrays.asList(paramArrayOfString));
    try {
      JSONArray jSONArray = new JSONArray(paramArrayOfString);
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("userLayers", jSONArray);
      this.a.e(h, jSONObject);
      return;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to construct registerUserLayers JSON due to: ");
      stringBuilder.append(jSONException.getMessage());
      Log.e("ExperimentProtocol", stringBuilder.toString());
      return;
    } 
  }
  
  public static b l() {
    if (f.getAndIncrement() == 0)
      e = new b(); 
    return e;
  }
  
  public void a() {
    this.c.clear();
    this.d.clear();
  }
  
  public JSONObject e(String paramString) {
    return this.d.get(paramString);
  }
  
  public void f(String[] paramArrayOfString, long paramLong) {
    k(paramArrayOfString);
    g(paramLong);
  }
  
  public void j() {
    ArrayList<String> arrayList = new ArrayList();
    if (c.a().q())
      arrayList.add("Backgrounding.General"); 
    if (c.a().O())
      arrayList.add("Engine.Interactivity.UICreation.NotchScreenSupport"); 
    if (!arrayList.isEmpty())
      k(arrayList.<String>toArray(new String[0])); 
  }
  
  class a implements Callback {
    a(b this$0) {}
    
    public void a(JSONObject param1JSONObject) {
      try {
        if (param1JSONObject.getString("status").equals("Initialized")) {
          b.b(this.a);
          return;
        } 
      } catch (JSONException jSONException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Loading status of IXP User Layers is not returned from the MessageBus. File a bug to NFDN component. Error: ");
        stringBuilder.append(jSONException.getMessage());
        Log.e("ExperimentProtocol", stringBuilder.toString());
      } 
    }
  }
  
  class b implements Callback {
    b(b this$0) {}
    
    public void a(JSONObject param1JSONObject) {
      try {
        String str = param1JSONObject.getString("layerName");
        param1JSONObject = new JSONObject(param1JSONObject.getString("layerVariables"));
        b.c(this.a).put(str, param1JSONObject);
        return;
      } catch (JSONException jSONException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get variables from layer. Error: ");
        stringBuilder.append(jSONException.getMessage());
        Log.e("ExperimentProtocol", stringBuilder.toString());
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\aa\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */