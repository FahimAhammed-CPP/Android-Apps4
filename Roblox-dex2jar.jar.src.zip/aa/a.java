package aa;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class a {
  private long a = -1L;
  
  private final long b;
  
  public a(JSONObject paramJSONObject, long paramLong) {
    this.b = paramLong;
    if (paramJSONObject == null) {
      Log.e("BackgroundExperiment", "Background experiment constructed with null JSON payload.");
      return;
    } 
    try {
      this.a = paramJSONObject.getLong("background_delay");
      return;
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to get background delay from JSON payload. Error: ");
      stringBuilder.append(jSONException.getMessage());
      Log.e("BackgroundExperiment", stringBuilder.toString());
      return;
    } 
  }
  
  public long a() {
    long l2 = this.a;
    long l1 = l2;
    if (l2 == -1L)
      l1 = this.b; 
    return l1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\aa\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */