package aa;

import android.util.Log;
import java.util.Arrays;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
  private boolean a = false;
  
  private List<String> b;
  
  public c(JSONObject paramJSONObject, long paramLong) {
    if (paramJSONObject == null) {
      Log.e("NotchScreenSupportExp", "NotchScreenSupportExperiment constructed with null JSON payload.");
      return;
    } 
    try {
      this.a = paramJSONObject.getBoolean("notchEnabled");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Got notch support enabled value: ");
      stringBuilder.append(this.a);
      Log.i("NotchScreenSupportExp", stringBuilder.toString());
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to get notch support enabled value from JSON payload. Error: ");
      stringBuilder.append(jSONException.getMessage());
      Log.e("NotchScreenSupportExp", stringBuilder.toString());
    } 
    if (z6.c.a().f0()) {
      this.b = Arrays.asList(z6.c.a().U0().split(";"));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Checking notch experiment value for place: ");
      stringBuilder.append(paramLong);
      Log.i("NotchScreenSupportExp", stringBuilder.toString());
      if (this.b.contains(Long.toString(paramLong))) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Notch support blocked for place: ");
        stringBuilder.append(paramLong);
        Log.i("NotchScreenSupportExp", stringBuilder.toString());
        this.a = false;
      } 
    } 
  }
  
  public boolean a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\aa\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */