package androidx.activity;

import androidx.lifecycle.l;

public interface c extends l {
  OnBackPressedDispatcher k();
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\activity\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */