package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(l paraml, b paramb) {
    f f = paraml.f();
    if (f.b() == f.c.n)
      return; 
    paramb.a(new LifecycleOnBackPressedCancellable(this, f, paramb));
  }
  
  a b(b paramb) {
    this.b.add(paramb);
    a a = new a(this, paramb);
    paramb.a(a);
    return a;
  }
  
  public void c() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.c()) {
        b.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  private class LifecycleOnBackPressedCancellable implements j, a {
    private final f n;
    
    private final b o;
    
    private a p;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, f param1f, b param1b) {
      this.n = param1f;
      this.o = param1b;
      param1f.a((k)this);
    }
    
    public void cancel() {
      this.n.c((k)this);
      this.o.e(this);
      a a1 = this.p;
      if (a1 != null) {
        a1.cancel();
        this.p = null;
      } 
    }
    
    public void e(l param1l, f.b param1b) {
      if (param1b == f.b.ON_START) {
        this.p = this.q.b(this.o);
        return;
      } 
      if (param1b == f.b.ON_STOP) {
        a a1 = this.p;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == f.b.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  private class a implements a {
    private final b n;
    
    a(OnBackPressedDispatcher this$0, b param1b) {
      this.n = param1b;
    }
    
    public void cancel() {
      this.o.b.remove(this.n);
      this.n.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */