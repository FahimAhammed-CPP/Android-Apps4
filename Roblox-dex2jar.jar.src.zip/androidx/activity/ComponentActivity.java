package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.a;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.lifecycle.a0;
import androidx.lifecycle.b0;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.v;
import androidx.lifecycle.y;
import androidx.lifecycle.z;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;
import p0.f;

public class ComponentActivity extends f implements z, c, c, c {
  final b.a p = new b.a();
  
  private final m q = new m(this);
  
  final androidx.savedstate.b r = androidx.savedstate.b.a(this);
  
  private y s;
  
  private final OnBackPressedDispatcher t = new OnBackPressedDispatcher(new a(this));
  
  private int u;
  
  private final AtomicInteger v = new AtomicInteger();
  
  private final ActivityResultRegistry w = new b(this);
  
  public ComponentActivity() {
    if (f() != null) {
      int i = Build.VERSION.SDK_INT;
      f().a((k)new j(this) {
            public void e(l param1l, f.b param1b) {
              if (param1b == f.b.ON_STOP) {
                Window window = this.n.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  window.cancelPendingInputEvents(); 
              } 
            }
          });
      f().a((k)new j(this) {
            public void e(l param1l, f.b param1b) {
              if (param1b == f.b.ON_DESTROY) {
                this.n.p.b();
                if (!this.n.isChangingConfigurations())
                  this.n.j0().a(); 
              } 
            }
          });
      f().a((k)new j(this) {
            public void e(l param1l, f.b param1b) {
              this.n.x0();
              this.n.f().c((k)this);
            }
          });
      if (i <= 23)
        f().a((k)new ImmLeaksCleaner((Activity)this)); 
      l().d("android:support:activity-result", new c(this));
      w0(new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private void y0() {
    a0.a(getWindow().getDecorView(), this);
    b0.a(getWindow().getDecorView(), this);
    androidx.savedstate.d.a(getWindow().getDecorView(), this);
  }
  
  public final <I, O> b<I> A0(c.a<I, O> parama, a<O> parama1) {
    return B0(parama, this.w, parama1);
  }
  
  public final <I, O> b<I> B0(c.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, a<O> parama1) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.v.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, parama1);
  }
  
  public final ActivityResultRegistry a0() {
    return this.w;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    y0();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public f f() {
    return (f)this.q;
  }
  
  public y j0() {
    if (getApplication() != null) {
      x0();
      return this.s;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final OnBackPressedDispatcher k() {
    return this.t;
  }
  
  public final SavedStateRegistry l() {
    return this.r.b();
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.w.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.t.c();
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.r.c(paramBundle);
    this.p.c((Context)this);
    super.onCreate(paramBundle);
    v.g((Activity)this);
    int i = this.u;
    if (i != 0)
      setContentView(i); 
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.w.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = z0();
    y y2 = this.s;
    y y1 = y2;
    if (y2 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      y1 = y2;
      if (e1 != null)
        y1 = e1.b; 
    } 
    if (y1 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = y1;
    return e;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    f f1 = f();
    if (f1 instanceof m)
      ((m)f1).o(f.c.p); 
    super.onSaveInstanceState(paramBundle);
    this.r.d(paramBundle);
  }
  
  public void reportFullyDrawn() {
    try {
      if (p1.a.d()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        p1.a.a(stringBuilder.toString());
      } 
      super.reportFullyDrawn();
      return;
    } finally {
      p1.a.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    y0();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    y0();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    y0();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public final void w0(b.b paramb) {
    this.p.a(paramb);
  }
  
  void x0() {
    if (this.s == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.s = e.b; 
      if (this.s == null)
        this.s = new y(); 
    } 
  }
  
  @Deprecated
  public Object z0() {
    return null;
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.u0(this.n);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, c.a<I, O> param1a, I param1I, p0.b param1b) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      IntentSenderRequest intentSenderRequest;
      ComponentActivity componentActivity = this.i;
      c.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      param1a = null;
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        p0.a.m((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        intentSenderRequest = (IntentSenderRequest)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          p0.a.p((Activity)componentActivity, intentSenderRequest.d(), param1Int, intentSenderRequest.a(), intentSenderRequest.b(), intentSenderRequest.c(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      p0.a.o((Activity)componentActivity, (Intent)intentSenderRequest, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, c.a.a param2a) {}
      
      public void run() {
        this.p.c(this.n, this.o.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.p.b(this.n, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.o));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, c.a.a param1a) {}
    
    public void run() {
      this.p.c(this.n, this.o.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.p.b(this.n, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.o));
    }
  }
  
  class c implements SavedStateRegistry.b {
    c(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public Bundle a() {
      Bundle bundle = new Bundle();
      ComponentActivity.v0(this.a).h(bundle);
      return bundle;
    }
  }
  
  class d implements b.b {
    d(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Context param1Context) {
      Bundle bundle = this.a.l().a("android:support:activity-result");
      if (bundle != null)
        ComponentActivity.v0(this.a).g(bundle); 
    }
  }
  
  static final class e {
    Object a;
    
    y b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */