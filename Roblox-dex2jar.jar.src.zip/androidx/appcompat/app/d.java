package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import e.a;
import h0.b;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class d {
  private static int n = -100;
  
  private static final b<WeakReference<d>> o = new b();
  
  private static final Object p = new Object();
  
  static void c(d paramd) {
    synchronized (p) {
      y(paramd);
      o.add(new WeakReference<d>(paramd));
      return;
    } 
  }
  
  public static d g(Activity paramActivity, a parama) {
    return new e(paramActivity, parama);
  }
  
  public static d h(Dialog paramDialog, a parama) {
    return new e(paramDialog, parama);
  }
  
  public static int j() {
    return n;
  }
  
  static void x(d paramd) {
    synchronized (p) {
      y(paramd);
      return;
    } 
  }
  
  private static void y(d paramd) {
    synchronized (p) {
      Iterator<WeakReference<d>> iterator = o.iterator();
      while (iterator.hasNext()) {
        d d1 = ((WeakReference<d>)iterator.next()).get();
        if (d1 == paramd || d1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract void A(int paramInt);
  
  public abstract void B(View paramView);
  
  public abstract void C(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void D(int paramInt) {}
  
  public abstract void E(CharSequence paramCharSequence);
  
  public abstract void d(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  @Deprecated
  public void e(Context paramContext) {}
  
  public Context f(Context paramContext) {
    e(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T i(int paramInt);
  
  public int k() {
    return -100;
  }
  
  public abstract MenuInflater l();
  
  public abstract a m();
  
  public abstract void n();
  
  public abstract void o();
  
  public abstract void p(Configuration paramConfiguration);
  
  public abstract void q(Bundle paramBundle);
  
  public abstract void r();
  
  public abstract void s(Bundle paramBundle);
  
  public abstract void t();
  
  public abstract void u(Bundle paramBundle);
  
  public abstract void v();
  
  public abstract void w();
  
  public abstract boolean z(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */