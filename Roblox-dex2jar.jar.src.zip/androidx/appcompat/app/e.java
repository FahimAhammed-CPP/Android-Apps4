package androidx.appcompat.app;

import a1.a0;
import a1.c0;
import a1.u;
import a1.y;
import a1.z;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.AppCompatDrawableManager;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.DecorContentParent;
import androidx.appcompat.widget.TintTypedArray;
import androidx.appcompat.widget.VectorEnabledTintResources;
import androidx.appcompat.widget.ViewUtils;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class e extends d implements e.a, LayoutInflater.Factory2 {
  private static final h0.g<String, Integer> o0 = new h0.g();
  
  private static final boolean p0 = false;
  
  private static final int[] q0 = new int[] { 16842836 };
  
  private static final boolean r0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean s0 = true;
  
  private s A;
  
  j.b B;
  
  ActionBarContextView C;
  
  PopupWindow D;
  
  Runnable E;
  
  y F = null;
  
  private boolean G = true;
  
  private boolean H;
  
  ViewGroup I;
  
  private TextView J;
  
  private View K;
  
  private boolean L;
  
  private boolean M;
  
  boolean N;
  
  boolean O;
  
  boolean P;
  
  boolean Q;
  
  boolean R;
  
  private boolean S;
  
  private r[] T;
  
  private r U;
  
  private boolean V;
  
  private boolean W;
  
  private boolean X;
  
  private boolean Y;
  
  boolean Z;
  
  private int a0 = -100;
  
  private int b0;
  
  private boolean c0;
  
  private boolean d0;
  
  private n e0;
  
  private n f0;
  
  boolean g0;
  
  int h0;
  
  private final Runnable i0 = new a(this);
  
  private boolean j0;
  
  private Rect k0;
  
  private Rect l0;
  
  private f m0;
  
  private g n0;
  
  final Object q;
  
  final Context r;
  
  Window s;
  
  private l t;
  
  final e.a u;
  
  a v;
  
  MenuInflater w;
  
  private CharSequence x;
  
  private DecorContentParent y;
  
  private f z;
  
  e(Activity paramActivity, e.a parama) {
    this((Context)paramActivity, null, parama, paramActivity);
  }
  
  e(Dialog paramDialog, e.a parama) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parama, paramDialog);
  }
  
  private e(Context paramContext, Window paramWindow, e.a parama, Object paramObject) {
    this.r = paramContext;
    this.u = parama;
    this.q = paramObject;
    if (this.a0 == -100 && paramObject instanceof Dialog) {
      c c = I0();
      if (c != null)
        this.a0 = c.M0().k(); 
    } 
    if (this.a0 == -100) {
      h0.g<String, Integer> g1 = o0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.a0 = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      I(paramWindow); 
    AppCompatDrawableManager.preload();
  }
  
  private boolean A0(r paramr, KeyEvent paramKeyEvent) {
    DecorContentParent decorContentParent;
    if (this.Z)
      return false; 
    if (paramr.m)
      return true; 
    r r1 = this.U;
    if (r1 != null && r1 != paramr)
      O(r1, false); 
    Window.Callback callback = f0();
    if (callback != null)
      paramr.i = callback.onCreatePanelView(paramr.a); 
    int i = paramr.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      DecorContentParent decorContentParent1 = this.y;
      if (decorContentParent1 != null)
        decorContentParent1.setMenuPrepared(); 
    } 
    if (paramr.i == null) {
      DecorContentParent decorContentParent1;
      boolean bool;
      if (i != 0)
        y0(); 
      e e1 = paramr.j;
      if (e1 == null || paramr.r) {
        if (e1 == null && (!j0(paramr) || paramr.j == null))
          return false; 
        if (i != 0 && this.y != null) {
          if (this.z == null)
            this.z = new f(this); 
          this.y.setMenu((Menu)paramr.j, this.z);
        } 
        paramr.j.d0();
        if (!callback.onCreatePanelMenu(paramr.a, (Menu)paramr.j)) {
          paramr.c(null);
          if (i != 0) {
            decorContentParent = this.y;
            if (decorContentParent != null)
              decorContentParent.setMenu(null, this.z); 
          } 
          return false;
        } 
        ((r)decorContentParent).r = false;
      } 
      ((r)decorContentParent).j.d0();
      Bundle bundle = ((r)decorContentParent).s;
      if (bundle != null) {
        ((r)decorContentParent).j.P(bundle);
        ((r)decorContentParent).s = null;
      } 
      if (!callback.onPreparePanel(0, ((r)decorContentParent).i, (Menu)((r)decorContentParent).j)) {
        if (i != 0) {
          decorContentParent1 = this.y;
          if (decorContentParent1 != null)
            decorContentParent1.setMenu(null, this.z); 
        } 
        ((r)decorContentParent).j.c0();
        return false;
      } 
      if (decorContentParent1 != null) {
        i = decorContentParent1.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((r)decorContentParent).p = bool;
      ((r)decorContentParent).j.setQwertyMode(bool);
      ((r)decorContentParent).j.c0();
    } 
    ((r)decorContentParent).m = true;
    ((r)decorContentParent).n = false;
    this.U = (r)decorContentParent;
    return true;
  }
  
  private void B0(boolean paramBoolean) {
    DecorContentParent decorContentParent = this.y;
    if (decorContentParent != null && decorContentParent.canShowOverflowMenu() && (!ViewConfiguration.get(this.r).hasPermanentMenuKey() || this.y.isOverflowMenuShowPending())) {
      Window.Callback callback = f0();
      if (!this.y.isOverflowMenuShowing() || !paramBoolean) {
        if (callback != null && !this.Z) {
          if (this.g0 && (this.h0 & 0x1) != 0) {
            this.s.getDecorView().removeCallbacks(this.i0);
            this.i0.run();
          } 
          r r2 = d0(0, true);
          e e1 = r2.j;
          if (e1 != null && !r2.r && callback.onPreparePanel(0, r2.i, (Menu)e1)) {
            callback.onMenuOpened(108, (Menu)r2.j);
            this.y.showOverflowMenu();
          } 
        } 
        return;
      } 
      this.y.hideOverflowMenu();
      if (!this.Z) {
        callback.onPanelClosed(108, (Menu)(d0(0, true)).j);
        return;
      } 
      return;
    } 
    r r1 = d0(0, true);
    r1.q = true;
    O(r1, false);
    x0(r1, null);
  }
  
  private int C0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean E0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.s.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (u.S((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private boolean G(boolean paramBoolean) {
    if (this.Z)
      return false; 
    int i = J();
    paramBoolean = J0(n0(this.r, i), paramBoolean);
    if (i == 0) {
      c0(this.r).e();
    } else {
      n n2 = this.e0;
      if (n2 != null)
        n2.a(); 
    } 
    if (i == 3) {
      b0(this.r).e();
      return paramBoolean;
    } 
    n n1 = this.f0;
    if (n1 != null)
      n1.a(); 
    return paramBoolean;
  }
  
  private void H() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.I.findViewById(16908290);
    View view = this.s.getDecorView();
    contentFrameLayout.setDecorPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.r.obtainStyledAttributes(d.j.B0);
    typedArray.getValue(d.j.N0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(d.j.O0, contentFrameLayout.getMinWidthMinor());
    int i = d.j.L0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = d.j.M0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = d.j.J0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = d.j.K0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void H0() {
    if (!this.H)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void I(Window paramWindow) {
    if (this.s == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof l)) {
        l l1 = new l(this, callback);
        this.t = l1;
        paramWindow.setCallback((Window.Callback)l1);
        TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(this.r, null, q0);
        Drawable drawable = tintTypedArray.getDrawableIfKnown(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        tintTypedArray.recycle();
        this.s = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private c I0() {
    Context context = this.r;
    while (context != null) {
      if (context instanceof c)
        return (c)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private int J() {
    int i = this.a0;
    return (i != -100) ? i : d.j();
  }
  
  private boolean J0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield r : Landroid/content/Context;
    //   5: iload_1
    //   6: aconst_null
    //   7: invokespecial P : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   10: astore #7
    //   12: aload_0
    //   13: invokespecial l0 : ()Z
    //   16: istore #6
    //   18: aload_0
    //   19: getfield r : Landroid/content/Context;
    //   22: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   25: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   28: getfield uiMode : I
    //   31: bipush #48
    //   33: iand
    //   34: istore_3
    //   35: aload #7
    //   37: getfield uiMode : I
    //   40: bipush #48
    //   42: iand
    //   43: istore #4
    //   45: iconst_1
    //   46: istore #5
    //   48: iload_3
    //   49: iload #4
    //   51: if_icmpeq -> 123
    //   54: iload_2
    //   55: ifeq -> 123
    //   58: iload #6
    //   60: ifne -> 123
    //   63: aload_0
    //   64: getfield W : Z
    //   67: ifeq -> 123
    //   70: getstatic androidx/appcompat/app/e.r0 : Z
    //   73: ifne -> 83
    //   76: aload_0
    //   77: getfield X : Z
    //   80: ifeq -> 123
    //   83: aload_0
    //   84: getfield q : Ljava/lang/Object;
    //   87: astore #7
    //   89: aload #7
    //   91: instanceof android/app/Activity
    //   94: ifeq -> 123
    //   97: aload #7
    //   99: checkcast android/app/Activity
    //   102: invokevirtual isChild : ()Z
    //   105: ifne -> 123
    //   108: aload_0
    //   109: getfield q : Ljava/lang/Object;
    //   112: checkcast android/app/Activity
    //   115: invokestatic l : (Landroid/app/Activity;)V
    //   118: iconst_1
    //   119: istore_2
    //   120: goto -> 125
    //   123: iconst_0
    //   124: istore_2
    //   125: iload_2
    //   126: ifne -> 150
    //   129: iload_3
    //   130: iload #4
    //   132: if_icmpeq -> 150
    //   135: aload_0
    //   136: iload #4
    //   138: iload #6
    //   140: aconst_null
    //   141: invokespecial K0 : (IZLandroid/content/res/Configuration;)V
    //   144: iload #5
    //   146: istore_2
    //   147: goto -> 150
    //   150: iload_2
    //   151: ifeq -> 177
    //   154: aload_0
    //   155: getfield q : Ljava/lang/Object;
    //   158: astore #7
    //   160: aload #7
    //   162: instanceof androidx/appcompat/app/c
    //   165: ifeq -> 177
    //   168: aload #7
    //   170: checkcast androidx/appcompat/app/c
    //   173: iload_1
    //   174: invokevirtual Q0 : (I)V
    //   177: iload_2
    //   178: ireturn
  }
  
  private void K0(int paramInt, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.r.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      h.a(resources); 
    int i = this.b0;
    if (i != 0) {
      this.r.setTheme(i);
      if (paramInt >= 23)
        this.r.getTheme().applyStyle(this.b0, true); 
    } 
    if (paramBoolean) {
      Object object = this.q;
      if (object instanceof Activity) {
        object = object;
        if (object instanceof androidx.lifecycle.l) {
          if (((androidx.lifecycle.l)object).f().b().b(androidx.lifecycle.f.c.q)) {
            object.onConfigurationChanged(configuration);
            return;
          } 
        } else if (this.Y) {
          object.onConfigurationChanged(configuration);
        } 
      } 
    } 
  }
  
  private void M() {
    n n1 = this.e0;
    if (n1 != null)
      n1.a(); 
    n1 = this.f0;
    if (n1 != null)
      n1.a(); 
  }
  
  private void M0(View paramView) {
    int i;
    if ((u.M(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = q0.a.c(this.r, d.c.b);
    } else {
      i = q0.a.c(this.r, d.c.a);
    } 
    paramView.setBackgroundColor(i);
  }
  
  private Configuration P(Context paramContext, int paramInt, Configuration paramConfiguration) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  private ViewGroup Q() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.r.obtainStyledAttributes(d.j.B0);
    int i = d.j.G0;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(d.j.P0, false)) {
        z(1);
      } else if (typedArray.getBoolean(i, false)) {
        z(108);
      } 
      if (typedArray.getBoolean(d.j.H0, false))
        z(109); 
      if (typedArray.getBoolean(d.j.I0, false))
        z(10); 
      this.Q = typedArray.getBoolean(d.j.C0, false);
      typedArray.recycle();
      X();
      this.s.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.r);
      if (!this.R) {
        if (this.Q) {
          viewGroup = (ViewGroup)layoutInflater.inflate(d.g.h, null);
          this.O = false;
          this.N = false;
        } else if (this.N) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.r.getTheme().resolveAttribute(d.a.g, typedValue, true);
          if (typedValue.resourceId != 0) {
            j.d d1 = new j.d(this.r, typedValue.resourceId);
          } else {
            context = this.r;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(d.g.r, null);
          DecorContentParent decorContentParent = (DecorContentParent)viewGroup1.findViewById(d.f.q);
          this.y = decorContentParent;
          decorContentParent.setWindowCallback(f0());
          if (this.O)
            this.y.initFeature(109); 
          if (this.L)
            this.y.initFeature(2); 
          viewGroup = viewGroup1;
          if (this.M) {
            this.y.initFeature(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.P) {
        viewGroup = (ViewGroup)layoutInflater.inflate(d.g.q, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(d.g.p, null);
      } 
      if (viewGroup != null) {
        u.z0((View)viewGroup, new b(this));
        if (this.y == null)
          this.J = (TextView)viewGroup.findViewById(d.f.S); 
        ViewUtils.makeOptionalFitsSystemWindows((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(d.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.s.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.s.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.N);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.O);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.Q);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.P);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.R);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void W() {
    if (!this.H) {
      this.I = Q();
      CharSequence charSequence = e0();
      if (!TextUtils.isEmpty(charSequence)) {
        DecorContentParent decorContentParent = this.y;
        if (decorContentParent != null) {
          decorContentParent.setWindowTitle(charSequence);
        } else if (y0() != null) {
          y0().n(charSequence);
        } else {
          TextView textView = this.J;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      H();
      w0(this.I);
      this.H = true;
      r r1 = d0(0, false);
      if (!this.Z && (r1 == null || r1.j == null))
        k0(108); 
    } 
  }
  
  private void X() {
    if (this.s == null) {
      Object object = this.q;
      if (object instanceof Activity)
        I(((Activity)object).getWindow()); 
    } 
    if (this.s != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration Z(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        j.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!z0.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        k.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      h.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private n b0(Context paramContext) {
    if (this.f0 == null)
      this.f0 = new m(this, paramContext); 
    return this.f0;
  }
  
  private n c0(Context paramContext) {
    if (this.e0 == null)
      this.e0 = new o(this, j.a(paramContext)); 
    return this.e0;
  }
  
  private void g0() {
    W();
    if (this.N) {
      if (this.v != null)
        return; 
      Object object = this.q;
      if (object instanceof Activity) {
        this.v = new k((Activity)this.q, this.O);
      } else if (object instanceof Dialog) {
        this.v = new k((Dialog)this.q);
      } 
      object = this.v;
      if (object != null)
        object.l(this.j0); 
    } 
  }
  
  private boolean h0(r paramr) {
    View view = paramr.i;
    if (view != null) {
      paramr.h = view;
      return true;
    } 
    if (paramr.j == null)
      return false; 
    if (this.A == null)
      this.A = new s(this); 
    view = (View)paramr.a(this.A);
    paramr.h = view;
    return (view != null);
  }
  
  private boolean i0(r paramr) {
    paramr.d(a0());
    paramr.g = (ViewGroup)new q(this, paramr.l);
    paramr.c = 81;
    return true;
  }
  
  private boolean j0(r paramr) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic d/a.g : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #6
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #7
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #6
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic d/a.h : I
    //   101: aload #6
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #7
    //   113: getstatic d/a.h : I
    //   116: aload #6
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new j/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/e
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual R : (Landroidx/appcompat/view/menu/e$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/e;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void k0(int paramInt) {
    this.h0 = 1 << paramInt | this.h0;
    if (!this.g0) {
      u.g0(this.s.getDecorView(), this.i0);
      this.g0 = true;
    } 
  }
  
  private boolean l0() {
    if (!this.d0 && this.q instanceof Activity) {
      PackageManager packageManager = this.r.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.r, this.q.getClass()), i);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.c0 = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.c0 = false;
      } 
    } 
    this.d0 = true;
    return this.c0;
  }
  
  private boolean q0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      r r1 = d0(paramInt, true);
      if (!r1.o)
        return A0(r1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean t0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield B : Lj/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual d0 : (IZ)Landroidx/appcompat/app/e$r;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface canShowOverflowMenu : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield r : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   62: invokeinterface isOverflowMenuShowing : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield Z : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial A0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   91: invokeinterface showOverflowMenu : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   104: invokeinterface hideOverflowMenu : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial A0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial x0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual O : (Landroidx/appcompat/app/e$r;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield r : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void x0(r paramr, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 405
    //   7: aload_0
    //   8: getfield Z : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield r : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual f0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/e;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual O : (Landroidx/appcompat/app/e$r;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield r : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial A0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial i0 : (Landroidx/appcompat/app/e$r;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial h0 : (Landroidx/appcompat/app/e$r;)Z
    //   217: ifeq -> 400
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 400
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: return
    //   400: aload_1
    //   401: iconst_1
    //   402: putfield q : Z
    //   405: return
  }
  
  private boolean z0(r paramr, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial A0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/e;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield y : Landroidx/appcompat/widget/DecorContentParent;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual O : (Landroidx/appcompat/app/e$r;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  public void A(int paramInt) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.I.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.r).inflate(paramInt, viewGroup);
    this.t.a().onContentChanged();
  }
  
  public void B(View paramView) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.I.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.t.a().onContentChanged();
  }
  
  public void C(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    W();
    ViewGroup viewGroup = (ViewGroup)this.I.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.t.a().onContentChanged();
  }
  
  public void D(int paramInt) {
    this.b0 = paramInt;
  }
  
  final boolean D0() {
    if (this.H) {
      ViewGroup viewGroup = this.I;
      if (viewGroup != null && u.T((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public final void E(CharSequence paramCharSequence) {
    this.x = paramCharSequence;
    DecorContentParent decorContentParent = this.y;
    if (decorContentParent != null) {
      decorContentParent.setWindowTitle(paramCharSequence);
      return;
    } 
    if (y0() != null) {
      y0().n(paramCharSequence);
      return;
    } 
    TextView textView = this.J;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean F() {
    return G(true);
  }
  
  public j.b F0(j.b.a parama) {
    if (parama != null) {
      j.b b1 = this.B;
      if (b1 != null)
        b1.c(); 
      parama = new g(this, parama);
      a a1 = m();
      if (a1 != null) {
        j.b b2 = a1.o(parama);
        this.B = b2;
        if (b2 != null) {
          e.a a2 = this.u;
          if (a2 != null)
            a2.g0(b2); 
        } 
      } 
      if (this.B == null)
        this.B = G0(parama); 
      return this.B;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  j.b G0(j.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual V : ()V
    //   4: aload_0
    //   5: getfield B : Lj/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/e$g
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/e$g
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/e;Lj/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield u : Le/a;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield Z : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface Z : (Lj/b$a;)Lj/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield B : Lj/b;
    //   80: goto -> 574
    //   83: aload_0
    //   84: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield Q : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield r : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic d/a.g : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield r : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new j/d
    //   169: dup
    //   170: aload_0
    //   171: getfield r : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield r : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic d/a.j : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield D : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield D : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield D : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic d/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield D : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/e$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/e;)V
    //   309: putfield E : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield I : Landroid/view/ViewGroup;
    //   319: getstatic d/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual a0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual inflate : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 574
    //   362: aload_0
    //   363: invokevirtual V : ()V
    //   366: aload_0
    //   367: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual killMode : ()V
    //   373: aload_0
    //   374: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield D : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new j/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Lj/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Lj/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 569
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual initForMode : (Lj/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield B : Lj/b;
    //   445: aload_0
    //   446: invokevirtual D0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic d : (Landroid/view/View;)La1/y;
    //   467: fconst_1
    //   468: invokevirtual a : (F)La1/y;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield F : La1/y;
    //   477: aload_1
    //   478: new androidx/appcompat/app/e$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/e;)V
    //   486: invokevirtual f : (La1/z;)La1/y;
    //   489: pop
    //   490: goto -> 544
    //   493: aload_0
    //   494: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: bipush #32
    //   515: invokevirtual sendAccessibilityEvent : (I)V
    //   518: aload_0
    //   519: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   522: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   525: instanceof android/view/View
    //   528: ifeq -> 544
    //   531: aload_0
    //   532: getfield C : Landroidx/appcompat/widget/ActionBarContextView;
    //   535: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   538: checkcast android/view/View
    //   541: invokestatic l0 : (Landroid/view/View;)V
    //   544: aload_0
    //   545: getfield D : Landroid/widget/PopupWindow;
    //   548: ifnull -> 574
    //   551: aload_0
    //   552: getfield s : Landroid/view/Window;
    //   555: invokevirtual getDecorView : ()Landroid/view/View;
    //   558: aload_0
    //   559: getfield E : Ljava/lang/Runnable;
    //   562: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   565: pop
    //   566: goto -> 574
    //   569: aload_0
    //   570: aconst_null
    //   571: putfield B : Lj/b;
    //   574: aload_0
    //   575: getfield B : Lj/b;
    //   578: astore_1
    //   579: aload_1
    //   580: ifnull -> 602
    //   583: aload_0
    //   584: getfield u : Le/a;
    //   587: astore #4
    //   589: aload #4
    //   591: ifnull -> 602
    //   594: aload #4
    //   596: aload_1
    //   597: invokeinterface g0 : (Lj/b;)V
    //   602: aload_0
    //   603: getfield B : Lj/b;
    //   606: areturn
    //   607: astore_1
    //   608: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	607	java/lang/AbstractMethodError
  }
  
  void K(int paramInt, r paramr, Menu paramMenu) {
    e e1;
    r r1 = paramr;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      r r2 = paramr;
      if (paramr == null) {
        r2 = paramr;
        if (paramInt >= 0) {
          r[] arrayOfR = this.T;
          r2 = paramr;
          if (paramInt < arrayOfR.length)
            r2 = arrayOfR[paramInt]; 
        } 
      } 
      r1 = r2;
      menu = paramMenu;
      if (r2 != null) {
        e1 = r2.j;
        r1 = r2;
      } 
    } 
    if (r1 != null && !r1.o)
      return; 
    if (!this.Z)
      this.t.a().onPanelClosed(paramInt, (Menu)e1); 
  }
  
  void L(e parame) {
    if (this.S)
      return; 
    this.S = true;
    this.y.dismissPopups();
    Window.Callback callback = f0();
    if (callback != null && !this.Z)
      callback.onPanelClosed(108, (Menu)parame); 
    this.S = false;
  }
  
  final int L0(c0 paramc0, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramc0 != null) {
      i = paramc0.l();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.C;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.C.getLayoutParams();
      boolean bool3 = this.C.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.k0 == null) {
          this.k0 = new Rect();
          this.l0 = new Rect();
        } 
        Rect rect1 = this.k0;
        Rect rect2 = this.l0;
        if (paramc0 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramc0.j(), paramc0.l(), paramc0.k(), paramc0.i());
        } 
        ViewUtils.computeFitSystemWindows((View)this.I, rect1, rect2);
        int i1 = rect1.top;
        bool = rect1.left;
        int i2 = rect1.right;
        paramc0 = u.J((View)this.I);
        if (paramc0 == null) {
          k = 0;
        } else {
          k = paramc0.j();
        } 
        if (paramc0 == null) {
          m = 0;
        } else {
          m = paramc0.k();
        } 
        if (marginLayoutParams.topMargin != i1 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i2) {
          marginLayoutParams.topMargin = i1;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i2;
          bool = true;
        } else {
          bool = false;
        } 
        if (i1 > 0 && this.K == null) {
          View view2 = new View(this.r);
          this.K = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.I.addView(this.K, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.K;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i1 = marginLayoutParams1.height;
            i2 = marginLayoutParams.topMargin;
            if (i1 != i2 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i2;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.K.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.K;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          M0(this.K); 
        k = i;
        if (!this.P) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.C.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.K;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  void N(int paramInt) {
    O(d0(paramInt, true), true);
  }
  
  void O(r paramr, boolean paramBoolean) {
    if (paramBoolean && paramr.a == 0) {
      DecorContentParent decorContentParent = this.y;
      if (decorContentParent != null && decorContentParent.isOverflowMenuShowing()) {
        L(paramr.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.r.getSystemService("window");
    if (windowManager != null && paramr.o) {
      ViewGroup viewGroup = paramr.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          K(paramr.a, paramr, null); 
      } 
    } 
    paramr.m = false;
    paramr.n = false;
    paramr.o = false;
    paramr.h = null;
    paramr.q = true;
    if (this.U == paramr)
      this.U = null; 
  }
  
  public View R(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    f f1 = this.m0;
    boolean bool1 = false;
    if (f1 == null) {
      String str = this.r.obtainStyledAttributes(d.j.B0).getString(d.j.F0);
      if (str == null) {
        this.m0 = new f();
      } else {
        try {
          this.m0 = Class.forName(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = p0;
    if (bool2) {
      if (this.n0 == null)
        this.n0 = new g(); 
      if (this.n0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = E0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.m0.q(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, VectorEnabledTintResources.shouldBeUsed());
  }
  
  void S() {
    DecorContentParent decorContentParent = this.y;
    if (decorContentParent != null)
      decorContentParent.dismissPopups(); 
    if (this.D != null) {
      this.s.getDecorView().removeCallbacks(this.E);
      if (this.D.isShowing())
        try {
          this.D.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.D = null;
    } 
    V();
    r r1 = d0(0, false);
    if (r1 != null) {
      e e1 = r1.j;
      if (e1 != null)
        e1.close(); 
    } 
  }
  
  boolean T(KeyEvent paramKeyEvent) {
    Object object = this.q;
    boolean bool1 = object instanceof a1.f.a;
    boolean bool = true;
    if (bool1 || object instanceof e.b) {
      object = this.s.getDecorView();
      if (object != null && a1.f.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.t.a().dispatchKeyEvent(paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? p0(i, paramKeyEvent) : s0(i, paramKeyEvent);
  }
  
  void U(int paramInt) {
    r r1 = d0(paramInt, true);
    if (r1.j != null) {
      Bundle bundle = new Bundle();
      r1.j.Q(bundle);
      if (bundle.size() > 0)
        r1.s = bundle; 
      r1.j.d0();
      r1.j.clear();
    } 
    r1.r = true;
    r1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.y != null) {
      r1 = d0(0, false);
      if (r1 != null) {
        r1.m = false;
        A0(r1, null);
      } 
    } 
  }
  
  void V() {
    y y1 = this.F;
    if (y1 != null)
      y1.b(); 
  }
  
  r Y(Menu paramMenu) {
    byte b1;
    r[] arrayOfR = this.T;
    int i = 0;
    if (arrayOfR != null) {
      b1 = arrayOfR.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      r r1 = arrayOfR[i];
      if (r1 != null && r1.j == paramMenu)
        return r1; 
      i++;
    } 
    return null;
  }
  
  public boolean a(e parame, MenuItem paramMenuItem) {
    Window.Callback callback = f0();
    if (callback != null && !this.Z) {
      r r1 = Y((Menu)parame.D());
      if (r1 != null)
        return callback.onMenuItemSelected(r1.a, paramMenuItem); 
    } 
    return false;
  }
  
  final Context a0() {
    Context context;
    a a1 = m();
    if (a1 != null) {
      Context context1 = a1.e();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.r; 
    return context;
  }
  
  public void b(e parame) {
    B0(true);
  }
  
  public void d(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    W();
    ((ViewGroup)this.I.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.t.a().onContentChanged();
  }
  
  protected r d0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield T : [Landroidx/appcompat/app/e$r;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/e$r
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield T : [Landroidx/appcompat/app/e$r;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/e$r
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence e0() {
    Object object = this.q;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.x;
  }
  
  public Context f(Context paramContext) {
    int i = 1;
    this.W = true;
    int j = n0(paramContext, J());
    boolean bool = s0;
    Configuration configuration1 = null;
    if (bool && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = P(paramContext, j, null);
      try {
        p.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof j.d) {
      Configuration configuration = P(paramContext, j, null);
      try {
        ((j.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!r0)
      return super.f(paramContext); 
    Configuration configuration2 = new Configuration();
    configuration2.uiMode = -1;
    configuration2.fontScale = 0.0F;
    configuration2 = h.a(paramContext, configuration2).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration2.uiMode = configuration3.uiMode;
    if (!configuration2.equals(configuration3))
      configuration1 = Z(configuration2, configuration3); 
    configuration2 = P(paramContext, j, configuration1);
    j.d d1 = new j.d(paramContext, d.i.c);
    d1.a(configuration2);
    j = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        i = 0; 
    } catch (NullPointerException nullPointerException) {
      i = j;
    } 
    if (i != 0)
      r0.f.b.a(d1.getTheme()); 
    return super.f((Context)d1);
  }
  
  final Window.Callback f0() {
    return this.s.getCallback();
  }
  
  public <T extends View> T i(int paramInt) {
    W();
    return (T)this.s.findViewById(paramInt);
  }
  
  public int k() {
    return this.a0;
  }
  
  public MenuInflater l() {
    if (this.w == null) {
      Context context;
      g0();
      a a1 = this.v;
      if (a1 != null) {
        context = a1.e();
      } else {
        context = this.r;
      } 
      this.w = (MenuInflater)new j.g(context);
    } 
    return this.w;
  }
  
  public a m() {
    g0();
    return this.v;
  }
  
  public boolean m0() {
    return this.G;
  }
  
  public void n() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.r);
    if (layoutInflater.getFactory() == null) {
      a1.g.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof e))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  int n0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return b0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : c0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void o() {
    a a1 = m();
    if (a1 != null && a1.f())
      return; 
    k0(0);
  }
  
  boolean o0() {
    j.b b1 = this.B;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = m();
    return (a1 != null && a1.b());
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return R(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p(Configuration paramConfiguration) {
    if (this.N && this.H) {
      a a1 = m();
      if (a1 != null)
        a1.g(paramConfiguration); 
    } 
    AppCompatDrawableManager.get().onConfigurationChanged(this.r);
    G(false);
  }
  
  boolean p0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      q0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.V = bool;
    return false;
  }
  
  public void q(Bundle paramBundle) {
    this.W = true;
    G(false);
    X();
    Object object = this.q;
    if (object instanceof Activity) {
      Object object1;
      paramBundle = null;
      try {
        object = p0.h.c((Activity)object);
        object1 = object;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (object1 != null) {
        object1 = y0();
        if (object1 == null) {
          this.j0 = true;
        } else {
          object1.l(true);
        } 
      } 
      d.c(this);
    } 
    this.X = true;
  }
  
  public void r() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic x : (Landroidx/appcompat/app/d;)V
    //   14: aload_0
    //   15: getfield g0 : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield s : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield i0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_0
    //   38: putfield Y : Z
    //   41: aload_0
    //   42: iconst_1
    //   43: putfield Z : Z
    //   46: aload_0
    //   47: getfield a0 : I
    //   50: bipush #-100
    //   52: if_icmpeq -> 104
    //   55: aload_0
    //   56: getfield q : Ljava/lang/Object;
    //   59: astore_1
    //   60: aload_1
    //   61: instanceof android/app/Activity
    //   64: ifeq -> 104
    //   67: aload_1
    //   68: checkcast android/app/Activity
    //   71: invokevirtual isChangingConfigurations : ()Z
    //   74: ifeq -> 104
    //   77: getstatic androidx/appcompat/app/e.o0 : Lh0/g;
    //   80: aload_0
    //   81: getfield q : Ljava/lang/Object;
    //   84: invokevirtual getClass : ()Ljava/lang/Class;
    //   87: invokevirtual getName : ()Ljava/lang/String;
    //   90: aload_0
    //   91: getfield a0 : I
    //   94: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   97: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   100: pop
    //   101: goto -> 121
    //   104: getstatic androidx/appcompat/app/e.o0 : Lh0/g;
    //   107: aload_0
    //   108: getfield q : Ljava/lang/Object;
    //   111: invokevirtual getClass : ()Ljava/lang/Class;
    //   114: invokevirtual getName : ()Ljava/lang/String;
    //   117: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   120: pop
    //   121: aload_0
    //   122: getfield v : Landroidx/appcompat/app/a;
    //   125: astore_1
    //   126: aload_1
    //   127: ifnull -> 134
    //   130: aload_1
    //   131: invokevirtual h : ()V
    //   134: aload_0
    //   135: invokespecial M : ()V
    //   138: return
  }
  
  boolean r0(int paramInt, KeyEvent paramKeyEvent) {
    r r1;
    a a1 = m();
    if (a1 != null && a1.i(paramInt, paramKeyEvent))
      return true; 
    r r2 = this.U;
    if (r2 != null && z0(r2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      r1 = this.U;
      if (r1 != null)
        r1.n = true; 
      return true;
    } 
    if (this.U == null) {
      r2 = d0(0, true);
      A0(r2, (KeyEvent)r1);
      boolean bool = z0(r2, r1.getKeyCode(), (KeyEvent)r1, 1);
      r2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void s(Bundle paramBundle) {
    W();
  }
  
  boolean s0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      t0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.V;
    this.V = false;
    r r1 = d0(0, false);
    if (r1 != null && r1.o) {
      if (!bool)
        O(r1, true); 
      return true;
    } 
    return o0();
  }
  
  public void t() {
    a a1 = m();
    if (a1 != null)
      a1.m(true); 
  }
  
  public void u(Bundle paramBundle) {}
  
  void u0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null)
        a1.c(true); 
    } 
  }
  
  public void v() {
    this.Y = true;
    F();
  }
  
  void v0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null) {
        a1.c(false);
        return;
      } 
    } else if (paramInt == 0) {
      r r1 = d0(paramInt, true);
      if (r1.o)
        O(r1, false); 
    } 
  }
  
  public void w() {
    this.Y = false;
    a a1 = m();
    if (a1 != null)
      a1.m(false); 
  }
  
  void w0(ViewGroup paramViewGroup) {}
  
  final a y0() {
    return this.v;
  }
  
  public boolean z(int paramInt) {
    paramInt = C0(paramInt);
    if (this.R && paramInt == 108)
      return false; 
    if (this.N && paramInt == 1)
      this.N = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.s.requestFeature(paramInt); 
              H0();
              this.O = true;
              return true;
            } 
            H0();
            this.N = true;
            return true;
          } 
          H0();
          this.P = true;
          return true;
        } 
        H0();
        this.M = true;
        return true;
      } 
      H0();
      this.L = true;
      return true;
    } 
    H0();
    this.R = true;
    return true;
  }
  
  class a implements Runnable {
    a(e this$0) {}
    
    public void run() {
      e e1 = this.n;
      if ((e1.h0 & 0x1) != 0)
        e1.U(0); 
      e1 = this.n;
      if ((e1.h0 & 0x1000) != 0)
        e1.U(108); 
      e1 = this.n;
      e1.g0 = false;
      e1.h0 = 0;
    }
  }
  
  class b implements a1.p {
    b(e this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      int i = param1c0.l();
      int j = this.a.L0(param1c0, null);
      c0 c01 = param1c0;
      if (i != j)
        c01 = param1c0.p(param1c0.j(), j, param1c0.k(), param1c0.i()); 
      return u.a0(param1View, c01);
    }
  }
  
  class c implements ContentFrameLayout.OnAttachListener {
    c(e this$0) {}
    
    public void onAttachedFromWindow() {}
    
    public void onDetachedFromWindow() {
      this.a.S();
    }
  }
  
  class d implements Runnable {
    d(e this$0) {}
    
    public void run() {
      e e1 = this.n;
      e1.D.showAtLocation((View)e1.C, 55, 0, 0);
      this.n.V();
      if (this.n.D0()) {
        this.n.C.setAlpha(0.0F);
        e1 = this.n;
        e1.F = u.d((View)e1.C).a(1.0F);
        this.n.F.f((z)new a(this));
        return;
      } 
      this.n.C.setAlpha(1.0F);
      this.n.C.setVisibility(0);
    }
    
    class a extends a0 {
      a(e.d this$0) {}
      
      public void onAnimationEnd(View param2View) {
        this.a.n.C.setAlpha(1.0F);
        this.a.n.F.f(null);
        this.a.n.F = null;
      }
      
      public void onAnimationStart(View param2View) {
        this.a.n.C.setVisibility(0);
      }
    }
  }
  
  class a extends a0 {
    a(e this$0) {}
    
    public void onAnimationEnd(View param1View) {
      this.a.n.C.setAlpha(1.0F);
      this.a.n.F.f(null);
      this.a.n.F = null;
    }
    
    public void onAnimationStart(View param1View) {
      this.a.n.C.setVisibility(0);
    }
  }
  
  class e extends a0 {
    e(e this$0) {}
    
    public void onAnimationEnd(View param1View) {
      this.a.C.setAlpha(1.0F);
      this.a.F.f(null);
      this.a.F = null;
    }
    
    public void onAnimationStart(View param1View) {
      this.a.C.setVisibility(0);
      this.a.C.sendAccessibilityEvent(32);
      if (this.a.C.getParent() instanceof View)
        u.l0((View)this.a.C.getParent()); 
    }
  }
  
  private final class f implements androidx.appcompat.view.menu.j.a {
    f(e this$0) {}
    
    public void a(e param1e, boolean param1Boolean) {
      this.n.L(param1e);
    }
    
    public boolean b(e param1e) {
      Window.Callback callback = this.n.f0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1e); 
      return true;
    }
  }
  
  class g implements j.b.a {
    private j.b.a a;
    
    public g(e this$0, j.b.a param1a) {
      this.a = param1a;
    }
    
    public boolean a(j.b param1b, MenuItem param1MenuItem) {
      return this.a.a(param1b, param1MenuItem);
    }
    
    public boolean b(j.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public void c(j.b param1b) {
      this.a.c(param1b);
      e e1 = this.b;
      if (e1.D != null)
        e1.s.getDecorView().removeCallbacks(this.b.E); 
      e1 = this.b;
      if (e1.C != null) {
        e1.V();
        e1 = this.b;
        e1.F = u.d((View)e1.C).a(0.0F);
        this.b.F.f((z)new a(this));
      } 
      e1 = this.b;
      e.a a1 = e1.u;
      if (a1 != null)
        a1.G(e1.B); 
      e1 = this.b;
      e1.B = null;
      u.l0((View)e1.I);
    }
    
    public boolean d(j.b param1b, Menu param1Menu) {
      u.l0((View)this.b.I);
      return this.a.d(param1b, param1Menu);
    }
    
    class a extends a0 {
      a(e.g this$0) {}
      
      public void onAnimationEnd(View param2View) {
        this.a.b.C.setVisibility(8);
        e e = this.a.b;
        PopupWindow popupWindow = e.D;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (e.C.getParent() instanceof View) {
          u.l0((View)this.a.b.C.getParent());
        } 
        this.a.b.C.killMode();
        this.a.b.F.f(null);
        e = this.a.b;
        e.F = null;
        u.l0((View)e.I);
      }
    }
  }
  
  class a extends a0 {
    a(e this$0) {}
    
    public void onAnimationEnd(View param1View) {
      this.a.b.C.setVisibility(8);
      e e = this.a.b;
      PopupWindow popupWindow = e.D;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (e.C.getParent() instanceof View) {
        u.l0((View)this.a.b.C.getParent());
      } 
      this.a.b.C.killMode();
      this.a.b.F.f(null);
      e = this.a.b;
      e.F = null;
      u.l0((View)e.I);
    }
  }
  
  static class h {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int j = param1Configuration2.densityDpi;
      if (i != j)
        param1Configuration3.densityDpi = j; 
    }
  }
  
  static class i {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
  }
  
  static class j {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = param1Configuration1.getLocales();
      LocaleList localeList2 = param1Configuration2.getLocales();
      if (!localeList1.equals(localeList2)) {
        param1Configuration3.setLocales(localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
  }
  
  static class k {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.colorMode;
      int j = param1Configuration2.colorMode;
      if ((i & 0x3) != (j & 0x3))
        param1Configuration3.colorMode |= j & 0x3; 
      i = param1Configuration1.colorMode;
      j = param1Configuration2.colorMode;
      if ((i & 0xC) != (j & 0xC))
        param1Configuration3.colorMode |= j & 0xC; 
    }
  }
  
  class l extends j.i {
    l(e this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    final ActionMode b(ActionMode.Callback param1Callback) {
      j.f.a a = new j.f.a(this.o.r, param1Callback);
      j.b b = this.o.F0((j.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.o.T(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.o.r0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof e)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.o.u0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.o.v0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      e e1;
      if (param1Menu instanceof e) {
        e1 = (e)param1Menu;
      } else {
        e1 = null;
      } 
      if (param1Int == 0 && e1 == null)
        return false; 
      if (e1 != null)
        e1.a0(true); 
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (e1 != null)
        e1.a0(false); 
      return bool;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      e.r r = this.o.d0(0, true);
      if (r != null) {
        e e1 = r.j;
        if (e1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)e1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.o.m0() ? b(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.o.m0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : b(param1Callback);
    }
  }
  
  private class m extends n {
    private final PowerManager c;
    
    m(e this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return e.i.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.F();
    }
  }
  
  abstract class n {
    private BroadcastReceiver a;
    
    n(e this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.r.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.r.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(e.n this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(e this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class o extends n {
    private final j c;
    
    o(e this$0, j param1j) {
      super(this$0);
      this.c = param1j;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.F();
    }
  }
  
  private static class p {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class q extends ContentFrameLayout {
    public q(e this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean a(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.n.T(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && a((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.n.N(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(f.a.d(getContext(), param1Int));
    }
  }
  
  protected static final class r {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    e j;
    
    androidx.appcompat.view.menu.c k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    r(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.k a(androidx.appcompat.view.menu.j.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.c c1 = new androidx.appcompat.view.menu.c(this.l, d.g.l);
        this.k = c1;
        c1.i(param1a);
        this.j.b((androidx.appcompat.view.menu.j)this.k);
      } 
      return this.k.j(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.e().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(e param1e) {
      e e1 = this.j;
      if (param1e == e1)
        return; 
      if (e1 != null)
        e1.O((androidx.appcompat.view.menu.j)this.k); 
      this.j = param1e;
      if (param1e != null) {
        androidx.appcompat.view.menu.c c1 = this.k;
        if (c1 != null)
          param1e.b((androidx.appcompat.view.menu.j)c1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(d.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(d.a.G, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(d.i.b, true);
      } 
      j.d d = new j.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(d.j.B0);
      this.b = typedArray.getResourceId(d.j.E0, 0);
      this.f = typedArray.getResourceId(d.j.D0, 0);
      typedArray.recycle();
    }
  }
  
  private final class s implements androidx.appcompat.view.menu.j.a {
    s(e this$0) {}
    
    public void a(e param1e, boolean param1Boolean) {
      boolean bool;
      e e1 = param1e.D();
      if (e1 != param1e) {
        bool = true;
      } else {
        bool = false;
      } 
      e e2 = this.n;
      if (bool)
        param1e = e1; 
      e.r r = e2.Y((Menu)param1e);
      if (r != null) {
        if (bool) {
          this.n.K(r.a, r, (Menu)e1);
          this.n.O(r, true);
          return;
        } 
        this.n.O(r, param1Boolean);
      } 
    }
    
    public boolean b(e param1e) {
      if (param1e == param1e.D()) {
        e e1 = this.n;
        if (e1.N) {
          Window.Callback callback = e1.f0();
          if (callback != null && !this.n.Z)
            callback.onMenuOpened(108, (Menu)param1e); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */