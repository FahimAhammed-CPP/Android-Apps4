package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.VectorEnabledTintResources;
import androidx.fragment.app.d;
import androidx.lifecycle.a0;
import androidx.lifecycle.b0;
import androidx.lifecycle.l;
import androidx.lifecycle.z;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.d;
import e.a;
import p0.h;
import p0.r;

public class c extends d implements a, r.a {
  private d C;
  
  private Resources D;
  
  public c() {
    O0();
  }
  
  private void O0() {
    l().d("androidx:appcompat", new a(this));
    w0(new b(this));
  }
  
  private boolean U0(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  private void y0() {
    a0.a(getWindow().getDecorView(), (l)this);
    b0.a(getWindow().getDecorView(), (z)this);
    d.a(getWindow().getDecorView(), (androidx.savedstate.c)this);
  }
  
  public void G(j.b paramb) {}
  
  public void L0() {
    M0().o();
  }
  
  public d M0() {
    if (this.C == null)
      this.C = d.g((Activity)this, this); 
    return this.C;
  }
  
  public a N0() {
    return M0().m();
  }
  
  public void P0(r paramr) {
    paramr.e((Activity)this);
  }
  
  protected void Q0(int paramInt) {}
  
  public void R0(r paramr) {}
  
  @Deprecated
  public void S0() {}
  
  public boolean T0() {
    Intent intent = e0();
    if (intent != null) {
      if (W0(intent)) {
        r r = r.k((Context)this);
        P0(r);
        R0(r);
        r.m();
        try {
          p0.a.k((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        V0((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void V0(Intent paramIntent) {
    h.e((Activity)this, paramIntent);
  }
  
  public boolean W0(Intent paramIntent) {
    return h.f((Activity)this, paramIntent);
  }
  
  public j.b Z(j.b.a parama) {
    return null;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    y0();
    M0().d(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(M0().f(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a1 = N0();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.a()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = N0();
    return (i == 82 && a1 != null && a1.j(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public Intent e0() {
    return h.a((Activity)this);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return M0().i(paramInt);
  }
  
  public void g0(j.b paramb) {}
  
  public MenuInflater getMenuInflater() {
    return M0().l();
  }
  
  public Resources getResources() {
    if (this.D == null && VectorEnabledTintResources.shouldBeUsed())
      this.D = (Resources)new VectorEnabledTintResources((Context)this, super.getResources()); 
    Resources resources2 = this.D;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public void invalidateOptionsMenu() {
    M0().o();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.D != null) {
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.D.updateConfiguration(paramConfiguration, displayMetrics);
    } 
    M0().p(paramConfiguration);
  }
  
  public void onContentChanged() {
    S0();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    M0().r();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return U0(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = N0();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.d() & 0x4) != 0) ? T0() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    M0().s(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    M0().t();
  }
  
  protected void onStart() {
    super.onStart();
    M0().v();
  }
  
  protected void onStop() {
    super.onStop();
    M0().w();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    M0().E(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = N0();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.k()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    y0();
    M0().A(paramInt);
  }
  
  public void setContentView(View paramView) {
    y0();
    M0().B(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    y0();
    M0().C(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    M0().D(paramInt);
  }
  
  class a implements SavedStateRegistry.b {
    a(c this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.M0().u(bundle);
      return bundle;
    }
  }
  
  class b implements b.b {
    b(c this$0) {}
    
    public void a(Context param1Context) {
      d d = this.a.M0();
      d.n();
      d.q(this.a.l().a("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */