package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import e.b;

public class b extends b {
  final AlertController p = new AlertController(getContext(), this, getWindow());
  
  protected b(Context paramContext, int paramInt) {
    super(paramContext, g(paramContext, paramInt));
  }
  
  static int g(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(d.a.q, typedValue, true);
    return typedValue.resourceId;
  }
  
  public Button e(int paramInt) {
    return this.p.c(paramInt);
  }
  
  public ListView f() {
    return this.p.e();
  }
  
  public void h(CharSequence paramCharSequence) {
    this.p.p(paramCharSequence);
  }
  
  public void i(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.p.u(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.p.f();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return this.p.h(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return this.p.i(paramInt, paramKeyEvent) ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    this.p.r(paramCharSequence);
  }
  
  public static class a {
    private final AlertController.f a;
    
    private final int b;
    
    public a(Context param1Context) {
      this(param1Context, b.g(param1Context, 0));
    }
    
    public a(Context param1Context, int param1Int) {
      this.a = new AlertController.f((Context)new ContextThemeWrapper(param1Context, b.g(param1Context, param1Int)));
      this.b = param1Int;
    }
    
    public b a() {
      b b = new b(this.a.a, this.b);
      this.a.a(b.p);
      b.setCancelable(this.a.r);
      if (this.a.r)
        b.setCanceledOnTouchOutside(true); 
      b.setOnCancelListener(this.a.s);
      b.setOnDismissListener(this.a.t);
      DialogInterface.OnKeyListener onKeyListener = this.a.u;
      if (onKeyListener != null)
        b.setOnKeyListener(onKeyListener); 
      return b;
    }
    
    public Context b() {
      return this.a.a;
    }
    
    public a c(ListAdapter param1ListAdapter, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.w = param1ListAdapter;
      f1.x = param1OnClickListener;
      return this;
    }
    
    public a d(boolean param1Boolean) {
      this.a.r = param1Boolean;
      return this;
    }
    
    public a e(View param1View) {
      this.a.g = param1View;
      return this;
    }
    
    public a f(Drawable param1Drawable) {
      this.a.d = param1Drawable;
      return this;
    }
    
    public a g(int param1Int) {
      AlertController.f f1 = this.a;
      f1.h = f1.a.getText(param1Int);
      return this;
    }
    
    public a h(CharSequence param1CharSequence) {
      this.a.h = param1CharSequence;
      return this;
    }
    
    public a i(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.l = f1.a.getText(param1Int);
      this.a.n = param1OnClickListener;
      return this;
    }
    
    public a j(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.l = param1CharSequence;
      f1.n = param1OnClickListener;
      return this;
    }
    
    public a k(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.o = f1.a.getText(param1Int);
      this.a.q = param1OnClickListener;
      return this;
    }
    
    public a l(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.o = param1CharSequence;
      f1.q = param1OnClickListener;
      return this;
    }
    
    public a m(DialogInterface.OnCancelListener param1OnCancelListener) {
      this.a.s = param1OnCancelListener;
      return this;
    }
    
    public a n(DialogInterface.OnDismissListener param1OnDismissListener) {
      this.a.t = param1OnDismissListener;
      return this;
    }
    
    public a o(DialogInterface.OnKeyListener param1OnKeyListener) {
      this.a.u = param1OnKeyListener;
      return this;
    }
    
    public a p(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.i = f1.a.getText(param1Int);
      this.a.k = param1OnClickListener;
      return this;
    }
    
    public a q(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.i = param1CharSequence;
      f1.k = param1OnClickListener;
      return this;
    }
    
    public a r(ListAdapter param1ListAdapter, int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.w = param1ListAdapter;
      f1.x = param1OnClickListener;
      f1.I = param1Int;
      f1.H = true;
      return this;
    }
    
    public a s(int param1Int) {
      AlertController.f f1 = this.a;
      f1.f = f1.a.getText(param1Int);
      return this;
    }
    
    public a t(CharSequence param1CharSequence) {
      this.a.f = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */