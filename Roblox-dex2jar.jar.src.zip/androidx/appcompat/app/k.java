package androidx.appcompat.app;

import a1.a0;
import a1.b0;
import a1.u;
import a1.y;
import a1.z;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.DecorToolbar;
import androidx.appcompat.widget.ScrollingTabContainerView;
import androidx.appcompat.widget.Toolbar;
import d.f;
import d.j;
import j.g;
import j.h;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class k extends a implements ActionBarOverlayLayout.ActionBarVisibilityCallback {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final z B = (z)new a(this);
  
  final z C = (z)new b(this);
  
  final b0 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  DecorToolbar f;
  
  ActionBarContextView g;
  
  View h;
  
  ScrollingTabContainerView i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  j.b n;
  
  j.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public k(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    x(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public k(Dialog paramDialog) {
    x(paramDialog.getWindow().getDecorView());
  }
  
  private void B(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.setEmbeddedTabView(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.setEmbeddedTabView(this.i);
    } 
    int i = v();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    ScrollingTabContainerView scrollingTabContainerView = this.i;
    if (scrollingTabContainerView != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        scrollingTabContainerView.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          u.l0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    DecorToolbar decorToolbar = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    decorToolbar.setCollapsible(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean E() {
    return u.T((View)this.e);
  }
  
  private void F() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      G(false);
    } 
  }
  
  private void G(boolean paramBoolean) {
    if (q(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        t(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      s(paramBoolean);
    } 
  }
  
  static boolean q(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private DecorToolbar u(View paramView) {
    String str;
    if (paramView instanceof DecorToolbar)
      return (DecorToolbar)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void w() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      G(false);
    } 
  }
  
  private void x(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.q);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = u(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    DecorToolbar decorToolbar = this.f;
    if (decorToolbar != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = decorToolbar.getContext();
      if ((this.f.getDisplayOptions() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      j.a a1 = j.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      D(bool);
      B(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, d.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        C(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        A(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void A(float paramFloat) {
    u.v0((View)this.e, paramFloat);
  }
  
  public void C(boolean paramBoolean) {
    if (!paramBoolean || this.d.isInOverlayMode()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void D(boolean paramBoolean) {
    this.f.setHomeButtonEnabled(paramBoolean);
  }
  
  public boolean b() {
    DecorToolbar decorToolbar = this.f;
    if (decorToolbar != null && decorToolbar.hasExpandedActionView()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void c(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).a(paramBoolean); 
  }
  
  public int d() {
    return this.f.getDisplayOptions();
  }
  
  public Context e() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(d.a.h, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void enableContentAnimations(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void g(Configuration paramConfiguration) {
    B(j.a.b(this.a).g());
  }
  
  public void hideForSystem() {
    if (!this.v) {
      this.v = true;
      G(true);
    } 
  }
  
  public boolean i(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void l(boolean paramBoolean) {
    if (!this.l)
      y(paramBoolean); 
  }
  
  public void m(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void n(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public j.b o(j.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.killMode();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.initForMode(d1);
      p(true);
      this.g.sendAccessibilityEvent(32);
      return d1;
    } 
    return null;
  }
  
  public void onContentScrollStarted() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void onContentScrollStopped() {}
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.s = paramInt;
  }
  
  public void p(boolean paramBoolean) {
    if (paramBoolean) {
      F();
    } else {
      w();
    } 
    if (E()) {
      y y1;
      y y2;
      if (paramBoolean) {
        y2 = this.f.setupAnimatorToVisibility(4, 100L);
        y1 = this.g.setupAnimatorToVisibility(0, 200L);
      } else {
        y1 = this.f.setupAnimatorToVisibility(0, 200L);
        y2 = this.g.setupAnimatorToVisibility(8, 100L);
      } 
      h h1 = new h();
      h1.d(y2, y1);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.setVisibility(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.setVisibility(0);
    this.g.setVisibility(8);
  }
  
  void r() {
    j.b.a a1 = this.o;
    if (a1 != null) {
      a1.c(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void s(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      y y = u.d((View)this.e).k(f1);
      y.i(this.D);
      h1.c(y);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(u.d(view).k(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.onAnimationEnd(null);
  }
  
  public void showForSystem() {
    if (this.v) {
      this.v = false;
      G(true);
    } 
  }
  
  public void t(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      y y = u.d((View)this.e).k(0.0F);
      y.i(this.D);
      h1.c(y);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(u.d(this.h).k(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.onAnimationEnd(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      u.l0((View)actionBarOverlayLayout); 
  }
  
  public int v() {
    return this.f.getNavigationMode();
  }
  
  public void y(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    z(bool, 4);
  }
  
  public void z(int paramInt1, int paramInt2) {
    int i = this.f.getDisplayOptions();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.setDisplayOptions(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  class a extends a0 {
    a(k this$0) {}
    
    public void onAnimationEnd(View param1View) {
      k k1 = this.a;
      if (k1.t) {
        View view = k1.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      k1 = this.a;
      k1.y = null;
      k1.r();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        u.l0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends a0 {
    b(k this$0) {}
    
    public void onAnimationEnd(View param1View) {
      k k1 = this.a;
      k1.y = null;
      k1.e.requestLayout();
    }
  }
  
  class c implements b0 {
    c(k this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends j.b implements e.a {
    private final Context p;
    
    private final e q;
    
    private j.b.a r;
    
    private WeakReference<View> s;
    
    public d(k this$0, Context param1Context, j.b.a param1a) {
      this.p = param1Context;
      this.r = param1a;
      e e1 = (new e(param1Context)).S(1);
      this.q = e1;
      e1.R(this);
    }
    
    public boolean a(e param1e, MenuItem param1MenuItem) {
      j.b.a a1 = this.r;
      return (a1 != null) ? a1.a(this, param1MenuItem) : false;
    }
    
    public void b(e param1e) {
      if (this.r == null)
        return; 
      k();
      this.t.g.showOverflowMenu();
    }
    
    public void c() {
      k k1 = this.t;
      if (k1.m != this)
        return; 
      if (!k.q(k1.u, k1.v, false)) {
        k1 = this.t;
        k1.n = this;
        k1.o = this.r;
      } else {
        this.r.c(this);
      } 
      this.r = null;
      this.t.p(false);
      this.t.g.closeMode();
      this.t.f.getViewGroup().sendAccessibilityEvent(32);
      k1 = this.t;
      k1.d.setHideOnContentScrollEnabled(k1.A);
      this.t.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.s;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.q;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.p);
    }
    
    public CharSequence g() {
      return this.t.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.t.g.getTitle();
    }
    
    public void k() {
      if (this.t.m != this)
        return; 
      this.q.d0();
      try {
        this.r.d(this, (Menu)this.q);
        return;
      } finally {
        this.q.c0();
      } 
    }
    
    public boolean l() {
      return this.t.g.isTitleOptional();
    }
    
    public void m(View param1View) {
      this.t.g.setCustomView(param1View);
      this.s = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.t.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.t.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.t.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.t.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.t.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.q.d0();
      try {
        return this.r.b(this, (Menu)this.q);
      } finally {
        this.q.c0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */