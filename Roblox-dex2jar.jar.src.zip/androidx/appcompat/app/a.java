package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import d.j;

public abstract class a {
  public boolean a() {
    return false;
  }
  
  public abstract boolean b();
  
  public abstract void c(boolean paramBoolean);
  
  public abstract int d();
  
  public abstract Context e();
  
  public boolean f() {
    return false;
  }
  
  public abstract void g(Configuration paramConfiguration);
  
  void h() {}
  
  public abstract boolean i(int paramInt, KeyEvent paramKeyEvent);
  
  public boolean j(KeyEvent paramKeyEvent) {
    return false;
  }
  
  public boolean k() {
    return false;
  }
  
  public abstract void l(boolean paramBoolean);
  
  public abstract void m(boolean paramBoolean);
  
  public abstract void n(CharSequence paramCharSequence);
  
  public abstract j.b o(j.b.a parama);
  
  public static class a extends ViewGroup.MarginLayoutParams {
    public int gravity = 8388627;
    
    public a(int param1Int) {
      this(-2, -1, param1Int);
    }
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(int param1Int1, int param1Int2, int param1Int3) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.t);
      this.gravity = typedArray.getInt(j.u, 0);
      typedArray.recycle();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public a(a param1a) {
      super(param1a);
      this.gravity = param1a.gravity;
    }
  }
  
  public static interface b {
    void a(boolean param1Boolean);
  }
  
  @Deprecated
  public static abstract class c {
    public abstract CharSequence a();
    
    public abstract View b();
    
    public abstract Drawable c();
    
    public abstract CharSequence d();
    
    public abstract void e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */