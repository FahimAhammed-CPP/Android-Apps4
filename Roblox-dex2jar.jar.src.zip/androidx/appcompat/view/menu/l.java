package androidx.appcompat.view.menu;

import a1.u;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.MenuPopupWindow;
import d.d;
import d.g;

final class l extends h implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int I = g.o;
  
  View A;
  
  private j.a B;
  
  ViewTreeObserver C;
  
  private boolean D;
  
  private boolean E;
  
  private int F;
  
  private int G = 0;
  
  private boolean H;
  
  private final Context o;
  
  private final e p;
  
  private final d q;
  
  private final boolean r;
  
  private final int s;
  
  private final int t;
  
  private final int u;
  
  final MenuPopupWindow v;
  
  final ViewTreeObserver.OnGlobalLayoutListener w = new a(this);
  
  private final View.OnAttachStateChangeListener x = new b(this);
  
  private PopupWindow.OnDismissListener y;
  
  private View z;
  
  public l(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.o = paramContext;
    this.p = parame;
    this.r = paramBoolean;
    this.q = new d(parame, LayoutInflater.from(paramContext), paramBoolean, I);
    this.t = paramInt1;
    this.u = paramInt2;
    Resources resources = paramContext.getResources();
    this.s = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.z = paramView;
    this.v = new MenuPopupWindow(paramContext, null, paramInt1, paramInt2);
    parame.c(this, paramContext);
  }
  
  private boolean w() {
    if (isShowing())
      return true; 
    if (!this.D) {
      boolean bool;
      View view = this.z;
      if (view == null)
        return false; 
      this.A = view;
      this.v.setOnDismissListener(this);
      this.v.setOnItemClickListener(this);
      this.v.setModal(true);
      view = this.A;
      if (this.C == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.C = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.w); 
      view.addOnAttachStateChangeListener(this.x);
      this.v.setAnchorView(view);
      this.v.setDropDownGravity(this.G);
      if (!this.E) {
        this.F = h.l((ListAdapter)this.q, null, this.o, this.s);
        this.E = true;
      } 
      this.v.setContentWidth(this.F);
      this.v.setInputMethodMode(2);
      this.v.setEpicenterBounds(k());
      this.v.show();
      ListView listView = this.v.getListView();
      listView.setOnKeyListener(this);
      if (this.H && this.p.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.o).inflate(g.n, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.p.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.v.setAdapter((ListAdapter)this.q);
      this.v.show();
      return true;
    } 
    return false;
  }
  
  public void a(e parame, boolean paramBoolean) {
    if (parame != this.p)
      return; 
    dismiss();
    j.a a1 = this.B;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public boolean c(m paramm) {
    if (paramm.hasVisibleItems()) {
      i i1 = new i(this.o, paramm, this.A, this.r, this.t, this.u);
      i1.l(this.B);
      i1.i(h.u(paramm));
      i1.k(this.y);
      this.y = null;
      this.p.e(false);
      int j = this.v.getHorizontalOffset();
      int k = this.v.getVerticalOffset();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.G, u.C(this.z)) & 0x7) == 5)
        i = j + this.z.getWidth(); 
      if (i1.p(i, k)) {
        j.a a1 = this.B;
        if (a1 != null)
          a1.b(paramm); 
        return true;
      } 
    } 
    return false;
  }
  
  public void d(boolean paramBoolean) {
    this.E = false;
    d d1 = this.q;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public void dismiss() {
    if (isShowing())
      this.v.dismiss(); 
  }
  
  public void e(e parame) {}
  
  public boolean f() {
    return false;
  }
  
  public ListView getListView() {
    return this.v.getListView();
  }
  
  public void i(j.a parama) {
    this.B = parama;
  }
  
  public boolean isShowing() {
    return (!this.D && this.v.isShowing());
  }
  
  public void m(View paramView) {
    this.z = paramView;
  }
  
  public void o(boolean paramBoolean) {
    this.q.d(paramBoolean);
  }
  
  public void onDismiss() {
    this.D = true;
    this.p.close();
    ViewTreeObserver viewTreeObserver = this.C;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.C = this.A.getViewTreeObserver(); 
      this.C.removeGlobalOnLayoutListener(this.w);
      this.C = null;
    } 
    this.A.removeOnAttachStateChangeListener(this.x);
    PopupWindow.OnDismissListener onDismissListener = this.y;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(int paramInt) {
    this.G = paramInt;
  }
  
  public void q(int paramInt) {
    this.v.setHorizontalOffset(paramInt);
  }
  
  public void r(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.y = paramOnDismissListener;
  }
  
  public void s(boolean paramBoolean) {
    this.H = paramBoolean;
  }
  
  public void show() {
    if (w())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void t(int paramInt) {
    this.v.setVerticalOffset(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(l this$0) {}
    
    public void onGlobalLayout() {
      if (this.n.isShowing() && !this.n.v.isModal()) {
        View view = this.n.A;
        if (view == null || !view.isShown()) {
          this.n.dismiss();
          return;
        } 
        this.n.v.show();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(l this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.n.C;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.n.C = param1View.getViewTreeObserver(); 
        l l1 = this.n;
        l1.C.removeGlobalOnLayoutListener(l1.w);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */