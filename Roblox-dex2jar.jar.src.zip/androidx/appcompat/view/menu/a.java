package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class a implements j {
  protected Context n;
  
  protected Context o;
  
  protected e p;
  
  protected LayoutInflater q;
  
  protected LayoutInflater r;
  
  private j.a s;
  
  private int t;
  
  private int u;
  
  protected k v;
  
  private int w;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.n = paramContext;
    this.q = LayoutInflater.from(paramContext);
    this.t = paramInt1;
    this.u = paramInt2;
  }
  
  public void a(e parame, boolean paramBoolean) {
    j.a a1 = this.s;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public void b(Context paramContext, e parame) {
    this.o = paramContext;
    this.r = LayoutInflater.from(paramContext);
    this.p = parame;
  }
  
  public boolean c(m paramm) {
    j.a a1 = this.s;
    if (a1 != null) {
      e e1;
      if (paramm == null)
        e1 = this.p; 
      return a1.b(e1);
    } 
    return false;
  }
  
  public void d(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.v;
    if (viewGroup == null)
      return; 
    e e1 = this.p;
    int i = 0;
    if (e1 != null) {
      e1.r();
      ArrayList<g> arrayList = this.p.E();
      int n = arrayList.size();
      int m = 0;
      for (i = 0; m < n; i = i1) {
        g g = arrayList.get(m);
        int i1 = i;
        if (r(i, g)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof k.a) {
            g g1 = ((k.a)view1).getItemData();
          } else {
            e1 = null;
          } 
          View view2 = o(g, view1, viewGroup);
          if (g != e1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            j(view2, i); 
          i1 = i + 1;
        } 
        m++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!m(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean g(e parame, g paramg) {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public void i(j.a parama) {
    this.s = parama;
  }
  
  protected void j(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.v).addView(paramView, paramInt);
  }
  
  public abstract void k(g paramg, k.a parama);
  
  public k.a l(ViewGroup paramViewGroup) {
    return (k.a)this.q.inflate(this.u, paramViewGroup, false);
  }
  
  protected boolean m(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public j.a n() {
    return this.s;
  }
  
  public View o(g paramg, View paramView, ViewGroup paramViewGroup) {
    k.a a1;
    if (paramView instanceof k.a) {
      a1 = (k.a)paramView;
    } else {
      a1 = l(paramViewGroup);
    } 
    k(paramg, a1);
    return (View)a1;
  }
  
  public k p(ViewGroup paramViewGroup) {
    if (this.v == null) {
      k k1 = (k)this.q.inflate(this.t, paramViewGroup, false);
      this.v = k1;
      k1.initialize(this.p);
      d(true);
    } 
    return this.v;
  }
  
  public void q(int paramInt) {
    this.w = paramInt;
  }
  
  public abstract boolean r(int paramInt, g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */