package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import d.g;
import java.util.ArrayList;

public class c implements j, AdapterView.OnItemClickListener {
  Context n;
  
  LayoutInflater o;
  
  e p;
  
  ExpandedMenuView q;
  
  int r;
  
  int s;
  
  int t;
  
  private j.a u;
  
  a v;
  
  public c(int paramInt1, int paramInt2) {
    this.t = paramInt1;
    this.s = paramInt2;
  }
  
  public c(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.n = paramContext;
    this.o = LayoutInflater.from(paramContext);
  }
  
  public void a(e parame, boolean paramBoolean) {
    j.a a1 = this.u;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public void b(Context paramContext, e parame) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.s != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.s);
      this.n = (Context)contextThemeWrapper;
      this.o = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.n != null) {
      this.n = (Context)contextThemeWrapper;
      if (this.o == null)
        this.o = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.p = parame;
    a a1 = this.v;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean c(m paramm) {
    if (!paramm.hasVisibleItems())
      return false; 
    (new f(paramm)).d(null);
    j.a a1 = this.u;
    if (a1 != null)
      a1.b(paramm); 
    return true;
  }
  
  public void d(boolean paramBoolean) {
    a a1 = this.v;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public ListAdapter e() {
    if (this.v == null)
      this.v = new a(this); 
    return (ListAdapter)this.v;
  }
  
  public boolean f() {
    return false;
  }
  
  public boolean g(e parame, g paramg) {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  public void i(j.a parama) {
    this.u = parama;
  }
  
  public k j(ViewGroup paramViewGroup) {
    if (this.q == null) {
      this.q = (ExpandedMenuView)this.o.inflate(g.i, paramViewGroup, false);
      if (this.v == null)
        this.v = new a(this); 
      this.q.setAdapter((ListAdapter)this.v);
      this.q.setOnItemClickListener(this);
    } 
    return this.q;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.p.M((MenuItem)this.v.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int n = -1;
    
    public a(c this$0) {
      a();
    }
    
    void a() {
      g g = this.o.p.v();
      if (g != null) {
        ArrayList<g> arrayList = this.o.p.z();
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.n = i;
            return;
          } 
        } 
      } 
      this.n = -1;
    }
    
    public g b(int param1Int) {
      ArrayList<g> arrayList = this.o.p.z();
      int i = param1Int + this.o.r;
      int j = this.n;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.o.p.z().size() - this.o.r;
      return (this.n < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        c c1 = this.o;
        view = c1.o.inflate(c1.t, param1ViewGroup, false);
      } 
      ((k.a)view).b(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */