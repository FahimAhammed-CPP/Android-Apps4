package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.b;
import d.g;

class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {
  private e n;
  
  private b o;
  
  c p;
  
  private j.a q;
  
  public f(e parame) {
    this.n = parame;
  }
  
  public void a(e parame, boolean paramBoolean) {
    if (paramBoolean || parame == this.n)
      c(); 
    j.a a1 = this.q;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public boolean b(e parame) {
    j.a a1 = this.q;
    return (a1 != null) ? a1.b(parame) : false;
  }
  
  public void c() {
    b b1 = this.o;
    if (b1 != null)
      b1.dismiss(); 
  }
  
  public void d(IBinder paramIBinder) {
    e e1 = this.n;
    b.a a1 = new b.a(e1.u());
    c c1 = new c(a1.b(), g.l);
    this.p = c1;
    c1.i(this);
    this.n.b(this.p);
    a1.c(this.p.e(), this);
    View view = e1.y();
    if (view != null) {
      a1.e(view);
    } else {
      a1.f(e1.w()).t(e1.x());
    } 
    a1.o(this);
    b b1 = a1.a();
    this.o = b1;
    b1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.o.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.o.show();
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.n.L((MenuItem)this.p.e().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.p.a(this.n, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.o.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.o.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.n.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.n.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */