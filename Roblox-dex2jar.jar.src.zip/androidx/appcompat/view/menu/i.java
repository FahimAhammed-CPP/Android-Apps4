package androidx.appcompat.view.menu;

import a1.e;
import a1.u;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.PopupWindow;
import d.d;

public class i {
  private final Context a;
  
  private final e b;
  
  private final boolean c;
  
  private final int d;
  
  private final int e;
  
  private View f;
  
  private int g = 8388611;
  
  private boolean h;
  
  private j.a i;
  
  private h j;
  
  private PopupWindow.OnDismissListener k;
  
  private final PopupWindow.OnDismissListener l = new a(this);
  
  public i(Context paramContext, e parame, View paramView, boolean paramBoolean, int paramInt) {
    this(paramContext, parame, paramView, paramBoolean, paramInt, 0);
  }
  
  public i(Context paramContext, e parame, View paramView, boolean paramBoolean, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.b = parame;
    this.f = paramView;
    this.c = paramBoolean;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  private h a() {
    boolean bool;
    l l;
    Display display = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
    Point point = new Point();
    display.getRealSize(point);
    if (Math.min(point.x, point.y) >= this.a.getResources().getDimensionPixelSize(d.c)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      b b = new b(this.a, this.f, this.d, this.e, this.c);
    } else {
      l = new l(this.a, this.b, this.f, this.d, this.e, this.c);
    } 
    l.e(this.b);
    l.r(this.l);
    l.m(this.f);
    l.i(this.i);
    l.o(this.h);
    l.p(this.g);
    return l;
  }
  
  private void n(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    h h1 = e();
    h1.s(paramBoolean2);
    if (paramBoolean1) {
      int j = paramInt1;
      if ((e.b(this.g, u.C(this.f)) & 0x7) == 5)
        j = paramInt1 - this.f.getWidth(); 
      h1.q(j);
      h1.t(paramInt2);
      paramInt1 = (int)((this.a.getResources().getDisplayMetrics()).density * 48.0F / 2.0F);
      h1.n(new Rect(j - paramInt1, paramInt2 - paramInt1, j + paramInt1, paramInt2 + paramInt1));
    } 
    h1.show();
  }
  
  public void b() {
    if (f())
      this.j.dismiss(); 
  }
  
  public int c() {
    return this.g;
  }
  
  public ListView d() {
    return e().getListView();
  }
  
  public h e() {
    if (this.j == null)
      this.j = a(); 
    return this.j;
  }
  
  public boolean f() {
    h h1 = this.j;
    return (h1 != null && h1.isShowing());
  }
  
  protected void g() {
    this.j = null;
    PopupWindow.OnDismissListener onDismissListener = this.k;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public void h(View paramView) {
    this.f = paramView;
  }
  
  public void i(boolean paramBoolean) {
    this.h = paramBoolean;
    h h1 = this.j;
    if (h1 != null)
      h1.o(paramBoolean); 
  }
  
  public void j(int paramInt) {
    this.g = paramInt;
  }
  
  public void k(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.k = paramOnDismissListener;
  }
  
  public void l(j.a parama) {
    this.i = parama;
    h h1 = this.j;
    if (h1 != null)
      h1.i(parama); 
  }
  
  public void m() {
    if (o())
      return; 
    throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
  }
  
  public boolean o() {
    if (f())
      return true; 
    if (this.f == null)
      return false; 
    n(0, 0, false, false);
    return true;
  }
  
  public boolean p(int paramInt1, int paramInt2) {
    if (f())
      return true; 
    if (this.f == null)
      return false; 
    n(paramInt1, paramInt2, true, true);
    return true;
  }
  
  class a implements PopupWindow.OnDismissListener {
    a(i this$0) {}
    
    public void onDismiss() {
      this.n.g();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */