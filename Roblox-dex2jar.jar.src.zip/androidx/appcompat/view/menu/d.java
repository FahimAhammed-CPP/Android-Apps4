package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  e n;
  
  private int o = -1;
  
  private boolean p;
  
  private final boolean q;
  
  private final LayoutInflater r;
  
  private final int s;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.q = paramBoolean;
    this.r = paramLayoutInflater;
    this.n = parame;
    this.s = paramInt;
    a();
  }
  
  void a() {
    g g = this.n.v();
    if (g != null) {
      ArrayList<g> arrayList = this.n.z();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.o = i;
          return;
        } 
      } 
    } 
    this.o = -1;
  }
  
  public e b() {
    return this.n;
  }
  
  public g c(int paramInt) {
    ArrayList<g> arrayList;
    if (this.q) {
      arrayList = this.n.z();
    } else {
      arrayList = this.n.E();
    } 
    int j = this.o;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.q) {
      arrayList = this.n.z();
    } else {
      arrayList = this.n.E();
    } 
    return (this.o < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.r.inflate(this.s, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.n.F() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    k.a a = (k.a)view;
    if (this.p)
      listMenuItemView.setForceShowIcon(true); 
    a.b(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */