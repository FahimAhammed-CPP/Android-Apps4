package androidx.appcompat.view.menu;

import a1.u;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.TintTypedArray;
import d.a;
import d.f;
import d.g;
import d.j;

public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {
  private Drawable A;
  
  private boolean B;
  
  private LayoutInflater C;
  
  private boolean D;
  
  private g n;
  
  private ImageView o;
  
  private RadioButton p;
  
  private TextView q;
  
  private CheckBox r;
  
  private TextView s;
  
  private ImageView t;
  
  private ImageView u;
  
  private LinearLayout v;
  
  private Drawable w;
  
  private int x;
  
  private Context y;
  
  private boolean z;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.E);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(getContext(), paramAttributeSet, j.Y1, paramInt, 0);
    this.w = tintTypedArray.getDrawable(j.a2);
    this.x = tintTypedArray.getResourceId(j.Z1, -1);
    this.z = tintTypedArray.getBoolean(j.b2, false);
    this.y = paramContext;
    this.A = tintTypedArray.getDrawable(j.c2);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.B;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.B = typedArray.hasValue(0);
    tintTypedArray.recycle();
    typedArray.recycle();
  }
  
  private void c(View paramView) {
    d(paramView, -1);
  }
  
  private void d(View paramView, int paramInt) {
    LinearLayout linearLayout = this.v;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void e() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.j, (ViewGroup)this, false);
    this.r = checkBox;
    c((View)checkBox);
  }
  
  private void f() {
    ImageView imageView = (ImageView)getInflater().inflate(g.k, (ViewGroup)this, false);
    this.o = imageView;
    d((View)imageView, 0);
  }
  
  private void g() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.m, (ViewGroup)this, false);
    this.p = radioButton;
    c((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.C == null)
      this.C = LayoutInflater.from(getContext()); 
    return this.C;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.t;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public boolean a() {
    return false;
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.u;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.u.getLayoutParams();
      paramRect.top += this.u.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public void b(g paramg, int paramInt) {
    this.n = paramg;
    if (paramg.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(paramg.i(this));
    setCheckable(paramg.isCheckable());
    h(paramg.A(), paramg.g());
    setIcon(paramg.getIcon());
    setEnabled(paramg.isEnabled());
    setSubMenuArrowVisible(paramg.hasSubMenu());
    setContentDescription(paramg.getContentDescription());
  }
  
  public g getItemData() {
    return this.n;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.n.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.s.setText(this.n.h()); 
    if (this.s.getVisibility() != paramChar)
      this.s.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    u.r0((View)this, this.w);
    TextView textView = (TextView)findViewById(f.S);
    this.q = textView;
    int i = this.x;
    if (i != -1)
      textView.setTextAppearance(this.y, i); 
    this.s = (TextView)findViewById(f.L);
    ImageView imageView = (ImageView)findViewById(f.O);
    this.t = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.A); 
    this.u = (ImageView)findViewById(f.u);
    this.v = (LinearLayout)findViewById(f.m);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.o != null && this.z) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.o.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.p == null && this.r == null)
      return; 
    if (this.n.m()) {
      if (this.p == null)
        g(); 
      RadioButton radioButton1 = this.p;
      CheckBox checkBox1 = this.r;
    } else {
      if (this.r == null)
        e(); 
      checkBox = this.r;
      radioButton = this.p;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.n.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.r;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.p;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.n.m()) {
      if (this.p == null)
        g(); 
      RadioButton radioButton = this.p;
    } else {
      if (this.r == null)
        e(); 
      checkBox = this.r;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.D = paramBoolean;
    this.z = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.u;
    if (imageView != null) {
      byte b;
      if (!this.B && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.n.z() || this.D) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.z)
      return; 
    ImageView imageView = this.o;
    if (imageView == null && paramDrawable == null && !this.z)
      return; 
    if (imageView == null)
      f(); 
    if (paramDrawable != null || this.z) {
      imageView = this.o;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.o.getVisibility() != 0)
        this.o.setVisibility(0); 
      return;
    } 
    this.o.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.q.setText(paramCharSequence);
      if (this.q.getVisibility() != 0) {
        this.q.setVisibility(0);
        return;
      } 
    } else if (this.q.getVisibility() != 8) {
      this.q.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */