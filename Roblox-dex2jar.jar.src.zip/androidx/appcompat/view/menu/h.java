package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import k.e;

abstract class h implements e, j, AdapterView.OnItemClickListener {
  private Rect n;
  
  protected static int l(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i2 = paramListAdapter.getCount();
    ViewGroup viewGroup2 = null;
    int k = 0;
    int m = 0;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (i < i2) {
      FrameLayout frameLayout2;
      int i4 = paramListAdapter.getItemViewType(i);
      int i3 = m;
      if (i4 != m) {
        paramViewGroup = null;
        i3 = i4;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(i, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(n, i1);
      i4 = view.getMeasuredWidth();
      if (i4 >= paramInt)
        return paramInt; 
      m = k;
      if (i4 > k)
        m = i4; 
      i++;
      k = m;
      m = i3;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return k;
  }
  
  protected static boolean u(e parame) {
    int k = parame.size();
    for (int i = 0; i < k; i++) {
      MenuItem menuItem = parame.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  protected static d v(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (d)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (d)paramListAdapter;
  }
  
  public void b(Context paramContext, e parame) {}
  
  public abstract void e(e parame);
  
  public boolean g(e parame, g paramg) {
    return false;
  }
  
  public boolean h(e parame, g paramg) {
    return false;
  }
  
  protected boolean j() {
    return true;
  }
  
  public Rect k() {
    return this.n;
  }
  
  public abstract void m(View paramView);
  
  public void n(Rect paramRect) {
    this.n = paramRect;
  }
  
  public abstract void o(boolean paramBoolean);
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    e e1 = (v(listAdapter)).n;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (j()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    e1.M(menuItem, this, paramInt);
  }
  
  public abstract void p(int paramInt);
  
  public abstract void q(int paramInt);
  
  public abstract void r(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void s(boolean paramBoolean);
  
  public abstract void t(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */