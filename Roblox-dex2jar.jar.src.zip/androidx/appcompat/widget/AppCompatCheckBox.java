package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import d.a;
import f.a;

public class AppCompatCheckBox extends CheckBox {
  private final c mBackgroundTintHelper;
  
  private final d mCompoundButtonHelper;
  
  private final k mTextHelper;
  
  public AppCompatCheckBox(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.t);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(TintContextWrapper.wrap(paramContext), paramAttributeSet, paramInt);
    ThemeUtils.checkAppCompatTheme((View)this, getContext());
    d d1 = new d((CompoundButton)this);
    this.mCompoundButtonHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    c c1 = new c((View)this);
    this.mBackgroundTintHelper = c1;
    c1.e(paramAttributeSet, paramInt);
    k k1 = new k((TextView)this);
    this.mTextHelper = k1;
    k1.m(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.b(); 
    k k1 = this.mTextHelper;
    if (k1 != null)
      k1.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int j = super.getCompoundPaddingLeft();
    d d1 = this.mCompoundButtonHelper;
    int i = j;
    if (d1 != null)
      i = d1.b(j); 
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    d d1 = this.mCompoundButtonHelper;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    d d1 = this.mCompoundButtonHelper;
    return (d1 != null) ? d1.d() : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.d(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    d d1 = this.mCompoundButtonHelper;
    if (d1 != null)
      d1.f(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    d d1 = this.mCompoundButtonHelper;
    if (d1 != null)
      d1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mCompoundButtonHelper;
    if (d1 != null)
      d1.h(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */