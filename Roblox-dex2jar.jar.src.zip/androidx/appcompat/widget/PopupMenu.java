package androidx.appcompat.widget;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.i;
import j.g;
import k.e;

public class PopupMenu {
  private final View mAnchor;
  
  private final Context mContext;
  
  private View.OnTouchListener mDragListener;
  
  private final e mMenu;
  
  OnMenuItemClickListener mMenuItemClickListener;
  
  OnDismissListener mOnDismissListener;
  
  final i mPopup;
  
  public PopupMenu(Context paramContext, View paramView) {
    this(paramContext, paramView, 0);
  }
  
  public PopupMenu(Context paramContext, View paramView, int paramInt) {
    this(paramContext, paramView, paramInt, d.a.H, 0);
  }
  
  public PopupMenu(Context paramContext, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    this.mContext = paramContext;
    this.mAnchor = paramView;
    e e1 = new e(paramContext);
    this.mMenu = e1;
    e1.R(new a(this));
    i i1 = new i(paramContext, e1, paramView, false, paramInt2, paramInt3);
    this.mPopup = i1;
    i1.j(paramInt1);
    i1.k(new b(this));
  }
  
  public void dismiss() {
    this.mPopup.b();
  }
  
  public View.OnTouchListener getDragToOpenListener() {
    if (this.mDragListener == null)
      this.mDragListener = new c(this, this.mAnchor); 
    return this.mDragListener;
  }
  
  public int getGravity() {
    return this.mPopup.c();
  }
  
  public Menu getMenu() {
    return (Menu)this.mMenu;
  }
  
  public MenuInflater getMenuInflater() {
    return (MenuInflater)new g(this.mContext);
  }
  
  ListView getMenuListView() {
    return !this.mPopup.f() ? null : this.mPopup.d();
  }
  
  public void inflate(int paramInt) {
    getMenuInflater().inflate(paramInt, (Menu)this.mMenu);
  }
  
  public void setGravity(int paramInt) {
    this.mPopup.j(paramInt);
  }
  
  public void setOnDismissListener(OnDismissListener paramOnDismissListener) {
    this.mOnDismissListener = paramOnDismissListener;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.mMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void show() {
    this.mPopup.m();
  }
  
  public static interface OnDismissListener {
    void onDismiss(PopupMenu param1PopupMenu);
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  class a implements e.a {
    a(PopupMenu this$0) {}
    
    public boolean a(e param1e, MenuItem param1MenuItem) {
      PopupMenu.OnMenuItemClickListener onMenuItemClickListener = this.n.mMenuItemClickListener;
      return (onMenuItemClickListener != null) ? onMenuItemClickListener.onMenuItemClick(param1MenuItem) : false;
    }
    
    public void b(e param1e) {}
  }
  
  class b implements PopupWindow.OnDismissListener {
    b(PopupMenu this$0) {}
    
    public void onDismiss() {
      PopupMenu popupMenu = this.n;
      PopupMenu.OnDismissListener onDismissListener = popupMenu.mOnDismissListener;
      if (onDismissListener != null)
        onDismissListener.onDismiss(popupMenu); 
    }
  }
  
  class c extends ForwardingListener {
    c(PopupMenu this$0, View param1View) {
      super(param1View);
    }
    
    public e getPopup() {
      return (e)this.n.mPopup.e();
    }
    
    protected boolean onForwardingStarted() {
      this.n.show();
      return true;
    }
    
    protected boolean onForwardingStopped() {
      this.n.dismiss();
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\PopupMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */