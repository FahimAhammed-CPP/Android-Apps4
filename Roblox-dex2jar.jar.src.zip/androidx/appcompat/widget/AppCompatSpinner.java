package androidx.appcompat.widget;

import a1.u;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;

public class AppCompatSpinner extends Spinner {
  private static final int[] ATTRS_ANDROID_SPINNERMODE = new int[] { 16843505 };
  
  private static final int MAX_ITEMS_MEASURED = 15;
  
  private static final int MODE_DIALOG = 0;
  
  private static final int MODE_DROPDOWN = 1;
  
  private static final int MODE_THEME = -1;
  
  private static final String TAG = "AppCompatSpinner";
  
  private final c mBackgroundTintHelper;
  
  int mDropDownWidth;
  
  private ForwardingListener mForwardingListener;
  
  private f mPopup;
  
  private final Context mPopupContext;
  
  private final boolean mPopupSet;
  
  private SpinnerAdapter mTempAdapter;
  
  final Rect mTempRect;
  
  public AppCompatSpinner(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public AppCompatSpinner(Context paramContext, int paramInt) {
    this(paramContext, null, d.a.M, paramInt);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, d.a.M);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield mTempRect : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic checkAppCompatTheme : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic d/j.C2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/c
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield mBackgroundTintHelper : Landroidx/appcompat/widget/c;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new j/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield mPopupContext : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #9
    //   74: getstatic d/j.H2 : I
    //   77: iconst_0
    //   78: invokevirtual getResourceId : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new j/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield mPopupContext : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield mPopupContext : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 242
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/AppCompatSpinner.ATTRS_ANDROID_SPINNERMODE : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #8
    //   143: aload #5
    //   145: astore #7
    //   147: aload #5
    //   149: iconst_0
    //   150: invokevirtual hasValue : (I)Z
    //   153: ifeq -> 173
    //   156: aload #5
    //   158: astore #7
    //   160: aload #5
    //   162: iconst_0
    //   163: iconst_0
    //   164: invokevirtual getInt : (II)I
    //   167: istore #6
    //   169: aload #5
    //   171: astore #8
    //   173: aload #8
    //   175: invokevirtual recycle : ()V
    //   178: goto -> 242
    //   181: astore #8
    //   183: goto -> 195
    //   186: astore_1
    //   187: goto -> 230
    //   190: astore #8
    //   192: aconst_null
    //   193: astore #5
    //   195: aload #5
    //   197: astore #7
    //   199: ldc 'AppCompatSpinner'
    //   201: ldc 'Could not read android:spinnerMode'
    //   203: aload #8
    //   205: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   208: pop
    //   209: iload #4
    //   211: istore #6
    //   213: aload #5
    //   215: ifnull -> 242
    //   218: iload #4
    //   220: istore #6
    //   222: aload #5
    //   224: astore #8
    //   226: goto -> 173
    //   229: astore_1
    //   230: aload #7
    //   232: ifnull -> 240
    //   235: aload #7
    //   237: invokevirtual recycle : ()V
    //   240: aload_1
    //   241: athrow
    //   242: iload #6
    //   244: ifeq -> 356
    //   247: iload #6
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 387
    //   256: new androidx/appcompat/widget/AppCompatSpinner$e
    //   259: dup
    //   260: aload_0
    //   261: aload_0
    //   262: getfield mPopupContext : Landroid/content/Context;
    //   265: aload_2
    //   266: iload_3
    //   267: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   270: astore #5
    //   272: aload_0
    //   273: getfield mPopupContext : Landroid/content/Context;
    //   276: aload_2
    //   277: getstatic d/j.C2 : [I
    //   280: iload_3
    //   281: iconst_0
    //   282: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   285: astore #7
    //   287: aload_0
    //   288: aload #7
    //   290: getstatic d/j.G2 : I
    //   293: bipush #-2
    //   295: invokevirtual getLayoutDimension : (II)I
    //   298: putfield mDropDownWidth : I
    //   301: aload #5
    //   303: aload #7
    //   305: getstatic d/j.E2 : I
    //   308: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   311: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   314: aload #5
    //   316: aload #9
    //   318: getstatic d/j.F2 : I
    //   321: invokevirtual getString : (I)Ljava/lang/String;
    //   324: invokevirtual a : (Ljava/lang/CharSequence;)V
    //   327: aload #7
    //   329: invokevirtual recycle : ()V
    //   332: aload_0
    //   333: aload #5
    //   335: putfield mPopup : Landroidx/appcompat/widget/AppCompatSpinner$f;
    //   338: aload_0
    //   339: new androidx/appcompat/widget/AppCompatSpinner$a
    //   342: dup
    //   343: aload_0
    //   344: aload_0
    //   345: aload #5
    //   347: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/view/View;Landroidx/appcompat/widget/AppCompatSpinner$e;)V
    //   350: putfield mForwardingListener : Landroidx/appcompat/widget/ForwardingListener;
    //   353: goto -> 387
    //   356: new androidx/appcompat/widget/AppCompatSpinner$c
    //   359: dup
    //   360: aload_0
    //   361: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;)V
    //   364: astore #5
    //   366: aload_0
    //   367: aload #5
    //   369: putfield mPopup : Landroidx/appcompat/widget/AppCompatSpinner$f;
    //   372: aload #5
    //   374: aload #9
    //   376: getstatic d/j.F2 : I
    //   379: invokevirtual getString : (I)Ljava/lang/String;
    //   382: invokeinterface a : (Ljava/lang/CharSequence;)V
    //   387: aload #9
    //   389: getstatic d/j.D2 : I
    //   392: invokevirtual getTextArray : (I)[Ljava/lang/CharSequence;
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 427
    //   402: new android/widget/ArrayAdapter
    //   405: dup
    //   406: aload_1
    //   407: ldc 17367048
    //   409: aload #5
    //   411: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   414: astore_1
    //   415: aload_1
    //   416: getstatic d/g.v : I
    //   419: invokevirtual setDropDownViewResource : (I)V
    //   422: aload_0
    //   423: aload_1
    //   424: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   427: aload #9
    //   429: invokevirtual recycle : ()V
    //   432: aload_0
    //   433: iconst_1
    //   434: putfield mPopupSet : Z
    //   437: aload_0
    //   438: getfield mTempAdapter : Landroid/widget/SpinnerAdapter;
    //   441: astore_1
    //   442: aload_1
    //   443: ifnull -> 456
    //   446: aload_0
    //   447: aload_1
    //   448: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   451: aload_0
    //   452: aconst_null
    //   453: putfield mTempAdapter : Landroid/widget/SpinnerAdapter;
    //   456: aload_0
    //   457: getfield mBackgroundTintHelper : Landroidx/appcompat/widget/c;
    //   460: aload_2
    //   461: iload_3
    //   462: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   465: return
    // Exception table:
    //   from	to	target	type
    //   123	135	190	java/lang/Exception
    //   123	135	186	finally
    //   147	156	181	java/lang/Exception
    //   147	156	229	finally
    //   160	169	181	java/lang/Exception
    //   160	169	229	finally
    //   199	209	229	finally
  }
  
  int compatMeasureContentWidth(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.mTempRect);
      Rect rect = this.mTempRect;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    f f1 = this.mPopup;
    return (f1 != null) ? f1.getHorizontalOffset() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    f f1 = this.mPopup;
    return (f1 != null) ? f1.getVerticalOffset() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.mPopup != null) ? this.mDropDownWidth : super.getDropDownWidth();
  }
  
  final f getInternalPopup() {
    return this.mPopup;
  }
  
  public Drawable getPopupBackground() {
    f f1 = this.mPopup;
    return (f1 != null) ? f1.getBackground() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.mPopupContext;
  }
  
  public CharSequence getPrompt() {
    f f1 = this.mPopup;
    return (f1 != null) ? f1.d() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    f f1 = this.mPopup;
    if (f1 != null && f1.isShowing())
      this.mPopup.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.mPopup != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), compatMeasureContentWidth(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.n) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    f f1 = this.mPopup;
    if (f1 != null && f1.isShowing()) {
      bool = true;
    } else {
      bool = false;
    } 
    savedState.n = bool;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    ForwardingListener forwardingListener = this.mForwardingListener;
    return (forwardingListener != null && forwardingListener.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    f f1 = this.mPopup;
    if (f1 != null) {
      if (!f1.isShowing())
        showPopup(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.mPopupSet) {
      this.mTempAdapter = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.mPopup != null) {
      Context context2 = this.mPopupContext;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.mPopup.setAdapter(new d(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    f f1 = this.mPopup;
    if (f1 != null) {
      f1.b(paramInt);
      this.mPopup.setHorizontalOffset(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    f f1 = this.mPopup;
    if (f1 != null) {
      f1.setVerticalOffset(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.mPopup != null) {
      this.mDropDownWidth = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    f f1 = this.mPopup;
    if (f1 != null) {
      f1.setBackgroundDrawable(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(f.a.d(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    f f1 = this.mPopup;
    if (f1 != null) {
      f1.a(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.j(paramMode); 
  }
  
  void showPopup() {
    this.mPopup.c(getTextDirection(), getTextAlignment());
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new a();
    
    boolean n;
    
    SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.n = bool;
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.n);
    }
    
    class a implements Parcelable.Creator<SavedState> {
      public AppCompatSpinner.SavedState a(Parcel param2Parcel) {
        return new AppCompatSpinner.SavedState(param2Parcel);
      }
      
      public AppCompatSpinner.SavedState[] b(int param2Int) {
        return new AppCompatSpinner.SavedState[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<SavedState> {
    public AppCompatSpinner.SavedState a(Parcel param1Parcel) {
      return new AppCompatSpinner.SavedState(param1Parcel);
    }
    
    public AppCompatSpinner.SavedState[] b(int param1Int) {
      return new AppCompatSpinner.SavedState[param1Int];
    }
  }
  
  class a extends ForwardingListener {
    a(AppCompatSpinner this$0, View param1View, AppCompatSpinner.e param1e) {
      super(param1View);
    }
    
    public k.e getPopup() {
      return this.n;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean onForwardingStarted() {
      if (!this.o.getInternalPopup().isShowing())
        this.o.showPopup(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      if (!this.n.getInternalPopup().isShowing())
        this.n.showPopup(); 
      ViewTreeObserver viewTreeObserver = this.n.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeOnGlobalLayoutListener(this); 
    }
  }
  
  class c implements f, DialogInterface.OnClickListener {
    androidx.appcompat.app.b n;
    
    private ListAdapter o;
    
    private CharSequence p;
    
    c(AppCompatSpinner this$0) {}
    
    public void a(CharSequence param1CharSequence) {
      this.p = param1CharSequence;
    }
    
    public void b(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void c(int param1Int1, int param1Int2) {
      if (this.o == null)
        return; 
      androidx.appcompat.app.b.a a = new androidx.appcompat.app.b.a(this.q.getPopupContext());
      CharSequence charSequence = this.p;
      if (charSequence != null)
        a.t(charSequence); 
      androidx.appcompat.app.b b1 = a.r(this.o, this.q.getSelectedItemPosition(), this).a();
      this.n = b1;
      ListView listView = b1.f();
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      this.n.show();
    }
    
    public CharSequence d() {
      return this.p;
    }
    
    public void dismiss() {
      androidx.appcompat.app.b b1 = this.n;
      if (b1 != null) {
        b1.dismiss();
        this.n = null;
      } 
    }
    
    public Drawable getBackground() {
      return null;
    }
    
    public int getHorizontalOffset() {
      return 0;
    }
    
    public int getVerticalOffset() {
      return 0;
    }
    
    public boolean isShowing() {
      androidx.appcompat.app.b b1 = this.n;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.q.setSelection(param1Int);
      if (this.q.getOnItemClickListener() != null)
        this.q.performItemClick(null, param1Int, this.o.getItemId(param1Int)); 
      dismiss();
    }
    
    public void setAdapter(ListAdapter param1ListAdapter) {
      this.o = param1ListAdapter;
    }
    
    public void setBackgroundDrawable(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public void setHorizontalOffset(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void setVerticalOffset(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
  }
  
  private static class d implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter n;
    
    private ListAdapter o;
    
    public d(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.n = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.o = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (themedSpinnerAdapter.getDropDownViewTheme() != param1Theme) {
            themedSpinnerAdapter.setDropDownViewTheme(param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof ThemedSpinnerAdapter) {
          ThemedSpinnerAdapter themedSpinnerAdapter1 = (ThemedSpinnerAdapter)themedSpinnerAdapter;
          if (themedSpinnerAdapter1.getDropDownViewTheme() == null)
            themedSpinnerAdapter1.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.o;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.n;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.n;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.n;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.n;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.n;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.o;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.n;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.n;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class e extends ListPopupWindow implements f {
    private CharSequence n;
    
    ListAdapter o;
    
    private final Rect p = new Rect();
    
    private int q;
    
    public e(AppCompatSpinner this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      setAnchorView((View)this$0);
      setModal(true);
      setPromptPosition(0);
      setOnItemClickListener(new a(this, this$0));
    }
    
    public void a(CharSequence param1CharSequence) {
      this.n = param1CharSequence;
    }
    
    public void b(int param1Int) {
      this.q = param1Int;
    }
    
    public void c(int param1Int1, int param1Int2) {
      boolean bool = isShowing();
      f();
      setInputMethodMode(2);
      show();
      ListView listView = getListView();
      listView.setChoiceMode(1);
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      setSelection(this.r.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.r.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        setOnDismissListener(new c(this, b));
      } 
    }
    
    public CharSequence d() {
      return this.n;
    }
    
    void f() {
      Drawable drawable = getBackground();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.r.mTempRect);
        if (ViewUtils.isLayoutRtl((View)this.r)) {
          i = this.r.mTempRect.right;
        } else {
          i = -this.r.mTempRect.left;
        } 
      } else {
        Rect rect = this.r.mTempRect;
        rect.right = 0;
        rect.left = 0;
      } 
      int k = this.r.getPaddingLeft();
      int m = this.r.getPaddingRight();
      int n = this.r.getWidth();
      AppCompatSpinner appCompatSpinner = this.r;
      int j = appCompatSpinner.mDropDownWidth;
      if (j == -2) {
        int i1 = appCompatSpinner.compatMeasureContentWidth((SpinnerAdapter)this.o, getBackground());
        j = (this.r.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.r.mTempRect;
        int i2 = j - rect.left - rect.right;
        j = i1;
        if (i1 > i2)
          j = i2; 
        setContentWidth(Math.max(j, n - k - m));
      } else if (j == -1) {
        setContentWidth(n - k - m);
      } else {
        setContentWidth(j);
      } 
      if (ViewUtils.isLayoutRtl((View)this.r)) {
        i += n - m - getWidth() - g();
      } else {
        i += k + g();
      } 
      setHorizontalOffset(i);
    }
    
    public int g() {
      return this.q;
    }
    
    boolean h(View param1View) {
      return (u.S(param1View) && param1View.getGlobalVisibleRect(this.p));
    }
    
    public void setAdapter(ListAdapter param1ListAdapter) {
      super.setAdapter(param1ListAdapter);
      this.o = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(AppCompatSpinner.e this$0, AppCompatSpinner param2AppCompatSpinner) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.o.r.setSelection(param2Int);
        if (this.o.r.getOnItemClickListener() != null) {
          AppCompatSpinner.e e1 = this.o;
          e1.r.performItemClick(param2View, param2Int, e1.o.getItemId(param2Int));
        } 
        this.o.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(AppCompatSpinner.e this$0) {}
      
      public void onGlobalLayout() {
        AppCompatSpinner.e e1 = this.n;
        if (!e1.h((View)e1.r)) {
          this.n.dismiss();
          return;
        } 
        this.n.f();
        AppCompatSpinner.e.e(this.n);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(AppCompatSpinner.e this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.o.r.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.n); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(AppCompatSpinner this$0, AppCompatSpinner param1AppCompatSpinner) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.o.r.setSelection(param1Int);
      if (this.o.r.getOnItemClickListener() != null) {
        AppCompatSpinner.e e1 = this.o;
        e1.r.performItemClick(param1View, param1Int, e1.o.getItemId(param1Int));
      } 
      this.o.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      AppCompatSpinner.e e1 = this.n;
      if (!e1.h((View)e1.r)) {
        this.n.dismiss();
        return;
      } 
      this.n.f();
      AppCompatSpinner.e.e(this.n);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(AppCompatSpinner this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.o.r.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.n); 
    }
  }
  
  static interface f {
    void a(CharSequence param1CharSequence);
    
    void b(int param1Int);
    
    void c(int param1Int1, int param1Int2);
    
    CharSequence d();
    
    void dismiss();
    
    Drawable getBackground();
    
    int getHorizontalOffset();
    
    int getVerticalOffset();
    
    boolean isShowing();
    
    void setAdapter(ListAdapter param1ListAdapter);
    
    void setBackgroundDrawable(Drawable param1Drawable);
    
    void setHorizontalOffset(int param1Int);
    
    void setVerticalOffset(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\AppCompatSpinner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */