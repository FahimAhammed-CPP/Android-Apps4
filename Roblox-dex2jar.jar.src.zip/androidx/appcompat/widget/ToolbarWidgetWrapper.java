package androidx.appcompat.widget;

import a1.a0;
import a1.u;
import a1.y;
import a1.z;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import d.e;
import d.f;
import d.h;
import d.j;

public class ToolbarWidgetWrapper implements DecorToolbar {
  private static final int AFFECTS_LOGO_MASK = 3;
  
  private static final long DEFAULT_FADE_DURATION_MS = 200L;
  
  private static final String TAG = "ToolbarWidgetWrapper";
  
  private b mActionMenuPresenter;
  
  private View mCustomView;
  
  private int mDefaultNavigationContentDescription;
  
  private Drawable mDefaultNavigationIcon;
  
  private int mDisplayOpts;
  
  private CharSequence mHomeDescription;
  
  private Drawable mIcon;
  
  private Drawable mLogo;
  
  boolean mMenuPrepared;
  
  private Drawable mNavIcon;
  
  private int mNavigationMode;
  
  private Spinner mSpinner;
  
  private CharSequence mSubtitle;
  
  private View mTabView;
  
  CharSequence mTitle;
  
  private boolean mTitleSet;
  
  Toolbar mToolbar;
  
  Window.Callback mWindowCallback;
  
  public ToolbarWidgetWrapper(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.a, e.n);
  }
  
  public ToolbarWidgetWrapper(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.mNavigationMode = 0;
    this.mDefaultNavigationContentDescription = 0;
    this.mToolbar = paramToolbar;
    this.mTitle = paramToolbar.getTitle();
    this.mSubtitle = paramToolbar.getSubtitle();
    if (this.mTitle != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mTitleSet = bool;
    this.mNavIcon = paramToolbar.getNavigationIcon();
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramToolbar.getContext(), null, j.a, d.a.c, 0);
    this.mDefaultNavigationIcon = tintTypedArray.getDrawable(j.l);
    if (paramBoolean) {
      CharSequence charSequence = tintTypedArray.getText(j.r);
      if (!TextUtils.isEmpty(charSequence))
        setTitle(charSequence); 
      charSequence = tintTypedArray.getText(j.p);
      if (!TextUtils.isEmpty(charSequence))
        setSubtitle(charSequence); 
      Drawable drawable = tintTypedArray.getDrawable(j.n);
      if (drawable != null)
        setLogo(drawable); 
      drawable = tintTypedArray.getDrawable(j.m);
      if (drawable != null)
        setIcon(drawable); 
      if (this.mNavIcon == null) {
        drawable = this.mDefaultNavigationIcon;
        if (drawable != null)
          setNavigationIcon(drawable); 
      } 
      setDisplayOptions(tintTypedArray.getInt(j.h, 0));
      paramInt2 = tintTypedArray.getResourceId(j.g, 0);
      if (paramInt2 != 0) {
        setCustomView(LayoutInflater.from(this.mToolbar.getContext()).inflate(paramInt2, this.mToolbar, false));
        setDisplayOptions(this.mDisplayOpts | 0x10);
      } 
      paramInt2 = tintTypedArray.getLayoutDimension(j.j, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.mToolbar.getLayoutParams();
        layoutParams.height = paramInt2;
        this.mToolbar.setLayoutParams(layoutParams);
      } 
      paramInt2 = tintTypedArray.getDimensionPixelOffset(j.f, -1);
      int i = tintTypedArray.getDimensionPixelOffset(j.e, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.mToolbar.setContentInsetsRelative(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = tintTypedArray.getResourceId(j.s, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.mToolbar;
        toolbar.setTitleTextAppearance(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = tintTypedArray.getResourceId(j.q, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.mToolbar;
        toolbar.setSubtitleTextAppearance(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = tintTypedArray.getResourceId(j.o, 0);
      if (paramInt2 != 0)
        this.mToolbar.setPopupTheme(paramInt2); 
    } else {
      this.mDisplayOpts = detectDisplayOptions();
    } 
    tintTypedArray.recycle();
    setDefaultNavigationContentDescription(paramInt1);
    this.mHomeDescription = this.mToolbar.getNavigationContentDescription();
    this.mToolbar.setNavigationOnClickListener(new a(this));
  }
  
  private int detectDisplayOptions() {
    if (this.mToolbar.getNavigationIcon() != null) {
      this.mDefaultNavigationIcon = this.mToolbar.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  private void ensureSpinner() {
    if (this.mSpinner == null) {
      this.mSpinner = new AppCompatSpinner(getContext(), null, d.a.i);
      Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(-2, -2, 8388627);
      this.mSpinner.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
  }
  
  private void setTitleInt(CharSequence paramCharSequence) {
    this.mTitle = paramCharSequence;
    if ((this.mDisplayOpts & 0x8) != 0)
      this.mToolbar.setTitle(paramCharSequence); 
  }
  
  private void updateHomeAccessibility() {
    if ((this.mDisplayOpts & 0x4) != 0) {
      if (TextUtils.isEmpty(this.mHomeDescription)) {
        this.mToolbar.setNavigationContentDescription(this.mDefaultNavigationContentDescription);
        return;
      } 
      this.mToolbar.setNavigationContentDescription(this.mHomeDescription);
    } 
  }
  
  private void updateNavigationIcon() {
    if ((this.mDisplayOpts & 0x4) != 0) {
      Toolbar toolbar = this.mToolbar;
      Drawable drawable = this.mNavIcon;
      if (drawable == null)
        drawable = this.mDefaultNavigationIcon; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.mToolbar.setNavigationIcon((Drawable)null);
  }
  
  private void updateToolbarLogo() {
    Drawable drawable;
    int i = this.mDisplayOpts;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.mLogo;
        if (drawable == null)
          drawable = this.mIcon; 
      } else {
        drawable = this.mIcon;
      } 
    } else {
      drawable = null;
    } 
    this.mToolbar.setLogo(drawable);
  }
  
  public void animateToVisibility(int paramInt) {
    y y = setupAnimatorToVisibility(paramInt, 200L);
    if (y != null)
      y.j(); 
  }
  
  public boolean canShowOverflowMenu() {
    return this.mToolbar.canShowOverflowMenu();
  }
  
  public void collapseActionView() {
    this.mToolbar.collapseActionView();
  }
  
  public void dismissPopupMenus() {
    this.mToolbar.dismissPopupMenus();
  }
  
  public Context getContext() {
    return this.mToolbar.getContext();
  }
  
  public View getCustomView() {
    return this.mCustomView;
  }
  
  public int getDisplayOptions() {
    return this.mDisplayOpts;
  }
  
  public int getDropdownItemCount() {
    Spinner spinner = this.mSpinner;
    return (spinner != null) ? spinner.getCount() : 0;
  }
  
  public int getDropdownSelectedPosition() {
    Spinner spinner = this.mSpinner;
    return (spinner != null) ? spinner.getSelectedItemPosition() : 0;
  }
  
  public int getHeight() {
    return this.mToolbar.getHeight();
  }
  
  public Menu getMenu() {
    return this.mToolbar.getMenu();
  }
  
  public int getNavigationMode() {
    return this.mNavigationMode;
  }
  
  public CharSequence getSubtitle() {
    return this.mToolbar.getSubtitle();
  }
  
  public CharSequence getTitle() {
    return this.mToolbar.getTitle();
  }
  
  public ViewGroup getViewGroup() {
    return this.mToolbar;
  }
  
  public int getVisibility() {
    return this.mToolbar.getVisibility();
  }
  
  public boolean hasEmbeddedTabs() {
    return (this.mTabView != null);
  }
  
  public boolean hasExpandedActionView() {
    return this.mToolbar.hasExpandedActionView();
  }
  
  public boolean hasIcon() {
    return (this.mIcon != null);
  }
  
  public boolean hasLogo() {
    return (this.mLogo != null);
  }
  
  public boolean hideOverflowMenu() {
    return this.mToolbar.hideOverflowMenu();
  }
  
  public void initIndeterminateProgress() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void initProgress() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public boolean isOverflowMenuShowPending() {
    return this.mToolbar.isOverflowMenuShowPending();
  }
  
  public boolean isOverflowMenuShowing() {
    return this.mToolbar.isOverflowMenuShowing();
  }
  
  public boolean isTitleTruncated() {
    return this.mToolbar.isTitleTruncated();
  }
  
  public void restoreHierarchyState(SparseArray<Parcelable> paramSparseArray) {
    this.mToolbar.restoreHierarchyState(paramSparseArray);
  }
  
  public void saveHierarchyState(SparseArray<Parcelable> paramSparseArray) {
    this.mToolbar.saveHierarchyState(paramSparseArray);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    u.r0((View)this.mToolbar, paramDrawable);
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.mToolbar.setCollapsible(paramBoolean);
  }
  
  public void setCustomView(View paramView) {
    View view = this.mCustomView;
    if (view != null && (this.mDisplayOpts & 0x10) != 0)
      this.mToolbar.removeView(view); 
    this.mCustomView = paramView;
    if (paramView != null && (this.mDisplayOpts & 0x10) != 0)
      this.mToolbar.addView(paramView); 
  }
  
  public void setDefaultNavigationContentDescription(int paramInt) {
    if (paramInt == this.mDefaultNavigationContentDescription)
      return; 
    this.mDefaultNavigationContentDescription = paramInt;
    if (TextUtils.isEmpty(this.mToolbar.getNavigationContentDescription()))
      setNavigationContentDescription(this.mDefaultNavigationContentDescription); 
  }
  
  public void setDefaultNavigationIcon(Drawable paramDrawable) {
    if (this.mDefaultNavigationIcon != paramDrawable) {
      this.mDefaultNavigationIcon = paramDrawable;
      updateNavigationIcon();
    } 
  }
  
  public void setDisplayOptions(int paramInt) {
    int i = this.mDisplayOpts ^ paramInt;
    this.mDisplayOpts = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          updateHomeAccessibility(); 
        updateNavigationIcon();
      } 
      if ((i & 0x3) != 0)
        updateToolbarLogo(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.mToolbar.setTitle(this.mTitle);
          this.mToolbar.setSubtitle(this.mSubtitle);
        } else {
          this.mToolbar.setTitle((CharSequence)null);
          this.mToolbar.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.mCustomView;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.mToolbar.addView(view);
            return;
          } 
          this.mToolbar.removeView(view);
        } 
      } 
    } 
  }
  
  public void setDropdownParams(SpinnerAdapter paramSpinnerAdapter, AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    ensureSpinner();
    this.mSpinner.setAdapter(paramSpinnerAdapter);
    this.mSpinner.setOnItemSelectedListener(paramOnItemSelectedListener);
  }
  
  public void setDropdownSelectedPosition(int paramInt) {
    Spinner spinner = this.mSpinner;
    if (spinner != null) {
      spinner.setSelection(paramInt);
      return;
    } 
    throw new IllegalStateException("Can't set dropdown selected position without an adapter");
  }
  
  public void setEmbeddedTabView(ScrollingTabContainerView paramScrollingTabContainerView) {
    View view = this.mTabView;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.mToolbar;
      if (viewParent == toolbar)
        toolbar.removeView(this.mTabView); 
    } 
    this.mTabView = (View)paramScrollingTabContainerView;
    if (paramScrollingTabContainerView != null && this.mNavigationMode == 2) {
      this.mToolbar.addView((View)paramScrollingTabContainerView, 0);
      Toolbar.LayoutParams layoutParams = (Toolbar.LayoutParams)this.mTabView.getLayoutParams();
      ((ViewGroup.MarginLayoutParams)layoutParams).width = -2;
      ((ViewGroup.MarginLayoutParams)layoutParams).height = -2;
      layoutParams.gravity = 8388691;
      paramScrollingTabContainerView.setAllowCollapse(true);
    } 
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {}
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = f.a.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mIcon = paramDrawable;
    updateToolbarLogo();
  }
  
  public void setLogo(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = f.a.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setLogo(drawable);
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.mLogo = paramDrawable;
    updateToolbarLogo();
  }
  
  public void setMenu(Menu paramMenu, j.a parama) {
    if (this.mActionMenuPresenter == null) {
      b b1 = new b(this.mToolbar.getContext());
      this.mActionMenuPresenter = b1;
      b1.q(f.g);
    } 
    this.mActionMenuPresenter.i(parama);
    this.mToolbar.setMenu((e)paramMenu, this.mActionMenuPresenter);
  }
  
  public void setMenuCallbacks(j.a parama, e.a parama1) {
    this.mToolbar.setMenuCallbacks(parama, parama1);
  }
  
  public void setMenuPrepared() {
    this.mMenuPrepared = true;
  }
  
  public void setNavigationContentDescription(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = getContext().getString(paramInt);
    } 
    setNavigationContentDescription(str);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    this.mHomeDescription = paramCharSequence;
    updateHomeAccessibility();
  }
  
  public void setNavigationIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = f.a.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setNavigationIcon(drawable);
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    this.mNavIcon = paramDrawable;
    updateNavigationIcon();
  }
  
  public void setNavigationMode(int paramInt) {
    int i = this.mNavigationMode;
    if (paramInt != i) {
      if (i != 1) {
        if (i == 2) {
          View view = this.mTabView;
          if (view != null) {
            ViewParent viewParent = view.getParent();
            Toolbar toolbar = this.mToolbar;
            if (viewParent == toolbar)
              toolbar.removeView(this.mTabView); 
          } 
        } 
      } else {
        Spinner spinner = this.mSpinner;
        if (spinner != null) {
          ViewParent viewParent = spinner.getParent();
          Toolbar toolbar = this.mToolbar;
          if (viewParent == toolbar)
            toolbar.removeView((View)this.mSpinner); 
        } 
      } 
      this.mNavigationMode = paramInt;
      if (paramInt != 0)
        if (paramInt != 1) {
          if (paramInt == 2) {
            View view = this.mTabView;
            if (view != null) {
              this.mToolbar.addView(view, 0);
              Toolbar.LayoutParams layoutParams = (Toolbar.LayoutParams)this.mTabView.getLayoutParams();
              ((ViewGroup.MarginLayoutParams)layoutParams).width = -2;
              ((ViewGroup.MarginLayoutParams)layoutParams).height = -2;
              layoutParams.gravity = 8388691;
              return;
            } 
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid navigation mode ");
            stringBuilder.append(paramInt);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } else {
          ensureSpinner();
          this.mToolbar.addView((View)this.mSpinner, 0);
        }  
    } 
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.mSubtitle = paramCharSequence;
    if ((this.mDisplayOpts & 0x8) != 0)
      this.mToolbar.setSubtitle(paramCharSequence); 
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mTitleSet = true;
    setTitleInt(paramCharSequence);
  }
  
  public void setVisibility(int paramInt) {
    this.mToolbar.setVisibility(paramInt);
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.mWindowCallback = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.mTitleSet)
      setTitleInt(paramCharSequence); 
  }
  
  public y setupAnimatorToVisibility(int paramInt, long paramLong) {
    float f;
    y y = u.d((View)this.mToolbar);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return y.a(f).d(paramLong).f((z)new b(this, paramInt));
  }
  
  public boolean showOverflowMenu() {
    return this.mToolbar.showOverflowMenu();
  }
  
  class a implements View.OnClickListener {
    final k.a n;
    
    a(ToolbarWidgetWrapper this$0) {
      this.n = new k.a(this$0.mToolbar.getContext(), 0, 16908332, 0, 0, this$0.mTitle);
    }
    
    public void onClick(View param1View) {
      ToolbarWidgetWrapper toolbarWidgetWrapper = this.o;
      Window.Callback callback = toolbarWidgetWrapper.mWindowCallback;
      if (callback != null && toolbarWidgetWrapper.mMenuPrepared)
        callback.onMenuItemSelected(0, (MenuItem)this.n); 
    }
  }
  
  class b extends a0 {
    private boolean a = false;
    
    b(ToolbarWidgetWrapper this$0, int param1Int) {}
    
    public void onAnimationCancel(View param1View) {
      this.a = true;
    }
    
    public void onAnimationEnd(View param1View) {
      if (!this.a)
        this.c.mToolbar.setVisibility(this.b); 
    }
    
    public void onAnimationStart(View param1View) {
      this.c.mToolbar.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\ToolbarWidgetWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */