package androidx.appcompat.widget;

import a1.u;
import a1.y;
import a1.z;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import d.j;

abstract class AbsActionBarView extends ViewGroup {
  private static final int FADE_DURATION = 200;
  
  protected b mActionMenuPresenter;
  
  protected int mContentHeight;
  
  private boolean mEatingHover;
  
  private boolean mEatingTouch;
  
  protected ActionMenuView mMenuView;
  
  protected final Context mPopupContext;
  
  protected final VisibilityAnimListener mVisAnimListener = new VisibilityAnimListener();
  
  protected y mVisibilityAnim;
  
  AbsActionBarView(Context paramContext) {
    this(paramContext, null);
  }
  
  AbsActionBarView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  AbsActionBarView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(d.a.a, typedValue, true) && typedValue.resourceId != 0) {
      this.mPopupContext = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.mPopupContext = paramContext;
  }
  
  protected static int next(int paramInt1, int paramInt2, boolean paramBoolean) {
    return paramBoolean ? (paramInt1 - paramInt2) : (paramInt1 + paramInt2);
  }
  
  public void animateToVisibility(int paramInt) {
    setupAnimatorToVisibility(paramInt, 200L).j();
  }
  
  public boolean canShowOverflowMenu() {
    return (isOverflowReserved() && getVisibility() == 0);
  }
  
  public void dismissPopupMenus() {
    b b1 = this.mActionMenuPresenter;
    if (b1 != null)
      b1.z(); 
  }
  
  public int getAnimatedVisibility() {
    return (this.mVisibilityAnim != null) ? this.mVisAnimListener.mFinalVisibility : getVisibility();
  }
  
  public int getContentHeight() {
    return this.mContentHeight;
  }
  
  public boolean hideOverflowMenu() {
    b b1 = this.mActionMenuPresenter;
    return (b1 != null) ? b1.C() : false;
  }
  
  public boolean isOverflowMenuShowPending() {
    b b1 = this.mActionMenuPresenter;
    return (b1 != null) ? b1.E() : false;
  }
  
  public boolean isOverflowMenuShowing() {
    b b1 = this.mActionMenuPresenter;
    return (b1 != null) ? b1.F() : false;
  }
  
  public boolean isOverflowReserved() {
    b b1 = this.mActionMenuPresenter;
    return (b1 != null && b1.G());
  }
  
  protected int measureChildView(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, j.a, d.a.c, 0);
    setContentHeight(typedArray.getLayoutDimension(j.j, 0));
    typedArray.recycle();
    b b1 = this.mActionMenuPresenter;
    if (b1 != null)
      b1.H(paramConfiguration); 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.mEatingHover = false; 
    if (!this.mEatingHover) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.mEatingHover = true; 
    } 
    if (i == 10 || i == 3)
      this.mEatingHover = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.mEatingTouch = false; 
    if (!this.mEatingTouch) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.mEatingTouch = true; 
    } 
    if (i == 1 || i == 3)
      this.mEatingTouch = false; 
    return true;
  }
  
  protected int positionChild(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 += (paramInt3 - j) / 2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public void postShowOverflowMenu() {
    post(new a(this));
  }
  
  public void setContentHeight(int paramInt) {
    this.mContentHeight = paramInt;
    requestLayout();
  }
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      y y1 = this.mVisibilityAnim;
      if (y1 != null)
        y1.b(); 
      super.setVisibility(paramInt);
    } 
  }
  
  public y setupAnimatorToVisibility(int paramInt, long paramLong) {
    y y1 = this.mVisibilityAnim;
    if (y1 != null)
      y1.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      y1 = u.d((View)this).a(1.0F);
      y1.d(paramLong);
      y1.f(this.mVisAnimListener.withFinalVisibility(y1, paramInt));
      return y1;
    } 
    y1 = u.d((View)this).a(0.0F);
    y1.d(paramLong);
    y1.f(this.mVisAnimListener.withFinalVisibility(y1, paramInt));
    return y1;
  }
  
  public boolean showOverflowMenu() {
    b b1 = this.mActionMenuPresenter;
    return (b1 != null) ? b1.M() : false;
  }
  
  protected class VisibilityAnimListener implements z {
    private boolean mCanceled = false;
    
    int mFinalVisibility;
    
    public void onAnimationCancel(View param1View) {
      this.mCanceled = true;
    }
    
    public void onAnimationEnd(View param1View) {
      if (this.mCanceled)
        return; 
      AbsActionBarView absActionBarView = AbsActionBarView.this;
      absActionBarView.mVisibilityAnim = null;
      absActionBarView.setVisibility(this.mFinalVisibility);
    }
    
    public void onAnimationStart(View param1View) {
      AbsActionBarView.this.setVisibility(0);
      this.mCanceled = false;
    }
    
    public VisibilityAnimListener withFinalVisibility(y param1y, int param1Int) {
      AbsActionBarView.this.mVisibilityAnim = param1y;
      this.mFinalVisibility = param1Int;
      return this;
    }
  }
  
  class a implements Runnable {
    a(AbsActionBarView this$0) {}
    
    public void run() {
      this.n.showOverflowMenu();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\AbsActionBarView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */