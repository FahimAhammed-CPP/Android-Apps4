package androidx.appcompat.widget;

import a1.u;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import d.j;
import t0.a;

class i extends g {
  private final SeekBar d;
  
  private Drawable e;
  
  private ColorStateList f = null;
  
  private PorterDuff.Mode g = null;
  
  private boolean h = false;
  
  private boolean i = false;
  
  i(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  private void f() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.r(drawable.mutate());
      this.e = drawable;
      if (this.h)
        a.o(drawable, this.f); 
      if (this.i)
        a.p(this.e, this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    super.c(paramAttributeSet, paramInt);
    Context context = this.d.getContext();
    int[] arrayOfInt = j.X;
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    SeekBar seekBar = this.d;
    u.m0((View)seekBar, seekBar.getContext(), arrayOfInt, paramAttributeSet, tintTypedArray.getWrappedTypeArray(), paramInt, 0);
    Drawable drawable = tintTypedArray.getDrawableIfKnown(j.Y);
    if (drawable != null)
      this.d.setThumb(drawable); 
    j(tintTypedArray.getDrawable(j.Z));
    paramInt = j.b0;
    if (tintTypedArray.hasValue(paramInt)) {
      this.g = DrawableUtils.parseTintMode(tintTypedArray.getInt(paramInt, -1), this.g);
      this.i = true;
    } 
    paramInt = j.a0;
    if (tintTypedArray.hasValue(paramInt)) {
      this.f = tintTypedArray.getColorStateList(paramInt);
      this.h = true;
    } 
    tintTypedArray.recycle();
    f();
  }
  
  void g(Canvas paramCanvas) {
    if (this.e != null) {
      int k = this.d.getMax();
      int j = 1;
      if (k > 1) {
        int m = this.e.getIntrinsicWidth();
        int n = this.e.getIntrinsicHeight();
        if (m >= 0) {
          m /= 2;
        } else {
          m = 1;
        } 
        if (n >= 0)
          j = n / 2; 
        this.e.setBounds(-m, -j, m, j);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / k;
        j = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (m = 0; m <= k; m++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(j);
      } 
    } 
  }
  
  void h() {
    Drawable drawable = this.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(this.d.getDrawableState()))
      this.d.invalidateDrawable(drawable); 
  }
  
  void i() {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  void j(Drawable paramDrawable) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.setCallback(null); 
    this.e = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this.d);
      a.m(paramDrawable, u.C((View)this.d));
      if (paramDrawable.isStateful())
        paramDrawable.setState(this.d.getDrawableState()); 
      f();
    } 
    this.d.invalidate();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */