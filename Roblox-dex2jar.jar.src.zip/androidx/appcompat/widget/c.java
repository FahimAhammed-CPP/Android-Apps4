package androidx.appcompat.widget;

import a1.u;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import d.j;

class c {
  private final View a;
  
  private final AppCompatDrawableManager b;
  
  private int c = -1;
  
  private TintInfo d;
  
  private TintInfo e;
  
  private TintInfo f;
  
  c(View paramView) {
    this.a = paramView;
    this.b = AppCompatDrawableManager.get();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new TintInfo(); 
    TintInfo tintInfo = this.f;
    tintInfo.clear();
    ColorStateList colorStateList = u.s(this.a);
    if (colorStateList != null) {
      tintInfo.mHasTintList = true;
      tintInfo.mTintList = colorStateList;
    } 
    PorterDuff.Mode mode = u.t(this.a);
    if (mode != null) {
      tintInfo.mHasTintMode = true;
      tintInfo.mTintMode = mode;
    } 
    if (tintInfo.mHasTintList || tintInfo.mHasTintMode) {
      AppCompatDrawableManager.tintDrawable(paramDrawable, tintInfo, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      TintInfo tintInfo = this.e;
      if (tintInfo != null) {
        AppCompatDrawableManager.tintDrawable(drawable, tintInfo, this.a.getDrawableState());
        return;
      } 
      tintInfo = this.d;
      if (tintInfo != null)
        AppCompatDrawableManager.tintDrawable(drawable, tintInfo, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    TintInfo tintInfo = this.e;
    return (tintInfo != null) ? tintInfo.mTintList : null;
  }
  
  PorterDuff.Mode d() {
    TintInfo tintInfo = this.e;
    return (tintInfo != null) ? tintInfo.mTintMode : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.T3;
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    u.m0(view, view.getContext(), arrayOfInt, paramAttributeSet, tintTypedArray.getWrappedTypeArray(), paramInt, 0);
    try {
      paramInt = j.U3;
      if (tintTypedArray.hasValue(paramInt)) {
        this.c = tintTypedArray.getResourceId(paramInt, -1);
        ColorStateList colorStateList = this.b.getTintList(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.V3;
      if (tintTypedArray.hasValue(paramInt))
        u.s0(this.a, tintTypedArray.getColorStateList(paramInt)); 
      paramInt = j.W3;
      if (tintTypedArray.hasValue(paramInt))
        u.t0(this.a, DrawableUtils.parseTintMode(tintTypedArray.getInt(paramInt, -1), null)); 
      return;
    } finally {
      tintTypedArray.recycle();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    AppCompatDrawableManager appCompatDrawableManager = this.b;
    if (appCompatDrawableManager != null) {
      ColorStateList colorStateList = appCompatDrawableManager.getTintList(this.a.getContext(), paramInt);
    } else {
      appCompatDrawableManager = null;
    } 
    h((ColorStateList)appCompatDrawableManager);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new TintInfo(); 
      TintInfo tintInfo = this.d;
      tintInfo.mTintList = paramColorStateList;
      tintInfo.mHasTintList = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new TintInfo(); 
    TintInfo tintInfo = this.e;
    tintInfo.mTintList = paramColorStateList;
    tintInfo.mHasTintList = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new TintInfo(); 
    TintInfo tintInfo = this.e;
    tintInfo.mTintMode = paramMode;
    tintInfo.mHasTintMode = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */