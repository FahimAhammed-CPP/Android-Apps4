package androidx.appcompat.widget;

import a1.b;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.view.menu.m;
import d.g;
import java.util.ArrayList;

class b extends a implements b.a {
  private boolean A;
  
  private boolean B;
  
  private int C;
  
  private int D;
  
  private int E;
  
  private boolean F;
  
  private boolean G;
  
  private boolean H;
  
  private boolean I;
  
  private int J;
  
  private final SparseBooleanArray K = new SparseBooleanArray();
  
  e L;
  
  a M;
  
  c N;
  
  private b O;
  
  final f P = new f(this);
  
  int Q;
  
  d x;
  
  private Drawable y;
  
  private boolean z;
  
  public b(Context paramContext) {
    super(paramContext, g.c, g.b);
  }
  
  private View A(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.v;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof k.a && ((k.a)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public Drawable B() {
    d d1 = this.x;
    return (d1 != null) ? d1.getDrawable() : (this.z ? this.y : null);
  }
  
  public boolean C() {
    c c1 = this.N;
    if (c1 != null) {
      k k = this.v;
      if (k != null) {
        ((View)k).removeCallbacks(c1);
        this.N = null;
        return true;
      } 
    } 
    e e1 = this.L;
    if (e1 != null) {
      e1.b();
      return true;
    } 
    return false;
  }
  
  public boolean D() {
    a a1 = this.M;
    if (a1 != null) {
      a1.b();
      return true;
    } 
    return false;
  }
  
  public boolean E() {
    return (this.N != null || F());
  }
  
  public boolean F() {
    e e1 = this.L;
    return (e1 != null && e1.f());
  }
  
  public boolean G() {
    return this.A;
  }
  
  public void H(Configuration paramConfiguration) {
    if (!this.F)
      this.E = j.a.b(this.o).d(); 
    androidx.appcompat.view.menu.e e1 = this.p;
    if (e1 != null)
      e1.K(true); 
  }
  
  public void I(boolean paramBoolean) {
    this.I = paramBoolean;
  }
  
  public void J(ActionMenuView paramActionMenuView) {
    this.v = paramActionMenuView;
    paramActionMenuView.initialize(this.p);
  }
  
  public void K(Drawable paramDrawable) {
    d d1 = this.x;
    if (d1 != null) {
      d1.setImageDrawable(paramDrawable);
      return;
    } 
    this.z = true;
    this.y = paramDrawable;
  }
  
  public void L(boolean paramBoolean) {
    this.A = paramBoolean;
    this.B = true;
  }
  
  public boolean M() {
    if (this.A && !F()) {
      androidx.appcompat.view.menu.e e1 = this.p;
      if (e1 != null && this.v != null && this.N == null && !e1.z().isEmpty()) {
        c c1 = new c(this, new e(this, this.o, this.p, (View)this.x, true));
        this.N = c1;
        ((View)this.v).post(c1);
        return true;
      } 
    } 
    return false;
  }
  
  public void a(androidx.appcompat.view.menu.e parame, boolean paramBoolean) {
    z();
    super.a(parame, paramBoolean);
  }
  
  public void b(Context paramContext, androidx.appcompat.view.menu.e parame) {
    super.b(paramContext, parame);
    Resources resources = paramContext.getResources();
    j.a a1 = j.a.b(paramContext);
    if (!this.B)
      this.A = a1.h(); 
    if (!this.H)
      this.C = a1.c(); 
    if (!this.F)
      this.E = a1.d(); 
    int i = this.C;
    if (this.A) {
      if (this.x == null) {
        d d1 = new d(this, this.n);
        this.x = d1;
        if (this.z) {
          d1.setImageDrawable(this.y);
          this.y = null;
          this.z = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.x.measure(j, j);
      } 
      i -= this.x.getMeasuredWidth();
    } else {
      this.x = null;
    } 
    this.D = i;
    this.J = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public boolean c(m paramm) {
    boolean bool = paramm.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    m m1;
    for (m1 = paramm; m1.e0() != this.p; m1 = (m)m1.e0());
    View view = A(m1.getItem());
    if (view == null)
      return false; 
    this.Q = paramm.getItem().getItemId();
    int j = paramm.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramm.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    a a1 = new a(this, this.o, paramm, view);
    this.M = a1;
    a1.i(bool);
    this.M.m();
    super.c(paramm);
    return true;
  }
  
  public void d(boolean paramBoolean) {
    super.d(paramBoolean);
    ((View)this.v).requestLayout();
    androidx.appcompat.view.menu.e<g> e1 = this.p;
    byte b1 = 0;
    if (e1 != null) {
      ArrayList<g> arrayList = e1.s();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        b b2 = ((g)arrayList.get(j)).a();
        if (b2 != null)
          b2.setSubUiVisibilityListener(this); 
      } 
    } 
    e1 = this.p;
    if (e1 != null) {
      ArrayList arrayList = e1.z();
    } else {
      e1 = null;
    } 
    int i = b1;
    if (this.A) {
      i = b1;
      if (e1 != null) {
        int j = e1.size();
        if (j == 1) {
          i = ((g)e1.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b1;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.x == null)
        this.x = new d(this, this.n); 
      ViewGroup viewGroup = (ViewGroup)this.x.getParent();
      if (viewGroup != this.v) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.x); 
        viewGroup = (ActionMenuView)this.v;
        viewGroup.addView((View)this.x, (ViewGroup.LayoutParams)viewGroup.generateOverflowButtonLayoutParams());
      } 
    } else {
      d d1 = this.x;
      if (d1 != null) {
        ViewParent viewParent = d1.getParent();
        k k = this.v;
        if (viewParent == k)
          ((ViewGroup)k).removeView((View)this.x); 
      } 
    } 
    ((ActionMenuView)this.v).setOverflowReserved(this.A);
  }
  
  public void e(boolean paramBoolean) {
    if (paramBoolean) {
      super.c(null);
      return;
    } 
    androidx.appcompat.view.menu.e e1 = this.p;
    if (e1 != null)
      e1.e(false); 
  }
  
  public boolean f() {
    // Byte code:
    //   0: aload_0
    //   1: astore #18
    //   3: aload #18
    //   5: getfield p : Landroidx/appcompat/view/menu/e;
    //   8: astore #17
    //   10: aload #17
    //   12: ifnull -> 32
    //   15: aload #17
    //   17: invokevirtual E : ()Ljava/util/ArrayList;
    //   20: astore #17
    //   22: aload #17
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: goto -> 38
    //   32: aconst_null
    //   33: astore #17
    //   35: iconst_0
    //   36: istore #4
    //   38: aload #18
    //   40: getfield E : I
    //   43: istore_1
    //   44: aload #18
    //   46: getfield D : I
    //   49: istore #10
    //   51: iconst_0
    //   52: iconst_0
    //   53: invokestatic makeMeasureSpec : (II)I
    //   56: istore #11
    //   58: aload #18
    //   60: getfield v : Landroidx/appcompat/view/menu/k;
    //   63: checkcast android/view/ViewGroup
    //   66: astore #19
    //   68: iconst_0
    //   69: istore_2
    //   70: iconst_0
    //   71: istore #6
    //   73: iconst_0
    //   74: istore_3
    //   75: iconst_0
    //   76: istore #5
    //   78: iload_2
    //   79: iload #4
    //   81: if_icmpge -> 165
    //   84: aload #17
    //   86: iload_2
    //   87: invokevirtual get : (I)Ljava/lang/Object;
    //   90: checkcast androidx/appcompat/view/menu/g
    //   93: astore #20
    //   95: aload #20
    //   97: invokevirtual o : ()Z
    //   100: ifeq -> 110
    //   103: iload_3
    //   104: iconst_1
    //   105: iadd
    //   106: istore_3
    //   107: goto -> 130
    //   110: aload #20
    //   112: invokevirtual n : ()Z
    //   115: ifeq -> 127
    //   118: iload #5
    //   120: iconst_1
    //   121: iadd
    //   122: istore #5
    //   124: goto -> 130
    //   127: iconst_1
    //   128: istore #6
    //   130: iload_1
    //   131: istore #7
    //   133: aload #18
    //   135: getfield I : Z
    //   138: ifeq -> 155
    //   141: iload_1
    //   142: istore #7
    //   144: aload #20
    //   146: invokevirtual isActionViewExpanded : ()Z
    //   149: ifeq -> 155
    //   152: iconst_0
    //   153: istore #7
    //   155: iload_2
    //   156: iconst_1
    //   157: iadd
    //   158: istore_2
    //   159: iload #7
    //   161: istore_1
    //   162: goto -> 78
    //   165: iload_1
    //   166: istore_2
    //   167: aload #18
    //   169: getfield A : Z
    //   172: ifeq -> 194
    //   175: iload #6
    //   177: ifne -> 190
    //   180: iload_1
    //   181: istore_2
    //   182: iload #5
    //   184: iload_3
    //   185: iadd
    //   186: iload_1
    //   187: if_icmple -> 194
    //   190: iload_1
    //   191: iconst_1
    //   192: isub
    //   193: istore_2
    //   194: iload_2
    //   195: iload_3
    //   196: isub
    //   197: istore_1
    //   198: aload #18
    //   200: getfield K : Landroid/util/SparseBooleanArray;
    //   203: astore #20
    //   205: aload #20
    //   207: invokevirtual clear : ()V
    //   210: aload #18
    //   212: getfield G : Z
    //   215: ifeq -> 242
    //   218: aload #18
    //   220: getfield J : I
    //   223: istore_2
    //   224: iload #10
    //   226: iload_2
    //   227: idiv
    //   228: istore_3
    //   229: iload_2
    //   230: iload #10
    //   232: iload_2
    //   233: irem
    //   234: iload_3
    //   235: idiv
    //   236: iadd
    //   237: istore #8
    //   239: goto -> 247
    //   242: iconst_0
    //   243: istore #8
    //   245: iconst_0
    //   246: istore_3
    //   247: iconst_0
    //   248: istore #9
    //   250: iconst_0
    //   251: istore_2
    //   252: iload #10
    //   254: istore #6
    //   256: iload #4
    //   258: istore #10
    //   260: aload_0
    //   261: astore #18
    //   263: iload #9
    //   265: iload #10
    //   267: if_icmpge -> 745
    //   270: aload #17
    //   272: iload #9
    //   274: invokevirtual get : (I)Ljava/lang/Object;
    //   277: checkcast androidx/appcompat/view/menu/g
    //   280: astore #21
    //   282: aload #21
    //   284: invokevirtual o : ()Z
    //   287: ifeq -> 394
    //   290: aload #18
    //   292: aload #21
    //   294: aconst_null
    //   295: aload #19
    //   297: invokevirtual o : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   300: astore #22
    //   302: aload #18
    //   304: getfield G : Z
    //   307: ifeq -> 327
    //   310: iload_3
    //   311: aload #22
    //   313: iload #8
    //   315: iload_3
    //   316: iload #11
    //   318: iconst_0
    //   319: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   322: isub
    //   323: istore_3
    //   324: goto -> 336
    //   327: aload #22
    //   329: iload #11
    //   331: iload #11
    //   333: invokevirtual measure : (II)V
    //   336: aload #22
    //   338: invokevirtual getMeasuredWidth : ()I
    //   341: istore #5
    //   343: iload #6
    //   345: iload #5
    //   347: isub
    //   348: istore #7
    //   350: iload_2
    //   351: istore #4
    //   353: iload_2
    //   354: ifne -> 361
    //   357: iload #5
    //   359: istore #4
    //   361: aload #21
    //   363: invokevirtual getGroupId : ()I
    //   366: istore_2
    //   367: iload_2
    //   368: ifeq -> 378
    //   371: aload #20
    //   373: iload_2
    //   374: iconst_1
    //   375: invokevirtual put : (IZ)V
    //   378: aload #21
    //   380: iconst_1
    //   381: invokevirtual u : (Z)V
    //   384: iload #7
    //   386: istore #6
    //   388: iload #4
    //   390: istore_2
    //   391: goto -> 736
    //   394: aload #21
    //   396: invokevirtual n : ()Z
    //   399: ifeq -> 730
    //   402: aload #21
    //   404: invokevirtual getGroupId : ()I
    //   407: istore #12
    //   409: aload #20
    //   411: iload #12
    //   413: invokevirtual get : (I)Z
    //   416: istore #16
    //   418: iload_1
    //   419: ifgt -> 427
    //   422: iload #16
    //   424: ifeq -> 450
    //   427: iload #6
    //   429: ifle -> 450
    //   432: aload #18
    //   434: getfield G : Z
    //   437: ifeq -> 444
    //   440: iload_3
    //   441: ifle -> 450
    //   444: iconst_1
    //   445: istore #13
    //   447: goto -> 453
    //   450: iconst_0
    //   451: istore #13
    //   453: iload #13
    //   455: istore #14
    //   457: iload #13
    //   459: istore #15
    //   461: iload #6
    //   463: istore #7
    //   465: iload_3
    //   466: istore #5
    //   468: iload_2
    //   469: istore #4
    //   471: iload #13
    //   473: ifeq -> 606
    //   476: aload #18
    //   478: aload #21
    //   480: aconst_null
    //   481: aload #19
    //   483: invokevirtual o : (Landroidx/appcompat/view/menu/g;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   486: astore #22
    //   488: aload #18
    //   490: getfield G : Z
    //   493: ifeq -> 532
    //   496: aload #22
    //   498: iload #8
    //   500: iload_3
    //   501: iload #11
    //   503: iconst_0
    //   504: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   507: istore #5
    //   509: iload_3
    //   510: iload #5
    //   512: isub
    //   513: istore #4
    //   515: iload #4
    //   517: istore_3
    //   518: iload #5
    //   520: ifne -> 541
    //   523: iconst_0
    //   524: istore #14
    //   526: iload #4
    //   528: istore_3
    //   529: goto -> 541
    //   532: aload #22
    //   534: iload #11
    //   536: iload #11
    //   538: invokevirtual measure : (II)V
    //   541: aload #22
    //   543: invokevirtual getMeasuredWidth : ()I
    //   546: istore #5
    //   548: iload #6
    //   550: iload #5
    //   552: isub
    //   553: istore #7
    //   555: iload_2
    //   556: istore #4
    //   558: iload_2
    //   559: ifne -> 566
    //   562: iload #5
    //   564: istore #4
    //   566: aload #18
    //   568: getfield G : Z
    //   571: ifeq -> 582
    //   574: iload #7
    //   576: iflt -> 595
    //   579: goto -> 590
    //   582: iload #7
    //   584: iload #4
    //   586: iadd
    //   587: ifle -> 595
    //   590: iconst_1
    //   591: istore_2
    //   592: goto -> 597
    //   595: iconst_0
    //   596: istore_2
    //   597: iload #14
    //   599: iload_2
    //   600: iand
    //   601: istore #15
    //   603: iload_3
    //   604: istore #5
    //   606: iload #15
    //   608: ifeq -> 629
    //   611: iload #12
    //   613: ifeq -> 629
    //   616: aload #20
    //   618: iload #12
    //   620: iconst_1
    //   621: invokevirtual put : (IZ)V
    //   624: iload_1
    //   625: istore_2
    //   626: goto -> 706
    //   629: iload_1
    //   630: istore_2
    //   631: iload #16
    //   633: ifeq -> 706
    //   636: aload #20
    //   638: iload #12
    //   640: iconst_0
    //   641: invokevirtual put : (IZ)V
    //   644: iconst_0
    //   645: istore_3
    //   646: iload_1
    //   647: istore_2
    //   648: iload_3
    //   649: iload #9
    //   651: if_icmpge -> 706
    //   654: aload #17
    //   656: iload_3
    //   657: invokevirtual get : (I)Ljava/lang/Object;
    //   660: checkcast androidx/appcompat/view/menu/g
    //   663: astore #18
    //   665: iload_1
    //   666: istore_2
    //   667: aload #18
    //   669: invokevirtual getGroupId : ()I
    //   672: iload #12
    //   674: if_icmpne -> 697
    //   677: iload_1
    //   678: istore_2
    //   679: aload #18
    //   681: invokevirtual l : ()Z
    //   684: ifeq -> 691
    //   687: iload_1
    //   688: iconst_1
    //   689: iadd
    //   690: istore_2
    //   691: aload #18
    //   693: iconst_0
    //   694: invokevirtual u : (Z)V
    //   697: iload_3
    //   698: iconst_1
    //   699: iadd
    //   700: istore_3
    //   701: iload_2
    //   702: istore_1
    //   703: goto -> 646
    //   706: iload_2
    //   707: istore_1
    //   708: iload #15
    //   710: ifeq -> 717
    //   713: iload_2
    //   714: iconst_1
    //   715: isub
    //   716: istore_1
    //   717: aload #21
    //   719: iload #15
    //   721: invokevirtual u : (Z)V
    //   724: iload #5
    //   726: istore_3
    //   727: goto -> 384
    //   730: aload #21
    //   732: iconst_0
    //   733: invokevirtual u : (Z)V
    //   736: iload #9
    //   738: iconst_1
    //   739: iadd
    //   740: istore #9
    //   742: goto -> 260
    //   745: iconst_1
    //   746: ireturn
  }
  
  public void k(g paramg, k.a parama) {
    parama.b(paramg, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.v;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)parama;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.O == null)
      this.O = new b(this); 
    actionMenuItemView.setPopupCallback(this.O);
  }
  
  public boolean m(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.x) ? false : super.m(paramViewGroup, paramInt);
  }
  
  public View o(g paramg, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramg.getActionView();
    if (view == null || paramg.j())
      view = super.o(paramg, paramView, paramViewGroup); 
    if (paramg.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public k p(ViewGroup paramViewGroup) {
    k k2 = this.v;
    k k1 = super.p(paramViewGroup);
    if (k2 != k1)
      ((ActionMenuView)k1).setPresenter(this); 
    return k1;
  }
  
  public boolean r(int paramInt, g paramg) {
    return paramg.l();
  }
  
  public boolean z() {
    return C() | D();
  }
  
  private class a extends i {
    public a(b this$0, Context param1Context, m param1m, View param1View) {
      super(param1Context, (androidx.appcompat.view.menu.e)param1m, param1View, false, d.a.n);
      if (!((g)param1m.getItem()).l()) {
        View view;
        b.d d2 = this$0.x;
        b.d d1 = d2;
        if (d2 == null)
          view = (View)b.u(this$0); 
        h(view);
      } 
      l(this$0.P);
    }
    
    protected void g() {
      b b1 = this.m;
      b1.M = null;
      b1.Q = 0;
      super.g();
    }
  }
  
  private class b extends ActionMenuItemView.b {
    b(b this$0) {}
    
    public k.e a() {
      b.a a = this.a.M;
      return (k.e)((a != null) ? a.e() : null);
    }
  }
  
  private class c implements Runnable {
    private b.e n;
    
    public c(b this$0, b.e param1e) {
      this.n = param1e;
    }
    
    public void run() {
      if (b.w(this.o) != null)
        b.x(this.o).d(); 
      View view = (View)b.y(this.o);
      if (view != null && view.getWindowToken() != null && this.n.o())
        this.o.L = this.n; 
      this.o.N = null;
    }
  }
  
  private class d extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    public d(b this$0, Context param1Context) {
      super(param1Context, null, d.a.m);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.n.M();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        t0.a.l(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    class a extends ForwardingListener {
      a(b.d this$0, View param2View, b param2b) {
        super(param2View);
      }
      
      public k.e getPopup() {
        b.e e = this.o.n.L;
        return (k.e)((e == null) ? null : e.e());
      }
      
      public boolean onForwardingStarted() {
        this.o.n.M();
        return true;
      }
      
      public boolean onForwardingStopped() {
        b b1 = this.o.n;
        if (b1.N != null)
          return false; 
        b1.C();
        return true;
      }
    }
  }
  
  class a extends ForwardingListener {
    a(b this$0, View param1View, b param1b) {
      super(param1View);
    }
    
    public k.e getPopup() {
      b.e e = this.o.n.L;
      return (k.e)((e == null) ? null : e.e());
    }
    
    public boolean onForwardingStarted() {
      this.o.n.M();
      return true;
    }
    
    public boolean onForwardingStopped() {
      b b1 = this.o.n;
      if (b1.N != null)
        return false; 
      b1.C();
      return true;
    }
  }
  
  private class e extends i {
    public e(b this$0, Context param1Context, androidx.appcompat.view.menu.e param1e, View param1View, boolean param1Boolean) {
      super(param1Context, param1e, param1View, param1Boolean, d.a.n);
      j(8388613);
      l(this$0.P);
    }
    
    protected void g() {
      if (b.s(this.m) != null)
        b.t(this.m).close(); 
      this.m.L = null;
      super.g();
    }
  }
  
  private class f implements j.a {
    f(b this$0) {}
    
    public void a(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (param1e instanceof m)
        param1e.D().e(false); 
      j.a a1 = this.n.n();
      if (a1 != null)
        a1.a(param1e, param1Boolean); 
    }
    
    public boolean b(androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = b.v(this.n);
      boolean bool = false;
      if (param1e == e1)
        return false; 
      this.n.Q = ((m)param1e).getItem().getItemId();
      j.a a1 = this.n.n();
      if (a1 != null)
        bool = a1.b(param1e); 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */