package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import androidx.core.widget.i;
import d.a;
import f.a;

public class AppCompatAutoCompleteTextView extends AutoCompleteTextView {
  private static final int[] TINT_ATTRS = new int[] { 16843126 };
  
  private final c mBackgroundTintHelper;
  
  private final k mTextHelper;
  
  public AppCompatAutoCompleteTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.r);
  }
  
  public AppCompatAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(TintContextWrapper.wrap(paramContext), paramAttributeSet, paramInt);
    ThemeUtils.checkAppCompatTheme((View)this, getContext());
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(getContext(), paramAttributeSet, TINT_ATTRS, paramInt, 0);
    if (tintTypedArray.hasValue(0))
      setDropDownBackgroundDrawable(tintTypedArray.getDrawable(0)); 
    tintTypedArray.recycle();
    c c1 = new c((View)this);
    this.mBackgroundTintHelper = c1;
    c1.e(paramAttributeSet, paramInt);
    k k1 = new k((TextView)this);
    this.mTextHelper = k1;
    k1.m(paramAttributeSet, paramInt);
    k1.b();
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.b(); 
    k k1 = this.mTextHelper;
    if (k1 != null)
      k1.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    c c1 = this.mBackgroundTintHelper;
    return (c1 != null) ? c1.d() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return e.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(i.r((TextView)this, paramCallback));
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.d(getContext(), paramInt));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    c c1 = this.mBackgroundTintHelper;
    if (c1 != null)
      c1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    k k1 = this.mTextHelper;
    if (k1 != null)
      k1.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\AppCompatAutoCompleteTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */