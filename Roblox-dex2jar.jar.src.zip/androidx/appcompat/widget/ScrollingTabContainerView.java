package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class ScrollingTabContainerView extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final int FADE_DURATION = 200;
  
  private static final String TAG = "ScrollingTabContainerView";
  
  private static final Interpolator sAlphaInterpolator = (Interpolator)new DecelerateInterpolator();
  
  private boolean mAllowCollapse;
  
  private int mContentHeight;
  
  int mMaxTabWidth;
  
  private int mSelectedTabIndex;
  
  int mStackedTabMaxWidth;
  
  private c mTabClickListener;
  
  LinearLayoutCompat mTabLayout;
  
  Runnable mTabSelector;
  
  private Spinner mTabSpinner;
  
  protected final VisibilityAnimListener mVisAnimListener = new VisibilityAnimListener();
  
  protected ViewPropertyAnimator mVisibilityAnim;
  
  public ScrollingTabContainerView(Context paramContext) {
    super(paramContext);
    setHorizontalScrollBarEnabled(false);
    j.a a = j.a.b(paramContext);
    setContentHeight(a.f());
    this.mStackedTabMaxWidth = a.e();
    LinearLayoutCompat linearLayoutCompat = createTabLayout();
    this.mTabLayout = linearLayoutCompat;
    addView((View)linearLayoutCompat, new ViewGroup.LayoutParams(-2, -1));
  }
  
  private Spinner createSpinner() {
    AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, d.a.i);
    appCompatSpinner.setLayoutParams((ViewGroup.LayoutParams)new LinearLayoutCompat.LayoutParams(-2, -1));
    appCompatSpinner.setOnItemSelectedListener(this);
    return appCompatSpinner;
  }
  
  private LinearLayoutCompat createTabLayout() {
    LinearLayoutCompat linearLayoutCompat = new LinearLayoutCompat(getContext(), null, d.a.d);
    linearLayoutCompat.setMeasureWithLargestChildEnabled(true);
    linearLayoutCompat.setGravity(17);
    linearLayoutCompat.setLayoutParams((ViewGroup.LayoutParams)new LinearLayoutCompat.LayoutParams(-2, -1));
    return linearLayoutCompat;
  }
  
  private boolean isCollapsed() {
    Spinner spinner = this.mTabSpinner;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void performCollapse() {
    if (isCollapsed())
      return; 
    if (this.mTabSpinner == null)
      this.mTabSpinner = createSpinner(); 
    removeView((View)this.mTabLayout);
    addView((View)this.mTabSpinner, new ViewGroup.LayoutParams(-2, -1));
    if (this.mTabSpinner.getAdapter() == null)
      this.mTabSpinner.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.mTabSelector;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.mTabSelector = null;
    } 
    this.mTabSpinner.setSelection(this.mSelectedTabIndex);
  }
  
  private boolean performExpand() {
    if (!isCollapsed())
      return false; 
    removeView((View)this.mTabSpinner);
    addView((View)this.mTabLayout, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.mTabSpinner.getSelectedItemPosition());
    return false;
  }
  
  public void addTab(androidx.appcompat.app.a.c paramc, int paramInt, boolean paramBoolean) {
    d d = createTabView(paramc, false);
    this.mTabLayout.addView((View)d, paramInt, (ViewGroup.LayoutParams)new LinearLayoutCompat.LayoutParams(0, -1, 1.0F));
    Spinner spinner = this.mTabSpinner;
    if (spinner != null)
      ((b)spinner.getAdapter()).notifyDataSetChanged(); 
    if (paramBoolean)
      d.setSelected(true); 
    if (this.mAllowCollapse)
      requestLayout(); 
  }
  
  public void addTab(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = createTabView(paramc, false);
    this.mTabLayout.addView((View)d, (ViewGroup.LayoutParams)new LinearLayoutCompat.LayoutParams(0, -1, 1.0F));
    Spinner spinner = this.mTabSpinner;
    if (spinner != null)
      ((b)spinner.getAdapter()).notifyDataSetChanged(); 
    if (paramBoolean)
      d.setSelected(true); 
    if (this.mAllowCollapse)
      requestLayout(); 
  }
  
  public void animateToTab(int paramInt) {
    View view = this.mTabLayout.getChildAt(paramInt);
    Runnable runnable = this.mTabSelector;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.mTabSelector = a;
    post(a);
  }
  
  public void animateToVisibility(int paramInt) {
    ViewPropertyAnimator viewPropertyAnimator = this.mVisibilityAnim;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      viewPropertyAnimator = animate().alpha(1.0F);
      viewPropertyAnimator.setDuration(200L);
      viewPropertyAnimator.setInterpolator((TimeInterpolator)sAlphaInterpolator);
      viewPropertyAnimator.setListener((Animator.AnimatorListener)this.mVisAnimListener.withFinalVisibility(viewPropertyAnimator, paramInt));
      viewPropertyAnimator.start();
      return;
    } 
    viewPropertyAnimator = animate().alpha(0.0F);
    viewPropertyAnimator.setDuration(200L);
    viewPropertyAnimator.setInterpolator((TimeInterpolator)sAlphaInterpolator);
    viewPropertyAnimator.setListener((Animator.AnimatorListener)this.mVisAnimListener.withFinalVisibility(viewPropertyAnimator, paramInt));
    viewPropertyAnimator.start();
  }
  
  d createTabView(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.mContentHeight));
      return d;
    } 
    d.setFocusable(true);
    if (this.mTabClickListener == null)
      this.mTabClickListener = new c(this); 
    d.setOnClickListener(this.mTabClickListener);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.mTabSelector;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    j.a a = j.a.b(getContext());
    setContentHeight(a.f());
    this.mStackedTabMaxWidth = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.mTabSelector;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.mTabLayout.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.mMaxTabWidth = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.mMaxTabWidth = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.mMaxTabWidth = Math.min(this.mMaxTabWidth, this.mStackedTabMaxWidth);
    } else {
      this.mMaxTabWidth = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.mContentHeight, 1073741824);
    if (bool || !this.mAllowCollapse)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.mTabLayout.measure(0, i);
      if (this.mTabLayout.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        performCollapse();
      } else {
        performExpand();
      } 
    } else {
      performExpand();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.mSelectedTabIndex); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void removeAllTabs() {
    this.mTabLayout.removeAllViews();
    Spinner spinner = this.mTabSpinner;
    if (spinner != null)
      ((b)spinner.getAdapter()).notifyDataSetChanged(); 
    if (this.mAllowCollapse)
      requestLayout(); 
  }
  
  public void removeTabAt(int paramInt) {
    this.mTabLayout.removeViewAt(paramInt);
    Spinner spinner = this.mTabSpinner;
    if (spinner != null)
      ((b)spinner.getAdapter()).notifyDataSetChanged(); 
    if (this.mAllowCollapse)
      requestLayout(); 
  }
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.mAllowCollapse = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.mContentHeight = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.mSelectedTabIndex = paramInt;
    int j = this.mTabLayout.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.mTabLayout.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        animateToTab(paramInt); 
    } 
    Spinner spinner = this.mTabSpinner;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  public void updateTab(int paramInt) {
    ((d)this.mTabLayout.getChildAt(paramInt)).c();
    Spinner spinner = this.mTabSpinner;
    if (spinner != null)
      ((b)spinner.getAdapter()).notifyDataSetChanged(); 
    if (this.mAllowCollapse)
      requestLayout(); 
  }
  
  protected class VisibilityAnimListener extends AnimatorListenerAdapter {
    private boolean mCanceled = false;
    
    private int mFinalVisibility;
    
    public void onAnimationCancel(Animator param1Animator) {
      this.mCanceled = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      if (this.mCanceled)
        return; 
      ScrollingTabContainerView scrollingTabContainerView = ScrollingTabContainerView.this;
      scrollingTabContainerView.mVisibilityAnim = null;
      scrollingTabContainerView.setVisibility(this.mFinalVisibility);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      ScrollingTabContainerView.this.setVisibility(0);
      this.mCanceled = false;
    }
    
    public VisibilityAnimListener withFinalVisibility(ViewPropertyAnimator param1ViewPropertyAnimator, int param1Int) {
      this.mFinalVisibility = param1Int;
      ScrollingTabContainerView.this.mVisibilityAnim = param1ViewPropertyAnimator;
      return this;
    }
  }
  
  class a implements Runnable {
    a(ScrollingTabContainerView this$0, View param1View) {}
    
    public void run() {
      int i = this.n.getLeft();
      int j = (this.o.getWidth() - this.n.getWidth()) / 2;
      this.o.smoothScrollTo(i - j, 0);
      this.o.mTabSelector = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(ScrollingTabContainerView this$0) {}
    
    public int getCount() {
      return this.n.mTabLayout.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((ScrollingTabContainerView.d)this.n.mTabLayout.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.n.createTabView((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((ScrollingTabContainerView.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(ScrollingTabContainerView this$0) {}
    
    public void onClick(View param1View) {
      ((ScrollingTabContainerView.d)param1View).b().e();
      int j = this.n.mTabLayout.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.n.mTabLayout.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] n;
    
    private androidx.appcompat.app.a.c o;
    
    private TextView p;
    
    private ImageView q;
    
    private View r;
    
    public d(ScrollingTabContainerView this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.n = arrayOfInt;
      this.o = param1c;
      TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(param1Context, null, arrayOfInt, i, 0);
      if (tintTypedArray.hasValue(0))
        setBackgroundDrawable(tintTypedArray.getDrawable(0)); 
      tintTypedArray.recycle();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.o = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.o;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.o;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.r = view;
        TextView textView = this.p;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.q;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.q.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.r;
        if (view != null) {
          removeView(view);
          this.r = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.q == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.q = appCompatImageView;
          } 
          this.q.setImageDrawable(drawable);
          this.q.setVisibility(0);
        } else {
          ImageView imageView1 = this.q;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.q.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.p == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, d.a.f);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.p = appCompatTextView;
          } 
          this.p.setText(charSequence2);
          this.p.setVisibility(0);
        } else {
          TextView textView = this.p;
          if (textView != null) {
            textView.setVisibility(8);
            this.p.setText(null);
          } 
        } 
        ImageView imageView = this.q;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        TooltipCompat.setTooltipText((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.s.mMaxTabWidth > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.s.mMaxTabWidth;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\ScrollingTabContainerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */