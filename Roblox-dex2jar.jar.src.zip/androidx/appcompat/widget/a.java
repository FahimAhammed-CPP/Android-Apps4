package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

class a extends Drawable {
  final ActionBarContainer a;
  
  public a(ActionBarContainer paramActionBarContainer) {
    this.a = paramActionBarContainer;
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable;
    ActionBarContainer actionBarContainer = this.a;
    if (actionBarContainer.mIsSplit) {
      drawable = actionBarContainer.mSplitBackground;
      if (drawable != null) {
        drawable.draw(paramCanvas);
        return;
      } 
    } else {
      drawable = ((ActionBarContainer)drawable).mBackground;
      if (drawable != null)
        drawable.draw(paramCanvas); 
      ActionBarContainer actionBarContainer1 = this.a;
      Drawable drawable1 = actionBarContainer1.mStackedBackground;
      if (drawable1 != null && actionBarContainer1.mIsStacked)
        drawable1.draw(paramCanvas); 
    } 
  }
  
  public int getOpacity() {
    return 0;
  }
  
  public void getOutline(Outline paramOutline) {
    Drawable drawable;
    ActionBarContainer actionBarContainer = this.a;
    if (actionBarContainer.mIsSplit) {
      drawable = actionBarContainer.mSplitBackground;
      if (drawable != null) {
        drawable.getOutline(paramOutline);
        return;
      } 
    } else {
      drawable = ((ActionBarContainer)drawable).mBackground;
      if (drawable != null)
        drawable.getOutline(paramOutline); 
    } 
  }
  
  public void setAlpha(int paramInt) {}
  
  public void setColorFilter(ColorFilter paramColorFilter) {}
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */