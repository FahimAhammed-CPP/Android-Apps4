package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ActivityChooserModel extends DataSetObservable {
  static final String n = ActivityChooserModel.class.getSimpleName();
  
  private static final Object o = new Object();
  
  private static final Map<String, ActivityChooserModel> p = new HashMap<String, ActivityChooserModel>();
  
  private final Object a = new Object();
  
  private final List<ActivityResolveInfo> b = new ArrayList<ActivityResolveInfo>();
  
  private final List<HistoricalRecord> c = new ArrayList<HistoricalRecord>();
  
  final Context d;
  
  final String e;
  
  private Intent f;
  
  private ActivitySorter g = new a();
  
  private int h = 50;
  
  boolean i = true;
  
  private boolean j = false;
  
  private boolean k = true;
  
  private boolean l = false;
  
  private OnChooseActivityListener m;
  
  private ActivityChooserModel(Context paramContext, String paramString) {
    this.d = paramContext.getApplicationContext();
    if (!TextUtils.isEmpty(paramString) && !paramString.endsWith(".xml")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(".xml");
      this.e = stringBuilder.toString();
      return;
    } 
    this.e = paramString;
  }
  
  private boolean a(HistoricalRecord paramHistoricalRecord) {
    boolean bool = this.c.add(paramHistoricalRecord);
    if (bool) {
      this.k = true;
      l();
      k();
      r();
      notifyChanged();
    } 
    return bool;
  }
  
  private void c() {
    boolean bool1 = j();
    boolean bool2 = m();
    l();
    if (bool1 | bool2) {
      r();
      notifyChanged();
    } 
  }
  
  public static ActivityChooserModel d(Context paramContext, String paramString) {
    synchronized (o) {
      Map<String, ActivityChooserModel> map = p;
      ActivityChooserModel activityChooserModel2 = map.get(paramString);
      ActivityChooserModel activityChooserModel1 = activityChooserModel2;
      if (activityChooserModel2 == null) {
        activityChooserModel1 = new ActivityChooserModel(paramContext, paramString);
        map.put(paramString, activityChooserModel1);
      } 
      return activityChooserModel1;
    } 
  }
  
  private boolean j() {
    boolean bool = this.l;
    int i = 0;
    if (bool && this.f != null) {
      this.l = false;
      this.b.clear();
      List<ResolveInfo> list = this.d.getPackageManager().queryIntentActivities(this.f, 0);
      int j = list.size();
      while (i < j) {
        ResolveInfo resolveInfo = list.get(i);
        this.b.add(new ActivityResolveInfo(resolveInfo));
        i++;
      } 
      return true;
    } 
    return false;
  }
  
  private void k() {
    if (this.j) {
      if (!this.k)
        return; 
      this.k = false;
      if (!TextUtils.isEmpty(this.e))
        (new b(this)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[] { new ArrayList<HistoricalRecord>(this.c), this.e }); 
      return;
    } 
    throw new IllegalStateException("No preceding call to #readHistoricalData");
  }
  
  private void l() {
    int j = this.c.size() - this.h;
    if (j <= 0)
      return; 
    this.k = true;
    for (int i = 0; i < j; i++)
      HistoricalRecord historicalRecord = this.c.remove(0); 
  }
  
  private boolean m() {
    if (this.i && this.k && !TextUtils.isEmpty(this.e)) {
      this.i = false;
      this.j = true;
      n();
      return true;
    } 
    return false;
  }
  
  private void n() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Landroid/content/Context;
    //   4: aload_0
    //   5: getfield e : Ljava/lang/String;
    //   8: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   11: astore_2
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore_3
    //   16: aload_3
    //   17: aload_2
    //   18: ldc 'UTF-8'
    //   20: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   25: iconst_0
    //   26: istore_1
    //   27: iload_1
    //   28: iconst_1
    //   29: if_icmpeq -> 47
    //   32: iload_1
    //   33: iconst_2
    //   34: if_icmpeq -> 47
    //   37: aload_3
    //   38: invokeinterface next : ()I
    //   43: istore_1
    //   44: goto -> 27
    //   47: ldc 'historical-records'
    //   49: aload_3
    //   50: invokeinterface getName : ()Ljava/lang/String;
    //   55: invokevirtual equals : (Ljava/lang/Object;)Z
    //   58: ifeq -> 188
    //   61: aload_0
    //   62: getfield c : Ljava/util/List;
    //   65: astore #4
    //   67: aload #4
    //   69: invokeinterface clear : ()V
    //   74: aload_3
    //   75: invokeinterface next : ()I
    //   80: istore_1
    //   81: iload_1
    //   82: iconst_1
    //   83: if_icmpne -> 95
    //   86: aload_2
    //   87: ifnull -> 309
    //   90: aload_2
    //   91: invokevirtual close : ()V
    //   94: return
    //   95: iload_1
    //   96: iconst_3
    //   97: if_icmpeq -> 74
    //   100: iload_1
    //   101: iconst_4
    //   102: if_icmpne -> 108
    //   105: goto -> 74
    //   108: ldc_w 'historical-record'
    //   111: aload_3
    //   112: invokeinterface getName : ()Ljava/lang/String;
    //   117: invokevirtual equals : (Ljava/lang/Object;)Z
    //   120: ifeq -> 177
    //   123: aload #4
    //   125: new androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
    //   128: dup
    //   129: aload_3
    //   130: aconst_null
    //   131: ldc_w 'activity'
    //   134: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   139: aload_3
    //   140: aconst_null
    //   141: ldc_w 'time'
    //   144: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   149: invokestatic parseLong : (Ljava/lang/String;)J
    //   152: aload_3
    //   153: aconst_null
    //   154: ldc_w 'weight'
    //   157: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   162: invokestatic parseFloat : (Ljava/lang/String;)F
    //   165: invokespecial <init> : (Ljava/lang/String;JF)V
    //   168: invokeinterface add : (Ljava/lang/Object;)Z
    //   173: pop
    //   174: goto -> 74
    //   177: new org/xmlpull/v1/XmlPullParserException
    //   180: dup
    //   181: ldc_w 'Share records file not well-formed.'
    //   184: invokespecial <init> : (Ljava/lang/String;)V
    //   187: athrow
    //   188: new org/xmlpull/v1/XmlPullParserException
    //   191: dup
    //   192: ldc_w 'Share records file does not start with historical-records tag.'
    //   195: invokespecial <init> : (Ljava/lang/String;)V
    //   198: athrow
    //   199: astore_3
    //   200: goto -> 310
    //   203: astore_3
    //   204: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
    //   207: astore #4
    //   209: new java/lang/StringBuilder
    //   212: dup
    //   213: invokespecial <init> : ()V
    //   216: astore #5
    //   218: aload #5
    //   220: ldc_w 'Error reading historical recrod file: '
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload #5
    //   229: aload_0
    //   230: getfield e : Ljava/lang/String;
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload #4
    //   239: aload #5
    //   241: invokevirtual toString : ()Ljava/lang/String;
    //   244: aload_3
    //   245: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   248: pop
    //   249: aload_2
    //   250: ifnull -> 309
    //   253: goto -> 90
    //   256: astore_3
    //   257: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
    //   260: astore #4
    //   262: new java/lang/StringBuilder
    //   265: dup
    //   266: invokespecial <init> : ()V
    //   269: astore #5
    //   271: aload #5
    //   273: ldc_w 'Error reading historical recrod file: '
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: pop
    //   280: aload #5
    //   282: aload_0
    //   283: getfield e : Ljava/lang/String;
    //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: pop
    //   290: aload #4
    //   292: aload #5
    //   294: invokevirtual toString : ()Ljava/lang/String;
    //   297: aload_3
    //   298: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   301: pop
    //   302: aload_2
    //   303: ifnull -> 309
    //   306: goto -> 90
    //   309: return
    //   310: aload_2
    //   311: ifnull -> 318
    //   314: aload_2
    //   315: invokevirtual close : ()V
    //   318: aload_3
    //   319: athrow
    //   320: astore_2
    //   321: return
    //   322: astore_2
    //   323: return
    //   324: astore_2
    //   325: goto -> 318
    // Exception table:
    //   from	to	target	type
    //   0	12	320	java/io/FileNotFoundException
    //   12	25	256	org/xmlpull/v1/XmlPullParserException
    //   12	25	203	java/io/IOException
    //   12	25	199	finally
    //   37	44	256	org/xmlpull/v1/XmlPullParserException
    //   37	44	203	java/io/IOException
    //   37	44	199	finally
    //   47	74	256	org/xmlpull/v1/XmlPullParserException
    //   47	74	203	java/io/IOException
    //   47	74	199	finally
    //   74	81	256	org/xmlpull/v1/XmlPullParserException
    //   74	81	203	java/io/IOException
    //   74	81	199	finally
    //   90	94	322	java/io/IOException
    //   108	174	256	org/xmlpull/v1/XmlPullParserException
    //   108	174	203	java/io/IOException
    //   108	174	199	finally
    //   177	188	256	org/xmlpull/v1/XmlPullParserException
    //   177	188	203	java/io/IOException
    //   177	188	199	finally
    //   188	199	256	org/xmlpull/v1/XmlPullParserException
    //   188	199	203	java/io/IOException
    //   188	199	199	finally
    //   204	249	199	finally
    //   257	302	199	finally
    //   314	318	324	java/io/IOException
  }
  
  private boolean r() {
    if (this.g != null && this.f != null && !this.b.isEmpty() && !this.c.isEmpty()) {
      this.g.sort(this.f, this.b, Collections.unmodifiableList(this.c));
      return true;
    } 
    return false;
  }
  
  public Intent b(int paramInt) {
    synchronized (this.a) {
      if (this.f == null)
        return null; 
      c();
      ActivityInfo activityInfo = ((ActivityResolveInfo)this.b.get(paramInt)).resolveInfo.activityInfo;
      ComponentName componentName = new ComponentName(activityInfo.packageName, activityInfo.name);
      Intent intent = new Intent(this.f);
      intent.setComponent(componentName);
      if (this.m != null) {
        Intent intent1 = new Intent(intent);
        if (this.m.onChooseActivity(this, intent1))
          return null; 
      } 
      a(new HistoricalRecord(componentName, System.currentTimeMillis(), 1.0F));
      return intent;
    } 
  }
  
  public ResolveInfo e(int paramInt) {
    synchronized (this.a) {
      c();
      return ((ActivityResolveInfo)this.b.get(paramInt)).resolveInfo;
    } 
  }
  
  public int f() {
    synchronized (this.a) {
      c();
      return this.b.size();
    } 
  }
  
  public int g(ResolveInfo paramResolveInfo) {
    synchronized (this.a) {
      c();
      List<ActivityResolveInfo> list = this.b;
      int j = list.size();
      for (int i = 0;; i++) {
        if (i < j) {
          if (((ActivityResolveInfo)list.get(i)).resolveInfo == paramResolveInfo)
            return i; 
        } else {
          return -1;
        } 
      } 
    } 
  }
  
  public ResolveInfo h() {
    synchronized (this.a) {
      c();
      if (!this.b.isEmpty())
        return ((ActivityResolveInfo)this.b.get(0)).resolveInfo; 
      return null;
    } 
  }
  
  public int i() {
    synchronized (this.a) {
      c();
      return this.c.size();
    } 
  }
  
  public void o(int paramInt) {
    synchronized (this.a) {
      float f;
      c();
      ActivityResolveInfo activityResolveInfo1 = this.b.get(paramInt);
      ActivityResolveInfo activityResolveInfo2 = this.b.get(0);
      if (activityResolveInfo2 != null) {
        f = activityResolveInfo2.weight - activityResolveInfo1.weight + 5.0F;
      } else {
        f = 1.0F;
      } 
      ActivityInfo activityInfo = activityResolveInfo1.resolveInfo.activityInfo;
      a(new HistoricalRecord(new ComponentName(activityInfo.packageName, activityInfo.name), System.currentTimeMillis(), f));
      return;
    } 
  }
  
  public void p(Intent paramIntent) {
    synchronized (this.a) {
      if (this.f == paramIntent)
        return; 
      this.f = paramIntent;
      this.l = true;
      c();
      return;
    } 
  }
  
  public void q(OnChooseActivityListener paramOnChooseActivityListener) {
    synchronized (this.a) {
      this.m = paramOnChooseActivityListener;
      return;
    } 
  }
  
  public static interface ActivityChooserModelClient {
    void setActivityChooserModel(ActivityChooserModel param1ActivityChooserModel);
  }
  
  public static final class ActivityResolveInfo implements Comparable<ActivityResolveInfo> {
    public final ResolveInfo resolveInfo;
    
    public float weight;
    
    public ActivityResolveInfo(ResolveInfo param1ResolveInfo) {
      this.resolveInfo = param1ResolveInfo;
    }
    
    public int compareTo(ActivityResolveInfo param1ActivityResolveInfo) {
      return Float.floatToIntBits(param1ActivityResolveInfo.weight) - Float.floatToIntBits(this.weight);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (ActivityResolveInfo.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return !(Float.floatToIntBits(this.weight) != Float.floatToIntBits(((ActivityResolveInfo)param1Object).weight));
    }
    
    public int hashCode() {
      return Float.floatToIntBits(this.weight) + 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append("resolveInfo:");
      stringBuilder.append(this.resolveInfo.toString());
      stringBuilder.append("; weight:");
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static interface ActivitySorter {
    void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1);
  }
  
  public static final class HistoricalRecord {
    public final ComponentName activity;
    
    public final long time;
    
    public final float weight;
    
    public HistoricalRecord(ComponentName param1ComponentName, long param1Long, float param1Float) {
      this.activity = param1ComponentName;
      this.time = param1Long;
      this.weight = param1Float;
    }
    
    public HistoricalRecord(String param1String, long param1Long, float param1Float) {
      this(ComponentName.unflattenFromString(param1String), param1Long, param1Float);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (HistoricalRecord.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      ComponentName componentName = this.activity;
      if (componentName == null) {
        if (((HistoricalRecord)param1Object).activity != null)
          return false; 
      } else if (!componentName.equals(((HistoricalRecord)param1Object).activity)) {
        return false;
      } 
      return (this.time != ((HistoricalRecord)param1Object).time) ? false : (!(Float.floatToIntBits(this.weight) != Float.floatToIntBits(((HistoricalRecord)param1Object).weight)));
    }
    
    public int hashCode() {
      int i;
      ComponentName componentName = this.activity;
      if (componentName == null) {
        i = 0;
      } else {
        i = componentName.hashCode();
      } 
      long l = this.time;
      return ((i + 31) * 31 + (int)(l ^ l >>> 32L)) * 31 + Float.floatToIntBits(this.weight);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append("; activity:");
      stringBuilder.append(this.activity);
      stringBuilder.append("; time:");
      stringBuilder.append(this.time);
      stringBuilder.append("; weight:");
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static interface OnChooseActivityListener {
    boolean onChooseActivity(ActivityChooserModel param1ActivityChooserModel, Intent param1Intent);
  }
  
  private static final class a implements ActivitySorter {
    private final Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> a = new HashMap<ComponentName, ActivityChooserModel.ActivityResolveInfo>();
    
    public void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1) {
      Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> map = this.a;
      map.clear();
      int j = param1List.size();
      int i;
      for (i = 0; i < j; i++) {
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = param1List.get(i);
        activityResolveInfo.weight = 0.0F;
        ActivityInfo activityInfo = activityResolveInfo.resolveInfo.activityInfo;
        map.put(new ComponentName(activityInfo.packageName, activityInfo.name), activityResolveInfo);
      } 
      i = param1List1.size() - 1;
      float f;
      for (f = 1.0F; i >= 0; f = f1) {
        ActivityChooserModel.HistoricalRecord historicalRecord = param1List1.get(i);
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = map.get(historicalRecord.activity);
        float f1 = f;
        if (activityResolveInfo != null) {
          activityResolveInfo.weight += historicalRecord.weight * f;
          f1 = f * 0.95F;
        } 
        i--;
      } 
      Collections.sort(param1List);
    }
  }
  
  private final class b extends AsyncTask<Object, Void, Void> {
    b(ActivityChooserModel this$0) {}
    
    public Void a(Object... param1VarArgs) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: aaload
      //   3: checkcast java/util/List
      //   6: astore #4
      //   8: aload_1
      //   9: iconst_1
      //   10: aaload
      //   11: checkcast java/lang/String
      //   14: astore #5
      //   16: aload_0
      //   17: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   20: getfield d : Landroid/content/Context;
      //   23: aload #5
      //   25: iconst_0
      //   26: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   29: astore_1
      //   30: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
      //   33: astore #5
      //   35: aload #5
      //   37: aload_1
      //   38: aconst_null
      //   39: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
      //   44: aload #5
      //   46: ldc 'UTF-8'
      //   48: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   51: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
      //   56: aload #5
      //   58: aconst_null
      //   59: ldc 'historical-records'
      //   61: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   66: pop
      //   67: aload #4
      //   69: invokeinterface size : ()I
      //   74: istore_3
      //   75: iconst_0
      //   76: istore_2
      //   77: iload_2
      //   78: iload_3
      //   79: if_icmpge -> 181
      //   82: aload #4
      //   84: iconst_0
      //   85: invokeinterface remove : (I)Ljava/lang/Object;
      //   90: checkcast androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
      //   93: astore #6
      //   95: aload #5
      //   97: aconst_null
      //   98: ldc 'historical-record'
      //   100: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   105: pop
      //   106: aload #5
      //   108: aconst_null
      //   109: ldc 'activity'
      //   111: aload #6
      //   113: getfield activity : Landroid/content/ComponentName;
      //   116: invokevirtual flattenToString : ()Ljava/lang/String;
      //   119: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   124: pop
      //   125: aload #5
      //   127: aconst_null
      //   128: ldc 'time'
      //   130: aload #6
      //   132: getfield time : J
      //   135: invokestatic valueOf : (J)Ljava/lang/String;
      //   138: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   143: pop
      //   144: aload #5
      //   146: aconst_null
      //   147: ldc 'weight'
      //   149: aload #6
      //   151: getfield weight : F
      //   154: invokestatic valueOf : (F)Ljava/lang/String;
      //   157: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   162: pop
      //   163: aload #5
      //   165: aconst_null
      //   166: ldc 'historical-record'
      //   168: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   173: pop
      //   174: iload_2
      //   175: iconst_1
      //   176: iadd
      //   177: istore_2
      //   178: goto -> 77
      //   181: aload #5
      //   183: aconst_null
      //   184: ldc 'historical-records'
      //   186: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
      //   191: pop
      //   192: aload #5
      //   194: invokeinterface endDocument : ()V
      //   199: aload_0
      //   200: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   203: iconst_1
      //   204: putfield i : Z
      //   207: aload_1
      //   208: ifnull -> 417
      //   211: aload_1
      //   212: invokevirtual close : ()V
      //   215: aconst_null
      //   216: areturn
      //   217: astore #4
      //   219: goto -> 419
      //   222: astore #4
      //   224: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
      //   227: astore #5
      //   229: new java/lang/StringBuilder
      //   232: dup
      //   233: invokespecial <init> : ()V
      //   236: astore #6
      //   238: aload #6
      //   240: ldc 'Error writing historical record file: '
      //   242: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   245: pop
      //   246: aload #6
      //   248: aload_0
      //   249: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   252: getfield e : Ljava/lang/String;
      //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   258: pop
      //   259: aload #5
      //   261: aload #6
      //   263: invokevirtual toString : ()Ljava/lang/String;
      //   266: aload #4
      //   268: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   271: pop
      //   272: aload_0
      //   273: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   276: iconst_1
      //   277: putfield i : Z
      //   280: aload_1
      //   281: ifnull -> 417
      //   284: goto -> 211
      //   287: astore #4
      //   289: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
      //   292: astore #5
      //   294: new java/lang/StringBuilder
      //   297: dup
      //   298: invokespecial <init> : ()V
      //   301: astore #6
      //   303: aload #6
      //   305: ldc 'Error writing historical record file: '
      //   307: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   310: pop
      //   311: aload #6
      //   313: aload_0
      //   314: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   317: getfield e : Ljava/lang/String;
      //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   323: pop
      //   324: aload #5
      //   326: aload #6
      //   328: invokevirtual toString : ()Ljava/lang/String;
      //   331: aload #4
      //   333: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   336: pop
      //   337: aload_0
      //   338: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   341: iconst_1
      //   342: putfield i : Z
      //   345: aload_1
      //   346: ifnull -> 417
      //   349: goto -> 211
      //   352: astore #4
      //   354: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
      //   357: astore #5
      //   359: new java/lang/StringBuilder
      //   362: dup
      //   363: invokespecial <init> : ()V
      //   366: astore #6
      //   368: aload #6
      //   370: ldc 'Error writing historical record file: '
      //   372: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   375: pop
      //   376: aload #6
      //   378: aload_0
      //   379: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   382: getfield e : Ljava/lang/String;
      //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   388: pop
      //   389: aload #5
      //   391: aload #6
      //   393: invokevirtual toString : ()Ljava/lang/String;
      //   396: aload #4
      //   398: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   401: pop
      //   402: aload_0
      //   403: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   406: iconst_1
      //   407: putfield i : Z
      //   410: aload_1
      //   411: ifnull -> 417
      //   414: goto -> 211
      //   417: aconst_null
      //   418: areturn
      //   419: aload_0
      //   420: getfield a : Landroidx/appcompat/widget/ActivityChooserModel;
      //   423: iconst_1
      //   424: putfield i : Z
      //   427: aload_1
      //   428: ifnull -> 435
      //   431: aload_1
      //   432: invokevirtual close : ()V
      //   435: aload #4
      //   437: athrow
      //   438: astore_1
      //   439: getstatic androidx/appcompat/widget/ActivityChooserModel.n : Ljava/lang/String;
      //   442: astore #4
      //   444: new java/lang/StringBuilder
      //   447: dup
      //   448: invokespecial <init> : ()V
      //   451: astore #6
      //   453: aload #6
      //   455: ldc 'Error writing historical record file: '
      //   457: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   460: pop
      //   461: aload #6
      //   463: aload #5
      //   465: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   468: pop
      //   469: aload #4
      //   471: aload #6
      //   473: invokevirtual toString : ()Ljava/lang/String;
      //   476: aload_1
      //   477: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   480: pop
      //   481: aconst_null
      //   482: areturn
      //   483: astore_1
      //   484: aconst_null
      //   485: areturn
      //   486: astore_1
      //   487: goto -> 435
      // Exception table:
      //   from	to	target	type
      //   16	30	438	java/io/FileNotFoundException
      //   35	75	352	java/lang/IllegalArgumentException
      //   35	75	287	java/lang/IllegalStateException
      //   35	75	222	java/io/IOException
      //   35	75	217	finally
      //   82	174	352	java/lang/IllegalArgumentException
      //   82	174	287	java/lang/IllegalStateException
      //   82	174	222	java/io/IOException
      //   82	174	217	finally
      //   181	199	352	java/lang/IllegalArgumentException
      //   181	199	287	java/lang/IllegalStateException
      //   181	199	222	java/io/IOException
      //   181	199	217	finally
      //   211	215	483	java/io/IOException
      //   224	272	217	finally
      //   289	337	217	finally
      //   354	402	217	finally
      //   431	435	486	java/io/IOException
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\ActivityChooserModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */