package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import d.c;
import d.d;
import d.e;

public final class AppCompatDrawableManager {
  private static final boolean DEBUG = false;
  
  private static final PorterDuff.Mode DEFAULT_MODE = PorterDuff.Mode.SRC_IN;
  
  private static AppCompatDrawableManager INSTANCE;
  
  private static final String TAG = "AppCompatDrawableManag";
  
  private ResourceManagerInternal mResourceManager;
  
  public static AppCompatDrawableManager get() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/AppCompatDrawableManager.INSTANCE : Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   6: ifnonnull -> 12
    //   9: invokestatic preload : ()V
    //   12: getstatic androidx/appcompat/widget/AppCompatDrawableManager.INSTANCE : Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   15: astore_0
    //   16: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter getPorterDuffColorFilter(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic getPorterDuffColorFilter : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void preload() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/AppCompatDrawableManager.INSTANCE : Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   6: ifnonnull -> 44
    //   9: new androidx/appcompat/widget/AppCompatDrawableManager
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/AppCompatDrawableManager.INSTANCE : Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   21: aload_0
    //   22: invokestatic get : ()Landroidx/appcompat/widget/ResourceManagerInternal;
    //   25: putfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   28: getstatic androidx/appcompat/widget/AppCompatDrawableManager.INSTANCE : Landroidx/appcompat/widget/AppCompatDrawableManager;
    //   31: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   34: new androidx/appcompat/widget/AppCompatDrawableManager$a
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: invokevirtual setHooks : (Landroidx/appcompat/widget/ResourceManagerInternal$ResourceManagerHooks;)V
    //   44: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   46: monitorexit
    //   47: return
    //   48: astore_0
    //   49: ldc androidx/appcompat/widget/AppCompatDrawableManager
    //   51: monitorexit
    //   52: aload_0
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   3	44	48	finally
  }
  
  static void tintDrawable(Drawable paramDrawable, TintInfo paramTintInfo, int[] paramArrayOfint) {
    ResourceManagerInternal.tintDrawable(paramDrawable, paramTintInfo, paramArrayOfint);
  }
  
  public Drawable getDrawable(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  Drawable getDrawable(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: invokevirtual getDrawable : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  ColorStateList getTintList(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual getTintList : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public void onConfigurationChanged(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   6: aload_1
    //   7: invokevirtual onConfigurationChanged : (Landroid/content/Context;)V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	13	finally
  }
  
  Drawable onDrawableLoadedFromResources(Context paramContext, VectorEnabledTintResources paramVectorEnabledTintResources, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResourceManager : Landroidx/appcompat/widget/ResourceManagerInternal;
    //   6: aload_1
    //   7: aload_2
    //   8: iload_3
    //   9: invokevirtual onDrawableLoadedFromResources : (Landroid/content/Context;Landroidx/appcompat/widget/VectorEnabledTintResources;I)Landroid/graphics/drawable/Drawable;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  boolean tintDrawableUsingColorFilter(Context paramContext, int paramInt, Drawable paramDrawable) {
    return this.mResourceManager.tintDrawableUsingColorFilter(paramContext, paramInt, paramDrawable);
  }
  
  class a implements ResourceManagerInternal.ResourceManagerHooks {
    private final int[] a = new int[] { e.R, e.P, e.a };
    
    private final int[] b = new int[] { e.o, e.B, e.t, e.p, e.q, e.s, e.r };
    
    private final int[] c = new int[] { e.O, e.Q, e.k, e.K, e.L, e.M, e.N };
    
    private final int[] d = new int[] { e.w, e.i, e.v };
    
    private final int[] e = new int[] { e.J, e.S };
    
    private final int[] f = new int[] { e.c, e.g, e.d, e.h };
    
    private boolean a(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    private ColorStateList b(Context param1Context) {
      return c(param1Context, 0);
    }
    
    private ColorStateList c(Context param1Context, int param1Int) {
      int k = ThemeUtils.getThemeAttrColor(param1Context, d.a.x);
      int i = ThemeUtils.getDisabledThemeAttrColor(param1Context, d.a.v);
      int[] arrayOfInt1 = ThemeUtils.DISABLED_STATE_SET;
      int[] arrayOfInt2 = ThemeUtils.PRESSED_STATE_SET;
      int j = s0.a.b(k, param1Int);
      int[] arrayOfInt3 = ThemeUtils.FOCUSED_STATE_SET;
      k = s0.a.b(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, ThemeUtils.EMPTY_STATE_SET }, new int[] { i, j, k, param1Int });
    }
    
    private ColorStateList d(Context param1Context) {
      return c(param1Context, ThemeUtils.getThemeAttrColor(param1Context, d.a.u));
    }
    
    private ColorStateList e(Context param1Context) {
      return c(param1Context, ThemeUtils.getThemeAttrColor(param1Context, d.a.v));
    }
    
    private ColorStateList f(Context param1Context) {
      int[][] arrayOfInt = new int[3][];
      int[] arrayOfInt1 = new int[3];
      int i = d.a.z;
      ColorStateList colorStateList = ThemeUtils.getThemeAttrColorStateList(param1Context, i);
      if (colorStateList != null && colorStateList.isStateful()) {
        arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
        arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
        arrayOfInt[1] = ThemeUtils.CHECKED_STATE_SET;
        arrayOfInt1[1] = ThemeUtils.getThemeAttrColor(param1Context, d.a.w);
        arrayOfInt[2] = ThemeUtils.EMPTY_STATE_SET;
        arrayOfInt1[2] = colorStateList.getDefaultColor();
      } else {
        arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
        arrayOfInt1[0] = ThemeUtils.getDisabledThemeAttrColor(param1Context, i);
        arrayOfInt[1] = ThemeUtils.CHECKED_STATE_SET;
        arrayOfInt1[1] = ThemeUtils.getThemeAttrColor(param1Context, d.a.w);
        arrayOfInt[2] = ThemeUtils.EMPTY_STATE_SET;
        arrayOfInt1[2] = ThemeUtils.getThemeAttrColor(param1Context, i);
      } 
      return new ColorStateList(arrayOfInt, arrayOfInt1);
    }
    
    private LayerDrawable g(ResourceManagerInternal param1ResourceManagerInternal, Context param1Context, int param1Int) {
      BitmapDrawable bitmapDrawable1;
      BitmapDrawable bitmapDrawable2;
      BitmapDrawable bitmapDrawable3;
      param1Int = param1Context.getResources().getDimensionPixelSize(param1Int);
      Drawable drawable2 = param1ResourceManagerInternal.getDrawable(param1Context, e.F);
      Drawable drawable1 = param1ResourceManagerInternal.getDrawable(param1Context, e.G);
      if (drawable2 instanceof BitmapDrawable && drawable2.getIntrinsicWidth() == param1Int && drawable2.getIntrinsicHeight() == param1Int) {
        bitmapDrawable1 = (BitmapDrawable)drawable2;
        bitmapDrawable2 = new BitmapDrawable(bitmapDrawable1.getBitmap());
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, param1Int, param1Int);
        drawable2.draw(canvas);
        bitmapDrawable1 = new BitmapDrawable(bitmap);
        bitmapDrawable2 = new BitmapDrawable(bitmap);
      } 
      bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
      if (drawable1 instanceof BitmapDrawable && drawable1.getIntrinsicWidth() == param1Int && drawable1.getIntrinsicHeight() == param1Int) {
        bitmapDrawable3 = (BitmapDrawable)drawable1;
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        bitmapDrawable3.setBounds(0, 0, param1Int, param1Int);
        bitmapDrawable3.draw(canvas);
        bitmapDrawable3 = new BitmapDrawable(bitmap);
      } 
      LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)bitmapDrawable1, (Drawable)bitmapDrawable3, (Drawable)bitmapDrawable2 });
      layerDrawable.setId(0, 16908288);
      layerDrawable.setId(1, 16908303);
      layerDrawable.setId(2, 16908301);
      return layerDrawable;
    }
    
    private void h(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (DrawableUtils.canSafelyMutateDrawable(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = AppCompatDrawableManager.DEFAULT_MODE; 
      drawable.setColorFilter((ColorFilter)AppCompatDrawableManager.getPorterDuffColorFilter(param1Int, mode));
    }
    
    public Drawable createDrawableFor(ResourceManagerInternal param1ResourceManagerInternal, Context param1Context, int param1Int) {
      return (Drawable)((param1Int == e.j) ? new LayerDrawable(new Drawable[] { param1ResourceManagerInternal.getDrawable(param1Context, e.i), param1ResourceManagerInternal.getDrawable(param1Context, e.k) }) : ((param1Int == e.y) ? g(param1ResourceManagerInternal, param1Context, d.i) : ((param1Int == e.x) ? g(param1ResourceManagerInternal, param1Context, d.j) : ((param1Int == e.z) ? g(param1ResourceManagerInternal, param1Context, d.k) : null))));
    }
    
    public ColorStateList getTintListForDrawableRes(Context param1Context, int param1Int) {
      return (param1Int == e.m) ? f.a.c(param1Context, c.e) : ((param1Int == e.I) ? f.a.c(param1Context, c.h) : ((param1Int == e.H) ? f(param1Context) : ((param1Int == e.f) ? e(param1Context) : ((param1Int == e.b) ? b(param1Context) : ((param1Int == e.e) ? d(param1Context) : ((param1Int == e.D || param1Int == e.E) ? f.a.c(param1Context, c.g) : (a(this.b, param1Int) ? ThemeUtils.getThemeAttrColorStateList(param1Context, d.a.y) : (a(this.e, param1Int) ? f.a.c(param1Context, c.d) : (a(this.f, param1Int) ? f.a.c(param1Context, c.c) : ((param1Int == e.A) ? f.a.c(param1Context, c.f) : null))))))))));
    }
    
    public PorterDuff.Mode getTintModeForDrawableRes(int param1Int) {
      return (param1Int == e.H) ? PorterDuff.Mode.MULTIPLY : null;
    }
    
    public boolean tintDrawable(Context param1Context, int param1Int, Drawable param1Drawable) {
      LayerDrawable layerDrawable;
      if (param1Int == e.C) {
        layerDrawable = (LayerDrawable)param1Drawable;
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
        param1Int = d.a.y;
        h(drawable, ThemeUtils.getThemeAttrColor(param1Context, param1Int), AppCompatDrawableManager.DEFAULT_MODE);
        h(layerDrawable.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(param1Context, param1Int), AppCompatDrawableManager.DEFAULT_MODE);
        h(layerDrawable.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(param1Context, d.a.w), AppCompatDrawableManager.DEFAULT_MODE);
        return true;
      } 
      if (param1Int == e.y || param1Int == e.x || param1Int == e.z) {
        layerDrawable = layerDrawable;
        h(layerDrawable.findDrawableByLayerId(16908288), ThemeUtils.getDisabledThemeAttrColor(param1Context, d.a.y), AppCompatDrawableManager.DEFAULT_MODE);
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908303);
        param1Int = d.a.w;
        h(drawable, ThemeUtils.getThemeAttrColor(param1Context, param1Int), AppCompatDrawableManager.DEFAULT_MODE);
        h(layerDrawable.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(param1Context, param1Int), AppCompatDrawableManager.DEFAULT_MODE);
        return true;
      } 
      return false;
    }
    
    public boolean tintDrawableUsingColorFilter(Context param1Context, int param1Int, Drawable param1Drawable) {
      // Byte code:
      //   0: invokestatic access$000 : ()Landroid/graphics/PorterDuff$Mode;
      //   3: astore #7
      //   5: aload_0
      //   6: aload_0
      //   7: getfield a : [I
      //   10: iload_2
      //   11: invokespecial a : ([II)Z
      //   14: istore #6
      //   16: ldc_w 16842801
      //   19: istore #4
      //   21: iload #6
      //   23: ifeq -> 39
      //   26: getstatic d/a.y : I
      //   29: istore_2
      //   30: iconst_m1
      //   31: istore #4
      //   33: iconst_1
      //   34: istore #5
      //   36: goto -> 124
      //   39: aload_0
      //   40: aload_0
      //   41: getfield c : [I
      //   44: iload_2
      //   45: invokespecial a : ([II)Z
      //   48: ifeq -> 58
      //   51: getstatic d/a.w : I
      //   54: istore_2
      //   55: goto -> 30
      //   58: aload_0
      //   59: aload_0
      //   60: getfield d : [I
      //   63: iload_2
      //   64: invokespecial a : ([II)Z
      //   67: ifeq -> 81
      //   70: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
      //   73: astore #7
      //   75: iload #4
      //   77: istore_2
      //   78: goto -> 30
      //   81: iload_2
      //   82: getstatic d/e.u : I
      //   85: if_icmpne -> 103
      //   88: ldc_w 16842800
      //   91: istore_2
      //   92: ldc_w 40.8
      //   95: invokestatic round : (F)I
      //   98: istore #4
      //   100: goto -> 33
      //   103: iload_2
      //   104: getstatic d/e.l : I
      //   107: if_icmpne -> 116
      //   110: iload #4
      //   112: istore_2
      //   113: goto -> 30
      //   116: iconst_m1
      //   117: istore #4
      //   119: iconst_0
      //   120: istore #5
      //   122: iconst_0
      //   123: istore_2
      //   124: iload #5
      //   126: ifeq -> 175
      //   129: aload_3
      //   130: astore #8
      //   132: aload_3
      //   133: invokestatic canSafelyMutateDrawable : (Landroid/graphics/drawable/Drawable;)Z
      //   136: ifeq -> 145
      //   139: aload_3
      //   140: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
      //   143: astore #8
      //   145: aload #8
      //   147: aload_1
      //   148: iload_2
      //   149: invokestatic getThemeAttrColor : (Landroid/content/Context;I)I
      //   152: aload #7
      //   154: invokestatic getPorterDuffColorFilter : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
      //   157: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
      //   160: iload #4
      //   162: iconst_m1
      //   163: if_icmpeq -> 173
      //   166: aload #8
      //   168: iload #4
      //   170: invokevirtual setAlpha : (I)V
      //   173: iconst_1
      //   174: ireturn
      //   175: iconst_0
      //   176: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\androidx\appcompat\widget\AppCompatDrawableManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */