package a8;

import android.content.ContentValues;
import android.net.Uri;

public abstract class a implements f {
  public void b(Uri paramUri, ContentValues paramContentValues) {
    throw new UnsupportedOperationException("unimplemented");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */