package a8;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

public interface f {
  Cursor a(Uri paramUri);
  
  void b(Uri paramUri, ContentValues paramContentValues);
  
  r6.a c(a parama);
  
  public enum a {
    n, o;
    
    static {
      a a1 = new a("GET", 0);
      n = a1;
      a a2 = new a("POST", 1);
      o = a2;
      p = new a[] { a1, a2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */