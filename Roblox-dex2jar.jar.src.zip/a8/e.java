package a8;

import android.database.Cursor;
import android.net.Uri;
import r6.a;
import z7.a;

public class e extends a {
  public Cursor a(Uri paramUri) {
    return (Cursor)new a();
  }
  
  public a c(f.a parama) {
    return (parama == f.a.n) ? a.p : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */