package a8;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.roblox.client.o;

public class d extends a {
  private Context a;
  
  public d(Context paramContext) {
    this.a = paramContext;
  }
  
  public Cursor a(Uri paramUri) {
    return (Cursor)new a(this, o.b(this.a));
  }
  
  public r6.a c(f.a parama) {
    return (parama == f.a.n) ? r6.a.t : null;
  }
  
  class a extends z7.a {
    a(d this$0, String param1String) {}
    
    public String[] getColumnNames() {
      return new String[] { "dev_rpc_ip_port_override" };
    }
    
    public String getString(int param1Int) {
      return this.n;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */