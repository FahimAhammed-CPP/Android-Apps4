package a8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.widget.Toast;
import com.roblox.client.e0;
import com.roblox.client.o;
import com.roblox.client.provider.ShellConfigurationContentProvider;
import com.roblox.client.q0;
import r6.a;
import t8.k;
import z7.b;
import z8.k;

public class c implements f {
  private final String a = "rbx.config";
  
  private Context b;
  
  private ShellConfigurationContentProvider c;
  
  public c(ShellConfigurationContentProvider paramShellConfigurationContentProvider, Context paramContext) {
    this.c = paramShellConfigurationContentProvider;
    this.b = paramContext;
  }
  
  private r6.c e() {
    return this.c.c();
  }
  
  private r6.c.a f() {
    return this.c.b();
  }
  
  public Cursor a(Uri paramUri) {
    return (Cursor)new b(this.c.c());
  }
  
  public void b(Uri paramUri, ContentValues paramContentValues) {
    if (paramContentValues.containsKey("settings_param")) {
      String str = paramContentValues.getAsString("settings_param");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("new payload:");
      stringBuilder.append(str);
      k.a("rbx.config", stringBuilder.toString());
      e().j(str);
      f().b(str);
    } 
    if (paramContentValues.containsKey("channel_param")) {
      String str = paramContentValues.getAsString("channel_param");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("new robloxChannel:");
      stringBuilder.append(str);
      k.a("rbx.config", stringBuilder.toString());
      e().m(str);
      f().f(str);
    } 
    if (paramContentValues.containsKey("base_url_param")) {
      String str = paramContentValues.getAsString("base_url_param");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("new baseUrl:");
      stringBuilder.append(str);
      k.a("rbx.config", stringBuilder.toString());
      e().k(str);
      f().e(str);
    } 
    if (paramContentValues.containsKey("user_agent_param")) {
      String str = paramContentValues.getAsString("user_agent_param");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("set user agent:");
      stringBuilder.append(str);
      k.a("rbx.config", stringBuilder.toString());
      e().n(str);
      f().a(str);
    } 
    if (paramContentValues.containsKey("dev_rpc_ip_port_override")) {
      String str = paramContentValues.getAsString("dev_rpc_ip_port_override");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("set dev rpc ip and port:");
      stringBuilder.append(str);
      k.a("rbx.config", stringBuilder.toString());
      e().l(str);
      f().c(str);
      o.e(this.b, str);
      (new Handler(this.b.getMainLooper())).post(new b(this));
      if (k.t(this.b).w())
        q0.P0(true); 
    } 
  }
  
  public a c(f.a parama) {
    return (parama == f.a.n) ? a.q : ((parama == f.a.o) ? a.r : null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */