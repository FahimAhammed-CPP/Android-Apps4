package a8;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.roblox.client.q0;

public class g extends a {
  private Context a;
  
  public g(Context paramContext) {
    this.a = paramContext;
  }
  
  public Cursor a(Uri paramUri) {
    String str2 = paramUri.getQueryParameter("user_agent_param");
    q0.T0(this.a);
    String str1 = str2;
    if (str2 == null)
      str1 = "google"; 
    return (Cursor)new a(this, q0.q(this.a, str1));
  }
  
  public r6.a c(f.a parama) {
    return (parama == f.a.n) ? r6.a.s : null;
  }
  
  class a extends z7.a {
    a(g this$0, String param1String) {}
    
    public String[] getColumnNames() {
      return new String[] { "user_agent_param" };
    }
    
    public String getString(int param1Int) {
      return this.n;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a8\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */