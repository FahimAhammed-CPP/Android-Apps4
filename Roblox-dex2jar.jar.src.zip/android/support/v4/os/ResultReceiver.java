package android.support.v4.os;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public class ResultReceiver implements Parcelable {
  public static final Parcelable.Creator<ResultReceiver> CREATOR = new a();
  
  final boolean n = false;
  
  final Handler o = null;
  
  a p;
  
  ResultReceiver(Parcel paramParcel) {
    this.p = a.a.h(paramParcel.readStrongBinder());
  }
  
  protected void a(int paramInt, Bundle paramBundle) {}
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield p : Landroid/support/v4/os/a;
    //   6: ifnonnull -> 21
    //   9: aload_0
    //   10: new android/support/v4/os/ResultReceiver$b
    //   13: dup
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/support/v4/os/ResultReceiver;)V
    //   18: putfield p : Landroid/support/v4/os/a;
    //   21: aload_1
    //   22: aload_0
    //   23: getfield p : Landroid/support/v4/os/a;
    //   26: invokeinterface asBinder : ()Landroid/os/IBinder;
    //   31: invokevirtual writeStrongBinder : (Landroid/os/IBinder;)V
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	37	finally
    //   21	36	37	finally
    //   38	40	37	finally
  }
  
  class a implements Parcelable.Creator<ResultReceiver> {
    public ResultReceiver a(Parcel param1Parcel) {
      return new ResultReceiver(param1Parcel);
    }
    
    public ResultReceiver[] b(int param1Int) {
      return new ResultReceiver[param1Int];
    }
  }
  
  class b extends a.a {
    b(ResultReceiver this$0) {}
    
    public void v0(int param1Int, Bundle param1Bundle) {
      ResultReceiver resultReceiver = this.a;
      Handler handler = resultReceiver.o;
      if (handler != null) {
        handler.post(new ResultReceiver.c(resultReceiver, param1Int, param1Bundle));
        return;
      } 
      resultReceiver.a(param1Int, param1Bundle);
    }
  }
  
  class c implements Runnable {
    final int n;
    
    final Bundle o;
    
    c(ResultReceiver this$0, int param1Int, Bundle param1Bundle) {
      this.n = param1Int;
      this.o = param1Bundle;
    }
    
    public void run() {
      this.p.a(this.n, this.o);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\android\support\v4\os\ResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */