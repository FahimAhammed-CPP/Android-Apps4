package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  final int n;
  
  final long o;
  
  final long p;
  
  final float q;
  
  final long r;
  
  final int s;
  
  final CharSequence t;
  
  final long u;
  
  List<CustomAction> v;
  
  final long w;
  
  final Bundle x;
  
  private Object y;
  
  PlaybackStateCompat(int paramInt1, long paramLong1, long paramLong2, float paramFloat, long paramLong3, int paramInt2, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.n = paramInt1;
    this.o = paramLong1;
    this.p = paramLong2;
    this.q = paramFloat;
    this.r = paramLong3;
    this.s = paramInt2;
    this.t = paramCharSequence;
    this.u = paramLong4;
    this.v = new ArrayList<CustomAction>(paramList);
    this.w = paramLong5;
    this.x = paramBundle;
  }
  
  PlaybackStateCompat(Parcel paramParcel) {
    this.n = paramParcel.readInt();
    this.o = paramParcel.readLong();
    this.q = paramParcel.readFloat();
    this.u = paramParcel.readLong();
    this.p = paramParcel.readLong();
    this.r = paramParcel.readLong();
    this.t = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.v = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.w = paramParcel.readLong();
    this.x = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.s = paramParcel.readInt();
  }
  
  public static PlaybackStateCompat a(Object paramObject) {
    PlaybackStateCompat playbackStateCompat;
    ArrayList<CustomAction> arrayList = null;
    Bundle bundle = null;
    if (paramObject != null) {
      List<Object> list = g.d(paramObject);
      if (list != null) {
        arrayList = new ArrayList(list.size());
        Iterator iterator = list.iterator();
        while (iterator.hasNext())
          arrayList.add(CustomAction.a(iterator.next())); 
      } else {
        arrayList = null;
      } 
      if (Build.VERSION.SDK_INT >= 22)
        bundle = h.a(paramObject); 
      playbackStateCompat = new PlaybackStateCompat(g.i(paramObject), g.h(paramObject), g.c(paramObject), g.g(paramObject), g.a(paramObject), 0, g.e(paramObject), g.f(paramObject), arrayList, g.b(paramObject), bundle);
      playbackStateCompat.y = paramObject;
    } 
    return playbackStateCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.n);
    stringBuilder.append(", position=");
    stringBuilder.append(this.o);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.p);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.q);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.u);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.r);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.s);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.t);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.v);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.w);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.n);
    paramParcel.writeLong(this.o);
    paramParcel.writeFloat(this.q);
    paramParcel.writeLong(this.u);
    paramParcel.writeLong(this.p);
    paramParcel.writeLong(this.r);
    TextUtils.writeToParcel(this.t, paramParcel, paramInt);
    paramParcel.writeTypedList(this.v);
    paramParcel.writeLong(this.w);
    paramParcel.writeBundle(this.x);
    paramParcel.writeInt(this.s);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String n;
    
    private final CharSequence o;
    
    private final int p;
    
    private final Bundle q;
    
    private Object r;
    
    CustomAction(Parcel param1Parcel) {
      this.n = param1Parcel.readString();
      this.o = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.p = param1Parcel.readInt();
      this.q = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.n = param1String;
      this.o = param1CharSequence;
      this.p = param1Int;
      this.q = param1Bundle;
    }
    
    public static CustomAction a(Object param1Object) {
      if (param1Object != null) {
        CustomAction customAction = new CustomAction(g.a.a(param1Object), g.a.d(param1Object), g.a.c(param1Object), g.a.b(param1Object));
        customAction.r = param1Object;
        return customAction;
      } 
      return null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.o);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.p);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.q);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.n);
      TextUtils.writeToParcel(this.o, param1Parcel, param1Int);
      param1Parcel.writeInt(this.p);
      param1Parcel.writeBundle(this.q);
    }
    
    static final class a implements Parcelable.Creator<CustomAction> {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */