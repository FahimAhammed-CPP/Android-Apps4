package a2;

import com.birbit.android.jobqueue.CancelResult;
import z1.b;
import z1.g;

public class d extends b {
  CancelResult.AsyncCancelCallback d;
  
  CancelResult e;
  
  public d() {
    super(g.q);
  }
  
  protected void a() {
    this.e = null;
    this.d = null;
  }
  
  public CancelResult.AsyncCancelCallback c() {
    return this.d;
  }
  
  public CancelResult d() {
    return this.e;
  }
  
  public void e(CancelResult.AsyncCancelCallback paramAsyncCancelCallback, CancelResult paramCancelResult) {
    this.d = paramAsyncCancelCallback;
    this.e = paramCancelResult;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */