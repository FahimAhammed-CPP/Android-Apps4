package a2;

import com.birbit.android.jobqueue.e;
import z1.b;
import z1.g;

public class a extends b {
  private e d;
  
  public a() {
    super(g.v);
  }
  
  protected void a() {
    this.d = null;
  }
  
  public e c() {
    return this.d;
  }
  
  public void d(e parame) {
    this.d = parame;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */