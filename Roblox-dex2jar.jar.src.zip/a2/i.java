package a2;

import com.birbit.android.jobqueue.f;
import z1.b;
import z1.g;

public class i extends b {
  private f d;
  
  public i() {
    super(g.r);
  }
  
  protected void a() {
    this.d = null;
  }
  
  public f c() {
    return this.d;
  }
  
  public void d(f paramf) {
    this.d = paramf;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */