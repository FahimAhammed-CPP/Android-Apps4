package a2;

import z1.b;

public class g extends b {
  private Object d;
  
  private long e;
  
  public g() {
    super(z1.g.u);
  }
  
  protected void a() {
    this.d = null;
  }
  
  public long c() {
    return this.e;
  }
  
  public Object d() {
    return this.d;
  }
  
  public void e(long paramLong) {
    this.e = paramLong;
  }
  
  public void f(Object paramObject) {
    this.d = paramObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */