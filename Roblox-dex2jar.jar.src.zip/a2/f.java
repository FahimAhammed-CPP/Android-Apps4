package a2;

import z1.b;
import z1.g;

public class f extends b {
  public f() {
    super(g.x);
  }
  
  protected void a() {}
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */