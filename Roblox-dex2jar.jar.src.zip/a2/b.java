package a2;

import com.birbit.android.jobqueue.e;
import z1.b;
import z1.g;

public class b extends b {
  private int d;
  
  private int e;
  
  private boolean f;
  
  private e g;
  
  public b() {
    super(g.p);
  }
  
  protected void a() {
    this.g = null;
  }
  
  public e c() {
    return this.g;
  }
  
  public int d() {
    return this.e;
  }
  
  public int e() {
    return this.d;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public void g(e parame, int paramInt) {
    this.d = paramInt;
    this.g = parame;
  }
  
  public void h(e parame, int paramInt1, int paramInt2) {
    this.d = paramInt1;
    this.e = paramInt2;
    this.g = parame;
  }
  
  public void i(e parame, int paramInt, boolean paramBoolean) {
    this.d = paramInt;
    this.f = paramBoolean;
    this.g = parame;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */