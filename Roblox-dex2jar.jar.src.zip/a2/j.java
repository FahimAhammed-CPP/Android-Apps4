package a2;

import com.birbit.android.jobqueue.f;
import z1.b;
import z1.g;

public class j extends b {
  private f d;
  
  private Object e;
  
  private int f;
  
  public j() {
    super(g.y);
  }
  
  protected void a() {
    this.d = null;
  }
  
  public f c() {
    return this.d;
  }
  
  public int d() {
    return this.f;
  }
  
  public Object e() {
    return this.e;
  }
  
  public void f(f paramf) {
    this.d = paramf;
  }
  
  public void g(int paramInt) {
    this.f = paramInt;
  }
  
  public void h(Object paramObject) {
    this.e = paramObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */