package a2;

import b2.a;
import z1.b;
import z1.g;

public class k extends b {
  private int d;
  
  private a e;
  
  public k() {
    super(g.z);
  }
  
  protected void a() {
    this.e = null;
  }
  
  public a c() {
    return this.e;
  }
  
  public int d() {
    return this.d;
  }
  
  public void e(int paramInt, a parama) {
    this.d = paramInt;
    this.e = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */