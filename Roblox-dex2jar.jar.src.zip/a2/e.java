package a2;

import z1.b;
import z1.g;

public class e extends b {
  private int d;
  
  public e() {
    super(g.s);
  }
  
  protected void a() {
    this.d = -1;
  }
  
  public int c() {
    return this.d;
  }
  
  public void d(int paramInt) {
    this.d = paramInt;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Command[");
    stringBuilder.append(this.d);
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */