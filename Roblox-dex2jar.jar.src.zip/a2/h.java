package a2;

import com.birbit.android.jobqueue.IntCallback;
import z1.b;
import z1.g;

public class h extends b implements IntCallback.MessageWithCallback {
  private IntCallback d;
  
  private int e = -1;
  
  private String f;
  
  public h() {
    super(g.t);
  }
  
  protected void a() {
    this.d = null;
    this.e = -1;
  }
  
  public IntCallback c() {
    return this.d;
  }
  
  public String d() {
    return this.f;
  }
  
  public int e() {
    return this.e;
  }
  
  public void setCallback(IntCallback paramIntCallback) {
    this.d = paramIntCallback;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PublicQuery[");
    stringBuilder.append(this.e);
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */