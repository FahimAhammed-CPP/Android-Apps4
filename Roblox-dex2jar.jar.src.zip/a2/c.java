package a2;

import com.birbit.android.jobqueue.CancelResult;
import u1.g;
import z1.b;
import z1.g;

public class c extends b {
  private g d;
  
  private String[] e;
  
  private CancelResult.AsyncCancelCallback f;
  
  public c() {
    super(g.w);
  }
  
  protected void a() {}
  
  public CancelResult.AsyncCancelCallback c() {
    return this.f;
  }
  
  public g d() {
    return this.d;
  }
  
  public String[] e() {
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Roblox-dex2jar.jar!\a2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */