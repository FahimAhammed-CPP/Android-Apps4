package androidx.activity.result;

import androidx.activity.result.contract.ActivityResultContract;

public interface ActivityResultCaller {
  <I, O> ActivityResultLauncher<I> registerForActivityResult(ActivityResultContract<I, O> paramActivityResultContract, ActivityResultCallback<O> paramActivityResultCallback);
  
  <I, O> ActivityResultLauncher<I> registerForActivityResult(ActivityResultContract<I, O> paramActivityResultContract, ActivityResultRegistry paramActivityResultRegistry, ActivityResultCallback<O> paramActivityResultCallback);
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\activity\result\ActivityResultCaller.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */