package androidx.activity.result;

public interface ActivityResultRegistryOwner {
  ActivityResultRegistry getActivityResultRegistry();
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\activity\result\ActivityResultRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */