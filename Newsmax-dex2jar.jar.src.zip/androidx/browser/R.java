package androidx.browser;

public final class R {
  public static final class color {
    public static final int browser_actions_bg_grey = 2131099709;
    
    public static final int browser_actions_divider_color = 2131099710;
    
    public static final int browser_actions_text_color = 2131099711;
    
    public static final int browser_actions_title_color = 2131099712;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2131165304;
    
    public static final int browser_actions_context_menu_min_padding = 2131165305;
  }
  
  public static final class id {
    public static final int browser_actions_header_text = 2131361959;
    
    public static final int browser_actions_menu_item_icon = 2131361960;
    
    public static final int browser_actions_menu_item_text = 2131361961;
    
    public static final int browser_actions_menu_items = 2131361962;
    
    public static final int browser_actions_menu_view = 2131361963;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131558450;
    
    public static final int browser_actions_context_menu_row = 2131558451;
  }
  
  public static final class string {
    public static final int copy_toast_msg = 2131886214;
    
    public static final int fallback_menu_item_copy_link = 2131886303;
    
    public static final int fallback_menu_item_open_in_browser = 2131886304;
    
    public static final int fallback_menu_item_share_link = 2131886305;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132082688;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\browser\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */