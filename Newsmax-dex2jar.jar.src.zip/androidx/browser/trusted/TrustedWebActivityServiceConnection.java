package androidx.browser.trusted;

import android.app.Notification;
import android.content.ComponentName;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.customtabs.trusted.ITrustedWebActivityCallback;
import android.support.customtabs.trusted.ITrustedWebActivityService;

public final class TrustedWebActivityServiceConnection {
  private static final String KEY_ACTIVE_NOTIFICATIONS = "android.support.customtabs.trusted.ACTIVE_NOTIFICATIONS";
  
  private static final String KEY_CHANNEL_NAME = "android.support.customtabs.trusted.CHANNEL_NAME";
  
  private static final String KEY_NOTIFICATION = "android.support.customtabs.trusted.NOTIFICATION";
  
  private static final String KEY_NOTIFICATION_SUCCESS = "android.support.customtabs.trusted.NOTIFICATION_SUCCESS";
  
  private static final String KEY_PLATFORM_ID = "android.support.customtabs.trusted.PLATFORM_ID";
  
  private static final String KEY_PLATFORM_TAG = "android.support.customtabs.trusted.PLATFORM_TAG";
  
  private final ComponentName mComponentName;
  
  private final ITrustedWebActivityService mService;
  
  TrustedWebActivityServiceConnection(ITrustedWebActivityService paramITrustedWebActivityService, ComponentName paramComponentName) {
    this.mService = paramITrustedWebActivityService;
    this.mComponentName = paramComponentName;
  }
  
  static void ensureBundleContains(Bundle paramBundle, String paramString) {
    if (paramBundle.containsKey(paramString))
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bundle must contain ");
    stringBuilder.append(paramString);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static ITrustedWebActivityCallback wrapCallback(final TrustedWebActivityCallback callback) {
    return (ITrustedWebActivityCallback)((callback == null) ? null : new ITrustedWebActivityCallback.Stub() {
        public void onExtraCallback(String param1String, Bundle param1Bundle) throws RemoteException {
          callback.onExtraCallback(param1String, param1Bundle);
        }
      });
  }
  
  public boolean areNotificationsEnabled(String paramString) throws RemoteException {
    Bundle bundle = (new NotificationsEnabledArgs(paramString)).toBundle();
    return (ResultArgs.fromBundle(this.mService.areNotificationsEnabled(bundle))).success;
  }
  
  public void cancel(String paramString, int paramInt) throws RemoteException {
    Bundle bundle = (new CancelNotificationArgs(paramString, paramInt)).toBundle();
    this.mService.cancelNotification(bundle);
  }
  
  public Parcelable[] getActiveNotifications() throws RemoteException {
    return (ActiveNotificationsArgs.fromBundle(this.mService.getActiveNotifications())).notifications;
  }
  
  public ComponentName getComponentName() {
    return this.mComponentName;
  }
  
  public Bitmap getSmallIconBitmap() throws RemoteException {
    return (Bitmap)this.mService.getSmallIconBitmap().getParcelable("android.support.customtabs.trusted.SMALL_ICON_BITMAP");
  }
  
  public int getSmallIconId() throws RemoteException {
    return this.mService.getSmallIconId();
  }
  
  public boolean notify(String paramString1, int paramInt, Notification paramNotification, String paramString2) throws RemoteException {
    Bundle bundle = (new NotifyNotificationArgs(paramString1, paramInt, paramNotification, paramString2)).toBundle();
    return (ResultArgs.fromBundle(this.mService.notifyNotificationWithChannel(bundle))).success;
  }
  
  public Bundle sendExtraCommand(String paramString, Bundle paramBundle, TrustedWebActivityCallback paramTrustedWebActivityCallback) throws RemoteException {
    IBinder iBinder;
    ITrustedWebActivityCallback iTrustedWebActivityCallback = wrapCallback(paramTrustedWebActivityCallback);
    if (iTrustedWebActivityCallback == null) {
      iTrustedWebActivityCallback = null;
    } else {
      iBinder = iTrustedWebActivityCallback.asBinder();
    } 
    return this.mService.extraCommand(paramString, paramBundle, iBinder);
  }
  
  static class ActiveNotificationsArgs {
    public final Parcelable[] notifications;
    
    ActiveNotificationsArgs(Parcelable[] param1ArrayOfParcelable) {
      this.notifications = param1ArrayOfParcelable;
    }
    
    public static ActiveNotificationsArgs fromBundle(Bundle param1Bundle) {
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.ACTIVE_NOTIFICATIONS");
      return new ActiveNotificationsArgs(param1Bundle.getParcelableArray("android.support.customtabs.trusted.ACTIVE_NOTIFICATIONS"));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putParcelableArray("android.support.customtabs.trusted.ACTIVE_NOTIFICATIONS", this.notifications);
      return bundle;
    }
  }
  
  static class CancelNotificationArgs {
    public final int platformId;
    
    public final String platformTag;
    
    CancelNotificationArgs(String param1String, int param1Int) {
      this.platformTag = param1String;
      this.platformId = param1Int;
    }
    
    public static CancelNotificationArgs fromBundle(Bundle param1Bundle) {
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.PLATFORM_TAG");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.PLATFORM_ID");
      return new CancelNotificationArgs(param1Bundle.getString("android.support.customtabs.trusted.PLATFORM_TAG"), param1Bundle.getInt("android.support.customtabs.trusted.PLATFORM_ID"));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putString("android.support.customtabs.trusted.PLATFORM_TAG", this.platformTag);
      bundle.putInt("android.support.customtabs.trusted.PLATFORM_ID", this.platformId);
      return bundle;
    }
  }
  
  static class NotificationsEnabledArgs {
    public final String channelName;
    
    NotificationsEnabledArgs(String param1String) {
      this.channelName = param1String;
    }
    
    public static NotificationsEnabledArgs fromBundle(Bundle param1Bundle) {
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.CHANNEL_NAME");
      return new NotificationsEnabledArgs(param1Bundle.getString("android.support.customtabs.trusted.CHANNEL_NAME"));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putString("android.support.customtabs.trusted.CHANNEL_NAME", this.channelName);
      return bundle;
    }
  }
  
  static class NotifyNotificationArgs {
    public final String channelName;
    
    public final Notification notification;
    
    public final int platformId;
    
    public final String platformTag;
    
    NotifyNotificationArgs(String param1String1, int param1Int, Notification param1Notification, String param1String2) {
      this.platformTag = param1String1;
      this.platformId = param1Int;
      this.notification = param1Notification;
      this.channelName = param1String2;
    }
    
    public static NotifyNotificationArgs fromBundle(Bundle param1Bundle) {
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.PLATFORM_TAG");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.PLATFORM_ID");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.NOTIFICATION");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.CHANNEL_NAME");
      return new NotifyNotificationArgs(param1Bundle.getString("android.support.customtabs.trusted.PLATFORM_TAG"), param1Bundle.getInt("android.support.customtabs.trusted.PLATFORM_ID"), (Notification)param1Bundle.getParcelable("android.support.customtabs.trusted.NOTIFICATION"), param1Bundle.getString("android.support.customtabs.trusted.CHANNEL_NAME"));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putString("android.support.customtabs.trusted.PLATFORM_TAG", this.platformTag);
      bundle.putInt("android.support.customtabs.trusted.PLATFORM_ID", this.platformId);
      bundle.putParcelable("android.support.customtabs.trusted.NOTIFICATION", (Parcelable)this.notification);
      bundle.putString("android.support.customtabs.trusted.CHANNEL_NAME", this.channelName);
      return bundle;
    }
  }
  
  static class ResultArgs {
    public final boolean success;
    
    ResultArgs(boolean param1Boolean) {
      this.success = param1Boolean;
    }
    
    public static ResultArgs fromBundle(Bundle param1Bundle) {
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, "android.support.customtabs.trusted.NOTIFICATION_SUCCESS");
      return new ResultArgs(param1Bundle.getBoolean("android.support.customtabs.trusted.NOTIFICATION_SUCCESS"));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putBoolean("android.support.customtabs.trusted.NOTIFICATION_SUCCESS", this.success);
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityServiceConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */