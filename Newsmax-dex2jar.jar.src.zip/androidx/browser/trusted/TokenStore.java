package androidx.browser.trusted;

public interface TokenStore {
  Token load();
  
  void store(Token paramToken);
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\browser\trusted\TokenStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */