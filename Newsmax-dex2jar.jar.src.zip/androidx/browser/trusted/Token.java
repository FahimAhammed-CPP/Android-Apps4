package androidx.browser.trusted;

import android.content.pm.PackageManager;
import android.util.Log;
import java.io.IOException;
import java.util.List;

public final class Token {
  private static final String TAG = "Token";
  
  private final TokenContents mContents;
  
  private Token(TokenContents paramTokenContents) {
    this.mContents = paramTokenContents;
  }
  
  public static Token create(String paramString, PackageManager paramPackageManager) {
    List<byte[]> list = PackageIdentityUtils.getFingerprintsForPackage(paramString, paramPackageManager);
    if (list == null)
      return null; 
    try {
      return new Token(TokenContents.create(paramString, list));
    } catch (IOException iOException) {
      Log.e("Token", "Exception when creating token.", iOException);
      return null;
    } 
  }
  
  public static Token deserialize(byte[] paramArrayOfbyte) {
    return new Token(TokenContents.deserialize(paramArrayOfbyte));
  }
  
  public boolean matches(String paramString, PackageManager paramPackageManager) {
    return PackageIdentityUtils.packageMatchesToken(paramString, paramPackageManager, this.mContents);
  }
  
  public byte[] serialize() {
    return this.mContents.serialize();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\browser\trusted\Token.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */