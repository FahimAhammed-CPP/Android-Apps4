package androidx.browser.trusted;

import android.os.Bundle;



/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityDisplayMode$-CC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */