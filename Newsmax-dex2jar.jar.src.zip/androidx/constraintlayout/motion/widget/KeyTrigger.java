package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import androidx.constraintlayout.motion.utils.ViewSpline;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;

public class KeyTrigger extends Key {
  public static final String CROSS = "CROSS";
  
  public static final int KEY_TYPE = 5;
  
  static final String NAME = "KeyTrigger";
  
  public static final String NEGATIVE_CROSS = "negativeCross";
  
  public static final String POSITIVE_CROSS = "positiveCross";
  
  public static final String POST_LAYOUT = "postLayout";
  
  private static final String TAG = "KeyTrigger";
  
  public static final String TRIGGER_COLLISION_ID = "triggerCollisionId";
  
  public static final String TRIGGER_COLLISION_VIEW = "triggerCollisionView";
  
  public static final String TRIGGER_ID = "triggerID";
  
  public static final String TRIGGER_RECEIVER = "triggerReceiver";
  
  public static final String TRIGGER_SLACK = "triggerSlack";
  
  public static final String VIEW_TRANSITION_ON_CROSS = "viewTransitionOnCross";
  
  public static final String VIEW_TRANSITION_ON_NEGATIVE_CROSS = "viewTransitionOnNegativeCross";
  
  public static final String VIEW_TRANSITION_ON_POSITIVE_CROSS = "viewTransitionOnPositiveCross";
  
  RectF mCollisionRect = new RectF();
  
  private String mCross = null;
  
  private int mCurveFit = -1;
  
  private boolean mFireCrossReset = true;
  
  private float mFireLastPos;
  
  private boolean mFireNegativeReset = true;
  
  private boolean mFirePositiveReset = true;
  
  private float mFireThreshold = Float.NaN;
  
  HashMap<String, Method> mMethodHashMap = new HashMap<String, Method>();
  
  private String mNegativeCross = null;
  
  private String mPositiveCross = null;
  
  private boolean mPostLayout = false;
  
  RectF mTargetRect = new RectF();
  
  private int mTriggerCollisionId = UNSET;
  
  private View mTriggerCollisionView = null;
  
  private int mTriggerID = UNSET;
  
  private int mTriggerReceiver = UNSET;
  
  float mTriggerSlack = 0.1F;
  
  int mViewTransitionOnCross = UNSET;
  
  int mViewTransitionOnNegativeCross = UNSET;
  
  int mViewTransitionOnPositiveCross = UNSET;
  
  private void fire(String paramString, View paramView) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: ldc '.'
    //   8: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   11: ifeq -> 21
    //   14: aload_0
    //   15: aload_1
    //   16: aload_2
    //   17: invokespecial fireCustom : (Ljava/lang/String;Landroid/view/View;)V
    //   20: return
    //   21: aload_0
    //   22: getfield mMethodHashMap : Ljava/util/HashMap;
    //   25: aload_1
    //   26: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   29: ifeq -> 54
    //   32: aload_0
    //   33: getfield mMethodHashMap : Ljava/util/HashMap;
    //   36: aload_1
    //   37: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   40: checkcast java/lang/reflect/Method
    //   43: astore #4
    //   45: aload #4
    //   47: astore_3
    //   48: aload #4
    //   50: ifnonnull -> 56
    //   53: return
    //   54: aconst_null
    //   55: astore_3
    //   56: aload_3
    //   57: astore #4
    //   59: aload_3
    //   60: ifnonnull -> 168
    //   63: aload_2
    //   64: invokevirtual getClass : ()Ljava/lang/Class;
    //   67: aload_1
    //   68: iconst_0
    //   69: anewarray java/lang/Class
    //   72: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   75: astore #4
    //   77: aload_0
    //   78: getfield mMethodHashMap : Ljava/util/HashMap;
    //   81: aload_1
    //   82: aload #4
    //   84: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   87: pop
    //   88: goto -> 168
    //   91: aload_0
    //   92: getfield mMethodHashMap : Ljava/util/HashMap;
    //   95: aload_1
    //   96: aconst_null
    //   97: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   100: pop
    //   101: new java/lang/StringBuilder
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore_3
    //   109: aload_3
    //   110: ldc 'Could not find method "'
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: aload_3
    //   117: aload_1
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: pop
    //   122: aload_3
    //   123: ldc '"on class '
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload_3
    //   130: aload_2
    //   131: invokevirtual getClass : ()Ljava/lang/Class;
    //   134: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: pop
    //   141: aload_3
    //   142: ldc ' '
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: pop
    //   148: aload_3
    //   149: aload_2
    //   150: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: ldc 'KeyTrigger'
    //   159: aload_3
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   166: pop
    //   167: return
    //   168: aload #4
    //   170: aload_2
    //   171: iconst_0
    //   172: anewarray java/lang/Object
    //   175: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   178: pop
    //   179: return
    //   180: new java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore_1
    //   188: aload_1
    //   189: ldc 'Exception in call "'
    //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: pop
    //   195: aload_1
    //   196: aload_0
    //   197: getfield mCross : Ljava/lang/String;
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload_1
    //   205: ldc '"on class '
    //   207: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   210: pop
    //   211: aload_1
    //   212: aload_2
    //   213: invokevirtual getClass : ()Ljava/lang/Class;
    //   216: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: pop
    //   223: aload_1
    //   224: ldc ' '
    //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: pop
    //   230: aload_1
    //   231: aload_2
    //   232: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   235: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: pop
    //   239: ldc 'KeyTrigger'
    //   241: aload_1
    //   242: invokevirtual toString : ()Ljava/lang/String;
    //   245: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   248: pop
    //   249: return
    //   250: astore_3
    //   251: goto -> 91
    //   254: astore_1
    //   255: goto -> 180
    // Exception table:
    //   from	to	target	type
    //   63	88	250	java/lang/NoSuchMethodException
    //   168	179	254	java/lang/Exception
  }
  
  private void fireCustom(String paramString, View paramView) {
    boolean bool;
    if (paramString.length() == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    String str = paramString;
    if (!bool)
      str = paramString.substring(1).toLowerCase(Locale.ROOT); 
    for (String str1 : this.mCustomConstraints.keySet()) {
      String str2 = str1.toLowerCase(Locale.ROOT);
      if (bool || str2.matches(str)) {
        ConstraintAttribute constraintAttribute = this.mCustomConstraints.get(str1);
        if (constraintAttribute != null)
          constraintAttribute.applyCustom(paramView); 
      } 
    } 
  }
  
  private void setUpRect(RectF paramRectF, View paramView, boolean paramBoolean) {
    paramRectF.top = paramView.getTop();
    paramRectF.bottom = paramView.getBottom();
    paramRectF.left = paramView.getLeft();
    paramRectF.right = paramView.getRight();
    if (paramBoolean)
      paramView.getMatrix().mapRect(paramRectF); 
  }
  
  public void addValues(HashMap<String, ViewSpline> paramHashMap) {}
  
  public Key clone() {
    return (new KeyTrigger()).copy(this);
  }
  
  public void conditionallyFire(float paramFloat, View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTriggerCollisionId : I
    //   4: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   7: if_icmpeq -> 181
    //   10: aload_0
    //   11: getfield mTriggerCollisionView : Landroid/view/View;
    //   14: ifnonnull -> 35
    //   17: aload_0
    //   18: aload_2
    //   19: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   22: checkcast android/view/ViewGroup
    //   25: aload_0
    //   26: getfield mTriggerCollisionId : I
    //   29: invokevirtual findViewById : (I)Landroid/view/View;
    //   32: putfield mTriggerCollisionView : Landroid/view/View;
    //   35: aload_0
    //   36: aload_0
    //   37: getfield mCollisionRect : Landroid/graphics/RectF;
    //   40: aload_0
    //   41: getfield mTriggerCollisionView : Landroid/view/View;
    //   44: aload_0
    //   45: getfield mPostLayout : Z
    //   48: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   51: aload_0
    //   52: aload_0
    //   53: getfield mTargetRect : Landroid/graphics/RectF;
    //   56: aload_2
    //   57: aload_0
    //   58: getfield mPostLayout : Z
    //   61: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   64: aload_0
    //   65: getfield mCollisionRect : Landroid/graphics/RectF;
    //   68: aload_0
    //   69: getfield mTargetRect : Landroid/graphics/RectF;
    //   72: invokevirtual intersect : (Landroid/graphics/RectF;)Z
    //   75: ifeq -> 131
    //   78: aload_0
    //   79: getfield mFireCrossReset : Z
    //   82: ifeq -> 96
    //   85: aload_0
    //   86: iconst_0
    //   87: putfield mFireCrossReset : Z
    //   90: iconst_1
    //   91: istore #5
    //   93: goto -> 99
    //   96: iconst_0
    //   97: istore #5
    //   99: aload_0
    //   100: getfield mFirePositiveReset : Z
    //   103: ifeq -> 117
    //   106: aload_0
    //   107: iconst_0
    //   108: putfield mFirePositiveReset : Z
    //   111: iconst_1
    //   112: istore #7
    //   114: goto -> 120
    //   117: iconst_0
    //   118: istore #7
    //   120: aload_0
    //   121: iconst_1
    //   122: putfield mFireNegativeReset : Z
    //   125: iconst_0
    //   126: istore #6
    //   128: goto -> 398
    //   131: aload_0
    //   132: getfield mFireCrossReset : Z
    //   135: ifne -> 149
    //   138: aload_0
    //   139: iconst_1
    //   140: putfield mFireCrossReset : Z
    //   143: iconst_1
    //   144: istore #5
    //   146: goto -> 152
    //   149: iconst_0
    //   150: istore #5
    //   152: aload_0
    //   153: getfield mFireNegativeReset : Z
    //   156: ifeq -> 170
    //   159: aload_0
    //   160: iconst_0
    //   161: putfield mFireNegativeReset : Z
    //   164: iconst_1
    //   165: istore #6
    //   167: goto -> 173
    //   170: iconst_0
    //   171: istore #6
    //   173: aload_0
    //   174: iconst_1
    //   175: putfield mFirePositiveReset : Z
    //   178: goto -> 395
    //   181: aload_0
    //   182: getfield mFireCrossReset : Z
    //   185: ifeq -> 219
    //   188: aload_0
    //   189: getfield mFireThreshold : F
    //   192: fstore_3
    //   193: fload_1
    //   194: fload_3
    //   195: fsub
    //   196: aload_0
    //   197: getfield mFireLastPos : F
    //   200: fload_3
    //   201: fsub
    //   202: fmul
    //   203: fconst_0
    //   204: fcmpg
    //   205: ifge -> 241
    //   208: aload_0
    //   209: iconst_0
    //   210: putfield mFireCrossReset : Z
    //   213: iconst_1
    //   214: istore #5
    //   216: goto -> 244
    //   219: fload_1
    //   220: aload_0
    //   221: getfield mFireThreshold : F
    //   224: fsub
    //   225: invokestatic abs : (F)F
    //   228: aload_0
    //   229: getfield mTriggerSlack : F
    //   232: fcmpl
    //   233: ifle -> 241
    //   236: aload_0
    //   237: iconst_1
    //   238: putfield mFireCrossReset : Z
    //   241: iconst_0
    //   242: istore #5
    //   244: aload_0
    //   245: getfield mFireNegativeReset : Z
    //   248: ifeq -> 293
    //   251: aload_0
    //   252: getfield mFireThreshold : F
    //   255: fstore_3
    //   256: fload_1
    //   257: fload_3
    //   258: fsub
    //   259: fstore #4
    //   261: aload_0
    //   262: getfield mFireLastPos : F
    //   265: fload_3
    //   266: fsub
    //   267: fload #4
    //   269: fmul
    //   270: fconst_0
    //   271: fcmpg
    //   272: ifge -> 315
    //   275: fload #4
    //   277: fconst_0
    //   278: fcmpg
    //   279: ifge -> 315
    //   282: aload_0
    //   283: iconst_0
    //   284: putfield mFireNegativeReset : Z
    //   287: iconst_1
    //   288: istore #6
    //   290: goto -> 318
    //   293: fload_1
    //   294: aload_0
    //   295: getfield mFireThreshold : F
    //   298: fsub
    //   299: invokestatic abs : (F)F
    //   302: aload_0
    //   303: getfield mTriggerSlack : F
    //   306: fcmpl
    //   307: ifle -> 315
    //   310: aload_0
    //   311: iconst_1
    //   312: putfield mFireNegativeReset : Z
    //   315: iconst_0
    //   316: istore #6
    //   318: aload_0
    //   319: getfield mFirePositiveReset : Z
    //   322: ifeq -> 373
    //   325: aload_0
    //   326: getfield mFireThreshold : F
    //   329: fstore_3
    //   330: fload_1
    //   331: fload_3
    //   332: fsub
    //   333: fstore #4
    //   335: aload_0
    //   336: getfield mFireLastPos : F
    //   339: fload_3
    //   340: fsub
    //   341: fload #4
    //   343: fmul
    //   344: fconst_0
    //   345: fcmpg
    //   346: ifge -> 367
    //   349: fload #4
    //   351: fconst_0
    //   352: fcmpl
    //   353: ifle -> 367
    //   356: aload_0
    //   357: iconst_0
    //   358: putfield mFirePositiveReset : Z
    //   361: iconst_1
    //   362: istore #7
    //   364: goto -> 370
    //   367: iconst_0
    //   368: istore #7
    //   370: goto -> 398
    //   373: fload_1
    //   374: aload_0
    //   375: getfield mFireThreshold : F
    //   378: fsub
    //   379: invokestatic abs : (F)F
    //   382: aload_0
    //   383: getfield mTriggerSlack : F
    //   386: fcmpl
    //   387: ifle -> 395
    //   390: aload_0
    //   391: iconst_1
    //   392: putfield mFirePositiveReset : Z
    //   395: iconst_0
    //   396: istore #7
    //   398: aload_0
    //   399: fload_1
    //   400: putfield mFireLastPos : F
    //   403: iload #6
    //   405: ifne -> 418
    //   408: iload #5
    //   410: ifne -> 418
    //   413: iload #7
    //   415: ifeq -> 435
    //   418: aload_2
    //   419: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   422: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   425: aload_0
    //   426: getfield mTriggerID : I
    //   429: iload #7
    //   431: fload_1
    //   432: invokevirtual fireTrigger : (IZF)V
    //   435: aload_0
    //   436: getfield mTriggerReceiver : I
    //   439: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   442: if_icmpne -> 451
    //   445: aload_2
    //   446: astore #8
    //   448: goto -> 467
    //   451: aload_2
    //   452: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   455: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   458: aload_0
    //   459: getfield mTriggerReceiver : I
    //   462: invokevirtual findViewById : (I)Landroid/view/View;
    //   465: astore #8
    //   467: iload #6
    //   469: ifeq -> 524
    //   472: aload_0
    //   473: getfield mNegativeCross : Ljava/lang/String;
    //   476: astore #9
    //   478: aload #9
    //   480: ifnull -> 491
    //   483: aload_0
    //   484: aload #9
    //   486: aload #8
    //   488: invokespecial fire : (Ljava/lang/String;Landroid/view/View;)V
    //   491: aload_0
    //   492: getfield mViewTransitionOnNegativeCross : I
    //   495: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   498: if_icmpeq -> 524
    //   501: aload_2
    //   502: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   505: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   508: aload_0
    //   509: getfield mViewTransitionOnNegativeCross : I
    //   512: iconst_1
    //   513: anewarray android/view/View
    //   516: dup
    //   517: iconst_0
    //   518: aload #8
    //   520: aastore
    //   521: invokevirtual viewTransition : (I[Landroid/view/View;)V
    //   524: iload #7
    //   526: ifeq -> 581
    //   529: aload_0
    //   530: getfield mPositiveCross : Ljava/lang/String;
    //   533: astore #9
    //   535: aload #9
    //   537: ifnull -> 548
    //   540: aload_0
    //   541: aload #9
    //   543: aload #8
    //   545: invokespecial fire : (Ljava/lang/String;Landroid/view/View;)V
    //   548: aload_0
    //   549: getfield mViewTransitionOnPositiveCross : I
    //   552: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   555: if_icmpeq -> 581
    //   558: aload_2
    //   559: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   562: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   565: aload_0
    //   566: getfield mViewTransitionOnPositiveCross : I
    //   569: iconst_1
    //   570: anewarray android/view/View
    //   573: dup
    //   574: iconst_0
    //   575: aload #8
    //   577: aastore
    //   578: invokevirtual viewTransition : (I[Landroid/view/View;)V
    //   581: iload #5
    //   583: ifeq -> 638
    //   586: aload_0
    //   587: getfield mCross : Ljava/lang/String;
    //   590: astore #9
    //   592: aload #9
    //   594: ifnull -> 605
    //   597: aload_0
    //   598: aload #9
    //   600: aload #8
    //   602: invokespecial fire : (Ljava/lang/String;Landroid/view/View;)V
    //   605: aload_0
    //   606: getfield mViewTransitionOnCross : I
    //   609: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   612: if_icmpeq -> 638
    //   615: aload_2
    //   616: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   619: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   622: aload_0
    //   623: getfield mViewTransitionOnCross : I
    //   626: iconst_1
    //   627: anewarray android/view/View
    //   630: dup
    //   631: iconst_0
    //   632: aload #8
    //   634: aastore
    //   635: invokevirtual viewTransition : (I[Landroid/view/View;)V
    //   638: return
  }
  
  public Key copy(Key paramKey) {
    super.copy(paramKey);
    paramKey = paramKey;
    this.mCurveFit = ((KeyTrigger)paramKey).mCurveFit;
    this.mCross = ((KeyTrigger)paramKey).mCross;
    this.mTriggerReceiver = ((KeyTrigger)paramKey).mTriggerReceiver;
    this.mNegativeCross = ((KeyTrigger)paramKey).mNegativeCross;
    this.mPositiveCross = ((KeyTrigger)paramKey).mPositiveCross;
    this.mTriggerID = ((KeyTrigger)paramKey).mTriggerID;
    this.mTriggerCollisionId = ((KeyTrigger)paramKey).mTriggerCollisionId;
    this.mTriggerCollisionView = ((KeyTrigger)paramKey).mTriggerCollisionView;
    this.mTriggerSlack = ((KeyTrigger)paramKey).mTriggerSlack;
    this.mFireCrossReset = ((KeyTrigger)paramKey).mFireCrossReset;
    this.mFireNegativeReset = ((KeyTrigger)paramKey).mFireNegativeReset;
    this.mFirePositiveReset = ((KeyTrigger)paramKey).mFirePositiveReset;
    this.mFireThreshold = ((KeyTrigger)paramKey).mFireThreshold;
    this.mFireLastPos = ((KeyTrigger)paramKey).mFireLastPos;
    this.mPostLayout = ((KeyTrigger)paramKey).mPostLayout;
    this.mCollisionRect = ((KeyTrigger)paramKey).mCollisionRect;
    this.mTargetRect = ((KeyTrigger)paramKey).mTargetRect;
    this.mMethodHashMap = ((KeyTrigger)paramKey).mMethodHashMap;
    return this;
  }
  
  public void getAttributeNames(HashSet<String> paramHashSet) {}
  
  int getCurveFit() {
    return this.mCurveFit;
  }
  
  public void load(Context paramContext, AttributeSet paramAttributeSet) {
    Loader.read(this, paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.KeyTrigger), paramContext);
  }
  
  public void setValue(String paramString, Object paramObject) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 1535404999:
        if (!paramString.equals("triggerReceiver"))
          break; 
        b = 11;
        break;
      case 1401391082:
        if (!paramString.equals("postLayout"))
          break; 
        b = 10;
        break;
      case 1301930599:
        if (!paramString.equals("viewTransitionOnCross"))
          break; 
        b = 9;
        break;
      case 364489912:
        if (!paramString.equals("triggerSlack"))
          break; 
        b = 8;
        break;
      case 64397344:
        if (!paramString.equals("CROSS"))
          break; 
        b = 7;
        break;
      case -9754574:
        if (!paramString.equals("viewTransitionOnNegativeCross"))
          break; 
        b = 6;
        break;
      case -76025313:
        if (!paramString.equals("triggerCollisionView"))
          break; 
        b = 5;
        break;
      case -638126837:
        if (!paramString.equals("negativeCross"))
          break; 
        b = 4;
        break;
      case -648752941:
        if (!paramString.equals("triggerID"))
          break; 
        b = 3;
        break;
      case -786670827:
        if (!paramString.equals("triggerCollisionId"))
          break; 
        b = 2;
        break;
      case -966421266:
        if (!paramString.equals("viewTransitionOnPositiveCross"))
          break; 
        b = 1;
        break;
      case -1594793529:
        if (!paramString.equals("positiveCross"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        return;
      case 11:
        this.mTriggerReceiver = toInt(paramObject);
        return;
      case 10:
        this.mPostLayout = toBoolean(paramObject);
        return;
      case 9:
        this.mViewTransitionOnCross = toInt(paramObject);
        return;
      case 8:
        this.mTriggerSlack = toFloat(paramObject);
        return;
      case 7:
        this.mCross = paramObject.toString();
        return;
      case 6:
        this.mViewTransitionOnNegativeCross = toInt(paramObject);
        return;
      case 5:
        this.mTriggerCollisionView = (View)paramObject;
        return;
      case 4:
        this.mNegativeCross = paramObject.toString();
        return;
      case 3:
        this.mTriggerID = toInt(paramObject);
        return;
      case 2:
        this.mTriggerCollisionId = toInt(paramObject);
        return;
      case 1:
        this.mViewTransitionOnPositiveCross = toInt(paramObject);
        return;
      case 0:
        break;
    } 
    this.mPositiveCross = paramObject.toString();
  }
  
  private static class Loader {
    private static final int COLLISION = 9;
    
    private static final int CROSS = 4;
    
    private static final int FRAME_POS = 8;
    
    private static final int NEGATIVE_CROSS = 1;
    
    private static final int POSITIVE_CROSS = 2;
    
    private static final int POST_LAYOUT = 10;
    
    private static final int TARGET_ID = 7;
    
    private static final int TRIGGER_ID = 6;
    
    private static final int TRIGGER_RECEIVER = 11;
    
    private static final int TRIGGER_SLACK = 5;
    
    private static final int VT_CROSS = 12;
    
    private static final int VT_NEGATIVE_CROSS = 13;
    
    private static final int VT_POSITIVE_CROSS = 14;
    
    private static SparseIntArray mAttrMap;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mAttrMap = sparseIntArray;
      sparseIntArray.append(R.styleable.KeyTrigger_framePosition, 8);
      mAttrMap.append(R.styleable.KeyTrigger_onCross, 4);
      mAttrMap.append(R.styleable.KeyTrigger_onNegativeCross, 1);
      mAttrMap.append(R.styleable.KeyTrigger_onPositiveCross, 2);
      mAttrMap.append(R.styleable.KeyTrigger_motionTarget, 7);
      mAttrMap.append(R.styleable.KeyTrigger_triggerId, 6);
      mAttrMap.append(R.styleable.KeyTrigger_triggerSlack, 5);
      mAttrMap.append(R.styleable.KeyTrigger_motion_triggerOnCollision, 9);
      mAttrMap.append(R.styleable.KeyTrigger_motion_postLayoutCollision, 10);
      mAttrMap.append(R.styleable.KeyTrigger_triggerReceiver, 11);
      mAttrMap.append(R.styleable.KeyTrigger_viewTransitionOnCross, 12);
      mAttrMap.append(R.styleable.KeyTrigger_viewTransitionOnNegativeCross, 13);
      mAttrMap.append(R.styleable.KeyTrigger_viewTransitionOnPositiveCross, 14);
    }
    
    public static void read(KeyTrigger param1KeyTrigger, TypedArray param1TypedArray, Context param1Context) {
      int j = param1TypedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        int k = param1TypedArray.getIndex(i);
        switch (mAttrMap.get(k)) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("unused attribute 0x");
            stringBuilder.append(Integer.toHexString(k));
            stringBuilder.append("   ");
            stringBuilder.append(mAttrMap.get(k));
            Log.e("KeyTrigger", stringBuilder.toString());
            break;
          case 14:
            param1KeyTrigger.mViewTransitionOnPositiveCross = param1TypedArray.getResourceId(k, param1KeyTrigger.mViewTransitionOnPositiveCross);
            break;
          case 13:
            param1KeyTrigger.mViewTransitionOnNegativeCross = param1TypedArray.getResourceId(k, param1KeyTrigger.mViewTransitionOnNegativeCross);
            break;
          case 12:
            param1KeyTrigger.mViewTransitionOnCross = param1TypedArray.getResourceId(k, param1KeyTrigger.mViewTransitionOnCross);
            break;
          case 11:
            KeyTrigger.access$702(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerReceiver));
            break;
          case 10:
            KeyTrigger.access$602(param1KeyTrigger, param1TypedArray.getBoolean(k, param1KeyTrigger.mPostLayout));
            break;
          case 9:
            KeyTrigger.access$502(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerCollisionId));
            break;
          case 8:
            param1KeyTrigger.mFramePosition = param1TypedArray.getInteger(k, param1KeyTrigger.mFramePosition);
            KeyTrigger.access$002(param1KeyTrigger, (param1KeyTrigger.mFramePosition + 0.5F) / 100.0F);
            break;
          case 7:
            if (MotionLayout.IS_IN_EDIT_MODE) {
              param1KeyTrigger.mTargetId = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
              if (param1KeyTrigger.mTargetId == -1)
                param1KeyTrigger.mTargetString = param1TypedArray.getString(k); 
              break;
            } 
            if ((param1TypedArray.peekValue(k)).type == 3) {
              param1KeyTrigger.mTargetString = param1TypedArray.getString(k);
              break;
            } 
            param1KeyTrigger.mTargetId = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
            break;
          case 6:
            KeyTrigger.access$402(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerID));
            break;
          case 5:
            param1KeyTrigger.mTriggerSlack = param1TypedArray.getFloat(k, param1KeyTrigger.mTriggerSlack);
            break;
          case 4:
            KeyTrigger.access$302(param1KeyTrigger, param1TypedArray.getString(k));
            break;
          case 2:
            KeyTrigger.access$202(param1KeyTrigger, param1TypedArray.getString(k));
            break;
          case 1:
            KeyTrigger.access$102(param1KeyTrigger, param1TypedArray.getString(k));
            break;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */