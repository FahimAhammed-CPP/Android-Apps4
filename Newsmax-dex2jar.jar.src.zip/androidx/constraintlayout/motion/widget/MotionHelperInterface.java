package androidx.constraintlayout.motion.widget;

import android.graphics.Canvas;
import android.view.View;
import java.util.HashMap;

public interface MotionHelperInterface extends Animatable, MotionLayout.TransitionListener {
  boolean isDecorator();
  
  boolean isUseOnHide();
  
  boolean isUsedOnShow();
  
  void onFinishedMotionScene(MotionLayout paramMotionLayout);
  
  void onPostDraw(Canvas paramCanvas);
  
  void onPreDraw(Canvas paramCanvas);
  
  void onPreSetup(MotionLayout paramMotionLayout, HashMap<View, MotionController> paramHashMap);
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionHelperInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */