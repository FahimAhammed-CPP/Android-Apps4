package androidx.constraintlayout.core;

public class Cache {
  Pools.Pool<ArrayRow> arrayRowPool = new Pools.SimplePool<ArrayRow>(256);
  
  SolverVariable[] mIndexedVariables = new SolverVariable[32];
  
  Pools.Pool<ArrayRow> optimizedArrayRowPool = new Pools.SimplePool<ArrayRow>(256);
  
  Pools.Pool<SolverVariable> solverVariablePool = new Pools.SimplePool<SolverVariable>(256);
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\Cache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */