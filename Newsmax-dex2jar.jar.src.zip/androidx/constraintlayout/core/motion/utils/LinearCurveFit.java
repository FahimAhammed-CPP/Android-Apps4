package androidx.constraintlayout.core.motion.utils;

public class LinearCurveFit extends CurveFit {
  private static final String TAG = "LinearCurveFit";
  
  private boolean mExtrapolate = true;
  
  double[] mSlopeTemp;
  
  private double[] mT;
  
  private double mTotalLength = Double.NaN;
  
  private double[][] mY;
  
  public LinearCurveFit(double[] paramArrayOfdouble, double[][] paramArrayOfdouble1) {
    int i = paramArrayOfdouble.length;
    i = (paramArrayOfdouble1[0]).length;
    this.mSlopeTemp = new double[i];
    this.mT = paramArrayOfdouble;
    this.mY = paramArrayOfdouble1;
    if (i > 2) {
      i = 0;
      double d1 = 0.0D;
      double d2;
      for (d2 = d1; i < paramArrayOfdouble.length; d2 = d3) {
        double d4 = paramArrayOfdouble1[i][0];
        double d3 = paramArrayOfdouble1[i][0];
        if (i > 0)
          Math.hypot(d4 - d1, d3 - d2); 
        i++;
        d1 = d4;
      } 
      this.mTotalLength = 0.0D;
    } 
  }
  
  private double getLength2D(double paramDouble) {
    if (Double.isNaN(this.mTotalLength))
      return 0.0D; 
    double[] arrayOfDouble = this.mT;
    int i = arrayOfDouble.length;
    if (paramDouble <= arrayOfDouble[0])
      return 0.0D; 
    int j = i - 1;
    if (paramDouble >= arrayOfDouble[j])
      return this.mTotalLength; 
    double d2 = 0.0D;
    double d1 = d2;
    double d4 = d1;
    i = 0;
    double d3 = d1;
    while (i < j) {
      double[][] arrayOfDouble2 = this.mY;
      double d6 = arrayOfDouble2[i][0];
      double d5 = arrayOfDouble2[i][1];
      d1 = d2;
      if (i > 0)
        d1 = d2 + Math.hypot(d6 - d3, d5 - d4); 
      double[] arrayOfDouble1 = this.mT;
      if (paramDouble == arrayOfDouble1[i])
        return d1; 
      int k = i + 1;
      if (paramDouble < arrayOfDouble1[k]) {
        d2 = arrayOfDouble1[k];
        d3 = arrayOfDouble1[i];
        paramDouble = (paramDouble - arrayOfDouble1[i]) / (d2 - d3);
        double[][] arrayOfDouble3 = this.mY;
        d2 = arrayOfDouble3[i][0];
        d3 = arrayOfDouble3[k][0];
        d4 = arrayOfDouble3[i][1];
        double d7 = arrayOfDouble3[k][1];
        double d8 = 1.0D - paramDouble;
        return d1 + Math.hypot(d5 - d4 * d8 + d7 * paramDouble, d6 - d2 * d8 + d3 * paramDouble);
      } 
      i = k;
      d3 = d6;
      d4 = d5;
      d2 = d1;
    } 
    return 0.0D;
  }
  
  public double getPos(double paramDouble, int paramInt) {
    double[] arrayOfDouble = this.mT;
    int j = arrayOfDouble.length;
    boolean bool = this.mExtrapolate;
    int i = 0;
    if (bool) {
      if (paramDouble <= arrayOfDouble[0])
        return this.mY[0][paramInt] + (paramDouble - arrayOfDouble[0]) * getSlope(arrayOfDouble[0], paramInt); 
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        return this.mY[k][paramInt] + (paramDouble - arrayOfDouble[k]) * getSlope(arrayOfDouble[k], paramInt); 
    } else {
      if (paramDouble <= arrayOfDouble[0])
        return this.mY[0][paramInt]; 
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        return this.mY[k][paramInt]; 
    } 
    while (i < j - 1) {
      arrayOfDouble = this.mT;
      if (paramDouble == arrayOfDouble[i])
        return this.mY[i][paramInt]; 
      int k = i + 1;
      if (paramDouble < arrayOfDouble[k]) {
        double d1 = arrayOfDouble[k];
        double d2 = arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / (d1 - d2);
        double[][] arrayOfDouble1 = this.mY;
        return arrayOfDouble1[i][paramInt] * (1.0D - paramDouble) + arrayOfDouble1[k][paramInt] * paramDouble;
      } 
      i = k;
    } 
    return 0.0D;
  }
  
  public void getPos(double paramDouble, double[] paramArrayOfdouble) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      if (paramDouble <= arrayOfDouble[0]) {
        getSlope(arrayOfDouble[0], this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]; 
        return;
      } 
      j = m - 1;
      if (paramDouble >= arrayOfDouble[j]) {
        getSlope(arrayOfDouble[j], this.mSlopeTemp);
        while (i < k) {
          paramArrayOfdouble[i] = this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i];
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOfdouble[i] = this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOfdouble[j] = this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (paramDouble < arrayOfDouble[n]) {
        double d1 = arrayOfDouble[n];
        double d2 = arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / (d1 - d2);
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          paramArrayOfdouble[j] = arrayOfDouble2[i][j] * (1.0D - paramDouble) + arrayOfDouble2[n][j] * paramDouble;
        } 
        return;
      } 
    } 
  }
  
  public void getPos(double paramDouble, float[] paramArrayOffloat) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      if (paramDouble <= arrayOfDouble[0]) {
        getSlope(arrayOfDouble[0], this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)(this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]); 
        return;
      } 
      j = m - 1;
      if (paramDouble >= arrayOfDouble[j]) {
        getSlope(arrayOfDouble[j], this.mSlopeTemp);
        while (i < k) {
          paramArrayOffloat[i] = (float)(this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i]);
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOffloat[j] = (float)this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (paramDouble < arrayOfDouble[n]) {
        double d1 = arrayOfDouble[n];
        double d2 = arrayOfDouble[i];
        paramDouble = (paramDouble - arrayOfDouble[i]) / (d1 - d2);
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          paramArrayOffloat[j] = (float)(arrayOfDouble2[i][j] * (1.0D - paramDouble) + arrayOfDouble2[n][j] * paramDouble);
        } 
        return;
      } 
    } 
  }
  
  public double getSlope(double paramDouble, int paramInt) {
    double d;
    int i;
    double[] arrayOfDouble = this.mT;
    int k = arrayOfDouble.length;
    int j = 0;
    if (paramDouble < arrayOfDouble[0]) {
      d = arrayOfDouble[0];
      i = j;
    } else {
      int m = k - 1;
      i = j;
      d = paramDouble;
      if (paramDouble >= arrayOfDouble[m]) {
        d = arrayOfDouble[m];
        i = j;
      } 
    } 
    while (i < k - 1) {
      arrayOfDouble = this.mT;
      j = i + 1;
      if (d <= arrayOfDouble[j]) {
        paramDouble = arrayOfDouble[j];
        d = arrayOfDouble[i];
        double d1 = arrayOfDouble[i];
        double[][] arrayOfDouble1 = this.mY;
        d1 = arrayOfDouble1[i][paramInt];
        return (arrayOfDouble1[j][paramInt] - d1) / (paramDouble - d);
      } 
      i = j;
    } 
    return 0.0D;
  }
  
  public void getSlope(double paramDouble, double[] paramArrayOfdouble) {
    double d;
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    int k = (arrayOfDouble1[0]).length;
    if (paramDouble <= arrayOfDouble[0]) {
      d = arrayOfDouble[0];
    } else {
      int n = m - 1;
      d = paramDouble;
      if (paramDouble >= arrayOfDouble[n])
        d = arrayOfDouble[n]; 
    } 
    int i;
    for (i = 0; i < m - 1; i = n) {
      arrayOfDouble = this.mT;
      int n = i + 1;
      if (d <= arrayOfDouble[n]) {
        paramDouble = arrayOfDouble[n];
        d = arrayOfDouble[i];
        double d1 = arrayOfDouble[i];
        while (j < k) {
          double[][] arrayOfDouble2 = this.mY;
          d1 = arrayOfDouble2[i][j];
          paramArrayOfdouble[j] = (arrayOfDouble2[n][j] - d1) / (paramDouble - d);
          j++;
        } 
        break;
      } 
    } 
  }
  
  public double[] getTimePoints() {
    return this.mT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\LinearCurveFit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */