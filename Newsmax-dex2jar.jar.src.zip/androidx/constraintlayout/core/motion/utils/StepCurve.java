package androidx.constraintlayout.core.motion.utils;

import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.Arrays;

public class StepCurve extends Easing {
  private static final boolean DEBUG = false;
  
  MonotonicCurveFit mCurveFit;
  
  StepCurve(String paramString) {
    this.str = paramString;
    double[] arrayOfDouble = new double[this.str.length() / 2];
    int j = paramString.indexOf('(') + 1;
    int k = paramString.indexOf(',', j);
    int i;
    for (i = 0; k != -1; i++) {
      arrayOfDouble[i] = Double.parseDouble(paramString.substring(j, k).trim());
      j = k + 1;
      k = paramString.indexOf(',', j);
    } 
    arrayOfDouble[i] = Double.parseDouble(paramString.substring(j, paramString.indexOf(')', j)).trim());
    this.mCurveFit = genSpline(Arrays.copyOf(arrayOfDouble, i + 1));
  }
  
  private static MonotonicCurveFit genSpline(String paramString) {
    String[] arrayOfString = paramString.split("\\s+");
    int j = arrayOfString.length;
    double[] arrayOfDouble = new double[j];
    for (int i = 0; i < j; i++)
      arrayOfDouble[i] = Double.parseDouble(arrayOfString[i]); 
    return genSpline(arrayOfDouble);
  }
  
  private static MonotonicCurveFit genSpline(double[] paramArrayOfdouble) {
    int i = paramArrayOfdouble.length * 3 - 2;
    int j = paramArrayOfdouble.length - 1;
    double d = 1.0D / j;
    double[][] arrayOfDouble = (double[][])Array.newInstance(double.class, new int[] { i, 1 });
    double[] arrayOfDouble1 = new double[i];
    for (i = 0; i < paramArrayOfdouble.length; i++) {
      double d1 = paramArrayOfdouble[i];
      int k = i + j;
      arrayOfDouble[k][0] = d1;
      double d2 = i * d;
      arrayOfDouble1[k] = d2;
      if (i > 0) {
        k = j * 2 + i;
        arrayOfDouble[k][0] = d1 + 1.0D;
        arrayOfDouble1[k] = d2 + 1.0D;
        k = i - 1;
        arrayOfDouble[k][0] = d1 - 1.0D - d;
        arrayOfDouble1[k] = d2 - 1.0D - d;
      } 
    } 
    MonotonicCurveFit monotonicCurveFit = new MonotonicCurveFit(arrayOfDouble1, arrayOfDouble);
    PrintStream printStream = System.out;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" 0 ");
    stringBuilder.append(monotonicCurveFit.getPos(0.0D, 0));
    printStream.println(stringBuilder.toString());
    printStream = System.out;
    stringBuilder = new StringBuilder();
    stringBuilder.append(" 1 ");
    stringBuilder.append(monotonicCurveFit.getPos(1.0D, 0));
    printStream.println(stringBuilder.toString());
    return monotonicCurveFit;
  }
  
  public double get(double paramDouble) {
    return this.mCurveFit.getPos(paramDouble, 0);
  }
  
  public double getDiff(double paramDouble) {
    return this.mCurveFit.getSlope(paramDouble, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\StepCurve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */