package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;

public class Chain {
  private static final boolean DEBUG = false;
  
  public static final boolean USE_CHAIN_OPTIMIZATION = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: iload_2
    //   1: istore #17
    //   3: aload #4
    //   5: getfield mFirst : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   8: astore #23
    //   10: aload #4
    //   12: getfield mLast : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   15: astore #27
    //   17: aload #4
    //   19: getfield mFirstVisibleWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   22: astore #18
    //   24: aload #4
    //   26: getfield mLastVisibleWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   29: astore #25
    //   31: aload #4
    //   33: getfield mHead : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   36: astore #20
    //   38: aload #4
    //   40: getfield mTotalWeight : F
    //   43: fstore #5
    //   45: aload #4
    //   47: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   50: astore #19
    //   52: aload #4
    //   54: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   57: astore #19
    //   59: aload_0
    //   60: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   63: iload #17
    //   65: aaload
    //   66: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   69: if_acmpne -> 78
    //   72: iconst_1
    //   73: istore #13
    //   75: goto -> 81
    //   78: iconst_0
    //   79: istore #13
    //   81: iload #17
    //   83: ifne -> 141
    //   86: aload #20
    //   88: getfield mHorizontalChainStyle : I
    //   91: ifne -> 100
    //   94: iconst_1
    //   95: istore #8
    //   97: goto -> 103
    //   100: iconst_0
    //   101: istore #8
    //   103: aload #20
    //   105: getfield mHorizontalChainStyle : I
    //   108: iconst_1
    //   109: if_icmpne -> 118
    //   112: iconst_1
    //   113: istore #9
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #9
    //   121: iload #8
    //   123: istore #10
    //   125: iload #9
    //   127: istore #11
    //   129: aload #20
    //   131: getfield mHorizontalChainStyle : I
    //   134: iconst_2
    //   135: if_icmpne -> 207
    //   138: goto -> 193
    //   141: aload #20
    //   143: getfield mVerticalChainStyle : I
    //   146: ifne -> 155
    //   149: iconst_1
    //   150: istore #8
    //   152: goto -> 158
    //   155: iconst_0
    //   156: istore #8
    //   158: aload #20
    //   160: getfield mVerticalChainStyle : I
    //   163: iconst_1
    //   164: if_icmpne -> 173
    //   167: iconst_1
    //   168: istore #9
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #9
    //   176: iload #8
    //   178: istore #10
    //   180: iload #9
    //   182: istore #11
    //   184: aload #20
    //   186: getfield mVerticalChainStyle : I
    //   189: iconst_2
    //   190: if_icmpne -> 207
    //   193: iconst_1
    //   194: istore #14
    //   196: iload #8
    //   198: istore #10
    //   200: iload #9
    //   202: istore #11
    //   204: goto -> 210
    //   207: iconst_0
    //   208: istore #14
    //   210: iconst_0
    //   211: istore #8
    //   213: aload #23
    //   215: astore #21
    //   217: iload #10
    //   219: istore #12
    //   221: aconst_null
    //   222: astore #26
    //   224: aconst_null
    //   225: astore #22
    //   227: iload #8
    //   229: ifne -> 672
    //   232: aload #21
    //   234: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   237: iload_3
    //   238: aaload
    //   239: astore #19
    //   241: iload #14
    //   243: ifeq -> 252
    //   246: iconst_1
    //   247: istore #9
    //   249: goto -> 255
    //   252: iconst_4
    //   253: istore #9
    //   255: aload #19
    //   257: invokevirtual getMargin : ()I
    //   260: istore #10
    //   262: aload #21
    //   264: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: iload #17
    //   269: aaload
    //   270: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   273: if_acmpne -> 293
    //   276: aload #21
    //   278: getfield mResolvedMatchConstraintDefault : [I
    //   281: iload #17
    //   283: iaload
    //   284: ifne -> 293
    //   287: iconst_1
    //   288: istore #16
    //   290: goto -> 296
    //   293: iconst_0
    //   294: istore #16
    //   296: iload #10
    //   298: istore #15
    //   300: aload #19
    //   302: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   305: ifnull -> 332
    //   308: iload #10
    //   310: istore #15
    //   312: aload #21
    //   314: aload #23
    //   316: if_acmpeq -> 332
    //   319: iload #10
    //   321: aload #19
    //   323: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   326: invokevirtual getMargin : ()I
    //   329: iadd
    //   330: istore #15
    //   332: iload #14
    //   334: ifeq -> 358
    //   337: aload #21
    //   339: aload #23
    //   341: if_acmpeq -> 358
    //   344: aload #21
    //   346: aload #18
    //   348: if_acmpeq -> 358
    //   351: bipush #8
    //   353: istore #9
    //   355: goto -> 358
    //   358: aload #19
    //   360: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   363: ifnull -> 492
    //   366: aload #21
    //   368: aload #18
    //   370: if_acmpne -> 397
    //   373: aload_1
    //   374: aload #19
    //   376: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   379: aload #19
    //   381: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   384: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   387: iload #15
    //   389: bipush #6
    //   391: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   394: goto -> 418
    //   397: aload_1
    //   398: aload #19
    //   400: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   403: aload #19
    //   405: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   408: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   411: iload #15
    //   413: bipush #8
    //   415: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   418: iload #9
    //   420: istore #10
    //   422: iload #16
    //   424: ifeq -> 439
    //   427: iload #9
    //   429: istore #10
    //   431: iload #14
    //   433: ifne -> 439
    //   436: iconst_5
    //   437: istore #10
    //   439: aload #21
    //   441: aload #18
    //   443: if_acmpne -> 467
    //   446: iload #14
    //   448: ifeq -> 467
    //   451: aload #21
    //   453: iload #17
    //   455: invokevirtual isInBarrier : (I)Z
    //   458: ifeq -> 467
    //   461: iconst_5
    //   462: istore #10
    //   464: goto -> 467
    //   467: aload_1
    //   468: aload #19
    //   470: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   473: aload #19
    //   475: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   478: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   481: iload #15
    //   483: iload #10
    //   485: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   488: pop
    //   489: goto -> 492
    //   492: iload #13
    //   494: ifeq -> 578
    //   497: aload #21
    //   499: invokevirtual getVisibility : ()I
    //   502: bipush #8
    //   504: if_icmpeq -> 552
    //   507: aload #21
    //   509: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   512: iload #17
    //   514: aaload
    //   515: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   518: if_acmpne -> 552
    //   521: aload_1
    //   522: aload #21
    //   524: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   527: iload_3
    //   528: iconst_1
    //   529: iadd
    //   530: aaload
    //   531: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   534: aload #21
    //   536: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   539: iload_3
    //   540: aaload
    //   541: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   544: iconst_0
    //   545: iconst_5
    //   546: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   549: goto -> 552
    //   552: aload_1
    //   553: aload #21
    //   555: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   558: iload_3
    //   559: aaload
    //   560: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   563: aload_0
    //   564: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   567: iload_3
    //   568: aaload
    //   569: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   572: iconst_0
    //   573: bipush #8
    //   575: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   578: aload #21
    //   580: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   583: iload_3
    //   584: iconst_1
    //   585: iadd
    //   586: aaload
    //   587: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   590: astore #24
    //   592: aload #22
    //   594: astore #19
    //   596: aload #24
    //   598: ifnull -> 654
    //   601: aload #24
    //   603: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   606: astore #24
    //   608: aload #22
    //   610: astore #19
    //   612: aload #24
    //   614: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   617: iload_3
    //   618: aaload
    //   619: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   622: ifnull -> 654
    //   625: aload #24
    //   627: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   630: iload_3
    //   631: aaload
    //   632: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   635: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   638: aload #21
    //   640: if_acmpeq -> 650
    //   643: aload #22
    //   645: astore #19
    //   647: goto -> 654
    //   650: aload #24
    //   652: astore #19
    //   654: aload #19
    //   656: ifnull -> 666
    //   659: aload #19
    //   661: astore #21
    //   663: goto -> 669
    //   666: iconst_1
    //   667: istore #8
    //   669: goto -> 221
    //   672: aload #25
    //   674: ifnull -> 870
    //   677: aload #27
    //   679: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   682: astore #19
    //   684: iload_3
    //   685: iconst_1
    //   686: iadd
    //   687: istore #9
    //   689: aload #19
    //   691: iload #9
    //   693: aaload
    //   694: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   697: ifnull -> 870
    //   700: aload #25
    //   702: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   705: iload #9
    //   707: aaload
    //   708: astore #19
    //   710: aload #25
    //   712: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   715: iload #17
    //   717: aaload
    //   718: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   721: if_acmpne -> 741
    //   724: aload #25
    //   726: getfield mResolvedMatchConstraintDefault : [I
    //   729: iload #17
    //   731: iaload
    //   732: ifne -> 741
    //   735: iconst_1
    //   736: istore #8
    //   738: goto -> 744
    //   741: iconst_0
    //   742: istore #8
    //   744: iload #8
    //   746: ifeq -> 794
    //   749: iload #14
    //   751: ifne -> 794
    //   754: aload #19
    //   756: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   759: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   762: aload_0
    //   763: if_acmpne -> 794
    //   766: aload_1
    //   767: aload #19
    //   769: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   772: aload #19
    //   774: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   777: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   780: aload #19
    //   782: invokevirtual getMargin : ()I
    //   785: ineg
    //   786: iconst_5
    //   787: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   790: pop
    //   791: goto -> 836
    //   794: iload #14
    //   796: ifeq -> 836
    //   799: aload #19
    //   801: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   804: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   807: aload_0
    //   808: if_acmpne -> 836
    //   811: aload_1
    //   812: aload #19
    //   814: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   817: aload #19
    //   819: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   822: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   825: aload #19
    //   827: invokevirtual getMargin : ()I
    //   830: ineg
    //   831: iconst_4
    //   832: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   835: pop
    //   836: aload_1
    //   837: aload #19
    //   839: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   842: aload #27
    //   844: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   847: iload #9
    //   849: aaload
    //   850: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   853: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   856: aload #19
    //   858: invokevirtual getMargin : ()I
    //   861: ineg
    //   862: bipush #6
    //   864: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   867: goto -> 870
    //   870: iload #13
    //   872: ifeq -> 920
    //   875: aload_0
    //   876: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   879: astore_0
    //   880: iload_3
    //   881: iconst_1
    //   882: iadd
    //   883: istore #8
    //   885: aload_1
    //   886: aload_0
    //   887: iload #8
    //   889: aaload
    //   890: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   893: aload #27
    //   895: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   898: iload #8
    //   900: aaload
    //   901: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   904: aload #27
    //   906: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   909: iload #8
    //   911: aaload
    //   912: invokevirtual getMargin : ()I
    //   915: bipush #8
    //   917: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   920: aload #4
    //   922: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   925: astore_0
    //   926: aload_0
    //   927: ifnull -> 1223
    //   930: aload_0
    //   931: invokevirtual size : ()I
    //   934: istore #8
    //   936: iload #8
    //   938: iconst_1
    //   939: if_icmple -> 1223
    //   942: aload #4
    //   944: getfield mHasUndefinedWeights : Z
    //   947: ifeq -> 969
    //   950: aload #4
    //   952: getfield mHasComplexMatchWeights : Z
    //   955: ifne -> 969
    //   958: aload #4
    //   960: getfield mWidgetsMatchCount : I
    //   963: i2f
    //   964: fstore #6
    //   966: goto -> 973
    //   969: fload #5
    //   971: fstore #6
    //   973: fconst_0
    //   974: fstore #7
    //   976: aconst_null
    //   977: astore #19
    //   979: iconst_0
    //   980: istore #9
    //   982: iload #9
    //   984: iload #8
    //   986: if_icmpge -> 1223
    //   989: aload_0
    //   990: iload #9
    //   992: invokevirtual get : (I)Ljava/lang/Object;
    //   995: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   998: astore #21
    //   1000: aload #21
    //   1002: getfield mWeight : [F
    //   1005: iload #17
    //   1007: faload
    //   1008: fstore #5
    //   1010: fload #5
    //   1012: fconst_0
    //   1013: fcmpg
    //   1014: ifge -> 1063
    //   1017: aload #4
    //   1019: getfield mHasComplexMatchWeights : Z
    //   1022: ifeq -> 1057
    //   1025: aload_1
    //   1026: aload #21
    //   1028: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1031: iload_3
    //   1032: iconst_1
    //   1033: iadd
    //   1034: aaload
    //   1035: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1038: aload #21
    //   1040: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1043: iload_3
    //   1044: aaload
    //   1045: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1048: iconst_0
    //   1049: iconst_4
    //   1050: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1053: pop
    //   1054: goto -> 1100
    //   1057: fconst_1
    //   1058: fstore #5
    //   1060: goto -> 1063
    //   1063: fload #5
    //   1065: fconst_0
    //   1066: fcmpl
    //   1067: ifne -> 1107
    //   1070: aload_1
    //   1071: aload #21
    //   1073: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1076: iload_3
    //   1077: iconst_1
    //   1078: iadd
    //   1079: aaload
    //   1080: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1083: aload #21
    //   1085: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1088: iload_3
    //   1089: aaload
    //   1090: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1093: iconst_0
    //   1094: bipush #8
    //   1096: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1099: pop
    //   1100: fload #7
    //   1102: fstore #5
    //   1104: goto -> 1210
    //   1107: aload #19
    //   1109: ifnull -> 1206
    //   1112: aload #19
    //   1114: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1117: iload_3
    //   1118: aaload
    //   1119: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1122: astore #22
    //   1124: aload #19
    //   1126: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1129: astore #19
    //   1131: iload_3
    //   1132: iconst_1
    //   1133: iadd
    //   1134: istore #10
    //   1136: aload #19
    //   1138: iload #10
    //   1140: aaload
    //   1141: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1144: astore #19
    //   1146: aload #21
    //   1148: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1151: iload_3
    //   1152: aaload
    //   1153: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1156: astore #24
    //   1158: aload #21
    //   1160: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1163: iload #10
    //   1165: aaload
    //   1166: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1169: astore #28
    //   1171: aload_1
    //   1172: invokevirtual createRow : ()Landroidx/constraintlayout/core/ArrayRow;
    //   1175: astore #29
    //   1177: aload #29
    //   1179: fload #7
    //   1181: fload #6
    //   1183: fload #5
    //   1185: aload #22
    //   1187: aload #19
    //   1189: aload #24
    //   1191: aload #28
    //   1193: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;)Landroidx/constraintlayout/core/ArrayRow;
    //   1196: pop
    //   1197: aload_1
    //   1198: aload #29
    //   1200: invokevirtual addConstraint : (Landroidx/constraintlayout/core/ArrayRow;)V
    //   1203: goto -> 1206
    //   1206: aload #21
    //   1208: astore #19
    //   1210: iload #9
    //   1212: iconst_1
    //   1213: iadd
    //   1214: istore #9
    //   1216: fload #5
    //   1218: fstore #7
    //   1220: goto -> 982
    //   1223: aload #18
    //   1225: ifnull -> 1403
    //   1228: aload #18
    //   1230: aload #25
    //   1232: if_acmpeq -> 1240
    //   1235: iload #14
    //   1237: ifeq -> 1403
    //   1240: aload #23
    //   1242: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1245: iload_3
    //   1246: aaload
    //   1247: astore_0
    //   1248: aload #27
    //   1250: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1253: astore #4
    //   1255: iload_3
    //   1256: iconst_1
    //   1257: iadd
    //   1258: istore_2
    //   1259: aload #4
    //   1261: iload_2
    //   1262: aaload
    //   1263: astore #19
    //   1265: aload_0
    //   1266: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1269: ifnull -> 1283
    //   1272: aload_0
    //   1273: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1276: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1279: astore_0
    //   1280: goto -> 1285
    //   1283: aconst_null
    //   1284: astore_0
    //   1285: aload #19
    //   1287: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1290: ifnull -> 1306
    //   1293: aload #19
    //   1295: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1298: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1301: astore #4
    //   1303: goto -> 1309
    //   1306: aconst_null
    //   1307: astore #4
    //   1309: aload #18
    //   1311: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1314: iload_3
    //   1315: aaload
    //   1316: astore #21
    //   1318: aload #25
    //   1320: ifnull -> 1332
    //   1323: aload #25
    //   1325: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1328: iload_2
    //   1329: aaload
    //   1330: astore #19
    //   1332: aload_0
    //   1333: ifnull -> 2442
    //   1336: aload #4
    //   1338: ifnull -> 2442
    //   1341: iload #17
    //   1343: ifne -> 1356
    //   1346: aload #20
    //   1348: getfield mHorizontalBiasPercent : F
    //   1351: fstore #5
    //   1353: goto -> 1363
    //   1356: aload #20
    //   1358: getfield mVerticalBiasPercent : F
    //   1361: fstore #5
    //   1363: aload #21
    //   1365: invokevirtual getMargin : ()I
    //   1368: istore_2
    //   1369: aload #19
    //   1371: invokevirtual getMargin : ()I
    //   1374: istore #8
    //   1376: aload_1
    //   1377: aload #21
    //   1379: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1382: aload_0
    //   1383: iload_2
    //   1384: fload #5
    //   1386: aload #4
    //   1388: aload #19
    //   1390: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1393: iload #8
    //   1395: bipush #7
    //   1397: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1400: goto -> 2442
    //   1403: iload #12
    //   1405: ifeq -> 1867
    //   1408: aload #18
    //   1410: ifnull -> 1867
    //   1413: aload #4
    //   1415: getfield mWidgetsMatchCount : I
    //   1418: ifle -> 1440
    //   1421: aload #4
    //   1423: getfield mWidgetsCount : I
    //   1426: aload #4
    //   1428: getfield mWidgetsMatchCount : I
    //   1431: if_icmpne -> 1440
    //   1434: iconst_1
    //   1435: istore #8
    //   1437: goto -> 1443
    //   1440: iconst_0
    //   1441: istore #8
    //   1443: aload #18
    //   1445: astore #19
    //   1447: aload #19
    //   1449: astore #20
    //   1451: aload #20
    //   1453: ifnull -> 2442
    //   1456: aload #20
    //   1458: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1461: iload #17
    //   1463: aaload
    //   1464: astore_0
    //   1465: aload_0
    //   1466: ifnull -> 1489
    //   1469: aload_0
    //   1470: invokevirtual getVisibility : ()I
    //   1473: bipush #8
    //   1475: if_icmpne -> 1489
    //   1478: aload_0
    //   1479: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1482: iload #17
    //   1484: aaload
    //   1485: astore_0
    //   1486: goto -> 1465
    //   1489: aload_0
    //   1490: ifnonnull -> 1506
    //   1493: aload #20
    //   1495: aload #25
    //   1497: if_acmpne -> 1503
    //   1500: goto -> 1506
    //   1503: goto -> 1840
    //   1506: aload #20
    //   1508: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1511: iload_3
    //   1512: aaload
    //   1513: astore #21
    //   1515: aload #21
    //   1517: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1520: astore #24
    //   1522: aload #21
    //   1524: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1527: ifnull -> 1543
    //   1530: aload #21
    //   1532: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1535: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1538: astore #4
    //   1540: goto -> 1546
    //   1543: aconst_null
    //   1544: astore #4
    //   1546: aload #19
    //   1548: aload #20
    //   1550: if_acmpeq -> 1570
    //   1553: aload #19
    //   1555: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1558: iload_3
    //   1559: iconst_1
    //   1560: iadd
    //   1561: aaload
    //   1562: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1565: astore #4
    //   1567: goto -> 1611
    //   1570: aload #20
    //   1572: aload #18
    //   1574: if_acmpne -> 1611
    //   1577: aload #23
    //   1579: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1582: iload_3
    //   1583: aaload
    //   1584: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1587: ifnull -> 1608
    //   1590: aload #23
    //   1592: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1595: iload_3
    //   1596: aaload
    //   1597: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1600: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1603: astore #4
    //   1605: goto -> 1611
    //   1608: aconst_null
    //   1609: astore #4
    //   1611: aload #21
    //   1613: invokevirtual getMargin : ()I
    //   1616: istore #13
    //   1618: aload #20
    //   1620: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1623: astore #21
    //   1625: iload_3
    //   1626: iconst_1
    //   1627: iadd
    //   1628: istore #10
    //   1630: aload #21
    //   1632: iload #10
    //   1634: aaload
    //   1635: invokevirtual getMargin : ()I
    //   1638: istore #9
    //   1640: aload_0
    //   1641: ifnull -> 1662
    //   1644: aload_0
    //   1645: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1648: iload_3
    //   1649: aaload
    //   1650: astore #22
    //   1652: aload #22
    //   1654: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1657: astore #21
    //   1659: goto -> 1693
    //   1662: aload #27
    //   1664: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1667: iload #10
    //   1669: aaload
    //   1670: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1673: astore #22
    //   1675: aload #22
    //   1677: ifnull -> 1690
    //   1680: aload #22
    //   1682: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1685: astore #21
    //   1687: goto -> 1659
    //   1690: aconst_null
    //   1691: astore #21
    //   1693: aload #20
    //   1695: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1698: iload #10
    //   1700: aaload
    //   1701: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1704: astore #28
    //   1706: iload #9
    //   1708: istore_2
    //   1709: aload #22
    //   1711: ifnull -> 1723
    //   1714: iload #9
    //   1716: aload #22
    //   1718: invokevirtual getMargin : ()I
    //   1721: iadd
    //   1722: istore_2
    //   1723: iload #13
    //   1725: aload #19
    //   1727: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1730: iload #10
    //   1732: aaload
    //   1733: invokevirtual getMargin : ()I
    //   1736: iadd
    //   1737: istore #9
    //   1739: aload #24
    //   1741: ifnull -> 1837
    //   1744: aload #4
    //   1746: ifnull -> 1837
    //   1749: aload #21
    //   1751: ifnull -> 1837
    //   1754: aload #28
    //   1756: ifnull -> 1837
    //   1759: aload #20
    //   1761: aload #18
    //   1763: if_acmpne -> 1778
    //   1766: aload #18
    //   1768: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1771: iload_3
    //   1772: aaload
    //   1773: invokevirtual getMargin : ()I
    //   1776: istore #9
    //   1778: aload #20
    //   1780: aload #25
    //   1782: if_acmpne -> 1800
    //   1785: aload #25
    //   1787: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1790: iload #10
    //   1792: aaload
    //   1793: invokevirtual getMargin : ()I
    //   1796: istore_2
    //   1797: goto -> 1800
    //   1800: iload #8
    //   1802: ifeq -> 1812
    //   1805: bipush #8
    //   1807: istore #10
    //   1809: goto -> 1815
    //   1812: iconst_5
    //   1813: istore #10
    //   1815: aload_1
    //   1816: aload #24
    //   1818: aload #4
    //   1820: iload #9
    //   1822: ldc 0.5
    //   1824: aload #21
    //   1826: aload #28
    //   1828: iload_2
    //   1829: iload #10
    //   1831: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1834: goto -> 1840
    //   1837: goto -> 1503
    //   1840: aload #20
    //   1842: invokevirtual getVisibility : ()I
    //   1845: bipush #8
    //   1847: if_icmpeq -> 1853
    //   1850: goto -> 1857
    //   1853: aload #19
    //   1855: astore #20
    //   1857: aload #20
    //   1859: astore #19
    //   1861: aload_0
    //   1862: astore #20
    //   1864: goto -> 1451
    //   1867: bipush #8
    //   1869: istore #8
    //   1871: iload #11
    //   1873: ifeq -> 2442
    //   1876: aload #18
    //   1878: ifnull -> 2442
    //   1881: aload #4
    //   1883: getfield mWidgetsMatchCount : I
    //   1886: ifle -> 1908
    //   1889: aload #4
    //   1891: getfield mWidgetsCount : I
    //   1894: aload #4
    //   1896: getfield mWidgetsMatchCount : I
    //   1899: if_icmpne -> 1908
    //   1902: iconst_1
    //   1903: istore #9
    //   1905: goto -> 1911
    //   1908: iconst_0
    //   1909: istore #9
    //   1911: aload #18
    //   1913: astore #4
    //   1915: aload #4
    //   1917: astore #19
    //   1919: iload_2
    //   1920: istore #10
    //   1922: aload #19
    //   1924: ifnull -> 2282
    //   1927: aload #19
    //   1929: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1932: iload #10
    //   1934: aaload
    //   1935: astore_0
    //   1936: aload_0
    //   1937: ifnull -> 1960
    //   1940: aload_0
    //   1941: invokevirtual getVisibility : ()I
    //   1944: iload #8
    //   1946: if_icmpne -> 1960
    //   1949: aload_0
    //   1950: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1953: iload #10
    //   1955: aaload
    //   1956: astore_0
    //   1957: goto -> 1936
    //   1960: aload #19
    //   1962: aload #18
    //   1964: if_acmpeq -> 2259
    //   1967: aload #19
    //   1969: aload #25
    //   1971: if_acmpeq -> 2259
    //   1974: aload_0
    //   1975: ifnull -> 2259
    //   1978: aload_0
    //   1979: aload #25
    //   1981: if_acmpne -> 1989
    //   1984: aconst_null
    //   1985: astore_0
    //   1986: goto -> 1989
    //   1989: aload #19
    //   1991: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1994: iload_3
    //   1995: aaload
    //   1996: astore #20
    //   1998: aload #20
    //   2000: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2003: astore #28
    //   2005: aload #20
    //   2007: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2010: ifnull -> 2023
    //   2013: aload #20
    //   2015: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2018: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2021: astore #21
    //   2023: aload #4
    //   2025: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2028: astore #21
    //   2030: iload_3
    //   2031: iconst_1
    //   2032: iadd
    //   2033: istore #14
    //   2035: aload #21
    //   2037: iload #14
    //   2039: aaload
    //   2040: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2043: astore #29
    //   2045: aload #20
    //   2047: invokevirtual getMargin : ()I
    //   2050: istore #13
    //   2052: aload #19
    //   2054: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2057: iload #14
    //   2059: aaload
    //   2060: invokevirtual getMargin : ()I
    //   2063: istore #10
    //   2065: aload_0
    //   2066: ifnull -> 2115
    //   2069: aload_0
    //   2070: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2073: iload_3
    //   2074: aaload
    //   2075: astore #21
    //   2077: aload #21
    //   2079: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2082: astore #22
    //   2084: aload #21
    //   2086: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2089: ifnull -> 2105
    //   2092: aload #21
    //   2094: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2097: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2100: astore #20
    //   2102: goto -> 2108
    //   2105: aconst_null
    //   2106: astore #20
    //   2108: aload #20
    //   2110: astore #24
    //   2112: goto -> 2159
    //   2115: aload #25
    //   2117: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2120: iload_3
    //   2121: aaload
    //   2122: astore #21
    //   2124: aload #21
    //   2126: ifnull -> 2139
    //   2129: aload #21
    //   2131: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2134: astore #20
    //   2136: goto -> 2142
    //   2139: aconst_null
    //   2140: astore #20
    //   2142: aload #19
    //   2144: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2147: iload #14
    //   2149: aaload
    //   2150: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2153: astore #24
    //   2155: aload #20
    //   2157: astore #22
    //   2159: iload #10
    //   2161: istore #8
    //   2163: aload #21
    //   2165: ifnull -> 2178
    //   2168: iload #10
    //   2170: aload #21
    //   2172: invokevirtual getMargin : ()I
    //   2175: iadd
    //   2176: istore #8
    //   2178: aload #4
    //   2180: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2183: iload #14
    //   2185: aaload
    //   2186: invokevirtual getMargin : ()I
    //   2189: istore #14
    //   2191: iload #9
    //   2193: ifeq -> 2203
    //   2196: bipush #8
    //   2198: istore #10
    //   2200: goto -> 2206
    //   2203: iconst_4
    //   2204: istore #10
    //   2206: aload #28
    //   2208: ifnull -> 2252
    //   2211: aload #29
    //   2213: ifnull -> 2252
    //   2216: aload #22
    //   2218: ifnull -> 2252
    //   2221: aload #24
    //   2223: ifnull -> 2252
    //   2226: aload_1
    //   2227: aload #28
    //   2229: aload #29
    //   2231: iload #14
    //   2233: iload #13
    //   2235: iadd
    //   2236: ldc 0.5
    //   2238: aload #22
    //   2240: aload #24
    //   2242: iload #8
    //   2244: iload #10
    //   2246: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2249: goto -> 2252
    //   2252: bipush #8
    //   2254: istore #8
    //   2256: goto -> 2259
    //   2259: aload #19
    //   2261: invokevirtual getVisibility : ()I
    //   2264: iload #8
    //   2266: if_icmpeq -> 2276
    //   2269: aload #19
    //   2271: astore #4
    //   2273: goto -> 2276
    //   2276: aload_0
    //   2277: astore #19
    //   2279: goto -> 1919
    //   2282: aload #18
    //   2284: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2287: iload_3
    //   2288: aaload
    //   2289: astore_0
    //   2290: aload #23
    //   2292: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2295: iload_3
    //   2296: aaload
    //   2297: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2300: astore #4
    //   2302: aload #25
    //   2304: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2307: astore #19
    //   2309: iload_3
    //   2310: iconst_1
    //   2311: iadd
    //   2312: istore_2
    //   2313: aload #19
    //   2315: iload_2
    //   2316: aaload
    //   2317: astore #19
    //   2319: aload #27
    //   2321: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2324: iload_2
    //   2325: aaload
    //   2326: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2329: astore #20
    //   2331: aload #4
    //   2333: ifnull -> 2408
    //   2336: aload #18
    //   2338: aload #25
    //   2340: if_acmpeq -> 2365
    //   2343: aload_1
    //   2344: aload_0
    //   2345: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2348: aload #4
    //   2350: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2353: aload_0
    //   2354: invokevirtual getMargin : ()I
    //   2357: iconst_5
    //   2358: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2361: pop
    //   2362: goto -> 2408
    //   2365: aload #20
    //   2367: ifnull -> 2408
    //   2370: aload_1
    //   2371: aload_0
    //   2372: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2375: aload #4
    //   2377: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2380: aload_0
    //   2381: invokevirtual getMargin : ()I
    //   2384: ldc 0.5
    //   2386: aload #19
    //   2388: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2391: aload #20
    //   2393: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2396: aload #19
    //   2398: invokevirtual getMargin : ()I
    //   2401: iconst_5
    //   2402: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2405: goto -> 2408
    //   2408: aload #20
    //   2410: ifnull -> 2442
    //   2413: aload #18
    //   2415: aload #25
    //   2417: if_acmpeq -> 2442
    //   2420: aload_1
    //   2421: aload #19
    //   2423: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2426: aload #20
    //   2428: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2431: aload #19
    //   2433: invokevirtual getMargin : ()I
    //   2436: ineg
    //   2437: iconst_5
    //   2438: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2441: pop
    //   2442: iload #12
    //   2444: ifne -> 2452
    //   2447: iload #11
    //   2449: ifeq -> 2659
    //   2452: aload #18
    //   2454: ifnull -> 2659
    //   2457: aload #18
    //   2459: aload #25
    //   2461: if_acmpeq -> 2659
    //   2464: aload #18
    //   2466: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2469: iload_3
    //   2470: aaload
    //   2471: astore #20
    //   2473: aload #25
    //   2475: astore #4
    //   2477: aload #25
    //   2479: ifnonnull -> 2486
    //   2482: aload #18
    //   2484: astore #4
    //   2486: aload #4
    //   2488: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2491: astore_0
    //   2492: iload_3
    //   2493: iconst_1
    //   2494: iadd
    //   2495: istore_2
    //   2496: aload_0
    //   2497: iload_2
    //   2498: aaload
    //   2499: astore #21
    //   2501: aload #20
    //   2503: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2506: ifnull -> 2522
    //   2509: aload #20
    //   2511: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2514: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2517: astore #19
    //   2519: goto -> 2525
    //   2522: aconst_null
    //   2523: astore #19
    //   2525: aload #21
    //   2527: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2530: ifnull -> 2545
    //   2533: aload #21
    //   2535: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2538: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2541: astore_0
    //   2542: goto -> 2547
    //   2545: aconst_null
    //   2546: astore_0
    //   2547: aload #27
    //   2549: aload #4
    //   2551: if_acmpeq -> 2586
    //   2554: aload #27
    //   2556: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2559: iload_2
    //   2560: aaload
    //   2561: astore #22
    //   2563: aload #26
    //   2565: astore_0
    //   2566: aload #22
    //   2568: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2571: ifnull -> 2583
    //   2574: aload #22
    //   2576: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2579: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2582: astore_0
    //   2583: goto -> 2586
    //   2586: aload #18
    //   2588: aload #4
    //   2590: if_acmpne -> 2611
    //   2593: aload #18
    //   2595: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2598: iload_3
    //   2599: aaload
    //   2600: astore #20
    //   2602: aload #18
    //   2604: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2607: iload_2
    //   2608: aaload
    //   2609: astore #21
    //   2611: aload #19
    //   2613: ifnull -> 2659
    //   2616: aload_0
    //   2617: ifnull -> 2659
    //   2620: aload #20
    //   2622: invokevirtual getMargin : ()I
    //   2625: istore_3
    //   2626: aload #4
    //   2628: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2631: iload_2
    //   2632: aaload
    //   2633: invokevirtual getMargin : ()I
    //   2636: istore_2
    //   2637: aload_1
    //   2638: aload #20
    //   2640: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2643: aload #19
    //   2645: iload_3
    //   2646: ldc 0.5
    //   2648: aload_0
    //   2649: aload #21
    //   2651: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2654: iload_2
    //   2655: iconst_5
    //   2656: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2659: return
  }
  
  public static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, ArrayList<ConstraintWidget> paramArrayList, int paramInt) {
    int i;
    byte b;
    ChainHead[] arrayOfChainHead;
    int j = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b = 0;
    } else {
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
      b = 2;
    } 
    while (j < i) {
      ChainHead chainHead = arrayOfChainHead[j];
      chainHead.define();
      if (paramArrayList == null || (paramArrayList != null && paramArrayList.contains(chainHead.mFirst)))
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b, chainHead); 
      j++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */