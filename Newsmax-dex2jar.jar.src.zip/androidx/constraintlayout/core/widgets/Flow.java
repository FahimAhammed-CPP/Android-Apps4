package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;
import java.util.HashMap;

public class Flow extends VirtualLayout {
  public static final int HORIZONTAL_ALIGN_CENTER = 2;
  
  public static final int HORIZONTAL_ALIGN_END = 1;
  
  public static final int HORIZONTAL_ALIGN_START = 0;
  
  public static final int VERTICAL_ALIGN_BASELINE = 3;
  
  public static final int VERTICAL_ALIGN_BOTTOM = 1;
  
  public static final int VERTICAL_ALIGN_CENTER = 2;
  
  public static final int VERTICAL_ALIGN_TOP = 0;
  
  public static final int WRAP_ALIGNED = 2;
  
  public static final int WRAP_CHAIN = 1;
  
  public static final int WRAP_CHAIN_NEW = 3;
  
  public static final int WRAP_NONE = 0;
  
  private ConstraintWidget[] mAlignedBiggestElementsInCols = null;
  
  private ConstraintWidget[] mAlignedBiggestElementsInRows = null;
  
  private int[] mAlignedDimensions = null;
  
  private ArrayList<WidgetsList> mChainList = new ArrayList<WidgetsList>();
  
  private ConstraintWidget[] mDisplayedWidgets;
  
  private int mDisplayedWidgetsCount = 0;
  
  private float mFirstHorizontalBias = 0.5F;
  
  private int mFirstHorizontalStyle = -1;
  
  private float mFirstVerticalBias = 0.5F;
  
  private int mFirstVerticalStyle = -1;
  
  private int mHorizontalAlign = 2;
  
  private float mHorizontalBias = 0.5F;
  
  private int mHorizontalGap = 0;
  
  private int mHorizontalStyle = -1;
  
  private float mLastHorizontalBias = 0.5F;
  
  private int mLastHorizontalStyle = -1;
  
  private float mLastVerticalBias = 0.5F;
  
  private int mLastVerticalStyle = -1;
  
  private int mMaxElementsWrap = -1;
  
  private int mOrientation = 0;
  
  private int mVerticalAlign = 2;
  
  private float mVerticalBias = 0.5F;
  
  private int mVerticalGap = 0;
  
  private int mVerticalStyle = -1;
  
  private int mWrapMode = 0;
  
  private void createAlignedConstraints(boolean paramBoolean) {
    if (this.mAlignedDimensions != null && this.mAlignedBiggestElementsInCols != null) {
      ConstraintWidget constraintWidget;
      if (this.mAlignedBiggestElementsInRows == null)
        return; 
      int i;
      for (i = 0; i < this.mDisplayedWidgetsCount; i++)
        this.mDisplayedWidgets[i].resetAnchors(); 
      int[] arrayOfInt = this.mAlignedDimensions;
      int j = arrayOfInt[0];
      int k = arrayOfInt[1];
      arrayOfInt = null;
      float f = this.mHorizontalBias;
      i = 0;
      while (i < j) {
        int m;
        ConstraintWidget constraintWidget1;
        if (paramBoolean) {
          m = j - i - 1;
          f = 1.0F - this.mHorizontalBias;
        } else {
          m = i;
        } 
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[m];
        int[] arrayOfInt1 = arrayOfInt;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            arrayOfInt1 = arrayOfInt;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, this.mLeft, getPaddingLeft());
              constraintWidget2.setHorizontalChainStyle(this.mHorizontalStyle);
              constraintWidget2.setHorizontalBiasPercent(f);
            } 
            if (i == j - 1)
              constraintWidget2.connect(constraintWidget2.mRight, this.mRight, getPaddingRight()); 
            if (i > 0 && arrayOfInt != null) {
              constraintWidget2.connect(constraintWidget2.mLeft, ((ConstraintWidget)arrayOfInt).mRight, this.mHorizontalGap);
              arrayOfInt.connect(((ConstraintWidget)arrayOfInt).mRight, constraintWidget2.mLeft, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      i = 0;
      while (i < k) {
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInRows[i];
        ConstraintWidget constraintWidget1 = constraintWidget;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            constraintWidget1 = constraintWidget;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mTop, this.mTop, getPaddingTop());
              constraintWidget2.setVerticalChainStyle(this.mVerticalStyle);
              constraintWidget2.setVerticalBiasPercent(this.mVerticalBias);
            } 
            if (i == k - 1)
              constraintWidget2.connect(constraintWidget2.mBottom, this.mBottom, getPaddingBottom()); 
            if (i > 0 && constraintWidget != null) {
              constraintWidget2.connect(constraintWidget2.mTop, constraintWidget.mBottom, this.mVerticalGap);
              constraintWidget.connect(constraintWidget.mBottom, constraintWidget2.mTop, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      for (i = 0; i < j; i++) {
        int m;
        for (m = 0; m < k; m++) {
          int n = m * j + i;
          if (this.mOrientation == 1)
            n = i * k + m; 
          ConstraintWidget[] arrayOfConstraintWidget = this.mDisplayedWidgets;
          if (n < arrayOfConstraintWidget.length) {
            ConstraintWidget constraintWidget1 = arrayOfConstraintWidget[n];
            if (constraintWidget1 != null && constraintWidget1.getVisibility() != 8) {
              ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[i];
              ConstraintWidget constraintWidget3 = this.mAlignedBiggestElementsInRows[m];
              if (constraintWidget1 != constraintWidget2) {
                constraintWidget1.connect(constraintWidget1.mLeft, constraintWidget2.mLeft, 0);
                constraintWidget1.connect(constraintWidget1.mRight, constraintWidget2.mRight, 0);
              } 
              if (constraintWidget1 != constraintWidget3) {
                constraintWidget1.connect(constraintWidget1.mTop, constraintWidget3.mTop, 0);
                constraintWidget1.connect(constraintWidget1.mBottom, constraintWidget3.mBottom, 0);
              } 
            } 
          } 
        } 
      } 
    } 
  }
  
  private final int getWidgetHeight(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentHeight * paramInt);
        if (paramInt != paramConstraintWidget.getHeight()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, paramConstraintWidget.getHorizontalDimensionBehaviour(), paramConstraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, paramInt);
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 1)
        return paramConstraintWidget.getHeight(); 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 3)
        return (int)(paramConstraintWidget.getWidth() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getHeight();
  }
  
  private final int getWidgetWidth(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentWidth * paramInt);
        if (paramInt != paramConstraintWidget.getWidth()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, paramInt, paramConstraintWidget.getVerticalDimensionBehaviour(), paramConstraintWidget.getHeight());
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 1)
        return paramConstraintWidget.getWidth(); 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 3)
        return (int)(paramConstraintWidget.getHeight() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getWidth();
  }
  
  private void measureAligned(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 136
    //   4: aload_0
    //   5: getfield mMaxElementsWrap : I
    //   8: istore #6
    //   10: iload #6
    //   12: istore #8
    //   14: iload #6
    //   16: ifgt -> 126
    //   19: iconst_0
    //   20: istore #8
    //   22: iload #8
    //   24: istore #6
    //   26: iload #6
    //   28: istore #7
    //   30: iload #6
    //   32: istore #9
    //   34: iload #8
    //   36: istore #6
    //   38: iload #6
    //   40: istore #8
    //   42: iload #9
    //   44: iload_2
    //   45: if_icmpge -> 126
    //   48: iload #7
    //   50: istore #8
    //   52: iload #9
    //   54: ifle -> 66
    //   57: iload #7
    //   59: aload_0
    //   60: getfield mHorizontalGap : I
    //   63: iadd
    //   64: istore #8
    //   66: aload_1
    //   67: iload #9
    //   69: aaload
    //   70: astore #13
    //   72: aload #13
    //   74: ifnonnull -> 84
    //   77: iload #8
    //   79: istore #7
    //   81: goto -> 117
    //   84: iload #8
    //   86: aload_0
    //   87: aload #13
    //   89: iload #4
    //   91: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   94: iadd
    //   95: istore #7
    //   97: iload #7
    //   99: iload #4
    //   101: if_icmple -> 111
    //   104: iload #6
    //   106: istore #8
    //   108: goto -> 126
    //   111: iload #6
    //   113: iconst_1
    //   114: iadd
    //   115: istore #6
    //   117: iload #9
    //   119: iconst_1
    //   120: iadd
    //   121: istore #9
    //   123: goto -> 38
    //   126: iload #8
    //   128: istore #7
    //   130: iconst_0
    //   131: istore #6
    //   133: goto -> 265
    //   136: aload_0
    //   137: getfield mMaxElementsWrap : I
    //   140: istore #6
    //   142: iload #6
    //   144: istore #8
    //   146: iload #6
    //   148: ifgt -> 258
    //   151: iconst_0
    //   152: istore #8
    //   154: iload #8
    //   156: istore #6
    //   158: iload #6
    //   160: istore #7
    //   162: iload #6
    //   164: istore #9
    //   166: iload #8
    //   168: istore #6
    //   170: iload #6
    //   172: istore #8
    //   174: iload #9
    //   176: iload_2
    //   177: if_icmpge -> 258
    //   180: iload #7
    //   182: istore #8
    //   184: iload #9
    //   186: ifle -> 198
    //   189: iload #7
    //   191: aload_0
    //   192: getfield mVerticalGap : I
    //   195: iadd
    //   196: istore #8
    //   198: aload_1
    //   199: iload #9
    //   201: aaload
    //   202: astore #13
    //   204: aload #13
    //   206: ifnonnull -> 216
    //   209: iload #8
    //   211: istore #7
    //   213: goto -> 249
    //   216: iload #8
    //   218: aload_0
    //   219: aload #13
    //   221: iload #4
    //   223: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   226: iadd
    //   227: istore #7
    //   229: iload #7
    //   231: iload #4
    //   233: if_icmple -> 243
    //   236: iload #6
    //   238: istore #8
    //   240: goto -> 258
    //   243: iload #6
    //   245: iconst_1
    //   246: iadd
    //   247: istore #6
    //   249: iload #9
    //   251: iconst_1
    //   252: iadd
    //   253: istore #9
    //   255: goto -> 170
    //   258: iconst_0
    //   259: istore #7
    //   261: iload #8
    //   263: istore #6
    //   265: aload_0
    //   266: getfield mAlignedDimensions : [I
    //   269: ifnonnull -> 279
    //   272: aload_0
    //   273: iconst_2
    //   274: newarray int
    //   276: putfield mAlignedDimensions : [I
    //   279: iload #6
    //   281: ifne -> 297
    //   284: iload #6
    //   286: istore #11
    //   288: iload #7
    //   290: istore #9
    //   292: iload_3
    //   293: iconst_1
    //   294: if_icmpeq -> 314
    //   297: iload #7
    //   299: ifne -> 328
    //   302: iload_3
    //   303: ifne -> 328
    //   306: iload #7
    //   308: istore #9
    //   310: iload #6
    //   312: istore #11
    //   314: iconst_1
    //   315: istore #12
    //   317: iload #11
    //   319: istore #6
    //   321: iload #9
    //   323: istore #7
    //   325: goto -> 331
    //   328: iconst_0
    //   329: istore #12
    //   331: iload #12
    //   333: ifne -> 872
    //   336: iload_3
    //   337: ifne -> 356
    //   340: iload_2
    //   341: i2f
    //   342: iload #7
    //   344: i2f
    //   345: fdiv
    //   346: f2d
    //   347: invokestatic ceil : (D)D
    //   350: d2i
    //   351: istore #6
    //   353: goto -> 369
    //   356: iload_2
    //   357: i2f
    //   358: iload #6
    //   360: i2f
    //   361: fdiv
    //   362: f2d
    //   363: invokestatic ceil : (D)D
    //   366: d2i
    //   367: istore #7
    //   369: aload_0
    //   370: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   373: astore #13
    //   375: aload #13
    //   377: ifnull -> 400
    //   380: aload #13
    //   382: arraylength
    //   383: iload #7
    //   385: if_icmpge -> 391
    //   388: goto -> 400
    //   391: aload #13
    //   393: aconst_null
    //   394: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   397: goto -> 409
    //   400: aload_0
    //   401: iload #7
    //   403: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   406: putfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   409: aload_0
    //   410: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   413: astore #13
    //   415: aload #13
    //   417: ifnull -> 440
    //   420: aload #13
    //   422: arraylength
    //   423: iload #6
    //   425: if_icmpge -> 431
    //   428: goto -> 440
    //   431: aload #13
    //   433: aconst_null
    //   434: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   437: goto -> 449
    //   440: aload_0
    //   441: iload #6
    //   443: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   446: putfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   449: iconst_0
    //   450: istore #8
    //   452: iload #8
    //   454: iload #7
    //   456: if_icmpge -> 628
    //   459: iconst_0
    //   460: istore #9
    //   462: iload #9
    //   464: iload #6
    //   466: if_icmpge -> 619
    //   469: iload #9
    //   471: iload #7
    //   473: imul
    //   474: iload #8
    //   476: iadd
    //   477: istore #10
    //   479: iload_3
    //   480: iconst_1
    //   481: if_icmpne -> 494
    //   484: iload #8
    //   486: iload #6
    //   488: imul
    //   489: iload #9
    //   491: iadd
    //   492: istore #10
    //   494: iload #10
    //   496: aload_1
    //   497: arraylength
    //   498: if_icmplt -> 504
    //   501: goto -> 610
    //   504: aload_1
    //   505: iload #10
    //   507: aaload
    //   508: astore #13
    //   510: aload #13
    //   512: ifnonnull -> 518
    //   515: goto -> 610
    //   518: aload_0
    //   519: aload #13
    //   521: iload #4
    //   523: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   526: istore #10
    //   528: aload_0
    //   529: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   532: astore #14
    //   534: aload #14
    //   536: iload #8
    //   538: aaload
    //   539: ifnull -> 555
    //   542: aload #14
    //   544: iload #8
    //   546: aaload
    //   547: invokevirtual getWidth : ()I
    //   550: iload #10
    //   552: if_icmpge -> 564
    //   555: aload_0
    //   556: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   559: iload #8
    //   561: aload #13
    //   563: aastore
    //   564: aload_0
    //   565: aload #13
    //   567: iload #4
    //   569: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   572: istore #10
    //   574: aload_0
    //   575: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   578: astore #14
    //   580: aload #14
    //   582: iload #9
    //   584: aaload
    //   585: ifnull -> 601
    //   588: aload #14
    //   590: iload #9
    //   592: aaload
    //   593: invokevirtual getHeight : ()I
    //   596: iload #10
    //   598: if_icmpge -> 610
    //   601: aload_0
    //   602: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   605: iload #9
    //   607: aload #13
    //   609: aastore
    //   610: iload #9
    //   612: iconst_1
    //   613: iadd
    //   614: istore #9
    //   616: goto -> 462
    //   619: iload #8
    //   621: iconst_1
    //   622: iadd
    //   623: istore #8
    //   625: goto -> 452
    //   628: iconst_0
    //   629: istore #9
    //   631: iload #9
    //   633: istore #8
    //   635: iload #9
    //   637: iload #7
    //   639: if_icmpge -> 704
    //   642: aload_0
    //   643: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   646: iload #9
    //   648: aaload
    //   649: astore #13
    //   651: iload #8
    //   653: istore #10
    //   655: aload #13
    //   657: ifnull -> 691
    //   660: iload #8
    //   662: istore #10
    //   664: iload #9
    //   666: ifle -> 678
    //   669: iload #8
    //   671: aload_0
    //   672: getfield mHorizontalGap : I
    //   675: iadd
    //   676: istore #10
    //   678: iload #10
    //   680: aload_0
    //   681: aload #13
    //   683: iload #4
    //   685: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   688: iadd
    //   689: istore #10
    //   691: iload #9
    //   693: iconst_1
    //   694: iadd
    //   695: istore #9
    //   697: iload #10
    //   699: istore #8
    //   701: goto -> 635
    //   704: iconst_0
    //   705: istore #9
    //   707: iload #9
    //   709: istore #10
    //   711: iload #9
    //   713: iload #6
    //   715: if_icmpge -> 780
    //   718: aload_0
    //   719: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   722: iload #9
    //   724: aaload
    //   725: astore #13
    //   727: iload #10
    //   729: istore #11
    //   731: aload #13
    //   733: ifnull -> 767
    //   736: iload #10
    //   738: istore #11
    //   740: iload #9
    //   742: ifle -> 754
    //   745: iload #10
    //   747: aload_0
    //   748: getfield mVerticalGap : I
    //   751: iadd
    //   752: istore #11
    //   754: iload #11
    //   756: aload_0
    //   757: aload #13
    //   759: iload #4
    //   761: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   764: iadd
    //   765: istore #11
    //   767: iload #9
    //   769: iconst_1
    //   770: iadd
    //   771: istore #9
    //   773: iload #11
    //   775: istore #10
    //   777: goto -> 711
    //   780: aload #5
    //   782: iconst_0
    //   783: iload #8
    //   785: iastore
    //   786: aload #5
    //   788: iconst_1
    //   789: iload #10
    //   791: iastore
    //   792: iload_3
    //   793: ifne -> 834
    //   796: iload #6
    //   798: istore #11
    //   800: iload #7
    //   802: istore #9
    //   804: iload #8
    //   806: iload #4
    //   808: if_icmple -> 314
    //   811: iload #6
    //   813: istore #11
    //   815: iload #7
    //   817: istore #9
    //   819: iload #7
    //   821: iconst_1
    //   822: if_icmple -> 314
    //   825: iload #7
    //   827: iconst_1
    //   828: isub
    //   829: istore #7
    //   831: goto -> 331
    //   834: iload #6
    //   836: istore #11
    //   838: iload #7
    //   840: istore #9
    //   842: iload #10
    //   844: iload #4
    //   846: if_icmple -> 314
    //   849: iload #6
    //   851: istore #11
    //   853: iload #7
    //   855: istore #9
    //   857: iload #6
    //   859: iconst_1
    //   860: if_icmple -> 314
    //   863: iload #6
    //   865: iconst_1
    //   866: isub
    //   867: istore #6
    //   869: goto -> 331
    //   872: aload_0
    //   873: getfield mAlignedDimensions : [I
    //   876: astore_1
    //   877: aload_1
    //   878: iconst_0
    //   879: iload #7
    //   881: iastore
    //   882: aload_1
    //   883: iconst_1
    //   884: iload #6
    //   886: iastore
    //   887: return
  }
  
  private void measureChainWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    ConstraintWidget constraintWidget;
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      j = 0;
      int i4 = j;
      int i6 = i4;
      int i5 = i4;
      for (i4 = j;; i4 = j) {
        j = i4;
        if (i6 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i6];
          int i8 = getWidgetWidth(constraintWidget, paramInt3);
          j = i4;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            j = i4 + 1; 
          if ((i5 == paramInt3 || this.mHorizontalGap + i5 + i8 > paramInt3) && widgetsList.biggest != null) {
            i4 = 1;
          } else {
            i4 = 0;
          } 
          int i7 = i4;
          if (i4 == 0) {
            i7 = i4;
            if (i6 > 0) {
              int i9 = this.mMaxElementsWrap;
              i7 = i4;
              if (i9 > 0) {
                i7 = i4;
                if (i6 % i9 == 0)
                  i7 = 1; 
              } 
            } 
          } 
          if (i7 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i6);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i6 > 0) {
              i5 += this.mHorizontalGap + i8;
              continue;
            } 
          } 
          i5 = i8;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i6++;
      } 
    } else {
      j = 0;
      int i4 = j;
      int i6 = i4;
      int i5 = i4;
      for (i4 = j;; i4 = j) {
        j = i4;
        if (i6 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i6];
          int i8 = getWidgetHeight(constraintWidget, paramInt3);
          j = i4;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            j = i4 + 1; 
          if ((i5 == paramInt3 || this.mVerticalGap + i5 + i8 > paramInt3) && widgetsList.biggest != null) {
            i4 = 1;
          } else {
            i4 = 0;
          } 
          int i7 = i4;
          if (i4 == 0) {
            i7 = i4;
            if (i6 > 0) {
              int i9 = this.mMaxElementsWrap;
              i7 = i4;
              if (i9 > 0) {
                i7 = i4;
                if (i6 % i9 == 0)
                  i7 = 1; 
              } 
            } 
          } 
          if (i7 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i6);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i6 > 0) {
              i5 += this.mVerticalGap + i8;
              continue;
            } 
          } 
          i5 = i8;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add(constraintWidget);
        i6++;
      } 
    } 
    int i3 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int k = getPaddingLeft();
    int m = getPaddingTop();
    int i1 = getPaddingRight();
    int n = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (j > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i3; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int j = 0;
    int i = j;
    paramInt1 = i;
    int i2;
    for (i2 = i; paramInt1 < i3; i2 = i) {
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i3 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, k, m, i1, i, paramInt3);
        m = Math.max(i2, widgetsList1.getWidth());
        n = j + widgetsList1.getHeight();
        j = n;
        if (paramInt1 > 0)
          j = n + this.mVerticalGap; 
        i2 = 0;
        constraintAnchor4 = constraintAnchor;
        n = i;
        i = m;
        m = i2;
      } else {
        i1 = paramInt1;
        if (i1 < i3 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(i1 + 1)).biggest.mLeft;
          i = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, k, m, i, n, paramInt3);
        k = i2 + widgetsList1.getWidth();
        i2 = Math.max(j, widgetsList1.getHeight());
        j = k;
        if (i1 > 0)
          j = k + this.mHorizontalGap; 
        k = i2;
        i2 = 0;
        i1 = i;
        constraintAnchor1 = constraintAnchor;
        i = j;
        j = k;
        k = i2;
      } 
      paramInt1++;
    } 
    paramArrayOfint[0] = i2;
    paramArrayOfint[1] = j;
  }
  
  private void measureChainWrap_new(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      int i7 = 0;
      int i4 = i7;
      j = i4;
      int i6 = j;
      int i5 = j;
      while (true) {
        j = i4;
        if (i6 < paramInt1) {
          int i9 = i7 + 1;
          ConstraintWidget constraintWidget = paramArrayOfConstraintWidget[i6];
          i7 = getWidgetWidth(constraintWidget, paramInt3);
          j = i4;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            j = i4 + 1; 
          if ((i5 == paramInt3 || this.mHorizontalGap + i5 + i7 > paramInt3) && widgetsList.biggest != null) {
            i4 = 1;
          } else {
            i4 = 0;
          } 
          int i8 = i4;
          if (i4 == 0) {
            i8 = i4;
            if (i6 > 0) {
              int i10 = this.mMaxElementsWrap;
              i8 = i4;
              if (i10 > 0) {
                i8 = i4;
                if (i9 > i10)
                  i8 = 1; 
              } 
            } 
          } 
          if (i8 != 0) {
            widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList.setStartIndex(i6);
            this.mChainList.add(widgetsList);
            i4 = i9;
            i5 = i7;
          } else {
            if (i6 > 0) {
              i5 += this.mHorizontalGap + i7;
            } else {
              i5 = i7;
            } 
            i4 = 0;
          } 
          widgetsList.add(constraintWidget);
          i6++;
          i7 = i4;
          i4 = j;
          continue;
        } 
        break;
      } 
    } else {
      int i6 = 0;
      int i4 = i6;
      int i5 = i4;
      while (true) {
        j = i4;
        if (i5 < paramInt1) {
          WidgetsList widgetsList1;
          ConstraintWidget constraintWidget = paramArrayOfConstraintWidget[i5];
          int i8 = getWidgetHeight(constraintWidget, paramInt3);
          j = i4;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            j = i4 + 1; 
          if ((i6 == paramInt3 || this.mVerticalGap + i6 + i8 > paramInt3) && widgetsList.biggest != null) {
            i4 = 1;
          } else {
            i4 = 0;
          } 
          int i7 = i4;
          if (i4 == 0) {
            i7 = i4;
            if (i5 > 0) {
              int i9 = this.mMaxElementsWrap;
              i7 = i4;
              if (i9 > 0) {
                i7 = i4;
                if (i9 < 0)
                  i7 = 1; 
              } 
            } 
          } 
          if (i7 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i5);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i5 > 0) {
              i4 = i6 + this.mVerticalGap + i8;
              continue;
            } 
          } 
          i4 = i8;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i5++;
        i6 = i4;
        i4 = j;
      } 
    } 
    int i3 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int k = getPaddingLeft();
    int m = getPaddingTop();
    int i1 = getPaddingRight();
    int n = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (j > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i3; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int j = 0;
    int i = j;
    paramInt1 = i;
    int i2;
    for (i2 = i; paramInt1 < i3; i2 = i) {
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i3 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, k, m, i1, i, paramInt3);
        m = Math.max(i2, widgetsList1.getWidth());
        n = j + widgetsList1.getHeight();
        j = n;
        if (paramInt1 > 0)
          j = n + this.mVerticalGap; 
        i2 = 0;
        constraintAnchor4 = constraintAnchor;
        n = i;
        i = m;
        m = i2;
      } else {
        i1 = paramInt1;
        if (i1 < i3 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(i1 + 1)).biggest.mLeft;
          i = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, k, m, i, n, paramInt3);
        k = i2 + widgetsList1.getWidth();
        i2 = Math.max(j, widgetsList1.getHeight());
        j = k;
        if (i1 > 0)
          j = k + this.mHorizontalGap; 
        k = i2;
        i2 = 0;
        i1 = i;
        constraintAnchor1 = constraintAnchor;
        i = j;
        j = k;
        k = i2;
      } 
      paramInt1++;
    } 
    paramArrayOfint[0] = i2;
    paramArrayOfint[1] = j;
  }
  
  private void measureNoWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    WidgetsList widgetsList;
    if (paramInt1 == 0)
      return; 
    if (this.mChainList.size() == 0) {
      widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
      this.mChainList.add(widgetsList);
    } else {
      widgetsList = this.mChainList.get(0);
      widgetsList.clear();
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      ConstraintAnchor constraintAnchor3 = this.mRight;
      ConstraintAnchor constraintAnchor4 = this.mBottom;
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getPaddingRight();
      int m = getPaddingBottom();
      widgetsList.setup(paramInt2, constraintAnchor1, constraintAnchor2, constraintAnchor3, constraintAnchor4, i, j, k, m, paramInt3);
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++)
      widgetsList.add(paramArrayOfConstraintWidget[paramInt2]); 
    paramArrayOfint[0] = widgetsList.getWidth();
    paramArrayOfint[1] = widgetsList.getHeight();
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (getParent() != null && ((ConstraintWidgetContainer)getParent()).isRtl()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    int i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3) {
            int j = this.mChainList.size();
            for (i = 0; i < j; i++) {
              boolean bool;
              WidgetsList widgetsList = this.mChainList.get(i);
              if (i == j - 1) {
                bool = true;
              } else {
                bool = false;
              } 
              widgetsList.createConstraints(paramBoolean, i, bool);
            } 
          } 
        } else {
          createAlignedConstraints(paramBoolean);
        } 
      } else {
        int j = this.mChainList.size();
        for (i = 0; i < j; i++) {
          boolean bool;
          WidgetsList widgetsList = this.mChainList.get(i);
          if (i == j - 1) {
            bool = true;
          } else {
            bool = false;
          } 
          widgetsList.createConstraints(paramBoolean, i, bool);
        } 
      } 
    } else if (this.mChainList.size() > 0) {
      ((WidgetsList)this.mChainList.get(0)).createConstraints(paramBoolean, 0, true);
    } 
    needsCallbackFromSolver(false);
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mHorizontalStyle = ((Flow)paramConstraintWidget).mHorizontalStyle;
    this.mVerticalStyle = ((Flow)paramConstraintWidget).mVerticalStyle;
    this.mFirstHorizontalStyle = ((Flow)paramConstraintWidget).mFirstHorizontalStyle;
    this.mFirstVerticalStyle = ((Flow)paramConstraintWidget).mFirstVerticalStyle;
    this.mLastHorizontalStyle = ((Flow)paramConstraintWidget).mLastHorizontalStyle;
    this.mLastVerticalStyle = ((Flow)paramConstraintWidget).mLastVerticalStyle;
    this.mHorizontalBias = ((Flow)paramConstraintWidget).mHorizontalBias;
    this.mVerticalBias = ((Flow)paramConstraintWidget).mVerticalBias;
    this.mFirstHorizontalBias = ((Flow)paramConstraintWidget).mFirstHorizontalBias;
    this.mFirstVerticalBias = ((Flow)paramConstraintWidget).mFirstVerticalBias;
    this.mLastHorizontalBias = ((Flow)paramConstraintWidget).mLastHorizontalBias;
    this.mLastVerticalBias = ((Flow)paramConstraintWidget).mLastVerticalBias;
    this.mHorizontalGap = ((Flow)paramConstraintWidget).mHorizontalGap;
    this.mVerticalGap = ((Flow)paramConstraintWidget).mVerticalGap;
    this.mHorizontalAlign = ((Flow)paramConstraintWidget).mHorizontalAlign;
    this.mVerticalAlign = ((Flow)paramConstraintWidget).mVerticalAlign;
    this.mWrapMode = ((Flow)paramConstraintWidget).mWrapMode;
    this.mMaxElementsWrap = ((Flow)paramConstraintWidget).mMaxElementsWrap;
    this.mOrientation = ((Flow)paramConstraintWidget).mOrientation;
  }
  
  public float getMaxElementsWrap() {
    return this.mMaxElementsWrap;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mWidgetsCount > 0 && !measureChildren()) {
      setMeasure(0, 0);
      needsCallbackFromSolver(false);
      return;
    } 
    int i1 = getPaddingLeft();
    int i2 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int[] arrayOfInt = new int[2];
    int j = paramInt2 - i1 - i2;
    int i = this.mOrientation;
    if (i == 1)
      j = paramInt4 - m - n; 
    if (i == 0) {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } else {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } 
    ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
    int k = 0;
    for (i = k; k < this.mWidgetsCount; i = i3) {
      int i3 = i;
      if (this.mWidgets[k].getVisibility() == 8)
        i3 = i + 1; 
      k++;
    } 
    k = this.mWidgetsCount;
    if (i > 0) {
      arrayOfConstraintWidget = new ConstraintWidget[this.mWidgetsCount - i];
      k = 0;
      for (i = 0; k < this.mWidgetsCount; i = i3) {
        ConstraintWidget constraintWidget = this.mWidgets[k];
        int i3 = i;
        if (constraintWidget.getVisibility() != 8) {
          arrayOfConstraintWidget[i] = constraintWidget;
          i3 = i + 1;
        } 
        k++;
      } 
      k = i;
    } 
    this.mDisplayedWidgets = arrayOfConstraintWidget;
    this.mDisplayedWidgetsCount = k;
    i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3)
            measureChainWrap_new(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt); 
        } else {
          measureAligned(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
        } 
      } else {
        measureChainWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
      } 
    } else {
      measureNoWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
    } 
    boolean bool = true;
    j = arrayOfInt[0] + i1 + i2;
    i = arrayOfInt[1] + m + n;
    if (paramInt1 == 1073741824) {
      paramInt1 = paramInt2;
    } else if (paramInt1 == Integer.MIN_VALUE) {
      paramInt1 = Math.min(j, paramInt2);
    } else if (paramInt1 == 0) {
      paramInt1 = j;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt3 == 1073741824) {
      paramInt2 = paramInt4;
    } else if (paramInt3 == Integer.MIN_VALUE) {
      paramInt2 = Math.min(i, paramInt4);
    } else if (paramInt3 == 0) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    setMeasure(paramInt1, paramInt2);
    setWidth(paramInt1);
    setHeight(paramInt2);
    if (this.mWidgetsCount <= 0)
      bool = false; 
    needsCallbackFromSolver(bool);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.mFirstHorizontalBias = paramFloat;
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.mFirstHorizontalStyle = paramInt;
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.mFirstVerticalBias = paramFloat;
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.mFirstVerticalStyle = paramInt;
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.mHorizontalAlign = paramInt;
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.mHorizontalBias = paramFloat;
  }
  
  public void setHorizontalGap(int paramInt) {
    this.mHorizontalGap = paramInt;
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.mHorizontalStyle = paramInt;
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.mLastHorizontalBias = paramFloat;
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.mLastHorizontalStyle = paramInt;
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.mLastVerticalBias = paramFloat;
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.mLastVerticalStyle = paramInt;
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.mMaxElementsWrap = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setVerticalAlign(int paramInt) {
    this.mVerticalAlign = paramInt;
  }
  
  public void setVerticalBias(float paramFloat) {
    this.mVerticalBias = paramFloat;
  }
  
  public void setVerticalGap(int paramInt) {
    this.mVerticalGap = paramInt;
  }
  
  public void setVerticalStyle(int paramInt) {
    this.mVerticalStyle = paramInt;
  }
  
  public void setWrapMode(int paramInt) {
    this.mWrapMode = paramInt;
  }
  
  private class WidgetsList {
    private ConstraintWidget biggest = null;
    
    int biggestDimension = 0;
    
    private ConstraintAnchor mBottom;
    
    private int mCount = 0;
    
    private int mHeight = 0;
    
    private ConstraintAnchor mLeft;
    
    private int mMax = 0;
    
    private int mNbMatchConstraintsWidgets = 0;
    
    private int mOrientation;
    
    private int mPaddingBottom = 0;
    
    private int mPaddingLeft = 0;
    
    private int mPaddingRight = 0;
    
    private int mPaddingTop = 0;
    
    private ConstraintAnchor mRight;
    
    private int mStartIndex = 0;
    
    private ConstraintAnchor mTop;
    
    private int mWidth = 0;
    
    public WidgetsList(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = Flow.this.getPaddingLeft();
      this.mPaddingTop = Flow.this.getPaddingTop();
      this.mPaddingRight = Flow.this.getPaddingRight();
      this.mPaddingBottom = Flow.this.getPaddingBottom();
      this.mMax = param1Int2;
    }
    
    private void recomputeDimensions() {
      this.mWidth = 0;
      this.mHeight = 0;
      this.biggest = null;
      this.biggestDimension = 0;
      int j = this.mCount;
      for (int i = 0; i < j; i++) {
        if (this.mStartIndex + i >= Flow.this.mDisplayedWidgetsCount)
          return; 
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + i];
        if (this.mOrientation == 0) {
          int m = constraintWidget.getWidth();
          int k = Flow.this.mHorizontalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mWidth += m + k;
          k = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          if (this.biggest == null || this.biggestDimension < k) {
            this.biggest = constraintWidget;
            this.biggestDimension = k;
            this.mHeight = k;
          } 
        } else {
          int m = Flow.this.getWidgetWidth(constraintWidget, this.mMax);
          int n = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          int k = Flow.this.mVerticalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mHeight += n + k;
          if (this.biggest == null || this.biggestDimension < m) {
            this.biggest = constraintWidget;
            this.biggestDimension = m;
            this.mWidth = m;
          } 
        } 
      } 
    }
    
    public void add(ConstraintWidget param1ConstraintWidget) {
      int i = this.mOrientation;
      int j = 0;
      int k = 0;
      if (i == 0) {
        i = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        j = Flow.this.mHorizontalGap;
        if (param1ConstraintWidget.getVisibility() == 8)
          j = k; 
        this.mWidth += i + j;
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (this.biggest == null || this.biggestDimension < i) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = i;
          this.mHeight = i;
        } 
      } else {
        int m = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        k = Flow.this.mVerticalGap;
        if (param1ConstraintWidget.getVisibility() != 8)
          j = k; 
        this.mHeight += i + j;
        if (this.biggest == null || this.biggestDimension < m) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = m;
          this.mWidth = m;
        } 
      } 
      this.mCount++;
    }
    
    public void clear() {
      this.biggestDimension = 0;
      this.biggest = null;
      this.mWidth = 0;
      this.mHeight = 0;
      this.mStartIndex = 0;
      this.mCount = 0;
      this.mNbMatchConstraintsWidgets = 0;
    }
    
    public void createConstraints(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mCount : I
      //   4: istore #12
      //   6: iconst_0
      //   7: istore #6
      //   9: iload #6
      //   11: iload #12
      //   13: if_icmpge -> 72
      //   16: aload_0
      //   17: getfield mStartIndex : I
      //   20: iload #6
      //   22: iadd
      //   23: aload_0
      //   24: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   27: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   30: if_icmplt -> 36
      //   33: goto -> 72
      //   36: aload_0
      //   37: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   40: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   43: aload_0
      //   44: getfield mStartIndex : I
      //   47: iload #6
      //   49: iadd
      //   50: aaload
      //   51: astore #13
      //   53: aload #13
      //   55: ifnull -> 63
      //   58: aload #13
      //   60: invokevirtual resetAnchors : ()V
      //   63: iload #6
      //   65: iconst_1
      //   66: iadd
      //   67: istore #6
      //   69: goto -> 9
      //   72: iload #12
      //   74: ifeq -> 1815
      //   77: aload_0
      //   78: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   81: ifnonnull -> 85
      //   84: return
      //   85: iload_3
      //   86: ifeq -> 99
      //   89: iload_2
      //   90: ifne -> 99
      //   93: iconst_1
      //   94: istore #9
      //   96: goto -> 102
      //   99: iconst_0
      //   100: istore #9
      //   102: iconst_0
      //   103: istore #6
      //   105: iconst_m1
      //   106: istore #7
      //   108: iload #7
      //   110: istore #8
      //   112: iload #6
      //   114: iload #12
      //   116: if_icmpge -> 244
      //   119: iload_1
      //   120: ifeq -> 135
      //   123: iload #12
      //   125: iconst_1
      //   126: isub
      //   127: iload #6
      //   129: isub
      //   130: istore #10
      //   132: goto -> 139
      //   135: iload #6
      //   137: istore #10
      //   139: aload_0
      //   140: getfield mStartIndex : I
      //   143: iload #10
      //   145: iadd
      //   146: aload_0
      //   147: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   150: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   153: if_icmplt -> 159
      //   156: goto -> 244
      //   159: aload_0
      //   160: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   163: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   166: aload_0
      //   167: getfield mStartIndex : I
      //   170: iload #10
      //   172: iadd
      //   173: aaload
      //   174: astore #13
      //   176: iload #7
      //   178: istore #11
      //   180: iload #8
      //   182: istore #10
      //   184: aload #13
      //   186: ifnull -> 227
      //   189: iload #7
      //   191: istore #11
      //   193: iload #8
      //   195: istore #10
      //   197: aload #13
      //   199: invokevirtual getVisibility : ()I
      //   202: ifne -> 227
      //   205: iload #7
      //   207: istore #8
      //   209: iload #7
      //   211: iconst_m1
      //   212: if_icmpne -> 219
      //   215: iload #6
      //   217: istore #8
      //   219: iload #6
      //   221: istore #10
      //   223: iload #8
      //   225: istore #11
      //   227: iload #6
      //   229: iconst_1
      //   230: iadd
      //   231: istore #6
      //   233: iload #11
      //   235: istore #7
      //   237: iload #10
      //   239: istore #8
      //   241: goto -> 112
      //   244: aconst_null
      //   245: astore #14
      //   247: aconst_null
      //   248: astore #13
      //   250: aload_0
      //   251: getfield mOrientation : I
      //   254: ifne -> 1087
      //   257: aload_0
      //   258: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   261: astore #15
      //   263: aload #15
      //   265: aload_0
      //   266: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   269: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   272: invokevirtual setVerticalChainStyle : (I)V
      //   275: aload_0
      //   276: getfield mPaddingTop : I
      //   279: istore #10
      //   281: iload #10
      //   283: istore #6
      //   285: iload_2
      //   286: ifle -> 301
      //   289: iload #10
      //   291: aload_0
      //   292: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   295: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   298: iadd
      //   299: istore #6
      //   301: aload #15
      //   303: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   306: aload_0
      //   307: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   310: iload #6
      //   312: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   315: pop
      //   316: iload_3
      //   317: ifeq -> 337
      //   320: aload #15
      //   322: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   325: aload_0
      //   326: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   329: aload_0
      //   330: getfield mPaddingBottom : I
      //   333: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   336: pop
      //   337: iload_2
      //   338: ifle -> 361
      //   341: aload_0
      //   342: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   345: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   348: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   351: aload #15
      //   353: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   356: iconst_0
      //   357: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   360: pop
      //   361: aload_0
      //   362: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   365: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   368: istore_2
      //   369: iconst_3
      //   370: istore #10
      //   372: iload_2
      //   373: iconst_3
      //   374: if_icmpne -> 466
      //   377: aload #15
      //   379: invokevirtual hasBaseline : ()Z
      //   382: ifne -> 466
      //   385: iconst_0
      //   386: istore_2
      //   387: iload_2
      //   388: iload #12
      //   390: if_icmpge -> 466
      //   393: iload_1
      //   394: ifeq -> 408
      //   397: iload #12
      //   399: iconst_1
      //   400: isub
      //   401: iload_2
      //   402: isub
      //   403: istore #6
      //   405: goto -> 411
      //   408: iload_2
      //   409: istore #6
      //   411: aload_0
      //   412: getfield mStartIndex : I
      //   415: iload #6
      //   417: iadd
      //   418: aload_0
      //   419: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   422: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   425: if_icmplt -> 431
      //   428: goto -> 466
      //   431: aload_0
      //   432: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   435: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   438: aload_0
      //   439: getfield mStartIndex : I
      //   442: iload #6
      //   444: iadd
      //   445: aaload
      //   446: astore #14
      //   448: aload #14
      //   450: invokevirtual hasBaseline : ()Z
      //   453: ifeq -> 459
      //   456: goto -> 470
      //   459: iload_2
      //   460: iconst_1
      //   461: iadd
      //   462: istore_2
      //   463: goto -> 387
      //   466: aload #15
      //   468: astore #14
      //   470: iconst_0
      //   471: istore #6
      //   473: iload #10
      //   475: istore_2
      //   476: iload #6
      //   478: iload #12
      //   480: if_icmpge -> 1815
      //   483: iload_1
      //   484: ifeq -> 499
      //   487: iload #12
      //   489: iconst_1
      //   490: isub
      //   491: iload #6
      //   493: isub
      //   494: istore #10
      //   496: goto -> 503
      //   499: iload #6
      //   501: istore #10
      //   503: aload_0
      //   504: getfield mStartIndex : I
      //   507: iload #10
      //   509: iadd
      //   510: aload_0
      //   511: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   514: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   517: if_icmplt -> 521
      //   520: return
      //   521: aload_0
      //   522: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   525: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   528: aload_0
      //   529: getfield mStartIndex : I
      //   532: iload #10
      //   534: iadd
      //   535: aaload
      //   536: astore #16
      //   538: aload #16
      //   540: ifnonnull -> 546
      //   543: goto -> 1078
      //   546: iload #6
      //   548: ifne -> 569
      //   551: aload #16
      //   553: aload #16
      //   555: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   558: aload_0
      //   559: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   562: aload_0
      //   563: getfield mPaddingLeft : I
      //   566: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   569: iload #10
      //   571: ifne -> 748
      //   574: aload_0
      //   575: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   578: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   581: istore #10
      //   583: aload_0
      //   584: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   587: invokestatic access$900 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   590: fstore #5
      //   592: fload #5
      //   594: fstore #4
      //   596: iload_1
      //   597: ifeq -> 606
      //   600: fconst_1
      //   601: fload #5
      //   603: fsub
      //   604: fstore #4
      //   606: aload_0
      //   607: getfield mStartIndex : I
      //   610: ifne -> 670
      //   613: aload_0
      //   614: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   617: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   620: iconst_m1
      //   621: if_icmpeq -> 670
      //   624: aload_0
      //   625: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   628: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   631: istore_2
      //   632: iload_1
      //   633: ifeq -> 654
      //   636: aload_0
      //   637: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   640: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   643: fstore #4
      //   645: fconst_1
      //   646: fload #4
      //   648: fsub
      //   649: fstore #4
      //   651: goto -> 663
      //   654: aload_0
      //   655: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   658: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   661: fstore #4
      //   663: fload #4
      //   665: fstore #5
      //   667: goto -> 735
      //   670: iload #10
      //   672: istore_2
      //   673: fload #4
      //   675: fstore #5
      //   677: iload_3
      //   678: ifeq -> 735
      //   681: iload #10
      //   683: istore_2
      //   684: fload #4
      //   686: fstore #5
      //   688: aload_0
      //   689: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   692: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   695: iconst_m1
      //   696: if_icmpeq -> 735
      //   699: aload_0
      //   700: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   703: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   706: istore_2
      //   707: iload_1
      //   708: ifeq -> 723
      //   711: aload_0
      //   712: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   715: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   718: fstore #4
      //   720: goto -> 645
      //   723: aload_0
      //   724: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   727: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   730: fstore #4
      //   732: goto -> 663
      //   735: aload #16
      //   737: iload_2
      //   738: invokevirtual setHorizontalChainStyle : (I)V
      //   741: aload #16
      //   743: fload #5
      //   745: invokevirtual setHorizontalBiasPercent : (F)V
      //   748: iload #6
      //   750: iload #12
      //   752: iconst_1
      //   753: isub
      //   754: if_icmpne -> 775
      //   757: aload #16
      //   759: aload #16
      //   761: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   764: aload_0
      //   765: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   768: aload_0
      //   769: getfield mPaddingRight : I
      //   772: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   775: aload #13
      //   777: ifnull -> 856
      //   780: aload #16
      //   782: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   785: aload #13
      //   787: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   790: aload_0
      //   791: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   794: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   797: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   800: pop
      //   801: iload #6
      //   803: iload #7
      //   805: if_icmpne -> 820
      //   808: aload #16
      //   810: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   813: aload_0
      //   814: getfield mPaddingLeft : I
      //   817: invokevirtual setGoneMargin : (I)V
      //   820: aload #13
      //   822: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   825: aload #16
      //   827: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   830: iconst_0
      //   831: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   834: pop
      //   835: iload #6
      //   837: iload #8
      //   839: iconst_1
      //   840: iadd
      //   841: if_icmpne -> 856
      //   844: aload #13
      //   846: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   849: aload_0
      //   850: getfield mPaddingRight : I
      //   853: invokevirtual setGoneMargin : (I)V
      //   856: aload #16
      //   858: aload #15
      //   860: if_acmpeq -> 1072
      //   863: aload_0
      //   864: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   867: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   870: istore #10
      //   872: iconst_3
      //   873: istore_2
      //   874: iload #10
      //   876: iconst_3
      //   877: if_icmpne -> 925
      //   880: aload #14
      //   882: invokevirtual hasBaseline : ()Z
      //   885: ifeq -> 925
      //   888: aload #16
      //   890: aload #14
      //   892: if_acmpeq -> 925
      //   895: aload #16
      //   897: invokevirtual hasBaseline : ()Z
      //   900: ifeq -> 925
      //   903: aload #16
      //   905: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   908: aload #14
      //   910: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   913: iconst_0
      //   914: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   917: pop
      //   918: aload #16
      //   920: astore #13
      //   922: goto -> 1078
      //   925: aload_0
      //   926: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   929: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   932: istore #10
      //   934: iload #10
      //   936: ifeq -> 1050
      //   939: iload #10
      //   941: iconst_1
      //   942: if_icmpeq -> 1028
      //   945: iload #9
      //   947: ifeq -> 991
      //   950: aload #16
      //   952: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   955: aload_0
      //   956: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   959: aload_0
      //   960: getfield mPaddingTop : I
      //   963: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   966: pop
      //   967: aload #16
      //   969: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   972: aload_0
      //   973: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   976: aload_0
      //   977: getfield mPaddingBottom : I
      //   980: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   983: pop
      //   984: aload #16
      //   986: astore #13
      //   988: goto -> 1078
      //   991: aload #16
      //   993: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   996: aload #15
      //   998: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1001: iconst_0
      //   1002: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1005: pop
      //   1006: aload #16
      //   1008: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1011: aload #15
      //   1013: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1016: iconst_0
      //   1017: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1020: pop
      //   1021: aload #16
      //   1023: astore #13
      //   1025: goto -> 1078
      //   1028: aload #16
      //   1030: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1033: aload #15
      //   1035: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1038: iconst_0
      //   1039: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1042: pop
      //   1043: aload #16
      //   1045: astore #13
      //   1047: goto -> 1078
      //   1050: aload #16
      //   1052: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1055: aload #15
      //   1057: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1060: iconst_0
      //   1061: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1064: pop
      //   1065: aload #16
      //   1067: astore #13
      //   1069: goto -> 1078
      //   1072: iconst_3
      //   1073: istore_2
      //   1074: aload #16
      //   1076: astore #13
      //   1078: iload #6
      //   1080: iconst_1
      //   1081: iadd
      //   1082: istore #6
      //   1084: goto -> 476
      //   1087: aload_0
      //   1088: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1091: astore #15
      //   1093: aload #15
      //   1095: aload_0
      //   1096: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1099: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1102: invokevirtual setHorizontalChainStyle : (I)V
      //   1105: aload_0
      //   1106: getfield mPaddingLeft : I
      //   1109: istore #10
      //   1111: iload #10
      //   1113: istore #6
      //   1115: iload_2
      //   1116: ifle -> 1131
      //   1119: iload #10
      //   1121: aload_0
      //   1122: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1125: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1128: iadd
      //   1129: istore #6
      //   1131: iload_1
      //   1132: ifeq -> 1198
      //   1135: aload #15
      //   1137: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1140: aload_0
      //   1141: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1144: iload #6
      //   1146: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1149: pop
      //   1150: iload_3
      //   1151: ifeq -> 1171
      //   1154: aload #15
      //   1156: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1159: aload_0
      //   1160: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1163: aload_0
      //   1164: getfield mPaddingRight : I
      //   1167: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1170: pop
      //   1171: iload_2
      //   1172: ifle -> 1258
      //   1175: aload_0
      //   1176: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1179: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1182: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1185: aload #15
      //   1187: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1190: iconst_0
      //   1191: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1194: pop
      //   1195: goto -> 1258
      //   1198: aload #15
      //   1200: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1203: aload_0
      //   1204: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1207: iload #6
      //   1209: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1212: pop
      //   1213: iload_3
      //   1214: ifeq -> 1234
      //   1217: aload #15
      //   1219: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1222: aload_0
      //   1223: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1226: aload_0
      //   1227: getfield mPaddingRight : I
      //   1230: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1233: pop
      //   1234: iload_2
      //   1235: ifle -> 1258
      //   1238: aload_0
      //   1239: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1242: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1245: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1248: aload #15
      //   1250: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1253: iconst_0
      //   1254: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1257: pop
      //   1258: iconst_0
      //   1259: istore #6
      //   1261: aload #14
      //   1263: astore #13
      //   1265: iload #6
      //   1267: iload #12
      //   1269: if_icmpge -> 1815
      //   1272: aload_0
      //   1273: getfield mStartIndex : I
      //   1276: iload #6
      //   1278: iadd
      //   1279: aload_0
      //   1280: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1283: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1286: if_icmplt -> 1290
      //   1289: return
      //   1290: aload_0
      //   1291: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1294: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1297: aload_0
      //   1298: getfield mStartIndex : I
      //   1301: iload #6
      //   1303: iadd
      //   1304: aaload
      //   1305: astore #14
      //   1307: aload #14
      //   1309: ifnonnull -> 1315
      //   1312: goto -> 1806
      //   1315: iload #6
      //   1317: ifne -> 1453
      //   1320: aload #14
      //   1322: aload #14
      //   1324: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1327: aload_0
      //   1328: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1331: aload_0
      //   1332: getfield mPaddingTop : I
      //   1335: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1338: aload_0
      //   1339: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1342: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1345: istore #10
      //   1347: aload_0
      //   1348: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1351: invokestatic access$1400 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1354: fstore #5
      //   1356: aload_0
      //   1357: getfield mStartIndex : I
      //   1360: ifne -> 1394
      //   1363: aload_0
      //   1364: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1367: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1370: iconst_m1
      //   1371: if_icmpeq -> 1394
      //   1374: aload_0
      //   1375: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1378: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1381: istore_2
      //   1382: aload_0
      //   1383: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1386: invokestatic access$1600 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1389: fstore #4
      //   1391: goto -> 1440
      //   1394: iload #10
      //   1396: istore_2
      //   1397: fload #5
      //   1399: fstore #4
      //   1401: iload_3
      //   1402: ifeq -> 1440
      //   1405: iload #10
      //   1407: istore_2
      //   1408: fload #5
      //   1410: fstore #4
      //   1412: aload_0
      //   1413: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1416: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1419: iconst_m1
      //   1420: if_icmpeq -> 1440
      //   1423: aload_0
      //   1424: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1427: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1430: istore_2
      //   1431: aload_0
      //   1432: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1435: invokestatic access$1800 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1438: fstore #4
      //   1440: aload #14
      //   1442: iload_2
      //   1443: invokevirtual setVerticalChainStyle : (I)V
      //   1446: aload #14
      //   1448: fload #4
      //   1450: invokevirtual setVerticalBiasPercent : (F)V
      //   1453: iload #6
      //   1455: iload #12
      //   1457: iconst_1
      //   1458: isub
      //   1459: if_icmpne -> 1480
      //   1462: aload #14
      //   1464: aload #14
      //   1466: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1469: aload_0
      //   1470: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1473: aload_0
      //   1474: getfield mPaddingBottom : I
      //   1477: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1480: aload #13
      //   1482: ifnull -> 1561
      //   1485: aload #14
      //   1487: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1490: aload #13
      //   1492: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1495: aload_0
      //   1496: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1499: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1502: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1505: pop
      //   1506: iload #6
      //   1508: iload #7
      //   1510: if_icmpne -> 1525
      //   1513: aload #14
      //   1515: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1518: aload_0
      //   1519: getfield mPaddingTop : I
      //   1522: invokevirtual setGoneMargin : (I)V
      //   1525: aload #13
      //   1527: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1530: aload #14
      //   1532: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1535: iconst_0
      //   1536: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1539: pop
      //   1540: iload #6
      //   1542: iload #8
      //   1544: iconst_1
      //   1545: iadd
      //   1546: if_icmpne -> 1561
      //   1549: aload #13
      //   1551: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1554: aload_0
      //   1555: getfield mPaddingBottom : I
      //   1558: invokevirtual setGoneMargin : (I)V
      //   1561: aload #14
      //   1563: aload #15
      //   1565: if_acmpeq -> 1802
      //   1568: iload_1
      //   1569: ifeq -> 1666
      //   1572: aload_0
      //   1573: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1576: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1579: istore_2
      //   1580: iload_2
      //   1581: ifeq -> 1648
      //   1584: iload_2
      //   1585: iconst_1
      //   1586: if_icmpeq -> 1630
      //   1589: iload_2
      //   1590: iconst_2
      //   1591: if_icmpeq -> 1597
      //   1594: goto -> 1802
      //   1597: aload #14
      //   1599: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1602: aload #15
      //   1604: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1607: iconst_0
      //   1608: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1611: pop
      //   1612: aload #14
      //   1614: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1617: aload #15
      //   1619: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1622: iconst_0
      //   1623: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1626: pop
      //   1627: goto -> 1802
      //   1630: aload #14
      //   1632: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1635: aload #15
      //   1637: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1640: iconst_0
      //   1641: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1644: pop
      //   1645: goto -> 1802
      //   1648: aload #14
      //   1650: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1653: aload #15
      //   1655: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1658: iconst_0
      //   1659: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1662: pop
      //   1663: goto -> 1802
      //   1666: aload_0
      //   1667: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1670: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1673: istore_2
      //   1674: iload_2
      //   1675: ifeq -> 1784
      //   1678: iload_2
      //   1679: iconst_1
      //   1680: if_icmpeq -> 1766
      //   1683: iload_2
      //   1684: iconst_2
      //   1685: if_icmpeq -> 1691
      //   1688: goto -> 1802
      //   1691: iload #9
      //   1693: ifeq -> 1733
      //   1696: aload #14
      //   1698: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1701: aload_0
      //   1702: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1705: aload_0
      //   1706: getfield mPaddingLeft : I
      //   1709: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1712: pop
      //   1713: aload #14
      //   1715: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1718: aload_0
      //   1719: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1722: aload_0
      //   1723: getfield mPaddingRight : I
      //   1726: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1729: pop
      //   1730: goto -> 1802
      //   1733: aload #14
      //   1735: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1738: aload #15
      //   1740: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1743: iconst_0
      //   1744: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1747: pop
      //   1748: aload #14
      //   1750: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1753: aload #15
      //   1755: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1758: iconst_0
      //   1759: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1762: pop
      //   1763: goto -> 1802
      //   1766: aload #14
      //   1768: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1771: aload #15
      //   1773: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1776: iconst_0
      //   1777: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1780: pop
      //   1781: goto -> 1802
      //   1784: aload #14
      //   1786: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1789: aload #15
      //   1791: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1794: iconst_0
      //   1795: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1798: pop
      //   1799: goto -> 1802
      //   1802: aload #14
      //   1804: astore #13
      //   1806: iload #6
      //   1808: iconst_1
      //   1809: iadd
      //   1810: istore #6
      //   1812: goto -> 1265
      //   1815: return
    }
    
    public int getHeight() {
      return (this.mOrientation == 1) ? (this.mHeight - Flow.this.mVerticalGap) : this.mHeight;
    }
    
    public int getWidth() {
      return (this.mOrientation == 0) ? (this.mWidth - Flow.this.mHorizontalGap) : this.mWidth;
    }
    
    public void measureMatchConstraints(int param1Int) {
      int j = this.mNbMatchConstraintsWidgets;
      if (j == 0)
        return; 
      int i = this.mCount;
      j = param1Int / j;
      for (param1Int = 0; param1Int < i && this.mStartIndex + param1Int < Flow.this.mDisplayedWidgetsCount; param1Int++) {
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + param1Int];
        if (this.mOrientation == 0) {
          if (constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultWidth == 0)
            Flow.this.measure(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, j, constraintWidget.getVerticalDimensionBehaviour(), constraintWidget.getHeight()); 
        } else if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultHeight == 0) {
          Flow.this.measure(constraintWidget, constraintWidget.getHorizontalDimensionBehaviour(), constraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, j);
        } 
      } 
      recomputeDimensions();
    }
    
    public void setStartIndex(int param1Int) {
      this.mStartIndex = param1Int;
    }
    
    public void setup(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = param1Int2;
      this.mPaddingTop = param1Int3;
      this.mPaddingRight = param1Int4;
      this.mPaddingBottom = param1Int5;
      this.mMax = param1Int6;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\widgets\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */