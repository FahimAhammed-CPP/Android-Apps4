package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;

public class BasicMeasure {
  public static final int AT_MOST = -2147483648;
  
  private static final boolean DEBUG = false;
  
  public static final int EXACTLY = 1073741824;
  
  public static final int FIXED = -3;
  
  public static final int MATCH_PARENT = -1;
  
  private static final int MODE_SHIFT = 30;
  
  public static final int UNSPECIFIED = 0;
  
  public static final int WRAP_CONTENT = -2;
  
  private ConstraintWidgetContainer constraintWidgetContainer;
  
  private Measure mMeasure = new Measure();
  
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<ConstraintWidget>();
  
  public BasicMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.constraintWidgetContainer = paramConstraintWidgetContainer;
  }
  
  private boolean measure(Measurer paramMeasurer, ConstraintWidget paramConstraintWidget, int paramInt) {
    boolean bool;
    this.mMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    this.mMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    this.mMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    this.mMeasure.verticalDimension = paramConstraintWidget.getHeight();
    this.mMeasure.measuredNeedsSolverPass = false;
    this.mMeasure.measureStrategy = paramInt;
    if (this.mMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.mMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (bool && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramInt != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (bool && paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4)
      this.mMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    if (paramInt != 0 && paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4)
      this.mMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
    paramMeasurer.measure(paramConstraintWidget, this.mMeasure);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
    this.mMeasure.measureStrategy = Measure.SELF_DIMENSIONS;
    return this.mMeasure.measuredNeedsSolverPass;
  }
  
  private void measureChildren(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mChildren : Ljava/util/ArrayList;
    //   4: invokevirtual size : ()I
    //   7: istore #6
    //   9: aload_1
    //   10: bipush #64
    //   12: invokevirtual optimizeFor : (I)Z
    //   15: istore #7
    //   17: aload_1
    //   18: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   21: astore #8
    //   23: iconst_0
    //   24: istore #4
    //   26: iload #4
    //   28: iload #6
    //   30: if_icmpge -> 391
    //   33: aload_1
    //   34: getfield mChildren : Ljava/util/ArrayList;
    //   37: iload #4
    //   39: invokevirtual get : (I)Ljava/lang/Object;
    //   42: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   45: astore #9
    //   47: aload #9
    //   49: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   52: ifeq -> 58
    //   55: goto -> 382
    //   58: aload #9
    //   60: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   63: ifeq -> 69
    //   66: goto -> 382
    //   69: aload #9
    //   71: invokevirtual isInVirtualLayout : ()Z
    //   74: ifeq -> 80
    //   77: goto -> 382
    //   80: iload #7
    //   82: ifeq -> 132
    //   85: aload #9
    //   87: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   90: ifnull -> 132
    //   93: aload #9
    //   95: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   98: ifnull -> 132
    //   101: aload #9
    //   103: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   106: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   109: getfield resolved : Z
    //   112: ifeq -> 132
    //   115: aload #9
    //   117: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   120: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   123: getfield resolved : Z
    //   126: ifeq -> 132
    //   129: goto -> 382
    //   132: aload #9
    //   134: iconst_0
    //   135: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   138: astore #10
    //   140: iconst_1
    //   141: istore #5
    //   143: aload #9
    //   145: iconst_1
    //   146: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   149: astore #11
    //   151: aload #10
    //   153: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   156: if_acmpne -> 190
    //   159: aload #9
    //   161: getfield mMatchConstraintDefaultWidth : I
    //   164: iconst_1
    //   165: if_icmpeq -> 190
    //   168: aload #11
    //   170: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   173: if_acmpne -> 190
    //   176: aload #9
    //   178: getfield mMatchConstraintDefaultHeight : I
    //   181: iconst_1
    //   182: if_icmpeq -> 190
    //   185: iconst_1
    //   186: istore_2
    //   187: goto -> 192
    //   190: iconst_0
    //   191: istore_2
    //   192: iload_2
    //   193: istore_3
    //   194: iload_2
    //   195: ifne -> 338
    //   198: iload_2
    //   199: istore_3
    //   200: aload_1
    //   201: iconst_1
    //   202: invokevirtual optimizeFor : (I)Z
    //   205: ifeq -> 338
    //   208: iload_2
    //   209: istore_3
    //   210: aload #9
    //   212: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   215: ifne -> 338
    //   218: iload_2
    //   219: istore_3
    //   220: aload #10
    //   222: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   225: if_acmpne -> 260
    //   228: iload_2
    //   229: istore_3
    //   230: aload #9
    //   232: getfield mMatchConstraintDefaultWidth : I
    //   235: ifne -> 260
    //   238: iload_2
    //   239: istore_3
    //   240: aload #11
    //   242: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   245: if_acmpeq -> 260
    //   248: iload_2
    //   249: istore_3
    //   250: aload #9
    //   252: invokevirtual isInHorizontalChain : ()Z
    //   255: ifne -> 260
    //   258: iconst_1
    //   259: istore_3
    //   260: iload_3
    //   261: istore_2
    //   262: aload #11
    //   264: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: if_acmpne -> 302
    //   270: iload_3
    //   271: istore_2
    //   272: aload #9
    //   274: getfield mMatchConstraintDefaultHeight : I
    //   277: ifne -> 302
    //   280: iload_3
    //   281: istore_2
    //   282: aload #10
    //   284: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   287: if_acmpeq -> 302
    //   290: iload_3
    //   291: istore_2
    //   292: aload #9
    //   294: invokevirtual isInHorizontalChain : ()Z
    //   297: ifne -> 302
    //   300: iconst_1
    //   301: istore_2
    //   302: aload #10
    //   304: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   307: if_acmpeq -> 320
    //   310: iload_2
    //   311: istore_3
    //   312: aload #11
    //   314: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   317: if_acmpne -> 338
    //   320: iload_2
    //   321: istore_3
    //   322: aload #9
    //   324: getfield mDimensionRatio : F
    //   327: fconst_0
    //   328: fcmpl
    //   329: ifle -> 338
    //   332: iload #5
    //   334: istore_3
    //   335: goto -> 338
    //   338: iload_3
    //   339: ifeq -> 345
    //   342: goto -> 382
    //   345: aload_0
    //   346: aload #8
    //   348: aload #9
    //   350: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   353: invokespecial measure : (Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)Z
    //   356: pop
    //   357: aload_1
    //   358: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   361: ifnull -> 382
    //   364: aload_1
    //   365: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   368: astore #9
    //   370: aload #9
    //   372: aload #9
    //   374: getfield measuredWidgets : J
    //   377: lconst_1
    //   378: ladd
    //   379: putfield measuredWidgets : J
    //   382: iload #4
    //   384: iconst_1
    //   385: iadd
    //   386: istore #4
    //   388: goto -> 26
    //   391: aload #8
    //   393: invokeinterface didMeasures : ()V
    //   398: return
  }
  
  private void solveLinearSystem(ConstraintWidgetContainer paramConstraintWidgetContainer, String paramString, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramConstraintWidgetContainer.getMinWidth();
    int j = paramConstraintWidgetContainer.getMinHeight();
    paramConstraintWidgetContainer.setMinWidth(0);
    paramConstraintWidgetContainer.setMinHeight(0);
    paramConstraintWidgetContainer.setWidth(paramInt2);
    paramConstraintWidgetContainer.setHeight(paramInt3);
    paramConstraintWidgetContainer.setMinWidth(i);
    paramConstraintWidgetContainer.setMinHeight(j);
    this.constraintWidgetContainer.setPass(paramInt1);
    this.constraintWidgetContainer.layout();
  }
  
  public long solverMeasure(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void updateHierarchy(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.mVariableDimensionsWidgets.clear();
    int j = paramConstraintWidgetContainer.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = paramConstraintWidgetContainer.mChildren.get(i);
      if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
        this.mVariableDimensionsWidgets.add(constraintWidget); 
    } 
    paramConstraintWidgetContainer.invalidateGraph();
  }
  
  public static class Measure {
    public static int SELF_DIMENSIONS = 0;
    
    public static int TRY_GIVEN_DIMENSIONS = 1;
    
    public static int USE_GIVEN_DIMENSIONS = 2;
    
    public ConstraintWidget.DimensionBehaviour horizontalBehavior;
    
    public int horizontalDimension;
    
    public int measureStrategy;
    
    public int measuredBaseline;
    
    public boolean measuredHasBaseline;
    
    public int measuredHeight;
    
    public boolean measuredNeedsSolverPass;
    
    public int measuredWidth;
    
    public ConstraintWidget.DimensionBehaviour verticalBehavior;
    
    public int verticalDimension;
  }
  
  public static interface Measurer {
    void didMeasures();
    
    void measure(ConstraintWidget param1ConstraintWidget, BasicMeasure.Measure param1Measure);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\BasicMeasure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */