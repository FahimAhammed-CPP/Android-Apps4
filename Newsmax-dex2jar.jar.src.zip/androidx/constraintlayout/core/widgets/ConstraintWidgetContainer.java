package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int myCounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private int pass;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  HashSet<ConstraintWidget> widgetsToAdd = new HashSet<ConstraintWidget>();
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(int paramInt1, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt2) {
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    if (paramConstraintWidget.getVisibility() == 8 || paramConstraintWidget instanceof Guideline || paramConstraintWidget instanceof Barrier) {
      paramMeasure.measuredWidth = 0;
      paramMeasure.measuredHeight = 0;
      return false;
    } 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt2;
    if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt1 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramInt2 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = paramInt1;
    if (paramInt1 != 0) {
      i = paramInt1;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        i = paramInt1;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          i = paramInt1;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (paramInt2 != 0 && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            i = 0;
          } 
        } 
      } 
    } 
    paramInt1 = paramInt2;
    if (paramInt2 != 0) {
      paramInt1 = paramInt2;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt1 = paramInt2;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt1 = paramInt2;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt1 = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      i = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt1 = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt1 == 0) {
        if (paramMeasure.verticalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (i == 0) {
        if (paramMeasure.horizontalBehavior == ConstraintWidget.DimensionBehaviour.FIXED) {
          paramInt1 = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
        if (paramConstraintWidget.getDimensionRatioSide() == -1) {
          paramMeasure.verticalDimension = (int)(paramInt1 / paramConstraintWidget.getDimensionRatio());
        } else {
          paramMeasure.verticalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
        } 
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool = optimizeFor(64);
    addToSolver(paramLinearSystem, bool);
    int k = this.mChildren.size();
    int i = 0;
    int j = i;
    while (i < k) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        j = 1; 
      i++;
    } 
    if (j != 0)
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    this.widgetsToAdd.clear();
    for (i = 0; i < k; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        if (constraintWidget instanceof VirtualLayout) {
          this.widgetsToAdd.add(constraintWidget);
        } else {
          constraintWidget.addToSolver(paramLinearSystem, bool);
        }  
    } 
    while (this.widgetsToAdd.size() > 0) {
      i = this.widgetsToAdd.size();
      for (VirtualLayout virtualLayout : this.widgetsToAdd) {
        if (virtualLayout.contains(this.widgetsToAdd)) {
          virtualLayout.addToSolver(paramLinearSystem, bool);
          this.widgetsToAdd.remove(virtualLayout);
          break;
        } 
      } 
      if (i == this.widgetsToAdd.size()) {
        Iterator<ConstraintWidget> iterator = this.widgetsToAdd.iterator();
        while (iterator.hasNext())
          ((ConstraintWidget)iterator.next()).addToSolver(paramLinearSystem, bool); 
        this.widgetsToAdd.clear();
      } 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool);
      } 
    } else {
      for (i = 0; i < k; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget.mListDimensionBehaviors[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget.mListDimensionBehaviors[1];
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool);
          if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 0)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public void getSceneString(StringBuilder paramStringBuilder) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.stringId);
    stringBuilder.append(":{\n");
    paramStringBuilder.append(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualWidth:");
    stringBuilder.append(this.mWidth);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualHeight:");
    stringBuilder.append(this.mHeight);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    Iterator<ConstraintWidget> iterator = getChildren().iterator();
    while (iterator.hasNext()) {
      ((ConstraintWidget)iterator.next()).getSceneString(paramStringBuilder);
      paramStringBuilder.append(",\n");
    } 
    paramStringBuilder.append("}");
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<ConstraintWidget> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        constraintWidget = constraintWidget;
        if (constraintWidget.getOrientation() == 1)
          arrayList.add(constraintWidget); 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #8
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: iconst_1
    //   52: aaload
    //   53: astore #16
    //   55: aload_0
    //   56: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   59: iconst_0
    //   60: aaload
    //   61: astore #17
    //   63: aload_0
    //   64: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   67: astore #18
    //   69: aload #18
    //   71: ifnull -> 86
    //   74: aload #18
    //   76: aload #18
    //   78: getfield layouts : J
    //   81: lconst_1
    //   82: ladd
    //   83: putfield layouts : J
    //   86: aload_0
    //   87: getfield pass : I
    //   90: ifne -> 269
    //   93: aload_0
    //   94: getfield mOptimizationLevel : I
    //   97: iconst_1
    //   98: invokestatic enabled : (II)Z
    //   101: ifeq -> 269
    //   104: aload_0
    //   105: aload_0
    //   106: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   109: invokestatic solvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V
    //   112: iconst_0
    //   113: istore_1
    //   114: iload_1
    //   115: iload #8
    //   117: if_icmpge -> 269
    //   120: aload_0
    //   121: getfield mChildren : Ljava/util/ArrayList;
    //   124: iload_1
    //   125: invokevirtual get : (I)Ljava/lang/Object;
    //   128: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   131: astore #18
    //   133: aload #18
    //   135: invokevirtual isMeasureRequested : ()Z
    //   138: ifeq -> 262
    //   141: aload #18
    //   143: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   146: ifne -> 262
    //   149: aload #18
    //   151: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   154: ifne -> 262
    //   157: aload #18
    //   159: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   162: ifne -> 262
    //   165: aload #18
    //   167: invokevirtual isInVirtualLayout : ()Z
    //   170: ifne -> 262
    //   173: aload #18
    //   175: iconst_0
    //   176: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   179: astore #19
    //   181: aload #18
    //   183: iconst_1
    //   184: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   187: astore #20
    //   189: aload #19
    //   191: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   194: if_acmpne -> 229
    //   197: aload #18
    //   199: getfield mMatchConstraintDefaultWidth : I
    //   202: iconst_1
    //   203: if_icmpeq -> 229
    //   206: aload #20
    //   208: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   211: if_acmpne -> 229
    //   214: aload #18
    //   216: getfield mMatchConstraintDefaultHeight : I
    //   219: iconst_1
    //   220: if_icmpeq -> 229
    //   223: iconst_1
    //   224: istore #4
    //   226: goto -> 232
    //   229: iconst_0
    //   230: istore #4
    //   232: iload #4
    //   234: ifne -> 262
    //   237: new androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure
    //   240: dup
    //   241: invokespecial <init> : ()V
    //   244: astore #19
    //   246: iconst_0
    //   247: aload #18
    //   249: aload_0
    //   250: getfield mMeasurer : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   253: aload #19
    //   255: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   258: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   261: pop
    //   262: iload_1
    //   263: iconst_1
    //   264: iadd
    //   265: istore_1
    //   266: goto -> 114
    //   269: iload #8
    //   271: iconst_2
    //   272: if_icmple -> 405
    //   275: aload #17
    //   277: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   280: if_acmpeq -> 291
    //   283: aload #16
    //   285: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   288: if_acmpne -> 405
    //   291: aload_0
    //   292: getfield mOptimizationLevel : I
    //   295: sipush #1024
    //   298: invokestatic enabled : (II)Z
    //   301: ifeq -> 405
    //   304: aload_0
    //   305: aload_0
    //   306: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   309: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   312: ifeq -> 405
    //   315: iload_2
    //   316: istore_1
    //   317: aload #17
    //   319: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   322: if_acmpne -> 357
    //   325: iload_2
    //   326: aload_0
    //   327: invokevirtual getWidth : ()I
    //   330: if_icmpge -> 352
    //   333: iload_2
    //   334: ifle -> 352
    //   337: aload_0
    //   338: iload_2
    //   339: invokevirtual setWidth : (I)V
    //   342: aload_0
    //   343: iconst_1
    //   344: putfield mWidthMeasuredTooSmall : Z
    //   347: iload_2
    //   348: istore_1
    //   349: goto -> 357
    //   352: aload_0
    //   353: invokevirtual getWidth : ()I
    //   356: istore_1
    //   357: iload_3
    //   358: istore_2
    //   359: aload #16
    //   361: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   364: if_acmpne -> 399
    //   367: iload_3
    //   368: aload_0
    //   369: invokevirtual getHeight : ()I
    //   372: if_icmpge -> 394
    //   375: iload_3
    //   376: ifle -> 394
    //   379: aload_0
    //   380: iload_3
    //   381: invokevirtual setHeight : (I)V
    //   384: aload_0
    //   385: iconst_1
    //   386: putfield mHeightMeasuredTooSmall : Z
    //   389: iload_3
    //   390: istore_2
    //   391: goto -> 399
    //   394: aload_0
    //   395: invokevirtual getHeight : ()I
    //   398: istore_2
    //   399: iconst_1
    //   400: istore #9
    //   402: goto -> 412
    //   405: iload_2
    //   406: istore_1
    //   407: iconst_0
    //   408: istore #9
    //   410: iload_3
    //   411: istore_2
    //   412: aload_0
    //   413: bipush #64
    //   415: invokevirtual optimizeFor : (I)Z
    //   418: ifne -> 439
    //   421: aload_0
    //   422: sipush #128
    //   425: invokevirtual optimizeFor : (I)Z
    //   428: ifeq -> 434
    //   431: goto -> 439
    //   434: iconst_0
    //   435: istore_3
    //   436: goto -> 441
    //   439: iconst_1
    //   440: istore_3
    //   441: aload_0
    //   442: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   445: iconst_0
    //   446: putfield graphOptimizer : Z
    //   449: aload_0
    //   450: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   453: iconst_0
    //   454: putfield newgraphOptimizer : Z
    //   457: aload_0
    //   458: getfield mOptimizationLevel : I
    //   461: ifeq -> 476
    //   464: iload_3
    //   465: ifeq -> 476
    //   468: aload_0
    //   469: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   472: iconst_1
    //   473: putfield newgraphOptimizer : Z
    //   476: aload_0
    //   477: getfield mChildren : Ljava/util/ArrayList;
    //   480: astore #18
    //   482: aload_0
    //   483: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   486: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   489: if_acmpeq -> 510
    //   492: aload_0
    //   493: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   496: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   499: if_acmpne -> 505
    //   502: goto -> 510
    //   505: iconst_0
    //   506: istore_3
    //   507: goto -> 512
    //   510: iconst_1
    //   511: istore_3
    //   512: aload_0
    //   513: invokespecial resetChains : ()V
    //   516: iconst_0
    //   517: istore #4
    //   519: iload #4
    //   521: iload #8
    //   523: if_icmpge -> 565
    //   526: aload_0
    //   527: getfield mChildren : Ljava/util/ArrayList;
    //   530: iload #4
    //   532: invokevirtual get : (I)Ljava/lang/Object;
    //   535: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   538: astore #19
    //   540: aload #19
    //   542: instanceof androidx/constraintlayout/core/widgets/WidgetContainer
    //   545: ifeq -> 556
    //   548: aload #19
    //   550: checkcast androidx/constraintlayout/core/widgets/WidgetContainer
    //   553: invokevirtual layout : ()V
    //   556: iload #4
    //   558: iconst_1
    //   559: iadd
    //   560: istore #4
    //   562: goto -> 519
    //   565: aload_0
    //   566: bipush #64
    //   568: invokevirtual optimizeFor : (I)Z
    //   571: istore #15
    //   573: iconst_0
    //   574: istore #4
    //   576: iconst_1
    //   577: istore #10
    //   579: iload #10
    //   581: ifeq -> 1594
    //   584: iload #4
    //   586: iconst_1
    //   587: iadd
    //   588: istore #7
    //   590: iload #10
    //   592: istore #11
    //   594: aload_0
    //   595: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   598: invokevirtual reset : ()V
    //   601: iload #10
    //   603: istore #11
    //   605: aload_0
    //   606: invokespecial resetChains : ()V
    //   609: iload #10
    //   611: istore #11
    //   613: aload_0
    //   614: aload_0
    //   615: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   618: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   621: iconst_0
    //   622: istore #4
    //   624: iload #4
    //   626: iload #8
    //   628: if_icmpge -> 663
    //   631: iload #10
    //   633: istore #11
    //   635: aload_0
    //   636: getfield mChildren : Ljava/util/ArrayList;
    //   639: iload #4
    //   641: invokevirtual get : (I)Ljava/lang/Object;
    //   644: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   647: aload_0
    //   648: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   651: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   654: iload #4
    //   656: iconst_1
    //   657: iadd
    //   658: istore #4
    //   660: goto -> 624
    //   663: iload #10
    //   665: istore #11
    //   667: aload_0
    //   668: aload_0
    //   669: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   672: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/core/LinearSystem;)Z
    //   675: istore #10
    //   677: iload #10
    //   679: istore #11
    //   681: aload_0
    //   682: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   685: astore #19
    //   687: aload #19
    //   689: ifnull -> 742
    //   692: iload #10
    //   694: istore #11
    //   696: aload #19
    //   698: invokevirtual get : ()Ljava/lang/Object;
    //   701: ifnull -> 742
    //   704: iload #10
    //   706: istore #11
    //   708: aload_0
    //   709: aload_0
    //   710: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   713: invokevirtual get : ()Ljava/lang/Object;
    //   716: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   719: aload_0
    //   720: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   723: aload_0
    //   724: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   727: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   730: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   733: iload #10
    //   735: istore #11
    //   737: aload_0
    //   738: aconst_null
    //   739: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   742: iload #10
    //   744: istore #11
    //   746: aload_0
    //   747: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   750: astore #19
    //   752: aload #19
    //   754: ifnull -> 807
    //   757: iload #10
    //   759: istore #11
    //   761: aload #19
    //   763: invokevirtual get : ()Ljava/lang/Object;
    //   766: ifnull -> 807
    //   769: iload #10
    //   771: istore #11
    //   773: aload_0
    //   774: aload_0
    //   775: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   778: invokevirtual get : ()Ljava/lang/Object;
    //   781: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   784: aload_0
    //   785: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   788: aload_0
    //   789: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   792: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   795: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   798: iload #10
    //   800: istore #11
    //   802: aload_0
    //   803: aconst_null
    //   804: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   807: iload #10
    //   809: istore #11
    //   811: aload_0
    //   812: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   815: astore #19
    //   817: aload #19
    //   819: ifnull -> 872
    //   822: iload #10
    //   824: istore #11
    //   826: aload #19
    //   828: invokevirtual get : ()Ljava/lang/Object;
    //   831: ifnull -> 872
    //   834: iload #10
    //   836: istore #11
    //   838: aload_0
    //   839: aload_0
    //   840: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   843: invokevirtual get : ()Ljava/lang/Object;
    //   846: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   849: aload_0
    //   850: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   853: aload_0
    //   854: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   857: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   860: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   863: iload #10
    //   865: istore #11
    //   867: aload_0
    //   868: aconst_null
    //   869: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   872: iload #10
    //   874: istore #11
    //   876: aload_0
    //   877: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   880: astore #19
    //   882: aload #19
    //   884: ifnull -> 937
    //   887: iload #10
    //   889: istore #11
    //   891: aload #19
    //   893: invokevirtual get : ()Ljava/lang/Object;
    //   896: ifnull -> 937
    //   899: iload #10
    //   901: istore #11
    //   903: aload_0
    //   904: aload_0
    //   905: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   908: invokevirtual get : ()Ljava/lang/Object;
    //   911: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   914: aload_0
    //   915: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   918: aload_0
    //   919: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   922: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   925: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   928: iload #10
    //   930: istore #11
    //   932: aload_0
    //   933: aconst_null
    //   934: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   937: iload #10
    //   939: istore #11
    //   941: iload #10
    //   943: ifeq -> 1012
    //   946: iload #10
    //   948: istore #11
    //   950: aload_0
    //   951: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   954: invokevirtual minimize : ()V
    //   957: iload #10
    //   959: istore #11
    //   961: goto -> 1012
    //   964: astore #19
    //   966: aload #19
    //   968: invokevirtual printStackTrace : ()V
    //   971: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   974: astore #20
    //   976: new java/lang/StringBuilder
    //   979: dup
    //   980: invokespecial <init> : ()V
    //   983: astore #21
    //   985: aload #21
    //   987: ldc_w 'EXCEPTION : '
    //   990: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   993: pop
    //   994: aload #21
    //   996: aload #19
    //   998: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1001: pop
    //   1002: aload #20
    //   1004: aload #21
    //   1006: invokevirtual toString : ()Ljava/lang/String;
    //   1009: invokevirtual println : (Ljava/lang/String;)V
    //   1012: iload #11
    //   1014: ifeq -> 1033
    //   1017: aload_0
    //   1018: aload_0
    //   1019: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1022: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1025: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/core/LinearSystem;[Z)Z
    //   1028: istore #10
    //   1030: goto -> 1086
    //   1033: aload_0
    //   1034: aload_0
    //   1035: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1038: iload #15
    //   1040: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1043: iconst_0
    //   1044: istore #4
    //   1046: iload #4
    //   1048: iload #8
    //   1050: if_icmpge -> 1083
    //   1053: aload_0
    //   1054: getfield mChildren : Ljava/util/ArrayList;
    //   1057: iload #4
    //   1059: invokevirtual get : (I)Ljava/lang/Object;
    //   1062: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1065: aload_0
    //   1066: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1069: iload #15
    //   1071: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1074: iload #4
    //   1076: iconst_1
    //   1077: iadd
    //   1078: istore #4
    //   1080: goto -> 1046
    //   1083: iconst_0
    //   1084: istore #10
    //   1086: iload_3
    //   1087: ifeq -> 1313
    //   1090: iload #7
    //   1092: bipush #8
    //   1094: if_icmpge -> 1313
    //   1097: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1100: iconst_2
    //   1101: baload
    //   1102: ifeq -> 1313
    //   1105: iconst_0
    //   1106: istore #5
    //   1108: iconst_0
    //   1109: istore #4
    //   1111: iconst_0
    //   1112: istore #6
    //   1114: iload #5
    //   1116: iload #8
    //   1118: if_icmpge -> 1180
    //   1121: aload_0
    //   1122: getfield mChildren : Ljava/util/ArrayList;
    //   1125: iload #5
    //   1127: invokevirtual get : (I)Ljava/lang/Object;
    //   1130: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1133: astore #19
    //   1135: iload #6
    //   1137: aload #19
    //   1139: getfield mX : I
    //   1142: aload #19
    //   1144: invokevirtual getWidth : ()I
    //   1147: iadd
    //   1148: invokestatic max : (II)I
    //   1151: istore #6
    //   1153: iload #4
    //   1155: aload #19
    //   1157: getfield mY : I
    //   1160: aload #19
    //   1162: invokevirtual getHeight : ()I
    //   1165: iadd
    //   1166: invokestatic max : (II)I
    //   1169: istore #4
    //   1171: iload #5
    //   1173: iconst_1
    //   1174: iadd
    //   1175: istore #5
    //   1177: goto -> 1114
    //   1180: aload_0
    //   1181: getfield mMinWidth : I
    //   1184: iload #6
    //   1186: invokestatic max : (II)I
    //   1189: istore #5
    //   1191: aload_0
    //   1192: getfield mMinHeight : I
    //   1195: iload #4
    //   1197: invokestatic max : (II)I
    //   1200: istore #4
    //   1202: iload #9
    //   1204: istore #12
    //   1206: iload #10
    //   1208: istore #11
    //   1210: aload #17
    //   1212: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1215: if_acmpne -> 1256
    //   1218: iload #9
    //   1220: istore #12
    //   1222: iload #10
    //   1224: istore #11
    //   1226: aload_0
    //   1227: invokevirtual getWidth : ()I
    //   1230: iload #5
    //   1232: if_icmpge -> 1256
    //   1235: aload_0
    //   1236: iload #5
    //   1238: invokevirtual setWidth : (I)V
    //   1241: aload_0
    //   1242: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1245: iconst_0
    //   1246: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1249: aastore
    //   1250: iconst_1
    //   1251: istore #12
    //   1253: iconst_1
    //   1254: istore #11
    //   1256: iload #12
    //   1258: istore #9
    //   1260: iload #11
    //   1262: istore #10
    //   1264: aload #16
    //   1266: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1269: if_acmpne -> 1313
    //   1272: iload #12
    //   1274: istore #9
    //   1276: iload #11
    //   1278: istore #10
    //   1280: aload_0
    //   1281: invokevirtual getHeight : ()I
    //   1284: iload #4
    //   1286: if_icmpge -> 1313
    //   1289: aload_0
    //   1290: iload #4
    //   1292: invokevirtual setHeight : (I)V
    //   1295: aload_0
    //   1296: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1299: iconst_1
    //   1300: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1303: aastore
    //   1304: iconst_1
    //   1305: istore #9
    //   1307: iconst_1
    //   1308: istore #10
    //   1310: goto -> 1313
    //   1313: aload_0
    //   1314: getfield mMinWidth : I
    //   1317: aload_0
    //   1318: invokevirtual getWidth : ()I
    //   1321: invokestatic max : (II)I
    //   1324: istore #4
    //   1326: iload #4
    //   1328: aload_0
    //   1329: invokevirtual getWidth : ()I
    //   1332: if_icmple -> 1356
    //   1335: aload_0
    //   1336: iload #4
    //   1338: invokevirtual setWidth : (I)V
    //   1341: aload_0
    //   1342: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1345: iconst_0
    //   1346: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1349: aastore
    //   1350: iconst_1
    //   1351: istore #9
    //   1353: iconst_1
    //   1354: istore #10
    //   1356: aload_0
    //   1357: getfield mMinHeight : I
    //   1360: aload_0
    //   1361: invokevirtual getHeight : ()I
    //   1364: invokestatic max : (II)I
    //   1367: istore #4
    //   1369: iload #4
    //   1371: aload_0
    //   1372: invokevirtual getHeight : ()I
    //   1375: if_icmple -> 1403
    //   1378: aload_0
    //   1379: iload #4
    //   1381: invokevirtual setHeight : (I)V
    //   1384: aload_0
    //   1385: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1388: iconst_1
    //   1389: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1392: aastore
    //   1393: iconst_1
    //   1394: istore #9
    //   1396: iload #9
    //   1398: istore #10
    //   1400: goto -> 1403
    //   1403: iload #9
    //   1405: istore #12
    //   1407: iload #10
    //   1409: istore #14
    //   1411: iload #9
    //   1413: ifne -> 1566
    //   1416: iload #9
    //   1418: istore #13
    //   1420: iload #10
    //   1422: istore #11
    //   1424: aload_0
    //   1425: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1428: iconst_0
    //   1429: aaload
    //   1430: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1433: if_acmpne -> 1490
    //   1436: iload #9
    //   1438: istore #13
    //   1440: iload #10
    //   1442: istore #11
    //   1444: iload_1
    //   1445: ifle -> 1490
    //   1448: iload #9
    //   1450: istore #13
    //   1452: iload #10
    //   1454: istore #11
    //   1456: aload_0
    //   1457: invokevirtual getWidth : ()I
    //   1460: iload_1
    //   1461: if_icmple -> 1490
    //   1464: aload_0
    //   1465: iconst_1
    //   1466: putfield mWidthMeasuredTooSmall : Z
    //   1469: aload_0
    //   1470: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1473: iconst_0
    //   1474: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1477: aastore
    //   1478: aload_0
    //   1479: iload_1
    //   1480: invokevirtual setWidth : (I)V
    //   1483: iconst_1
    //   1484: istore #13
    //   1486: iload #13
    //   1488: istore #11
    //   1490: iload #13
    //   1492: istore #12
    //   1494: iload #11
    //   1496: istore #14
    //   1498: aload_0
    //   1499: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1502: iconst_1
    //   1503: aaload
    //   1504: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1507: if_acmpne -> 1566
    //   1510: iload #13
    //   1512: istore #12
    //   1514: iload #11
    //   1516: istore #14
    //   1518: iload_2
    //   1519: ifle -> 1566
    //   1522: iload #13
    //   1524: istore #12
    //   1526: iload #11
    //   1528: istore #14
    //   1530: aload_0
    //   1531: invokevirtual getHeight : ()I
    //   1534: iload_2
    //   1535: if_icmple -> 1566
    //   1538: aload_0
    //   1539: iconst_1
    //   1540: putfield mHeightMeasuredTooSmall : Z
    //   1543: aload_0
    //   1544: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1547: iconst_1
    //   1548: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1551: aastore
    //   1552: aload_0
    //   1553: iload_2
    //   1554: invokevirtual setHeight : (I)V
    //   1557: iconst_1
    //   1558: istore #10
    //   1560: iconst_1
    //   1561: istore #9
    //   1563: goto -> 1574
    //   1566: iload #14
    //   1568: istore #10
    //   1570: iload #12
    //   1572: istore #9
    //   1574: iload #7
    //   1576: bipush #8
    //   1578: if_icmple -> 1587
    //   1581: iconst_0
    //   1582: istore #10
    //   1584: goto -> 1587
    //   1587: iload #7
    //   1589: istore #4
    //   1591: goto -> 579
    //   1594: aload #18
    //   1596: checkcast java/util/ArrayList
    //   1599: astore #19
    //   1601: aload_0
    //   1602: aload #18
    //   1604: putfield mChildren : Ljava/util/ArrayList;
    //   1607: iload #9
    //   1609: ifeq -> 1628
    //   1612: aload_0
    //   1613: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1616: iconst_0
    //   1617: aload #17
    //   1619: aastore
    //   1620: aload_0
    //   1621: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1624: iconst_1
    //   1625: aload #16
    //   1627: aastore
    //   1628: aload_0
    //   1629: aload_0
    //   1630: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1633: invokevirtual getCache : ()Landroidx/constraintlayout/core/Cache;
    //   1636: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/core/Cache;)V
    //   1639: return
    // Exception table:
    //   from	to	target	type
    //   594	601	964	java/lang/Exception
    //   605	609	964	java/lang/Exception
    //   613	621	964	java/lang/Exception
    //   635	654	964	java/lang/Exception
    //   667	677	964	java/lang/Exception
    //   681	687	964	java/lang/Exception
    //   696	704	964	java/lang/Exception
    //   708	733	964	java/lang/Exception
    //   737	742	964	java/lang/Exception
    //   746	752	964	java/lang/Exception
    //   761	769	964	java/lang/Exception
    //   773	798	964	java/lang/Exception
    //   802	807	964	java/lang/Exception
    //   811	817	964	java/lang/Exception
    //   826	834	964	java/lang/Exception
    //   838	863	964	java/lang/Exception
    //   867	872	964	java/lang/Exception
    //   876	882	964	java/lang/Exception
    //   891	899	964	java/lang/Exception
    //   903	928	964	java/lang/Exception
    //   932	937	964	java/lang/Exception
    //   950	957	964	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setPass(int paramInt) {
    this.pass = paramInt;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public boolean updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool1 = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.updateFromSolver(paramLinearSystem, bool1);
      if (constraintWidget.hasDimensionOverride())
        bool = true; 
      i++;
    } 
    return bool;
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */