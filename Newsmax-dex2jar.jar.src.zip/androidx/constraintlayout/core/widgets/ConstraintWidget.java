package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.Cache;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.state.WidgetFrame;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.HorizontalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.VerticalWidgetRun;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidget {
  public static final int ANCHOR_BASELINE = 4;
  
  public static final int ANCHOR_BOTTOM = 3;
  
  public static final int ANCHOR_LEFT = 0;
  
  public static final int ANCHOR_RIGHT = 1;
  
  public static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int BOTH = 2;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  private static final boolean USE_WRAP_DIMENSION_FOR_SPREAD = false;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  public static final int WRAP_BEHAVIOR_HORIZONTAL_ONLY = 1;
  
  public static final int WRAP_BEHAVIOR_INCLUDED = 0;
  
  public static final int WRAP_BEHAVIOR_SKIPPED = 3;
  
  public static final int WRAP_BEHAVIOR_VERTICAL_ONLY = 2;
  
  private boolean OPTIMIZE_WRAP = false;
  
  private boolean OPTIMIZE_WRAP_ON_RESOLVED = true;
  
  public WidgetFrame frame = new WidgetFrame(this);
  
  private boolean hasBaseline = false;
  
  public ChainRun horizontalChainRun;
  
  public int horizontalGroup;
  
  public HorizontalWidgetRun horizontalRun = null;
  
  private boolean horizontalSolvingPass = false;
  
  private boolean inPlaceholder;
  
  public boolean[] isTerminalWidget = new boolean[] { true, true };
  
  protected ArrayList<ConstraintAnchor> mAnchors;
  
  private boolean mAnimated;
  
  public ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance;
  
  public ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  public ConstraintAnchor mCenter;
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  public float mDimensionRatio;
  
  protected int mDimensionRatioSide;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  boolean mGroupsToSolver;
  
  int mHeight;
  
  private int mHeightOverride = -1;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  private boolean mInVirtualLayout = false;
  
  public boolean mIsHeightWrapContent;
  
  private boolean[] mIsInBarrier;
  
  public boolean mIsWidthWrapContent;
  
  private int mLastHorizontalMeasureSpec = 0;
  
  private int mLastVerticalMeasureSpec = 0;
  
  public ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  public ConstraintAnchor[] mListAnchors;
  
  public DimensionBehaviour[] mListDimensionBehaviors;
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  public int mMatchConstraintDefaultHeight = 0;
  
  public int mMatchConstraintDefaultWidth = 0;
  
  public int mMatchConstraintMaxHeight = 0;
  
  public int mMatchConstraintMaxWidth = 0;
  
  public int mMatchConstraintMinHeight = 0;
  
  public int mMatchConstraintMinWidth = 0;
  
  public float mMatchConstraintPercentHeight = 1.0F;
  
  public float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private boolean mMeasureRequested = true;
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX;
  
  protected int mOffsetY;
  
  public ConstraintWidget mParent;
  
  int mRelX;
  
  int mRelY;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  boolean mResolvedHasRatio = false;
  
  public int[] mResolvedMatchConstraintDefault = new int[2];
  
  public ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  public ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  public float[] mWeight;
  
  int mWidth;
  
  private int mWidthOverride = -1;
  
  private int mWrapBehaviorInParent = 0;
  
  protected int mX;
  
  protected int mY;
  
  public boolean measured = false;
  
  private boolean resolvedHorizontal = false;
  
  private boolean resolvedVertical = false;
  
  public WidgetRun[] run = new WidgetRun[2];
  
  public String stringId;
  
  public ChainRun verticalChainRun;
  
  public int verticalGroup;
  
  public VerticalWidgetRun verticalRun = null;
  
  private boolean verticalSolvingPass = false;
  
  public ConstraintWidget() {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
  }
  
  public ConstraintWidget(String paramString) {
    ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
    this.mCenter = constraintAnchor;
    this.mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, constraintAnchor };
    this.mAnchors = new ArrayList<ConstraintAnchor>();
    this.mIsInBarrier = new boolean[2];
    this.mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
    this.mParent = null;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mRelX = 0;
    this.mRelY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mAnimated = false;
    this.mDebugName = null;
    this.mType = null;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.horizontalGroup = -1;
    this.verticalGroup = -1;
    addAnchors();
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  public ConstraintWidget(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(paramInt1, paramInt2, paramInt3, paramInt4);
    setDebugName(paramString);
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean5, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private void getSceneString(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "      size", paramInt1, 0);
    serializeAttribute(paramStringBuilder, "      min", paramInt2, 0);
    serializeAttribute(paramStringBuilder, "      max", paramInt3, 2147483647);
    serializeAttribute(paramStringBuilder, "      matchMin", paramInt5, 0);
    serializeAttribute(paramStringBuilder, "      matchDef", paramInt6, 0);
    serializeAttribute(paramStringBuilder, "      matchPercent", paramFloat1, 1.0F);
    paramStringBuilder.append("    },\n");
  }
  
  private void getSceneString(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("    ");
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("'");
    if (paramConstraintAnchor.mGoneMargin != Integer.MIN_VALUE || paramConstraintAnchor.mMargin != 0) {
      paramStringBuilder.append(",");
      paramStringBuilder.append(paramConstraintAnchor.mMargin);
      if (paramConstraintAnchor.mGoneMargin != Integer.MIN_VALUE) {
        paramStringBuilder.append(",");
        paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
        paramStringBuilder.append(",");
      } 
    } 
    paramStringBuilder.append(" ] ,\n");
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    if ((this.mListAnchors[paramInt]).mTarget != null) {
      ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return true;  
    } 
    return false;
  }
  
  private void serializeAnchor(StringBuilder paramStringBuilder, String paramString, ConstraintAnchor paramConstraintAnchor) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramConstraintAnchor.mGoneMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, float paramFloat1, float paramFloat2) {
    if (paramFloat1 == paramFloat2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramFloat1);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeAttribute(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :   ");
    paramStringBuilder.append(paramInt1);
    paramStringBuilder.append(",\n");
  }
  
  private void serializeCircle(StringBuilder paramStringBuilder, ConstraintAnchor paramConstraintAnchor, float paramFloat) {
    if (paramConstraintAnchor.mTarget == null)
      return; 
    paramStringBuilder.append("circle : [ '");
    paramStringBuilder.append(paramConstraintAnchor.mTarget);
    paramStringBuilder.append("',");
    paramStringBuilder.append(paramConstraintAnchor.mMargin);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(" ] ,\n");
  }
  
  private void serializeDimensionRatio(StringBuilder paramStringBuilder, String paramString, float paramFloat, int paramInt) {
    if (paramFloat == 0.0F)
      return; 
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  [");
    paramStringBuilder.append(paramFloat);
    paramStringBuilder.append(",");
    paramStringBuilder.append(paramInt);
    paramStringBuilder.append("");
    paramStringBuilder.append("],\n");
  }
  
  private void serializeSize(StringBuilder paramStringBuilder, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
    paramStringBuilder.append(paramString);
    paramStringBuilder.append(" :  {\n");
    serializeAttribute(paramStringBuilder, "size", paramInt1, -2147483648);
    serializeAttribute(paramStringBuilder, "min", paramInt2, 0);
    serializeAttribute(paramStringBuilder, "max", paramInt3, 2147483647);
    serializeAttribute(paramStringBuilder, "matchMin", paramInt5, 0);
    serializeAttribute(paramStringBuilder, "matchDef", paramInt6, 0);
    serializeAttribute(paramStringBuilder, "matchPercent", paramInt6, 1);
    paramStringBuilder.append("},\n");
  }
  
  public void addChildrenToSolverByDependency(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, HashSet<ConstraintWidget> paramHashSet, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      if (!paramHashSet.contains(this))
        return; 
      Optimizer.checkMatchParent(paramConstraintWidgetContainer, paramLinearSystem, this);
      paramHashSet.remove(this);
      addToSolver(paramLinearSystem, paramConstraintWidgetContainer.optimizeFor(64));
    } 
    if (paramInt == 0) {
      HashSet<ConstraintAnchor> hashSet = this.mLeft.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mRight.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
    } else {
      HashSet<ConstraintAnchor> hashSet = this.mTop.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBottom.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (iterator.hasNext())
          ((ConstraintAnchor)iterator.next()).mOwner.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true); 
      } 
      hashSet = this.mBaseline.getDependents();
      if (hashSet != null) {
        Iterator<ConstraintAnchor> iterator = hashSet.iterator();
        while (true) {
          if (iterator.hasNext()) {
            ConstraintWidget constraintWidget = ((ConstraintAnchor)iterator.next()).mOwner;
            try {
              constraintWidget.addChildrenToSolverByDependency(paramConstraintWidgetContainer, paramLinearSystem, paramHashSet, paramInt, true);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  boolean addFirst() {
    return (this instanceof VirtualLayout || this instanceof Guideline);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   8: astore #28
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   18: astore #27
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   28: astore #30
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   38: astore #29
    //   40: aload_1
    //   41: aload_0
    //   42: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   45: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   48: astore #26
    //   50: aload_0
    //   51: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   54: astore #24
    //   56: aload #24
    //   58: ifnull -> 184
    //   61: aload #24
    //   63: ifnull -> 85
    //   66: aload #24
    //   68: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   71: iconst_0
    //   72: aaload
    //   73: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   76: if_acmpne -> 85
    //   79: iconst_1
    //   80: istore #11
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   92: astore #24
    //   94: aload #24
    //   96: ifnull -> 118
    //   99: aload #24
    //   101: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: iconst_1
    //   105: aaload
    //   106: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   109: if_acmpne -> 118
    //   112: iconst_1
    //   113: istore #12
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #12
    //   121: aload_0
    //   122: getfield mWrapBehaviorInParent : I
    //   125: istore #4
    //   127: iload #4
    //   129: iconst_1
    //   130: if_icmpeq -> 170
    //   133: iload #4
    //   135: iconst_2
    //   136: if_icmpeq -> 160
    //   139: iload #4
    //   141: iconst_3
    //   142: if_icmpeq -> 184
    //   145: iload #12
    //   147: istore #13
    //   149: iload #11
    //   151: istore #12
    //   153: iload #13
    //   155: istore #11
    //   157: goto -> 191
    //   160: iload #12
    //   162: istore #11
    //   164: iconst_0
    //   165: istore #12
    //   167: goto -> 191
    //   170: iconst_0
    //   171: istore #13
    //   173: iload #11
    //   175: istore #12
    //   177: iload #13
    //   179: istore #11
    //   181: goto -> 191
    //   184: iconst_0
    //   185: istore #12
    //   187: iload #12
    //   189: istore #11
    //   191: aload_0
    //   192: getfield mVisibility : I
    //   195: bipush #8
    //   197: if_icmpne -> 235
    //   200: aload_0
    //   201: getfield mAnimated : Z
    //   204: ifne -> 235
    //   207: aload_0
    //   208: invokevirtual hasDependencies : ()Z
    //   211: ifne -> 235
    //   214: aload_0
    //   215: getfield mIsInBarrier : [Z
    //   218: astore #24
    //   220: aload #24
    //   222: iconst_0
    //   223: baload
    //   224: ifne -> 235
    //   227: aload #24
    //   229: iconst_1
    //   230: baload
    //   231: ifne -> 235
    //   234: return
    //   235: aload_0
    //   236: getfield resolvedHorizontal : Z
    //   239: istore #13
    //   241: iload #13
    //   243: ifne -> 253
    //   246: aload_0
    //   247: getfield resolvedVertical : Z
    //   250: ifeq -> 501
    //   253: iload #13
    //   255: ifeq -> 351
    //   258: aload_1
    //   259: aload #28
    //   261: aload_0
    //   262: getfield mX : I
    //   265: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   268: aload_1
    //   269: aload #27
    //   271: aload_0
    //   272: getfield mX : I
    //   275: aload_0
    //   276: getfield mWidth : I
    //   279: iadd
    //   280: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   283: iload #12
    //   285: ifeq -> 351
    //   288: aload_0
    //   289: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   292: astore #24
    //   294: aload #24
    //   296: ifnull -> 351
    //   299: aload_0
    //   300: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   303: ifeq -> 334
    //   306: aload #24
    //   308: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   311: astore #24
    //   313: aload #24
    //   315: aload_0
    //   316: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   319: invokevirtual addHorizontalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   322: aload #24
    //   324: aload_0
    //   325: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   328: invokevirtual addHorizontalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   331: goto -> 351
    //   334: aload_1
    //   335: aload_1
    //   336: aload #24
    //   338: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   341: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   344: aload #27
    //   346: iconst_0
    //   347: iconst_5
    //   348: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   351: aload_0
    //   352: getfield resolvedVertical : Z
    //   355: ifeq -> 476
    //   358: aload_1
    //   359: aload #30
    //   361: aload_0
    //   362: getfield mY : I
    //   365: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   368: aload_1
    //   369: aload #29
    //   371: aload_0
    //   372: getfield mY : I
    //   375: aload_0
    //   376: getfield mHeight : I
    //   379: iadd
    //   380: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   383: aload_0
    //   384: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   387: invokevirtual hasDependents : ()Z
    //   390: ifeq -> 408
    //   393: aload_1
    //   394: aload #26
    //   396: aload_0
    //   397: getfield mY : I
    //   400: aload_0
    //   401: getfield mBaselineDistance : I
    //   404: iadd
    //   405: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   408: iload #11
    //   410: ifeq -> 476
    //   413: aload_0
    //   414: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   417: astore #24
    //   419: aload #24
    //   421: ifnull -> 476
    //   424: aload_0
    //   425: getfield OPTIMIZE_WRAP_ON_RESOLVED : Z
    //   428: ifeq -> 459
    //   431: aload #24
    //   433: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   436: astore #24
    //   438: aload #24
    //   440: aload_0
    //   441: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   444: invokevirtual addVerticalWrapMinVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   447: aload #24
    //   449: aload_0
    //   450: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   453: invokevirtual addVerticalWrapMaxVariable : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;)V
    //   456: goto -> 476
    //   459: aload_1
    //   460: aload_1
    //   461: aload #24
    //   463: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   466: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   469: aload #29
    //   471: iconst_0
    //   472: iconst_5
    //   473: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   476: aload_0
    //   477: getfield resolvedHorizontal : Z
    //   480: ifeq -> 501
    //   483: aload_0
    //   484: getfield resolvedVertical : Z
    //   487: ifeq -> 501
    //   490: aload_0
    //   491: iconst_0
    //   492: putfield resolvedHorizontal : Z
    //   495: aload_0
    //   496: iconst_0
    //   497: putfield resolvedVertical : Z
    //   500: return
    //   501: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   504: ifnull -> 524
    //   507: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   510: astore #24
    //   512: aload #24
    //   514: aload #24
    //   516: getfield widgets : J
    //   519: lconst_1
    //   520: ladd
    //   521: putfield widgets : J
    //   524: iload_2
    //   525: ifeq -> 799
    //   528: aload_0
    //   529: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   532: astore #24
    //   534: aload #24
    //   536: ifnull -> 799
    //   539: aload_0
    //   540: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   543: ifnull -> 799
    //   546: aload #24
    //   548: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   551: getfield resolved : Z
    //   554: ifeq -> 799
    //   557: aload_0
    //   558: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   561: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   564: getfield resolved : Z
    //   567: ifeq -> 799
    //   570: aload_0
    //   571: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   574: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   577: getfield resolved : Z
    //   580: ifeq -> 799
    //   583: aload_0
    //   584: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   587: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   590: getfield resolved : Z
    //   593: ifeq -> 799
    //   596: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   599: ifnull -> 619
    //   602: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   605: astore #24
    //   607: aload #24
    //   609: aload #24
    //   611: getfield graphSolved : J
    //   614: lconst_1
    //   615: ladd
    //   616: putfield graphSolved : J
    //   619: aload_1
    //   620: aload #28
    //   622: aload_0
    //   623: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   626: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   629: getfield value : I
    //   632: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   635: aload_1
    //   636: aload #27
    //   638: aload_0
    //   639: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   642: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   645: getfield value : I
    //   648: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   651: aload_1
    //   652: aload #30
    //   654: aload_0
    //   655: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   658: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   661: getfield value : I
    //   664: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   667: aload_1
    //   668: aload #29
    //   670: aload_0
    //   671: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   674: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   677: getfield value : I
    //   680: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   683: aload_1
    //   684: aload #26
    //   686: aload_0
    //   687: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   690: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   693: getfield value : I
    //   696: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   699: aload_0
    //   700: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   703: ifnull -> 788
    //   706: iload #12
    //   708: ifeq -> 747
    //   711: aload_0
    //   712: getfield isTerminalWidget : [Z
    //   715: iconst_0
    //   716: baload
    //   717: ifeq -> 747
    //   720: aload_0
    //   721: invokevirtual isInHorizontalChain : ()Z
    //   724: ifne -> 747
    //   727: aload_1
    //   728: aload_1
    //   729: aload_0
    //   730: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   733: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   736: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   739: aload #27
    //   741: iconst_0
    //   742: bipush #8
    //   744: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   747: iload #11
    //   749: ifeq -> 788
    //   752: aload_0
    //   753: getfield isTerminalWidget : [Z
    //   756: iconst_1
    //   757: baload
    //   758: ifeq -> 788
    //   761: aload_0
    //   762: invokevirtual isInVerticalChain : ()Z
    //   765: ifne -> 788
    //   768: aload_1
    //   769: aload_1
    //   770: aload_0
    //   771: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   774: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   777: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   780: aload #29
    //   782: iconst_0
    //   783: bipush #8
    //   785: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   788: aload_0
    //   789: iconst_0
    //   790: putfield resolvedHorizontal : Z
    //   793: aload_0
    //   794: iconst_0
    //   795: putfield resolvedVertical : Z
    //   798: return
    //   799: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   802: ifnull -> 822
    //   805: getstatic androidx/constraintlayout/core/LinearSystem.sMetrics : Landroidx/constraintlayout/core/Metrics;
    //   808: astore #24
    //   810: aload #24
    //   812: aload #24
    //   814: getfield linearSolved : J
    //   817: lconst_1
    //   818: ladd
    //   819: putfield linearSolved : J
    //   822: aload_0
    //   823: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   826: ifnull -> 1023
    //   829: aload_0
    //   830: iconst_0
    //   831: invokespecial isChainHead : (I)Z
    //   834: ifeq -> 855
    //   837: aload_0
    //   838: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   841: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   844: aload_0
    //   845: iconst_0
    //   846: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   849: iconst_1
    //   850: istore #13
    //   852: goto -> 861
    //   855: aload_0
    //   856: invokevirtual isInHorizontalChain : ()Z
    //   859: istore #13
    //   861: aload_0
    //   862: iconst_1
    //   863: invokespecial isChainHead : (I)Z
    //   866: ifeq -> 887
    //   869: aload_0
    //   870: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   873: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   876: aload_0
    //   877: iconst_1
    //   878: invokevirtual addChain : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)V
    //   881: iconst_1
    //   882: istore #14
    //   884: goto -> 893
    //   887: aload_0
    //   888: invokevirtual isInVerticalChain : ()Z
    //   891: istore #14
    //   893: iload #13
    //   895: ifne -> 951
    //   898: iload #12
    //   900: ifeq -> 951
    //   903: aload_0
    //   904: getfield mVisibility : I
    //   907: bipush #8
    //   909: if_icmpeq -> 951
    //   912: aload_0
    //   913: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   916: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   919: ifnonnull -> 951
    //   922: aload_0
    //   923: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   926: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   929: ifnonnull -> 951
    //   932: aload_1
    //   933: aload_1
    //   934: aload_0
    //   935: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   938: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   941: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   944: aload #27
    //   946: iconst_0
    //   947: iconst_1
    //   948: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   951: iload #14
    //   953: ifne -> 1016
    //   956: iload #11
    //   958: ifeq -> 1016
    //   961: aload_0
    //   962: getfield mVisibility : I
    //   965: bipush #8
    //   967: if_icmpeq -> 1016
    //   970: aload_0
    //   971: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   974: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   977: ifnonnull -> 1016
    //   980: aload_0
    //   981: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   984: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   987: ifnonnull -> 1016
    //   990: aload_0
    //   991: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   994: ifnonnull -> 1016
    //   997: aload_1
    //   998: aload_1
    //   999: aload_0
    //   1000: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1003: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1006: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1009: aload #29
    //   1011: iconst_0
    //   1012: iconst_1
    //   1013: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1016: iload #13
    //   1018: istore #15
    //   1020: goto -> 1030
    //   1023: iconst_0
    //   1024: istore #14
    //   1026: iload #14
    //   1028: istore #15
    //   1030: aload_0
    //   1031: getfield mWidth : I
    //   1034: istore #4
    //   1036: aload_0
    //   1037: getfield mMinWidth : I
    //   1040: istore #5
    //   1042: iload #4
    //   1044: istore #6
    //   1046: iload #4
    //   1048: iload #5
    //   1050: if_icmpge -> 1057
    //   1053: iload #5
    //   1055: istore #6
    //   1057: aload_0
    //   1058: getfield mHeight : I
    //   1061: istore #4
    //   1063: aload_0
    //   1064: getfield mMinHeight : I
    //   1067: istore #7
    //   1069: iload #4
    //   1071: istore #5
    //   1073: iload #4
    //   1075: iload #7
    //   1077: if_icmpge -> 1084
    //   1080: iload #7
    //   1082: istore #5
    //   1084: aload_0
    //   1085: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1088: iconst_0
    //   1089: aaload
    //   1090: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1093: if_acmpeq -> 1102
    //   1096: iconst_1
    //   1097: istore #13
    //   1099: goto -> 1105
    //   1102: iconst_0
    //   1103: istore #13
    //   1105: aload_0
    //   1106: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1109: iconst_1
    //   1110: aaload
    //   1111: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1114: if_acmpeq -> 1123
    //   1117: iconst_1
    //   1118: istore #16
    //   1120: goto -> 1126
    //   1123: iconst_0
    //   1124: istore #16
    //   1126: aload_0
    //   1127: aload_0
    //   1128: getfield mDimensionRatioSide : I
    //   1131: putfield mResolvedDimensionRatioSide : I
    //   1134: aload_0
    //   1135: getfield mDimensionRatio : F
    //   1138: fstore_3
    //   1139: aload_0
    //   1140: fload_3
    //   1141: putfield mResolvedDimensionRatio : F
    //   1144: aload_0
    //   1145: getfield mMatchConstraintDefaultWidth : I
    //   1148: istore #7
    //   1150: aload_0
    //   1151: getfield mMatchConstraintDefaultHeight : I
    //   1154: istore #8
    //   1156: fload_3
    //   1157: fconst_0
    //   1158: fcmpl
    //   1159: ifle -> 1500
    //   1162: aload_0
    //   1163: getfield mVisibility : I
    //   1166: bipush #8
    //   1168: if_icmpeq -> 1500
    //   1171: iload #7
    //   1173: istore #4
    //   1175: aload_0
    //   1176: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1179: iconst_0
    //   1180: aaload
    //   1181: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1184: if_acmpne -> 1199
    //   1187: iload #7
    //   1189: istore #4
    //   1191: iload #7
    //   1193: ifne -> 1199
    //   1196: iconst_3
    //   1197: istore #4
    //   1199: iload #8
    //   1201: istore #7
    //   1203: aload_0
    //   1204: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1207: iconst_1
    //   1208: aaload
    //   1209: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1212: if_acmpne -> 1227
    //   1215: iload #8
    //   1217: istore #7
    //   1219: iload #8
    //   1221: ifne -> 1227
    //   1224: iconst_3
    //   1225: istore #7
    //   1227: aload_0
    //   1228: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1231: iconst_0
    //   1232: aaload
    //   1233: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1236: if_acmpne -> 1282
    //   1239: aload_0
    //   1240: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1243: iconst_1
    //   1244: aaload
    //   1245: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1248: if_acmpne -> 1282
    //   1251: iload #4
    //   1253: iconst_3
    //   1254: if_icmpne -> 1282
    //   1257: iload #7
    //   1259: iconst_3
    //   1260: if_icmpne -> 1282
    //   1263: aload_0
    //   1264: iload #12
    //   1266: iload #11
    //   1268: iload #13
    //   1270: iload #16
    //   1272: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   1275: iload #5
    //   1277: istore #8
    //   1279: goto -> 1474
    //   1282: aload_0
    //   1283: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1286: iconst_0
    //   1287: aaload
    //   1288: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1291: if_acmpne -> 1378
    //   1294: iload #4
    //   1296: iconst_3
    //   1297: if_icmpne -> 1378
    //   1300: aload_0
    //   1301: iconst_0
    //   1302: putfield mResolvedDimensionRatioSide : I
    //   1305: aload_0
    //   1306: getfield mResolvedDimensionRatio : F
    //   1309: aload_0
    //   1310: getfield mHeight : I
    //   1313: i2f
    //   1314: fmul
    //   1315: f2i
    //   1316: istore #9
    //   1318: aload_0
    //   1319: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1322: iconst_1
    //   1323: aaload
    //   1324: astore #24
    //   1326: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1329: astore #25
    //   1331: iload #5
    //   1333: istore #8
    //   1335: iload #7
    //   1337: istore #6
    //   1339: aload #24
    //   1341: aload #25
    //   1343: if_acmpeq -> 1360
    //   1346: iconst_4
    //   1347: istore #7
    //   1349: iload #9
    //   1351: istore #5
    //   1353: iload #8
    //   1355: istore #4
    //   1357: goto -> 1520
    //   1360: iload #4
    //   1362: istore #7
    //   1364: iconst_1
    //   1365: istore #13
    //   1367: iload #9
    //   1369: istore #5
    //   1371: iload #8
    //   1373: istore #4
    //   1375: goto -> 1523
    //   1378: iload #5
    //   1380: istore #8
    //   1382: aload_0
    //   1383: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1386: iconst_1
    //   1387: aaload
    //   1388: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1391: if_acmpne -> 1474
    //   1394: iload #5
    //   1396: istore #8
    //   1398: iload #7
    //   1400: iconst_3
    //   1401: if_icmpne -> 1474
    //   1404: aload_0
    //   1405: iconst_1
    //   1406: putfield mResolvedDimensionRatioSide : I
    //   1409: aload_0
    //   1410: getfield mDimensionRatioSide : I
    //   1413: iconst_m1
    //   1414: if_icmpne -> 1427
    //   1417: aload_0
    //   1418: fconst_1
    //   1419: aload_0
    //   1420: getfield mResolvedDimensionRatio : F
    //   1423: fdiv
    //   1424: putfield mResolvedDimensionRatio : F
    //   1427: aload_0
    //   1428: getfield mResolvedDimensionRatio : F
    //   1431: aload_0
    //   1432: getfield mWidth : I
    //   1435: i2f
    //   1436: fmul
    //   1437: f2i
    //   1438: istore #5
    //   1440: iload #5
    //   1442: istore #8
    //   1444: aload_0
    //   1445: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1448: iconst_0
    //   1449: aaload
    //   1450: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1453: if_acmpeq -> 1474
    //   1456: iload #4
    //   1458: istore #7
    //   1460: iconst_4
    //   1461: istore #8
    //   1463: iload #5
    //   1465: istore #4
    //   1467: iload #8
    //   1469: istore #5
    //   1471: goto -> 1508
    //   1474: iload #4
    //   1476: istore #9
    //   1478: iload #6
    //   1480: istore #5
    //   1482: iconst_1
    //   1483: istore #13
    //   1485: iload #8
    //   1487: istore #4
    //   1489: iload #7
    //   1491: istore #6
    //   1493: iload #9
    //   1495: istore #7
    //   1497: goto -> 1523
    //   1500: iload #5
    //   1502: istore #4
    //   1504: iload #8
    //   1506: istore #5
    //   1508: iload #6
    //   1510: istore #8
    //   1512: iload #5
    //   1514: istore #6
    //   1516: iload #8
    //   1518: istore #5
    //   1520: iconst_0
    //   1521: istore #13
    //   1523: aload_0
    //   1524: getfield mResolvedMatchConstraintDefault : [I
    //   1527: astore #24
    //   1529: aload #24
    //   1531: iconst_0
    //   1532: iload #7
    //   1534: iastore
    //   1535: aload #24
    //   1537: iconst_1
    //   1538: iload #6
    //   1540: iastore
    //   1541: aload_0
    //   1542: iload #13
    //   1544: putfield mResolvedHasRatio : Z
    //   1547: iload #13
    //   1549: ifeq -> 1575
    //   1552: aload_0
    //   1553: getfield mResolvedDimensionRatioSide : I
    //   1556: istore #8
    //   1558: iload #8
    //   1560: ifeq -> 1569
    //   1563: iload #8
    //   1565: iconst_m1
    //   1566: if_icmpne -> 1575
    //   1569: iconst_1
    //   1570: istore #17
    //   1572: goto -> 1578
    //   1575: iconst_0
    //   1576: istore #17
    //   1578: iload #13
    //   1580: ifeq -> 1607
    //   1583: aload_0
    //   1584: getfield mResolvedDimensionRatioSide : I
    //   1587: istore #8
    //   1589: iload #8
    //   1591: iconst_1
    //   1592: if_icmpeq -> 1601
    //   1595: iload #8
    //   1597: iconst_m1
    //   1598: if_icmpne -> 1607
    //   1601: iconst_1
    //   1602: istore #16
    //   1604: goto -> 1610
    //   1607: iconst_0
    //   1608: istore #16
    //   1610: aload_0
    //   1611: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1614: iconst_0
    //   1615: aaload
    //   1616: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1619: if_acmpne -> 1635
    //   1622: aload_0
    //   1623: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   1626: ifeq -> 1635
    //   1629: iconst_1
    //   1630: istore #18
    //   1632: goto -> 1638
    //   1635: iconst_0
    //   1636: istore #18
    //   1638: iload #18
    //   1640: ifeq -> 1649
    //   1643: iconst_0
    //   1644: istore #5
    //   1646: goto -> 1649
    //   1649: aload_0
    //   1650: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1653: invokevirtual isConnected : ()Z
    //   1656: iconst_1
    //   1657: ixor
    //   1658: istore #20
    //   1660: aload_0
    //   1661: getfield mIsInBarrier : [Z
    //   1664: astore #24
    //   1666: aload #24
    //   1668: iconst_0
    //   1669: baload
    //   1670: istore #22
    //   1672: aload #24
    //   1674: iconst_1
    //   1675: baload
    //   1676: istore #21
    //   1678: aload_0
    //   1679: getfield mHorizontalResolution : I
    //   1682: iconst_2
    //   1683: if_icmpeq -> 2018
    //   1686: aload_0
    //   1687: getfield resolvedHorizontal : Z
    //   1690: ifne -> 2018
    //   1693: iload_2
    //   1694: ifeq -> 1822
    //   1697: aload_0
    //   1698: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1701: astore #24
    //   1703: aload #24
    //   1705: ifnull -> 1822
    //   1708: aload #24
    //   1710: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1713: getfield resolved : Z
    //   1716: ifeq -> 1822
    //   1719: aload_0
    //   1720: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1723: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1726: getfield resolved : Z
    //   1729: ifne -> 1735
    //   1732: goto -> 1822
    //   1735: iload_2
    //   1736: ifeq -> 2018
    //   1739: aload_1
    //   1740: aload #28
    //   1742: aload_0
    //   1743: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1746: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1749: getfield value : I
    //   1752: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1755: aload_1
    //   1756: aload #27
    //   1758: aload_0
    //   1759: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1762: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1765: getfield value : I
    //   1768: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   1771: aload_0
    //   1772: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1775: ifnull -> 2018
    //   1778: iload #12
    //   1780: ifeq -> 2018
    //   1783: aload_0
    //   1784: getfield isTerminalWidget : [Z
    //   1787: iconst_0
    //   1788: baload
    //   1789: ifeq -> 2018
    //   1792: aload_0
    //   1793: invokevirtual isInHorizontalChain : ()Z
    //   1796: ifne -> 2018
    //   1799: aload_1
    //   1800: aload_1
    //   1801: aload_0
    //   1802: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1805: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1808: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1811: aload #27
    //   1813: iconst_0
    //   1814: bipush #8
    //   1816: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1819: goto -> 2018
    //   1822: aload_0
    //   1823: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1826: astore #24
    //   1828: aload #24
    //   1830: ifnull -> 1847
    //   1833: aload_1
    //   1834: aload #24
    //   1836: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1839: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1842: astore #24
    //   1844: goto -> 1850
    //   1847: aconst_null
    //   1848: astore #24
    //   1850: aload_0
    //   1851: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1854: astore #25
    //   1856: aload #25
    //   1858: ifnull -> 1875
    //   1861: aload_1
    //   1862: aload #25
    //   1864: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1867: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   1870: astore #25
    //   1872: goto -> 1878
    //   1875: aconst_null
    //   1876: astore #25
    //   1878: aload_0
    //   1879: getfield isTerminalWidget : [Z
    //   1882: iconst_0
    //   1883: baload
    //   1884: istore #23
    //   1886: aload_0
    //   1887: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1890: astore #31
    //   1892: aload #31
    //   1894: iconst_0
    //   1895: aaload
    //   1896: astore #32
    //   1898: aload_0
    //   1899: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1902: astore #33
    //   1904: aload_0
    //   1905: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1908: astore #34
    //   1910: aload_0
    //   1911: getfield mX : I
    //   1914: istore #8
    //   1916: aload_0
    //   1917: getfield mMinWidth : I
    //   1920: istore #9
    //   1922: aload_0
    //   1923: getfield mMaxDimension : [I
    //   1926: iconst_0
    //   1927: iaload
    //   1928: istore #10
    //   1930: aload_0
    //   1931: getfield mHorizontalBiasPercent : F
    //   1934: fstore_3
    //   1935: aload #31
    //   1937: iconst_1
    //   1938: aaload
    //   1939: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1942: if_acmpne -> 1951
    //   1945: iconst_1
    //   1946: istore #19
    //   1948: goto -> 1954
    //   1951: iconst_0
    //   1952: istore #19
    //   1954: aload_0
    //   1955: aload_1
    //   1956: iconst_1
    //   1957: iload #12
    //   1959: iload #11
    //   1961: iload #23
    //   1963: aload #25
    //   1965: aload #24
    //   1967: aload #32
    //   1969: iload #18
    //   1971: aload #33
    //   1973: aload #34
    //   1975: iload #8
    //   1977: iload #5
    //   1979: iload #9
    //   1981: iload #10
    //   1983: fload_3
    //   1984: iload #17
    //   1986: iload #19
    //   1988: iload #15
    //   1990: iload #14
    //   1992: iload #22
    //   1994: iload #7
    //   1996: iload #6
    //   1998: aload_0
    //   1999: getfield mMatchConstraintMinWidth : I
    //   2002: aload_0
    //   2003: getfield mMatchConstraintMaxWidth : I
    //   2006: aload_0
    //   2007: getfield mMatchConstraintPercentWidth : F
    //   2010: iload #20
    //   2012: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2015: goto -> 2018
    //   2018: aload #30
    //   2020: astore #25
    //   2022: aload #29
    //   2024: astore #24
    //   2026: iload #11
    //   2028: istore #18
    //   2030: aload #27
    //   2032: astore #29
    //   2034: iload_2
    //   2035: ifeq -> 2214
    //   2038: aload_0
    //   2039: astore #27
    //   2041: aload #27
    //   2043: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2046: astore #30
    //   2048: aload #30
    //   2050: ifnull -> 2211
    //   2053: aload #30
    //   2055: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2058: getfield resolved : Z
    //   2061: ifeq -> 2211
    //   2064: aload #27
    //   2066: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2069: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2072: getfield resolved : Z
    //   2075: ifeq -> 2211
    //   2078: aload #27
    //   2080: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2083: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2086: getfield value : I
    //   2089: istore #5
    //   2091: aload_1
    //   2092: astore #30
    //   2094: aload #30
    //   2096: aload #25
    //   2098: iload #5
    //   2100: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2103: aload #27
    //   2105: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2108: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2111: getfield value : I
    //   2114: istore #5
    //   2116: aload #24
    //   2118: astore #31
    //   2120: aload #30
    //   2122: aload #31
    //   2124: iload #5
    //   2126: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2129: aload #30
    //   2131: aload #26
    //   2133: aload #27
    //   2135: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   2138: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2141: getfield value : I
    //   2144: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   2147: aload #27
    //   2149: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2152: astore #32
    //   2154: aload #32
    //   2156: ifnull -> 2205
    //   2159: iload #14
    //   2161: ifne -> 2205
    //   2164: iload #18
    //   2166: ifeq -> 2205
    //   2169: aload #27
    //   2171: getfield isTerminalWidget : [Z
    //   2174: iconst_1
    //   2175: baload
    //   2176: ifeq -> 2202
    //   2179: aload #30
    //   2181: aload #30
    //   2183: aload #32
    //   2185: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2188: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2191: aload #31
    //   2193: iconst_0
    //   2194: bipush #8
    //   2196: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2199: goto -> 2205
    //   2202: goto -> 2205
    //   2205: iconst_0
    //   2206: istore #5
    //   2208: goto -> 2217
    //   2211: goto -> 2214
    //   2214: iconst_1
    //   2215: istore #5
    //   2217: aload_0
    //   2218: astore #30
    //   2220: aload_1
    //   2221: astore #31
    //   2223: aload #26
    //   2225: astore #32
    //   2227: aload #30
    //   2229: getfield mVerticalResolution : I
    //   2232: iconst_2
    //   2233: if_icmpne -> 2242
    //   2236: iconst_0
    //   2237: istore #5
    //   2239: goto -> 2242
    //   2242: iload #5
    //   2244: ifeq -> 2659
    //   2247: aload #30
    //   2249: getfield resolvedVertical : Z
    //   2252: ifne -> 2659
    //   2255: aload #30
    //   2257: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2260: iconst_1
    //   2261: aaload
    //   2262: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2265: if_acmpne -> 2281
    //   2268: aload #30
    //   2270: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   2273: ifeq -> 2281
    //   2276: iconst_1
    //   2277: istore_2
    //   2278: goto -> 2283
    //   2281: iconst_0
    //   2282: istore_2
    //   2283: iload_2
    //   2284: ifeq -> 2290
    //   2287: iconst_0
    //   2288: istore #4
    //   2290: aload #30
    //   2292: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2295: astore #26
    //   2297: aload #26
    //   2299: ifnull -> 2317
    //   2302: aload #31
    //   2304: aload #26
    //   2306: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2309: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2312: astore #26
    //   2314: goto -> 2320
    //   2317: aconst_null
    //   2318: astore #26
    //   2320: aload #30
    //   2322: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2325: astore #27
    //   2327: aload #27
    //   2329: ifnull -> 2347
    //   2332: aload #31
    //   2334: aload #27
    //   2336: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2339: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2342: astore #27
    //   2344: goto -> 2350
    //   2347: aconst_null
    //   2348: astore #27
    //   2350: aload #30
    //   2352: getfield mBaselineDistance : I
    //   2355: ifgt -> 2368
    //   2358: aload #30
    //   2360: getfield mVisibility : I
    //   2363: bipush #8
    //   2365: if_icmpne -> 2505
    //   2368: aload #30
    //   2370: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2373: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2376: ifnull -> 2456
    //   2379: aload #31
    //   2381: aload #32
    //   2383: aload #25
    //   2385: aload_0
    //   2386: invokevirtual getBaselineDistance : ()I
    //   2389: bipush #8
    //   2391: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2394: pop
    //   2395: aload #31
    //   2397: aload #32
    //   2399: aload #31
    //   2401: aload #30
    //   2403: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2406: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2409: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2412: aload #30
    //   2414: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2417: invokevirtual getMargin : ()I
    //   2420: bipush #8
    //   2422: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2425: pop
    //   2426: iload #18
    //   2428: ifeq -> 2450
    //   2431: aload #31
    //   2433: aload #26
    //   2435: aload #31
    //   2437: aload #30
    //   2439: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2442: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   2445: iconst_0
    //   2446: iconst_5
    //   2447: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2450: iconst_0
    //   2451: istore #11
    //   2453: goto -> 2509
    //   2456: aload #30
    //   2458: getfield mVisibility : I
    //   2461: bipush #8
    //   2463: if_icmpne -> 2489
    //   2466: aload #31
    //   2468: aload #32
    //   2470: aload #25
    //   2472: aload #30
    //   2474: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2477: invokevirtual getMargin : ()I
    //   2480: bipush #8
    //   2482: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2485: pop
    //   2486: goto -> 2505
    //   2489: aload #31
    //   2491: aload #32
    //   2493: aload #25
    //   2495: aload_0
    //   2496: invokevirtual getBaselineDistance : ()I
    //   2499: bipush #8
    //   2501: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2504: pop
    //   2505: iload #20
    //   2507: istore #11
    //   2509: aload #30
    //   2511: getfield isTerminalWidget : [Z
    //   2514: iconst_1
    //   2515: baload
    //   2516: istore #19
    //   2518: aload #30
    //   2520: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2523: astore #31
    //   2525: aload #31
    //   2527: iconst_1
    //   2528: aaload
    //   2529: astore #32
    //   2531: aload #30
    //   2533: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2536: astore #33
    //   2538: aload #30
    //   2540: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2543: astore #34
    //   2545: aload #30
    //   2547: getfield mY : I
    //   2550: istore #5
    //   2552: aload #30
    //   2554: getfield mMinHeight : I
    //   2557: istore #8
    //   2559: aload #30
    //   2561: getfield mMaxDimension : [I
    //   2564: iconst_1
    //   2565: iaload
    //   2566: istore #9
    //   2568: aload #30
    //   2570: getfield mVerticalBiasPercent : F
    //   2573: fstore_3
    //   2574: aload #31
    //   2576: iconst_0
    //   2577: aaload
    //   2578: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2581: if_acmpne -> 2590
    //   2584: iconst_1
    //   2585: istore #17
    //   2587: goto -> 2593
    //   2590: iconst_0
    //   2591: istore #17
    //   2593: aload_0
    //   2594: aload_1
    //   2595: iconst_0
    //   2596: iload #18
    //   2598: iload #12
    //   2600: iload #19
    //   2602: aload #27
    //   2604: aload #26
    //   2606: aload #32
    //   2608: iload_2
    //   2609: aload #33
    //   2611: aload #34
    //   2613: iload #5
    //   2615: iload #4
    //   2617: iload #8
    //   2619: iload #9
    //   2621: fload_3
    //   2622: iload #16
    //   2624: iload #17
    //   2626: iload #14
    //   2628: iload #15
    //   2630: iload #21
    //   2632: iload #6
    //   2634: iload #7
    //   2636: aload #30
    //   2638: getfield mMatchConstraintMinHeight : I
    //   2641: aload #30
    //   2643: getfield mMatchConstraintMaxHeight : I
    //   2646: aload #30
    //   2648: getfield mMatchConstraintPercentHeight : F
    //   2651: iload #11
    //   2653: invokespecial applyConstraints : (Landroidx/constraintlayout/core/LinearSystem;ZZZZLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;IIIIFZZZZZIIIIFZ)V
    //   2656: goto -> 2659
    //   2659: iload #13
    //   2661: ifeq -> 2720
    //   2664: aload_0
    //   2665: astore #26
    //   2667: aload #26
    //   2669: getfield mResolvedDimensionRatioSide : I
    //   2672: iconst_1
    //   2673: if_icmpne -> 2698
    //   2676: aload_1
    //   2677: aload #24
    //   2679: aload #25
    //   2681: aload #29
    //   2683: aload #28
    //   2685: aload #26
    //   2687: getfield mResolvedDimensionRatio : F
    //   2690: bipush #8
    //   2692: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2695: goto -> 2720
    //   2698: aload_1
    //   2699: aload #29
    //   2701: aload #28
    //   2703: aload #24
    //   2705: aload #25
    //   2707: aload #26
    //   2709: getfield mResolvedDimensionRatio : F
    //   2712: bipush #8
    //   2714: invokevirtual addRatio : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;FI)V
    //   2717: goto -> 2720
    //   2720: aload_0
    //   2721: astore #24
    //   2723: aload #24
    //   2725: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2728: invokevirtual isConnected : ()Z
    //   2731: ifeq -> 2773
    //   2734: aload_1
    //   2735: aload #24
    //   2737: aload #24
    //   2739: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2742: invokevirtual getTarget : ()Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2745: invokevirtual getOwner : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2748: aload #24
    //   2750: getfield mCircleConstraintAngle : F
    //   2753: ldc_w 90.0
    //   2756: fadd
    //   2757: f2d
    //   2758: invokestatic toRadians : (D)D
    //   2761: d2f
    //   2762: aload #24
    //   2764: getfield mCenter : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2767: invokevirtual getMargin : ()I
    //   2770: invokevirtual addCenterPoint : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget;FI)V
    //   2773: aload #24
    //   2775: iconst_0
    //   2776: putfield resolvedHorizontal : Z
    //   2779: aload #24
    //   2781: iconst_0
    //   2782: putfield resolvedVertical : Z
    //   2785: return
  }
  
  public boolean allowedInBarrier() {
    return (this.mVisibility != 8);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    ConstraintAnchor constraintAnchor;
    if (paramType1 == ConstraintAnchor.Type.CENTER) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.TOP);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.BOTTOM);
        boolean bool = true;
        if ((constraintAnchor1 != null && constraintAnchor1.isConnected()) || (constraintAnchor != null && constraintAnchor.isConnected())) {
          paramInt = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0);
          paramInt = 1;
        } 
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0);
        } 
        if (paramInt != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0);
          return;
        } 
        if (paramInt != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0);
          return;
        } 
        if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0);
          return;
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
          return;
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor2 = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor2, 0);
        constraintAnchor.connect(constraintAnchor2, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0);
        return;
      } 
      ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
      ConstraintAnchor constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
      if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
        if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
          constraintAnchor1 = getAnchor(ConstraintAnchor.Type.TOP);
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BOTTOM);
          if (constraintAnchor1 != null)
            constraintAnchor1.reset(); 
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
          if (constraintAnchor != null)
            constraintAnchor.reset(); 
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_Y);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
          if (constraintAnchor.getTarget() != constraintAnchor2)
            constraintAnchor.reset(); 
          constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
          constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_X);
          if (constraintAnchor.isConnected()) {
            constraintAnchor1.reset();
            constraintAnchor.reset();
          } 
        } 
        constraintAnchor3.connect(constraintAnchor2, paramInt);
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    int[] arrayOfInt1;
    ConstraintWidget constraintWidget1;
    this.mHorizontalResolution = paramConstraintWidget.mHorizontalResolution;
    this.mVerticalResolution = paramConstraintWidget.mVerticalResolution;
    this.mMatchConstraintDefaultWidth = paramConstraintWidget.mMatchConstraintDefaultWidth;
    this.mMatchConstraintDefaultHeight = paramConstraintWidget.mMatchConstraintDefaultHeight;
    int[] arrayOfInt2 = this.mResolvedMatchConstraintDefault;
    int[] arrayOfInt3 = paramConstraintWidget.mResolvedMatchConstraintDefault;
    arrayOfInt2[0] = arrayOfInt3[0];
    arrayOfInt2[1] = arrayOfInt3[1];
    this.mMatchConstraintMinWidth = paramConstraintWidget.mMatchConstraintMinWidth;
    this.mMatchConstraintMaxWidth = paramConstraintWidget.mMatchConstraintMaxWidth;
    this.mMatchConstraintMinHeight = paramConstraintWidget.mMatchConstraintMinHeight;
    this.mMatchConstraintMaxHeight = paramConstraintWidget.mMatchConstraintMaxHeight;
    this.mMatchConstraintPercentHeight = paramConstraintWidget.mMatchConstraintPercentHeight;
    this.mIsWidthWrapContent = paramConstraintWidget.mIsWidthWrapContent;
    this.mIsHeightWrapContent = paramConstraintWidget.mIsHeightWrapContent;
    this.mResolvedDimensionRatioSide = paramConstraintWidget.mResolvedDimensionRatioSide;
    this.mResolvedDimensionRatio = paramConstraintWidget.mResolvedDimensionRatio;
    arrayOfInt2 = paramConstraintWidget.mMaxDimension;
    this.mMaxDimension = Arrays.copyOf(arrayOfInt2, arrayOfInt2.length);
    this.mCircleConstraintAngle = paramConstraintWidget.mCircleConstraintAngle;
    this.hasBaseline = paramConstraintWidget.hasBaseline;
    this.inPlaceholder = paramConstraintWidget.inPlaceholder;
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mListDimensionBehaviors = Arrays.<DimensionBehaviour>copyOf(this.mListDimensionBehaviors, 2);
    ConstraintWidget constraintWidget3 = this.mParent;
    arrayOfInt3 = null;
    if (constraintWidget3 == null) {
      constraintWidget3 = null;
    } else {
      constraintWidget3 = paramHashMap.get(paramConstraintWidget.mParent);
    } 
    this.mParent = constraintWidget3;
    this.mWidth = paramConstraintWidget.mWidth;
    this.mHeight = paramConstraintWidget.mHeight;
    this.mDimensionRatio = paramConstraintWidget.mDimensionRatio;
    this.mDimensionRatioSide = paramConstraintWidget.mDimensionRatioSide;
    this.mX = paramConstraintWidget.mX;
    this.mY = paramConstraintWidget.mY;
    this.mRelX = paramConstraintWidget.mRelX;
    this.mRelY = paramConstraintWidget.mRelY;
    this.mOffsetX = paramConstraintWidget.mOffsetX;
    this.mOffsetY = paramConstraintWidget.mOffsetY;
    this.mBaselineDistance = paramConstraintWidget.mBaselineDistance;
    this.mMinWidth = paramConstraintWidget.mMinWidth;
    this.mMinHeight = paramConstraintWidget.mMinHeight;
    this.mHorizontalBiasPercent = paramConstraintWidget.mHorizontalBiasPercent;
    this.mVerticalBiasPercent = paramConstraintWidget.mVerticalBiasPercent;
    this.mCompanionWidget = paramConstraintWidget.mCompanionWidget;
    this.mContainerItemSkip = paramConstraintWidget.mContainerItemSkip;
    this.mVisibility = paramConstraintWidget.mVisibility;
    this.mAnimated = paramConstraintWidget.mAnimated;
    this.mDebugName = paramConstraintWidget.mDebugName;
    this.mType = paramConstraintWidget.mType;
    this.mDistToTop = paramConstraintWidget.mDistToTop;
    this.mDistToLeft = paramConstraintWidget.mDistToLeft;
    this.mDistToRight = paramConstraintWidget.mDistToRight;
    this.mDistToBottom = paramConstraintWidget.mDistToBottom;
    this.mLeftHasCentered = paramConstraintWidget.mLeftHasCentered;
    this.mRightHasCentered = paramConstraintWidget.mRightHasCentered;
    this.mTopHasCentered = paramConstraintWidget.mTopHasCentered;
    this.mBottomHasCentered = paramConstraintWidget.mBottomHasCentered;
    this.mHorizontalWrapVisited = paramConstraintWidget.mHorizontalWrapVisited;
    this.mVerticalWrapVisited = paramConstraintWidget.mVerticalWrapVisited;
    this.mHorizontalChainStyle = paramConstraintWidget.mHorizontalChainStyle;
    this.mVerticalChainStyle = paramConstraintWidget.mVerticalChainStyle;
    this.mHorizontalChainFixedPosition = paramConstraintWidget.mHorizontalChainFixedPosition;
    this.mVerticalChainFixedPosition = paramConstraintWidget.mVerticalChainFixedPosition;
    float[] arrayOfFloat1 = this.mWeight;
    float[] arrayOfFloat2 = paramConstraintWidget.mWeight;
    arrayOfFloat1[0] = arrayOfFloat2[0];
    arrayOfFloat1[1] = arrayOfFloat2[1];
    ConstraintWidget[] arrayOfConstraintWidget1 = this.mListNextMatchConstraintsWidget;
    ConstraintWidget[] arrayOfConstraintWidget2 = paramConstraintWidget.mListNextMatchConstraintsWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    arrayOfConstraintWidget1 = this.mNextChainWidget;
    arrayOfConstraintWidget2 = paramConstraintWidget.mNextChainWidget;
    arrayOfConstraintWidget1[0] = arrayOfConstraintWidget2[0];
    arrayOfConstraintWidget1[1] = arrayOfConstraintWidget2[1];
    ConstraintWidget constraintWidget2 = paramConstraintWidget.mHorizontalNextWidget;
    if (constraintWidget2 == null) {
      constraintWidget2 = null;
    } else {
      constraintWidget2 = paramHashMap.get(constraintWidget2);
    } 
    this.mHorizontalNextWidget = constraintWidget2;
    paramConstraintWidget = paramConstraintWidget.mVerticalNextWidget;
    if (paramConstraintWidget == null) {
      arrayOfInt1 = arrayOfInt3;
    } else {
      constraintWidget1 = paramHashMap.get(arrayOfInt1);
    } 
    this.mVerticalNextWidget = constraintWidget1;
  }
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void ensureMeasureRequested() {
    this.mMeasureRequested = true;
  }
  
  public void ensureWidgetRuns() {
    if (this.horizontalRun == null)
      this.horizontalRun = new HorizontalWidgetRun(this); 
    if (this.verticalRun == null)
      this.verticalRun = new VerticalWidgetRun(this); 
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case null:
        return this.mBottom;
      case null:
        return this.mRight;
      case null:
        return this.mTop;
      case null:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public boolean getHasBaseline() {
    return this.hasBaseline;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    boolean bool = isInHorizontalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getHorizontalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + constraintAnchor.mMargin; 
    constraintAnchor = this.mRight;
    int j = i;
    if (constraintAnchor != null)
      j = i + constraintAnchor.mMargin; 
    return j;
  }
  
  public int getLastHorizontalMeasureSpec() {
    return this.mLastHorizontalMeasureSpec;
  }
  
  public int getLastVerticalMeasureSpec() {
    return this.mLastVerticalMeasureSpec;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public ConstraintWidget getNextChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mRight.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mRight.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mRight;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mBottom.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mBottom.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mBottom;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  public ConstraintWidget getPreviousChainMember(int paramInt) {
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        ConstraintAnchor constraintAnchor1 = this.mLeft.mTarget.mTarget;
        ConstraintAnchor constraintAnchor2 = this.mLeft;
        if (constraintAnchor1 == constraintAnchor2)
          return constraintAnchor2.mTarget.mOwner; 
      } 
    } else if (paramInt == 1 && this.mTop.mTarget != null) {
      ConstraintAnchor constraintAnchor1 = this.mTop.mTarget.mTarget;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      if (constraintAnchor1 == constraintAnchor2)
        return constraintAnchor2.mTarget.mOwner; 
    } 
    return null;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public WidgetRun getRun(int paramInt) {
    return (WidgetRun)((paramInt == 0) ? this.horizontalRun : ((paramInt == 1) ? this.verticalRun : null));
  }
  
  public void getSceneString(StringBuilder paramStringBuilder) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("  ");
    stringBuilder.append(this.stringId);
    stringBuilder.append(":{\n");
    paramStringBuilder.append(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualWidth:");
    stringBuilder.append(this.mWidth);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualHeight:");
    stringBuilder.append(this.mHeight);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualLeft:");
    stringBuilder.append(this.mX);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("    actualTop:");
    stringBuilder.append(this.mY);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    getSceneString(paramStringBuilder, "left", this.mLeft);
    getSceneString(paramStringBuilder, "top", this.mTop);
    getSceneString(paramStringBuilder, "right", this.mRight);
    getSceneString(paramStringBuilder, "bottom", this.mBottom);
    getSceneString(paramStringBuilder, "baseline", this.mBaseline);
    getSceneString(paramStringBuilder, "centerX", this.mCenterX);
    getSceneString(paramStringBuilder, "centerY", this.mCenterY);
    getSceneString(paramStringBuilder, "    width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    getSceneString(paramStringBuilder, "    height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "    dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "    horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "    verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "    horizontalChainStyle", this.mHorizontalChainStyle, 0);
    serializeAttribute(paramStringBuilder, "    verticalChainStyle", this.mVerticalChainStyle, 0);
    paramStringBuilder.append("  }");
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    boolean bool = isInVerticalChain();
    ConstraintWidget constraintWidget = null;
    if (bool) {
      ConstraintWidget constraintWidget1 = this;
      constraintWidget = null;
      while (constraintWidget == null && constraintWidget1 != null) {
        ConstraintWidget constraintWidget2;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor1 = constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintAnchor1 = constraintAnchor1.getTarget();
        } 
        if (constraintAnchor1 == null) {
          constraintAnchor1 = null;
        } else {
          constraintWidget2 = constraintAnchor1.getOwner();
        } 
        if (constraintWidget2 == getParent())
          return constraintWidget1; 
        if (constraintWidget2 == null) {
          constraintAnchor2 = null;
        } else {
          constraintAnchor2 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
        } 
        if (constraintAnchor2 != null && constraintAnchor2.getOwner() != constraintWidget1) {
          constraintWidget = constraintWidget1;
          continue;
        } 
        constraintWidget1 = constraintWidget2;
      } 
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVerticalMargin() {
    ConstraintAnchor constraintAnchor = this.mLeft;
    int i = 0;
    if (constraintAnchor != null)
      i = 0 + this.mTop.mMargin; 
    int j = i;
    if (this.mRight != null)
      j = i + this.mBottom.mMargin; 
    return j;
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapBehaviorInParent() {
    return this.mWrapBehaviorInParent;
  }
  
  public int getX() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingLeft + this.mX) : this.mX;
  }
  
  public int getY() {
    ConstraintWidget constraintWidget = this.mParent;
    return (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer) ? (((ConstraintWidgetContainer)constraintWidget).mPaddingTop + this.mY) : this.mY;
  }
  
  public boolean hasBaseline() {
    return this.hasBaseline;
  }
  
  public boolean hasDanglingDimension(int paramInt) {
    byte b1;
    byte b2;
    if (paramInt == 0) {
      if (this.mLeft.mTarget != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (this.mRight.mTarget != null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      return (paramInt + b1 < 2);
    } 
    if (this.mTop.mTarget != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (this.mBottom.mTarget != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (this.mBaseline.mTarget != null) {
      b2 = 1;
    } else {
      b2 = 0;
    } 
    return (paramInt + b1 + b2 < 2);
  }
  
  public boolean hasDependencies() {
    int j = this.mAnchors.size();
    for (int i = 0; i < j; i++) {
      if (((ConstraintAnchor)this.mAnchors.get(i)).hasDependents())
        return true; 
    } 
    return false;
  }
  
  public boolean hasDimensionOverride() {
    return (this.mWidthOverride != -1 || this.mHeightOverride != -1);
  }
  
  public boolean hasResolvedTargets(int paramInt1, int paramInt2) {
    if (paramInt1 == 0) {
      if (this.mLeft.mTarget != null && this.mLeft.mTarget.hasFinalValue() && this.mRight.mTarget != null && this.mRight.mTarget.hasFinalValue())
        return (this.mRight.mTarget.getFinalValue() - this.mRight.getMargin() - this.mLeft.mTarget.getFinalValue() + this.mLeft.getMargin() >= paramInt2); 
    } else if (this.mTop.mTarget != null && this.mTop.mTarget.hasFinalValue() && this.mBottom.mTarget != null && this.mBottom.mTarget.hasFinalValue()) {
      return (this.mBottom.mTarget.getFinalValue() - this.mBottom.getMargin() - this.mTop.mTarget.getFinalValue() + this.mTop.getMargin() >= paramInt2);
    } 
    return false;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, true);
  }
  
  public boolean isAnimated() {
    return this.mAnimated;
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isHorizontalSolvingPassDone() {
    return this.horizontalSolvingPass;
  }
  
  public boolean isInBarrier(int paramInt) {
    return this.mIsInBarrier[paramInt];
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInPlaceholder() {
    return this.inPlaceholder;
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInVirtualLayout() {
    return this.mInVirtualLayout;
  }
  
  public boolean isMeasureRequested() {
    return (this.mMeasureRequested && this.mVisibility != 8);
  }
  
  public boolean isResolvedHorizontally() {
    return (this.resolvedHorizontal || (this.mLeft.hasFinalValue() && this.mRight.hasFinalValue()));
  }
  
  public boolean isResolvedVertically() {
    return (this.resolvedVertical || (this.mTop.hasFinalValue() && this.mBottom.hasFinalValue()));
  }
  
  public boolean isRoot() {
    return (this.mParent == null);
  }
  
  public boolean isSpreadHeight() {
    return (this.mMatchConstraintDefaultHeight == 0 && this.mDimensionRatio == 0.0F && this.mMatchConstraintMinHeight == 0 && this.mMatchConstraintMaxHeight == 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.mDimensionRatio == 0.0F) {
        bool1 = bool2;
        if (this.mMatchConstraintMinWidth == 0) {
          bool1 = bool2;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool1 = bool2;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public boolean isVerticalSolvingPassDone() {
    return this.verticalSolvingPass;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void markHorizontalSolvingPassDone() {
    this.horizontalSolvingPass = true;
  }
  
  public void markVerticalSolvingPassDone() {
    this.verticalSolvingPass = true;
  }
  
  public boolean oppositeDimensionDependsOn(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[paramInt];
    DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[bool];
    return (dimensionBehaviour1 == DimensionBehaviour.MATCH_CONSTRAINT && dimensionBehaviour2 == DimensionBehaviour.MATCH_CONSTRAINT);
  }
  
  public boolean oppositeDimensionsTied() {
    DimensionBehaviour[] arrayOfDimensionBehaviour = this.mListDimensionBehaviors;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (arrayOfDimensionBehaviour[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      bool1 = bool2;
      if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt2 = this.mMaxDimension;
    arrayOfInt2[0] = Integer.MAX_VALUE;
    arrayOfInt2[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedHasRatio = false;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    this.mGroupsToSolver = false;
    boolean[] arrayOfBoolean = this.isTerminalWidget;
    arrayOfBoolean[0] = true;
    arrayOfBoolean[1] = true;
    this.mInVirtualLayout = false;
    arrayOfBoolean = this.mIsInBarrier;
    arrayOfBoolean[0] = false;
    arrayOfBoolean[1] = false;
    this.mMeasureRequested = true;
    int[] arrayOfInt1 = this.mResolvedMatchConstraintDefault;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    this.mWidthOverride = -1;
    this.mHeightOverride = -1;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    int i = 0;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).reset();
      i++;
    } 
  }
  
  public void resetFinalResolution() {
    int i = 0;
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
    int j = this.mAnchors.size();
    while (i < j) {
      ((ConstraintAnchor)this.mAnchors.get(i)).resetFinalResolution();
      i++;
    } 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resetSolvingPassFlag() {
    this.horizontalSolvingPass = false;
    this.verticalSolvingPass = false;
  }
  
  public StringBuilder serialize(StringBuilder paramStringBuilder) {
    paramStringBuilder.append("{\n");
    serializeAnchor(paramStringBuilder, "left", this.mLeft);
    serializeAnchor(paramStringBuilder, "top", this.mTop);
    serializeAnchor(paramStringBuilder, "right", this.mRight);
    serializeAnchor(paramStringBuilder, "bottom", this.mBottom);
    serializeAnchor(paramStringBuilder, "baseline", this.mBaseline);
    serializeAnchor(paramStringBuilder, "centerX", this.mCenterX);
    serializeAnchor(paramStringBuilder, "centerY", this.mCenterY);
    serializeCircle(paramStringBuilder, this.mCenter, this.mCircleConstraintAngle);
    serializeSize(paramStringBuilder, "width", this.mWidth, this.mMinWidth, this.mMaxDimension[0], this.mWidthOverride, this.mMatchConstraintMinWidth, this.mMatchConstraintDefaultWidth, this.mMatchConstraintPercentWidth, this.mWeight[0]);
    serializeSize(paramStringBuilder, "height", this.mHeight, this.mMinHeight, this.mMaxDimension[1], this.mHeightOverride, this.mMatchConstraintMinHeight, this.mMatchConstraintDefaultHeight, this.mMatchConstraintPercentHeight, this.mWeight[1]);
    serializeDimensionRatio(paramStringBuilder, "dimensionRatio", this.mDimensionRatio, this.mDimensionRatioSide);
    serializeAttribute(paramStringBuilder, "horizontalBias", this.mHorizontalBiasPercent, DEFAULT_BIAS);
    serializeAttribute(paramStringBuilder, "verticalBias", this.mVerticalBiasPercent, DEFAULT_BIAS);
    paramStringBuilder.append("}\n");
    return paramStringBuilder;
  }
  
  public void setAnimated(boolean paramBoolean) {
    this.mAnimated = paramBoolean;
  }
  
  public void setBaselineDistance(int paramInt) {
    boolean bool;
    this.mBaselineDistance = paramInt;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.hasBaseline = bool;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
      return;
    } 
    this.mContainerItemSkip = 0;
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable5 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder5 = new StringBuilder();
    stringBuilder5.append(paramString);
    stringBuilder5.append(".left");
    solverVariable5.setName(stringBuilder5.toString());
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".top");
    solverVariable4.setName(stringBuilder4.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".right");
    solverVariable3.setName(stringBuilder3.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".bottom");
    solverVariable2.setName(stringBuilder2.toString());
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mBaseline);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".baseline");
    solverVariable1.setName(stringBuilder1.toString());
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mMinWidth;
    if (paramInt1 < i)
      this.mWidth = i; 
    this.mHeight = paramInt2;
    paramInt1 = this.mMinHeight;
    if (paramInt2 < paramInt1)
      this.mHeight = paramInt1; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 261
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 261
    //   14: iconst_m1
    //   15: istore #6
    //   17: aload_1
    //   18: invokevirtual length : ()I
    //   21: istore #8
    //   23: aload_1
    //   24: bipush #44
    //   26: invokevirtual indexOf : (I)I
    //   29: istore #9
    //   31: iconst_0
    //   32: istore #7
    //   34: iload #6
    //   36: istore #4
    //   38: iload #7
    //   40: istore #5
    //   42: iload #9
    //   44: ifle -> 114
    //   47: iload #6
    //   49: istore #4
    //   51: iload #7
    //   53: istore #5
    //   55: iload #9
    //   57: iload #8
    //   59: iconst_1
    //   60: isub
    //   61: if_icmpge -> 114
    //   64: aload_1
    //   65: iconst_0
    //   66: iload #9
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #10
    //   73: aload #10
    //   75: ldc_w 'W'
    //   78: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   81: ifeq -> 90
    //   84: iconst_0
    //   85: istore #4
    //   87: goto -> 108
    //   90: iload #6
    //   92: istore #4
    //   94: aload #10
    //   96: ldc_w 'H'
    //   99: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   102: ifeq -> 108
    //   105: iconst_1
    //   106: istore #4
    //   108: iload #9
    //   110: iconst_1
    //   111: iadd
    //   112: istore #5
    //   114: aload_1
    //   115: bipush #58
    //   117: invokevirtual indexOf : (I)I
    //   120: istore #6
    //   122: iload #6
    //   124: iflt -> 219
    //   127: iload #6
    //   129: iload #8
    //   131: iconst_1
    //   132: isub
    //   133: if_icmpge -> 219
    //   136: aload_1
    //   137: iload #5
    //   139: iload #6
    //   141: invokevirtual substring : (II)Ljava/lang/String;
    //   144: astore #10
    //   146: aload_1
    //   147: iload #6
    //   149: iconst_1
    //   150: iadd
    //   151: invokevirtual substring : (I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload #10
    //   157: invokevirtual length : ()I
    //   160: ifle -> 241
    //   163: aload_1
    //   164: invokevirtual length : ()I
    //   167: ifle -> 241
    //   170: aload #10
    //   172: invokestatic parseFloat : (Ljava/lang/String;)F
    //   175: fstore_2
    //   176: aload_1
    //   177: invokestatic parseFloat : (Ljava/lang/String;)F
    //   180: fstore_3
    //   181: fload_2
    //   182: fconst_0
    //   183: fcmpl
    //   184: ifle -> 241
    //   187: fload_3
    //   188: fconst_0
    //   189: fcmpl
    //   190: ifle -> 241
    //   193: iload #4
    //   195: iconst_1
    //   196: if_icmpne -> 209
    //   199: fload_3
    //   200: fload_2
    //   201: fdiv
    //   202: invokestatic abs : (F)F
    //   205: fstore_2
    //   206: goto -> 243
    //   209: fload_2
    //   210: fload_3
    //   211: fdiv
    //   212: invokestatic abs : (F)F
    //   215: fstore_2
    //   216: goto -> 243
    //   219: aload_1
    //   220: iload #5
    //   222: invokevirtual substring : (I)Ljava/lang/String;
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual length : ()I
    //   230: ifle -> 241
    //   233: aload_1
    //   234: invokestatic parseFloat : (Ljava/lang/String;)F
    //   237: fstore_2
    //   238: goto -> 243
    //   241: fconst_0
    //   242: fstore_2
    //   243: fload_2
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 260
    //   249: aload_0
    //   250: fload_2
    //   251: putfield mDimensionRatio : F
    //   254: aload_0
    //   255: iload #4
    //   257: putfield mDimensionRatioSide : I
    //   260: return
    //   261: aload_0
    //   262: fconst_0
    //   263: putfield mDimensionRatio : F
    //   266: return
    //   267: astore_1
    //   268: goto -> 241
    // Exception table:
    //   from	to	target	type
    //   170	181	267	java/lang/NumberFormatException
    //   199	206	267	java/lang/NumberFormatException
    //   209	216	267	java/lang/NumberFormatException
    //   233	238	267	java/lang/NumberFormatException
  }
  
  public void setFinalBaseline(int paramInt) {
    if (!this.hasBaseline)
      return; 
    int i = paramInt - this.mBaselineDistance;
    int j = this.mHeight;
    this.mY = i;
    this.mTop.setFinalValue(i);
    this.mBottom.setFinalValue(j + i);
    this.mBaseline.setFinalValue(paramInt);
    this.resolvedVertical = true;
  }
  
  public void setFinalFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    setBaselineDistance(paramInt5);
    if (paramInt6 == 0) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = false;
      return;
    } 
    if (paramInt6 == 1) {
      this.resolvedHorizontal = false;
      this.resolvedVertical = true;
      return;
    } 
    if (paramInt6 == 2) {
      this.resolvedHorizontal = true;
      this.resolvedVertical = true;
      return;
    } 
    this.resolvedHorizontal = false;
    this.resolvedVertical = false;
  }
  
  public void setFinalHorizontal(int paramInt1, int paramInt2) {
    if (this.resolvedHorizontal)
      return; 
    this.mLeft.setFinalValue(paramInt1);
    this.mRight.setFinalValue(paramInt2);
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    this.resolvedHorizontal = true;
  }
  
  public void setFinalLeft(int paramInt) {
    this.mLeft.setFinalValue(paramInt);
    this.mX = paramInt;
  }
  
  public void setFinalTop(int paramInt) {
    this.mTop.setFinalValue(paramInt);
    this.mY = paramInt;
  }
  
  public void setFinalVertical(int paramInt1, int paramInt2) {
    if (this.resolvedVertical)
      return; 
    this.mTop.setFinalValue(paramInt1);
    this.mBottom.setFinalValue(paramInt2);
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    if (this.hasBaseline)
      this.mBaseline.setFinalValue(paramInt1 + this.mBaselineDistance); 
    this.resolvedVertical = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
      return;
    } 
    if (paramInt3 == 1)
      setVerticalDimension(paramInt1, paramInt2); 
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.mX = paramInt1;
    this.mY = paramInt2;
    if (this.mVisibility == 8) {
      this.mWidth = 0;
      this.mHeight = 0;
      return;
    } 
    paramInt1 = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.FIXED) {
      paramInt2 = this.mWidth;
      paramInt1 = i;
      if (i < paramInt2)
        paramInt1 = paramInt2; 
    } 
    paramInt2 = paramInt3;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.FIXED) {
      paramInt4 = this.mHeight;
      paramInt2 = paramInt3;
      if (paramInt3 < paramInt4)
        paramInt2 = paramInt4; 
    } 
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    paramInt3 = this.mMinHeight;
    if (paramInt2 < paramInt3)
      this.mHeight = paramInt3; 
    paramInt3 = this.mMinWidth;
    if (paramInt1 < paramInt3)
      this.mWidth = paramInt3; 
    if (this.mMatchConstraintMaxWidth > 0 && this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mWidth = Math.min(this.mWidth, this.mMatchConstraintMaxWidth); 
    if (this.mMatchConstraintMaxHeight > 0 && this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT)
      this.mHeight = Math.min(this.mHeight, this.mMatchConstraintMaxHeight); 
    paramInt3 = this.mWidth;
    if (paramInt1 != paramInt3)
      this.mWidthOverride = paramInt3; 
    paramInt1 = this.mHeight;
    if (paramInt2 != paramInt1)
      this.mHeightOverride = paramInt1; 
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$core$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              return; 
            this.mBaseline.mGoneMargin = paramInt;
            return;
          } 
          this.mBottom.mGoneMargin = paramInt;
          return;
        } 
        this.mRight.mGoneMargin = paramInt;
        return;
      } 
      this.mTop.mGoneMargin = paramInt;
      return;
    } 
    this.mLeft.mGoneMargin = paramInt;
  }
  
  public void setHasBaseline(boolean paramBoolean) {
    this.hasBaseline = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mMinHeight;
    if (paramInt < i)
      this.mHeight = i; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mWidth = paramInt1;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxWidth = paramInt2;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  protected void setInBarrier(int paramInt, boolean paramBoolean) {
    this.mIsInBarrier[paramInt] = paramBoolean;
  }
  
  public void setInPlaceholder(boolean paramBoolean) {
    this.inPlaceholder = paramBoolean;
  }
  
  public void setInVirtualLayout(boolean paramBoolean) {
    this.mInVirtualLayout = paramBoolean;
  }
  
  public void setLastMeasureSpec(int paramInt1, int paramInt2) {
    this.mLastHorizontalMeasureSpec = paramInt1;
    this.mLastVerticalMeasureSpec = paramInt2;
    setMeasureRequested(false);
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
      return;
    } 
    if (paramInt2 == 1)
      setHeight(paramInt1); 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMeasureRequested(boolean paramBoolean) {
    this.mMeasureRequested = paramBoolean;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
      return;
    } 
    this.mMinHeight = paramInt;
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
      return;
    } 
    this.mMinWidth = paramInt;
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
      return;
    } 
    if (paramInt2 == 1)
      this.mRelY = paramInt1; 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    this.mHeight = paramInt1;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    paramInt2 = paramInt3;
    if (paramInt3 == Integer.MAX_VALUE)
      paramInt2 = 0; 
    this.mMatchConstraintMaxHeight = paramInt2;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat > 0.0F && paramFloat < 1.0F && paramInt1 == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mMinWidth;
    if (paramInt < i)
      this.mWidth = i; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapBehaviorInParent(int paramInt) {
    if (paramInt >= 0 && paramInt <= 3)
      this.mWrapBehaviorInParent = paramInt; 
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1) {
      int i = this.mMatchConstraintMinWidth;
      if (i > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
        return;
      } 
      if (i == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   5: invokevirtual isResolved : ()Z
    //   8: iand
    //   9: istore #9
    //   11: iload_2
    //   12: aload_0
    //   13: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   16: invokevirtual isResolved : ()Z
    //   19: iand
    //   20: istore #8
    //   22: aload_0
    //   23: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   26: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   29: getfield value : I
    //   32: istore_3
    //   33: aload_0
    //   34: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   37: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   40: getfield value : I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   49: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   52: getfield value : I
    //   55: istore #7
    //   57: aload_0
    //   58: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   61: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   64: getfield value : I
    //   67: istore #6
    //   69: iload #7
    //   71: iload_3
    //   72: isub
    //   73: iflt -> 146
    //   76: iload #6
    //   78: iload #4
    //   80: isub
    //   81: iflt -> 146
    //   84: iload_3
    //   85: ldc_w -2147483648
    //   88: if_icmpeq -> 146
    //   91: iload_3
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 146
    //   97: iload #4
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 146
    //   105: iload #4
    //   107: ldc 2147483647
    //   109: if_icmpeq -> 146
    //   112: iload #7
    //   114: ldc_w -2147483648
    //   117: if_icmpeq -> 146
    //   120: iload #7
    //   122: ldc 2147483647
    //   124: if_icmpeq -> 146
    //   127: iload #6
    //   129: ldc_w -2147483648
    //   132: if_icmpeq -> 146
    //   135: iload #6
    //   137: istore #5
    //   139: iload #6
    //   141: ldc 2147483647
    //   143: if_icmpne -> 169
    //   146: iconst_0
    //   147: istore #6
    //   149: iload #6
    //   151: istore_3
    //   152: iload_3
    //   153: istore #4
    //   155: iload #4
    //   157: istore #5
    //   159: iload #4
    //   161: istore #7
    //   163: iload_3
    //   164: istore #4
    //   166: iload #6
    //   168: istore_3
    //   169: iload #7
    //   171: iload_3
    //   172: isub
    //   173: istore #6
    //   175: iload #5
    //   177: iload #4
    //   179: isub
    //   180: istore #5
    //   182: iload #9
    //   184: ifeq -> 192
    //   187: aload_0
    //   188: iload_3
    //   189: putfield mX : I
    //   192: iload #8
    //   194: ifeq -> 203
    //   197: aload_0
    //   198: iload #4
    //   200: putfield mY : I
    //   203: aload_0
    //   204: getfield mVisibility : I
    //   207: bipush #8
    //   209: if_icmpne -> 223
    //   212: aload_0
    //   213: iconst_0
    //   214: putfield mWidth : I
    //   217: aload_0
    //   218: iconst_0
    //   219: putfield mHeight : I
    //   222: return
    //   223: iload #9
    //   225: ifeq -> 285
    //   228: iload #6
    //   230: istore_3
    //   231: aload_0
    //   232: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   235: iconst_0
    //   236: aaload
    //   237: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   240: if_acmpne -> 262
    //   243: aload_0
    //   244: getfield mWidth : I
    //   247: istore #4
    //   249: iload #6
    //   251: istore_3
    //   252: iload #6
    //   254: iload #4
    //   256: if_icmpge -> 262
    //   259: iload #4
    //   261: istore_3
    //   262: aload_0
    //   263: iload_3
    //   264: putfield mWidth : I
    //   267: aload_0
    //   268: getfield mMinWidth : I
    //   271: istore #4
    //   273: iload_3
    //   274: iload #4
    //   276: if_icmpge -> 285
    //   279: aload_0
    //   280: iload #4
    //   282: putfield mWidth : I
    //   285: iload #8
    //   287: ifeq -> 347
    //   290: iload #5
    //   292: istore_3
    //   293: aload_0
    //   294: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   297: iconst_1
    //   298: aaload
    //   299: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   302: if_acmpne -> 324
    //   305: aload_0
    //   306: getfield mHeight : I
    //   309: istore #4
    //   311: iload #5
    //   313: istore_3
    //   314: iload #5
    //   316: iload #4
    //   318: if_icmpge -> 324
    //   321: iload #4
    //   323: istore_3
    //   324: aload_0
    //   325: iload_3
    //   326: putfield mHeight : I
    //   329: aload_0
    //   330: getfield mMinHeight : I
    //   333: istore #4
    //   335: iload_3
    //   336: iload #4
    //   338: if_icmpge -> 347
    //   341: aload_0
    //   342: iload #4
    //   344: putfield mHeight : I
    //   347: return
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore #4
    //   10: aload_1
    //   11: aload_0
    //   12: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   15: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   18: istore #7
    //   20: aload_1
    //   21: aload_0
    //   22: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   25: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   28: istore #6
    //   30: aload_1
    //   31: aload_0
    //   32: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   35: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   38: istore #8
    //   40: iload #4
    //   42: istore #5
    //   44: iload #6
    //   46: istore_3
    //   47: iload_2
    //   48: ifeq -> 127
    //   51: aload_0
    //   52: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   55: astore_1
    //   56: iload #4
    //   58: istore #5
    //   60: iload #6
    //   62: istore_3
    //   63: aload_1
    //   64: ifnull -> 127
    //   67: iload #4
    //   69: istore #5
    //   71: iload #6
    //   73: istore_3
    //   74: aload_1
    //   75: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   78: getfield resolved : Z
    //   81: ifeq -> 127
    //   84: iload #4
    //   86: istore #5
    //   88: iload #6
    //   90: istore_3
    //   91: aload_0
    //   92: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   95: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   98: getfield resolved : Z
    //   101: ifeq -> 127
    //   104: aload_0
    //   105: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   108: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   111: getfield value : I
    //   114: istore #5
    //   116: aload_0
    //   117: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   120: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   123: getfield value : I
    //   126: istore_3
    //   127: iload #7
    //   129: istore #6
    //   131: iload #8
    //   133: istore #4
    //   135: iload_2
    //   136: ifeq -> 219
    //   139: aload_0
    //   140: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   143: astore_1
    //   144: iload #7
    //   146: istore #6
    //   148: iload #8
    //   150: istore #4
    //   152: aload_1
    //   153: ifnull -> 219
    //   156: iload #7
    //   158: istore #6
    //   160: iload #8
    //   162: istore #4
    //   164: aload_1
    //   165: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   168: getfield resolved : Z
    //   171: ifeq -> 219
    //   174: iload #7
    //   176: istore #6
    //   178: iload #8
    //   180: istore #4
    //   182: aload_0
    //   183: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   186: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   189: getfield resolved : Z
    //   192: ifeq -> 219
    //   195: aload_0
    //   196: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   199: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   202: getfield value : I
    //   205: istore #6
    //   207: aload_0
    //   208: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   211: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   214: getfield value : I
    //   217: istore #4
    //   219: iload_3
    //   220: iload #5
    //   222: isub
    //   223: iflt -> 303
    //   226: iload #4
    //   228: iload #6
    //   230: isub
    //   231: iflt -> 303
    //   234: iload #5
    //   236: ldc_w -2147483648
    //   239: if_icmpeq -> 303
    //   242: iload #5
    //   244: ldc 2147483647
    //   246: if_icmpeq -> 303
    //   249: iload #6
    //   251: ldc_w -2147483648
    //   254: if_icmpeq -> 303
    //   257: iload #6
    //   259: ldc 2147483647
    //   261: if_icmpeq -> 303
    //   264: iload_3
    //   265: ldc_w -2147483648
    //   268: if_icmpeq -> 303
    //   271: iload_3
    //   272: ldc 2147483647
    //   274: if_icmpeq -> 303
    //   277: iload #4
    //   279: ldc_w -2147483648
    //   282: if_icmpeq -> 303
    //   285: iload #5
    //   287: istore #7
    //   289: iload_3
    //   290: istore #8
    //   292: iload #4
    //   294: istore #5
    //   296: iload #4
    //   298: ldc 2147483647
    //   300: if_icmpne -> 323
    //   303: iconst_0
    //   304: istore #5
    //   306: iload #5
    //   308: istore_3
    //   309: iload_3
    //   310: istore #4
    //   312: iload #4
    //   314: istore #8
    //   316: iload #4
    //   318: istore #6
    //   320: iload_3
    //   321: istore #7
    //   323: aload_0
    //   324: iload #7
    //   326: iload #6
    //   328: iload #8
    //   330: iload #5
    //   332: invokevirtual setFrame : (IIII)V
    //   335: return
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    static {
      DimensionBehaviour dimensionBehaviour1 = new DimensionBehaviour("FIXED", 0);
      FIXED = dimensionBehaviour1;
      DimensionBehaviour dimensionBehaviour2 = new DimensionBehaviour("WRAP_CONTENT", 1);
      WRAP_CONTENT = dimensionBehaviour2;
      DimensionBehaviour dimensionBehaviour3 = new DimensionBehaviour("MATCH_CONSTRAINT", 2);
      MATCH_CONSTRAINT = dimensionBehaviour3;
      DimensionBehaviour dimensionBehaviour4 = new DimensionBehaviour("MATCH_PARENT", 3);
      MATCH_PARENT = dimensionBehaviour4;
      $VALUES = new DimensionBehaviour[] { dimensionBehaviour1, dimensionBehaviour2, dimensionBehaviour3, dimensionBehaviour4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */