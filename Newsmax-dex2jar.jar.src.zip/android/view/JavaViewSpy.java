package android.view;

import android.content.Context;

class JavaViewSpy extends View {
  JavaViewSpy(Context paramContext) {
    super(paramContext);
    throw new UnsupportedOperationException("This class isn't meant to be instantiated");
  }
  
  static int windowAttachCount(View paramView) {
    return paramView.getWindowAttachCount();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Newsmax-dex2jar.jar!\android\view\JavaViewSpy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */