package com.airbnb.lottie;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import aw;
import ay;
import bw;
import by;
import dw;
import fe;
import fw;
import gw;
import gy;
import java.io.ByteArrayInputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import jn1;
import jw;
import kn1;
import kw;
import lw;
import mw;
import nw;
import qv;
import rv;
import rz;
import s10;
import s30;
import t10;
import tv;
import uv;
import vv;
import w10;
import wv;
import xv;
import yv;
import z10;
import zv;

public class LottieAnimationView extends AppCompatImageView {
  public static final String b = LottieAnimationView.class.getSimpleName();
  
  public static final dw<Throwable> c = new a();
  
  public Set<fw> A;
  
  public int B;
  
  public jw<wv> C;
  
  public wv D;
  
  public final dw<wv> d = new b(this);
  
  public final dw<Throwable> f = new c(this);
  
  public dw<Throwable> g;
  
  public int p;
  
  public final bw q;
  
  public boolean r;
  
  public String s;
  
  public int t;
  
  public boolean u;
  
  public boolean v;
  
  public boolean w;
  
  public boolean x;
  
  public boolean y;
  
  public lw z;
  
  public LottieAnimationView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    boolean bool = false;
    this.p = 0;
    bw bw1 = new bw();
    this.q = bw1;
    this.u = false;
    this.v = false;
    this.w = false;
    this.x = false;
    this.y = true;
    lw lw1 = lw.AUTOMATIC;
    this.z = lw1;
    this.A = new HashSet<fw>();
    this.B = 0;
    int i = jn1.lottieAnimationViewStyle;
    TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, kn1.LottieAnimationView, i, 0);
    this.y = typedArray.getBoolean(kn1.LottieAnimationView_lottie_cacheComposition, true);
    i = kn1.LottieAnimationView_lottie_rawRes;
    boolean bool1 = typedArray.hasValue(i);
    int j = kn1.LottieAnimationView_lottie_fileName;
    boolean bool2 = typedArray.hasValue(j);
    int k = kn1.LottieAnimationView_lottie_url;
    boolean bool3 = typedArray.hasValue(k);
    if (!bool1 || !bool2) {
      if (bool1) {
        i = typedArray.getResourceId(i, 0);
        if (i != 0)
          setAnimation(i); 
      } else if (bool2) {
        String str = typedArray.getString(j);
        if (str != null)
          setAnimation(str); 
      } else if (bool3) {
        String str = typedArray.getString(k);
        if (str != null)
          setAnimationFromUrl(str); 
      } 
      setFallbackResource(typedArray.getResourceId(kn1.LottieAnimationView_lottie_fallbackRes, 0));
      if (typedArray.getBoolean(kn1.LottieAnimationView_lottie_autoPlay, false)) {
        this.w = true;
        this.x = true;
      } 
      if (typedArray.getBoolean(kn1.LottieAnimationView_lottie_loop, false))
        bw1.f.setRepeatCount(-1); 
      i = kn1.LottieAnimationView_lottie_repeatMode;
      if (typedArray.hasValue(i))
        setRepeatMode(typedArray.getInt(i, 1)); 
      i = kn1.LottieAnimationView_lottie_repeatCount;
      if (typedArray.hasValue(i))
        setRepeatCount(typedArray.getInt(i, -1)); 
      i = kn1.LottieAnimationView_lottie_speed;
      if (typedArray.hasValue(i))
        setSpeed(typedArray.getFloat(i, 1.0F)); 
      setImageAssetsFolder(typedArray.getString(kn1.LottieAnimationView_lottie_imageAssetsFolder));
      setProgress(typedArray.getFloat(kn1.LottieAnimationView_lottie_progress, 0.0F));
      d(typedArray.getBoolean(kn1.LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove, false));
      i = kn1.LottieAnimationView_lottie_colorFilter;
      if (typedArray.hasValue(i)) {
        mw mw = new mw(typedArray.getColor(i, 0));
        gy gy = new gy(new String[] { "**" });
        z10 z10 = new z10(mw);
        bw1.a(gy, gw.C, z10);
      } 
      i = kn1.LottieAnimationView_lottie_scale;
      if (typedArray.hasValue(i)) {
        bw1.g = typedArray.getFloat(i, 1.0F);
        bw1.v();
      } 
      i = kn1.LottieAnimationView_lottie_renderMode;
      if (typedArray.hasValue(i)) {
        j = typedArray.getInt(i, lw1.ordinal());
        lw.values();
        i = j;
        if (j >= 3)
          i = lw1.ordinal(); 
        setRenderMode(lw.values()[i]);
      } 
      if (getScaleType() != null)
        bw1.t = getScaleType(); 
      typedArray.recycle();
      Context context = getContext();
      ThreadLocal threadLocal = w10.a;
      if (Settings.Global.getFloat(context.getContentResolver(), "animator_duration_scale", 1.0F) != 0.0F)
        bool = true; 
      Objects.requireNonNull(bw1);
      bw1.p = Boolean.valueOf(bool).booleanValue();
      e();
      this.r = true;
      return;
    } 
    throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
  }
  
  private void setCompositionTask(jw<wv> paramjw) {
    this.D = null;
    this.q.c();
    c();
    paramjw.b(this.d);
    paramjw.a(this.f);
    this.C = paramjw;
  }
  
  public void buildDrawingCache(boolean paramBoolean) {
    this.B++;
    super.buildDrawingCache(paramBoolean);
    if (this.B == 1 && getWidth() > 0 && getHeight() > 0 && getLayerType() == 1 && getDrawingCache(paramBoolean) == null)
      setRenderMode(lw.HARDWARE); 
    this.B--;
    tv.a("buildDrawingCache");
  }
  
  public final void c() {
    jw<wv> jw1 = this.C;
    if (jw1 != null)
      synchronized (this.d) {
        jw1.b.remove(null);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{jw<ObjectType{wv}>}, name=null} */
        jw1 = this.C;
        synchronized (this.f) {
          jw1.c.remove(null);
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{jw<ObjectType{wv}>}, name=null} */
          return;
        } 
      }  
  }
  
  public void d(boolean paramBoolean) {
    bw bw1 = this.q;
    if (bw1.z == paramBoolean)
      return; 
    bw1.z = paramBoolean;
    if (bw1.d != null)
      bw1.b(); 
  }
  
  public final void e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield z : Llw;
    //   4: invokevirtual ordinal : ()I
    //   7: istore_3
    //   8: iconst_2
    //   9: istore_2
    //   10: iload_3
    //   11: ifeq -> 26
    //   14: iload_2
    //   15: istore_1
    //   16: iload_3
    //   17: iconst_1
    //   18: if_icmpeq -> 125
    //   21: iconst_1
    //   22: istore_1
    //   23: goto -> 125
    //   26: aload_0
    //   27: getfield D : Lwv;
    //   30: astore #5
    //   32: iconst_0
    //   33: istore_3
    //   34: aload #5
    //   36: ifnull -> 60
    //   39: aload #5
    //   41: getfield n : Z
    //   44: ifeq -> 60
    //   47: getstatic android/os/Build$VERSION.SDK_INT : I
    //   50: bipush #28
    //   52: if_icmpge -> 60
    //   55: iload_3
    //   56: istore_1
    //   57: goto -> 119
    //   60: aload #5
    //   62: ifnull -> 79
    //   65: aload #5
    //   67: getfield o : I
    //   70: iconst_4
    //   71: if_icmple -> 79
    //   74: iload_3
    //   75: istore_1
    //   76: goto -> 119
    //   79: getstatic android/os/Build$VERSION.SDK_INT : I
    //   82: istore #4
    //   84: iload #4
    //   86: bipush #21
    //   88: if_icmpge -> 96
    //   91: iload_3
    //   92: istore_1
    //   93: goto -> 119
    //   96: iload_3
    //   97: istore_1
    //   98: iload #4
    //   100: bipush #24
    //   102: if_icmpeq -> 119
    //   105: iload #4
    //   107: bipush #25
    //   109: if_icmpne -> 117
    //   112: iload_3
    //   113: istore_1
    //   114: goto -> 119
    //   117: iconst_1
    //   118: istore_1
    //   119: iload_1
    //   120: ifeq -> 21
    //   123: iload_2
    //   124: istore_1
    //   125: iload_1
    //   126: aload_0
    //   127: invokevirtual getLayerType : ()I
    //   130: if_icmpeq -> 139
    //   133: aload_0
    //   134: iload_1
    //   135: aconst_null
    //   136: invokevirtual setLayerType : (ILandroid/graphics/Paint;)V
    //   139: return
  }
  
  public void f() {
    if (isShown()) {
      this.q.j();
      e();
      return;
    } 
    this.u = true;
  }
  
  public wv getComposition() {
    return this.D;
  }
  
  public long getDuration() {
    wv wv1 = this.D;
    return (wv1 != null) ? (long)wv1.b() : 0L;
  }
  
  public int getFrame() {
    return (int)this.q.f.p;
  }
  
  public String getImageAssetsFolder() {
    return this.q.v;
  }
  
  public String getImageRenderFolder() {
    return this.q.w;
  }
  
  public float getMaxFrame() {
    return this.q.e();
  }
  
  public float getMinFrame() {
    return this.q.f();
  }
  
  public kw getPerformanceTracker() {
    wv wv1 = this.q.d;
    return (wv1 != null) ? wv1.a : null;
  }
  
  public float getProgress() {
    return this.q.g();
  }
  
  public int getRepeatCount() {
    return this.q.h();
  }
  
  public int getRepeatMode() {
    return this.q.f.getRepeatMode();
  }
  
  public float getScale() {
    return this.q.g;
  }
  
  public float getSpeed() {
    return this.q.f.d;
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    Drawable drawable = getDrawable();
    bw bw1 = this.q;
    if (drawable == bw1) {
      super.invalidateDrawable((Drawable)bw1);
      return;
    } 
    super.invalidateDrawable(paramDrawable);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (!isInEditMode() && (this.x || this.w)) {
      f();
      this.x = false;
      this.w = false;
    } 
    if (Build.VERSION.SDK_INT < 23)
      onVisibilityChanged((View)this, getVisibility()); 
  }
  
  public void onDetachedFromWindow() {
    if (this.q.i()) {
      this.w = false;
      this.v = false;
      this.u = false;
      bw bw1 = this.q;
      bw1.r.clear();
      bw1.f.cancel();
      e();
      this.w = true;
    } 
    super.onDetachedFromWindow();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof d)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    d d = (d)paramParcelable;
    super.onRestoreInstanceState(d.getSuperState());
    String str = d.b;
    this.s = str;
    if (!TextUtils.isEmpty(str))
      setAnimation(this.s); 
    int i = d.c;
    this.t = i;
    if (i != 0)
      setAnimation(i); 
    setProgress(d.d);
    if (d.f)
      f(); 
    this.q.v = d.g;
    setRepeatMode(d.p);
    setRepeatCount(d.q);
  }
  
  public Parcelable onSaveInstanceState() {
    d d = new d(super.onSaveInstanceState());
    d.b = this.s;
    d.c = this.t;
    d.d = this.q.g();
    if (!this.q.i()) {
      AtomicInteger atomicInteger = fe.a;
      if (!fe.g.b((View)this) && this.w) {
        boolean bool2 = true;
        d.f = bool2;
        bw bw3 = this.q;
        d.g = bw3.v;
        d.p = bw3.f.getRepeatMode();
        d.q = this.q.h();
        return (Parcelable)d;
      } 
      boolean bool1 = false;
      d.f = bool1;
      bw bw2 = this.q;
      d.g = bw2.v;
      d.p = bw2.f.getRepeatMode();
      d.q = this.q.h();
      return (Parcelable)d;
    } 
    boolean bool = true;
    d.f = bool;
    bw bw1 = this.q;
    d.g = bw1.v;
    d.p = bw1.f.getRepeatMode();
    d.q = this.q.h();
    return (Parcelable)d;
  }
  
  public void onVisibilityChanged(View paramView, int paramInt) {
    if (!this.r)
      return; 
    if (isShown()) {
      if (this.v) {
        if (isShown()) {
          this.q.k();
          e();
        } else {
          this.u = false;
          this.v = true;
        } 
      } else if (this.u) {
        f();
      } 
      this.v = false;
      this.u = false;
      return;
    } 
    if (this.q.i()) {
      this.x = false;
      this.w = false;
      this.v = false;
      this.u = false;
      bw bw1 = this.q;
      bw1.r.clear();
      bw1.f.i();
      e();
      this.v = true;
    } 
  }
  
  public void setAnimation(int paramInt) {
    jw<wv> jw1;
    this.t = paramInt;
    this.s = null;
    if (isInEditMode()) {
      jw1 = new jw((Callable)new uv(this, paramInt), true);
    } else if (this.y) {
      Context context = getContext();
      String str = xv.k(context, paramInt);
      jw1 = xv.a(str, (Callable)new zv(new WeakReference<Context>(context), context.getApplicationContext(), paramInt, str));
    } else {
      Context context = getContext();
      Map map = xv.a;
      jw1 = xv.a(null, (Callable)new zv(new WeakReference<Context>(context), context.getApplicationContext(), paramInt, null));
    } 
    setCompositionTask(jw1);
  }
  
  public void setAnimation(String paramString) {
    jw<wv> jw1;
    this.s = paramString;
    this.t = 0;
    if (isInEditMode()) {
      jw1 = new jw((Callable)new vv(this, paramString), true);
    } else if (this.y) {
      jw1 = xv.b(getContext(), (String)jw1);
    } else {
      jw1 = xv.c(getContext(), (String)jw1, null);
    } 
    setCompositionTask(jw1);
  }
  
  @Deprecated
  public void setAnimationFromJson(String paramString) {
    setCompositionTask(xv.a(null, (Callable)new aw(new ByteArrayInputStream(paramString.getBytes()), null)));
  }
  
  public void setAnimationFromUrl(String paramString) {
    jw<wv> jw1;
    if (this.y) {
      Context context = getContext();
      Map map = xv.a;
      String str = s30.g0("url_", paramString);
      jw1 = xv.a(str, (Callable)new yv(context, paramString, str));
    } else {
      jw1 = xv.a(null, (Callable)new yv(getContext(), (String)jw1, null));
    } 
    setCompositionTask(jw1);
  }
  
  public void setApplyingOpacityToLayersEnabled(boolean paramBoolean) {
    this.q.E = paramBoolean;
  }
  
  public void setCacheComposition(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setComposition(wv paramwv) {
    this.q.setCallback((Drawable.Callback)this);
    this.D = paramwv;
    bw bw1 = this.q;
    wv wv1 = bw1.d;
    boolean bool2 = false;
    boolean bool1 = false;
    if (wv1 == paramwv) {
      bool1 = bool2;
    } else {
      bw1.G = false;
      bw1.c();
      bw1.d = paramwv;
      bw1.b();
      t10 t10 = bw1.f;
      if (t10.t == null)
        bool1 = true; 
      t10.t = paramwv;
      if (bool1) {
        t10.k((int)Math.max(t10.r, paramwv.k), (int)Math.min(t10.s, paramwv.l));
      } else {
        t10.k((int)paramwv.k, (int)paramwv.l);
      } 
      float f = t10.p;
      t10.p = 0.0F;
      t10.j((int)f);
      t10.b();
      bw1.u(bw1.f.getAnimatedFraction());
      bw1.g = bw1.g;
      bw1.v();
      bw1.v();
      Iterator<?> iterator1 = (new ArrayList(bw1.r)).iterator();
      while (iterator1.hasNext()) {
        ((bw.o)iterator1.next()).a(paramwv);
        iterator1.remove();
      } 
      bw1.r.clear();
      boolean bool = bw1.C;
      paramwv.a.a = bool;
      Drawable.Callback callback = bw1.getCallback();
      if (callback instanceof ImageView) {
        ImageView imageView = (ImageView)callback;
        imageView.setImageDrawable(null);
        imageView.setImageDrawable((Drawable)bw1);
      } 
      bool1 = true;
    } 
    e();
    if (getDrawable() == this.q && !bool1)
      return; 
    onVisibilityChanged((View)this, getVisibility());
    requestLayout();
    Iterator<fw> iterator = this.A.iterator();
    while (iterator.hasNext())
      ((fw)iterator.next()).a(paramwv); 
  }
  
  public void setFailureListener(dw<Throwable> paramdw) {
    this.g = paramdw;
  }
  
  public void setFallbackResource(int paramInt) {
    this.p = paramInt;
  }
  
  public void setFontAssetDelegate(qv paramqv) {
    ay ay = this.q.y;
  }
  
  public void setFrame(int paramInt) {
    this.q.l(paramInt);
  }
  
  public void setImageAssetDelegate(rv paramrv) {
    bw bw1 = this.q;
    bw1.x = paramrv;
    by by = bw1.u;
    if (by != null)
      by.d = paramrv; 
  }
  
  public void setImageAssetsFolder(String paramString) {
    this.q.v = paramString;
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    c();
    super.setImageBitmap(paramBitmap);
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    c();
    super.setImageDrawable(paramDrawable);
  }
  
  public void setImageRenderFolder(String paramString) {
    this.q.w = paramString;
  }
  
  public void setImageResource(int paramInt) {
    c();
    super.setImageResource(paramInt);
  }
  
  public void setMaxFrame(int paramInt) {
    this.q.m(paramInt);
  }
  
  public void setMaxFrame(String paramString) {
    this.q.n(paramString);
  }
  
  public void setMaxProgress(float paramFloat) {
    this.q.o(paramFloat);
  }
  
  public void setMinAndMaxFrame(String paramString) {
    this.q.q(paramString);
  }
  
  public void setMinFrame(int paramInt) {
    this.q.r(paramInt);
  }
  
  public void setMinFrame(String paramString) {
    this.q.s(paramString);
  }
  
  public void setMinProgress(float paramFloat) {
    this.q.t(paramFloat);
  }
  
  public void setOutlineMasksAndMattes(boolean paramBoolean) {
    bw bw1 = this.q;
    if (bw1.D == paramBoolean)
      return; 
    bw1.D = paramBoolean;
    rz rz = bw1.A;
    if (rz != null)
      rz.o(paramBoolean); 
  }
  
  public void setPerformanceTrackingEnabled(boolean paramBoolean) {
    bw bw1 = this.q;
    bw1.C = paramBoolean;
    wv wv1 = bw1.d;
    if (wv1 != null)
      wv1.a.a = paramBoolean; 
  }
  
  public void setProgress(float paramFloat) {
    this.q.u(paramFloat);
  }
  
  public void setRenderMode(lw paramlw) {
    this.z = paramlw;
    e();
  }
  
  public void setRepeatCount(int paramInt) {
    this.q.f.setRepeatCount(paramInt);
  }
  
  public void setRepeatMode(int paramInt) {
    this.q.f.setRepeatMode(paramInt);
  }
  
  public void setSafeMode(boolean paramBoolean) {
    this.q.q = paramBoolean;
  }
  
  public void setScale(float paramFloat) {
    bw bw1 = this.q;
    bw1.g = paramFloat;
    bw1.v();
    if (getDrawable() == this.q) {
      setImageDrawable(null);
      setImageDrawable((Drawable)this.q);
    } 
  }
  
  public void setScaleType(ImageView.ScaleType paramScaleType) {
    super.setScaleType(paramScaleType);
    bw bw1 = this.q;
    if (bw1 != null)
      bw1.t = paramScaleType; 
  }
  
  public void setSpeed(float paramFloat) {
    this.q.f.d = paramFloat;
  }
  
  public void setTextDelegate(nw paramnw) {
    Objects.requireNonNull(this.q);
  }
  
  public class a implements dw<Throwable> {
    public void a(Object param1Object) {
      boolean bool;
      param1Object = param1Object;
      ThreadLocal threadLocal = w10.a;
      if (param1Object instanceof java.net.SocketException || param1Object instanceof java.nio.channels.ClosedChannelException || param1Object instanceof java.io.InterruptedIOException || param1Object instanceof java.net.ProtocolException || param1Object instanceof javax.net.ssl.SSLException || param1Object instanceof java.net.UnknownHostException || param1Object instanceof java.net.UnknownServiceException) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        s10.c("Unable to load composition.", (Throwable)param1Object);
        return;
      } 
      throw new IllegalStateException("Unable to parse composition", param1Object);
    }
  }
  
  public class b implements dw<wv> {
    public b(LottieAnimationView this$0) {}
    
    public void a(Object param1Object) {
      param1Object = param1Object;
      this.a.setComposition((wv)param1Object);
    }
  }
  
  public class c implements dw<Throwable> {
    public c(LottieAnimationView this$0) {}
    
    public void a(Object<Throwable> param1Object) {
      dw<Throwable> dw1;
      Throwable throwable = (Throwable)param1Object;
      param1Object = (Object<Throwable>)this.a;
      int i = ((LottieAnimationView)param1Object).p;
      if (i != 0)
        param1Object.setImageResource(i); 
      dw<Throwable> dw2 = this.a.g;
      param1Object = (Object<Throwable>)dw2;
      if (dw2 == null) {
        param1Object = (Object<Throwable>)LottieAnimationView.b;
        dw1 = LottieAnimationView.c;
      } 
      dw1.a(throwable);
    }
  }
  
  public static class d extends View.BaseSavedState {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    public String b;
    
    public int c;
    
    public float d;
    
    public boolean f;
    
    public String g;
    
    public int p;
    
    public int q;
    
    public d(Parcel param1Parcel, LottieAnimationView.a param1a) {
      super(param1Parcel);
      this.b = param1Parcel.readString();
      this.d = param1Parcel.readFloat();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.f = bool;
      this.g = param1Parcel.readString();
      this.p = param1Parcel.readInt();
      this.q = param1Parcel.readInt();
    }
    
    public d(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<d> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new LottieAnimationView.d(param2Parcel, null);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new LottieAnimationView.d[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<d> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new LottieAnimationView.d(param1Parcel, null);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new LottieAnimationView.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\airbnb\lottie\LottieAnimationView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */