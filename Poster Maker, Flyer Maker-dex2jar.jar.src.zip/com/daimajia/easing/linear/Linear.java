package com.daimajia.easing.linear;

import com.daimajia.easing.BaseEasingMethod;

public class Linear extends BaseEasingMethod {
  public Linear(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return Float.valueOf(paramFloat3 * paramFloat1 / paramFloat4 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\linear\Linear.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */