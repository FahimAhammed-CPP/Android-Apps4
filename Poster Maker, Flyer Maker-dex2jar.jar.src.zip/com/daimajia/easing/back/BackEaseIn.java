package com.daimajia.easing.back;

import com.daimajia.easing.BaseEasingMethod;

public class BackEaseIn extends BaseEasingMethod {
  private float s = 1.70158F;
  
  public BackEaseIn(float paramFloat) {
    super(paramFloat);
  }
  
  public BackEaseIn(float paramFloat1, float paramFloat2) {
    this(paramFloat1);
    this.s = paramFloat2;
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 /= paramFloat4;
    paramFloat4 = this.s;
    return Float.valueOf(((1.0F + paramFloat4) * paramFloat1 - paramFloat4) * paramFloat3 * paramFloat1 * paramFloat1 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\back\BackEaseIn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */