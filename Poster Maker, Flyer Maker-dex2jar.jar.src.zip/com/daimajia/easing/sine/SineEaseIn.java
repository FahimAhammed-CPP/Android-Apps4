package com.daimajia.easing.sine;

import com.daimajia.easing.BaseEasingMethod;

public class SineEaseIn extends BaseEasingMethod {
  public SineEaseIn(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    float f = -paramFloat3;
    double d = (paramFloat1 / paramFloat4);
    Double.isNaN(d);
    return Float.valueOf(f * (float)Math.cos(d * 1.5707963267948966D) + paramFloat3 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\sine\SineEaseIn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */