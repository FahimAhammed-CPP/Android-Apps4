package com.daimajia.easing.sine;

import com.daimajia.easing.BaseEasingMethod;

public class SineEaseOut extends BaseEasingMethod {
  public SineEaseOut(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    double d = (paramFloat1 / paramFloat4);
    Double.isNaN(d);
    return Float.valueOf(paramFloat3 * (float)Math.sin(d * 1.5707963267948966D) + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\sine\SineEaseOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */