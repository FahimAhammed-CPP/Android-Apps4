package com.daimajia.easing.sine;

import com.daimajia.easing.BaseEasingMethod;

public class SineEaseInOut extends BaseEasingMethod {
  public SineEaseInOut(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat3 = -paramFloat3 / 2.0F;
    double d1 = paramFloat1;
    Double.isNaN(d1);
    double d2 = paramFloat4;
    Double.isNaN(d2);
    return Float.valueOf(((float)Math.cos(d1 * Math.PI / d2) - 1.0F) * paramFloat3 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\sine\SineEaseInOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */