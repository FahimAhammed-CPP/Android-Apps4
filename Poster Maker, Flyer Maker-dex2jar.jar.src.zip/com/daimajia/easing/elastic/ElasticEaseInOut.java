package com.daimajia.easing.elastic;

import com.daimajia.easing.BaseEasingMethod;

public class ElasticEaseInOut extends BaseEasingMethod {
  public ElasticEaseInOut(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (paramFloat1 == 0.0F)
      return Float.valueOf(paramFloat2); 
    float f2 = paramFloat1 / paramFloat4 / 2.0F;
    if (f2 == 2.0F)
      return Float.valueOf(paramFloat2 + paramFloat3); 
    paramFloat1 = 0.45000002F * paramFloat4;
    float f1 = paramFloat1 / 4.0F;
    if (f2 < 1.0F) {
      f2--;
      return Float.valueOf(paramFloat3 * (float)Math.pow(2.0D, (10.0F * f2)) * (float)Math.sin(((f2 * paramFloat4 - f1) * 6.2831855F / paramFloat1)) * -0.5F + paramFloat2);
    } 
    f2--;
    return Float.valueOf((float)Math.pow(2.0D, (-10.0F * f2)) * paramFloat3 * (float)Math.sin(((f2 * paramFloat4 - f1) * 6.2831855F / paramFloat1)) * 0.5F + paramFloat3 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\elastic\ElasticEaseInOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */