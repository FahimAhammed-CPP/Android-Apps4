package com.daimajia.easing;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;

public class Glider {
  public static PropertyValuesHolder glide(Skill paramSkill, float paramFloat, PropertyValuesHolder paramPropertyValuesHolder) {
    paramPropertyValuesHolder.setEvaluator(paramSkill.getMethod(paramFloat));
    return paramPropertyValuesHolder;
  }
  
  public static ValueAnimator glide(Skill paramSkill, float paramFloat, ValueAnimator paramValueAnimator) {
    return glide(paramSkill, paramFloat, paramValueAnimator, null);
  }
  
  public static ValueAnimator glide(Skill paramSkill, float paramFloat, ValueAnimator paramValueAnimator, BaseEasingMethod.EasingListener... paramVarArgs) {
    BaseEasingMethod baseEasingMethod = paramSkill.getMethod(paramFloat);
    if (paramVarArgs != null)
      baseEasingMethod.addEasingListeners(paramVarArgs); 
    paramValueAnimator.setEvaluator(baseEasingMethod);
    return paramValueAnimator;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\Glider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */