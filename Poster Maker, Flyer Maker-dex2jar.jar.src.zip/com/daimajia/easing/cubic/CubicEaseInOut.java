package com.daimajia.easing.cubic;

import com.daimajia.easing.BaseEasingMethod;

public class CubicEaseInOut extends BaseEasingMethod {
  public CubicEaseInOut(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 /= paramFloat4 / 2.0F;
    if (paramFloat1 < 1.0F)
      return Float.valueOf(paramFloat3 / 2.0F * paramFloat1 * paramFloat1 * paramFloat1 + paramFloat2); 
    paramFloat3 /= 2.0F;
    paramFloat1 -= 2.0F;
    return Float.valueOf((paramFloat1 * paramFloat1 * paramFloat1 + 2.0F) * paramFloat3 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\cubic\CubicEaseInOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */