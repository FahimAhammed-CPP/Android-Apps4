package com.daimajia.easing.bounce;

import com.daimajia.easing.BaseEasingMethod;

public class BounceEaseInOut extends BaseEasingMethod {
  private BounceEaseIn mBounceEaseIn;
  
  private BounceEaseOut mBounceEaseOut;
  
  public BounceEaseInOut(float paramFloat) {
    super(paramFloat);
    this.mBounceEaseIn = new BounceEaseIn(paramFloat);
    this.mBounceEaseOut = new BounceEaseOut(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (paramFloat1 < paramFloat4 / 2.0F) ? Float.valueOf(this.mBounceEaseIn.calculate(paramFloat1 * 2.0F, 0.0F, paramFloat3, paramFloat4).floatValue() * 0.5F + paramFloat2) : Float.valueOf(paramFloat3 * 0.5F + this.mBounceEaseOut.calculate(paramFloat1 * 2.0F - paramFloat4, 0.0F, paramFloat3, paramFloat4).floatValue() * 0.5F + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\bounce\BounceEaseInOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */