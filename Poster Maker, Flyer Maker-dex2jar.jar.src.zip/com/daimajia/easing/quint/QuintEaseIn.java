package com.daimajia.easing.quint;

import com.daimajia.easing.BaseEasingMethod;

public class QuintEaseIn extends BaseEasingMethod {
  public QuintEaseIn(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 /= paramFloat4;
    return Float.valueOf(paramFloat3 * paramFloat1 * paramFloat1 * paramFloat1 * paramFloat1 * paramFloat1 + paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\quint\QuintEaseIn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */