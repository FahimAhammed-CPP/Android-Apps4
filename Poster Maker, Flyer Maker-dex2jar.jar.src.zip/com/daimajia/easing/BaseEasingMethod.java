package com.daimajia.easing;

import android.animation.TypeEvaluator;
import java.util.ArrayList;
import java.util.Iterator;

public abstract class BaseEasingMethod implements TypeEvaluator<Number> {
  public float mDuration;
  
  private ArrayList<EasingListener> mListeners = new ArrayList<EasingListener>();
  
  public BaseEasingMethod(float paramFloat) {
    this.mDuration = paramFloat;
  }
  
  public void addEasingListener(EasingListener paramEasingListener) {
    this.mListeners.add(paramEasingListener);
  }
  
  public void addEasingListeners(EasingListener... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      EasingListener easingListener = paramVarArgs[i];
      this.mListeners.add(easingListener);
    } 
  }
  
  public abstract Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public void clearEasingListeners() {
    this.mListeners.clear();
  }
  
  public final Float evaluate(float paramFloat, Number paramNumber1, Number paramNumber2) {
    paramFloat = this.mDuration * paramFloat;
    float f1 = paramNumber1.floatValue();
    float f2 = paramNumber2.floatValue() - paramNumber1.floatValue();
    float f3 = this.mDuration;
    float f4 = calculate(paramFloat, f1, f2, f3).floatValue();
    Iterator<EasingListener> iterator = this.mListeners.iterator();
    while (iterator.hasNext())
      ((EasingListener)iterator.next()).on(paramFloat, f4, f1, f2, f3); 
    return Float.valueOf(f4);
  }
  
  public void removeEasingListener(EasingListener paramEasingListener) {
    this.mListeners.remove(paramEasingListener);
  }
  
  public void setDuration(float paramFloat) {
    this.mDuration = paramFloat;
  }
  
  public static interface EasingListener {
    void on(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\BaseEasingMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */