package com.daimajia.easing.expo;

import com.daimajia.easing.BaseEasingMethod;

public class ExpoEaseOut extends BaseEasingMethod {
  public ExpoEaseOut(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (paramFloat1 == paramFloat4) {
      paramFloat1 = paramFloat2 + paramFloat3;
    } else {
      paramFloat1 = paramFloat2 + (-((float)Math.pow(2.0D, (paramFloat1 * -10.0F / paramFloat4))) + 1.0F) * paramFloat3;
    } 
    return Float.valueOf(paramFloat1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\expo\ExpoEaseOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */