package com.daimajia.easing.expo;

import com.daimajia.easing.BaseEasingMethod;

public class ExpoEaseIn extends BaseEasingMethod {
  public ExpoEaseIn(float paramFloat) {
    super(paramFloat);
  }
  
  public Float calculate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (paramFloat1 != 0.0F)
      paramFloat2 += paramFloat3 * (float)Math.pow(2.0D, ((paramFloat1 / paramFloat4 - 1.0F) * 10.0F)); 
    return Float.valueOf(paramFloat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\expo\ExpoEaseIn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */