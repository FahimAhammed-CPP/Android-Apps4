package com.daimajia.easing;

import com.daimajia.easing.back.BackEaseIn;
import com.daimajia.easing.back.BackEaseInOut;
import com.daimajia.easing.back.BackEaseOut;
import com.daimajia.easing.bounce.BounceEaseIn;
import com.daimajia.easing.bounce.BounceEaseInOut;
import com.daimajia.easing.bounce.BounceEaseOut;
import com.daimajia.easing.circ.CircEaseIn;
import com.daimajia.easing.circ.CircEaseInOut;
import com.daimajia.easing.circ.CircEaseOut;
import com.daimajia.easing.cubic.CubicEaseIn;
import com.daimajia.easing.cubic.CubicEaseInOut;
import com.daimajia.easing.cubic.CubicEaseOut;
import com.daimajia.easing.elastic.ElasticEaseIn;
import com.daimajia.easing.elastic.ElasticEaseOut;
import com.daimajia.easing.expo.ExpoEaseIn;
import com.daimajia.easing.expo.ExpoEaseInOut;
import com.daimajia.easing.expo.ExpoEaseOut;
import com.daimajia.easing.linear.Linear;
import com.daimajia.easing.quad.QuadEaseIn;
import com.daimajia.easing.quad.QuadEaseInOut;
import com.daimajia.easing.quad.QuadEaseOut;
import com.daimajia.easing.quint.QuintEaseIn;
import com.daimajia.easing.quint.QuintEaseInOut;
import com.daimajia.easing.quint.QuintEaseOut;
import com.daimajia.easing.sine.SineEaseIn;
import com.daimajia.easing.sine.SineEaseInOut;
import com.daimajia.easing.sine.SineEaseOut;

public enum Skill {
  BackEaseIn, BackEaseInOut, BackEaseOut, BounceEaseIn, BounceEaseInOut, BounceEaseOut, CircEaseIn, CircEaseInOut, CircEaseOut, CubicEaseIn, CubicEaseInOut, CubicEaseOut, ElasticEaseIn, ElasticEaseOut, ExpoEaseIn, ExpoEaseInOut, ExpoEaseOut, Linear, QuadEaseIn, QuadEaseInOut, QuadEaseOut, QuintEaseIn, QuintEaseInOut, QuintEaseOut, SineEaseIn, SineEaseInOut, SineEaseOut;
  
  private Class easingMethod;
  
  static {
    Skill skill1 = new Skill("BackEaseIn", 0, BackEaseIn.class);
    BackEaseIn = skill1;
    Skill skill2 = new Skill("BackEaseOut", 1, BackEaseOut.class);
    BackEaseOut = skill2;
    Skill skill3 = new Skill("BackEaseInOut", 2, BackEaseInOut.class);
    BackEaseInOut = skill3;
    Skill skill4 = new Skill("BounceEaseIn", 3, BounceEaseIn.class);
    BounceEaseIn = skill4;
    Skill skill5 = new Skill("BounceEaseOut", 4, BounceEaseOut.class);
    BounceEaseOut = skill5;
    Skill skill6 = new Skill("BounceEaseInOut", 5, BounceEaseInOut.class);
    BounceEaseInOut = skill6;
    Skill skill7 = new Skill("CircEaseIn", 6, CircEaseIn.class);
    CircEaseIn = skill7;
    Skill skill8 = new Skill("CircEaseOut", 7, CircEaseOut.class);
    CircEaseOut = skill8;
    Skill skill9 = new Skill("CircEaseInOut", 8, CircEaseInOut.class);
    CircEaseInOut = skill9;
    Skill skill10 = new Skill("CubicEaseIn", 9, CubicEaseIn.class);
    CubicEaseIn = skill10;
    Skill skill11 = new Skill("CubicEaseOut", 10, CubicEaseOut.class);
    CubicEaseOut = skill11;
    Skill skill12 = new Skill("CubicEaseInOut", 11, CubicEaseInOut.class);
    CubicEaseInOut = skill12;
    Skill skill13 = new Skill("ElasticEaseIn", 12, ElasticEaseIn.class);
    ElasticEaseIn = skill13;
    Skill skill14 = new Skill("ElasticEaseOut", 13, ElasticEaseOut.class);
    ElasticEaseOut = skill14;
    Skill skill15 = new Skill("ExpoEaseIn", 14, ExpoEaseIn.class);
    ExpoEaseIn = skill15;
    Skill skill16 = new Skill("ExpoEaseOut", 15, ExpoEaseOut.class);
    ExpoEaseOut = skill16;
    Skill skill17 = new Skill("ExpoEaseInOut", 16, ExpoEaseInOut.class);
    ExpoEaseInOut = skill17;
    Skill skill18 = new Skill("QuadEaseIn", 17, QuadEaseIn.class);
    QuadEaseIn = skill18;
    Skill skill19 = new Skill("QuadEaseOut", 18, QuadEaseOut.class);
    QuadEaseOut = skill19;
    Skill skill20 = new Skill("QuadEaseInOut", 19, QuadEaseInOut.class);
    QuadEaseInOut = skill20;
    Skill skill21 = new Skill("QuintEaseIn", 20, QuintEaseIn.class);
    QuintEaseIn = skill21;
    Skill skill22 = new Skill("QuintEaseOut", 21, QuintEaseOut.class);
    QuintEaseOut = skill22;
    Skill skill23 = new Skill("QuintEaseInOut", 22, QuintEaseInOut.class);
    QuintEaseInOut = skill23;
    Skill skill24 = new Skill("SineEaseIn", 23, SineEaseIn.class);
    SineEaseIn = skill24;
    Skill skill25 = new Skill("SineEaseOut", 24, SineEaseOut.class);
    SineEaseOut = skill25;
    Skill skill26 = new Skill("SineEaseInOut", 25, SineEaseInOut.class);
    SineEaseInOut = skill26;
    Skill skill27 = new Skill("Linear", 26, Linear.class);
    Linear = skill27;
    $VALUES = new Skill[] { 
        skill1, skill2, skill3, skill4, skill5, skill6, skill7, skill8, skill9, skill10, 
        skill11, skill12, skill13, skill14, skill15, skill16, skill17, skill18, skill19, skill20, 
        skill21, skill22, skill23, skill24, skill25, skill26, skill27 };
  }
  
  Skill(Class paramClass) {
    this.easingMethod = paramClass;
  }
  
  public BaseEasingMethod getMethod(float paramFloat) {
    try {
      return this.easingMethod.getConstructor(new Class[] { float.class }).newInstance(new Object[] { Float.valueOf(paramFloat) });
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new Error("Can not init easingMethod instance");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\easing\Skill.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */