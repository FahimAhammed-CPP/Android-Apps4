package com.daimajia.androidanimations.library;

import com.daimajia.androidanimations.library.attention.BounceAnimator;
import com.daimajia.androidanimations.library.attention.FlashAnimator;
import com.daimajia.androidanimations.library.attention.PulseAnimator;
import com.daimajia.androidanimations.library.attention.RubberBandAnimator;
import com.daimajia.androidanimations.library.attention.ShakeAnimator;
import com.daimajia.androidanimations.library.attention.StandUpAnimator;
import com.daimajia.androidanimations.library.attention.SwingAnimator;
import com.daimajia.androidanimations.library.attention.TadaAnimator;
import com.daimajia.androidanimations.library.attention.WaveAnimator;
import com.daimajia.androidanimations.library.attention.WobbleAnimator;
import com.daimajia.androidanimations.library.bouncing_entrances.BounceInAnimator;
import com.daimajia.androidanimations.library.bouncing_entrances.BounceInDownAnimator;
import com.daimajia.androidanimations.library.bouncing_entrances.BounceInLeftAnimator;
import com.daimajia.androidanimations.library.bouncing_entrances.BounceInRightAnimator;
import com.daimajia.androidanimations.library.bouncing_entrances.BounceInUpAnimator;
import com.daimajia.androidanimations.library.fading_entrances.FadeInAnimator;
import com.daimajia.androidanimations.library.fading_entrances.FadeInDownAnimator;
import com.daimajia.androidanimations.library.fading_entrances.FadeInLeftAnimator;
import com.daimajia.androidanimations.library.fading_entrances.FadeInRightAnimator;
import com.daimajia.androidanimations.library.fading_entrances.FadeInUpAnimator;
import com.daimajia.androidanimations.library.fading_exits.FadeOutAnimator;
import com.daimajia.androidanimations.library.fading_exits.FadeOutDownAnimator;
import com.daimajia.androidanimations.library.fading_exits.FadeOutLeftAnimator;
import com.daimajia.androidanimations.library.fading_exits.FadeOutRightAnimator;
import com.daimajia.androidanimations.library.fading_exits.FadeOutUpAnimator;
import com.daimajia.androidanimations.library.flippers.FlipInXAnimator;
import com.daimajia.androidanimations.library.flippers.FlipInYAnimator;
import com.daimajia.androidanimations.library.flippers.FlipOutXAnimator;
import com.daimajia.androidanimations.library.flippers.FlipOutYAnimator;
import com.daimajia.androidanimations.library.rotating_entrances.RotateInAnimator;
import com.daimajia.androidanimations.library.rotating_entrances.RotateInDownLeftAnimator;
import com.daimajia.androidanimations.library.rotating_entrances.RotateInDownRightAnimator;
import com.daimajia.androidanimations.library.rotating_entrances.RotateInUpLeftAnimator;
import com.daimajia.androidanimations.library.rotating_entrances.RotateInUpRightAnimator;
import com.daimajia.androidanimations.library.rotating_exits.RotateOutAnimator;
import com.daimajia.androidanimations.library.rotating_exits.RotateOutDownLeftAnimator;
import com.daimajia.androidanimations.library.rotating_exits.RotateOutDownRightAnimator;
import com.daimajia.androidanimations.library.rotating_exits.RotateOutUpLeftAnimator;
import com.daimajia.androidanimations.library.rotating_exits.RotateOutUpRightAnimator;
import com.daimajia.androidanimations.library.sliders.SlideInDownAnimator;
import com.daimajia.androidanimations.library.sliders.SlideInLeftAnimator;
import com.daimajia.androidanimations.library.sliders.SlideInRightAnimator;
import com.daimajia.androidanimations.library.sliders.SlideInUpAnimator;
import com.daimajia.androidanimations.library.sliders.SlideOutDownAnimator;
import com.daimajia.androidanimations.library.sliders.SlideOutLeftAnimator;
import com.daimajia.androidanimations.library.sliders.SlideOutRightAnimator;
import com.daimajia.androidanimations.library.sliders.SlideOutUpAnimator;
import com.daimajia.androidanimations.library.specials.HingeAnimator;
import com.daimajia.androidanimations.library.specials.RollInAnimator;
import com.daimajia.androidanimations.library.specials.RollOutAnimator;
import com.daimajia.androidanimations.library.specials.in.DropOutAnimator;
import com.daimajia.androidanimations.library.specials.in.LandingAnimator;
import com.daimajia.androidanimations.library.specials.out.TakingOffAnimator;
import com.daimajia.androidanimations.library.zooming_entrances.ZoomInAnimator;
import com.daimajia.androidanimations.library.zooming_entrances.ZoomInDownAnimator;
import com.daimajia.androidanimations.library.zooming_entrances.ZoomInLeftAnimator;
import com.daimajia.androidanimations.library.zooming_entrances.ZoomInRightAnimator;
import com.daimajia.androidanimations.library.zooming_entrances.ZoomInUpAnimator;
import com.daimajia.androidanimations.library.zooming_exits.ZoomOutAnimator;
import com.daimajia.androidanimations.library.zooming_exits.ZoomOutDownAnimator;
import com.daimajia.androidanimations.library.zooming_exits.ZoomOutLeftAnimator;
import com.daimajia.androidanimations.library.zooming_exits.ZoomOutRightAnimator;
import com.daimajia.androidanimations.library.zooming_exits.ZoomOutUpAnimator;

public enum Techniques {
  Bounce,
  BounceIn,
  BounceInDown,
  BounceInLeft,
  BounceInRight,
  BounceInUp,
  DropOut(DropOutAnimator.class),
  FadeIn(DropOutAnimator.class),
  FadeInDown(DropOutAnimator.class),
  FadeInLeft(DropOutAnimator.class),
  FadeInRight(DropOutAnimator.class),
  FadeInUp(DropOutAnimator.class),
  FadeOut(DropOutAnimator.class),
  FadeOutDown(DropOutAnimator.class),
  FadeOutLeft(DropOutAnimator.class),
  FadeOutRight(DropOutAnimator.class),
  FadeOutUp(DropOutAnimator.class),
  Flash(DropOutAnimator.class),
  FlipInX(DropOutAnimator.class),
  FlipInY(DropOutAnimator.class),
  FlipOutX(DropOutAnimator.class),
  FlipOutY(DropOutAnimator.class),
  Hinge(DropOutAnimator.class),
  Landing(LandingAnimator.class),
  Pulse(LandingAnimator.class),
  RollIn(LandingAnimator.class),
  RollOut(LandingAnimator.class),
  RotateIn(LandingAnimator.class),
  RotateInDownLeft(LandingAnimator.class),
  RotateInDownRight(LandingAnimator.class),
  RotateInUpLeft(LandingAnimator.class),
  RotateInUpRight(LandingAnimator.class),
  RotateOut(LandingAnimator.class),
  RotateOutDownLeft(LandingAnimator.class),
  RotateOutDownRight(LandingAnimator.class),
  RotateOutUpLeft(LandingAnimator.class),
  RotateOutUpRight(LandingAnimator.class),
  RubberBand(LandingAnimator.class),
  Shake(LandingAnimator.class),
  SlideInDown(LandingAnimator.class),
  SlideInLeft(LandingAnimator.class),
  SlideInRight(LandingAnimator.class),
  SlideInUp(LandingAnimator.class),
  SlideOutDown(LandingAnimator.class),
  SlideOutLeft(LandingAnimator.class),
  SlideOutRight(LandingAnimator.class),
  SlideOutUp(LandingAnimator.class),
  StandUp(LandingAnimator.class),
  Swing(LandingAnimator.class),
  Tada(LandingAnimator.class),
  TakingOff(TakingOffAnimator.class),
  Wave(TakingOffAnimator.class),
  Wobble(TakingOffAnimator.class),
  ZoomIn(TakingOffAnimator.class),
  ZoomInDown(TakingOffAnimator.class),
  ZoomInLeft(TakingOffAnimator.class),
  ZoomInRight(TakingOffAnimator.class),
  ZoomInUp(TakingOffAnimator.class),
  ZoomOut(TakingOffAnimator.class),
  ZoomOutDown(TakingOffAnimator.class),
  ZoomOutLeft(TakingOffAnimator.class),
  ZoomOutRight(TakingOffAnimator.class),
  ZoomOutUp(TakingOffAnimator.class);
  
  private Class animatorClazz;
  
  static {
    Flash = new Techniques("Flash", 3, FlashAnimator.class);
    Pulse = new Techniques("Pulse", 4, PulseAnimator.class);
    RubberBand = new Techniques("RubberBand", 5, RubberBandAnimator.class);
    Shake = new Techniques("Shake", 6, ShakeAnimator.class);
    Swing = new Techniques("Swing", 7, SwingAnimator.class);
    Wobble = new Techniques("Wobble", 8, WobbleAnimator.class);
    Bounce = new Techniques("Bounce", 9, BounceAnimator.class);
    Tada = new Techniques("Tada", 10, TadaAnimator.class);
    StandUp = new Techniques("StandUp", 11, StandUpAnimator.class);
    Wave = new Techniques("Wave", 12, WaveAnimator.class);
    Hinge = new Techniques("Hinge", 13, HingeAnimator.class);
    RollIn = new Techniques("RollIn", 14, RollInAnimator.class);
    RollOut = new Techniques("RollOut", 15, RollOutAnimator.class);
    BounceIn = new Techniques("BounceIn", 16, BounceInAnimator.class);
    BounceInDown = new Techniques("BounceInDown", 17, BounceInDownAnimator.class);
    BounceInLeft = new Techniques("BounceInLeft", 18, BounceInLeftAnimator.class);
    BounceInRight = new Techniques("BounceInRight", 19, BounceInRightAnimator.class);
    BounceInUp = new Techniques("BounceInUp", 20, BounceInUpAnimator.class);
    FadeIn = new Techniques("FadeIn", 21, FadeInAnimator.class);
    FadeInUp = new Techniques("FadeInUp", 22, FadeInUpAnimator.class);
    FadeInDown = new Techniques("FadeInDown", 23, FadeInDownAnimator.class);
    FadeInLeft = new Techniques("FadeInLeft", 24, FadeInLeftAnimator.class);
    FadeInRight = new Techniques("FadeInRight", 25, FadeInRightAnimator.class);
    FadeOut = new Techniques("FadeOut", 26, FadeOutAnimator.class);
    FadeOutDown = new Techniques("FadeOutDown", 27, FadeOutDownAnimator.class);
    FadeOutLeft = new Techniques("FadeOutLeft", 28, FadeOutLeftAnimator.class);
    FadeOutRight = new Techniques("FadeOutRight", 29, FadeOutRightAnimator.class);
    FadeOutUp = new Techniques("FadeOutUp", 30, FadeOutUpAnimator.class);
    FlipInX = new Techniques("FlipInX", 31, FlipInXAnimator.class);
    FlipOutX = new Techniques("FlipOutX", 32, FlipOutXAnimator.class);
    FlipInY = new Techniques("FlipInY", 33, FlipInYAnimator.class);
    FlipOutY = new Techniques("FlipOutY", 34, FlipOutYAnimator.class);
    RotateIn = new Techniques("RotateIn", 35, RotateInAnimator.class);
    RotateInDownLeft = new Techniques("RotateInDownLeft", 36, RotateInDownLeftAnimator.class);
    RotateInDownRight = new Techniques("RotateInDownRight", 37, RotateInDownRightAnimator.class);
    RotateInUpLeft = new Techniques("RotateInUpLeft", 38, RotateInUpLeftAnimator.class);
    RotateInUpRight = new Techniques("RotateInUpRight", 39, RotateInUpRightAnimator.class);
    RotateOut = new Techniques("RotateOut", 40, RotateOutAnimator.class);
    RotateOutDownLeft = new Techniques("RotateOutDownLeft", 41, RotateOutDownLeftAnimator.class);
    RotateOutDownRight = new Techniques("RotateOutDownRight", 42, RotateOutDownRightAnimator.class);
    RotateOutUpLeft = new Techniques("RotateOutUpLeft", 43, RotateOutUpLeftAnimator.class);
    RotateOutUpRight = new Techniques("RotateOutUpRight", 44, RotateOutUpRightAnimator.class);
    SlideInLeft = new Techniques("SlideInLeft", 45, SlideInLeftAnimator.class);
    SlideInRight = new Techniques("SlideInRight", 46, SlideInRightAnimator.class);
    SlideInUp = new Techniques("SlideInUp", 47, SlideInUpAnimator.class);
    SlideInDown = new Techniques("SlideInDown", 48, SlideInDownAnimator.class);
    SlideOutLeft = new Techniques("SlideOutLeft", 49, SlideOutLeftAnimator.class);
    SlideOutRight = new Techniques("SlideOutRight", 50, SlideOutRightAnimator.class);
    SlideOutUp = new Techniques("SlideOutUp", 51, SlideOutUpAnimator.class);
    SlideOutDown = new Techniques("SlideOutDown", 52, SlideOutDownAnimator.class);
    ZoomIn = new Techniques("ZoomIn", 53, ZoomInAnimator.class);
    ZoomInDown = new Techniques("ZoomInDown", 54, ZoomInDownAnimator.class);
    ZoomInLeft = new Techniques("ZoomInLeft", 55, ZoomInLeftAnimator.class);
    ZoomInRight = new Techniques("ZoomInRight", 56, ZoomInRightAnimator.class);
    ZoomInUp = new Techniques("ZoomInUp", 57, ZoomInUpAnimator.class);
    ZoomOut = new Techniques("ZoomOut", 58, ZoomOutAnimator.class);
    ZoomOutDown = new Techniques("ZoomOutDown", 59, ZoomOutDownAnimator.class);
    ZoomOutLeft = new Techniques("ZoomOutLeft", 60, ZoomOutLeftAnimator.class);
    ZoomOutRight = new Techniques("ZoomOutRight", 61, ZoomOutRightAnimator.class);
    ZoomOutUp = new Techniques("ZoomOutUp", 62, ZoomOutUpAnimator.class);
    $VALUES = new Techniques[] { 
        DropOut, Landing, TakingOff, Flash, Pulse, RubberBand, Shake, Swing, Wobble, Bounce, 
        Tada, StandUp, Wave, Hinge, RollIn, RollOut, BounceIn, BounceInDown, BounceInLeft, BounceInRight, 
        BounceInUp, FadeIn, FadeInUp, FadeInDown, FadeInLeft, FadeInRight, FadeOut, FadeOutDown, FadeOutLeft, FadeOutRight, 
        FadeOutUp, FlipInX, FlipOutX, FlipInY, FlipOutY, RotateIn, RotateInDownLeft, RotateInDownRight, RotateInUpLeft, RotateInUpRight, 
        RotateOut, RotateOutDownLeft, RotateOutDownRight, RotateOutUpLeft, RotateOutUpRight, SlideInLeft, SlideInRight, SlideInUp, SlideInDown, SlideOutLeft, 
        SlideOutRight, SlideOutUp, SlideOutDown, ZoomIn, ZoomInDown, ZoomInLeft, ZoomInRight, ZoomInUp, ZoomOut, ZoomOutDown, 
        ZoomOutLeft, ZoomOutRight, ZoomOutUp };
  }
  
  Techniques(Class paramClass) {
    this.animatorClazz = paramClass;
  }
  
  public BaseViewAnimator getAnimator() {
    try {
      return this.animatorClazz.newInstance();
    } catch (Exception exception) {
      throw new Error("Can not init animatorClazz instance");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\Techniques.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */