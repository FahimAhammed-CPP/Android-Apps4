package com.daimajia.androidanimations.library.bouncing_entrances;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class BounceInAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    getAnimatorAgent().playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F, 1.0F, 1.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 0.3F, 1.05F, 0.9F, 1.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 0.3F, 1.05F, 0.9F, 1.0F }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\bouncing_entrances\BounceInAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */