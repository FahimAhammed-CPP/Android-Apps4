package com.daimajia.androidanimations.library.bouncing_entrances;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class BounceInRightAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    AnimatorSet animatorSet = getAnimatorAgent();
    int i = paramView.getMeasuredWidth();
    animatorSet.playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "translationX", new float[] { (paramView.getWidth() + i), -30.0F, 10.0F, 0.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F, 1.0F, 1.0F }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\bouncing_entrances\BounceInRightAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */