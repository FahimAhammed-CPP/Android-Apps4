package com.daimajia.androidanimations.library;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.Interpolator;
import fe;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class BaseViewAnimator {
  public static final long DURATION = 1000L;
  
  private AnimatorSet mAnimatorSet = new AnimatorSet();
  
  private long mDuration = 1000L;
  
  private int mRepeatMode = 1;
  
  private int mRepeatTimes = 0;
  
  public BaseViewAnimator addAnimatorListener(Animator.AnimatorListener paramAnimatorListener) {
    this.mAnimatorSet.addListener(paramAnimatorListener);
    return this;
  }
  
  public void animate() {
    start();
  }
  
  public void cancel() {
    this.mAnimatorSet.cancel();
  }
  
  public AnimatorSet getAnimatorAgent() {
    return this.mAnimatorSet;
  }
  
  public long getDuration() {
    return this.mDuration;
  }
  
  public long getStartDelay() {
    return this.mAnimatorSet.getStartDelay();
  }
  
  public boolean isRunning() {
    return this.mAnimatorSet.isRunning();
  }
  
  public boolean isStarted() {
    return this.mAnimatorSet.isStarted();
  }
  
  public abstract void prepare(View paramView);
  
  public void removeAllListener() {
    this.mAnimatorSet.removeAllListeners();
  }
  
  public void removeAnimatorListener(Animator.AnimatorListener paramAnimatorListener) {
    this.mAnimatorSet.removeListener(paramAnimatorListener);
  }
  
  public void reset(View paramView) {
    AtomicInteger atomicInteger = fe.a;
    paramView.setAlpha(1.0F);
    paramView.setScaleX(1.0F);
    paramView.setScaleY(1.0F);
    paramView.setTranslationX(0.0F);
    paramView.setTranslationY(0.0F);
    paramView.setRotation(0.0F);
    paramView.setRotationY(0.0F);
    paramView.setRotationX(0.0F);
  }
  
  public void restart() {
    this.mAnimatorSet = this.mAnimatorSet.clone();
    start();
  }
  
  public BaseViewAnimator setDuration(long paramLong) {
    this.mDuration = paramLong;
    return this;
  }
  
  public BaseViewAnimator setInterpolator(Interpolator paramInterpolator) {
    this.mAnimatorSet.setInterpolator((TimeInterpolator)paramInterpolator);
    return this;
  }
  
  public BaseViewAnimator setRepeatMode(int paramInt) {
    this.mRepeatMode = paramInt;
    return this;
  }
  
  public BaseViewAnimator setRepeatTimes(int paramInt) {
    this.mRepeatTimes = paramInt;
    return this;
  }
  
  public BaseViewAnimator setStartDelay(long paramLong) {
    getAnimatorAgent().setStartDelay(paramLong);
    return this;
  }
  
  public BaseViewAnimator setTarget(View paramView) {
    reset(paramView);
    prepare(paramView);
    return this;
  }
  
  public void start() {
    for (Animator animator : this.mAnimatorSet.getChildAnimations()) {
      if (animator instanceof ValueAnimator) {
        ValueAnimator valueAnimator = (ValueAnimator)animator;
        valueAnimator.setRepeatCount(this.mRepeatTimes);
        valueAnimator.setRepeatMode(this.mRepeatMode);
      } 
    } 
    this.mAnimatorSet.setDuration(this.mDuration);
    this.mAnimatorSet.start();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\BaseViewAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */