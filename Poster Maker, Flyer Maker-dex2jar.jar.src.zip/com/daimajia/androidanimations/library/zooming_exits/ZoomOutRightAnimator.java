package com.daimajia.androidanimations.library.zooming_exits;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.ViewGroup;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class ZoomOutRightAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    int i = viewGroup.getWidth();
    int j = viewGroup.getLeft();
    getAnimatorAgent().playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 1.0F, 0.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.0F, 0.475F, 0.1F }), (Animator)ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.0F, 0.475F, 0.1F }), (Animator)ObjectAnimator.ofFloat(paramView, "translationX", new float[] { 0.0F, -42.0F, (i - j) }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\zooming_exits\ZoomOutRightAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */