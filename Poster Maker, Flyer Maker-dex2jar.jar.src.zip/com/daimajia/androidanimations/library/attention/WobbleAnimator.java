package com.daimajia.androidanimations.library.attention;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class WobbleAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    double d = paramView.getWidth();
    Double.isNaN(d);
    float f1 = (float)(d / 100.0D);
    AnimatorSet animatorSet = getAnimatorAgent();
    float f2 = f1 * 0.0F;
    animatorSet.playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "translationX", new float[] { f2, -25.0F * f1, 20.0F * f1, -15.0F * f1, 10.0F * f1, f1 * -5.0F, f2, 0.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "rotation", new float[] { 0.0F, -5.0F, 3.0F, -3.0F, 2.0F, -1.0F, 0.0F }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\attention\WobbleAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */