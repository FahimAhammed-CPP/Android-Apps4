package com.daimajia.androidanimations.library.fading_entrances;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class FadeInUpAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    getAnimatorAgent().playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "translationY", new float[] { (paramView.getHeight() / 4), 0.0F }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\fading_entrances\FadeInUpAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */