package com.daimajia.androidanimations.library.fading_exits;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;

public class FadeOutRightAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    getAnimatorAgent().playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 0.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "translationX", new float[] { 0.0F, (paramView.getWidth() / 4) }) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\fading_exits\FadeOutRightAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */