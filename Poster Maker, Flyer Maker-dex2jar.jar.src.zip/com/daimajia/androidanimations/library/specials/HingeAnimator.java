package com.daimajia.androidanimations.library.specials;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;
import com.daimajia.easing.Glider;
import com.daimajia.easing.Skill;

public class HingeAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    float f1 = paramView.getPaddingLeft();
    float f2 = paramView.getPaddingTop();
    getAnimatorAgent().playTogether(new Animator[] { (Animator)Glider.glide(Skill.SineEaseInOut, 1300.0F, (ValueAnimator)ObjectAnimator.ofFloat(paramView, "rotation", new float[] { 0.0F, 80.0F, 60.0F, 80.0F, 60.0F, 60.0F })), (Animator)ObjectAnimator.ofFloat(paramView, "translationY", new float[] { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 700.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F }), (Animator)ObjectAnimator.ofFloat(paramView, "pivotX", new float[] { f1, f1, f1, f1, f1, f1 }), (Animator)ObjectAnimator.ofFloat(paramView, "pivotY", new float[] { f2, f2, f2, f2, f2, f2 }) });
    setDuration(1300L);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\specials\HingeAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */