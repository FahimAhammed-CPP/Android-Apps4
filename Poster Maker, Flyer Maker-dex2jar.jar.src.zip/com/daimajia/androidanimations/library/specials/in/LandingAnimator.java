package com.daimajia.androidanimations.library.specials.in;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;
import com.daimajia.easing.Glider;
import com.daimajia.easing.Skill;

public class LandingAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    AnimatorSet animatorSet = getAnimatorAgent();
    Skill skill = Skill.QuintEaseOut;
    animatorSet.playTogether(new Animator[] { (Animator)Glider.glide(skill, (float)getDuration(), (ValueAnimator)ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.5F, 1.0F })), (Animator)Glider.glide(skill, (float)getDuration(), (ValueAnimator)ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.5F, 1.0F })), (Animator)Glider.glide(skill, (float)getDuration(), (ValueAnimator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F })) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\specials\in\LandingAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */