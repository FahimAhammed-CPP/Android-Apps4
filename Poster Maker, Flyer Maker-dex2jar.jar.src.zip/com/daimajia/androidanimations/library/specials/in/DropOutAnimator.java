package com.daimajia.androidanimations.library.specials.in;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import com.daimajia.androidanimations.library.BaseViewAnimator;
import com.daimajia.easing.Glider;
import com.daimajia.easing.Skill;

public class DropOutAnimator extends BaseViewAnimator {
  public void prepare(View paramView) {
    int i = paramView.getTop();
    int j = paramView.getHeight();
    getAnimatorAgent().playTogether(new Animator[] { (Animator)ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F }), (Animator)Glider.glide(Skill.BounceEaseOut, (float)getDuration(), (ValueAnimator)ObjectAnimator.ofFloat(paramView, "translationY", new float[] { -(j + i), 0.0F })) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\specials\in\DropOutAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */