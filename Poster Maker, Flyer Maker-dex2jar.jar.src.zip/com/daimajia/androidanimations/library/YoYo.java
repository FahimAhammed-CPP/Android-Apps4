package com.daimajia.androidanimations.library;

import android.animation.Animator;
import android.view.View;
import android.view.animation.Interpolator;
import fe;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class YoYo {
  public static final float CENTER_PIVOT = 3.4028235E38F;
  
  private static final long DURATION = 1000L;
  
  public static final int INFINITE = -1;
  
  private static final long NO_DELAY = 0L;
  
  private BaseViewAnimator animator;
  
  private List<Animator.AnimatorListener> callbacks;
  
  private long delay;
  
  private long duration;
  
  private Interpolator interpolator;
  
  private float pivotX;
  
  private float pivotY;
  
  private boolean repeat;
  
  private int repeatMode;
  
  private int repeatTimes;
  
  private View target;
  
  private YoYo(AnimationComposer paramAnimationComposer) {
    this.animator = paramAnimationComposer.animator;
    this.duration = paramAnimationComposer.duration;
    this.delay = paramAnimationComposer.delay;
    this.repeat = paramAnimationComposer.repeat;
    this.repeatTimes = paramAnimationComposer.repeatTimes;
    this.repeatMode = paramAnimationComposer.repeatMode;
    this.interpolator = paramAnimationComposer.interpolator;
    this.pivotX = paramAnimationComposer.pivotX;
    this.pivotY = paramAnimationComposer.pivotY;
    this.callbacks = paramAnimationComposer.callbacks;
    this.target = paramAnimationComposer.target;
  }
  
  private BaseViewAnimator play() {
    this.animator.setTarget(this.target);
    float f = this.pivotX;
    if (f == Float.MAX_VALUE) {
      View view = this.target;
      f = view.getMeasuredWidth() / 2.0F;
      AtomicInteger atomicInteger = fe.a;
      view.setPivotX(f);
    } else {
      this.target.setPivotX(f);
    } 
    f = this.pivotY;
    if (f == Float.MAX_VALUE) {
      View view = this.target;
      f = view.getMeasuredHeight() / 2.0F;
      AtomicInteger atomicInteger = fe.a;
      view.setPivotY(f);
    } else {
      this.target.setPivotY(f);
    } 
    this.animator.setDuration(this.duration).setRepeatTimes(this.repeatTimes).setRepeatMode(this.repeatMode).setInterpolator(this.interpolator).setStartDelay(this.delay);
    if (this.callbacks.size() > 0)
      for (Animator.AnimatorListener animatorListener : this.callbacks)
        this.animator.addAnimatorListener(animatorListener);  
    this.animator.animate();
    return this.animator;
  }
  
  public static AnimationComposer with(BaseViewAnimator paramBaseViewAnimator) {
    return new AnimationComposer(paramBaseViewAnimator);
  }
  
  public static AnimationComposer with(Techniques paramTechniques) {
    return new AnimationComposer(paramTechniques);
  }
  
  public static final class AnimationComposer {
    private BaseViewAnimator animator;
    
    private List<Animator.AnimatorListener> callbacks = new ArrayList<Animator.AnimatorListener>();
    
    private long delay = 0L;
    
    private long duration = 1000L;
    
    private Interpolator interpolator;
    
    private float pivotX = Float.MAX_VALUE;
    
    private float pivotY = Float.MAX_VALUE;
    
    private boolean repeat = false;
    
    private int repeatMode = 1;
    
    private int repeatTimes = 0;
    
    private View target;
    
    private AnimationComposer(BaseViewAnimator param1BaseViewAnimator) {
      this.animator = param1BaseViewAnimator;
    }
    
    private AnimationComposer(Techniques param1Techniques) {
      this.animator = param1Techniques.getAnimator();
    }
    
    public AnimationComposer delay(long param1Long) {
      this.delay = param1Long;
      return this;
    }
    
    public AnimationComposer duration(long param1Long) {
      this.duration = param1Long;
      return this;
    }
    
    public AnimationComposer interpolate(Interpolator param1Interpolator) {
      this.interpolator = param1Interpolator;
      return this;
    }
    
    public AnimationComposer onCancel(final YoYo.AnimatorCallback callback) {
      this.callbacks.add(new YoYo.EmptyAnimatorListener() {
            public void onAnimationCancel(Animator param2Animator) {
              callback.call(param2Animator);
            }
          });
      return this;
    }
    
    public AnimationComposer onEnd(final YoYo.AnimatorCallback callback) {
      this.callbacks.add(new YoYo.EmptyAnimatorListener() {
            public void onAnimationEnd(Animator param2Animator) {
              callback.call(param2Animator);
            }
          });
      return this;
    }
    
    public AnimationComposer onRepeat(final YoYo.AnimatorCallback callback) {
      this.callbacks.add(new YoYo.EmptyAnimatorListener() {
            public void onAnimationRepeat(Animator param2Animator) {
              callback.call(param2Animator);
            }
          });
      return this;
    }
    
    public AnimationComposer onStart(final YoYo.AnimatorCallback callback) {
      this.callbacks.add(new YoYo.EmptyAnimatorListener() {
            public void onAnimationStart(Animator param2Animator) {
              callback.call(param2Animator);
            }
          });
      return this;
    }
    
    public AnimationComposer pivot(float param1Float1, float param1Float2) {
      this.pivotX = param1Float1;
      this.pivotY = param1Float2;
      return this;
    }
    
    public AnimationComposer pivotX(float param1Float) {
      this.pivotX = param1Float;
      return this;
    }
    
    public AnimationComposer pivotY(float param1Float) {
      this.pivotY = param1Float;
      return this;
    }
    
    public YoYo.YoYoString playOn(View param1View) {
      this.target = param1View;
      return new YoYo.YoYoString((new YoYo(this)).play(), this.target);
    }
    
    public AnimationComposer repeat(int param1Int) {
      if (param1Int >= -1) {
        boolean bool;
        if (param1Int != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.repeat = bool;
        this.repeatTimes = param1Int;
        return this;
      } 
      throw new RuntimeException("Can not be less than -1, -1 is infinite loop");
    }
    
    public AnimationComposer repeatMode(int param1Int) {
      this.repeatMode = param1Int;
      return this;
    }
    
    public AnimationComposer withListener(Animator.AnimatorListener param1AnimatorListener) {
      this.callbacks.add(param1AnimatorListener);
      return this;
    }
  }
  
  public class null extends EmptyAnimatorListener {
    public void onAnimationStart(Animator param1Animator) {
      callback.call(param1Animator);
    }
  }
  
  public class null extends EmptyAnimatorListener {
    public void onAnimationEnd(Animator param1Animator) {
      callback.call(param1Animator);
    }
  }
  
  public class null extends EmptyAnimatorListener {
    public void onAnimationCancel(Animator param1Animator) {
      callback.call(param1Animator);
    }
  }
  
  public class null extends EmptyAnimatorListener {
    public void onAnimationRepeat(Animator param1Animator) {
      callback.call(param1Animator);
    }
  }
  
  public static interface AnimatorCallback {
    void call(Animator param1Animator);
  }
  
  public static class EmptyAnimatorListener implements Animator.AnimatorListener {
    private EmptyAnimatorListener() {}
    
    public void onAnimationCancel(Animator param1Animator) {}
    
    public void onAnimationEnd(Animator param1Animator) {}
    
    public void onAnimationRepeat(Animator param1Animator) {}
    
    public void onAnimationStart(Animator param1Animator) {}
  }
  
  public static final class YoYoString {
    private BaseViewAnimator animator;
    
    private View target;
    
    private YoYoString(BaseViewAnimator param1BaseViewAnimator, View param1View) {
      this.target = param1View;
      this.animator = param1BaseViewAnimator;
    }
    
    public boolean isRunning() {
      return this.animator.isRunning();
    }
    
    public boolean isStarted() {
      return this.animator.isStarted();
    }
    
    public void stop() {
      stop(true);
    }
    
    public void stop(boolean param1Boolean) {
      this.animator.cancel();
      if (param1Boolean)
        this.animator.reset(this.target); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daimajia\androidanimations\library\YoYo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */