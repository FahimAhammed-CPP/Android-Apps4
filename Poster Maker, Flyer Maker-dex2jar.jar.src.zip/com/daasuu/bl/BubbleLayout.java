package com.daasuu.bl;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import fk0;
import gk0;
import hk0;

public class BubbleLayout extends FrameLayout {
  public fk0 b;
  
  public gk0 c;
  
  public float d;
  
  public float f;
  
  public float g;
  
  public float p;
  
  public int q;
  
  public float r;
  
  public int s;
  
  public BubbleLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, hk0.BubbleLayout);
    this.d = typedArray.getDimension(hk0.BubbleLayout_bl_arrowWidth, a(8.0F, paramContext));
    this.g = typedArray.getDimension(hk0.BubbleLayout_bl_arrowHeight, a(8.0F, paramContext));
    this.f = typedArray.getDimension(hk0.BubbleLayout_bl_cornersRadius, 0.0F);
    this.p = typedArray.getDimension(hk0.BubbleLayout_bl_arrowPosition, a(12.0F, paramContext));
    this.q = typedArray.getColor(hk0.BubbleLayout_bl_bubbleColor, -1);
    this.r = typedArray.getDimension(hk0.BubbleLayout_bl_strokeWidth, -1.0F);
    this.s = typedArray.getColor(hk0.BubbleLayout_bl_strokeColor, -7829368);
    this.b = fk0.fromInt(typedArray.getInt(hk0.BubbleLayout_bl_arrowDirection, fk0.LEFT.getValue()));
    typedArray.recycle();
    int k = getPaddingLeft();
    int m = getPaddingRight();
    int i = getPaddingTop();
    int j = getPaddingBottom();
    switch (this.b.ordinal()) {
      case 3:
      case 7:
        j = (int)(j + this.g);
        break;
      case 2:
      case 6:
        i = (int)(i + this.g);
        break;
      case 1:
      case 5:
        m = (int)(m + this.d);
        break;
      case 0:
      case 4:
        k = (int)(k + this.d);
        break;
    } 
    float f = this.r;
    int i3 = i;
    int i2 = j;
    int i1 = k;
    int n = m;
    if (f > 0.0F) {
      i1 = (int)(k + f);
      n = (int)(m + f);
      i3 = (int)(i + f);
      i2 = (int)(j + f);
    } 
    setPadding(i1, i3, n, i2);
  }
  
  public static float a(float paramFloat, Context paramContext) {
    return paramFloat * ((paramContext.getResources().getDisplayMetrics()).densityDpi / 160);
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    gk0 gk01 = this.c;
    if (gk01 != null)
      gk01.draw(paramCanvas); 
    super.dispatchDraw(paramCanvas);
  }
  
  public fk0 getArrowDirection() {
    return this.b;
  }
  
  public float getArrowHeight() {
    return this.g;
  }
  
  public float getArrowPosition() {
    return this.p;
  }
  
  public float getArrowWidth() {
    return this.d;
  }
  
  public int getBubbleColor() {
    return this.q;
  }
  
  public float getCornersRadius() {
    return this.f;
  }
  
  public int getStrokeColor() {
    return this.s;
  }
  
  public float getStrokeWidth() {
    return this.r;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = getWidth();
    paramInt2 = getHeight();
    if (paramInt1 >= 0) {
      if (paramInt2 < 0)
        return; 
      float f = false;
      RectF rectF = new RectF(f, f, paramInt1, paramInt2);
      paramInt3 = this.b.ordinal();
      if (paramInt3 != 4 && paramInt3 != 5) {
        if (paramInt3 == 6 || paramInt3 == 7)
          this.p = ((paramInt1 - 0) / 2) - this.d / 2.0F; 
      } else {
        this.p = ((paramInt2 - 0) / 2) - this.g / 2.0F;
      } 
      this.c = new gk0(rectF, this.d, this.f, this.g, this.p, this.r, this.s, this.q, this.b);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\daasuu\bl\BubbleLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */