package com.facebook.ads;

import androidx.annotation.Keep;
import com.facebook.ads.internal.bench.Benchmark;

@Keep
public interface Ad {
  @Benchmark
  void destroy();
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  String getPlacementId();
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  boolean isAdInvalidated();
  
  @Benchmark
  void loadAd();
  
  @Deprecated
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  void setExtraHints(ExtraHints paramExtraHints);
  
  @Keep
  public static interface LoadAdConfig {}
  
  @Keep
  public static interface LoadConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    Ad.LoadAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    LoadConfigBuilder withBid(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\Ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */