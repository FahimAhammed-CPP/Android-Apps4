package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public enum AdExperienceType {
  AD_EXPERIENCE_TYPE_INTERSTITIAL, AD_EXPERIENCE_TYPE_REWARDED, AD_EXPERIENCE_TYPE_REWARDED_INTERSTITIAL;
  
  private String adExperienceType;
  
  static {
    AdExperienceType adExperienceType1 = new AdExperienceType("AD_EXPERIENCE_TYPE_REWARDED", 0, "ad_experience_config_rewarded");
    AD_EXPERIENCE_TYPE_REWARDED = adExperienceType1;
    AdExperienceType adExperienceType2 = new AdExperienceType("AD_EXPERIENCE_TYPE_REWARDED_INTERSTITIAL", 1, "ad_experience_config_rewarded_interstitial");
    AD_EXPERIENCE_TYPE_REWARDED_INTERSTITIAL = adExperienceType2;
    AdExperienceType adExperienceType3 = new AdExperienceType("AD_EXPERIENCE_TYPE_INTERSTITIAL", 2, "ad_experience_config_interstitial");
    AD_EXPERIENCE_TYPE_INTERSTITIAL = adExperienceType3;
    $VALUES = new AdExperienceType[] { adExperienceType1, adExperienceType2, adExperienceType3 };
  }
  
  AdExperienceType(String paramString1) {
    this.adExperienceType = paramString1;
  }
  
  public String getAdExperienceType() {
    return this.adExperienceType;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdExperienceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */