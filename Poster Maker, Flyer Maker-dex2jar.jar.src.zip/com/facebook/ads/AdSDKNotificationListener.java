package com.facebook.ads;

import android.os.Bundle;
import androidx.annotation.Keep;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Keep
public interface AdSDKNotificationListener {
  public static final String ENCRYPTED_CPM_KEY = "encrypted_cpm";
  
  public static final String IMPRESSION_EVENT = "impression";
  
  void onAdEvent(String paramString, Bundle paramBundle);
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface SDKEventKey {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface SDKEventType {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdSDKNotificationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */