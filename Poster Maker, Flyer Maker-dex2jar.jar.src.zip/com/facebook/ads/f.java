package com.facebook.ads;


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */