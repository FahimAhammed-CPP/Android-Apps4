package com.facebook.ads;

import androidx.annotation.Keep;
import java.util.EnumSet;

@Keep
public enum CacheFlag {
  ICON, IMAGE, NONE, VIDEO;
  
  public static final EnumSet<CacheFlag> ALL;
  
  static {
    CacheFlag cacheFlag1 = new CacheFlag("NONE", 0);
    NONE = cacheFlag1;
    CacheFlag cacheFlag2 = new CacheFlag("ICON", 1);
    ICON = cacheFlag2;
    CacheFlag cacheFlag3 = new CacheFlag("IMAGE", 2);
    IMAGE = cacheFlag3;
    CacheFlag cacheFlag4 = new CacheFlag("VIDEO", 3);
    VIDEO = cacheFlag4;
    $VALUES = new CacheFlag[] { cacheFlag1, cacheFlag2, cacheFlag3, cacheFlag4 };
    ALL = EnumSet.allOf(CacheFlag.class);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\CacheFlag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */