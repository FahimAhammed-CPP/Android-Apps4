package com.facebook.ads;

import android.content.Context;
import android.graphics.Typeface;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdViewAttributesApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class NativeAdViewAttributes {
  private final NativeAdViewAttributesApi mNativeAdViewAttributesApi = DynamicLoaderFactory.makeLoaderUnsafe().createNativeAdViewAttributesApi();
  
  @Deprecated
  public NativeAdViewAttributes() {}
  
  public NativeAdViewAttributes(Context paramContext) {}
  
  @Deprecated
  public boolean getAutoplay() {
    return AdSettings.isVideoAutoplay();
  }
  
  @Deprecated
  public boolean getAutoplayOnMobile() {
    return AdSettings.isVideoAutoplayOnMobile();
  }
  
  @Deprecated
  public int getBackgroundColor() {
    return 0;
  }
  
  @Deprecated
  public int getButtonBorderColor() {
    return 0;
  }
  
  @Deprecated
  public int getButtonColor() {
    return 0;
  }
  
  @Deprecated
  public int getButtonTextColor() {
    return 0;
  }
  
  @Deprecated
  public int getDescriptionTextColor() {
    return 0;
  }
  
  @Deprecated
  public int getDescriptionTextSize() {
    return 0;
  }
  
  public NativeAdViewAttributesApi getInternalAttributes() {
    return this.mNativeAdViewAttributesApi;
  }
  
  @Deprecated
  public int getTitleTextColor() {
    return 0;
  }
  
  @Deprecated
  public int getTitleTextSize() {
    return 0;
  }
  
  @Deprecated
  public Typeface getTypeface() {
    return null;
  }
  
  @Deprecated
  public NativeAdViewAttributes setAutoplay(boolean paramBoolean) {
    return this;
  }
  
  @Deprecated
  public NativeAdViewAttributes setAutoplayOnMobile(boolean paramBoolean) {
    return this;
  }
  
  public NativeAdViewAttributes setBackgroundColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setBackgroundColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setButtonBorderColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setCTABorderColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setButtonColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setCTABackgroundColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setButtonTextColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setCTATextColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setDescriptionTextColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setSecondaryTextColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setTitleTextColor(int paramInt) {
    this.mNativeAdViewAttributesApi.setPrimaryTextColor(paramInt);
    return this;
  }
  
  public NativeAdViewAttributes setTypeface(Typeface paramTypeface) {
    this.mNativeAdViewAttributesApi.setTypeface(paramTypeface);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAdViewAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */