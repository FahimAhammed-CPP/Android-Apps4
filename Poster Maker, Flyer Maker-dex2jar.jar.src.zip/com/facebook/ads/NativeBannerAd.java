package com.facebook.ads;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.api.NativeBannerAdApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;
import java.util.List;

@Keep
public class NativeBannerAd extends NativeAdBase {
  private final NativeBannerAdApi mNativeBannerAdApi;
  
  public NativeBannerAd(Context paramContext, NativeAdBaseApi paramNativeAdBaseApi) {
    super(paramNativeAdBaseApi);
    this.mNativeBannerAdApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeBannerAdApi(this, this.mNativeAdBaseApi);
  }
  
  public NativeBannerAd(Context paramContext, String paramString) {
    super(paramContext, paramString);
    this.mNativeBannerAdApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeBannerAdApi(this, this.mNativeAdBaseApi);
  }
  
  public void registerViewForInteraction(View paramView, ImageView paramImageView) {
    Preconditions.checkIsOnMainThread();
    this.mNativeBannerAdApi.registerViewForInteraction(paramView, paramImageView);
  }
  
  public void registerViewForInteraction(View paramView, ImageView paramImageView, List<View> paramList) {
    Preconditions.checkIsOnMainThread();
    this.mNativeBannerAdApi.registerViewForInteraction(paramView, paramImageView, paramList);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView) {
    Preconditions.checkIsOnMainThread();
    this.mNativeBannerAdApi.registerViewForInteraction(paramView, paramMediaView);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView, List<View> paramList) {
    Preconditions.checkIsOnMainThread();
    this.mNativeBannerAdApi.registerViewForInteraction(paramView, paramMediaView, paramList);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeBannerAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */