package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public interface S2SRewardedVideoAdExtendedListener extends RewardedVideoAdExtendedListener, S2SRewardedVideoAdListener {}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\S2SRewardedVideoAdExtendedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */