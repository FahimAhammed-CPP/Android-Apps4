package com.facebook.ads;

import android.content.Context;
import android.content.res.Configuration;
import android.widget.RelativeLayout;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdViewApi;
import com.facebook.ads.internal.api.AdViewParentApi;
import com.facebook.ads.internal.bench.Benchmark;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class AdView extends RelativeLayout implements Ad {
  private final AdViewApi mAdViewApi;
  
  private final AdViewParentApi mAdViewParentApi;
  
  @Benchmark
  public AdView(Context paramContext, String paramString, AdSize paramAdSize) {
    super(paramContext);
    AdViewParentApi adViewParentApi = new AdViewParentApi() {
        @Benchmark
        public void onConfigurationChanged(Configuration param1Configuration) {
          AdView.this.onConfigurationChanged(param1Configuration);
        }
      };
    this.mAdViewParentApi = adViewParentApi;
    this.mAdViewApi = DynamicLoaderFactory.makeLoader(paramContext).createAdViewApi(paramContext, paramString, paramAdSize, adViewParentApi, this);
  }
  
  @Benchmark
  public AdView(Context paramContext, String paramString1, String paramString2) {
    super(paramContext);
    AdViewParentApi adViewParentApi = new AdViewParentApi() {
        @Benchmark
        public void onConfigurationChanged(Configuration param1Configuration) {
          AdView.this.onConfigurationChanged(param1Configuration);
        }
      };
    this.mAdViewParentApi = adViewParentApi;
    this.mAdViewApi = DynamicLoaderFactory.makeLoader(paramContext).createAdViewApi(paramContext, paramString1, paramString2, adViewParentApi, this);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public AdViewLoadConfigBuilder buildLoadAdConfig() {
    return this.mAdViewApi.buildLoadAdConfig();
  }
  
  public void destroy() {
    this.mAdViewApi.destroy();
  }
  
  public String getPlacementId() {
    return this.mAdViewApi.getPlacementId();
  }
  
  public boolean isAdInvalidated() {
    return this.mAdViewApi.isAdInvalidated();
  }
  
  @Benchmark
  public void loadAd() {
    this.mAdViewApi.loadAd();
  }
  
  @Benchmark
  public void loadAd(AdViewLoadConfig paramAdViewLoadConfig) {
    this.mAdViewApi.loadAd(paramAdViewLoadConfig);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.mAdViewApi.onConfigurationChanged(paramConfiguration);
  }
  
  @Deprecated
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mAdViewApi.setExtraHints(paramExtraHints);
  }
  
  @Keep
  public static interface AdViewLoadConfig extends Ad.LoadAdConfig {}
  
  @Keep
  public static interface AdViewLoadConfigBuilder extends Ad.LoadConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    AdView.AdViewLoadConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    AdViewLoadConfigBuilder withAdListener(AdListener param1AdListener);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    AdViewLoadConfigBuilder withBid(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */