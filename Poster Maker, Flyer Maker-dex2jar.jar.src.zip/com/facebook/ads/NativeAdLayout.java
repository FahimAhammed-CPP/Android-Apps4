package com.facebook.ads;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdComponentFrameLayout;
import com.facebook.ads.internal.api.AdComponentViewApiProvider;
import com.facebook.ads.internal.api.NativeAdLayoutApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class NativeAdLayout extends AdComponentFrameLayout {
  private NativeAdLayoutApi mNativeAdLayoutApi;
  
  public NativeAdLayout(Context paramContext) {
    super(paramContext);
    initializeSelf(paramContext);
  }
  
  public NativeAdLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initializeSelf(paramContext);
  }
  
  public NativeAdLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initializeSelf(paramContext);
  }
  
  public NativeAdLayout(Context paramContext, NativeAdLayoutApi paramNativeAdLayoutApi) {
    super(paramContext);
    this.mNativeAdLayoutApi = paramNativeAdLayoutApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)paramNativeAdLayoutApi);
    this.mNativeAdLayoutApi.initialize(this);
  }
  
  private void initializeSelf(Context paramContext) {
    NativeAdLayoutApi nativeAdLayoutApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdLayoutApi();
    this.mNativeAdLayoutApi = nativeAdLayoutApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)nativeAdLayoutApi);
    this.mNativeAdLayoutApi.initialize(this);
  }
  
  public NativeAdLayoutApi getNativeAdLayoutApi() {
    return this.mNativeAdLayoutApi;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mNativeAdLayoutApi.setMaxWidth(paramInt);
  }
  
  public void setMinWidth(int paramInt) {
    this.mNativeAdLayoutApi.setMinWidth(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAdLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */