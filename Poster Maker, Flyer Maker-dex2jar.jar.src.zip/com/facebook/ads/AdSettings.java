package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.settings.AdInternalSettings;
import com.facebook.ads.internal.settings.MultithreadedBundleWrapper;
import java.io.Serializable;
import java.util.Collection;

@Keep
public class AdSettings {
  public static final boolean DEBUG = false;
  
  public static void addTestDevice(String paramString) {
    AdInternalSettings.addTestDevice(paramString);
  }
  
  public static void addTestDevices(Collection<String> paramCollection) {
    AdInternalSettings.addTestDevices(paramCollection);
  }
  
  public static void clearTestDevices() {
    AdInternalSettings.clearTestDevices();
  }
  
  public static String getMediationService() {
    return AdInternalSettings.getMediationService();
  }
  
  public static TestAdType getTestAdType() {
    MultithreadedBundleWrapper multithreadedBundleWrapper = AdInternalSettings.sSettingsBundle;
    Serializable serializable = multithreadedBundleWrapper.getSerializable("TEST_AD_TYPE_KEY");
    if (!(serializable instanceof TestAdType)) {
      serializable = TestAdType.DEFAULT;
      multithreadedBundleWrapper.putSerializable("TEST_AD_TYPE_KEY", serializable);
      return (TestAdType)serializable;
    } 
    return (TestAdType)serializable;
  }
  
  public static String getUrlPrefix() {
    return AdInternalSettings.getUrlPrefix();
  }
  
  public static boolean isMixedAudience() {
    return AdInternalSettings.sSettingsBundle.getBoolean("BOOL_MIXED_AUDIENCE_KEY", false);
  }
  
  public static boolean isTestMode(Context paramContext) {
    return AdInternalSettings.isTestMode(paramContext);
  }
  
  public static boolean isVideoAutoplay() {
    return AdInternalSettings.isVideoAutoplay();
  }
  
  public static boolean isVideoAutoplayOnMobile() {
    return AdInternalSettings.isVideoAutoplayOnMobile();
  }
  
  public static void setDataProcessingOptions(String[] paramArrayOfString) {
    AdInternalSettings.setDataProcessingOptions(paramArrayOfString, null, null);
  }
  
  public static void setDataProcessingOptions(String[] paramArrayOfString, int paramInt1, int paramInt2) {
    AdInternalSettings.setDataProcessingOptions(paramArrayOfString, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2));
  }
  
  public static void setDebugBuild(boolean paramBoolean) {
    AdInternalSettings.setDebugBuild(paramBoolean);
  }
  
  public static void setIntegrationErrorMode(IntegrationErrorMode paramIntegrationErrorMode) {
    AdInternalSettings.sSettingsBundle.putSerializable("SRL_INTEGRATION_ERROR_MODE_KEY", paramIntegrationErrorMode);
  }
  
  public static void setMediationService(String paramString) {
    AdInternalSettings.setMediationService(paramString);
  }
  
  public static void setMixedAudience(boolean paramBoolean) {
    AdInternalSettings.sSettingsBundle.putBoolean("BOOL_MIXED_AUDIENCE_KEY", paramBoolean);
  }
  
  public static void setTestAdType(TestAdType paramTestAdType) {
    AdInternalSettings.sSettingsBundle.putSerializable("TEST_AD_TYPE_KEY", paramTestAdType);
  }
  
  public static void setTestMode(boolean paramBoolean) {
    AdInternalSettings.setTestMode(paramBoolean);
  }
  
  public static void setUrlPrefix(String paramString) {
    AdInternalSettings.setUrlPrefix(paramString);
  }
  
  public static void setVideoAutoplay(boolean paramBoolean) {
    AdInternalSettings.setVideoAutoplay(paramBoolean);
  }
  
  public static void setVideoAutoplayOnMobile(boolean paramBoolean) {
    AdInternalSettings.setVideoAutoplayOnMobile(paramBoolean);
  }
  
  public static void setVisibleAnimation(boolean paramBoolean) {
    AdInternalSettings.setVisibleAnimation(paramBoolean);
  }
  
  public static void turnOnSDKDebugger(Context paramContext) {
    AdInternalSettings.turnOnSDKDebugger(paramContext);
  }
  
  @Keep
  public enum IntegrationErrorMode {
    INTEGRATION_ERROR_CALLBACK_MODE, INTEGRATION_ERROR_CRASH_DEBUG_MODE;
    
    public static final long serialVersionUID = 1L;
    
    static {
      IntegrationErrorMode integrationErrorMode1 = new IntegrationErrorMode("INTEGRATION_ERROR_CRASH_DEBUG_MODE", 0);
      INTEGRATION_ERROR_CRASH_DEBUG_MODE = integrationErrorMode1;
      IntegrationErrorMode integrationErrorMode2 = new IntegrationErrorMode("INTEGRATION_ERROR_CALLBACK_MODE", 1);
      INTEGRATION_ERROR_CALLBACK_MODE = integrationErrorMode2;
      $VALUES = new IntegrationErrorMode[] { integrationErrorMode1, integrationErrorMode2 };
    }
  }
  
  @Keep
  public enum TestAdType implements Serializable {
    CAROUSEL_IMG_SQUARE_APP_INSTALL, CAROUSEL_IMG_SQUARE_LINK, DEFAULT, IMG_16_9_APP_INSTALL, IMG_16_9_LINK, PLAYABLE, VIDEO_HD_16_9_15S_APP_INSTALL, VIDEO_HD_16_9_15S_LINK, VIDEO_HD_16_9_46S_APP_INSTALL, VIDEO_HD_16_9_46S_LINK, VIDEO_HD_9_16_39S_APP_INSTALL, VIDEO_HD_9_16_39S_LINK;
    
    public static final long serialVersionUID = 1L;
    
    private final String adTypeString;
    
    private final String humanReadable;
    
    static {
      TestAdType testAdType1 = new TestAdType("DEFAULT", 0, "DEFAULT", "Default");
      DEFAULT = testAdType1;
      TestAdType testAdType2 = new TestAdType("IMG_16_9_APP_INSTALL", 1, "IMG_16_9_APP_INSTALL", "Image App install");
      IMG_16_9_APP_INSTALL = testAdType2;
      TestAdType testAdType3 = new TestAdType("IMG_16_9_LINK", 2, "IMG_16_9_LINK", "Image link");
      IMG_16_9_LINK = testAdType3;
      TestAdType testAdType4 = new TestAdType("VIDEO_HD_16_9_46S_APP_INSTALL", 3, "VID_HD_16_9_46S_APP_INSTALL", "Video 46 sec App install");
      VIDEO_HD_16_9_46S_APP_INSTALL = testAdType4;
      TestAdType testAdType5 = new TestAdType("VIDEO_HD_16_9_46S_LINK", 4, "VID_HD_16_9_46S_LINK", "Video 46 sec link");
      VIDEO_HD_16_9_46S_LINK = testAdType5;
      TestAdType testAdType6 = new TestAdType("VIDEO_HD_16_9_15S_APP_INSTALL", 5, "VID_HD_16_9_15S_APP_INSTALL", "Video 15 sec App install");
      VIDEO_HD_16_9_15S_APP_INSTALL = testAdType6;
      TestAdType testAdType7 = new TestAdType("VIDEO_HD_16_9_15S_LINK", 6, "VID_HD_16_9_15S_LINK", "Video 15 sec link");
      VIDEO_HD_16_9_15S_LINK = testAdType7;
      TestAdType testAdType8 = new TestAdType("VIDEO_HD_9_16_39S_APP_INSTALL", 7, "VID_HD_9_16_39S_APP_INSTALL", "Video 39 sec App install");
      VIDEO_HD_9_16_39S_APP_INSTALL = testAdType8;
      TestAdType testAdType9 = new TestAdType("VIDEO_HD_9_16_39S_LINK", 8, "VID_HD_9_16_39S_LINK", "Video 39 sec link");
      VIDEO_HD_9_16_39S_LINK = testAdType9;
      TestAdType testAdType10 = new TestAdType("CAROUSEL_IMG_SQUARE_APP_INSTALL", 9, "CAROUSEL_IMG_SQUARE_APP_INSTALL", "Carousel App install");
      CAROUSEL_IMG_SQUARE_APP_INSTALL = testAdType10;
      TestAdType testAdType11 = new TestAdType("CAROUSEL_IMG_SQUARE_LINK", 10, "CAROUSEL_IMG_SQUARE_LINK", "Carousel link");
      CAROUSEL_IMG_SQUARE_LINK = testAdType11;
      TestAdType testAdType12 = new TestAdType("PLAYABLE", 11, "PLAYABLE", "Playable ad");
      PLAYABLE = testAdType12;
      $VALUES = new TestAdType[] { 
          testAdType1, testAdType2, testAdType3, testAdType4, testAdType5, testAdType6, testAdType7, testAdType8, testAdType9, testAdType10, 
          testAdType11, testAdType12 };
    }
    
    TestAdType(String param1String1, String param1String2) {
      this.adTypeString = param1String1;
      this.humanReadable = param1String2;
    }
    
    public String getAdTypeString() {
      return this.adTypeString;
    }
    
    public String getHumanReadable() {
      return this.humanReadable;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */