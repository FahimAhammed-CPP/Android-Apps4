package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public interface InterstitialAdListener extends AdListener {
  void onInterstitialDismissed(Ad paramAd);
  
  void onInterstitialDisplayed(Ad paramAd);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\InterstitialAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */