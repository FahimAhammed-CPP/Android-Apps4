package com.facebook.ads;

import androidx.annotation.Keep;

public interface FullScreenAd extends Ad {
  Ad.LoadConfigBuilder buildLoadAdConfig();
  
  ShowConfigBuilder buildShowAdConfig();
  
  boolean show();
  
  @Keep
  public static interface ShowAdConfig {}
  
  @Keep
  public static interface ShowConfigBuilder {
    FullScreenAd.ShowAdConfig build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\FullScreenAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */