package com.facebook.ads;

import android.content.Context;
import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdViewTypeApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

@Keep
public class NativeAdView {
  public static View render(Context paramContext, NativeAd paramNativeAd) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeAd, "nativeAd must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeAdViewApi().render(paramContext, paramNativeAd);
  }
  
  @Deprecated
  public static View render(Context paramContext, NativeAd paramNativeAd, Type paramType) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeAd, "nativeAd must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeAdViewApi().render(paramContext, paramNativeAd, paramType);
  }
  
  @Deprecated
  public static View render(Context paramContext, NativeAd paramNativeAd, Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeAd, "nativeAd must be not null");
    Preconditions.checkNotNull(paramType, "type must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeAdViewApi().render(paramContext, paramNativeAd, paramType, paramNativeAdViewAttributes);
  }
  
  public static View render(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeAd, "nativeAd must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeAdViewApi().render(paramContext, paramNativeAd, paramNativeAdViewAttributes);
  }
  
  @Deprecated
  @Keep
  public enum Type {
    HEIGHT_300, HEIGHT_400;
    
    private final int mEnumCode;
    
    private NativeAdViewTypeApi mNativeAdViewTypeApi;
    
    static {
      Type type1 = new Type("HEIGHT_300", 0, 2);
      HEIGHT_300 = type1;
      Type type2 = new Type("HEIGHT_400", 1, 3);
      HEIGHT_400 = type2;
      $VALUES = new Type[] { type1, type2 };
    }
    
    @Deprecated
    Type(int param1Int1) {
      this.mEnumCode = param1Int1;
    }
    
    private NativeAdViewTypeApi getNativeAdViewTypeApi(int param1Int) {
      if (this.mNativeAdViewTypeApi == null)
        this.mNativeAdViewTypeApi = DynamicLoaderFactory.makeLoaderUnsafe().createNativeAdViewTypeApi(param1Int); 
      return this.mNativeAdViewTypeApi;
    }
    
    public int getEnumCode() {
      return this.mEnumCode;
    }
    
    @Deprecated
    public int getHeight() {
      return getNativeAdViewTypeApi(this.mEnumCode).getHeight();
    }
    
    @Deprecated
    public int getValue() {
      return getNativeAdViewTypeApi(this.mEnumCode).getValue();
    }
    
    @Deprecated
    public int getWidth() {
      return getNativeAdViewTypeApi(this.mEnumCode).getWidth();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */