package com.facebook.ads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AudienceNetworkActivityApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import java.io.FileDescriptor;
import java.io.PrintWriter;

@SuppressLint({"MissingSuperCall"})
@Keep
public class AudienceNetworkActivity extends Activity {
  private AudienceNetworkActivityApi mAudienceNetworkActivityApi;
  
  private final AudienceNetworkActivityApi mAudienceNetworkActivityParentApi = new AudienceNetworkActivityApi() {
      public void dump(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
        AudienceNetworkActivity.this.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
      }
      
      public void finish(int param1Int) {
        AudienceNetworkActivity.this.finish();
      }
      
      public void onActivityResult(int param1Int1, int param1Int2, Intent param1Intent) {
        AudienceNetworkActivity.this.onActivityResult(param1Int1, param1Int2, param1Intent);
      }
      
      public void onBackPressed() {
        AudienceNetworkActivity.this.onBackPressed();
      }
      
      public void onConfigurationChanged(Configuration param1Configuration) {
        AudienceNetworkActivity.this.onConfigurationChanged(param1Configuration);
      }
      
      public void onCreate(Bundle param1Bundle) {
        AudienceNetworkActivity.this.onCreate(param1Bundle);
      }
      
      public void onDestroy() {
        AudienceNetworkActivity.this.onDestroy();
      }
      
      public void onPause() {
        AudienceNetworkActivity.this.onPause();
      }
      
      public void onResume() {
        AudienceNetworkActivity.this.onResume();
      }
      
      public void onSaveInstanceState(Bundle param1Bundle) {
        AudienceNetworkActivity.this.onSaveInstanceState(param1Bundle);
      }
      
      public void onStart() {
        AudienceNetworkActivity.this.onStart();
      }
      
      public void onStop() {
        AudienceNetworkActivity.this.onStop();
      }
      
      public boolean onTouchEvent(MotionEvent param1MotionEvent) {
        return AudienceNetworkActivity.this.onTouchEvent(param1MotionEvent);
      }
    };
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    this.mAudienceNetworkActivityApi.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void finish() {
    this.mAudienceNetworkActivityApi.finish(0);
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.mAudienceNetworkActivityApi.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onBackPressed() {
    this.mAudienceNetworkActivityApi.onBackPressed();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.mAudienceNetworkActivityApi.onConfigurationChanged(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    AudienceNetworkActivityApi audienceNetworkActivityApi = DynamicLoaderFactory.makeLoader((Context)this).createAudienceNetworkActivity(this, this.mAudienceNetworkActivityParentApi);
    this.mAudienceNetworkActivityApi = audienceNetworkActivityApi;
    audienceNetworkActivityApi.onCreate(paramBundle);
  }
  
  public void onDestroy() {
    this.mAudienceNetworkActivityApi.onDestroy();
  }
  
  public void onPause() {
    this.mAudienceNetworkActivityApi.onPause();
  }
  
  public void onResume() {
    this.mAudienceNetworkActivityApi.onResume();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    this.mAudienceNetworkActivityApi.onSaveInstanceState(paramBundle);
  }
  
  public void onStart() {
    this.mAudienceNetworkActivityApi.onStart();
  }
  
  public void onStop() {
    this.mAudienceNetworkActivityApi.onStop();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.mAudienceNetworkActivityApi.onTouchEvent(paramMotionEvent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AudienceNetworkActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */