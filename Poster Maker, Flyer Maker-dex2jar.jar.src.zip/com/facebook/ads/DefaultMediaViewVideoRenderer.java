package com.facebook.ads;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.DefaultMediaViewVideoRendererApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public final class DefaultMediaViewVideoRenderer extends MediaViewVideoRenderer {
  private DefaultMediaViewVideoRendererApi mDefaultMediaViewVideoRendererApi;
  
  public DefaultMediaViewVideoRenderer(Context paramContext) {
    super(paramContext);
    initializeSelf(paramContext);
  }
  
  public DefaultMediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initializeSelf(paramContext);
  }
  
  public DefaultMediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initializeSelf(paramContext);
  }
  
  @TargetApi(21)
  public DefaultMediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    initializeSelf(paramContext);
  }
  
  private void initializeSelf(Context paramContext) {
    DefaultMediaViewVideoRendererApi defaultMediaViewVideoRendererApi = DynamicLoaderFactory.makeLoader(paramContext).createDefaultMediaViewVideoRendererApi();
    this.mDefaultMediaViewVideoRendererApi = defaultMediaViewVideoRendererApi;
    defaultMediaViewVideoRendererApi.initialize(paramContext, this, getMediaViewVideoRendererApi(), 0);
  }
  
  public void onPrepared() {
    super.onPrepared();
    this.mDefaultMediaViewVideoRendererApi.onPrepared();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\DefaultMediaViewVideoRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */