package com.facebook.ads;

import androidx.annotation.Keep;
import java.io.Serializable;

@Keep
public class RewardData implements Serializable {
  private static final long serialVersionUID = -6264212909606201882L;
  
  private String mCurrency;
  
  private int mQuantity;
  
  private String mUserID;
  
  public RewardData(String paramString1, String paramString2) {
    this(paramString1, paramString2, 0);
  }
  
  public RewardData(String paramString1, String paramString2, int paramInt) {
    this.mUserID = paramString1;
    this.mCurrency = paramString2;
    this.mQuantity = paramInt;
  }
  
  public String getCurrency() {
    return this.mCurrency;
  }
  
  public int getQuantity() {
    return this.mQuantity;
  }
  
  public String getUserID() {
    return this.mUserID;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\RewardData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */