package com.facebook.ads;

import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdSizeApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import java.io.Serializable;

@Keep
public class AdSize implements Serializable {
  @Deprecated
  public static final AdSize BANNER_320_50 = new AdSize(4);
  
  public static final AdSize BANNER_HEIGHT_50;
  
  public static final AdSize BANNER_HEIGHT_90;
  
  public static final AdSize INTERSTITIAL = new AdSize(100);
  
  public static final AdSize RECTANGLE_HEIGHT_250;
  
  private final int UNDEFINED = -1;
  
  private AdSizeApi mAdSizeApi;
  
  private final int mInitHeight;
  
  private final int mInitSizeType;
  
  private final int mInitWidth;
  
  static {
    BANNER_HEIGHT_50 = new AdSize(5);
    BANNER_HEIGHT_90 = new AdSize(6);
    RECTANGLE_HEIGHT_250 = new AdSize(7);
  }
  
  private AdSize(int paramInt) {
    this.mInitSizeType = paramInt;
    this.mInitWidth = -1;
    this.mInitHeight = -1;
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this.mInitSizeType = -1;
    this.mInitWidth = paramInt1;
    this.mInitHeight = paramInt2;
  }
  
  public static AdSize fromWidthAndHeight(int paramInt1, int paramInt2) {
    AdSize adSize = INTERSTITIAL;
    if (adSize.getHeight() == paramInt2 && adSize.getWidth() == paramInt1)
      return adSize; 
    adSize = BANNER_320_50;
    if (adSize.getHeight() == paramInt2 && adSize.getWidth() == paramInt1)
      return adSize; 
    adSize = BANNER_HEIGHT_50;
    if (adSize.getHeight() == paramInt2 && adSize.getWidth() == paramInt1)
      return adSize; 
    adSize = BANNER_HEIGHT_90;
    if (adSize.getHeight() == paramInt2 && adSize.getWidth() == paramInt1)
      return adSize; 
    adSize = RECTANGLE_HEIGHT_250;
    if (adSize.getHeight() == paramInt2 && adSize.getWidth() == paramInt1)
      return adSize; 
    throw new IllegalArgumentException("Can't create AdSize using this width and height.");
  }
  
  private AdSizeApi getAdSizeApi(int paramInt) {
    if (this.mAdSizeApi == null)
      this.mAdSizeApi = DynamicLoaderFactory.makeLoaderUnsafe().createAdSizeApi(paramInt); 
    return this.mAdSizeApi;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (getWidth() != paramObject.getWidth()) ? false : ((getHeight() == paramObject.getHeight()));
    } 
    return false;
  }
  
  public int getHeight() {
    int i = this.mInitSizeType;
    return (i != -1) ? getAdSizeApi(i).getHeight() : this.mInitHeight;
  }
  
  public int getWidth() {
    int i = this.mInitSizeType;
    return (i != -1) ? getAdSizeApi(i).getWidth() : this.mInitWidth;
  }
  
  public int hashCode() {
    int i = getWidth();
    return getHeight() + i * 31;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */