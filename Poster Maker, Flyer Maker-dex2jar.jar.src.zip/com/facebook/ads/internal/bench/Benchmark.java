package com.facebook.ads.internal.bench;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
public @interface Benchmark {
  int failAtMillis() default 2147483647;
  
  int warnAtMillis() default 2147483647;
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\bench\Benchmark.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */