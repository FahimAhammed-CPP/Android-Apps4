package com.facebook.ads.internal.bench;

public class BenchmarkLimitsMs {
  public static final int GSF = 5;
  
  public static final int GSW = 1;
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\bench\BenchmarkLimitsMs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */