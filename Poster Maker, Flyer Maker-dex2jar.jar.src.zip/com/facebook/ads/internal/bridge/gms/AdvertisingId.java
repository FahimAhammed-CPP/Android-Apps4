package com.facebook.ads.internal.bridge.gms;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;

@Keep
public class AdvertisingId {
  private final String mId;
  
  private final boolean mLimitAdTracking;
  
  public AdvertisingId(String paramString, boolean paramBoolean) {
    this.mId = paramString;
    this.mLimitAdTracking = paramBoolean;
  }
  
  @SuppressLint({"CatchGeneralException"})
  public static AdvertisingId getAdvertisingIdInfoDirectly(Context paramContext) {
    try {
      AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(paramContext);
      if (info != null)
        return new AdvertisingId(info.getId(), info.isLimitAdTrackingEnabled()); 
    } finally {}
    return null;
  }
  
  public String getId() {
    return this.mId;
  }
  
  public boolean isLimitAdTracking() {
    return this.mLimitAdTracking;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\bridge\gms\AdvertisingId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */