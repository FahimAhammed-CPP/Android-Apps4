package com.facebook.ads.internal.bridge.fbsdk;

import android.annotation.SuppressLint;
import androidx.annotation.Keep;

@Keep
public class FBLoginASID {
  @SuppressLint({"CatchGeneralException"})
  public static String getFBLoginASID() {
    try {
      Object object;
      return (object != null) ? (String)Class.forName("com.facebook.AccessToken").getDeclaredMethod("getUserId", new Class[0]).invoke(object, new Object[0]) : null;
    } finally {
      Exception exception = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\bridge\fbsdk\FBLoginASID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */