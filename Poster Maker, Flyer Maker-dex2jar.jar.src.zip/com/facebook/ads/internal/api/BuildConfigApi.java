package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.BuildConfig;
import s30;

@Keep
public class BuildConfigApi {
  public static final String UNITY_SHARED_PREFERENCES_SUFIX = ".v2.playerprefs";
  
  public static final String UNITY_TAG = "an_isUnitySDK";
  
  public static final String UNITY_VERSION_SUFIX = "-unity";
  
  public static String getVersionName(Context paramContext) {
    return isUnity(paramContext) ? s30.o0(new StringBuilder(), BuildConfig.VERSION_NAME, "-unity") : BuildConfig.VERSION_NAME;
  }
  
  public static boolean isDebug() {
    return BuildConfig.DEBUG;
  }
  
  private static boolean isUnity(Context paramContext) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramContext.getPackageName());
    stringBuilder.append(".v2.playerprefs");
    String str = stringBuilder.toString();
    boolean bool = false;
    if (paramContext.getSharedPreferences(str, 0).contains("an_isUnitySDK") || paramContext.getSharedPreferences(paramContext.getPackageName(), 0).contains("an_isUnitySDK"))
      bool = true; 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\BuildConfigApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */