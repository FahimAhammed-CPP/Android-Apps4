package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;

@Keep
public interface BidderTokenProviderApi {
  String getBidderToken(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\BidderTokenProviderApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */