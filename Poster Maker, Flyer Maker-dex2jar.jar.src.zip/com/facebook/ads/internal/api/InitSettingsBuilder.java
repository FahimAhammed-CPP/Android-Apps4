package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.settings.MultithreadedBundleWrapper;
import java.util.ArrayList;
import java.util.List;

@Keep
public class InitSettingsBuilder implements AudienceNetworkAds.InitSettingsBuilder {
  public static final String PLACEMENTS_KEY = "PLACEMENTS_KEY";
  
  private final Context mContext;
  
  private final MultithreadedBundleWrapper mInitSettings = new MultithreadedBundleWrapper();
  
  private AudienceNetworkAds.InitListener mInitializationListener;
  
  public InitSettingsBuilder(Context paramContext) {
    this.mContext = paramContext;
  }
  
  public void initialize() {
    DynamicLoaderFactory.initialize(this.mContext, this.mInitSettings, this.mInitializationListener, false);
  }
  
  public InitSettingsBuilder withInitListener(AudienceNetworkAds.InitListener paramInitListener) {
    this.mInitializationListener = paramInitListener;
    return this;
  }
  
  public InitSettingsBuilder withMediationService(String paramString) {
    AdSettings.setMediationService(paramString);
    return this;
  }
  
  public InitSettingsBuilder withPlacementIds(List<String> paramList) {
    paramList = new ArrayList<String>(paramList);
    this.mInitSettings.putStringArrayList("PLACEMENTS_KEY", (ArrayList)paramList);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\InitSettingsBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */