package com.facebook.ads.internal.api;

import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.MediaViewVideoRenderer;
import com.facebook.ads.VideoStartReason;

@Keep
public interface MediaViewVideoRendererApi extends AdComponentViewApiProvider {
  void destroy();
  
  void disengageSeek(VideoStartReason paramVideoStartReason);
  
  void engageSeek();
  
  int getCurrentTimeMs();
  
  int getDuration();
  
  View getVideoView();
  
  float getVolume();
  
  void initialize(AdViewConstructorParams paramAdViewConstructorParams, MediaViewVideoRenderer paramMediaViewVideoRenderer);
  
  void pause(boolean paramBoolean);
  
  void play(VideoStartReason paramVideoStartReason);
  
  void seekTo(int paramInt);
  
  void setVolume(float paramFloat);
  
  boolean shouldAutoplay();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\MediaViewVideoRendererApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */