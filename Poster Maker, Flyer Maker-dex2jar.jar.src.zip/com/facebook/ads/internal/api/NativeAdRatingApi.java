package com.facebook.ads.internal.api;

import androidx.annotation.Keep;

@Keep
public interface NativeAdRatingApi {
  double getScale();
  
  double getValue();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdRatingApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */