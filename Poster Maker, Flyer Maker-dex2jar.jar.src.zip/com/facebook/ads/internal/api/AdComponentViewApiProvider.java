package com.facebook.ads.internal.api;

import androidx.annotation.Keep;

@Keep
public interface AdComponentViewApiProvider {
  AdComponentViewApi getAdComponentViewApi();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdComponentViewApiProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */