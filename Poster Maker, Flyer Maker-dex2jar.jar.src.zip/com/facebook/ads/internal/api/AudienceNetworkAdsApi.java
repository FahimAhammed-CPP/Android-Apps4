package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.internal.settings.MultithreadedBundleWrapper;

@Keep
public interface AudienceNetworkAdsApi {
  public static final int BANNER = 1;
  
  public static final int INTERSTITIAL = 2;
  
  public static final int NATIVE = 4;
  
  public static final int NATIVE_BANNER = 5;
  
  public static final int REWARDED_VIDEO = 6;
  
  public static final int UNKNOWN = 0;
  
  int getAdFormatForPlacement(String paramString);
  
  void initialize(Context paramContext, MultithreadedBundleWrapper paramMultithreadedBundleWrapper, AudienceNetworkAds.InitListener paramInitListener);
  
  boolean isInitialized();
  
  void onContentProviderCreated(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AudienceNetworkAdsApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */