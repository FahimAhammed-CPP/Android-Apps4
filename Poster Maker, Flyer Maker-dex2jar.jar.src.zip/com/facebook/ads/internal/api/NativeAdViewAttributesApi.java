package com.facebook.ads.internal.api;

import android.graphics.Typeface;
import androidx.annotation.Keep;

@Keep
public interface NativeAdViewAttributesApi {
  void setBackgroundColor(int paramInt);
  
  void setCTABackgroundColor(int paramInt);
  
  void setCTABorderColor(int paramInt);
  
  void setCTATextColor(int paramInt);
  
  void setPrimaryTextColor(int paramInt);
  
  void setSecondaryTextColor(int paramInt);
  
  void setTypeface(Typeface paramTypeface);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdViewAttributesApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */