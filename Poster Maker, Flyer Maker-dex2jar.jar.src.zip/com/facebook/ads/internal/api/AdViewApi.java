package com.facebook.ads.internal.api;

import android.content.res.Configuration;
import androidx.annotation.Keep;
import com.facebook.ads.Ad;
import com.facebook.ads.AdView;
import com.facebook.ads.ExtraHints;
import com.facebook.proguard.annotations.DoNotStripAny;

@Keep
@DoNotStripAny
public interface AdViewApi extends AdViewParentApi, Ad {
  AdView.AdViewLoadConfigBuilder buildLoadAdConfig();
  
  void loadAd(AdView.AdViewLoadConfig paramAdViewLoadConfig);
  
  void onConfigurationChanged(Configuration paramConfiguration);
  
  @Deprecated
  void setExtraHints(ExtraHints paramExtraHints);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdViewApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */