package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.internal.settings.MultithreadedBundleWrapper;

@Keep
public interface InitApi {
  public static final int INIT_TYPE_CONTENT_PROVIDER = 0;
  
  public static final int INIT_TYPE_INTERNAL_API = 3;
  
  public static final int INIT_TYPE_PUBLIC_API = 1;
  
  public static final int INIT_TYPE_REMOTE_PROCESS = 2;
  
  void initialize(Context paramContext, MultithreadedBundleWrapper paramMultithreadedBundleWrapper, AudienceNetworkAds.InitListener paramInitListener, int paramInt);
  
  boolean isInitialized();
  
  void onAdLoadInvoked(Context paramContext);
  
  void onContentProviderCreated(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\InitApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */