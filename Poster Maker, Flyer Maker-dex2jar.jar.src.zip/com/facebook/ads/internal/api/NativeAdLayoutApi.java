package com.facebook.ads.internal.api;

import androidx.annotation.Keep;
import com.facebook.ads.NativeAdLayout;

@Keep
public interface NativeAdLayoutApi extends AdComponentViewApiProvider {
  void initialize(NativeAdLayout paramNativeAdLayout);
  
  void setMaxWidth(int paramInt);
  
  void setMinWidth(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdLayoutApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */