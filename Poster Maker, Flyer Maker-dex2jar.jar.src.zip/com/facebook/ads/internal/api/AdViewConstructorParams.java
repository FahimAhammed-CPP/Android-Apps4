package com.facebook.ads.internal.api;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;

@Keep
public class AdViewConstructorParams {
  public static final int CONTEXT = 0;
  
  public static final int CONTEXT_ATTRS = 1;
  
  public static final int CONTEXT_ATTRS_STYLE_ATTR = 2;
  
  public static final int CONTEXT_ATTRS_STYLE_ATTR_STYLE_RES = 3;
  
  private final AttributeSet mAttributeSet;
  
  private final Context mContext;
  
  private final int mDefStyleAttr;
  
  private final int mDefStyleRes;
  
  private final int mInitializationType = 0;
  
  public AdViewConstructorParams(Context paramContext) {
    this.mContext = paramContext;
    this.mAttributeSet = null;
    this.mDefStyleAttr = 0;
    this.mDefStyleRes = 0;
  }
  
  public AdViewConstructorParams(Context paramContext, AttributeSet paramAttributeSet) {
    this.mContext = paramContext;
    this.mAttributeSet = paramAttributeSet;
    this.mDefStyleAttr = 0;
    this.mDefStyleRes = 0;
  }
  
  public AdViewConstructorParams(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this.mContext = paramContext;
    this.mAttributeSet = paramAttributeSet;
    this.mDefStyleAttr = paramInt;
    this.mDefStyleRes = 0;
  }
  
  public AdViewConstructorParams(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mContext = paramContext;
    this.mAttributeSet = paramAttributeSet;
    this.mDefStyleAttr = paramInt1;
    this.mDefStyleRes = paramInt2;
  }
  
  public AttributeSet getAttributeSet() {
    return this.mAttributeSet;
  }
  
  public Context getContext() {
    return this.mContext;
  }
  
  public int getDefStyleAttr() {
    return this.mDefStyleAttr;
  }
  
  public int getDefStyleRes() {
    return this.mDefStyleRes;
  }
  
  public int getInitializationType() {
    return this.mInitializationType;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdViewConstructorParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */