package com.facebook.ads.internal.api;

public interface AdCompanionViewApi extends AdComponentViewApiProvider {
  void initialize(AdCompanionView paramAdCompanionView);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdCompanionViewApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */