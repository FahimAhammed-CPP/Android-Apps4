package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;

@Keep
public interface AdSettingsApi {
  boolean isTestMode(Context paramContext);
  
  void turnOnDebugger();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdSettingsApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */