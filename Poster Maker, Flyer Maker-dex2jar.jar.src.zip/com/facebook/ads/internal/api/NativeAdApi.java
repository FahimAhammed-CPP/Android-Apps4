package com.facebook.ads.internal.api;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.Keep;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.VideoAutoplayBehavior;
import java.util.List;

@Keep
public interface NativeAdApi {
  NativeAd.AdCreativeType getAdCreativeType();
  
  VideoAutoplayBehavior getVideoAutoplayBehavior();
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView, ImageView paramImageView);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView, ImageView paramImageView, List<View> paramList);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView1, MediaView paramMediaView2);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView1, MediaView paramMediaView2, List<View> paramList);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView, List<View> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */