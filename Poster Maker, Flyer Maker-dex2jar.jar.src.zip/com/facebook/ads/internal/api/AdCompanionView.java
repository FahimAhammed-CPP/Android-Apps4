package com.facebook.ads.internal.api;

import android.content.Context;
import android.util.AttributeSet;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

public class AdCompanionView extends AdComponentFrameLayout {
  private AdCompanionViewApi mAdCompanionViewApi;
  
  public AdCompanionView(Context paramContext) {
    super(paramContext);
    initializeSelf(paramContext);
  }
  
  public AdCompanionView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initializeSelf(paramContext);
  }
  
  public AdCompanionView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initializeSelf(paramContext);
  }
  
  private void initializeSelf(Context paramContext) {
    AdCompanionViewApi adCompanionViewApi = DynamicLoaderFactory.makeLoader(paramContext).createAdCompanionViewApi();
    this.mAdCompanionViewApi = adCompanionViewApi;
    attachAdComponentViewApi(adCompanionViewApi);
    this.mAdCompanionViewApi.initialize(this);
  }
  
  public AdCompanionViewApi getAdCompanionViewApi() {
    return this.mAdCompanionViewApi;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdCompanionView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */