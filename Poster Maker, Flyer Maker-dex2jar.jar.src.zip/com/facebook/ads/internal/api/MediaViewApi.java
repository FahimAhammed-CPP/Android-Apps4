package com.facebook.ads.internal.api;

import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.facebook.ads.MediaViewVideoRenderer;

@Keep
public interface MediaViewApi extends AdComponentViewApiProvider {
  void destroy();
  
  View getAdContentsView();
  
  int getMediaHeight();
  
  int getMediaWidth();
  
  void initialize(AdViewConstructorParams paramAdViewConstructorParams, MediaView paramMediaView);
  
  void setListener(MediaViewListener paramMediaViewListener);
  
  void setVideoRenderer(MediaViewVideoRenderer paramMediaViewVideoRenderer);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\MediaViewApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */