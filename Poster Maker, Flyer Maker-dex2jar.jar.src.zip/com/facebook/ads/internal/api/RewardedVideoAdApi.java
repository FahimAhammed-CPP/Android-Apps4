package com.facebook.ads.internal.api;

import androidx.annotation.Keep;
import com.facebook.ads.Ad;
import com.facebook.ads.ExtraHints;
import com.facebook.ads.FullScreenAd;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.proguard.annotations.DoNotStripAny;

@Keep
@DoNotStripAny
public interface RewardedVideoAdApi extends FullScreenAd {
  RewardedVideoAd.RewardedVideoAdLoadConfigBuilder buildLoadAdConfig();
  
  RewardedVideoAd.RewardedVideoAdShowConfigBuilder buildShowAdConfig();
  
  void destroy();
  
  String getPlacementId();
  
  int getVideoDuration();
  
  boolean isAdLoaded();
  
  void loadAd();
  
  void loadAd(RewardedVideoAd.RewardedVideoLoadAdConfig paramRewardedVideoLoadAdConfig);
  
  void registerAdCompanionView(AdCompanionView paramAdCompanionView);
  
  @Deprecated
  void setExtraHints(ExtraHints paramExtraHints);
  
  boolean show();
  
  boolean show(RewardedVideoAd.RewardedVideoShowAdConfig paramRewardedVideoShowAdConfig);
  
  void unregisterAdCompanionView();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\RewardedVideoAdApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */