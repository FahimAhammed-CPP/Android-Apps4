package com.facebook.ads.internal.api;

import android.view.View;
import android.widget.ImageView;
import androidx.annotation.Keep;
import com.facebook.ads.MediaView;
import java.util.List;

@Keep
public interface NativeBannerAdApi {
  void registerViewForInteraction(View paramView, ImageView paramImageView);
  
  void registerViewForInteraction(View paramView, ImageView paramImageView, List<View> paramList);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView);
  
  void registerViewForInteraction(View paramView, MediaView paramMediaView, List<View> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeBannerAdApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */