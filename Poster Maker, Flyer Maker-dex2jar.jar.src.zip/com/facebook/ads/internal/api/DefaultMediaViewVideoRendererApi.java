package com.facebook.ads.internal.api;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.MediaViewVideoRenderer;

@Keep
public interface DefaultMediaViewVideoRendererApi {
  public static final int MEDIA_VIEW_RENDERER_CHILD_TYPE_BACKGROUND_PLAYBACK = 1;
  
  public static final int MEDIA_VIEW_RENDERER_CHILD_TYPE_DEFAULT = 0;
  
  void initialize(Context paramContext, MediaViewVideoRenderer paramMediaViewVideoRenderer, MediaViewVideoRendererApi paramMediaViewVideoRendererApi, int paramInt);
  
  void onPrepared();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\DefaultMediaViewVideoRendererApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */