package com.facebook.ads.internal.api;

import androidx.annotation.Keep;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdsManager;
import com.facebook.proguard.annotations.DoNotStripAny;

@Keep
@DoNotStripAny
public interface NativeAdsManagerApi {
  void disableAutoRefresh();
  
  int getUniqueNativeAdCount();
  
  boolean isLoaded();
  
  void loadAds();
  
  void loadAds(NativeAdBase.MediaCacheFlag paramMediaCacheFlag);
  
  NativeAd nextNativeAd();
  
  NativeAd nextNativeAd(NativeAdListener paramNativeAdListener);
  
  void setExtraHints(String paramString);
  
  void setListener(NativeAdsManager.Listener paramListener);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdsManagerApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */