package com.facebook.ads.internal.api;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import androidx.annotation.Keep;
import com.facebook.proguard.annotations.DoNotStripAny;
import java.io.FileDescriptor;
import java.io.PrintWriter;

@Keep
@DoNotStripAny
public interface AudienceNetworkActivityApi {
  public static final int EXTERNAL_FINISH_REASON = 0;
  
  void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  void finish(int paramInt);
  
  void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent);
  
  void onBackPressed();
  
  void onConfigurationChanged(Configuration paramConfiguration);
  
  void onCreate(Bundle paramBundle);
  
  void onDestroy();
  
  void onPause();
  
  void onResume();
  
  void onSaveInstanceState(Bundle paramBundle);
  
  void onStart();
  
  void onStop();
  
  boolean onTouchEvent(MotionEvent paramMotionEvent);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AudienceNetworkActivityApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */