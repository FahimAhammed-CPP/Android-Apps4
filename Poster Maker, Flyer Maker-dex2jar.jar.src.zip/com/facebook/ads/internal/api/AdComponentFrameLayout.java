package com.facebook.ads.internal.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.Keep;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public abstract class AdComponentFrameLayout extends FrameLayout implements AdComponentView {
  private AdComponentViewApi mAdComponentViewApi;
  
  private final AdComponentViewParentApi mAdComponentViewParentApi = new AdComponentViewParentApi() {
      public void addView(View param1View) {
        AdComponentFrameLayout.this.addView(param1View);
      }
      
      public void addView(View param1View, int param1Int) {
        AdComponentFrameLayout.this.addView(param1View, param1Int);
      }
      
      public void addView(View param1View, int param1Int1, int param1Int2) {
        AdComponentFrameLayout.this.addView(param1View, param1Int1, param1Int2);
      }
      
      public void addView(View param1View, int param1Int, ViewGroup.LayoutParams param1LayoutParams) {
        AdComponentFrameLayout.this.addView(param1View, param1Int, param1LayoutParams);
      }
      
      public void addView(View param1View, ViewGroup.LayoutParams param1LayoutParams) {
        AdComponentFrameLayout.this.addView(param1View, param1LayoutParams);
      }
      
      public void bringChildToFront(View param1View) {
        AdComponentFrameLayout.this.bringChildToFront(param1View);
      }
      
      public void onAttachedToWindow() {
        AdComponentFrameLayout.this.onAttachedToWindow();
      }
      
      public void onDetachedFromWindow() {
        AdComponentFrameLayout.this.onDetachedFromWindow();
      }
      
      public void onMeasure(int param1Int1, int param1Int2) {
        AdComponentFrameLayout.this.onMeasure(param1Int1, param1Int2);
      }
      
      public void onVisibilityChanged(View param1View, int param1Int) {
        AdComponentFrameLayout.this.onVisibilityChanged(param1View, param1Int);
      }
      
      public void onWindowFocusChanged(boolean param1Boolean) {
        AdComponentFrameLayout.this.onWindowFocusChanged(param1Boolean);
      }
      
      public void setLayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
        AdComponentFrameLayout.this.setLayoutParams(param1LayoutParams);
      }
      
      public void setMeasuredDimension(int param1Int1, int param1Int2) {
        AdComponentFrameLayout.this.setMeasuredDimension(param1Int1, param1Int2);
      }
    };
  
  public AdComponentFrameLayout(Context paramContext) {
    super(paramContext);
  }
  
  public AdComponentFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public AdComponentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public AdComponentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void addView(View paramView) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView);
      return;
    } 
    super.addView(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt);
      return;
    } 
    super.addView(paramView, paramInt);
  }
  
  public void addView(View paramView, int paramInt1, int paramInt2) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt1, paramInt2);
      return;
    } 
    super.addView(paramView, paramInt1, paramInt2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramLayoutParams);
      return;
    } 
    super.addView(paramView, paramLayoutParams);
  }
  
  public void attachAdComponentViewApi(AdComponentViewApiProvider paramAdComponentViewApiProvider) {
    if (DynamicLoaderFactory.isFallbackMode())
      return; 
    if (this.mAdComponentViewApi == null) {
      paramAdComponentViewApiProvider.getAdComponentViewApi().onAttachedToView(this, this.mAdComponentViewParentApi);
      this.mAdComponentViewApi = paramAdComponentViewApiProvider.getAdComponentViewApi();
      return;
    } 
    throw new IllegalStateException("AdComponentViewApi can't be attached more then once.");
  }
  
  @SuppressLint({"MissingSuperCall"})
  public void onAttachedToWindow() {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onAttachedToWindow();
      return;
    } 
    super.onAttachedToWindow();
  }
  
  @SuppressLint({"MissingSuperCall"})
  public void onDetachedFromWindow() {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onDetachedFromWindow();
      return;
    } 
    super.onDetachedFromWindow();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onVisibilityChanged(View paramView, int paramInt) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onVisibilityChanged(paramView, paramInt);
      return;
    } 
    super.onVisibilityChanged(paramView, paramInt);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onWindowFocusChanged(paramBoolean);
      return;
    } 
    super.onWindowFocusChanged(paramBoolean);
  }
  
  public void setLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.setLayoutParams(paramLayoutParams);
      return;
    } 
    super.setLayoutParams(paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdComponentFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */