package com.facebook.ads.internal.api;

import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.ExtraHints;
import com.facebook.ads.NativeAdBase;

@Keep
public interface NativeAdBaseApi {
  NativeAdBase.NativeAdLoadConfigBuilder buildLoadAdConfig(NativeAdBase paramNativeAdBase);
  
  void destroy();
  
  void downloadMedia();
  
  String getAdBodyText();
  
  String getAdCallToAction();
  
  NativeAdImageApi getAdChoicesIcon();
  
  String getAdChoicesImageUrl();
  
  String getAdChoicesLinkUrl();
  
  String getAdChoicesText();
  
  NativeAdImageApi getAdCoverImage();
  
  String getAdHeadline();
  
  NativeAdImageApi getAdIcon();
  
  String getAdLinkDescription();
  
  String getAdSocialContext();
  
  @Deprecated
  NativeAdRatingApi getAdStarRating();
  
  String getAdTranslation();
  
  String getAdUntrimmedBodyText();
  
  String getAdvertiserName();
  
  float getAspectRatio();
  
  String getId();
  
  String getPlacementId();
  
  Drawable getPreloadedIconViewDrawable();
  
  String getPromotedTranslation();
  
  String getSponsoredTranslation();
  
  boolean hasCallToAction();
  
  boolean isAdInvalidated();
  
  boolean isAdLoaded();
  
  void loadAd();
  
  void loadAd(NativeAdBase.NativeLoadAdConfig paramNativeLoadAdConfig);
  
  void onCtaBroadcast();
  
  void setExtraHints(ExtraHints paramExtraHints);
  
  void setOnTouchListener(View.OnTouchListener paramOnTouchListener);
  
  void unregisterView();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdBaseApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */