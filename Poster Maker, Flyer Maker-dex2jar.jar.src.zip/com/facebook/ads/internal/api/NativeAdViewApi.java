package com.facebook.ads.internal.api;

import android.content.Context;
import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeAdViewAttributes;

@Keep
public interface NativeAdViewApi {
  View render(Context paramContext, NativeAd paramNativeAd);
  
  @Deprecated
  View render(Context paramContext, NativeAd paramNativeAd, NativeAdView.Type paramType);
  
  @Deprecated
  View render(Context paramContext, NativeAd paramNativeAd, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes);
  
  View render(Context paramContext, NativeAd paramNativeAd, NativeAdViewAttributes paramNativeAdViewAttributes);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\NativeAdViewApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */