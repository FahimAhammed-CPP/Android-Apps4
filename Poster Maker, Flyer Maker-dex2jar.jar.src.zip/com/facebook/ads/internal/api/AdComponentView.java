package com.facebook.ads.internal.api;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Keep;

@Keep
public interface AdComponentView {
  void addView(View paramView);
  
  void addView(View paramView, int paramInt);
  
  void addView(View paramView, int paramInt1, int paramInt2);
  
  void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams);
  
  void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  void onWindowFocusChanged(boolean paramBoolean);
  
  void setLayoutParams(ViewGroup.LayoutParams paramLayoutParams);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\api\AdComponentView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */