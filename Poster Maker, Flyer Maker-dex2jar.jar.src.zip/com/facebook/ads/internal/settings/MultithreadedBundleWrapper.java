package com.facebook.ads.internal.settings;

import android.os.Bundle;
import androidx.annotation.Keep;
import java.io.Serializable;
import java.util.ArrayList;

@Keep
public class MultithreadedBundleWrapper {
  private final Bundle mBundle = new Bundle();
  
  public boolean getBoolean(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   10: istore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: iload_2
    //   14: ireturn
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	15	finally
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   11: istore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: iload_2
    //   15: ireturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public Integer getInteger(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   10: ifeq -> 28
    //   13: aload_0
    //   14: getfield mBundle : Landroid/os/Bundle;
    //   17: aload_1
    //   18: invokevirtual getInt : (Ljava/lang/String;)I
    //   21: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   24: astore_1
    //   25: goto -> 30
    //   28: aconst_null
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: areturn
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	34	finally
  }
  
  public Serializable getSerializable(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: invokevirtual getSerializable : (Ljava/lang/String;)Ljava/io/Serializable;
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: areturn
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	15	finally
  }
  
  public String getString(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: aload_2
    //   8: invokevirtual getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public String[] getStringArray(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: invokevirtual getStringArray : (Ljava/lang/String;)[Ljava/lang/String;
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: areturn
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	15	finally
  }
  
  public ArrayList<String> getStringArrayList(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: invokevirtual getStringArrayList : (Ljava/lang/String;)Ljava/util/ArrayList;
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: areturn
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	15	finally
  }
  
  public void putBoolean(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void putInteger(String paramString, Integer paramInteger) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: ifnull -> 21
    //   6: aload_0
    //   7: getfield mBundle : Landroid/os/Bundle;
    //   10: aload_1
    //   11: aload_2
    //   12: invokevirtual intValue : ()I
    //   15: invokevirtual putInt : (Ljava/lang/String;I)V
    //   18: goto -> 29
    //   21: aload_0
    //   22: getfield mBundle : Landroid/os/Bundle;
    //   25: aload_1
    //   26: invokevirtual remove : (Ljava/lang/String;)V
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   6	18	32	finally
    //   21	29	32	finally
  }
  
  public void putSerializable(String paramString, Serializable paramSerializable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: aload_2
    //   8: invokevirtual putSerializable : (Ljava/lang/String;Ljava/io/Serializable;)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void putString(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: aload_2
    //   8: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void putStringArray(String paramString, String[] paramArrayOfString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: aload_2
    //   8: invokevirtual putStringArray : (Ljava/lang/String;[Ljava/lang/String;)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void putStringArrayList(String paramString, ArrayList<String> paramArrayList) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: aload_1
    //   7: aload_2
    //   8: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void reset(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBundle : Landroid/os/Bundle;
    //   6: invokevirtual clear : ()V
    //   9: aload_0
    //   10: getfield mBundle : Landroid/os/Bundle;
    //   13: aload_1
    //   14: invokevirtual putAll : (Landroid/os/Bundle;)V
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	20	finally
  }
  
  public Bundle toBundle() {
    return new Bundle(this.mBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\settings\MultithreadedBundleWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */