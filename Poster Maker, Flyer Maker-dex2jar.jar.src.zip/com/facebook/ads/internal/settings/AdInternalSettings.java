package com.facebook.ads.internal.settings;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.dynamicloading.DynamicLoader;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicBoolean;

@Keep
public class AdInternalSettings {
  private static final String BOOL_AUTOPLAY_ON_MOBILE_KEY = "BOOL_AUTOPLAY_ON_MOBILE_KEY";
  
  private static final String BOOL_DEBUGGER_STATE_KEY = "BOOL_DEBUGGER_STATE_KEY";
  
  private static final String BOOL_DEBUG_BUILD_KEY = "BOOL_DEBUG_BUILD_KEY";
  
  private static final String BOOL_EXPLICIT_TEST_MODE_KEY = "BOOL_EXPLICIT_TEST_MODE_KEY";
  
  public static final String BOOL_MIXED_AUDIENCE_KEY = "BOOL_MIXED_AUDIENCE_KEY";
  
  private static final String BOOL_VIDEO_AUTOPLAY_KEY = "BOOL_VIDEO_AUTOPLAY_KEY";
  
  private static final String BOOL_VISIBLE_ANIMATION_KEY = "BOOL_VISIBLE_ANIMATION_KEY";
  
  public static final String DATA_PROCESSING_OPTIONS_COUNTRY_KEY = "DATA_PROCESSING_OPTIONS_COUNTRY_KEY";
  
  public static final String DATA_PROCESSING_OPTIONS_KEY = "DATA_PROCESSING_OPTIONS_KEY";
  
  public static final String DATA_PROCESSING_OPTIONS_STATE_KEY = "DATA_PROCESSING_OPTIONS_STATE_KEY";
  
  private static final String LIST_TEST_DEVICES_KEY = "LIST_TEST_DEVICES_KEY";
  
  public static final String SRL_INTEGRATION_ERROR_MODE_KEY = "SRL_INTEGRATION_ERROR_MODE_KEY";
  
  private static final String STR_MEDIATION_SERVICE_KEY = "STR_MEDIATION_SERVICE_KEY";
  
  private static final String STR_URL_PREFIX_KEY = "STR_URL_PREFIX_KEY";
  
  public static final String TEST_AD_TYPE_KEY = "TEST_AD_TYPE_KEY";
  
  public static final AtomicBoolean sDataProcessingOptionsUpdate;
  
  public static final MultithreadedBundleWrapper sSettingsBundle = new MultithreadedBundleWrapper();
  
  static {
    sDataProcessingOptionsUpdate = new AtomicBoolean(false);
  }
  
  public static void addTestDevice(String paramString) {
    getTestDevicesList().add(paramString);
  }
  
  public static void addTestDevices(Collection<String> paramCollection) {
    getTestDevicesList().addAll(paramCollection);
  }
  
  public static void clearTestDevices() {
    getTestDevicesList().clear();
  }
  
  public static String getMediationService() {
    return sSettingsBundle.getString("STR_MEDIATION_SERVICE_KEY", null);
  }
  
  public static ArrayList<String> getTestDevicesList() {
    MultithreadedBundleWrapper multithreadedBundleWrapper = sSettingsBundle;
    ArrayList<String> arrayList2 = multithreadedBundleWrapper.getStringArrayList("LIST_TEST_DEVICES_KEY");
    ArrayList<String> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList<String>();
      multithreadedBundleWrapper.putStringArrayList("LIST_TEST_DEVICES_KEY", arrayList1);
    } 
    return arrayList1;
  }
  
  public static String getUrlPrefix() {
    return sSettingsBundle.getString("STR_URL_PREFIX_KEY", null);
  }
  
  public static boolean isDebugBuild() {
    return sSettingsBundle.getBoolean("BOOL_DEBUG_BUILD_KEY", false);
  }
  
  public static boolean isDebuggerOn() {
    return sSettingsBundle.getBoolean("BOOL_DEBUGGER_STATE_KEY", false);
  }
  
  public static boolean isExplicitTestMode() {
    return sSettingsBundle.getBoolean("BOOL_EXPLICIT_TEST_MODE_KEY", false);
  }
  
  public static boolean isTestMode(Context paramContext) {
    return DynamicLoaderFactory.makeLoader(paramContext).createAdSettingsApi().isTestMode(paramContext);
  }
  
  public static boolean isVideoAutoplay() {
    return sSettingsBundle.getBoolean("BOOL_VIDEO_AUTOPLAY_KEY");
  }
  
  public static boolean isVideoAutoplayOnMobile() {
    return sSettingsBundle.getBoolean("BOOL_AUTOPLAY_ON_MOBILE_KEY", false);
  }
  
  public static boolean isVisibleAnimation() {
    return sSettingsBundle.getBoolean("BOOL_VISIBLE_ANIMATION_KEY", false);
  }
  
  public static void setDataProcessingOptions(String[] paramArrayOfString, Integer paramInteger1, Integer paramInteger2) {
    synchronized (sSettingsBundle) {
      sDataProcessingOptionsUpdate.set(true);
      null.putStringArray("DATA_PROCESSING_OPTIONS_KEY", paramArrayOfString);
      null.putInteger("DATA_PROCESSING_OPTIONS_COUNTRY_KEY", paramInteger1);
      null.putInteger("DATA_PROCESSING_OPTIONS_STATE_KEY", paramInteger2);
      return;
    } 
  }
  
  public static void setDebugBuild(boolean paramBoolean) {
    DynamicLoader dynamicLoader = DynamicLoaderFactory.getDynamicLoader();
    if (dynamicLoader != null && paramBoolean)
      dynamicLoader.createAdSettingsApi().turnOnDebugger(); 
    sSettingsBundle.putBoolean("BOOL_DEBUG_BUILD_KEY", paramBoolean);
  }
  
  public static void setMediationService(String paramString) {
    sSettingsBundle.putString("STR_MEDIATION_SERVICE_KEY", paramString);
  }
  
  public static void setTestMode(boolean paramBoolean) {
    sSettingsBundle.putBoolean("BOOL_EXPLICIT_TEST_MODE_KEY", paramBoolean);
  }
  
  public static void setUrlPrefix(String paramString) {
    sSettingsBundle.putString("STR_URL_PREFIX_KEY", paramString);
  }
  
  public static void setVideoAutoplay(boolean paramBoolean) {
    sSettingsBundle.putBoolean("BOOL_VIDEO_AUTOPLAY_KEY", paramBoolean);
  }
  
  public static void setVideoAutoplayOnMobile(boolean paramBoolean) {
    sSettingsBundle.putBoolean("BOOL_AUTOPLAY_ON_MOBILE_KEY", paramBoolean);
  }
  
  public static void setVisibleAnimation(boolean paramBoolean) {
    sSettingsBundle.putBoolean("BOOL_VISIBLE_ANIMATION_KEY", paramBoolean);
  }
  
  public static void turnOnSDKDebugger(Context paramContext) {
    DynamicLoader dynamicLoader = DynamicLoaderFactory.getDynamicLoader();
    if (dynamicLoader != null) {
      dynamicLoader.createAdSettingsApi().turnOnDebugger();
      return;
    } 
    sSettingsBundle.putBoolean("BOOL_DEBUGGER_STATE_KEY", true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\settings\AdInternalSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */