package com.facebook.ads.internal.dynamicloading;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Keep;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.internal.api.AdViewApi;
import com.facebook.ads.internal.api.AdViewParentApi;
import com.facebook.ads.internal.api.InterstitialAdApi;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.api.RewardedVideoAdApi;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

@Keep
public class DynamicLoaderFallback {
  private static final WeakHashMap<Object, AdListener> sApiProxyToAdListenersMap = new WeakHashMap<Object, AdListener>();
  
  private static boolean equalsMethodParams(Method paramMethod1, Method paramMethod2) {
    return Arrays.equals((Object[])paramMethod1.getParameterTypes(), (Object[])paramMethod2.getParameterTypes());
  }
  
  private static boolean equalsMethods(Method paramMethod1, Method paramMethod2) {
    return (paramMethod1 != null && paramMethod2 != null && paramMethod1.getDeclaringClass().equals(paramMethod2.getDeclaringClass()) && paramMethod1.getName().equals(paramMethod2.getName()) && equalsMethodParams(paramMethod1, paramMethod2));
  }
  
  @SuppressLint({"Parameter Not Nullable", "CatchGeneralException"})
  public static DynamicLoader makeFallbackLoader() {
    final ArrayList<Method> loadMethods = new ArrayList();
    final ArrayList<Method> loadWithConfigMethods = new ArrayList();
    final ArrayList<Method> withListenerMethods = new ArrayList();
    final ArrayList<Method> buildLoadConfigMethods = new ArrayList();
    final ArrayList<Method> createApiMethods = new ArrayList();
    final HashMap<Object, Object> apiProxyToAdMap = new HashMap<Object, Object>();
    final HashMap<Object, Object> loadConfigBuilderProxyToApiMap = new HashMap<Object, Object>();
    SimpleMethodCaptor simpleMethodCaptor = new SimpleMethodCaptor();
    DynamicLoader dynamicLoader = simpleMethodCaptor.<DynamicLoader>mock(DynamicLoader.class);
    dynamicLoader.createInterstitialAd(null, null, null);
    arrayList5.add(simpleMethodCaptor.getLastMethod());
    dynamicLoader.createRewardedVideoAd(null, null, null);
    arrayList5.add(simpleMethodCaptor.getLastMethod());
    dynamicLoader.createAdViewApi((Context)null, (String)null, (AdSize)null, (AdViewParentApi)null, (AdView)null);
    arrayList5.add(simpleMethodCaptor.getLastMethod());
    try {
      dynamicLoader.createAdViewApi((Context)null, (String)null, (String)null, (AdViewParentApi)null, (AdView)null);
    } catch (Exception exception) {}
    arrayList5.add(simpleMethodCaptor.getLastMethod());
    dynamicLoader.createNativeAdApi(null, null);
    final Method nativeAdCreateMethod = simpleMethodCaptor.getLastMethod();
    dynamicLoader.createNativeBannerAdApi(null, null);
    final Method nativeBannerAdCreateMethod = simpleMethodCaptor.getLastMethod();
    NativeAdBaseApi nativeAdBaseApi = simpleMethodCaptor.<NativeAdBaseApi>mock(NativeAdBaseApi.class);
    nativeAdBaseApi.loadAd();
    arrayList1.add(simpleMethodCaptor.getLastMethod());
    nativeAdBaseApi.loadAd(null);
    arrayList2.add(simpleMethodCaptor.getLastMethod());
    nativeAdBaseApi.buildLoadAdConfig(null);
    arrayList4.add(simpleMethodCaptor.getLastMethod());
    InterstitialAdApi interstitialAdApi = simpleMethodCaptor.<InterstitialAdApi>mock(InterstitialAdApi.class);
    interstitialAdApi.loadAd();
    arrayList1.add(simpleMethodCaptor.getLastMethod());
    interstitialAdApi.loadAd(null);
    arrayList2.add(simpleMethodCaptor.getLastMethod());
    interstitialAdApi.buildLoadAdConfig();
    arrayList4.add(simpleMethodCaptor.getLastMethod());
    RewardedVideoAdApi rewardedVideoAdApi = simpleMethodCaptor.<RewardedVideoAdApi>mock(RewardedVideoAdApi.class);
    rewardedVideoAdApi.loadAd();
    arrayList1.add(simpleMethodCaptor.getLastMethod());
    rewardedVideoAdApi.loadAd(null);
    arrayList2.add(simpleMethodCaptor.getLastMethod());
    rewardedVideoAdApi.buildLoadAdConfig();
    arrayList4.add(simpleMethodCaptor.getLastMethod());
    AdViewApi adViewApi = simpleMethodCaptor.<AdViewApi>mock(AdViewApi.class);
    adViewApi.loadAd();
    arrayList1.add(simpleMethodCaptor.getLastMethod());
    adViewApi.loadAd(null);
    arrayList2.add(simpleMethodCaptor.getLastMethod());
    adViewApi.buildLoadAdConfig();
    arrayList4.add(simpleMethodCaptor.getLastMethod());
    ((AdView.AdViewLoadConfigBuilder)simpleMethodCaptor.<AdView.AdViewLoadConfigBuilder>mock(AdView.AdViewLoadConfigBuilder.class)).withAdListener(null);
    arrayList3.add(simpleMethodCaptor.getLastMethod());
    ((NativeAdBase.NativeAdLoadConfigBuilder)simpleMethodCaptor.<NativeAdBase.NativeAdLoadConfigBuilder>mock(NativeAdBase.NativeAdLoadConfigBuilder.class)).withAdListener(null);
    arrayList3.add(simpleMethodCaptor.getLastMethod());
    ((InterstitialAd.InterstitialAdLoadConfigBuilder)simpleMethodCaptor.<InterstitialAd.InterstitialAdLoadConfigBuilder>mock(InterstitialAd.InterstitialAdLoadConfigBuilder.class)).withAdListener(null);
    arrayList3.add(simpleMethodCaptor.getLastMethod());
    ((RewardedVideoAd.RewardedVideoAdLoadConfigBuilder)simpleMethodCaptor.<RewardedVideoAd.RewardedVideoAdLoadConfigBuilder>mock(RewardedVideoAd.RewardedVideoAdLoadConfigBuilder.class)).withAdListener(null);
    arrayList3.add(simpleMethodCaptor.getLastMethod());
    InvocationHandler invocationHandler = new InvocationHandler() {
        public Object invoke(Object param1Object, Method param1Method, Object[] param1ArrayOfObject) {
          Iterator<Method> iterator1;
          Object object;
          if (param1Method.getReturnType().isPrimitive()) {
            if (param1Method.getReturnType().equals(void.class)) {
              iterator1 = loadMethods.iterator();
              do {
              
              } while (iterator1.hasNext() && (!DynamicLoaderFallback.equalsMethods(param1Method, iterator1.next()) || !DynamicLoaderFallback.reportError(param1Object, apiProxyToAdMap)));
              iterator1 = loadWithConfigMethods.iterator();
              do {
              
              } while (iterator1.hasNext() && (!DynamicLoaderFallback.equalsMethods(param1Method, iterator1.next()) || !DynamicLoaderFallback.reportError(param1Object, apiProxyToAdMap)));
              return null;
            } 
            return Array.get(Array.newInstance(param1Method.getReturnType(), 1), 0);
          } 
          if (param1Method.getReturnType().equals(String.class))
            return ""; 
          if (param1Method.getReturnType().equals(param1Object.getClass().getInterfaces()[0])) {
            object = param1Object;
          } else {
            object = Proxy.newProxyInstance(DynamicLoaderFallback.class.getClassLoader(), new Class[] { param1Method.getReturnType() }, this);
          } 
          Iterator<Method> iterator2 = withListenerMethods.iterator();
          while (iterator2.hasNext()) {
            if (DynamicLoaderFallback.equalsMethods(param1Method, iterator2.next())) {
              DynamicLoaderFallback.sApiProxyToAdListenersMap.put(loadConfigBuilderProxyToApiMap.get(param1Object), iterator1[0]);
              break;
            } 
          } 
          iterator2 = buildLoadConfigMethods.iterator();
          while (iterator2.hasNext()) {
            if (DynamicLoaderFallback.equalsMethods(param1Method, iterator2.next()))
              loadConfigBuilderProxyToApiMap.put(object, param1Object); 
          } 
          param1Object = createApiMethods.iterator();
          while (param1Object.hasNext()) {
            if (DynamicLoaderFallback.equalsMethods(param1Method, param1Object.next())) {
              int j = iterator1.length;
              int i;
              for (i = 0; i < j; i++) {
                iterator2 = iterator1[i];
                if (iterator2 instanceof Ad)
                  apiProxyToAdMap.put(object, (Ad)iterator2); 
              } 
            } 
          } 
          if (DynamicLoaderFallback.equalsMethods(param1Method, nativeAdCreateMethod))
            apiProxyToAdMap.put(iterator1[1], (Ad)iterator1[0]); 
          if (DynamicLoaderFallback.equalsMethods(param1Method, nativeBannerAdCreateMethod))
            apiProxyToAdMap.put(iterator1[1], (Ad)iterator1[0]); 
          return object;
        }
      };
    return (DynamicLoader)Proxy.newProxyInstance(DynamicLoaderFallback.class.getClassLoader(), new Class[] { DynamicLoader.class }, invocationHandler);
  }
  
  private static boolean reportError(final Object ad, Map<Object, Ad> paramMap) {
    if (ad == null)
      return false; 
    final AdListener adListener = sApiProxyToAdListenersMap.get(ad);
    ad = paramMap.get(ad);
    if (adListener != null) {
      (new Handler(Looper.getMainLooper())).postDelayed(new Runnable() {
            public void run() {
              adListener.onError(ad, new AdError(-1, "Can't load Audience Network Dex. Please, check that audience_network.dex is inside of assets folder."));
            }
          }500L);
      return true;
    } 
    return false;
  }
  
  public static class SimpleMethodCaptor {
    private final InvocationHandler mInvocationHandler = new InvocationHandler() {
        public Object invoke(Object param2Object, Method param2Method, Object[] param2ArrayOfObject) {
          if (!"toString".equals(param2Method.getName()))
            DynamicLoaderFallback.SimpleMethodCaptor.access$402(DynamicLoaderFallback.SimpleMethodCaptor.this, param2Method); 
          return null;
        }
      };
    
    private Method mLastInvokedMethod;
    
    private SimpleMethodCaptor() {}
    
    public Method getLastMethod() {
      return this.mLastInvokedMethod;
    }
    
    public <T> T mock(Class<T> param1Class) {
      ClassLoader classLoader = DynamicLoaderFallback.class.getClassLoader();
      InvocationHandler invocationHandler = this.mInvocationHandler;
      return param1Class.cast(Proxy.newProxyInstance(classLoader, new Class[] { param1Class }, invocationHandler));
    }
  }
  
  public class null implements InvocationHandler {
    public Object invoke(Object param1Object, Method param1Method, Object[] param1ArrayOfObject) {
      if (!"toString".equals(param1Method.getName()))
        DynamicLoaderFallback.SimpleMethodCaptor.access$402(this.this$0, param1Method); 
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\dynamicloading\DynamicLoaderFallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */