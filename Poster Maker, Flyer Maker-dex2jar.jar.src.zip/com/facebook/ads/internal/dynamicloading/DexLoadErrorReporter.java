package com.facebook.ads.internal.dynamicloading;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import com.facebook.ads.internal.api.BuildConfigApi;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public class DexLoadErrorReporter {
  private static final String LOGGING_URL = "https://www.facebook.com/adnw_logging/";
  
  public static final double SAMPLING = 0.1D;
  
  private static final AtomicBoolean sAlreadyReported = new AtomicBoolean();
  
  private static void addEnvFields(Context paramContext, JSONObject paramJSONObject, String paramString) {
    String str = paramContext.getPackageName();
    paramJSONObject.put("APPBUILD", (paramContext.getPackageManager().getPackageInfo(str, 0)).versionCode);
    ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(str, 0);
    paramJSONObject.put("APPNAME", paramContext.getPackageManager().getApplicationLabel(applicationInfo));
    paramJSONObject.put("APPVERS", (paramContext.getPackageManager().getPackageInfo(str, 0)).versionName);
    paramJSONObject.put("OSVERS", Build.VERSION.RELEASE);
    paramJSONObject.put("SDK", "android");
    paramJSONObject.put("SESSION_ID", paramString);
    paramJSONObject.put("MODEL", Build.MODEL);
    paramJSONObject.put("BUNDLE", str);
    paramJSONObject.put("SDK_VERSION", BuildConfigApi.getVersionName(paramContext));
    paramJSONObject.put("OS", "Android");
  }
  
  @SuppressLint({"CatchGeneralException"})
  public static void reportDexLoadingIssue(final Context context, final String error, double paramDouble) {
    AtomicBoolean atomicBoolean = sAlreadyReported;
    if (!atomicBoolean.get() && Math.random() < paramDouble) {
      atomicBoolean.set(true);
      (new Thread() {
          public void run() {
            // Byte code:
            //   0: aload_0
            //   1: invokespecial run : ()V
            //   4: aconst_null
            //   5: astore #5
            //   7: aconst_null
            //   8: astore #4
            //   10: new java/net/URL
            //   13: dup
            //   14: ldc 'https://www.facebook.com/adnw_logging/'
            //   16: invokespecial <init> : (Ljava/lang/String;)V
            //   19: invokevirtual openConnection : ()Ljava/net/URLConnection;
            //   22: checkcast java/net/HttpURLConnection
            //   25: astore_3
            //   26: aload_3
            //   27: ldc 'POST'
            //   29: invokevirtual setRequestMethod : (Ljava/lang/String;)V
            //   32: aload_3
            //   33: ldc 'Content-Type'
            //   35: ldc 'application/x-www-form-urlencoded;charset=UTF-8'
            //   37: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
            //   40: aload_3
            //   41: ldc 'Accept'
            //   43: ldc 'application/json'
            //   45: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
            //   48: aload_3
            //   49: ldc 'Accept-Charset'
            //   51: ldc 'UTF-8'
            //   53: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
            //   56: aload_3
            //   57: ldc 'user-agent'
            //   59: ldc '[FBAN/AudienceNetworkForAndroid;FBSN/Android]'
            //   61: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
            //   64: aload_3
            //   65: iconst_1
            //   66: invokevirtual setDoOutput : (Z)V
            //   69: aload_3
            //   70: iconst_1
            //   71: invokevirtual setDoInput : (Z)V
            //   74: aload_3
            //   75: invokevirtual connect : ()V
            //   78: invokestatic randomUUID : ()Ljava/util/UUID;
            //   81: invokevirtual toString : ()Ljava/lang/String;
            //   84: astore #7
            //   86: new org/json/JSONObject
            //   89: dup
            //   90: invokespecial <init> : ()V
            //   93: astore_2
            //   94: aload_2
            //   95: ldc 'attempt'
            //   97: ldc '0'
            //   99: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   102: pop
            //   103: aload_0
            //   104: getfield val$context : Landroid/content/Context;
            //   107: aload_2
            //   108: aload #7
            //   110: invokestatic access$000 : (Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;)V
            //   113: new org/json/JSONObject
            //   116: dup
            //   117: invokespecial <init> : ()V
            //   120: astore #8
            //   122: aload #8
            //   124: ldc 'subtype'
            //   126: ldc 'generic'
            //   128: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   131: pop
            //   132: aload #8
            //   134: ldc 'subtype_code'
            //   136: ldc '1320'
            //   138: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   141: pop
            //   142: aload #8
            //   144: ldc 'caught_exception'
            //   146: ldc '1'
            //   148: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   151: pop
            //   152: aload #8
            //   154: ldc 'stacktrace'
            //   156: aload_0
            //   157: getfield val$error : Ljava/lang/String;
            //   160: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   163: pop
            //   164: new org/json/JSONObject
            //   167: dup
            //   168: invokespecial <init> : ()V
            //   171: astore #6
            //   173: aload #6
            //   175: ldc 'id'
            //   177: invokestatic randomUUID : ()Ljava/util/UUID;
            //   180: invokevirtual toString : ()Ljava/lang/String;
            //   183: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   186: pop
            //   187: aload #6
            //   189: ldc 'type'
            //   191: ldc 'debug'
            //   193: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   196: pop
            //   197: new java/lang/StringBuilder
            //   200: dup
            //   201: invokespecial <init> : ()V
            //   204: astore #9
            //   206: aload #9
            //   208: ldc ''
            //   210: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   213: pop
            //   214: aload #9
            //   216: invokestatic currentTimeMillis : ()J
            //   219: ldc2_w 1000
            //   222: ldiv
            //   223: invokevirtual append : (J)Ljava/lang/StringBuilder;
            //   226: pop
            //   227: aload #6
            //   229: ldc 'session_time'
            //   231: aload #9
            //   233: invokevirtual toString : ()Ljava/lang/String;
            //   236: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   239: pop
            //   240: new java/lang/StringBuilder
            //   243: dup
            //   244: invokespecial <init> : ()V
            //   247: astore #9
            //   249: aload #9
            //   251: ldc ''
            //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   256: pop
            //   257: aload #9
            //   259: invokestatic currentTimeMillis : ()J
            //   262: ldc2_w 1000
            //   265: ldiv
            //   266: invokevirtual append : (J)Ljava/lang/StringBuilder;
            //   269: pop
            //   270: aload #6
            //   272: ldc 'time'
            //   274: aload #9
            //   276: invokevirtual toString : ()Ljava/lang/String;
            //   279: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   282: pop
            //   283: aload #6
            //   285: ldc 'session_id'
            //   287: aload #7
            //   289: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   292: pop
            //   293: aload #6
            //   295: ldc 'data'
            //   297: aload #8
            //   299: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   302: pop
            //   303: aload #6
            //   305: ldc 'attempt'
            //   307: ldc '0'
            //   309: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   312: pop
            //   313: aload_0
            //   314: getfield val$context : Landroid/content/Context;
            //   317: aload #8
            //   319: aload #7
            //   321: invokestatic access$000 : (Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;)V
            //   324: new org/json/JSONArray
            //   327: dup
            //   328: invokespecial <init> : ()V
            //   331: astore #7
            //   333: aload #7
            //   335: aload #6
            //   337: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
            //   340: pop
            //   341: new org/json/JSONObject
            //   344: dup
            //   345: invokespecial <init> : ()V
            //   348: astore #6
            //   350: aload #6
            //   352: ldc 'data'
            //   354: aload_2
            //   355: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   358: pop
            //   359: aload #6
            //   361: ldc 'events'
            //   363: aload #7
            //   365: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
            //   368: pop
            //   369: aload #6
            //   371: invokevirtual toString : ()Ljava/lang/String;
            //   374: astore #7
            //   376: new java/io/DataOutputStream
            //   379: dup
            //   380: aload_3
            //   381: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
            //   384: invokespecial <init> : (Ljava/io/OutputStream;)V
            //   387: astore #6
            //   389: aload #5
            //   391: astore_2
            //   392: new java/lang/StringBuilder
            //   395: dup
            //   396: invokespecial <init> : ()V
            //   399: astore #4
            //   401: aload #5
            //   403: astore_2
            //   404: aload #4
            //   406: ldc 'payload='
            //   408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   411: pop
            //   412: aload #5
            //   414: astore_2
            //   415: aload #4
            //   417: aload #7
            //   419: ldc 'UTF-8'
            //   421: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
            //   424: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   427: pop
            //   428: aload #5
            //   430: astore_2
            //   431: aload #6
            //   433: aload #4
            //   435: invokevirtual toString : ()Ljava/lang/String;
            //   438: invokevirtual writeBytes : (Ljava/lang/String;)V
            //   441: aload #5
            //   443: astore_2
            //   444: aload #6
            //   446: invokevirtual flush : ()V
            //   449: aload #5
            //   451: astore_2
            //   452: sipush #16384
            //   455: newarray byte
            //   457: astore #7
            //   459: aload #5
            //   461: astore_2
            //   462: new java/io/ByteArrayOutputStream
            //   465: dup
            //   466: invokespecial <init> : ()V
            //   469: astore #8
            //   471: aload #5
            //   473: astore_2
            //   474: aload_3
            //   475: invokevirtual getInputStream : ()Ljava/io/InputStream;
            //   478: astore #4
            //   480: aload #4
            //   482: astore_2
            //   483: aload #4
            //   485: aload #7
            //   487: invokevirtual read : ([B)I
            //   490: istore_1
            //   491: iload_1
            //   492: iconst_m1
            //   493: if_icmpeq -> 511
            //   496: aload #4
            //   498: astore_2
            //   499: aload #8
            //   501: aload #7
            //   503: iconst_0
            //   504: iload_1
            //   505: invokevirtual write : ([BII)V
            //   508: goto -> 480
            //   511: aload #4
            //   513: astore_2
            //   514: aload #8
            //   516: invokevirtual flush : ()V
            //   519: aload #6
            //   521: invokevirtual close : ()V
            //   524: aload #4
            //   526: invokevirtual close : ()V
            //   529: goto -> 576
            //   532: aload #6
            //   534: astore #4
            //   536: goto -> 548
            //   539: aconst_null
            //   540: astore_2
            //   541: goto -> 548
            //   544: aconst_null
            //   545: astore_2
            //   546: aload_2
            //   547: astore_3
            //   548: aload #4
            //   550: ifnull -> 561
            //   553: aload #4
            //   555: invokevirtual close : ()V
            //   558: goto -> 561
            //   561: aload_2
            //   562: ifnull -> 572
            //   565: aload_2
            //   566: invokevirtual close : ()V
            //   569: goto -> 572
            //   572: aload_3
            //   573: ifnull -> 580
            //   576: aload_3
            //   577: invokevirtual disconnect : ()V
            //   580: return
            //   581: astore_2
            //   582: goto -> 544
            //   585: astore_2
            //   586: goto -> 539
            //   589: astore #4
            //   591: goto -> 532
            //   594: astore_2
            //   595: goto -> 524
            //   598: astore_2
            //   599: goto -> 576
            //   602: astore #4
            //   604: goto -> 561
            //   607: astore_2
            //   608: goto -> 572
            // Exception table:
            //   from	to	target	type
            //   10	26	581	finally
            //   26	389	585	finally
            //   392	401	589	finally
            //   404	412	589	finally
            //   415	428	589	finally
            //   431	441	589	finally
            //   444	449	589	finally
            //   452	459	589	finally
            //   462	471	589	finally
            //   474	480	589	finally
            //   483	491	589	finally
            //   499	508	589	finally
            //   514	519	589	finally
            //   519	524	594	java/lang/Exception
            //   524	529	598	java/lang/Exception
            //   553	558	602	java/lang/Exception
            //   565	569	607	java/lang/Exception
          }
        }).start();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\dynamicloading\DexLoadErrorReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */