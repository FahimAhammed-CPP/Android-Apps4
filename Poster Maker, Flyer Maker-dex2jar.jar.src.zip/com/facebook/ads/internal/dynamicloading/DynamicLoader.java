package com.facebook.ads.internal.dynamicloading;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkActivity;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdScrollView;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeAdViewAttributes;
import com.facebook.ads.NativeAdsManager;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.RewardedInterstitialAd;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.internal.api.AdCompanionViewApi;
import com.facebook.ads.internal.api.AdOptionsViewApi;
import com.facebook.ads.internal.api.AdSettingsApi;
import com.facebook.ads.internal.api.AdSizeApi;
import com.facebook.ads.internal.api.AdViewApi;
import com.facebook.ads.internal.api.AdViewParentApi;
import com.facebook.ads.internal.api.AudienceNetworkActivityApi;
import com.facebook.ads.internal.api.AudienceNetworkAdsApi;
import com.facebook.ads.internal.api.BidderTokenProviderApi;
import com.facebook.ads.internal.api.DefaultMediaViewVideoRendererApi;
import com.facebook.ads.internal.api.InitApi;
import com.facebook.ads.internal.api.InterstitialAdApi;
import com.facebook.ads.internal.api.MediaViewApi;
import com.facebook.ads.internal.api.MediaViewVideoRendererApi;
import com.facebook.ads.internal.api.NativeAdApi;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.api.NativeAdImageApi;
import com.facebook.ads.internal.api.NativeAdLayoutApi;
import com.facebook.ads.internal.api.NativeAdRatingApi;
import com.facebook.ads.internal.api.NativeAdScrollViewApi;
import com.facebook.ads.internal.api.NativeAdViewApi;
import com.facebook.ads.internal.api.NativeAdViewAttributesApi;
import com.facebook.ads.internal.api.NativeAdViewTypeApi;
import com.facebook.ads.internal.api.NativeAdsManagerApi;
import com.facebook.ads.internal.api.NativeBannerAdApi;
import com.facebook.ads.internal.api.NativeBannerAdViewApi;
import com.facebook.ads.internal.api.NativeComponentTagApi;
import com.facebook.ads.internal.api.RewardedInterstitialAdApi;
import com.facebook.ads.internal.api.RewardedVideoAdApi;
import org.json.JSONObject;

@Keep
public interface DynamicLoader {
  AdCompanionViewApi createAdCompanionViewApi();
  
  AdOptionsViewApi createAdOptionsView(Context paramContext, NativeAdBase paramNativeAdBase, NativeAdLayout paramNativeAdLayout, AdOptionsView.Orientation paramOrientation, int paramInt, AdOptionsView paramAdOptionsView);
  
  AdOptionsViewApi createAdOptionsView(Context paramContext, NativeAdBase paramNativeAdBase, NativeAdLayout paramNativeAdLayout, AdOptionsView paramAdOptionsView);
  
  AdSettingsApi createAdSettingsApi();
  
  AdSizeApi createAdSizeApi(int paramInt);
  
  AdViewApi createAdViewApi(Context paramContext, String paramString, AdSize paramAdSize, AdViewParentApi paramAdViewParentApi, AdView paramAdView);
  
  AdViewApi createAdViewApi(Context paramContext, String paramString1, String paramString2, AdViewParentApi paramAdViewParentApi, AdView paramAdView);
  
  AudienceNetworkActivityApi createAudienceNetworkActivity(AudienceNetworkActivity paramAudienceNetworkActivity, AudienceNetworkActivityApi paramAudienceNetworkActivityApi);
  
  AudienceNetworkAdsApi createAudienceNetworkAdsApi();
  
  BidderTokenProviderApi createBidderTokenProviderApi();
  
  DefaultMediaViewVideoRendererApi createDefaultMediaViewVideoRendererApi();
  
  InterstitialAdApi createInterstitialAd(Context paramContext, String paramString, InterstitialAd paramInterstitialAd);
  
  MediaViewApi createMediaViewApi();
  
  MediaViewVideoRendererApi createMediaViewVideoRendererApi();
  
  NativeAdApi createNativeAdApi(NativeAd paramNativeAd, NativeAdBaseApi paramNativeAdBaseApi);
  
  NativeAdApi createNativeAdApi(NativeAdBase paramNativeAdBase, NativeAd paramNativeAd, NativeAdBaseApi paramNativeAdBaseApi);
  
  NativeAdBaseApi createNativeAdBaseApi(Context paramContext, String paramString);
  
  NativeAdBaseApi createNativeAdBaseApi(NativeAdBaseApi paramNativeAdBaseApi);
  
  NativeAdBase createNativeAdBaseFromBidPayload(Context paramContext, String paramString1, String paramString2);
  
  NativeAdImageApi createNativeAdImageApi(JSONObject paramJSONObject);
  
  NativeAdLayoutApi createNativeAdLayoutApi();
  
  NativeAdRatingApi createNativeAdRatingApi(JSONObject paramJSONObject);
  
  NativeAdScrollViewApi createNativeAdScrollViewApi(NativeAdScrollView paramNativeAdScrollView, Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdScrollView.AdViewProvider paramAdViewProvider, int paramInt1, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt2);
  
  NativeAdViewApi createNativeAdViewApi();
  
  NativeAdViewAttributesApi createNativeAdViewAttributesApi();
  
  NativeAdViewTypeApi createNativeAdViewTypeApi(int paramInt);
  
  NativeAdsManagerApi createNativeAdsManagerApi(Context paramContext, String paramString, int paramInt);
  
  NativeBannerAdApi createNativeBannerAdApi(NativeBannerAd paramNativeBannerAd, NativeAdBaseApi paramNativeAdBaseApi);
  
  NativeBannerAdViewApi createNativeBannerAdViewApi();
  
  NativeComponentTagApi createNativeComponentTagApi();
  
  RewardedInterstitialAdApi createRewardedInterstitialAd(Context paramContext, String paramString, RewardedInterstitialAd paramRewardedInterstitialAd);
  
  RewardedVideoAdApi createRewardedVideoAd(Context paramContext, String paramString, RewardedVideoAd paramRewardedVideoAd);
  
  InitApi getInitApi();
  
  void maybeInitInternally(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\dynamicloading\DynamicLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */