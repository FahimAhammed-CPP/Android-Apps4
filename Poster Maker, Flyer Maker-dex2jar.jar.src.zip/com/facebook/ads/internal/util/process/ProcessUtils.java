package com.facebook.ads.internal.util.process;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.Keep;
import java.lang.reflect.Field;
import s30;

@Keep
public final class ProcessUtils {
  private static String sProcessName;
  
  public static String getProcessName(Context paramContext) {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/util/process/ProcessUtils.sProcessName : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 16
    //   11: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   18: monitorexit
    //   19: getstatic android/os/Build$VERSION.SDK_INT : I
    //   22: bipush #28
    //   24: if_icmplt -> 31
    //   27: invokestatic getProcessNameAPI28 : ()Ljava/lang/String;
    //   30: areturn
    //   31: aload_0
    //   32: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   35: astore_0
    //   36: aload_0
    //   37: instanceof android/app/Application
    //   40: ifeq -> 69
    //   43: aload_0
    //   44: checkcast android/app/Application
    //   47: invokestatic getProcessNameViaReflection : (Landroid/app/Application;)Ljava/lang/String;
    //   50: astore_0
    //   51: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   53: monitorenter
    //   54: aload_0
    //   55: putstatic com/facebook/ads/internal/util/process/ProcessUtils.sProcessName : Ljava/lang/String;
    //   58: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   60: monitorexit
    //   61: aload_0
    //   62: areturn
    //   63: astore_0
    //   64: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   66: monitorexit
    //   67: aload_0
    //   68: athrow
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: ldc com/facebook/ads/internal/util/process/ProcessUtils
    //   74: monitorexit
    //   75: aload_0
    //   76: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	71	finally
    //   11	14	71	finally
    //   16	19	71	finally
    //   54	61	63	finally
    //   64	67	63	finally
    //   72	75	71	finally
  }
  
  private static String getProcessNameAPI28() {
    try {
      return (String)Application.class.getMethod("getProcessName", null).invoke(null, null);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private static String getProcessNameViaReflection(Application paramApplication) {
    try {
      Field field = paramApplication.getClass().getField("mLoadedApk");
      field.setAccessible(true);
      null = field.get(paramApplication);
      field = null.getClass().getDeclaredField("mActivityThread");
      field.setAccessible(true);
      null = field.get(null);
      return (String)null.getClass().getDeclaredMethod("getProcessName", null).invoke(null, null);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static String getProcessSpecificName(String paramString, Context paramContext) {
    String str3 = paramContext.getPackageName();
    String str2 = getProcessName(paramContext);
    String str1 = paramString;
    if (!TextUtils.isEmpty(str2)) {
      str1 = paramString;
      if (!str3.equals(str2)) {
        str1 = str2;
        if (str2.contains(":"))
          str1 = str2.split(":")[1]; 
        str1 = s30.h0(paramString, "_", str1);
      } 
    } 
    return str1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\interna\\util\process\ProcessUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */