package com.facebook.ads.internal.util.parcelable;

import android.os.Parcel;
import android.os.Parcelable;

public class WrappedParcelable implements Parcelable {
  public static final Parcelable.Creator<WrappedParcelable> CREATOR = new Parcelable.Creator<WrappedParcelable>() {
      public WrappedParcelable createFromParcel(Parcel param1Parcel) {
        return new WrappedParcelable(param1Parcel);
      }
      
      public WrappedParcelable[] newArray(int param1Int) {
        return new WrappedParcelable[param1Int];
      }
    };
  
  private final byte[] mParcelableBytes;
  
  public WrappedParcelable(Parcel paramParcel) {
    this.mParcelableBytes = paramParcel.createByteArray();
  }
  
  public WrappedParcelable(Parcelable paramParcelable) {
    this.mParcelableBytes = marshallParcelable(paramParcelable);
  }
  
  public WrappedParcelable(byte[] paramArrayOfbyte) {
    this.mParcelableBytes = paramArrayOfbyte;
  }
  
  public static byte[] marshallParcelable(Parcelable paramParcelable) {
    Parcel parcel = Parcel.obtain();
    parcel.writeParcelable(paramParcelable, 0);
    byte[] arrayOfByte = parcel.marshall();
    parcel.recycle();
    return arrayOfByte;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Parcelable unwrap(ClassLoader paramClassLoader) {
    Parcel parcel = Parcel.obtain();
    byte[] arrayOfByte = this.mParcelableBytes;
    if (arrayOfByte != null) {
      parcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
      parcel.setDataPosition(0);
      Parcelable parcelable = parcel.readParcelable(paramClassLoader);
      parcel.recycle();
      return parcelable;
    } 
    return null;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeByteArray(this.mParcelableBytes);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\interna\\util\parcelable\WrappedParcelable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */