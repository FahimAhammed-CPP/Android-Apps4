package com.facebook.ads.internal.util.common;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

@Keep
public class ANActivityLifecycleCallbacksListener implements Application.ActivityLifecycleCallbacks {
  public static final int ACTIVITY_CREATED = 1;
  
  public static final int ACTIVITY_DESTROYED = 6;
  
  public static final int ACTIVITY_PAUSED = 4;
  
  public static final int ACTIVITY_RESUMED = 3;
  
  public static final int ACTIVITY_STARTED = 2;
  
  public static final int ACTIVITY_STOPPED = 5;
  
  private static ANActivityLifecycleCallbacksListener sANActivityLifecycleCallbacksListener;
  
  private static final Map<Activity, Integer> sActivityStateMap = Collections.synchronizedMap(new WeakHashMap<Activity, Integer>());
  
  public static ANActivityLifecycleCallbacksListener getANActivityLifecycleCallbacksListener() {
    // Byte code:
    //   0: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   2: monitorenter
    //   3: getstatic com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener.sANActivityLifecycleCallbacksListener : Lcom/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener;
    //   6: astore_0
    //   7: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static void registerActivityCallbacks(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   4: astore_0
    //   5: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   7: monitorenter
    //   8: aload_0
    //   9: instanceof android/app/Application
    //   12: ifeq -> 41
    //   15: getstatic com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener.sANActivityLifecycleCallbacksListener : Lcom/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener;
    //   18: ifnonnull -> 41
    //   21: new com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore_1
    //   29: aload_1
    //   30: putstatic com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener.sANActivityLifecycleCallbacksListener : Lcom/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener;
    //   33: aload_0
    //   34: checkcast android/app/Application
    //   37: aload_1
    //   38: invokevirtual registerActivityLifecycleCallbacks : (Landroid/app/Application$ActivityLifecycleCallbacks;)V
    //   41: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   43: monitorexit
    //   44: return
    //   45: astore_0
    //   46: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   48: monitorexit
    //   49: aload_0
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   8	41	45	finally
    //   41	44	45	finally
    //   46	49	45	finally
  }
  
  public static void unregisterActivityCallbacks(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   4: astore_0
    //   5: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   7: monitorenter
    //   8: aload_0
    //   9: instanceof android/app/Application
    //   12: ifeq -> 29
    //   15: aload_0
    //   16: checkcast android/app/Application
    //   19: getstatic com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener.sANActivityLifecycleCallbacksListener : Lcom/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener;
    //   22: invokevirtual unregisterActivityLifecycleCallbacks : (Landroid/app/Application$ActivityLifecycleCallbacks;)V
    //   25: aconst_null
    //   26: putstatic com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener.sANActivityLifecycleCallbacksListener : Lcom/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener;
    //   29: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   31: monitorexit
    //   32: return
    //   33: astore_0
    //   34: ldc com/facebook/ads/internal/util/common/ANActivityLifecycleCallbacksListener
    //   36: monitorexit
    //   37: aload_0
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   8	29	33	finally
    //   29	32	33	finally
    //   34	37	33	finally
  }
  
  public Map<Activity, Integer> getActivityStateMap() {
    return sActivityStateMap;
  }
  
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(1));
  }
  
  public void onActivityDestroyed(Activity paramActivity) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(6));
  }
  
  public void onActivityPaused(Activity paramActivity) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(4));
  }
  
  public void onActivityResumed(Activity paramActivity) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(3));
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
  
  public void onActivityStarted(Activity paramActivity) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(2));
  }
  
  public void onActivityStopped(Activity paramActivity) {
    sActivityStateMap.put(paramActivity, Integer.valueOf(5));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\interna\\util\common\ANActivityLifecycleCallbacksListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */