package com.facebook.ads.internal.util.common;

import android.os.Looper;
import androidx.annotation.Keep;

@Keep
public final class Preconditions {
  public static void checkIsOnMainThread() {
    if (Looper.myLooper() == Looper.getMainLooper())
      return; 
    throw new RuntimeException("Must be called from the UiThread");
  }
  
  public static void checkIsTrue(boolean paramBoolean, String paramString) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(paramString);
  }
  
  public static <T> T checkNotNull(T paramT, String paramString) {
    if (paramT != null)
      return paramT; 
    throw new IllegalArgumentException(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\interna\\util\common\Preconditions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */