package com.facebook.ads.internal.context;

import androidx.annotation.Keep;

@Keep
public interface Repairable {
  void repair(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\internal\context\Repairable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */