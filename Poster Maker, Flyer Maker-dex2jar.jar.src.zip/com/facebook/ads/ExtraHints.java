package com.facebook.ads;

import android.text.TextUtils;
import androidx.annotation.Keep;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@Deprecated
@Keep
public class ExtraHints {
  private static final String HINTS_JSON_KEY = "hints";
  
  private static final int KEYWORDS_MAX_COUNT = 5;
  
  private static final String KEYWORD_SEPARATOR = ";";
  
  private final String mHintsSerialized;
  
  private final String mMediationData;
  
  private ExtraHints(HashMap<HintType, String> paramHashMap, String paramString) {
    this.mMediationData = paramString;
    JSONObject jSONObject1 = new JSONObject();
    JSONObject jSONObject2 = new JSONObject();
    Iterator<Map.Entry> iterator = paramHashMap.entrySet().iterator();
    while (true) {
      if (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        try {
          jSONObject2.put(((HintType)entry.getKey()).mKey, entry.getValue());
        } catch (JSONException jSONException) {}
        continue;
      } 
      try {
        jSONObject1.put("hints", jSONObject2);
      } catch (JSONException jSONException) {}
      this.mHintsSerialized = jSONObject1.toString();
      return;
    } 
  }
  
  private static String join(List<String> paramList) {
    StringBuilder stringBuilder = new StringBuilder();
    Iterator<String> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      stringBuilder.append(";");
    } 
    return stringBuilder.toString();
  }
  
  public String getHints() {
    return this.mHintsSerialized;
  }
  
  public String getMediationData() {
    return this.mMediationData;
  }
  
  @Deprecated
  @Keep
  public static class Builder {
    private HashMap<ExtraHints.HintType, String> mHints = new HashMap<ExtraHints.HintType, String>();
    
    private String mMediationData;
    
    public ExtraHints build() {
      return new ExtraHints(this.mHints, this.mMediationData);
    }
    
    public Builder contentUrl(String param1String) {
      if (param1String == null)
        return this; 
      this.mHints.put(ExtraHints.HintType.CONTENT_URL, param1String);
      return this;
    }
    
    public Builder extraData(String param1String) {
      if (param1String == null)
        return this; 
      this.mHints.put(ExtraHints.HintType.EXTRA_DATA, param1String);
      return this;
    }
    
    @Deprecated
    public Builder keywords(List<ExtraHints.Keyword> param1List) {
      return this;
    }
    
    public Builder mediationData(String param1String) {
      if (TextUtils.isEmpty(param1String))
        return this; 
      this.mMediationData = param1String;
      return this;
    }
  }
  
  public enum HintType {
    CONTENT_URL, EXTRA_DATA, KEYWORDS;
    
    private String mKey;
    
    static {
      HintType hintType1 = new HintType("KEYWORDS", 0, "keywords");
      KEYWORDS = hintType1;
      HintType hintType2 = new HintType("CONTENT_URL", 1, "content_url");
      CONTENT_URL = hintType2;
      HintType hintType3 = new HintType("EXTRA_DATA", 2, "extra_data");
      EXTRA_DATA = hintType3;
      $VALUES = new HintType[] { hintType1, hintType2, hintType3 };
    }
    
    HintType(String param1String1) {
      this.mKey = param1String1;
    }
  }
  
  @Deprecated
  @Keep
  public enum Keyword {
    ACCESSORIES, ART_HISTORY, AUTOMOTIVE, BEAUTY, BIOLOGY, BOARD_GAMES, BUSINESS_SOFTWARE, BUYING_SELLING_HOMES, CATS, CELEBRITIES, CLOTHING, COMIC_BOOKS, DESKTOP_VIDEO, DOGS, EDUCATION, EMAIL, ENTERTAINMENT, FAMILY_PARENTING, FASHION, FINE_ART, FOOD_DRINK, FRENCH_CUISINE, GOVERNMENT, HEALTH_FITNESS, HOBBIES, HOME_GARDEN, HUMOR, INTERNET_TECHNOLOGY, LARGE_ANIMALS, LAW, LEGAL_ISSUES, LITERATURE, MARKETING, MOVIES, MUSIC, NEWS, PERSONAL_FINANCE, PETS, PHOTOGRAPHY, POLITICS, REAL_ESTATE, ROLEPLAYING_GAMES, SCIENCE, SHOPPING, SOCIETY, SPORTS, TECHNOLOGY, TELEVISION, TRAVEL, VIDEO_COMPUTER_GAMES;
    
    private String mKeyword;
    
    static {
      Keyword keyword1 = new Keyword("ACCESSORIES", 0, "accessories");
      ACCESSORIES = keyword1;
      Keyword keyword2 = new Keyword("ART_HISTORY", 1, "art_history");
      ART_HISTORY = keyword2;
      Keyword keyword3 = new Keyword("AUTOMOTIVE", 2, "automotive");
      AUTOMOTIVE = keyword3;
      Keyword keyword4 = new Keyword("BEAUTY", 3, "beauty");
      BEAUTY = keyword4;
      Keyword keyword5 = new Keyword("BIOLOGY", 4, "biology");
      BIOLOGY = keyword5;
      Keyword keyword6 = new Keyword("BOARD_GAMES", 5, "board_games");
      BOARD_GAMES = keyword6;
      Keyword keyword7 = new Keyword("BUSINESS_SOFTWARE", 6, "business_software");
      BUSINESS_SOFTWARE = keyword7;
      Keyword keyword8 = new Keyword("BUYING_SELLING_HOMES", 7, "buying_selling_homes");
      BUYING_SELLING_HOMES = keyword8;
      Keyword keyword9 = new Keyword("CATS", 8, "cats");
      CATS = keyword9;
      Keyword keyword10 = new Keyword("CELEBRITIES", 9, "celebrities");
      CELEBRITIES = keyword10;
      Keyword keyword11 = new Keyword("CLOTHING", 10, "clothing");
      CLOTHING = keyword11;
      Keyword keyword12 = new Keyword("COMIC_BOOKS", 11, "comic_books");
      COMIC_BOOKS = keyword12;
      Keyword keyword13 = new Keyword("DESKTOP_VIDEO", 12, "desktop_video");
      DESKTOP_VIDEO = keyword13;
      Keyword keyword14 = new Keyword("DOGS", 13, "dogs");
      DOGS = keyword14;
      Keyword keyword15 = new Keyword("EDUCATION", 14, "education");
      EDUCATION = keyword15;
      Keyword keyword16 = new Keyword("EMAIL", 15, "email");
      EMAIL = keyword16;
      Keyword keyword17 = new Keyword("ENTERTAINMENT", 16, "entertainment");
      ENTERTAINMENT = keyword17;
      Keyword keyword18 = new Keyword("FAMILY_PARENTING", 17, "family_parenting");
      FAMILY_PARENTING = keyword18;
      Keyword keyword19 = new Keyword("FASHION", 18, "fashion");
      FASHION = keyword19;
      Keyword keyword20 = new Keyword("FINE_ART", 19, "fine_art");
      FINE_ART = keyword20;
      Keyword keyword21 = new Keyword("FOOD_DRINK", 20, "food_drink");
      FOOD_DRINK = keyword21;
      Keyword keyword22 = new Keyword("FRENCH_CUISINE", 21, "french_cuisine");
      FRENCH_CUISINE = keyword22;
      Keyword keyword23 = new Keyword("GOVERNMENT", 22, "government");
      GOVERNMENT = keyword23;
      Keyword keyword24 = new Keyword("HEALTH_FITNESS", 23, "health_fitness");
      HEALTH_FITNESS = keyword24;
      Keyword keyword25 = new Keyword("HOBBIES", 24, "hobbies");
      HOBBIES = keyword25;
      Keyword keyword26 = new Keyword("HOME_GARDEN", 25, "home_garden");
      HOME_GARDEN = keyword26;
      Keyword keyword27 = new Keyword("HUMOR", 26, "humor");
      HUMOR = keyword27;
      Keyword keyword28 = new Keyword("INTERNET_TECHNOLOGY", 27, "internet_technology");
      INTERNET_TECHNOLOGY = keyword28;
      Keyword keyword29 = new Keyword("LARGE_ANIMALS", 28, "large_animals");
      LARGE_ANIMALS = keyword29;
      Keyword keyword30 = new Keyword("LAW", 29, "law");
      LAW = keyword30;
      Keyword keyword31 = new Keyword("LEGAL_ISSUES", 30, "legal_issues");
      LEGAL_ISSUES = keyword31;
      Keyword keyword32 = new Keyword("LITERATURE", 31, "literature");
      LITERATURE = keyword32;
      Keyword keyword33 = new Keyword("MARKETING", 32, "marketing");
      MARKETING = keyword33;
      Keyword keyword34 = new Keyword("MOVIES", 33, "movies");
      MOVIES = keyword34;
      Keyword keyword35 = new Keyword("MUSIC", 34, "music");
      MUSIC = keyword35;
      Keyword keyword36 = new Keyword("NEWS", 35, "news");
      NEWS = keyword36;
      Keyword keyword37 = new Keyword("PERSONAL_FINANCE", 36, "personal_finance");
      PERSONAL_FINANCE = keyword37;
      Keyword keyword38 = new Keyword("PETS", 37, "pets");
      PETS = keyword38;
      Keyword keyword39 = new Keyword("PHOTOGRAPHY", 38, "photography");
      PHOTOGRAPHY = keyword39;
      Keyword keyword40 = new Keyword("POLITICS", 39, "politics");
      POLITICS = keyword40;
      Keyword keyword41 = new Keyword("REAL_ESTATE", 40, "real_estate");
      REAL_ESTATE = keyword41;
      Keyword keyword42 = new Keyword("ROLEPLAYING_GAMES", 41, "roleplaying_games");
      ROLEPLAYING_GAMES = keyword42;
      Keyword keyword43 = new Keyword("SCIENCE", 42, "science");
      SCIENCE = keyword43;
      Keyword keyword44 = new Keyword("SHOPPING", 43, "shopping");
      SHOPPING = keyword44;
      Keyword keyword45 = new Keyword("SOCIETY", 44, "society");
      SOCIETY = keyword45;
      Keyword keyword46 = new Keyword("SPORTS", 45, "sports");
      SPORTS = keyword46;
      Keyword keyword47 = new Keyword("TECHNOLOGY", 46, "technology");
      TECHNOLOGY = keyword47;
      Keyword keyword48 = new Keyword("TELEVISION", 47, "television");
      TELEVISION = keyword48;
      Keyword keyword49 = new Keyword("TRAVEL", 48, "travel");
      TRAVEL = keyword49;
      Keyword keyword50 = new Keyword("VIDEO_COMPUTER_GAMES", 49, "video_computer_games");
      VIDEO_COMPUTER_GAMES = keyword50;
      $VALUES = new Keyword[] { 
          keyword1, keyword2, keyword3, keyword4, keyword5, keyword6, keyword7, keyword8, keyword9, keyword10, 
          keyword11, keyword12, keyword13, keyword14, keyword15, keyword16, keyword17, keyword18, keyword19, keyword20, 
          keyword21, keyword22, keyword23, keyword24, keyword25, keyword26, keyword27, keyword28, keyword29, keyword30, 
          keyword31, keyword32, keyword33, keyword34, keyword35, keyword36, keyword37, keyword38, keyword39, keyword40, 
          keyword41, keyword42, keyword43, keyword44, keyword45, keyword46, keyword47, keyword48, keyword49, keyword50 };
    }
    
    Keyword(String param1String1) {
      this.mKeyword = param1String1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\ExtraHints.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */