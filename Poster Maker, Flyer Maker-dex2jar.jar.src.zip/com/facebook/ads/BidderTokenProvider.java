package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

@Keep
public final class BidderTokenProvider {
  public static String getBidderToken(Context paramContext) {
    Preconditions.checkNotNull(paramContext, "Context can not be null.");
    return DynamicLoaderFactory.makeLoader(paramContext).createBidderTokenProviderApi().getBidderToken(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\BidderTokenProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */