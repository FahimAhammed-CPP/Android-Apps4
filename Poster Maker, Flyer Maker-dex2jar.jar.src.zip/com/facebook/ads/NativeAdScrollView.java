package com.facebook.ads;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdScrollViewApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class NativeAdScrollView extends LinearLayout {
  public static final int DEFAULT_INSET = 20;
  
  public static final int DEFAULT_MAX_ADS = 10;
  
  private final NativeAdScrollViewApi mNativeAdScrollViewApi;
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, int paramInt) {
    this(paramContext, paramNativeAdsManager, null, paramInt, null, null, 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, int paramInt, NativeAdViewAttributes paramNativeAdViewAttributes) {
    this(paramContext, paramNativeAdsManager, null, paramInt, null, paramNativeAdViewAttributes, 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, int paramInt1, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt2) {
    this(paramContext, paramNativeAdsManager, null, paramInt1, null, paramNativeAdViewAttributes, paramInt2);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider) {
    this(paramContext, paramNativeAdsManager, paramAdViewProvider, 0, null, null, 10);
  }
  
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider, int paramInt) {
    this(paramContext, paramNativeAdsManager, paramAdViewProvider, 0, null, null, paramInt);
  }
  
  private NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, AdViewProvider paramAdViewProvider, int paramInt1, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt2) {
    super(paramContext);
    this.mNativeAdScrollViewApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdScrollViewApi(this, paramContext, paramNativeAdsManager, paramAdViewProvider, paramInt1, paramType, paramNativeAdViewAttributes, paramInt2);
  }
  
  @Deprecated
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType) {
    this(paramContext, paramNativeAdsManager, null, 0, paramType, null, 10);
  }
  
  @Deprecated
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    this(paramContext, paramNativeAdsManager, null, 0, paramType, paramNativeAdViewAttributes, 10);
  }
  
  @Deprecated
  public NativeAdScrollView(Context paramContext, NativeAdsManager paramNativeAdsManager, NativeAdView.Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes, int paramInt) {
    this(paramContext, paramNativeAdsManager, null, 0, paramType, paramNativeAdViewAttributes, paramInt);
  }
  
  public void setInset(int paramInt) {
    this.mNativeAdScrollViewApi.setInset(paramInt);
  }
  
  @Keep
  public static interface AdViewProvider {
    View createView(NativeAd param1NativeAd, int param1Int);
    
    void destroyView(NativeAd param1NativeAd, View param1View);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAdScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */