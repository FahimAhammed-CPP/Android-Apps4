package com.facebook.ads;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdComponentViewApi;
import com.facebook.ads.internal.api.AdComponentViewApiProvider;
import com.facebook.ads.internal.api.AdNativeComponentView;
import com.facebook.ads.internal.api.AdViewConstructorParams;
import com.facebook.ads.internal.api.MediaViewApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class MediaView extends AdNativeComponentView {
  private AdViewConstructorParams mConstructorParams;
  
  private MediaViewApi mMediaViewApi;
  
  public MediaView(Context paramContext) {
    super(paramContext);
    initializeSelf(new AdViewConstructorParams(paramContext));
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initializeSelf(new AdViewConstructorParams(paramContext, paramAttributeSet));
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initializeSelf(new AdViewConstructorParams(paramContext, paramAttributeSet, paramInt));
  }
  
  @TargetApi(21)
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    initializeSelf(new AdViewConstructorParams(paramContext, paramAttributeSet, paramInt1, paramInt2));
  }
  
  private void initializeSelf(AdViewConstructorParams paramAdViewConstructorParams) {
    this.mConstructorParams = paramAdViewConstructorParams;
    MediaViewApi mediaViewApi = DynamicLoaderFactory.makeLoader(paramAdViewConstructorParams.getContext()).createMediaViewApi();
    this.mMediaViewApi = mediaViewApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)mediaViewApi);
    this.mMediaViewApi.initialize(paramAdViewConstructorParams, this);
  }
  
  public void destroy() {
    this.mMediaViewApi.destroy();
  }
  
  public View getAdContentsView() {
    return this.mMediaViewApi.getAdContentsView();
  }
  
  public int getMediaHeight() {
    return this.mMediaViewApi.getMediaHeight();
  }
  
  public MediaViewApi getMediaViewApi() {
    return this.mMediaViewApi;
  }
  
  public int getMediaWidth() {
    return this.mMediaViewApi.getMediaWidth();
  }
  
  public void repair(Throwable paramThrowable) {
    post(new Runnable() {
          public void run() {
            MediaView.this.removeAllViews();
            MediaView.access$002(MediaView.this, null);
            MediaView mediaView = MediaView.this;
            MediaView.access$102(mediaView, DynamicLoaderFactory.makeLoader(mediaView.mConstructorParams.getContext()).createMediaViewApi());
            mediaView = MediaView.this;
            mediaView.attachAdComponentViewApi((AdComponentViewApiProvider)mediaView.mMediaViewApi);
            MediaView.this.mMediaViewApi.initialize(MediaView.this.mConstructorParams, MediaView.this);
          }
        });
  }
  
  public void setListener(MediaViewListener paramMediaViewListener) {
    this.mMediaViewApi.setListener(paramMediaViewListener);
  }
  
  public void setVideoRenderer(MediaViewVideoRenderer paramMediaViewVideoRenderer) {
    this.mMediaViewApi.setVideoRenderer(paramMediaViewVideoRenderer);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\MediaView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */