package com.facebook.ads;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.DefaultMediaViewVideoRendererApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public final class MediaViewVideoRendererWithBackgroundPlayback extends MediaViewVideoRenderer {
  private DefaultMediaViewVideoRendererApi mDefaultMediaViewVideoRendererApi;
  
  public MediaViewVideoRendererWithBackgroundPlayback(Context paramContext) {
    super(paramContext);
    initialize(paramContext);
  }
  
  public MediaViewVideoRendererWithBackgroundPlayback(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initialize(paramContext);
  }
  
  public MediaViewVideoRendererWithBackgroundPlayback(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initialize(paramContext);
  }
  
  @TargetApi(21)
  public MediaViewVideoRendererWithBackgroundPlayback(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    initialize(paramContext);
  }
  
  private void initialize(Context paramContext) {
    DefaultMediaViewVideoRendererApi defaultMediaViewVideoRendererApi = DynamicLoaderFactory.makeLoader(paramContext).createDefaultMediaViewVideoRendererApi();
    this.mDefaultMediaViewVideoRendererApi = defaultMediaViewVideoRendererApi;
    defaultMediaViewVideoRendererApi.initialize(paramContext, this, getMediaViewVideoRendererApi(), 1);
  }
  
  public void onPrepared() {
    super.onPrepared();
    this.mDefaultMediaViewVideoRendererApi.onPrepared();
  }
  
  public boolean shouldAllowBackgroundPlayback() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\MediaViewVideoRendererWithBackgroundPlayback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */