package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdCompanionView;
import com.facebook.ads.internal.api.RewardedVideoAdApi;
import com.facebook.ads.internal.bench.Benchmark;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

@Keep
public class RewardedVideoAd implements FullScreenAd {
  public static final int UNSET_VIDEO_DURATION = -1;
  
  private final RewardedVideoAdApi mRewardedVideoAdApi;
  
  @Benchmark
  public RewardedVideoAd(Context paramContext, String paramString) {
    this.mRewardedVideoAdApi = DynamicLoaderFactory.makeLoader(paramContext).createRewardedVideoAd(paramContext, paramString, this);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public RewardedVideoAdLoadConfigBuilder buildLoadAdConfig() {
    return this.mRewardedVideoAdApi.buildLoadAdConfig();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public RewardedVideoAdShowConfigBuilder buildShowAdConfig() {
    return this.mRewardedVideoAdApi.buildShowAdConfig();
  }
  
  public void destroy() {
    this.mRewardedVideoAdApi.destroy();
  }
  
  public String getPlacementId() {
    return this.mRewardedVideoAdApi.getPlacementId();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public int getVideoDuration() {
    return this.mRewardedVideoAdApi.getVideoDuration();
  }
  
  public boolean isAdInvalidated() {
    return this.mRewardedVideoAdApi.isAdInvalidated();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean isAdLoaded() {
    return this.mRewardedVideoAdApi.isAdLoaded();
  }
  
  public void loadAd() {
    this.mRewardedVideoAdApi.loadAd();
  }
  
  @Benchmark
  public void loadAd(RewardedVideoLoadAdConfig paramRewardedVideoLoadAdConfig) {
    this.mRewardedVideoAdApi.loadAd(paramRewardedVideoLoadAdConfig);
  }
  
  public void registerAdCompanionView(AdCompanionView paramAdCompanionView) {
    Preconditions.checkIsOnMainThread();
    this.mRewardedVideoAdApi.registerAdCompanionView(paramAdCompanionView);
  }
  
  @Deprecated
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mRewardedVideoAdApi.setExtraHints(paramExtraHints);
  }
  
  public boolean show() {
    return this.mRewardedVideoAdApi.show();
  }
  
  @Benchmark
  public boolean show(RewardedVideoShowAdConfig paramRewardedVideoShowAdConfig) {
    return this.mRewardedVideoAdApi.show(paramRewardedVideoShowAdConfig);
  }
  
  public void unregisterAdCompanionView() {
    Preconditions.checkIsOnMainThread();
    this.mRewardedVideoAdApi.unregisterAdCompanionView();
  }
  
  @Keep
  public static interface RewardedVideoAdLoadConfigBuilder extends Ad.LoadConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAd.RewardedVideoLoadAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withAdCompanionView(boolean param1Boolean);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withAdExperience(AdExperienceType param1AdExperienceType);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withAdListener(RewardedVideoAdListener param1RewardedVideoAdListener);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withBid(String param1String);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withFailOnCacheFailureEnabled(boolean param1Boolean);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdLoadConfigBuilder withRewardData(RewardData param1RewardData);
  }
  
  @Keep
  public static interface RewardedVideoAdShowConfigBuilder extends FullScreenAd.ShowConfigBuilder {
    RewardedVideoAd.RewardedVideoShowAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedVideoAdShowConfigBuilder withAppOrientation(int param1Int);
  }
  
  @Keep
  public static interface RewardedVideoLoadAdConfig extends Ad.LoadAdConfig {}
  
  @Keep
  public static interface RewardedVideoShowAdConfig extends FullScreenAd.ShowAdConfig {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\RewardedVideoAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */