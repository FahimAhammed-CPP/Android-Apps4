package com.facebook.ads;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdApi;
import com.facebook.ads.internal.api.NativeAdBaseApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;
import java.util.List;

@Keep
public class NativeAd extends NativeAdBase {
  private NativeAdApi mNativeAdApi;
  
  public NativeAd(Context paramContext, NativeAdBase paramNativeAdBase) {
    super(paramContext, paramNativeAdBase);
    this.mNativeAdApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdApi(paramNativeAdBase, this, this.mNativeAdBaseApi);
  }
  
  public NativeAd(Context paramContext, NativeAdBaseApi paramNativeAdBaseApi) {
    super(paramNativeAdBaseApi);
    this.mNativeAdApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdApi(this, this.mNativeAdBaseApi);
  }
  
  public NativeAd(Context paramContext, String paramString) {
    super(paramContext, paramString);
    this.mNativeAdApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdApi(this, this.mNativeAdBaseApi);
  }
  
  public AdCreativeType getAdCreativeType() {
    return this.mNativeAdApi.getAdCreativeType();
  }
  
  public NativeAdApi getNativeAdApi() {
    return this.mNativeAdApi;
  }
  
  @Deprecated
  public VideoAutoplayBehavior getVideoAutoplayBehavior() {
    return this.mNativeAdApi.getVideoAutoplayBehavior();
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView, ImageView paramImageView) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView, paramImageView);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView, ImageView paramImageView, List<View> paramList) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView, paramImageView, paramList);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView1, MediaView paramMediaView2) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView1, paramMediaView2);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView1, MediaView paramMediaView2, List<View> paramList) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView1, paramMediaView2, paramList);
  }
  
  public void registerViewForInteraction(View paramView, MediaView paramMediaView, List<View> paramList) {
    Preconditions.checkIsOnMainThread();
    this.mNativeAdApi.registerViewForInteraction(paramView, paramMediaView, paramList);
  }
  
  @Keep
  public enum AdCreativeType {
    CAROUSEL, IMAGE, UNKNOWN, VIDEO;
    
    static {
      AdCreativeType adCreativeType1 = new AdCreativeType("IMAGE", 0);
      IMAGE = adCreativeType1;
      AdCreativeType adCreativeType2 = new AdCreativeType("VIDEO", 1);
      VIDEO = adCreativeType2;
      AdCreativeType adCreativeType3 = new AdCreativeType("CAROUSEL", 2);
      CAROUSEL = adCreativeType3;
      AdCreativeType adCreativeType4 = new AdCreativeType("UNKNOWN", 3);
      UNKNOWN = adCreativeType4;
      $VALUES = new AdCreativeType[] { adCreativeType1, adCreativeType2, adCreativeType3, adCreativeType4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */