package com.facebook.ads;

import android.content.Context;
import android.view.View;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdViewTypeApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

@Keep
public class NativeBannerAdView {
  public static View render(Context paramContext, NativeBannerAd paramNativeBannerAd, Type paramType) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeBannerAd, "nativeBannerAd must be not null");
    Preconditions.checkNotNull(paramType, "type must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeBannerAdViewApi().render(paramContext, paramNativeBannerAd, paramType, null);
  }
  
  public static View render(Context paramContext, NativeBannerAd paramNativeBannerAd, Type paramType, NativeAdViewAttributes paramNativeAdViewAttributes) {
    Preconditions.checkNotNull(paramContext, "context must be not null");
    Preconditions.checkNotNull(paramNativeBannerAd, "nativeBannerAd must be not null");
    Preconditions.checkNotNull(paramType, "type must be not null");
    return DynamicLoaderFactory.makeLoader(paramContext).createNativeBannerAdViewApi().render(paramContext, paramNativeBannerAd, paramType, paramNativeAdViewAttributes);
  }
  
  @Keep
  public enum Type {
    HEIGHT_100, HEIGHT_120, HEIGHT_50;
    
    private final int mEnumCode;
    
    private NativeAdViewTypeApi mNativeAdViewTypeApi;
    
    static {
      Type type1 = new Type("HEIGHT_50", 0, 4);
      HEIGHT_50 = type1;
      Type type2 = new Type("HEIGHT_100", 1, 0);
      HEIGHT_100 = type2;
      Type type3 = new Type("HEIGHT_120", 2, 1);
      HEIGHT_120 = type3;
      $VALUES = new Type[] { type1, type2, type3 };
    }
    
    Type(int param1Int1) {
      this.mEnumCode = param1Int1;
    }
    
    private NativeAdViewTypeApi getNativeAdViewTypeApi() {
      if (this.mNativeAdViewTypeApi == null)
        this.mNativeAdViewTypeApi = DynamicLoaderFactory.makeLoaderUnsafe().createNativeAdViewTypeApi(this.mEnumCode); 
      return this.mNativeAdViewTypeApi;
    }
    
    public int getEnumCode() {
      return this.mEnumCode;
    }
    
    public int getHeight() {
      return getNativeAdViewTypeApi().getHeight();
    }
    
    public int getValue() {
      return getNativeAdViewTypeApi().getValue();
    }
    
    public int getWidth() {
      return getNativeAdViewTypeApi().getWidth();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeBannerAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */