package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdComponentFrameLayout;
import com.facebook.ads.internal.api.AdComponentViewApiProvider;
import com.facebook.ads.internal.api.AdOptionsViewApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class AdOptionsView extends AdComponentFrameLayout {
  private final AdOptionsViewApi mAdOptionsViewApi;
  
  public AdOptionsView(Context paramContext, NativeAdBase paramNativeAdBase, NativeAdLayout paramNativeAdLayout) {
    super(paramContext);
    AdOptionsViewApi adOptionsViewApi = DynamicLoaderFactory.makeLoader(paramContext).createAdOptionsView(paramContext, paramNativeAdBase, paramNativeAdLayout, this);
    this.mAdOptionsViewApi = adOptionsViewApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)adOptionsViewApi);
  }
  
  public AdOptionsView(Context paramContext, NativeAdBase paramNativeAdBase, NativeAdLayout paramNativeAdLayout, Orientation paramOrientation, int paramInt) {
    super(paramContext);
    AdOptionsViewApi adOptionsViewApi = DynamicLoaderFactory.makeLoader(paramContext).createAdOptionsView(paramContext, paramNativeAdBase, paramNativeAdLayout, paramOrientation, paramInt, this);
    this.mAdOptionsViewApi = adOptionsViewApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)adOptionsViewApi);
  }
  
  public void setIconColor(int paramInt) {
    this.mAdOptionsViewApi.setIconColor(paramInt);
  }
  
  public void setIconSizeDp(int paramInt) {
    this.mAdOptionsViewApi.setIconSizeDp(paramInt);
  }
  
  public void setSingleIcon(boolean paramBoolean) {
    this.mAdOptionsViewApi.setSingleIcon(paramBoolean);
  }
  
  @Keep
  public enum Orientation {
    HORIZONTAL, VERTICAL;
    
    static {
      Orientation orientation1 = new Orientation("HORIZONTAL", 0);
      HORIZONTAL = orientation1;
      Orientation orientation2 = new Orientation("VERTICAL", 1);
      VERTICAL = orientation2;
      $VALUES = new Orientation[] { orientation1, orientation2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdOptionsView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */