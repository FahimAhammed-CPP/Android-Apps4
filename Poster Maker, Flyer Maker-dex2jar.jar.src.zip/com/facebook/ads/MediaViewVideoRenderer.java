package com.facebook.ads;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdComponentFrameLayout;
import com.facebook.ads.internal.api.AdComponentViewApiProvider;
import com.facebook.ads.internal.api.AdViewConstructorParams;
import com.facebook.ads.internal.api.MediaViewVideoRendererApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public abstract class MediaViewVideoRenderer extends AdComponentFrameLayout {
  private MediaViewVideoRendererApi mMediaViewVideoRendererApi;
  
  @Deprecated
  public NativeAd nativeAd;
  
  @Deprecated
  public VideoAutoplayBehavior videoAutoplayBehavior;
  
  public MediaViewVideoRenderer(Context paramContext) {
    super(paramContext);
    initialize(new AdViewConstructorParams(paramContext));
  }
  
  public MediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initialize(new AdViewConstructorParams(paramContext, paramAttributeSet));
  }
  
  public MediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initialize(new AdViewConstructorParams(paramContext, paramAttributeSet, paramInt));
  }
  
  @TargetApi(21)
  public MediaViewVideoRenderer(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    initialize(new AdViewConstructorParams(paramContext, paramAttributeSet, paramInt1, paramInt2));
  }
  
  private void initialize(AdViewConstructorParams paramAdViewConstructorParams) {
    MediaViewVideoRendererApi mediaViewVideoRendererApi = DynamicLoaderFactory.makeLoader(paramAdViewConstructorParams.getContext()).createMediaViewVideoRendererApi();
    this.mMediaViewVideoRendererApi = mediaViewVideoRendererApi;
    attachAdComponentViewApi((AdComponentViewApiProvider)mediaViewVideoRendererApi);
    this.mMediaViewVideoRendererApi.initialize(paramAdViewConstructorParams, this);
  }
  
  public void addView(View paramView) {}
  
  public void addView(View paramView, int paramInt) {}
  
  public void addView(View paramView, int paramInt1, int paramInt2) {}
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {}
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {}
  
  @Deprecated
  public void destroy() {}
  
  public final void disengageSeek(VideoStartReason paramVideoStartReason) {
    this.mMediaViewVideoRendererApi.disengageSeek(paramVideoStartReason);
  }
  
  public final void engageSeek() {
    this.mMediaViewVideoRendererApi.engageSeek();
  }
  
  public final int getCurrentTimeMs() {
    return this.mMediaViewVideoRendererApi.getCurrentTimeMs();
  }
  
  public final int getDuration() {
    return this.mMediaViewVideoRendererApi.getDuration();
  }
  
  public MediaViewVideoRendererApi getMediaViewVideoRendererApi() {
    return this.mMediaViewVideoRendererApi;
  }
  
  @Deprecated
  public final View getVideoView() {
    return this.mMediaViewVideoRendererApi.getVideoView();
  }
  
  public final float getVolume() {
    return this.mMediaViewVideoRendererApi.getVolume();
  }
  
  public void onCompleted() {}
  
  public void onError() {}
  
  public void onPaused() {}
  
  public void onPlayed() {}
  
  public void onPrepared() {}
  
  public void onSeek() {}
  
  public void onSeekDisengaged() {}
  
  public void onSeekEngaged() {}
  
  public void onVolumeChanged() {}
  
  public final void pause(boolean paramBoolean) {
    this.mMediaViewVideoRendererApi.pause(paramBoolean);
  }
  
  public final void play(VideoStartReason paramVideoStartReason) {
    this.mMediaViewVideoRendererApi.play(paramVideoStartReason);
  }
  
  public final void seekTo(int paramInt) {
    this.mMediaViewVideoRendererApi.seekTo(paramInt);
  }
  
  @Deprecated
  public final void setListener(Object paramObject) {}
  
  @Deprecated
  public void setNativeAd(NativeAd paramNativeAd) {
    this.nativeAd = paramNativeAd;
    this.videoAutoplayBehavior = paramNativeAd.getVideoAutoplayBehavior();
  }
  
  public final void setVolume(float paramFloat) {
    this.mMediaViewVideoRendererApi.setVolume(paramFloat);
  }
  
  public boolean shouldAllowBackgroundPlayback() {
    return false;
  }
  
  public final boolean shouldAutoplay() {
    return this.mMediaViewVideoRendererApi.shouldAutoplay();
  }
  
  @Deprecated
  public void unsetNativeAd() {
    this.nativeAd = null;
    this.videoAutoplayBehavior = VideoAutoplayBehavior.DEFAULT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\MediaViewVideoRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */