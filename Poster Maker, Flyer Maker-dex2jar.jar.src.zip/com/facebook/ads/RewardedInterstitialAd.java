package com.facebook.ads;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.RewardedInterstitialAdApi;
import com.facebook.ads.internal.bench.Benchmark;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;

@Keep
public class RewardedInterstitialAd implements FullScreenAd {
  public static final int UNSET_VIDEO_DURATION = -1;
  
  private final RewardedInterstitialAdApi mRewardedInterstitialAdApi;
  
  @Benchmark
  public RewardedInterstitialAd(Context paramContext, String paramString) {
    this.mRewardedInterstitialAdApi = DynamicLoaderFactory.makeLoader(paramContext).createRewardedInterstitialAd(paramContext, paramString, this);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public RewardedInterstitialAdLoadConfigBuilder buildLoadAdConfig() {
    return this.mRewardedInterstitialAdApi.buildLoadAdConfig();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public RewardedInterstitialAdShowConfigBuilder buildShowAdConfig() {
    return this.mRewardedInterstitialAdApi.buildShowAdConfig();
  }
  
  public void destroy() {
    this.mRewardedInterstitialAdApi.destroy();
  }
  
  public String getPlacementId() {
    return this.mRewardedInterstitialAdApi.getPlacementId();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public int getVideoDuration() {
    return this.mRewardedInterstitialAdApi.getVideoDuration();
  }
  
  public boolean isAdInvalidated() {
    return this.mRewardedInterstitialAdApi.isAdInvalidated();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean isAdLoaded() {
    return this.mRewardedInterstitialAdApi.isAdLoaded();
  }
  
  public void loadAd() {
    this.mRewardedInterstitialAdApi.loadAd();
  }
  
  @Benchmark
  public void loadAd(RewardedInterstitialLoadAdConfig paramRewardedInterstitialLoadAdConfig) {
    this.mRewardedInterstitialAdApi.loadAd(paramRewardedInterstitialLoadAdConfig);
  }
  
  @Deprecated
  @SuppressLint({"DeprecatedMethod"})
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mRewardedInterstitialAdApi.setExtraHints(paramExtraHints);
  }
  
  public boolean show() {
    return this.mRewardedInterstitialAdApi.show();
  }
  
  @Benchmark
  public boolean show(RewardedInterstitialShowAdConfig paramRewardedInterstitialShowAdConfig) {
    return this.mRewardedInterstitialAdApi.show(paramRewardedInterstitialShowAdConfig);
  }
  
  @Keep
  public static interface RewardedInterstitialAdLoadConfigBuilder extends Ad.LoadConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAd.RewardedInterstitialLoadAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAdLoadConfigBuilder withAdListener(RewardedInterstitialAdListener param1RewardedInterstitialAdListener);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAdLoadConfigBuilder withBid(String param1String);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAdLoadConfigBuilder withFailOnCacheFailureEnabled(boolean param1Boolean);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAdLoadConfigBuilder withRewardData(RewardData param1RewardData);
  }
  
  @Keep
  public static interface RewardedInterstitialAdShowConfigBuilder extends FullScreenAd.ShowConfigBuilder {
    RewardedInterstitialAd.RewardedInterstitialShowAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    RewardedInterstitialAdShowConfigBuilder withAppOrientation(int param1Int);
  }
  
  @Keep
  public static interface RewardedInterstitialLoadAdConfig extends Ad.LoadAdConfig {}
  
  @Keep
  public static interface RewardedInterstitialShowAdConfig extends FullScreenAd.ShowAdConfig {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\RewardedInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */