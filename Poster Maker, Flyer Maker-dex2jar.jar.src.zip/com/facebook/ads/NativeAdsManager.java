package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.NativeAdsManagerApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

@Keep
public class NativeAdsManager {
  private final NativeAdsManagerApi mNativeAdsManagerApi;
  
  public NativeAdsManager(Context paramContext, String paramString, int paramInt) {
    boolean bool;
    Preconditions.checkNotNull(paramContext, "Context can not be null");
    if (paramInt > -1) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkIsTrue(bool, "Number of requested ads should be not be negative");
    this.mNativeAdsManagerApi = DynamicLoaderFactory.makeLoader(paramContext).createNativeAdsManagerApi(paramContext, paramString, paramInt);
  }
  
  public void disableAutoRefresh() {
    this.mNativeAdsManagerApi.disableAutoRefresh();
  }
  
  public int getUniqueNativeAdCount() {
    return this.mNativeAdsManagerApi.getUniqueNativeAdCount();
  }
  
  public boolean isLoaded() {
    return this.mNativeAdsManagerApi.isLoaded();
  }
  
  public void loadAds() {
    this.mNativeAdsManagerApi.loadAds();
  }
  
  public void loadAds(NativeAdBase.MediaCacheFlag paramMediaCacheFlag) {
    this.mNativeAdsManagerApi.loadAds(paramMediaCacheFlag);
  }
  
  public NativeAd nextNativeAd() {
    return this.mNativeAdsManagerApi.nextNativeAd();
  }
  
  public NativeAd nextNativeAd(NativeAdListener paramNativeAdListener) {
    return this.mNativeAdsManagerApi.nextNativeAd(paramNativeAdListener);
  }
  
  public void setExtraHints(String paramString) {
    this.mNativeAdsManagerApi.setExtraHints(paramString);
  }
  
  public void setListener(Listener paramListener) {
    this.mNativeAdsManagerApi.setListener(paramListener);
  }
  
  @Keep
  public static interface Listener {
    void onAdError(AdError param1AdError);
    
    void onAdsLoaded();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\NativeAdsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */