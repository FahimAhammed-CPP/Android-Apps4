package com.facebook.ads;

import androidx.annotation.Keep;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Keep
public class AdSDKNotificationManager {
  private static final List<AdSDKNotificationListener> sNotificationListeners = Collections.synchronizedList(new ArrayList<AdSDKNotificationListener>());
  
  public static void addSDKNotificationListener(AdSDKNotificationListener paramAdSDKNotificationListener) {
    synchronized (sNotificationListeners) {
      null.add(paramAdSDKNotificationListener);
      return;
    } 
  }
  
  public static List<AdSDKNotificationListener> getNotificationListeners() {
    return sNotificationListeners;
  }
  
  public static void removeSDKNotificationListener(AdSDKNotificationListener paramAdSDKNotificationListener) {
    synchronized (sNotificationListeners) {
      null.remove(paramAdSDKNotificationListener);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\AdSDKNotificationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */