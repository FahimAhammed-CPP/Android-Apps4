package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public interface S2SRewardedInterstitialAdExtendedListener extends RewardedInterstitialAdExtendedListener, S2SRewardedInterstitialAdListener {}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\S2SRewardedInterstitialAdExtendedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */