package com.facebook.ads;

import com.facebook.ads.internal.bench.Benchmark;



/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */