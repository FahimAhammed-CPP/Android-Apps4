package com.facebook.ads;

import android.content.Context;
import androidx.annotation.Keep;
import com.facebook.ads.internal.api.AdCompanionView;
import com.facebook.ads.internal.api.InterstitialAdApi;
import com.facebook.ads.internal.bench.Benchmark;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;
import java.util.EnumSet;

@Keep
public class InterstitialAd implements FullScreenAd {
  private final InterstitialAdApi mInterstitialAdApi;
  
  @Benchmark
  public InterstitialAd(Context paramContext, String paramString) {
    this.mInterstitialAdApi = DynamicLoaderFactory.makeLoader(paramContext).createInterstitialAd(paramContext, paramString, this);
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public InterstitialAdLoadConfigBuilder buildLoadAdConfig() {
    return this.mInterstitialAdApi.buildLoadAdConfig();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public InterstitialAdShowConfigBuilder buildShowAdConfig() {
    return this.mInterstitialAdApi.buildShowAdConfig();
  }
  
  public void destroy() {
    this.mInterstitialAdApi.destroy();
  }
  
  public String getPlacementId() {
    return this.mInterstitialAdApi.getPlacementId();
  }
  
  public boolean isAdInvalidated() {
    return this.mInterstitialAdApi.isAdInvalidated();
  }
  
  @Benchmark(failAtMillis = 5, warnAtMillis = 1)
  public boolean isAdLoaded() {
    return this.mInterstitialAdApi.isAdLoaded();
  }
  
  public void loadAd() {
    this.mInterstitialAdApi.loadAd();
  }
  
  public void loadAd(InterstitialLoadAdConfig paramInterstitialLoadAdConfig) {
    this.mInterstitialAdApi.loadAd(paramInterstitialLoadAdConfig);
  }
  
  public void registerAdCompanionView(AdCompanionView paramAdCompanionView) {
    Preconditions.checkIsOnMainThread();
    this.mInterstitialAdApi.registerAdCompanionView(paramAdCompanionView);
  }
  
  @Deprecated
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mInterstitialAdApi.setExtraHints(paramExtraHints);
  }
  
  @Benchmark
  public boolean show() {
    return this.mInterstitialAdApi.show();
  }
  
  @Benchmark
  public boolean show(InterstitialShowAdConfig paramInterstitialShowAdConfig) {
    return this.mInterstitialAdApi.show(paramInterstitialShowAdConfig);
  }
  
  public void unregisterAdCompanionView() {
    Preconditions.checkIsOnMainThread();
    this.mInterstitialAdApi.unregisterAdCompanionView();
  }
  
  @Keep
  public static interface InterstitialAdLoadConfigBuilder extends Ad.LoadConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAd.InterstitialLoadAdConfig build();
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAdLoadConfigBuilder withAdCompanionView(boolean param1Boolean);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAdLoadConfigBuilder withAdListener(InterstitialAdListener param1InterstitialAdListener);
    
    InterstitialAdLoadConfigBuilder withBid(String param1String);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAdLoadConfigBuilder withCacheFlags(EnumSet<CacheFlag> param1EnumSet);
    
    InterstitialAdLoadConfigBuilder withRewardData(RewardData param1RewardData);
    
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAdLoadConfigBuilder withRewardedAdListener(RewardedAdListener param1RewardedAdListener);
  }
  
  @Keep
  public static interface InterstitialAdShowConfigBuilder extends FullScreenAd.ShowConfigBuilder {
    @Benchmark(failAtMillis = 5, warnAtMillis = 1)
    InterstitialAd.InterstitialShowAdConfig build();
  }
  
  @Keep
  public static interface InterstitialLoadAdConfig extends Ad.LoadAdConfig {}
  
  @Keep
  public static interface InterstitialShowAdConfig extends FullScreenAd.ShowAdConfig {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\InterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */