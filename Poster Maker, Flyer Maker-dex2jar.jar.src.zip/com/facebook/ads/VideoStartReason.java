package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public enum VideoStartReason {
  AUTO_STARTED, NOT_STARTED, USER_STARTED;
  
  static {
    VideoStartReason videoStartReason1 = new VideoStartReason("NOT_STARTED", 0);
    NOT_STARTED = videoStartReason1;
    VideoStartReason videoStartReason2 = new VideoStartReason("USER_STARTED", 1);
    USER_STARTED = videoStartReason2;
    VideoStartReason videoStartReason3 = new VideoStartReason("AUTO_STARTED", 2);
    AUTO_STARTED = videoStartReason3;
    $VALUES = new VideoStartReason[] { videoStartReason1, videoStartReason2, videoStartReason3 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\ads\VideoStartReason.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */