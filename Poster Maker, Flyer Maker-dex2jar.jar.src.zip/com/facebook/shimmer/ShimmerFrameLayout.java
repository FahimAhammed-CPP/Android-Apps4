package com.facebook.shimmer;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class ShimmerFrameLayout extends FrameLayout {
  private final Paint mContentPaint = new Paint();
  
  private final ShimmerDrawable mShimmerDrawable = new ShimmerDrawable();
  
  private boolean mShowShimmer = true;
  
  public ShimmerFrameLayout(Context paramContext) {
    super(paramContext);
    init(paramContext, null);
  }
  
  public ShimmerFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramContext, paramAttributeSet);
  }
  
  public ShimmerFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext, paramAttributeSet);
  }
  
  @TargetApi(21)
  public ShimmerFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramContext, paramAttributeSet);
  }
  
  private void init(Context paramContext, AttributeSet paramAttributeSet) {
    setWillNotDraw(false);
    this.mShimmerDrawable.setCallback((Drawable.Callback)this);
    if (paramAttributeSet == null) {
      setShimmer((new Shimmer.AlphaHighlightBuilder()).build());
      return;
    } 
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ShimmerFrameLayout, 0, 0);
    try {
      Shimmer.AlphaHighlightBuilder alphaHighlightBuilder;
      int i = R.styleable.ShimmerFrameLayout_shimmer_colored;
      if (typedArray.hasValue(i) && typedArray.getBoolean(i, false)) {
        Shimmer.ColorHighlightBuilder colorHighlightBuilder = new Shimmer.ColorHighlightBuilder();
      } else {
        alphaHighlightBuilder = new Shimmer.AlphaHighlightBuilder();
      } 
      setShimmer(alphaHighlightBuilder.consumeAttributes(typedArray).build());
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    super.dispatchDraw(paramCanvas);
    if (this.mShowShimmer)
      this.mShimmerDrawable.draw(paramCanvas); 
  }
  
  public void hideShimmer() {
    if (!this.mShowShimmer)
      return; 
    stopShimmer();
    this.mShowShimmer = false;
    invalidate();
  }
  
  public boolean isShimmerStarted() {
    return this.mShimmerDrawable.isShimmerStarted();
  }
  
  public boolean isShimmerVisible() {
    return this.mShowShimmer;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mShimmerDrawable.maybeStartShimmer();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    stopShimmer();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = getWidth();
    paramInt2 = getHeight();
    this.mShimmerDrawable.setBounds(0, 0, paramInt1, paramInt2);
  }
  
  public ShimmerFrameLayout setShimmer(Shimmer paramShimmer) {
    this.mShimmerDrawable.setShimmer(paramShimmer);
    if (paramShimmer != null && paramShimmer.clipToChildren) {
      setLayerType(2, this.mContentPaint);
      return this;
    } 
    setLayerType(0, null);
    return this;
  }
  
  public void showShimmer(boolean paramBoolean) {
    if (this.mShowShimmer)
      return; 
    this.mShowShimmer = true;
    if (paramBoolean)
      startShimmer(); 
  }
  
  public void startShimmer() {
    this.mShimmerDrawable.startShimmer();
  }
  
  public void stopShimmer() {
    this.mShimmerDrawable.stopShimmer();
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mShimmerDrawable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\shimmer\ShimmerFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */