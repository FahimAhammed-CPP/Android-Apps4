package com.facebook.shimmer;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import s30;

public final class ShimmerDrawable extends Drawable {
  private final Rect mDrawRect;
  
  private final Matrix mShaderMatrix;
  
  private Shimmer mShimmer;
  
  private final Paint mShimmerPaint;
  
  private final ValueAnimator.AnimatorUpdateListener mUpdateListener = new ValueAnimator.AnimatorUpdateListener() {
      public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
        ShimmerDrawable.this.invalidateSelf();
      }
    };
  
  private ValueAnimator mValueAnimator;
  
  public ShimmerDrawable() {
    Paint paint = new Paint();
    this.mShimmerPaint = paint;
    this.mDrawRect = new Rect();
    this.mShaderMatrix = new Matrix();
    paint.setAntiAlias(true);
  }
  
  private float offset(float paramFloat1, float paramFloat2, float paramFloat3) {
    return s30.R(paramFloat2, paramFloat1, paramFloat3, paramFloat1);
  }
  
  private void updateShader() {
    Rect rect = getBounds();
    int j = rect.width();
    int i = rect.height();
    if (j != 0 && i != 0) {
      RadialGradient radialGradient;
      Shimmer shimmer = this.mShimmer;
      if (shimmer == null)
        return; 
      j = shimmer.width(j);
      int k = this.mShimmer.height(i);
      shimmer = this.mShimmer;
      i = shimmer.shape;
      boolean bool = true;
      if (i != 1) {
        int m = shimmer.direction;
        i = bool;
        if (m != 1)
          if (m == 3) {
            i = bool;
          } else {
            i = 0;
          }  
        if (i != 0)
          j = 0; 
        if (i != 0) {
          i = k;
        } else {
          i = 0;
        } 
        float f1 = j;
        float f2 = i;
        shimmer = this.mShimmer;
        LinearGradient linearGradient = new LinearGradient(0.0F, 0.0F, f1, f2, shimmer.colors, shimmer.positions, Shader.TileMode.CLAMP);
      } else {
        float f1 = j / 2.0F;
        float f2 = k / 2.0F;
        double d1 = Math.max(j, k);
        double d2 = Math.sqrt(2.0D);
        Double.isNaN(d1);
        float f3 = (float)(d1 / d2);
        shimmer = this.mShimmer;
        radialGradient = new RadialGradient(f1, f2, f3, shimmer.colors, shimmer.positions, Shader.TileMode.CLAMP);
      } 
      this.mShimmerPaint.setShader((Shader)radialGradient);
    } 
  }
  
  private void updateValueAnimator() {
    boolean bool;
    if (this.mShimmer == null)
      return; 
    ValueAnimator valueAnimator2 = this.mValueAnimator;
    if (valueAnimator2 != null) {
      bool = valueAnimator2.isStarted();
      this.mValueAnimator.cancel();
      this.mValueAnimator.removeAllUpdateListeners();
    } else {
      bool = false;
    } 
    Shimmer shimmer1 = this.mShimmer;
    ValueAnimator valueAnimator1 = ValueAnimator.ofFloat(new float[] { 0.0F, (float)(shimmer1.repeatDelay / shimmer1.animationDuration) + 1.0F });
    this.mValueAnimator = valueAnimator1;
    valueAnimator1.setRepeatMode(this.mShimmer.repeatMode);
    this.mValueAnimator.setRepeatCount(this.mShimmer.repeatCount);
    valueAnimator1 = this.mValueAnimator;
    Shimmer shimmer2 = this.mShimmer;
    valueAnimator1.setDuration(shimmer2.animationDuration + shimmer2.repeatDelay);
    this.mValueAnimator.addUpdateListener(this.mUpdateListener);
    if (bool)
      this.mValueAnimator.start(); 
  }
  
  public void draw(Canvas paramCanvas) {
    float f1;
    float f2;
    if (this.mShimmer != null) {
      if (this.mShimmerPaint.getShader() == null)
        return; 
      f1 = (float)Math.tan(Math.toRadians(this.mShimmer.tilt));
      f2 = this.mDrawRect.height();
      float f3 = this.mDrawRect.width() * f1 + f2;
      f2 = this.mDrawRect.width();
      float f4 = f1 * this.mDrawRect.height() + f2;
      ValueAnimator valueAnimator = this.mValueAnimator;
      f2 = 0.0F;
      if (valueAnimator != null) {
        f1 = valueAnimator.getAnimatedFraction();
      } else {
        f1 = 0.0F;
      } 
      int i = this.mShimmer.direction;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            f1 = offset(-f4, f4, f1);
          } else {
            f1 = offset(f3, -f3, f1);
            this.mShaderMatrix.reset();
            this.mShaderMatrix.setRotate(this.mShimmer.tilt, this.mDrawRect.width() / 2.0F, this.mDrawRect.height() / 2.0F);
            this.mShaderMatrix.postTranslate(f2, f1);
            this.mShimmerPaint.getShader().setLocalMatrix(this.mShaderMatrix);
            paramCanvas.drawRect(this.mDrawRect, this.mShimmerPaint);
          } 
        } else {
          f1 = offset(f4, -f4, f1);
        } 
        f2 = f1;
        f1 = 0.0F;
      } else {
        f1 = offset(-f3, f3, f1);
      } 
    } else {
      return;
    } 
    this.mShaderMatrix.reset();
    this.mShaderMatrix.setRotate(this.mShimmer.tilt, this.mDrawRect.width() / 2.0F, this.mDrawRect.height() / 2.0F);
    this.mShaderMatrix.postTranslate(f2, f1);
    this.mShimmerPaint.getShader().setLocalMatrix(this.mShaderMatrix);
    paramCanvas.drawRect(this.mDrawRect, this.mShimmerPaint);
  }
  
  public int getOpacity() {
    Shimmer shimmer = this.mShimmer;
    return (shimmer != null && (shimmer.clipToChildren || shimmer.alphaShimmer)) ? -3 : -1;
  }
  
  public boolean isShimmerStarted() {
    ValueAnimator valueAnimator = this.mValueAnimator;
    return (valueAnimator != null && valueAnimator.isStarted());
  }
  
  public void maybeStartShimmer() {
    ValueAnimator valueAnimator = this.mValueAnimator;
    if (valueAnimator != null && !valueAnimator.isStarted()) {
      Shimmer shimmer = this.mShimmer;
      if (shimmer != null && shimmer.autoStart && getCallback() != null)
        this.mValueAnimator.start(); 
    } 
  }
  
  public void onBoundsChange(Rect paramRect) {
    super.onBoundsChange(paramRect);
    int i = paramRect.width();
    int j = paramRect.height();
    this.mDrawRect.set(0, 0, i, j);
    updateShader();
    maybeStartShimmer();
  }
  
  public void setAlpha(int paramInt) {}
  
  public void setColorFilter(ColorFilter paramColorFilter) {}
  
  public void setShimmer(Shimmer paramShimmer) {
    this.mShimmer = paramShimmer;
    if (paramShimmer != null) {
      PorterDuff.Mode mode;
      Paint paint = this.mShimmerPaint;
      if (this.mShimmer.alphaShimmer) {
        mode = PorterDuff.Mode.DST_IN;
      } else {
        mode = PorterDuff.Mode.SRC_IN;
      } 
      paint.setXfermode((Xfermode)new PorterDuffXfermode(mode));
    } 
    updateShader();
    updateValueAnimator();
    invalidateSelf();
  }
  
  public void startShimmer() {
    if (this.mValueAnimator != null && !isShimmerStarted() && getCallback() != null)
      this.mValueAnimator.start(); 
  }
  
  public void stopShimmer() {
    if (this.mValueAnimator != null && isShimmerStarted())
      this.mValueAnimator.cancel(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\shimmer\ShimmerDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */