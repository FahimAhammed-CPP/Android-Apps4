package com.facebook.shimmer;

public final class R {
  public static final class attr {
    public static final int shimmer_auto_start = 2130969791;
    
    public static final int shimmer_base_alpha = 2130969792;
    
    public static final int shimmer_base_color = 2130969793;
    
    public static final int shimmer_clip_to_children = 2130969794;
    
    public static final int shimmer_colored = 2130969795;
    
    public static final int shimmer_direction = 2130969796;
    
    public static final int shimmer_dropoff = 2130969797;
    
    public static final int shimmer_duration = 2130969798;
    
    public static final int shimmer_fixed_height = 2130969799;
    
    public static final int shimmer_fixed_width = 2130969800;
    
    public static final int shimmer_height_ratio = 2130969801;
    
    public static final int shimmer_highlight_alpha = 2130969802;
    
    public static final int shimmer_highlight_color = 2130969803;
    
    public static final int shimmer_intensity = 2130969804;
    
    public static final int shimmer_repeat_count = 2130969805;
    
    public static final int shimmer_repeat_delay = 2130969806;
    
    public static final int shimmer_repeat_mode = 2130969807;
    
    public static final int shimmer_shape = 2130969808;
    
    public static final int shimmer_tilt = 2130969809;
    
    public static final int shimmer_width_ratio = 2130969810;
  }
  
  public static final class id {
    public static final int bottom_to_top = 2131362286;
    
    public static final int left_to_right = 2131364493;
    
    public static final int linear = 2131364508;
    
    public static final int radial = 2131365143;
    
    public static final int restart = 2131365223;
    
    public static final int reverse = 2131365225;
    
    public static final int right_to_left = 2131365245;
    
    public static final int top_to_bottom = 2131365820;
  }
  
  public static final class styleable {
    public static final int[] ShimmerFrameLayout = new int[] { 
        2130969791, 2130969792, 2130969793, 2130969794, 2130969795, 2130969796, 2130969797, 2130969798, 2130969799, 2130969800, 
        2130969801, 2130969802, 2130969803, 2130969804, 2130969805, 2130969806, 2130969807, 2130969808, 2130969809, 2130969810 };
    
    public static final int ShimmerFrameLayout_shimmer_auto_start = 0;
    
    public static final int ShimmerFrameLayout_shimmer_base_alpha = 1;
    
    public static final int ShimmerFrameLayout_shimmer_base_color = 2;
    
    public static final int ShimmerFrameLayout_shimmer_clip_to_children = 3;
    
    public static final int ShimmerFrameLayout_shimmer_colored = 4;
    
    public static final int ShimmerFrameLayout_shimmer_direction = 5;
    
    public static final int ShimmerFrameLayout_shimmer_dropoff = 6;
    
    public static final int ShimmerFrameLayout_shimmer_duration = 7;
    
    public static final int ShimmerFrameLayout_shimmer_fixed_height = 8;
    
    public static final int ShimmerFrameLayout_shimmer_fixed_width = 9;
    
    public static final int ShimmerFrameLayout_shimmer_height_ratio = 10;
    
    public static final int ShimmerFrameLayout_shimmer_highlight_alpha = 11;
    
    public static final int ShimmerFrameLayout_shimmer_highlight_color = 12;
    
    public static final int ShimmerFrameLayout_shimmer_intensity = 13;
    
    public static final int ShimmerFrameLayout_shimmer_repeat_count = 14;
    
    public static final int ShimmerFrameLayout_shimmer_repeat_delay = 15;
    
    public static final int ShimmerFrameLayout_shimmer_repeat_mode = 16;
    
    public static final int ShimmerFrameLayout_shimmer_shape = 17;
    
    public static final int ShimmerFrameLayout_shimmer_tilt = 18;
    
    public static final int ShimmerFrameLayout_shimmer_width_ratio = 19;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\shimmer\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */