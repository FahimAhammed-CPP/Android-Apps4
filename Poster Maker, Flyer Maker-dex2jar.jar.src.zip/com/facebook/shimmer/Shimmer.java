package com.facebook.shimmer;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import s30;

public class Shimmer {
  private static final int COMPONENT_COUNT = 4;
  
  public boolean alphaShimmer = true;
  
  public long animationDuration = 1000L;
  
  public boolean autoStart = true;
  
  public int baseColor = 1291845631;
  
  public final RectF bounds = new RectF();
  
  public boolean clipToChildren = true;
  
  public final int[] colors = new int[4];
  
  public int direction = 0;
  
  public float dropoff = 0.5F;
  
  public int fixedHeight = 0;
  
  public int fixedWidth = 0;
  
  public float heightRatio = 1.0F;
  
  public int highlightColor = -1;
  
  public float intensity = 0.0F;
  
  public final float[] positions = new float[4];
  
  public int repeatCount = -1;
  
  public long repeatDelay;
  
  public int repeatMode = 1;
  
  public int shape = 0;
  
  public float tilt = 20.0F;
  
  public float widthRatio = 1.0F;
  
  public int height(int paramInt) {
    int i = this.fixedHeight;
    return (i > 0) ? i : Math.round(this.heightRatio * paramInt);
  }
  
  public void updateBounds(int paramInt1, int paramInt2) {
    int i = Math.max(paramInt1, paramInt2);
    double d2 = Math.toRadians((this.tilt % 90.0F));
    double d1 = i;
    d2 = Math.sin(1.5707963267948966D - d2);
    Double.isNaN(d1);
    d2 = d1 / d2;
    Double.isNaN(d1);
    i = Math.round((float)(d2 - d1) / 2.0F) * 3;
    RectF rectF = this.bounds;
    float f = -i;
    rectF.set(f, f, (width(paramInt1) + i), (height(paramInt2) + i));
  }
  
  public void updateColors() {
    if (this.shape != 1) {
      int[] arrayOfInt1 = this.colors;
      int j = this.baseColor;
      arrayOfInt1[0] = j;
      int k = this.highlightColor;
      arrayOfInt1[1] = k;
      arrayOfInt1[2] = k;
      arrayOfInt1[3] = j;
      return;
    } 
    int[] arrayOfInt = this.colors;
    int i = this.highlightColor;
    arrayOfInt[0] = i;
    arrayOfInt[1] = i;
    i = this.baseColor;
    arrayOfInt[2] = i;
    arrayOfInt[3] = i;
  }
  
  public void updatePositions() {
    if (this.shape != 1) {
      this.positions[0] = Math.max((1.0F - this.intensity - this.dropoff) / 2.0F, 0.0F);
      this.positions[1] = Math.max((1.0F - this.intensity - 0.001F) / 2.0F, 0.0F);
      this.positions[2] = Math.min((this.intensity + 1.0F + 0.001F) / 2.0F, 1.0F);
      this.positions[3] = Math.min((this.intensity + 1.0F + this.dropoff) / 2.0F, 1.0F);
      return;
    } 
    float[] arrayOfFloat = this.positions;
    arrayOfFloat[0] = 0.0F;
    arrayOfFloat[1] = Math.min(this.intensity, 1.0F);
    this.positions[2] = Math.min(this.intensity + this.dropoff, 1.0F);
    this.positions[3] = 1.0F;
  }
  
  public int width(int paramInt) {
    int i = this.fixedWidth;
    return (i > 0) ? i : Math.round(this.widthRatio * paramInt);
  }
  
  public static class AlphaHighlightBuilder extends Builder<AlphaHighlightBuilder> {
    public AlphaHighlightBuilder() {
      this.mShimmer.alphaShimmer = true;
    }
    
    public AlphaHighlightBuilder getThis() {
      return this;
    }
  }
  
  public static abstract class Builder<T extends Builder<T>> {
    public final Shimmer mShimmer = new Shimmer();
    
    private static float clamp(float param1Float1, float param1Float2, float param1Float3) {
      return Math.min(param1Float2, Math.max(param1Float1, param1Float3));
    }
    
    public Shimmer build() {
      this.mShimmer.updateColors();
      this.mShimmer.updatePositions();
      return this.mShimmer;
    }
    
    public T consumeAttributes(Context param1Context, AttributeSet param1AttributeSet) {
      return consumeAttributes(param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.ShimmerFrameLayout, 0, 0));
    }
    
    public T consumeAttributes(TypedArray param1TypedArray) {
      int i = R.styleable.ShimmerFrameLayout_shimmer_clip_to_children;
      if (param1TypedArray.hasValue(i))
        setClipToChildren(param1TypedArray.getBoolean(i, this.mShimmer.clipToChildren)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_auto_start;
      if (param1TypedArray.hasValue(i))
        setAutoStart(param1TypedArray.getBoolean(i, this.mShimmer.autoStart)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_base_alpha;
      if (param1TypedArray.hasValue(i))
        setBaseAlpha(param1TypedArray.getFloat(i, 0.3F)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_highlight_alpha;
      if (param1TypedArray.hasValue(i))
        setHighlightAlpha(param1TypedArray.getFloat(i, 1.0F)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_duration;
      if (param1TypedArray.hasValue(i))
        setDuration(param1TypedArray.getInt(i, (int)this.mShimmer.animationDuration)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_repeat_count;
      if (param1TypedArray.hasValue(i))
        setRepeatCount(param1TypedArray.getInt(i, this.mShimmer.repeatCount)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_repeat_delay;
      if (param1TypedArray.hasValue(i))
        setRepeatDelay(param1TypedArray.getInt(i, (int)this.mShimmer.repeatDelay)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_repeat_mode;
      if (param1TypedArray.hasValue(i))
        setRepeatMode(param1TypedArray.getInt(i, this.mShimmer.repeatMode)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_direction;
      if (param1TypedArray.hasValue(i)) {
        i = param1TypedArray.getInt(i, this.mShimmer.direction);
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              setDirection(0);
            } else {
              setDirection(3);
            } 
          } else {
            setDirection(2);
          } 
        } else {
          setDirection(1);
        } 
      } 
      i = R.styleable.ShimmerFrameLayout_shimmer_shape;
      if (param1TypedArray.hasValue(i))
        if (param1TypedArray.getInt(i, this.mShimmer.shape) != 1) {
          setShape(0);
        } else {
          setShape(1);
        }  
      i = R.styleable.ShimmerFrameLayout_shimmer_dropoff;
      if (param1TypedArray.hasValue(i))
        setDropoff(param1TypedArray.getFloat(i, this.mShimmer.dropoff)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_fixed_width;
      if (param1TypedArray.hasValue(i))
        setFixedWidth(param1TypedArray.getDimensionPixelSize(i, this.mShimmer.fixedWidth)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_fixed_height;
      if (param1TypedArray.hasValue(i))
        setFixedHeight(param1TypedArray.getDimensionPixelSize(i, this.mShimmer.fixedHeight)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_intensity;
      if (param1TypedArray.hasValue(i))
        setIntensity(param1TypedArray.getFloat(i, this.mShimmer.intensity)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_width_ratio;
      if (param1TypedArray.hasValue(i))
        setWidthRatio(param1TypedArray.getFloat(i, this.mShimmer.widthRatio)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_height_ratio;
      if (param1TypedArray.hasValue(i))
        setHeightRatio(param1TypedArray.getFloat(i, this.mShimmer.heightRatio)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_tilt;
      if (param1TypedArray.hasValue(i))
        setTilt(param1TypedArray.getFloat(i, this.mShimmer.tilt)); 
      return getThis();
    }
    
    public T copyFrom(Shimmer param1Shimmer) {
      setDirection(param1Shimmer.direction);
      setShape(param1Shimmer.shape);
      setFixedWidth(param1Shimmer.fixedWidth);
      setFixedHeight(param1Shimmer.fixedHeight);
      setWidthRatio(param1Shimmer.widthRatio);
      setHeightRatio(param1Shimmer.heightRatio);
      setIntensity(param1Shimmer.intensity);
      setDropoff(param1Shimmer.dropoff);
      setTilt(param1Shimmer.tilt);
      setClipToChildren(param1Shimmer.clipToChildren);
      setAutoStart(param1Shimmer.autoStart);
      setRepeatCount(param1Shimmer.repeatCount);
      setRepeatMode(param1Shimmer.repeatMode);
      setRepeatDelay(param1Shimmer.repeatDelay);
      setDuration(param1Shimmer.animationDuration);
      Shimmer shimmer = this.mShimmer;
      shimmer.baseColor = param1Shimmer.baseColor;
      shimmer.highlightColor = param1Shimmer.highlightColor;
      return getThis();
    }
    
    public abstract T getThis();
    
    public T setAutoStart(boolean param1Boolean) {
      this.mShimmer.autoStart = param1Boolean;
      return getThis();
    }
    
    public T setBaseAlpha(float param1Float) {
      int i = (int)(clamp(0.0F, 1.0F, param1Float) * 255.0F);
      Shimmer shimmer = this.mShimmer;
      shimmer.baseColor = i << 24 | shimmer.baseColor & 0xFFFFFF;
      return getThis();
    }
    
    public T setClipToChildren(boolean param1Boolean) {
      this.mShimmer.clipToChildren = param1Boolean;
      return getThis();
    }
    
    public T setDirection(int param1Int) {
      this.mShimmer.direction = param1Int;
      return getThis();
    }
    
    public T setDropoff(float param1Float) {
      if (param1Float >= 0.0F) {
        this.mShimmer.dropoff = param1Float;
        return getThis();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Given invalid dropoff value: ");
      stringBuilder.append(param1Float);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public T setDuration(long param1Long) {
      if (param1Long >= 0L) {
        this.mShimmer.animationDuration = param1Long;
        return getThis();
      } 
      throw new IllegalArgumentException(s30.d0("Given a negative duration: ", param1Long));
    }
    
    public T setFixedHeight(int param1Int) {
      if (param1Int >= 0) {
        this.mShimmer.fixedHeight = param1Int;
        return getThis();
      } 
      throw new IllegalArgumentException(s30.Z("Given invalid height: ", param1Int));
    }
    
    public T setFixedWidth(int param1Int) {
      if (param1Int >= 0) {
        this.mShimmer.fixedWidth = param1Int;
        return getThis();
      } 
      throw new IllegalArgumentException(s30.Z("Given invalid width: ", param1Int));
    }
    
    public T setHeightRatio(float param1Float) {
      if (param1Float >= 0.0F) {
        this.mShimmer.heightRatio = param1Float;
        return getThis();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Given invalid height ratio: ");
      stringBuilder.append(param1Float);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public T setHighlightAlpha(float param1Float) {
      int i = (int)(clamp(0.0F, 1.0F, param1Float) * 255.0F);
      Shimmer shimmer = this.mShimmer;
      shimmer.highlightColor = i << 24 | shimmer.highlightColor & 0xFFFFFF;
      return getThis();
    }
    
    public T setIntensity(float param1Float) {
      if (param1Float >= 0.0F) {
        this.mShimmer.intensity = param1Float;
        return getThis();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Given invalid intensity value: ");
      stringBuilder.append(param1Float);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public T setRepeatCount(int param1Int) {
      this.mShimmer.repeatCount = param1Int;
      return getThis();
    }
    
    public T setRepeatDelay(long param1Long) {
      if (param1Long >= 0L) {
        this.mShimmer.repeatDelay = param1Long;
        return getThis();
      } 
      throw new IllegalArgumentException(s30.d0("Given a negative repeat delay: ", param1Long));
    }
    
    public T setRepeatMode(int param1Int) {
      this.mShimmer.repeatMode = param1Int;
      return getThis();
    }
    
    public T setShape(int param1Int) {
      this.mShimmer.shape = param1Int;
      return getThis();
    }
    
    public T setTilt(float param1Float) {
      this.mShimmer.tilt = param1Float;
      return getThis();
    }
    
    public T setWidthRatio(float param1Float) {
      if (param1Float >= 0.0F) {
        this.mShimmer.widthRatio = param1Float;
        return getThis();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Given invalid width ratio: ");
      stringBuilder.append(param1Float);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
  }
  
  public static class ColorHighlightBuilder extends Builder<ColorHighlightBuilder> {
    public ColorHighlightBuilder() {
      this.mShimmer.alphaShimmer = false;
    }
    
    public ColorHighlightBuilder consumeAttributes(TypedArray param1TypedArray) {
      super.consumeAttributes(param1TypedArray);
      int i = R.styleable.ShimmerFrameLayout_shimmer_base_color;
      if (param1TypedArray.hasValue(i))
        setBaseColor(param1TypedArray.getColor(i, this.mShimmer.baseColor)); 
      i = R.styleable.ShimmerFrameLayout_shimmer_highlight_color;
      if (param1TypedArray.hasValue(i))
        setHighlightColor(param1TypedArray.getColor(i, this.mShimmer.highlightColor)); 
      return getThis();
    }
    
    public ColorHighlightBuilder getThis() {
      return this;
    }
    
    public ColorHighlightBuilder setBaseColor(int param1Int) {
      Shimmer shimmer = this.mShimmer;
      shimmer.baseColor = param1Int & 0xFFFFFF | shimmer.baseColor & 0xFF000000;
      return getThis();
    }
    
    public ColorHighlightBuilder setHighlightColor(int param1Int) {
      this.mShimmer.highlightColor = param1Int;
      return getThis();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Direction {
    public static final int BOTTOM_TO_TOP = 3;
    
    public static final int LEFT_TO_RIGHT = 0;
    
    public static final int RIGHT_TO_LEFT = 2;
    
    public static final int TOP_TO_BOTTOM = 1;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Shape {
    public static final int LINEAR = 0;
    
    public static final int RADIAL = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\facebook\shimmer\Shimmer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */