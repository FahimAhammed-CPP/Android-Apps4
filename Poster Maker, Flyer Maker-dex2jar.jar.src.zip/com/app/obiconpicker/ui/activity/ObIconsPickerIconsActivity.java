package com.app.obiconpicker.ui.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b40;
import c40;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import d40;
import e40;
import f40;
import f91;
import g40;
import h40;
import h91;
import i40;
import j40;
import j91;
import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import k40;
import k91;
import l40;
import m40;
import m91;
import ma;
import n0;
import n40;
import o40;
import p0;
import p40;
import q40;
import r4;
import r40;
import rh2;
import s30;
import s40;
import t30;
import t40;
import u40;
import u5;
import v30;
import v40;
import w30;
import w40;
import x30;
import x40;
import y30;
import y40;
import z30;
import z40;

public class ObIconsPickerIconsActivity extends n0 implements f40, g40 {
  public static final String b = ObIconsPickerIconsActivity.class.getSimpleName();
  
  public f91 A;
  
  public i40 B = new i40();
  
  public ArrayList<String> C = new ArrayList<String>();
  
  public String D = "";
  
  public String E;
  
  public boolean F = false;
  
  public LinearLayout G;
  
  public RelativeLayout H;
  
  public Handler I;
  
  public Runnable J;
  
  public String K = "";
  
  public boolean L = false;
  
  public h91 M = new c(this);
  
  public Button c;
  
  public RecyclerView d;
  
  public AutoCompleteTextView f;
  
  public ImageView g;
  
  public ImageView p;
  
  public ImageView q;
  
  public ImageView r;
  
  public TextView s;
  
  public RelativeLayout t;
  
  public RelativeLayout u;
  
  public LinearLayout v;
  
  public ProgressDialog w;
  
  public d40 x;
  
  public b40 y;
  
  public Gson z;
  
  static {
    u5 u5 = p0.b;
    r4.b = true;
  }
  
  public static void F(ObIconsPickerIconsActivity paramObIconsPickerIconsActivity, String paramString) {
    File file;
    BitmapDrawable bitmapDrawable;
    paramObIconsPickerIconsActivity.t0();
    String str1 = l40.a;
    String str2 = paramString.substring(paramString.lastIndexOf(".") + 1, paramString.length()).toLowerCase();
    str1 = b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("EXT: ");
    stringBuilder.append(str2);
    z40.b(str1, stringBuilder.toString());
    if (str2.equals("png") || str2.equals("PNG")) {
      File file1 = new File(paramString);
      long l = file1.length();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("File size is: ");
      stringBuilder1.append(l);
      z40.b(str1, stringBuilder1.toString());
      if (l > 20971520L) {
        paramObIconsPickerIconsActivity.s0(paramObIconsPickerIconsActivity.getResources().getString(x30.obIconsPicker_err_img_too_large));
        String str = paramObIconsPickerIconsActivity.E;
        if (str == null)
          return; 
        file = new File(str.replace("file://", ""));
        if (file.exists() && file.isFile()) {
          paramString = l40.a;
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("deleted file: ");
          stringBuilder2.append(file);
          z40.b(paramString, stringBuilder2.toString());
          file.delete();
          return;
        } 
        z40.b(l40.a, "File not Exist");
        return;
      } 
      h40 h40 = new h40(file.getApplicationContext());
      h40.setIconName(file1.getName());
      if (!paramString.startsWith("file://")) {
        str1 = s30.g0("file://", paramString);
      } else {
        str1 = paramString;
      } 
      h40.setOriginalIconName(str1);
      h40.setIconId(-1);
      Bitmap bitmap = BitmapFactory.decodeFile(paramString);
      bitmapDrawable = new BitmapDrawable(file.getResources(), bitmap);
      d40 d401 = ((ObIconsPickerIconsActivity)file).x;
      if (d401 != null)
        ((rh2)d401).t2((Drawable)bitmapDrawable, h40); 
      file.finish();
      ((ObIconsPickerIconsActivity)file).E = paramString;
      return;
    } 
    z40.a((String)bitmapDrawable, "Please select valid file");
    file.s0(file.getResources().getString(x30.obIconsPicker_err_img_type));
  }
  
  public static void w(ObIconsPickerIconsActivity paramObIconsPickerIconsActivity) {
    Objects.requireNonNull(paramObIconsPickerIconsActivity);
    if (l40.b((Context)paramObIconsPickerIconsActivity)) {
      if (l40.b((Context)paramObIconsPickerIconsActivity)) {
        ProgressDialog progressDialog = paramObIconsPickerIconsActivity.w;
        if (progressDialog == null) {
          if ((c40.a()).h) {
            paramObIconsPickerIconsActivity.w = new ProgressDialog((Context)paramObIconsPickerIconsActivity, y30.ObIconspicker_RoundedProgressDialog);
          } else {
            paramObIconsPickerIconsActivity.w = new ProgressDialog((Context)paramObIconsPickerIconsActivity, y30.ObIconspicker_AppCompatAlertDialogStyle);
          } 
          paramObIconsPickerIconsActivity.w.setMessage(paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_pls_wait));
          paramObIconsPickerIconsActivity.w.setProgressStyle(0);
          paramObIconsPickerIconsActivity.w.setCancelable(false);
          paramObIconsPickerIconsActivity.w.show();
        } else if (!progressDialog.isShowing()) {
          paramObIconsPickerIconsActivity.w.setMessage(paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_pls_wait));
          paramObIconsPickerIconsActivity.w.show();
        } 
      } 
      f91 f911 = new f91((Activity)paramObIconsPickerIconsActivity);
      paramObIconsPickerIconsActivity.A = f911;
      ((m91)f911).m = paramObIconsPickerIconsActivity.M;
      ((m91)f911).i = true;
      ((m91)f911).h = false;
      f911.i();
      Bundle bundle = new Bundle();
      if ((c40.a()).m != null && !(c40.a()).m.isEmpty())
        bundle.putString("click_from", (c40.a()).m); 
      d40 d401 = paramObIconsPickerIconsActivity.x;
      if (d401 != null)
        rh2 rh2 = (rh2)d401; 
    } 
  }
  
  public static void y(ObIconsPickerIconsActivity paramObIconsPickerIconsActivity) {
    if (l40.b(paramObIconsPickerIconsActivity.getApplicationContext())) {
      String str3 = paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_need_permission);
      String str4 = paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_need_permission_message);
      String str1 = paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_goto_setting);
      String str2 = paramObIconsPickerIconsActivity.getString(x30.obIconsPicker_text_cancel);
      y40 y40 = new y40();
      Bundle bundle = s30.A("TITLE", str3, "MSG", str4);
      bundle.putString("OK", str1);
      bundle.putString("CANCEL", str2);
      bundle.putString("NEUTRAL", "");
      y40.setArguments(bundle);
      ((x40)y40).c = (e40)new o40(paramObIconsPickerIconsActivity);
      Dialog dialog = y40.s2((Context)paramObIconsPickerIconsActivity);
      if (dialog != null) {
        dialog.show();
        return;
      } 
      z40.a(x40.b, "show: dialog getting null.");
    } 
  }
  
  public final void M() {
    AutoCompleteTextView autoCompleteTextView = this.f;
    if (autoCompleteTextView != null)
      autoCompleteTextView.dismissDropDown(); 
  }
  
  public final GridLayoutManager X() {
    return l40.b((Context)this) ? new GridLayoutManager((Context)this, 9, 1, false) : null;
  }
  
  public final void e0(String paramString) {
    if (l40.b((Context)this) && !paramString.isEmpty()) {
      String str = this.D;
      if (str != null && !str.equals(paramString)) {
        this.D = paramString;
        RecyclerView recyclerView = this.d;
        if (recyclerView != null)
          recyclerView.smoothScrollToPosition(0); 
        AutoCompleteTextView autoCompleteTextView = this.f;
        if (autoCompleteTextView != null && autoCompleteTextView.getText() != null) {
          autoCompleteTextView = this.f;
          autoCompleteTextView.setSelection(autoCompleteTextView.getText().length());
        } 
      } 
    } 
  }
  
  public final void l0() {
    if (l40.b((Context)this)) {
      ArrayList<String> arrayList = new ArrayList();
      arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
      int i = Build.VERSION.SDK_INT;
      if (i >= 33) {
        arrayList.add("android.permission.READ_MEDIA_IMAGES");
      } else if (i < 29) {
        arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
      } 
      Dexter.withContext((Context)this).withPermissions(arrayList).withListener(new b(this, (Activity)this)).withErrorListener(new a(this)).onSameThread().check();
    } 
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 != 2302) {
      String str;
      if (paramInt1 != 3000) {
        if (paramInt1 != 3111)
          return; 
        if (paramInt2 == -1 && paramIntent != null) {
          if (this.A == null && l40.b((Context)this)) {
            f91 f912 = new f91((Activity)this);
            this.A = f912;
            ((m91)f912).m = this.M;
          } 
          f91 f911 = this.A;
          if (f911 != null) {
            f911.h(paramIntent);
            return;
          } 
        } else {
          t0();
          str = b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("PICK_IMAGE_DEVICE intent is null or result code is ");
          stringBuilder.append(paramInt2);
          z40.a(str, stringBuilder.toString());
          return;
        } 
      } else if (paramInt2 == -1 && str != null) {
        ArrayList<String> arrayList = str.getStringArrayListExtra("android.speech.extra.RESULTS");
        if (arrayList != null && arrayList.size() > 0) {
          String str1 = arrayList.get(0);
          String str2 = b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onActivityResult: mAnswer: ");
          stringBuilder.append(str1);
          z40.a(str2, stringBuilder.toString());
          if (!str1.isEmpty()) {
            AutoCompleteTextView autoCompleteTextView = this.f;
            if (autoCompleteTextView != null) {
              autoCompleteTextView.setText(str1);
              this.f.setSelection(str1.length());
              e0(str1);
              M();
              l40.a((Activity)this);
              return;
            } 
          } 
        } 
      } 
    } else {
      l0();
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.x = (c40.a()).c;
    setContentView(w30.ob_iconspicker_activity_main_icons_picker);
    String str2 = b;
    z40.b(str2, ": bindAllView");
    this.d = (RecyclerView)findViewById(v30.recyler_view_icons);
    this.f = (AutoCompleteTextView)findViewById(v30.autotext_Searchbar);
    this.v = (LinearLayout)findViewById(v30.relative_Search);
    this.g = (ImageView)findViewById(v30.button_Back);
    this.t = (RelativeLayout)findViewById(v30.relative_EmptyList);
    this.p = (ImageView)findViewById(v30.image_ImportIcon);
    this.c = (Button)findViewById(v30.button_Feedback);
    this.s = (TextView)findViewById(v30.text_SearchText);
    this.u = (RelativeLayout)findViewById(v30.relativeRoot);
    this.q = (ImageView)findViewById(v30.button_Cross);
    this.G = (LinearLayout)findViewById(v30.lay_mice);
    this.H = (RelativeLayout)findViewById(v30.laySearch);
    this.r = (ImageView)findViewById(v30.btnSearch);
    ImageView imageView3 = this.g;
    if (imageView3 != null)
      imageView3.setOnClickListener((View.OnClickListener)new p40(this)); 
    imageView3 = this.p;
    if (imageView3 != null)
      imageView3.setOnClickListener((View.OnClickListener)new q40(this)); 
    Button button = this.c;
    if (button != null)
      button.setOnClickListener((View.OnClickListener)new r40(this)); 
    LinearLayout linearLayout = this.G;
    if (linearLayout != null)
      linearLayout.setOnClickListener((View.OnClickListener)new s40(this)); 
    ImageView imageView2 = this.r;
    if (imageView2 != null)
      imageView2.setOnClickListener((View.OnClickListener)new t40(this)); 
    if (this.f != null && c40.a() != null)
      if ((c40.a()).i) {
        this.v.setVisibility(0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate: if");
        stringBuilder.append((c40.a()).i);
        z40.b(str2, stringBuilder.toString());
      } else {
        this.v.setVisibility(8);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate: else ");
        stringBuilder.append((c40.a()).i);
        z40.b(str2, stringBuilder.toString());
      }  
    if (this.p != null)
      if ((c40.a()).j) {
        this.p.setVisibility(0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate: if");
        stringBuilder.append((c40.a()).j);
        z40.b(str2, stringBuilder.toString());
      } else {
        this.p.setVisibility(8);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate: else ");
        stringBuilder.append((c40.a()).j);
        z40.b(str2, stringBuilder.toString());
      }  
    if (c40.a() != null)
      if ((c40.a()).h) {
        (c40.a()).h = true;
      } else {
        (c40.a()).h = false;
      }  
    z40.b(str2, "setUpIconArrayList: ");
    ArrayList arrayList2 = new ArrayList(EnumSet.allOf(j40.b.class));
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])new String[] { 
            "FOOD_FORK_DRINK", "SMOKING_OFF", "SMOKING", "SMOKE_DETECTOR", "BEER", "BOTTLE_WINE", "GLASS_WINE", "GLASS_FLUTE", "GLASS_MUG", "GLASS_TULIP", 
            "GLASS_COCKTAIL" }));
    if (this.B == null)
      this.B = new i40(); 
    this.B.getIconArrayList().clear();
    Iterator<j40.b> iterator = arrayList2.iterator();
    int i = 0;
    while (iterator.hasNext()) {
      j40.b b = iterator.next();
      if (b != null && !arrayList1.contains(b.name())) {
        h40 h40 = new h40(getApplicationContext());
        h40.setIconId(i);
        h40.setIconValue(b);
        h40.setOriginalIconName(b.name());
        h40.setIconName(b.name().toUpperCase(Locale.US).replace("_", " "));
        this.B.getIconArrayList().add(h40);
        i++;
      } 
    } 
    if (this.d != null && this.B != null && l40.b((Context)this)) {
      GridLayoutManager gridLayoutManager;
      boolean bool = getResources().getBoolean(t30.isTablet);
      if (bool) {
        gridLayoutManager = X();
      } else if ((getResources().getConfiguration()).orientation == 1) {
        if (l40.b((Context)this)) {
          gridLayoutManager = new GridLayoutManager((Context)this, 5, 1, false);
        } else {
          arrayList1 = null;
        } 
      } else {
        gridLayoutManager = X();
      } 
      if (gridLayoutManager != null)
        this.d.setLayoutManager((RecyclerView.o)gridLayoutManager); 
      b40 b401 = new b40(this.B, (Activity)this, Boolean.valueOf(bool));
      this.y = b401;
      b401.b = this;
      this.d.setAdapter((RecyclerView.g)b401);
    } 
    AutoCompleteTextView autoCompleteTextView1 = this.f;
    if (autoCompleteTextView1 != null)
      autoCompleteTextView1.addTextChangedListener((TextWatcher)new u40(this)); 
    autoCompleteTextView1 = this.f;
    if (autoCompleteTextView1 != null)
      autoCompleteTextView1.setOnClickListener((View.OnClickListener)new v40(this)); 
    autoCompleteTextView1 = this.f;
    if (autoCompleteTextView1 != null)
      autoCompleteTextView1.setOnEditorActionListener((TextView.OnEditorActionListener)new w40(this)); 
    ImageView imageView1 = this.q;
    if (imageView1 != null)
      imageView1.setOnClickListener((View.OnClickListener)new m40(this)); 
    n40 n40 = new n40(this);
    AutoCompleteTextView autoCompleteTextView2 = this.f;
    if (autoCompleteTextView2 != null)
      autoCompleteTextView2.addTextChangedListener((TextWatcher)n40); 
    String str1 = "";
    this.D = "";
    ArrayList<String> arrayList = this.C;
    if (arrayList != null) {
      ArrayList<String> arrayList3;
      arrayList.clear();
      if (l40.b(getApplicationContext())) {
        Context context = getApplicationContext();
        try {
          InputStream inputStream = context.getAssets().open("obiconspicker_en_words.json");
          byte[] arrayOfByte = new byte[inputStream.available()];
          inputStream.read(arrayOfByte);
          inputStream.close();
          String str = new String(arrayOfByte, "UTF-8");
        } finally {
          context = null;
        } 
        if (!str1.isEmpty()) {
          JsonReader jsonReader = new JsonReader(new StringReader(str1));
          jsonReader.setLenient(true);
          if (this.z == null)
            this.z = new Gson(); 
          k40 k40 = (k40)this.z.fromJson(jsonReader, k40.class);
          if (k40 != null && k40.getEnWords() != null) {
            arrayList3 = k40.getEnWords();
          } else {
            arrayList3 = new ArrayList();
          } 
        } else {
          arrayList3 = new ArrayList();
        } 
      } else {
        arrayList3 = new ArrayList();
      } 
      this.C = arrayList3;
    } 
    if (this.f != null) {
      ArrayList<String> arrayList3 = this.C;
      if (arrayList3 != null && arrayList3.size() > 0 && l40.b((Context)this)) {
        z30 z30 = new z30((Context)this, this.f, w30.ob_iconspicker_card_search_suggestion, v30.text_SuggestionWord, this.C);
        z30.q = this;
        this.f.setThreshold(1);
        this.f.setAdapter((ListAdapter)z30);
      } 
    } 
    this.J = new d(this);
    if ((c40.a()).c == null)
      finish(); 
  }
  
  public void onDestroy() {
    super.onDestroy();
    z40.a(b, "onDestroy: ");
    RecyclerView recyclerView = this.d;
    if (recyclerView != null) {
      recyclerView.setAdapter(null);
      this.d = null;
    } 
    b40 b401 = this.y;
    if (b401 != null) {
      b401.b = null;
      this.y = null;
    } 
    if (this.f != null)
      this.f = null; 
    ImageView imageView2 = this.g;
    if (imageView2 != null) {
      imageView2.setOnClickListener(null);
      this.g = null;
    } 
    Button button = this.c;
    if (button != null) {
      button.setOnClickListener(null);
      this.c = null;
    } 
    ImageView imageView1 = this.p;
    if (imageView1 != null) {
      imageView1.setOnClickListener(null);
      this.p = null;
    } 
    imageView1 = this.q;
    if (imageView1 != null) {
      imageView1.setOnClickListener(null);
      this.q = null;
    } 
    if (this.s != null)
      this.s = null; 
    if (this.t != null)
      this.t = null; 
    if (this.u != null)
      this.u = null; 
    ProgressDialog progressDialog = this.w;
    if (progressDialog != null)
      progressDialog.dismiss(); 
    if (this.x != null)
      this.x = null; 
    if (this.y != null)
      this.y = null; 
    if (this.z != null)
      this.z = null; 
    if (this.B != null)
      this.B = null; 
    ArrayList<String> arrayList = this.C;
    if (arrayList != null) {
      arrayList.clear();
      this.C = null;
    } 
    this.D = null;
    this.E = null;
  }
  
  public void onResume() {
    super.onResume();
    if (this.F != (c40.a()).k) {
      this.F = (c40.a()).k;
      b40 b401 = this.y;
      if (b401 != null)
        b401.notifyDataSetChanged(); 
    } 
  }
  
  public final void s0(String paramString) {
    if (l40.b((Context)this) && this.u != null && paramString != null && !paramString.isEmpty())
      Snackbar.make((View)this.u, paramString, -1).show(); 
  }
  
  public final void t0() {
    ProgressDialog progressDialog = this.w;
    if (progressDialog != null)
      progressDialog.cancel(); 
  }
  
  public class a implements PermissionRequestErrorListener {
    public a(ObIconsPickerIconsActivity this$0) {}
    
    public void onError(DexterError param1DexterError) {
      String str = ObIconsPickerIconsActivity.b;
      z40.b(ObIconsPickerIconsActivity.b, "onError: Error ");
    }
  }
  
  public class b implements MultiplePermissionsListener {
    public b(ObIconsPickerIconsActivity this$0, Activity param1Activity) {}
    
    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> param1List, PermissionToken param1PermissionToken) {
      param1PermissionToken.continuePermissionRequest();
    }
    
    public void onPermissionsChecked(MultiplePermissionsReport param1MultiplePermissionsReport) {
      if (Build.VERSION.SDK_INT >= 33) {
        String str = ObIconsPickerIconsActivity.b;
        z40.b(ObIconsPickerIconsActivity.b, "onPermissionsChecked: if ");
        if (l40.b((Context)this.a)) {
          if (ma.checkSelfPermission((Context)this.a, "android.permission.READ_MEDIA_IMAGES") == 0) {
            ObIconsPickerIconsActivity.w(this.b);
            return;
          } 
          if (param1MultiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
            ObIconsPickerIconsActivity.y(this.b);
            return;
          } 
        } 
      } else {
        if (param1MultiplePermissionsReport.areAllPermissionsGranted())
          ObIconsPickerIconsActivity.w(this.b); 
        if (param1MultiplePermissionsReport.isAnyPermissionPermanentlyDenied())
          ObIconsPickerIconsActivity.y(this.b); 
      } 
    }
  }
  
  public class c implements h91 {
    public c(ObIconsPickerIconsActivity this$0) {}
    
    public void a(List<k91> param1List) {
      try {
        String str = ObIconsPickerIconsActivity.b;
        str = ObIconsPickerIconsActivity.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onImagesChosen() ");
        stringBuilder.append(param1List.size());
        z40.b(str, stringBuilder.toString());
        if (param1List.size() == 0)
          return; 
        k91 k91 = param1List.get(0);
        return;
      } finally {
        param1List = null;
        ObIconsPickerIconsActivity obIconsPickerIconsActivity = this.a;
        String str = ObIconsPickerIconsActivity.b;
        obIconsPickerIconsActivity.t0();
        param1List.printStackTrace();
      } 
    }
    
    public void b(String param1String) {
      ObIconsPickerIconsActivity obIconsPickerIconsActivity = this.a;
      String str = ObIconsPickerIconsActivity.b;
      obIconsPickerIconsActivity.t0();
    }
    
    public class a implements Runnable {
      public a(ObIconsPickerIconsActivity.c this$0, k91 param2k91) {}
      
      public void run() {
        k91 k911 = this.b;
        if (k911 != null) {
          String str1 = ((j91)k911).d;
          if (str1 != null && !str1.isEmpty()) {
            ObIconsPickerIconsActivity.F(this.c.a, ((j91)this.b).d);
            return;
          } 
          str1 = this.b.z;
          if (str1 != null && !str1.isEmpty()) {
            ObIconsPickerIconsActivity.F(this.c.a, this.b.z);
            return;
          } 
          ObIconsPickerIconsActivity obIconsPickerIconsActivity1 = this.c.a;
          String str2 = ObIconsPickerIconsActivity.b;
          obIconsPickerIconsActivity1.t0();
          obIconsPickerIconsActivity1 = this.c.a;
          obIconsPickerIconsActivity1.s0(obIconsPickerIconsActivity1.getString(x30.obIconsPicker_failed_choose_image));
          return;
        } 
        ObIconsPickerIconsActivity obIconsPickerIconsActivity = this.c.a;
        String str = ObIconsPickerIconsActivity.b;
        obIconsPickerIconsActivity.t0();
        obIconsPickerIconsActivity = this.c.a;
        obIconsPickerIconsActivity.s0(obIconsPickerIconsActivity.getString(x30.obIconsPicker_failed_choose_image));
        z40.a(ObIconsPickerIconsActivity.b, "Failed to choose image");
      }
    }
  }
  
  public class a implements Runnable {
    public a(ObIconsPickerIconsActivity this$0, k91 param1k91) {}
    
    public void run() {
      k91 k911 = this.b;
      if (k911 != null) {
        String str1 = ((j91)k911).d;
        if (str1 != null && !str1.isEmpty()) {
          ObIconsPickerIconsActivity.F(this.c.a, ((j91)this.b).d);
          return;
        } 
        str1 = this.b.z;
        if (str1 != null && !str1.isEmpty()) {
          ObIconsPickerIconsActivity.F(this.c.a, this.b.z);
          return;
        } 
        ObIconsPickerIconsActivity obIconsPickerIconsActivity1 = this.c.a;
        String str2 = ObIconsPickerIconsActivity.b;
        obIconsPickerIconsActivity1.t0();
        obIconsPickerIconsActivity1 = this.c.a;
        obIconsPickerIconsActivity1.s0(obIconsPickerIconsActivity1.getString(x30.obIconsPicker_failed_choose_image));
        return;
      } 
      ObIconsPickerIconsActivity obIconsPickerIconsActivity = this.c.a;
      String str = ObIconsPickerIconsActivity.b;
      obIconsPickerIconsActivity.t0();
      obIconsPickerIconsActivity = this.c.a;
      obIconsPickerIconsActivity.s0(obIconsPickerIconsActivity.getString(x30.obIconsPicker_failed_choose_image));
      z40.a(ObIconsPickerIconsActivity.b, "Failed to choose image");
    }
  }
  
  public class d implements Runnable {
    public d(ObIconsPickerIconsActivity this$0) {}
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Lcom/app/obiconpicker/ui/activity/ObIconsPickerIconsActivity;
      //   4: astore_1
      //   5: getstatic com/app/obiconpicker/ui/activity/ObIconsPickerIconsActivity.b : Ljava/lang/String;
      //   8: astore_2
      //   9: aload_1
      //   10: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   13: pop
      //   14: new android/os/Bundle
      //   17: dup
      //   18: invokespecial <init> : ()V
      //   21: astore_2
      //   22: aload_1
      //   23: getfield K : Ljava/lang/String;
      //   26: astore_3
      //   27: aload_3
      //   28: ifnull -> 48
      //   31: aload_3
      //   32: invokevirtual isEmpty : ()Z
      //   35: ifne -> 48
      //   38: aload_2
      //   39: ldc 'name'
      //   41: aload_1
      //   42: getfield K : Ljava/lang/String;
      //   45: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   48: invokestatic a : ()Lc40;
      //   51: getfield m : Ljava/lang/String;
      //   54: ifnull -> 81
      //   57: invokestatic a : ()Lc40;
      //   60: getfield m : Ljava/lang/String;
      //   63: invokevirtual isEmpty : ()Z
      //   66: ifne -> 81
      //   69: aload_2
      //   70: ldc 'click_from'
      //   72: invokestatic a : ()Lc40;
      //   75: getfield m : Ljava/lang/String;
      //   78: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   81: aload_1
      //   82: getfield y : Lb40;
      //   85: astore_3
      //   86: aload_3
      //   87: ifnull -> 133
      //   90: aload_3
      //   91: getfield c : Li40;
      //   94: astore_3
      //   95: aload_3
      //   96: ifnull -> 133
      //   99: aload_3
      //   100: invokevirtual getIconArrayList : ()Ljava/util/ArrayList;
      //   103: ifnull -> 133
      //   106: aload_1
      //   107: getfield y : Lb40;
      //   110: getfield c : Li40;
      //   113: invokevirtual getIconArrayList : ()Ljava/util/ArrayList;
      //   116: invokevirtual size : ()I
      //   119: ifle -> 133
      //   122: aload_2
      //   123: ldc 'extra_parameter_2'
      //   125: ldc 'success'
      //   127: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   130: goto -> 141
      //   133: aload_2
      //   134: ldc 'extra_parameter_2'
      //   136: ldc 'failed'
      //   138: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   141: aload_1
      //   142: getfield x : Ld40;
      //   145: astore_1
      //   146: aload_1
      //   147: ifnull -> 155
      //   150: aload_1
      //   151: checkcast rh2
      //   154: astore_1
      //   155: return
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\app\obiconpicke\\ui\activity\ObIconsPickerIconsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */