package com.android.billingclient.api;

import android.text.TextUtils;
import java.util.Objects;

@Deprecated
public class SkuDetails {
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SkuDetails))
      return false; 
    Objects.requireNonNull((SkuDetails)paramObject);
    return TextUtils.equals(null, null);
  }
  
  public int hashCode() {
    throw null;
  }
  
  public String toString() {
    return "SkuDetails: ".concat("null");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\billingclient\api\SkuDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */