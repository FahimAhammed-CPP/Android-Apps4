package com.android.billingclient.api;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import com.google.android.apps.common.proguard.UsedByReflection;
import com.google.android.gms.internal.play_billing.zzb;

@UsedByReflection("PlatformActivityProxy")
public class ProxyBillingActivity extends Activity {
  public ResultReceiver b;
  
  public ResultReceiver c;
  
  public boolean d;
  
  public boolean f;
  
  public final Intent a() {
    Intent intent = new Intent("com.android.vending.billing.PURCHASES_UPDATED");
    intent.setPackage(getApplicationContext().getPackageName());
    return intent;
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    ResultReceiver resultReceiver1 = null;
    ResultReceiver resultReceiver3 = null;
    if (paramInt1 == 100 || paramInt1 == 110) {
      int j = (zzb.zzd(paramIntent, "ProxyBillingActivity")).a;
      int i = paramInt2;
      if (paramInt2 == -1)
        if (j != 0) {
          i = -1;
        } else {
          paramInt2 = 0;
          resultReceiver3 = this.b;
        }  
      stringBuilder = new StringBuilder();
      stringBuilder.append("Activity finished with resultCode ");
      stringBuilder.append(i);
      stringBuilder.append(" and billing's responseCode: ");
      stringBuilder.append(j);
      zzb.zzj("ProxyBillingActivity", stringBuilder.toString());
      paramInt2 = j;
    } else {
      if (paramInt1 == 101) {
        paramInt1 = zzb.zza(paramIntent, "ProxyBillingActivity");
        resultReceiver1 = this.c;
        if (resultReceiver1 != null) {
          StringBuilder stringBuilder1;
          Bundle bundle;
          if (paramIntent == null) {
            stringBuilder1 = stringBuilder;
          } else {
            bundle = stringBuilder1.getExtras();
          } 
          resultReceiver1.send(paramInt1, bundle);
        } 
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Got onActivityResult with wrong requestCode: ");
        stringBuilder1.append(paramInt1);
        stringBuilder1.append("; skipping...");
        zzb.zzj("ProxyBillingActivity", stringBuilder1.toString());
      } 
      this.d = false;
      finish();
    } 
    ResultReceiver resultReceiver2 = this.b;
  }
  
  public void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_1
    //   6: ifnonnull -> 306
    //   9: ldc 'ProxyBillingActivity'
    //   11: ldc 'Launching Play Store billing flow'
    //   13: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   16: aload_0
    //   17: invokevirtual getIntent : ()Landroid/content/Intent;
    //   20: ldc 'BUY_INTENT'
    //   22: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   25: ifeq -> 83
    //   28: aload_0
    //   29: invokevirtual getIntent : ()Landroid/content/Intent;
    //   32: ldc 'BUY_INTENT'
    //   34: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   37: checkcast android/app/PendingIntent
    //   40: astore_3
    //   41: aload_3
    //   42: astore_1
    //   43: aload_0
    //   44: invokevirtual getIntent : ()Landroid/content/Intent;
    //   47: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   49: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   52: ifeq -> 124
    //   55: aload_3
    //   56: astore_1
    //   57: aload_0
    //   58: invokevirtual getIntent : ()Landroid/content/Intent;
    //   61: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   63: iconst_0
    //   64: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   67: ifeq -> 124
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield f : Z
    //   75: bipush #110
    //   77: istore_2
    //   78: aload_3
    //   79: astore_1
    //   80: goto -> 182
    //   83: aload_0
    //   84: invokevirtual getIntent : ()Landroid/content/Intent;
    //   87: ldc 'SUBS_MANAGEMENT_INTENT'
    //   89: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   92: ifeq -> 130
    //   95: aload_0
    //   96: invokevirtual getIntent : ()Landroid/content/Intent;
    //   99: ldc 'SUBS_MANAGEMENT_INTENT'
    //   101: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   104: checkcast android/app/PendingIntent
    //   107: astore_1
    //   108: aload_0
    //   109: aload_0
    //   110: invokevirtual getIntent : ()Landroid/content/Intent;
    //   113: ldc 'result_receiver'
    //   115: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   118: checkcast android/os/ResultReceiver
    //   121: putfield b : Landroid/os/ResultReceiver;
    //   124: bipush #100
    //   126: istore_2
    //   127: goto -> 182
    //   130: aload_0
    //   131: invokevirtual getIntent : ()Landroid/content/Intent;
    //   134: ldc 'IN_APP_MESSAGE_INTENT'
    //   136: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   139: ifeq -> 177
    //   142: aload_0
    //   143: invokevirtual getIntent : ()Landroid/content/Intent;
    //   146: ldc 'IN_APP_MESSAGE_INTENT'
    //   148: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   151: checkcast android/app/PendingIntent
    //   154: astore_1
    //   155: aload_0
    //   156: aload_0
    //   157: invokevirtual getIntent : ()Landroid/content/Intent;
    //   160: ldc 'in_app_message_result_receiver'
    //   162: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   165: checkcast android/os/ResultReceiver
    //   168: putfield c : Landroid/os/ResultReceiver;
    //   171: bipush #101
    //   173: istore_2
    //   174: goto -> 182
    //   177: aconst_null
    //   178: astore_1
    //   179: goto -> 124
    //   182: aload_0
    //   183: iconst_1
    //   184: putfield d : Z
    //   187: aload_0
    //   188: aload_1
    //   189: invokevirtual getIntentSender : ()Landroid/content/IntentSender;
    //   192: iload_2
    //   193: new android/content/Intent
    //   196: dup
    //   197: invokespecial <init> : ()V
    //   200: iconst_0
    //   201: iconst_0
    //   202: iconst_0
    //   203: invokevirtual startIntentSenderForResult : (Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    //   206: return
    //   207: astore_1
    //   208: ldc 'ProxyBillingActivity'
    //   210: ldc 'Got exception while trying to start a purchase flow.'
    //   212: aload_1
    //   213: invokestatic zzk : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   216: aload_0
    //   217: getfield b : Landroid/os/ResultReceiver;
    //   220: astore_1
    //   221: aload_1
    //   222: ifnull -> 235
    //   225: aload_1
    //   226: bipush #6
    //   228: aconst_null
    //   229: invokevirtual send : (ILandroid/os/Bundle;)V
    //   232: goto -> 296
    //   235: aload_0
    //   236: getfield c : Landroid/os/ResultReceiver;
    //   239: astore_1
    //   240: aload_1
    //   241: ifnull -> 253
    //   244: aload_1
    //   245: iconst_0
    //   246: aconst_null
    //   247: invokevirtual send : (ILandroid/os/Bundle;)V
    //   250: goto -> 296
    //   253: aload_0
    //   254: invokevirtual a : ()Landroid/content/Intent;
    //   257: astore_1
    //   258: aload_0
    //   259: getfield f : Z
    //   262: ifeq -> 273
    //   265: aload_1
    //   266: ldc 'IS_FIRST_PARTY_PURCHASE'
    //   268: iconst_1
    //   269: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   272: pop
    //   273: aload_1
    //   274: ldc 'RESPONSE_CODE'
    //   276: bipush #6
    //   278: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   281: pop
    //   282: aload_1
    //   283: ldc 'DEBUG_MESSAGE'
    //   285: ldc 'An internal error occurred.'
    //   287: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   290: pop
    //   291: aload_0
    //   292: aload_1
    //   293: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   296: aload_0
    //   297: iconst_0
    //   298: putfield d : Z
    //   301: aload_0
    //   302: invokevirtual finish : ()V
    //   305: return
    //   306: ldc 'ProxyBillingActivity'
    //   308: ldc 'Launching Play Store billing flow from savedInstanceState'
    //   310: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   313: aload_0
    //   314: aload_1
    //   315: ldc 'send_cancelled_broadcast_if_finished'
    //   317: iconst_0
    //   318: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   321: putfield d : Z
    //   324: aload_1
    //   325: ldc 'result_receiver'
    //   327: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   330: ifeq -> 349
    //   333: aload_0
    //   334: aload_1
    //   335: ldc 'result_receiver'
    //   337: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   340: checkcast android/os/ResultReceiver
    //   343: putfield b : Landroid/os/ResultReceiver;
    //   346: goto -> 371
    //   349: aload_1
    //   350: ldc 'in_app_message_result_receiver'
    //   352: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   355: ifeq -> 371
    //   358: aload_0
    //   359: aload_1
    //   360: ldc 'in_app_message_result_receiver'
    //   362: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   365: checkcast android/os/ResultReceiver
    //   368: putfield c : Landroid/os/ResultReceiver;
    //   371: aload_0
    //   372: aload_1
    //   373: ldc 'IS_FLOW_FROM_FIRST_PARTY_CLIENT'
    //   375: iconst_0
    //   376: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   379: putfield f : Z
    //   382: return
    // Exception table:
    //   from	to	target	type
    //   182	206	207	android/content/IntentSender$SendIntentException
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (!isFinishing())
      return; 
    if (!this.d)
      return; 
    Intent intent = a();
    intent.putExtra("RESPONSE_CODE", 1);
    intent.putExtra("DEBUG_MESSAGE", "Billing dialog closed.");
    sendBroadcast(intent);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    ResultReceiver resultReceiver = this.b;
    if (resultReceiver != null)
      paramBundle.putParcelable("result_receiver", (Parcelable)resultReceiver); 
    resultReceiver = this.c;
    if (resultReceiver != null)
      paramBundle.putParcelable("in_app_message_result_receiver", (Parcelable)resultReceiver); 
    paramBundle.putBoolean("send_cancelled_broadcast_if_finished", this.d);
    paramBundle.putBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\billingclient\api\ProxyBillingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */