package com.android.billingclient.api;

import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Purchase {
  public final String a;
  
  public final String b;
  
  public final JSONObject c;
  
  public Purchase(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = new JSONObject(paramString1);
  }
  
  public List<String> a() {
    ArrayList<String> arrayList = new ArrayList();
    if (this.c.has("productIds")) {
      JSONArray jSONArray = this.c.optJSONArray("productIds");
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.optString(i));  
    } else if (this.c.has("productId")) {
      arrayList.add(this.c.optString("productId"));
    } 
    return arrayList;
  }
  
  public int b() {
    return (this.c.optInt("purchaseState", 1) != 4) ? 1 : 2;
  }
  
  public long c() {
    return this.c.optLong("purchaseTime");
  }
  
  public String d() {
    JSONObject jSONObject = this.c;
    return jSONObject.optString("token", jSONObject.optString("purchaseToken"));
  }
  
  public boolean e() {
    return this.c.optBoolean("autoRenewing");
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Purchase))
      return false; 
    paramObject = paramObject;
    return (TextUtils.equals(this.a, ((Purchase)paramObject).a) && TextUtils.equals(this.b, ((Purchase)paramObject).b));
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return "Purchase. Json: ".concat(String.valueOf(this.a));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\billingclient\api\Purchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */