package com.android.volley;

public class ParseError extends VolleyError {
  public ParseError() {}
  
  public ParseError(NetworkResponse paramNetworkResponse) {
    super(paramNetworkResponse);
  }
  
  public ParseError(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\ParseError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */