package com.android.volley;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class NetworkResponse {
  public final List<Header> allHeaders;
  
  public final byte[] data;
  
  public final Map<String, String> headers;
  
  public final long networkTimeMs;
  
  public final boolean notModified;
  
  public final int statusCode;
  
  private NetworkResponse(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, List<Header> paramList, boolean paramBoolean, long paramLong) {
    this.statusCode = paramInt;
    this.data = paramArrayOfbyte;
    this.headers = paramMap;
    if (paramList == null) {
      this.allHeaders = null;
    } else {
      this.allHeaders = Collections.unmodifiableList(paramList);
    } 
    this.notModified = paramBoolean;
    this.networkTimeMs = paramLong;
  }
  
  @Deprecated
  public NetworkResponse(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean) {
    this(paramInt, paramArrayOfbyte, paramMap, paramBoolean, 0L);
  }
  
  @Deprecated
  public NetworkResponse(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean, long paramLong) {
    this(paramInt, paramArrayOfbyte, paramMap, toAllHeaderList(paramMap), paramBoolean, paramLong);
  }
  
  public NetworkResponse(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean, long paramLong, List<Header> paramList) {
    this(paramInt, paramArrayOfbyte, toHeaderMap(paramList), paramList, paramBoolean, paramLong);
  }
  
  public NetworkResponse(byte[] paramArrayOfbyte) {
    this(200, paramArrayOfbyte, false, 0L, Collections.emptyList());
  }
  
  @Deprecated
  public NetworkResponse(byte[] paramArrayOfbyte, Map<String, String> paramMap) {
    this(200, paramArrayOfbyte, paramMap, false, 0L);
  }
  
  private static List<Header> toAllHeaderList(Map<String, String> paramMap) {
    if (paramMap == null)
      return null; 
    if (paramMap.isEmpty())
      return Collections.emptyList(); 
    ArrayList<Header> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, String> entry : paramMap.entrySet())
      arrayList.add(new Header((String)entry.getKey(), (String)entry.getValue())); 
    return arrayList;
  }
  
  private static Map<String, String> toHeaderMap(List<Header> paramList) {
    if (paramList == null)
      return null; 
    if (paramList.isEmpty())
      return Collections.emptyMap(); 
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (Header header : paramList)
      treeMap.put(header.getName(), header.getValue()); 
    return (Map)treeMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\NetworkResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */