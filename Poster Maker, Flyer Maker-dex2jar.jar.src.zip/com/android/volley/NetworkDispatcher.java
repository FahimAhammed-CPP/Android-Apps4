package com.android.volley;

import android.annotation.TargetApi;
import android.net.TrafficStats;
import android.os.Process;
import android.os.SystemClock;
import java.util.concurrent.BlockingQueue;

public class NetworkDispatcher extends Thread {
  private final Cache mCache;
  
  private final ResponseDelivery mDelivery;
  
  private final Network mNetwork;
  
  private final BlockingQueue<Request<?>> mQueue;
  
  private volatile boolean mQuit = false;
  
  public NetworkDispatcher(BlockingQueue<Request<?>> paramBlockingQueue, Network paramNetwork, Cache paramCache, ResponseDelivery paramResponseDelivery) {
    this.mQueue = paramBlockingQueue;
    this.mNetwork = paramNetwork;
    this.mCache = paramCache;
    this.mDelivery = paramResponseDelivery;
  }
  
  @TargetApi(14)
  private void addTrafficStatsTag(Request<?> paramRequest) {
    TrafficStats.setThreadStatsTag(paramRequest.getTrafficStatsTag());
  }
  
  private void parseAndDeliverNetworkError(Request<?> paramRequest, VolleyError paramVolleyError) {
    paramVolleyError = paramRequest.parseNetworkError(paramVolleyError);
    this.mDelivery.postError(paramRequest, paramVolleyError);
  }
  
  private void processRequest() {
    processRequest(this.mQueue.take());
  }
  
  public void processRequest(Request<?> paramRequest) {
    long l = SystemClock.elapsedRealtime();
    paramRequest.sendEvent(3);
    try {
      paramRequest.addMarker("network-queue-take");
      if (paramRequest.isCanceled()) {
        paramRequest.finish("network-discard-cancelled");
        paramRequest.notifyListenerResponseNotUsable();
        paramRequest.sendEvent(4);
        return;
      } 
      addTrafficStatsTag(paramRequest);
      NetworkResponse networkResponse = this.mNetwork.performRequest(paramRequest);
      paramRequest.addMarker("network-http-complete");
      if (networkResponse.notModified && paramRequest.hasHadResponseDelivered()) {
        paramRequest.finish("not-modified");
        paramRequest.notifyListenerResponseNotUsable();
        paramRequest.sendEvent(4);
        return;
      } 
      Response<?> response = paramRequest.parseNetworkResponse(networkResponse);
      paramRequest.addMarker("network-parse-complete");
      if (paramRequest.shouldCache() && response.cacheEntry != null) {
        this.mCache.put(paramRequest.getCacheKey(), response.cacheEntry);
        paramRequest.addMarker("network-cache-written");
      } 
      paramRequest.markDelivered();
      this.mDelivery.postResponse(paramRequest, response);
      paramRequest.notifyListenerResponseReceived(response);
    } catch (VolleyError volleyError) {
      volleyError.setNetworkTimeMs(SystemClock.elapsedRealtime() - l);
      parseAndDeliverNetworkError(paramRequest, volleyError);
      paramRequest.notifyListenerResponseNotUsable();
    } catch (Exception exception) {
      VolleyLog.e(exception, "Unhandled exception %s", new Object[] { exception.toString() });
      exception = new VolleyError(exception);
      exception.setNetworkTimeMs(SystemClock.elapsedRealtime() - l);
      this.mDelivery.postError(paramRequest, (VolleyError)exception);
      paramRequest.notifyListenerResponseNotUsable();
    } finally {
      Exception exception;
    } 
    paramRequest.sendEvent(4);
  }
  
  public void quit() {
    this.mQuit = true;
    interrupt();
  }
  
  public void run() {
    Process.setThreadPriority(10);
    while (true) {
      try {
        while (true)
          processRequest(); 
        break;
      } catch (InterruptedException interruptedException) {
        if (this.mQuit) {
          Thread.currentThread().interrupt();
          return;
        } 
        VolleyLog.e("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\NetworkDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */