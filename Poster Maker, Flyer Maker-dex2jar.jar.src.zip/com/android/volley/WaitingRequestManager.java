package com.android.volley;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

public class WaitingRequestManager implements Request.NetworkRequestCompleteListener {
  private final CacheDispatcher mCacheDispatcher;
  
  private final BlockingQueue<Request<?>> mNetworkQueue;
  
  private final RequestQueue mRequestQueue = null;
  
  private final ResponseDelivery mResponseDelivery;
  
  private final Map<String, List<Request<?>>> mWaitingRequests = new HashMap<String, List<Request<?>>>();
  
  public WaitingRequestManager(CacheDispatcher paramCacheDispatcher, BlockingQueue<Request<?>> paramBlockingQueue, ResponseDelivery paramResponseDelivery) {
    this.mResponseDelivery = paramResponseDelivery;
    this.mCacheDispatcher = paramCacheDispatcher;
    this.mNetworkQueue = paramBlockingQueue;
  }
  
  public WaitingRequestManager(RequestQueue paramRequestQueue) {
    this.mResponseDelivery = paramRequestQueue.getResponseDelivery();
    this.mCacheDispatcher = null;
    this.mNetworkQueue = null;
  }
  
  public boolean maybeAddToWaitingRequests(Request<?> paramRequest) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokevirtual getCacheKey : ()Ljava/lang/String;
    //   6: astore #4
    //   8: aload_0
    //   9: getfield mWaitingRequests : Ljava/util/Map;
    //   12: aload #4
    //   14: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   19: ifeq -> 102
    //   22: aload_0
    //   23: getfield mWaitingRequests : Ljava/util/Map;
    //   26: aload #4
    //   28: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast java/util/List
    //   36: astore_3
    //   37: aload_3
    //   38: astore_2
    //   39: aload_3
    //   40: ifnonnull -> 51
    //   43: new java/util/ArrayList
    //   46: dup
    //   47: invokespecial <init> : ()V
    //   50: astore_2
    //   51: aload_1
    //   52: ldc 'waiting-for-response'
    //   54: invokevirtual addMarker : (Ljava/lang/String;)V
    //   57: aload_2
    //   58: aload_1
    //   59: invokeinterface add : (Ljava/lang/Object;)Z
    //   64: pop
    //   65: aload_0
    //   66: getfield mWaitingRequests : Ljava/util/Map;
    //   69: aload #4
    //   71: aload_2
    //   72: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   77: pop
    //   78: getstatic com/android/volley/VolleyLog.DEBUG : Z
    //   81: ifeq -> 98
    //   84: ldc 'Request for cacheKey=%s is in flight, putting on hold.'
    //   86: iconst_1
    //   87: anewarray java/lang/Object
    //   90: dup
    //   91: iconst_0
    //   92: aload #4
    //   94: aastore
    //   95: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   98: aload_0
    //   99: monitorexit
    //   100: iconst_1
    //   101: ireturn
    //   102: aload_0
    //   103: getfield mWaitingRequests : Ljava/util/Map;
    //   106: aload #4
    //   108: aconst_null
    //   109: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   114: pop
    //   115: aload_1
    //   116: aload_0
    //   117: invokevirtual setNetworkRequestCompleteListener : (Lcom/android/volley/Request$NetworkRequestCompleteListener;)V
    //   120: getstatic com/android/volley/VolleyLog.DEBUG : Z
    //   123: ifeq -> 140
    //   126: ldc 'new request, sending to network %s'
    //   128: iconst_1
    //   129: anewarray java/lang/Object
    //   132: dup
    //   133: iconst_0
    //   134: aload #4
    //   136: aastore
    //   137: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   140: aload_0
    //   141: monitorexit
    //   142: iconst_0
    //   143: ireturn
    //   144: astore_1
    //   145: aload_0
    //   146: monitorexit
    //   147: aload_1
    //   148: athrow
    // Exception table:
    //   from	to	target	type
    //   2	37	144	finally
    //   43	51	144	finally
    //   51	98	144	finally
    //   102	140	144	finally
  }
  
  public void onNoUsableResponseReceived(Request<?> paramRequest) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokevirtual getCacheKey : ()Ljava/lang/String;
    //   6: astore_2
    //   7: aload_0
    //   8: getfield mWaitingRequests : Ljava/util/Map;
    //   11: aload_2
    //   12: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: checkcast java/util/List
    //   20: astore_3
    //   21: aload_3
    //   22: ifnull -> 166
    //   25: aload_3
    //   26: invokeinterface isEmpty : ()Z
    //   31: ifne -> 166
    //   34: getstatic com/android/volley/VolleyLog.DEBUG : Z
    //   37: ifeq -> 65
    //   40: ldc '%d waiting requests for cacheKey=%s; resend to network'
    //   42: iconst_2
    //   43: anewarray java/lang/Object
    //   46: dup
    //   47: iconst_0
    //   48: aload_3
    //   49: invokeinterface size : ()I
    //   54: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   57: aastore
    //   58: dup
    //   59: iconst_1
    //   60: aload_2
    //   61: aastore
    //   62: invokestatic v : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   65: aload_3
    //   66: iconst_0
    //   67: invokeinterface remove : (I)Ljava/lang/Object;
    //   72: checkcast com/android/volley/Request
    //   75: astore_1
    //   76: aload_0
    //   77: getfield mWaitingRequests : Ljava/util/Map;
    //   80: aload_2
    //   81: aload_3
    //   82: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   87: pop
    //   88: aload_1
    //   89: aload_0
    //   90: invokevirtual setNetworkRequestCompleteListener : (Lcom/android/volley/Request$NetworkRequestCompleteListener;)V
    //   93: aload_0
    //   94: getfield mRequestQueue : Lcom/android/volley/RequestQueue;
    //   97: astore_2
    //   98: aload_2
    //   99: ifnull -> 110
    //   102: aload_2
    //   103: aload_1
    //   104: invokevirtual sendRequestOverNetwork : (Lcom/android/volley/Request;)V
    //   107: goto -> 166
    //   110: aload_0
    //   111: getfield mCacheDispatcher : Lcom/android/volley/CacheDispatcher;
    //   114: ifnull -> 166
    //   117: aload_0
    //   118: getfield mNetworkQueue : Ljava/util/concurrent/BlockingQueue;
    //   121: astore_2
    //   122: aload_2
    //   123: ifnull -> 166
    //   126: aload_2
    //   127: aload_1
    //   128: invokeinterface put : (Ljava/lang/Object;)V
    //   133: goto -> 166
    //   136: astore_1
    //   137: ldc 'Couldn't add request to queue. %s'
    //   139: iconst_1
    //   140: anewarray java/lang/Object
    //   143: dup
    //   144: iconst_0
    //   145: aload_1
    //   146: invokevirtual toString : ()Ljava/lang/String;
    //   149: aastore
    //   150: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   153: invokestatic currentThread : ()Ljava/lang/Thread;
    //   156: invokevirtual interrupt : ()V
    //   159: aload_0
    //   160: getfield mCacheDispatcher : Lcom/android/volley/CacheDispatcher;
    //   163: invokevirtual quit : ()V
    //   166: aload_0
    //   167: monitorexit
    //   168: return
    //   169: astore_1
    //   170: aload_0
    //   171: monitorexit
    //   172: aload_1
    //   173: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	169	finally
    //   25	65	169	finally
    //   65	98	169	finally
    //   102	107	169	finally
    //   110	122	169	finally
    //   126	133	136	java/lang/InterruptedException
    //   126	133	169	finally
    //   137	166	169	finally
  }
  
  public void onResponseReceived(Request<?> paramRequest, Response<?> paramResponse) {
    // Byte code:
    //   0: aload_2
    //   1: getfield cacheEntry : Lcom/android/volley/Cache$Entry;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnull -> 123
    //   9: aload_3
    //   10: invokevirtual isExpired : ()Z
    //   13: ifeq -> 19
    //   16: goto -> 123
    //   19: aload_1
    //   20: invokevirtual getCacheKey : ()Ljava/lang/String;
    //   23: astore_1
    //   24: aload_0
    //   25: monitorenter
    //   26: aload_0
    //   27: getfield mWaitingRequests : Ljava/util/Map;
    //   30: aload_1
    //   31: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast java/util/List
    //   39: astore_3
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_3
    //   43: ifnull -> 117
    //   46: getstatic com/android/volley/VolleyLog.DEBUG : Z
    //   49: ifeq -> 77
    //   52: ldc 'Releasing %d waiting requests for cacheKey=%s.'
    //   54: iconst_2
    //   55: anewarray java/lang/Object
    //   58: dup
    //   59: iconst_0
    //   60: aload_3
    //   61: invokeinterface size : ()I
    //   66: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   69: aastore
    //   70: dup
    //   71: iconst_1
    //   72: aload_1
    //   73: aastore
    //   74: invokestatic v : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   77: aload_3
    //   78: invokeinterface iterator : ()Ljava/util/Iterator;
    //   83: astore_1
    //   84: aload_1
    //   85: invokeinterface hasNext : ()Z
    //   90: ifeq -> 117
    //   93: aload_1
    //   94: invokeinterface next : ()Ljava/lang/Object;
    //   99: checkcast com/android/volley/Request
    //   102: astore_3
    //   103: aload_0
    //   104: getfield mResponseDelivery : Lcom/android/volley/ResponseDelivery;
    //   107: aload_3
    //   108: aload_2
    //   109: invokeinterface postResponse : (Lcom/android/volley/Request;Lcom/android/volley/Response;)V
    //   114: goto -> 84
    //   117: return
    //   118: astore_1
    //   119: aload_0
    //   120: monitorexit
    //   121: aload_1
    //   122: athrow
    //   123: aload_0
    //   124: aload_1
    //   125: invokevirtual onNoUsableResponseReceived : (Lcom/android/volley/Request;)V
    //   128: return
    // Exception table:
    //   from	to	target	type
    //   26	42	118	finally
    //   119	121	118	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\WaitingRequestManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */