package com.android.volley;

import android.os.Handler;
import android.os.Looper;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class RequestQueue {
  private static final int DEFAULT_NETWORK_THREAD_POOL_SIZE = 4;
  
  private final Cache mCache;
  
  private CacheDispatcher mCacheDispatcher;
  
  private final PriorityBlockingQueue<Request<?>> mCacheQueue = new PriorityBlockingQueue<Request<?>>();
  
  private final Set<Request<?>> mCurrentRequests = new HashSet<Request<?>>();
  
  private final ResponseDelivery mDelivery;
  
  private final NetworkDispatcher[] mDispatchers;
  
  private final List<RequestEventListener> mEventListeners = new ArrayList<RequestEventListener>();
  
  private final List<RequestFinishedListener> mFinishedListeners = new ArrayList<RequestFinishedListener>();
  
  private final Network mNetwork;
  
  private final PriorityBlockingQueue<Request<?>> mNetworkQueue = new PriorityBlockingQueue<Request<?>>();
  
  private final AtomicInteger mSequenceGenerator = new AtomicInteger();
  
  public RequestQueue(Cache paramCache, Network paramNetwork) {
    this(paramCache, paramNetwork, 4);
  }
  
  public RequestQueue(Cache paramCache, Network paramNetwork, int paramInt) {
    this(paramCache, paramNetwork, paramInt, new ExecutorDelivery(new Handler(Looper.getMainLooper())));
  }
  
  public RequestQueue(Cache paramCache, Network paramNetwork, int paramInt, ResponseDelivery paramResponseDelivery) {
    this.mCache = paramCache;
    this.mNetwork = paramNetwork;
    this.mDispatchers = new NetworkDispatcher[paramInt];
    this.mDelivery = paramResponseDelivery;
  }
  
  public <T> Request<T> add(Request<T> paramRequest) {
    paramRequest.setRequestQueue(this);
    synchronized (this.mCurrentRequests) {
      this.mCurrentRequests.add(paramRequest);
      paramRequest.setSequence(getSequenceNumber());
      paramRequest.addMarker("add-to-queue");
      sendRequestEvent(paramRequest, 0);
      beginRequest(paramRequest);
      return paramRequest;
    } 
  }
  
  public void addRequestEventListener(RequestEventListener paramRequestEventListener) {
    synchronized (this.mEventListeners) {
      this.mEventListeners.add(paramRequestEventListener);
      return;
    } 
  }
  
  @Deprecated
  public <T> void addRequestFinishedListener(RequestFinishedListener<T> paramRequestFinishedListener) {
    synchronized (this.mFinishedListeners) {
      this.mFinishedListeners.add(paramRequestFinishedListener);
      return;
    } 
  }
  
  public <T> void beginRequest(Request<T> paramRequest) {
    if (!paramRequest.shouldCache()) {
      sendRequestOverNetwork(paramRequest);
      return;
    } 
    this.mCacheQueue.add(paramRequest);
  }
  
  public void cancelAll(RequestFilter paramRequestFilter) {
    synchronized (this.mCurrentRequests) {
      for (Request<?> request : this.mCurrentRequests) {
        if (paramRequestFilter.apply(request))
          request.cancel(); 
      } 
      return;
    } 
  }
  
  public void cancelAll(final Object tag) {
    if (tag != null) {
      cancelAll(new RequestFilter() {
            public boolean apply(Request<?> param1Request) {
              return (param1Request.getTag() == tag);
            }
          });
      return;
    } 
    throw new IllegalArgumentException("Cannot cancelAll with a null tag");
  }
  
  public <T> void finish(Request<T> paramRequest) {
    synchronized (this.mCurrentRequests) {
      this.mCurrentRequests.remove(paramRequest);
      synchronized (this.mFinishedListeners) {
        Iterator<RequestFinishedListener> iterator = this.mFinishedListeners.iterator();
        while (iterator.hasNext())
          ((RequestFinishedListener<T>)iterator.next()).onRequestFinished(paramRequest); 
        sendRequestEvent(paramRequest, 5);
        return;
      } 
    } 
  }
  
  public Cache getCache() {
    return this.mCache;
  }
  
  public ResponseDelivery getResponseDelivery() {
    return this.mDelivery;
  }
  
  public int getSequenceNumber() {
    return this.mSequenceGenerator.incrementAndGet();
  }
  
  public void removeRequestEventListener(RequestEventListener paramRequestEventListener) {
    synchronized (this.mEventListeners) {
      this.mEventListeners.remove(paramRequestEventListener);
      return;
    } 
  }
  
  @Deprecated
  public <T> void removeRequestFinishedListener(RequestFinishedListener<T> paramRequestFinishedListener) {
    synchronized (this.mFinishedListeners) {
      this.mFinishedListeners.remove(paramRequestFinishedListener);
      return;
    } 
  }
  
  public void sendRequestEvent(Request<?> paramRequest, int paramInt) {
    synchronized (this.mEventListeners) {
      Iterator<RequestEventListener> iterator = this.mEventListeners.iterator();
      while (iterator.hasNext())
        ((RequestEventListener)iterator.next()).onRequestEvent(paramRequest, paramInt); 
      return;
    } 
  }
  
  public <T> void sendRequestOverNetwork(Request<T> paramRequest) {
    this.mNetworkQueue.add(paramRequest);
  }
  
  public void start() {
    stop();
    CacheDispatcher cacheDispatcher = new CacheDispatcher(this.mCacheQueue, this.mNetworkQueue, this.mCache, this.mDelivery);
    this.mCacheDispatcher = cacheDispatcher;
    cacheDispatcher.start();
    for (int i = 0; i < this.mDispatchers.length; i++) {
      NetworkDispatcher networkDispatcher = new NetworkDispatcher(this.mNetworkQueue, this.mNetwork, this.mCache, this.mDelivery);
      this.mDispatchers[i] = networkDispatcher;
      networkDispatcher.start();
    } 
  }
  
  public void stop() {
    CacheDispatcher cacheDispatcher = this.mCacheDispatcher;
    if (cacheDispatcher != null)
      cacheDispatcher.quit(); 
    for (NetworkDispatcher networkDispatcher : this.mDispatchers) {
      if (networkDispatcher != null)
        networkDispatcher.quit(); 
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RequestEvent {
    public static final int REQUEST_CACHE_LOOKUP_FINISHED = 2;
    
    public static final int REQUEST_CACHE_LOOKUP_STARTED = 1;
    
    public static final int REQUEST_FINISHED = 5;
    
    public static final int REQUEST_NETWORK_DISPATCH_FINISHED = 4;
    
    public static final int REQUEST_NETWORK_DISPATCH_STARTED = 3;
    
    public static final int REQUEST_QUEUED = 0;
  }
  
  public static interface RequestEventListener {
    void onRequestEvent(Request<?> param1Request, int param1Int);
  }
  
  public static interface RequestFilter {
    boolean apply(Request<?> param1Request);
  }
  
  @Deprecated
  public static interface RequestFinishedListener<T> {
    void onRequestFinished(Request<T> param1Request);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\RequestQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */