package com.android.volley;

public interface ResponseDelivery {
  void postError(Request<?> paramRequest, VolleyError paramVolleyError);
  
  void postResponse(Request<?> paramRequest, Response<?> paramResponse);
  
  void postResponse(Request<?> paramRequest, Response<?> paramResponse, Runnable paramRunnable);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\ResponseDelivery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */