package com.android.volley;

public class ClientError extends ServerError {
  public ClientError() {}
  
  public ClientError(NetworkResponse paramNetworkResponse) {
    super(paramNetworkResponse);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\ClientError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */