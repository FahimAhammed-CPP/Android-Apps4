package com.android.volley;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import s30;

public class AsyncRequestQueue extends RequestQueue {
  private static final int DEFAULT_BLOCKING_THREAD_POOL_SIZE = 4;
  
  private final AsyncCache mAsyncCache;
  
  private ExecutorService mBlockingExecutor;
  
  private final Object mCacheInitializationLock = new Object[0];
  
  private ExecutorFactory mExecutorFactory;
  
  private volatile boolean mIsCacheInitialized = false;
  
  private final AsyncNetwork mNetwork;
  
  private ExecutorService mNonBlockingExecutor;
  
  private ScheduledExecutorService mNonBlockingScheduledExecutor;
  
  private final List<Request<?>> mRequestsAwaitingCacheInitialization = new ArrayList<Request<?>>();
  
  private final WaitingRequestManager mWaitingRequestManager = new WaitingRequestManager(this);
  
  private AsyncRequestQueue(Cache paramCache, AsyncNetwork paramAsyncNetwork, AsyncCache paramAsyncCache, ResponseDelivery paramResponseDelivery, ExecutorFactory paramExecutorFactory) {
    super(paramCache, paramAsyncNetwork, 0, paramResponseDelivery);
    this.mAsyncCache = paramAsyncCache;
    this.mNetwork = paramAsyncNetwork;
    this.mExecutorFactory = paramExecutorFactory;
  }
  
  private void finishRequest(Request<?> paramRequest, Response<?> paramResponse, boolean paramBoolean) {
    if (paramBoolean)
      paramRequest.addMarker("network-cache-written"); 
    paramRequest.markDelivered();
    getResponseDelivery().postResponse(paramRequest, paramResponse);
    paramRequest.notifyListenerResponseReceived(paramResponse);
  }
  
  private static PriorityBlockingQueue<Runnable> getBlockingQueue() {
    return new PriorityBlockingQueue<Runnable>(11, new Comparator<Runnable>() {
          public int compare(Runnable param1Runnable1, Runnable param1Runnable2) {
            return (param1Runnable1 instanceof RequestTask) ? ((param1Runnable2 instanceof RequestTask) ? ((RequestTask)param1Runnable1).compareTo((RequestTask)param1Runnable2) : 1) : ((param1Runnable2 instanceof RequestTask) ? -1 : 0);
          }
        });
  }
  
  private void handleEntry(Cache.Entry paramEntry, Request<?> paramRequest) {
    if (paramEntry == null) {
      paramRequest.addMarker("cache-miss");
      if (!this.mWaitingRequestManager.maybeAddToWaitingRequests(paramRequest))
        sendRequestOverNetwork(paramRequest); 
      return;
    } 
    long l = System.currentTimeMillis();
    if (paramEntry.isExpired(l)) {
      paramRequest.addMarker("cache-hit-expired");
      paramRequest.setCacheEntry(paramEntry);
      if (!this.mWaitingRequestManager.maybeAddToWaitingRequests(paramRequest))
        sendRequestOverNetwork(paramRequest); 
      return;
    } 
    this.mBlockingExecutor.execute(new CacheParseTask(paramRequest, paramEntry, l));
  }
  
  private void onCacheInitializationComplete() {
    synchronized (this.mCacheInitializationLock) {
      ArrayList<Request<?>> arrayList = new ArrayList<Request<?>>(this.mRequestsAwaitingCacheInitialization);
      this.mRequestsAwaitingCacheInitialization.clear();
      this.mIsCacheInitialized = true;
      null = (Object<Request<?>>)arrayList.iterator();
      while (null.hasNext())
        beginRequest(null.next()); 
      return;
    } 
  }
  
  public <T> void beginRequest(Request<T> paramRequest) {
    if (!this.mIsCacheInitialized)
      synchronized (this.mCacheInitializationLock) {
        if (!this.mIsCacheInitialized) {
          this.mRequestsAwaitingCacheInitialization.add(paramRequest);
          return;
        } 
      }  
    if (paramRequest.shouldCache()) {
      if (this.mAsyncCache != null) {
        this.mNonBlockingExecutor.execute(new CacheTask<T>(paramRequest));
        return;
      } 
      this.mBlockingExecutor.execute(new CacheTask<T>(paramRequest));
      return;
    } 
    sendRequestOverNetwork(paramRequest);
  }
  
  public <T> void sendRequestOverNetwork(Request<T> paramRequest) {
    this.mNonBlockingExecutor.execute(new NetworkTask<T>(paramRequest));
  }
  
  public void start() {
    stop();
    this.mNonBlockingExecutor = this.mExecutorFactory.createNonBlockingExecutor(getBlockingQueue());
    this.mBlockingExecutor = this.mExecutorFactory.createBlockingExecutor(getBlockingQueue());
    this.mNonBlockingScheduledExecutor = this.mExecutorFactory.createNonBlockingScheduledExecutor();
    this.mNetwork.setBlockingExecutor(this.mBlockingExecutor);
    this.mNetwork.setNonBlockingExecutor(this.mNonBlockingExecutor);
    this.mNetwork.setNonBlockingScheduledExecutor(this.mNonBlockingScheduledExecutor);
    if (this.mAsyncCache != null) {
      this.mNonBlockingExecutor.execute(new Runnable() {
            public void run() {
              AsyncRequestQueue.this.mAsyncCache.initialize(new AsyncCache.OnWriteCompleteCallback() {
                    public void onWriteComplete() {
                      AsyncRequestQueue.this.onCacheInitializationComplete();
                    }
                  });
            }
          });
      return;
    } 
    this.mBlockingExecutor.execute(new Runnable() {
          public void run() {
            AsyncRequestQueue.this.getCache().initialize();
            AsyncRequestQueue.this.mNonBlockingExecutor.execute(new Runnable() {
                  public void run() {
                    AsyncRequestQueue.this.onCacheInitializationComplete();
                  }
                });
          }
        });
  }
  
  public void stop() {
    ExecutorService executorService = this.mNonBlockingExecutor;
    if (executorService != null) {
      executorService.shutdownNow();
      this.mNonBlockingExecutor = null;
    } 
    executorService = this.mBlockingExecutor;
    if (executorService != null) {
      executorService.shutdownNow();
      this.mBlockingExecutor = null;
    } 
    executorService = this.mNonBlockingScheduledExecutor;
    if (executorService != null) {
      executorService.shutdownNow();
      this.mNonBlockingScheduledExecutor = null;
    } 
  }
  
  public static class Builder {
    private AsyncCache mAsyncCache = null;
    
    private Cache mCache = null;
    
    private AsyncRequestQueue.ExecutorFactory mExecutorFactory = null;
    
    private final AsyncNetwork mNetwork;
    
    private ResponseDelivery mResponseDelivery = null;
    
    public Builder(AsyncNetwork param1AsyncNetwork) {
      if (param1AsyncNetwork != null) {
        this.mNetwork = param1AsyncNetwork;
        return;
      } 
      throw new IllegalArgumentException("Network cannot be null");
    }
    
    private AsyncRequestQueue.ExecutorFactory getDefaultExecutorFactory() {
      return new AsyncRequestQueue.ExecutorFactory() {
          private ThreadPoolExecutor getNewThreadPoolExecutor(int param2Int, String param2String, BlockingQueue<Runnable> param2BlockingQueue) {
            return new ThreadPoolExecutor(0, param2Int, 60L, TimeUnit.SECONDS, param2BlockingQueue, getThreadFactory(param2String));
          }
          
          private ThreadFactory getThreadFactory(final String threadNameSuffix) {
            return new ThreadFactory() {
                public Thread newThread(Runnable param3Runnable) {
                  param3Runnable = Executors.defaultThreadFactory().newThread(param3Runnable);
                  StringBuilder stringBuilder = s30.x0("Volley-");
                  stringBuilder.append(threadNameSuffix);
                  param3Runnable.setName(stringBuilder.toString());
                  return (Thread)param3Runnable;
                }
              };
          }
          
          public ExecutorService createBlockingExecutor(BlockingQueue<Runnable> param2BlockingQueue) {
            return getNewThreadPoolExecutor(4, "BlockingExecutor", param2BlockingQueue);
          }
          
          public ExecutorService createNonBlockingExecutor(BlockingQueue<Runnable> param2BlockingQueue) {
            return getNewThreadPoolExecutor(1, "Non-BlockingExecutor", param2BlockingQueue);
          }
          
          public ScheduledExecutorService createNonBlockingScheduledExecutor() {
            return new ScheduledThreadPoolExecutor(0, getThreadFactory("ScheduledExecutor"));
          }
        };
    }
    
    public AsyncRequestQueue build() {
      Cache cache = this.mCache;
      if (cache != null || this.mAsyncCache != null) {
        if (cache == null)
          this.mCache = new AsyncRequestQueue.ThrowingCache(); 
        if (this.mResponseDelivery == null)
          this.mResponseDelivery = new ExecutorDelivery(new Handler(Looper.getMainLooper())); 
        if (this.mExecutorFactory == null)
          this.mExecutorFactory = getDefaultExecutorFactory(); 
        return new AsyncRequestQueue(this.mCache, this.mNetwork, this.mAsyncCache, this.mResponseDelivery, this.mExecutorFactory);
      } 
      throw new IllegalArgumentException("You must set one of the cache objects");
    }
    
    public Builder setAsyncCache(AsyncCache param1AsyncCache) {
      this.mAsyncCache = param1AsyncCache;
      return this;
    }
    
    public Builder setCache(Cache param1Cache) {
      this.mCache = param1Cache;
      return this;
    }
    
    public Builder setExecutorFactory(AsyncRequestQueue.ExecutorFactory param1ExecutorFactory) {
      this.mExecutorFactory = param1ExecutorFactory;
      return this;
    }
    
    public Builder setResponseDelivery(ResponseDelivery param1ResponseDelivery) {
      this.mResponseDelivery = param1ResponseDelivery;
      return this;
    }
  }
  
  public class null extends ExecutorFactory {
    private ThreadPoolExecutor getNewThreadPoolExecutor(int param1Int, String param1String, BlockingQueue<Runnable> param1BlockingQueue) {
      return new ThreadPoolExecutor(0, param1Int, 60L, TimeUnit.SECONDS, param1BlockingQueue, getThreadFactory(param1String));
    }
    
    private ThreadFactory getThreadFactory(final String threadNameSuffix) {
      return new ThreadFactory() {
          public Thread newThread(Runnable param3Runnable) {
            param3Runnable = Executors.defaultThreadFactory().newThread(param3Runnable);
            StringBuilder stringBuilder = s30.x0("Volley-");
            stringBuilder.append(threadNameSuffix);
            param3Runnable.setName(stringBuilder.toString());
            return (Thread)param3Runnable;
          }
        };
    }
    
    public ExecutorService createBlockingExecutor(BlockingQueue<Runnable> param1BlockingQueue) {
      return getNewThreadPoolExecutor(4, "BlockingExecutor", param1BlockingQueue);
    }
    
    public ExecutorService createNonBlockingExecutor(BlockingQueue<Runnable> param1BlockingQueue) {
      return getNewThreadPoolExecutor(1, "Non-BlockingExecutor", param1BlockingQueue);
    }
    
    public ScheduledExecutorService createNonBlockingScheduledExecutor() {
      return new ScheduledThreadPoolExecutor(0, getThreadFactory("ScheduledExecutor"));
    }
  }
  
  public class null implements ThreadFactory {
    public Thread newThread(Runnable param1Runnable) {
      param1Runnable = Executors.defaultThreadFactory().newThread(param1Runnable);
      StringBuilder stringBuilder = s30.x0("Volley-");
      stringBuilder.append(threadNameSuffix);
      param1Runnable.setName(stringBuilder.toString());
      return (Thread)param1Runnable;
    }
  }
  
  public class CacheParseTask<T> extends RequestTask<T> {
    public Cache.Entry entry;
    
    public long startTimeMillis;
    
    public CacheParseTask(Request<T> param1Request, Cache.Entry param1Entry, long param1Long) {
      super(param1Request);
      this.entry = param1Entry;
      this.startTimeMillis = param1Long;
    }
    
    public void run() {
      this.mRequest.addMarker("cache-hit");
      Request<T> request = this.mRequest;
      Cache.Entry entry = this.entry;
      Response<T> response = request.parseNetworkResponse(new NetworkResponse(200, entry.data, false, 0L, entry.allResponseHeaders));
      this.mRequest.addMarker("cache-hit-parsed");
      if (!this.entry.refreshNeeded(this.startTimeMillis)) {
        AsyncRequestQueue.this.getResponseDelivery().postResponse(this.mRequest, response);
        return;
      } 
      this.mRequest.addMarker("cache-hit-refresh-needed");
      this.mRequest.setCacheEntry(this.entry);
      response.intermediate = true;
      if (!AsyncRequestQueue.this.mWaitingRequestManager.maybeAddToWaitingRequests(this.mRequest)) {
        AsyncRequestQueue.this.getResponseDelivery().postResponse(this.mRequest, response, new Runnable() {
              public void run() {
                AsyncRequestQueue.CacheParseTask cacheParseTask = AsyncRequestQueue.CacheParseTask.this;
                AsyncRequestQueue.this.sendRequestOverNetwork(cacheParseTask.mRequest);
              }
            });
        return;
      } 
      AsyncRequestQueue.this.getResponseDelivery().postResponse(this.mRequest, response);
    }
  }
  
  public class null implements Runnable {
    public void run() {
      AsyncRequestQueue.CacheParseTask cacheParseTask = this.this$1;
      AsyncRequestQueue.this.sendRequestOverNetwork(cacheParseTask.mRequest);
    }
  }
  
  public class CachePutTask<T> extends RequestTask<T> {
    public Response<?> response;
    
    public CachePutTask(Request<T> param1Request, Response<?> param1Response) {
      super(param1Request);
      this.response = param1Response;
    }
    
    public void run() {
      if (AsyncRequestQueue.this.mAsyncCache != null) {
        AsyncRequestQueue.this.mAsyncCache.put(this.mRequest.getCacheKey(), this.response.cacheEntry, new AsyncCache.OnWriteCompleteCallback() {
              public void onWriteComplete() {
                AsyncRequestQueue.CachePutTask cachePutTask = AsyncRequestQueue.CachePutTask.this;
                AsyncRequestQueue.this.finishRequest(cachePutTask.mRequest, cachePutTask.response, true);
              }
            });
        return;
      } 
      AsyncRequestQueue.this.getCache().put(this.mRequest.getCacheKey(), this.response.cacheEntry);
      AsyncRequestQueue.this.finishRequest(this.mRequest, this.response, true);
    }
  }
  
  public class null implements AsyncCache.OnWriteCompleteCallback {
    public void onWriteComplete() {
      AsyncRequestQueue.CachePutTask cachePutTask = this.this$1;
      AsyncRequestQueue.this.finishRequest(cachePutTask.mRequest, cachePutTask.response, true);
    }
  }
  
  public class CacheTask<T> extends RequestTask<T> {
    public CacheTask(Request<T> param1Request) {
      super(param1Request);
    }
    
    public void run() {
      if (this.mRequest.isCanceled()) {
        this.mRequest.finish("cache-discard-canceled");
        return;
      } 
      this.mRequest.addMarker("cache-queue-take");
      if (AsyncRequestQueue.this.mAsyncCache != null) {
        AsyncRequestQueue.this.mAsyncCache.get(this.mRequest.getCacheKey(), new AsyncCache.OnGetCompleteCallback() {
              public void onGetComplete(Cache.Entry param2Entry) {
                AsyncRequestQueue.CacheTask cacheTask = AsyncRequestQueue.CacheTask.this;
                AsyncRequestQueue.this.handleEntry(param2Entry, cacheTask.mRequest);
              }
            });
        return;
      } 
      Cache.Entry entry = AsyncRequestQueue.this.getCache().get(this.mRequest.getCacheKey());
      AsyncRequestQueue.this.handleEntry(entry, this.mRequest);
    }
  }
  
  public class null implements AsyncCache.OnGetCompleteCallback {
    public void onGetComplete(Cache.Entry param1Entry) {
      AsyncRequestQueue.CacheTask cacheTask = this.this$1;
      AsyncRequestQueue.this.handleEntry(param1Entry, cacheTask.mRequest);
    }
  }
  
  public static abstract class ExecutorFactory {
    public abstract ExecutorService createBlockingExecutor(BlockingQueue<Runnable> param1BlockingQueue);
    
    public abstract ExecutorService createNonBlockingExecutor(BlockingQueue<Runnable> param1BlockingQueue);
    
    public abstract ScheduledExecutorService createNonBlockingScheduledExecutor();
  }
  
  public class NetworkParseTask<T> extends RequestTask<T> {
    public NetworkResponse networkResponse;
    
    public NetworkParseTask(Request<T> param1Request, NetworkResponse param1NetworkResponse) {
      super(param1Request);
      this.networkResponse = param1NetworkResponse;
    }
    
    public void run() {
      Response<T> response = this.mRequest.parseNetworkResponse(this.networkResponse);
      this.mRequest.addMarker("network-parse-complete");
      if (this.mRequest.shouldCache() && response.cacheEntry != null) {
        if (AsyncRequestQueue.this.mAsyncCache != null) {
          AsyncRequestQueue.this.mNonBlockingExecutor.execute(new AsyncRequestQueue.CachePutTask<T>(this.mRequest, response));
          return;
        } 
        AsyncRequestQueue.this.mBlockingExecutor.execute(new AsyncRequestQueue.CachePutTask<T>(this.mRequest, response));
        return;
      } 
      AsyncRequestQueue.this.finishRequest(this.mRequest, response, false);
    }
  }
  
  public class NetworkTask<T> extends RequestTask<T> {
    public NetworkTask(Request<T> param1Request) {
      super(param1Request);
    }
    
    public void run() {
      if (this.mRequest.isCanceled()) {
        this.mRequest.finish("network-discard-cancelled");
        this.mRequest.notifyListenerResponseNotUsable();
        return;
      } 
      final long startTimeMs = SystemClock.elapsedRealtime();
      this.mRequest.addMarker("network-queue-take");
      AsyncRequestQueue.this.mNetwork.performRequest(this.mRequest, new AsyncNetwork.OnRequestComplete() {
            public void onError(VolleyError param2VolleyError) {
              param2VolleyError.setNetworkTimeMs(SystemClock.elapsedRealtime() - startTimeMs);
              ExecutorService executorService = AsyncRequestQueue.this.mBlockingExecutor;
              AsyncRequestQueue.NetworkTask networkTask = AsyncRequestQueue.NetworkTask.this;
              executorService.execute(new AsyncRequestQueue.ParseErrorTask(networkTask.mRequest, param2VolleyError));
            }
            
            public void onSuccess(NetworkResponse param2NetworkResponse) {
              AsyncRequestQueue.NetworkTask.this.mRequest.addMarker("network-http-complete");
              if (param2NetworkResponse.notModified && AsyncRequestQueue.NetworkTask.this.mRequest.hasHadResponseDelivered()) {
                AsyncRequestQueue.NetworkTask.this.mRequest.finish("not-modified");
                AsyncRequestQueue.NetworkTask.this.mRequest.notifyListenerResponseNotUsable();
                return;
              } 
              ExecutorService executorService = AsyncRequestQueue.this.mBlockingExecutor;
              AsyncRequestQueue.NetworkTask networkTask = AsyncRequestQueue.NetworkTask.this;
              executorService.execute(new AsyncRequestQueue.NetworkParseTask(networkTask.mRequest, param2NetworkResponse));
            }
          });
    }
  }
  
  public class null implements AsyncNetwork.OnRequestComplete {
    public void onError(VolleyError param1VolleyError) {
      param1VolleyError.setNetworkTimeMs(SystemClock.elapsedRealtime() - startTimeMs);
      ExecutorService executorService = AsyncRequestQueue.this.mBlockingExecutor;
      AsyncRequestQueue.NetworkTask networkTask = this.this$1;
      executorService.execute(new AsyncRequestQueue.ParseErrorTask(networkTask.mRequest, param1VolleyError));
    }
    
    public void onSuccess(NetworkResponse param1NetworkResponse) {
      this.this$1.mRequest.addMarker("network-http-complete");
      if (param1NetworkResponse.notModified && this.this$1.mRequest.hasHadResponseDelivered()) {
        this.this$1.mRequest.finish("not-modified");
        this.this$1.mRequest.notifyListenerResponseNotUsable();
        return;
      } 
      ExecutorService executorService = AsyncRequestQueue.this.mBlockingExecutor;
      AsyncRequestQueue.NetworkTask networkTask = this.this$1;
      executorService.execute(new AsyncRequestQueue.NetworkParseTask(networkTask.mRequest, param1NetworkResponse));
    }
  }
  
  public class ParseErrorTask<T> extends RequestTask<T> {
    public VolleyError volleyError;
    
    public ParseErrorTask(Request<T> param1Request, VolleyError param1VolleyError) {
      super(param1Request);
      this.volleyError = param1VolleyError;
    }
    
    public void run() {
      VolleyError volleyError = this.mRequest.parseNetworkError(this.volleyError);
      AsyncRequestQueue.this.getResponseDelivery().postError(this.mRequest, volleyError);
      this.mRequest.notifyListenerResponseNotUsable();
    }
  }
  
  public static class ThrowingCache implements Cache {
    private ThrowingCache() {}
    
    public void clear() {
      throw new UnsupportedOperationException();
    }
    
    public Cache.Entry get(String param1String) {
      throw new UnsupportedOperationException();
    }
    
    public void initialize() {
      throw new UnsupportedOperationException();
    }
    
    public void invalidate(String param1String, boolean param1Boolean) {
      throw new UnsupportedOperationException();
    }
    
    public void put(String param1String, Cache.Entry param1Entry) {
      throw new UnsupportedOperationException();
    }
    
    public void remove(String param1String) {
      throw new UnsupportedOperationException();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\AsyncRequestQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */