package com.android.volley.toolbox;

import android.os.Looper;

public final class Threads {
  public static void throwIfNotOnMainThread() {
    if (Looper.myLooper() == Looper.getMainLooper())
      return; 
    throw new IllegalStateException("Must be invoked from the main thread.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\Threads.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */