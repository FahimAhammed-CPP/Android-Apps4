package com.android.volley.toolbox;

import com.android.volley.Header;
import com.android.volley.Request;
import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import s30;

public class HurlStack extends BaseHttpStack {
  private static final int HTTP_CONTINUE = 100;
  
  private final SSLSocketFactory mSslSocketFactory;
  
  private final UrlRewriter mUrlRewriter;
  
  public HurlStack() {
    this(null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter) {
    this(paramUrlRewriter, null);
  }
  
  public HurlStack(UrlRewriter paramUrlRewriter, SSLSocketFactory paramSSLSocketFactory) {
    this.mUrlRewriter = paramUrlRewriter;
    this.mSslSocketFactory = paramSSLSocketFactory;
  }
  
  private void addBody(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest, byte[] paramArrayOfbyte) {
    paramHttpURLConnection.setDoOutput(true);
    if (!paramHttpURLConnection.getRequestProperties().containsKey("Content-Type"))
      paramHttpURLConnection.setRequestProperty("Content-Type", paramRequest.getBodyContentType()); 
    DataOutputStream dataOutputStream = new DataOutputStream(createOutputStream(paramRequest, paramHttpURLConnection, paramArrayOfbyte.length));
    dataOutputStream.write(paramArrayOfbyte);
    dataOutputStream.close();
  }
  
  private void addBodyIfExists(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) {
    byte[] arrayOfByte = paramRequest.getBody();
    if (arrayOfByte != null)
      addBody(paramHttpURLConnection, paramRequest, arrayOfByte); 
  }
  
  public static List<Header> convertHeaders(Map<String, List<String>> paramMap) {
    ArrayList<Header> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, List<String>> entry : paramMap.entrySet()) {
      if (entry.getKey() != null)
        for (String str : entry.getValue())
          arrayList.add(new Header((String)entry.getKey(), str));  
    } 
    return arrayList;
  }
  
  private static boolean hasResponseBody(int paramInt1, int paramInt2) {
    return (paramInt1 != 4 && (100 > paramInt2 || paramInt2 >= 200) && paramInt2 != 204 && paramInt2 != 304);
  }
  
  private static InputStream inputStreamFromConnection(HttpURLConnection paramHttpURLConnection) {
    try {
      return paramHttpURLConnection.getInputStream();
    } catch (IOException iOException) {
      return paramHttpURLConnection.getErrorStream();
    } 
  }
  
  private HttpURLConnection openConnection(URL paramURL, Request<?> paramRequest) {
    HttpURLConnection httpURLConnection = createConnection(paramURL);
    int i = paramRequest.getTimeoutMs();
    httpURLConnection.setConnectTimeout(i);
    httpURLConnection.setReadTimeout(i);
    httpURLConnection.setUseCaches(false);
    httpURLConnection.setDoInput(true);
    if ("https".equals(paramURL.getProtocol())) {
      SSLSocketFactory sSLSocketFactory = this.mSslSocketFactory;
      if (sSLSocketFactory != null)
        ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(sSLSocketFactory); 
    } 
    return httpURLConnection;
  }
  
  public HttpURLConnection createConnection(URL paramURL) {
    HttpURLConnection httpURLConnection = (HttpURLConnection)paramURL.openConnection();
    httpURLConnection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
    return httpURLConnection;
  }
  
  public InputStream createInputStream(Request<?> paramRequest, HttpURLConnection paramHttpURLConnection) {
    return new UrlConnectionInputStream(paramHttpURLConnection);
  }
  
  public OutputStream createOutputStream(Request<?> paramRequest, HttpURLConnection paramHttpURLConnection, int paramInt) {
    return paramHttpURLConnection.getOutputStream();
  }
  
  public HttpResponse executeRequest(Request<?> paramRequest, Map<String, String> paramMap) {
    String str2 = paramRequest.getUrl();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(paramMap);
    hashMap.putAll(paramRequest.getHeaders());
    UrlRewriter urlRewriter = this.mUrlRewriter;
    String str1 = str2;
    if (urlRewriter != null) {
      str1 = urlRewriter.rewriteUrl(str2);
      if (str1 == null)
        throw new IOException(s30.g0("URL blocked by rewriter: ", str2)); 
    } 
    HttpURLConnection httpURLConnection = openConnection(new URL(str1), paramRequest);
    boolean bool2 = false;
    boolean bool1 = bool2;
    try {
      Iterator<String> iterator = hashMap.keySet().iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          bool1 = bool2;
          String str = iterator.next();
          bool1 = bool2;
          httpURLConnection.setRequestProperty(str, (String)hashMap.get(str));
          continue;
        } 
        bool1 = bool2;
        setConnectionParametersForRequest(httpURLConnection, paramRequest);
        bool1 = bool2;
        int i = httpURLConnection.getResponseCode();
        if (i != -1) {
          HttpResponse httpResponse;
          bool1 = bool2;
          if (!hasResponseBody(paramRequest.getMethod(), i)) {
            bool1 = bool2;
            httpResponse = new HttpResponse(i, convertHeaders(httpURLConnection.getHeaderFields()));
            return httpResponse;
          } 
          return new HttpResponse(i, convertHeaders(httpURLConnection.getHeaderFields()), httpURLConnection.getContentLength(), createInputStream((Request<?>)httpResponse, httpURLConnection));
        } 
        bool1 = bool2;
        throw new IOException("Could not retrieve response code from HttpUrlConnection.");
      } 
    } finally {
      if (!bool1)
        httpURLConnection.disconnect(); 
    } 
  }
  
  public void setConnectionParametersForRequest(HttpURLConnection paramHttpURLConnection, Request<?> paramRequest) {
    switch (paramRequest.getMethod()) {
      default:
        throw new IllegalStateException("Unknown method type.");
      case 7:
        paramHttpURLConnection.setRequestMethod("PATCH");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 6:
        paramHttpURLConnection.setRequestMethod("TRACE");
        return;
      case 5:
        paramHttpURLConnection.setRequestMethod("OPTIONS");
        return;
      case 4:
        paramHttpURLConnection.setRequestMethod("HEAD");
        return;
      case 3:
        paramHttpURLConnection.setRequestMethod("DELETE");
        return;
      case 2:
        paramHttpURLConnection.setRequestMethod("PUT");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 1:
        paramHttpURLConnection.setRequestMethod("POST");
        addBodyIfExists(paramHttpURLConnection, paramRequest);
        return;
      case 0:
        paramHttpURLConnection.setRequestMethod("GET");
        return;
      case -1:
        break;
    } 
    byte[] arrayOfByte = paramRequest.getPostBody();
    if (arrayOfByte != null) {
      paramHttpURLConnection.setRequestMethod("POST");
      addBody(paramHttpURLConnection, paramRequest, arrayOfByte);
    } 
  }
  
  public static class UrlConnectionInputStream extends FilterInputStream {
    private final HttpURLConnection mConnection;
    
    public UrlConnectionInputStream(HttpURLConnection param1HttpURLConnection) {
      super(HurlStack.inputStreamFromConnection(param1HttpURLConnection));
      this.mConnection = param1HttpURLConnection;
    }
    
    public void close() {
      super.close();
      this.mConnection.disconnect();
    }
  }
  
  public static interface UrlRewriter extends UrlRewriter {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\HurlStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */