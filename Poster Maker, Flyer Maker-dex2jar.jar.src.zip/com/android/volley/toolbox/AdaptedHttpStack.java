package com.android.volley.toolbox;

import com.android.volley.Header;
import com.android.volley.Request;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.conn.ConnectTimeoutException;
import s30;

public class AdaptedHttpStack extends BaseHttpStack {
  private final HttpStack mHttpStack;
  
  public AdaptedHttpStack(HttpStack paramHttpStack) {
    this.mHttpStack = paramHttpStack;
  }
  
  public HttpResponse executeRequest(Request<?> paramRequest, Map<String, String> paramMap) {
    try {
      HttpResponse httpResponse = this.mHttpStack.performRequest(paramRequest, paramMap);
      int j = httpResponse.getStatusLine().getStatusCode();
      Header[] arrayOfHeader = httpResponse.getAllHeaders();
      ArrayList<Header> arrayList = new ArrayList(arrayOfHeader.length);
      int k = arrayOfHeader.length;
      for (int i = 0; i < k; i++) {
        Header header = arrayOfHeader[i];
        arrayList.add(new Header(header.getName(), header.getValue()));
      } 
      if (httpResponse.getEntity() == null)
        return new HttpResponse(j, arrayList); 
      long l = httpResponse.getEntity().getContentLength();
      if ((int)l == l)
        return new HttpResponse(j, arrayList, (int)httpResponse.getEntity().getContentLength(), httpResponse.getEntity().getContent()); 
      throw new IOException(s30.d0("Response too large: ", l));
    } catch (ConnectTimeoutException connectTimeoutException) {
      SocketTimeoutException socketTimeoutException = new SocketTimeoutException(connectTimeoutException.getMessage());
      throw socketTimeoutException;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\AdaptedHttpStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */