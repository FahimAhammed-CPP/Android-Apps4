package com.android.volley.toolbox;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class RequestFuture<T> implements Future<T>, Response.Listener<T>, Response.ErrorListener {
  private VolleyError mException;
  
  private Request<?> mRequest;
  
  private T mResult;
  
  private boolean mResultReceived = false;
  
  private T doGet(Long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mException : Lcom/android/volley/VolleyError;
    //   6: ifnonnull -> 137
    //   9: aload_0
    //   10: getfield mResultReceived : Z
    //   13: ifeq -> 25
    //   16: aload_0
    //   17: getfield mResult : Ljava/lang/Object;
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: areturn
    //   25: aload_1
    //   26: ifnonnull -> 44
    //   29: aload_0
    //   30: invokevirtual isDone : ()Z
    //   33: ifne -> 94
    //   36: aload_0
    //   37: lconst_0
    //   38: invokevirtual wait : (J)V
    //   41: goto -> 29
    //   44: aload_1
    //   45: invokevirtual longValue : ()J
    //   48: lconst_0
    //   49: lcmp
    //   50: ifle -> 94
    //   53: invokestatic uptimeMillis : ()J
    //   56: lstore_2
    //   57: aload_1
    //   58: invokevirtual longValue : ()J
    //   61: lload_2
    //   62: ladd
    //   63: lstore #4
    //   65: aload_0
    //   66: invokevirtual isDone : ()Z
    //   69: ifne -> 94
    //   72: lload_2
    //   73: lload #4
    //   75: lcmp
    //   76: ifge -> 94
    //   79: aload_0
    //   80: lload #4
    //   82: lload_2
    //   83: lsub
    //   84: invokevirtual wait : (J)V
    //   87: invokestatic uptimeMillis : ()J
    //   90: lstore_2
    //   91: goto -> 65
    //   94: aload_0
    //   95: getfield mException : Lcom/android/volley/VolleyError;
    //   98: ifnonnull -> 125
    //   101: aload_0
    //   102: getfield mResultReceived : Z
    //   105: ifeq -> 117
    //   108: aload_0
    //   109: getfield mResult : Ljava/lang/Object;
    //   112: astore_1
    //   113: aload_0
    //   114: monitorexit
    //   115: aload_1
    //   116: areturn
    //   117: new java/util/concurrent/TimeoutException
    //   120: dup
    //   121: invokespecial <init> : ()V
    //   124: athrow
    //   125: new java/util/concurrent/ExecutionException
    //   128: dup
    //   129: aload_0
    //   130: getfield mException : Lcom/android/volley/VolleyError;
    //   133: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   136: athrow
    //   137: new java/util/concurrent/ExecutionException
    //   140: dup
    //   141: aload_0
    //   142: getfield mException : Lcom/android/volley/VolleyError;
    //   145: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   148: athrow
    //   149: astore_1
    //   150: aload_0
    //   151: monitorexit
    //   152: goto -> 157
    //   155: aload_1
    //   156: athrow
    //   157: goto -> 155
    // Exception table:
    //   from	to	target	type
    //   2	21	149	finally
    //   29	41	149	finally
    //   44	65	149	finally
    //   65	72	149	finally
    //   79	91	149	finally
    //   94	113	149	finally
    //   117	125	149	finally
    //   125	137	149	finally
    //   137	149	149	finally
  }
  
  public static <E> RequestFuture<E> newFuture() {
    return new RequestFuture<E>();
  }
  
  public boolean cancel(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mRequest : Lcom/android/volley/Request;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_0
    //   14: ireturn
    //   15: aload_0
    //   16: invokevirtual isDone : ()Z
    //   19: ifne -> 33
    //   22: aload_0
    //   23: getfield mRequest : Lcom/android/volley/Request;
    //   26: invokevirtual cancel : ()V
    //   29: aload_0
    //   30: monitorexit
    //   31: iconst_1
    //   32: ireturn
    //   33: aload_0
    //   34: monitorexit
    //   35: iconst_0
    //   36: ireturn
    //   37: astore_2
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	37	finally
    //   15	29	37	finally
  }
  
  public T get() {
    try {
      return doGet(null);
    } catch (TimeoutException timeoutException) {
      throw new AssertionError(timeoutException);
    } 
  }
  
  public T get(long paramLong, TimeUnit paramTimeUnit) {
    return doGet(Long.valueOf(TimeUnit.MILLISECONDS.convert(paramLong, paramTimeUnit)));
  }
  
  public boolean isCancelled() {
    Request<?> request = this.mRequest;
    return (request == null) ? false : request.isCanceled();
  }
  
  public boolean isDone() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mResultReceived : Z
    //   6: ifne -> 33
    //   9: aload_0
    //   10: getfield mException : Lcom/android/volley/VolleyError;
    //   13: ifnonnull -> 33
    //   16: aload_0
    //   17: invokevirtual isCancelled : ()Z
    //   20: istore_1
    //   21: iload_1
    //   22: ifeq -> 28
    //   25: goto -> 33
    //   28: iconst_0
    //   29: istore_1
    //   30: goto -> 35
    //   33: iconst_1
    //   34: istore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: iload_1
    //   38: ireturn
    //   39: astore_2
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_2
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	39	finally
  }
  
  public void onErrorResponse(VolleyError paramVolleyError) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield mException : Lcom/android/volley/VolleyError;
    //   7: aload_0
    //   8: invokevirtual notifyAll : ()V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void onResponse(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: putfield mResultReceived : Z
    //   7: aload_0
    //   8: aload_1
    //   9: putfield mResult : Ljava/lang/Object;
    //   12: aload_0
    //   13: invokevirtual notifyAll : ()V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  public void setRequest(Request<?> paramRequest) {
    this.mRequest = paramRequest;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\RequestFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */