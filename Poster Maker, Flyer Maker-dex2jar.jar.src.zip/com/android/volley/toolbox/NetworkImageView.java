package com.android.volley.toolbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import com.android.volley.VolleyError;

public class NetworkImageView extends ImageView {
  private Bitmap mDefaultImageBitmap;
  
  private Drawable mDefaultImageDrawable;
  
  private int mDefaultImageId;
  
  private Bitmap mErrorImageBitmap;
  
  private Drawable mErrorImageDrawable;
  
  private int mErrorImageId;
  
  private ImageLoader.ImageContainer mImageContainer;
  
  private ImageLoader mImageLoader;
  
  private String mUrl;
  
  public NetworkImageView(Context paramContext) {
    this(paramContext, null);
  }
  
  public NetworkImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NetworkImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  private void setDefaultImageOrNull() {
    int i = this.mDefaultImageId;
    if (i != 0) {
      setImageResource(i);
      return;
    } 
    Drawable drawable = this.mDefaultImageDrawable;
    if (drawable != null) {
      setImageDrawable(drawable);
      return;
    } 
    Bitmap bitmap = this.mDefaultImageBitmap;
    if (bitmap != null) {
      setImageBitmap(bitmap);
      return;
    } 
    setImageBitmap(null);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    invalidate();
  }
  
  public void loadImageIfNecessary(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getWidth : ()I
    //   4: istore #6
    //   6: aload_0
    //   7: invokevirtual getHeight : ()I
    //   10: istore #5
    //   12: aload_0
    //   13: invokevirtual getScaleType : ()Landroid/widget/ImageView$ScaleType;
    //   16: astore #8
    //   18: aload_0
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: astore #9
    //   24: iconst_1
    //   25: istore #4
    //   27: aload #9
    //   29: ifnull -> 76
    //   32: aload_0
    //   33: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   36: getfield width : I
    //   39: bipush #-2
    //   41: if_icmpne -> 49
    //   44: iconst_1
    //   45: istore_2
    //   46: goto -> 51
    //   49: iconst_0
    //   50: istore_2
    //   51: iload_2
    //   52: istore_3
    //   53: aload_0
    //   54: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   57: getfield height : I
    //   60: bipush #-2
    //   62: if_icmpne -> 78
    //   65: iconst_1
    //   66: istore #7
    //   68: iload_2
    //   69: istore_3
    //   70: iload #7
    //   72: istore_2
    //   73: goto -> 80
    //   76: iconst_0
    //   77: istore_3
    //   78: iconst_0
    //   79: istore_2
    //   80: iload_3
    //   81: ifeq -> 91
    //   84: iload_2
    //   85: ifeq -> 91
    //   88: goto -> 94
    //   91: iconst_0
    //   92: istore #4
    //   94: iload #6
    //   96: ifne -> 110
    //   99: iload #5
    //   101: ifne -> 110
    //   104: iload #4
    //   106: ifne -> 110
    //   109: return
    //   110: aload_0
    //   111: getfield mUrl : Ljava/lang/String;
    //   114: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   117: ifeq -> 146
    //   120: aload_0
    //   121: getfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   124: astore #8
    //   126: aload #8
    //   128: ifnull -> 141
    //   131: aload #8
    //   133: invokevirtual cancelRequest : ()V
    //   136: aload_0
    //   137: aconst_null
    //   138: putfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   141: aload_0
    //   142: invokespecial setDefaultImageOrNull : ()V
    //   145: return
    //   146: aload_0
    //   147: getfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   150: astore #9
    //   152: aload #9
    //   154: ifnull -> 194
    //   157: aload #9
    //   159: invokevirtual getRequestUrl : ()Ljava/lang/String;
    //   162: ifnull -> 194
    //   165: aload_0
    //   166: getfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   169: invokevirtual getRequestUrl : ()Ljava/lang/String;
    //   172: aload_0
    //   173: getfield mUrl : Ljava/lang/String;
    //   176: invokevirtual equals : (Ljava/lang/Object;)Z
    //   179: ifeq -> 183
    //   182: return
    //   183: aload_0
    //   184: getfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   187: invokevirtual cancelRequest : ()V
    //   190: aload_0
    //   191: invokespecial setDefaultImageOrNull : ()V
    //   194: iload #6
    //   196: istore #4
    //   198: iload_3
    //   199: ifeq -> 205
    //   202: iconst_0
    //   203: istore #4
    //   205: iload_2
    //   206: ifeq -> 214
    //   209: iconst_0
    //   210: istore_2
    //   211: goto -> 217
    //   214: iload #5
    //   216: istore_2
    //   217: aload_0
    //   218: aload_0
    //   219: getfield mImageLoader : Lcom/android/volley/toolbox/ImageLoader;
    //   222: aload_0
    //   223: getfield mUrl : Ljava/lang/String;
    //   226: new com/android/volley/toolbox/NetworkImageView$1
    //   229: dup
    //   230: aload_0
    //   231: iload_1
    //   232: invokespecial <init> : (Lcom/android/volley/toolbox/NetworkImageView;Z)V
    //   235: iload #4
    //   237: iload_2
    //   238: aload #8
    //   240: invokevirtual get : (Ljava/lang/String;Lcom/android/volley/toolbox/ImageLoader$ImageListener;IILandroid/widget/ImageView$ScaleType;)Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   243: putfield mImageContainer : Lcom/android/volley/toolbox/ImageLoader$ImageContainer;
    //   246: return
  }
  
  public void onDetachedFromWindow() {
    ImageLoader.ImageContainer imageContainer = this.mImageContainer;
    if (imageContainer != null) {
      imageContainer.cancelRequest();
      setImageBitmap(null);
      this.mImageContainer = null;
    } 
    super.onDetachedFromWindow();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    loadImageIfNecessary(true);
  }
  
  public void setDefaultImageBitmap(Bitmap paramBitmap) {
    this.mDefaultImageId = 0;
    this.mDefaultImageDrawable = null;
    this.mDefaultImageBitmap = paramBitmap;
  }
  
  public void setDefaultImageDrawable(Drawable paramDrawable) {
    this.mDefaultImageId = 0;
    this.mDefaultImageBitmap = null;
    this.mDefaultImageDrawable = paramDrawable;
  }
  
  public void setDefaultImageResId(int paramInt) {
    this.mDefaultImageBitmap = null;
    this.mDefaultImageDrawable = null;
    this.mDefaultImageId = paramInt;
  }
  
  public void setErrorImageBitmap(Bitmap paramBitmap) {
    this.mErrorImageId = 0;
    this.mErrorImageDrawable = null;
    this.mErrorImageBitmap = paramBitmap;
  }
  
  public void setErrorImageDrawable(Drawable paramDrawable) {
    this.mErrorImageId = 0;
    this.mErrorImageBitmap = null;
    this.mErrorImageDrawable = paramDrawable;
  }
  
  public void setErrorImageResId(int paramInt) {
    this.mErrorImageBitmap = null;
    this.mErrorImageDrawable = null;
    this.mErrorImageId = paramInt;
  }
  
  public void setImageUrl(String paramString, ImageLoader paramImageLoader) {
    Threads.throwIfNotOnMainThread();
    this.mUrl = paramString;
    this.mImageLoader = paramImageLoader;
    loadImageIfNecessary(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\NetworkImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */