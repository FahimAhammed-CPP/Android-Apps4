package com.android.volley.toolbox;

import com.android.volley.Header;
import com.android.volley.Request;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;

public abstract class BaseHttpStack implements HttpStack {
  public abstract HttpResponse executeRequest(Request<?> paramRequest, Map<String, String> paramMap);
  
  @Deprecated
  public final HttpResponse performRequest(Request<?> paramRequest, Map<String, String> paramMap) {
    HttpResponse httpResponse = executeRequest(paramRequest, paramMap);
    BasicHttpResponse basicHttpResponse = new BasicHttpResponse((StatusLine)new BasicStatusLine(new ProtocolVersion("HTTP", 1, 1), httpResponse.getStatusCode(), ""));
    ArrayList<BasicHeader> arrayList = new ArrayList();
    for (Header header : httpResponse.getHeaders())
      arrayList.add(new BasicHeader(header.getName(), header.getValue())); 
    basicHttpResponse.setHeaders(arrayList.<Header>toArray(new Header[0]));
    InputStream inputStream = httpResponse.getContent();
    if (inputStream != null) {
      BasicHttpEntity basicHttpEntity = new BasicHttpEntity();
      basicHttpEntity.setContent(inputStream);
      basicHttpEntity.setContentLength(httpResponse.getContentLength());
      basicHttpResponse.setEntity((HttpEntity)basicHttpEntity);
    } 
    return (HttpResponse)basicHttpResponse;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\BaseHttpStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */