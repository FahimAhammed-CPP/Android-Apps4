package com.android.volley.toolbox;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import java.io.UnsupportedEncodingException;

public class StringRequest extends Request<String> {
  private Response.Listener<String> mListener;
  
  private final Object mLock = new Object();
  
  public StringRequest(int paramInt, String paramString, Response.Listener<String> paramListener, Response.ErrorListener paramErrorListener) {
    super(paramInt, paramString, paramErrorListener);
    this.mListener = paramListener;
  }
  
  public StringRequest(String paramString, Response.Listener<String> paramListener, Response.ErrorListener paramErrorListener) {
    this(0, paramString, paramListener, paramErrorListener);
  }
  
  public void cancel() {
    super.cancel();
    synchronized (this.mLock) {
      this.mListener = null;
      return;
    } 
  }
  
  public void deliverResponse(String paramString) {
    synchronized (this.mLock) {
      Response.Listener<String> listener = this.mListener;
      if (listener != null)
        listener.onResponse(paramString); 
      return;
    } 
  }
  
  public Response<String> parseNetworkResponse(NetworkResponse paramNetworkResponse) {
    String str;
    try {
      str = new String(paramNetworkResponse.data, HttpHeaderParser.parseCharset(paramNetworkResponse.headers));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      str = new String(paramNetworkResponse.data);
    } 
    return Response.success(str, HttpHeaderParser.parseCacheHeaders(paramNetworkResponse));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\StringRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */