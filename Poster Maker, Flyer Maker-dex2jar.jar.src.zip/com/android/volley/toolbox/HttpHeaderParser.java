package com.android.volley.toolbox;

import com.android.volley.Cache;
import com.android.volley.Header;
import com.android.volley.NetworkResponse;
import com.android.volley.VolleyLog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;

public class HttpHeaderParser {
  private static final String DEFAULT_CONTENT_CHARSET = "ISO-8859-1";
  
  public static final String HEADER_CONTENT_TYPE = "Content-Type";
  
  private static final String RFC1123_OUTPUT_FORMAT = "EEE, dd MMM yyyy HH:mm:ss 'GMT'";
  
  private static final String RFC1123_PARSE_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";
  
  public static List<Header> combineHeaders(List<Header> paramList, Cache.Entry paramEntry) {
    TreeSet<String> treeSet = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
    if (!paramList.isEmpty()) {
      Iterator<Header> iterator = paramList.iterator();
      while (iterator.hasNext())
        treeSet.add(((Header)iterator.next()).getName()); 
    } 
    paramList = new ArrayList<Header>(paramList);
    List list = paramEntry.allResponseHeaders;
    if (list != null) {
      if (!list.isEmpty())
        for (Header header : paramEntry.allResponseHeaders) {
          if (!treeSet.contains(header.getName()))
            paramList.add(header); 
        }  
    } else if (!paramEntry.responseHeaders.isEmpty()) {
      for (Map.Entry entry : paramEntry.responseHeaders.entrySet()) {
        if (!treeSet.contains(entry.getKey()))
          paramList.add(new Header((String)entry.getKey(), (String)entry.getValue())); 
      } 
    } 
    return paramList;
  }
  
  public static String formatEpochAsRfc1123(long paramLong) {
    return newUsGmtFormatter("EEE, dd MMM yyyy HH:mm:ss 'GMT'").format(new Date(paramLong));
  }
  
  public static Map<String, String> getCacheHeaders(Cache.Entry paramEntry) {
    if (paramEntry == null)
      return Collections.emptyMap(); 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String str = paramEntry.etag;
    if (str != null)
      hashMap.put("If-None-Match", str); 
    long l = paramEntry.lastModified;
    if (l > 0L)
      hashMap.put("If-Modified-Since", formatEpochAsRfc1123(l)); 
    return (Map)hashMap;
  }
  
  private static SimpleDateFormat newUsGmtFormatter(String paramString) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString, Locale.US);
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    return simpleDateFormat;
  }
  
  public static Cache.Entry parseCacheHeaders(NetworkResponse paramNetworkResponse) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore #13
    //   5: aload_0
    //   6: getfield headers : Ljava/util/Map;
    //   9: astore #15
    //   11: aload #15
    //   13: ifnonnull -> 18
    //   16: aconst_null
    //   17: areturn
    //   18: aload #15
    //   20: ldc 'Date'
    //   22: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   27: checkcast java/lang/String
    //   30: astore #16
    //   32: aload #16
    //   34: ifnull -> 47
    //   37: aload #16
    //   39: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   42: lstore #7
    //   44: goto -> 50
    //   47: lconst_0
    //   48: lstore #7
    //   50: aload #15
    //   52: ldc 'Cache-Control'
    //   54: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   59: checkcast java/lang/String
    //   62: astore #16
    //   64: iconst_0
    //   65: istore_1
    //   66: iconst_0
    //   67: istore_2
    //   68: aload #16
    //   70: ifnull -> 242
    //   73: aload #16
    //   75: ldc ','
    //   77: iconst_0
    //   78: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   81: astore #16
    //   83: iconst_0
    //   84: istore_1
    //   85: lconst_0
    //   86: lstore #5
    //   88: lconst_0
    //   89: lstore_3
    //   90: iload_2
    //   91: aload #16
    //   93: arraylength
    //   94: if_icmpge -> 237
    //   97: aload #16
    //   99: iload_2
    //   100: aaload
    //   101: invokevirtual trim : ()Ljava/lang/String;
    //   104: astore #17
    //   106: aload #17
    //   108: ldc 'no-cache'
    //   110: invokevirtual equals : (Ljava/lang/Object;)Z
    //   113: ifne -> 235
    //   116: aload #17
    //   118: ldc 'no-store'
    //   120: invokevirtual equals : (Ljava/lang/Object;)Z
    //   123: ifeq -> 128
    //   126: aconst_null
    //   127: areturn
    //   128: aload #17
    //   130: ldc 'max-age='
    //   132: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   135: ifeq -> 156
    //   138: aload #17
    //   140: bipush #8
    //   142: invokevirtual substring : (I)Ljava/lang/String;
    //   145: invokestatic parseLong : (Ljava/lang/String;)J
    //   148: lstore #9
    //   150: lload_3
    //   151: lstore #11
    //   153: goto -> 221
    //   156: aload #17
    //   158: ldc 'stale-while-revalidate='
    //   160: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   163: ifeq -> 185
    //   166: aload #17
    //   168: bipush #23
    //   170: invokevirtual substring : (I)Ljava/lang/String;
    //   173: invokestatic parseLong : (Ljava/lang/String;)J
    //   176: lstore #11
    //   178: lload #5
    //   180: lstore #9
    //   182: goto -> 221
    //   185: aload #17
    //   187: ldc 'must-revalidate'
    //   189: invokevirtual equals : (Ljava/lang/Object;)Z
    //   192: ifne -> 212
    //   195: lload #5
    //   197: lstore #9
    //   199: lload_3
    //   200: lstore #11
    //   202: aload #17
    //   204: ldc 'proxy-revalidate'
    //   206: invokevirtual equals : (Ljava/lang/Object;)Z
    //   209: ifeq -> 221
    //   212: iconst_1
    //   213: istore_1
    //   214: lload_3
    //   215: lstore #11
    //   217: lload #5
    //   219: lstore #9
    //   221: iload_2
    //   222: iconst_1
    //   223: iadd
    //   224: istore_2
    //   225: lload #9
    //   227: lstore #5
    //   229: lload #11
    //   231: lstore_3
    //   232: goto -> 90
    //   235: aconst_null
    //   236: areturn
    //   237: iconst_1
    //   238: istore_2
    //   239: goto -> 249
    //   242: iconst_0
    //   243: istore_2
    //   244: lconst_0
    //   245: lstore #5
    //   247: lconst_0
    //   248: lstore_3
    //   249: aload #15
    //   251: ldc 'Expires'
    //   253: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   258: checkcast java/lang/String
    //   261: astore #16
    //   263: aload #16
    //   265: ifnull -> 278
    //   268: aload #16
    //   270: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   273: lstore #11
    //   275: goto -> 281
    //   278: lconst_0
    //   279: lstore #11
    //   281: aload #15
    //   283: ldc 'Last-Modified'
    //   285: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   290: checkcast java/lang/String
    //   293: astore #16
    //   295: aload #16
    //   297: ifnull -> 310
    //   300: aload #16
    //   302: invokestatic parseDateAsEpoch : (Ljava/lang/String;)J
    //   305: lstore #9
    //   307: goto -> 313
    //   310: lconst_0
    //   311: lstore #9
    //   313: aload #15
    //   315: ldc 'ETag'
    //   317: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   322: checkcast java/lang/String
    //   325: astore #16
    //   327: iload_2
    //   328: ifeq -> 379
    //   331: lload #13
    //   333: lload #5
    //   335: ldc2_w 1000
    //   338: lmul
    //   339: ladd
    //   340: lstore #5
    //   342: iload_1
    //   343: ifeq -> 352
    //   346: lload #5
    //   348: lstore_3
    //   349: goto -> 366
    //   352: lload_3
    //   353: invokestatic signum : (J)I
    //   356: pop
    //   357: lload_3
    //   358: ldc2_w 1000
    //   361: lmul
    //   362: lload #5
    //   364: ladd
    //   365: lstore_3
    //   366: lload_3
    //   367: lstore #11
    //   369: lload #5
    //   371: lstore_3
    //   372: lload #11
    //   374: lstore #5
    //   376: goto -> 414
    //   379: lconst_0
    //   380: lstore #5
    //   382: lload #7
    //   384: lconst_0
    //   385: lcmp
    //   386: ifle -> 412
    //   389: lload #11
    //   391: lload #7
    //   393: lcmp
    //   394: iflt -> 412
    //   397: lload #13
    //   399: lload #11
    //   401: lload #7
    //   403: lsub
    //   404: ladd
    //   405: lstore_3
    //   406: lload_3
    //   407: lstore #5
    //   409: goto -> 414
    //   412: lconst_0
    //   413: lstore_3
    //   414: new com/android/volley/Cache$Entry
    //   417: dup
    //   418: invokespecial <init> : ()V
    //   421: astore #17
    //   423: aload #17
    //   425: aload_0
    //   426: getfield data : [B
    //   429: putfield data : [B
    //   432: aload #17
    //   434: aload #16
    //   436: putfield etag : Ljava/lang/String;
    //   439: aload #17
    //   441: lload_3
    //   442: putfield softTtl : J
    //   445: aload #17
    //   447: lload #5
    //   449: putfield ttl : J
    //   452: aload #17
    //   454: lload #7
    //   456: putfield serverDate : J
    //   459: aload #17
    //   461: lload #9
    //   463: putfield lastModified : J
    //   466: aload #17
    //   468: aload #15
    //   470: putfield responseHeaders : Ljava/util/Map;
    //   473: aload #17
    //   475: aload_0
    //   476: getfield allHeaders : Ljava/util/List;
    //   479: putfield allResponseHeaders : Ljava/util/List;
    //   482: aload #17
    //   484: areturn
    //   485: astore #17
    //   487: lload #5
    //   489: lstore #9
    //   491: lload_3
    //   492: lstore #11
    //   494: goto -> 221
    // Exception table:
    //   from	to	target	type
    //   138	150	485	java/lang/Exception
    //   166	178	485	java/lang/Exception
  }
  
  public static String parseCharset(Map<String, String> paramMap) {
    return parseCharset(paramMap, "ISO-8859-1");
  }
  
  public static String parseCharset(Map<String, String> paramMap, String paramString) {
    if (paramMap == null)
      return paramString; 
    String str = paramMap.get("Content-Type");
    if (str != null) {
      String[] arrayOfString = str.split(";", 0);
      for (int i = 1; i < arrayOfString.length; i++) {
        String[] arrayOfString1 = arrayOfString[i].trim().split("=", 0);
        if (arrayOfString1.length == 2 && arrayOfString1[0].equals("charset"))
          return arrayOfString1[1]; 
      } 
    } 
    return paramString;
  }
  
  public static long parseDateAsEpoch(String paramString) {
    try {
      return newUsGmtFormatter("EEE, dd MMM yyyy HH:mm:ss zzz").parse(paramString).getTime();
    } catch (ParseException parseException) {
      if ("0".equals(paramString) || "-1".equals(paramString)) {
        VolleyLog.v("Unable to parse dateStr: %s, falling back to 0", new Object[] { paramString });
        return 0L;
      } 
      VolleyLog.e(parseException, "Unable to parse dateStr: %s, falling back to 0", new Object[] { paramString });
    } 
    return 0L;
  }
  
  public static List<Header> toAllHeaderList(Map<String, String> paramMap) {
    ArrayList<Header> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, String> entry : paramMap.entrySet())
      arrayList.add(new Header((String)entry.getKey(), (String)entry.getValue())); 
    return arrayList;
  }
  
  public static Map<String, String> toHeaderMap(List<Header> paramList) {
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (Header header : paramList)
      treeMap.put(header.getName(), header.getValue()); 
    return (Map)treeMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\HttpHeaderParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */