package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.Header;
import com.android.volley.Network;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class BasicNetwork implements Network {
  private static final int DEFAULT_POOL_SIZE = 4096;
  
  private final BaseHttpStack mBaseHttpStack;
  
  @Deprecated
  public final HttpStack mHttpStack;
  
  public final ByteArrayPool mPool;
  
  public BasicNetwork(BaseHttpStack paramBaseHttpStack) {
    this(paramBaseHttpStack, new ByteArrayPool(4096));
  }
  
  public BasicNetwork(BaseHttpStack paramBaseHttpStack, ByteArrayPool paramByteArrayPool) {
    this.mBaseHttpStack = paramBaseHttpStack;
    this.mHttpStack = paramBaseHttpStack;
    this.mPool = paramByteArrayPool;
  }
  
  @Deprecated
  public BasicNetwork(HttpStack paramHttpStack) {
    this(paramHttpStack, new ByteArrayPool(4096));
  }
  
  @Deprecated
  public BasicNetwork(HttpStack paramHttpStack, ByteArrayPool paramByteArrayPool) {
    this.mHttpStack = paramHttpStack;
    this.mBaseHttpStack = new AdaptedHttpStack(paramHttpStack);
    this.mPool = paramByteArrayPool;
  }
  
  @Deprecated
  public static Map<String, String> convertHeaders(Header[] paramArrayOfHeader) {
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (int i = 0; i < paramArrayOfHeader.length; i++)
      treeMap.put(paramArrayOfHeader[i].getName(), paramArrayOfHeader[i].getValue()); 
    return (Map)treeMap;
  }
  
  public NetworkResponse performRequest(Request<?> paramRequest) {
    long l = SystemClock.elapsedRealtime();
    while (true) {
      IOException iOException;
      Map<String, String> map2;
      Collections.emptyList();
      Map<String, String> map1 = null;
      try {
        byte[] arrayOfByte;
        Map<String, String> map = HttpHeaderParser.getCacheHeaders(paramRequest.getCacheEntry());
        HttpResponse httpResponse = this.mBaseHttpStack.executeRequest(paramRequest, map);
        map = map1;
        try {
          byte[] arrayOfByte1;
          int i = httpResponse.getStatusCode();
          map = map1;
          List<Header> list = httpResponse.getHeaders();
          if (i == 304) {
            map = map1;
            return NetworkUtility.getNotModifiedNetworkResponse(paramRequest, SystemClock.elapsedRealtime() - l, list);
          } 
          map = map1;
          InputStream inputStream = httpResponse.getContent();
          if (inputStream != null) {
            map = map1;
            arrayOfByte1 = NetworkUtility.inputStreamToBytes(inputStream, httpResponse.getContentLength(), this.mPool);
          } else {
            byte[] arrayOfByte2 = arrayOfByte1;
            arrayOfByte1 = new byte[0];
          } 
          arrayOfByte = arrayOfByte1;
          NetworkUtility.logSlowRequests(SystemClock.elapsedRealtime() - l, paramRequest, arrayOfByte1, i);
          if (i >= 200 && i <= 299) {
            arrayOfByte = arrayOfByte1;
            return new NetworkResponse(i, arrayOfByte1, false, SystemClock.elapsedRealtime() - l, list);
          } 
          arrayOfByte = arrayOfByte1;
          throw new IOException();
        } catch (IOException iOException1) {
          HttpResponse httpResponse1 = httpResponse;
          iOException = iOException1;
          byte[] arrayOfByte1 = arrayOfByte;
        } 
      } catch (IOException iOException1) {
        map1 = null;
        map2 = map1;
        iOException = iOException1;
      } 
      NetworkUtility.attemptRetryOnException(paramRequest, NetworkUtility.shouldRetryException(paramRequest, iOException, l, (HttpResponse)map1, (byte[])map2));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\BasicNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */