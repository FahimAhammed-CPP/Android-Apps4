package com.android.volley.toolbox;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.VolleyLog;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicReference;

public abstract class AsyncHttpStack extends BaseHttpStack {
  private ExecutorService mBlockingExecutor;
  
  private ExecutorService mNonBlockingExecutor;
  
  public final HttpResponse executeRequest(Request<?> paramRequest, Map<String, String> paramMap) {
    final CountDownLatch latch = new CountDownLatch(1);
    final AtomicReference<Response> entry = new AtomicReference();
    executeRequest(paramRequest, paramMap, new OnRequestComplete() {
          public void onAuthError(AuthFailureError param1AuthFailureError) {
            AsyncHttpStack.Response response = new AsyncHttpStack.Response(null, null, param1AuthFailureError);
            entry.set(response);
            latch.countDown();
          }
          
          public void onError(IOException param1IOException) {
            AsyncHttpStack.Response response = new AsyncHttpStack.Response(null, param1IOException, null);
            entry.set(response);
            latch.countDown();
          }
          
          public void onSuccess(HttpResponse param1HttpResponse) {
            AsyncHttpStack.Response response = new AsyncHttpStack.Response(param1HttpResponse, null, null);
            entry.set(response);
            latch.countDown();
          }
        });
    try {
      countDownLatch.await();
      Response response = atomicReference.get();
      HttpResponse httpResponse = response.httpResponse;
      if (httpResponse != null)
        return httpResponse; 
      IOException iOException = response.ioException;
      if (iOException != null)
        throw iOException; 
      throw response.authFailureError;
    } catch (InterruptedException interruptedException) {
      VolleyLog.e(interruptedException, "while waiting for CountDownLatch", new Object[0]);
      Thread.currentThread().interrupt();
      throw new InterruptedIOException(interruptedException.toString());
    } 
  }
  
  public abstract void executeRequest(Request<?> paramRequest, Map<String, String> paramMap, OnRequestComplete paramOnRequestComplete);
  
  public ExecutorService getBlockingExecutor() {
    return this.mBlockingExecutor;
  }
  
  public ExecutorService getNonBlockingExecutor() {
    return this.mNonBlockingExecutor;
  }
  
  public void setBlockingExecutor(ExecutorService paramExecutorService) {
    this.mBlockingExecutor = paramExecutorService;
  }
  
  public void setNonBlockingExecutor(ExecutorService paramExecutorService) {
    this.mNonBlockingExecutor = paramExecutorService;
  }
  
  public static interface OnRequestComplete {
    void onAuthError(AuthFailureError param1AuthFailureError);
    
    void onError(IOException param1IOException);
    
    void onSuccess(HttpResponse param1HttpResponse);
  }
  
  public static class Response {
    public AuthFailureError authFailureError;
    
    public HttpResponse httpResponse;
    
    public IOException ioException;
    
    private Response(HttpResponse param1HttpResponse, IOException param1IOException, AuthFailureError param1AuthFailureError) {
      this.httpResponse = param1HttpResponse;
      this.ioException = param1IOException;
      this.authFailureError = param1AuthFailureError;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\AsyncHttpStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */