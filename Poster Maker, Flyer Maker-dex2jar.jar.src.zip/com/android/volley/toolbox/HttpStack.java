package com.android.volley.toolbox;

import com.android.volley.Request;
import java.util.Map;
import org.apache.http.HttpResponse;

@Deprecated
public interface HttpStack {
  HttpResponse performRequest(Request<?> paramRequest, Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\HttpStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */