package com.android.volley.toolbox;

import java.io.File;

public interface FileSupplier {
  File get();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\FileSupplier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */