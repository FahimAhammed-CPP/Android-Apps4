package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.AsyncNetwork;
import com.android.volley.AuthFailureError;
import com.android.volley.Header;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestTask;
import com.android.volley.VolleyError;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

public class BasicAsyncNetwork extends AsyncNetwork {
  private final AsyncHttpStack mAsyncStack;
  
  private final ByteArrayPool mPool;
  
  private BasicAsyncNetwork(AsyncHttpStack paramAsyncHttpStack, ByteArrayPool paramByteArrayPool) {
    this.mAsyncStack = paramAsyncHttpStack;
    this.mPool = paramByteArrayPool;
  }
  
  private void onRequestFailed(Request<?> paramRequest, AsyncNetwork.OnRequestComplete paramOnRequestComplete, IOException paramIOException, long paramLong, HttpResponse paramHttpResponse, byte[] paramArrayOfbyte) {
    try {
      NetworkUtility.RetryInfo retryInfo = NetworkUtility.shouldRetryException(paramRequest, paramIOException, paramLong, paramHttpResponse, paramArrayOfbyte);
      getBlockingExecutor().execute((Runnable)new InvokeRetryPolicyTask(paramRequest, retryInfo, paramOnRequestComplete));
      return;
    } catch (VolleyError volleyError) {
      paramOnRequestComplete.onError(volleyError);
      return;
    } 
  }
  
  private void onRequestSucceeded(Request<?> paramRequest, long paramLong, HttpResponse paramHttpResponse, AsyncNetwork.OnRequestComplete paramOnRequestComplete) {
    int i = paramHttpResponse.getStatusCode();
    List<Header> list = paramHttpResponse.getHeaders();
    if (i == 304) {
      paramOnRequestComplete.onSuccess(NetworkUtility.getNotModifiedNetworkResponse(paramRequest, SystemClock.elapsedRealtime() - paramLong, list));
      return;
    } 
    byte[] arrayOfByte2 = paramHttpResponse.getContentBytes();
    byte[] arrayOfByte1 = arrayOfByte2;
    if (arrayOfByte2 == null) {
      arrayOfByte1 = arrayOfByte2;
      if (paramHttpResponse.getContent() == null)
        arrayOfByte1 = new byte[0]; 
    } 
    if (arrayOfByte1 != null) {
      onResponseRead(paramLong, i, paramHttpResponse, paramRequest, paramOnRequestComplete, list, arrayOfByte1);
      return;
    } 
    InputStream inputStream = paramHttpResponse.getContent();
    getBlockingExecutor().execute((Runnable)new ResponseParsingTask(inputStream, paramHttpResponse, paramRequest, paramOnRequestComplete, paramLong, list, i));
  }
  
  private void onResponseRead(long paramLong, int paramInt, HttpResponse paramHttpResponse, Request<?> paramRequest, AsyncNetwork.OnRequestComplete paramOnRequestComplete, List<Header> paramList, byte[] paramArrayOfbyte) {
    NetworkUtility.logSlowRequests(SystemClock.elapsedRealtime() - paramLong, paramRequest, paramArrayOfbyte, paramInt);
    if (paramInt < 200 || paramInt > 299) {
      onRequestFailed(paramRequest, paramOnRequestComplete, new IOException(), paramLong, paramHttpResponse, paramArrayOfbyte);
      return;
    } 
    paramOnRequestComplete.onSuccess(new NetworkResponse(paramInt, paramArrayOfbyte, false, SystemClock.elapsedRealtime() - paramLong, paramList));
  }
  
  public void performRequest(final Request<?> request, final AsyncNetwork.OnRequestComplete callback) {
    if (getBlockingExecutor() != null) {
      final long requestStartMs = SystemClock.elapsedRealtime();
      Map<String, String> map = HttpHeaderParser.getCacheHeaders(request.getCacheEntry());
      this.mAsyncStack.executeRequest(request, map, new AsyncHttpStack.OnRequestComplete() {
            public void onAuthError(AuthFailureError param1AuthFailureError) {
              callback.onError((VolleyError)param1AuthFailureError);
            }
            
            public void onError(IOException param1IOException) {
              BasicAsyncNetwork.this.onRequestFailed(request, callback, param1IOException, requestStartMs, null, null);
            }
            
            public void onSuccess(HttpResponse param1HttpResponse) {
              BasicAsyncNetwork.this.onRequestSucceeded(request, requestStartMs, param1HttpResponse, callback);
            }
          });
      return;
    } 
    throw new IllegalStateException("mBlockingExecuter must be set before making a request");
  }
  
  public void setBlockingExecutor(ExecutorService paramExecutorService) {
    super.setBlockingExecutor(paramExecutorService);
    this.mAsyncStack.setBlockingExecutor(paramExecutorService);
  }
  
  public void setNonBlockingExecutor(ExecutorService paramExecutorService) {
    super.setNonBlockingExecutor(paramExecutorService);
    this.mAsyncStack.setNonBlockingExecutor(paramExecutorService);
  }
  
  public static class Builder {
    private static final int DEFAULT_POOL_SIZE = 4096;
    
    private AsyncHttpStack mAsyncStack;
    
    private ByteArrayPool mPool;
    
    public Builder(AsyncHttpStack param1AsyncHttpStack) {
      this.mAsyncStack = param1AsyncHttpStack;
      this.mPool = null;
    }
    
    public BasicAsyncNetwork build() {
      if (this.mPool == null)
        this.mPool = new ByteArrayPool(4096); 
      return new BasicAsyncNetwork(this.mAsyncStack, this.mPool);
    }
    
    public Builder setPool(ByteArrayPool param1ByteArrayPool) {
      this.mPool = param1ByteArrayPool;
      return this;
    }
  }
  
  public class InvokeRetryPolicyTask<T> extends RequestTask<T> {
    public final AsyncNetwork.OnRequestComplete callback;
    
    public final Request<T> request;
    
    public final NetworkUtility.RetryInfo retryInfo;
    
    public InvokeRetryPolicyTask(Request<T> param1Request, NetworkUtility.RetryInfo param1RetryInfo, AsyncNetwork.OnRequestComplete param1OnRequestComplete) {
      super(param1Request);
      this.request = param1Request;
      this.retryInfo = param1RetryInfo;
      this.callback = param1OnRequestComplete;
    }
    
    public void run() {
      try {
        NetworkUtility.attemptRetryOnException(this.request, this.retryInfo);
        BasicAsyncNetwork.this.performRequest(this.request, this.callback);
        return;
      } catch (VolleyError volleyError) {
        this.callback.onError(volleyError);
        return;
      } 
    }
  }
  
  public class ResponseParsingTask<T> extends RequestTask<T> {
    public AsyncNetwork.OnRequestComplete callback;
    
    public HttpResponse httpResponse;
    
    public InputStream inputStream;
    
    public Request<T> request;
    
    public long requestStartMs;
    
    public List<Header> responseHeaders;
    
    public int statusCode;
    
    public ResponseParsingTask(InputStream param1InputStream, HttpResponse param1HttpResponse, Request<T> param1Request, AsyncNetwork.OnRequestComplete param1OnRequestComplete, long param1Long, List<Header> param1List, int param1Int) {
      super(param1Request);
      this.inputStream = param1InputStream;
      this.httpResponse = param1HttpResponse;
      this.request = param1Request;
      this.callback = param1OnRequestComplete;
      this.requestStartMs = param1Long;
      this.responseHeaders = param1List;
      this.statusCode = param1Int;
    }
    
    public void run() {
      try {
        byte[] arrayOfByte = NetworkUtility.inputStreamToBytes(this.inputStream, this.httpResponse.getContentLength(), BasicAsyncNetwork.this.mPool);
        BasicAsyncNetwork.this.onResponseRead(this.requestStartMs, this.statusCode, this.httpResponse, this.request, this.callback, this.responseHeaders, arrayOfByte);
        return;
      } catch (IOException iOException) {
        BasicAsyncNetwork.this.onRequestFailed(this.request, this.callback, iOException, this.requestStartMs, this.httpResponse, null);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\BasicAsyncNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */