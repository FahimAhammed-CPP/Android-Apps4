package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.ClientError;
import com.android.volley.Header;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import s30;

public final class NetworkUtility {
  private static final int SLOW_REQUEST_THRESHOLD_MS = 3000;
  
  public static void attemptRetryOnException(Request<?> paramRequest, RetryInfo paramRetryInfo) {
    RetryPolicy retryPolicy = paramRequest.getRetryPolicy();
    int i = paramRequest.getTimeoutMs();
    try {
      retryPolicy.retry(paramRetryInfo.errorToRetry);
      paramRequest.addMarker(String.format("%s-retry [timeout=%s]", new Object[] { RetryInfo.access$100(paramRetryInfo), Integer.valueOf(i) }));
      return;
    } catch (VolleyError volleyError) {
      paramRequest.addMarker(String.format("%s-timeout-giveup [timeout=%s]", new Object[] { RetryInfo.access$100(paramRetryInfo), Integer.valueOf(i) }));
      throw volleyError;
    } 
  }
  
  public static NetworkResponse getNotModifiedNetworkResponse(Request<?> paramRequest, long paramLong, List<Header> paramList) {
    Cache.Entry entry = paramRequest.getCacheEntry();
    if (entry == null)
      return new NetworkResponse(304, null, true, paramLong, paramList); 
    paramList = HttpHeaderParser.combineHeaders(paramList, entry);
    return new NetworkResponse(304, entry.data, true, paramLong, paramList);
  }
  
  public static byte[] inputStreamToBytes(InputStream paramInputStream, int paramInt, ByteArrayPool paramByteArrayPool) {
    Exception exception;
    byte[] arrayOfByte;
    PoolingByteArrayOutputStream poolingByteArrayOutputStream = new PoolingByteArrayOutputStream(paramByteArrayPool, paramInt);
    try {
      arrayOfByte = paramByteArrayPool.getBuf(1024);
    } finally {
      exception = null;
    } 
    if (iOException != null)
      try {
        iOException.close();
      } catch (IOException iOException1) {
        VolleyLog.v("Error occurred when closing InputStream", new Object[0]);
      }  
    paramByteArrayPool.returnBuf(arrayOfByte);
    poolingByteArrayOutputStream.close();
    throw exception;
  }
  
  public static void logSlowRequests(long paramLong, Request<?> paramRequest, byte[] paramArrayOfbyte, int paramInt) {
    if (VolleyLog.DEBUG || paramLong > 3000L) {
      String str;
      if (paramArrayOfbyte != null) {
        Integer integer = Integer.valueOf(paramArrayOfbyte.length);
      } else {
        str = "null";
      } 
      VolleyLog.d("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", new Object[] { paramRequest, Long.valueOf(paramLong), str, Integer.valueOf(paramInt), Integer.valueOf(paramRequest.getRetryPolicy().getCurrentRetryCount()) });
    } 
  }
  
  public static RetryInfo shouldRetryException(Request<?> paramRequest, IOException paramIOException, long paramLong, HttpResponse paramHttpResponse, byte[] paramArrayOfbyte) {
    NetworkResponse networkResponse;
    if (paramIOException instanceof java.net.SocketTimeoutException)
      return new RetryInfo("socket", (VolleyError)new TimeoutError()); 
    if (!(paramIOException instanceof java.net.MalformedURLException)) {
      if (paramHttpResponse != null) {
        int i = paramHttpResponse.getStatusCode();
        VolleyLog.e("Unexpected response code %d for %s", new Object[] { Integer.valueOf(i), paramRequest.getUrl() });
        if (paramArrayOfbyte != null) {
          List<Header> list = paramHttpResponse.getHeaders();
          networkResponse = new NetworkResponse(i, paramArrayOfbyte, false, SystemClock.elapsedRealtime() - paramLong, list);
          if (i == 401 || i == 403)
            return new RetryInfo("auth", (VolleyError)new AuthFailureError(networkResponse)); 
          if (i < 400 || i > 499) {
            if (i >= 500 && i <= 599 && paramRequest.shouldRetryServerErrors())
              return new RetryInfo("server", (VolleyError)new ServerError(networkResponse)); 
            throw new ServerError(networkResponse);
          } 
          throw new ClientError(networkResponse);
        } 
        return new RetryInfo("network", (VolleyError)new NetworkError());
      } 
      if (paramRequest.shouldRetryConnectionErrors())
        return new RetryInfo("connection", (VolleyError)new NoConnectionError()); 
      throw new NoConnectionError(networkResponse);
    } 
    StringBuilder stringBuilder = s30.x0("Bad URL ");
    stringBuilder.append(paramRequest.getUrl());
    throw new RuntimeException(stringBuilder.toString(), networkResponse);
  }
  
  public static class RetryInfo {
    private final VolleyError errorToRetry;
    
    private final String logPrefix;
    
    private RetryInfo(String param1String, VolleyError param1VolleyError) {
      this.logPrefix = param1String;
      this.errorToRetry = param1VolleyError;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\NetworkUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */