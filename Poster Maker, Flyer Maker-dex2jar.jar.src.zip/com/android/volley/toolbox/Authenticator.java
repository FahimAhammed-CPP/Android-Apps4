package com.android.volley.toolbox;

public interface Authenticator {
  String getAuthToken();
  
  void invalidateAuthToken(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\Authenticator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */