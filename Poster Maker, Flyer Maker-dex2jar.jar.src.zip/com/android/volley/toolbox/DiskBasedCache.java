package com.android.volley.toolbox;

import android.os.SystemClock;
import com.android.volley.Cache;
import com.android.volley.Header;
import com.android.volley.VolleyLog;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import s30;

public class DiskBasedCache implements Cache {
  private static final int CACHE_MAGIC = 538247942;
  
  private static final int DEFAULT_DISK_USAGE_BYTES = 5242880;
  
  public static final float HYSTERESIS_FACTOR = 0.9F;
  
  private final Map<String, CacheHeader> mEntries = new LinkedHashMap<String, CacheHeader>(16, 0.75F, true);
  
  private final int mMaxCacheSizeInBytes;
  
  private final FileSupplier mRootDirectorySupplier;
  
  private long mTotalSize = 0L;
  
  public DiskBasedCache(FileSupplier paramFileSupplier) {
    this(paramFileSupplier, 5242880);
  }
  
  public DiskBasedCache(FileSupplier paramFileSupplier, int paramInt) {
    this.mRootDirectorySupplier = paramFileSupplier;
    this.mMaxCacheSizeInBytes = paramInt;
  }
  
  public DiskBasedCache(File paramFile) {
    this(paramFile, 5242880);
  }
  
  public DiskBasedCache(final File rootDirectory, int paramInt) {
    this.mRootDirectorySupplier = new FileSupplier() {
        public File get() {
          return rootDirectory;
        }
      };
    this.mMaxCacheSizeInBytes = paramInt;
  }
  
  private String getFilenameForKey(String paramString) {
    int i = paramString.length() / 2;
    StringBuilder stringBuilder = s30.x0(String.valueOf(paramString.substring(0, i).hashCode()));
    stringBuilder.append(String.valueOf(paramString.substring(i).hashCode()));
    return stringBuilder.toString();
  }
  
  private void initializeIfRootDirectoryDeleted() {
    if (!this.mRootDirectorySupplier.get().exists()) {
      VolleyLog.d("Re-initializing cache after external clearing.", new Object[0]);
      this.mEntries.clear();
      this.mTotalSize = 0L;
      initialize();
    } 
  }
  
  private void pruneIfNeeded() {
    int j;
    if (this.mTotalSize < this.mMaxCacheSizeInBytes)
      return; 
    if (VolleyLog.DEBUG)
      VolleyLog.v("Pruning old cache entries.", new Object[0]); 
    long l1 = this.mTotalSize;
    long l2 = SystemClock.elapsedRealtime();
    Iterator<Map.Entry> iterator = this.mEntries.entrySet().iterator();
    int i = 0;
    while (true) {
      j = i;
      if (iterator.hasNext()) {
        CacheHeader cacheHeader = (CacheHeader)((Map.Entry)iterator.next()).getValue();
        if (getFileForKey(cacheHeader.key).delete()) {
          this.mTotalSize -= cacheHeader.size;
        } else {
          String str = cacheHeader.key;
          VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", new Object[] { str, getFilenameForKey(str) });
        } 
        iterator.remove();
        j = i + 1;
        i = j;
        if ((float)this.mTotalSize < this.mMaxCacheSizeInBytes * 0.9F)
          break; 
        continue;
      } 
      break;
    } 
    if (VolleyLog.DEBUG)
      VolleyLog.v("pruned %d files, %d bytes, %d ms", new Object[] { Integer.valueOf(j), Long.valueOf(this.mTotalSize - l1), Long.valueOf(SystemClock.elapsedRealtime() - l2) }); 
  }
  
  private void putEntry(String paramString, CacheHeader paramCacheHeader) {
    if (!this.mEntries.containsKey(paramString)) {
      this.mTotalSize += paramCacheHeader.size;
    } else {
      CacheHeader cacheHeader = this.mEntries.get(paramString);
      long l = this.mTotalSize;
      this.mTotalSize = paramCacheHeader.size - cacheHeader.size + l;
    } 
    this.mEntries.put(paramString, paramCacheHeader);
  }
  
  private static int read(InputStream paramInputStream) {
    int i = paramInputStream.read();
    if (i != -1)
      return i; 
    throw new EOFException();
  }
  
  public static List<Header> readHeaderList(CountingInputStream paramCountingInputStream) {
    int i = readInt(paramCountingInputStream);
    if (i >= 0) {
      List<?> list;
      if (i == 0) {
        list = Collections.emptyList();
      } else {
        list = new ArrayList();
      } 
      for (int j = 0; j < i; j++)
        list.add(new Header(readString(paramCountingInputStream).intern(), readString(paramCountingInputStream).intern())); 
      return (List)list;
    } 
    IOException iOException = new IOException(s30.Z("readHeaderList size=", i));
    throw iOException;
  }
  
  public static int readInt(InputStream paramInputStream) {
    int i = read(paramInputStream);
    int j = read(paramInputStream);
    int k = read(paramInputStream);
    return read(paramInputStream) << 24 | i << 0 | 0x0 | j << 8 | k << 16;
  }
  
  public static long readLong(InputStream paramInputStream) {
    return (read(paramInputStream) & 0xFFL) << 0L | 0x0L | (read(paramInputStream) & 0xFFL) << 8L | (read(paramInputStream) & 0xFFL) << 16L | (read(paramInputStream) & 0xFFL) << 24L | (read(paramInputStream) & 0xFFL) << 32L | (read(paramInputStream) & 0xFFL) << 40L | (read(paramInputStream) & 0xFFL) << 48L | (0xFFL & read(paramInputStream)) << 56L;
  }
  
  public static String readString(CountingInputStream paramCountingInputStream) {
    return new String(streamToBytes(paramCountingInputStream, readLong(paramCountingInputStream)), "UTF-8");
  }
  
  private void removeEntry(String paramString) {
    CacheHeader cacheHeader = this.mEntries.remove(paramString);
    if (cacheHeader != null)
      this.mTotalSize -= cacheHeader.size; 
  }
  
  public static byte[] streamToBytes(CountingInputStream paramCountingInputStream, long paramLong) {
    long l = paramCountingInputStream.bytesRemaining();
    if (paramLong >= 0L && paramLong <= l) {
      int i = (int)paramLong;
      if (i == paramLong) {
        byte[] arrayOfByte = new byte[i];
        (new DataInputStream(paramCountingInputStream)).readFully(arrayOfByte);
        return arrayOfByte;
      } 
    } 
    StringBuilder stringBuilder = s30.B0("streamToBytes length=", paramLong, ", maxLength=");
    stringBuilder.append(l);
    throw new IOException(stringBuilder.toString());
  }
  
  public static void writeHeaderList(List<Header> paramList, OutputStream paramOutputStream) {
    if (paramList != null) {
      writeInt(paramOutputStream, paramList.size());
      for (Header header : paramList) {
        writeString(paramOutputStream, header.getName());
        writeString(paramOutputStream, header.getValue());
      } 
    } else {
      writeInt(paramOutputStream, 0);
    } 
  }
  
  public static void writeInt(OutputStream paramOutputStream, int paramInt) {
    paramOutputStream.write(paramInt >> 0 & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
    paramOutputStream.write(paramInt >> 16 & 0xFF);
    paramOutputStream.write(paramInt >> 24 & 0xFF);
  }
  
  public static void writeLong(OutputStream paramOutputStream, long paramLong) {
    paramOutputStream.write((byte)(int)(paramLong >>> 0L));
    paramOutputStream.write((byte)(int)(paramLong >>> 8L));
    paramOutputStream.write((byte)(int)(paramLong >>> 16L));
    paramOutputStream.write((byte)(int)(paramLong >>> 24L));
    paramOutputStream.write((byte)(int)(paramLong >>> 32L));
    paramOutputStream.write((byte)(int)(paramLong >>> 40L));
    paramOutputStream.write((byte)(int)(paramLong >>> 48L));
    paramOutputStream.write((byte)(int)(paramLong >>> 56L));
  }
  
  public static void writeString(OutputStream paramOutputStream, String paramString) {
    byte[] arrayOfByte = paramString.getBytes("UTF-8");
    writeLong(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
  }
  
  public void clear() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mRootDirectorySupplier : Lcom/android/volley/toolbox/DiskBasedCache$FileSupplier;
    //   6: invokeinterface get : ()Ljava/io/File;
    //   11: invokevirtual listFiles : ()[Ljava/io/File;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 43
    //   19: aload_3
    //   20: arraylength
    //   21: istore_2
    //   22: iconst_0
    //   23: istore_1
    //   24: iload_1
    //   25: iload_2
    //   26: if_icmpge -> 43
    //   29: aload_3
    //   30: iload_1
    //   31: aaload
    //   32: invokevirtual delete : ()Z
    //   35: pop
    //   36: iload_1
    //   37: iconst_1
    //   38: iadd
    //   39: istore_1
    //   40: goto -> 24
    //   43: aload_0
    //   44: getfield mEntries : Ljava/util/Map;
    //   47: invokeinterface clear : ()V
    //   52: aload_0
    //   53: lconst_0
    //   54: putfield mTotalSize : J
    //   57: ldc_w 'Cache cleared.'
    //   60: iconst_0
    //   61: anewarray java/lang/Object
    //   64: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: astore_3
    //   71: aload_0
    //   72: monitorexit
    //   73: goto -> 78
    //   76: aload_3
    //   77: athrow
    //   78: goto -> 76
    // Exception table:
    //   from	to	target	type
    //   2	15	70	finally
    //   19	22	70	finally
    //   29	36	70	finally
    //   43	67	70	finally
  }
  
  public InputStream createInputStream(File paramFile) {
    return new FileInputStream(paramFile);
  }
  
  public OutputStream createOutputStream(File paramFile) {
    return new FileOutputStream(paramFile);
  }
  
  public Cache.Entry get(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mEntries : Ljava/util/Map;
    //   6: aload_1
    //   7: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast com/android/volley/toolbox/DiskBasedCache$CacheHeader
    //   15: astore #4
    //   17: aload #4
    //   19: ifnonnull -> 26
    //   22: aload_0
    //   23: monitorexit
    //   24: aconst_null
    //   25: areturn
    //   26: aload_0
    //   27: aload_1
    //   28: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   31: astore_2
    //   32: new com/android/volley/toolbox/DiskBasedCache$CountingInputStream
    //   35: dup
    //   36: new java/io/BufferedInputStream
    //   39: dup
    //   40: aload_0
    //   41: aload_2
    //   42: invokevirtual createInputStream : (Ljava/io/File;)Ljava/io/InputStream;
    //   45: invokespecial <init> : (Ljava/io/InputStream;)V
    //   48: aload_2
    //   49: invokevirtual length : ()J
    //   52: invokespecial <init> : (Ljava/io/InputStream;J)V
    //   55: astore_3
    //   56: aload_3
    //   57: invokestatic readHeader : (Lcom/android/volley/toolbox/DiskBasedCache$CountingInputStream;)Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;
    //   60: astore #5
    //   62: aload_1
    //   63: aload #5
    //   65: getfield key : Ljava/lang/String;
    //   68: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   71: ifne -> 116
    //   74: ldc_w '%s: key=%s, found=%s'
    //   77: iconst_3
    //   78: anewarray java/lang/Object
    //   81: dup
    //   82: iconst_0
    //   83: aload_2
    //   84: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   87: aastore
    //   88: dup
    //   89: iconst_1
    //   90: aload_1
    //   91: aastore
    //   92: dup
    //   93: iconst_2
    //   94: aload #5
    //   96: getfield key : Ljava/lang/String;
    //   99: aastore
    //   100: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   103: aload_0
    //   104: aload_1
    //   105: invokespecial removeEntry : (Ljava/lang/String;)V
    //   108: aload_3
    //   109: invokevirtual close : ()V
    //   112: aload_0
    //   113: monitorexit
    //   114: aconst_null
    //   115: areturn
    //   116: aload #4
    //   118: aload_3
    //   119: aload_3
    //   120: invokevirtual bytesRemaining : ()J
    //   123: invokestatic streamToBytes : (Lcom/android/volley/toolbox/DiskBasedCache$CountingInputStream;J)[B
    //   126: invokevirtual toCacheEntry : ([B)Lcom/android/volley/Cache$Entry;
    //   129: astore #4
    //   131: aload_3
    //   132: invokevirtual close : ()V
    //   135: aload_0
    //   136: monitorexit
    //   137: aload #4
    //   139: areturn
    //   140: astore #4
    //   142: aload_3
    //   143: invokevirtual close : ()V
    //   146: aload #4
    //   148: athrow
    //   149: astore_3
    //   150: ldc_w '%s: %s'
    //   153: iconst_2
    //   154: anewarray java/lang/Object
    //   157: dup
    //   158: iconst_0
    //   159: aload_2
    //   160: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   163: aastore
    //   164: dup
    //   165: iconst_1
    //   166: aload_3
    //   167: invokevirtual toString : ()Ljava/lang/String;
    //   170: aastore
    //   171: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   174: aload_0
    //   175: aload_1
    //   176: invokevirtual remove : (Ljava/lang/String;)V
    //   179: aload_0
    //   180: monitorexit
    //   181: aconst_null
    //   182: areturn
    //   183: astore_1
    //   184: aload_0
    //   185: monitorexit
    //   186: aload_1
    //   187: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	183	finally
    //   26	32	183	finally
    //   32	56	149	java/io/IOException
    //   32	56	183	finally
    //   56	108	140	finally
    //   108	112	149	java/io/IOException
    //   108	112	183	finally
    //   116	131	140	finally
    //   131	135	149	java/io/IOException
    //   131	135	183	finally
    //   142	149	149	java/io/IOException
    //   142	149	183	finally
    //   150	179	183	finally
  }
  
  public File getFileForKey(String paramString) {
    return new File(this.mRootDirectorySupplier.get(), getFilenameForKey(paramString));
  }
  
  public void initialize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mRootDirectorySupplier : Lcom/android/volley/toolbox/DiskBasedCache$FileSupplier;
    //   6: invokeinterface get : ()Ljava/io/File;
    //   11: astore #6
    //   13: aload #6
    //   15: invokevirtual exists : ()Z
    //   18: istore_3
    //   19: iconst_0
    //   20: istore_1
    //   21: iload_3
    //   22: ifne -> 54
    //   25: aload #6
    //   27: invokevirtual mkdirs : ()Z
    //   30: ifne -> 51
    //   33: ldc_w 'Unable to create cache dir %s'
    //   36: iconst_1
    //   37: anewarray java/lang/Object
    //   40: dup
    //   41: iconst_0
    //   42: aload #6
    //   44: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   47: aastore
    //   48: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: aload #6
    //   56: invokevirtual listFiles : ()[Ljava/io/File;
    //   59: astore #6
    //   61: aload #6
    //   63: ifnonnull -> 69
    //   66: aload_0
    //   67: monitorexit
    //   68: return
    //   69: aload #6
    //   71: arraylength
    //   72: istore_2
    //   73: iload_1
    //   74: iload_2
    //   75: if_icmpge -> 171
    //   78: aload #6
    //   80: iload_1
    //   81: aaload
    //   82: astore #7
    //   84: aload #7
    //   86: invokevirtual length : ()J
    //   89: lstore #4
    //   91: new com/android/volley/toolbox/DiskBasedCache$CountingInputStream
    //   94: dup
    //   95: new java/io/BufferedInputStream
    //   98: dup
    //   99: aload_0
    //   100: aload #7
    //   102: invokevirtual createInputStream : (Ljava/io/File;)Ljava/io/InputStream;
    //   105: invokespecial <init> : (Ljava/io/InputStream;)V
    //   108: lload #4
    //   110: invokespecial <init> : (Ljava/io/InputStream;J)V
    //   113: astore #8
    //   115: aload #8
    //   117: invokestatic readHeader : (Lcom/android/volley/toolbox/DiskBasedCache$CountingInputStream;)Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;
    //   120: astore #9
    //   122: aload #9
    //   124: lload #4
    //   126: putfield size : J
    //   129: aload_0
    //   130: aload #9
    //   132: getfield key : Ljava/lang/String;
    //   135: aload #9
    //   137: invokespecial putEntry : (Ljava/lang/String;Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;)V
    //   140: aload #8
    //   142: invokevirtual close : ()V
    //   145: goto -> 164
    //   148: astore #9
    //   150: aload #8
    //   152: invokevirtual close : ()V
    //   155: aload #9
    //   157: athrow
    //   158: aload #7
    //   160: invokevirtual delete : ()Z
    //   163: pop
    //   164: iload_1
    //   165: iconst_1
    //   166: iadd
    //   167: istore_1
    //   168: goto -> 73
    //   171: aload_0
    //   172: monitorexit
    //   173: return
    //   174: astore #6
    //   176: aload_0
    //   177: monitorexit
    //   178: goto -> 184
    //   181: aload #6
    //   183: athrow
    //   184: goto -> 181
    //   187: astore #8
    //   189: goto -> 158
    // Exception table:
    //   from	to	target	type
    //   2	19	174	finally
    //   25	51	174	finally
    //   54	61	174	finally
    //   69	73	174	finally
    //   84	115	187	java/io/IOException
    //   84	115	174	finally
    //   115	140	148	finally
    //   140	145	187	java/io/IOException
    //   140	145	174	finally
    //   150	158	187	java/io/IOException
    //   150	158	174	finally
    //   158	164	174	finally
  }
  
  public void invalidate(String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual get : (Ljava/lang/String;)Lcom/android/volley/Cache$Entry;
    //   7: astore_3
    //   8: aload_3
    //   9: ifnull -> 32
    //   12: aload_3
    //   13: lconst_0
    //   14: putfield softTtl : J
    //   17: iload_2
    //   18: ifeq -> 26
    //   21: aload_3
    //   22: lconst_0
    //   23: putfield ttl : J
    //   26: aload_0
    //   27: aload_1
    //   28: aload_3
    //   29: invokevirtual put : (Ljava/lang/String;Lcom/android/volley/Cache$Entry;)V
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	35	finally
    //   12	17	35	finally
    //   21	26	35	finally
    //   26	32	35	finally
  }
  
  public void put(String paramString, Cache.Entry paramEntry) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTotalSize : J
    //   6: lstore #5
    //   8: aload_2
    //   9: getfield data : [B
    //   12: astore #9
    //   14: aload #9
    //   16: arraylength
    //   17: i2l
    //   18: lstore #7
    //   20: aload_0
    //   21: getfield mMaxCacheSizeInBytes : I
    //   24: istore_3
    //   25: lload #5
    //   27: lload #7
    //   29: ladd
    //   30: iload_3
    //   31: i2l
    //   32: lcmp
    //   33: ifle -> 56
    //   36: aload #9
    //   38: arraylength
    //   39: istore #4
    //   41: iload #4
    //   43: i2f
    //   44: iload_3
    //   45: i2f
    //   46: ldc 0.9
    //   48: fmul
    //   49: fcmpl
    //   50: ifle -> 56
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: aload_0
    //   57: aload_1
    //   58: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   61: astore #9
    //   63: new java/io/BufferedOutputStream
    //   66: dup
    //   67: aload_0
    //   68: aload #9
    //   70: invokevirtual createOutputStream : (Ljava/io/File;)Ljava/io/OutputStream;
    //   73: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   76: astore #10
    //   78: new com/android/volley/toolbox/DiskBasedCache$CacheHeader
    //   81: dup
    //   82: aload_1
    //   83: aload_2
    //   84: invokespecial <init> : (Ljava/lang/String;Lcom/android/volley/Cache$Entry;)V
    //   87: astore #11
    //   89: aload #11
    //   91: aload #10
    //   93: invokevirtual writeHeader : (Ljava/io/OutputStream;)Z
    //   96: ifeq -> 137
    //   99: aload #10
    //   101: aload_2
    //   102: getfield data : [B
    //   105: invokevirtual write : ([B)V
    //   108: aload #10
    //   110: invokevirtual close : ()V
    //   113: aload #11
    //   115: aload #9
    //   117: invokevirtual length : ()J
    //   120: putfield size : J
    //   123: aload_0
    //   124: aload_1
    //   125: aload #11
    //   127: invokespecial putEntry : (Ljava/lang/String;Lcom/android/volley/toolbox/DiskBasedCache$CacheHeader;)V
    //   130: aload_0
    //   131: invokespecial pruneIfNeeded : ()V
    //   134: goto -> 198
    //   137: aload #10
    //   139: invokevirtual close : ()V
    //   142: ldc_w 'Failed to write header for %s'
    //   145: iconst_1
    //   146: anewarray java/lang/Object
    //   149: dup
    //   150: iconst_0
    //   151: aload #9
    //   153: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   156: aastore
    //   157: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   160: new java/io/IOException
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: athrow
    //   168: aload #9
    //   170: invokevirtual delete : ()Z
    //   173: ifne -> 194
    //   176: ldc_w 'Could not clean up file %s'
    //   179: iconst_1
    //   180: anewarray java/lang/Object
    //   183: dup
    //   184: iconst_0
    //   185: aload #9
    //   187: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   190: aastore
    //   191: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   194: aload_0
    //   195: invokespecial initializeIfRootDirectoryDeleted : ()V
    //   198: aload_0
    //   199: monitorexit
    //   200: return
    //   201: astore_1
    //   202: aload_0
    //   203: monitorexit
    //   204: aload_1
    //   205: athrow
    //   206: astore_1
    //   207: goto -> 168
    // Exception table:
    //   from	to	target	type
    //   2	25	201	finally
    //   36	41	201	finally
    //   56	63	201	finally
    //   63	134	206	java/io/IOException
    //   63	134	201	finally
    //   137	168	206	java/io/IOException
    //   137	168	201	finally
    //   168	194	201	finally
    //   194	198	201	finally
  }
  
  public void remove(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual getFileForKey : (Ljava/lang/String;)Ljava/io/File;
    //   7: invokevirtual delete : ()Z
    //   10: istore_2
    //   11: aload_0
    //   12: aload_1
    //   13: invokespecial removeEntry : (Ljava/lang/String;)V
    //   16: iload_2
    //   17: ifne -> 41
    //   20: ldc 'Could not delete cache entry for key=%s, filename=%s'
    //   22: iconst_2
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: aload_1
    //   29: aastore
    //   30: dup
    //   31: iconst_1
    //   32: aload_0
    //   33: aload_1
    //   34: invokespecial getFilenameForKey : (Ljava/lang/String;)Ljava/lang/String;
    //   37: aastore
    //   38: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	44	finally
    //   20	41	44	finally
  }
  
  public static class CacheHeader {
    public final List<Header> allResponseHeaders;
    
    public final String etag;
    
    public final String key;
    
    public final long lastModified;
    
    public final long serverDate;
    
    public long size;
    
    public final long softTtl;
    
    public final long ttl;
    
    public CacheHeader(String param1String, Cache.Entry param1Entry) {
      this(param1String, param1Entry.etag, param1Entry.serverDate, param1Entry.lastModified, param1Entry.ttl, param1Entry.softTtl, getAllResponseHeaders(param1Entry));
    }
    
    private CacheHeader(String param1String1, String param1String2, long param1Long1, long param1Long2, long param1Long3, long param1Long4, List<Header> param1List) {
      this.key = param1String1;
      param1String1 = param1String2;
      if ("".equals(param1String2))
        param1String1 = null; 
      this.etag = param1String1;
      this.serverDate = param1Long1;
      this.lastModified = param1Long2;
      this.ttl = param1Long3;
      this.softTtl = param1Long4;
      this.allResponseHeaders = param1List;
    }
    
    private static List<Header> getAllResponseHeaders(Cache.Entry param1Entry) {
      List<Header> list = param1Entry.allResponseHeaders;
      return (list != null) ? list : HttpHeaderParser.toAllHeaderList(param1Entry.responseHeaders);
    }
    
    public static CacheHeader readHeader(DiskBasedCache.CountingInputStream param1CountingInputStream) {
      if (DiskBasedCache.readInt(param1CountingInputStream) == 538247942)
        return new CacheHeader(DiskBasedCache.readString(param1CountingInputStream), DiskBasedCache.readString(param1CountingInputStream), DiskBasedCache.readLong(param1CountingInputStream), DiskBasedCache.readLong(param1CountingInputStream), DiskBasedCache.readLong(param1CountingInputStream), DiskBasedCache.readLong(param1CountingInputStream), DiskBasedCache.readHeaderList(param1CountingInputStream)); 
      throw new IOException();
    }
    
    public Cache.Entry toCacheEntry(byte[] param1ArrayOfbyte) {
      Cache.Entry entry = new Cache.Entry();
      entry.data = param1ArrayOfbyte;
      entry.etag = this.etag;
      entry.serverDate = this.serverDate;
      entry.lastModified = this.lastModified;
      entry.ttl = this.ttl;
      entry.softTtl = this.softTtl;
      entry.responseHeaders = HttpHeaderParser.toHeaderMap(this.allResponseHeaders);
      entry.allResponseHeaders = Collections.unmodifiableList(this.allResponseHeaders);
      return entry;
    }
    
    public boolean writeHeader(OutputStream param1OutputStream) {
      try {
        DiskBasedCache.writeInt(param1OutputStream, 538247942);
        DiskBasedCache.writeString(param1OutputStream, this.key);
        String str2 = this.etag;
        String str1 = str2;
        if (str2 == null)
          str1 = ""; 
        DiskBasedCache.writeString(param1OutputStream, str1);
        DiskBasedCache.writeLong(param1OutputStream, this.serverDate);
        DiskBasedCache.writeLong(param1OutputStream, this.lastModified);
        DiskBasedCache.writeLong(param1OutputStream, this.ttl);
        DiskBasedCache.writeLong(param1OutputStream, this.softTtl);
        DiskBasedCache.writeHeaderList(this.allResponseHeaders, param1OutputStream);
        param1OutputStream.flush();
        return true;
      } catch (IOException iOException) {
        VolleyLog.d("%s", new Object[] { iOException.toString() });
        return false;
      } 
    }
  }
  
  public static class CountingInputStream extends FilterInputStream {
    private long bytesRead;
    
    private final long length;
    
    public CountingInputStream(InputStream param1InputStream, long param1Long) {
      super(param1InputStream);
      this.length = param1Long;
    }
    
    public long bytesRead() {
      return this.bytesRead;
    }
    
    public long bytesRemaining() {
      return this.length - this.bytesRead;
    }
    
    public int read() {
      int i = super.read();
      if (i != -1)
        this.bytesRead++; 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      param1Int1 = super.read(param1ArrayOfbyte, param1Int1, param1Int2);
      if (param1Int1 != -1)
        this.bytesRead += param1Int1; 
      return param1Int1;
    }
  }
  
  public static interface FileSupplier {
    File get();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\DiskBasedCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */