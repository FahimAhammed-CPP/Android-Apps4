package com.android.volley.toolbox;

import com.android.volley.Header;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public final class HttpResponse {
  private final InputStream mContent;
  
  private final byte[] mContentBytes;
  
  private final int mContentLength;
  
  private final List<Header> mHeaders;
  
  private final int mStatusCode;
  
  public HttpResponse(int paramInt, List<Header> paramList) {
    this(paramInt, paramList, -1, null);
  }
  
  public HttpResponse(int paramInt1, List<Header> paramList, int paramInt2, InputStream paramInputStream) {
    this.mStatusCode = paramInt1;
    this.mHeaders = paramList;
    this.mContentLength = paramInt2;
    this.mContent = paramInputStream;
    this.mContentBytes = null;
  }
  
  public HttpResponse(int paramInt, List<Header> paramList, byte[] paramArrayOfbyte) {
    this.mStatusCode = paramInt;
    this.mHeaders = paramList;
    this.mContentLength = paramArrayOfbyte.length;
    this.mContentBytes = paramArrayOfbyte;
    this.mContent = null;
  }
  
  public final InputStream getContent() {
    InputStream inputStream = this.mContent;
    return (inputStream != null) ? inputStream : ((this.mContentBytes != null) ? new ByteArrayInputStream(this.mContentBytes) : null);
  }
  
  public final byte[] getContentBytes() {
    return this.mContentBytes;
  }
  
  public final int getContentLength() {
    return this.mContentLength;
  }
  
  public final List<Header> getHeaders() {
    return Collections.unmodifiableList(this.mHeaders);
  }
  
  public final int getStatusCode() {
    return this.mStatusCode;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\HttpResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */