package com.android.volley.toolbox;

import com.android.volley.AsyncCache;
import com.android.volley.Cache;

public class NoAsyncCache extends AsyncCache {
  public void clear(AsyncCache.OnWriteCompleteCallback paramOnWriteCompleteCallback) {
    paramOnWriteCompleteCallback.onWriteComplete();
  }
  
  public void get(String paramString, AsyncCache.OnGetCompleteCallback paramOnGetCompleteCallback) {
    paramOnGetCompleteCallback.onGetComplete(null);
  }
  
  public void initialize(AsyncCache.OnWriteCompleteCallback paramOnWriteCompleteCallback) {
    paramOnWriteCompleteCallback.onWriteComplete();
  }
  
  public void invalidate(String paramString, boolean paramBoolean, AsyncCache.OnWriteCompleteCallback paramOnWriteCompleteCallback) {
    paramOnWriteCompleteCallback.onWriteComplete();
  }
  
  public void put(String paramString, Cache.Entry paramEntry, AsyncCache.OnWriteCompleteCallback paramOnWriteCompleteCallback) {
    paramOnWriteCompleteCallback.onWriteComplete();
  }
  
  public void remove(String paramString, AsyncCache.OnWriteCompleteCallback paramOnWriteCompleteCallback) {
    paramOnWriteCompleteCallback.onWriteComplete();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\toolbox\NoAsyncCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */