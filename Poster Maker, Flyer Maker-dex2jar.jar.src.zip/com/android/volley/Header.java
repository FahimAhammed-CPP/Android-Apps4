package com.android.volley;

import android.text.TextUtils;
import s30;

public final class Header {
  private final String mName;
  
  private final String mValue;
  
  public Header(String paramString1, String paramString2) {
    this.mName = paramString1;
    this.mValue = paramString2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (Header.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (TextUtils.equals(this.mName, ((Header)paramObject).mName) && TextUtils.equals(this.mValue, ((Header)paramObject).mValue));
    } 
    return false;
  }
  
  public final String getName() {
    return this.mName;
  }
  
  public final String getValue() {
    return this.mValue;
  }
  
  public int hashCode() {
    int i = this.mName.hashCode();
    return this.mValue.hashCode() + i * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = s30.x0("Header[name=");
    stringBuilder.append(this.mName);
    stringBuilder.append(",value=");
    return s30.o0(stringBuilder, this.mValue, "]");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\Header.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */