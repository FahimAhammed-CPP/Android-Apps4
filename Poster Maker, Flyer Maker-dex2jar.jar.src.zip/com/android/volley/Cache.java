package com.android.volley;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public interface Cache {
  void clear();
  
  Entry get(String paramString);
  
  void initialize();
  
  void invalidate(String paramString, boolean paramBoolean);
  
  void put(String paramString, Entry paramEntry);
  
  void remove(String paramString);
  
  public static class Entry {
    public List<Header> allResponseHeaders;
    
    public byte[] data;
    
    public String etag;
    
    public long lastModified;
    
    public Map<String, String> responseHeaders = Collections.emptyMap();
    
    public long serverDate;
    
    public long softTtl;
    
    public long ttl;
    
    public boolean isExpired() {
      return isExpired(System.currentTimeMillis());
    }
    
    public boolean isExpired(long param1Long) {
      return (this.ttl < param1Long);
    }
    
    public boolean refreshNeeded() {
      return refreshNeeded(System.currentTimeMillis());
    }
    
    public boolean refreshNeeded(long param1Long) {
      return (this.softTtl < param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\Cache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */