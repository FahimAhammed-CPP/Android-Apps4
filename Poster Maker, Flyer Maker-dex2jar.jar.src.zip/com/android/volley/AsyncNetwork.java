package com.android.volley;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicReference;

public abstract class AsyncNetwork implements Network {
  private ExecutorService mBlockingExecutor;
  
  private ExecutorService mNonBlockingExecutor;
  
  private ScheduledExecutorService mNonBlockingScheduledExecutor;
  
  public ExecutorService getBlockingExecutor() {
    return this.mBlockingExecutor;
  }
  
  public ExecutorService getNonBlockingExecutor() {
    return this.mNonBlockingExecutor;
  }
  
  public ScheduledExecutorService getNonBlockingScheduledExecutor() {
    return this.mNonBlockingScheduledExecutor;
  }
  
  public NetworkResponse performRequest(Request<?> paramRequest) {
    final CountDownLatch latch = new CountDownLatch(1);
    final AtomicReference<NetworkResponse> response = new AtomicReference();
    final AtomicReference error = new AtomicReference();
    performRequest(paramRequest, new OnRequestComplete() {
          public void onError(VolleyError param1VolleyError) {
            error.set(param1VolleyError);
            latch.countDown();
          }
          
          public void onSuccess(NetworkResponse param1NetworkResponse) {
            response.set(param1NetworkResponse);
            latch.countDown();
          }
        });
    try {
      countDownLatch.await();
      if (atomicReference.get() != null)
        return atomicReference.get(); 
      if (atomicReference1.get() != null)
        throw (VolleyError)atomicReference1.get(); 
      throw new VolleyError("Neither response entry was set");
    } catch (InterruptedException interruptedException) {
      VolleyLog.e(interruptedException, "while waiting for CountDownLatch", new Object[0]);
      Thread.currentThread().interrupt();
      throw new VolleyError(interruptedException);
    } 
  }
  
  public abstract void performRequest(Request<?> paramRequest, OnRequestComplete paramOnRequestComplete);
  
  public void setBlockingExecutor(ExecutorService paramExecutorService) {
    this.mBlockingExecutor = paramExecutorService;
  }
  
  public void setNonBlockingExecutor(ExecutorService paramExecutorService) {
    this.mNonBlockingExecutor = paramExecutorService;
  }
  
  public void setNonBlockingScheduledExecutor(ScheduledExecutorService paramScheduledExecutorService) {
    this.mNonBlockingScheduledExecutor = paramScheduledExecutorService;
  }
  
  public static interface OnRequestComplete {
    void onError(VolleyError param1VolleyError);
    
    void onSuccess(NetworkResponse param1NetworkResponse);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\AsyncNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */