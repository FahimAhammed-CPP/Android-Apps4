package com.android.volley;

public abstract class AsyncCache {
  public abstract void clear(OnWriteCompleteCallback paramOnWriteCompleteCallback);
  
  public abstract void get(String paramString, OnGetCompleteCallback paramOnGetCompleteCallback);
  
  public abstract void initialize(OnWriteCompleteCallback paramOnWriteCompleteCallback);
  
  public abstract void invalidate(String paramString, boolean paramBoolean, OnWriteCompleteCallback paramOnWriteCompleteCallback);
  
  public abstract void put(String paramString, Cache.Entry paramEntry, OnWriteCompleteCallback paramOnWriteCompleteCallback);
  
  public abstract void remove(String paramString, OnWriteCompleteCallback paramOnWriteCompleteCallback);
  
  public static interface OnGetCompleteCallback {
    void onGetComplete(Cache.Entry param1Entry);
  }
  
  public static interface OnWriteCompleteCallback {
    void onWriteComplete();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\AsyncCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */