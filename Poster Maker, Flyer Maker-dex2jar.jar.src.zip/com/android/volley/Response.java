package com.android.volley;

public class Response<T> {
  public final Cache.Entry cacheEntry = null;
  
  public final VolleyError error;
  
  public boolean intermediate = false;
  
  public final T result = null;
  
  private Response(VolleyError paramVolleyError) {
    this.error = paramVolleyError;
  }
  
  private Response(T paramT, Cache.Entry paramEntry) {
    this.error = null;
  }
  
  public static <T> Response<T> error(VolleyError paramVolleyError) {
    return new Response<T>(paramVolleyError);
  }
  
  public static <T> Response<T> success(T paramT, Cache.Entry paramEntry) {
    return new Response<T>(paramT, paramEntry);
  }
  
  public boolean isSuccess() {
    return (this.error == null);
  }
  
  public static interface ErrorListener {
    void onErrorResponse(VolleyError param1VolleyError);
  }
  
  public static interface Listener<T> {
    void onResponse(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */