package com.android.volley;

public abstract class RequestTask<T> implements Runnable {
  public final Request<T> mRequest;
  
  public RequestTask(Request<T> paramRequest) {
    this.mRequest = paramRequest;
  }
  
  public int compareTo(RequestTask<?> paramRequestTask) {
    return this.mRequest.compareTo(paramRequestTask.mRequest);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\RequestTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */