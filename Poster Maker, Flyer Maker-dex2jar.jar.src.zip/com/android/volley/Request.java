package com.android.volley;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Map;
import s30;

public abstract class Request<T> implements Comparable<Request<T>> {
  private static final String DEFAULT_PARAMS_ENCODING = "UTF-8";
  
  private Cache.Entry mCacheEntry;
  
  private boolean mCanceled;
  
  private final int mDefaultTrafficStatsTag;
  
  private Response.ErrorListener mErrorListener;
  
  private final VolleyLog.MarkerLog mEventLog;
  
  private final Object mLock;
  
  private final int mMethod;
  
  private NetworkRequestCompleteListener mRequestCompleteListener;
  
  private RequestQueue mRequestQueue;
  
  private boolean mResponseDelivered;
  
  private RetryPolicy mRetryPolicy;
  
  private Integer mSequence;
  
  private boolean mShouldCache;
  
  private boolean mShouldRetryConnectionErrors;
  
  private boolean mShouldRetryServerErrors;
  
  private Object mTag;
  
  private final String mUrl;
  
  public Request(int paramInt, String paramString, Response.ErrorListener paramErrorListener) {
    VolleyLog.MarkerLog markerLog;
    if (VolleyLog.MarkerLog.ENABLED) {
      markerLog = new VolleyLog.MarkerLog();
    } else {
      markerLog = null;
    } 
    this.mEventLog = markerLog;
    this.mLock = new Object();
    this.mShouldCache = true;
    this.mCanceled = false;
    this.mResponseDelivered = false;
    this.mShouldRetryServerErrors = false;
    this.mShouldRetryConnectionErrors = false;
    this.mCacheEntry = null;
    this.mMethod = paramInt;
    this.mUrl = paramString;
    this.mErrorListener = paramErrorListener;
    setRetryPolicy(new DefaultRetryPolicy());
    this.mDefaultTrafficStatsTag = findDefaultTrafficStatsTag(paramString);
  }
  
  @Deprecated
  public Request(String paramString, Response.ErrorListener paramErrorListener) {
    this(-1, paramString, paramErrorListener);
  }
  
  private byte[] encodeParameters(Map<String, String> paramMap, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    try {
      for (Map.Entry<String, String> entry : paramMap.entrySet()) {
        if (entry.getKey() != null && entry.getValue() != null) {
          stringBuilder.append(URLEncoder.encode((String)entry.getKey(), paramString));
          stringBuilder.append('=');
          stringBuilder.append(URLEncoder.encode((String)entry.getValue(), paramString));
          stringBuilder.append('&');
          continue;
        } 
        throw new IllegalArgumentException(String.format("Request#getParams() or Request#getPostParams() returned a map containing a null key or value: (%s, %s). All keys and values must be non-null.", new Object[] { entry.getKey(), entry.getValue() }));
      } 
      return stringBuilder.toString().getBytes(paramString);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      RuntimeException runtimeException = new RuntimeException(s30.g0("Encoding not supported: ", paramString), unsupportedEncodingException);
      throw runtimeException;
    } 
  }
  
  private static int findDefaultTrafficStatsTag(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      Uri uri = Uri.parse(paramString);
      if (uri != null) {
        String str = uri.getHost();
        if (str != null)
          return str.hashCode(); 
      } 
    } 
    return 0;
  }
  
  public void addMarker(String paramString) {
    if (VolleyLog.MarkerLog.ENABLED)
      this.mEventLog.add(paramString, Thread.currentThread().getId()); 
  }
  
  public void cancel() {
    synchronized (this.mLock) {
      this.mCanceled = true;
      this.mErrorListener = null;
      return;
    } 
  }
  
  public int compareTo(Request<T> paramRequest) {
    Priority priority1 = getPriority();
    Priority priority2 = paramRequest.getPriority();
    return (priority1 == priority2) ? (this.mSequence.intValue() - paramRequest.mSequence.intValue()) : (priority2.ordinal() - priority1.ordinal());
  }
  
  public void deliverError(VolleyError paramVolleyError) {
    synchronized (this.mLock) {
      Response.ErrorListener errorListener = this.mErrorListener;
      if (errorListener != null)
        errorListener.onErrorResponse(paramVolleyError); 
      return;
    } 
  }
  
  public abstract void deliverResponse(T paramT);
  
  public void finish(final String tag) {
    RequestQueue requestQueue = this.mRequestQueue;
    if (requestQueue != null)
      requestQueue.finish(this); 
    if (VolleyLog.MarkerLog.ENABLED) {
      final long threadId = Thread.currentThread().getId();
      if (Looper.myLooper() != Looper.getMainLooper()) {
        (new Handler(Looper.getMainLooper())).post(new Runnable() {
              public void run() {
                Request.this.mEventLog.add(tag, threadId);
                Request.this.mEventLog.finish(Request.this.toString());
              }
            });
        return;
      } 
      this.mEventLog.add(tag, l);
      this.mEventLog.finish(toString());
    } 
  }
  
  public byte[] getBody() {
    Map<String, String> map = getParams();
    return (map != null && map.size() > 0) ? encodeParameters(map, getParamsEncoding()) : null;
  }
  
  public String getBodyContentType() {
    StringBuilder stringBuilder = s30.x0("application/x-www-form-urlencoded; charset=");
    stringBuilder.append(getParamsEncoding());
    return stringBuilder.toString();
  }
  
  public Cache.Entry getCacheEntry() {
    return this.mCacheEntry;
  }
  
  public String getCacheKey() {
    String str2 = getUrl();
    int i = getMethod();
    String str1 = str2;
    if (i != 0) {
      if (i == -1)
        return str2; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Integer.toString(i));
      stringBuilder.append('-');
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
  
  public Response.ErrorListener getErrorListener() {
    synchronized (this.mLock) {
      return this.mErrorListener;
    } 
  }
  
  public Map<String, String> getHeaders() {
    return Collections.emptyMap();
  }
  
  public int getMethod() {
    return this.mMethod;
  }
  
  public Map<String, String> getParams() {
    return null;
  }
  
  public String getParamsEncoding() {
    return "UTF-8";
  }
  
  @Deprecated
  public byte[] getPostBody() {
    Map<String, String> map = getPostParams();
    return (map != null && map.size() > 0) ? encodeParameters(map, getPostParamsEncoding()) : null;
  }
  
  @Deprecated
  public String getPostBodyContentType() {
    return getBodyContentType();
  }
  
  @Deprecated
  public Map<String, String> getPostParams() {
    return getParams();
  }
  
  @Deprecated
  public String getPostParamsEncoding() {
    return getParamsEncoding();
  }
  
  public Priority getPriority() {
    return Priority.NORMAL;
  }
  
  public RetryPolicy getRetryPolicy() {
    return this.mRetryPolicy;
  }
  
  public final int getSequence() {
    Integer integer = this.mSequence;
    if (integer != null)
      return integer.intValue(); 
    throw new IllegalStateException("getSequence called before setSequence");
  }
  
  public Object getTag() {
    return this.mTag;
  }
  
  public final int getTimeoutMs() {
    return getRetryPolicy().getCurrentTimeout();
  }
  
  public int getTrafficStatsTag() {
    return this.mDefaultTrafficStatsTag;
  }
  
  public String getUrl() {
    return this.mUrl;
  }
  
  public boolean hasHadResponseDelivered() {
    synchronized (this.mLock) {
      return this.mResponseDelivered;
    } 
  }
  
  public boolean isCanceled() {
    synchronized (this.mLock) {
      return this.mCanceled;
    } 
  }
  
  public void markDelivered() {
    synchronized (this.mLock) {
      this.mResponseDelivered = true;
      return;
    } 
  }
  
  public void notifyListenerResponseNotUsable() {
    synchronized (this.mLock) {
      NetworkRequestCompleteListener networkRequestCompleteListener = this.mRequestCompleteListener;
      if (networkRequestCompleteListener != null)
        networkRequestCompleteListener.onNoUsableResponseReceived(this); 
      return;
    } 
  }
  
  public void notifyListenerResponseReceived(Response<?> paramResponse) {
    synchronized (this.mLock) {
      NetworkRequestCompleteListener networkRequestCompleteListener = this.mRequestCompleteListener;
      if (networkRequestCompleteListener != null)
        networkRequestCompleteListener.onResponseReceived(this, paramResponse); 
      return;
    } 
  }
  
  public VolleyError parseNetworkError(VolleyError paramVolleyError) {
    return paramVolleyError;
  }
  
  public abstract Response<T> parseNetworkResponse(NetworkResponse paramNetworkResponse);
  
  public void sendEvent(int paramInt) {
    RequestQueue requestQueue = this.mRequestQueue;
    if (requestQueue != null)
      requestQueue.sendRequestEvent(this, paramInt); 
  }
  
  public Request<?> setCacheEntry(Cache.Entry paramEntry) {
    this.mCacheEntry = paramEntry;
    return this;
  }
  
  public void setNetworkRequestCompleteListener(NetworkRequestCompleteListener paramNetworkRequestCompleteListener) {
    synchronized (this.mLock) {
      this.mRequestCompleteListener = paramNetworkRequestCompleteListener;
      return;
    } 
  }
  
  public Request<?> setRequestQueue(RequestQueue paramRequestQueue) {
    this.mRequestQueue = paramRequestQueue;
    return this;
  }
  
  public Request<?> setRetryPolicy(RetryPolicy paramRetryPolicy) {
    this.mRetryPolicy = paramRetryPolicy;
    return this;
  }
  
  public final Request<?> setSequence(int paramInt) {
    this.mSequence = Integer.valueOf(paramInt);
    return this;
  }
  
  public final Request<?> setShouldCache(boolean paramBoolean) {
    this.mShouldCache = paramBoolean;
    return this;
  }
  
  public final Request<?> setShouldRetryConnectionErrors(boolean paramBoolean) {
    this.mShouldRetryConnectionErrors = paramBoolean;
    return this;
  }
  
  public final Request<?> setShouldRetryServerErrors(boolean paramBoolean) {
    this.mShouldRetryServerErrors = paramBoolean;
    return this;
  }
  
  public Request<?> setTag(Object paramObject) {
    this.mTag = paramObject;
    return this;
  }
  
  public final boolean shouldCache() {
    return this.mShouldCache;
  }
  
  public final boolean shouldRetryConnectionErrors() {
    return this.mShouldRetryConnectionErrors;
  }
  
  public final boolean shouldRetryServerErrors() {
    return this.mShouldRetryServerErrors;
  }
  
  public String toString() {
    String str1;
    StringBuilder stringBuilder1 = s30.x0("0x");
    stringBuilder1.append(Integer.toHexString(getTrafficStatsTag()));
    String str2 = stringBuilder1.toString();
    StringBuilder stringBuilder2 = new StringBuilder();
    if (isCanceled()) {
      str1 = "[X] ";
    } else {
      str1 = "[ ] ";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append(getUrl());
    stringBuilder2.append(" ");
    stringBuilder2.append(str2);
    stringBuilder2.append(" ");
    stringBuilder2.append(getPriority());
    stringBuilder2.append(" ");
    stringBuilder2.append(this.mSequence);
    return stringBuilder2.toString();
  }
  
  public static interface Method {
    public static final int DELETE = 3;
    
    public static final int DEPRECATED_GET_OR_POST = -1;
    
    public static final int GET = 0;
    
    public static final int HEAD = 4;
    
    public static final int OPTIONS = 5;
    
    public static final int PATCH = 7;
    
    public static final int POST = 1;
    
    public static final int PUT = 2;
    
    public static final int TRACE = 6;
  }
  
  public static interface NetworkRequestCompleteListener {
    void onNoUsableResponseReceived(Request<?> param1Request);
    
    void onResponseReceived(Request<?> param1Request, Response<?> param1Response);
  }
  
  public enum Priority {
    HIGH, IMMEDIATE, LOW, NORMAL;
    
    static {
      Priority priority1 = new Priority("LOW", 0);
      LOW = priority1;
      Priority priority2 = new Priority("NORMAL", 1);
      NORMAL = priority2;
      Priority priority3 = new Priority("HIGH", 2);
      HIGH = priority3;
      Priority priority4 = new Priority("IMMEDIATE", 3);
      IMMEDIATE = priority4;
      $VALUES = new Priority[] { priority1, priority2, priority3, priority4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\android\volley\Request.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */