package com.davemorrissey.labs.subscaleview;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Objects;
import s30;

public final class ImageSource {
  public static final String ASSET_SCHEME = "file:///android_asset/";
  
  public static final String FILE_SCHEME = "file:///";
  
  private final Bitmap bitmap;
  
  private boolean cached;
  
  private final Integer resource;
  
  private int sHeight;
  
  private Rect sRegion;
  
  private int sWidth;
  
  private boolean tile;
  
  private final Uri uri;
  
  private ImageSource(int paramInt) {
    this.bitmap = null;
    this.uri = null;
    this.resource = Integer.valueOf(paramInt);
    this.tile = true;
  }
  
  private ImageSource(Bitmap paramBitmap, boolean paramBoolean) {
    this.bitmap = paramBitmap;
    this.uri = null;
    this.resource = null;
    this.tile = false;
    this.sWidth = paramBitmap.getWidth();
    this.sHeight = paramBitmap.getHeight();
    this.cached = paramBoolean;
  }
  
  private ImageSource(Uri paramUri) {
    String str = paramUri.toString();
    Uri uri = paramUri;
    uri = paramUri;
    if (str.startsWith("file:///") && !(new File(str.substring(7))).exists())
      try {
        uri = Uri.parse(URLDecoder.decode(str, "UTF-8"));
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        uri = paramUri;
      }  
    this.bitmap = null;
    this.uri = uri;
    this.resource = null;
    this.tile = true;
  }
  
  public static ImageSource asset(String paramString) {
    Objects.requireNonNull(paramString, "Asset name must not be null");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("file:///android_asset/");
    stringBuilder.append(paramString);
    return uri(stringBuilder.toString());
  }
  
  public static ImageSource bitmap(Bitmap paramBitmap) {
    Objects.requireNonNull(paramBitmap, "Bitmap must not be null");
    return new ImageSource(paramBitmap, false);
  }
  
  public static ImageSource cachedBitmap(Bitmap paramBitmap) {
    Objects.requireNonNull(paramBitmap, "Bitmap must not be null");
    return new ImageSource(paramBitmap, true);
  }
  
  public static ImageSource resource(int paramInt) {
    return new ImageSource(paramInt);
  }
  
  private void setInvariants() {
    Rect rect = this.sRegion;
    if (rect != null) {
      this.tile = true;
      this.sWidth = rect.width();
      this.sHeight = this.sRegion.height();
    } 
  }
  
  public static ImageSource uri(Uri paramUri) {
    Objects.requireNonNull(paramUri, "Uri must not be null");
    return new ImageSource(paramUri);
  }
  
  public static ImageSource uri(String paramString) {
    Objects.requireNonNull(paramString, "Uri must not be null");
    String str = paramString;
    if (!paramString.contains("://")) {
      str = paramString;
      if (paramString.startsWith("/"))
        str = paramString.substring(1); 
      str = s30.g0("file:///", str);
    } 
    return new ImageSource(Uri.parse(str));
  }
  
  public ImageSource dimensions(int paramInt1, int paramInt2) {
    if (this.bitmap == null) {
      this.sWidth = paramInt1;
      this.sHeight = paramInt2;
    } 
    setInvariants();
    return this;
  }
  
  public final Bitmap getBitmap() {
    return this.bitmap;
  }
  
  public final Integer getResource() {
    return this.resource;
  }
  
  public final int getSHeight() {
    return this.sHeight;
  }
  
  public final Rect getSRegion() {
    return this.sRegion;
  }
  
  public final int getSWidth() {
    return this.sWidth;
  }
  
  public final boolean getTile() {
    return this.tile;
  }
  
  public final Uri getUri() {
    return this.uri;
  }
  
  public final boolean isCached() {
    return this.cached;
  }
  
  public ImageSource region(Rect paramRect) {
    this.sRegion = paramRect;
    setInvariants();
    return this;
  }
  
  public ImageSource tiling(boolean paramBoolean) {
    this.tile = paramBoolean;
    return this;
  }
  
  public ImageSource tilingDisabled() {
    return tiling(false);
  }
  
  public ImageSource tilingEnabled() {
    return tiling(true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\ImageSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */