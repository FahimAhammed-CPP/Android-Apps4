package com.davemorrissey.labs.subscaleview;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.davemorrissey.labs.subscaleview";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = 1;
  
  public static final String VERSION_NAME = "1.0";
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */