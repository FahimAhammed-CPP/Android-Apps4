package com.davemorrissey.labs.subscaleview;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import bh;
import com.davemorrissey.labs.subscaleview.decoder.CompatDecoderFactory;
import com.davemorrissey.labs.subscaleview.decoder.DecoderFactory;
import com.davemorrissey.labs.subscaleview.decoder.ImageDecoder;
import com.davemorrissey.labs.subscaleview.decoder.ImageRegionDecoder;
import com.davemorrissey.labs.subscaleview.decoder.SkiaImageDecoder;
import com.davemorrissey.labs.subscaleview.decoder.SkiaImageRegionDecoder;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import s30;

public class SubsamplingScaleImageView extends View {
  public static final int EASE_IN_OUT_QUAD = 2;
  
  public static final int EASE_OUT_QUAD = 1;
  
  private static final int MESSAGE_LONG_CLICK = 1;
  
  public static final int ORIENTATION_0 = 0;
  
  public static final int ORIENTATION_180 = 180;
  
  public static final int ORIENTATION_270 = 270;
  
  public static final int ORIENTATION_90 = 90;
  
  public static final int ORIENTATION_USE_EXIF = -1;
  
  public static final int ORIGIN_ANIM = 1;
  
  public static final int ORIGIN_DOUBLE_TAP_ZOOM = 4;
  
  public static final int ORIGIN_FLING = 3;
  
  public static final int ORIGIN_TOUCH = 2;
  
  public static final int PAN_LIMIT_CENTER = 3;
  
  public static final int PAN_LIMIT_INSIDE = 1;
  
  public static final int PAN_LIMIT_OUTSIDE = 2;
  
  public static final int SCALE_TYPE_CENTER_CROP = 2;
  
  public static final int SCALE_TYPE_CENTER_INSIDE = 1;
  
  public static final int SCALE_TYPE_CUSTOM = 3;
  
  public static final int SCALE_TYPE_START = 4;
  
  private static final String TAG = SubsamplingScaleImageView.class.getSimpleName();
  
  public static final int TILE_SIZE_AUTO = 2147483647;
  
  private static final List<Integer> VALID_EASING_STYLES;
  
  private static final List<Integer> VALID_ORIENTATIONS = Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(90), Integer.valueOf(180), Integer.valueOf(270), Integer.valueOf(-1) });
  
  private static final List<Integer> VALID_PAN_LIMITS;
  
  private static final List<Integer> VALID_SCALE_TYPES;
  
  private static final List<Integer> VALID_ZOOM_STYLES;
  
  public static final int ZOOM_FOCUS_CENTER = 2;
  
  public static final int ZOOM_FOCUS_CENTER_IMMEDIATE = 3;
  
  public static final int ZOOM_FOCUS_FIXED = 1;
  
  private static Bitmap.Config preferredBitmapConfig;
  
  private Anim anim;
  
  private Bitmap bitmap;
  
  private DecoderFactory<? extends ImageDecoder> bitmapDecoderFactory = (DecoderFactory<? extends ImageDecoder>)new CompatDecoderFactory(SkiaImageDecoder.class);
  
  private boolean bitmapIsCached;
  
  private boolean bitmapIsPreview;
  
  private Paint bitmapPaint;
  
  private boolean debug;
  
  private Paint debugLinePaint;
  
  private Paint debugTextPaint;
  
  private ImageRegionDecoder decoder;
  
  private final ReadWriteLock decoderLock = new ReentrantReadWriteLock(true);
  
  private final float density = (getResources().getDisplayMetrics()).density;
  
  private GestureDetector detector;
  
  private int doubleTapZoomDuration = 500;
  
  private float doubleTapZoomScale = 1.0F;
  
  private int doubleTapZoomStyle = 1;
  
  private final float[] dstArray = new float[8];
  
  private boolean eagerLoadingEnabled = true;
  
  private Executor executor = AsyncTask.THREAD_POOL_EXECUTOR;
  
  private int fullImageSampleSize;
  
  private final Handler handler;
  
  private boolean imageLoadedSent;
  
  private boolean isPanning;
  
  private boolean isQuickScaling;
  
  private boolean isZooming;
  
  private Matrix matrix;
  
  private float maxScale = 2.0F;
  
  private int maxTileHeight = Integer.MAX_VALUE;
  
  private int maxTileWidth = Integer.MAX_VALUE;
  
  private int maxTouchCount;
  
  private float minScale = minScale();
  
  private int minimumScaleType = 1;
  
  private int minimumTileDpi = -1;
  
  private OnImageEventListener onImageEventListener;
  
  private View.OnLongClickListener onLongClickListener;
  
  private OnStateChangedListener onStateChangedListener;
  
  private int orientation = 0;
  
  private Rect pRegion;
  
  private boolean panEnabled = true;
  
  private int panLimit = 1;
  
  private Float pendingScale;
  
  private boolean quickScaleEnabled = true;
  
  private float quickScaleLastDistance;
  
  private boolean quickScaleMoved;
  
  private PointF quickScaleSCenter;
  
  private final float quickScaleThreshold;
  
  private PointF quickScaleVLastPoint;
  
  private PointF quickScaleVStart;
  
  private boolean readySent;
  
  private DecoderFactory<? extends ImageRegionDecoder> regionDecoderFactory = (DecoderFactory<? extends ImageRegionDecoder>)new CompatDecoderFactory(SkiaImageRegionDecoder.class);
  
  private int sHeight;
  
  private int sOrientation;
  
  private PointF sPendingCenter;
  
  private RectF sRect;
  
  private Rect sRegion;
  
  private PointF sRequestedCenter;
  
  private int sWidth;
  
  private ScaleAndTranslate satTemp;
  
  private float scale;
  
  private float scaleStart;
  
  private GestureDetector singleDetector;
  
  private final float[] srcArray = new float[8];
  
  private Paint tileBgPaint;
  
  private Map<Integer, List<Tile>> tileMap;
  
  private Uri uri;
  
  private PointF vCenterStart;
  
  private float vDistStart;
  
  private PointF vTranslate;
  
  private PointF vTranslateBefore;
  
  private PointF vTranslateStart;
  
  private boolean zoomEnabled = true;
  
  static {
    VALID_ZOOM_STYLES = Arrays.asList(new Integer[] { integer1, integer2, integer3 });
    VALID_EASING_STYLES = Arrays.asList(new Integer[] { integer2, integer1 });
    VALID_PAN_LIMITS = Arrays.asList(new Integer[] { integer1, integer2, integer3 });
    VALID_SCALE_TYPES = Arrays.asList(new Integer[] { integer2, integer1, integer3, Integer.valueOf(4) });
  }
  
  public SubsamplingScaleImageView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SubsamplingScaleImageView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setMinimumDpi(160);
    setDoubleTapZoomDpi(160);
    setMinimumTileDpi(320);
    setGestureDetector(paramContext);
    this.handler = new Handler(new Handler.Callback() {
          public boolean handleMessage(Message param1Message) {
            if (param1Message.what == 1 && SubsamplingScaleImageView.this.onLongClickListener != null) {
              SubsamplingScaleImageView.access$102(SubsamplingScaleImageView.this, 0);
              SubsamplingScaleImageView subsamplingScaleImageView = SubsamplingScaleImageView.this;
              subsamplingScaleImageView.setOnLongClickListener(subsamplingScaleImageView.onLongClickListener);
              SubsamplingScaleImageView.this.performLongClick();
              SubsamplingScaleImageView.this.setOnLongClickListener(null);
            } 
            return true;
          }
        });
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.SubsamplingScaleImageView);
      int i = R.styleable.SubsamplingScaleImageView_assetName;
      if (typedArray.hasValue(i)) {
        String str = typedArray.getString(i);
        if (str != null && str.length() > 0)
          setImage(ImageSource.asset(str).tilingEnabled()); 
      } 
      i = R.styleable.SubsamplingScaleImageView_src;
      if (typedArray.hasValue(i)) {
        i = typedArray.getResourceId(i, 0);
        if (i > 0)
          setImage(ImageSource.resource(i).tilingEnabled()); 
      } 
      i = R.styleable.SubsamplingScaleImageView_panEnabled;
      if (typedArray.hasValue(i))
        setPanEnabled(typedArray.getBoolean(i, true)); 
      i = R.styleable.SubsamplingScaleImageView_zoomEnabled;
      if (typedArray.hasValue(i))
        setZoomEnabled(typedArray.getBoolean(i, true)); 
      i = R.styleable.SubsamplingScaleImageView_quickScaleEnabled;
      if (typedArray.hasValue(i))
        setQuickScaleEnabled(typedArray.getBoolean(i, true)); 
      i = R.styleable.SubsamplingScaleImageView_tileBackgroundColor;
      if (typedArray.hasValue(i))
        setTileBackgroundColor(typedArray.getColor(i, Color.argb(0, 0, 0, 0))); 
      typedArray.recycle();
    } 
    this.quickScaleThreshold = TypedValue.applyDimension(1, 20.0F, paramContext.getResources().getDisplayMetrics());
  }
  
  private int calculateInSampleSize(float paramFloat) {
    float f = paramFloat;
    if (this.minimumTileDpi > 0) {
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      f = (displayMetrics.xdpi + displayMetrics.ydpi) / 2.0F;
      f = paramFloat * this.minimumTileDpi / f;
    } 
    int k = (int)(sWidth() * f);
    int i = (int)(sHeight() * f);
    if (k == 0 || i == 0)
      return 32; 
    int m = sHeight();
    int j = 1;
    if (m > i || sWidth() > k) {
      i = Math.round(sHeight() / i);
      k = Math.round(sWidth() / k);
      if (i >= k)
        i = k; 
    } else {
      i = 1;
    } 
    while (true) {
      k = j * 2;
      if (k < i) {
        j = k;
        continue;
      } 
      return j;
    } 
  }
  
  private boolean checkImageLoaded() {
    boolean bool = isBaseLayerReady();
    if (!this.imageLoadedSent && bool) {
      preDraw();
      this.imageLoadedSent = true;
      onImageLoaded();
      OnImageEventListener onImageEventListener = this.onImageEventListener;
      if (onImageEventListener != null)
        onImageEventListener.onImageLoaded(); 
    } 
    return bool;
  }
  
  private boolean checkReady() {
    boolean bool;
    if (getWidth() > 0 && getHeight() > 0 && this.sWidth > 0 && this.sHeight > 0 && (this.bitmap != null || isBaseLayerReady())) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!this.readySent && bool) {
      preDraw();
      this.readySent = true;
      onReady();
      OnImageEventListener onImageEventListener = this.onImageEventListener;
      if (onImageEventListener != null)
        onImageEventListener.onReady(); 
    } 
    return bool;
  }
  
  private void createPaints() {
    if (this.bitmapPaint == null) {
      Paint paint = new Paint();
      this.bitmapPaint = paint;
      paint.setAntiAlias(true);
      this.bitmapPaint.setFilterBitmap(true);
      this.bitmapPaint.setDither(true);
    } 
    if ((this.debugTextPaint == null || this.debugLinePaint == null) && this.debug) {
      Paint paint = new Paint();
      this.debugTextPaint = paint;
      paint.setTextSize(px(12));
      this.debugTextPaint.setColor(-65281);
      this.debugTextPaint.setStyle(Paint.Style.FILL);
      paint = new Paint();
      this.debugLinePaint = paint;
      paint.setColor(-65281);
      this.debugLinePaint.setStyle(Paint.Style.STROKE);
      this.debugLinePaint.setStrokeWidth(px(1));
    } 
  }
  
  private void debug(String paramString, Object... paramVarArgs) {
    if (this.debug)
      String.format(paramString, paramVarArgs); 
  }
  
  private float distance(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 -= paramFloat2;
    paramFloat2 = paramFloat3 - paramFloat4;
    return (float)Math.sqrt((paramFloat2 * paramFloat2 + paramFloat1 * paramFloat1));
  }
  
  private void doubleTapZoom(PointF paramPointF1, PointF paramPointF2) {
    boolean bool;
    if (!this.panEnabled) {
      PointF pointF = this.sRequestedCenter;
      if (pointF != null) {
        paramPointF1.x = pointF.x;
        paramPointF1.y = pointF.y;
      } else {
        paramPointF1.x = (sWidth() / 2);
        paramPointF1.y = (sHeight() / 2);
      } 
    } 
    float f1 = Math.min(this.maxScale, this.doubleTapZoomScale);
    float f2 = this.scale;
    double d1 = f2;
    double d2 = f1;
    Double.isNaN(d2);
    if (d1 <= d2 * 0.9D || f2 == this.minScale) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      f1 = minScale(); 
    int i = this.doubleTapZoomStyle;
    if (i == 3) {
      setScaleAndCenter(f1, paramPointF1);
    } else if (i == 2 || !bool || !this.panEnabled) {
      (new AnimationBuilder(f1, paramPointF1)).withInterruptible(false).withDuration(this.doubleTapZoomDuration).withOrigin(4).start();
    } else if (i == 1) {
      (new AnimationBuilder(f1, paramPointF1, paramPointF2)).withInterruptible(false).withDuration(this.doubleTapZoomDuration).withOrigin(4).start();
    } 
    invalidate();
  }
  
  private float ease(int paramInt, long paramLong1, float paramFloat1, float paramFloat2, long paramLong2) {
    if (paramInt != 1) {
      if (paramInt == 2)
        return easeInOutQuad(paramLong1, paramFloat1, paramFloat2, paramLong2); 
      throw new IllegalStateException(s30.Z("Unexpected easing type: ", paramInt));
    } 
    return easeOutQuad(paramLong1, paramFloat1, paramFloat2, paramLong2);
  }
  
  private float easeInOutQuad(long paramLong1, float paramFloat1, float paramFloat2, long paramLong2) {
    float f = (float)paramLong1 / (float)paramLong2 / 2.0F;
    if (f < 1.0F)
      return paramFloat2 / 2.0F * f * f + paramFloat1; 
    f--;
    return ((f - 2.0F) * f - 1.0F) * -paramFloat2 / 2.0F + paramFloat1;
  }
  
  private float easeOutQuad(long paramLong1, float paramFloat1, float paramFloat2, long paramLong2) {
    float f = (float)paramLong1 / (float)paramLong2;
    return s30.R(f, 2.0F, -paramFloat2 * f, paramFloat1);
  }
  
  private void execute(AsyncTask<Void, Void, ?> paramAsyncTask) {
    paramAsyncTask.executeOnExecutor(this.executor, (Object[])new Void[0]);
  }
  
  private void fileSRect(Rect paramRect1, Rect paramRect2) {
    if (getRequiredRotation() == 0) {
      paramRect2.set(paramRect1);
      return;
    } 
    if (getRequiredRotation() == 90) {
      int j = paramRect1.top;
      int k = this.sHeight;
      paramRect2.set(j, k - paramRect1.right, paramRect1.bottom, k - paramRect1.left);
      return;
    } 
    if (getRequiredRotation() == 180) {
      int j = this.sWidth;
      int k = paramRect1.right;
      int m = this.sHeight;
      paramRect2.set(j - k, m - paramRect1.bottom, j - paramRect1.left, m - paramRect1.top);
      return;
    } 
    int i = this.sWidth;
    paramRect2.set(i - paramRect1.bottom, paramRect1.left, i - paramRect1.top, paramRect1.right);
  }
  
  private void fitToBounds(boolean paramBoolean) {
    boolean bool;
    if (this.vTranslate == null) {
      bool = true;
      this.vTranslate = new PointF(0.0F, 0.0F);
    } else {
      bool = false;
    } 
    if (this.satTemp == null)
      this.satTemp = new ScaleAndTranslate(0.0F, new PointF(0.0F, 0.0F)); 
    ScaleAndTranslate.access$4702(this.satTemp, this.scale);
    this.satTemp.vTranslate.set(this.vTranslate);
    fitToBounds(paramBoolean, this.satTemp);
    this.scale = this.satTemp.scale;
    this.vTranslate.set(this.satTemp.vTranslate);
    if (bool && this.minimumScaleType != 4)
      this.vTranslate.set(vTranslateForSCenter((sWidth() / 2), (sHeight() / 2), this.scale)); 
  }
  
  private void fitToBounds(boolean paramBoolean, ScaleAndTranslate paramScaleAndTranslate) {
    boolean bool = paramBoolean;
    if (this.panLimit == 2) {
      bool = paramBoolean;
      if (isReady())
        bool = false; 
    } 
    PointF pointF = paramScaleAndTranslate.vTranslate;
    float f4 = limitedScale(paramScaleAndTranslate.scale);
    float f3 = sWidth() * f4;
    float f5 = sHeight() * f4;
    if (this.panLimit == 3 && isReady()) {
      pointF.x = Math.max(pointF.x, (getWidth() / 2) - f3);
      pointF.y = Math.max(pointF.y, (getHeight() / 2) - f5);
    } else if (bool) {
      pointF.x = Math.max(pointF.x, getWidth() - f3);
      pointF.y = Math.max(pointF.y, getHeight() - f5);
    } else {
      pointF.x = Math.max(pointF.x, -f3);
      pointF.y = Math.max(pointF.y, -f5);
    } 
    int i = getPaddingLeft();
    float f2 = 0.5F;
    if (i > 0 || getPaddingRight() > 0) {
      f1 = getPaddingLeft();
      i = getPaddingLeft();
      f1 /= (getPaddingRight() + i);
    } else {
      f1 = 0.5F;
    } 
    if (getPaddingTop() > 0 || getPaddingBottom() > 0) {
      f2 = getPaddingTop();
      i = getPaddingTop();
      f2 /= (getPaddingBottom() + i);
    } 
    if (this.panLimit == 3 && isReady()) {
      f1 = Math.max(0, getWidth() / 2);
      i = Math.max(0, getHeight() / 2);
    } else {
      if (bool) {
        f3 = Math.max(0.0F, (getWidth() - f3) * f1);
        f1 = Math.max(0.0F, (getHeight() - f5) * f2);
        f2 = f3;
      } else {
        f1 = Math.max(0, getWidth());
        i = Math.max(0, getHeight());
        f3 = i;
        f2 = f1;
        f1 = f3;
      } 
      pointF.x = Math.min(pointF.x, f2);
      pointF.y = Math.min(pointF.y, f1);
      ScaleAndTranslate.access$4702(paramScaleAndTranslate, f4);
      return;
    } 
    f3 = i;
    f2 = f1;
    float f1 = f3;
  }
  
  private int getExifOrientation(Context paramContext, String paramString) {
    boolean bool = paramString.startsWith("content");
    boolean bool2 = false;
    boolean bool1 = false;
    int i = 0;
    if (bool) {
      Cursor cursor1 = null;
      Cursor cursor2 = null;
      try {
        Cursor cursor = paramContext.getContentResolver().query(Uri.parse(paramString), new String[] { "orientation" }, null, null, null);
        int j = i;
        if (cursor != null) {
          j = i;
          cursor2 = cursor;
          cursor1 = cursor;
          if (cursor.moveToFirst()) {
            cursor2 = cursor;
            cursor1 = cursor;
            int k = cursor.getInt(0);
            cursor2 = cursor;
            cursor1 = cursor;
            bool = VALID_ORIENTATIONS.contains(Integer.valueOf(k));
            j = i;
            if (bool) {
              j = i;
              if (k != -1)
                j = k; 
            } 
          } 
        } 
        i = j;
      } catch (Exception exception) {
        i = bool1;
      } finally {
        if (cursor2 != null)
          cursor2.close(); 
      } 
    } else {
      i = bool1;
      if (paramString.startsWith("file:///")) {
        i = bool1;
        if (!paramString.startsWith("file:///android_asset/"))
          try {
            int j = (new bh(paramString.substring(7))).k("Orientation", 1);
            i = bool1;
            if (j != 1) {
              if (j == 0)
                return 0; 
              if (j == 6)
                return 90; 
              if (j == 3)
                return 180; 
              i = bool1;
              if (j == 8)
                i = 270; 
            } 
            return i;
          } catch (Exception exception) {
            return 0;
          }  
      } 
    } 
    return i;
  }
  
  private Point getMaxBitmapDimensions(Canvas paramCanvas) {
    return new Point(Math.min(paramCanvas.getMaximumBitmapWidth(), this.maxTileWidth), Math.min(paramCanvas.getMaximumBitmapHeight(), this.maxTileHeight));
  }
  
  public static Bitmap.Config getPreferredBitmapConfig() {
    return preferredBitmapConfig;
  }
  
  private int getRequiredRotation() {
    int j = this.orientation;
    int i = j;
    if (j == -1)
      i = this.sOrientation; 
    return i;
  }
  
  private void initialiseBaseLayer(Point paramPoint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 'initialiseBaseLayer maxTileDimensions=%dx%d'
    //   6: iconst_2
    //   7: anewarray java/lang/Object
    //   10: dup
    //   11: iconst_0
    //   12: aload_1
    //   13: getfield x : I
    //   16: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   19: aastore
    //   20: dup
    //   21: iconst_1
    //   22: aload_1
    //   23: getfield y : I
    //   26: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   29: aastore
    //   30: invokespecial debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   33: new com/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$ScaleAndTranslate
    //   36: dup
    //   37: fconst_0
    //   38: new android/graphics/PointF
    //   41: dup
    //   42: fconst_0
    //   43: fconst_0
    //   44: invokespecial <init> : (FF)V
    //   47: aconst_null
    //   48: invokespecial <init> : (FLandroid/graphics/PointF;Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$1;)V
    //   51: astore_3
    //   52: aload_0
    //   53: aload_3
    //   54: putfield satTemp : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$ScaleAndTranslate;
    //   57: aload_0
    //   58: iconst_1
    //   59: aload_3
    //   60: invokespecial fitToBounds : (ZLcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$ScaleAndTranslate;)V
    //   63: aload_0
    //   64: aload_0
    //   65: getfield satTemp : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$ScaleAndTranslate;
    //   68: invokestatic access$4700 : (Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$ScaleAndTranslate;)F
    //   71: invokespecial calculateInSampleSize : (F)I
    //   74: istore_2
    //   75: aload_0
    //   76: iload_2
    //   77: putfield fullImageSampleSize : I
    //   80: iload_2
    //   81: iconst_1
    //   82: if_icmple -> 92
    //   85: aload_0
    //   86: iload_2
    //   87: iconst_2
    //   88: idiv
    //   89: putfield fullImageSampleSize : I
    //   92: aload_0
    //   93: getfield fullImageSampleSize : I
    //   96: iconst_1
    //   97: if_icmpne -> 171
    //   100: aload_0
    //   101: getfield sRegion : Landroid/graphics/Rect;
    //   104: ifnonnull -> 171
    //   107: aload_0
    //   108: invokespecial sWidth : ()I
    //   111: aload_1
    //   112: getfield x : I
    //   115: if_icmpge -> 171
    //   118: aload_0
    //   119: invokespecial sHeight : ()I
    //   122: aload_1
    //   123: getfield y : I
    //   126: if_icmpge -> 171
    //   129: aload_0
    //   130: getfield decoder : Lcom/davemorrissey/labs/subscaleview/decoder/ImageRegionDecoder;
    //   133: invokeinterface recycle : ()V
    //   138: aload_0
    //   139: aconst_null
    //   140: putfield decoder : Lcom/davemorrissey/labs/subscaleview/decoder/ImageRegionDecoder;
    //   143: aload_0
    //   144: new com/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$BitmapLoadTask
    //   147: dup
    //   148: aload_0
    //   149: aload_0
    //   150: invokevirtual getContext : ()Landroid/content/Context;
    //   153: aload_0
    //   154: getfield bitmapDecoderFactory : Lcom/davemorrissey/labs/subscaleview/decoder/DecoderFactory;
    //   157: aload_0
    //   158: getfield uri : Landroid/net/Uri;
    //   161: iconst_0
    //   162: invokespecial <init> : (Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView;Landroid/content/Context;Lcom/davemorrissey/labs/subscaleview/decoder/DecoderFactory;Landroid/net/Uri;Z)V
    //   165: invokespecial execute : (Landroid/os/AsyncTask;)V
    //   168: goto -> 245
    //   171: aload_0
    //   172: aload_1
    //   173: invokespecial initialiseTileMap : (Landroid/graphics/Point;)V
    //   176: aload_0
    //   177: getfield tileMap : Ljava/util/Map;
    //   180: aload_0
    //   181: getfield fullImageSampleSize : I
    //   184: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   187: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   192: checkcast java/util/List
    //   195: invokeinterface iterator : ()Ljava/util/Iterator;
    //   200: astore_1
    //   201: aload_1
    //   202: invokeinterface hasNext : ()Z
    //   207: ifeq -> 240
    //   210: aload_1
    //   211: invokeinterface next : ()Ljava/lang/Object;
    //   216: checkcast com/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$Tile
    //   219: astore_3
    //   220: aload_0
    //   221: new com/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$TileLoadTask
    //   224: dup
    //   225: aload_0
    //   226: aload_0
    //   227: getfield decoder : Lcom/davemorrissey/labs/subscaleview/decoder/ImageRegionDecoder;
    //   230: aload_3
    //   231: invokespecial <init> : (Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView;Lcom/davemorrissey/labs/subscaleview/decoder/ImageRegionDecoder;Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$Tile;)V
    //   234: invokespecial execute : (Landroid/os/AsyncTask;)V
    //   237: goto -> 201
    //   240: aload_0
    //   241: iconst_1
    //   242: invokespecial refreshRequiredTiles : (Z)V
    //   245: aload_0
    //   246: monitorexit
    //   247: return
    //   248: astore_1
    //   249: aload_0
    //   250: monitorexit
    //   251: goto -> 256
    //   254: aload_1
    //   255: athrow
    //   256: goto -> 254
    // Exception table:
    //   from	to	target	type
    //   2	80	248	finally
    //   85	92	248	finally
    //   92	168	248	finally
    //   171	201	248	finally
    //   201	237	248	finally
    //   240	245	248	finally
  }
  
  private void initialiseTileMap(Point paramPoint) {
    debug("initialiseTileMap maxTileDimensions=%dx%d", new Object[] { Integer.valueOf(paramPoint.x), Integer.valueOf(paramPoint.y) });
    this.tileMap = new LinkedHashMap<Integer, List<Tile>>();
    int i = this.fullImageSampleSize;
    int j = 1;
    int k = 1;
    label50: while (true) {
      int m = sWidth() / j;
      int i1 = sHeight() / k;
      int n = m / i;
      int i2 = i1 / i;
      while (true) {
        if (n + j + 1 <= paramPoint.x) {
          double d1 = n;
          double d2 = getWidth();
          Double.isNaN(d2);
          n = k;
          int i3 = i1;
          int i4 = i2;
          if (d1 > d2 * 1.25D) {
            n = k;
            i3 = i1;
            i4 = i2;
            if (i < this.fullImageSampleSize)
              continue; 
          } 
          while (true) {
            if (i4 + n + 1 <= paramPoint.y) {
              d1 = i4;
              d2 = getHeight();
              Double.isNaN(d2);
              if (d1 <= d2 * 1.25D || i >= this.fullImageSampleSize) {
                ArrayList<Tile> arrayList = new ArrayList(j * n);
                for (k = 0; k < j; k++) {
                  for (i4 = 0; i4 < n; i4++) {
                    boolean bool;
                    Tile tile = new Tile();
                    Tile.access$4302(tile, i);
                    if (i == this.fullImageSampleSize) {
                      bool = true;
                    } else {
                      bool = false;
                    } 
                    Tile.access$402(tile, bool);
                    if (k == j - 1) {
                      i1 = sWidth();
                    } else {
                      i1 = (k + 1) * m;
                    } 
                    if (i4 == n - 1) {
                      i2 = sHeight();
                    } else {
                      i2 = (i4 + 1) * i3;
                    } 
                    Tile.access$4102(tile, new Rect(k * m, i4 * i3, i1, i2));
                    Tile.access$4202(tile, new Rect(0, 0, 0, 0));
                    Tile.access$5002(tile, new Rect(tile.sRect));
                    arrayList.add(tile);
                  } 
                } 
                this.tileMap.put(Integer.valueOf(i), arrayList);
                if (i == 1)
                  return; 
                i /= 2;
                k = n;
                continue label50;
              } 
            } 
            i3 = sHeight() / ++n;
            i4 = i3 / i;
          } 
          break;
        } 
        continue;
        m = sWidth() / ++j;
        n = m / i;
      } 
      break;
    } 
  }
  
  private boolean isBaseLayerReady() {
    Bitmap bitmap = this.bitmap;
    boolean bool = true;
    if (bitmap != null && !this.bitmapIsPreview)
      return true; 
    Map<Integer, List<Tile>> map = this.tileMap;
    if (map != null) {
      label23: for (Map.Entry<Integer, List<Tile>> entry : map.entrySet()) {
        if (((Integer)entry.getKey()).intValue() == this.fullImageSampleSize) {
          Iterator<Tile> iterator = ((List)entry.getValue()).iterator();
          boolean bool1 = bool;
          while (true) {
            bool = bool1;
            if (iterator.hasNext()) {
              Tile tile = iterator.next();
              if (tile.loading || tile.bitmap == null)
                bool1 = false; 
              continue;
            } 
            continue label23;
          } 
        } 
      } 
      return bool;
    } 
    return false;
  }
  
  private PointF limitedSCenter(float paramFloat1, float paramFloat2, float paramFloat3, PointF paramPointF) {
    PointF pointF = vTranslateForSCenter(paramFloat1, paramFloat2, paramFloat3);
    int i = getPaddingLeft();
    int j = (getWidth() - getPaddingRight() - getPaddingLeft()) / 2;
    int k = getPaddingTop();
    int m = (getHeight() - getPaddingBottom() - getPaddingTop()) / 2;
    paramPointF.set(((j + i) - pointF.x) / paramFloat3, ((m + k) - pointF.y) / paramFloat3);
    return paramPointF;
  }
  
  private float limitedScale(float paramFloat) {
    paramFloat = Math.max(minScale(), paramFloat);
    return Math.min(this.maxScale, paramFloat);
  }
  
  private float minScale() {
    int i = getPaddingBottom();
    i = getPaddingTop() + i;
    int j = getPaddingLeft();
    j = getPaddingRight() + j;
    int k = this.minimumScaleType;
    if (k == 2 || k == 4)
      return Math.max((getWidth() - j) / sWidth(), (getHeight() - i) / sHeight()); 
    if (k == 3) {
      float f = this.minScale;
      if (f > 0.0F)
        return f; 
    } 
    return Math.min((getWidth() - j) / sWidth(), (getHeight() - i) / sHeight());
  }
  
  private void onImageLoaded(Bitmap paramBitmap, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 'onImageLoaded'
    //   6: iconst_0
    //   7: anewarray java/lang/Object
    //   10: invokespecial debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   13: aload_0
    //   14: getfield sWidth : I
    //   17: istore #4
    //   19: iload #4
    //   21: ifle -> 56
    //   24: aload_0
    //   25: getfield sHeight : I
    //   28: ifle -> 56
    //   31: iload #4
    //   33: aload_1
    //   34: invokevirtual getWidth : ()I
    //   37: if_icmpne -> 51
    //   40: aload_0
    //   41: getfield sHeight : I
    //   44: aload_1
    //   45: invokevirtual getHeight : ()I
    //   48: if_icmpeq -> 56
    //   51: aload_0
    //   52: iconst_0
    //   53: invokespecial reset : (Z)V
    //   56: aload_0
    //   57: getfield bitmap : Landroid/graphics/Bitmap;
    //   60: astore #6
    //   62: aload #6
    //   64: ifnull -> 79
    //   67: aload_0
    //   68: getfield bitmapIsCached : Z
    //   71: ifne -> 79
    //   74: aload #6
    //   76: invokevirtual recycle : ()V
    //   79: aload_0
    //   80: getfield bitmap : Landroid/graphics/Bitmap;
    //   83: ifnull -> 111
    //   86: aload_0
    //   87: getfield bitmapIsCached : Z
    //   90: ifeq -> 111
    //   93: aload_0
    //   94: getfield onImageEventListener : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$OnImageEventListener;
    //   97: astore #6
    //   99: aload #6
    //   101: ifnull -> 111
    //   104: aload #6
    //   106: invokeinterface onPreviewReleased : ()V
    //   111: aload_0
    //   112: iconst_0
    //   113: putfield bitmapIsPreview : Z
    //   116: aload_0
    //   117: iload_3
    //   118: putfield bitmapIsCached : Z
    //   121: aload_0
    //   122: aload_1
    //   123: putfield bitmap : Landroid/graphics/Bitmap;
    //   126: aload_0
    //   127: aload_1
    //   128: invokevirtual getWidth : ()I
    //   131: putfield sWidth : I
    //   134: aload_0
    //   135: aload_1
    //   136: invokevirtual getHeight : ()I
    //   139: putfield sHeight : I
    //   142: aload_0
    //   143: iload_2
    //   144: putfield sOrientation : I
    //   147: aload_0
    //   148: invokespecial checkReady : ()Z
    //   151: istore_3
    //   152: aload_0
    //   153: invokespecial checkImageLoaded : ()Z
    //   156: istore #5
    //   158: iload_3
    //   159: ifne -> 167
    //   162: iload #5
    //   164: ifeq -> 175
    //   167: aload_0
    //   168: invokevirtual invalidate : ()V
    //   171: aload_0
    //   172: invokevirtual requestLayout : ()V
    //   175: aload_0
    //   176: monitorexit
    //   177: return
    //   178: astore_1
    //   179: aload_0
    //   180: monitorexit
    //   181: aload_1
    //   182: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	178	finally
    //   24	51	178	finally
    //   51	56	178	finally
    //   56	62	178	finally
    //   67	79	178	finally
    //   79	99	178	finally
    //   104	111	178	finally
    //   111	158	178	finally
    //   167	175	178	finally
  }
  
  private void onPreviewLoaded(Bitmap paramBitmap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 'onPreviewLoaded'
    //   6: iconst_0
    //   7: anewarray java/lang/Object
    //   10: invokespecial debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   13: aload_0
    //   14: getfield bitmap : Landroid/graphics/Bitmap;
    //   17: ifnonnull -> 97
    //   20: aload_0
    //   21: getfield imageLoadedSent : Z
    //   24: ifeq -> 30
    //   27: goto -> 97
    //   30: aload_0
    //   31: getfield pRegion : Landroid/graphics/Rect;
    //   34: astore_2
    //   35: aload_2
    //   36: ifnull -> 69
    //   39: aload_0
    //   40: aload_1
    //   41: aload_2
    //   42: getfield left : I
    //   45: aload_2
    //   46: getfield top : I
    //   49: aload_2
    //   50: invokevirtual width : ()I
    //   53: aload_0
    //   54: getfield pRegion : Landroid/graphics/Rect;
    //   57: invokevirtual height : ()I
    //   60: invokestatic createBitmap : (Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;
    //   63: putfield bitmap : Landroid/graphics/Bitmap;
    //   66: goto -> 74
    //   69: aload_0
    //   70: aload_1
    //   71: putfield bitmap : Landroid/graphics/Bitmap;
    //   74: aload_0
    //   75: iconst_1
    //   76: putfield bitmapIsPreview : Z
    //   79: aload_0
    //   80: invokespecial checkReady : ()Z
    //   83: ifeq -> 94
    //   86: aload_0
    //   87: invokevirtual invalidate : ()V
    //   90: aload_0
    //   91: invokevirtual requestLayout : ()V
    //   94: aload_0
    //   95: monitorexit
    //   96: return
    //   97: aload_1
    //   98: invokevirtual recycle : ()V
    //   101: aload_0
    //   102: monitorexit
    //   103: return
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	104	finally
    //   30	35	104	finally
    //   39	66	104	finally
    //   69	74	104	finally
    //   74	94	104	finally
    //   97	101	104	finally
  }
  
  private void onTileLoaded() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 'onTileLoaded'
    //   6: iconst_0
    //   7: anewarray java/lang/Object
    //   10: invokespecial debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   13: aload_0
    //   14: invokespecial checkReady : ()Z
    //   17: pop
    //   18: aload_0
    //   19: invokespecial checkImageLoaded : ()Z
    //   22: pop
    //   23: aload_0
    //   24: invokespecial isBaseLayerReady : ()Z
    //   27: ifeq -> 87
    //   30: aload_0
    //   31: getfield bitmap : Landroid/graphics/Bitmap;
    //   34: astore_1
    //   35: aload_1
    //   36: ifnull -> 87
    //   39: aload_0
    //   40: getfield bitmapIsCached : Z
    //   43: ifne -> 50
    //   46: aload_1
    //   47: invokevirtual recycle : ()V
    //   50: aload_0
    //   51: aconst_null
    //   52: putfield bitmap : Landroid/graphics/Bitmap;
    //   55: aload_0
    //   56: getfield onImageEventListener : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$OnImageEventListener;
    //   59: astore_1
    //   60: aload_1
    //   61: ifnull -> 77
    //   64: aload_0
    //   65: getfield bitmapIsCached : Z
    //   68: ifeq -> 77
    //   71: aload_1
    //   72: invokeinterface onPreviewReleased : ()V
    //   77: aload_0
    //   78: iconst_0
    //   79: putfield bitmapIsPreview : Z
    //   82: aload_0
    //   83: iconst_0
    //   84: putfield bitmapIsCached : Z
    //   87: aload_0
    //   88: invokevirtual invalidate : ()V
    //   91: aload_0
    //   92: monitorexit
    //   93: return
    //   94: astore_1
    //   95: aload_0
    //   96: monitorexit
    //   97: aload_1
    //   98: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	94	finally
    //   39	50	94	finally
    //   50	60	94	finally
    //   64	77	94	finally
    //   77	87	94	finally
    //   87	91	94	finally
  }
  
  private void onTilesInited(ImageRegionDecoder paramImageRegionDecoder, int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 'onTilesInited sWidth=%d, sHeight=%d, sOrientation=%d'
    //   6: iconst_3
    //   7: anewarray java/lang/Object
    //   10: dup
    //   11: iconst_0
    //   12: iload_2
    //   13: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   16: aastore
    //   17: dup
    //   18: iconst_1
    //   19: iload_3
    //   20: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   23: aastore
    //   24: dup
    //   25: iconst_2
    //   26: aload_0
    //   27: getfield orientation : I
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: aastore
    //   34: invokespecial debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   37: aload_0
    //   38: getfield sWidth : I
    //   41: istore #5
    //   43: iload #5
    //   45: ifle -> 139
    //   48: aload_0
    //   49: getfield sHeight : I
    //   52: istore #6
    //   54: iload #6
    //   56: ifle -> 139
    //   59: iload #5
    //   61: iload_2
    //   62: if_icmpne -> 71
    //   65: iload #6
    //   67: iload_3
    //   68: if_icmpeq -> 139
    //   71: aload_0
    //   72: iconst_0
    //   73: invokespecial reset : (Z)V
    //   76: aload_0
    //   77: getfield bitmap : Landroid/graphics/Bitmap;
    //   80: astore #7
    //   82: aload #7
    //   84: ifnull -> 139
    //   87: aload_0
    //   88: getfield bitmapIsCached : Z
    //   91: ifne -> 99
    //   94: aload #7
    //   96: invokevirtual recycle : ()V
    //   99: aload_0
    //   100: aconst_null
    //   101: putfield bitmap : Landroid/graphics/Bitmap;
    //   104: aload_0
    //   105: getfield onImageEventListener : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$OnImageEventListener;
    //   108: astore #7
    //   110: aload #7
    //   112: ifnull -> 129
    //   115: aload_0
    //   116: getfield bitmapIsCached : Z
    //   119: ifeq -> 129
    //   122: aload #7
    //   124: invokeinterface onPreviewReleased : ()V
    //   129: aload_0
    //   130: iconst_0
    //   131: putfield bitmapIsPreview : Z
    //   134: aload_0
    //   135: iconst_0
    //   136: putfield bitmapIsCached : Z
    //   139: aload_0
    //   140: aload_1
    //   141: putfield decoder : Lcom/davemorrissey/labs/subscaleview/decoder/ImageRegionDecoder;
    //   144: aload_0
    //   145: iload_2
    //   146: putfield sWidth : I
    //   149: aload_0
    //   150: iload_3
    //   151: putfield sHeight : I
    //   154: aload_0
    //   155: iload #4
    //   157: putfield sOrientation : I
    //   160: aload_0
    //   161: invokespecial checkReady : ()Z
    //   164: pop
    //   165: aload_0
    //   166: invokespecial checkImageLoaded : ()Z
    //   169: ifne -> 235
    //   172: aload_0
    //   173: getfield maxTileWidth : I
    //   176: istore_2
    //   177: iload_2
    //   178: ifle -> 235
    //   181: iload_2
    //   182: ldc 2147483647
    //   184: if_icmpeq -> 235
    //   187: aload_0
    //   188: getfield maxTileHeight : I
    //   191: istore_2
    //   192: iload_2
    //   193: ifle -> 235
    //   196: iload_2
    //   197: ldc 2147483647
    //   199: if_icmpeq -> 235
    //   202: aload_0
    //   203: invokevirtual getWidth : ()I
    //   206: ifle -> 235
    //   209: aload_0
    //   210: invokevirtual getHeight : ()I
    //   213: ifle -> 235
    //   216: aload_0
    //   217: new android/graphics/Point
    //   220: dup
    //   221: aload_0
    //   222: getfield maxTileWidth : I
    //   225: aload_0
    //   226: getfield maxTileHeight : I
    //   229: invokespecial <init> : (II)V
    //   232: invokespecial initialiseBaseLayer : (Landroid/graphics/Point;)V
    //   235: aload_0
    //   236: invokevirtual invalidate : ()V
    //   239: aload_0
    //   240: invokevirtual requestLayout : ()V
    //   243: aload_0
    //   244: monitorexit
    //   245: return
    //   246: astore_1
    //   247: aload_0
    //   248: monitorexit
    //   249: aload_1
    //   250: athrow
    // Exception table:
    //   from	to	target	type
    //   2	43	246	finally
    //   48	54	246	finally
    //   71	82	246	finally
    //   87	99	246	finally
    //   99	110	246	finally
    //   115	129	246	finally
    //   129	139	246	finally
    //   139	177	246	finally
    //   187	192	246	finally
    //   202	235	246	finally
    //   235	243	246	finally
  }
  
  private boolean onTouchEventInternal(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getPointerCount : ()I
    //   4: istore #16
    //   6: aload_1
    //   7: invokevirtual getAction : ()I
    //   10: istore #17
    //   12: iload #17
    //   14: ifeq -> 1941
    //   17: iload #17
    //   19: iconst_1
    //   20: if_icmpeq -> 1732
    //   23: iload #17
    //   25: iconst_2
    //   26: if_icmpeq -> 60
    //   29: iload #17
    //   31: iconst_5
    //   32: if_icmpeq -> 1941
    //   35: iload #17
    //   37: bipush #6
    //   39: if_icmpeq -> 1732
    //   42: iload #17
    //   44: sipush #261
    //   47: if_icmpeq -> 1941
    //   50: iload #17
    //   52: sipush #262
    //   55: if_icmpeq -> 1732
    //   58: iconst_0
    //   59: ireturn
    //   60: aload_0
    //   61: getfield maxTouchCount : I
    //   64: ifle -> 1708
    //   67: iload #16
    //   69: iconst_2
    //   70: if_icmplt -> 671
    //   73: aload_0
    //   74: aload_1
    //   75: iconst_0
    //   76: invokevirtual getX : (I)F
    //   79: aload_1
    //   80: iconst_1
    //   81: invokevirtual getX : (I)F
    //   84: aload_1
    //   85: iconst_0
    //   86: invokevirtual getY : (I)F
    //   89: aload_1
    //   90: iconst_1
    //   91: invokevirtual getY : (I)F
    //   94: invokespecial distance : (FFFF)F
    //   97: fstore #6
    //   99: aload_1
    //   100: iconst_0
    //   101: invokevirtual getX : (I)F
    //   104: fstore #7
    //   106: aload_1
    //   107: iconst_1
    //   108: invokevirtual getX : (I)F
    //   111: fload #7
    //   113: fadd
    //   114: fconst_2
    //   115: fdiv
    //   116: fstore #7
    //   118: aload_1
    //   119: iconst_0
    //   120: invokevirtual getY : (I)F
    //   123: fstore #8
    //   125: aload_1
    //   126: iconst_1
    //   127: invokevirtual getY : (I)F
    //   130: fload #8
    //   132: fadd
    //   133: fconst_2
    //   134: fdiv
    //   135: fstore #8
    //   137: aload_0
    //   138: getfield zoomEnabled : Z
    //   141: ifeq -> 1708
    //   144: aload_0
    //   145: getfield vCenterStart : Landroid/graphics/PointF;
    //   148: astore_1
    //   149: aload_0
    //   150: aload_1
    //   151: getfield x : F
    //   154: fload #7
    //   156: aload_1
    //   157: getfield y : F
    //   160: fload #8
    //   162: invokespecial distance : (FFFF)F
    //   165: ldc_w 5.0
    //   168: fcmpl
    //   169: ifgt -> 196
    //   172: fload #6
    //   174: aload_0
    //   175: getfield vDistStart : F
    //   178: fsub
    //   179: invokestatic abs : (F)F
    //   182: ldc_w 5.0
    //   185: fcmpl
    //   186: ifgt -> 196
    //   189: aload_0
    //   190: getfield isPanning : Z
    //   193: ifeq -> 1708
    //   196: aload_0
    //   197: iconst_1
    //   198: putfield isZooming : Z
    //   201: aload_0
    //   202: iconst_1
    //   203: putfield isPanning : Z
    //   206: aload_0
    //   207: getfield scale : F
    //   210: f2d
    //   211: dstore_2
    //   212: aload_0
    //   213: getfield maxScale : F
    //   216: fload #6
    //   218: aload_0
    //   219: getfield vDistStart : F
    //   222: fdiv
    //   223: aload_0
    //   224: getfield scaleStart : F
    //   227: fmul
    //   228: invokestatic min : (FF)F
    //   231: fstore #9
    //   233: aload_0
    //   234: fload #9
    //   236: putfield scale : F
    //   239: fload #9
    //   241: aload_0
    //   242: invokespecial minScale : ()F
    //   245: fcmpg
    //   246: ifgt -> 288
    //   249: aload_0
    //   250: fload #6
    //   252: putfield vDistStart : F
    //   255: aload_0
    //   256: aload_0
    //   257: invokespecial minScale : ()F
    //   260: putfield scaleStart : F
    //   263: aload_0
    //   264: getfield vCenterStart : Landroid/graphics/PointF;
    //   267: fload #7
    //   269: fload #8
    //   271: invokevirtual set : (FF)V
    //   274: aload_0
    //   275: getfield vTranslateStart : Landroid/graphics/PointF;
    //   278: aload_0
    //   279: getfield vTranslate : Landroid/graphics/PointF;
    //   282: invokevirtual set : (Landroid/graphics/PointF;)V
    //   285: goto -> 655
    //   288: aload_0
    //   289: getfield panEnabled : Z
    //   292: ifeq -> 537
    //   295: aload_0
    //   296: getfield vCenterStart : Landroid/graphics/PointF;
    //   299: astore_1
    //   300: aload_1
    //   301: getfield x : F
    //   304: fstore #9
    //   306: aload_0
    //   307: getfield vTranslateStart : Landroid/graphics/PointF;
    //   310: astore #22
    //   312: aload #22
    //   314: getfield x : F
    //   317: fstore #10
    //   319: aload_1
    //   320: getfield y : F
    //   323: fstore #11
    //   325: aload #22
    //   327: getfield y : F
    //   330: fstore #12
    //   332: aload_0
    //   333: getfield scale : F
    //   336: fstore #14
    //   338: aload_0
    //   339: getfield scaleStart : F
    //   342: fstore #15
    //   344: fload #14
    //   346: fload #15
    //   348: fdiv
    //   349: fstore #13
    //   351: fload #14
    //   353: fload #15
    //   355: fdiv
    //   356: fstore #14
    //   358: aload_0
    //   359: getfield vTranslate : Landroid/graphics/PointF;
    //   362: astore_1
    //   363: aload_1
    //   364: fload #7
    //   366: fload #13
    //   368: fload #9
    //   370: fload #10
    //   372: fsub
    //   373: fmul
    //   374: fsub
    //   375: putfield x : F
    //   378: aload_1
    //   379: fload #8
    //   381: fload #14
    //   383: fload #11
    //   385: fload #12
    //   387: fsub
    //   388: fmul
    //   389: fsub
    //   390: putfield y : F
    //   393: aload_0
    //   394: invokespecial sHeight : ()I
    //   397: i2d
    //   398: dstore #4
    //   400: dload_2
    //   401: invokestatic isNaN : (D)Z
    //   404: pop
    //   405: dload #4
    //   407: invokestatic isNaN : (D)Z
    //   410: pop
    //   411: dload #4
    //   413: dload_2
    //   414: dmul
    //   415: aload_0
    //   416: invokevirtual getHeight : ()I
    //   419: i2d
    //   420: dcmpg
    //   421: ifge -> 443
    //   424: aload_0
    //   425: getfield scale : F
    //   428: aload_0
    //   429: invokespecial sHeight : ()I
    //   432: i2f
    //   433: fmul
    //   434: aload_0
    //   435: invokevirtual getHeight : ()I
    //   438: i2f
    //   439: fcmpl
    //   440: ifge -> 493
    //   443: aload_0
    //   444: invokespecial sWidth : ()I
    //   447: i2d
    //   448: dstore #4
    //   450: dload_2
    //   451: invokestatic isNaN : (D)Z
    //   454: pop
    //   455: dload #4
    //   457: invokestatic isNaN : (D)Z
    //   460: pop
    //   461: dload_2
    //   462: dload #4
    //   464: dmul
    //   465: aload_0
    //   466: invokevirtual getWidth : ()I
    //   469: i2d
    //   470: dcmpg
    //   471: ifge -> 655
    //   474: aload_0
    //   475: getfield scale : F
    //   478: aload_0
    //   479: invokespecial sWidth : ()I
    //   482: i2f
    //   483: fmul
    //   484: aload_0
    //   485: invokevirtual getWidth : ()I
    //   488: i2f
    //   489: fcmpl
    //   490: iflt -> 655
    //   493: aload_0
    //   494: iconst_1
    //   495: invokespecial fitToBounds : (Z)V
    //   498: aload_0
    //   499: getfield vCenterStart : Landroid/graphics/PointF;
    //   502: fload #7
    //   504: fload #8
    //   506: invokevirtual set : (FF)V
    //   509: aload_0
    //   510: getfield vTranslateStart : Landroid/graphics/PointF;
    //   513: aload_0
    //   514: getfield vTranslate : Landroid/graphics/PointF;
    //   517: invokevirtual set : (Landroid/graphics/PointF;)V
    //   520: aload_0
    //   521: aload_0
    //   522: getfield scale : F
    //   525: putfield scaleStart : F
    //   528: aload_0
    //   529: fload #6
    //   531: putfield vDistStart : F
    //   534: goto -> 655
    //   537: aload_0
    //   538: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   541: ifnull -> 601
    //   544: aload_0
    //   545: getfield vTranslate : Landroid/graphics/PointF;
    //   548: aload_0
    //   549: invokevirtual getWidth : ()I
    //   552: iconst_2
    //   553: idiv
    //   554: i2f
    //   555: aload_0
    //   556: getfield scale : F
    //   559: aload_0
    //   560: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   563: getfield x : F
    //   566: fmul
    //   567: fsub
    //   568: putfield x : F
    //   571: aload_0
    //   572: getfield vTranslate : Landroid/graphics/PointF;
    //   575: aload_0
    //   576: invokevirtual getHeight : ()I
    //   579: iconst_2
    //   580: idiv
    //   581: i2f
    //   582: aload_0
    //   583: getfield scale : F
    //   586: aload_0
    //   587: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   590: getfield y : F
    //   593: fmul
    //   594: fsub
    //   595: putfield y : F
    //   598: goto -> 655
    //   601: aload_0
    //   602: getfield vTranslate : Landroid/graphics/PointF;
    //   605: aload_0
    //   606: invokevirtual getWidth : ()I
    //   609: iconst_2
    //   610: idiv
    //   611: i2f
    //   612: aload_0
    //   613: getfield scale : F
    //   616: aload_0
    //   617: invokespecial sWidth : ()I
    //   620: iconst_2
    //   621: idiv
    //   622: i2f
    //   623: fmul
    //   624: fsub
    //   625: putfield x : F
    //   628: aload_0
    //   629: getfield vTranslate : Landroid/graphics/PointF;
    //   632: aload_0
    //   633: invokevirtual getHeight : ()I
    //   636: iconst_2
    //   637: idiv
    //   638: i2f
    //   639: aload_0
    //   640: getfield scale : F
    //   643: aload_0
    //   644: invokespecial sHeight : ()I
    //   647: iconst_2
    //   648: idiv
    //   649: i2f
    //   650: fmul
    //   651: fsub
    //   652: putfield y : F
    //   655: aload_0
    //   656: iconst_1
    //   657: invokespecial fitToBounds : (Z)V
    //   660: aload_0
    //   661: aload_0
    //   662: getfield eagerLoadingEnabled : Z
    //   665: invokespecial refreshRequiredTiles : (Z)V
    //   668: goto -> 1276
    //   671: aload_0
    //   672: getfield isQuickScaling : Z
    //   675: ifeq -> 1282
    //   678: aload_0
    //   679: getfield quickScaleVStart : Landroid/graphics/PointF;
    //   682: getfield y : F
    //   685: aload_1
    //   686: invokevirtual getY : ()F
    //   689: fsub
    //   690: invokestatic abs : (F)F
    //   693: fconst_2
    //   694: fmul
    //   695: aload_0
    //   696: getfield quickScaleThreshold : F
    //   699: fadd
    //   700: fstore #7
    //   702: aload_0
    //   703: getfield quickScaleLastDistance : F
    //   706: ldc_w -1.0
    //   709: fcmpl
    //   710: ifne -> 719
    //   713: aload_0
    //   714: fload #7
    //   716: putfield quickScaleLastDistance : F
    //   719: aload_1
    //   720: invokevirtual getY : ()F
    //   723: fstore #6
    //   725: aload_0
    //   726: getfield quickScaleVLastPoint : Landroid/graphics/PointF;
    //   729: astore #22
    //   731: fload #6
    //   733: aload #22
    //   735: getfield y : F
    //   738: fcmpl
    //   739: ifle -> 748
    //   742: iconst_1
    //   743: istore #16
    //   745: goto -> 751
    //   748: iconst_0
    //   749: istore #16
    //   751: aload #22
    //   753: fconst_0
    //   754: aload_1
    //   755: invokevirtual getY : ()F
    //   758: invokevirtual set : (FF)V
    //   761: fload #7
    //   763: aload_0
    //   764: getfield quickScaleLastDistance : F
    //   767: fdiv
    //   768: fstore #6
    //   770: fconst_1
    //   771: fstore #8
    //   773: fconst_1
    //   774: fload #6
    //   776: fsub
    //   777: invokestatic abs : (F)F
    //   780: ldc_w 0.5
    //   783: fmul
    //   784: fstore #9
    //   786: fload #9
    //   788: ldc_w 0.03
    //   791: fcmpl
    //   792: ifgt -> 806
    //   795: fload #7
    //   797: fstore #6
    //   799: aload_0
    //   800: getfield quickScaleMoved : Z
    //   803: ifeq -> 1257
    //   806: aload_0
    //   807: iconst_1
    //   808: putfield quickScaleMoved : Z
    //   811: fload #8
    //   813: fstore #6
    //   815: aload_0
    //   816: getfield quickScaleLastDistance : F
    //   819: fconst_0
    //   820: fcmpl
    //   821: ifle -> 844
    //   824: iload #16
    //   826: ifeq -> 838
    //   829: fload #9
    //   831: fconst_1
    //   832: fadd
    //   833: fstore #6
    //   835: goto -> 844
    //   838: fconst_1
    //   839: fload #9
    //   841: fsub
    //   842: fstore #6
    //   844: aload_0
    //   845: getfield scale : F
    //   848: f2d
    //   849: dstore_2
    //   850: aload_0
    //   851: invokespecial minScale : ()F
    //   854: aload_0
    //   855: getfield maxScale : F
    //   858: aload_0
    //   859: getfield scale : F
    //   862: fload #6
    //   864: fmul
    //   865: invokestatic min : (FF)F
    //   868: invokestatic max : (FF)F
    //   871: fstore #12
    //   873: aload_0
    //   874: fload #12
    //   876: putfield scale : F
    //   879: aload_0
    //   880: getfield panEnabled : Z
    //   883: ifeq -> 1131
    //   886: aload_0
    //   887: getfield vCenterStart : Landroid/graphics/PointF;
    //   890: astore_1
    //   891: aload_1
    //   892: getfield x : F
    //   895: fstore #6
    //   897: aload_0
    //   898: getfield vTranslateStart : Landroid/graphics/PointF;
    //   901: astore #22
    //   903: aload #22
    //   905: getfield x : F
    //   908: fstore #8
    //   910: aload_1
    //   911: getfield y : F
    //   914: fstore #9
    //   916: aload #22
    //   918: getfield y : F
    //   921: fstore #10
    //   923: aload_0
    //   924: getfield scaleStart : F
    //   927: fstore #13
    //   929: fload #12
    //   931: fload #13
    //   933: fdiv
    //   934: fstore #11
    //   936: fload #12
    //   938: fload #13
    //   940: fdiv
    //   941: fstore #12
    //   943: aload_0
    //   944: getfield vTranslate : Landroid/graphics/PointF;
    //   947: astore_1
    //   948: aload_1
    //   949: fload #6
    //   951: fload #11
    //   953: fload #6
    //   955: fload #8
    //   957: fsub
    //   958: fmul
    //   959: fsub
    //   960: putfield x : F
    //   963: aload_1
    //   964: fload #9
    //   966: fload #12
    //   968: fload #9
    //   970: fload #10
    //   972: fsub
    //   973: fmul
    //   974: fsub
    //   975: putfield y : F
    //   978: aload_0
    //   979: invokespecial sHeight : ()I
    //   982: i2d
    //   983: dstore #4
    //   985: dload_2
    //   986: invokestatic isNaN : (D)Z
    //   989: pop
    //   990: dload #4
    //   992: invokestatic isNaN : (D)Z
    //   995: pop
    //   996: dload #4
    //   998: dload_2
    //   999: dmul
    //   1000: aload_0
    //   1001: invokevirtual getHeight : ()I
    //   1004: i2d
    //   1005: dcmpg
    //   1006: ifge -> 1028
    //   1009: aload_0
    //   1010: getfield scale : F
    //   1013: aload_0
    //   1014: invokespecial sHeight : ()I
    //   1017: i2f
    //   1018: fmul
    //   1019: aload_0
    //   1020: invokevirtual getHeight : ()I
    //   1023: i2f
    //   1024: fcmpl
    //   1025: ifge -> 1086
    //   1028: aload_0
    //   1029: invokespecial sWidth : ()I
    //   1032: i2d
    //   1033: dstore #4
    //   1035: dload_2
    //   1036: invokestatic isNaN : (D)Z
    //   1039: pop
    //   1040: dload #4
    //   1042: invokestatic isNaN : (D)Z
    //   1045: pop
    //   1046: fload #7
    //   1048: fstore #6
    //   1050: dload_2
    //   1051: dload #4
    //   1053: dmul
    //   1054: aload_0
    //   1055: invokevirtual getWidth : ()I
    //   1058: i2d
    //   1059: dcmpg
    //   1060: ifge -> 1257
    //   1063: fload #7
    //   1065: fstore #6
    //   1067: aload_0
    //   1068: getfield scale : F
    //   1071: aload_0
    //   1072: invokespecial sWidth : ()I
    //   1075: i2f
    //   1076: fmul
    //   1077: aload_0
    //   1078: invokevirtual getWidth : ()I
    //   1081: i2f
    //   1082: fcmpl
    //   1083: iflt -> 1257
    //   1086: aload_0
    //   1087: iconst_1
    //   1088: invokespecial fitToBounds : (Z)V
    //   1091: aload_0
    //   1092: getfield vCenterStart : Landroid/graphics/PointF;
    //   1095: aload_0
    //   1096: aload_0
    //   1097: getfield quickScaleSCenter : Landroid/graphics/PointF;
    //   1100: invokevirtual sourceToViewCoord : (Landroid/graphics/PointF;)Landroid/graphics/PointF;
    //   1103: invokevirtual set : (Landroid/graphics/PointF;)V
    //   1106: aload_0
    //   1107: getfield vTranslateStart : Landroid/graphics/PointF;
    //   1110: aload_0
    //   1111: getfield vTranslate : Landroid/graphics/PointF;
    //   1114: invokevirtual set : (Landroid/graphics/PointF;)V
    //   1117: aload_0
    //   1118: aload_0
    //   1119: getfield scale : F
    //   1122: putfield scaleStart : F
    //   1125: fconst_0
    //   1126: fstore #6
    //   1128: goto -> 1257
    //   1131: aload_0
    //   1132: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   1135: ifnull -> 1199
    //   1138: aload_0
    //   1139: getfield vTranslate : Landroid/graphics/PointF;
    //   1142: aload_0
    //   1143: invokevirtual getWidth : ()I
    //   1146: iconst_2
    //   1147: idiv
    //   1148: i2f
    //   1149: aload_0
    //   1150: getfield scale : F
    //   1153: aload_0
    //   1154: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   1157: getfield x : F
    //   1160: fmul
    //   1161: fsub
    //   1162: putfield x : F
    //   1165: aload_0
    //   1166: getfield vTranslate : Landroid/graphics/PointF;
    //   1169: aload_0
    //   1170: invokevirtual getHeight : ()I
    //   1173: iconst_2
    //   1174: idiv
    //   1175: i2f
    //   1176: aload_0
    //   1177: getfield scale : F
    //   1180: aload_0
    //   1181: getfield sRequestedCenter : Landroid/graphics/PointF;
    //   1184: getfield y : F
    //   1187: fmul
    //   1188: fsub
    //   1189: putfield y : F
    //   1192: fload #7
    //   1194: fstore #6
    //   1196: goto -> 1257
    //   1199: aload_0
    //   1200: getfield vTranslate : Landroid/graphics/PointF;
    //   1203: aload_0
    //   1204: invokevirtual getWidth : ()I
    //   1207: iconst_2
    //   1208: idiv
    //   1209: i2f
    //   1210: aload_0
    //   1211: getfield scale : F
    //   1214: aload_0
    //   1215: invokespecial sWidth : ()I
    //   1218: iconst_2
    //   1219: idiv
    //   1220: i2f
    //   1221: fmul
    //   1222: fsub
    //   1223: putfield x : F
    //   1226: aload_0
    //   1227: getfield vTranslate : Landroid/graphics/PointF;
    //   1230: aload_0
    //   1231: invokevirtual getHeight : ()I
    //   1234: iconst_2
    //   1235: idiv
    //   1236: i2f
    //   1237: aload_0
    //   1238: getfield scale : F
    //   1241: aload_0
    //   1242: invokespecial sHeight : ()I
    //   1245: iconst_2
    //   1246: idiv
    //   1247: i2f
    //   1248: fmul
    //   1249: fsub
    //   1250: putfield y : F
    //   1253: fload #7
    //   1255: fstore #6
    //   1257: aload_0
    //   1258: fload #6
    //   1260: putfield quickScaleLastDistance : F
    //   1263: aload_0
    //   1264: iconst_1
    //   1265: invokespecial fitToBounds : (Z)V
    //   1268: aload_0
    //   1269: aload_0
    //   1270: getfield eagerLoadingEnabled : Z
    //   1273: invokespecial refreshRequiredTiles : (Z)V
    //   1276: iconst_1
    //   1277: istore #16
    //   1279: goto -> 1711
    //   1282: aload_0
    //   1283: getfield isZooming : Z
    //   1286: ifne -> 1708
    //   1289: aload_1
    //   1290: invokevirtual getX : ()F
    //   1293: aload_0
    //   1294: getfield vCenterStart : Landroid/graphics/PointF;
    //   1297: getfield x : F
    //   1300: fsub
    //   1301: invokestatic abs : (F)F
    //   1304: fstore #6
    //   1306: aload_1
    //   1307: invokevirtual getY : ()F
    //   1310: aload_0
    //   1311: getfield vCenterStart : Landroid/graphics/PointF;
    //   1314: getfield y : F
    //   1317: fsub
    //   1318: invokestatic abs : (F)F
    //   1321: fstore #7
    //   1323: aload_0
    //   1324: getfield density : F
    //   1327: ldc_w 5.0
    //   1330: fmul
    //   1331: fstore #8
    //   1333: fload #6
    //   1335: fload #8
    //   1337: fcmpl
    //   1338: ifgt -> 1356
    //   1341: fload #7
    //   1343: fload #8
    //   1345: fcmpl
    //   1346: ifgt -> 1356
    //   1349: aload_0
    //   1350: getfield isPanning : Z
    //   1353: ifeq -> 1708
    //   1356: aload_0
    //   1357: getfield vTranslate : Landroid/graphics/PointF;
    //   1360: astore #22
    //   1362: aload_0
    //   1363: getfield vTranslateStart : Landroid/graphics/PointF;
    //   1366: getfield x : F
    //   1369: fstore #9
    //   1371: aload #22
    //   1373: aload_1
    //   1374: invokevirtual getX : ()F
    //   1377: aload_0
    //   1378: getfield vCenterStart : Landroid/graphics/PointF;
    //   1381: getfield x : F
    //   1384: fsub
    //   1385: fload #9
    //   1387: fadd
    //   1388: putfield x : F
    //   1391: aload_0
    //   1392: getfield vTranslate : Landroid/graphics/PointF;
    //   1395: astore #22
    //   1397: aload_0
    //   1398: getfield vTranslateStart : Landroid/graphics/PointF;
    //   1401: getfield y : F
    //   1404: fstore #9
    //   1406: aload #22
    //   1408: aload_1
    //   1409: invokevirtual getY : ()F
    //   1412: aload_0
    //   1413: getfield vCenterStart : Landroid/graphics/PointF;
    //   1416: getfield y : F
    //   1419: fsub
    //   1420: fload #9
    //   1422: fadd
    //   1423: putfield y : F
    //   1426: aload_0
    //   1427: getfield vTranslate : Landroid/graphics/PointF;
    //   1430: astore_1
    //   1431: aload_1
    //   1432: getfield x : F
    //   1435: fstore #10
    //   1437: aload_1
    //   1438: getfield y : F
    //   1441: fstore #9
    //   1443: aload_0
    //   1444: iconst_1
    //   1445: invokespecial fitToBounds : (Z)V
    //   1448: aload_0
    //   1449: getfield vTranslate : Landroid/graphics/PointF;
    //   1452: astore_1
    //   1453: fload #10
    //   1455: aload_1
    //   1456: getfield x : F
    //   1459: fcmpl
    //   1460: ifeq -> 1469
    //   1463: iconst_1
    //   1464: istore #16
    //   1466: goto -> 1472
    //   1469: iconst_0
    //   1470: istore #16
    //   1472: aload_1
    //   1473: getfield y : F
    //   1476: fstore #10
    //   1478: fload #9
    //   1480: fload #10
    //   1482: fcmpl
    //   1483: ifeq -> 1492
    //   1486: iconst_1
    //   1487: istore #17
    //   1489: goto -> 1495
    //   1492: iconst_0
    //   1493: istore #17
    //   1495: iload #16
    //   1497: ifeq -> 1521
    //   1500: fload #6
    //   1502: fload #7
    //   1504: fcmpl
    //   1505: ifle -> 1521
    //   1508: aload_0
    //   1509: getfield isPanning : Z
    //   1512: ifne -> 1521
    //   1515: iconst_1
    //   1516: istore #18
    //   1518: goto -> 1524
    //   1521: iconst_0
    //   1522: istore #18
    //   1524: iload #17
    //   1526: ifeq -> 1550
    //   1529: fload #7
    //   1531: fload #6
    //   1533: fcmpl
    //   1534: ifle -> 1550
    //   1537: aload_0
    //   1538: getfield isPanning : Z
    //   1541: ifne -> 1550
    //   1544: iconst_1
    //   1545: istore #19
    //   1547: goto -> 1553
    //   1550: iconst_0
    //   1551: istore #19
    //   1553: fload #9
    //   1555: fload #10
    //   1557: fcmpl
    //   1558: ifne -> 1579
    //   1561: fload #7
    //   1563: ldc_w 3.0
    //   1566: fload #8
    //   1568: fmul
    //   1569: fcmpl
    //   1570: ifle -> 1579
    //   1573: iconst_1
    //   1574: istore #20
    //   1576: goto -> 1582
    //   1579: iconst_0
    //   1580: istore #20
    //   1582: iload #18
    //   1584: ifne -> 1622
    //   1587: iload #19
    //   1589: ifne -> 1622
    //   1592: iload #16
    //   1594: ifeq -> 1614
    //   1597: iload #17
    //   1599: ifeq -> 1614
    //   1602: iload #20
    //   1604: ifne -> 1614
    //   1607: aload_0
    //   1608: getfield isPanning : Z
    //   1611: ifeq -> 1622
    //   1614: aload_0
    //   1615: iconst_1
    //   1616: putfield isPanning : Z
    //   1619: goto -> 1656
    //   1622: fload #6
    //   1624: fload #8
    //   1626: fcmpl
    //   1627: ifgt -> 1638
    //   1630: fload #7
    //   1632: fload #8
    //   1634: fcmpl
    //   1635: ifle -> 1656
    //   1638: aload_0
    //   1639: iconst_0
    //   1640: putfield maxTouchCount : I
    //   1643: aload_0
    //   1644: getfield handler : Landroid/os/Handler;
    //   1647: iconst_1
    //   1648: invokevirtual removeMessages : (I)V
    //   1651: aload_0
    //   1652: iconst_0
    //   1653: invokespecial requestDisallowInterceptTouchEvent : (Z)V
    //   1656: aload_0
    //   1657: getfield panEnabled : Z
    //   1660: ifne -> 1697
    //   1663: aload_0
    //   1664: getfield vTranslate : Landroid/graphics/PointF;
    //   1667: astore_1
    //   1668: aload_0
    //   1669: getfield vTranslateStart : Landroid/graphics/PointF;
    //   1672: astore #22
    //   1674: aload_1
    //   1675: aload #22
    //   1677: getfield x : F
    //   1680: putfield x : F
    //   1683: aload_1
    //   1684: aload #22
    //   1686: getfield y : F
    //   1689: putfield y : F
    //   1692: aload_0
    //   1693: iconst_0
    //   1694: invokespecial requestDisallowInterceptTouchEvent : (Z)V
    //   1697: aload_0
    //   1698: aload_0
    //   1699: getfield eagerLoadingEnabled : Z
    //   1702: invokespecial refreshRequiredTiles : (Z)V
    //   1705: goto -> 1276
    //   1708: iconst_0
    //   1709: istore #16
    //   1711: iload #16
    //   1713: ifeq -> 1730
    //   1716: aload_0
    //   1717: getfield handler : Landroid/os/Handler;
    //   1720: iconst_1
    //   1721: invokevirtual removeMessages : (I)V
    //   1724: aload_0
    //   1725: invokevirtual invalidate : ()V
    //   1728: iconst_1
    //   1729: ireturn
    //   1730: iconst_0
    //   1731: ireturn
    //   1732: aload_0
    //   1733: getfield handler : Landroid/os/Handler;
    //   1736: iconst_1
    //   1737: invokevirtual removeMessages : (I)V
    //   1740: aload_0
    //   1741: getfield isQuickScaling : Z
    //   1744: ifeq -> 1771
    //   1747: aload_0
    //   1748: iconst_0
    //   1749: putfield isQuickScaling : Z
    //   1752: aload_0
    //   1753: getfield quickScaleMoved : Z
    //   1756: ifne -> 1771
    //   1759: aload_0
    //   1760: aload_0
    //   1761: getfield quickScaleSCenter : Landroid/graphics/PointF;
    //   1764: aload_0
    //   1765: getfield vCenterStart : Landroid/graphics/PointF;
    //   1768: invokespecial doubleTapZoom : (Landroid/graphics/PointF;Landroid/graphics/PointF;)V
    //   1771: aload_0
    //   1772: getfield maxTouchCount : I
    //   1775: ifle -> 1918
    //   1778: aload_0
    //   1779: getfield isZooming : Z
    //   1782: istore #21
    //   1784: iload #21
    //   1786: ifne -> 1796
    //   1789: aload_0
    //   1790: getfield isPanning : Z
    //   1793: ifeq -> 1918
    //   1796: iload #21
    //   1798: ifeq -> 1884
    //   1801: iload #16
    //   1803: iconst_2
    //   1804: if_icmpne -> 1884
    //   1807: aload_0
    //   1808: iconst_1
    //   1809: putfield isPanning : Z
    //   1812: aload_0
    //   1813: getfield vTranslateStart : Landroid/graphics/PointF;
    //   1816: astore #22
    //   1818: aload_0
    //   1819: getfield vTranslate : Landroid/graphics/PointF;
    //   1822: astore #23
    //   1824: aload #22
    //   1826: aload #23
    //   1828: getfield x : F
    //   1831: aload #23
    //   1833: getfield y : F
    //   1836: invokevirtual set : (FF)V
    //   1839: aload_1
    //   1840: invokevirtual getActionIndex : ()I
    //   1843: iconst_1
    //   1844: if_icmpne -> 1867
    //   1847: aload_0
    //   1848: getfield vCenterStart : Landroid/graphics/PointF;
    //   1851: aload_1
    //   1852: iconst_0
    //   1853: invokevirtual getX : (I)F
    //   1856: aload_1
    //   1857: iconst_0
    //   1858: invokevirtual getY : (I)F
    //   1861: invokevirtual set : (FF)V
    //   1864: goto -> 1884
    //   1867: aload_0
    //   1868: getfield vCenterStart : Landroid/graphics/PointF;
    //   1871: aload_1
    //   1872: iconst_1
    //   1873: invokevirtual getX : (I)F
    //   1876: aload_1
    //   1877: iconst_1
    //   1878: invokevirtual getY : (I)F
    //   1881: invokevirtual set : (FF)V
    //   1884: iload #16
    //   1886: iconst_3
    //   1887: if_icmpge -> 1895
    //   1890: aload_0
    //   1891: iconst_0
    //   1892: putfield isZooming : Z
    //   1895: iload #16
    //   1897: iconst_2
    //   1898: if_icmpge -> 1911
    //   1901: aload_0
    //   1902: iconst_0
    //   1903: putfield isPanning : Z
    //   1906: aload_0
    //   1907: iconst_0
    //   1908: putfield maxTouchCount : I
    //   1911: aload_0
    //   1912: iconst_1
    //   1913: invokespecial refreshRequiredTiles : (Z)V
    //   1916: iconst_1
    //   1917: ireturn
    //   1918: iload #16
    //   1920: iconst_1
    //   1921: if_icmpne -> 1939
    //   1924: aload_0
    //   1925: iconst_0
    //   1926: putfield isZooming : Z
    //   1929: aload_0
    //   1930: iconst_0
    //   1931: putfield isPanning : Z
    //   1934: aload_0
    //   1935: iconst_0
    //   1936: putfield maxTouchCount : I
    //   1939: iconst_1
    //   1940: ireturn
    //   1941: aload_0
    //   1942: aconst_null
    //   1943: putfield anim : Lcom/davemorrissey/labs/subscaleview/SubsamplingScaleImageView$Anim;
    //   1946: aload_0
    //   1947: iconst_1
    //   1948: invokespecial requestDisallowInterceptTouchEvent : (Z)V
    //   1951: aload_0
    //   1952: aload_0
    //   1953: getfield maxTouchCount : I
    //   1956: iload #16
    //   1958: invokestatic max : (II)I
    //   1961: putfield maxTouchCount : I
    //   1964: iload #16
    //   1966: iconst_2
    //   1967: if_icmplt -> 2111
    //   1970: aload_0
    //   1971: getfield zoomEnabled : Z
    //   1974: ifeq -> 2096
    //   1977: aload_0
    //   1978: aload_1
    //   1979: iconst_0
    //   1980: invokevirtual getX : (I)F
    //   1983: aload_1
    //   1984: iconst_1
    //   1985: invokevirtual getX : (I)F
    //   1988: aload_1
    //   1989: iconst_0
    //   1990: invokevirtual getY : (I)F
    //   1993: aload_1
    //   1994: iconst_1
    //   1995: invokevirtual getY : (I)F
    //   1998: invokespecial distance : (FFFF)F
    //   2001: fstore #6
    //   2003: aload_0
    //   2004: aload_0
    //   2005: getfield scale : F
    //   2008: putfield scaleStart : F
    //   2011: aload_0
    //   2012: fload #6
    //   2014: putfield vDistStart : F
    //   2017: aload_0
    //   2018: getfield vTranslateStart : Landroid/graphics/PointF;
    //   2021: astore #22
    //   2023: aload_0
    //   2024: getfield vTranslate : Landroid/graphics/PointF;
    //   2027: astore #23
    //   2029: aload #22
    //   2031: aload #23
    //   2033: getfield x : F
    //   2036: aload #23
    //   2038: getfield y : F
    //   2041: invokevirtual set : (FF)V
    //   2044: aload_0
    //   2045: getfield vCenterStart : Landroid/graphics/PointF;
    //   2048: astore #22
    //   2050: aload_1
    //   2051: iconst_0
    //   2052: invokevirtual getX : (I)F
    //   2055: fstore #6
    //   2057: aload_1
    //   2058: iconst_1
    //   2059: invokevirtual getX : (I)F
    //   2062: fload #6
    //   2064: fadd
    //   2065: fconst_2
    //   2066: fdiv
    //   2067: fstore #6
    //   2069: aload_1
    //   2070: iconst_0
    //   2071: invokevirtual getY : (I)F
    //   2074: fstore #7
    //   2076: aload #22
    //   2078: fload #6
    //   2080: aload_1
    //   2081: iconst_1
    //   2082: invokevirtual getY : (I)F
    //   2085: fload #7
    //   2087: fadd
    //   2088: fconst_2
    //   2089: fdiv
    //   2090: invokevirtual set : (FF)V
    //   2093: goto -> 2101
    //   2096: aload_0
    //   2097: iconst_0
    //   2098: putfield maxTouchCount : I
    //   2101: aload_0
    //   2102: getfield handler : Landroid/os/Handler;
    //   2105: iconst_1
    //   2106: invokevirtual removeMessages : (I)V
    //   2109: iconst_1
    //   2110: ireturn
    //   2111: aload_0
    //   2112: getfield isQuickScaling : Z
    //   2115: ifne -> 2172
    //   2118: aload_0
    //   2119: getfield vTranslateStart : Landroid/graphics/PointF;
    //   2122: astore #22
    //   2124: aload_0
    //   2125: getfield vTranslate : Landroid/graphics/PointF;
    //   2128: astore #23
    //   2130: aload #22
    //   2132: aload #23
    //   2134: getfield x : F
    //   2137: aload #23
    //   2139: getfield y : F
    //   2142: invokevirtual set : (FF)V
    //   2145: aload_0
    //   2146: getfield vCenterStart : Landroid/graphics/PointF;
    //   2149: aload_1
    //   2150: invokevirtual getX : ()F
    //   2153: aload_1
    //   2154: invokevirtual getY : ()F
    //   2157: invokevirtual set : (FF)V
    //   2160: aload_0
    //   2161: getfield handler : Landroid/os/Handler;
    //   2164: iconst_1
    //   2165: ldc2_w 600
    //   2168: invokevirtual sendEmptyMessageDelayed : (IJ)Z
    //   2171: pop
    //   2172: iconst_1
    //   2173: ireturn
  }
  
  private void preDraw() {
    if (getWidth() != 0 && getHeight() != 0 && this.sWidth > 0) {
      if (this.sHeight <= 0)
        return; 
      if (this.sPendingCenter != null) {
        Float float_ = this.pendingScale;
        if (float_ != null) {
          this.scale = float_.floatValue();
          if (this.vTranslate == null)
            this.vTranslate = new PointF(); 
          this.vTranslate.x = (getWidth() / 2) - this.scale * this.sPendingCenter.x;
          this.vTranslate.y = (getHeight() / 2) - this.scale * this.sPendingCenter.y;
          this.sPendingCenter = null;
          this.pendingScale = null;
          fitToBounds(true);
          refreshRequiredTiles(true);
        } 
      } 
      fitToBounds(false);
    } 
  }
  
  private int px(int paramInt) {
    return (int)(this.density * paramInt);
  }
  
  private void refreshRequiredTiles(boolean paramBoolean) {
    if (this.decoder != null) {
      if (this.tileMap == null)
        return; 
      int i = Math.min(this.fullImageSampleSize, calculateInSampleSize(this.scale));
      Iterator<Map.Entry> iterator = this.tileMap.entrySet().iterator();
      while (iterator.hasNext()) {
        for (Tile tile : ((Map.Entry)iterator.next()).getValue()) {
          if (tile.sampleSize < i || (tile.sampleSize > i && tile.sampleSize != this.fullImageSampleSize)) {
            Tile.access$402(tile, false);
            if (tile.bitmap != null) {
              tile.bitmap.recycle();
              Tile.access$502(tile, null);
            } 
          } 
          if (tile.sampleSize == i) {
            if (tileVisible(tile)) {
              Tile.access$402(tile, true);
              if (!tile.loading && tile.bitmap == null && paramBoolean)
                execute(new TileLoadTask(this, this.decoder, tile)); 
              continue;
            } 
            if (tile.sampleSize != this.fullImageSampleSize) {
              Tile.access$402(tile, false);
              if (tile.bitmap != null) {
                tile.bitmap.recycle();
                Tile.access$502(tile, null);
              } 
            } 
            continue;
          } 
          if (tile.sampleSize == this.fullImageSampleSize)
            Tile.access$402(tile, true); 
        } 
      } 
    } 
  }
  
  private void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    ViewParent viewParent = getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(paramBoolean); 
  }
  
  private void reset(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("reset newImage=");
    stringBuilder.append(paramBoolean);
    debug(stringBuilder.toString(), new Object[0]);
    this.scale = 0.0F;
    this.scaleStart = 0.0F;
    this.vTranslate = null;
    this.vTranslateStart = null;
    this.vTranslateBefore = null;
    this.pendingScale = Float.valueOf(0.0F);
    this.sPendingCenter = null;
    this.sRequestedCenter = null;
    this.isZooming = false;
    this.isPanning = false;
    this.isQuickScaling = false;
    this.maxTouchCount = 0;
    this.fullImageSampleSize = 0;
    this.vCenterStart = null;
    this.vDistStart = 0.0F;
    this.quickScaleLastDistance = 0.0F;
    this.quickScaleMoved = false;
    this.quickScaleSCenter = null;
    this.quickScaleVLastPoint = null;
    this.quickScaleVStart = null;
    this.anim = null;
    this.satTemp = null;
    this.matrix = null;
    this.sRect = null;
    if (paramBoolean) {
      this.uri = null;
      this.decoderLock.writeLock().lock();
      try {
        ImageRegionDecoder imageRegionDecoder = this.decoder;
        if (imageRegionDecoder != null) {
          imageRegionDecoder.recycle();
          this.decoder = null;
        } 
        this.decoderLock.writeLock().unlock();
        Bitmap bitmap = this.bitmap;
        if (bitmap != null && !this.bitmapIsCached)
          bitmap.recycle(); 
        if (this.bitmap != null && this.bitmapIsCached) {
          OnImageEventListener onImageEventListener = this.onImageEventListener;
          if (onImageEventListener != null)
            onImageEventListener.onPreviewReleased(); 
        } 
        this.sWidth = 0;
        this.sHeight = 0;
        this.sOrientation = 0;
        this.sRegion = null;
        this.pRegion = null;
        this.readySent = false;
        this.imageLoadedSent = false;
        this.bitmap = null;
        this.bitmapIsPreview = false;
      } finally {
        this.decoderLock.writeLock().unlock();
      } 
    } 
    Map<Integer, List<Tile>> map = this.tileMap;
    if (map != null) {
      Iterator<Map.Entry> iterator = map.entrySet().iterator();
      while (iterator.hasNext()) {
        for (Tile tile : ((Map.Entry)iterator.next()).getValue()) {
          Tile.access$402(tile, false);
          if (tile.bitmap != null) {
            tile.bitmap.recycle();
            Tile.access$502(tile, null);
          } 
        } 
      } 
      this.tileMap = null;
    } 
    setGestureDetector(getContext());
  }
  
  private void restoreState(ImageViewState paramImageViewState) {
    if (paramImageViewState != null && VALID_ORIENTATIONS.contains(Integer.valueOf(paramImageViewState.getOrientation()))) {
      this.orientation = paramImageViewState.getOrientation();
      this.pendingScale = Float.valueOf(paramImageViewState.getScale());
      this.sPendingCenter = paramImageViewState.getCenter();
      invalidate();
    } 
  }
  
  private int sHeight() {
    int i = getRequiredRotation();
    return (i == 90 || i == 270) ? this.sWidth : this.sHeight;
  }
  
  private int sWidth() {
    int i = getRequiredRotation();
    return (i == 90 || i == 270) ? this.sHeight : this.sWidth;
  }
  
  private void sendStateChanged(float paramFloat, PointF paramPointF, int paramInt) {
    OnStateChangedListener onStateChangedListener = this.onStateChangedListener;
    if (onStateChangedListener != null) {
      float f = this.scale;
      if (f != paramFloat)
        onStateChangedListener.onScaleChanged(f, paramInt); 
    } 
    if (this.onStateChangedListener != null && !this.vTranslate.equals(paramPointF))
      this.onStateChangedListener.onCenterChanged(getCenter(), paramInt); 
  }
  
  private void setGestureDetector(final Context context) {
    this.detector = new GestureDetector(context, (GestureDetector.OnGestureListener)new GestureDetector.SimpleOnGestureListener() {
          public boolean onDoubleTap(MotionEvent param1MotionEvent) {
            if (SubsamplingScaleImageView.this.zoomEnabled && SubsamplingScaleImageView.this.readySent && SubsamplingScaleImageView.this.vTranslate != null) {
              SubsamplingScaleImageView.this.setGestureDetector(context);
              if (SubsamplingScaleImageView.this.quickScaleEnabled) {
                SubsamplingScaleImageView.access$1702(SubsamplingScaleImageView.this, new PointF(param1MotionEvent.getX(), param1MotionEvent.getY()));
                SubsamplingScaleImageView.access$1802(SubsamplingScaleImageView.this, new PointF(SubsamplingScaleImageView.this.vTranslate.x, SubsamplingScaleImageView.this.vTranslate.y));
                SubsamplingScaleImageView subsamplingScaleImageView1 = SubsamplingScaleImageView.this;
                SubsamplingScaleImageView.access$1902(subsamplingScaleImageView1, subsamplingScaleImageView1.scale);
                SubsamplingScaleImageView.access$2002(SubsamplingScaleImageView.this, true);
                SubsamplingScaleImageView.access$902(SubsamplingScaleImageView.this, true);
                SubsamplingScaleImageView.access$2102(SubsamplingScaleImageView.this, -1.0F);
                subsamplingScaleImageView1 = SubsamplingScaleImageView.this;
                SubsamplingScaleImageView.access$2202(subsamplingScaleImageView1, subsamplingScaleImageView1.viewToSourceCoord(subsamplingScaleImageView1.vCenterStart));
                SubsamplingScaleImageView.access$2302(SubsamplingScaleImageView.this, new PointF(param1MotionEvent.getX(), param1MotionEvent.getY()));
                SubsamplingScaleImageView.access$2402(SubsamplingScaleImageView.this, new PointF(SubsamplingScaleImageView.this.quickScaleSCenter.x, SubsamplingScaleImageView.this.quickScaleSCenter.y));
                SubsamplingScaleImageView.access$2502(SubsamplingScaleImageView.this, false);
                return false;
              } 
              SubsamplingScaleImageView subsamplingScaleImageView = SubsamplingScaleImageView.this;
              subsamplingScaleImageView.doubleTapZoom(subsamplingScaleImageView.viewToSourceCoord(new PointF(param1MotionEvent.getX(), param1MotionEvent.getY())), new PointF(param1MotionEvent.getX(), param1MotionEvent.getY()));
              return true;
            } 
            return onDoubleTapEvent(param1MotionEvent);
          }
          
          public boolean onFling(MotionEvent param1MotionEvent1, MotionEvent param1MotionEvent2, float param1Float1, float param1Float2) {
            PointF pointF;
            if (SubsamplingScaleImageView.this.panEnabled && SubsamplingScaleImageView.this.readySent && SubsamplingScaleImageView.this.vTranslate != null && param1MotionEvent1 != null && param1MotionEvent2 != null && (Math.abs(param1MotionEvent1.getX() - param1MotionEvent2.getX()) > 50.0F || Math.abs(param1MotionEvent1.getY() - param1MotionEvent2.getY()) > 50.0F) && (Math.abs(param1Float1) > 500.0F || Math.abs(param1Float2) > 500.0F) && !SubsamplingScaleImageView.this.isZooming) {
              pointF = new PointF(param1Float1 * 0.25F + SubsamplingScaleImageView.this.vTranslate.x, param1Float2 * 0.25F + SubsamplingScaleImageView.this.vTranslate.y);
              param1Float1 = ((SubsamplingScaleImageView.this.getWidth() / 2) - pointF.x) / SubsamplingScaleImageView.this.scale;
              param1Float2 = ((SubsamplingScaleImageView.this.getHeight() / 2) - pointF.y) / SubsamplingScaleImageView.this.scale;
              (new SubsamplingScaleImageView.AnimationBuilder(new PointF(param1Float1, param1Float2))).withEasing(1).withPanLimited(false).withOrigin(3).start();
              return true;
            } 
            return super.onFling((MotionEvent)pointF, param1MotionEvent2, param1Float1, param1Float2);
          }
          
          public boolean onSingleTapConfirmed(MotionEvent param1MotionEvent) {
            SubsamplingScaleImageView.this.performClick();
            return true;
          }
        });
    this.singleDetector = new GestureDetector(context, (GestureDetector.OnGestureListener)new GestureDetector.SimpleOnGestureListener() {
          public boolean onSingleTapConfirmed(MotionEvent param1MotionEvent) {
            SubsamplingScaleImageView.this.performClick();
            return true;
          }
        });
  }
  
  private void setMatrixArray(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    paramArrayOffloat[0] = paramFloat1;
    paramArrayOffloat[1] = paramFloat2;
    paramArrayOffloat[2] = paramFloat3;
    paramArrayOffloat[3] = paramFloat4;
    paramArrayOffloat[4] = paramFloat5;
    paramArrayOffloat[5] = paramFloat6;
    paramArrayOffloat[6] = paramFloat7;
    paramArrayOffloat[7] = paramFloat8;
  }
  
  public static void setPreferredBitmapConfig(Bitmap.Config paramConfig) {
    preferredBitmapConfig = paramConfig;
  }
  
  private void sourceToViewRect(Rect paramRect1, Rect paramRect2) {
    paramRect2.set((int)sourceToViewX(paramRect1.left), (int)sourceToViewY(paramRect1.top), (int)sourceToViewX(paramRect1.right), (int)sourceToViewY(paramRect1.bottom));
  }
  
  private float sourceToViewX(float paramFloat) {
    PointF pointF = this.vTranslate;
    return (pointF == null) ? Float.NaN : (paramFloat * this.scale + pointF.x);
  }
  
  private float sourceToViewY(float paramFloat) {
    PointF pointF = this.vTranslate;
    return (pointF == null) ? Float.NaN : (paramFloat * this.scale + pointF.y);
  }
  
  private boolean tileVisible(Tile paramTile) {
    float f1 = viewToSourceX(0.0F);
    float f2 = viewToSourceX(getWidth());
    float f3 = viewToSourceY(0.0F);
    float f4 = viewToSourceY(getHeight());
    return (f1 <= paramTile.sRect.right && paramTile.sRect.left <= f2 && f3 <= paramTile.sRect.bottom && paramTile.sRect.top <= f4);
  }
  
  private PointF vTranslateForSCenter(float paramFloat1, float paramFloat2, float paramFloat3) {
    int i = getPaddingLeft();
    int j = (getWidth() - getPaddingRight() - getPaddingLeft()) / 2;
    int k = getPaddingTop();
    int m = (getHeight() - getPaddingBottom() - getPaddingTop()) / 2;
    if (this.satTemp == null)
      this.satTemp = new ScaleAndTranslate(0.0F, new PointF(0.0F, 0.0F)); 
    ScaleAndTranslate.access$4702(this.satTemp, paramFloat3);
    this.satTemp.vTranslate.set((j + i) - paramFloat1 * paramFloat3, (m + k) - paramFloat2 * paramFloat3);
    fitToBounds(true, this.satTemp);
    return this.satTemp.vTranslate;
  }
  
  private float viewToSourceX(float paramFloat) {
    PointF pointF = this.vTranslate;
    return (pointF == null) ? Float.NaN : ((paramFloat - pointF.x) / this.scale);
  }
  
  private float viewToSourceY(float paramFloat) {
    PointF pointF = this.vTranslate;
    return (pointF == null) ? Float.NaN : ((paramFloat - pointF.y) / this.scale);
  }
  
  public AnimationBuilder animateCenter(PointF paramPointF) {
    return !isReady() ? null : new AnimationBuilder(paramPointF);
  }
  
  public AnimationBuilder animateScale(float paramFloat) {
    return !isReady() ? null : new AnimationBuilder(paramFloat);
  }
  
  public AnimationBuilder animateScaleAndCenter(float paramFloat, PointF paramPointF) {
    return !isReady() ? null : new AnimationBuilder(paramFloat, paramPointF);
  }
  
  public final int getAppliedOrientation() {
    return getRequiredRotation();
  }
  
  public final PointF getCenter() {
    int i = getWidth() / 2;
    int j = getHeight() / 2;
    return viewToSourceCoord(i, j);
  }
  
  public float getMaxScale() {
    return this.maxScale;
  }
  
  public final float getMinScale() {
    return minScale();
  }
  
  public final int getOrientation() {
    return this.orientation;
  }
  
  public final void getPanRemaining(RectF paramRectF) {
    if (!isReady())
      return; 
    float f1 = this.scale * sWidth();
    float f2 = this.scale * sHeight();
    int i = this.panLimit;
    if (i == 3) {
      paramRectF.top = Math.max(0.0F, -(this.vTranslate.y - (getHeight() / 2)));
      paramRectF.left = Math.max(0.0F, -(this.vTranslate.x - (getWidth() / 2)));
      paramRectF.bottom = Math.max(0.0F, this.vTranslate.y - (getHeight() / 2) - f2);
      paramRectF.right = Math.max(0.0F, this.vTranslate.x - (getWidth() / 2) - f1);
      return;
    } 
    if (i == 2) {
      paramRectF.top = Math.max(0.0F, -(this.vTranslate.y - getHeight()));
      paramRectF.left = Math.max(0.0F, -(this.vTranslate.x - getWidth()));
      paramRectF.bottom = Math.max(0.0F, this.vTranslate.y + f2);
      paramRectF.right = Math.max(0.0F, this.vTranslate.x + f1);
      return;
    } 
    paramRectF.top = Math.max(0.0F, -this.vTranslate.y);
    paramRectF.left = Math.max(0.0F, -this.vTranslate.x);
    paramRectF.bottom = Math.max(0.0F, f2 + this.vTranslate.y - getHeight());
    paramRectF.right = Math.max(0.0F, f1 + this.vTranslate.x - getWidth());
  }
  
  public final int getSHeight() {
    return this.sHeight;
  }
  
  public final int getSWidth() {
    return this.sWidth;
  }
  
  public final float getScale() {
    return this.scale;
  }
  
  public final ImageViewState getState() {
    return (this.vTranslate != null && this.sWidth > 0 && this.sHeight > 0) ? new ImageViewState(getScale(), getCenter(), getOrientation()) : null;
  }
  
  public boolean hasImage() {
    return (this.uri != null || this.bitmap != null);
  }
  
  public final boolean isImageLoaded() {
    return this.imageLoadedSent;
  }
  
  public final boolean isPanEnabled() {
    return this.panEnabled;
  }
  
  public final boolean isQuickScaleEnabled() {
    return this.quickScaleEnabled;
  }
  
  public final boolean isReady() {
    return this.readySent;
  }
  
  public final boolean isZoomEnabled() {
    return this.zoomEnabled;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    createPaints();
    if (this.sWidth != 0 && this.sHeight != 0 && getWidth() != 0) {
      if (getHeight() == 0)
        return; 
      if (this.tileMap == null && this.decoder != null)
        initialiseBaseLayer(getMaxBitmapDimensions(paramCanvas)); 
      if (!checkReady())
        return; 
      preDraw();
      Anim anim = this.anim;
      if (anim != null && anim.vFocusStart != null) {
        boolean bool1;
        boolean bool2;
        float f1 = this.scale;
        if (this.vTranslateBefore == null)
          this.vTranslateBefore = new PointF(0.0F, 0.0F); 
        this.vTranslateBefore.set(this.vTranslate);
        long l = System.currentTimeMillis() - this.anim.time;
        if (l > this.anim.duration) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        l = Math.min(l, this.anim.duration);
        this.scale = ease(this.anim.easing, l, this.anim.scaleStart, this.anim.scaleEnd - this.anim.scaleStart, this.anim.duration);
        float f2 = ease(this.anim.easing, l, this.anim.vFocusStart.x, this.anim.vFocusEnd.x - this.anim.vFocusStart.x, this.anim.duration);
        float f3 = ease(this.anim.easing, l, this.anim.vFocusStart.y, this.anim.vFocusEnd.y - this.anim.vFocusStart.y, this.anim.duration);
        PointF pointF = this.vTranslate;
        pointF.x -= sourceToViewX(this.anim.sCenterEnd.x) - f2;
        pointF = this.vTranslate;
        pointF.y -= sourceToViewY(this.anim.sCenterEnd.y) - f3;
        if (bool1 || this.anim.scaleStart == this.anim.scaleEnd) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        fitToBounds(bool2);
        sendStateChanged(f1, this.vTranslateBefore, this.anim.origin);
        refreshRequiredTiles(bool1);
        if (bool1) {
          if (this.anim.listener != null)
            try {
              this.anim.listener.onComplete();
            } catch (Exception exception) {} 
          this.anim = null;
        } 
        invalidate();
      } 
      if (this.tileMap != null && isBaseLayerReady()) {
        int i = Math.min(this.fullImageSampleSize, calculateInSampleSize(this.scale));
        null = this.tileMap.entrySet().iterator();
        boolean bool = false;
        label139: while (null.hasNext()) {
          Map.Entry entry = null.next();
          if (((Integer)entry.getKey()).intValue() == i) {
            Iterator<Tile> iterator = ((List)entry.getValue()).iterator();
            boolean bool1 = bool;
            while (true) {
              bool = bool1;
              if (iterator.hasNext()) {
                Tile tile = iterator.next();
                if (tile.visible && (tile.loading || tile.bitmap == null))
                  bool1 = true; 
                continue;
              } 
              continue label139;
            } 
          } 
        } 
        for (Map.Entry<Integer, List<Tile>> entry : this.tileMap.entrySet()) {
          if (((Integer)entry.getKey()).intValue() == i || bool)
            for (Tile tile : entry.getValue()) {
              sourceToViewRect(tile.sRect, tile.vRect);
              if (!tile.loading && tile.bitmap != null) {
                if (this.tileBgPaint != null)
                  paramCanvas.drawRect(tile.vRect, this.tileBgPaint); 
                if (this.matrix == null)
                  this.matrix = new Matrix(); 
                this.matrix.reset();
                setMatrixArray(this.srcArray, 0.0F, 0.0F, tile.bitmap.getWidth(), 0.0F, tile.bitmap.getWidth(), tile.bitmap.getHeight(), 0.0F, tile.bitmap.getHeight());
                if (getRequiredRotation() == 0) {
                  setMatrixArray(this.dstArray, tile.vRect.left, tile.vRect.top, tile.vRect.right, tile.vRect.top, tile.vRect.right, tile.vRect.bottom, tile.vRect.left, tile.vRect.bottom);
                } else if (getRequiredRotation() == 90) {
                  setMatrixArray(this.dstArray, tile.vRect.right, tile.vRect.top, tile.vRect.right, tile.vRect.bottom, tile.vRect.left, tile.vRect.bottom, tile.vRect.left, tile.vRect.top);
                } else if (getRequiredRotation() == 180) {
                  setMatrixArray(this.dstArray, tile.vRect.right, tile.vRect.bottom, tile.vRect.left, tile.vRect.bottom, tile.vRect.left, tile.vRect.top, tile.vRect.right, tile.vRect.top);
                } else if (getRequiredRotation() == 270) {
                  setMatrixArray(this.dstArray, tile.vRect.left, tile.vRect.bottom, tile.vRect.left, tile.vRect.top, tile.vRect.right, tile.vRect.top, tile.vRect.right, tile.vRect.bottom);
                } 
                this.matrix.setPolyToPoly(this.srcArray, 0, this.dstArray, 0, 4);
                paramCanvas.drawBitmap(tile.bitmap, this.matrix, this.bitmapPaint);
                if (this.debug)
                  paramCanvas.drawRect(tile.vRect, this.debugLinePaint); 
              } else if (tile.loading && this.debug) {
                paramCanvas.drawText("LOADING", (tile.vRect.left + px(5)), (tile.vRect.top + px(35)), this.debugTextPaint);
              } 
              if (tile.visible && this.debug) {
                StringBuilder stringBuilder = s30.x0("ISS ");
                stringBuilder.append(tile.sampleSize);
                stringBuilder.append(" RECT ");
                stringBuilder.append(tile.sRect.top);
                stringBuilder.append(",");
                stringBuilder.append(tile.sRect.left);
                stringBuilder.append(",");
                stringBuilder.append(tile.sRect.bottom);
                stringBuilder.append(",");
                stringBuilder.append(tile.sRect.right);
                paramCanvas.drawText(stringBuilder.toString(), (tile.vRect.left + px(5)), (tile.vRect.top + px(15)), this.debugTextPaint);
              } 
            }  
        } 
      } else {
        Bitmap bitmap = this.bitmap;
        if (bitmap != null) {
          float f2;
          float f1 = this.scale;
          if (this.bitmapIsPreview) {
            f2 = this.sWidth / bitmap.getWidth();
            float f = this.scale * this.sHeight / this.bitmap.getHeight();
            f2 = f1 * f2;
            f1 = f;
          } else {
            f2 = f1;
          } 
          if (this.matrix == null)
            this.matrix = new Matrix(); 
          this.matrix.reset();
          this.matrix.postScale(f2, f1);
          this.matrix.postRotate(getRequiredRotation());
          Matrix matrix = this.matrix;
          PointF pointF = this.vTranslate;
          matrix.postTranslate(pointF.x, pointF.y);
          if (getRequiredRotation() == 180) {
            matrix = this.matrix;
            f1 = this.scale;
            matrix.postTranslate(this.sWidth * f1, f1 * this.sHeight);
          } else if (getRequiredRotation() == 90) {
            this.matrix.postTranslate(this.scale * this.sHeight, 0.0F);
          } else if (getRequiredRotation() == 270) {
            this.matrix.postTranslate(0.0F, this.scale * this.sWidth);
          } 
          if (this.tileBgPaint != null) {
            int i;
            if (this.sRect == null)
              this.sRect = new RectF(); 
            RectF rectF = this.sRect;
            if (this.bitmapIsPreview) {
              i = this.bitmap.getWidth();
            } else {
              i = this.sWidth;
            } 
            f1 = i;
            if (this.bitmapIsPreview) {
              i = this.bitmap.getHeight();
            } else {
              i = this.sHeight;
            } 
            rectF.set(0.0F, 0.0F, f1, i);
            this.matrix.mapRect(this.sRect);
            paramCanvas.drawRect(this.sRect, this.tileBgPaint);
          } 
          paramCanvas.drawBitmap(this.bitmap, this.matrix, this.bitmapPaint);
        } 
      } 
      if (this.debug) {
        StringBuilder stringBuilder1 = s30.x0("Scale: ");
        Locale locale = Locale.ENGLISH;
        stringBuilder1.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(this.scale) }));
        stringBuilder1.append(" (");
        stringBuilder1.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(minScale()) }));
        stringBuilder1.append(" - ");
        stringBuilder1.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(this.maxScale) }));
        stringBuilder1.append(")");
        paramCanvas.drawText(stringBuilder1.toString(), px(5), px(15), this.debugTextPaint);
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Translate: ");
        stringBuilder1.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(this.vTranslate.x) }));
        stringBuilder1.append(":");
        stringBuilder1.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(this.vTranslate.y) }));
        paramCanvas.drawText(stringBuilder1.toString(), px(5), px(30), this.debugTextPaint);
        PointF pointF = getCenter();
        StringBuilder stringBuilder2 = s30.x0("Source center: ");
        stringBuilder2.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(pointF.x) }));
        stringBuilder2.append(":");
        stringBuilder2.append(String.format(locale, "%.2f", new Object[] { Float.valueOf(pointF.y) }));
        paramCanvas.drawText(stringBuilder2.toString(), px(5), px(45), this.debugTextPaint);
        Anim anim1 = this.anim;
        if (anim1 != null) {
          PointF pointF1 = sourceToViewCoord(anim1.sCenterStart);
          pointF = sourceToViewCoord(this.anim.sCenterEndRequested);
          PointF pointF2 = sourceToViewCoord(this.anim.sCenterEnd);
          paramCanvas.drawCircle(pointF1.x, pointF1.y, px(10), this.debugLinePaint);
          this.debugLinePaint.setColor(-65536);
          paramCanvas.drawCircle(pointF.x, pointF.y, px(20), this.debugLinePaint);
          this.debugLinePaint.setColor(-16776961);
          paramCanvas.drawCircle(pointF2.x, pointF2.y, px(25), this.debugLinePaint);
          this.debugLinePaint.setColor(-16711681);
          paramCanvas.drawCircle((getWidth() / 2), (getHeight() / 2), px(30), this.debugLinePaint);
        } 
        if (this.vCenterStart != null) {
          this.debugLinePaint.setColor(-65536);
          PointF pointF1 = this.vCenterStart;
          paramCanvas.drawCircle(pointF1.x, pointF1.y, px(20), this.debugLinePaint);
        } 
        if (this.quickScaleSCenter != null) {
          this.debugLinePaint.setColor(-16776961);
          paramCanvas.drawCircle(sourceToViewX(this.quickScaleSCenter.x), sourceToViewY(this.quickScaleSCenter.y), px(35), this.debugLinePaint);
        } 
        if (this.quickScaleVStart != null && this.isQuickScaling) {
          this.debugLinePaint.setColor(-16711681);
          PointF pointF1 = this.quickScaleVStart;
          paramCanvas.drawCircle(pointF1.x, pointF1.y, px(30), this.debugLinePaint);
        } 
        this.debugLinePaint.setColor(-65281);
      } 
    } 
  }
  
  public void onImageLoaded() {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int m = View.MeasureSpec.getMode(paramInt2);
    int j = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getSize(paramInt2);
    boolean bool = true;
    if (i != 1073741824) {
      i = 1;
    } else {
      i = 0;
    } 
    if (m == 1073741824)
      bool = false; 
    paramInt1 = j;
    paramInt2 = k;
    if (this.sWidth > 0) {
      paramInt1 = j;
      paramInt2 = k;
      if (this.sHeight > 0)
        if (i != 0 && bool) {
          paramInt1 = sWidth();
          paramInt2 = sHeight();
        } else if (bool) {
          double d1 = sHeight();
          double d2 = sWidth();
          Double.isNaN(d1);
          Double.isNaN(d2);
          d1 /= d2;
          d2 = j;
          Double.isNaN(d2);
          paramInt2 = (int)(d1 * d2);
          paramInt1 = j;
        } else {
          paramInt1 = j;
          paramInt2 = k;
          if (i != 0) {
            double d1 = sWidth();
            double d2 = sHeight();
            Double.isNaN(d1);
            Double.isNaN(d2);
            d1 /= d2;
            d2 = k;
            Double.isNaN(d2);
            paramInt1 = (int)(d1 * d2);
            paramInt2 = k;
          } 
        }  
    } 
    setMeasuredDimension(Math.max(paramInt1, getSuggestedMinimumWidth()), Math.max(paramInt2, getSuggestedMinimumHeight()));
  }
  
  public void onReady() {}
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    debug("onSizeChanged %dx%d -> %dx%d", new Object[] { Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    PointF pointF = getCenter();
    if (this.readySent && pointF != null) {
      this.anim = null;
      this.pendingScale = Float.valueOf(this.scale);
      this.sPendingCenter = pointF;
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    Anim anim = this.anim;
    boolean bool = true;
    if (anim != null && !anim.interruptible) {
      requestDisallowInterceptTouchEvent(true);
      return true;
    } 
    anim = this.anim;
    if (anim != null && anim.listener != null)
      try {
        this.anim.listener.onInterruptedByUser();
      } catch (Exception exception) {} 
    this.anim = null;
    if (this.vTranslate == null) {
      GestureDetector gestureDetector = this.singleDetector;
      if (gestureDetector != null)
        gestureDetector.onTouchEvent(paramMotionEvent); 
      return true;
    } 
    if (!this.isQuickScaling) {
      GestureDetector gestureDetector = this.detector;
      if (gestureDetector == null || gestureDetector.onTouchEvent(paramMotionEvent)) {
        this.isZooming = false;
        this.isPanning = false;
        this.maxTouchCount = 0;
        return true;
      } 
    } 
    if (this.vTranslateStart == null)
      this.vTranslateStart = new PointF(0.0F, 0.0F); 
    if (this.vTranslateBefore == null)
      this.vTranslateBefore = new PointF(0.0F, 0.0F); 
    if (this.vCenterStart == null)
      this.vCenterStart = new PointF(0.0F, 0.0F); 
    float f = this.scale;
    this.vTranslateBefore.set(this.vTranslate);
    boolean bool1 = onTouchEventInternal(paramMotionEvent);
    sendStateChanged(f, this.vTranslateBefore, 2);
    if (!bool1) {
      if (super.onTouchEvent(paramMotionEvent))
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  public void recycle() {
    reset(true);
    this.bitmapPaint = null;
    this.debugTextPaint = null;
    this.debugLinePaint = null;
    this.tileBgPaint = null;
  }
  
  public final void resetScaleAndCenter() {
    this.anim = null;
    this.pendingScale = Float.valueOf(limitedScale(0.0F));
    if (isReady()) {
      this.sPendingCenter = new PointF((sWidth() / 2), (sHeight() / 2));
    } else {
      this.sPendingCenter = new PointF(0.0F, 0.0F);
    } 
    invalidate();
  }
  
  public final void setBitmapDecoderClass(Class<? extends ImageDecoder> paramClass) {
    if (paramClass != null) {
      this.bitmapDecoderFactory = (DecoderFactory<? extends ImageDecoder>)new CompatDecoderFactory(paramClass);
      return;
    } 
    throw new IllegalArgumentException("Decoder class cannot be set to null");
  }
  
  public final void setBitmapDecoderFactory(DecoderFactory<? extends ImageDecoder> paramDecoderFactory) {
    if (paramDecoderFactory != null) {
      this.bitmapDecoderFactory = paramDecoderFactory;
      return;
    } 
    throw new IllegalArgumentException("Decoder factory cannot be set to null");
  }
  
  public final void setDebug(boolean paramBoolean) {
    this.debug = paramBoolean;
  }
  
  public final void setDoubleTapZoomDpi(int paramInt) {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    setDoubleTapZoomScale((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0F / paramInt);
  }
  
  public final void setDoubleTapZoomDuration(int paramInt) {
    this.doubleTapZoomDuration = Math.max(0, paramInt);
  }
  
  public final void setDoubleTapZoomScale(float paramFloat) {
    this.doubleTapZoomScale = paramFloat;
  }
  
  public final void setDoubleTapZoomStyle(int paramInt) {
    if (VALID_ZOOM_STYLES.contains(Integer.valueOf(paramInt))) {
      this.doubleTapZoomStyle = paramInt;
      return;
    } 
    throw new IllegalArgumentException(s30.Z("Invalid zoom style: ", paramInt));
  }
  
  public void setEagerLoadingEnabled(boolean paramBoolean) {
    this.eagerLoadingEnabled = paramBoolean;
  }
  
  public void setExecutor(Executor paramExecutor) {
    Objects.requireNonNull(paramExecutor, "Executor must not be null");
    this.executor = paramExecutor;
  }
  
  public final void setImage(ImageSource paramImageSource) {
    setImage(paramImageSource, null, null);
  }
  
  public final void setImage(ImageSource paramImageSource1, ImageSource paramImageSource2) {
    setImage(paramImageSource1, paramImageSource2, null);
  }
  
  public final void setImage(ImageSource paramImageSource1, ImageSource paramImageSource2, ImageViewState paramImageViewState) {
    Objects.requireNonNull(paramImageSource1, "imageSource must not be null");
    reset(true);
    if (paramImageViewState != null)
      restoreState(paramImageViewState); 
    if (paramImageSource2 != null)
      if (paramImageSource1.getBitmap() == null) {
        if (paramImageSource1.getSWidth() > 0 && paramImageSource1.getSHeight() > 0) {
          this.sWidth = paramImageSource1.getSWidth();
          this.sHeight = paramImageSource1.getSHeight();
          this.pRegion = paramImageSource2.getSRegion();
          if (paramImageSource2.getBitmap() != null) {
            this.bitmapIsCached = paramImageSource2.isCached();
            onPreviewLoaded(paramImageSource2.getBitmap());
          } else {
            Uri uri2 = paramImageSource2.getUri();
            Uri uri1 = uri2;
            if (uri2 == null) {
              uri1 = uri2;
              if (paramImageSource2.getResource() != null) {
                StringBuilder stringBuilder = s30.x0("android.resource://");
                stringBuilder.append(getContext().getPackageName());
                stringBuilder.append("/");
                stringBuilder.append(paramImageSource2.getResource());
                uri1 = Uri.parse(stringBuilder.toString());
              } 
            } 
            execute(new BitmapLoadTask(this, getContext(), this.bitmapDecoderFactory, uri1, true));
          } 
        } else {
          throw new IllegalArgumentException("Preview image cannot be used unless dimensions are provided for the main image");
        } 
      } else {
        throw new IllegalArgumentException("Preview image cannot be used when a bitmap is provided for the main image");
      }  
    if (paramImageSource1.getBitmap() != null && paramImageSource1.getSRegion() != null) {
      onImageLoaded(Bitmap.createBitmap(paramImageSource1.getBitmap(), (paramImageSource1.getSRegion()).left, (paramImageSource1.getSRegion()).top, paramImageSource1.getSRegion().width(), paramImageSource1.getSRegion().height()), 0, false);
      return;
    } 
    if (paramImageSource1.getBitmap() != null) {
      onImageLoaded(paramImageSource1.getBitmap(), 0, paramImageSource1.isCached());
      return;
    } 
    this.sRegion = paramImageSource1.getSRegion();
    Uri uri = paramImageSource1.getUri();
    this.uri = uri;
    if (uri == null && paramImageSource1.getResource() != null) {
      StringBuilder stringBuilder = s30.x0("android.resource://");
      stringBuilder.append(getContext().getPackageName());
      stringBuilder.append("/");
      stringBuilder.append(paramImageSource1.getResource());
      this.uri = Uri.parse(stringBuilder.toString());
    } 
    if (paramImageSource1.getTile() || this.sRegion != null) {
      execute(new TilesInitTask(this, getContext(), this.regionDecoderFactory, this.uri));
      return;
    } 
    execute(new BitmapLoadTask(this, getContext(), this.bitmapDecoderFactory, this.uri, false));
  }
  
  public final void setImage(ImageSource paramImageSource, ImageViewState paramImageViewState) {
    setImage(paramImageSource, null, paramImageViewState);
  }
  
  public final void setMaxScale(float paramFloat) {
    this.maxScale = paramFloat;
  }
  
  public void setMaxTileSize(int paramInt) {
    this.maxTileWidth = paramInt;
    this.maxTileHeight = paramInt;
  }
  
  public void setMaxTileSize(int paramInt1, int paramInt2) {
    this.maxTileWidth = paramInt1;
    this.maxTileHeight = paramInt2;
  }
  
  public final void setMaximumDpi(int paramInt) {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    setMinScale((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0F / paramInt);
  }
  
  public final void setMinScale(float paramFloat) {
    this.minScale = paramFloat;
  }
  
  public final void setMinimumDpi(int paramInt) {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    setMaxScale((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0F / paramInt);
  }
  
  public final void setMinimumScaleType(int paramInt) {
    if (VALID_SCALE_TYPES.contains(Integer.valueOf(paramInt))) {
      this.minimumScaleType = paramInt;
      if (isReady()) {
        fitToBounds(true);
        invalidate();
      } 
      return;
    } 
    throw new IllegalArgumentException(s30.Z("Invalid scale type: ", paramInt));
  }
  
  public void setMinimumTileDpi(int paramInt) {
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    this.minimumTileDpi = (int)Math.min((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0F, paramInt);
    if (isReady()) {
      reset(false);
      invalidate();
    } 
  }
  
  public void setOnImageEventListener(OnImageEventListener paramOnImageEventListener) {
    this.onImageEventListener = paramOnImageEventListener;
  }
  
  public void setOnLongClickListener(View.OnLongClickListener paramOnLongClickListener) {
    this.onLongClickListener = paramOnLongClickListener;
  }
  
  public void setOnStateChangedListener(OnStateChangedListener paramOnStateChangedListener) {
    this.onStateChangedListener = paramOnStateChangedListener;
  }
  
  public final void setOrientation(int paramInt) {
    if (VALID_ORIENTATIONS.contains(Integer.valueOf(paramInt))) {
      this.orientation = paramInt;
      reset(false);
      invalidate();
      requestLayout();
      return;
    } 
    throw new IllegalArgumentException(s30.Z("Invalid orientation: ", paramInt));
  }
  
  public final void setPanEnabled(boolean paramBoolean) {
    this.panEnabled = paramBoolean;
    if (!paramBoolean) {
      PointF pointF = this.vTranslate;
      if (pointF != null) {
        pointF.x = (getWidth() / 2) - this.scale * (sWidth() / 2);
        this.vTranslate.y = (getHeight() / 2) - this.scale * (sHeight() / 2);
        if (isReady()) {
          refreshRequiredTiles(true);
          invalidate();
        } 
      } 
    } 
  }
  
  public final void setPanLimit(int paramInt) {
    if (VALID_PAN_LIMITS.contains(Integer.valueOf(paramInt))) {
      this.panLimit = paramInt;
      if (isReady()) {
        fitToBounds(true);
        invalidate();
      } 
      return;
    } 
    throw new IllegalArgumentException(s30.Z("Invalid pan limit: ", paramInt));
  }
  
  public final void setQuickScaleEnabled(boolean paramBoolean) {
    this.quickScaleEnabled = paramBoolean;
  }
  
  public final void setRegionDecoderClass(Class<? extends ImageRegionDecoder> paramClass) {
    if (paramClass != null) {
      this.regionDecoderFactory = (DecoderFactory<? extends ImageRegionDecoder>)new CompatDecoderFactory(paramClass);
      return;
    } 
    throw new IllegalArgumentException("Decoder class cannot be set to null");
  }
  
  public final void setRegionDecoderFactory(DecoderFactory<? extends ImageRegionDecoder> paramDecoderFactory) {
    if (paramDecoderFactory != null) {
      this.regionDecoderFactory = paramDecoderFactory;
      return;
    } 
    throw new IllegalArgumentException("Decoder factory cannot be set to null");
  }
  
  public final void setScaleAndCenter(float paramFloat, PointF paramPointF) {
    this.anim = null;
    this.pendingScale = Float.valueOf(paramFloat);
    this.sPendingCenter = paramPointF;
    this.sRequestedCenter = paramPointF;
    invalidate();
  }
  
  public final void setTileBackgroundColor(int paramInt) {
    if (Color.alpha(paramInt) == 0) {
      this.tileBgPaint = null;
    } else {
      Paint paint = new Paint();
      this.tileBgPaint = paint;
      paint.setStyle(Paint.Style.FILL);
      this.tileBgPaint.setColor(paramInt);
    } 
    invalidate();
  }
  
  public final void setZoomEnabled(boolean paramBoolean) {
    this.zoomEnabled = paramBoolean;
  }
  
  public final PointF sourceToViewCoord(float paramFloat1, float paramFloat2) {
    return sourceToViewCoord(paramFloat1, paramFloat2, new PointF());
  }
  
  public final PointF sourceToViewCoord(float paramFloat1, float paramFloat2, PointF paramPointF) {
    if (this.vTranslate == null)
      return null; 
    paramPointF.set(sourceToViewX(paramFloat1), sourceToViewY(paramFloat2));
    return paramPointF;
  }
  
  public final PointF sourceToViewCoord(PointF paramPointF) {
    return sourceToViewCoord(paramPointF.x, paramPointF.y, new PointF());
  }
  
  public final PointF sourceToViewCoord(PointF paramPointF1, PointF paramPointF2) {
    return sourceToViewCoord(paramPointF1.x, paramPointF1.y, paramPointF2);
  }
  
  public void viewToFileRect(Rect paramRect1, Rect paramRect2) {
    if (this.vTranslate != null) {
      if (!this.readySent)
        return; 
      paramRect2.set((int)viewToSourceX(paramRect1.left), (int)viewToSourceY(paramRect1.top), (int)viewToSourceX(paramRect1.right), (int)viewToSourceY(paramRect1.bottom));
      fileSRect(paramRect2, paramRect2);
      paramRect2.set(Math.max(0, paramRect2.left), Math.max(0, paramRect2.top), Math.min(this.sWidth, paramRect2.right), Math.min(this.sHeight, paramRect2.bottom));
      paramRect1 = this.sRegion;
      if (paramRect1 != null)
        paramRect2.offset(paramRect1.left, paramRect1.top); 
    } 
  }
  
  public final PointF viewToSourceCoord(float paramFloat1, float paramFloat2) {
    return viewToSourceCoord(paramFloat1, paramFloat2, new PointF());
  }
  
  public final PointF viewToSourceCoord(float paramFloat1, float paramFloat2, PointF paramPointF) {
    if (this.vTranslate == null)
      return null; 
    paramPointF.set(viewToSourceX(paramFloat1), viewToSourceY(paramFloat2));
    return paramPointF;
  }
  
  public final PointF viewToSourceCoord(PointF paramPointF) {
    return viewToSourceCoord(paramPointF.x, paramPointF.y, new PointF());
  }
  
  public final PointF viewToSourceCoord(PointF paramPointF1, PointF paramPointF2) {
    return viewToSourceCoord(paramPointF1.x, paramPointF1.y, paramPointF2);
  }
  
  public void visibleFileRect(Rect paramRect) {
    if (this.vTranslate != null) {
      if (!this.readySent)
        return; 
      paramRect.set(0, 0, getWidth(), getHeight());
      viewToFileRect(paramRect, paramRect);
    } 
  }
  
  static {
    Integer integer1 = Integer.valueOf(1);
    Integer integer2 = Integer.valueOf(2);
    Integer integer3 = Integer.valueOf(3);
  }
  
  public static class Anim {
    private long duration = 500L;
    
    private int easing = 2;
    
    private boolean interruptible = true;
    
    private SubsamplingScaleImageView.OnAnimationEventListener listener;
    
    private int origin = 1;
    
    private PointF sCenterEnd;
    
    private PointF sCenterEndRequested;
    
    private PointF sCenterStart;
    
    private float scaleEnd;
    
    private float scaleStart;
    
    private long time = System.currentTimeMillis();
    
    private PointF vFocusEnd;
    
    private PointF vFocusStart;
    
    private Anim() {}
  }
  
  public final class AnimationBuilder {
    private long duration = 500L;
    
    private int easing = 2;
    
    private boolean interruptible = true;
    
    private SubsamplingScaleImageView.OnAnimationEventListener listener;
    
    private int origin = 1;
    
    private boolean panLimited = true;
    
    private final PointF targetSCenter;
    
    private final float targetScale;
    
    private final PointF vFocus;
    
    private AnimationBuilder(float param1Float) {
      this.targetScale = param1Float;
      this.targetSCenter = SubsamplingScaleImageView.this.getCenter();
      this.vFocus = null;
    }
    
    private AnimationBuilder(float param1Float, PointF param1PointF) {
      this.targetScale = param1Float;
      this.targetSCenter = param1PointF;
      this.vFocus = null;
    }
    
    private AnimationBuilder(float param1Float, PointF param1PointF1, PointF param1PointF2) {
      this.targetScale = param1Float;
      this.targetSCenter = param1PointF1;
      this.vFocus = param1PointF2;
    }
    
    private AnimationBuilder(PointF param1PointF) {
      this.targetScale = SubsamplingScaleImageView.this.scale;
      this.targetSCenter = param1PointF;
      this.vFocus = null;
    }
    
    private AnimationBuilder withOrigin(int param1Int) {
      this.origin = param1Int;
      return this;
    }
    
    private AnimationBuilder withPanLimited(boolean param1Boolean) {
      this.panLimited = param1Boolean;
      return this;
    }
    
    public void start() {
      if (SubsamplingScaleImageView.this.anim != null && SubsamplingScaleImageView.this.anim.listener != null)
        try {
          SubsamplingScaleImageView.this.anim.listener.onInterruptedByNewAnim();
        } catch (Exception exception) {
          SubsamplingScaleImageView.TAG;
        }  
      int i = SubsamplingScaleImageView.this.getPaddingLeft();
      int j = (SubsamplingScaleImageView.this.getWidth() - SubsamplingScaleImageView.this.getPaddingRight() - SubsamplingScaleImageView.this.getPaddingLeft()) / 2;
      int k = SubsamplingScaleImageView.this.getPaddingTop();
      int m = (SubsamplingScaleImageView.this.getHeight() - SubsamplingScaleImageView.this.getPaddingBottom() - SubsamplingScaleImageView.this.getPaddingTop()) / 2;
      float f = SubsamplingScaleImageView.this.limitedScale(this.targetScale);
      if (this.panLimited) {
        SubsamplingScaleImageView subsamplingScaleImageView = SubsamplingScaleImageView.this;
        PointF pointF1 = this.targetSCenter;
        pointF = subsamplingScaleImageView.limitedSCenter(pointF1.x, pointF1.y, f, new PointF());
      } else {
        pointF = this.targetSCenter;
      } 
      SubsamplingScaleImageView.access$6402(SubsamplingScaleImageView.this, new SubsamplingScaleImageView.Anim());
      SubsamplingScaleImageView.Anim.access$3502(SubsamplingScaleImageView.this.anim, SubsamplingScaleImageView.this.scale);
      SubsamplingScaleImageView.Anim.access$3602(SubsamplingScaleImageView.this.anim, f);
      SubsamplingScaleImageView.Anim.access$3202(SubsamplingScaleImageView.this.anim, System.currentTimeMillis());
      SubsamplingScaleImageView.Anim.access$4502(SubsamplingScaleImageView.this.anim, pointF);
      SubsamplingScaleImageView.Anim.access$4402(SubsamplingScaleImageView.this.anim, SubsamplingScaleImageView.this.getCenter());
      SubsamplingScaleImageView.Anim.access$3802(SubsamplingScaleImageView.this.anim, pointF);
      SubsamplingScaleImageView.Anim.access$3102(SubsamplingScaleImageView.this.anim, SubsamplingScaleImageView.this.sourceToViewCoord(pointF));
      SubsamplingScaleImageView.Anim.access$3702(SubsamplingScaleImageView.this.anim, new PointF((j + i), (m + k)));
      SubsamplingScaleImageView.Anim.access$3302(SubsamplingScaleImageView.this.anim, this.duration);
      SubsamplingScaleImageView.Anim.access$2702(SubsamplingScaleImageView.this.anim, this.interruptible);
      SubsamplingScaleImageView.Anim.access$3402(SubsamplingScaleImageView.this.anim, this.easing);
      SubsamplingScaleImageView.Anim.access$3902(SubsamplingScaleImageView.this.anim, this.origin);
      SubsamplingScaleImageView.Anim.access$3202(SubsamplingScaleImageView.this.anim, System.currentTimeMillis());
      SubsamplingScaleImageView.Anim.access$2802(SubsamplingScaleImageView.this.anim, this.listener);
      PointF pointF = this.vFocus;
      if (pointF != null) {
        float f1 = pointF.x - SubsamplingScaleImageView.this.anim.sCenterStart.x * f;
        float f2 = this.vFocus.y - SubsamplingScaleImageView.this.anim.sCenterStart.y * f;
        SubsamplingScaleImageView.ScaleAndTranslate scaleAndTranslate = new SubsamplingScaleImageView.ScaleAndTranslate(f, new PointF(f1, f2));
        SubsamplingScaleImageView.this.fitToBounds(true, scaleAndTranslate);
        SubsamplingScaleImageView.Anim anim = SubsamplingScaleImageView.this.anim;
        f = this.vFocus.x;
        float f3 = scaleAndTranslate.vTranslate.x;
        float f4 = this.vFocus.y;
        SubsamplingScaleImageView.Anim.access$3702(anim, new PointF(f3 - f1 + f, scaleAndTranslate.vTranslate.y - f2 + f4));
      } 
      SubsamplingScaleImageView.this.invalidate();
    }
    
    public AnimationBuilder withDuration(long param1Long) {
      this.duration = param1Long;
      return this;
    }
    
    public AnimationBuilder withEasing(int param1Int) {
      if (SubsamplingScaleImageView.VALID_EASING_STYLES.contains(Integer.valueOf(param1Int))) {
        this.easing = param1Int;
        return this;
      } 
      throw new IllegalArgumentException(s30.Z("Unknown easing type: ", param1Int));
    }
    
    public AnimationBuilder withInterruptible(boolean param1Boolean) {
      this.interruptible = param1Boolean;
      return this;
    }
    
    public AnimationBuilder withOnAnimationEventListener(SubsamplingScaleImageView.OnAnimationEventListener param1OnAnimationEventListener) {
      this.listener = param1OnAnimationEventListener;
      return this;
    }
  }
  
  public static class BitmapLoadTask extends AsyncTask<Void, Void, Integer> {
    private Bitmap bitmap;
    
    private final WeakReference<Context> contextRef;
    
    private final WeakReference<DecoderFactory<? extends ImageDecoder>> decoderFactoryRef;
    
    private Exception exception;
    
    private final boolean preview;
    
    private final Uri source;
    
    private final WeakReference<SubsamplingScaleImageView> viewRef;
    
    public BitmapLoadTask(SubsamplingScaleImageView param1SubsamplingScaleImageView, Context param1Context, DecoderFactory<? extends ImageDecoder> param1DecoderFactory, Uri param1Uri, boolean param1Boolean) {
      this.viewRef = new WeakReference<SubsamplingScaleImageView>(param1SubsamplingScaleImageView);
      this.contextRef = new WeakReference<Context>(param1Context);
      this.decoderFactoryRef = new WeakReference<DecoderFactory<? extends ImageDecoder>>(param1DecoderFactory);
      this.source = param1Uri;
      this.preview = param1Boolean;
    }
    
    public Integer doInBackground(Void... param1VarArgs) {
      try {
        String str = this.source.toString();
        Context context = this.contextRef.get();
        DecoderFactory decoderFactory = this.decoderFactoryRef.get();
        SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
        if (context != null && decoderFactory != null && subsamplingScaleImageView != null) {
          subsamplingScaleImageView.debug("BitmapLoadTask.doInBackground", new Object[0]);
          this.bitmap = ((ImageDecoder)decoderFactory.make()).decode(context, this.source);
          int i = subsamplingScaleImageView.getExifOrientation(context, str);
          return Integer.valueOf(i);
        } 
      } catch (Exception exception) {
        SubsamplingScaleImageView.TAG;
        this.exception = exception;
      } catch (OutOfMemoryError outOfMemoryError) {
        SubsamplingScaleImageView.TAG;
        this.exception = new RuntimeException(outOfMemoryError);
      } 
      return null;
    }
    
    public void onPostExecute(Integer param1Integer) {
      SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
      if (subsamplingScaleImageView != null) {
        Bitmap bitmap = this.bitmap;
        if (bitmap != null && param1Integer != null) {
          if (this.preview) {
            subsamplingScaleImageView.onPreviewLoaded(bitmap);
            return;
          } 
          subsamplingScaleImageView.onImageLoaded(bitmap, param1Integer.intValue(), false);
          return;
        } 
        if (this.exception != null && subsamplingScaleImageView.onImageEventListener != null) {
          if (this.preview) {
            subsamplingScaleImageView.onImageEventListener.onPreviewLoadError(this.exception);
            return;
          } 
          subsamplingScaleImageView.onImageEventListener.onImageLoadError(this.exception);
        } 
      } 
    }
  }
  
  public static class DefaultOnAnimationEventListener implements OnAnimationEventListener {
    public void onComplete() {}
    
    public void onInterruptedByNewAnim() {}
    
    public void onInterruptedByUser() {}
  }
  
  public static class DefaultOnImageEventListener implements OnImageEventListener {
    public void onImageLoadError(Exception param1Exception) {}
    
    public void onImageLoaded() {}
    
    public void onPreviewLoadError(Exception param1Exception) {}
    
    public void onPreviewReleased() {}
    
    public void onReady() {}
    
    public void onTileLoadError(Exception param1Exception) {}
  }
  
  public static class DefaultOnStateChangedListener implements OnStateChangedListener {
    public void onCenterChanged(PointF param1PointF, int param1Int) {}
    
    public void onScaleChanged(float param1Float, int param1Int) {}
  }
  
  public static interface OnAnimationEventListener {
    void onComplete();
    
    void onInterruptedByNewAnim();
    
    void onInterruptedByUser();
  }
  
  public static interface OnImageEventListener {
    void onImageLoadError(Exception param1Exception);
    
    void onImageLoaded();
    
    void onPreviewLoadError(Exception param1Exception);
    
    void onPreviewReleased();
    
    void onReady();
    
    void onTileLoadError(Exception param1Exception);
  }
  
  public static interface OnStateChangedListener {
    void onCenterChanged(PointF param1PointF, int param1Int);
    
    void onScaleChanged(float param1Float, int param1Int);
  }
  
  public static class ScaleAndTranslate {
    private float scale;
    
    private final PointF vTranslate;
    
    private ScaleAndTranslate(float param1Float, PointF param1PointF) {
      this.scale = param1Float;
      this.vTranslate = param1PointF;
    }
  }
  
  public static class Tile {
    private Bitmap bitmap;
    
    private Rect fileSRect;
    
    private boolean loading;
    
    private Rect sRect;
    
    private int sampleSize;
    
    private Rect vRect;
    
    private boolean visible;
    
    private Tile() {}
  }
  
  public static class TileLoadTask extends AsyncTask<Void, Void, Bitmap> {
    private final WeakReference<ImageRegionDecoder> decoderRef;
    
    private Exception exception;
    
    private final WeakReference<SubsamplingScaleImageView.Tile> tileRef;
    
    private final WeakReference<SubsamplingScaleImageView> viewRef;
    
    public TileLoadTask(SubsamplingScaleImageView param1SubsamplingScaleImageView, ImageRegionDecoder param1ImageRegionDecoder, SubsamplingScaleImageView.Tile param1Tile) {
      this.viewRef = new WeakReference<SubsamplingScaleImageView>(param1SubsamplingScaleImageView);
      this.decoderRef = new WeakReference<ImageRegionDecoder>(param1ImageRegionDecoder);
      this.tileRef = new WeakReference<SubsamplingScaleImageView.Tile>(param1Tile);
      SubsamplingScaleImageView.Tile.access$4002(param1Tile, true);
    }
    
    public Bitmap doInBackground(Void... param1VarArgs) {
      try {
        SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
        ImageRegionDecoder imageRegionDecoder = this.decoderRef.get();
        SubsamplingScaleImageView.Tile tile = this.tileRef.get();
        if (imageRegionDecoder != null && tile != null && subsamplingScaleImageView != null && imageRegionDecoder.isReady() && tile.visible) {
          subsamplingScaleImageView.debug("TileLoadTask.doInBackground, tile.sRect=%s, tile.sampleSize=%d", new Object[] { SubsamplingScaleImageView.Tile.access$4100(tile), Integer.valueOf(SubsamplingScaleImageView.Tile.access$4300(tile)) });
          subsamplingScaleImageView.decoderLock.readLock().lock();
          try {
            if (imageRegionDecoder.isReady()) {
              subsamplingScaleImageView.fileSRect(tile.sRect, tile.fileSRect);
              if (subsamplingScaleImageView.sRegion != null)
                tile.fileSRect.offset(subsamplingScaleImageView.sRegion.left, subsamplingScaleImageView.sRegion.top); 
              return imageRegionDecoder.decodeRegion(tile.fileSRect, tile.sampleSize);
            } 
            SubsamplingScaleImageView.Tile.access$4002(tile, false);
          } finally {
            subsamplingScaleImageView.decoderLock.readLock().unlock();
          } 
        } else if (tile != null) {
          SubsamplingScaleImageView.Tile.access$4002(tile, false);
        } 
      } catch (Exception exception) {
        SubsamplingScaleImageView.TAG;
        this.exception = exception;
      } catch (OutOfMemoryError outOfMemoryError) {
        SubsamplingScaleImageView.TAG;
        this.exception = new RuntimeException(outOfMemoryError);
      } 
      return null;
    }
    
    public void onPostExecute(Bitmap param1Bitmap) {
      SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
      SubsamplingScaleImageView.Tile tile = this.tileRef.get();
      if (subsamplingScaleImageView != null && tile != null) {
        if (param1Bitmap != null) {
          SubsamplingScaleImageView.Tile.access$502(tile, param1Bitmap);
          SubsamplingScaleImageView.Tile.access$4002(tile, false);
          subsamplingScaleImageView.onTileLoaded();
          return;
        } 
        if (this.exception != null && subsamplingScaleImageView.onImageEventListener != null)
          subsamplingScaleImageView.onImageEventListener.onTileLoadError(this.exception); 
      } 
    }
  }
  
  public static class TilesInitTask extends AsyncTask<Void, Void, int[]> {
    private final WeakReference<Context> contextRef;
    
    private ImageRegionDecoder decoder;
    
    private final WeakReference<DecoderFactory<? extends ImageRegionDecoder>> decoderFactoryRef;
    
    private Exception exception;
    
    private final Uri source;
    
    private final WeakReference<SubsamplingScaleImageView> viewRef;
    
    public TilesInitTask(SubsamplingScaleImageView param1SubsamplingScaleImageView, Context param1Context, DecoderFactory<? extends ImageRegionDecoder> param1DecoderFactory, Uri param1Uri) {
      this.viewRef = new WeakReference<SubsamplingScaleImageView>(param1SubsamplingScaleImageView);
      this.contextRef = new WeakReference<Context>(param1Context);
      this.decoderFactoryRef = new WeakReference<DecoderFactory<? extends ImageRegionDecoder>>(param1DecoderFactory);
      this.source = param1Uri;
    }
    
    public int[] doInBackground(Void... param1VarArgs) {
      try {
        String str = this.source.toString();
        Context context = this.contextRef.get();
        DecoderFactory decoderFactory = this.decoderFactoryRef.get();
        SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
        if (context != null && decoderFactory != null && subsamplingScaleImageView != null) {
          subsamplingScaleImageView.debug("TilesInitTask.doInBackground", new Object[0]);
          ImageRegionDecoder imageRegionDecoder = (ImageRegionDecoder)decoderFactory.make();
          this.decoder = imageRegionDecoder;
          Point point = imageRegionDecoder.init(context, this.source);
          int k = point.x;
          int m = point.y;
          int n = subsamplingScaleImageView.getExifOrientation(context, str);
          int j = m;
          int i = k;
          if (subsamplingScaleImageView.sRegion != null) {
            subsamplingScaleImageView.sRegion.left = Math.max(0, subsamplingScaleImageView.sRegion.left);
            subsamplingScaleImageView.sRegion.top = Math.max(0, subsamplingScaleImageView.sRegion.top);
            subsamplingScaleImageView.sRegion.right = Math.min(k, subsamplingScaleImageView.sRegion.right);
            subsamplingScaleImageView.sRegion.bottom = Math.min(m, subsamplingScaleImageView.sRegion.bottom);
            i = subsamplingScaleImageView.sRegion.width();
            j = subsamplingScaleImageView.sRegion.height();
          } 
          return new int[] { i, j, n };
        } 
      } catch (Exception exception) {
        SubsamplingScaleImageView.TAG;
        this.exception = exception;
      } 
      return null;
    }
    
    public void onPostExecute(int[] param1ArrayOfint) {
      SubsamplingScaleImageView subsamplingScaleImageView = this.viewRef.get();
      if (subsamplingScaleImageView != null) {
        ImageRegionDecoder imageRegionDecoder = this.decoder;
        if (imageRegionDecoder != null && param1ArrayOfint != null && param1ArrayOfint.length == 3) {
          subsamplingScaleImageView.onTilesInited(imageRegionDecoder, param1ArrayOfint[0], param1ArrayOfint[1], param1ArrayOfint[2]);
          return;
        } 
        if (this.exception != null && subsamplingScaleImageView.onImageEventListener != null)
          subsamplingScaleImageView.onImageEventListener.onImageLoadError(this.exception); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\SubsamplingScaleImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */