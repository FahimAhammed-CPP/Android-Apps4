package com.davemorrissey.labs.subscaleview;

import android.graphics.PointF;
import java.io.Serializable;

public class ImageViewState implements Serializable {
  private final float centerX;
  
  private final float centerY;
  
  private final int orientation;
  
  private final float scale;
  
  public ImageViewState(float paramFloat, PointF paramPointF, int paramInt) {
    this.scale = paramFloat;
    this.centerX = paramPointF.x;
    this.centerY = paramPointF.y;
    this.orientation = paramInt;
  }
  
  public PointF getCenter() {
    return new PointF(this.centerX, this.centerY);
  }
  
  public int getOrientation() {
    return this.orientation;
  }
  
  public float getScale() {
    return this.scale;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\ImageViewState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */