package com.davemorrissey.labs.subscaleview.decoder;

import android.graphics.Bitmap;

public class CompatDecoderFactory<T> implements DecoderFactory<T> {
  private final Bitmap.Config bitmapConfig;
  
  private final Class<? extends T> clazz;
  
  public CompatDecoderFactory(Class<? extends T> paramClass) {
    this(paramClass, null);
  }
  
  public CompatDecoderFactory(Class<? extends T> paramClass, Bitmap.Config paramConfig) {
    this.clazz = paramClass;
    this.bitmapConfig = paramConfig;
  }
  
  public T make() {
    return (this.bitmapConfig == null) ? this.clazz.newInstance() : this.clazz.getConstructor(new Class[] { Bitmap.Config.class }).newInstance(new Object[] { this.bitmapConfig });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\decoder\CompatDecoderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */