package com.davemorrissey.labs.subscaleview.decoder;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import androidx.annotation.Keep;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.io.File;
import java.io.FileFilter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Pattern;
import s30;

public class SkiaPooledImageRegionDecoder implements ImageRegionDecoder {
  private static final String ASSET_PREFIX = "file:///android_asset/";
  
  private static final String FILE_PREFIX = "file://";
  
  private static final String RESOURCE_PREFIX = "android.resource://";
  
  private static final String TAG = "SkiaPooledImageRegionDecoder";
  
  private static boolean debug = false;
  
  private final Bitmap.Config bitmapConfig;
  
  private Context context;
  
  private final ReadWriteLock decoderLock = new ReentrantReadWriteLock(true);
  
  private DecoderPool decoderPool = new DecoderPool();
  
  private long fileLength = Long.MAX_VALUE;
  
  private final Point imageDimensions = new Point(0, 0);
  
  private final AtomicBoolean lazyInited = new AtomicBoolean(false);
  
  private Uri uri;
  
  @Keep
  public SkiaPooledImageRegionDecoder() {
    this(null);
  }
  
  public SkiaPooledImageRegionDecoder(Bitmap.Config paramConfig) {
    Bitmap.Config config = SubsamplingScaleImageView.getPreferredBitmapConfig();
    if (paramConfig != null) {
      this.bitmapConfig = paramConfig;
      return;
    } 
    if (config != null) {
      this.bitmapConfig = config;
      return;
    } 
    this.bitmapConfig = Bitmap.Config.RGB_565;
  }
  
  private void debug(String paramString) {
    boolean bool = debug;
  }
  
  private int getNumCoresOldPhones() {
    try {
      public class CpuFilter implements FileFilter {
        public boolean accept(File param1File) {
          return Pattern.matches("cpu[0-9]+", param1File.getName());
        }
      };
      return ((new File("/sys/devices/system/cpu/")).listFiles(new CpuFilter())).length;
    } catch (Exception exception) {
      return 1;
    } 
  }
  
  private int getNumberOfCores() {
    return Runtime.getRuntime().availableProcessors();
  }
  
  private void initialiseDecoder() {
    // Byte code:
    //   0: aload_0
    //   1: getfield uri : Landroid/net/Uri;
    //   4: invokevirtual toString : ()Ljava/lang/String;
    //   7: astore #8
    //   9: aload #8
    //   11: ldc 'android.resource://'
    //   13: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   16: istore_2
    //   17: ldc2_w 9223372036854775807
    //   20: lstore_3
    //   21: iload_2
    //   22: ifeq -> 221
    //   25: aload_0
    //   26: getfield uri : Landroid/net/Uri;
    //   29: invokevirtual getAuthority : ()Ljava/lang/String;
    //   32: astore #8
    //   34: aload_0
    //   35: getfield context : Landroid/content/Context;
    //   38: invokevirtual getPackageName : ()Ljava/lang/String;
    //   41: aload #8
    //   43: invokevirtual equals : (Ljava/lang/Object;)Z
    //   46: ifeq -> 61
    //   49: aload_0
    //   50: getfield context : Landroid/content/Context;
    //   53: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   56: astore #7
    //   58: goto -> 75
    //   61: aload_0
    //   62: getfield context : Landroid/content/Context;
    //   65: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   68: aload #8
    //   70: invokevirtual getResourcesForApplication : (Ljava/lang/String;)Landroid/content/res/Resources;
    //   73: astore #7
    //   75: aload_0
    //   76: getfield uri : Landroid/net/Uri;
    //   79: invokevirtual getPathSegments : ()Ljava/util/List;
    //   82: astore #9
    //   84: aload #9
    //   86: invokeinterface size : ()I
    //   91: istore_1
    //   92: iload_1
    //   93: iconst_2
    //   94: if_icmpne -> 140
    //   97: aload #9
    //   99: iconst_0
    //   100: invokeinterface get : (I)Ljava/lang/Object;
    //   105: checkcast java/lang/String
    //   108: ldc 'drawable'
    //   110: invokevirtual equals : (Ljava/lang/Object;)Z
    //   113: ifeq -> 140
    //   116: aload #7
    //   118: aload #9
    //   120: iconst_1
    //   121: invokeinterface get : (I)Ljava/lang/Object;
    //   126: checkcast java/lang/String
    //   129: ldc 'drawable'
    //   131: aload #8
    //   133: invokevirtual getIdentifier : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   136: istore_1
    //   137: goto -> 182
    //   140: iload_1
    //   141: iconst_1
    //   142: if_icmpne -> 180
    //   145: aload #9
    //   147: iconst_0
    //   148: invokeinterface get : (I)Ljava/lang/Object;
    //   153: checkcast java/lang/CharSequence
    //   156: invokestatic isDigitsOnly : (Ljava/lang/CharSequence;)Z
    //   159: ifeq -> 180
    //   162: aload #9
    //   164: iconst_0
    //   165: invokeinterface get : (I)Ljava/lang/Object;
    //   170: checkcast java/lang/String
    //   173: invokestatic parseInt : (Ljava/lang/String;)I
    //   176: istore_1
    //   177: goto -> 182
    //   180: iconst_0
    //   181: istore_1
    //   182: aload_0
    //   183: getfield context : Landroid/content/Context;
    //   186: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   189: iload_1
    //   190: invokevirtual openRawResourceFd : (I)Landroid/content/res/AssetFileDescriptor;
    //   193: invokevirtual getLength : ()J
    //   196: lstore #5
    //   198: lload #5
    //   200: lstore_3
    //   201: aload_0
    //   202: getfield context : Landroid/content/Context;
    //   205: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   208: iload_1
    //   209: invokevirtual openRawResource : (I)Ljava/io/InputStream;
    //   212: iconst_0
    //   213: invokestatic newInstance : (Ljava/io/InputStream;Z)Landroid/graphics/BitmapRegionDecoder;
    //   216: astore #7
    //   218: goto -> 440
    //   221: aload #8
    //   223: ldc 'file:///android_asset/'
    //   225: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   228: ifeq -> 282
    //   231: aload #8
    //   233: bipush #22
    //   235: invokevirtual substring : (I)Ljava/lang/String;
    //   238: astore #7
    //   240: aload_0
    //   241: getfield context : Landroid/content/Context;
    //   244: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   247: aload #7
    //   249: invokevirtual openFd : (Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;
    //   252: invokevirtual getLength : ()J
    //   255: lstore #5
    //   257: lload #5
    //   259: lstore_3
    //   260: aload_0
    //   261: getfield context : Landroid/content/Context;
    //   264: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   267: aload #7
    //   269: iconst_1
    //   270: invokevirtual open : (Ljava/lang/String;I)Ljava/io/InputStream;
    //   273: iconst_0
    //   274: invokestatic newInstance : (Ljava/io/InputStream;Z)Landroid/graphics/BitmapRegionDecoder;
    //   277: astore #7
    //   279: goto -> 440
    //   282: aload #8
    //   284: ldc 'file://'
    //   286: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   289: ifeq -> 340
    //   292: aload #8
    //   294: bipush #7
    //   296: invokevirtual substring : (I)Ljava/lang/String;
    //   299: iconst_0
    //   300: invokestatic newInstance : (Ljava/lang/String;Z)Landroid/graphics/BitmapRegionDecoder;
    //   303: astore #7
    //   305: new java/io/File
    //   308: dup
    //   309: aload #8
    //   311: invokespecial <init> : (Ljava/lang/String;)V
    //   314: astore #8
    //   316: lload_3
    //   317: lstore #5
    //   319: aload #8
    //   321: invokevirtual exists : ()Z
    //   324: ifeq -> 334
    //   327: aload #8
    //   329: invokevirtual length : ()J
    //   332: lstore #5
    //   334: lload #5
    //   336: lstore_3
    //   337: goto -> 440
    //   340: aconst_null
    //   341: astore #8
    //   343: aload #8
    //   345: astore #7
    //   347: aload_0
    //   348: getfield context : Landroid/content/Context;
    //   351: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   354: astore #10
    //   356: aload #8
    //   358: astore #7
    //   360: aload #10
    //   362: aload_0
    //   363: getfield uri : Landroid/net/Uri;
    //   366: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   369: astore #9
    //   371: aload #9
    //   373: astore #7
    //   375: aload #9
    //   377: iconst_0
    //   378: invokestatic newInstance : (Ljava/io/InputStream;Z)Landroid/graphics/BitmapRegionDecoder;
    //   381: astore #8
    //   383: aload #9
    //   385: astore #7
    //   387: aload #10
    //   389: aload_0
    //   390: getfield uri : Landroid/net/Uri;
    //   393: ldc_w 'r'
    //   396: invokevirtual openAssetFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;
    //   399: astore #10
    //   401: lload_3
    //   402: lstore #5
    //   404: aload #10
    //   406: ifnull -> 423
    //   409: aload #9
    //   411: astore #7
    //   413: aload #10
    //   415: invokevirtual getLength : ()J
    //   418: lstore #5
    //   420: goto -> 423
    //   423: aload #9
    //   425: ifnull -> 433
    //   428: aload #9
    //   430: invokevirtual close : ()V
    //   433: aload #8
    //   435: astore #7
    //   437: lload #5
    //   439: lstore_3
    //   440: aload_0
    //   441: lload_3
    //   442: putfield fileLength : J
    //   445: aload_0
    //   446: getfield imageDimensions : Landroid/graphics/Point;
    //   449: aload #7
    //   451: invokevirtual getWidth : ()I
    //   454: aload #7
    //   456: invokevirtual getHeight : ()I
    //   459: invokevirtual set : (II)V
    //   462: aload_0
    //   463: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   466: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   471: invokeinterface lock : ()V
    //   476: aload_0
    //   477: getfield decoderPool : Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;
    //   480: astore #8
    //   482: aload #8
    //   484: ifnull -> 494
    //   487: aload #8
    //   489: aload #7
    //   491: invokestatic access$600 : (Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;Landroid/graphics/BitmapRegionDecoder;)V
    //   494: aload_0
    //   495: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   498: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   503: invokeinterface unlock : ()V
    //   508: return
    //   509: astore #7
    //   511: aload_0
    //   512: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   515: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   520: invokeinterface unlock : ()V
    //   525: aload #7
    //   527: athrow
    //   528: astore #8
    //   530: aload #7
    //   532: ifnull -> 540
    //   535: aload #7
    //   537: invokevirtual close : ()V
    //   540: aload #8
    //   542: athrow
    //   543: astore #7
    //   545: goto -> 180
    //   548: astore #7
    //   550: goto -> 201
    //   553: astore #8
    //   555: goto -> 260
    //   558: astore #8
    //   560: lload_3
    //   561: lstore #5
    //   563: goto -> 334
    //   566: astore #7
    //   568: lload_3
    //   569: lstore #5
    //   571: goto -> 423
    //   574: astore #7
    //   576: goto -> 433
    //   579: astore #7
    //   581: goto -> 540
    // Exception table:
    //   from	to	target	type
    //   162	177	543	java/lang/NumberFormatException
    //   182	198	548	java/lang/Exception
    //   240	257	553	java/lang/Exception
    //   305	316	558	java/lang/Exception
    //   319	334	558	java/lang/Exception
    //   347	356	528	finally
    //   360	371	528	finally
    //   375	383	528	finally
    //   387	401	566	java/lang/Exception
    //   387	401	528	finally
    //   413	420	566	java/lang/Exception
    //   413	420	528	finally
    //   428	433	574	java/lang/Exception
    //   476	482	509	finally
    //   487	494	509	finally
    //   535	540	579	java/lang/Exception
  }
  
  private boolean isLowMemory() {
    ActivityManager activityManager = (ActivityManager)this.context.getSystemService("activity");
    if (activityManager != null) {
      ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
      activityManager.getMemoryInfo(memoryInfo);
      return memoryInfo.lowMemory;
    } 
    return true;
  }
  
  private void lazyInit() {
    if (this.lazyInited.compareAndSet(false, true) && this.fileLength < Long.MAX_VALUE) {
      debug("Starting lazy init of additional decoders");
      (new Thread() {
          public void run() {
            while (SkiaPooledImageRegionDecoder.this.decoderPool != null) {
              SkiaPooledImageRegionDecoder skiaPooledImageRegionDecoder = SkiaPooledImageRegionDecoder.this;
              if (skiaPooledImageRegionDecoder.allowAdditionalDecoder(skiaPooledImageRegionDecoder.decoderPool.size(), SkiaPooledImageRegionDecoder.this.fileLength))
                try {
                  if (SkiaPooledImageRegionDecoder.this.decoderPool != null) {
                    long l1 = System.currentTimeMillis();
                    SkiaPooledImageRegionDecoder.this.debug("Starting decoder");
                    SkiaPooledImageRegionDecoder.this.initialiseDecoder();
                    long l2 = System.currentTimeMillis();
                    skiaPooledImageRegionDecoder = SkiaPooledImageRegionDecoder.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Started decoder, took ");
                    stringBuilder.append(l2 - l1);
                    stringBuilder.append("ms");
                    skiaPooledImageRegionDecoder.debug(stringBuilder.toString());
                  } 
                } catch (Exception exception) {
                  SkiaPooledImageRegionDecoder skiaPooledImageRegionDecoder1 = SkiaPooledImageRegionDecoder.this;
                  StringBuilder stringBuilder = s30.x0("Failed to start decoder: ");
                  stringBuilder.append(exception.getMessage());
                  skiaPooledImageRegionDecoder1.debug(stringBuilder.toString());
                }  
            } 
          }
        }).start();
    } 
  }
  
  @Keep
  public static void setDebug(boolean paramBoolean) {
    debug = paramBoolean;
  }
  
  public boolean allowAdditionalDecoder(int paramInt, long paramLong) {
    if (paramInt >= 4) {
      debug("No additional decoders allowed, reached hard limit (4)");
      return false;
    } 
    paramLong = paramInt * paramLong;
    if (paramLong > 20971520L) {
      debug("No additional encoders allowed, reached hard memory limit (20Mb)");
      return false;
    } 
    if (paramInt >= getNumberOfCores()) {
      debug(s30.l0(s30.x0("No additional encoders allowed, limited by CPU cores ("), getNumberOfCores(), ")"));
      return false;
    } 
    if (isLowMemory()) {
      debug("No additional encoders allowed, memory is low");
      return false;
    } 
    StringBuilder stringBuilder = s30.z0("Additional decoder allowed, current count is ", paramInt, ", estimated native memory ");
    stringBuilder.append(paramLong / 1048576L);
    stringBuilder.append("Mb");
    debug(stringBuilder.toString());
    return true;
  }
  
  public Bitmap decodeRegion(Rect paramRect, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Decode region ");
    stringBuilder.append(paramRect);
    stringBuilder.append(" on thread ");
    stringBuilder.append(Thread.currentThread().getName());
    debug(stringBuilder.toString());
    if (paramRect.width() < this.imageDimensions.x || paramRect.height() < this.imageDimensions.y)
      lazyInit(); 
    this.decoderLock.readLock().lock();
    try {
      DecoderPool decoderPool = this.decoderPool;
      if (decoderPool != null) {
        BitmapRegionDecoder bitmapRegionDecoder = decoderPool.acquire();
        if (bitmapRegionDecoder != null)
          try {
            if (!bitmapRegionDecoder.isRecycled()) {
              BitmapFactory.Options options = new BitmapFactory.Options();
              options.inSampleSize = paramInt;
              options.inPreferredConfig = this.bitmapConfig;
              Bitmap bitmap = bitmapRegionDecoder.decodeRegion(paramRect, options);
              if (bitmap != null)
                return bitmap; 
              throw new RuntimeException("Skia image decoder returned null bitmap - image format may not be supported");
            } 
          } finally {
            this.decoderPool.release(bitmapRegionDecoder);
          }  
        if (bitmapRegionDecoder != null)
          this.decoderPool.release(bitmapRegionDecoder); 
      } 
      throw new IllegalStateException("Cannot decode region after decoder has been recycled");
    } finally {
      this.decoderLock.readLock().unlock();
    } 
  }
  
  public Point init(Context paramContext, Uri paramUri) {
    this.context = paramContext;
    this.uri = paramUri;
    initialiseDecoder();
    return this.imageDimensions;
  }
  
  public boolean isReady() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield decoderPool : Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 25
    //   11: aload_2
    //   12: invokestatic access$900 : (Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;)Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifne -> 25
    //   20: iconst_1
    //   21: istore_1
    //   22: goto -> 27
    //   25: iconst_0
    //   26: istore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: iload_1
    //   30: ireturn
    //   31: astore_2
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_2
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	31	finally
    //   11	16	31	finally
  }
  
  public void recycle() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   6: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   11: invokeinterface lock : ()V
    //   16: aload_0
    //   17: getfield decoderPool : Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;
    //   20: astore_1
    //   21: aload_1
    //   22: ifnull -> 44
    //   25: aload_1
    //   26: invokestatic access$1000 : (Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;)V
    //   29: aload_0
    //   30: aconst_null
    //   31: putfield decoderPool : Lcom/davemorrissey/labs/subscaleview/decoder/SkiaPooledImageRegionDecoder$DecoderPool;
    //   34: aload_0
    //   35: aconst_null
    //   36: putfield context : Landroid/content/Context;
    //   39: aload_0
    //   40: aconst_null
    //   41: putfield uri : Landroid/net/Uri;
    //   44: aload_0
    //   45: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   48: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   53: invokeinterface unlock : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: astore_1
    //   62: aload_0
    //   63: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   66: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   71: invokeinterface unlock : ()V
    //   76: aload_1
    //   77: athrow
    //   78: astore_1
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_1
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	78	finally
    //   16	21	61	finally
    //   25	44	61	finally
    //   44	58	78	finally
    //   62	78	78	finally
  }
  
  public static class DecoderPool {
    private final Semaphore available = new Semaphore(0, true);
    
    private final Map<BitmapRegionDecoder, Boolean> decoders = new ConcurrentHashMap<BitmapRegionDecoder, Boolean>();
    
    private DecoderPool() {}
    
    private BitmapRegionDecoder acquire() {
      this.available.acquireUninterruptibly();
      return getNextAvailable();
    }
    
    private void add(BitmapRegionDecoder param1BitmapRegionDecoder) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: aload_1
      //   7: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   10: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   15: pop
      //   16: aload_0
      //   17: getfield available : Ljava/util/concurrent/Semaphore;
      //   20: invokevirtual release : ()V
      //   23: aload_0
      //   24: monitorexit
      //   25: return
      //   26: astore_1
      //   27: aload_0
      //   28: monitorexit
      //   29: aload_1
      //   30: athrow
      // Exception table:
      //   from	to	target	type
      //   2	23	26	finally
    }
    
    private BitmapRegionDecoder getNextAvailable() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: invokeinterface entrySet : ()Ljava/util/Set;
      //   11: invokeinterface iterator : ()Ljava/util/Iterator;
      //   16: astore_1
      //   17: aload_1
      //   18: invokeinterface hasNext : ()Z
      //   23: ifeq -> 75
      //   26: aload_1
      //   27: invokeinterface next : ()Ljava/lang/Object;
      //   32: checkcast java/util/Map$Entry
      //   35: astore_2
      //   36: aload_2
      //   37: invokeinterface getValue : ()Ljava/lang/Object;
      //   42: checkcast java/lang/Boolean
      //   45: invokevirtual booleanValue : ()Z
      //   48: ifne -> 17
      //   51: aload_2
      //   52: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   55: invokeinterface setValue : (Ljava/lang/Object;)Ljava/lang/Object;
      //   60: pop
      //   61: aload_2
      //   62: invokeinterface getKey : ()Ljava/lang/Object;
      //   67: checkcast android/graphics/BitmapRegionDecoder
      //   70: astore_1
      //   71: aload_0
      //   72: monitorexit
      //   73: aload_1
      //   74: areturn
      //   75: aload_0
      //   76: monitorexit
      //   77: aconst_null
      //   78: areturn
      //   79: astore_1
      //   80: aload_0
      //   81: monitorexit
      //   82: goto -> 87
      //   85: aload_1
      //   86: athrow
      //   87: goto -> 85
      // Exception table:
      //   from	to	target	type
      //   2	17	79	finally
      //   17	71	79	finally
    }
    
    private boolean isEmpty() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: invokeinterface isEmpty : ()Z
      //   11: istore_1
      //   12: aload_0
      //   13: monitorexit
      //   14: iload_1
      //   15: ireturn
      //   16: astore_2
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_2
      //   20: athrow
      // Exception table:
      //   from	to	target	type
      //   2	12	16	finally
    }
    
    private boolean markAsUnused(BitmapRegionDecoder param1BitmapRegionDecoder) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: invokeinterface entrySet : ()Ljava/util/Set;
      //   11: invokeinterface iterator : ()Ljava/util/Iterator;
      //   16: astore_2
      //   17: aload_2
      //   18: invokeinterface hasNext : ()Z
      //   23: ifeq -> 79
      //   26: aload_2
      //   27: invokeinterface next : ()Ljava/lang/Object;
      //   32: checkcast java/util/Map$Entry
      //   35: astore_3
      //   36: aload_1
      //   37: aload_3
      //   38: invokeinterface getKey : ()Ljava/lang/Object;
      //   43: if_acmpne -> 17
      //   46: aload_3
      //   47: invokeinterface getValue : ()Ljava/lang/Object;
      //   52: checkcast java/lang/Boolean
      //   55: invokevirtual booleanValue : ()Z
      //   58: ifeq -> 75
      //   61: aload_3
      //   62: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   65: invokeinterface setValue : (Ljava/lang/Object;)Ljava/lang/Object;
      //   70: pop
      //   71: aload_0
      //   72: monitorexit
      //   73: iconst_1
      //   74: ireturn
      //   75: aload_0
      //   76: monitorexit
      //   77: iconst_0
      //   78: ireturn
      //   79: aload_0
      //   80: monitorexit
      //   81: iconst_0
      //   82: ireturn
      //   83: astore_1
      //   84: aload_0
      //   85: monitorexit
      //   86: goto -> 91
      //   89: aload_1
      //   90: athrow
      //   91: goto -> 89
      // Exception table:
      //   from	to	target	type
      //   2	17	83	finally
      //   17	71	83	finally
    }
    
    private void recycle() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: invokeinterface isEmpty : ()Z
      //   11: ifne -> 37
      //   14: aload_0
      //   15: invokespecial acquire : ()Landroid/graphics/BitmapRegionDecoder;
      //   18: astore_1
      //   19: aload_1
      //   20: invokevirtual recycle : ()V
      //   23: aload_0
      //   24: getfield decoders : Ljava/util/Map;
      //   27: aload_1
      //   28: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   33: pop
      //   34: goto -> 2
      //   37: aload_0
      //   38: monitorexit
      //   39: return
      //   40: astore_1
      //   41: aload_0
      //   42: monitorexit
      //   43: goto -> 48
      //   46: aload_1
      //   47: athrow
      //   48: goto -> 46
      // Exception table:
      //   from	to	target	type
      //   2	34	40	finally
    }
    
    private void release(BitmapRegionDecoder param1BitmapRegionDecoder) {
      if (markAsUnused(param1BitmapRegionDecoder))
        this.available.release(); 
    }
    
    private int size() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield decoders : Ljava/util/Map;
      //   6: invokeinterface size : ()I
      //   11: istore_1
      //   12: aload_0
      //   13: monitorexit
      //   14: iload_1
      //   15: ireturn
      //   16: astore_2
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_2
      //   20: athrow
      // Exception table:
      //   from	to	target	type
      //   2	12	16	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\decoder\SkiaPooledImageRegionDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */