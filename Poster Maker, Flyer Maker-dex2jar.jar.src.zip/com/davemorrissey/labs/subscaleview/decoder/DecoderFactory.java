package com.davemorrissey.labs.subscaleview.decoder;

public interface DecoderFactory<T> {
  T make();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\decoder\DecoderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */