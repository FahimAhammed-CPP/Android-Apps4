package com.davemorrissey.labs.subscaleview.decoder;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.Keep;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.io.InputStream;
import java.util.List;

public class SkiaImageDecoder implements ImageDecoder {
  private static final String ASSET_PREFIX = "file:///android_asset/";
  
  private static final String FILE_PREFIX = "file://";
  
  private static final String RESOURCE_PREFIX = "android.resource://";
  
  private final Bitmap.Config bitmapConfig;
  
  @Keep
  public SkiaImageDecoder() {
    this(null);
  }
  
  public SkiaImageDecoder(Bitmap.Config paramConfig) {
    Bitmap.Config config = SubsamplingScaleImageView.getPreferredBitmapConfig();
    if (paramConfig != null) {
      this.bitmapConfig = paramConfig;
      return;
    } 
    if (config != null) {
      this.bitmapConfig = config;
      return;
    } 
    this.bitmapConfig = Bitmap.Config.RGB_565;
  }
  
  public Bitmap decode(Context paramContext, Uri paramUri) {
    Bitmap bitmap;
    String str = paramUri.toString();
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = this.bitmapConfig;
    if (str.startsWith("android.resource://")) {
      int i;
      Resources resources;
      str = paramUri.getAuthority();
      if (paramContext.getPackageName().equals(str)) {
        resources = paramContext.getResources();
      } else {
        resources = paramContext.getPackageManager().getResourcesForApplication(str);
      } 
      List<String> list = paramUri.getPathSegments();
      int j = list.size();
      byte b = 0;
      if (j == 2 && ((String)list.get(0)).equals("drawable")) {
        i = resources.getIdentifier(list.get(1), "drawable", str);
      } else {
        i = b;
        if (j == 1) {
          i = b;
          if (TextUtils.isDigitsOnly(list.get(0)))
            try {
              i = Integer.parseInt(list.get(0));
            } catch (NumberFormatException numberFormatException) {
              i = b;
            }  
        } 
      } 
      bitmap = BitmapFactory.decodeResource(paramContext.getResources(), i, options);
    } else {
      String str1;
      boolean bool = str.startsWith("file:///android_asset/");
      String str2 = null;
      if (bool) {
        str1 = str.substring(22);
        bitmap = BitmapFactory.decodeStream(bitmap.getAssets().open(str1), null, options);
      } else if (str.startsWith("file://")) {
        bitmap = BitmapFactory.decodeFile(str.substring(7), options);
      } else {
        try {
          InputStream inputStream = bitmap.getContentResolver().openInputStream((Uri)str1);
        } finally {
          bitmap = null;
        } 
        if (str1 != null)
          try {
            str1.close();
          } catch (Exception exception) {} 
        throw bitmap;
      } 
    } 
    if (bitmap != null)
      return bitmap; 
    throw new RuntimeException("Skia image region decoder returned null bitmap - image format may not be supported");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\decoder\SkiaImageDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */