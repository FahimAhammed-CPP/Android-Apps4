package com.davemorrissey.labs.subscaleview.decoder;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import androidx.annotation.Keep;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SkiaImageRegionDecoder implements ImageRegionDecoder {
  private static final String ASSET_PREFIX = "file:///android_asset/";
  
  private static final String FILE_PREFIX = "file://";
  
  private static final String RESOURCE_PREFIX = "android.resource://";
  
  private final Bitmap.Config bitmapConfig;
  
  private BitmapRegionDecoder decoder;
  
  private final ReadWriteLock decoderLock = new ReentrantReadWriteLock(true);
  
  @Keep
  public SkiaImageRegionDecoder() {
    this(null);
  }
  
  public SkiaImageRegionDecoder(Bitmap.Config paramConfig) {
    Bitmap.Config config = SubsamplingScaleImageView.getPreferredBitmapConfig();
    if (paramConfig != null) {
      this.bitmapConfig = paramConfig;
      return;
    } 
    if (config != null) {
      this.bitmapConfig = config;
      return;
    } 
    this.bitmapConfig = Bitmap.Config.RGB_565;
  }
  
  private Lock getDecodeLock() {
    return (Build.VERSION.SDK_INT < 21) ? this.decoderLock.writeLock() : this.decoderLock.readLock();
  }
  
  public Bitmap decodeRegion(Rect paramRect, int paramInt) {
    getDecodeLock().lock();
    try {
      BitmapRegionDecoder bitmapRegionDecoder = this.decoder;
      if (bitmapRegionDecoder != null && !bitmapRegionDecoder.isRecycled()) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = paramInt;
        options.inPreferredConfig = this.bitmapConfig;
        Bitmap bitmap = this.decoder.decodeRegion(paramRect, options);
        if (bitmap != null)
          return bitmap; 
        throw new RuntimeException("Skia image decoder returned null bitmap - image format may not be supported");
      } 
      throw new IllegalStateException("Cannot decode region after decoder has been recycled");
    } finally {
      getDecodeLock().unlock();
    } 
  }
  
  public Point init(Context paramContext, Uri paramUri) {
    int i;
    Resources resources;
    String str = paramUri.toString();
    if (str.startsWith("android.resource://")) {
      String str1 = paramUri.getAuthority();
      if (paramContext.getPackageName().equals(str1)) {
        resources = paramContext.getResources();
      } else {
        resources = paramContext.getPackageManager().getResourcesForApplication(str1);
      } 
      List<String> list = paramUri.getPathSegments();
      i = list.size();
      if (i == 2 && ((String)list.get(0)).equals("drawable")) {
        i = resources.getIdentifier(list.get(1), "drawable", str1);
      } else {
        if (i == 1 && TextUtils.isDigitsOnly(list.get(0)))
          try {
            i = Integer.parseInt(list.get(0));
            this.decoder = BitmapRegionDecoder.newInstance(paramContext.getResources().openRawResource(i), false);
            return new Point(this.decoder.getWidth(), this.decoder.getHeight());
          } catch (NumberFormatException numberFormatException) {} 
        i = 0;
      } 
    } else {
      String str1;
      if (resources.startsWith("file:///android_asset/")) {
        str1 = resources.substring(22);
        this.decoder = BitmapRegionDecoder.newInstance(paramContext.getAssets().open(str1, 1), false);
      } else if (resources.startsWith("file://")) {
        this.decoder = BitmapRegionDecoder.newInstance(resources.substring(7), false);
      } else {
        InputStream inputStream;
        resources = null;
        try {
          InputStream inputStream1 = paramContext.getContentResolver().openInputStream((Uri)str1);
          inputStream = inputStream1;
          this.decoder = BitmapRegionDecoder.newInstance(inputStream1, false);
          return new Point(this.decoder.getWidth(), this.decoder.getHeight());
        } finally {
          if (inputStream != null)
            try {
              inputStream.close();
            } catch (Exception exception) {} 
        } 
      } 
      return new Point(this.decoder.getWidth(), this.decoder.getHeight());
    } 
    this.decoder = BitmapRegionDecoder.newInstance(paramContext.getResources().openRawResource(i), false);
    return new Point(this.decoder.getWidth(), this.decoder.getHeight());
  }
  
  public boolean isReady() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield decoder : Landroid/graphics/BitmapRegionDecoder;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 25
    //   11: aload_2
    //   12: invokevirtual isRecycled : ()Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifne -> 25
    //   20: iconst_1
    //   21: istore_1
    //   22: goto -> 27
    //   25: iconst_0
    //   26: istore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: iload_1
    //   30: ireturn
    //   31: astore_2
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_2
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	31	finally
    //   11	16	31	finally
  }
  
  public void recycle() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   6: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   11: invokeinterface lock : ()V
    //   16: aload_0
    //   17: getfield decoder : Landroid/graphics/BitmapRegionDecoder;
    //   20: invokevirtual recycle : ()V
    //   23: aload_0
    //   24: aconst_null
    //   25: putfield decoder : Landroid/graphics/BitmapRegionDecoder;
    //   28: aload_0
    //   29: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   32: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   37: invokeinterface unlock : ()V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: aload_0
    //   47: getfield decoderLock : Ljava/util/concurrent/locks/ReadWriteLock;
    //   50: invokeinterface writeLock : ()Ljava/util/concurrent/locks/Lock;
    //   55: invokeinterface unlock : ()V
    //   60: aload_1
    //   61: athrow
    //   62: astore_1
    //   63: aload_0
    //   64: monitorexit
    //   65: aload_1
    //   66: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	62	finally
    //   16	28	45	finally
    //   28	42	62	finally
    //   46	62	62	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\decoder\SkiaImageRegionDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */