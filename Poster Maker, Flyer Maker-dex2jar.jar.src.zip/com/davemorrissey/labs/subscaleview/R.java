package com.davemorrissey.labs.subscaleview;

public final class R {
  public static final class attr {
    public static final int assetName = 2130968651;
    
    public static final int panEnabled = 2130969607;
    
    public static final int quickScaleEnabled = 2130969676;
    
    public static final int src = 2130969868;
    
    public static final int tileBackgroundColor = 2130970032;
    
    public static final int zoomEnabled = 2130970149;
  }
  
  public static final class styleable {
    public static final int[] SubsamplingScaleImageView = new int[] { 2130968651, 2130969607, 2130969676, 2130969868, 2130970032, 2130970149 };
    
    public static final int SubsamplingScaleImageView_assetName = 0;
    
    public static final int SubsamplingScaleImageView_panEnabled = 1;
    
    public static final int SubsamplingScaleImageView_quickScaleEnabled = 2;
    
    public static final int SubsamplingScaleImageView_src = 3;
    
    public static final int SubsamplingScaleImageView_tileBackgroundColor = 4;
    
    public static final int SubsamplingScaleImageView_zoomEnabled = 5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\davemorrissey\labs\subscaleview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */