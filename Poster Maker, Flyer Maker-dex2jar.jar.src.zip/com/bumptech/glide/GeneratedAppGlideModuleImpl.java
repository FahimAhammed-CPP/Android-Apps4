package com.bumptech.glide;

import android.content.Context;
import android.util.Log;
import c50;
import com.optimumbrew.obglide.core.imageloader.MyAppGlideModule;
import e50;
import f50;
import fd0;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import l50;

public final class GeneratedAppGlideModuleImpl extends GeneratedAppGlideModule {
  public final MyAppGlideModule a = new MyAppGlideModule();
  
  public GeneratedAppGlideModuleImpl(Context paramContext) {
    Log.isLoggable("Glide", 3);
  }
  
  public void a(Context paramContext, f50 paramf50) {
    this.a.a(paramContext, paramf50);
  }
  
  public void b(Context paramContext, e50 parame50, l50 paraml50) {
    Objects.requireNonNull(this.a);
  }
  
  public boolean c() {
    Objects.requireNonNull(this.a);
    return false;
  }
  
  public Set<Class<?>> d() {
    return Collections.emptySet();
  }
  
  public fd0.b e() {
    return (fd0.b)new c50();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\bumptech\glide\GeneratedAppGlideModuleImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */