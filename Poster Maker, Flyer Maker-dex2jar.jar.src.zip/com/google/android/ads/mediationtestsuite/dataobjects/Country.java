package com.google.android.ads.mediationtestsuite.dataobjects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Country implements Parcelable {
  public static final Parcelable.Creator<Country> CREATOR = new Parcelable.Creator<Country>() {
      public Country createFromParcel(Parcel param1Parcel) {
        return new Country(param1Parcel);
      }
      
      public Country[] newArray(int param1Int) {
        return new Country[param1Int];
      }
    };
  
  @SerializedName("code")
  private String code;
  
  @SerializedName("name")
  private String name;
  
  public Country() {}
  
  private Country(Parcel paramParcel) {
    this.code = paramParcel.readString();
    this.name = paramParcel.readString();
  }
  
  public Country(String paramString1, String paramString2) {
    this.code = paramString1;
    this.name = paramString2;
  }
  
  public static Country allCountry() {
    return new Country("ALL", "All Countries");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String getCode() {
    return this.code;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.code);
    paramParcel.writeString(this.name);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\Country.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */