package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import java.util.Map;

public class AdManagerNetworkResponse {
  @SerializedName("data")
  private Map<String, String> data;
  
  @SerializedName("format")
  private AdFormat format;
  
  @SerializedName("mediation_group_id")
  private List<Integer> mediationGroupIds;
  
  public Map<String, String> getData() {
    return this.data;
  }
  
  public AdFormat getFormat() {
    return this.format;
  }
  
  public List<Integer> getMediationGroupIds() {
    return this.mediationGroupIds;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdManagerNetworkResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */