package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.utils.logging.TestSuiteTabViewEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemsFragmentViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.HomeActivityViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.NetworkConfigDetailViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.YieldGroupViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.YieldPartnerConfigDetailViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.YieldPartnerViewModel;
import java.util.ArrayList;
import java.util.Collection;
import org.jspecify.nullness.Nullable;

public class AdManagerProductTheme implements ProductTheme {
  private static final String ADAPTER_INITIALIZATION_ANDROID_URL = "https://googlemobileadssdk.page.link/ad-manager-android-adapter-initialization";
  
  private static final String DISCLAIMER_URL = "https://googlemobileadssdk.page.link/mts-ad-manager-disclaimer";
  
  private static final String REGISTER_TEST_DEVICES_ANDROID_URL = "https://googlemobileadssdk.page.link/ad-manager-android-register-test-device";
  
  public String buildTestDeviceRegistrationUrl(String paramString) {
    return null;
  }
  
  public int getAdLoadNoFillDescriptionId() {
    return R.string.gmts_error_yield_partner_no_fill_message;
  }
  
  public int getAdLoadNoFillTitleId() {
    return R.string.gmts_error_yield_partner_no_fill_title;
  }
  
  public int getAdLoadNotTestedDescriptionId() {
    return R.string.gmts_yield_partner_not_tested_message;
  }
  
  public int getAdSourceConfigurationSectionTitleId() {
    return R.string.gmts_section_yield_partner_configuration;
  }
  
  public int getAdSourcePageOpenBiddingAdSourcesHeaderId() {
    return R.string.gmts_section_open_bidding_yield_partners;
  }
  
  public int getAdSourcePageWaterfallAdSourcesHeaderId() {
    return R.string.gmts_section_waterfall_ad_yield_partners;
  }
  
  public int getAdUnitPageNoAdUnitsFoundId(TestSuiteTabViewEvent.ViewType paramViewType) {
    return (paramViewType == TestSuiteTabViewEvent.ViewType.AD_UNIT_MAPPINGS) ? R.string.gmts_no_yield_partners_found : R.string.gmts_no_yield_groups_found;
  }
  
  public int getAdUnitPageSearchPlaceholderId() {
    return R.string.gmts_placeholder_search_yield_groups;
  }
  
  public String getAdapterInitializationHelpUrl() {
    return TestSuiteState.sharedInstance().isUnity() ? "https://googlemobileadssdk.page.link/unity-adapter-initialization" : "https://googlemobileadssdk.page.link/ad-manager-android-adapter-initialization";
  }
  
  @Nullable
  public ConfigurationItemViewModel<? extends ConfigurationItem> getConfigurationItemViewModel(ConfigurationItem paramConfigurationItem) {
    return (ConfigurationItemViewModel<? extends ConfigurationItem>)((paramConfigurationItem instanceof YieldGroup) ? new YieldGroupViewModel((YieldGroup)paramConfigurationItem) : ((paramConfigurationItem instanceof YieldPartner) ? new YieldPartnerViewModel((YieldPartner)paramConfigurationItem) : null));
  }
  
  public String getDisclaimerUrl() {
    return "https://googlemobileadssdk.page.link/mts-ad-manager-disclaimer";
  }
  
  public HomeActivityViewModel getHomeActivityViewModel(Collection<ConfigurationItem> paramCollection) {
    ArrayList<ConfigurationItem> arrayList2 = new ArrayList();
    ArrayList<ConfigurationItem> arrayList1 = new ArrayList();
    for (ConfigurationItem configurationItem : paramCollection) {
      if (configurationItem instanceof YieldGroup) {
        arrayList2.add(configurationItem);
        continue;
      } 
      if (configurationItem instanceof YieldPartner)
        arrayList1.add(configurationItem); 
    } 
    ConfigurationItemsFragmentViewModel configurationItemsFragmentViewModel1 = new ConfigurationItemsFragmentViewModel(arrayList2, TestSuiteTabViewEvent.ViewType.YIELD_GROUPS, R.string.gmts_yield_groups);
    ConfigurationItemsFragmentViewModel configurationItemsFragmentViewModel2 = new ConfigurationItemsFragmentViewModel(arrayList1, TestSuiteTabViewEvent.ViewType.AD_UNIT_MAPPINGS, R.string.gmts_open_bidding_partners);
    arrayList2 = new ArrayList<ConfigurationItem>();
    arrayList2.add(configurationItemsFragmentViewModel1);
    arrayList2.add(configurationItemsFragmentViewModel2);
    return new HomeActivityViewModel(arrayList2);
  }
  
  public String getHomePageSubtitle() {
    return "Google Ad Manager";
  }
  
  public NetworkConfigDetailViewModel getNetworkConfigDetailViewModel(NetworkConfig paramNetworkConfig) {
    return (NetworkConfigDetailViewModel)(paramNetworkConfig.isRtbAdapter() ? new YieldPartnerConfigDetailViewModel(paramNetworkConfig) : new NetworkConfigDetailViewModel(paramNetworkConfig));
  }
  
  public int getProductStyleId() {
    return R.style.gmts_AdManagerStyle;
  }
  
  public String getRegisterTestDevicesHelpUrl() {
    return TestSuiteState.sharedInstance().isUnity() ? "https://googlemobileadssdk.page.link/unity-register-test-device" : "https://googlemobileadssdk.page.link/ad-manager-android-register-test-device";
  }
  
  public boolean supportsRegisteringTestDevices() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdManagerProductTheme.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */