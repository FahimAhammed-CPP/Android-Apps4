package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.logging.TestSuiteTabViewEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.HomeActivityViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.NetworkConfigDetailViewModel;
import java.util.Collection;

public interface ProductTheme {
  String buildTestDeviceRegistrationUrl(String paramString);
  
  int getAdLoadNoFillDescriptionId();
  
  int getAdLoadNoFillTitleId();
  
  int getAdLoadNotTestedDescriptionId();
  
  int getAdSourceConfigurationSectionTitleId();
  
  int getAdSourcePageOpenBiddingAdSourcesHeaderId();
  
  int getAdSourcePageWaterfallAdSourcesHeaderId();
  
  int getAdUnitPageNoAdUnitsFoundId(TestSuiteTabViewEvent.ViewType paramViewType);
  
  int getAdUnitPageSearchPlaceholderId();
  
  String getAdapterInitializationHelpUrl();
  
  ConfigurationItemViewModel<? extends ConfigurationItem> getConfigurationItemViewModel(ConfigurationItem paramConfigurationItem);
  
  String getDisclaimerUrl();
  
  HomeActivityViewModel getHomeActivityViewModel(Collection<ConfigurationItem> paramCollection);
  
  String getHomePageSubtitle();
  
  NetworkConfigDetailViewModel getNetworkConfigDetailViewModel(NetworkConfig paramNetworkConfig);
  
  int getProductStyleId();
  
  String getRegisterTestDevicesHelpUrl();
  
  boolean supportsRegisteringTestDevices();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\ProductTheme.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */