package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class AdManagerInitializationSettings {
  @SerializedName("config")
  private Map<String, AdManagerAdapterInitializationSettings> config;
  
  public Map<String, AdManagerAdapterInitializationSettings> getConfig() {
    return this.config;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdManagerInitializationSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */