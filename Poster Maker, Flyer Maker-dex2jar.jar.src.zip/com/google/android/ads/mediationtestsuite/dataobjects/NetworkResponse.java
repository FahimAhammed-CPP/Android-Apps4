package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.jspecify.nullness.Nullable;

public class NetworkResponse {
  private List<String> adapters;
  
  private Map<String, String> data;
  
  @SerializedName("rtb_adapters")
  private List<String> rtbAdapters;
  
  public NetworkResponse(Map<String, String> paramMap, String paramString, boolean paramBoolean) {
    this.data = paramMap;
    ArrayList<String> arrayList = new ArrayList();
    arrayList.add(paramString);
    if (paramBoolean) {
      this.rtbAdapters = arrayList;
      return;
    } 
    this.adapters = arrayList;
  }
  
  public List<String> getAdapters() {
    return this.adapters;
  }
  
  @Nullable
  public String getClassName() {
    if (isRtbAdapter())
      return this.rtbAdapters.get(0); 
    List<String> list = this.adapters;
    return (list == null || list.isEmpty()) ? null : this.adapters.get(0);
  }
  
  public Map<String, String> getData() {
    return this.data;
  }
  
  public boolean hasValidMediationAdapter() {
    String str = getClassName();
    return (str == null) ? false : (!(this.data == null && !str.equals("com.google.ads.mediation.admob.AdMobAdapter")));
  }
  
  public boolean isCustomEventAdapter() {
    return (getClassName() != null && getClassName().equals("com.google.ads.mediation.customevent.CustomEventAdapter"));
  }
  
  public boolean isRtbAdapter() {
    List<String> list = this.rtbAdapters;
    return (list != null && !list.isEmpty());
  }
  
  public void setAdapters(List<String> paramList) {
    this.adapters = paramList;
  }
  
  public void setData(Map<String, String> paramMap) {
    this.data = paramMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\NetworkResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */