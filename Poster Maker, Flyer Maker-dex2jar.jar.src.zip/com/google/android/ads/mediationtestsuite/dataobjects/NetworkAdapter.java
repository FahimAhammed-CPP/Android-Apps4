package com.google.android.ads.mediationtestsuite.dataobjects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.ads.mediationtestsuite.utils.AppInfoUtil;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.gms.ads.mediation.Adapter;
import com.google.android.gms.ads.mediation.VersionInfo;
import com.google.gson.annotations.SerializedName;
import java.util.HashMap;
import java.util.Map;

public class NetworkAdapter implements Parcelable {
  public static final Parcelable.Creator<NetworkAdapter> CREATOR = new Parcelable.Creator<NetworkAdapter>() {
      public NetworkAdapter createFromParcel(Parcel param1Parcel) {
        return new NetworkAdapter(param1Parcel);
      }
      
      public NetworkAdapter[] newArray(int param1Int) {
        return new NetworkAdapter[param1Int];
      }
    };
  
  private boolean adapterPresent;
  
  @SerializedName("className")
  private String className;
  
  @SerializedName("format")
  private AdFormat format;
  
  private boolean initializerPresent;
  
  @SerializedName("is_rtb")
  private boolean isRtbAdapter;
  
  private Network network;
  
  @SerializedName("networkLabel")
  private String networkLabel;
  
  @SerializedName("serverParameters")
  private Map<String, String> serverParameters;
  
  public NetworkAdapter() {
    this.serverParameters = new HashMap<String, String>();
  }
  
  private NetworkAdapter(Parcel paramParcel) {
    boolean[] arrayOfBoolean = new boolean[3];
    paramParcel.readBooleanArray(arrayOfBoolean);
    int i = 0;
    this.adapterPresent = arrayOfBoolean[0];
    this.isRtbAdapter = arrayOfBoolean[1];
    this.initializerPresent = arrayOfBoolean[2];
    this.format = AdFormat.from(paramParcel.readString());
    this.className = paramParcel.readString();
    this.networkLabel = paramParcel.readString();
    this.network = (Network)paramParcel.readParcelable(Network.class.getClassLoader());
    this.serverParameters = new HashMap<String, String>();
    int j = paramParcel.readInt();
    while (i < j) {
      this.serverParameters.put(paramParcel.readString(), paramParcel.readString());
      i++;
    } 
  }
  
  private Adapter getAdapter() {
    String str = getClassName();
    try {
      Class<?> clazz = NetworkAdapter.class.getClassLoader().loadClass(str);
      if (clazz != null && Adapter.class.isAssignableFrom(clazz))
        return clazz.<Adapter>asSubclass(Adapter.class).getConstructor(new Class[0]).newInstance(new Object[0]); 
      if (getInitializerClassName() != null) {
        clazz = NetworkAdapter.class.getClassLoader().loadClass(getInitializerClassName());
        if (clazz != null && Adapter.class.isAssignableFrom(clazz))
          return clazz.<Adapter>asSubclass(Adapter.class).getConstructor(new Class[0]).newInstance(new Object[0]); 
      } 
      return null;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void detectInstallation() {
    this.adapterPresent = AppInfoUtil.classExists(this.className);
    String str = getInitializerClassName();
    if (str != null)
      this.initializerPresent = AppInfoUtil.classExists(str); 
  }
  
  public String getClassName() {
    return this.className;
  }
  
  public AdFormat getFormat() {
    return this.format;
  }
  
  public String getInitializerClassName() {
    Network network = this.network;
    return (network != null) ? network.getInitializerClass() : null;
  }
  
  public Network getNetwork() {
    return this.network;
  }
  
  public String getNetworkLabel() {
    return (TestSuiteState.isAdManagerApp() && this.networkLabel.equals("AdMob")) ? "Ad Manager" : this.networkLabel;
  }
  
  public VersionInfo getSDKVersion() {
    Adapter adapter = getAdapter();
    return (adapter == null) ? null : adapter.getSDKVersionInfo();
  }
  
  public Map<String, String> getServerParameters() {
    return this.serverParameters;
  }
  
  public VersionInfo getVersion() {
    Adapter adapter = getAdapter();
    return (adapter == null) ? null : adapter.getVersionInfo();
  }
  
  public boolean isAdapterPresent() {
    return this.adapterPresent;
  }
  
  public boolean isInitializerPresent() {
    return this.initializerPresent;
  }
  
  public boolean isRtbAdapter() {
    return this.isRtbAdapter;
  }
  
  public void setAdapterPresent(boolean paramBoolean) {
    this.adapterPresent = paramBoolean;
  }
  
  public void setClassName(String paramString) {
    this.className = paramString;
  }
  
  public void setFormat(AdFormat paramAdFormat) {
    this.format = paramAdFormat;
  }
  
  public void setNetwork(Network paramNetwork) {
    this.network = paramNetwork;
  }
  
  public void setNetworkLabel(String paramString) {
    this.networkLabel = paramString;
  }
  
  public void setServerParameters(Map<String, String> paramMap) {
    this.serverParameters = paramMap;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeBooleanArray(new boolean[] { this.adapterPresent, this.isRtbAdapter, this.initializerPresent });
    paramParcel.writeString(this.format.getFormatString());
    paramParcel.writeString(this.className);
    paramParcel.writeString(this.networkLabel);
    paramParcel.writeParcelable(this.network, 0);
    paramParcel.writeInt(this.serverParameters.size());
    for (String str : this.serverParameters.keySet()) {
      paramParcel.writeString(str);
      paramParcel.writeString(this.serverParameters.get(str));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\NetworkAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */