package com.google.android.ads.mediationtestsuite.dataobjects;

import android.content.Context;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.viewmodels.TestState;

public enum TestResult {
  FAILURE_INTERNAL_ERROR,
  FAILURE_INVALID_REQUEST,
  FAILURE_NETWORK_ERROR,
  FAILURE_NO_FILL,
  FAILURE_UNABLE_TO_TEST,
  SUCCESS,
  UNTESTED(TestState.INFO);
  
  public static final int FAIL_COLOR = -30584;
  
  public static final int NEUTRAL_COLOR = -4473925;
  
  public static final int OK_COLOR = -7798904;
  
  private final TestState testState;
  
  static {
    SUCCESS = new TestResult("SUCCESS", 1, TestState.OK);
    TestState testState = TestState.ERROR;
    FAILURE_INTERNAL_ERROR = new TestResult("FAILURE_INTERNAL_ERROR", 2, testState);
    FAILURE_INVALID_REQUEST = new TestResult("FAILURE_INVALID_REQUEST", 3, testState);
    FAILURE_NETWORK_ERROR = new TestResult("FAILURE_NETWORK_ERROR", 4, testState);
    FAILURE_NO_FILL = new TestResult("FAILURE_NO_FILL", 5, testState);
    FAILURE_UNABLE_TO_TEST = new TestResult("FAILURE_UNABLE_TO_TEST", 6, testState);
    $VALUES = $values();
  }
  
  TestResult(TestState paramTestState) {
    this.testState = paramTestState;
  }
  
  public static TestResult getFailureResult(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? UNTESTED : FAILURE_NO_FILL) : FAILURE_NETWORK_ERROR) : FAILURE_INVALID_REQUEST) : FAILURE_INTERNAL_ERROR;
  }
  
  public int getErrorCode() {
    int i = ordinal();
    return (i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? -1 : 3) : 2) : 1) : 0;
  }
  
  public TestState getTestState() {
    return this.testState;
  }
  
  public String getText(Context paramContext) {
    return paramContext.getString(getTextResId());
  }
  
  public int getTextResId() {
    switch (ordinal()) {
      default:
        return -1;
      case 6:
        return R.string.gmts_section_missing_components;
      case 5:
        return TestSuiteState.getProductTheme().getAdLoadNoFillTitleId();
      case 4:
        return R.string.gmts_error_network_error;
      case 3:
        return R.string.gmts_error_invalid_request;
      case 2:
        return R.string.gmts_error_internal_error;
      case 1:
        return R.string.gmts_section_working;
      case 0:
        break;
    } 
    return R.string.gmts_not_tested_label;
  }
  
  public boolean isFailure() {
    return (this.testState == TestState.ERROR);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\TestResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */