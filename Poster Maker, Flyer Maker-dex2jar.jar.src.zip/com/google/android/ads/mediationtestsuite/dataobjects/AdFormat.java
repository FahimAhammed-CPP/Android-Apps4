package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.AdLoadCallback;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.utils.AdManager;
import com.google.android.ads.mediationtestsuite.utils.AppInfoUtil;
import com.google.android.ads.mediationtestsuite.utils.BannerAdManager;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.InterstitialAdManager;
import com.google.android.ads.mediationtestsuite.utils.NativeAdManager;
import com.google.android.ads.mediationtestsuite.utils.RewardedAdManager;
import org.jspecify.nullness.Nullable;

public enum AdFormat {
  BANNER("banner", R.string.gmts_format_banner) {
    public AdManager createAdLoader(NetworkConfig param1NetworkConfig, AdLoadCallback param1AdLoadCallback) {
      return (AdManager)new BannerAdManager(param1NetworkConfig, param1AdLoadCallback);
    }
  },
  BANNER_INTERSTITIAL("banner", R.string.gmts_format_banner),
  INTERSTITIAL("interstitial", R.string.gmts_format_interstitial) {
    public AdManager createAdLoader(NetworkConfig param1NetworkConfig, AdLoadCallback param1AdLoadCallback) {
      return (AdManager)new InterstitialAdManager(param1NetworkConfig, param1AdLoadCallback);
    }
  },
  NATIVE("native", R.string.gmts_format_native) {
    public AdManager createAdLoader(NetworkConfig param1NetworkConfig, AdLoadCallback param1AdLoadCallback) {
      return (AdManager)new NativeAdManager(param1NetworkConfig, param1AdLoadCallback);
    }
  },
  REWARDED("rewarded", R.string.gmts_format_rewarded) {
    public AdManager createAdLoader(NetworkConfig param1NetworkConfig, AdLoadCallback param1AdLoadCallback) {
      return (AdManager)new RewardedAdManager(param1NetworkConfig, param1AdLoadCallback);
    }
  },
  UNKNOWN("rewarded", R.string.gmts_format_rewarded);
  
  private final int displayResId;
  
  private final String formatString;
  
  static {
    BANNER_INTERSTITIAL = new null("BANNER_INTERSTITIAL", 4, "banner,interstitial", R.string.gmts_format_banner_interstitial);
    UNKNOWN = new null("UNKNOWN", 5, "unknown", -1);
    $VALUES = $values();
  }
  
  AdFormat(String paramString1, int paramInt1) {
    this.formatString = paramString1;
    this.displayResId = paramInt1;
  }
  
  public static AdFormat from(String paramString) {
    AdFormat[] arrayOfAdFormat = values();
    for (int i = 0; i < 6; i++) {
      AdFormat adFormat = arrayOfAdFormat[i];
      if (paramString.equals(adFormat.getFormatString()))
        return adFormat; 
    } 
    return UNKNOWN;
  }
  
  public abstract AdManager createAdLoader(NetworkConfig paramNetworkConfig, AdLoadCallback paramAdLoadCallback);
  
  public String getDisplayString() {
    return DataStore.getContext().getString(this.displayResId);
  }
  
  public String getFormatString() {
    return this.formatString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */