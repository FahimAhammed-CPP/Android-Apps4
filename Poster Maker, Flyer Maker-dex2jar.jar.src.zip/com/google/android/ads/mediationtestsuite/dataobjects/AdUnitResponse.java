package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.MediationConfigClient;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.google.gson.reflect.TypeToken;

public class AdUnitResponse implements Cloneable {
  @SerializedName("ad_unit_id")
  private String adUnitId;
  
  @SerializedName("ad_unit_name")
  private String adUnitName;
  
  private AdFormat format;
  
  @SerializedName("mediation_config")
  private MediationConfig mediationConfig;
  
  public AdUnitResponse clone() {
    Gson gson = MediationConfigClient.createGson();
    return (AdUnitResponse)gson.fromJson(gson.toJsonTree(this), (new TypeToken<AdUnitResponse>(this) {
        
        }).getType());
  }
  
  public String getAdUnitId() {
    return this.adUnitId;
  }
  
  public String getAdUnitName() {
    return this.adUnitName;
  }
  
  public AdFormat getFormat() {
    return this.format;
  }
  
  public MediationConfig getMediationConfig() {
    return this.mediationConfig;
  }
  
  public void setAdUnitId(String paramString) {
    this.adUnitId = paramString;
  }
  
  public void setFormat(AdFormat paramAdFormat) {
    this.format = paramAdFormat;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdUnitResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */