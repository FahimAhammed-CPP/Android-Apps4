package com.google.android.ads.mediationtestsuite.dataobjects;

import android.content.Context;
import android.content.ContextWrapper;
import com.google.android.ads.mediationtestsuite.AdLoadCallback;
import com.google.android.ads.mediationtestsuite.BatchAdRequestCallbacks;
import com.google.android.ads.mediationtestsuite.utils.AdManager;
import com.google.android.gms.ads.LoadAdError;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class BatchAdRequestManager implements AdLoadCallback {
  private final Context context;
  
  private final List<NetworkConfig> networks;
  
  private final HashMap<NetworkConfig, AdManager> networksToLoaders = new HashMap<NetworkConfig, AdManager>();
  
  private boolean stopTesting = false;
  
  private int testedCount = 0;
  
  private final BatchAdRequestCallbacks tester;
  
  public BatchAdRequestManager(Context paramContext, Collection<NetworkConfig> paramCollection, BatchAdRequestCallbacks paramBatchAdRequestCallbacks) {
    this.networks = new ArrayList<NetworkConfig>(paramCollection);
    this.tester = paramBatchAdRequestCallbacks;
    Context context = paramContext;
    if (paramContext instanceof ContextWrapper) {
      ContextWrapper contextWrapper = (ContextWrapper)paramContext;
      context = paramContext;
      if (contextWrapper.getBaseContext() instanceof android.app.Activity)
        context = contextWrapper.getBaseContext(); 
    } 
    this.context = context;
  }
  
  private void testNextConfig() {
    if (this.testedCount < this.networks.size() && !this.stopTesting) {
      NetworkConfig networkConfig = this.networks.get(this.testedCount);
      this.testedCount++;
      if (networkConfig.isTestable()) {
        AdManager adManager2 = this.networksToLoaders.get(networkConfig);
        AdManager adManager1 = adManager2;
        if (adManager2 == null) {
          adManager1 = networkConfig.getAdapter().getFormat().createAdLoader(networkConfig, this);
          this.networksToLoaders.put(networkConfig, adManager1);
        } 
        adManager1.loadAd(this.context);
        return;
      } 
      this.tester.onNetworkConfigTested(this, networkConfig);
      testNextConfig();
      return;
    } 
    this.tester.onBatchAdRequestCompleted(this);
  }
  
  public void beginTesting() {
    this.testedCount = 0;
    this.stopTesting = false;
    testNextConfig();
  }
  
  public void cancelTesting() {
    this.stopTesting = true;
    Iterator<AdManager> iterator = this.networksToLoaders.values().iterator();
    while (iterator.hasNext())
      ((AdManager)iterator.next()).cancel(); 
  }
  
  public void onAdFailedToLoad(AdManager paramAdManager, LoadAdError paramLoadAdError) {
    testNextConfig();
  }
  
  public void onAdLoaded(AdManager paramAdManager) {
    testNextConfig();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\BatchAdRequestManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */