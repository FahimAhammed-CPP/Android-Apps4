package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class AdManagerCLDResponse {
  @SerializedName("ad_unit_settings")
  private List<AdUnitResponse> adUnitSettings;
  
  @SerializedName("app_id")
  private String appId;
  
  @SerializedName("initializer_settings")
  private AdManagerInitializationSettings initializerSettings;
  
  @SerializedName("status")
  private Integer status;
  
  @SerializedName("version")
  private String version;
  
  public List<AdUnitResponse> getAdUnitSettings() {
    return this.adUnitSettings;
  }
  
  public String getAppId() {
    return this.appId;
  }
  
  public AdManagerInitializationSettings getInitializerSettings() {
    return this.initializerSettings;
  }
  
  public Integer getStatus() {
    return this.status;
  }
  
  public String getVersion() {
    return this.version;
  }
  
  public List<YieldGroup> getYieldGroups() {
    ArrayList<YieldGroup> arrayList = new ArrayList();
    if (getInitializerSettings() == null)
      return arrayList; 
    Map<String, AdManagerAdapterInitializationSettings> map = getInitializerSettings().getConfig();
    if (map == null)
      return arrayList; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (String str : map.keySet()) {
      for (AdManagerNetworkResponse adManagerNetworkResponse : ((AdManagerAdapterInitializationSettings)map.get(str)).getData()) {
        NetworkResponse networkResponse = new NetworkResponse(adManagerNetworkResponse.getData(), str, false);
        List<Integer> list = adManagerNetworkResponse.getMediationGroupIds();
        if (list == null)
          continue; 
        for (Integer integer : new HashSet(list)) {
          Map<Object, Object> map2 = (Map)hashMap.get(integer);
          Map<Object, Object> map1 = map2;
          if (map2 == null) {
            map1 = new HashMap<Object, Object>();
            map1.put(adManagerNetworkResponse.getFormat(), new ArrayList());
            hashMap.put(integer, map1);
          } 
          ((List<NetworkResponse>)map1.get(adManagerNetworkResponse.getFormat())).add(networkResponse);
        } 
      } 
    } 
    for (Integer integer : hashMap.keySet()) {
      map = (Map<String, AdManagerAdapterInitializationSettings>)hashMap.get(integer);
      for (AdFormat adFormat : map.keySet())
        arrayList.add(new YieldGroup(integer, adFormat, (List<NetworkResponse>)map.get(adFormat))); 
    } 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdManagerCLDResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */