package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class MediationConfig {
  @SerializedName("ad_networks")
  private List<NetworkResponse> adNetworks;
  
  @SerializedName("mediation_group_name")
  private String mediationGroupName;
  
  public List<NetworkResponse> getAdNetworks() {
    return this.adNetworks;
  }
  
  public String getMediationGroupName() {
    return this.mediationGroupName;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\MediationConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */