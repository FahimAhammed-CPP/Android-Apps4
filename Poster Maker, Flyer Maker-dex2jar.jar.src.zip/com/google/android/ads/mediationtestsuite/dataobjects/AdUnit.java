package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.AdRequestUtil;
import java.util.Iterator;

public class AdUnit extends SingleFormatConfigurationItem implements Matchable {
  public static final String CUSTOM_EVENT_ADAPTER_CLASS = "com.google.ads.mediation.customevent.CustomEventAdapter";
  
  public static final String GOOGLE_ADAPTER_CLASS = "com.google.ads.mediation.admob.AdMobAdapter";
  
  private AdUnitId adUnitId;
  
  private String id;
  
  private String mediationGroup;
  
  private String name;
  
  public AdUnit(String paramString1, String paramString2, AdFormat paramAdFormat, MediationConfig paramMediationConfig) {
    super(paramAdFormat, paramMediationConfig.getAdNetworks());
    this.id = paramString1;
    this.name = paramString2;
    this.adUnitId = new AdUnitId(paramString1, paramString2);
    this.mediationGroup = paramMediationConfig.getMediationGroupName();
    Iterator<NetworkConfig> iterator = getNetworkConfigs().iterator();
    while (iterator.hasNext())
      ((NetworkConfig)iterator.next()).setAdUnitId(paramString1); 
  }
  
  public AdUnitId getAdUnitId() {
    return this.adUnitId;
  }
  
  public String getAdUnitIdForTestLoad(NetworkConfig paramNetworkConfig) {
    return AdRequestUtil.getAdMobAdUnitIdForFormat(paramNetworkConfig.getAdapter().getFormat());
  }
  
  public String getId() {
    return this.id;
  }
  
  public String getMediationGroup() {
    return this.mediationGroup;
  }
  
  public String getName() {
    return this.name;
  }
  
  public boolean matches(CharSequence paramCharSequence) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface toString : ()Ljava/lang/String;
    //   6: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   9: astore_1
    //   10: aload_0
    //   11: invokevirtual getName : ()Ljava/lang/String;
    //   14: ifnull -> 31
    //   17: aload_0
    //   18: invokevirtual getName : ()Ljava/lang/String;
    //   21: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   24: aload_1
    //   25: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   28: ifne -> 99
    //   31: aload_0
    //   32: getfield format : Lcom/google/android/ads/mediationtestsuite/dataobjects/AdFormat;
    //   35: invokevirtual getDisplayString : ()Ljava/lang/String;
    //   38: astore_3
    //   39: getstatic java/util/Locale.ENGLISH : Ljava/util/Locale;
    //   42: astore #4
    //   44: aload_3
    //   45: aload #4
    //   47: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   50: aload_1
    //   51: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   54: ifne -> 99
    //   57: aload_0
    //   58: invokevirtual getId : ()Ljava/lang/String;
    //   61: aload #4
    //   63: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   66: aload_1
    //   67: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   70: ifne -> 99
    //   73: aload_0
    //   74: invokevirtual getMediationGroup : ()Ljava/lang/String;
    //   77: ifnull -> 94
    //   80: aload_0
    //   81: invokevirtual getMediationGroup : ()Ljava/lang/String;
    //   84: aload_1
    //   85: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   88: ifeq -> 94
    //   91: goto -> 99
    //   94: iconst_0
    //   95: istore_2
    //   96: goto -> 101
    //   99: iconst_1
    //   100: istore_2
    //   101: iload_2
    //   102: ifeq -> 107
    //   105: iconst_1
    //   106: ireturn
    //   107: aload_0
    //   108: invokevirtual getNetworkConfigs : ()Ljava/util/List;
    //   111: invokeinterface iterator : ()Ljava/util/Iterator;
    //   116: astore_3
    //   117: aload_3
    //   118: invokeinterface hasNext : ()Z
    //   123: ifeq -> 144
    //   126: aload_3
    //   127: invokeinterface next : ()Ljava/lang/Object;
    //   132: checkcast com/google/android/ads/mediationtestsuite/dataobjects/NetworkConfig
    //   135: aload_1
    //   136: invokevirtual matches : (Ljava/lang/CharSequence;)Z
    //   139: ifeq -> 117
    //   142: iconst_1
    //   143: ireturn
    //   144: iconst_0
    //   145: ireturn
  }
  
  public void setId(String paramString) {
    this.id = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdUnit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */