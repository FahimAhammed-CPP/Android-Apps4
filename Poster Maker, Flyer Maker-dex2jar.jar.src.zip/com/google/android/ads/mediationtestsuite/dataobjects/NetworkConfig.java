package com.google.android.ads.mediationtestsuite.dataobjects;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.viewmodels.TestState;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.mediation.VersionInfo;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class NetworkConfig implements Parcelable, Matchable {
  public static final Parcelable.Creator<NetworkConfig> CREATOR = new Parcelable.Creator<NetworkConfig>() {
      public NetworkConfig createFromParcel(Parcel param1Parcel) {
        return new NetworkConfig(param1Parcel);
      }
      
      public NetworkConfig[] newArray(int param1Int) {
        return new NetworkConfig[param1Int];
      }
    };
  
  private static int nextConfigId = 1;
  
  private String adUnitId;
  
  private NetworkAdapter adapter;
  
  private ConfigurationItem configurationItem;
  
  private boolean hasMissingParameters;
  
  private int id;
  
  private boolean isRtbAdapter;
  
  private String label;
  
  private TestResult lastTestResult;
  
  private Map<String, String> serverParameters;
  
  private NetworkConfig(Parcel paramParcel) {
    int i = 0;
    this.isRtbAdapter = false;
    this.hasMissingParameters = false;
    this.id = paramParcel.readInt();
    this.label = paramParcel.readString();
    this.lastTestResult = TestResult.values()[paramParcel.readInt()];
    this.adapter = (NetworkAdapter)paramParcel.readParcelable(NetworkAdapter.class.getClassLoader());
    this.serverParameters = new HashMap<String, String>();
    int j = paramParcel.readInt();
    while (i < j) {
      this.serverParameters.put(paramParcel.readString(), paramParcel.readString());
      i++;
    } 
    this.adUnitId = paramParcel.readString();
  }
  
  public NetworkConfig(AdFormat paramAdFormat, NetworkResponse paramNetworkResponse) {
    NetworkAdapter networkAdapter;
    this.isRtbAdapter = false;
    this.hasMissingParameters = false;
    int i = nextConfigId;
    nextConfigId = i + 1;
    this.id = i;
    this.serverParameters = new HashMap<String, String>();
    if (!paramNetworkResponse.hasValidMediationAdapter())
      return; 
    this.isRtbAdapter = paramNetworkResponse.isRtbAdapter();
    Map<String, String> map = paramNetworkResponse.getData();
    if (paramNetworkResponse.isCustomEventAdapter()) {
      networkAdapter = new NetworkAdapter();
      for (String str1 : map.keySet()) {
        String[] arrayOfString;
        String str2 = map.get(str1);
        str1.hashCode();
        i = -1;
        switch (str1.hashCode()) {
          case 1954460585:
            if (!str1.equals("parameter"))
              break; 
            i = 2;
            break;
          case 102727412:
            if (!str1.equals("label"))
              break; 
            i = 1;
            break;
          case -290474766:
            if (!str1.equals("class_name"))
              break; 
            i = 0;
            break;
        } 
        switch (i) {
          default:
            continue;
          case 2:
            this.serverParameters.put("parameter", str2);
            continue;
          case 1:
            arrayOfString = str2.split("\\.");
            networkAdapter.setNetworkLabel(String.format(DataStore.getContext().getString(R.string.gmts_ad_source_custom_event_title_format), new Object[] { arrayOfString[arrayOfString.length - 1] }));
            this.label = networkAdapter.getNetworkLabel();
            continue;
          case 0:
            break;
        } 
        networkAdapter.setClassName(str2);
      } 
      networkAdapter.setFormat(paramAdFormat);
      networkAdapter.getServerParameters().put(DataStore.getContext().getString(R.string.gmts_parameter_label), "parameter");
      networkAdapter.detectInstallation();
      this.adapter = networkAdapter;
    } else {
      NetworkAdapter networkAdapter1;
      String str = networkAdapter.getClassName();
      NetworkAdapterDataStore networkAdapterDataStore = DataStore.getNetworkAdapterDataStore();
      if (networkAdapterDataStore == null) {
        paramAdFormat = null;
      } else {
        networkAdapter1 = networkAdapterDataStore.getAdapter(paramAdFormat, this.isRtbAdapter, str);
      } 
      this.adapter = networkAdapter1;
      this.serverParameters = map;
      if (networkAdapter1 != null) {
        checkMissingParameters();
        this.label = this.adapter.getNetwork().getName();
      } 
    } 
    this.lastTestResult = TestResult.UNTESTED;
    if (this.adapter != null && !isTestable())
      this.lastTestResult = TestResult.FAILURE_UNABLE_TO_TEST; 
  }
  
  private void checkMissingParameters() {
    for (String str : this.adapter.getServerParameters().values()) {
      if (this.serverParameters.get(str) == null)
        this.hasMissingParameters = true; 
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public TestState getAdLoadState() {
    if (isTestable()) {
      int i = this.lastTestResult.ordinal();
      return (i != 0) ? ((i != 1) ? TestState.ERROR : TestState.OK) : TestState.WARNING;
    } 
    return null;
  }
  
  public String getAdUnitId() {
    return this.adUnitId;
  }
  
  public String getAdUnitIdForTestLoad() {
    if (!this.adapter.getClassName().equals("com.google.ads.mediation.admob.AdMobAdapter")) {
      String str = this.adUnitId;
      if (str != null)
        return str; 
    } 
    return this.configurationItem.getAdUnitIdForTestLoad(this);
  }
  
  public NetworkAdapter getAdapter() {
    return this.adapter;
  }
  
  public TestState getAdapterState() {
    if (!isAdMob()) {
      NetworkAdapter networkAdapter = this.adapter;
      if (networkAdapter == null || !networkAdapter.isAdapterPresent())
        return TestState.ERROR; 
    } 
    return TestState.OK;
  }
  
  public AdapterStatus getAdapterStatus() {
    Map map = MobileAds.getInitializationStatus().getAdapterStatusMap();
    return (this.adapter.getInitializerClassName() != null) ? (AdapterStatus)map.get(this.adapter.getInitializerClassName()) : null;
  }
  
  public String getAdapterVersion() {
    VersionInfo versionInfo = getAdapter().getVersion();
    if (versionInfo != null) {
      int i = versionInfo.getMicroVersion();
      double d = i;
      Double.isNaN(d);
      int j = (int)Math.floor(d / 100.0D);
      return String.format("%d.%d.%d.%d", new Object[] { Integer.valueOf(versionInfo.getMajorVersion()), Integer.valueOf(versionInfo.getMinorVersion()), Integer.valueOf(j), Integer.valueOf(i % 100) });
    } 
    return null;
  }
  
  public int getId() {
    return this.id;
  }
  
  public String getLabel() {
    return this.label;
  }
  
  public TestResult getLastTestResult() {
    return this.lastTestResult;
  }
  
  public TestState getManifestState() {
    NetworkAdapter networkAdapter = this.adapter;
    if (networkAdapter != null) {
      Network network = networkAdapter.getNetwork();
      if (network != null)
        return network.isManifestPresent() ? TestState.OK : TestState.ERROR; 
    } 
    return null;
  }
  
  public String getNotTestableReason(Context paramContext) {
    if (!requiredComponentsInstalled())
      return paramContext.getResources().getString(R.string.gmts_error_missing_components_message); 
    if (this.isRtbAdapter) {
      boolean bool = TestSuiteState.isTestDevice(DataStore.getContext());
      String str = paramContext.getResources().getString(R.string.gmts_link_text_learn_more);
      if (!isAdapterInitialized()) {
        str = String.format("<a href=\"%s\">%s</a>", new Object[] { TestSuiteState.getProductTheme().getAdapterInitializationHelpUrl(), str });
        return paramContext.getResources().getString(R.string.gmts_open_bidding_load_error_inititialization_format, new Object[] { str });
      } 
      if (!bool) {
        str = String.format("<a href=\"%s\">%s</a>", new Object[] { TestSuiteState.getProductTheme().getRegisterTestDevicesHelpUrl(), str });
        return paramContext.getResources().getString(R.string.gmts_open_bidding_load_error_test_device_format, new Object[] { str });
      } 
    } 
    return paramContext.getResources().getString(R.string.gmts_error_missing_components_message);
  }
  
  public TestState getSDKState() {
    NetworkAdapter networkAdapter = this.adapter;
    if (networkAdapter != null) {
      Network network = networkAdapter.getNetwork();
      if (network != null)
        return network.isSdkPresent() ? TestState.OK : TestState.ERROR; 
    } 
    return null;
  }
  
  public String getSDKVersion() {
    if (isAdMob())
      return MobileAds.getVersionString(); 
    VersionInfo versionInfo = getAdapter().getSDKVersion();
    return (versionInfo != null) ? String.format("%d.%d.%d", new Object[] { Integer.valueOf(versionInfo.getMajorVersion()), Integer.valueOf(versionInfo.getMinorVersion()), Integer.valueOf(versionInfo.getMicroVersion()) }) : null;
  }
  
  public Map<String, String> getServerParameters() {
    return this.serverParameters;
  }
  
  public TestState getServerParametersState() {
    return this.hasMissingParameters ? TestState.ERROR : TestState.OK;
  }
  
  public boolean isAdMob() {
    return this.adapter.getClassName().equals("com.google.ads.mediation.admob.AdMobAdapter");
  }
  
  public boolean isAdapterInitialized() {
    AdapterStatus adapterStatus = getAdapterStatus();
    return (adapterStatus != null && adapterStatus.getInitializationState() == AdapterStatus.State.READY);
  }
  
  public boolean isRtbAdapter() {
    return this.isRtbAdapter;
  }
  
  public boolean isTestable() {
    return !requiredComponentsInstalled() ? false : (!(this.isRtbAdapter && (!TestSuiteState.isTestDevice(DataStore.getContext()) || !isAdapterInitialized())));
  }
  
  public boolean matches(CharSequence paramCharSequence) {
    paramCharSequence = paramCharSequence.toString().toLowerCase();
    String str = this.label;
    if (str == null || !str.toLowerCase(Locale.ENGLISH).contains(paramCharSequence)) {
      str = this.adUnitId;
      if (str == null || !str.toLowerCase(Locale.ENGLISH).contains(paramCharSequence)) {
        NetworkAdapter networkAdapter = this.adapter;
        if (networkAdapter == null || !networkAdapter.getClassName().toLowerCase(Locale.ENGLISH).contains(paramCharSequence)) {
          networkAdapter = this.adapter;
          if (networkAdapter == null || !networkAdapter.getFormat().getDisplayString().toLowerCase(Locale.ENGLISH).startsWith((String)paramCharSequence))
            return false; 
        } 
      } 
    } 
    return true;
  }
  
  public boolean requiredComponentsInstalled() {
    NetworkAdapter networkAdapter = this.adapter;
    boolean bool = false;
    null = bool;
    if (networkAdapter != null) {
      Network network = networkAdapter.getNetwork();
      null = bool;
      if (this.adapter.isAdapterPresent()) {
        if (network != null) {
          null = bool;
          if (network.isSdkPresent()) {
            null = bool;
            if (network.isManifestPresent())
              return true; 
          } 
          return null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public void setAdUnitId(String paramString) {
    this.adUnitId = paramString;
  }
  
  public void setAdapter(NetworkAdapter paramNetworkAdapter) {
    this.adapter = paramNetworkAdapter;
  }
  
  public void setConfigurationItem(ConfigurationItem paramConfigurationItem) {
    this.configurationItem = paramConfigurationItem;
  }
  
  public void setId(int paramInt) {
    this.id = paramInt;
  }
  
  public void setLabel(String paramString) {
    this.label = paramString;
  }
  
  public void setLastTestResult(TestResult paramTestResult) {
    TestResult testResult = this.lastTestResult;
    this.lastTestResult = paramTestResult;
    if (testResult != paramTestResult) {
      DataStore.networkConfigUpdated(this);
      this.configurationItem.configTestResultUpdated(Integer.valueOf(this.id));
    } 
  }
  
  public boolean testedSuccessfully() {
    return (this.lastTestResult == TestResult.SUCCESS);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.id);
    paramParcel.writeString(this.label);
    paramParcel.writeInt(this.lastTestResult.ordinal());
    paramParcel.writeParcelable(this.adapter, 0);
    paramParcel.writeInt(this.serverParameters.size());
    for (String str : this.serverParameters.keySet()) {
      paramParcel.writeString(str);
      paramParcel.writeString(this.serverParameters.get(str));
    } 
    paramParcel.writeString(this.adUnitId);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\NetworkConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */