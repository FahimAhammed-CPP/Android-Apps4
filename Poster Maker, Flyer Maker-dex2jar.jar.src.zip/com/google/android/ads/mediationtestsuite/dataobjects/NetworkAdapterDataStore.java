package com.google.android.ads.mediationtestsuite.dataobjects;

import android.content.Context;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NetworkAdapterDataStore {
  private List<Network> networks;
  
  private Map<String, Map<AdFormat, NetworkAdapter>> rtbAdapterMapping;
  
  private Map<String, Map<AdFormat, NetworkAdapter>> waterfallAdapterMapping;
  
  public NetworkAdapterDataStore(Context paramContext, List<Network> paramList, List<NetworkAdapter> paramList1) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Network network : paramList) {
      network.detectInstallation();
      hashMap.put(network.getName(), network);
    } 
    this.networks = paramList;
    this.waterfallAdapterMapping = new HashMap<String, Map<AdFormat, NetworkAdapter>>();
    this.rtbAdapterMapping = new HashMap<String, Map<AdFormat, NetworkAdapter>>();
    for (NetworkAdapter networkAdapter : paramList1) {
      Network network = (Network)hashMap.get(networkAdapter.getNetworkLabel());
      networkAdapter.setNetwork(network);
      networkAdapter.detectInstallation();
      String str = networkAdapter.getClassName();
      if (network != null) {
        String str1 = network.getInitializerClass();
      } else {
        network = null;
      } 
      if (networkAdapter.isRtbAdapter()) {
        if (!this.rtbAdapterMapping.containsKey(str))
          this.rtbAdapterMapping.put(networkAdapter.getClassName(), new HashMap<AdFormat, NetworkAdapter>()); 
        ((Map<AdFormat, NetworkAdapter>)this.rtbAdapterMapping.get(networkAdapter.getClassName())).put(networkAdapter.getFormat(), networkAdapter);
        if (network != null && !network.equals(str)) {
          if (!this.rtbAdapterMapping.containsKey(network))
            this.rtbAdapterMapping.put(network, new HashMap<AdFormat, NetworkAdapter>()); 
          ((Map<AdFormat, NetworkAdapter>)this.rtbAdapterMapping.get(network)).put(networkAdapter.getFormat(), networkAdapter);
        } 
        continue;
      } 
      if (!this.waterfallAdapterMapping.containsKey(str))
        this.waterfallAdapterMapping.put(str, new HashMap<AdFormat, NetworkAdapter>()); 
      ((Map<AdFormat, NetworkAdapter>)this.waterfallAdapterMapping.get(str)).put(networkAdapter.getFormat(), networkAdapter);
      if (network != null && !network.equals(str)) {
        if (!this.waterfallAdapterMapping.containsKey(network))
          this.waterfallAdapterMapping.put(network, new HashMap<AdFormat, NetworkAdapter>()); 
        ((Map<AdFormat, NetworkAdapter>)this.waterfallAdapterMapping.get(network)).put(networkAdapter.getFormat(), networkAdapter);
      } 
    } 
  }
  
  public NetworkAdapter getAdapter(AdFormat paramAdFormat, boolean paramBoolean, String paramString) {
    if (paramBoolean) {
      map = this.rtbAdapterMapping.get(paramString);
      return (map != null) ? (NetworkAdapter)map.get(paramAdFormat) : null;
    } 
    Map map = this.waterfallAdapterMapping.get(map);
    return (map != null) ? (NetworkAdapter)map.get(paramAdFormat) : null;
  }
  
  public List<Network> getNetworks() {
    return this.networks;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\NetworkAdapterDataStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */