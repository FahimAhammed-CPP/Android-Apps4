package com.google.android.ads.mediationtestsuite.dataobjects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.ads.mediationtestsuite.utils.AppInfoUtil;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NetworkSDK implements Parcelable {
  public static final Parcelable.Creator<NetworkSDK> CREATOR = new Parcelable.Creator<NetworkSDK>() {
      public NetworkSDK createFromParcel(Parcel param1Parcel) {
        return new NetworkSDK(param1Parcel);
      }
      
      public NetworkSDK[] newArray(int param1Int) {
        return new NetworkSDK[param1Int];
      }
    };
  
  private boolean installationDetected = false;
  
  private boolean manifestPresent;
  
  @SerializedName("requiredActivities")
  private List<String> requiredActivities;
  
  @SerializedName("requiredMetadata")
  private List<String> requiredMetadata;
  
  @SerializedName("requiredPermissions")
  private List<String> requiredPermissions;
  
  @SerializedName("requiredProviders")
  private List<String> requiredProviders;
  
  @SerializedName("requiredReceivers")
  private List<String> requiredReceivers;
  
  @SerializedName("sdkDetectionClass")
  private String sdkDetectionClass;
  
  private boolean sdkPresent;
  
  private NetworkSDK(Parcel paramParcel) {
    boolean[] arrayOfBoolean = new boolean[2];
    paramParcel.readBooleanArray(arrayOfBoolean);
    this.sdkPresent = arrayOfBoolean[0];
    this.manifestPresent = arrayOfBoolean[1];
    this.sdkDetectionClass = paramParcel.readString();
    ArrayList<String> arrayList = new ArrayList();
    this.requiredActivities = arrayList;
    paramParcel.readStringList(arrayList);
    arrayList = new ArrayList<String>();
    this.requiredPermissions = arrayList;
    paramParcel.readStringList(arrayList);
    arrayList = new ArrayList<String>();
    this.requiredReceivers = arrayList;
    paramParcel.readStringList(arrayList);
    arrayList = new ArrayList<String>();
    this.requiredProviders = arrayList;
    paramParcel.readStringList(arrayList);
    arrayList = new ArrayList<String>();
    this.requiredMetadata = arrayList;
    paramParcel.readStringList(arrayList);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void detectInstallation() {
    if (this.installationDetected)
      return; 
    this.sdkPresent = AppInfoUtil.classExists(this.sdkDetectionClass);
    Iterator<String> iterator = this.requiredActivities.iterator();
    boolean bool;
    for (bool = true; iterator.hasNext(); bool = false) {
      if (AppInfoUtil.activityIsRegistered(iterator.next()))
        continue; 
    } 
    iterator = this.requiredPermissions.iterator();
    while (iterator.hasNext()) {
      if (AppInfoUtil.permissionIsRequested(iterator.next()))
        continue; 
      bool = false;
    } 
    iterator = this.requiredReceivers.iterator();
    while (iterator.hasNext()) {
      if (AppInfoUtil.receiverIsRegistered(iterator.next()))
        continue; 
      bool = false;
    } 
    iterator = this.requiredProviders.iterator();
    while (iterator.hasNext()) {
      if (AppInfoUtil.providerIsRegistered(iterator.next()))
        continue; 
      bool = false;
    } 
    iterator = this.requiredMetadata.iterator();
    while (iterator.hasNext()) {
      if (AppInfoUtil.appHasMetaData(iterator.next()))
        continue; 
      bool = false;
    } 
    this.manifestPresent = bool;
    this.installationDetected = true;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof NetworkSDK) ? this.sdkDetectionClass.equals(((NetworkSDK)paramObject).getSdkDetectionClass()) : super.equals(paramObject);
  }
  
  public List<String> getRequiredActivities() {
    return this.requiredActivities;
  }
  
  public List<String> getRequiredMetadata() {
    return this.requiredMetadata;
  }
  
  public List<String> getRequiredPermissions() {
    return this.requiredPermissions;
  }
  
  public List<String> getRequiredProviders() {
    return this.requiredProviders;
  }
  
  public List<String> getRequiredReceivers() {
    return this.requiredReceivers;
  }
  
  public String getSdkDetectionClass() {
    return this.sdkDetectionClass;
  }
  
  public int hashCode() {
    return this.sdkDetectionClass.hashCode();
  }
  
  public boolean isManifestPresent() {
    detectInstallation();
    return this.manifestPresent;
  }
  
  public boolean isSdkPresent() {
    detectInstallation();
    return this.sdkPresent;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.sdkDetectionClass);
    paramParcel.writeStringList(this.requiredActivities);
    paramParcel.writeStringList(this.requiredPermissions);
    paramParcel.writeStringList(this.requiredReceivers);
    paramParcel.writeStringList(this.requiredProviders);
    paramParcel.writeStringList(this.requiredMetadata);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\NetworkSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */