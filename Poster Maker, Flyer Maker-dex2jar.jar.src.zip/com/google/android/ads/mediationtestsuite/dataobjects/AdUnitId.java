package com.google.android.ads.mediationtestsuite.dataobjects;

import java.util.Locale;

public class AdUnitId {
  private String id;
  
  private String name;
  
  public AdUnitId(String paramString1, String paramString2) {
    this.id = paramString1;
    this.name = paramString2;
  }
  
  public String getId() {
    return this.id;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPubId() {
    return this.id.substring(0, 26);
  }
  
  public String getSlotId() {
    return this.id.substring(28);
  }
  
  public String getTitle() {
    String str = this.name;
    return (str != null) ? str : this.id;
  }
  
  public boolean matches(String paramString) {
    String str = this.name;
    return ((str != null && str.toLowerCase().contains(paramString)) || getSlotId().toLowerCase(Locale.ENGLISH).startsWith(paramString));
  }
  
  public void setId(String paramString) {
    this.id = paramString;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdUnitId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */