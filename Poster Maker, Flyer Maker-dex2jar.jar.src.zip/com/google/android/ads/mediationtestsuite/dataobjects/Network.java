package com.google.android.ads.mediationtestsuite.dataobjects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Network implements Parcelable {
  public static final Parcelable.Creator<Network> CREATOR = new Parcelable.Creator<Network>() {
      public Network createFromParcel(Parcel param1Parcel) {
        return new Network(param1Parcel);
      }
      
      public Network[] newArray(int param1Int) {
        return new Network[param1Int];
      }
    };
  
  @SerializedName("buyerNetworkId")
  private Integer buyerNetworkId;
  
  private List<NetworkConfig> configs;
  
  private NetworkSDK detectedSDK;
  
  @SerializedName("initializerClass")
  private String initializerClass;
  
  @SerializedName("name")
  private String name;
  
  @SerializedName("sdks")
  private final List<NetworkSDK> sdks;
  
  public Network() {
    this.sdks = new ArrayList<NetworkSDK>();
    this.configs = new ArrayList<NetworkConfig>();
  }
  
  private Network(Parcel paramParcel) {
    NetworkSDK[] arrayOfNetworkSDK = (NetworkSDK[])paramParcel.readParcelableArray(NetworkSDK.class.getClassLoader());
    ArrayList<NetworkSDK> arrayList = new ArrayList();
    this.sdks = arrayList;
    Collections.addAll(arrayList, arrayOfNetworkSDK);
    this.name = paramParcel.readString();
    this.initializerClass = paramParcel.readString();
    this.configs = new ArrayList<NetworkConfig>();
  }
  
  public void addConfig(NetworkConfig paramNetworkConfig) {
    this.configs.add(paramNetworkConfig);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void detectInstallation() {
    for (NetworkSDK networkSDK : this.sdks) {
      if (networkSDK.isSdkPresent())
        this.detectedSDK = networkSDK; 
    } 
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof Network) ? this.name.equals(((Network)paramObject).getName()) : super.equals(paramObject);
  }
  
  public Integer getBuyerNetworkId() {
    return this.buyerNetworkId;
  }
  
  public List<NetworkConfig> getConfigs() {
    return this.configs;
  }
  
  public String getInitializerClass() {
    return this.initializerClass;
  }
  
  public String getName() {
    return (TestSuiteState.isAdManagerApp() && this.name.equals("AdMob")) ? "Ad Manager" : this.name;
  }
  
  public List<NetworkSDK> getSdks() {
    return this.sdks;
  }
  
  public int hashCode() {
    return this.name.hashCode();
  }
  
  public boolean isManifestPresent() {
    NetworkSDK networkSDK = this.detectedSDK;
    return (networkSDK != null && networkSDK.isManifestPresent());
  }
  
  public boolean isSdkPresent() {
    NetworkSDK networkSDK = this.detectedSDK;
    return (networkSDK != null && networkSDK.isSdkPresent());
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    NetworkSDK[] arrayOfNetworkSDK = (NetworkSDK[])NetworkSDK.CREATOR.newArray(this.sdks.size());
    this.sdks.toArray(arrayOfNetworkSDK);
    paramParcel.writeParcelableArray((Parcelable[])arrayOfNetworkSDK, 0);
    paramParcel.writeString(this.name);
    paramParcel.writeString(this.initializerClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\Network.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */