package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.utils.AppInfoUtil;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.utils.logging.TestSuiteTabViewEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.AdUnitViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemsFragmentViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.HomeActivityViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.NetworkConfigDetailViewModel;
import java.util.ArrayList;
import java.util.Collection;

public class AdMobProductTheme implements ProductTheme {
  private static final String ADAPTER_INITIALIZATION_ANDROID_URL = "https://googlemobileadssdk.page.link/admob-android-adapter-initialization";
  
  public static final String ADAPTER_INITIALIZATION_UNITY_URL = "https://googlemobileadssdk.page.link/unity-adapter-initialization";
  
  private static final String DISCLAIMER_URL = "https://googlemobileadssdk.page.link/mts-admob-disclaimer";
  
  public static final String REGISTER_TEST_DEVICES_ANDROID_URL = "https://googlemobileadssdk.page.link/admob-android-register-test-device";
  
  public static final String REGISTER_TEST_DEVICES_UNITY_URL = "https://googlemobileadssdk.page.link/unity-register-test-device";
  
  private static final String REGISTER_TEST_DEVICE_URL_FORMAT = "https://apps.admob.com/v2/settings/test-devices/create?tdid=%1$s&p=android";
  
  public String buildTestDeviceRegistrationUrl(String paramString) {
    return String.format("https://apps.admob.com/v2/settings/test-devices/create?tdid=%1$s&p=android", new Object[] { paramString });
  }
  
  public int getAdLoadNoFillDescriptionId() {
    return R.string.gmts_error_no_fill_message;
  }
  
  public int getAdLoadNoFillTitleId() {
    return R.string.gmts_error_no_fill_title;
  }
  
  public int getAdLoadNotTestedDescriptionId() {
    return R.string.gmts_not_tested_message;
  }
  
  public int getAdSourceConfigurationSectionTitleId() {
    return R.string.gmts_section_ad_source_configuration;
  }
  
  public int getAdSourcePageOpenBiddingAdSourcesHeaderId() {
    return R.string.gmts_section_open_bidding_ad_sources;
  }
  
  public int getAdSourcePageWaterfallAdSourcesHeaderId() {
    return R.string.gmts_section_waterfall_ad_sources;
  }
  
  public int getAdUnitPageNoAdUnitsFoundId(TestSuiteTabViewEvent.ViewType paramViewType) {
    return R.string.gmts_no_ad_units_found;
  }
  
  public int getAdUnitPageSearchPlaceholderId() {
    return R.string.gmts_placeholder_search_ad_units;
  }
  
  public String getAdapterInitializationHelpUrl() {
    return TestSuiteState.sharedInstance().isUnity() ? "https://googlemobileadssdk.page.link/unity-adapter-initialization" : "https://googlemobileadssdk.page.link/admob-android-adapter-initialization";
  }
  
  public ConfigurationItemViewModel<? extends ConfigurationItem> getConfigurationItemViewModel(ConfigurationItem paramConfigurationItem) {
    return (ConfigurationItemViewModel<? extends ConfigurationItem>)new AdUnitViewModel((AdUnit)paramConfigurationItem);
  }
  
  public String getDisclaimerUrl() {
    return "https://googlemobileadssdk.page.link/mts-admob-disclaimer";
  }
  
  public HomeActivityViewModel getHomeActivityViewModel(Collection<ConfigurationItem> paramCollection) {
    ArrayList<ConfigurationItem> arrayList2 = new ArrayList();
    ArrayList<ConfigurationItem> arrayList1 = new ArrayList();
    for (ConfigurationItem configurationItem : paramCollection) {
      if (configurationItem.hasAllConfigsPassing()) {
        arrayList2.add(configurationItem);
        continue;
      } 
      arrayList1.add(configurationItem);
    } 
    ConfigurationItemsFragmentViewModel configurationItemsFragmentViewModel1 = new ConfigurationItemsFragmentViewModel(arrayList2, TestSuiteTabViewEvent.ViewType.WORKING, R.string.gmts_working_ad_units);
    ConfigurationItemsFragmentViewModel configurationItemsFragmentViewModel2 = new ConfigurationItemsFragmentViewModel(arrayList1, TestSuiteTabViewEvent.ViewType.FAILING, R.string.gmts_failing_ad_units);
    arrayList2 = new ArrayList<ConfigurationItem>();
    arrayList2.add(configurationItemsFragmentViewModel2);
    arrayList2.add(configurationItemsFragmentViewModel1);
    return new HomeActivityViewModel(arrayList2);
  }
  
  public String getHomePageSubtitle() {
    return "Google AdMob";
  }
  
  public NetworkConfigDetailViewModel getNetworkConfigDetailViewModel(NetworkConfig paramNetworkConfig) {
    return new NetworkConfigDetailViewModel(paramNetworkConfig);
  }
  
  public int getProductStyleId() {
    return R.style.gmts_AdMobStyle;
  }
  
  public String getRegisterTestDevicesHelpUrl() {
    return TestSuiteState.sharedInstance().isUnity() ? "https://googlemobileadssdk.page.link/unity-register-test-device" : "https://googlemobileadssdk.page.link/admob-android-register-test-device";
  }
  
  public boolean supportsRegisteringTestDevices() {
    return (AppInfoUtil.getAdvertisingId() != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdMobProductTheme.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */