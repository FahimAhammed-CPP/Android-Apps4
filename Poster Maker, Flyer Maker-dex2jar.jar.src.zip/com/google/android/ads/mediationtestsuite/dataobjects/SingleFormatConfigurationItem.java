package com.google.android.ads.mediationtestsuite.dataobjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class SingleFormatConfigurationItem extends ConfigurationItem {
  public Map<AdFormat, List<NetworkConfig>> configsPerFormat;
  
  public AdFormat format;
  
  public SingleFormatConfigurationItem() {}
  
  public SingleFormatConfigurationItem(AdFormat paramAdFormat) {
    this.configsPerFormat = new HashMap<AdFormat, List<NetworkConfig>>();
    this.format = paramAdFormat;
    if (paramAdFormat == AdFormat.UNKNOWN)
      return; 
    for (AdFormat adFormat : getSupportedFormats(paramAdFormat))
      this.configsPerFormat.put(adFormat, new ArrayList<NetworkConfig>()); 
  }
  
  public SingleFormatConfigurationItem(AdFormat paramAdFormat, List<NetworkResponse> paramList) {
    this(paramAdFormat);
    for (AdFormat adFormat : getSupportedFormats(paramAdFormat)) {
      Iterator<NetworkResponse> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        NetworkConfig networkConfig = new NetworkConfig(adFormat, iterator.next());
        if (networkConfig.getAdapter() != null) {
          ((List<NetworkConfig>)this.configsPerFormat.get(adFormat)).add(networkConfig);
          updateTestStates(networkConfig);
        } 
      } 
    } 
  }
  
  public static List<AdFormat> getSupportedFormats(AdFormat paramAdFormat) {
    ArrayList<AdFormat> arrayList = new ArrayList();
    if (paramAdFormat == AdFormat.BANNER_INTERSTITIAL) {
      arrayList.add(AdFormat.BANNER);
      arrayList.add(AdFormat.INTERSTITIAL);
      return arrayList;
    } 
    if (paramAdFormat != AdFormat.UNKNOWN)
      arrayList.add(paramAdFormat); 
    return arrayList;
  }
  
  public AdFormat getFormat() {
    return this.format;
  }
  
  public List<NetworkConfig> getNetworkConfigs() {
    ArrayList<NetworkConfig> arrayList = new ArrayList();
    Iterator<List> iterator = this.configsPerFormat.values().iterator();
    while (iterator.hasNext())
      arrayList.addAll(iterator.next()); 
    return arrayList;
  }
  
  public boolean hasAllConfigsPassing() {
    if (hasConfigsMissingComponents())
      return false; 
    for (AdFormat adFormat : this.configsPerFormat.keySet()) {
      boolean bool;
      Iterator<NetworkConfig> iterator = ((List)this.configsPerFormat.get(adFormat)).iterator();
      while (true) {
        if (iterator.hasNext()) {
          if (((NetworkConfig)iterator.next()).getLastTestResult() != TestResult.SUCCESS) {
            boolean bool1 = false;
            break;
          } 
          continue;
        } 
        bool = true;
        break;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\SingleFormatConfigurationItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */