package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.AdRequestUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public final class YieldPartner extends ConfigurationItem implements Matchable {
  private String name;
  
  private final List<NetworkConfig> networkConfigs = new ArrayList<NetworkConfig>();
  
  private YieldPartner() {}
  
  public YieldPartner(String paramString) {
    this.name = paramString;
  }
  
  public static Collection<YieldPartner> getYieldPartners(AdManagerCLDResponse paramAdManagerCLDResponse) {
    List<AdUnitResponse> list = paramAdManagerCLDResponse.getAdUnitSettings();
    if (list == null)
      return new ArrayList<YieldPartner>(); 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (AdUnitResponse adUnitResponse : list) {
      MediationConfig mediationConfig = adUnitResponse.getMediationConfig();
      if (mediationConfig == null)
        continue; 
      String str = adUnitResponse.getAdUnitId();
      if (str == null || !str.matches("^/\\d+(/[^/]+)*$"))
        continue; 
      for (NetworkConfig networkConfig : (new AdUnit(str, adUnitResponse.getAdUnitName(), adUnitResponse.getFormat(), mediationConfig)).getNetworkConfigs()) {
        NetworkAdapter networkAdapter = networkConfig.getAdapter();
        if (networkAdapter == null)
          continue; 
        Network network = networkAdapter.getNetwork();
        if (network == null)
          continue; 
        String str1 = network.getName();
        YieldPartner yieldPartner2 = (YieldPartner)hashMap.get(str1);
        YieldPartner yieldPartner1 = yieldPartner2;
        if (yieldPartner2 == null) {
          yieldPartner1 = new YieldPartner(str1);
          hashMap.put(str1, yieldPartner1);
        } 
        yieldPartner1.addNetworkConfig(networkConfig);
      } 
    } 
    return hashMap.values();
  }
  
  public void addNetworkConfig(NetworkConfig paramNetworkConfig) {
    this.networkConfigs.add(paramNetworkConfig);
    updateTestStates(paramNetworkConfig);
  }
  
  public String getAdUnitIdForTestLoad(NetworkConfig paramNetworkConfig) {
    return (!paramNetworkConfig.isAdMob() && paramNetworkConfig.isRtbAdapter() && paramNetworkConfig.getAdUnitId() != null) ? paramNetworkConfig.getAdUnitId() : AdRequestUtil.getAdManagerAdUnitIdForFormat(paramNetworkConfig.getAdapter().getFormat());
  }
  
  public String getId() {
    return this.name;
  }
  
  public String getName() {
    return this.name;
  }
  
  public List<NetworkConfig> getNetworkConfigs() {
    return this.networkConfigs;
  }
  
  public boolean matches(CharSequence paramCharSequence) {
    paramCharSequence = paramCharSequence.toString().toLowerCase();
    if (this.name.toLowerCase(Locale.getDefault()).startsWith((String)paramCharSequence))
      return true; 
    Iterator<NetworkConfig> iterator = getNetworkConfigs().iterator();
    while (iterator.hasNext()) {
      if (((NetworkConfig)iterator.next()).matches(paramCharSequence))
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\YieldPartner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */