package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.AdRequestUtil;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class YieldGroup extends SingleFormatConfigurationItem implements Matchable {
  private Integer id;
  
  public YieldGroup(Integer paramInteger, AdFormat paramAdFormat, List<NetworkResponse> paramList) {
    super(paramAdFormat, paramList);
    this.id = paramInteger;
    for (AdFormat paramAdFormat : SingleFormatConfigurationItem.getSupportedFormats(paramAdFormat)) {
      NetworkResponse networkResponse = new NetworkResponse(null, "com.google.ads.mediation.admob.AdMobAdapter", false);
      ((List<NetworkConfig>)this.configsPerFormat.get(paramAdFormat)).add(new NetworkConfig(paramAdFormat, networkResponse));
    } 
  }
  
  public String getAdUnitIdForTestLoad(NetworkConfig paramNetworkConfig) {
    return AdRequestUtil.getAdManagerAdUnitIdForFormat(paramNetworkConfig.getAdapter().getFormat());
  }
  
  public String getId() {
    return this.id.toString();
  }
  
  public String getName() {
    return null;
  }
  
  public boolean matches(CharSequence paramCharSequence) {
    boolean bool;
    paramCharSequence = paramCharSequence.toString().toLowerCase(Locale.getDefault());
    if (this.format.getDisplayString().toLowerCase(Locale.getDefault()).startsWith((String)paramCharSequence) || getId().toLowerCase(Locale.getDefault()).contains(paramCharSequence)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return true; 
    Iterator<NetworkConfig> iterator = getNetworkConfigs().iterator();
    while (iterator.hasNext()) {
      if (((NetworkConfig)iterator.next()).matches(paramCharSequence))
        return true; 
    } 
    return false;
  }
  
  public void setId(Integer paramInteger) {
    this.id = paramInteger;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\YieldGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */