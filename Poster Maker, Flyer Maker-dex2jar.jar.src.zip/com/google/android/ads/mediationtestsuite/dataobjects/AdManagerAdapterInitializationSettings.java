package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class AdManagerAdapterInitializationSettings {
  @SerializedName("data")
  private List<AdManagerNetworkResponse> data;
  
  public List<AdManagerNetworkResponse> getData() {
    return this.data;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\AdManagerAdapterInitializationSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */