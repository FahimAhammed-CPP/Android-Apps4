package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.viewmodels.TestState;

public class Caption {
  private final Component component;
  
  private final TestState testState;
  
  private final String version;
  
  public Caption(TestState paramTestState, Component paramComponent) {
    this(paramTestState, paramComponent, null);
  }
  
  public Caption(TestState paramTestState, Component paramComponent, String paramString) {
    this.testState = paramTestState;
    this.component = paramComponent;
    this.version = paramString;
  }
  
  public Component getComponent() {
    return this.component;
  }
  
  public TestState getTestState() {
    return this.testState;
  }
  
  public String getVersion() {
    return this.version;
  }
  
  public enum Component {
    ADAPTER,
    AD_LOAD,
    MANIFEST,
    SDK(R.string.gmts_sdk);
    
    private final int stringResId;
    
    static {
      AD_LOAD = new Component("AD_LOAD", 3, R.string.gmts_ad_load);
      $VALUES = $values();
    }
    
    Component(int param1Int1) {
      this.stringResId = param1Int1;
    }
    
    public int getStringResId() {
      return this.stringResId;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\Caption.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */