package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class CLDResponse {
  @SerializedName("ad_unit_settings")
  private List<AdUnitResponse> adUnitSettings;
  
  public List<AdUnitResponse> getAdUnitSettings() {
    return this.adUnitSettings;
  }
  
  public void setAdUnitSettings(List<AdUnitResponse> paramList) {
    this.adUnitSettings = paramList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\CLDResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */