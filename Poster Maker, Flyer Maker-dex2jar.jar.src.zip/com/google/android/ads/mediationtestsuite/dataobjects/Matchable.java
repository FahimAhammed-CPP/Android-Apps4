package com.google.android.ads.mediationtestsuite.dataobjects;

public interface Matchable {
  boolean matches(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\Matchable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */