package com.google.android.ads.mediationtestsuite.dataobjects;

import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.viewmodels.TestState;
import java.util.Iterator;
import java.util.List;

public abstract class ConfigurationItem {
  public TestState adapterTestState;
  
  public TestState manifestTestState;
  
  public TestState sdkTestState;
  
  public ConfigurationItem() {
    TestState testState = TestState.OK;
    this.sdkTestState = testState;
    this.adapterTestState = testState;
    this.manifestTestState = testState;
  }
  
  public void configTestResultUpdated(Integer paramInteger) {
    if (hasAllConfigsPassing() || hasFailingNetworkConfiguration())
      DataStore.configurationUpdated(this); 
  }
  
  public abstract String getAdUnitIdForTestLoad(NetworkConfig paramNetworkConfig);
  
  public TestState getAdapterTestState() {
    return this.adapterTestState;
  }
  
  public abstract String getId();
  
  public TestState getManifestTestState() {
    return this.manifestTestState;
  }
  
  public abstract String getName();
  
  public abstract List<NetworkConfig> getNetworkConfigs();
  
  public TestState getSdkTestState() {
    return this.sdkTestState;
  }
  
  public boolean hasAllConfigsPassing() {
    if (hasConfigsMissingComponents())
      return false; 
    Iterator<NetworkConfig> iterator = getNetworkConfigs().iterator();
    while (iterator.hasNext()) {
      if (((NetworkConfig)iterator.next()).getLastTestResult() != TestResult.SUCCESS)
        return false; 
    } 
    return true;
  }
  
  public boolean hasConfigsMissingComponents() {
    int i = TestState.OK.getOrderValue();
    return (this.adapterTestState.getOrderValue() < i || this.manifestTestState.getOrderValue() < i || this.sdkTestState.getOrderValue() < i);
  }
  
  public boolean hasFailingNetworkConfiguration() {
    Iterator<NetworkConfig> iterator = getNetworkConfigs().iterator();
    while (iterator.hasNext()) {
      if (((NetworkConfig)iterator.next()).getLastTestResult().isFailure())
        return true; 
    } 
    return false;
  }
  
  public void updateTestStates(NetworkConfig paramNetworkConfig) {
    Network network = paramNetworkConfig.getAdapter().getNetwork();
    if (paramNetworkConfig.getAdapterState().getOrderValue() < this.adapterTestState.getOrderValue())
      this.adapterTestState = paramNetworkConfig.getAdapterState(); 
    if (network != null && !network.isSdkPresent())
      this.sdkTestState = TestState.ERROR; 
    if (network != null && !network.isManifestPresent())
      this.manifestTestState = TestState.ERROR; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\ConfigurationItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */