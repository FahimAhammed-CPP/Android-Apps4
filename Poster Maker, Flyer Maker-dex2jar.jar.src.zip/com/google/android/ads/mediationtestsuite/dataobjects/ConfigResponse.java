package com.google.android.ads.mediationtestsuite.dataobjects;

import java.util.Iterator;
import java.util.List;

public class ConfigResponse {
  private final List<ConfigurationItem> configurationItems;
  
  private final List<Network> networks;
  
  public ConfigResponse(List<ConfigurationItem> paramList, List<Network> paramList1) {
    this.configurationItems = paramList;
    this.networks = paramList1;
  }
  
  public List<ConfigurationItem> getConfigurationItems() {
    return this.configurationItems;
  }
  
  public List<Network> getNetworks() {
    return this.networks;
  }
  
  public boolean isRegisteredTestDevice() {
    Iterator<ConfigurationItem> iterator = this.configurationItems.iterator();
    while (iterator.hasNext()) {
      if (((ConfigurationItem)iterator.next()).getName() != null)
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\dataobjects\ConfigResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */