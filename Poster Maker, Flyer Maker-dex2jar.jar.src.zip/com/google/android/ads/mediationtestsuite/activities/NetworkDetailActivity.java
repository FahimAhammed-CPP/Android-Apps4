package com.google.android.ads.mediationtestsuite.activities;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.adapters.ItemsListRecyclerViewAdapter;
import com.google.android.ads.mediationtestsuite.dataobjects.NetworkConfig;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.viewmodels.DetailItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ListItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.NetworkConfigDetailViewModel;
import java.util.List;
import n0;

public class NetworkDetailActivity extends n0 {
  public static final String NETWORK_CONFIG_EXTRA_KEY = "network_config";
  
  private ItemsListRecyclerViewAdapter<DetailItemViewModel> adapter;
  
  private NetworkConfig networkConfig;
  
  private RecyclerView recyclerView;
  
  private List<ListItemViewModel> recyclerViewItems;
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(R.layout.gmts_activity_network_detail);
    this.recyclerView = (RecyclerView)findViewById(R.id.gmts_recycler);
    this.networkConfig = DataStore.getNetworkConfig(getIntent().getIntExtra("network_config", -1));
    NetworkConfigDetailViewModel networkConfigDetailViewModel = TestSuiteState.getProductTheme().getNetworkConfigDetailViewModel(this.networkConfig);
    setTitle(networkConfigDetailViewModel.getPageTitle((Context)this));
    getSupportActionBar().v(networkConfigDetailViewModel.getPageSubtitle((Context)this));
    this.recyclerViewItems = networkConfigDetailViewModel.getListItemViewModels((Context)this);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)this);
    this.recyclerView.setLayoutManager((RecyclerView.o)linearLayoutManager);
    ItemsListRecyclerViewAdapter<DetailItemViewModel> itemsListRecyclerViewAdapter = new ItemsListRecyclerViewAdapter((Activity)this, this.recyclerViewItems, null);
    this.adapter = itemsListRecyclerViewAdapter;
    this.recyclerView.setAdapter((RecyclerView.g)itemsListRecyclerViewAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\activities\NetworkDetailActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */