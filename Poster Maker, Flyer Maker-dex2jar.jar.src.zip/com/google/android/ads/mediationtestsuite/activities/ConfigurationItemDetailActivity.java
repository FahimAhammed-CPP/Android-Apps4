package com.google.android.ads.mediationtestsuite.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewPropertyAnimator;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.ads.mediationtestsuite.BatchAdRequestCallbacks;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.adapters.ItemsListRecyclerViewAdapter;
import com.google.android.ads.mediationtestsuite.dataobjects.BatchAdRequestManager;
import com.google.android.ads.mediationtestsuite.dataobjects.ConfigurationItem;
import com.google.android.ads.mediationtestsuite.dataobjects.NetworkConfig;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.utils.UIUtils;
import com.google.android.ads.mediationtestsuite.utils.logging.LogEvent;
import com.google.android.ads.mediationtestsuite.utils.logging.Logger;
import com.google.android.ads.mediationtestsuite.utils.logging.RequestEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.DetailItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ListItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.NetworkConfigViewModel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import m0;
import n0;

public class ConfigurationItemDetailActivity extends n0 implements ItemsListRecyclerViewAdapter.OnItemClickListener<NetworkConfigViewModel>, ItemsListRecyclerViewAdapter.OnItemCheckedStateChangedListener<NetworkConfigViewModel>, OnNetworkConfigStateChangedListener {
  public static final String AD_UNIT_EXTRA_KEY = "ad_unit";
  
  public static final String SEARCH_MODE_EXTRA_KEY = "search_mode";
  
  private ItemsListRecyclerViewAdapter<NetworkConfigViewModel> adapter;
  
  private BatchAdRequestManager batchAdRequestManager;
  
  private ConfigurationItemViewModel<? extends ConfigurationItem> configurationItemViewModel;
  
  private Toolbar mainToolbar;
  
  private RecyclerView recyclerView;
  
  private List<ListItemViewModel> recyclerViewItems;
  
  private boolean searchMode;
  
  private Toolbar secondaryToolbar;
  
  private final Set<NetworkConfigViewModel> selectedViewModels = new HashSet<NetworkConfigViewModel>();
  
  private void cancelAdLoading() {
    this.batchAdRequestManager.cancelTesting();
  }
  
  private void configureSearchView(SearchView paramSearchView) {
    paramSearchView.setQueryHint(this.configurationItemViewModel.getDetailPageSearchPlaceholder((Context)this));
    paramSearchView.setIconified(false);
    paramSearchView.setOnQueryTextListener(new SearchView.l() {
          public boolean onQueryTextChange(String param1String) {
            ConfigurationItemDetailActivity.this.adapter.getFilter().filter(param1String);
            return false;
          }
          
          public boolean onQueryTextSubmit(String param1String) {
            ConfigurationItemDetailActivity.this.adapter.getFilter().filter(param1String);
            return false;
          }
        });
  }
  
  private static void crossfadeToolbars(Toolbar paramToolbar1, final Toolbar makeGone) {
    paramToolbar1.setAlpha(0.0F);
    paramToolbar1.setVisibility(0);
    ViewPropertyAnimator viewPropertyAnimator = paramToolbar1.animate().alpha(1.0F);
    long l = 300L;
    viewPropertyAnimator.setDuration(l).setListener(null);
    makeGone.animate().alpha(0.0F).setDuration(l).setListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            makeGone.setVisibility(8);
          }
        });
  }
  
  private void loadSelectedAds() {
    final m0 alertDialog = (new m0.a((Context)this, R.style.gmts_DialogTheme_FlippedButtonColor)).setTitle(R.string.gmts_loading_ads_title).setView(R.layout.gmts_dialog_loading).setCancelable(false).setNegativeButton(R.string.gmts_button_cancel, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            ConfigurationItemDetailActivity.this.cancelAdLoading();
          }
        }).create();
    m0.show();
    HashSet<NetworkConfig> hashSet = new HashSet();
    Iterator<NetworkConfigViewModel> iterator = this.selectedViewModels.iterator();
    while (iterator.hasNext())
      hashSet.add(((NetworkConfigViewModel)iterator.next()).getNetworkConfig()); 
    BatchAdRequestManager batchAdRequestManager = new BatchAdRequestManager((Context)this, hashSet, new BatchAdRequestCallbacks() {
          public void onBatchAdRequestCompleted(BatchAdRequestManager param1BatchAdRequestManager) {
            ConfigurationItemDetailActivity.this.runOnUiThread(new Runnable() {
                  public void run() {
                    alertDialog.dismiss();
                    ConfigurationItemDetailActivity.crossfadeToolbars(ConfigurationItemDetailActivity.this.mainToolbar, ConfigurationItemDetailActivity.this.secondaryToolbar);
                    Iterator<NetworkConfigViewModel> iterator = ConfigurationItemDetailActivity.this.selectedViewModels.iterator();
                    while (iterator.hasNext())
                      ((NetworkConfigViewModel)iterator.next()).setChecked(false); 
                    ConfigurationItemDetailActivity.this.selectedViewModels.clear();
                    ConfigurationItemDetailActivity.this.adapter.notifyDataSetChanged();
                  }
                });
          }
          
          public void onNetworkConfigTested(BatchAdRequestManager param1BatchAdRequestManager, NetworkConfig param1NetworkConfig) {
            Logger.logEvent((LogEvent)new RequestEvent(param1NetworkConfig, RequestEvent.Origin.BATCH_REQUEST), (Context)ConfigurationItemDetailActivity.this);
          }
        });
    this.batchAdRequestManager = batchAdRequestManager;
    batchAdRequestManager.beginTesting();
  }
  
  private void updateNavigationBar() {
    boolean bool;
    if (!this.selectedViewModels.isEmpty())
      updateSecondaryToolbarTitle(); 
    if (this.secondaryToolbar.getVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = this.selectedViewModels.size();
    if (!bool && i > 0) {
      crossfadeToolbars(this.secondaryToolbar, this.mainToolbar);
      return;
    } 
    if (bool && i == 0)
      crossfadeToolbars(this.mainToolbar, this.secondaryToolbar); 
  }
  
  private void updateSecondaryToolbarTitle() {
    this.secondaryToolbar.setTitle(getString(R.string.gmts_num_ads_selected, new Object[] { Integer.valueOf(this.selectedViewModels.size()) }));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(R.layout.gmts_activity_ad_unit_detail);
    this.mainToolbar = (Toolbar)findViewById(R.id.gmts_main_toolbar);
    Toolbar toolbar = (Toolbar)findViewById(R.id.gmts_secondary_toolbar);
    this.secondaryToolbar = toolbar;
    toolbar.setNavigationIcon(R.drawable.gmts_quantum_ic_close_white_24);
    this.secondaryToolbar.setNavigationOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Iterator<NetworkConfigViewModel> iterator = ConfigurationItemDetailActivity.this.selectedViewModels.iterator();
            while (iterator.hasNext())
              ((NetworkConfigViewModel)iterator.next()).setChecked(false); 
            ConfigurationItemDetailActivity.this.selectedViewModels.clear();
            ConfigurationItemDetailActivity.crossfadeToolbars(ConfigurationItemDetailActivity.this.mainToolbar, ConfigurationItemDetailActivity.this.secondaryToolbar);
            ConfigurationItemDetailActivity.this.adapter.notifyDataSetChanged();
          }
        });
    this.secondaryToolbar.inflateMenu(R.menu.gmts_menu_load_ads);
    this.secondaryToolbar.setOnMenuItemClickListener(new Toolbar.f() {
          public boolean onMenuItemClick(MenuItem param1MenuItem) {
            if (param1MenuItem.getItemId() == R.id.gmts_load_ads)
              ConfigurationItemDetailActivity.this.loadSelectedAds(); 
            return true;
          }
        });
    setSupportActionBar(this.mainToolbar);
    this.searchMode = getIntent().getBooleanExtra("search_mode", false);
    this.recyclerView = (RecyclerView)findViewById(R.id.gmts_recycler);
    ConfigurationItem configurationItem = DataStore.getConfigurationItem(getIntent().getStringExtra("ad_unit"));
    ConfigurationItemViewModel<? extends ConfigurationItem> configurationItemViewModel = TestSuiteState.getProductTheme().getConfigurationItemViewModel(configurationItem);
    this.configurationItemViewModel = configurationItemViewModel;
    setTitle(configurationItemViewModel.getDetailPageTitle((Context)this));
    this.mainToolbar.setSubtitle(this.configurationItemViewModel.getDetailPageSubtitle((Context)this));
    this.recyclerViewItems = this.configurationItemViewModel.getConfigurationDetailViewModels((Context)this, this.searchMode);
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)this);
    this.recyclerView.setLayoutManager((RecyclerView.o)linearLayoutManager);
    ItemsListRecyclerViewAdapter<NetworkConfigViewModel> itemsListRecyclerViewAdapter = new ItemsListRecyclerViewAdapter((Activity)this, this.recyclerViewItems, this);
    this.adapter = itemsListRecyclerViewAdapter;
    itemsListRecyclerViewAdapter.setCheckStateChangeListener(this);
    this.recyclerView.setAdapter((RecyclerView.g)this.adapter);
    if (this.searchMode) {
      this.mainToolbar.setContentInsetsAbsolute(0, 0);
      getSupportActionBar().n(R.layout.gmts_search_view);
      getSupportActionBar().q(true);
      getSupportActionBar().r(false);
      getSupportActionBar().s(false);
      configureSearchView((SearchView)getSupportActionBar().d());
    } 
    DataStore.addToNetworkConfigListeners(this);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    MenuInflater menuInflater = getMenuInflater();
    if (!this.searchMode) {
      menuInflater.inflate(R.menu.gmts_menu_search_icon, paramMenu);
      UIUtils.tintAllIcons(paramMenu, getResources().getColor(R.color.gmts_dark_text_primary));
      return true;
    } 
    return false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    DataStore.removeFromNetworkConfigListeners(this);
  }
  
  public void onItemCheckStateChanged(NetworkConfigViewModel paramNetworkConfigViewModel) {
    if (paramNetworkConfigViewModel.isChecked()) {
      this.selectedViewModels.add(paramNetworkConfigViewModel);
    } else {
      this.selectedViewModels.remove(paramNetworkConfigViewModel);
    } 
    updateNavigationBar();
  }
  
  public void onItemClick(NetworkConfigViewModel paramNetworkConfigViewModel) {
    Intent intent = new Intent((Context)this, NetworkDetailActivity.class);
    intent.putExtra("network_config", paramNetworkConfigViewModel.getNetworkConfig().getId());
    startActivityForResult(intent, paramNetworkConfigViewModel.getNetworkConfig().getId());
  }
  
  public void onNetworkConfigStateChanged(NetworkConfig paramNetworkConfig) {
    NetworkConfigViewModel networkConfigViewModel = new NetworkConfigViewModel(paramNetworkConfig);
    if (this.recyclerViewItems.contains(networkConfigViewModel)) {
      this.recyclerViewItems.clear();
      this.recyclerViewItems.addAll(this.configurationItemViewModel.getConfigurationDetailViewModels((Context)this, this.searchMode));
      runOnUiThread(new Runnable() {
            public void run() {
              ConfigurationItemDetailActivity.this.adapter.notifyDataSetChanged();
            }
          });
    } 
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    Intent intent;
    if (paramMenuItem.getItemId() == 16908332) {
      onBackPressed();
      return true;
    } 
    if (paramMenuItem.getItemId() == R.id.gmts_search) {
      intent = new Intent((Context)this, ConfigurationItemDetailActivity.class);
      intent.putExtra("search_mode", true);
      intent.putExtra("ad_unit", this.configurationItemViewModel.getConfigurationItem().getId());
      startActivity(intent);
      return true;
    } 
    return super.onOptionsItemSelected((MenuItem)intent);
  }
  
  public void onResume() {
    super.onResume();
    updateNavigationBar();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\activities\ConfigurationItemDetailActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */