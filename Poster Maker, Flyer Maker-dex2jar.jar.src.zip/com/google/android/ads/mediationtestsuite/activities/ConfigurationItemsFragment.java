package com.google.android.ads.mediationtestsuite.activities;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.adapters.ItemsListRecyclerViewAdapter;
import com.google.android.ads.mediationtestsuite.dataobjects.ConfigurationItem;
import com.google.android.ads.mediationtestsuite.utils.AppInfoUtil;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemsFragmentViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.ListItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.RegisterTestDeviceViewHolder;
import com.google.android.ads.mediationtestsuite.viewmodels.ViewModelFactory;
import java.util.ArrayList;
import java.util.List;
import rh;

public class ConfigurationItemsFragment extends Fragment implements OnConfigurationItemsStateChangedListener {
  private static final String ARG_INDEX = "index";
  
  private static final String ARG_TYPE = "type";
  
  private ItemsListRecyclerViewAdapter<ConfigurationItemViewModel<? extends ConfigurationItem>> adapter;
  
  private int index;
  
  private List<ListItemViewModel> listItemViewModels;
  
  private RecyclerView recyclerView;
  
  @Type
  private int type;
  
  public static ConfigurationItemsFragment newPagerInstance(int paramInt) {
    Bundle bundle = new Bundle();
    bundle.putInt("index", paramInt);
    bundle.putInt("type", 0);
    ConfigurationItemsFragment configurationItemsFragment = new ConfigurationItemsFragment();
    configurationItemsFragment.setArguments(bundle);
    return configurationItemsFragment;
  }
  
  public static ConfigurationItemsFragment newSearchInstance() {
    Bundle bundle = new Bundle();
    bundle.putInt("index", -1);
    bundle.putInt("type", 1);
    ConfigurationItemsFragment configurationItemsFragment = new ConfigurationItemsFragment();
    configurationItemsFragment.setArguments(bundle);
    return configurationItemsFragment;
  }
  
  public ConfigurationItemsFragmentViewModel getViewModel() {
    int i = this.type;
    return (i != 0) ? ((i != 1) ? null : DataStore.getSearchViewModel()) : DataStore.getHomeActivityViewModel().getPageViewModels().get(this.index);
  }
  
  public void handleSearchQuery(CharSequence paramCharSequence) {
    this.adapter.getFilter().filter(paramCharSequence);
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    this.index = getArguments().getInt("index");
    this.type = getArguments().getInt("type");
    this.listItemViewModels = new ArrayList<ListItemViewModel>();
    rh rh = getActivity();
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)rh);
    this.recyclerView.setLayoutManager((RecyclerView.o)linearLayoutManager);
    ItemsListRecyclerViewAdapter<ConfigurationItemViewModel<? extends ConfigurationItem>> itemsListRecyclerViewAdapter = new ItemsListRecyclerViewAdapter((Activity)rh, this.listItemViewModels, null);
    this.adapter = itemsListRecyclerViewAdapter;
    this.recyclerView.setAdapter((RecyclerView.g)itemsListRecyclerViewAdapter);
    DataStore.addToAdUnitListeners(this);
    if (ItemsListRecyclerViewAdapter.OnItemClickListener.class.isInstance(rh))
      this.adapter.setOnItemClickListener((ItemsListRecyclerViewAdapter.OnItemClickListener)rh); 
    this.adapter.setRegisterTestDeviceViewListener(new RegisterTestDeviceViewHolder.RegisterTestDeviceViewListener() {
          public void onDismissClicked() {
            TestSuiteState.testDevicePromptShown();
            ConfigurationItemsFragment.this.refreshAdapter();
          }
          
          public void onRegisterClicked() {
            try {
              String str = AppInfoUtil.getAdvertisingId();
              if (str == null) {
                Toast.makeText(ConfigurationItemsFragment.this.getContext(), "AdvertisingId not available", 0).show();
                return;
              } 
              Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(TestSuiteState.getProductTheme().buildTestDeviceRegistrationUrl(str)));
              ConfigurationItemsFragment.this.startActivity(intent);
            } catch (ActivityNotFoundException activityNotFoundException) {
              activityNotFoundException.getLocalizedMessage();
              activityNotFoundException.printStackTrace();
            } 
            TestSuiteState.testDevicePromptShown();
            ConfigurationItemsFragment.this.refreshAdapter();
          }
        });
    refreshAdapter();
  }
  
  public void onConfigurationItemsStateChanged() {
    refreshAdapter();
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return paramLayoutInflater.inflate(R.layout.gmts_fragment_ad_units, paramViewGroup, false);
  }
  
  public void onDestroy() {
    DataStore.removeFromAdUnitListeners(this);
    super.onDestroy();
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {
    super.onViewCreated(paramView, paramBundle);
    this.recyclerView = (RecyclerView)paramView.findViewById(R.id.gmts_recycler);
  }
  
  public void refreshAdapter() {
    getActivity().runOnUiThread(new Runnable() {
          public void run() {
            ConfigurationItemsFragmentViewModel configurationItemsFragmentViewModel = ConfigurationItemsFragment.this.getViewModel();
            List list = configurationItemsFragmentViewModel.getConfigurationItems();
            if (list != null) {
              ConfigurationItemsFragment.this.listItemViewModels.clear();
              ConfigurationItemsFragment.this.listItemViewModels.addAll(ViewModelFactory.viewModelsForConfigurations(list, configurationItemsFragmentViewModel.getViewType()));
              ConfigurationItemsFragment.this.adapter.refresh();
            } 
          }
        });
  }
  
  public static @interface Type {
    public static final int PAGER = 0;
    
    public static final int SEARCH = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\activities\ConfigurationItemsFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */