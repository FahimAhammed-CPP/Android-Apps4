package com.google.android.ads.mediationtestsuite.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import com.google.android.ads.mediationtestsuite.MediationTestSuite;
import com.google.android.ads.mediationtestsuite.MediationTestSuiteListener;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.adapters.HomeActivityPagerAdapter;
import com.google.android.ads.mediationtestsuite.adapters.ItemsListRecyclerViewAdapter;
import com.google.android.ads.mediationtestsuite.utils.DataStore;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.utils.logging.LogEvent;
import com.google.android.ads.mediationtestsuite.utils.logging.Logger;
import com.google.android.ads.mediationtestsuite.utils.logging.TestSuiteTabViewEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.DetailItemViewModel;
import com.google.android.material.tabs.TabLayout;
import hq;
import java.io.IOException;
import m0;
import n0;

public class HomeActivity extends n0 implements ItemsListRecyclerViewAdapter.OnItemClickListener<ConfigurationItemViewModel<?>> {
  public static final String APP_ID_EXTRA_KEY = "app_id";
  
  private HomeActivityPagerAdapter homeActivityPagerAdapter;
  
  private TabLayout tabLayout;
  
  private Toolbar toolbar;
  
  private ViewPager viewPager;
  
  private void setViewPager() {
    this.viewPager = (ViewPager)findViewById(R.id.gmts_pager);
    HomeActivityPagerAdapter homeActivityPagerAdapter = new HomeActivityPagerAdapter(getSupportFragmentManager(), (Context)this, DataStore.getHomeActivityViewModel().getPageViewModels());
    this.homeActivityPagerAdapter = homeActivityPagerAdapter;
    this.viewPager.setAdapter((hq)homeActivityPagerAdapter);
    this.viewPager.b(new ViewPager.i() {
          public void onPageScrollStateChanged(int param1Int) {}
          
          public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {}
          
          public void onPageSelected(int param1Int) {
            Logger.logEvent((LogEvent)new TestSuiteTabViewEvent(HomeActivity.this.homeActivityPagerAdapter.viewTypeForPosition(param1Int)), (Context)HomeActivity.this);
          }
        });
    this.tabLayout.setupWithViewPager(this.viewPager);
  }
  
  private void showDisclaimer() {
    String str1 = getString(R.string.gmts_disclaimer_link_text);
    str1 = String.format("<a href=\"%1$s\">%2$s</a>", new Object[] { TestSuiteState.getProductTheme().getDisclaimerUrl(), str1 });
    String str2 = String.format(getString(R.string.gmts_disclaimer_confirmation), new Object[] { str1 });
    View view = getLayoutInflater().inflate(R.layout.gmts_dialog_disclaimer, null);
    TextView textView = (TextView)view.findViewById(R.id.gmts_confirmation_text);
    textView.setText((CharSequence)Html.fromHtml(str2));
    textView.setMovementMethod(LinkMovementMethod.getInstance());
    final CheckBox checkBox = (CheckBox)view.findViewById(R.id.gmts_checkbox);
    m0 m0 = (new m0.a((Context)this, R.style.gmts_DialogTheme)).setTitle(R.string.gmts_disclaimer_title).setView(view).setCancelable(false).setPositiveButton(R.string.gmts_button_agree, new DialogInterface.OnClickListener(this) {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            DataStore.setDidAcceptDisclaimer(true);
          }
        }).setNegativeButton(R.string.gmts_button_cancel, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            HomeActivity.this.finish();
          }
        }).create();
    m0.setOnShowListener(new DialogInterface.OnShowListener(this) {
          public void onShow(DialogInterface param1DialogInterface) {
            final m0 alert = (m0)param1DialogInterface;
            m0.a(-1).setEnabled(false);
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this) {
                  public void onCheckedChanged(CompoundButton param2CompoundButton, boolean param2Boolean) {
                    alert.a(-1).setEnabled(param2Boolean);
                  }
                });
          }
        });
    m0.show();
  }
  
  public void finish() {
    MediationTestSuiteListener mediationTestSuiteListener = MediationTestSuite.getListener();
    if (mediationTestSuiteListener != null)
      mediationTestSuiteListener.onMediationTestSuiteDismissed(); 
    TestSuiteState.sharedInstance().reset();
    super.finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    DataStore.initialize((Context)this, getIntent().getStringExtra("app_id"));
    getTheme().applyStyle(TestSuiteState.getProductTheme().getProductStyleId(), true);
    setContentView(R.layout.gmts_activity_home);
    this.toolbar = (Toolbar)findViewById(R.id.gmts_main_toolbar);
    this.tabLayout = (TabLayout)findViewById(R.id.gmts_tab);
    setSupportActionBar(this.toolbar);
    setTitle("Mediation Test Suite");
    this.toolbar.setSubtitle(TestSuiteState.getProductTheme().getHomePageSubtitle());
    try {
      DataStore.downloadConfigurationItems();
    } catch (IOException iOException) {
      iOException.getLocalizedMessage();
      iOException.printStackTrace();
    } 
    setViewPager();
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(R.menu.gmts_menu_search_icon, paramMenu);
    return true;
  }
  
  public void onItemClick(ConfigurationItemViewModel<?> paramConfigurationItemViewModel) {
    Intent intent = new Intent((Context)this, ConfigurationItemDetailActivity.class);
    intent.putExtra("ad_unit", paramConfigurationItemViewModel.getConfigurationItem().getId());
    startActivity(intent);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getItemId() == R.id.gmts_search) {
      Logger.logEvent((LogEvent)new TestSuiteTabViewEvent(TestSuiteTabViewEvent.ViewType.SEARCH), (Context)this);
      startActivity(new Intent((Context)this, ConfigurationItemsSearchActivity.class));
      return true;
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  public void onResume() {
    super.onResume();
    if (!DataStore.getDidAcceptDisclaimer())
      showDisclaimer(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\activities\HomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */