package com.google.android.ads.mediationtestsuite.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import com.google.android.ads.mediationtestsuite.R;
import com.google.android.ads.mediationtestsuite.adapters.ItemsListRecyclerViewAdapter;
import com.google.android.ads.mediationtestsuite.utils.TestSuiteState;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemViewModel;
import com.google.android.ads.mediationtestsuite.viewmodels.DetailItemViewModel;
import fh;
import n0;

public class ConfigurationItemsSearchActivity extends n0 implements ItemsListRecyclerViewAdapter.OnItemClickListener<ConfigurationItemViewModel<?>> {
  private static final String FRAGMENT_TAG = "ConfigItemsSearchFragment";
  
  private ConfigurationItemsFragment configurationItemsFragment;
  
  private void configureSearchView(SearchView paramSearchView) {
    paramSearchView.setQueryHint(getResources().getString(TestSuiteState.getProductTheme().getAdUnitPageSearchPlaceholderId()));
    paramSearchView.setIconified(false);
    paramSearchView.setOnQueryTextListener(new SearchView.l() {
          public boolean onQueryTextChange(String param1String) {
            ConfigurationItemsSearchActivity.this.configurationItemsFragment.handleSearchQuery(param1String);
            return false;
          }
          
          public boolean onQueryTextSubmit(String param1String) {
            ConfigurationItemsSearchActivity.this.configurationItemsFragment.handleSearchQuery(param1String);
            return false;
          }
        });
  }
  
  private void handleIntent(Intent paramIntent) {
    if ("android.intent.action.SEARCH".equals(paramIntent.getAction())) {
      String str = paramIntent.getStringExtra("query");
      this.configurationItemsFragment.handleSearchQuery(str);
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(R.layout.gmts_activity_ad_units_search);
    ConfigurationItemsFragment configurationItemsFragment = (ConfigurationItemsFragment)getSupportFragmentManager().I("ConfigItemsSearchFragment");
    this.configurationItemsFragment = configurationItemsFragment;
    if (configurationItemsFragment == null) {
      this.configurationItemsFragment = ConfigurationItemsFragment.newSearchInstance();
      fh fh = new fh(getSupportFragmentManager());
      fh.g(R.id.gmts_content_view, this.configurationItemsFragment, "ConfigItemsSearchFragment", 1);
      fh.d();
    } 
    handleIntent(getIntent());
    Toolbar toolbar = (Toolbar)findViewById(R.id.gmts_toolbar);
    toolbar.setNavigationIcon(null);
    setSupportActionBar(toolbar);
    getSupportActionBar().n(R.layout.gmts_search_view);
    getSupportActionBar().q(true);
    getSupportActionBar().r(false);
    getSupportActionBar().s(false);
    configureSearchView((SearchView)getSupportActionBar().d());
  }
  
  public void onItemClick(ConfigurationItemViewModel<?> paramConfigurationItemViewModel) {
    Intent intent = new Intent((Context)this, ConfigurationItemDetailActivity.class);
    intent.putExtra("ad_unit", paramConfigurationItemViewModel.getConfigurationItem().getId());
    startActivity(intent);
  }
  
  public void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    handleIntent(paramIntent);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getItemId() == 16908332) {
      onBackPressed();
      return true;
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\activities\ConfigurationItemsSearchActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */