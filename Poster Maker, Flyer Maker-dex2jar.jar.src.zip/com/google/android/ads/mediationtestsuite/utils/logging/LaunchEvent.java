package com.google.android.ads.mediationtestsuite.utils.logging;

import java.util.HashMap;
import java.util.Map;

public class LaunchEvent implements LogEvent {
  public String getEventType() {
    return "launch";
  }
  
  public Map<String, String> getParameters() {
    return new HashMap<String, String>();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuit\\utils\logging\LaunchEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */