package com.google.android.ads.mediationtestsuite.utils.logging;

import java.util.Map;

public interface LogEvent {
  String getEventType();
  
  Map<String, String> getParameters();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuit\\utils\logging\LogEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */