package com.google.android.ads.mediationtestsuite.adapters;

import android.content.Context;
import androidx.fragment.app.Fragment;
import com.google.android.ads.mediationtestsuite.activities.ConfigurationItemsFragment;
import com.google.android.ads.mediationtestsuite.utils.logging.TestSuiteTabViewEvent;
import com.google.android.ads.mediationtestsuite.viewmodels.ConfigurationItemsFragmentViewModel;
import di;
import java.util.ArrayList;
import java.util.List;
import li;

public class HomeActivityPagerAdapter extends li {
  private final Context context;
  
  private final List<ConfigurationItemsFragment> fragments = new ArrayList<ConfigurationItemsFragment>();
  
  private List<ConfigurationItemsFragmentViewModel> pageViewModels;
  
  public HomeActivityPagerAdapter(di paramdi, Context paramContext, List<ConfigurationItemsFragmentViewModel> paramList) {
    super(paramdi, 1);
    this.context = paramContext;
    this.pageViewModels = paramList;
    int i;
    for (i = 0; i < paramList.size(); i++)
      this.fragments.add(ConfigurationItemsFragment.newPagerInstance(i)); 
  }
  
  public int getCount() {
    return this.fragments.size();
  }
  
  public Fragment getItem(int paramInt) {
    return (Fragment)this.fragments.get(paramInt);
  }
  
  public CharSequence getPageTitle(int paramInt) {
    return ((ConfigurationItemsFragmentViewModel)this.pageViewModels.get(paramInt)).getTitle(this.context);
  }
  
  public TestSuiteTabViewEvent.ViewType viewTypeForPosition(int paramInt) {
    return ((ConfigurationItemsFragmentViewModel)this.pageViewModels.get(paramInt)).getViewType();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\android\ads\mediationtestsuite\adapters\HomeActivityPagerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */