package com.google.ads.mediation;

import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.common.util.VisibleForTesting;

@VisibleForTesting
public final class zzd extends FullScreenContentCallback {
  @VisibleForTesting
  public final AbstractAdViewAdapter zza;
  
  @VisibleForTesting
  public final MediationInterstitialListener zzb;
  
  public zzd(AbstractAdViewAdapter paramAbstractAdViewAdapter, MediationInterstitialListener paramMediationInterstitialListener) {
    this.zza = paramAbstractAdViewAdapter;
    this.zzb = paramMediationInterstitialListener;
  }
  
  public final void onAdDismissedFullScreenContent() {
    this.zzb.onAdClosed(this.zza);
  }
  
  public final void onAdShowedFullScreenContent() {
    this.zzb.onAdOpened(this.zza);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */