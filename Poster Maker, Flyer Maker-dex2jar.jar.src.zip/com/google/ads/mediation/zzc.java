package com.google.ads.mediation;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.common.util.VisibleForTesting;

@VisibleForTesting
public final class zzc extends InterstitialAdLoadCallback {
  @VisibleForTesting
  public final AbstractAdViewAdapter zza;
  
  @VisibleForTesting
  public final MediationInterstitialListener zzb;
  
  public zzc(AbstractAdViewAdapter paramAbstractAdViewAdapter, MediationInterstitialListener paramMediationInterstitialListener) {
    this.zza = paramAbstractAdViewAdapter;
    this.zzb = paramMediationInterstitialListener;
  }
  
  public final void onAdFailedToLoad(LoadAdError paramLoadAdError) {
    this.zzb.onAdFailedToLoad(this.zza, (AdError)paramLoadAdError);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */