package com.google.ads.mediation;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.common.util.VisibleForTesting;

@VisibleForTesting
public final class zze extends AdListener implements UnifiedNativeAd.OnUnifiedNativeAdLoadedListener, NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener, NativeCustomTemplateAd.OnCustomClickListener {
  @VisibleForTesting
  public final AbstractAdViewAdapter zza;
  
  @VisibleForTesting
  public final MediationNativeListener zzb;
  
  public zze(AbstractAdViewAdapter paramAbstractAdViewAdapter, MediationNativeListener paramMediationNativeListener) {
    this.zza = paramAbstractAdViewAdapter;
    this.zzb = paramMediationNativeListener;
  }
  
  public final void onAdClicked() {
    this.zzb.onAdClicked(this.zza);
  }
  
  public final void onAdClosed() {
    this.zzb.onAdClosed(this.zza);
  }
  
  public final void onAdFailedToLoad(LoadAdError paramLoadAdError) {
    this.zzb.onAdFailedToLoad(this.zza, (AdError)paramLoadAdError);
  }
  
  public final void onAdImpression() {
    this.zzb.onAdImpression(this.zza);
  }
  
  public final void onAdLoaded() {}
  
  public final void onAdOpened() {
    this.zzb.onAdOpened(this.zza);
  }
  
  public final void onCustomClick(NativeCustomTemplateAd paramNativeCustomTemplateAd, String paramString) {
    this.zzb.zze(this.zza, paramNativeCustomTemplateAd, paramString);
  }
  
  public final void onCustomTemplateAdLoaded(NativeCustomTemplateAd paramNativeCustomTemplateAd) {
    this.zzb.zzc(this.zza, paramNativeCustomTemplateAd);
  }
  
  public final void onUnifiedNativeAdLoaded(UnifiedNativeAd paramUnifiedNativeAd) {
    this.zzb.onAdLoaded(this.zza, new zza(paramUnifiedNativeAd));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */