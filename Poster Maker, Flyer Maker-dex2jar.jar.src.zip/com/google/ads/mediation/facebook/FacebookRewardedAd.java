package com.google.ads.mediation.facebook;

import android.content.Context;
import android.text.TextUtils;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdExperienceType;
import com.facebook.ads.ExtraHints;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.RewardedVideoAdExtendedListener;
import com.facebook.ads.RewardedVideoAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import java.util.concurrent.atomic.AtomicBoolean;

public class FacebookRewardedAd implements MediationRewardedAd, RewardedVideoAdExtendedListener {
  private final MediationRewardedAdConfiguration adConfiguration;
  
  private final AtomicBoolean didRewardedAdClose = new AtomicBoolean();
  
  private final MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback;
  
  private RewardedVideoAd rewardedAd;
  
  private MediationRewardedAdCallback rewardedAdCallback;
  
  private final AtomicBoolean showAdCalled = new AtomicBoolean();
  
  public FacebookRewardedAd(MediationRewardedAdConfiguration paramMediationRewardedAdConfiguration, MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> paramMediationAdLoadCallback) {
    this.adConfiguration = paramMediationRewardedAdConfiguration;
    this.mediationAdLoadCallback = paramMediationAdLoadCallback;
  }
  
  public AdExperienceType getAdExperienceType() {
    return AdExperienceType.AD_EXPERIENCE_TYPE_REWARDED;
  }
  
  public void onAdClicked(Ad paramAd) {
    MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
    if (mediationRewardedAdCallback != null)
      mediationRewardedAdCallback.reportAdClicked(); 
  }
  
  public void onAdLoaded(Ad paramAd) {
    MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback = this.mediationAdLoadCallback;
    if (mediationAdLoadCallback != null)
      this.rewardedAdCallback = (MediationRewardedAdCallback)mediationAdLoadCallback.onSuccess(this); 
  }
  
  public void onError(Ad paramAd, AdError paramAdError) {
    AdError adError = FacebookMediationAdapter.getAdError(paramAdError);
    if (this.showAdCalled.get()) {
      adError.getMessage();
      MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
      if (mediationRewardedAdCallback != null)
        mediationRewardedAdCallback.onAdFailedToShow(adError); 
    } else {
      adError.getMessage();
      MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback = this.mediationAdLoadCallback;
      if (mediationAdLoadCallback != null)
        mediationAdLoadCallback.onFailure(adError); 
    } 
    this.rewardedAd.destroy();
  }
  
  public void onLoggingImpression(Ad paramAd) {
    MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
    if (mediationRewardedAdCallback != null)
      mediationRewardedAdCallback.reportAdImpression(); 
  }
  
  public void onRewardedVideoActivityDestroyed() {
    if (!this.didRewardedAdClose.getAndSet(true)) {
      MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
      if (mediationRewardedAdCallback != null)
        mediationRewardedAdCallback.onAdClosed(); 
    } 
    RewardedVideoAd rewardedVideoAd = this.rewardedAd;
    if (rewardedVideoAd != null)
      rewardedVideoAd.destroy(); 
  }
  
  public void onRewardedVideoClosed() {
    if (!this.didRewardedAdClose.getAndSet(true)) {
      MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
      if (mediationRewardedAdCallback != null)
        mediationRewardedAdCallback.onAdClosed(); 
    } 
    RewardedVideoAd rewardedVideoAd = this.rewardedAd;
    if (rewardedVideoAd != null)
      rewardedVideoAd.destroy(); 
  }
  
  public void onRewardedVideoCompleted() {
    this.rewardedAdCallback.onVideoComplete();
    this.rewardedAdCallback.onUserEarnedReward(new FacebookReward());
  }
  
  public void render() {
    AdError adError;
    Context context = this.adConfiguration.getContext();
    String str = FacebookMediationAdapter.getPlacementID(this.adConfiguration.getServerParameters());
    if (TextUtils.isEmpty(str)) {
      adError = new AdError(101, "Failed to request ad. PlacementID is null or empty.", "com.google.ads.mediation.facebook");
      adError.getMessage();
      this.mediationAdLoadCallback.onFailure(adError);
      return;
    } 
    FacebookMediationAdapter.setMixedAudience((MediationAdConfiguration)this.adConfiguration);
    this.rewardedAd = new RewardedVideoAd((Context)adError, str);
    if (!TextUtils.isEmpty(this.adConfiguration.getWatermark()))
      this.rewardedAd.setExtraHints((new ExtraHints.Builder()).mediationData(this.adConfiguration.getWatermark()).build()); 
    RewardedVideoAd rewardedVideoAd = this.rewardedAd;
    rewardedVideoAd.loadAd(rewardedVideoAd.buildLoadAdConfig().withAdListener((RewardedVideoAdListener)this).withBid(this.adConfiguration.getBidResponse()).withAdExperience(getAdExperienceType()).build());
  }
  
  public void showAd(Context paramContext) {
    this.showAdCalled.set(true);
    if (!this.rewardedAd.show()) {
      AdError adError = new AdError(110, "Failed to present rewarded ad.", "com.google.ads.mediation.facebook");
      String str = FacebookMediationAdapter.TAG;
      adError.getMessage();
      MediationRewardedAdCallback mediationRewardedAdCallback1 = this.rewardedAdCallback;
      if (mediationRewardedAdCallback1 != null)
        mediationRewardedAdCallback1.onAdFailedToShow(adError); 
      this.rewardedAd.destroy();
      return;
    } 
    MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
    if (mediationRewardedAdCallback != null) {
      mediationRewardedAdCallback.onVideoStart();
      this.rewardedAdCallback.onAdOpened();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\FacebookRewardedAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */