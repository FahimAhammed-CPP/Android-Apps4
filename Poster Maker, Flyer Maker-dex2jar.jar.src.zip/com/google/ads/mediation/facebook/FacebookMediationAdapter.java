package com.google.ads.mediation.facebook;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.BidderTokenProvider;
import com.google.ads.mediation.facebook.rtb.FacebookRtbBannerAd;
import com.google.ads.mediation.facebook.rtb.FacebookRtbInterstitialAd;
import com.google.ads.mediation.facebook.rtb.FacebookRtbNativeAd;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.VersionInfo;
import com.google.android.gms.ads.mediation.InitializationCompleteCallback;
import com.google.android.gms.ads.mediation.MediationAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationBannerAdCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAdCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;
import com.google.android.gms.ads.mediation.rtb.RtbSignalData;
import com.google.android.gms.ads.mediation.rtb.SignalCallbacks;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FacebookMediationAdapter extends RtbAdapter {
  public static final int ERROR_ADVIEW_CONSTRUCTOR_EXCEPTION = 111;
  
  public static final int ERROR_BANNER_SIZE_MISMATCH = 102;
  
  public static final int ERROR_CREATE_NATIVE_AD_FROM_BID_PAYLOAD = 109;
  
  public static final String ERROR_DOMAIN = "com.google.ads.mediation.facebook";
  
  public static final int ERROR_FACEBOOK_INITIALIZATION = 104;
  
  public static final int ERROR_FAILED_TO_PRESENT_AD = 110;
  
  public static final int ERROR_INVALID_SERVER_PARAMETERS = 101;
  
  public static final int ERROR_MAPPING_NATIVE_ASSETS = 108;
  
  public static final int ERROR_NULL_CONTEXT = 107;
  
  public static final int ERROR_REQUIRES_ACTIVITY_CONTEXT = 103;
  
  public static final int ERROR_REQUIRES_UNIFIED_NATIVE_ADS = 105;
  
  public static final int ERROR_WRONG_NATIVE_TYPE = 106;
  
  public static final String FACEBOOK_SDK_ERROR_DOMAIN = "com.facebook.ads";
  
  public static final String KEY_ID = "id";
  
  public static final String KEY_SOCIAL_CONTEXT_ASSET = "social_context";
  
  public static final String PLACEMENT_PARAMETER = "pubid";
  
  public static final String RTB_PLACEMENT_PARAMETER = "placement_id";
  
  public static final String TAG = "FacebookMediationAdapter";
  
  private FacebookRtbBannerAd banner;
  
  private FacebookRtbInterstitialAd interstitial;
  
  private FacebookRtbNativeAd nativeAd;
  
  private FacebookRewardedAd rewardedAd;
  
  private FacebookRewardedInterstitialAd rewardedInterstitialAd;
  
  public static AdError getAdError(AdError paramAdError) {
    return new AdError(paramAdError.getErrorCode(), paramAdError.getErrorMessage(), "com.facebook.ads");
  }
  
  public static String getPlacementID(Bundle paramBundle) {
    String str2 = paramBundle.getString("placement_id");
    String str1 = str2;
    if (str2 == null)
      str1 = paramBundle.getString("pubid"); 
    return str1;
  }
  
  public static void setMixedAudience(MediationAdConfiguration paramMediationAdConfiguration) {
    if (paramMediationAdConfiguration.taggedForChildDirectedTreatment() == 1) {
      AdSettings.setMixedAudience(true);
      return;
    } 
    if (paramMediationAdConfiguration.taggedForChildDirectedTreatment() == 0)
      AdSettings.setMixedAudience(false); 
  }
  
  public void collectSignals(RtbSignalData paramRtbSignalData, SignalCallbacks paramSignalCallbacks) {
    paramSignalCallbacks.onSuccess(BidderTokenProvider.getBidderToken(paramRtbSignalData.getContext()));
  }
  
  public VersionInfo getSDKVersionInfo() {
    String[] arrayOfString = "6.14.0".split("\\.");
    if (arrayOfString.length >= 3)
      return new VersionInfo(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2])); 
    String.format("Unexpected SDK version format: %s.Returning 0.0.0 for SDK version.", new Object[] { "6.14.0" });
    return new VersionInfo(0, 0, 0);
  }
  
  public VersionInfo getVersionInfo() {
    String[] arrayOfString = "6.14.0.0".split("\\.");
    if (arrayOfString.length >= 4) {
      int i = Integer.parseInt(arrayOfString[0]);
      int j = Integer.parseInt(arrayOfString[1]);
      int k = Integer.parseInt(arrayOfString[2]);
      return new VersionInfo(i, j, Integer.parseInt(arrayOfString[3]) + k * 100);
    } 
    String.format("Unexpected adapter version format: %s.Returning 0.0.0 for adapter version.", new Object[] { "6.14.0.0" });
    return new VersionInfo(0, 0, 0);
  }
  
  public void initialize(Context paramContext, final InitializationCompleteCallback initializationCompleteCallback, List<MediationConfiguration> paramList) {
    ArrayList<String> arrayList = new ArrayList();
    Iterator<MediationConfiguration> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      String str = getPlacementID(((MediationConfiguration)iterator.next()).getServerParameters());
      if (!TextUtils.isEmpty(str))
        arrayList.add(str); 
    } 
    if (arrayList.isEmpty()) {
      initializationCompleteCallback.onInitializationFailed("Initialization failed. No placement IDs found.");
      return;
    } 
    FacebookInitializer.getInstance().initialize(paramContext, arrayList, new FacebookInitializer.Listener() {
          public void onInitializeError(AdError param1AdError) {
            initializationCompleteCallback.onInitializationFailed(param1AdError.getMessage());
          }
          
          public void onInitializeSuccess() {
            initializationCompleteCallback.onInitializationSucceeded();
          }
        });
  }
  
  public void loadRtbBannerAd(MediationBannerAdConfiguration paramMediationBannerAdConfiguration, MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> paramMediationAdLoadCallback) {
    FacebookRtbBannerAd facebookRtbBannerAd = new FacebookRtbBannerAd(paramMediationBannerAdConfiguration, paramMediationAdLoadCallback);
    this.banner = facebookRtbBannerAd;
    facebookRtbBannerAd.render();
  }
  
  public void loadRtbInterstitialAd(MediationInterstitialAdConfiguration paramMediationInterstitialAdConfiguration, MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> paramMediationAdLoadCallback) {
    FacebookRtbInterstitialAd facebookRtbInterstitialAd = new FacebookRtbInterstitialAd(paramMediationInterstitialAdConfiguration, paramMediationAdLoadCallback);
    this.interstitial = facebookRtbInterstitialAd;
    facebookRtbInterstitialAd.render();
  }
  
  public void loadRtbNativeAd(MediationNativeAdConfiguration paramMediationNativeAdConfiguration, MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> paramMediationAdLoadCallback) {
    FacebookRtbNativeAd facebookRtbNativeAd = new FacebookRtbNativeAd(paramMediationNativeAdConfiguration, paramMediationAdLoadCallback);
    this.nativeAd = facebookRtbNativeAd;
    facebookRtbNativeAd.render();
  }
  
  public void loadRtbRewardedAd(MediationRewardedAdConfiguration paramMediationRewardedAdConfiguration, MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> paramMediationAdLoadCallback) {
    FacebookRewardedAd facebookRewardedAd = new FacebookRewardedAd(paramMediationRewardedAdConfiguration, paramMediationAdLoadCallback);
    this.rewardedAd = facebookRewardedAd;
    facebookRewardedAd.render();
  }
  
  public void loadRtbRewardedInterstitialAd(MediationRewardedAdConfiguration paramMediationRewardedAdConfiguration, MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> paramMediationAdLoadCallback) {
    FacebookRewardedInterstitialAd facebookRewardedInterstitialAd = new FacebookRewardedInterstitialAd(paramMediationRewardedAdConfiguration, paramMediationAdLoadCallback);
    this.rewardedInterstitialAd = facebookRewardedInterstitialAd;
    facebookRewardedInterstitialAd.render();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface AdapterError {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\FacebookMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */