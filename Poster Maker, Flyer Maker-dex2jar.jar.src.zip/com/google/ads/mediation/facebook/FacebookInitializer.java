package com.google.ads.mediation.facebook;

import android.content.Context;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdError;
import java.util.ArrayList;

public class FacebookInitializer implements AudienceNetworkAds.InitListener {
  private static FacebookInitializer instance;
  
  private boolean isInitialized = false;
  
  private boolean isInitializing = false;
  
  private final ArrayList<Listener> listeners = new ArrayList<Listener>();
  
  public static FacebookInitializer getInstance() {
    if (instance == null)
      instance = new FacebookInitializer(); 
    return instance;
  }
  
  public void initialize(Context paramContext, String paramString, Listener paramListener) {
    ArrayList<String> arrayList = new ArrayList();
    arrayList.add(paramString);
    getInstance().initialize(paramContext, arrayList, paramListener);
  }
  
  public void initialize(Context paramContext, ArrayList<String> paramArrayList, Listener paramListener) {
    if (this.isInitializing) {
      this.listeners.add(paramListener);
      return;
    } 
    if (this.isInitialized) {
      paramListener.onInitializeSuccess();
      return;
    } 
    this.isInitializing = true;
    (getInstance()).listeners.add(paramListener);
    AudienceNetworkAds.buildInitSettings(paramContext).withMediationService("GOOGLE:6.14.0.0").withPlacementIds(paramArrayList).withInitListener(this).initialize();
  }
  
  public void onInitialized(AudienceNetworkAds.InitResult paramInitResult) {
    this.isInitializing = false;
    this.isInitialized = paramInitResult.isSuccess();
    for (Listener listener : this.listeners) {
      if (paramInitResult.isSuccess()) {
        listener.onInitializeSuccess();
        continue;
      } 
      listener.onInitializeError(new AdError(104, paramInitResult.getMessage(), "com.google.ads.mediation.facebook"));
    } 
    this.listeners.clear();
  }
  
  public static interface Listener {
    void onInitializeError(AdError param1AdError);
    
    void onInitializeSuccess();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\FacebookInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */