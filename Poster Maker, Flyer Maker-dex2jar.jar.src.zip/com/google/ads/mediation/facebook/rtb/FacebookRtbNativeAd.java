package com.google.ads.mediation.facebook.rtb;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.ExtraHints;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.google.ads.mediation.facebook.FacebookMediationAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.formats.NativeAd;
import com.google.android.gms.ads.mediation.MediationAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import s30;

public class FacebookRtbNativeAd extends UnifiedNativeAdMapper {
  private final MediationNativeAdConfiguration adConfiguration;
  
  private final MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> callback;
  
  private MediaView mediaView;
  
  private NativeAdBase nativeAdBase;
  
  private MediationNativeAdCallback nativeAdCallback;
  
  public FacebookRtbNativeAd(MediationNativeAdConfiguration paramMediationNativeAdConfiguration, MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> paramMediationAdLoadCallback) {
    this.callback = paramMediationAdLoadCallback;
    this.adConfiguration = paramMediationNativeAdConfiguration;
  }
  
  private boolean containsRequiredFieldsForUnifiedNativeAd(NativeAdBase paramNativeAdBase) {
    boolean bool;
    if (paramNativeAdBase.getAdHeadline() != null && paramNativeAdBase.getAdBodyText() != null && paramNativeAdBase.getAdIcon() != null && paramNativeAdBase.getAdCallToAction() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (paramNativeAdBase instanceof NativeBannerAd) ? bool : ((bool && paramNativeAdBase.getAdCoverImage() != null && this.mediaView != null));
  }
  
  public void mapNativeAd(Context paramContext, NativeAdMapperListener paramNativeAdMapperListener) {
    AdError adError;
    if (!containsRequiredFieldsForUnifiedNativeAd(this.nativeAdBase)) {
      adError = new AdError(108, "Ad from Meta Audience Network doesn't have all required assets.", "com.google.ads.mediation.facebook");
      String str = FacebookMediationAdapter.TAG;
      adError.getMessage();
      paramNativeAdMapperListener.onMappingFailed(adError);
      return;
    } 
    setHeadline(this.nativeAdBase.getAdHeadline());
    if (this.nativeAdBase.getAdCoverImage() != null) {
      ArrayList<FacebookAdapterNativeAdImage> arrayList = new ArrayList();
      arrayList.add(new FacebookAdapterNativeAdImage(Uri.parse(this.nativeAdBase.getAdCoverImage().getUrl())));
      setImages(arrayList);
    } 
    setBody(this.nativeAdBase.getAdBodyText());
    if (this.nativeAdBase.getPreloadedIconViewDrawable() == null) {
      if (this.nativeAdBase.getAdIcon() == null) {
        setIcon(new FacebookAdapterNativeAdImage());
      } else {
        setIcon(new FacebookAdapterNativeAdImage(Uri.parse(this.nativeAdBase.getAdIcon().getUrl())));
      } 
    } else {
      setIcon(new FacebookAdapterNativeAdImage(this.nativeAdBase.getPreloadedIconViewDrawable()));
    } 
    setCallToAction(this.nativeAdBase.getAdCallToAction());
    setAdvertiser(this.nativeAdBase.getAdvertiserName());
    this.mediaView.setListener(new MediaViewListener() {
          public void onComplete(MediaView param1MediaView) {
            if (FacebookRtbNativeAd.this.nativeAdCallback != null)
              FacebookRtbNativeAd.this.nativeAdCallback.onVideoComplete(); 
          }
          
          public void onEnterFullscreen(MediaView param1MediaView) {}
          
          public void onExitFullscreen(MediaView param1MediaView) {}
          
          public void onFullscreenBackground(MediaView param1MediaView) {}
          
          public void onFullscreenForeground(MediaView param1MediaView) {}
          
          public void onPause(MediaView param1MediaView) {}
          
          public void onPlay(MediaView param1MediaView) {}
          
          public void onVolumeChange(MediaView param1MediaView, float param1Float) {}
        });
    setHasVideoContent(true);
    setMediaView((View)this.mediaView);
    Bundle bundle = new Bundle();
    bundle.putCharSequence("id", this.nativeAdBase.getId());
    bundle.putCharSequence("social_context", this.nativeAdBase.getAdSocialContext());
    setExtras(bundle);
    setAdChoicesContent((View)new AdOptionsView((Context)adError, this.nativeAdBase, null));
    paramNativeAdMapperListener.onMappingSuccess();
  }
  
  public void render() {
    AdError adError;
    String str = FacebookMediationAdapter.getPlacementID(this.adConfiguration.getServerParameters());
    if (TextUtils.isEmpty(str)) {
      adError = new AdError(101, "Failed to request ad. PlacementID is null or empty.", "com.google.ads.mediation.facebook");
      adError.getMessage();
      this.callback.onFailure(adError);
      return;
    } 
    FacebookMediationAdapter.setMixedAudience((MediationAdConfiguration)this.adConfiguration);
    this.mediaView = new MediaView(this.adConfiguration.getContext());
    try {
      this.nativeAdBase = NativeAdBase.fromBidPayload(this.adConfiguration.getContext(), (String)adError, this.adConfiguration.getBidResponse());
      if (!TextUtils.isEmpty(this.adConfiguration.getWatermark()))
        this.nativeAdBase.setExtraHints((new ExtraHints.Builder()).mediationData(this.adConfiguration.getWatermark()).build()); 
      NativeAdBase nativeAdBase = this.nativeAdBase;
      nativeAdBase.loadAd(nativeAdBase.buildLoadAdConfig().withAdListener(new NativeListener(this.adConfiguration.getContext(), this.nativeAdBase)).withBid(this.adConfiguration.getBidResponse()).withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL).withPreloadedIconView(-1, -1).build());
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = s30.x0("Failed to create native ad from bid payload: ");
      stringBuilder.append(exception.getMessage());
      AdError adError1 = new AdError(109, stringBuilder.toString(), "com.google.ads.mediation.facebook");
      adError1.getMessage();
      this.callback.onFailure(adError1);
      return;
    } 
  }
  
  public void trackViews(View paramView, Map<String, View> paramMap1, Map<String, View> paramMap2) {
    setOverrideClickHandling(true);
    ArrayList arrayList = new ArrayList(paramMap1.values());
    View view = paramMap1.get("3003");
    NativeAdBase nativeAdBase = this.nativeAdBase;
    if (nativeAdBase instanceof NativeBannerAd) {
      if (view == null) {
        str = FacebookMediationAdapter.TAG;
        return;
      } 
      if (!(view instanceof ImageView)) {
        String.format("Native ad icon asset is rendered with an incompatible class type. Meta Audience Network impression recording might be impacted for this ad. Expected: ImageView, actual: %s.", new Object[] { view.getClass() });
        str = FacebookMediationAdapter.TAG;
        return;
      } 
      ((NativeBannerAd)nativeAdBase).registerViewForInteraction((View)str, (ImageView)view, arrayList);
      return;
    } 
    if (nativeAdBase instanceof NativeAd) {
      NativeAd nativeAd = (NativeAd)nativeAdBase;
      if (view instanceof ImageView) {
        nativeAd.registerViewForInteraction((View)str, this.mediaView, (ImageView)view, arrayList);
        return;
      } 
      String str1 = FacebookMediationAdapter.TAG;
      nativeAd.registerViewForInteraction((View)str, this.mediaView, arrayList);
      return;
    } 
    String str = FacebookMediationAdapter.TAG;
  }
  
  public void untrackView(View paramView) {
    NativeAdBase nativeAdBase = this.nativeAdBase;
    if (nativeAdBase != null)
      nativeAdBase.unregisterView(); 
    super.untrackView(paramView);
  }
  
  public class FacebookAdapterNativeAdImage extends NativeAd.Image {
    private Drawable drawable;
    
    private Uri uri;
    
    public FacebookAdapterNativeAdImage() {}
    
    public FacebookAdapterNativeAdImage(Drawable param1Drawable) {
      this.drawable = param1Drawable;
    }
    
    public FacebookAdapterNativeAdImage(Uri param1Uri) {
      this.uri = param1Uri;
    }
    
    public Drawable getDrawable() {
      return this.drawable;
    }
    
    public double getScale() {
      return 1.0D;
    }
    
    public Uri getUri() {
      return this.uri;
    }
  }
  
  public static interface NativeAdMapperListener {
    void onMappingFailed(AdError param1AdError);
    
    void onMappingSuccess();
  }
  
  public class NativeListener implements AdListener, NativeAdListener {
    private final WeakReference<Context> context;
    
    private final NativeAdBase nativeAd;
    
    public NativeListener(Context param1Context, NativeAdBase param1NativeAdBase) {
      this.nativeAd = param1NativeAdBase;
      this.context = new WeakReference<Context>(param1Context);
    }
    
    public void onAdClicked(Ad param1Ad) {
      FacebookRtbNativeAd.this.nativeAdCallback.reportAdClicked();
      FacebookRtbNativeAd.this.nativeAdCallback.onAdOpened();
      FacebookRtbNativeAd.this.nativeAdCallback.onAdLeftApplication();
    }
    
    public void onAdLoaded(Ad param1Ad) {
      AdError adError;
      if (param1Ad != this.nativeAd) {
        adError = new AdError(106, "Ad Loaded is not a Native Ad.", "com.google.ads.mediation.facebook");
        String str = FacebookMediationAdapter.TAG;
        adError.getMessage();
        FacebookRtbNativeAd.this.callback.onFailure(adError);
        return;
      } 
      Context context = this.context.get();
      if (context == null) {
        adError = new AdError(107, "Context is null.", "com.google.ads.mediation.facebook");
        String str = FacebookMediationAdapter.TAG;
        adError.getMessage();
        FacebookRtbNativeAd.this.callback.onFailure(adError);
        return;
      } 
      FacebookRtbNativeAd.this.mapNativeAd((Context)adError, new FacebookRtbNativeAd.NativeAdMapperListener() {
            public void onMappingFailed(AdError param2AdError) {
              String str = FacebookMediationAdapter.TAG;
              param2AdError.getMessage();
              FacebookRtbNativeAd.this.callback.onFailure(param2AdError);
            }
            
            public void onMappingSuccess() {
              FacebookRtbNativeAd facebookRtbNativeAd = FacebookRtbNativeAd.this;
              FacebookRtbNativeAd.access$002(facebookRtbNativeAd, (MediationNativeAdCallback)facebookRtbNativeAd.callback.onSuccess(FacebookRtbNativeAd.this));
            }
          });
    }
    
    public void onError(Ad param1Ad, AdError param1AdError) {
      AdError adError = FacebookMediationAdapter.getAdError(param1AdError);
      adError.getMessage();
      FacebookRtbNativeAd.this.callback.onFailure(adError);
    }
    
    public void onLoggingImpression(Ad param1Ad) {}
    
    public void onMediaDownloaded(Ad param1Ad) {
      String str = FacebookMediationAdapter.TAG;
    }
  }
  
  public class null implements NativeAdMapperListener {
    public void onMappingFailed(AdError param1AdError) {
      String str = FacebookMediationAdapter.TAG;
      param1AdError.getMessage();
      FacebookRtbNativeAd.this.callback.onFailure(param1AdError);
    }
    
    public void onMappingSuccess() {
      FacebookRtbNativeAd facebookRtbNativeAd = FacebookRtbNativeAd.this;
      FacebookRtbNativeAd.access$002(facebookRtbNativeAd, (MediationNativeAdCallback)facebookRtbNativeAd.callback.onSuccess(FacebookRtbNativeAd.this));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\rtb\FacebookRtbNativeAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */