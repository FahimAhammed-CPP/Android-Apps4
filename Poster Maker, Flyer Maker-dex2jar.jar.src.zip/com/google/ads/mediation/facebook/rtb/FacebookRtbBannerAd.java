package com.google.ads.mediation.facebook.rtb;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdView;
import com.facebook.ads.ExtraHints;
import com.google.ads.mediation.facebook.FacebookMediationAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationBannerAdCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import s30;

public class FacebookRtbBannerAd implements MediationBannerAd, AdListener {
  private final MediationBannerAdConfiguration adConfiguration;
  
  private AdView adView;
  
  private MediationBannerAdCallback bannerAdCallback;
  
  private final MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> callback;
  
  private FrameLayout wrappedAdView;
  
  public FacebookRtbBannerAd(MediationBannerAdConfiguration paramMediationBannerAdConfiguration, MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> paramMediationAdLoadCallback) {
    this.adConfiguration = paramMediationBannerAdConfiguration;
    this.callback = paramMediationAdLoadCallback;
  }
  
  public View getView() {
    return (View)this.wrappedAdView;
  }
  
  public void onAdClicked(Ad paramAd) {
    MediationBannerAdCallback mediationBannerAdCallback = this.bannerAdCallback;
    if (mediationBannerAdCallback != null) {
      mediationBannerAdCallback.reportAdClicked();
      this.bannerAdCallback.onAdOpened();
      this.bannerAdCallback.onAdLeftApplication();
    } 
  }
  
  public void onAdLoaded(Ad paramAd) {
    this.bannerAdCallback = (MediationBannerAdCallback)this.callback.onSuccess(this);
  }
  
  public void onError(Ad paramAd, AdError paramAdError) {
    AdError adError = FacebookMediationAdapter.getAdError(paramAdError);
    adError.getMessage();
    this.callback.onFailure(adError);
  }
  
  public void onLoggingImpression(Ad paramAd) {
    MediationBannerAdCallback mediationBannerAdCallback = this.bannerAdCallback;
    if (mediationBannerAdCallback != null)
      mediationBannerAdCallback.reportAdImpression(); 
  }
  
  public void render() {
    AdError adError;
    String str = FacebookMediationAdapter.getPlacementID(this.adConfiguration.getServerParameters());
    if (TextUtils.isEmpty(str)) {
      adError = new AdError(101, "Failed to request ad. PlacementID is null or empty.", "com.google.ads.mediation.facebook");
      adError.getMessage();
      this.callback.onFailure(adError);
      return;
    } 
    FacebookMediationAdapter.setMixedAudience((MediationAdConfiguration)this.adConfiguration);
    try {
      this.adView = new AdView(this.adConfiguration.getContext(), (String)adError, this.adConfiguration.getBidResponse());
      if (!TextUtils.isEmpty(this.adConfiguration.getWatermark()))
        this.adView.setExtraHints((new ExtraHints.Builder()).mediationData(this.adConfiguration.getWatermark()).build()); 
      Context context = this.adConfiguration.getContext();
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(this.adConfiguration.getAdSize().getWidthInPixels(context), -2);
      this.wrappedAdView = new FrameLayout(context);
      this.adView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.wrappedAdView.addView((View)this.adView);
      AdView adView = this.adView;
      adView.loadAd(adView.buildLoadAdConfig().withAdListener(this).withBid(this.adConfiguration.getBidResponse()).build());
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = s30.x0("Failed to create banner ad: ");
      stringBuilder.append(exception.getMessage());
      AdError adError1 = new AdError(111, stringBuilder.toString(), "com.google.ads.mediation.facebook");
      adError1.getMessage();
      this.callback.onFailure(adError1);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\rtb\FacebookRtbBannerAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */