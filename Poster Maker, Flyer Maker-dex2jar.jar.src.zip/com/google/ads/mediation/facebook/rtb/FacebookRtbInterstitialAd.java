package com.google.ads.mediation.facebook.rtb;

import android.content.Context;
import android.text.TextUtils;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.ExtraHints;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdExtendedListener;
import com.facebook.ads.InterstitialAdListener;
import com.google.ads.mediation.facebook.FacebookMediationAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAdCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import java.util.concurrent.atomic.AtomicBoolean;

public class FacebookRtbInterstitialAd implements MediationInterstitialAd, InterstitialAdExtendedListener {
  private final MediationInterstitialAdConfiguration adConfiguration;
  
  private final MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> callback;
  
  private final AtomicBoolean didInterstitialAdClose = new AtomicBoolean();
  
  private MediationInterstitialAdCallback interstitalAdCallback;
  
  private InterstitialAd interstitialAd;
  
  private final AtomicBoolean showAdCalled = new AtomicBoolean();
  
  public FacebookRtbInterstitialAd(MediationInterstitialAdConfiguration paramMediationInterstitialAdConfiguration, MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> paramMediationAdLoadCallback) {
    this.adConfiguration = paramMediationInterstitialAdConfiguration;
    this.callback = paramMediationAdLoadCallback;
  }
  
  public void onAdClicked(Ad paramAd) {
    MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
    if (mediationInterstitialAdCallback != null) {
      mediationInterstitialAdCallback.reportAdClicked();
      this.interstitalAdCallback.onAdLeftApplication();
    } 
  }
  
  public void onAdLoaded(Ad paramAd) {
    this.interstitalAdCallback = (MediationInterstitialAdCallback)this.callback.onSuccess(this);
  }
  
  public void onError(Ad paramAd, AdError paramAdError) {
    MediationInterstitialAdCallback mediationInterstitialAdCallback;
    AdError adError = FacebookMediationAdapter.getAdError(paramAdError);
    adError.getMessage();
    if (this.showAdCalled.get()) {
      mediationInterstitialAdCallback = this.interstitalAdCallback;
      if (mediationInterstitialAdCallback != null) {
        mediationInterstitialAdCallback.onAdOpened();
        this.interstitalAdCallback.onAdClosed();
      } 
      return;
    } 
    this.callback.onFailure((AdError)mediationInterstitialAdCallback);
  }
  
  public void onInterstitialActivityDestroyed() {
    if (!this.didInterstitialAdClose.getAndSet(true)) {
      MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
      if (mediationInterstitialAdCallback != null)
        mediationInterstitialAdCallback.onAdClosed(); 
    } 
  }
  
  public void onInterstitialDismissed(Ad paramAd) {
    if (!this.didInterstitialAdClose.getAndSet(true)) {
      MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
      if (mediationInterstitialAdCallback != null)
        mediationInterstitialAdCallback.onAdClosed(); 
    } 
  }
  
  public void onInterstitialDisplayed(Ad paramAd) {
    MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
    if (mediationInterstitialAdCallback != null)
      mediationInterstitialAdCallback.onAdOpened(); 
  }
  
  public void onLoggingImpression(Ad paramAd) {
    MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
    if (mediationInterstitialAdCallback != null)
      mediationInterstitialAdCallback.reportAdImpression(); 
  }
  
  public void onRewardedAdCompleted() {}
  
  public void onRewardedAdServerFailed() {}
  
  public void onRewardedAdServerSucceeded() {}
  
  public void render() {
    AdError adError;
    String str = FacebookMediationAdapter.getPlacementID(this.adConfiguration.getServerParameters());
    if (TextUtils.isEmpty(str)) {
      adError = new AdError(101, "Failed to request ad. PlacementID is null or empty. ", "com.google.ads.mediation.facebook");
      adError.getMessage();
      this.callback.onFailure(adError);
      return;
    } 
    FacebookMediationAdapter.setMixedAudience((MediationAdConfiguration)this.adConfiguration);
    this.interstitialAd = new InterstitialAd(this.adConfiguration.getContext(), (String)adError);
    if (!TextUtils.isEmpty(this.adConfiguration.getWatermark()))
      this.interstitialAd.setExtraHints((new ExtraHints.Builder()).mediationData(this.adConfiguration.getWatermark()).build()); 
    InterstitialAd interstitialAd = this.interstitialAd;
    interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withBid(this.adConfiguration.getBidResponse()).withAdListener((InterstitialAdListener)this).build());
  }
  
  public void showAd(Context paramContext) {
    this.showAdCalled.set(true);
    if (!this.interstitialAd.show()) {
      AdError adError = new AdError(110, "Failed to present interstitial ad.", "com.google.ads.mediation.facebook");
      String str = FacebookMediationAdapter.TAG;
      adError.toString();
      MediationInterstitialAdCallback mediationInterstitialAdCallback = this.interstitalAdCallback;
      if (mediationInterstitialAdCallback != null)
        mediationInterstitialAdCallback.onAdFailedToShow(adError); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\rtb\FacebookRtbInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */