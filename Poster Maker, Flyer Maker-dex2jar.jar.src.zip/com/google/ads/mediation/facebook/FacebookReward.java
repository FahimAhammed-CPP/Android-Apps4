package com.google.ads.mediation.facebook;

import com.google.android.gms.ads.rewarded.RewardItem;

public class FacebookReward implements RewardItem {
  public int getAmount() {
    return 1;
  }
  
  public String getType() {
    return "";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\facebook\FacebookReward.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */