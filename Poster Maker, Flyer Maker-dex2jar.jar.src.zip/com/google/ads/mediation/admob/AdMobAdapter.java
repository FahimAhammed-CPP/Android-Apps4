package com.google.ads.mediation.admob;

import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Keep;
import com.google.ads.mediation.AbstractAdViewAdapter;

@Keep
public final class AdMobAdapter extends AbstractAdViewAdapter {
  public static final String AD_JSON_PARAMETER = "adJson";
  
  public static final String AD_PARAMETER = "_ad";
  
  public static final String HOUSE_ADS_PARAMETER = "mad_hac";
  
  public static final String NEW_BUNDLE = "_newBundle";
  
  public Bundle buildExtrasBundle(Bundle paramBundle1, Bundle paramBundle2) {
    Bundle bundle = paramBundle1;
    if (paramBundle1 == null)
      bundle = new Bundle(); 
    paramBundle1 = bundle;
    if (bundle.getBoolean("_newBundle"))
      paramBundle1 = new Bundle(bundle); 
    paramBundle1.putInt("gw", 1);
    paramBundle1.putString("mad_hac", paramBundle2.getString("mad_hac"));
    if (!TextUtils.isEmpty(paramBundle2.getString("adJson")))
      paramBundle1.putString("_ad", paramBundle2.getString("adJson")); 
    paramBundle1.putBoolean("_noRefresh", true);
    return paramBundle1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\admob\AdMobAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */