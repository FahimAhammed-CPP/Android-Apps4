package com.google.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdq;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeMediationAdRequest;
import com.google.android.gms.ads.mediation.OnImmersiveModeUpdatedListener;
import com.google.android.gms.ads.mediation.zza;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.internal.ads.zzbyt;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter, OnImmersiveModeUpdatedListener, zza {
  public static final String AD_UNIT_ID_PARAMETER = "pubid";
  
  private AdLoader adLoader;
  
  public AdView mAdView;
  
  public InterstitialAd mInterstitialAd;
  
  public AdRequest buildAdRequest(Context paramContext, MediationAdRequest paramMediationAdRequest, Bundle paramBundle1, Bundle paramBundle2) {
    AdRequest.Builder builder = new AdRequest.Builder();
    Date date = paramMediationAdRequest.getBirthday();
    if (date != null)
      builder.zzb(date); 
    int i = paramMediationAdRequest.getGender();
    if (i != 0)
      builder.zzc(i); 
    Set set = paramMediationAdRequest.getKeywords();
    if (set != null) {
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        builder.addKeyword(iterator.next()); 
    } 
    if (paramMediationAdRequest.isTesting()) {
      zzay.zzb();
      builder.zza(zzbyt.zzz(paramContext));
    } 
    if (paramMediationAdRequest.taggedForChildDirectedTreatment() != -1) {
      i = paramMediationAdRequest.taggedForChildDirectedTreatment();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      builder.zze(bool);
    } 
    builder.zzd(paramMediationAdRequest.isDesignedForFamilies());
    builder.addNetworkExtrasBundle(AdMobAdapter.class, buildExtrasBundle(paramBundle1, paramBundle2));
    return builder.build();
  }
  
  public abstract Bundle buildExtrasBundle(Bundle paramBundle1, Bundle paramBundle2);
  
  public String getAdUnitId(Bundle paramBundle) {
    return paramBundle.getString("pubid");
  }
  
  public View getBannerView() {
    return (View)this.mAdView;
  }
  
  @VisibleForTesting
  public InterstitialAd getInterstitialAd() {
    return this.mInterstitialAd;
  }
  
  public zzdq getVideoController() {
    AdView adView = this.mAdView;
    return (adView != null) ? adView.zza().zza() : null;
  }
  
  @VisibleForTesting
  public AdLoader.Builder newAdLoader(Context paramContext, String paramString) {
    return new AdLoader.Builder(paramContext, paramString);
  }
  
  public void onDestroy() {
    AdView adView = this.mAdView;
    if (adView != null) {
      adView.destroy();
      this.mAdView = null;
    } 
    if (this.mInterstitialAd != null)
      this.mInterstitialAd = null; 
    if (this.adLoader != null)
      this.adLoader = null; 
  }
  
  public void onImmersiveModeUpdated(boolean paramBoolean) {
    InterstitialAd interstitialAd = this.mInterstitialAd;
    if (interstitialAd != null)
      interstitialAd.setImmersiveMode(paramBoolean); 
  }
  
  public void onPause() {
    AdView adView = this.mAdView;
    if (adView != null)
      adView.pause(); 
  }
  
  public void onResume() {
    AdView adView = this.mAdView;
    if (adView != null)
      adView.resume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    AdView adView = new AdView(paramContext);
    this.mAdView = adView;
    adView.setAdSize(new AdSize(paramAdSize.getWidth(), paramAdSize.getHeight()));
    this.mAdView.setAdUnitId(getAdUnitId(paramBundle1));
    this.mAdView.setAdListener(new zzb(this, paramMediationBannerListener));
    this.mAdView.loadAd(buildAdRequest(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    InterstitialAd.load(paramContext, getAdUnitId(paramBundle1), buildAdRequest(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1), new zzc(this, paramMediationInterstitialListener));
  }
  
  public void requestNativeAd(Context paramContext, MediationNativeListener paramMediationNativeListener, Bundle paramBundle1, NativeMediationAdRequest paramNativeMediationAdRequest, Bundle paramBundle2) {
    zze zze = new zze(this, paramMediationNativeListener);
    AdLoader.Builder builder = newAdLoader(paramContext, paramBundle1.getString("pubid")).withAdListener(zze);
    builder.withNativeAdOptions(paramNativeMediationAdRequest.getNativeAdOptions());
    builder.withNativeAdOptions(paramNativeMediationAdRequest.getNativeAdRequestOptions());
    if (paramNativeMediationAdRequest.isUnifiedNativeAdRequested())
      builder.forUnifiedNativeAd(zze); 
    if (paramNativeMediationAdRequest.zzb())
      for (String str : paramNativeMediationAdRequest.zza().keySet()) {
        zze zze1;
        if (true != ((Boolean)paramNativeMediationAdRequest.zza().get(str)).booleanValue()) {
          paramMediationNativeListener = null;
        } else {
          zze1 = zze;
        } 
        builder.forCustomTemplateAd(str, zze, zze1);
      }  
    AdLoader adLoader = builder.build();
    this.adLoader = adLoader;
    adLoader.loadAd(buildAdRequest(paramContext, (MediationAdRequest)paramNativeMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void showInterstitial() {
    InterstitialAd interstitialAd = this.mInterstitialAd;
    if (interstitialAd != null)
      interstitialAd.show(null); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\mediation\AbstractAdViewAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */