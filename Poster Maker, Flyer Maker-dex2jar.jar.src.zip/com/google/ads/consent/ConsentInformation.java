package com.google.ads.consent;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class ConsentInformation {
  private static final String CONSENT_DATA_KEY = "consent_string";
  
  private static final String MOBILE_ADS_SERVER_URL = "https://adservice.google.com/getconfig/pubvendors";
  
  private static final String PREFERENCES_FILE_KEY = "mobileads_consent";
  
  private static final String TAG = "ConsentInformation";
  
  private static ConsentInformation instance;
  
  private final Context context;
  
  private DebugGeography debugGeography;
  
  private String hashedDeviceId;
  
  private List<String> testDevices;
  
  private ConsentInformation(Context paramContext) {
    this.context = paramContext.getApplicationContext();
    this.debugGeography = DebugGeography.DEBUG_GEOGRAPHY_DISABLED;
    this.testDevices = new ArrayList<String>();
    this.hashedDeviceId = getHashedDeviceId();
  }
  
  public static ConsentInformation getInstance(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/ads/consent/ConsentInformation
    //   2: monitorenter
    //   3: getstatic com/google/ads/consent/ConsentInformation.instance : Lcom/google/ads/consent/ConsentInformation;
    //   6: ifnonnull -> 20
    //   9: new com/google/ads/consent/ConsentInformation
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Landroid/content/Context;)V
    //   17: putstatic com/google/ads/consent/ConsentInformation.instance : Lcom/google/ads/consent/ConsentInformation;
    //   20: getstatic com/google/ads/consent/ConsentInformation.instance : Lcom/google/ads/consent/ConsentInformation;
    //   23: astore_0
    //   24: ldc com/google/ads/consent/ConsentInformation
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc com/google/ads/consent/ConsentInformation
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	24	29	finally
  }
  
  private HashSet<AdProvider> getNonPersonalizedAdProviders(List<AdProvider> paramList, HashSet<String> paramHashSet) {
    ArrayList<AdProvider> arrayList = new ArrayList();
    for (AdProvider adProvider : paramList) {
      if (paramHashSet.contains(adProvider.getId()))
        arrayList.add(adProvider); 
    } 
    return new HashSet<AdProvider>(arrayList);
  }
  
  private boolean isEmulator() {
    String str = Build.FINGERPRINT;
    if (!str.startsWith("generic") && !str.startsWith("unknown")) {
      str = Build.MODEL;
      if (!str.contains("google_sdk") && !str.contains("Emulator") && !str.contains("Android SDK built for x86") && !Build.MANUFACTURER.contains("Genymotion") && (!Build.BRAND.startsWith("generic") || !Build.DEVICE.startsWith("generic")) && !"google_sdk".equals(Build.PRODUCT))
        return false; 
    } 
    return true;
  }
  
  private String md5(String paramString) {
    int i = 0;
    while (true) {
      if (i < 3) {
        try {
          MessageDigest messageDigest = MessageDigest.getInstance("MD5");
          messageDigest.update(paramString.getBytes());
          return String.format("%032X", new Object[] { new BigInteger(1, messageDigest.digest()) });
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
          i++;
        } catch (ArithmeticException arithmeticException) {
          return null;
        } 
        continue;
      } 
      return null;
    } 
  }
  
  private void saveConsentData(ConsentData paramConsentData) {
    SharedPreferences.Editor editor = this.context.getSharedPreferences("mobileads_consent", 0).edit();
    editor.putString("consent_string", (new Gson()).toJson(paramConsentData));
    editor.apply();
  }
  
  private void updateConsentData(String paramString, List<String> paramList) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new com/google/gson/Gson
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: aload_1
    //   10: ldc com/google/ads/consent/ConsentInformation$ServerResponse
    //   12: invokevirtual fromJson : (Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    //   15: checkcast com/google/ads/consent/ConsentInformation$ServerResponse
    //   18: astore #7
    //   20: aload_0
    //   21: aload #7
    //   23: invokespecial validatePublisherIds : (Lcom/google/ads/consent/ConsentInformation$ServerResponse;)V
    //   26: new java/util/HashSet
    //   29: dup
    //   30: invokespecial <init> : ()V
    //   33: astore #6
    //   35: aload #7
    //   37: getfield adNetworkLookupResponses : Ljava/util/List;
    //   40: astore #8
    //   42: iconst_1
    //   43: istore_3
    //   44: aload #8
    //   46: ifnull -> 336
    //   49: aload #8
    //   51: invokeinterface iterator : ()Ljava/util/Iterator;
    //   56: astore #8
    //   58: iconst_0
    //   59: istore #4
    //   61: iload #4
    //   63: istore #5
    //   65: aload #8
    //   67: invokeinterface hasNext : ()Z
    //   72: ifeq -> 121
    //   75: aload #8
    //   77: invokeinterface next : ()Ljava/lang/Object;
    //   82: checkcast com/google/ads/consent/ConsentInformation$AdNetworkLookupResponse
    //   85: astore #9
    //   87: aload #9
    //   89: invokestatic access$400 : (Lcom/google/ads/consent/ConsentInformation$AdNetworkLookupResponse;)Z
    //   92: ifne -> 98
    //   95: goto -> 61
    //   98: aload #9
    //   100: invokestatic access$500 : (Lcom/google/ads/consent/ConsentInformation$AdNetworkLookupResponse;)Ljava/util/List;
    //   103: astore #9
    //   105: aload #9
    //   107: ifnull -> 330
    //   110: aload #6
    //   112: aload #9
    //   114: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   117: pop
    //   118: goto -> 330
    //   121: aload #7
    //   123: getfield companies : Ljava/util/List;
    //   126: astore #8
    //   128: aload #8
    //   130: ifnonnull -> 145
    //   133: new java/util/HashSet
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: astore #6
    //   142: goto -> 177
    //   145: iload #5
    //   147: ifeq -> 163
    //   150: aload_0
    //   151: aload #8
    //   153: aload #6
    //   155: invokespecial getNonPersonalizedAdProviders : (Ljava/util/List;Ljava/util/HashSet;)Ljava/util/HashSet;
    //   158: astore #6
    //   160: goto -> 177
    //   163: new java/util/HashSet
    //   166: dup
    //   167: aload #7
    //   169: getfield companies : Ljava/util/List;
    //   172: invokespecial <init> : (Ljava/util/Collection;)V
    //   175: astore #6
    //   177: aload_0
    //   178: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   181: astore #8
    //   183: aload #8
    //   185: invokevirtual hasNonPersonalizedPublisherId : ()Z
    //   188: iload #5
    //   190: if_icmpeq -> 342
    //   193: goto -> 196
    //   196: aload #8
    //   198: iload #5
    //   200: invokevirtual setHasNonPersonalizedPublisherId : (Z)V
    //   203: aload #8
    //   205: aload_1
    //   206: invokevirtual setRawResponse : (Ljava/lang/String;)V
    //   209: aload #8
    //   211: new java/util/HashSet
    //   214: dup
    //   215: aload_2
    //   216: invokespecial <init> : (Ljava/util/Collection;)V
    //   219: invokevirtual setPublisherIds : (Ljava/util/HashSet;)V
    //   222: aload #8
    //   224: aload #6
    //   226: invokevirtual setAdProviders : (Ljava/util/HashSet;)V
    //   229: aload #8
    //   231: aload #7
    //   233: getfield isRequestLocationInEeaOrUnknown : Ljava/lang/Boolean;
    //   236: invokevirtual booleanValue : ()Z
    //   239: invokevirtual setRequestLocationInEeaOrUnknown : (Z)V
    //   242: aload #7
    //   244: getfield isRequestLocationInEeaOrUnknown : Ljava/lang/Boolean;
    //   247: invokevirtual booleanValue : ()Z
    //   250: ifne -> 262
    //   253: aload_0
    //   254: aload #8
    //   256: invokespecial saveConsentData : (Lcom/google/ads/consent/ConsentData;)V
    //   259: aload_0
    //   260: monitorexit
    //   261: return
    //   262: aload #8
    //   264: invokevirtual getConsentedAdProviders : ()Ljava/util/HashSet;
    //   267: aload #8
    //   269: invokevirtual getAdProviders : ()Ljava/util/HashSet;
    //   272: invokevirtual containsAll : (Ljava/util/Collection;)Z
    //   275: ifeq -> 282
    //   278: iload_3
    //   279: ifeq -> 310
    //   282: aload #8
    //   284: ldc_w 'sdk'
    //   287: invokevirtual setConsentSource : (Ljava/lang/String;)V
    //   290: aload #8
    //   292: getstatic com/google/ads/consent/ConsentStatus.UNKNOWN : Lcom/google/ads/consent/ConsentStatus;
    //   295: invokevirtual setConsentStatus : (Lcom/google/ads/consent/ConsentStatus;)V
    //   298: aload #8
    //   300: new java/util/HashSet
    //   303: dup
    //   304: invokespecial <init> : ()V
    //   307: invokevirtual setConsentedAdProviders : (Ljava/util/HashSet;)V
    //   310: aload_0
    //   311: aload #8
    //   313: invokespecial saveConsentData : (Lcom/google/ads/consent/ConsentData;)V
    //   316: aload_0
    //   317: monitorexit
    //   318: return
    //   319: astore_1
    //   320: aload_0
    //   321: monitorexit
    //   322: goto -> 327
    //   325: aload_1
    //   326: athrow
    //   327: goto -> 325
    //   330: iconst_1
    //   331: istore #4
    //   333: goto -> 61
    //   336: iconst_0
    //   337: istore #5
    //   339: goto -> 121
    //   342: iconst_0
    //   343: istore_3
    //   344: goto -> 196
    // Exception table:
    //   from	to	target	type
    //   2	42	319	finally
    //   49	58	319	finally
    //   65	95	319	finally
    //   98	105	319	finally
    //   110	118	319	finally
    //   121	128	319	finally
    //   133	142	319	finally
    //   150	160	319	finally
    //   163	177	319	finally
    //   177	193	319	finally
    //   196	259	319	finally
    //   262	278	319	finally
    //   282	310	319	finally
    //   310	316	319	finally
  }
  
  private void validatePublisherIds(ServerResponse paramServerResponse) {
    Boolean bool = paramServerResponse.isRequestLocationInEeaOrUnknown;
    if (bool != null) {
      if (paramServerResponse.companies != null || !bool.booleanValue()) {
        if (!paramServerResponse.isRequestLocationInEeaOrUnknown.booleanValue())
          return; 
        HashSet<String> hashSet1 = new HashSet();
        HashSet<String> hashSet2 = new HashSet();
        for (AdNetworkLookupResponse adNetworkLookupResponse : paramServerResponse.adNetworkLookupResponses) {
          if (adNetworkLookupResponse.lookupFailed)
            hashSet1.add(adNetworkLookupResponse.id); 
          if (adNetworkLookupResponse.notFound)
            hashSet2.add(adNetworkLookupResponse.id); 
        } 
        if (hashSet1.isEmpty() && hashSet2.isEmpty())
          return; 
        StringBuilder stringBuilder = new StringBuilder("Response error.");
        if (!hashSet1.isEmpty())
          stringBuilder.append(String.format(" Lookup failure for: %s.", new Object[] { TextUtils.join(",", hashSet1) })); 
        if (!hashSet2.isEmpty())
          stringBuilder.append(String.format(" Publisher Ids not found: %s", new Object[] { TextUtils.join(",", hashSet2) })); 
        throw new Exception(stringBuilder.toString());
      } 
      throw new Exception("Could not parse Event FE preflight response.");
    } 
    Exception exception = new Exception("Could not parse Event FE preflight response.");
    throw exception;
  }
  
  public void addTestDevice(String paramString) {
    this.testDevices.add(paramString);
  }
  
  public List<AdProvider> getAdProviders() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: aload_0
    //   7: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   10: invokevirtual getAdProviders : ()Ljava/util/HashSet;
    //   13: invokespecial <init> : (Ljava/util/Collection;)V
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: areturn
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	21	finally
  }
  
  public ConsentStatus getConsentStatus() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   6: invokevirtual getConsentStatus : ()Lcom/google/ads/consent/ConsentStatus;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public DebugGeography getDebugGeography() {
    return this.debugGeography;
  }
  
  public String getHashedDeviceId() {
    String str;
    ContentResolver contentResolver = this.context.getContentResolver();
    if (contentResolver == null) {
      contentResolver = null;
    } else {
      str = Settings.Secure.getString(contentResolver, "android_id");
    } 
    if (str == null || isEmulator())
      str = "emulator"; 
    return md5(str);
  }
  
  public boolean isRequestLocationInEeaOrUnknown() {
    return loadConsentData().isRequestLocationInEeaOrUnknown();
  }
  
  public boolean isTaggedForUnderAgeOfConsent() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   6: invokevirtual isTaggedForUnderAgeOfConsent : ()Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public boolean isTestDevice() {
    return (isEmulator() || this.testDevices.contains(this.hashedDeviceId));
  }
  
  public ConsentData loadConsentData() {
    String str = this.context.getSharedPreferences("mobileads_consent", 0).getString("consent_string", "");
    return TextUtils.isEmpty(str) ? new ConsentData() : (ConsentData)(new Gson()).fromJson(str, ConsentData.class);
  }
  
  public void requestConsentInfoUpdate(String[] paramArrayOfString, ConsentInfoUpdateListener paramConsentInfoUpdateListener) {
    requestConsentInfoUpdate(paramArrayOfString, "https://adservice.google.com/getconfig/pubvendors", paramConsentInfoUpdateListener);
  }
  
  public void requestConsentInfoUpdate(String[] paramArrayOfString, String paramString, ConsentInfoUpdateListener paramConsentInfoUpdateListener) {
    if (!isTestDevice())
      String.valueOf(getHashedDeviceId()).length(); 
    (new ConsentInfoUpdateTask(paramString, this, Arrays.asList(paramArrayOfString), paramConsentInfoUpdateListener)).execute((Object[])new Void[0]);
  }
  
  public void reset() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield context : Landroid/content/Context;
    //   6: ldc 'mobileads_consent'
    //   8: iconst_0
    //   9: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   12: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   17: astore_1
    //   18: aload_1
    //   19: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
    //   24: pop
    //   25: aload_1
    //   26: invokeinterface apply : ()V
    //   31: aload_0
    //   32: new java/util/ArrayList
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: putfield testDevices : Ljava/util/List;
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_1
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   2	42	45	finally
  }
  
  public void setConsentStatus(ConsentStatus paramConsentStatus) {
    setConsentStatus(paramConsentStatus, "programmatic");
  }
  
  public void setConsentStatus(ConsentStatus paramConsentStatus, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   6: astore_3
    //   7: aload_1
    //   8: getstatic com/google/ads/consent/ConsentStatus.UNKNOWN : Lcom/google/ads/consent/ConsentStatus;
    //   11: if_acmpne -> 28
    //   14: aload_3
    //   15: new java/util/HashSet
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: invokevirtual setConsentedAdProviders : (Ljava/util/HashSet;)V
    //   25: goto -> 36
    //   28: aload_3
    //   29: aload_3
    //   30: invokevirtual getAdProviders : ()Ljava/util/HashSet;
    //   33: invokevirtual setConsentedAdProviders : (Ljava/util/HashSet;)V
    //   36: aload_3
    //   37: aload_2
    //   38: invokevirtual setConsentSource : (Ljava/lang/String;)V
    //   41: aload_3
    //   42: aload_1
    //   43: invokevirtual setConsentStatus : (Lcom/google/ads/consent/ConsentStatus;)V
    //   46: aload_0
    //   47: aload_3
    //   48: invokespecial saveConsentData : (Lcom/google/ads/consent/ConsentData;)V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: astore_1
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_1
    //   58: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	54	finally
    //   28	36	54	finally
    //   36	51	54	finally
  }
  
  public void setDebugGeography(DebugGeography paramDebugGeography) {
    this.debugGeography = paramDebugGeography;
  }
  
  public void setHashedDeviceId(String paramString) {
    this.hashedDeviceId = paramString;
  }
  
  public void setTagForUnderAgeOfConsent(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual loadConsentData : ()Lcom/google/ads/consent/ConsentData;
    //   6: astore_2
    //   7: aload_2
    //   8: iload_1
    //   9: invokevirtual tagForUnderAgeOfConsent : (Z)V
    //   12: aload_0
    //   13: aload_2
    //   14: invokespecial saveConsentData : (Lcom/google/ads/consent/ConsentData;)V
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: astore_2
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_2
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	20	finally
  }
  
  public static class AdNetworkLookupResponse {
    @SerializedName("company_ids")
    private List<String> companyIds;
    
    @SerializedName("ad_network_id")
    private String id;
    
    @SerializedName("is_npa")
    private boolean isNPA;
    
    @SerializedName("lookup_failed")
    private boolean lookupFailed;
    
    @SerializedName("not_found")
    private boolean notFound;
  }
  
  public static class ConsentInfoUpdateResponse {
    public String responseInfo;
    
    public boolean success;
    
    public ConsentInfoUpdateResponse(boolean param1Boolean, String param1String) {
      this.success = param1Boolean;
      this.responseInfo = param1String;
    }
  }
  
  public static class ConsentInfoUpdateTask extends AsyncTask<Void, Void, ConsentInfoUpdateResponse> {
    private static final String UPDATE_SUCCESS = "Consent update successful.";
    
    private final ConsentInformation consentInformation;
    
    private final ConsentInfoUpdateListener listener;
    
    private final List<String> publisherIds;
    
    private final String url;
    
    public ConsentInfoUpdateTask(String param1String, ConsentInformation param1ConsentInformation, List<String> param1List, ConsentInfoUpdateListener param1ConsentInfoUpdateListener) {
      this.url = param1String;
      this.listener = param1ConsentInfoUpdateListener;
      this.publisherIds = param1List;
      this.consentInformation = param1ConsentInformation;
    }
    
    private ConsentInformation.ConsentInfoUpdateResponse makeConsentLookupRequest(String param1String) {
      try {
        HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(param1String)).openConnection();
        if (httpURLConnection.getResponseCode() == 200) {
          String str = readStream(httpURLConnection.getInputStream());
          httpURLConnection.disconnect();
          this.consentInformation.updateConsentData(str, this.publisherIds);
          return new ConsentInformation.ConsentInfoUpdateResponse(true, "Consent update successful.");
        } 
        return new ConsentInformation.ConsentInfoUpdateResponse(false, httpURLConnection.getResponseMessage());
      } catch (Exception exception) {
        return new ConsentInformation.ConsentInfoUpdateResponse(false, exception.getLocalizedMessage());
      } 
    }
    
    private String readStream(InputStream param1InputStream) {
      // Byte code:
      //   0: sipush #1024
      //   3: newarray byte
      //   5: astore #4
      //   7: new java/lang/StringBuilder
      //   10: dup
      //   11: invokespecial <init> : ()V
      //   14: astore_3
      //   15: new java/io/BufferedInputStream
      //   18: dup
      //   19: aload_1
      //   20: invokespecial <init> : (Ljava/io/InputStream;)V
      //   23: astore_1
      //   24: aload_1
      //   25: aload #4
      //   27: invokevirtual read : ([B)I
      //   30: istore_2
      //   31: iload_2
      //   32: iconst_m1
      //   33: if_icmpeq -> 55
      //   36: aload_3
      //   37: new java/lang/String
      //   40: dup
      //   41: aload #4
      //   43: iconst_0
      //   44: iload_2
      //   45: invokespecial <init> : ([BII)V
      //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   51: pop
      //   52: goto -> 24
      //   55: aload_1
      //   56: invokevirtual close : ()V
      //   59: goto -> 68
      //   62: astore_1
      //   63: aload_1
      //   64: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   67: pop
      //   68: aload_3
      //   69: invokevirtual toString : ()Ljava/lang/String;
      //   72: areturn
      //   73: astore_3
      //   74: goto -> 97
      //   77: astore_3
      //   78: aload_3
      //   79: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   82: pop
      //   83: aload_1
      //   84: invokevirtual close : ()V
      //   87: aconst_null
      //   88: areturn
      //   89: astore_1
      //   90: aload_1
      //   91: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   94: pop
      //   95: aconst_null
      //   96: areturn
      //   97: aload_1
      //   98: invokevirtual close : ()V
      //   101: goto -> 110
      //   104: astore_1
      //   105: aload_1
      //   106: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   109: pop
      //   110: goto -> 115
      //   113: aload_3
      //   114: athrow
      //   115: goto -> 113
      // Exception table:
      //   from	to	target	type
      //   24	31	77	java/io/IOException
      //   24	31	73	finally
      //   36	52	77	java/io/IOException
      //   36	52	73	finally
      //   55	59	62	java/io/IOException
      //   78	83	73	finally
      //   83	87	89	java/io/IOException
      //   97	101	104	java/io/IOException
    }
    
    public ConsentInformation.ConsentInfoUpdateResponse doInBackground(Void... param1VarArgs) {
      String str = TextUtils.join(",", this.publisherIds);
      ConsentData consentData = this.consentInformation.loadConsentData();
      Uri.Builder builder2 = Uri.parse(this.url).buildUpon().appendQueryParameter("pubs", str).appendQueryParameter("es", "2").appendQueryParameter("plat", consentData.getSDKPlatformString()).appendQueryParameter("v", consentData.getSDKVersionString());
      Uri.Builder builder1 = builder2;
      if (this.consentInformation.isTestDevice()) {
        builder1 = builder2;
        if (this.consentInformation.getDebugGeography() != DebugGeography.DEBUG_GEOGRAPHY_DISABLED)
          builder1 = builder2.appendQueryParameter("debug_geo", this.consentInformation.getDebugGeography().getCode().toString()); 
      } 
      return makeConsentLookupRequest(builder1.build().toString());
    }
    
    public void onPostExecute(ConsentInformation.ConsentInfoUpdateResponse param1ConsentInfoUpdateResponse) {
      if (param1ConsentInfoUpdateResponse.success) {
        this.listener.onConsentInfoUpdated(this.consentInformation.getConsentStatus());
        return;
      } 
      this.listener.onFailedToUpdateConsentInfo(param1ConsentInfoUpdateResponse.responseInfo);
    }
  }
  
  public static class ServerResponse {
    @SerializedName("ad_network_ids")
    public List<ConsentInformation.AdNetworkLookupResponse> adNetworkLookupResponses;
    
    public List<AdProvider> companies;
    
    @SerializedName("is_request_in_eea_or_unknown")
    public Boolean isRequestLocationInEeaOrUnknown;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\ConsentInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */