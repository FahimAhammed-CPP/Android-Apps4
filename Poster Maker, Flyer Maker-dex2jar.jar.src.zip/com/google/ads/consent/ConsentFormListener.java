package com.google.ads.consent;

public abstract class ConsentFormListener {
  public void onConsentFormClosed(ConsentStatus paramConsentStatus, Boolean paramBoolean) {}
  
  public void onConsentFormError(String paramString) {}
  
  public void onConsentFormLoaded() {}
  
  public void onConsentFormOpened() {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\ConsentFormListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */