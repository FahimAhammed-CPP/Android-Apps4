package com.google.ads.consent;

import com.google.gson.annotations.SerializedName;

public final class AdProvider {
  @SerializedName("company_id")
  private String id;
  
  @SerializedName("company_name")
  private String name;
  
  @SerializedName("policy_url")
  private String privacyPolicyUrlString;
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || AdProvider.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return this.id.equals(((AdProvider)paramObject).id);
  }
  
  public String getId() {
    return this.id;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPrivacyPolicyUrlString() {
    return this.privacyPolicyUrlString;
  }
  
  public int hashCode() {
    return this.id.hashCode();
  }
  
  public void setId(String paramString) {
    this.id = paramString;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public void setPrivacyPolicyUrlString(String paramString) {
    this.privacyPolicyUrlString = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\AdProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */