package com.google.ads.consent;

import com.google.gson.annotations.SerializedName;
import java.util.HashSet;

public class ConsentData {
  private static final String SDK_PLATFORM = "android";
  
  private static final String SDK_VERSION = "1.0.8";
  
  @SerializedName("providers")
  private HashSet<AdProvider> adProviders = new HashSet<AdProvider>();
  
  @SerializedName("consent_source")
  private String consentSource;
  
  @SerializedName("consent_state")
  private ConsentStatus consentStatus = ConsentStatus.UNKNOWN;
  
  @SerializedName("consented_providers")
  private HashSet<AdProvider> consentedAdProviders = new HashSet<AdProvider>();
  
  @SerializedName("has_any_npa_pub_id")
  private boolean hasNonPersonalizedPublisherId = false;
  
  @SerializedName("is_request_in_eea_or_unknown")
  private boolean isRequestLocationInEeaOrUnknown = false;
  
  @SerializedName("pub_ids")
  private HashSet<String> publisherIds = new HashSet<String>();
  
  @SerializedName("raw_response")
  private String rawResponse = "";
  
  @SerializedName("plat")
  private final String sdkPlatformString = "android";
  
  @SerializedName("version")
  private final String sdkVersionString = "1.0.8";
  
  @SerializedName("tag_for_under_age_of_consent")
  private Boolean underAgeOfConsent = Boolean.FALSE;
  
  public HashSet<AdProvider> getAdProviders() {
    return this.adProviders;
  }
  
  public String getConsentSource() {
    return this.consentSource;
  }
  
  public ConsentStatus getConsentStatus() {
    return this.consentStatus;
  }
  
  public HashSet<AdProvider> getConsentedAdProviders() {
    return this.consentedAdProviders;
  }
  
  public HashSet<String> getPublisherIds() {
    return this.publisherIds;
  }
  
  public String getRawResponse() {
    return this.rawResponse;
  }
  
  public String getSDKPlatformString() {
    return this.sdkPlatformString;
  }
  
  public String getSDKVersionString() {
    return this.sdkVersionString;
  }
  
  public boolean hasNonPersonalizedPublisherId() {
    return this.hasNonPersonalizedPublisherId;
  }
  
  public boolean isRequestLocationInEeaOrUnknown() {
    return this.isRequestLocationInEeaOrUnknown;
  }
  
  public boolean isTaggedForUnderAgeOfConsent() {
    return this.underAgeOfConsent.booleanValue();
  }
  
  public void setAdProviders(HashSet<AdProvider> paramHashSet) {
    this.adProviders = paramHashSet;
  }
  
  public void setConsentSource(String paramString) {
    this.consentSource = paramString;
  }
  
  public void setConsentStatus(ConsentStatus paramConsentStatus) {
    this.consentStatus = paramConsentStatus;
  }
  
  public void setConsentedAdProviders(HashSet<AdProvider> paramHashSet) {
    this.consentedAdProviders = paramHashSet;
  }
  
  public void setHasNonPersonalizedPublisherId(boolean paramBoolean) {
    this.hasNonPersonalizedPublisherId = paramBoolean;
  }
  
  public void setPublisherIds(HashSet<String> paramHashSet) {
    this.publisherIds = paramHashSet;
  }
  
  public void setRawResponse(String paramString) {
    this.rawResponse = paramString;
  }
  
  public void setRequestLocationInEeaOrUnknown(boolean paramBoolean) {
    this.isRequestLocationInEeaOrUnknown = paramBoolean;
  }
  
  public void tagForUnderAgeOfConsent(boolean paramBoolean) {
    this.underAgeOfConsent = Boolean.valueOf(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\ConsentData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */