package com.google.ads.consent;

import com.google.gson.annotations.SerializedName;

public enum ConsentStatus {
  NON_PERSONALIZED, PERSONALIZED, UNKNOWN;
  
  static {
    ConsentStatus consentStatus1 = new ConsentStatus("UNKNOWN", 0);
    UNKNOWN = consentStatus1;
    ConsentStatus consentStatus2 = new ConsentStatus("NON_PERSONALIZED", 1);
    NON_PERSONALIZED = consentStatus2;
    ConsentStatus consentStatus3 = new ConsentStatus("PERSONALIZED", 2);
    PERSONALIZED = consentStatus3;
    $VALUES = new ConsentStatus[] { consentStatus1, consentStatus2, consentStatus3 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\ConsentStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */