package com.google.ads.consent;

public enum DebugGeography {
  DEBUG_GEOGRAPHY_DISABLED, DEBUG_GEOGRAPHY_EEA, DEBUG_GEOGRAPHY_NOT_EEA;
  
  private final int value;
  
  static {
    DebugGeography debugGeography1 = new DebugGeography("DEBUG_GEOGRAPHY_DISABLED", 0, 0);
    DEBUG_GEOGRAPHY_DISABLED = debugGeography1;
    DebugGeography debugGeography2 = new DebugGeography("DEBUG_GEOGRAPHY_EEA", 1, 1);
    DEBUG_GEOGRAPHY_EEA = debugGeography2;
    DebugGeography debugGeography3 = new DebugGeography("DEBUG_GEOGRAPHY_NOT_EEA", 2, 2);
    DEBUG_GEOGRAPHY_NOT_EEA = debugGeography3;
    $VALUES = new DebugGeography[] { debugGeography1, debugGeography2, debugGeography3 };
  }
  
  DebugGeography(int paramInt1) {
    this.value = paramInt1;
  }
  
  public Integer getCode() {
    return Integer.valueOf(this.value);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\DebugGeography.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */