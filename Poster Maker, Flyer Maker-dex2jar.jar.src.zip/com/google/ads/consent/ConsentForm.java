package com.google.ads.consent;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.gson.Gson;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.util.HashMap;
import s30;

public class ConsentForm {
  private final boolean adFreeOption;
  
  private final URL appPrivacyPolicyURL;
  
  private final Context context;
  
  private final Dialog dialog;
  
  private final ConsentFormListener listener;
  
  private LoadState loadState;
  
  private final boolean nonPersonalizedAdsOption;
  
  private final boolean personalizedAdsOption;
  
  private final WebView webView;
  
  private ConsentForm(Builder paramBuilder) {
    Context context = paramBuilder.context;
    this.context = context;
    if (paramBuilder.listener == null) {
      this.listener = new ConsentFormListener(this) {
        
        };
    } else {
      this.listener = paramBuilder.listener;
    } 
    this.personalizedAdsOption = paramBuilder.personalizedAdsOption;
    this.nonPersonalizedAdsOption = paramBuilder.nonPersonalizedAdsOption;
    this.adFreeOption = paramBuilder.adFreeOption;
    this.appPrivacyPolicyURL = paramBuilder.appPrivacyPolicyURL;
    Dialog dialog = new Dialog(context, 16973840);
    this.dialog = dialog;
    this.loadState = LoadState.NOT_READY;
    WebView webView = new WebView(context);
    this.webView = webView;
    webView.setBackgroundColor(0);
    dialog.setContentView((View)webView);
    dialog.setCancelable(false);
    webView.getSettings().setJavaScriptEnabled(true);
    webView.setWebViewClient(new WebViewClient() {
          public boolean isInternalRedirect;
          
          private void handleUrl(String param1String) {
            // Byte code:
            //   0: aload_0
            //   1: aload_1
            //   2: invokespecial isConsentFormUrl : (Ljava/lang/String;)Z
            //   5: ifne -> 9
            //   8: return
            //   9: iconst_1
            //   10: istore_2
            //   11: aload_0
            //   12: iconst_1
            //   13: putfield isInternalRedirect : Z
            //   16: aload_1
            //   17: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
            //   20: astore #4
            //   22: aload #4
            //   24: ldc 'action'
            //   26: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
            //   29: astore_1
            //   30: aload #4
            //   32: ldc 'status'
            //   34: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
            //   37: astore_3
            //   38: aload #4
            //   40: ldc 'url'
            //   42: invokevirtual getQueryParameter : (Ljava/lang/String;)Ljava/lang/String;
            //   45: astore #4
            //   47: aload_1
            //   48: invokevirtual hashCode : ()I
            //   51: pop
            //   52: aload_1
            //   53: invokevirtual hashCode : ()I
            //   56: lookupswitch default -> 92, -1370505102 -> 126, 150940456 -> 114, 1671672458 -> 97
            //   92: iconst_m1
            //   93: istore_2
            //   94: goto -> 140
            //   97: aload_1
            //   98: ldc 'dismiss'
            //   100: invokevirtual equals : (Ljava/lang/Object;)Z
            //   103: ifne -> 109
            //   106: goto -> 92
            //   109: iconst_2
            //   110: istore_2
            //   111: goto -> 140
            //   114: aload_1
            //   115: ldc 'browser'
            //   117: invokevirtual equals : (Ljava/lang/Object;)Z
            //   120: ifne -> 140
            //   123: goto -> 92
            //   126: aload_1
            //   127: ldc 'load_complete'
            //   129: invokevirtual equals : (Ljava/lang/Object;)Z
            //   132: ifne -> 138
            //   135: goto -> 92
            //   138: iconst_0
            //   139: istore_2
            //   140: iload_2
            //   141: tableswitch default -> 168, 0 -> 193, 1 -> 183, 2 -> 169
            //   168: return
            //   169: aload_0
            //   170: iconst_0
            //   171: putfield isInternalRedirect : Z
            //   174: aload_0
            //   175: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
            //   178: aload_3
            //   179: invokestatic access$700 : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
            //   182: return
            //   183: aload_0
            //   184: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
            //   187: aload #4
            //   189: invokestatic access$800 : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
            //   192: return
            //   193: aload_0
            //   194: getfield this$0 : Lcom/google/ads/consent/ConsentForm;
            //   197: aload_3
            //   198: invokestatic access$600 : (Lcom/google/ads/consent/ConsentForm;Ljava/lang/String;)V
            //   201: return
          }
          
          private boolean isConsentFormUrl(String param1String) {
            return (!TextUtils.isEmpty(param1String) && param1String.startsWith("consent://"));
          }
          
          public void onLoadResource(WebView param1WebView, String param1String) {
            handleUrl(param1String);
          }
          
          public void onPageFinished(WebView param1WebView, String param1String) {
            if (!this.isInternalRedirect)
              ConsentForm.this.updateDialogContent(param1WebView); 
            super.onPageFinished(param1WebView, param1String);
          }
          
          public void onReceivedError(WebView param1WebView, WebResourceRequest param1WebResourceRequest, WebResourceError param1WebResourceError) {
            super.onReceivedError(param1WebView, param1WebResourceRequest, param1WebResourceError);
            ConsentForm.access$1002(ConsentForm.this, ConsentForm.LoadState.NOT_READY);
            ConsentForm.this.listener.onConsentFormError(param1WebResourceError.toString());
          }
          
          @TargetApi(24)
          public boolean shouldOverrideUrlLoading(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
            String str = param1WebResourceRequest.getUrl().toString();
            if (isConsentFormUrl(str)) {
              handleUrl(str);
              return true;
            } 
            return false;
          }
          
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            if (isConsentFormUrl(param1String)) {
              handleUrl(param1String);
              return true;
            } 
            return false;
          }
        });
  }
  
  private static String createJavascriptCommand(String paramString1, String paramString2) {
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    hashMap2.put("info", paramString2);
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
    hashMap1.put("args", hashMap2);
    return String.format("javascript:%s(%s)", new Object[] { paramString1, (new Gson()).toJson(hashMap1) });
  }
  
  private static String getAppIconURIString(Context paramContext) {
    Drawable drawable = paramContext.getPackageManager().getApplicationIcon(paramContext.getApplicationInfo());
    Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
    drawable.draw(canvas);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
    String str = String.valueOf(Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0));
    return (str.length() != 0) ? "data:image/png;base64,".concat(str) : new String("data:image/png;base64,");
  }
  
  private static String getApplicationName(Context paramContext) {
    return paramContext.getApplicationInfo().loadLabel(paramContext.getPackageManager()).toString();
  }
  
  private void handleDismiss(String paramString) {
    ConsentStatus consentStatus;
    this.loadState = LoadState.NOT_READY;
    this.dialog.dismiss();
    if (TextUtils.isEmpty(paramString)) {
      this.listener.onConsentFormError("No information provided.");
      return;
    } 
    if (paramString.contains("Error")) {
      this.listener.onConsentFormError(paramString);
      return;
    } 
    byte b = -1;
    int i = paramString.hashCode();
    boolean bool = true;
    switch (i) {
      case 1666911234:
        if (!paramString.equals("non_personalized"))
          break; 
        b = 2;
        break;
      case -258041904:
        if (!paramString.equals("personalized"))
          break; 
        b = 1;
        break;
      case -1152655096:
        if (!paramString.equals("ad_free"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        consentStatus = ConsentStatus.UNKNOWN;
        bool = false;
        break;
      case 2:
        consentStatus = ConsentStatus.NON_PERSONALIZED;
        bool = false;
        break;
      case 1:
        consentStatus = ConsentStatus.PERSONALIZED;
        bool = false;
        break;
      case 0:
        consentStatus = ConsentStatus.UNKNOWN;
        break;
    } 
    ConsentInformation.getInstance(this.context).setConsentStatus(consentStatus, "form");
    this.listener.onConsentFormClosed(consentStatus, Boolean.valueOf(bool));
  }
  
  private void handleLoadComplete(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      this.loadState = LoadState.NOT_READY;
      this.listener.onConsentFormError("No information");
      return;
    } 
    if (paramString.contains("Error")) {
      this.loadState = LoadState.NOT_READY;
      this.listener.onConsentFormError(paramString);
      return;
    } 
    this.loadState = LoadState.LOADED;
    this.listener.onConsentFormLoaded();
  }
  
  private void handleOpenBrowser(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      this.listener.onConsentFormError("No valid URL for browser navigation.");
      return;
    } 
    try {
      Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
      this.context.startActivity(intent);
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      this.listener.onConsentFormError("No Activity found to handle browser intent.");
      return;
    } 
  }
  
  private void updateDialogContent(WebView paramWebView) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("app_name", getApplicationName(this.context));
    hashMap.put("app_icon", getAppIconURIString(this.context));
    hashMap.put("offer_personalized", Boolean.valueOf(this.personalizedAdsOption));
    hashMap.put("offer_non_personalized", Boolean.valueOf(this.nonPersonalizedAdsOption));
    hashMap.put("offer_ad_free", Boolean.valueOf(this.adFreeOption));
    hashMap.put("is_request_in_eea_or_unknown", Boolean.valueOf(ConsentInformation.getInstance(this.context).isRequestLocationInEeaOrUnknown()));
    hashMap.put("app_privacy_url", this.appPrivacyPolicyURL);
    ConsentData consentData = ConsentInformation.getInstance(this.context).loadConsentData();
    hashMap.put("plat", consentData.getSDKPlatformString());
    hashMap.put("consent_info", consentData);
    paramWebView.loadUrl(createJavascriptCommand("setUpConsentDialog", (new Gson()).toJson(hashMap)));
  }
  
  public boolean isShowing() {
    return this.dialog.isShowing();
  }
  
  public void load() {
    LoadState loadState1 = this.loadState;
    LoadState loadState2 = LoadState.LOADING;
    if (loadState1 == loadState2) {
      this.listener.onConsentFormError("Cannot simultaneously load multiple consent forms.");
      return;
    } 
    if (loadState1 == LoadState.LOADED) {
      this.listener.onConsentFormLoaded();
      return;
    } 
    this.loadState = loadState2;
    this.webView.loadUrl("file:///android_asset/consentform.html");
  }
  
  public void show() {
    if (this.loadState != LoadState.LOADED) {
      this.listener.onConsentFormError("Consent form is not ready to be displayed.");
      return;
    } 
    if (ConsentInformation.getInstance(this.context).isTaggedForUnderAgeOfConsent()) {
      this.listener.onConsentFormError("Error: tagged for under age of consent");
      return;
    } 
    this.dialog.getWindow().setLayout(-1, -1);
    s30.J0(0, this.dialog.getWindow());
    this.dialog.setOnShowListener(new DialogInterface.OnShowListener() {
          public void onShow(DialogInterface param1DialogInterface) {
            ConsentForm.this.listener.onConsentFormOpened();
          }
        });
    this.dialog.show();
    if (!this.dialog.isShowing())
      this.listener.onConsentFormError("Consent form could not be displayed."); 
  }
  
  public static class Builder {
    private boolean adFreeOption;
    
    private final URL appPrivacyPolicyURL;
    
    private final Context context;
    
    private ConsentFormListener listener;
    
    private boolean nonPersonalizedAdsOption;
    
    private boolean personalizedAdsOption;
    
    public Builder(Context param1Context, URL param1URL) {
      this.context = param1Context;
      this.personalizedAdsOption = false;
      this.nonPersonalizedAdsOption = false;
      this.adFreeOption = false;
      this.appPrivacyPolicyURL = param1URL;
      if (param1URL != null)
        return; 
      throw new IllegalArgumentException("Must provide valid app privacy policy url to create a ConsentForm");
    }
    
    public ConsentForm build() {
      return new ConsentForm(this);
    }
    
    public Builder withAdFreeOption() {
      this.adFreeOption = true;
      return this;
    }
    
    public Builder withListener(ConsentFormListener param1ConsentFormListener) {
      this.listener = param1ConsentFormListener;
      return this;
    }
    
    public Builder withNonPersonalizedAdsOption() {
      this.nonPersonalizedAdsOption = true;
      return this;
    }
    
    public Builder withPersonalizedAdsOption() {
      this.personalizedAdsOption = true;
      return this;
    }
  }
  
  public enum LoadState {
    LOADED, LOADING, NOT_READY;
    
    static {
      LoadState loadState1 = new LoadState("NOT_READY", 0);
      NOT_READY = loadState1;
      LoadState loadState2 = new LoadState("LOADING", 1);
      LOADING = loadState2;
      LoadState loadState3 = new LoadState("LOADED", 2);
      LOADED = loadState3;
      $VALUES = new LoadState[] { loadState1, loadState2, loadState3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\google\ads\consent\ConsentForm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */