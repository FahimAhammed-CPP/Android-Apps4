package com.core.reminder.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;

public class AlarmReceiver extends BroadcastReceiver {
  public static final String a = AlarmReceiver.class.getSimpleName();
  
  public Context b;
  
  public Bitmap c;
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   5: ldc 2131230827
    //   7: invokestatic decodeResource : (Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;
    //   10: putfield c : Landroid/graphics/Bitmap;
    //   13: aload_0
    //   14: aload_1
    //   15: putfield b : Landroid/content/Context;
    //   18: getstatic android/os/Build$VERSION.SDK_INT : I
    //   21: istore #4
    //   23: iload #4
    //   25: bipush #31
    //   27: if_icmplt -> 133
    //   30: aload_1
    //   31: invokestatic t : (Landroid/content/Context;)Z
    //   34: ifeq -> 133
    //   37: aload_2
    //   38: ifnull -> 133
    //   41: aload_2
    //   42: invokevirtual getAction : ()Ljava/lang/String;
    //   45: ifnull -> 133
    //   48: aload_2
    //   49: invokevirtual getAction : ()Ljava/lang/String;
    //   52: invokevirtual isEmpty : ()Z
    //   55: ifne -> 133
    //   58: aload_2
    //   59: invokevirtual getAction : ()Ljava/lang/String;
    //   62: ldc 'android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED'
    //   64: invokevirtual equals : (Ljava/lang/Object;)Z
    //   67: ifeq -> 133
    //   70: aload_0
    //   71: getfield b : Landroid/content/Context;
    //   74: invokestatic t : (Landroid/content/Context;)Z
    //   77: ifeq -> 133
    //   80: new ak0
    //   83: dup
    //   84: aload_0
    //   85: getfield b : Landroid/content/Context;
    //   88: invokespecial <init> : (Landroid/content/Context;)V
    //   91: sipush #333
    //   94: invokevirtual d : (I)V
    //   97: invokestatic u : ()Ldk0;
    //   100: astore #6
    //   102: invokestatic a : ()Ljava/lang/String;
    //   105: astore #7
    //   107: aload #6
    //   109: getfield c : Landroid/content/SharedPreferences$Editor;
    //   112: ldc 'app_use_date'
    //   114: aload #7
    //   116: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   121: pop
    //   122: aload #6
    //   124: getfield c : Landroid/content/SharedPreferences$Editor;
    //   127: invokeinterface commit : ()Z
    //   132: pop
    //   133: aload_1
    //   134: invokestatic t : (Landroid/content/Context;)Z
    //   137: ifeq -> 833
    //   140: aload_2
    //   141: ifnull -> 833
    //   144: aload_2
    //   145: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   148: ifnull -> 833
    //   151: aload_2
    //   152: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   155: ldc 'code'
    //   157: invokevirtual getInt : (Ljava/lang/String;)I
    //   160: istore #5
    //   162: iload #5
    //   164: sipush #333
    //   167: if_icmpeq -> 173
    //   170: goto -> 706
    //   173: aload_2
    //   174: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   177: ldc 'code'
    //   179: invokevirtual getInt : (Ljava/lang/String;)I
    //   182: pop
    //   183: invokestatic u : ()Ldk0;
    //   186: getfield b : Landroid/content/SharedPreferences;
    //   189: ldc 'open_notification'
    //   191: iconst_1
    //   192: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
    //   197: ifeq -> 706
    //   200: invokestatic u : ()Ldk0;
    //   203: invokevirtual x : ()Ljava/lang/Boolean;
    //   206: invokevirtual booleanValue : ()Z
    //   209: ifeq -> 706
    //   212: invokestatic u : ()Ldk0;
    //   215: invokevirtual y : ()Ljava/lang/String;
    //   218: astore #6
    //   220: invokestatic a : ()Ljava/lang/String;
    //   223: astore_2
    //   224: aload #6
    //   226: ifnull -> 342
    //   229: aload #6
    //   231: ldc ''
    //   233: invokevirtual equals : (Ljava/lang/Object;)Z
    //   236: ifne -> 342
    //   239: aload #6
    //   241: invokestatic d : (Ljava/lang/String;)Ljava/lang/String;
    //   244: astore #6
    //   246: aload_2
    //   247: invokestatic d : (Ljava/lang/String;)Ljava/lang/String;
    //   250: astore #7
    //   252: aload #6
    //   254: ldc 'MM.dd.yyyy'
    //   256: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Date;
    //   259: astore_2
    //   260: aload #7
    //   262: ldc 'MM.dd.yyyy'
    //   264: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Date;
    //   267: astore #6
    //   269: new java/lang/StringBuilder
    //   272: dup
    //   273: invokespecial <init> : ()V
    //   276: astore #7
    //   278: aload #7
    //   280: ldc 'from : '
    //   282: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   285: pop
    //   286: aload #7
    //   288: aload_2
    //   289: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   292: pop
    //   293: aload #7
    //   295: ldc ' to : '
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: pop
    //   301: aload #7
    //   303: aload #6
    //   305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   308: pop
    //   309: aload #7
    //   311: invokevirtual toString : ()Ljava/lang/String;
    //   314: pop
    //   315: aload_2
    //   316: ifnull -> 342
    //   319: aload #6
    //   321: ifnull -> 342
    //   324: aload_2
    //   325: aload #6
    //   327: invokestatic b : (Ljava/util/Date;Ljava/util/Date;)J
    //   330: ldc2_w 3
    //   333: lcmp
    //   334: iflt -> 342
    //   337: iconst_1
    //   338: istore_3
    //   339: goto -> 344
    //   342: iconst_0
    //   343: istore_3
    //   344: iload_3
    //   345: ifeq -> 706
    //   348: ldc 'It has been a few days since you have used the %1$s app.'
    //   350: iconst_1
    //   351: anewarray java/lang/Object
    //   354: dup
    //   355: iconst_0
    //   356: aload_1
    //   357: ldc 2131886211
    //   359: invokevirtual getString : (I)Ljava/lang/String;
    //   362: aastore
    //   363: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   366: astore #7
    //   368: aload_1
    //   369: ldc 2131886211
    //   371: invokevirtual getString : (I)Ljava/lang/String;
    //   374: astore #6
    //   376: new android/content/Intent
    //   379: dup
    //   380: aload_1
    //   381: ldc com/ui/activity/SplashActivity
    //   383: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   386: astore_2
    //   387: aload_2
    //   388: ldc 268468224
    //   390: invokevirtual setFlags : (I)Landroid/content/Intent;
    //   393: pop
    //   394: iload #4
    //   396: bipush #23
    //   398: if_icmplt -> 419
    //   401: aload_1
    //   402: invokestatic getInstance : ()Ljava/util/Calendar;
    //   405: invokevirtual getTimeInMillis : ()J
    //   408: l2i
    //   409: aload_2
    //   410: ldc 67108864
    //   412: invokestatic getActivity : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   415: astore_2
    //   416: goto -> 434
    //   419: aload_1
    //   420: invokestatic getInstance : ()Ljava/util/Calendar;
    //   423: invokevirtual getTimeInMillis : ()J
    //   426: l2i
    //   427: aload_2
    //   428: ldc 1073741824
    //   430: invokestatic getActivity : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   433: astore_2
    //   434: new ca
    //   437: dup
    //   438: invokespecial <init> : ()V
    //   441: astore #8
    //   443: aload #8
    //   445: aload #7
    //   447: invokevirtual j : (Ljava/lang/CharSequence;)Lca;
    //   450: pop
    //   451: aload #8
    //   453: aload_1
    //   454: ldc 2131886211
    //   456: invokevirtual getString : (I)Ljava/lang/String;
    //   459: invokestatic c : (Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    //   462: putfield b : Ljava/lang/CharSequence;
    //   465: aload #8
    //   467: aload #6
    //   469: invokestatic c : (Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    //   472: putfield c : Ljava/lang/CharSequence;
    //   475: aload #8
    //   477: iconst_1
    //   478: putfield d : Z
    //   481: iload #4
    //   483: bipush #26
    //   485: if_icmplt -> 541
    //   488: aload_1
    //   489: ldc 2131886445
    //   491: invokevirtual getString : (I)Ljava/lang/String;
    //   494: astore #6
    //   496: new android/app/NotificationChannel
    //   499: dup
    //   500: aload #6
    //   502: ldc 'Application_name'
    //   504: iconst_3
    //   505: invokespecial <init> : (Ljava/lang/String;Ljava/lang/CharSequence;I)V
    //   508: astore #9
    //   510: aload #9
    //   512: ldc 'Application_name Alert'
    //   514: invokevirtual setDescription : (Ljava/lang/String;)V
    //   517: aload #9
    //   519: iconst_1
    //   520: invokevirtual enableVibration : (Z)V
    //   523: aload_1
    //   524: ldc_w 'notification'
    //   527: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   530: checkcast android/app/NotificationManager
    //   533: aload #9
    //   535: invokevirtual createNotificationChannel : (Landroid/app/NotificationChannel;)V
    //   538: goto -> 544
    //   541: aconst_null
    //   542: astore #6
    //   544: new da
    //   547: dup
    //   548: aload_1
    //   549: aload #6
    //   551: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;)V
    //   554: astore #6
    //   556: aload #6
    //   558: getfield B : Landroid/app/Notification;
    //   561: ldc_w 2131231540
    //   564: putfield icon : I
    //   567: aload #6
    //   569: aload_1
    //   570: ldc 2131886211
    //   572: invokevirtual getString : (I)Ljava/lang/String;
    //   575: invokevirtual e : (Ljava/lang/CharSequence;)Lda;
    //   578: pop
    //   579: aload #6
    //   581: aload #7
    //   583: invokevirtual d : (Ljava/lang/CharSequence;)Lda;
    //   586: pop
    //   587: aload #6
    //   589: getfield m : Lea;
    //   592: aload #8
    //   594: if_acmpeq -> 611
    //   597: aload #6
    //   599: aload #8
    //   601: putfield m : Lea;
    //   604: aload #8
    //   606: aload #6
    //   608: invokevirtual i : (Lda;)V
    //   611: aload #6
    //   613: aload_0
    //   614: getfield c : Landroid/graphics/Bitmap;
    //   617: invokevirtual g : (Landroid/graphics/Bitmap;)Lda;
    //   620: pop
    //   621: aload #6
    //   623: aload_1
    //   624: ldc_w 2131099720
    //   627: invokestatic getColor : (Landroid/content/Context;I)I
    //   630: putfield w : I
    //   633: aload #6
    //   635: getfield B : Landroid/app/Notification;
    //   638: iconst_2
    //   639: newarray long
    //   641: dup
    //   642: iconst_0
    //   643: ldc2_w 1000
    //   646: lastore
    //   647: dup
    //   648: iconst_1
    //   649: ldc2_w 1000
    //   652: lastore
    //   653: putfield vibrate : [J
    //   656: aload #6
    //   658: getstatic android/provider/Settings$System.DEFAULT_NOTIFICATION_URI : Landroid/net/Uri;
    //   661: invokevirtual h : (Landroid/net/Uri;)Lda;
    //   664: pop
    //   665: aload #6
    //   667: iconst_1
    //   668: putfield j : I
    //   671: aload #6
    //   673: bipush #16
    //   675: iconst_1
    //   676: invokevirtual f : (IZ)V
    //   679: aload #6
    //   681: aload_2
    //   682: putfield g : Landroid/app/PendingIntent;
    //   685: aload_1
    //   686: ldc_w 'notification'
    //   689: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   692: checkcast android/app/NotificationManager
    //   695: sipush #3730
    //   698: aload #6
    //   700: invokevirtual a : ()Landroid/app/Notification;
    //   703: invokevirtual notify : (ILandroid/app/Notification;)V
    //   706: new ak0
    //   709: dup
    //   710: aload_1
    //   711: invokespecial <init> : (Landroid/content/Context;)V
    //   714: astore_1
    //   715: new java/text/SimpleDateFormat
    //   718: dup
    //   719: ldc_w 'h:mm a'
    //   722: invokestatic getDefault : ()Ljava/util/Locale;
    //   725: invokespecial <init> : (Ljava/lang/String;Ljava/util/Locale;)V
    //   728: astore #6
    //   730: invokestatic getInstance : ()Ljava/util/Calendar;
    //   733: astore_2
    //   734: invokestatic u : ()Ldk0;
    //   737: invokevirtual C : ()Ljava/lang/String;
    //   740: astore #7
    //   742: aload #7
    //   744: ifnull -> 833
    //   747: aload #7
    //   749: invokevirtual isEmpty : ()Z
    //   752: ifne -> 833
    //   755: aload #6
    //   757: aload #7
    //   759: invokevirtual parse : (Ljava/lang/String;)Ljava/util/Date;
    //   762: astore #6
    //   764: aload #6
    //   766: ifnull -> 833
    //   769: invokestatic getInstance : ()Ljava/util/Calendar;
    //   772: astore #7
    //   774: aload #7
    //   776: aload #6
    //   778: invokevirtual setTime : (Ljava/util/Date;)V
    //   781: aload_2
    //   782: iconst_5
    //   783: iconst_1
    //   784: invokevirtual add : (II)V
    //   787: aload_2
    //   788: bipush #11
    //   790: aload #7
    //   792: bipush #11
    //   794: invokevirtual get : (I)I
    //   797: invokevirtual set : (II)V
    //   800: aload_2
    //   801: bipush #12
    //   803: aload #7
    //   805: bipush #12
    //   807: invokevirtual get : (I)I
    //   810: invokevirtual set : (II)V
    //   813: aload_2
    //   814: bipush #13
    //   816: iconst_0
    //   817: invokevirtual set : (II)V
    //   820: aload_1
    //   821: aload_2
    //   822: iload #5
    //   824: invokevirtual e : (Ljava/util/Calendar;I)V
    //   827: return
    //   828: astore_1
    //   829: aload_1
    //   830: invokevirtual printStackTrace : ()V
    //   833: return
    // Exception table:
    //   from	to	target	type
    //   734	742	828	java/text/ParseException
    //   747	764	828	java/text/ParseException
    //   769	827	828	java/text/ParseException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\core\reminder\broadcastreceiver\AlarmReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */