package com.core.reminder.broadcastreceiver;

import ak0;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import dk0;

public class AlarmBootReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent.getAction() != null && paramIntent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
      ak0 ak0 = new ak0(paramContext);
      if (dk0.u().x().booleanValue())
        ak0.d(333); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\core\reminder\broadcastreceiver\AlarmBootReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */