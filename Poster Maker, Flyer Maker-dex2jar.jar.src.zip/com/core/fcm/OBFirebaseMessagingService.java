package com.core.fcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import ba;
import bg0;
import ca;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.ui.activity.SplashActivity;
import da;
import df0;
import ea;
import lu2;
import ma;
import oe0;
import qo;
import wd0;
import wk1;

public class OBFirebaseMessagingService extends FirebaseMessagingService {
  public static final String b = OBFirebaseMessagingService.class.getSimpleName();
  
  public Bitmap c;
  
  public final void b(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Bitmap paramBitmap) {
    PendingIntent pendingIntent;
    Intent intent = new Intent((Context)this, SplashActivity.class);
    intent.putExtra("click_action_type", paramString3);
    intent.putExtra("search_query", paramString5);
    intent.putExtra("app_update_android", paramString4);
    intent.setFlags(335577088);
    stopService(intent);
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      pendingIntent = PendingIntent.getActivity((Context)this, 0, intent, 67108864);
    } else {
      pendingIntent = PendingIntent.getActivity((Context)this, 0, intent, 1073741824);
    } 
    if (i >= 26 && lu2.t((Context)this)) {
      paramString4 = getString(2131886445);
      NotificationChannel notificationChannel = new NotificationChannel(paramString4, "Application_name", 3);
      notificationChannel.setDescription("Application_name Alert");
      notificationChannel.enableVibration(true);
      ((NotificationManager)getSystemService("notification")).createNotificationChannel(notificationChannel);
    } else {
      paramString4 = null;
    } 
    da da = new da((Context)this, paramString4);
    da.e(paramString1);
    da.d(paramString2);
    ca ca = new ca();
    ca.j(paramString2);
    if (da.m != ca) {
      da.m = (ea)ca;
      ca.i(da);
    } 
    da.B.icon = 2131231540;
    da.w = ma.getColor((Context)this, 2131099717);
    da.f(16, true);
    da.B.vibrate = new long[] { 1000L, 1000L };
    da.h(Settings.System.DEFAULT_NOTIFICATION_URI);
    da.j = 1;
    da.g = pendingIntent;
    if (paramBitmap != null) {
      ba ba = new ba();
      ba.e = paramBitmap;
      if (da.m != ba) {
        da.m = (ea)ba;
        ba.i(da);
      } 
    } 
    Bitmap bitmap = this.c;
    if (bitmap != null)
      da.g(bitmap); 
    ((NotificationManager)getSystemService("notification")).notify(0, da.a());
  }
  
  public void onMessageReceived(RemoteMessage paramRemoteMessage) {
    this.c = BitmapFactory.decodeResource(getResources(), 2131230827);
    if (paramRemoteMessage.getNotification() != null) {
      String str1;
      String str3;
      Uri uri;
      String str4;
      String str5;
      String str2 = paramRemoteMessage.getNotification().getTitle();
      String str6 = "";
      if (str2 != null) {
        str2 = paramRemoteMessage.getNotification().getTitle();
      } else {
        str2 = "";
      } 
      if (paramRemoteMessage.getNotification().getBody() != null) {
        str3 = paramRemoteMessage.getNotification().getBody();
      } else {
        str3 = "";
      } 
      if (paramRemoteMessage.getNotification().getImageUrl() != null) {
        uri = paramRemoteMessage.getNotification().getImageUrl();
      } else {
        uri = null;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Notification Message imageUrl: ");
      stringBuilder.append(uri);
      stringBuilder.toString();
      if (paramRemoteMessage.getData() != null && paramRemoteMessage.getData().size() > 0) {
        paramRemoteMessage.getData().size();
        str6 = (String)paramRemoteMessage.getData().get("click_action_type");
        str4 = (String)paramRemoteMessage.getData().get("search_query");
        str5 = (String)paramRemoteMessage.getData().get("app_update_android");
        str1 = str6;
      } else {
        str5 = "";
        str4 = str5;
        str1 = str6;
      } 
      if (uri != null && !uri.toString().isEmpty()) {
        wk1 wk1 = (wk1)qo.D1(getApplicationContext()).r().L(uri);
        wk1.E((oe0)new bg0(this, str2, str3, str1, str5, str4), null, (wd0)wk1, df0.a);
        return;
      } 
      b(str2, str3, str1, str5, str4, null);
    } 
  }
  
  public void onNewToken(String paramString) {
    super.onNewToken(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\core\fcm\OBFirebaseMessagingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */