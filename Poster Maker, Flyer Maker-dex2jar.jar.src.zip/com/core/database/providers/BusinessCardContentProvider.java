package com.core.database.providers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import qo;
import rf0;
import s30;
import zf0;

public class BusinessCardContentProvider extends ContentProvider {
  public static Uri b;
  
  public static Uri c;
  
  public static Uri d;
  
  public static Uri f;
  
  public static Uri g;
  
  public static Uri p;
  
  public static Uri q;
  
  public static Context r;
  
  public String s = "BusinessCardContentProvider";
  
  public zf0 t;
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    SQLiteDatabase sQLiteDatabase = rf0.h().getWritableDatabase();
    switch (this.t.a(paramUri).ordinal()) {
      default:
        throw new IllegalArgumentException(s30.e0("Unknown URI ", paramUri));
      case 6:
        i = sQLiteDatabase.delete("tbl_advertise_master", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 5:
        i = sQLiteDatabase.delete("tbl_re_edit", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 4:
        i = sQLiteDatabase.delete("sync_history", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 3:
        i = sQLiteDatabase.delete("Tbl_sample_master", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 2:
        i = sQLiteDatabase.delete("tbl_purchase_queue", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 1:
        i = sQLiteDatabase.delete("tbl_purchase_items", paramString, paramArrayOfString);
        getContext().getContentResolver().notifyChange(paramUri, null);
        return i;
      case 0:
        break;
    } 
    int i = sQLiteDatabase.delete("user_master", paramString, paramArrayOfString);
    getContext().getContentResolver().notifyChange(paramUri, null);
    return i;
  }
  
  public String getType(Uri paramUri) {
    return (this.t.a(paramUri)).contentType;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    SQLiteDatabase sQLiteDatabase = rf0.h().getWritableDatabase();
    int i = this.t.a(paramUri).ordinal();
    Uri uri = null;
    if (i != 0) {
      if (i != 1) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              if (i == 6) {
                long l = sQLiteDatabase.insert("tbl_advertise_master", "", paramContentValues);
                paramUri = uri;
                if (l > 0L) {
                  paramUri = ContentUris.withAppendedId(p, l);
                  getContext().getContentResolver().notifyChange(paramUri, null);
                } 
              } else {
                throw new SQLException(s30.e0("Failed to add a record into ", paramUri));
              } 
            } else {
              long l = sQLiteDatabase.insert("tbl_re_edit", "", paramContentValues);
              paramUri = uri;
              if (l > 0L) {
                paramUri = ContentUris.withAppendedId(g, l);
                getContext().getContentResolver().notifyChange(paramUri, null);
              } 
            } 
          } else {
            long l = sQLiteDatabase.insert("sync_history", "", paramContentValues);
            paramUri = uri;
            if (l > 0L) {
              paramUri = ContentUris.withAppendedId(f, l);
              getContext().getContentResolver().notifyChange(paramUri, null);
            } 
          } 
        } else {
          long l = sQLiteDatabase.insert("Tbl_sample_master", "", paramContentValues);
          paramUri = uri;
          if (l > 0L) {
            paramUri = ContentUris.withAppendedId(d, l);
            getContext().getContentResolver().notifyChange(paramUri, null);
          } 
        } 
      } else {
        long l = sQLiteDatabase.insert("tbl_purchase_items", "", paramContentValues);
        paramUri = uri;
        if (l > 0L) {
          paramUri = ContentUris.withAppendedId(c, l);
          getContext().getContentResolver().notifyChange(paramUri, null);
        } 
      } 
    } else {
      long l = sQLiteDatabase.insert("user_master", "", paramContentValues);
      paramUri = uri;
      if (l > 0L) {
        paramUri = ContentUris.withAppendedId(b, l);
        getContext().getContentResolver().notifyChange(paramUri, null);
      } 
    } 
    return paramUri;
  }
  
  public boolean onCreate() {
    Context context = getContext();
    r = context;
    if (rf0.c == null)
      rf0.c = new rf0(context); 
    rf0.h();
    this.t = new zf0(r);
    StringBuilder stringBuilder = s30.x0("content://");
    stringBuilder.append(r.getString(2131886210));
    q = Uri.parse(stringBuilder.toString());
    stringBuilder = s30.x0("BASE_CONTENT_URI: ");
    stringBuilder.append(q);
    stringBuilder.toString();
    c = qo.l(r, "tbl_purchase_items");
    b = qo.l(r, "user_master");
    d = qo.l(r, "Tbl_sample_master");
    f = qo.l(r, "sync_history");
    g = qo.l(r, "tbl_re_edit");
    p = qo.l(r, "tbl_advertise_master");
    Uri.parse("content://media").buildUpon().appendPath("external_primary").appendPath("images").appendPath("media").build();
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    SQLiteDatabase sQLiteDatabase = rf0.h().getWritableDatabase();
    SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
    switch (this.t.a(paramUri).ordinal()) {
      default:
        throw new IllegalArgumentException(s30.e0("Unsupported URI: ", paramUri));
      case 6:
        sQLiteQueryBuilder.setTables("tbl_advertise_master");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 5:
        sQLiteQueryBuilder.setTables("tbl_re_edit");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 4:
        sQLiteQueryBuilder.setTables("sync_history");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 3:
        sQLiteQueryBuilder.setTables("Tbl_sample_master");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 2:
        sQLiteQueryBuilder.setTables("tbl_purchase_queue");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 1:
        sQLiteQueryBuilder.setTables("tbl_purchase_items");
        return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
      case 0:
        break;
    } 
    sQLiteQueryBuilder.setTables("user_master");
    return sQLiteQueryBuilder.query(sQLiteDatabase, paramArrayOfString1, paramString1, paramArrayOfString2, null, null, paramString2);
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    SQLiteDatabase sQLiteDatabase = rf0.h().getWritableDatabase();
    switch (this.t.a(paramUri).ordinal()) {
      default:
        throw new IllegalArgumentException(s30.e0("Unknown URI ", paramUri));
      case 6:
        i = sQLiteDatabase.update("tbl_advertise_master", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 5:
        i = sQLiteDatabase.update("tbl_re_edit", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 4:
        i = sQLiteDatabase.update("sync_history", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 3:
        i = sQLiteDatabase.update("Tbl_sample_master", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 2:
        i = sQLiteDatabase.update("tbl_purchase_queue", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 1:
        i = sQLiteDatabase.update("tbl_purchase_items", paramContentValues, paramString, paramArrayOfString);
        r.getContentResolver().notifyChange(paramUri, null);
        return i;
      case 0:
        break;
    } 
    int i = sQLiteDatabase.update("user_master", paramContentValues, paramString, paramArrayOfString);
    r.getContentResolver().notifyChange(paramUri, null);
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\com\core\database\providers\BusinessCardContentProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */