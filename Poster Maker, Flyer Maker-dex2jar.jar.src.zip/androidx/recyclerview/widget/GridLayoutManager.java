package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;
import km;
import oe;
import s30;

public class GridLayoutManager extends LinearLayoutManager {
  public boolean b = false;
  
  public int c = -1;
  
  public int[] d;
  
  public View[] f;
  
  public final SparseIntArray g = new SparseIntArray();
  
  public final SparseIntArray p = new SparseIntArray();
  
  public c q = new a();
  
  public final Rect r = new Rect();
  
  public GridLayoutManager(Context paramContext, int paramInt) {
    super(paramContext);
    i(paramInt);
  }
  
  public GridLayoutManager(Context paramContext, int paramInt1, int paramInt2, boolean paramBoolean) {
    super(paramContext, paramInt2, paramBoolean);
    i(paramInt1);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    i((RecyclerView.o.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2)).b);
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : [I
    //   4: astore #9
    //   6: aload_0
    //   7: getfield c : I
    //   10: istore #6
    //   12: iconst_1
    //   13: istore_3
    //   14: aload #9
    //   16: ifnull -> 45
    //   19: aload #9
    //   21: arraylength
    //   22: iload #6
    //   24: iconst_1
    //   25: iadd
    //   26: if_icmpne -> 45
    //   29: aload #9
    //   31: astore #8
    //   33: aload #9
    //   35: aload #9
    //   37: arraylength
    //   38: iconst_1
    //   39: isub
    //   40: iaload
    //   41: iload_1
    //   42: if_icmpeq -> 53
    //   45: iload #6
    //   47: iconst_1
    //   48: iadd
    //   49: newarray int
    //   51: astore #8
    //   53: iconst_0
    //   54: istore #4
    //   56: aload #8
    //   58: iconst_0
    //   59: iconst_0
    //   60: iastore
    //   61: iload_1
    //   62: iload #6
    //   64: idiv
    //   65: istore #5
    //   67: iload_1
    //   68: iload #6
    //   70: irem
    //   71: istore #7
    //   73: iconst_0
    //   74: istore_2
    //   75: iload #4
    //   77: istore_1
    //   78: iload_3
    //   79: iload #6
    //   81: if_icmpgt -> 137
    //   84: iload_1
    //   85: iload #7
    //   87: iadd
    //   88: istore_1
    //   89: iload_1
    //   90: ifle -> 116
    //   93: iload #6
    //   95: iload_1
    //   96: isub
    //   97: iload #7
    //   99: if_icmpge -> 116
    //   102: iload #5
    //   104: iconst_1
    //   105: iadd
    //   106: istore #4
    //   108: iload_1
    //   109: iload #6
    //   111: isub
    //   112: istore_1
    //   113: goto -> 120
    //   116: iload #5
    //   118: istore #4
    //   120: iload_2
    //   121: iload #4
    //   123: iadd
    //   124: istore_2
    //   125: aload #8
    //   127: iload_3
    //   128: iload_2
    //   129: iastore
    //   130: iload_3
    //   131: iconst_1
    //   132: iadd
    //   133: istore_3
    //   134: goto -> 78
    //   137: aload_0
    //   138: aload #8
    //   140: putfield d : [I
    //   143: return
  }
  
  public final void b() {
    View[] arrayOfView = this.f;
    if (arrayOfView == null || arrayOfView.length != this.c)
      this.f = new View[this.c]; 
  }
  
  public int c(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1 && isLayoutRTL()) {
      int[] arrayOfInt1 = this.d;
      int i = this.c;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.d;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public boolean checkLayoutParams(RecyclerView.p paramp) {
    return paramp instanceof b;
  }
  
  public void collectPrefetchPositionsForLayoutState(RecyclerView.a0 parama0, LinearLayoutManager.c paramc, RecyclerView.o.c paramc1) {
    int j = this.c;
    int i;
    for (i = 0; i < this.c && paramc.b(parama0) && j > 0; i++) {
      int k = paramc.d;
      int m = Math.max(0, paramc.g);
      ((km.b)paramc1).a(k, m);
      j -= this.q.c(k);
      paramc.d += paramc.e;
    } 
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.a0 parama0) {
    return super.computeHorizontalScrollOffset(parama0);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.a0 parama0) {
    return super.computeHorizontalScrollRange(parama0);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.a0 parama0) {
    return super.computeVerticalScrollOffset(parama0);
  }
  
  public int computeVerticalScrollRange(RecyclerView.a0 parama0) {
    return super.computeVerticalScrollRange(parama0);
  }
  
  public final int d(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.g)
      return this.q.a(paramInt, this.c); 
    paramInt = paramv.c(paramInt);
    return (paramInt == -1) ? 0 : this.q.a(paramInt, this.c);
  }
  
  public final int e(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.g)
      return this.q.b(paramInt, this.c); 
    int i = this.p.get(paramInt, -1);
    if (i != -1)
      return i; 
    paramInt = paramv.c(paramInt);
    return (paramInt == -1) ? 0 : this.q.b(paramInt, this.c);
  }
  
  public final int f(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.g)
      return this.q.c(paramInt); 
    int i = this.g.get(paramInt, -1);
    if (i != -1)
      return i; 
    paramInt = paramv.c(paramInt);
    return (paramInt == -1) ? 1 : this.q.c(paramInt);
  }
  
  public View findReferenceChild(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean1, boolean paramBoolean2) {
    int i = getChildCount();
    int j = -1;
    byte b = 1;
    if (paramBoolean2) {
      i = getChildCount() - 1;
      b = -1;
    } else {
      j = i;
      i = 0;
    } 
    int k = parama0.b();
    ensureLayoutState();
    int m = this.mOrientationHelper.k();
    int n = this.mOrientationHelper.g();
    View view2 = null;
    View view1;
    for (view1 = null; i != j; view1 = view4) {
      View view5 = getChildAt(i);
      int i1 = getPosition(view5);
      View view3 = view2;
      View view4 = view1;
      if (i1 >= 0) {
        view3 = view2;
        view4 = view1;
        if (i1 < k)
          if (e(paramv, parama0, i1) != 0) {
            view3 = view2;
            view4 = view1;
          } else if (((RecyclerView.p)view5.getLayoutParams()).isItemRemoved()) {
            view3 = view2;
            view4 = view1;
            if (view1 == null) {
              view4 = view5;
              view3 = view2;
            } 
          } else if (this.mOrientationHelper.e(view5) >= n || this.mOrientationHelper.b(view5) < m) {
            view3 = view2;
            view4 = view1;
            if (view2 == null) {
              view3 = view5;
              view4 = view1;
            } 
          } else {
            return view5;
          }  
      } 
      i += b;
      view2 = view3;
    } 
    return (view2 != null) ? view2 : view1;
  }
  
  public final void g(View paramView, int paramInt, boolean paramBoolean) {
    b b = (b)paramView.getLayoutParams();
    Rect rect = b.mDecorInsets;
    int j = rect.top + rect.bottom + b.topMargin + b.bottomMargin;
    int i = rect.left + rect.right + b.leftMargin + b.rightMargin;
    int k = c(b.a, b.b);
    if (this.mOrientation == 1) {
      i = RecyclerView.o.getChildMeasureSpec(k, paramInt, i, b.width, false);
      paramInt = RecyclerView.o.getChildMeasureSpec(this.mOrientationHelper.l(), getHeightMode(), j, b.height, true);
    } else {
      paramInt = RecyclerView.o.getChildMeasureSpec(k, paramInt, j, b.height, false);
      i = RecyclerView.o.getChildMeasureSpec(this.mOrientationHelper.l(), getWidthMode(), i, b.width, true);
    } 
    h(paramView, i, paramInt, paramBoolean);
  }
  
  public RecyclerView.p generateDefaultLayoutParams() {
    return (this.mOrientation == 0) ? new b(-2, -1) : new b(-1, -2);
  }
  
  public RecyclerView.p generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet) {
    return new b(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new b((ViewGroup.MarginLayoutParams)paramLayoutParams) : new b(paramLayoutParams);
  }
  
  public int getColumnCountForAccessibility(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.mOrientation == 1) ? this.c : ((parama0.b() < 1) ? 0 : (d(paramv, parama0, parama0.b() - 1) + 1));
  }
  
  public int getRowCountForAccessibility(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.mOrientation == 0) ? this.c : ((parama0.b() < 1) ? 0 : (d(paramv, parama0, parama0.b() - 1) + 1));
  }
  
  public final void h(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.p p = (RecyclerView.p)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = shouldReMeasureChild(paramView, paramInt1, paramInt2, p);
    } else {
      paramBoolean = shouldMeasureChild(paramView, paramInt1, paramInt2, p);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public void i(int paramInt) {
    if (paramInt == this.c)
      return; 
    this.b = true;
    if (paramInt >= 1) {
      this.c = paramInt;
      this.q.a.clear();
      requestLayout();
      return;
    } 
    throw new IllegalArgumentException(s30.Z("Span count should be at least 1. Provided ", paramInt));
  }
  
  public final void j() {
    int i;
    int j;
    if (getOrientation() == 1) {
      i = getWidth() - getPaddingRight();
      j = getPaddingLeft();
    } else {
      i = getHeight() - getPaddingBottom();
      j = getPaddingTop();
    } 
    a(i - j);
  }
  
  public void layoutChunk(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    int m;
    int n;
    int i2;
    int i3;
    int i4 = this.mOrientationHelper.j();
    if (i4 != 1073741824) {
      m = 1;
    } else {
      m = 0;
    } 
    if (getChildCount() > 0) {
      n = this.d[this.c];
    } else {
      n = 0;
    } 
    if (m)
      j(); 
    if (paramc.e == 1) {
      i1 = 1;
    } else {
      i1 = 0;
    } 
    int j = this.c;
    if (!i1)
      j = e(paramv, parama0, paramc.d) + f(paramv, parama0, paramc.d); 
    int i = 0;
    while (i < this.c && paramc.b(parama0) && j > 0) {
      k = paramc.d;
      i2 = f(paramv, parama0, k);
      if (i2 <= this.c) {
        j -= i2;
        if (j < 0)
          break; 
        View view = paramc.c(paramv);
        if (view == null)
          break; 
        this.f[i] = view;
        i++;
        continue;
      } 
      throw new IllegalArgumentException(s30.l0(s30.A0("Item at position ", k, " requires ", i2, " spans but GridLayoutManager has only "), this.c, " spans."));
    } 
    if (i == 0) {
      paramb.b = true;
      return;
    } 
    if (i1) {
      j = 0;
      i2 = i;
      k = 0;
      i3 = 1;
    } else {
      j = i - 1;
      i2 = -1;
      k = 0;
      i3 = -1;
    } 
    while (j != i2) {
      View view = this.f[j];
      b b1 = (b)view.getLayoutParams();
      int i5 = f(paramv, parama0, getPosition(view));
      b1.b = i5;
      b1.a = k;
      k += i5;
      j += i3;
    } 
    float f = 0.0F;
    int k = 0;
    for (j = 0; k < i; j = i2) {
      View view = this.f[k];
      if (paramc.k == null) {
        if (i1) {
          addView(view);
        } else {
          addView(view, 0);
        } 
      } else if (i1) {
        addDisappearingView(view);
      } else {
        addDisappearingView(view, 0);
      } 
      calculateItemDecorationsForChild(view, this.r);
      g(view, i4, false);
      i3 = this.mOrientationHelper.c(view);
      i2 = j;
      if (i3 > j)
        i2 = i3; 
      b b1 = (b)view.getLayoutParams();
      float f2 = this.mOrientationHelper.d(view) * 1.0F / b1.b;
      float f1 = f;
      if (f2 > f)
        f1 = f2; 
      k++;
      f = f1;
    } 
    k = j;
    if (m) {
      a(Math.max(Math.round(f * this.c), n));
      m = 0;
      j = 0;
      while (true) {
        k = j;
        if (m < i) {
          View view = this.f[m];
          g(view, 1073741824, true);
          n = this.mOrientationHelper.c(view);
          k = j;
          if (n > j)
            k = n; 
          m++;
          j = k;
          continue;
        } 
        break;
      } 
    } 
    for (j = 0; j < i; j++) {
      View view = this.f[j];
      if (this.mOrientationHelper.c(view) != k) {
        b b1 = (b)view.getLayoutParams();
        Rect rect = b1.mDecorInsets;
        n = rect.top + rect.bottom + b1.topMargin + b1.bottomMargin;
        m = rect.left + rect.right + b1.leftMargin + b1.rightMargin;
        i1 = c(b1.a, b1.b);
        if (this.mOrientation == 1) {
          m = RecyclerView.o.getChildMeasureSpec(i1, 1073741824, m, b1.width, false);
          n = View.MeasureSpec.makeMeasureSpec(k - n, 1073741824);
        } else {
          m = View.MeasureSpec.makeMeasureSpec(k - m, 1073741824);
          n = RecyclerView.o.getChildMeasureSpec(i1, 1073741824, n, b1.height, false);
        } 
        h(view, m, n, true);
      } 
    } 
    paramb.a = k;
    if (this.mOrientation == 1) {
      if (paramc.f == -1) {
        j = paramc.b;
        m = j - k;
        k = j;
        j = m;
      } else {
        j = paramc.b;
        k += j;
      } 
      m = 0;
      n = 0;
    } else {
      if (paramc.f == -1) {
        j = paramc.b;
        m = j;
        n = j - k;
      } else {
        j = paramc.b;
        n = j;
        m = k + j;
      } 
      j = 0;
      k = 0;
    } 
    int i1;
    for (i1 = 0; i1 < i; i1++) {
      View view = this.f[i1];
      b b1 = (b)view.getLayoutParams();
      if (this.mOrientation == 1) {
        if (isLayoutRTL()) {
          m = getPaddingLeft() + this.d[this.c - b1.a];
          n = m - this.mOrientationHelper.d(view);
        } else {
          m = getPaddingLeft();
          n = this.d[b1.a] + m;
          m = this.mOrientationHelper.d(view) + n;
        } 
      } else {
        k = getPaddingTop() + this.d[b1.a];
        i2 = this.mOrientationHelper.d(view);
        j = k;
        k = i2 + k;
      } 
      layoutDecoratedWithMargins(view, n, j, m, k);
      if (b1.isItemRemoved() || b1.isItemChanged())
        paramb.c = true; 
      paramb.d |= view.hasFocusable();
    } 
    Arrays.fill((Object[])this.f, (Object)null);
  }
  
  public void onAnchorReady(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.a parama, int paramInt) {
    super.onAnchorReady(paramv, parama0, parama, paramInt);
    j();
    if (parama0.b() > 0 && !parama0.g) {
      if (paramInt == 1) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      int i = e(paramv, parama0, parama.b);
      if (paramInt != 0) {
        while (i > 0) {
          paramInt = parama.b;
          if (paramInt > 0) {
            parama.b = --paramInt;
            i = e(paramv, parama0, paramInt);
          } 
        } 
      } else {
        int j = parama0.b();
        paramInt = parama.b;
        while (paramInt < j - 1) {
          int m = paramInt + 1;
          int k = e(paramv, parama0, m);
          if (k > i) {
            paramInt = m;
            i = k;
          } 
        } 
        parama.b = paramInt;
      } 
    } 
    b();
  }
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual findContainingItemView : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #22
    //   7: aconst_null
    //   8: astore #23
    //   10: aload #22
    //   12: ifnonnull -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload #22
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   25: astore #24
    //   27: aload #24
    //   29: getfield a : I
    //   32: istore #15
    //   34: aload #24
    //   36: getfield b : I
    //   39: iload #15
    //   41: iadd
    //   42: istore #16
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial onFocusSearchFailed : (Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual convertFocusDirectionToLayoutDirection : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #21
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #21
    //   76: iload #21
    //   78: aload_0
    //   79: getfield mShouldReverseLayout : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 112
    //   96: aload_0
    //   97: invokevirtual getChildCount : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore_2
    //   103: iconst_m1
    //   104: istore #5
    //   106: iconst_m1
    //   107: istore #8
    //   109: goto -> 123
    //   112: aload_0
    //   113: invokevirtual getChildCount : ()I
    //   116: istore #5
    //   118: iconst_0
    //   119: istore_2
    //   120: iconst_1
    //   121: istore #8
    //   123: aload_0
    //   124: getfield mOrientation : I
    //   127: iconst_1
    //   128: if_icmpne -> 144
    //   131: aload_0
    //   132: invokevirtual isLayoutRTL : ()Z
    //   135: ifeq -> 144
    //   138: iconst_1
    //   139: istore #9
    //   141: goto -> 147
    //   144: iconst_0
    //   145: istore #9
    //   147: aload_0
    //   148: aload_3
    //   149: aload #4
    //   151: iload_2
    //   152: invokevirtual d : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;I)I
    //   155: istore #17
    //   157: iload_2
    //   158: istore #11
    //   160: iconst_0
    //   161: istore #7
    //   163: iconst_m1
    //   164: istore #12
    //   166: iconst_m1
    //   167: istore #6
    //   169: iconst_0
    //   170: istore_2
    //   171: aconst_null
    //   172: astore_1
    //   173: iload #5
    //   175: istore #10
    //   177: iload #7
    //   179: istore #5
    //   181: iload #11
    //   183: iload #10
    //   185: if_icmpeq -> 564
    //   188: aload_0
    //   189: aload_3
    //   190: aload #4
    //   192: iload #11
    //   194: invokevirtual d : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;I)I
    //   197: istore #7
    //   199: aload_0
    //   200: iload #11
    //   202: invokevirtual getChildAt : (I)Landroid/view/View;
    //   205: astore #24
    //   207: aload #24
    //   209: aload #22
    //   211: if_acmpne -> 217
    //   214: goto -> 564
    //   217: aload #24
    //   219: invokevirtual hasFocusable : ()Z
    //   222: ifeq -> 243
    //   225: iload #7
    //   227: iload #17
    //   229: if_icmpeq -> 243
    //   232: aload #23
    //   234: ifnull -> 240
    //   237: goto -> 564
    //   240: goto -> 554
    //   243: aload #24
    //   245: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   248: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   251: astore #25
    //   253: aload #25
    //   255: getfield a : I
    //   258: istore #18
    //   260: aload #25
    //   262: getfield b : I
    //   265: iload #18
    //   267: iadd
    //   268: istore #19
    //   270: aload #24
    //   272: invokevirtual hasFocusable : ()Z
    //   275: ifeq -> 295
    //   278: iload #18
    //   280: iload #15
    //   282: if_icmpne -> 295
    //   285: iload #19
    //   287: iload #16
    //   289: if_icmpne -> 295
    //   292: aload #24
    //   294: areturn
    //   295: aload #24
    //   297: invokevirtual hasFocusable : ()Z
    //   300: ifeq -> 308
    //   303: aload #23
    //   305: ifnull -> 320
    //   308: aload #24
    //   310: invokevirtual hasFocusable : ()Z
    //   313: ifne -> 326
    //   316: aload_1
    //   317: ifnonnull -> 326
    //   320: iconst_1
    //   321: istore #7
    //   323: goto -> 473
    //   326: iload #18
    //   328: iload #15
    //   330: invokestatic max : (II)I
    //   333: istore #7
    //   335: iload #19
    //   337: iload #16
    //   339: invokestatic min : (II)I
    //   342: iload #7
    //   344: isub
    //   345: istore #20
    //   347: aload #24
    //   349: invokevirtual hasFocusable : ()Z
    //   352: ifeq -> 398
    //   355: iload #20
    //   357: iload #5
    //   359: if_icmple -> 365
    //   362: goto -> 320
    //   365: iload #20
    //   367: iload #5
    //   369: if_icmpne -> 470
    //   372: iload #18
    //   374: iload #12
    //   376: if_icmple -> 385
    //   379: iconst_1
    //   380: istore #7
    //   382: goto -> 388
    //   385: iconst_0
    //   386: istore #7
    //   388: iload #9
    //   390: iload #7
    //   392: if_icmpne -> 470
    //   395: goto -> 362
    //   398: aload #23
    //   400: ifnonnull -> 470
    //   403: iconst_1
    //   404: istore #14
    //   406: iconst_1
    //   407: istore #7
    //   409: aload_0
    //   410: aload #24
    //   412: iconst_0
    //   413: iconst_1
    //   414: invokevirtual isViewPartiallyVisible : (Landroid/view/View;ZZ)Z
    //   417: ifeq -> 470
    //   420: iload_2
    //   421: istore #13
    //   423: iload #20
    //   425: iload #13
    //   427: if_icmple -> 437
    //   430: iload #14
    //   432: istore #7
    //   434: goto -> 473
    //   437: iload #20
    //   439: iload #13
    //   441: if_icmpne -> 467
    //   444: iload #18
    //   446: iload #6
    //   448: if_icmple -> 454
    //   451: goto -> 457
    //   454: iconst_0
    //   455: istore #7
    //   457: iload #9
    //   459: iload #7
    //   461: if_icmpne -> 470
    //   464: goto -> 320
    //   467: goto -> 470
    //   470: iconst_0
    //   471: istore #7
    //   473: iload #7
    //   475: ifeq -> 554
    //   478: aload #24
    //   480: invokevirtual hasFocusable : ()Z
    //   483: ifeq -> 525
    //   486: aload #25
    //   488: getfield a : I
    //   491: istore #12
    //   493: iload #19
    //   495: iload #16
    //   497: invokestatic min : (II)I
    //   500: istore #5
    //   502: iload #18
    //   504: iload #15
    //   506: invokestatic max : (II)I
    //   509: istore #7
    //   511: aload #24
    //   513: astore #23
    //   515: iload #5
    //   517: iload #7
    //   519: isub
    //   520: istore #5
    //   522: goto -> 554
    //   525: aload #25
    //   527: getfield a : I
    //   530: istore #6
    //   532: iload #19
    //   534: iload #16
    //   536: invokestatic min : (II)I
    //   539: iload #18
    //   541: iload #15
    //   543: invokestatic max : (II)I
    //   546: isub
    //   547: istore_2
    //   548: aload #24
    //   550: astore_1
    //   551: goto -> 554
    //   554: iload #11
    //   556: iload #8
    //   558: iadd
    //   559: istore #11
    //   561: goto -> 181
    //   564: aload #23
    //   566: ifnull -> 572
    //   569: aload #23
    //   571: areturn
    //   572: aload_1
    //   573: areturn
  }
  
  public void onInitializeAccessibilityNodeInfoForItem(RecyclerView.v paramv, RecyclerView.a0 parama0, View paramView, oe paramoe) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof b)) {
      onInitializeAccessibilityNodeInfoForItem(paramView, paramoe);
      return;
    } 
    b b = (b)layoutParams;
    int i = d(paramv, parama0, b.getViewLayoutPosition());
    if (this.mOrientation == 0) {
      paramoe.j(oe.c.a(b.a, b.b, i, 1, false, false));
      return;
    } 
    paramoe.j(oe.c.a(i, 1, b.a, b.b, false, false));
  }
  
  public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.q.a.clear();
    this.q.b.clear();
  }
  
  public void onItemsChanged(RecyclerView paramRecyclerView) {
    this.q.a.clear();
    this.q.b.clear();
  }
  
  public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.q.a.clear();
    this.q.b.clear();
  }
  
  public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.q.a.clear();
    this.q.b.clear();
  }
  
  public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.q.a.clear();
    this.q.b.clear();
  }
  
  public void onLayoutChildren(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (parama0.g) {
      int j = getChildCount();
      for (int i = 0; i < j; i++) {
        b b = (b)getChildAt(i).getLayoutParams();
        int k = b.getViewLayoutPosition();
        this.g.put(k, b.b);
        this.p.put(k, b.a);
      } 
    } 
    super.onLayoutChildren(paramv, parama0);
    this.g.clear();
    this.p.clear();
  }
  
  public void onLayoutCompleted(RecyclerView.a0 parama0) {
    super.onLayoutCompleted(parama0);
    this.b = false;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    j();
    b();
    return super.scrollHorizontallyBy(paramInt, paramv, parama0);
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    j();
    b();
    return super.scrollVerticallyBy(paramInt, paramv, parama0);
  }
  
  public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.d == null)
      super.setMeasuredDimension(paramRect, paramInt1, paramInt2); 
    int i = getPaddingLeft();
    i = getPaddingRight() + i;
    int j = getPaddingTop();
    j = getPaddingBottom() + j;
    if (this.mOrientation == 1) {
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, paramRect.height() + j, getMinimumHeight());
      arrayOfInt = this.d;
      i = RecyclerView.o.chooseSize(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, getMinimumWidth());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, arrayOfInt.width() + i, getMinimumWidth());
      arrayOfInt = this.d;
      i = RecyclerView.o.chooseSize(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, getMinimumHeight());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    setMeasuredDimension(paramInt2, paramInt1);
  }
  
  public void setStackFromEnd(boolean paramBoolean) {
    if (!paramBoolean) {
      super.setStackFromEnd(false);
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public boolean supportsPredictiveItemAnimations() {
    return (this.mPendingSavedState == null && !this.b);
  }
  
  public static final class a extends c {
    public int b(int param1Int1, int param1Int2) {
      return param1Int1 % param1Int2;
    }
    
    public int c(int param1Int) {
      return 1;
    }
  }
  
  public static class b extends RecyclerView.p {
    public int a = -1;
    
    public int b = 0;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static abstract class c {
    public final SparseIntArray a = new SparseIntArray();
    
    public final SparseIntArray b = new SparseIntArray();
    
    public int a(int param1Int1, int param1Int2) {
      int m = c(param1Int1);
      int k = 0;
      int i = 0;
      int j;
      for (j = 0; k < param1Int1; j = n) {
        int n;
        int i1 = c(k);
        int i2 = i + i1;
        if (i2 == param1Int2) {
          n = j + 1;
          i = 0;
        } else {
          i = i2;
          n = j;
          if (i2 > param1Int2) {
            n = j + 1;
            i = i1;
          } 
        } 
        k++;
      } 
      param1Int1 = j;
      if (i + m > param1Int2)
        param1Int1 = j + 1; 
      return param1Int1;
    }
    
    public int b(int param1Int1, int param1Int2) {
      int k = c(param1Int1);
      if (k == param1Int2)
        return 0; 
      int j = 0;
      int i = 0;
      while (j < param1Int1) {
        int m = c(j);
        int n = i + m;
        if (n == param1Int2) {
          i = 0;
        } else {
          i = n;
          if (n > param1Int2)
            i = m; 
        } 
        j++;
      } 
      return (k + i <= param1Int2) ? i : 0;
    }
    
    public abstract int c(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\recyclerview\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */