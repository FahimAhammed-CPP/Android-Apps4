package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.activity.ComponentActivity;
import java.util.List;
import java.util.Objects;
import km;
import lm;
import pm;
import s30;
import um;

public class LinearLayoutManager extends RecyclerView.o implements lm.g, RecyclerView.z.b {
  public static final boolean DEBUG = false;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVALID_OFFSET = -2147483648;
  
  private static final float MAX_SCROLL_FACTOR = 0.33333334F;
  
  private static final String TAG = "LinearLayoutManager";
  
  public static final int VERTICAL = 1;
  
  public final a mAnchorInfo = new a();
  
  private int mInitialPrefetchItemCount = 2;
  
  private boolean mLastStackFromEnd;
  
  private final b mLayoutChunkResult = new b();
  
  private c mLayoutState;
  
  public int mOrientation = 1;
  
  public um mOrientationHelper;
  
  public d mPendingSavedState = null;
  
  public int mPendingScrollPosition = -1;
  
  public int mPendingScrollPositionOffset = Integer.MIN_VALUE;
  
  private boolean mRecycleChildrenOnDetach;
  
  private int[] mReusableIntPair = new int[2];
  
  private boolean mReverseLayout = false;
  
  public boolean mShouldReverseLayout = false;
  
  private boolean mSmoothScrollbarEnabled = true;
  
  private boolean mStackFromEnd = false;
  
  public LinearLayoutManager(Context paramContext) {
    this(paramContext, 1, false);
  }
  
  public LinearLayoutManager(Context paramContext, int paramInt, boolean paramBoolean) {
    setOrientation(paramInt);
    setReverseLayout(paramBoolean);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setOrientation(d1.a);
    setReverseLayout(d1.c);
    setStackFromEnd(d1.d);
  }
  
  private int computeScrollExtent(RecyclerView.a0 parama0) {
    if (getChildCount() == 0)
      return 0; 
    ensureLayoutState();
    return ComponentActivity.c.t(parama0, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled);
  }
  
  private int computeScrollOffset(RecyclerView.a0 parama0) {
    if (getChildCount() == 0)
      return 0; 
    ensureLayoutState();
    return ComponentActivity.c.u(parama0, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled, this.mShouldReverseLayout);
  }
  
  private int computeScrollRange(RecyclerView.a0 parama0) {
    if (getChildCount() == 0)
      return 0; 
    ensureLayoutState();
    return ComponentActivity.c.v(parama0, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled);
  }
  
  private View findFirstPartiallyOrCompletelyInvisibleChild() {
    return findOnePartiallyOrCompletelyInvisibleChild(0, getChildCount());
  }
  
  private View findLastPartiallyOrCompletelyInvisibleChild() {
    return findOnePartiallyOrCompletelyInvisibleChild(getChildCount() - 1, -1);
  }
  
  private View findPartiallyOrCompletelyInvisibleChildClosestToEnd() {
    return this.mShouldReverseLayout ? findFirstPartiallyOrCompletelyInvisibleChild() : findLastPartiallyOrCompletelyInvisibleChild();
  }
  
  private View findPartiallyOrCompletelyInvisibleChildClosestToStart() {
    return this.mShouldReverseLayout ? findLastPartiallyOrCompletelyInvisibleChild() : findFirstPartiallyOrCompletelyInvisibleChild();
  }
  
  private int fixLayoutEndGap(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = this.mOrientationHelper.g() - paramInt;
    if (i > 0) {
      i = -scrollBy(-i, paramv, parama0);
      if (paramBoolean) {
        paramInt = this.mOrientationHelper.g() - paramInt + i;
        if (paramInt > 0) {
          this.mOrientationHelper.p(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  private int fixLayoutStartGap(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = paramInt - this.mOrientationHelper.k();
    if (i > 0) {
      int j = -scrollBy(i, paramv, parama0);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.mOrientationHelper.k();
        i = j;
        if (paramInt > 0) {
          this.mOrientationHelper.p(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  private View getChildClosestToEnd() {
    int i;
    if (this.mShouldReverseLayout) {
      i = 0;
    } else {
      i = getChildCount() - 1;
    } 
    return getChildAt(i);
  }
  
  private View getChildClosestToStart() {
    boolean bool;
    if (this.mShouldReverseLayout) {
      bool = getChildCount() - 1;
    } else {
      bool = false;
    } 
    return getChildAt(bool);
  }
  
  private void layoutForPredictiveAnimations(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2) {
    if (parama0.k && getChildCount() != 0 && !parama0.g) {
      if (!supportsPredictiveItemAnimations())
        return; 
      List<RecyclerView.d0> list = paramv.d;
      int m = list.size();
      int n = getPosition(getChildAt(0));
      int i = 0;
      int k = 0;
      int j = 0;
      while (i < m) {
        RecyclerView.d0 d0 = list.get(i);
        if (!d0.isRemoved()) {
          boolean bool;
          int i1 = d0.getLayoutPosition();
          byte b1 = 1;
          if (i1 < n) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool != this.mShouldReverseLayout)
            b1 = -1; 
          if (b1 == -1) {
            k += this.mOrientationHelper.c(d0.itemView);
          } else {
            j += this.mOrientationHelper.c(d0.itemView);
          } 
        } 
        i++;
      } 
      this.mLayoutState.k = list;
      if (k > 0) {
        updateLayoutStateToFillStart(getPosition(getChildClosestToStart()), paramInt1);
        c c1 = this.mLayoutState;
        c1.h = k;
        c1.c = 0;
        c1.a(null);
        fill(paramv, this.mLayoutState, parama0, false);
      } 
      if (j > 0) {
        updateLayoutStateToFillEnd(getPosition(getChildClosestToEnd()), paramInt2);
        c c1 = this.mLayoutState;
        c1.h = j;
        c1.c = 0;
        c1.a(null);
        fill(paramv, this.mLayoutState, parama0, false);
      } 
      this.mLayoutState.k = null;
    } 
  }
  
  private void logChildren() {
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      getPosition(view);
      this.mOrientationHelper.e(view);
    } 
  }
  
  private void recycleByLayoutState(RecyclerView.v paramv, c paramc) {
    if (paramc.a) {
      if (paramc.l)
        return; 
      int i = paramc.g;
      int j = paramc.i;
      if (paramc.f == -1) {
        recycleViewsFromEnd(paramv, i, j);
        return;
      } 
      recycleViewsFromStart(paramv, i, j);
    } 
  }
  
  private void recycleChildren(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        removeAndRecycleViewAt(paramInt2, paramv);
        paramInt2--;
      } 
    } else {
      while (i > paramInt2) {
        removeAndRecycleViewAt(i, paramv);
        i--;
      } 
    } 
  }
  
  private void recycleViewsFromEnd(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    int j = getChildCount();
    if (paramInt1 < 0)
      return; 
    int i = this.mOrientationHelper.f() - paramInt1 + paramInt2;
    if (this.mShouldReverseLayout) {
      for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
        View view = getChildAt(paramInt1);
        if (this.mOrientationHelper.e(view) < i || this.mOrientationHelper.o(view) < i) {
          recycleChildren(paramv, 0, paramInt1);
          return;
        } 
      } 
    } else {
      paramInt2 = j - 1;
      for (paramInt1 = paramInt2; paramInt1 >= 0; paramInt1--) {
        View view = getChildAt(paramInt1);
        if (this.mOrientationHelper.e(view) < i || this.mOrientationHelper.o(view) < i) {
          recycleChildren(paramv, paramInt2, paramInt1);
          break;
        } 
      } 
    } 
  }
  
  private void recycleViewsFromStart(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      return; 
    int i = paramInt1 - paramInt2;
    paramInt2 = getChildCount();
    if (this.mShouldReverseLayout) {
      for (paramInt1 = --paramInt2; paramInt1 >= 0; paramInt1--) {
        View view = getChildAt(paramInt1);
        if (this.mOrientationHelper.b(view) > i || this.mOrientationHelper.n(view) > i) {
          recycleChildren(paramv, paramInt2, paramInt1);
          return;
        } 
      } 
    } else {
      for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
        View view = getChildAt(paramInt1);
        if (this.mOrientationHelper.b(view) > i || this.mOrientationHelper.n(view) > i) {
          recycleChildren(paramv, 0, paramInt1);
          break;
        } 
      } 
    } 
  }
  
  private void resolveShouldLayoutReverse() {
    if (this.mOrientation == 1 || !isLayoutRTL()) {
      this.mShouldReverseLayout = this.mReverseLayout;
      return;
    } 
    this.mShouldReverseLayout = this.mReverseLayout ^ true;
  }
  
  private boolean updateAnchorFromChildren(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return false; 
    View view2 = getFocusedChild();
    if (view2 != null) {
      Objects.requireNonNull(parama);
      RecyclerView.p p = (RecyclerView.p)view2.getLayoutParams();
      if (!p.isItemRemoved() && p.getViewLayoutPosition() >= 0 && p.getViewLayoutPosition() < parama0.b()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        parama.c(view2, getPosition(view2));
        return true;
      } 
    } 
    boolean bool1 = this.mLastStackFromEnd;
    boolean bool2 = this.mStackFromEnd;
    if (bool1 != bool2)
      return false; 
    View view1 = findReferenceChild(paramv, parama0, parama.d, bool2);
    if (view1 != null) {
      parama.b(view1, getPosition(view1));
      if (!parama0.g && supportsPredictiveItemAnimations()) {
        int m = this.mOrientationHelper.e(view1);
        int n = this.mOrientationHelper.b(view1);
        int k = this.mOrientationHelper.k();
        int j = this.mOrientationHelper.g();
        if (n <= k && m < k) {
          i = 1;
        } else {
          i = 0;
        } 
        boolean bool3 = bool;
        if (m >= j) {
          bool3 = bool;
          if (n > j)
            bool3 = true; 
        } 
        if (i != 0 || bool3) {
          i = k;
          if (parama.d)
            i = j; 
          parama.c = i;
        } 
      } 
      return true;
    } 
    return false;
  }
  
  private boolean updateAnchorFromPendingData(RecyclerView.a0 parama0, a parama) {
    boolean bool = parama0.g;
    boolean bool1 = false;
    if (!bool) {
      int i = this.mPendingScrollPosition;
      if (i == -1)
        return false; 
      if (i < 0 || i >= parama0.b()) {
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        return false;
      } 
      parama.b = this.mPendingScrollPosition;
      d d1 = this.mPendingSavedState;
      if (d1 != null && d1.a()) {
        bool = this.mPendingSavedState.d;
        parama.d = bool;
        if (bool) {
          parama.c = this.mOrientationHelper.g() - this.mPendingSavedState.c;
          return true;
        } 
        parama.c = this.mOrientationHelper.k() + this.mPendingSavedState.c;
        return true;
      } 
      if (this.mPendingScrollPositionOffset == Integer.MIN_VALUE) {
        View view = findViewByPosition(this.mPendingScrollPosition);
        if (view != null) {
          if (this.mOrientationHelper.c(view) > this.mOrientationHelper.l()) {
            parama.a();
            return true;
          } 
          if (this.mOrientationHelper.e(view) - this.mOrientationHelper.k() < 0) {
            parama.c = this.mOrientationHelper.k();
            parama.d = false;
            return true;
          } 
          if (this.mOrientationHelper.g() - this.mOrientationHelper.b(view) < 0) {
            parama.c = this.mOrientationHelper.g();
            parama.d = true;
            return true;
          } 
          if (parama.d) {
            i = this.mOrientationHelper.b(view);
            i = this.mOrientationHelper.m() + i;
          } else {
            i = this.mOrientationHelper.e(view);
          } 
          parama.c = i;
          return true;
        } 
        if (getChildCount() > 0) {
          i = getPosition(getChildAt(0));
          if (this.mPendingScrollPosition < i) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool == this.mShouldReverseLayout)
            bool1 = true; 
          parama.d = bool1;
        } 
        parama.a();
        return true;
      } 
      bool = this.mShouldReverseLayout;
      parama.d = bool;
      if (bool) {
        parama.c = this.mOrientationHelper.g() - this.mPendingScrollPositionOffset;
        return true;
      } 
      parama.c = this.mOrientationHelper.k() + this.mPendingScrollPositionOffset;
      return true;
    } 
    return false;
  }
  
  private void updateAnchorInfoForLayout(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    boolean bool;
    if (updateAnchorFromPendingData(parama0, parama))
      return; 
    if (updateAnchorFromChildren(paramv, parama0, parama))
      return; 
    parama.a();
    if (this.mStackFromEnd) {
      bool = parama0.b() - 1;
    } else {
      bool = false;
    } 
    parama.b = bool;
  }
  
  private void updateLayoutState(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.a0 parama0) {
    this.mLayoutState.l = resolveIsInfinite();
    this.mLayoutState.f = paramInt1;
    int[] arrayOfInt = this.mReusableIntPair;
    boolean bool1 = false;
    arrayOfInt[0] = 0;
    boolean bool2 = true;
    boolean bool3 = true;
    arrayOfInt[1] = 0;
    calculateExtraLayoutSpace(parama0, arrayOfInt);
    int i = Math.max(0, this.mReusableIntPair[0]);
    int j = Math.max(0, this.mReusableIntPair[1]);
    if (paramInt1 == 1)
      bool1 = true; 
    c c1 = this.mLayoutState;
    if (bool1) {
      paramInt1 = j;
    } else {
      paramInt1 = i;
    } 
    c1.h = paramInt1;
    if (!bool1)
      i = j; 
    c1.i = i;
    if (bool1) {
      c1.h = this.mOrientationHelper.h() + paramInt1;
      View view = getChildClosestToEnd();
      c c2 = this.mLayoutState;
      paramInt1 = bool3;
      if (this.mShouldReverseLayout)
        paramInt1 = -1; 
      c2.e = paramInt1;
      paramInt1 = getPosition(view);
      c c3 = this.mLayoutState;
      c2.d = paramInt1 + c3.e;
      c3.b = this.mOrientationHelper.b(view);
      paramInt1 = this.mOrientationHelper.b(view) - this.mOrientationHelper.g();
    } else {
      View view = getChildClosestToStart();
      c c2 = this.mLayoutState;
      paramInt1 = c2.h;
      c2.h = this.mOrientationHelper.k() + paramInt1;
      c2 = this.mLayoutState;
      if (this.mShouldReverseLayout) {
        paramInt1 = bool2;
      } else {
        paramInt1 = -1;
      } 
      c2.e = paramInt1;
      paramInt1 = getPosition(view);
      c c3 = this.mLayoutState;
      c2.d = paramInt1 + c3.e;
      c3.b = this.mOrientationHelper.e(view);
      paramInt1 = -this.mOrientationHelper.e(view) + this.mOrientationHelper.k();
    } 
    c1 = this.mLayoutState;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  private void updateLayoutStateToFillEnd(int paramInt1, int paramInt2) {
    boolean bool;
    this.mLayoutState.c = this.mOrientationHelper.g() - paramInt2;
    c c1 = this.mLayoutState;
    if (this.mShouldReverseLayout) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private void updateLayoutStateToFillEnd(a parama) {
    updateLayoutStateToFillEnd(parama.b, parama.c);
  }
  
  private void updateLayoutStateToFillStart(int paramInt1, int paramInt2) {
    this.mLayoutState.c = paramInt2 - this.mOrientationHelper.k();
    c c1 = this.mLayoutState;
    c1.d = paramInt1;
    if (this.mShouldReverseLayout) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private void updateLayoutStateToFillStart(a parama) {
    updateLayoutStateToFillStart(parama.b, parama.c);
  }
  
  public void assertNotInLayoutOrScroll(String paramString) {
    if (this.mPendingSavedState == null)
      super.assertNotInLayoutOrScroll(paramString); 
  }
  
  public void calculateExtraLayoutSpace(RecyclerView.a0 parama0, int[] paramArrayOfint) {
    int j;
    boolean bool;
    int i = getExtraLayoutSpace(parama0);
    if (this.mLayoutState.f == -1) {
      j = 0;
      bool = i;
    } else {
      bool = false;
      j = i;
    } 
    paramArrayOfint[0] = bool;
    paramArrayOfint[1] = j;
  }
  
  public boolean canScrollHorizontally() {
    return (this.mOrientation == 0);
  }
  
  public boolean canScrollVertically() {
    return (this.mOrientation == 1);
  }
  
  public void collectAdjacentPrefetchPositions(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.mOrientation != 0)
      paramInt1 = paramInt2; 
    if (getChildCount() != 0) {
      if (paramInt1 == 0)
        return; 
      ensureLayoutState();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      updateLayoutState(paramInt2, Math.abs(paramInt1), true, parama0);
      collectPrefetchPositionsForLayoutState(parama0, this.mLayoutState, paramc);
    } 
  }
  
  public void collectInitialPrefetchPositions(int paramInt, RecyclerView.o.c paramc) {
    int i;
    boolean bool;
    d d1 = this.mPendingSavedState;
    byte b1 = -1;
    if (d1 != null && d1.a()) {
      d1 = this.mPendingSavedState;
      bool = d1.d;
      i = d1.b;
    } else {
      resolveShouldLayoutReverse();
      boolean bool1 = this.mShouldReverseLayout;
      int k = this.mPendingScrollPosition;
      i = k;
      bool = bool1;
      if (k == -1)
        if (bool1) {
          i = paramInt - 1;
          bool = bool1;
        } else {
          i = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    int j;
    for (j = 0; j < this.mInitialPrefetchItemCount && i >= 0 && i < paramInt; j++) {
      ((km.b)paramc).a(i, 0);
      i += b1;
    } 
  }
  
  public void collectPrefetchPositionsForLayoutState(RecyclerView.a0 parama0, c paramc, RecyclerView.o.c paramc1) {
    int i = paramc.d;
    if (i >= 0 && i < parama0.b()) {
      int j = Math.max(0, paramc.g);
      ((km.b)paramc1).a(i, j);
    } 
  }
  
  public int computeHorizontalScrollExtent(RecyclerView.a0 parama0) {
    return computeScrollExtent(parama0);
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.a0 parama0) {
    return computeScrollOffset(parama0);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.a0 parama0) {
    return computeScrollRange(parama0);
  }
  
  public PointF computeScrollVectorForPosition(int paramInt) {
    if (getChildCount() == 0)
      return null; 
    boolean bool1 = false;
    int i = getPosition(getChildAt(0));
    boolean bool = true;
    if (paramInt < i)
      bool1 = true; 
    paramInt = bool;
    if (bool1 != this.mShouldReverseLayout)
      paramInt = -1; 
    return (this.mOrientation == 0) ? new PointF(paramInt, 0.0F) : new PointF(0.0F, paramInt);
  }
  
  public int computeVerticalScrollExtent(RecyclerView.a0 parama0) {
    return computeScrollExtent(parama0);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.a0 parama0) {
    return computeScrollOffset(parama0);
  }
  
  public int computeVerticalScrollRange(RecyclerView.a0 parama0) {
    return computeScrollRange(parama0);
  }
  
  public int convertFocusDirectionToLayoutDirection(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.mOrientation == 1) ? 1 : Integer.MIN_VALUE)) : ((this.mOrientation == 0) ? 1 : Integer.MIN_VALUE)) : ((this.mOrientation == 1) ? -1 : Integer.MIN_VALUE)) : ((this.mOrientation == 0) ? -1 : Integer.MIN_VALUE)) : ((this.mOrientation == 1) ? 1 : (isLayoutRTL() ? -1 : 1))) : ((this.mOrientation == 1) ? -1 : (isLayoutRTL() ? 1 : -1));
  }
  
  public c createLayoutState() {
    return new c();
  }
  
  public void ensureLayoutState() {
    if (this.mLayoutState == null)
      this.mLayoutState = createLayoutState(); 
  }
  
  public int fill(RecyclerView.v paramv, c paramc, RecyclerView.a0 parama0, boolean paramBoolean) {
    int k = paramc.c;
    int i = paramc.g;
    if (i != Integer.MIN_VALUE) {
      if (k < 0)
        paramc.g = i + k; 
      recycleByLayoutState(paramv, paramc);
    } 
    int j = paramc.c + paramc.h;
    b b1 = this.mLayoutChunkResult;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        j = i;
        if (b1.d)
          break; 
      } 
    } 
    return k - paramc.c;
  }
  
  public int findFirstCompletelyVisibleItemPosition() {
    View view = findOneVisibleChild(0, getChildCount(), true, false);
    return (view == null) ? -1 : getPosition(view);
  }
  
  public View findFirstVisibleChildClosestToEnd(boolean paramBoolean1, boolean paramBoolean2) {
    return this.mShouldReverseLayout ? findOneVisibleChild(0, getChildCount(), paramBoolean1, paramBoolean2) : findOneVisibleChild(getChildCount() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  public View findFirstVisibleChildClosestToStart(boolean paramBoolean1, boolean paramBoolean2) {
    return this.mShouldReverseLayout ? findOneVisibleChild(getChildCount() - 1, -1, paramBoolean1, paramBoolean2) : findOneVisibleChild(0, getChildCount(), paramBoolean1, paramBoolean2);
  }
  
  public int findFirstVisibleItemPosition() {
    View view = findOneVisibleChild(0, getChildCount(), false, true);
    return (view == null) ? -1 : getPosition(view);
  }
  
  public int findLastCompletelyVisibleItemPosition() {
    View view = findOneVisibleChild(getChildCount() - 1, -1, true, false);
    return (view == null) ? -1 : getPosition(view);
  }
  
  public int findLastVisibleItemPosition() {
    View view = findOneVisibleChild(getChildCount() - 1, -1, false, true);
    return (view == null) ? -1 : getPosition(view);
  }
  
  public View findOnePartiallyOrCompletelyInvisibleChild(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    ensureLayoutState();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return getChildAt(paramInt1); 
    if (this.mOrientationHelper.e(getChildAt(paramInt1)) < this.mOrientationHelper.k()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    return (this.mOrientation == 0) ? this.mHorizontalBoundCheck.a(paramInt1, paramInt2, c1, c2) : this.mVerticalBoundCheck.a(paramInt1, paramInt2, c1, c2);
  }
  
  public View findOneVisibleChild(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    ensureLayoutState();
    char c2 = 'ŀ';
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (!paramBoolean2)
      c2 = Character.MIN_VALUE; 
    return (this.mOrientation == 0) ? this.mHorizontalBoundCheck.a(paramInt1, paramInt2, c1, c2) : this.mVerticalBoundCheck.a(paramInt1, paramInt2, c1, c2);
  }
  
  public View findReferenceChild(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual ensureLayoutState : ()V
    //   4: aload_0
    //   5: invokevirtual getChildCount : ()I
    //   8: istore #5
    //   10: iconst_m1
    //   11: istore #6
    //   13: iload #4
    //   15: ifeq -> 32
    //   18: aload_0
    //   19: invokevirtual getChildCount : ()I
    //   22: iconst_1
    //   23: isub
    //   24: istore #5
    //   26: iconst_m1
    //   27: istore #7
    //   29: goto -> 42
    //   32: iload #5
    //   34: istore #6
    //   36: iconst_0
    //   37: istore #5
    //   39: iconst_1
    //   40: istore #7
    //   42: aload_2
    //   43: invokevirtual b : ()I
    //   46: istore #10
    //   48: aload_0
    //   49: getfield mOrientationHelper : Lum;
    //   52: invokevirtual k : ()I
    //   55: istore #11
    //   57: aload_0
    //   58: getfield mOrientationHelper : Lum;
    //   61: invokevirtual g : ()I
    //   64: istore #12
    //   66: aconst_null
    //   67: astore #15
    //   69: aconst_null
    //   70: astore #14
    //   72: aload #14
    //   74: astore_2
    //   75: iload #5
    //   77: iload #6
    //   79: if_icmpeq -> 349
    //   82: aload_0
    //   83: iload #5
    //   85: invokevirtual getChildAt : (I)Landroid/view/View;
    //   88: astore_1
    //   89: aload_0
    //   90: aload_1
    //   91: invokevirtual getPosition : (Landroid/view/View;)I
    //   94: istore #8
    //   96: aload_0
    //   97: getfield mOrientationHelper : Lum;
    //   100: aload_1
    //   101: invokevirtual e : (Landroid/view/View;)I
    //   104: istore #9
    //   106: aload_0
    //   107: getfield mOrientationHelper : Lum;
    //   110: aload_1
    //   111: invokevirtual b : (Landroid/view/View;)I
    //   114: istore #13
    //   116: aload #15
    //   118: astore #16
    //   120: aload #14
    //   122: astore #17
    //   124: aload_2
    //   125: astore #18
    //   127: iload #8
    //   129: iflt -> 328
    //   132: aload #15
    //   134: astore #16
    //   136: aload #14
    //   138: astore #17
    //   140: aload_2
    //   141: astore #18
    //   143: iload #8
    //   145: iload #10
    //   147: if_icmpge -> 328
    //   150: aload_1
    //   151: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   154: checkcast androidx/recyclerview/widget/RecyclerView$p
    //   157: invokevirtual isItemRemoved : ()Z
    //   160: ifeq -> 192
    //   163: aload #15
    //   165: astore #16
    //   167: aload #14
    //   169: astore #17
    //   171: aload_2
    //   172: astore #18
    //   174: aload_2
    //   175: ifnonnull -> 328
    //   178: aload #15
    //   180: astore #16
    //   182: aload #14
    //   184: astore #17
    //   186: aload_1
    //   187: astore #18
    //   189: goto -> 328
    //   192: iload #13
    //   194: iload #11
    //   196: if_icmpgt -> 212
    //   199: iload #9
    //   201: iload #11
    //   203: if_icmpge -> 212
    //   206: iconst_1
    //   207: istore #8
    //   209: goto -> 215
    //   212: iconst_0
    //   213: istore #8
    //   215: iload #9
    //   217: iload #12
    //   219: if_icmplt -> 235
    //   222: iload #13
    //   224: iload #12
    //   226: if_icmple -> 235
    //   229: iconst_1
    //   230: istore #9
    //   232: goto -> 238
    //   235: iconst_0
    //   236: istore #9
    //   238: iload #8
    //   240: ifne -> 253
    //   243: iload #9
    //   245: ifeq -> 251
    //   248: goto -> 253
    //   251: aload_1
    //   252: areturn
    //   253: iload_3
    //   254: ifeq -> 284
    //   257: iload #9
    //   259: ifeq -> 265
    //   262: goto -> 289
    //   265: aload #15
    //   267: astore #16
    //   269: aload #14
    //   271: astore #17
    //   273: aload_2
    //   274: astore #18
    //   276: aload #15
    //   278: ifnonnull -> 328
    //   281: goto -> 318
    //   284: iload #8
    //   286: ifeq -> 302
    //   289: aload #15
    //   291: astore #16
    //   293: aload_1
    //   294: astore #17
    //   296: aload_2
    //   297: astore #18
    //   299: goto -> 328
    //   302: aload #15
    //   304: astore #16
    //   306: aload #14
    //   308: astore #17
    //   310: aload_2
    //   311: astore #18
    //   313: aload #15
    //   315: ifnonnull -> 328
    //   318: aload_2
    //   319: astore #18
    //   321: aload #14
    //   323: astore #17
    //   325: aload_1
    //   326: astore #16
    //   328: iload #5
    //   330: iload #7
    //   332: iadd
    //   333: istore #5
    //   335: aload #16
    //   337: astore #15
    //   339: aload #17
    //   341: astore #14
    //   343: aload #18
    //   345: astore_2
    //   346: goto -> 75
    //   349: aload #15
    //   351: ifnull -> 357
    //   354: aload #15
    //   356: areturn
    //   357: aload #14
    //   359: ifnull -> 365
    //   362: aload #14
    //   364: areturn
    //   365: aload_2
    //   366: areturn
  }
  
  public View findViewByPosition(int paramInt) {
    int i = getChildCount();
    if (i == 0)
      return null; 
    int j = paramInt - getPosition(getChildAt(0));
    if (j >= 0 && j < i) {
      View view = getChildAt(j);
      if (getPosition(view) == paramInt)
        return view; 
    } 
    return super.findViewByPosition(paramInt);
  }
  
  public RecyclerView.p generateDefaultLayoutParams() {
    return new RecyclerView.p(-2, -2);
  }
  
  @Deprecated
  public int getExtraLayoutSpace(RecyclerView.a0 parama0) {
    boolean bool;
    if (parama0.a != -1) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? this.mOrientationHelper.l() : 0;
  }
  
  public int getInitialPrefetchItemCount() {
    return this.mInitialPrefetchItemCount;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public boolean getRecycleChildrenOnDetach() {
    return this.mRecycleChildrenOnDetach;
  }
  
  public boolean getReverseLayout() {
    return this.mReverseLayout;
  }
  
  public boolean getStackFromEnd() {
    return this.mStackFromEnd;
  }
  
  public boolean isAutoMeasureEnabled() {
    return true;
  }
  
  public boolean isLayoutRTL() {
    return (getLayoutDirection() == 1);
  }
  
  public boolean isSmoothScrollbarEnabled() {
    return this.mSmoothScrollbarEnabled;
  }
  
  public void layoutChunk(RecyclerView.v paramv, RecyclerView.a0 parama0, c paramc, b paramb) {
    int i;
    int j;
    int k;
    int m;
    View view = paramc.c(paramv);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool1;
      boolean bool2 = this.mShouldReverseLayout;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        addView(view);
      } else {
        addView(view, 0);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.mShouldReverseLayout;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        addDisappearingView(view);
      } else {
        addDisappearingView(view, 0);
      } 
    } 
    measureChildWithMargins(view, 0, 0);
    paramb.a = this.mOrientationHelper.c(view);
    if (this.mOrientation == 1) {
      if (isLayoutRTL()) {
        i = getWidth() - getPaddingRight();
        j = i - this.mOrientationHelper.d(view);
      } else {
        j = getPaddingLeft();
        i = this.mOrientationHelper.d(view) + j;
      } 
      if (paramc.f == -1) {
        m = paramc.b;
        int i1 = paramb.a;
        k = m;
        int n = i;
        i = m - i1;
        m = j;
        j = n;
      } else {
        m = paramc.b;
        int i1 = paramb.a;
        k = m;
        int n = i;
        i1 += m;
        m = j;
        i = k;
        j = n;
        k = i1;
      } 
    } else {
      m = getPaddingTop();
      i = this.mOrientationHelper.d(view) + m;
      if (paramc.f == -1) {
        int i1 = paramc.b;
        int i2 = paramb.a;
        j = i1;
        int n = m;
        k = i;
        m = i1 - i2;
        i = n;
      } else {
        int n = paramc.b;
        j = paramb.a;
        j += n;
        k = i;
        i = m;
        m = n;
      } 
    } 
    layoutDecoratedWithMargins(view, m, i, j, k);
    if (p.isItemRemoved() || p.isItemChanged())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public void onAnchorReady(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama, int paramInt) {}
  
  public void onDetachedFromWindow(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.onDetachedFromWindow(paramRecyclerView, paramv);
    if (this.mRecycleChildrenOnDetach) {
      removeAndRecycleAllViews(paramv);
      paramv.b();
    } 
  }
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view1;
    View view2;
    resolveShouldLayoutReverse();
    if (getChildCount() == 0)
      return null; 
    paramInt = convertFocusDirectionToLayoutDirection(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    ensureLayoutState();
    updateLayoutState(paramInt, (int)(this.mOrientationHelper.l() * 0.33333334F), false, parama0);
    c c1 = this.mLayoutState;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    fill(paramv, c1, parama0, true);
    if (paramInt == -1) {
      view1 = findPartiallyOrCompletelyInvisibleChildClosestToStart();
    } else {
      view1 = findPartiallyOrCompletelyInvisibleChildClosestToEnd();
    } 
    if (paramInt == -1) {
      view2 = getChildClosestToStart();
    } else {
      view2 = getChildClosestToEnd();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    if (getChildCount() > 0) {
      paramAccessibilityEvent.setFromIndex(findFirstVisibleItemPosition());
      paramAccessibilityEvent.setToIndex(findLastVisibleItemPosition());
    } 
  }
  
  public void onLayoutChildren(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    a a2;
    c c1;
    d d1 = this.mPendingSavedState;
    int k = -1;
    if ((d1 != null || this.mPendingScrollPosition != -1) && parama0.b() == 0) {
      removeAndRecycleAllViews(paramv);
      return;
    } 
    d1 = this.mPendingSavedState;
    if (d1 != null && d1.a())
      this.mPendingScrollPosition = this.mPendingSavedState.b; 
    ensureLayoutState();
    this.mLayoutState.a = false;
    resolveShouldLayoutReverse();
    View view = getFocusedChild();
    a a3 = this.mAnchorInfo;
    if (!a3.e || this.mPendingScrollPosition != -1 || this.mPendingSavedState != null) {
      a3.d();
      a2 = this.mAnchorInfo;
      a2.d = this.mShouldReverseLayout ^ this.mStackFromEnd;
      updateAnchorInfoForLayout(paramv, parama0, a2);
      this.mAnchorInfo.e = true;
    } else if (a2 != null && (this.mOrientationHelper.e((View)a2) >= this.mOrientationHelper.g() || this.mOrientationHelper.b((View)a2) <= this.mOrientationHelper.k())) {
      this.mAnchorInfo.c((View)a2, getPosition((View)a2));
    } 
    c c2 = this.mLayoutState;
    if (c2.j >= 0) {
      i = 1;
    } else {
      i = -1;
    } 
    c2.f = i;
    int[] arrayOfInt = this.mReusableIntPair;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    calculateExtraLayoutSpace(parama0, arrayOfInt);
    int i = Math.max(0, this.mReusableIntPair[0]);
    int m = this.mOrientationHelper.k() + i;
    i = Math.max(0, this.mReusableIntPair[1]);
    int n = this.mOrientationHelper.h() + i;
    i = m;
    int j = n;
    if (parama0.g) {
      int i1 = this.mPendingScrollPosition;
      i = m;
      j = n;
      if (i1 != -1) {
        i = m;
        j = n;
        if (this.mPendingScrollPositionOffset != Integer.MIN_VALUE) {
          View view1 = findViewByPosition(i1);
          i = m;
          j = n;
          if (view1 != null) {
            if (this.mShouldReverseLayout) {
              j = this.mOrientationHelper.g() - this.mOrientationHelper.b(view1);
              i = this.mPendingScrollPositionOffset;
            } else {
              i = this.mOrientationHelper.e(view1) - this.mOrientationHelper.k();
              j = this.mPendingScrollPositionOffset;
            } 
            i = j - i;
            if (i > 0) {
              i = m + i;
              j = n;
            } else {
              j = n - i;
              i = m;
            } 
          } 
        } 
      } 
    } 
    a a1 = this.mAnchorInfo;
    if (a1.d ? this.mShouldReverseLayout : !this.mShouldReverseLayout)
      k = 1; 
    onAnchorReady(paramv, parama0, a1, k);
    detachAndScrapAttachedViews(paramv);
    this.mLayoutState.l = resolveIsInfinite();
    Objects.requireNonNull(this.mLayoutState);
    this.mLayoutState.i = 0;
    a1 = this.mAnchorInfo;
    if (a1.d) {
      updateLayoutStateToFillStart(a1);
      c1 = this.mLayoutState;
      c1.h = i;
      fill(paramv, c1, parama0, false);
      c1 = this.mLayoutState;
      k = c1.b;
      n = c1.d;
      m = c1.c;
      i = j;
      if (m > 0)
        i = j + m; 
      updateLayoutStateToFillEnd(this.mAnchorInfo);
      c1 = this.mLayoutState;
      c1.h = i;
      c1.d += c1.e;
      fill(paramv, c1, parama0, false);
      c1 = this.mLayoutState;
      m = c1.b;
      int i1 = c1.c;
      i = k;
      j = m;
      if (i1 > 0) {
        updateLayoutStateToFillStart(n, k);
        c1 = this.mLayoutState;
        c1.h = i1;
        fill(paramv, c1, parama0, false);
        i = this.mLayoutState.b;
        j = m;
      } 
    } else {
      updateLayoutStateToFillEnd((a)c1);
      c1 = this.mLayoutState;
      c1.h = j;
      fill(paramv, c1, parama0, false);
      c1 = this.mLayoutState;
      k = c1.b;
      m = c1.d;
      n = c1.c;
      j = i;
      if (n > 0)
        j = i + n; 
      updateLayoutStateToFillStart(this.mAnchorInfo);
      c1 = this.mLayoutState;
      c1.h = j;
      c1.d += c1.e;
      fill(paramv, c1, parama0, false);
      c1 = this.mLayoutState;
      i = c1.b;
      n = c1.c;
      j = k;
      if (n > 0) {
        updateLayoutStateToFillEnd(m, k);
        c1 = this.mLayoutState;
        c1.h = n;
        fill(paramv, c1, parama0, false);
        j = this.mLayoutState.b;
      } 
    } 
    m = i;
    k = j;
    if (getChildCount() > 0) {
      if ((this.mShouldReverseLayout ^ this.mStackFromEnd) != 0) {
        m = fixLayoutEndGap(j, paramv, parama0, true);
        k = i + m;
        j += m;
        i = fixLayoutStartGap(k, paramv, parama0, false);
      } else {
        m = fixLayoutStartGap(i, paramv, parama0, true);
        k = i + m;
        j += m;
        i = fixLayoutEndGap(j, paramv, parama0, false);
      } 
      m = k + i;
      k = j + i;
    } 
    layoutForPredictiveAnimations(paramv, parama0, m, k);
    if (!parama0.g) {
      um um1 = this.mOrientationHelper;
      um1.b = um1.l();
    } else {
      this.mAnchorInfo.d();
    } 
    this.mLastStackFromEnd = this.mStackFromEnd;
  }
  
  public void onLayoutCompleted(RecyclerView.a0 parama0) {
    super.onLayoutCompleted(parama0);
    this.mPendingSavedState = null;
    this.mPendingScrollPosition = -1;
    this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
    this.mAnchorInfo.d();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      paramParcelable = paramParcelable;
      this.mPendingSavedState = (d)paramParcelable;
      if (this.mPendingScrollPosition != -1)
        ((d)paramParcelable).b = -1; 
      requestLayout();
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    d d1 = this.mPendingSavedState;
    if (d1 != null)
      return new d(d1); 
    d1 = new d();
    if (getChildCount() > 0) {
      ensureLayoutState();
      int i = this.mLastStackFromEnd ^ this.mShouldReverseLayout;
      d1.d = i;
      if (i != 0) {
        View view1 = getChildClosestToEnd();
        d1.c = this.mOrientationHelper.g() - this.mOrientationHelper.b(view1);
        d1.b = getPosition(view1);
        return d1;
      } 
      View view = getChildClosestToStart();
      d1.b = getPosition(view);
      d1.c = this.mOrientationHelper.e(view) - this.mOrientationHelper.k();
      return d1;
    } 
    d1.b = -1;
    return d1;
  }
  
  public void prepareForDrop(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    assertNotInLayoutOrScroll("Cannot drop a view during a scroll or layout calculation");
    ensureLayoutState();
    resolveShouldLayoutReverse();
    paramInt1 = getPosition(paramView1);
    paramInt2 = getPosition(paramView2);
    if (paramInt1 < paramInt2) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    if (this.mShouldReverseLayout) {
      if (paramInt1 == 1) {
        paramInt1 = this.mOrientationHelper.g();
        int i = this.mOrientationHelper.e(paramView2);
        scrollToPositionWithOffset(paramInt2, paramInt1 - this.mOrientationHelper.c(paramView1) + i);
        return;
      } 
      scrollToPositionWithOffset(paramInt2, this.mOrientationHelper.g() - this.mOrientationHelper.b(paramView2));
      return;
    } 
    if (paramInt1 == -1) {
      scrollToPositionWithOffset(paramInt2, this.mOrientationHelper.e(paramView2));
      return;
    } 
    scrollToPositionWithOffset(paramInt2, this.mOrientationHelper.b(paramView2) - this.mOrientationHelper.c(paramView1));
  }
  
  public boolean resolveIsInfinite() {
    return (this.mOrientationHelper.i() == 0 && this.mOrientationHelper.f() == 0);
  }
  
  public int scrollBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (getChildCount() != 0) {
      byte b1;
      if (paramInt == 0)
        return 0; 
      ensureLayoutState();
      this.mLayoutState.a = true;
      if (paramInt > 0) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      int i = Math.abs(paramInt);
      updateLayoutState(b1, i, true, parama0);
      c c1 = this.mLayoutState;
      int j = c1.g;
      j = fill(paramv, c1, parama0, false) + j;
      if (j < 0)
        return 0; 
      if (i > j)
        paramInt = b1 * j; 
      this.mOrientationHelper.p(-paramInt);
      this.mLayoutState.j = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.mOrientation == 1) ? 0 : scrollBy(paramInt, paramv, parama0);
  }
  
  public void scrollToPosition(int paramInt) {
    this.mPendingScrollPosition = paramInt;
    this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
    d d1 = this.mPendingSavedState;
    if (d1 != null)
      d1.b = -1; 
    requestLayout();
  }
  
  public void scrollToPositionWithOffset(int paramInt1, int paramInt2) {
    this.mPendingScrollPosition = paramInt1;
    this.mPendingScrollPositionOffset = paramInt2;
    d d1 = this.mPendingSavedState;
    if (d1 != null)
      d1.b = -1; 
    requestLayout();
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.mOrientation == 0) ? 0 : scrollBy(paramInt, paramv, parama0);
  }
  
  public void setInitialPrefetchItemCount(int paramInt) {
    this.mInitialPrefetchItemCount = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      assertNotInLayoutOrScroll(null);
      if (paramInt != this.mOrientation || this.mOrientationHelper == null) {
        um um1 = um.a(this, paramInt);
        this.mOrientationHelper = um1;
        this.mAnchorInfo.a = um1;
        this.mOrientation = paramInt;
        requestLayout();
      } 
      return;
    } 
    throw new IllegalArgumentException(s30.Z("invalid orientation:", paramInt));
  }
  
  public void setRecycleChildrenOnDetach(boolean paramBoolean) {
    this.mRecycleChildrenOnDetach = paramBoolean;
  }
  
  public void setReverseLayout(boolean paramBoolean) {
    assertNotInLayoutOrScroll(null);
    if (paramBoolean == this.mReverseLayout)
      return; 
    this.mReverseLayout = paramBoolean;
    requestLayout();
  }
  
  public void setSmoothScrollbarEnabled(boolean paramBoolean) {
    this.mSmoothScrollbarEnabled = paramBoolean;
  }
  
  public void setStackFromEnd(boolean paramBoolean) {
    assertNotInLayoutOrScroll(null);
    if (this.mStackFromEnd == paramBoolean)
      return; 
    this.mStackFromEnd = paramBoolean;
    requestLayout();
  }
  
  public boolean shouldMeasureTwice() {
    return (getHeightMode() != 1073741824 && getWidthMode() != 1073741824 && hasFlexibleChildInBothOrientations());
  }
  
  public void smoothScrollToPosition(RecyclerView paramRecyclerView, RecyclerView.a0 parama0, int paramInt) {
    pm pm = new pm(paramRecyclerView.getContext());
    pm.setTargetPosition(paramInt);
    startSmoothScroll((RecyclerView.z)pm);
  }
  
  public boolean supportsPredictiveItemAnimations() {
    return (this.mPendingSavedState == null && this.mLastStackFromEnd == this.mStackFromEnd);
  }
  
  public void validateChildOrder() {
    getChildCount();
    int i = getChildCount();
    boolean bool2 = true;
    boolean bool1 = true;
    if (i < 1)
      return; 
    int j = getPosition(getChildAt(0));
    int k = this.mOrientationHelper.e(getChildAt(0));
    if (this.mShouldReverseLayout) {
      i = 1;
      while (i < getChildCount()) {
        View view = getChildAt(i);
        int m = getPosition(view);
        int n = this.mOrientationHelper.e(view);
        if (m < j) {
          logChildren();
          StringBuilder stringBuilder = s30.x0("detected invalid position. loc invalid? ");
          if (n >= k)
            bool1 = false; 
          stringBuilder.append(bool1);
          throw new RuntimeException(stringBuilder.toString());
        } 
        if (n <= k) {
          i++;
          continue;
        } 
        logChildren();
        throw new RuntimeException("detected invalid location");
      } 
    } else {
      i = 1;
      while (i < getChildCount()) {
        View view = getChildAt(i);
        int m = getPosition(view);
        int n = this.mOrientationHelper.e(view);
        if (m < j) {
          logChildren();
          StringBuilder stringBuilder = s30.x0("detected invalid position. loc invalid? ");
          if (n < k) {
            bool1 = bool2;
          } else {
            bool1 = false;
          } 
          stringBuilder.append(bool1);
          throw new RuntimeException(stringBuilder.toString());
        } 
        if (n >= k) {
          i++;
          continue;
        } 
        logChildren();
        throw new RuntimeException("detected invalid location");
      } 
    } 
  }
  
  public static class a {
    public um a;
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public boolean e;
    
    public a() {
      d();
    }
    
    public void a() {
      int i;
      if (this.d) {
        i = this.a.g();
      } else {
        i = this.a.k();
      } 
      this.c = i;
    }
    
    public void b(View param1View, int param1Int) {
      if (this.d) {
        int i = this.a.b(param1View);
        this.c = this.a.m() + i;
      } else {
        this.c = this.a.e(param1View);
      } 
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int i = this.a.m();
      if (i >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.g() - i - this.a.b(param1View);
        this.c = this.a.g() - param1Int;
        if (param1Int > 0) {
          i = this.a.c(param1View);
          int j = this.c;
          int k = this.a.k();
          i = j - i - Math.min(this.a.e(param1View) - k, 0) + k;
          if (i < 0) {
            j = this.c;
            this.c = Math.min(param1Int, -i) + j;
            return;
          } 
        } 
      } else {
        int j = this.a.e(param1View);
        param1Int = j - this.a.k();
        this.c = j;
        if (param1Int > 0) {
          int k = this.a.c(param1View);
          int m = this.a.g();
          int n = this.a.b(param1View);
          i = this.a.g() - Math.min(0, m - i - n) - k + j;
          if (i < 0)
            this.c -= Math.min(param1Int, -i); 
        } 
      } 
    }
    
    public void d() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = s30.x0("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class c {
    public boolean a = true;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h = 0;
    
    public int i = 0;
    
    public int j;
    
    public List<RecyclerView.d0> k = null;
    
    public boolean l;
    
    public void a(View param1View) {
      View view2;
      int k = this.k.size();
      View view1 = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (true) {
        view2 = view1;
        if (i < k) {
          View view = ((RecyclerView.d0)this.k.get(i)).itemView;
          RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
          view2 = view1;
          int m = j;
          if (view != param1View)
            if (p.isItemRemoved()) {
              view2 = view1;
              m = j;
            } else {
              int n = (p.getViewLayoutPosition() - this.d) * this.e;
              if (n < 0) {
                view2 = view1;
                m = j;
              } else {
                view2 = view1;
                m = j;
                if (n < j) {
                  view1 = view;
                  if (n == 0) {
                    view2 = view1;
                    break;
                  } 
                  m = n;
                  view2 = view1;
                } 
              } 
            }  
          i++;
          view1 = view2;
          j = m;
          continue;
        } 
        break;
      } 
      if (view2 == null) {
        this.d = -1;
        return;
      } 
      this.d = ((RecyclerView.p)view2.getLayoutParams()).getViewLayoutPosition();
    }
    
    public boolean b(RecyclerView.a0 param1a0) {
      int i = this.d;
      return (i >= 0 && i < param1a0.b());
    }
    
    public View c(RecyclerView.v param1v) {
      List<RecyclerView.d0> list = this.k;
      if (list != null) {
        int j = list.size();
        for (int i = 0; i < j; i++) {
          view = ((RecyclerView.d0)this.k.get(i)).itemView;
          RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
          if (!p.isItemRemoved() && this.d == p.getViewLayoutPosition()) {
            a(view);
            return view;
          } 
        } 
        return null;
      } 
      View view = view.e(this.d);
      this.d += this.e;
      return view;
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public d() {}
    
    public d(Parcel param1Parcel) {
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.d = bool;
    }
    
    public d(d param1d) {
      this.b = param1d.b;
      this.c = param1d.c;
      this.d = param1d.d;
    }
    
    public boolean a() {
      return (this.b >= 0);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<d> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new LinearLayoutManager.d(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new LinearLayoutManager.d[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<d> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new LinearLayoutManager.d(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new LinearLayoutManager.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */