package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.activity.ComponentActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import km;
import om;
import pm;
import s30;
import um;

public class StaggeredGridLayoutManager extends RecyclerView.o implements RecyclerView.z.b {
  public e A;
  
  public int B;
  
  public final Rect C = new Rect();
  
  public final b D = new b(this);
  
  public boolean E = false;
  
  public boolean F = true;
  
  public int[] G;
  
  public final Runnable H = new a(this);
  
  public int b = -1;
  
  public f[] c;
  
  public um d;
  
  public um f;
  
  public int g;
  
  public int p;
  
  public final om q;
  
  public boolean r = false;
  
  public boolean s = false;
  
  public BitSet t;
  
  public int u = -1;
  
  public int v = Integer.MIN_VALUE;
  
  public d w = new d();
  
  public int x = 2;
  
  public boolean y;
  
  public boolean z;
  
  public StaggeredGridLayoutManager(int paramInt1, int paramInt2) {
    this.g = paramInt2;
    v(paramInt1);
    this.q = new om();
    this.d = um.a(this, this.g);
    this.f = um.a(this, 1 - this.g);
  }
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = d1.a;
    if (paramInt1 == 0 || paramInt1 == 1) {
      assertNotInLayoutOrScroll(null);
      if (paramInt1 != this.g) {
        this.g = paramInt1;
        um um1 = this.d;
        this.d = this.f;
        this.f = um1;
        requestLayout();
      } 
      v(d1.b);
      boolean bool = d1.c;
      assertNotInLayoutOrScroll(null);
      e e1 = this.A;
      if (e1 != null && e1.r != bool)
        e1.r = bool; 
      this.r = bool;
      requestLayout();
      this.q = new om();
      this.d = um.a(this, this.g);
      this.f = um.a(this, 1 - this.g);
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public final int a(int paramInt) {
    boolean bool;
    int i = getChildCount();
    byte b1 = -1;
    if (i == 0) {
      paramInt = b1;
      if (this.s)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < h()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.s) ? -1 : 1;
  }
  
  public void assertNotInLayoutOrScroll(String paramString) {
    if (this.A == null)
      super.assertNotInLayoutOrScroll(paramString); 
  }
  
  public boolean b() {
    if (getChildCount() != 0 && this.x != 0) {
      int i;
      int j;
      byte b1;
      if (!isAttachedToWindow())
        return false; 
      if (this.s) {
        i = i();
        j = h();
      } else {
        i = h();
        j = i();
      } 
      if (i == 0 && m() != null) {
        this.w.b();
        requestSimpleAnimationsInNextLayout();
        requestLayout();
        return true;
      } 
      if (!this.E)
        return false; 
      if (this.s) {
        b1 = -1;
      } else {
        b1 = 1;
      } 
      d d1 = this.w;
      d.a a1 = d1.e(i, ++j, b1, true);
      if (a1 == null) {
        this.E = false;
        this.w.d(j);
        return false;
      } 
      d.a a2 = this.w.e(i, a1.b, b1 * -1, true);
      if (a2 == null) {
        this.w.d(a1.b);
      } else {
        this.w.d(a2.b + 1);
      } 
      requestSimpleAnimationsInNextLayout();
      requestLayout();
      return true;
    } 
    return false;
  }
  
  public final int c(RecyclerView.v paramv, om paramom, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : Ljava/util/BitSet;
    //   4: iconst_0
    //   5: aload_0
    //   6: getfield b : I
    //   9: iconst_1
    //   10: invokevirtual set : (IIZ)V
    //   13: aload_0
    //   14: getfield q : Lom;
    //   17: getfield i : Z
    //   20: ifeq -> 45
    //   23: aload_2
    //   24: getfield e : I
    //   27: iconst_1
    //   28: if_icmpne -> 38
    //   31: ldc 2147483647
    //   33: istore #5
    //   35: goto -> 82
    //   38: ldc -2147483648
    //   40: istore #5
    //   42: goto -> 82
    //   45: aload_2
    //   46: getfield e : I
    //   49: iconst_1
    //   50: if_icmpne -> 67
    //   53: aload_2
    //   54: getfield g : I
    //   57: aload_2
    //   58: getfield b : I
    //   61: iadd
    //   62: istore #4
    //   64: goto -> 78
    //   67: aload_2
    //   68: getfield f : I
    //   71: aload_2
    //   72: getfield b : I
    //   75: isub
    //   76: istore #4
    //   78: iload #4
    //   80: istore #5
    //   82: aload_0
    //   83: aload_2
    //   84: getfield e : I
    //   87: iload #5
    //   89: invokevirtual w : (II)V
    //   92: aload_0
    //   93: getfield s : Z
    //   96: ifeq -> 111
    //   99: aload_0
    //   100: getfield d : Lum;
    //   103: invokevirtual g : ()I
    //   106: istore #6
    //   108: goto -> 120
    //   111: aload_0
    //   112: getfield d : Lum;
    //   115: invokevirtual k : ()I
    //   118: istore #6
    //   120: iconst_0
    //   121: istore #4
    //   123: aload_1
    //   124: astore #15
    //   126: aload_2
    //   127: getfield c : I
    //   130: istore #7
    //   132: iload #7
    //   134: iflt -> 152
    //   137: iload #7
    //   139: aload_3
    //   140: invokevirtual b : ()I
    //   143: if_icmpge -> 152
    //   146: iconst_1
    //   147: istore #7
    //   149: goto -> 155
    //   152: iconst_0
    //   153: istore #7
    //   155: iload #7
    //   157: ifeq -> 1758
    //   160: aload_0
    //   161: getfield q : Lom;
    //   164: getfield i : Z
    //   167: ifne -> 180
    //   170: aload_0
    //   171: getfield t : Ljava/util/BitSet;
    //   174: invokevirtual isEmpty : ()Z
    //   177: ifne -> 1758
    //   180: aload #15
    //   182: aload_2
    //   183: getfield c : I
    //   186: invokevirtual e : (I)Landroid/view/View;
    //   189: astore #18
    //   191: aload_2
    //   192: aload_2
    //   193: getfield c : I
    //   196: aload_2
    //   197: getfield d : I
    //   200: iadd
    //   201: putfield c : I
    //   204: aload #18
    //   206: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   209: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   212: astore #17
    //   214: aload #17
    //   216: invokevirtual getViewLayoutPosition : ()I
    //   219: istore #13
    //   221: aload_0
    //   222: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   225: getfield a : [I
    //   228: astore #15
    //   230: aload #15
    //   232: ifnull -> 256
    //   235: iload #13
    //   237: aload #15
    //   239: arraylength
    //   240: if_icmplt -> 246
    //   243: goto -> 256
    //   246: aload #15
    //   248: iload #13
    //   250: iaload
    //   251: istore #4
    //   253: goto -> 259
    //   256: iconst_m1
    //   257: istore #4
    //   259: iload #4
    //   261: iconst_m1
    //   262: if_icmpne -> 271
    //   265: iconst_1
    //   266: istore #7
    //   268: goto -> 274
    //   271: iconst_0
    //   272: istore #7
    //   274: iload #7
    //   276: ifeq -> 543
    //   279: aload #17
    //   281: getfield b : Z
    //   284: ifeq -> 298
    //   287: aload_0
    //   288: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   291: iconst_0
    //   292: aaload
    //   293: astore #15
    //   295: goto -> 514
    //   298: aload_0
    //   299: aload_2
    //   300: getfield e : I
    //   303: invokevirtual p : (I)Z
    //   306: ifeq -> 326
    //   309: aload_0
    //   310: getfield b : I
    //   313: iconst_1
    //   314: isub
    //   315: istore #4
    //   317: iconst_m1
    //   318: istore #8
    //   320: iconst_m1
    //   321: istore #9
    //   323: goto -> 338
    //   326: aload_0
    //   327: getfield b : I
    //   330: istore #8
    //   332: iconst_0
    //   333: istore #4
    //   335: iconst_1
    //   336: istore #9
    //   338: aload_2
    //   339: getfield e : I
    //   342: istore #10
    //   344: aconst_null
    //   345: astore #16
    //   347: aconst_null
    //   348: astore #15
    //   350: iload #10
    //   352: iconst_1
    //   353: if_icmpne -> 431
    //   356: aload_0
    //   357: getfield d : Lum;
    //   360: invokevirtual k : ()I
    //   363: istore #14
    //   365: ldc 2147483647
    //   367: istore #10
    //   369: aload #15
    //   371: astore #16
    //   373: iload #4
    //   375: iload #8
    //   377: if_icmpeq -> 510
    //   380: aload_0
    //   381: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   384: iload #4
    //   386: aaload
    //   387: astore #16
    //   389: aload #16
    //   391: iload #14
    //   393: invokevirtual j : (I)I
    //   396: istore #12
    //   398: iload #10
    //   400: istore #11
    //   402: iload #12
    //   404: iload #10
    //   406: if_icmpge -> 417
    //   409: aload #16
    //   411: astore #15
    //   413: iload #12
    //   415: istore #11
    //   417: iload #4
    //   419: iload #9
    //   421: iadd
    //   422: istore #4
    //   424: iload #11
    //   426: istore #10
    //   428: goto -> 369
    //   431: aload_0
    //   432: getfield d : Lum;
    //   435: invokevirtual g : ()I
    //   438: istore #14
    //   440: ldc -2147483648
    //   442: istore #10
    //   444: aload #16
    //   446: astore #15
    //   448: aload #15
    //   450: astore #16
    //   452: iload #4
    //   454: iload #8
    //   456: if_icmpeq -> 510
    //   459: aload_0
    //   460: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   463: iload #4
    //   465: aaload
    //   466: astore #16
    //   468: aload #16
    //   470: iload #14
    //   472: invokevirtual m : (I)I
    //   475: istore #12
    //   477: iload #10
    //   479: istore #11
    //   481: iload #12
    //   483: iload #10
    //   485: if_icmple -> 496
    //   488: aload #16
    //   490: astore #15
    //   492: iload #12
    //   494: istore #11
    //   496: iload #4
    //   498: iload #9
    //   500: iadd
    //   501: istore #4
    //   503: iload #11
    //   505: istore #10
    //   507: goto -> 448
    //   510: aload #16
    //   512: astore #15
    //   514: aload_0
    //   515: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   518: astore #16
    //   520: aload #16
    //   522: iload #13
    //   524: invokevirtual c : (I)V
    //   527: aload #16
    //   529: getfield a : [I
    //   532: iload #13
    //   534: aload #15
    //   536: getfield e : I
    //   539: iastore
    //   540: goto -> 552
    //   543: aload_0
    //   544: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   547: iload #4
    //   549: aaload
    //   550: astore #15
    //   552: aload #17
    //   554: aload #15
    //   556: putfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   559: aload_2
    //   560: getfield e : I
    //   563: iconst_1
    //   564: if_icmpne -> 576
    //   567: aload_0
    //   568: aload #18
    //   570: invokevirtual addView : (Landroid/view/View;)V
    //   573: goto -> 583
    //   576: aload_0
    //   577: aload #18
    //   579: iconst_0
    //   580: invokevirtual addView : (Landroid/view/View;I)V
    //   583: aload #17
    //   585: getfield b : Z
    //   588: ifeq -> 707
    //   591: aload_0
    //   592: getfield g : I
    //   595: iconst_1
    //   596: if_icmpne -> 655
    //   599: aload_0
    //   600: getfield B : I
    //   603: istore #4
    //   605: aload_0
    //   606: invokevirtual getHeight : ()I
    //   609: istore #8
    //   611: aload_0
    //   612: invokevirtual getHeightMode : ()I
    //   615: istore #9
    //   617: aload_0
    //   618: invokevirtual getPaddingTop : ()I
    //   621: istore #10
    //   623: aload_0
    //   624: aload #18
    //   626: iload #4
    //   628: iload #8
    //   630: iload #9
    //   632: aload_0
    //   633: invokevirtual getPaddingBottom : ()I
    //   636: iload #10
    //   638: iadd
    //   639: aload #17
    //   641: getfield height : I
    //   644: iconst_1
    //   645: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   648: iconst_0
    //   649: invokevirtual n : (Landroid/view/View;IIZ)V
    //   652: goto -> 848
    //   655: aload_0
    //   656: invokevirtual getWidth : ()I
    //   659: istore #4
    //   661: aload_0
    //   662: invokevirtual getWidthMode : ()I
    //   665: istore #8
    //   667: aload_0
    //   668: invokevirtual getPaddingLeft : ()I
    //   671: istore #9
    //   673: aload_0
    //   674: aload #18
    //   676: iload #4
    //   678: iload #8
    //   680: aload_0
    //   681: invokevirtual getPaddingRight : ()I
    //   684: iload #9
    //   686: iadd
    //   687: aload #17
    //   689: getfield width : I
    //   692: iconst_1
    //   693: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   696: aload_0
    //   697: getfield B : I
    //   700: iconst_0
    //   701: invokevirtual n : (Landroid/view/View;IIZ)V
    //   704: goto -> 848
    //   707: aload_0
    //   708: getfield g : I
    //   711: iconst_1
    //   712: if_icmpne -> 785
    //   715: aload_0
    //   716: getfield p : I
    //   719: aload_0
    //   720: invokevirtual getWidthMode : ()I
    //   723: iconst_0
    //   724: aload #17
    //   726: getfield width : I
    //   729: iconst_0
    //   730: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   733: istore #4
    //   735: aload_0
    //   736: invokevirtual getHeight : ()I
    //   739: istore #8
    //   741: aload_0
    //   742: invokevirtual getHeightMode : ()I
    //   745: istore #9
    //   747: aload_0
    //   748: invokevirtual getPaddingTop : ()I
    //   751: istore #10
    //   753: aload_0
    //   754: aload #18
    //   756: iload #4
    //   758: iload #8
    //   760: iload #9
    //   762: aload_0
    //   763: invokevirtual getPaddingBottom : ()I
    //   766: iload #10
    //   768: iadd
    //   769: aload #17
    //   771: getfield height : I
    //   774: iconst_1
    //   775: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   778: iconst_0
    //   779: invokevirtual n : (Landroid/view/View;IIZ)V
    //   782: goto -> 848
    //   785: aload_0
    //   786: invokevirtual getWidth : ()I
    //   789: istore #4
    //   791: aload_0
    //   792: invokevirtual getWidthMode : ()I
    //   795: istore #8
    //   797: aload_0
    //   798: invokevirtual getPaddingLeft : ()I
    //   801: istore #9
    //   803: aload_0
    //   804: aload #18
    //   806: iload #4
    //   808: iload #8
    //   810: aload_0
    //   811: invokevirtual getPaddingRight : ()I
    //   814: iload #9
    //   816: iadd
    //   817: aload #17
    //   819: getfield width : I
    //   822: iconst_1
    //   823: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   826: aload_0
    //   827: getfield p : I
    //   830: aload_0
    //   831: invokevirtual getHeightMode : ()I
    //   834: iconst_0
    //   835: aload #17
    //   837: getfield height : I
    //   840: iconst_0
    //   841: invokestatic getChildMeasureSpec : (IIIIZ)I
    //   844: iconst_0
    //   845: invokevirtual n : (Landroid/view/View;IIZ)V
    //   848: aload_2
    //   849: getfield e : I
    //   852: iconst_1
    //   853: if_icmpne -> 1008
    //   856: aload #17
    //   858: getfield b : Z
    //   861: ifeq -> 875
    //   864: aload_0
    //   865: iload #6
    //   867: invokevirtual j : (I)I
    //   870: istore #4
    //   872: goto -> 884
    //   875: aload #15
    //   877: iload #6
    //   879: invokevirtual j : (I)I
    //   882: istore #4
    //   884: aload_0
    //   885: getfield d : Lum;
    //   888: aload #18
    //   890: invokevirtual c : (Landroid/view/View;)I
    //   893: istore #9
    //   895: iload #7
    //   897: ifeq -> 994
    //   900: aload #17
    //   902: getfield b : Z
    //   905: ifeq -> 994
    //   908: new androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
    //   911: dup
    //   912: invokespecial <init> : ()V
    //   915: astore #16
    //   917: aload #16
    //   919: aload_0
    //   920: getfield b : I
    //   923: newarray int
    //   925: putfield d : [I
    //   928: iconst_0
    //   929: istore #8
    //   931: iload #8
    //   933: aload_0
    //   934: getfield b : I
    //   937: if_icmpge -> 972
    //   940: aload #16
    //   942: getfield d : [I
    //   945: iload #8
    //   947: iload #4
    //   949: aload_0
    //   950: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   953: iload #8
    //   955: aaload
    //   956: iload #4
    //   958: invokevirtual j : (I)I
    //   961: isub
    //   962: iastore
    //   963: iload #8
    //   965: iconst_1
    //   966: iadd
    //   967: istore #8
    //   969: goto -> 931
    //   972: aload #16
    //   974: iconst_m1
    //   975: putfield c : I
    //   978: aload #16
    //   980: iload #13
    //   982: putfield b : I
    //   985: aload_0
    //   986: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   989: aload #16
    //   991: invokevirtual a : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;)V
    //   994: iload #4
    //   996: istore #8
    //   998: iload #9
    //   1000: iload #4
    //   1002: iadd
    //   1003: istore #9
    //   1005: goto -> 1157
    //   1008: aload #17
    //   1010: getfield b : Z
    //   1013: ifeq -> 1027
    //   1016: aload_0
    //   1017: iload #6
    //   1019: invokevirtual k : (I)I
    //   1022: istore #4
    //   1024: goto -> 1036
    //   1027: aload #15
    //   1029: iload #6
    //   1031: invokevirtual m : (I)I
    //   1034: istore #4
    //   1036: aload_0
    //   1037: getfield d : Lum;
    //   1040: aload #18
    //   1042: invokevirtual c : (Landroid/view/View;)I
    //   1045: istore #10
    //   1047: iload #7
    //   1049: ifeq -> 1146
    //   1052: aload #17
    //   1054: getfield b : Z
    //   1057: ifeq -> 1146
    //   1060: new androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
    //   1063: dup
    //   1064: invokespecial <init> : ()V
    //   1067: astore #16
    //   1069: aload #16
    //   1071: aload_0
    //   1072: getfield b : I
    //   1075: newarray int
    //   1077: putfield d : [I
    //   1080: iconst_0
    //   1081: istore #8
    //   1083: iload #8
    //   1085: aload_0
    //   1086: getfield b : I
    //   1089: if_icmpge -> 1124
    //   1092: aload #16
    //   1094: getfield d : [I
    //   1097: iload #8
    //   1099: aload_0
    //   1100: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1103: iload #8
    //   1105: aaload
    //   1106: iload #4
    //   1108: invokevirtual m : (I)I
    //   1111: iload #4
    //   1113: isub
    //   1114: iastore
    //   1115: iload #8
    //   1117: iconst_1
    //   1118: iadd
    //   1119: istore #8
    //   1121: goto -> 1083
    //   1124: aload #16
    //   1126: iconst_1
    //   1127: putfield c : I
    //   1130: aload #16
    //   1132: iload #13
    //   1134: putfield b : I
    //   1137: aload_0
    //   1138: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1141: aload #16
    //   1143: invokevirtual a : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;)V
    //   1146: iload #4
    //   1148: istore #9
    //   1150: iload #4
    //   1152: iload #10
    //   1154: isub
    //   1155: istore #8
    //   1157: aload #17
    //   1159: getfield b : Z
    //   1162: ifeq -> 1345
    //   1165: aload_2
    //   1166: getfield d : I
    //   1169: iconst_m1
    //   1170: if_icmpne -> 1345
    //   1173: iload #7
    //   1175: ifeq -> 1186
    //   1178: aload_0
    //   1179: iconst_1
    //   1180: putfield E : Z
    //   1183: goto -> 1345
    //   1186: aload_2
    //   1187: getfield e : I
    //   1190: iconst_1
    //   1191: if_icmpne -> 1248
    //   1194: aload_0
    //   1195: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1198: iconst_0
    //   1199: aaload
    //   1200: ldc -2147483648
    //   1202: invokevirtual j : (I)I
    //   1205: istore #7
    //   1207: iconst_1
    //   1208: istore #4
    //   1210: iload #4
    //   1212: aload_0
    //   1213: getfield b : I
    //   1216: if_icmpge -> 1305
    //   1219: aload_0
    //   1220: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1223: iload #4
    //   1225: aaload
    //   1226: ldc -2147483648
    //   1228: invokevirtual j : (I)I
    //   1231: iload #7
    //   1233: if_icmpeq -> 1239
    //   1236: goto -> 1290
    //   1239: iload #4
    //   1241: iconst_1
    //   1242: iadd
    //   1243: istore #4
    //   1245: goto -> 1210
    //   1248: aload_0
    //   1249: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1252: iconst_0
    //   1253: aaload
    //   1254: ldc -2147483648
    //   1256: invokevirtual m : (I)I
    //   1259: istore #7
    //   1261: iconst_1
    //   1262: istore #4
    //   1264: iload #4
    //   1266: aload_0
    //   1267: getfield b : I
    //   1270: if_icmpge -> 1305
    //   1273: aload_0
    //   1274: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1277: iload #4
    //   1279: aaload
    //   1280: ldc -2147483648
    //   1282: invokevirtual m : (I)I
    //   1285: iload #7
    //   1287: if_icmpeq -> 1296
    //   1290: iconst_0
    //   1291: istore #4
    //   1293: goto -> 1308
    //   1296: iload #4
    //   1298: iconst_1
    //   1299: iadd
    //   1300: istore #4
    //   1302: goto -> 1264
    //   1305: iconst_1
    //   1306: istore #4
    //   1308: iload #4
    //   1310: iconst_1
    //   1311: ixor
    //   1312: ifeq -> 1345
    //   1315: aload_0
    //   1316: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1319: iload #13
    //   1321: invokevirtual f : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
    //   1324: astore #16
    //   1326: aload #16
    //   1328: ifnull -> 1337
    //   1331: aload #16
    //   1333: iconst_1
    //   1334: putfield f : Z
    //   1337: aload_0
    //   1338: iconst_1
    //   1339: putfield E : Z
    //   1342: goto -> 1345
    //   1345: aload_2
    //   1346: getfield e : I
    //   1349: iconst_1
    //   1350: if_icmpne -> 1406
    //   1353: aload #17
    //   1355: getfield b : Z
    //   1358: ifeq -> 1393
    //   1361: aload_0
    //   1362: getfield b : I
    //   1365: istore #4
    //   1367: iload #4
    //   1369: iconst_1
    //   1370: isub
    //   1371: istore #4
    //   1373: iload #4
    //   1375: iflt -> 1456
    //   1378: aload_0
    //   1379: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1382: iload #4
    //   1384: aaload
    //   1385: aload #18
    //   1387: invokevirtual a : (Landroid/view/View;)V
    //   1390: goto -> 1367
    //   1393: aload #17
    //   1395: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1398: aload #18
    //   1400: invokevirtual a : (Landroid/view/View;)V
    //   1403: goto -> 1456
    //   1406: aload #17
    //   1408: getfield b : Z
    //   1411: ifeq -> 1446
    //   1414: aload_0
    //   1415: getfield b : I
    //   1418: istore #4
    //   1420: iload #4
    //   1422: iconst_1
    //   1423: isub
    //   1424: istore #4
    //   1426: iload #4
    //   1428: iflt -> 1456
    //   1431: aload_0
    //   1432: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1435: iload #4
    //   1437: aaload
    //   1438: aload #18
    //   1440: invokevirtual p : (Landroid/view/View;)V
    //   1443: goto -> 1420
    //   1446: aload #17
    //   1448: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1451: aload #18
    //   1453: invokevirtual p : (Landroid/view/View;)V
    //   1456: aload_0
    //   1457: invokevirtual isLayoutRTL : ()Z
    //   1460: ifeq -> 1547
    //   1463: aload_0
    //   1464: getfield g : I
    //   1467: iconst_1
    //   1468: if_icmpne -> 1547
    //   1471: aload #17
    //   1473: getfield b : Z
    //   1476: ifeq -> 1491
    //   1479: aload_0
    //   1480: getfield f : Lum;
    //   1483: invokevirtual g : ()I
    //   1486: istore #4
    //   1488: goto -> 1518
    //   1491: aload_0
    //   1492: getfield f : Lum;
    //   1495: invokevirtual g : ()I
    //   1498: aload_0
    //   1499: getfield b : I
    //   1502: iconst_1
    //   1503: isub
    //   1504: aload #15
    //   1506: getfield e : I
    //   1509: isub
    //   1510: aload_0
    //   1511: getfield p : I
    //   1514: imul
    //   1515: isub
    //   1516: istore #4
    //   1518: aload_0
    //   1519: getfield f : Lum;
    //   1522: aload #18
    //   1524: invokevirtual c : (Landroid/view/View;)I
    //   1527: istore #10
    //   1529: iload #4
    //   1531: istore #7
    //   1533: iload #4
    //   1535: iload #10
    //   1537: isub
    //   1538: istore #4
    //   1540: iload #7
    //   1542: istore #10
    //   1544: goto -> 1613
    //   1547: aload #17
    //   1549: getfield b : Z
    //   1552: ifeq -> 1567
    //   1555: aload_0
    //   1556: getfield f : Lum;
    //   1559: invokevirtual k : ()I
    //   1562: istore #4
    //   1564: goto -> 1587
    //   1567: aload #15
    //   1569: getfield e : I
    //   1572: aload_0
    //   1573: getfield p : I
    //   1576: imul
    //   1577: aload_0
    //   1578: getfield f : Lum;
    //   1581: invokevirtual k : ()I
    //   1584: iadd
    //   1585: istore #4
    //   1587: aload_0
    //   1588: getfield f : Lum;
    //   1591: aload #18
    //   1593: invokevirtual c : (Landroid/view/View;)I
    //   1596: istore #10
    //   1598: iload #4
    //   1600: istore #7
    //   1602: iload #10
    //   1604: iload #4
    //   1606: iadd
    //   1607: istore #10
    //   1609: iload #7
    //   1611: istore #4
    //   1613: aload_0
    //   1614: getfield g : I
    //   1617: iconst_1
    //   1618: if_icmpne -> 1638
    //   1621: aload_0
    //   1622: aload #18
    //   1624: iload #4
    //   1626: iload #8
    //   1628: iload #10
    //   1630: iload #9
    //   1632: invokevirtual layoutDecoratedWithMargins : (Landroid/view/View;IIII)V
    //   1635: goto -> 1652
    //   1638: aload_0
    //   1639: aload #18
    //   1641: iload #8
    //   1643: iload #4
    //   1645: iload #9
    //   1647: iload #10
    //   1649: invokevirtual layoutDecoratedWithMargins : (Landroid/view/View;IIII)V
    //   1652: aload #17
    //   1654: getfield b : Z
    //   1657: ifeq -> 1676
    //   1660: aload_0
    //   1661: aload_0
    //   1662: getfield q : Lom;
    //   1665: getfield e : I
    //   1668: iload #5
    //   1670: invokevirtual w : (II)V
    //   1673: goto -> 1691
    //   1676: aload_0
    //   1677: aload #15
    //   1679: aload_0
    //   1680: getfield q : Lom;
    //   1683: getfield e : I
    //   1686: iload #5
    //   1688: invokevirtual y : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;II)V
    //   1691: aload_0
    //   1692: aload_1
    //   1693: aload_0
    //   1694: getfield q : Lom;
    //   1697: invokevirtual r : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;)V
    //   1700: aload_0
    //   1701: getfield q : Lom;
    //   1704: getfield h : Z
    //   1707: ifeq -> 1752
    //   1710: aload #18
    //   1712: invokevirtual hasFocusable : ()Z
    //   1715: ifeq -> 1752
    //   1718: aload #17
    //   1720: getfield b : Z
    //   1723: ifeq -> 1736
    //   1726: aload_0
    //   1727: getfield t : Ljava/util/BitSet;
    //   1730: invokevirtual clear : ()V
    //   1733: goto -> 1752
    //   1736: aload_0
    //   1737: getfield t : Ljava/util/BitSet;
    //   1740: aload #15
    //   1742: getfield e : I
    //   1745: iconst_0
    //   1746: invokevirtual set : (IZ)V
    //   1749: goto -> 1752
    //   1752: iconst_1
    //   1753: istore #4
    //   1755: goto -> 123
    //   1758: iload #4
    //   1760: ifne -> 1773
    //   1763: aload_0
    //   1764: aload #15
    //   1766: aload_0
    //   1767: getfield q : Lom;
    //   1770: invokevirtual r : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;)V
    //   1773: aload_0
    //   1774: getfield q : Lom;
    //   1777: getfield e : I
    //   1780: iconst_m1
    //   1781: if_icmpne -> 1812
    //   1784: aload_0
    //   1785: aload_0
    //   1786: getfield d : Lum;
    //   1789: invokevirtual k : ()I
    //   1792: invokevirtual k : (I)I
    //   1795: istore #4
    //   1797: aload_0
    //   1798: getfield d : Lum;
    //   1801: invokevirtual k : ()I
    //   1804: iload #4
    //   1806: isub
    //   1807: istore #4
    //   1809: goto -> 1833
    //   1812: aload_0
    //   1813: aload_0
    //   1814: getfield d : Lum;
    //   1817: invokevirtual g : ()I
    //   1820: invokevirtual j : (I)I
    //   1823: aload_0
    //   1824: getfield d : Lum;
    //   1827: invokevirtual g : ()I
    //   1830: isub
    //   1831: istore #4
    //   1833: iload #4
    //   1835: ifle -> 1848
    //   1838: aload_2
    //   1839: getfield b : I
    //   1842: iload #4
    //   1844: invokestatic min : (II)I
    //   1847: ireturn
    //   1848: iconst_0
    //   1849: ireturn
  }
  
  public boolean canScrollHorizontally() {
    return (this.g == 0);
  }
  
  public boolean canScrollVertically() {
    return (this.g == 1);
  }
  
  public boolean checkLayoutParams(RecyclerView.p paramp) {
    return paramp instanceof c;
  }
  
  public void collectAdjacentPrefetchPositions(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.g != 0)
      paramInt1 = paramInt2; 
    if (getChildCount() != 0) {
      if (paramInt1 == 0)
        return; 
      q(paramInt1, parama0);
      int[] arrayOfInt = this.G;
      if (arrayOfInt == null || arrayOfInt.length < this.b)
        this.G = new int[this.b]; 
      paramInt2 = 0;
      for (paramInt1 = 0; paramInt2 < this.b; paramInt1 = i) {
        om om1 = this.q;
        if (om1.d == -1) {
          i = om1.f;
          j = this.c[paramInt2].m(i);
        } else {
          i = this.c[paramInt2].j(om1.g);
          j = this.q.g;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.G[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.G, 0, paramInt1);
      paramInt2 = 0;
      while (paramInt2 < paramInt1) {
        int i = this.q.c;
        if (i >= 0 && i < parama0.b()) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          i = this.q.c;
          int j = this.G[paramInt2];
          ((km.b)paramc).a(i, j);
          om om1 = this.q;
          om1.c += om1.d;
          paramInt2++;
        } 
      } 
    } 
  }
  
  public int computeHorizontalScrollExtent(RecyclerView.a0 parama0) {
    return computeScrollExtent(parama0);
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.a0 parama0) {
    return computeScrollOffset(parama0);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.a0 parama0) {
    return computeScrollRange(parama0);
  }
  
  public final int computeScrollExtent(RecyclerView.a0 parama0) {
    return (getChildCount() == 0) ? 0 : ComponentActivity.c.t(parama0, this.d, e(this.F ^ true), d(this.F ^ true), this, this.F);
  }
  
  public final int computeScrollOffset(RecyclerView.a0 parama0) {
    return (getChildCount() == 0) ? 0 : ComponentActivity.c.u(parama0, this.d, e(this.F ^ true), d(this.F ^ true), this, this.F, this.s);
  }
  
  public final int computeScrollRange(RecyclerView.a0 parama0) {
    return (getChildCount() == 0) ? 0 : ComponentActivity.c.v(parama0, this.d, e(this.F ^ true), d(this.F ^ true), this, this.F);
  }
  
  public PointF computeScrollVectorForPosition(int paramInt) {
    paramInt = a(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.g == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public int computeVerticalScrollExtent(RecyclerView.a0 parama0) {
    return computeScrollExtent(parama0);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.a0 parama0) {
    return computeScrollOffset(parama0);
  }
  
  public int computeVerticalScrollRange(RecyclerView.a0 parama0) {
    return computeScrollRange(parama0);
  }
  
  public View d(boolean paramBoolean) {
    int j = this.d.k();
    int k = this.d.g();
    int i = getChildCount() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = getChildAt(i);
      int m = this.d.e(view2);
      int n = this.d.b(view2);
      View view1 = view;
      if (n > j)
        if (m >= k) {
          view1 = view;
        } else if (n > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  public View e(boolean paramBoolean) {
    int j = this.d.k();
    int k = this.d.g();
    int m = getChildCount();
    View view = null;
    int i = 0;
    while (i < m) {
      View view2 = getChildAt(i);
      int n = this.d.e(view2);
      View view1 = view;
      if (this.d.b(view2) > j)
        if (n >= k) {
          view1 = view;
        } else if (n < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  public final void f(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = j(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.d.g() - i;
    if (i > 0) {
      i -= -scrollBy(-i, paramv, parama0);
      if (paramBoolean && i > 0)
        this.d.p(i); 
    } 
  }
  
  public final void g(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = k(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.d.k();
    if (i > 0) {
      i -= scrollBy(i, paramv, parama0);
      if (paramBoolean && i > 0)
        this.d.p(-i); 
    } 
  }
  
  public RecyclerView.p generateDefaultLayoutParams() {
    return (this.g == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public RecyclerView.p generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  public int h() {
    return (getChildCount() == 0) ? 0 : getPosition(getChildAt(0));
  }
  
  public int i() {
    int i = getChildCount();
    return (i == 0) ? 0 : getPosition(getChildAt(i - 1));
  }
  
  public boolean isAutoMeasureEnabled() {
    return (this.x != 0);
  }
  
  public boolean isLayoutRTL() {
    return (getLayoutDirection() == 1);
  }
  
  public final int j(int paramInt) {
    int j = this.c[0].j(paramInt);
    int i = 1;
    while (i < this.b) {
      int m = this.c[i].j(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public final int k(int paramInt) {
    int j = this.c[0].m(paramInt);
    int i = 1;
    while (i < this.b) {
      int m = this.c[i].m(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public final void l(int paramInt1, int paramInt2, int paramInt3) {
    if (this.s) {
      int j = i();
    } else {
      int j = h();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.w.g(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.w.g(i);
  }
  
  public View m() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield b : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #8
    //   20: aload #8
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield b : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield g : I
    //   35: iconst_1
    //   36: if_icmpne -> 51
    //   39: aload_0
    //   40: invokevirtual isLayoutRTL : ()Z
    //   43: ifeq -> 51
    //   46: iconst_1
    //   47: istore_2
    //   48: goto -> 53
    //   51: iconst_m1
    //   52: istore_2
    //   53: aload_0
    //   54: getfield s : Z
    //   57: ifeq -> 65
    //   60: iconst_m1
    //   61: istore_3
    //   62: goto -> 71
    //   65: iload_1
    //   66: iconst_1
    //   67: iadd
    //   68: istore_3
    //   69: iconst_0
    //   70: istore_1
    //   71: iload_1
    //   72: iload_3
    //   73: if_icmpge -> 82
    //   76: iconst_1
    //   77: istore #4
    //   79: goto -> 85
    //   82: iconst_m1
    //   83: istore #4
    //   85: iload_1
    //   86: iload_3
    //   87: if_icmpeq -> 512
    //   90: aload_0
    //   91: iload_1
    //   92: invokevirtual getChildAt : (I)Landroid/view/View;
    //   95: astore #9
    //   97: aload #9
    //   99: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   102: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   105: astore #10
    //   107: aload #8
    //   109: aload #10
    //   111: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   114: getfield e : I
    //   117: invokevirtual get : (I)Z
    //   120: ifeq -> 309
    //   123: aload #10
    //   125: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   128: astore #11
    //   130: aload_0
    //   131: getfield s : Z
    //   134: ifeq -> 213
    //   137: aload #11
    //   139: getfield c : I
    //   142: istore #5
    //   144: iload #5
    //   146: ldc -2147483648
    //   148: if_icmpeq -> 154
    //   151: goto -> 166
    //   154: aload #11
    //   156: invokevirtual b : ()V
    //   159: aload #11
    //   161: getfield c : I
    //   164: istore #5
    //   166: iload #5
    //   168: aload_0
    //   169: getfield d : Lum;
    //   172: invokevirtual g : ()I
    //   175: if_icmpge -> 285
    //   178: aload #11
    //   180: getfield a : Ljava/util/ArrayList;
    //   183: astore #12
    //   185: aload #11
    //   187: aload #12
    //   189: aload #12
    //   191: invokevirtual size : ()I
    //   194: iconst_1
    //   195: isub
    //   196: invokevirtual get : (I)Ljava/lang/Object;
    //   199: checkcast android/view/View
    //   202: invokevirtual l : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   205: getfield b : Z
    //   208: istore #7
    //   210: goto -> 276
    //   213: aload #11
    //   215: getfield b : I
    //   218: istore #5
    //   220: iload #5
    //   222: ldc -2147483648
    //   224: if_icmpeq -> 230
    //   227: goto -> 242
    //   230: aload #11
    //   232: invokevirtual c : ()V
    //   235: aload #11
    //   237: getfield b : I
    //   240: istore #5
    //   242: iload #5
    //   244: aload_0
    //   245: getfield d : Lum;
    //   248: invokevirtual k : ()I
    //   251: if_icmple -> 285
    //   254: aload #11
    //   256: aload #11
    //   258: getfield a : Ljava/util/ArrayList;
    //   261: iconst_0
    //   262: invokevirtual get : (I)Ljava/lang/Object;
    //   265: checkcast android/view/View
    //   268: invokevirtual l : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   271: getfield b : Z
    //   274: istore #7
    //   276: iload #7
    //   278: iconst_1
    //   279: ixor
    //   280: istore #5
    //   282: goto -> 288
    //   285: iconst_0
    //   286: istore #5
    //   288: iload #5
    //   290: ifeq -> 296
    //   293: aload #9
    //   295: areturn
    //   296: aload #8
    //   298: aload #10
    //   300: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   303: getfield e : I
    //   306: invokevirtual clear : (I)V
    //   309: aload #10
    //   311: getfield b : Z
    //   314: ifeq -> 320
    //   317: goto -> 504
    //   320: iload_1
    //   321: iload #4
    //   323: iadd
    //   324: istore #5
    //   326: iload #5
    //   328: iload_3
    //   329: if_icmpeq -> 504
    //   332: aload_0
    //   333: iload #5
    //   335: invokevirtual getChildAt : (I)Landroid/view/View;
    //   338: astore #11
    //   340: aload_0
    //   341: getfield s : Z
    //   344: ifeq -> 389
    //   347: aload_0
    //   348: getfield d : Lum;
    //   351: aload #9
    //   353: invokevirtual b : (Landroid/view/View;)I
    //   356: istore #5
    //   358: aload_0
    //   359: getfield d : Lum;
    //   362: aload #11
    //   364: invokevirtual b : (Landroid/view/View;)I
    //   367: istore #6
    //   369: iload #5
    //   371: iload #6
    //   373: if_icmpge -> 379
    //   376: aload #9
    //   378: areturn
    //   379: iload #5
    //   381: iload #6
    //   383: if_icmpne -> 434
    //   386: goto -> 428
    //   389: aload_0
    //   390: getfield d : Lum;
    //   393: aload #9
    //   395: invokevirtual e : (Landroid/view/View;)I
    //   398: istore #5
    //   400: aload_0
    //   401: getfield d : Lum;
    //   404: aload #11
    //   406: invokevirtual e : (Landroid/view/View;)I
    //   409: istore #6
    //   411: iload #5
    //   413: iload #6
    //   415: if_icmple -> 421
    //   418: aload #9
    //   420: areturn
    //   421: iload #5
    //   423: iload #6
    //   425: if_icmpne -> 434
    //   428: iconst_1
    //   429: istore #5
    //   431: goto -> 437
    //   434: iconst_0
    //   435: istore #5
    //   437: iload #5
    //   439: ifeq -> 504
    //   442: aload #11
    //   444: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   447: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   450: astore #11
    //   452: aload #10
    //   454: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   457: getfield e : I
    //   460: aload #11
    //   462: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   465: getfield e : I
    //   468: isub
    //   469: ifge -> 478
    //   472: iconst_1
    //   473: istore #5
    //   475: goto -> 481
    //   478: iconst_0
    //   479: istore #5
    //   481: iload_2
    //   482: ifge -> 491
    //   485: iconst_1
    //   486: istore #6
    //   488: goto -> 494
    //   491: iconst_0
    //   492: istore #6
    //   494: iload #5
    //   496: iload #6
    //   498: if_icmpeq -> 504
    //   501: aload #9
    //   503: areturn
    //   504: iload_1
    //   505: iload #4
    //   507: iadd
    //   508: istore_1
    //   509: goto -> 85
    //   512: aconst_null
    //   513: areturn
  }
  
  public final void n(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    calculateItemDecorationsForChild(paramView, this.C);
    c c = (c)paramView.getLayoutParams();
    int i = c.leftMargin;
    Rect rect = this.C;
    paramInt1 = z(paramInt1, i + rect.left, c.rightMargin + rect.right);
    i = c.topMargin;
    rect = this.C;
    paramInt2 = z(paramInt2, i + rect.top, c.bottomMargin + rect.bottom);
    if (paramBoolean) {
      paramBoolean = shouldReMeasureChild(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = shouldMeasureChild(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public final void o(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield u : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual removeAndRecycleAllViews : (Landroidx/recyclerview/widget/RecyclerView$v;)V
    //   33: aload #14
    //   35: invokevirtual b : ()V
    //   38: return
    //   39: aload #14
    //   41: getfield e : Z
    //   44: istore #13
    //   46: iconst_1
    //   47: istore #10
    //   49: iload #13
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield u : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #8
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #8
    //   81: iload #8
    //   83: ifeq -> 1092
    //   86: aload #14
    //   88: invokevirtual b : ()V
    //   91: aload_0
    //   92: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   95: astore #15
    //   97: aload #15
    //   99: ifnull -> 434
    //   102: aload #15
    //   104: getfield d : I
    //   107: istore #7
    //   109: iload #7
    //   111: ifle -> 280
    //   114: iload #7
    //   116: aload_0
    //   117: getfield b : I
    //   120: if_icmpne -> 240
    //   123: iconst_0
    //   124: istore #7
    //   126: iload #7
    //   128: aload_0
    //   129: getfield b : I
    //   132: if_icmpge -> 280
    //   135: aload_0
    //   136: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   139: iload #7
    //   141: aaload
    //   142: invokevirtual d : ()V
    //   145: aload_0
    //   146: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   149: astore #15
    //   151: aload #15
    //   153: getfield f : [I
    //   156: iload #7
    //   158: iaload
    //   159: istore #11
    //   161: iload #11
    //   163: istore #9
    //   165: iload #11
    //   167: ldc -2147483648
    //   169: if_icmpeq -> 208
    //   172: aload #15
    //   174: getfield s : Z
    //   177: ifeq -> 192
    //   180: aload_0
    //   181: getfield d : Lum;
    //   184: invokevirtual g : ()I
    //   187: istore #9
    //   189: goto -> 201
    //   192: aload_0
    //   193: getfield d : Lum;
    //   196: invokevirtual k : ()I
    //   199: istore #9
    //   201: iload #11
    //   203: iload #9
    //   205: iadd
    //   206: istore #9
    //   208: aload_0
    //   209: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   212: iload #7
    //   214: aaload
    //   215: astore #15
    //   217: aload #15
    //   219: iload #9
    //   221: putfield b : I
    //   224: aload #15
    //   226: iload #9
    //   228: putfield c : I
    //   231: iload #7
    //   233: iconst_1
    //   234: iadd
    //   235: istore #7
    //   237: goto -> 126
    //   240: aload #15
    //   242: aconst_null
    //   243: putfield f : [I
    //   246: aload #15
    //   248: iconst_0
    //   249: putfield d : I
    //   252: aload #15
    //   254: iconst_0
    //   255: putfield g : I
    //   258: aload #15
    //   260: aconst_null
    //   261: putfield p : [I
    //   264: aload #15
    //   266: aconst_null
    //   267: putfield q : Ljava/util/List;
    //   270: aload #15
    //   272: aload #15
    //   274: getfield c : I
    //   277: putfield b : I
    //   280: aload_0
    //   281: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   284: astore #15
    //   286: aload_0
    //   287: aload #15
    //   289: getfield t : Z
    //   292: putfield z : Z
    //   295: aload #15
    //   297: getfield r : Z
    //   300: istore #13
    //   302: aload_0
    //   303: aconst_null
    //   304: invokevirtual assertNotInLayoutOrScroll : (Ljava/lang/String;)V
    //   307: aload_0
    //   308: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   311: astore #15
    //   313: aload #15
    //   315: ifnull -> 335
    //   318: aload #15
    //   320: getfield r : Z
    //   323: iload #13
    //   325: if_icmpeq -> 335
    //   328: aload #15
    //   330: iload #13
    //   332: putfield r : Z
    //   335: aload_0
    //   336: iload #13
    //   338: putfield r : Z
    //   341: aload_0
    //   342: invokevirtual requestLayout : ()V
    //   345: aload_0
    //   346: invokevirtual resolveShouldLayoutReverse : ()V
    //   349: aload_0
    //   350: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   353: astore #15
    //   355: aload #15
    //   357: getfield b : I
    //   360: istore #7
    //   362: iload #7
    //   364: iconst_m1
    //   365: if_icmpeq -> 387
    //   368: aload_0
    //   369: iload #7
    //   371: putfield u : I
    //   374: aload #14
    //   376: aload #15
    //   378: getfield s : Z
    //   381: putfield c : Z
    //   384: goto -> 396
    //   387: aload #14
    //   389: aload_0
    //   390: getfield s : Z
    //   393: putfield c : Z
    //   396: aload #15
    //   398: getfield g : I
    //   401: iconst_1
    //   402: if_icmple -> 447
    //   405: aload_0
    //   406: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   409: astore #16
    //   411: aload #16
    //   413: aload #15
    //   415: getfield p : [I
    //   418: putfield a : [I
    //   421: aload #16
    //   423: aload #15
    //   425: getfield q : Ljava/util/List;
    //   428: putfield b : Ljava/util/List;
    //   431: goto -> 447
    //   434: aload_0
    //   435: invokevirtual resolveShouldLayoutReverse : ()V
    //   438: aload #14
    //   440: aload_0
    //   441: getfield s : Z
    //   444: putfield c : Z
    //   447: aload_2
    //   448: getfield g : Z
    //   451: ifne -> 927
    //   454: aload_0
    //   455: getfield u : I
    //   458: istore #7
    //   460: iload #7
    //   462: iconst_m1
    //   463: if_icmpne -> 469
    //   466: goto -> 927
    //   469: iload #7
    //   471: iflt -> 916
    //   474: iload #7
    //   476: aload_2
    //   477: invokevirtual b : ()I
    //   480: if_icmplt -> 486
    //   483: goto -> 916
    //   486: aload_0
    //   487: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   490: astore #15
    //   492: aload #15
    //   494: ifnull -> 537
    //   497: aload #15
    //   499: getfield b : I
    //   502: iconst_m1
    //   503: if_icmpeq -> 537
    //   506: aload #15
    //   508: getfield d : I
    //   511: iconst_1
    //   512: if_icmpge -> 518
    //   515: goto -> 537
    //   518: aload #14
    //   520: ldc -2147483648
    //   522: putfield b : I
    //   525: aload #14
    //   527: aload_0
    //   528: getfield u : I
    //   531: putfield a : I
    //   534: goto -> 910
    //   537: aload_0
    //   538: aload_0
    //   539: getfield u : I
    //   542: invokevirtual findViewByPosition : (I)Landroid/view/View;
    //   545: astore #15
    //   547: aload #15
    //   549: ifnull -> 795
    //   552: aload_0
    //   553: getfield s : Z
    //   556: ifeq -> 568
    //   559: aload_0
    //   560: invokevirtual i : ()I
    //   563: istore #7
    //   565: goto -> 574
    //   568: aload_0
    //   569: invokevirtual h : ()I
    //   572: istore #7
    //   574: aload #14
    //   576: iload #7
    //   578: putfield a : I
    //   581: aload_0
    //   582: getfield v : I
    //   585: ldc -2147483648
    //   587: if_icmpeq -> 658
    //   590: aload #14
    //   592: getfield c : Z
    //   595: ifeq -> 628
    //   598: aload #14
    //   600: aload_0
    //   601: getfield d : Lum;
    //   604: invokevirtual g : ()I
    //   607: aload_0
    //   608: getfield v : I
    //   611: isub
    //   612: aload_0
    //   613: getfield d : Lum;
    //   616: aload #15
    //   618: invokevirtual b : (Landroid/view/View;)I
    //   621: isub
    //   622: putfield b : I
    //   625: goto -> 910
    //   628: aload #14
    //   630: aload_0
    //   631: getfield d : Lum;
    //   634: invokevirtual k : ()I
    //   637: aload_0
    //   638: getfield v : I
    //   641: iadd
    //   642: aload_0
    //   643: getfield d : Lum;
    //   646: aload #15
    //   648: invokevirtual e : (Landroid/view/View;)I
    //   651: isub
    //   652: putfield b : I
    //   655: goto -> 910
    //   658: aload_0
    //   659: getfield d : Lum;
    //   662: aload #15
    //   664: invokevirtual c : (Landroid/view/View;)I
    //   667: aload_0
    //   668: getfield d : Lum;
    //   671: invokevirtual l : ()I
    //   674: if_icmple -> 716
    //   677: aload #14
    //   679: getfield c : Z
    //   682: ifeq -> 697
    //   685: aload_0
    //   686: getfield d : Lum;
    //   689: invokevirtual g : ()I
    //   692: istore #7
    //   694: goto -> 706
    //   697: aload_0
    //   698: getfield d : Lum;
    //   701: invokevirtual k : ()I
    //   704: istore #7
    //   706: aload #14
    //   708: iload #7
    //   710: putfield b : I
    //   713: goto -> 910
    //   716: aload_0
    //   717: getfield d : Lum;
    //   720: aload #15
    //   722: invokevirtual e : (Landroid/view/View;)I
    //   725: aload_0
    //   726: getfield d : Lum;
    //   729: invokevirtual k : ()I
    //   732: isub
    //   733: istore #7
    //   735: iload #7
    //   737: ifge -> 751
    //   740: aload #14
    //   742: iload #7
    //   744: ineg
    //   745: putfield b : I
    //   748: goto -> 910
    //   751: aload_0
    //   752: getfield d : Lum;
    //   755: invokevirtual g : ()I
    //   758: aload_0
    //   759: getfield d : Lum;
    //   762: aload #15
    //   764: invokevirtual b : (Landroid/view/View;)I
    //   767: isub
    //   768: istore #7
    //   770: iload #7
    //   772: ifge -> 785
    //   775: aload #14
    //   777: iload #7
    //   779: putfield b : I
    //   782: goto -> 910
    //   785: aload #14
    //   787: ldc -2147483648
    //   789: putfield b : I
    //   792: goto -> 910
    //   795: aload_0
    //   796: getfield u : I
    //   799: istore #7
    //   801: aload #14
    //   803: iload #7
    //   805: putfield a : I
    //   808: aload_0
    //   809: getfield v : I
    //   812: istore #9
    //   814: iload #9
    //   816: ldc -2147483648
    //   818: if_icmpne -> 855
    //   821: aload_0
    //   822: iload #7
    //   824: invokevirtual a : (I)I
    //   827: iconst_1
    //   828: if_icmpne -> 837
    //   831: iconst_1
    //   832: istore #13
    //   834: goto -> 840
    //   837: iconst_0
    //   838: istore #13
    //   840: aload #14
    //   842: iload #13
    //   844: putfield c : Z
    //   847: aload #14
    //   849: invokevirtual a : ()V
    //   852: goto -> 904
    //   855: aload #14
    //   857: getfield c : Z
    //   860: ifeq -> 885
    //   863: aload #14
    //   865: aload #14
    //   867: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   870: getfield d : Lum;
    //   873: invokevirtual g : ()I
    //   876: iload #9
    //   878: isub
    //   879: putfield b : I
    //   882: goto -> 904
    //   885: aload #14
    //   887: aload #14
    //   889: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   892: getfield d : Lum;
    //   895: invokevirtual k : ()I
    //   898: iload #9
    //   900: iadd
    //   901: putfield b : I
    //   904: aload #14
    //   906: iconst_1
    //   907: putfield d : Z
    //   910: iconst_1
    //   911: istore #7
    //   913: goto -> 930
    //   916: aload_0
    //   917: iconst_m1
    //   918: putfield u : I
    //   921: aload_0
    //   922: ldc -2147483648
    //   924: putfield v : I
    //   927: iconst_0
    //   928: istore #7
    //   930: iload #7
    //   932: ifeq -> 938
    //   935: goto -> 1086
    //   938: aload_0
    //   939: getfield y : Z
    //   942: ifeq -> 1007
    //   945: aload_2
    //   946: invokevirtual b : ()I
    //   949: istore #12
    //   951: aload_0
    //   952: invokevirtual getChildCount : ()I
    //   955: istore #7
    //   957: iload #7
    //   959: iconst_1
    //   960: isub
    //   961: istore #9
    //   963: iload #9
    //   965: iflt -> 1069
    //   968: aload_0
    //   969: aload_0
    //   970: iload #9
    //   972: invokevirtual getChildAt : (I)Landroid/view/View;
    //   975: invokevirtual getPosition : (Landroid/view/View;)I
    //   978: istore #11
    //   980: iload #9
    //   982: istore #7
    //   984: iload #11
    //   986: iflt -> 957
    //   989: iload #9
    //   991: istore #7
    //   993: iload #11
    //   995: iload #12
    //   997: if_icmpge -> 957
    //   1000: iload #11
    //   1002: istore #7
    //   1004: goto -> 1072
    //   1007: aload_2
    //   1008: invokevirtual b : ()I
    //   1011: istore #11
    //   1013: aload_0
    //   1014: invokevirtual getChildCount : ()I
    //   1017: istore #12
    //   1019: iconst_0
    //   1020: istore #7
    //   1022: iload #7
    //   1024: iload #12
    //   1026: if_icmpge -> 1069
    //   1029: aload_0
    //   1030: aload_0
    //   1031: iload #7
    //   1033: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1036: invokevirtual getPosition : (Landroid/view/View;)I
    //   1039: istore #9
    //   1041: iload #9
    //   1043: iflt -> 1060
    //   1046: iload #9
    //   1048: iload #11
    //   1050: if_icmpge -> 1060
    //   1053: iload #9
    //   1055: istore #7
    //   1057: goto -> 1072
    //   1060: iload #7
    //   1062: iconst_1
    //   1063: iadd
    //   1064: istore #7
    //   1066: goto -> 1022
    //   1069: iconst_0
    //   1070: istore #7
    //   1072: aload #14
    //   1074: iload #7
    //   1076: putfield a : I
    //   1079: aload #14
    //   1081: ldc -2147483648
    //   1083: putfield b : I
    //   1086: aload #14
    //   1088: iconst_1
    //   1089: putfield e : Z
    //   1092: aload_0
    //   1093: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1096: ifnonnull -> 1143
    //   1099: aload_0
    //   1100: getfield u : I
    //   1103: iconst_m1
    //   1104: if_icmpne -> 1143
    //   1107: aload #14
    //   1109: getfield c : Z
    //   1112: aload_0
    //   1113: getfield y : Z
    //   1116: if_icmpne -> 1130
    //   1119: aload_0
    //   1120: invokevirtual isLayoutRTL : ()Z
    //   1123: aload_0
    //   1124: getfield z : Z
    //   1127: if_icmpeq -> 1143
    //   1130: aload_0
    //   1131: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1134: invokevirtual b : ()V
    //   1137: aload #14
    //   1139: iconst_1
    //   1140: putfield d : Z
    //   1143: aload_0
    //   1144: invokevirtual getChildCount : ()I
    //   1147: ifle -> 1582
    //   1150: aload_0
    //   1151: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1154: astore #15
    //   1156: aload #15
    //   1158: ifnull -> 1170
    //   1161: aload #15
    //   1163: getfield d : I
    //   1166: iconst_1
    //   1167: if_icmpge -> 1582
    //   1170: aload #14
    //   1172: getfield d : Z
    //   1175: ifeq -> 1246
    //   1178: iconst_0
    //   1179: istore #7
    //   1181: iload #7
    //   1183: aload_0
    //   1184: getfield b : I
    //   1187: if_icmpge -> 1582
    //   1190: aload_0
    //   1191: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1194: iload #7
    //   1196: aaload
    //   1197: invokevirtual d : ()V
    //   1200: aload #14
    //   1202: getfield b : I
    //   1205: istore #8
    //   1207: iload #8
    //   1209: ldc -2147483648
    //   1211: if_icmpeq -> 1237
    //   1214: aload_0
    //   1215: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1218: iload #7
    //   1220: aaload
    //   1221: astore #15
    //   1223: aload #15
    //   1225: iload #8
    //   1227: putfield b : I
    //   1230: aload #15
    //   1232: iload #8
    //   1234: putfield c : I
    //   1237: iload #7
    //   1239: iconst_1
    //   1240: iadd
    //   1241: istore #7
    //   1243: goto -> 1181
    //   1246: iload #8
    //   1248: ifne -> 1325
    //   1251: aload_0
    //   1252: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1255: getfield f : [I
    //   1258: ifnonnull -> 1264
    //   1261: goto -> 1325
    //   1264: iconst_0
    //   1265: istore #7
    //   1267: iload #7
    //   1269: aload_0
    //   1270: getfield b : I
    //   1273: if_icmpge -> 1582
    //   1276: aload_0
    //   1277: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1280: iload #7
    //   1282: aaload
    //   1283: astore #15
    //   1285: aload #15
    //   1287: invokevirtual d : ()V
    //   1290: aload_0
    //   1291: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1294: getfield f : [I
    //   1297: iload #7
    //   1299: iaload
    //   1300: istore #8
    //   1302: aload #15
    //   1304: iload #8
    //   1306: putfield b : I
    //   1309: aload #15
    //   1311: iload #8
    //   1313: putfield c : I
    //   1316: iload #7
    //   1318: iconst_1
    //   1319: iadd
    //   1320: istore #7
    //   1322: goto -> 1267
    //   1325: iconst_0
    //   1326: istore #8
    //   1328: iload #8
    //   1330: aload_0
    //   1331: getfield b : I
    //   1334: if_icmpge -> 1486
    //   1337: aload_0
    //   1338: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1341: iload #8
    //   1343: aaload
    //   1344: astore #15
    //   1346: aload_0
    //   1347: getfield s : Z
    //   1350: istore #13
    //   1352: aload #14
    //   1354: getfield b : I
    //   1357: istore #11
    //   1359: iload #13
    //   1361: ifeq -> 1376
    //   1364: aload #15
    //   1366: ldc -2147483648
    //   1368: invokevirtual j : (I)I
    //   1371: istore #7
    //   1373: goto -> 1385
    //   1376: aload #15
    //   1378: ldc -2147483648
    //   1380: invokevirtual m : (I)I
    //   1383: istore #7
    //   1385: aload #15
    //   1387: invokevirtual d : ()V
    //   1390: iload #7
    //   1392: ldc -2147483648
    //   1394: if_icmpne -> 1400
    //   1397: goto -> 1477
    //   1400: iload #13
    //   1402: ifeq -> 1421
    //   1405: iload #7
    //   1407: aload #15
    //   1409: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1412: getfield d : Lum;
    //   1415: invokevirtual g : ()I
    //   1418: if_icmplt -> 1477
    //   1421: iload #13
    //   1423: ifne -> 1445
    //   1426: iload #7
    //   1428: aload #15
    //   1430: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1433: getfield d : Lum;
    //   1436: invokevirtual k : ()I
    //   1439: if_icmple -> 1445
    //   1442: goto -> 1477
    //   1445: iload #7
    //   1447: istore #9
    //   1449: iload #11
    //   1451: ldc -2147483648
    //   1453: if_icmpeq -> 1463
    //   1456: iload #7
    //   1458: iload #11
    //   1460: iadd
    //   1461: istore #9
    //   1463: aload #15
    //   1465: iload #9
    //   1467: putfield c : I
    //   1470: aload #15
    //   1472: iload #9
    //   1474: putfield b : I
    //   1477: iload #8
    //   1479: iconst_1
    //   1480: iadd
    //   1481: istore #8
    //   1483: goto -> 1328
    //   1486: aload_0
    //   1487: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1490: astore #15
    //   1492: aload_0
    //   1493: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1496: astore #16
    //   1498: aload #15
    //   1500: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1503: pop
    //   1504: aload #16
    //   1506: arraylength
    //   1507: istore #8
    //   1509: aload #15
    //   1511: getfield f : [I
    //   1514: astore #17
    //   1516: aload #17
    //   1518: ifnull -> 1529
    //   1521: aload #17
    //   1523: arraylength
    //   1524: iload #8
    //   1526: if_icmpge -> 1545
    //   1529: aload #15
    //   1531: aload #15
    //   1533: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1536: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1539: arraylength
    //   1540: newarray int
    //   1542: putfield f : [I
    //   1545: iconst_0
    //   1546: istore #7
    //   1548: iload #7
    //   1550: iload #8
    //   1552: if_icmpge -> 1582
    //   1555: aload #15
    //   1557: getfield f : [I
    //   1560: iload #7
    //   1562: aload #16
    //   1564: iload #7
    //   1566: aaload
    //   1567: ldc -2147483648
    //   1569: invokevirtual m : (I)I
    //   1572: iastore
    //   1573: iload #7
    //   1575: iconst_1
    //   1576: iadd
    //   1577: istore #7
    //   1579: goto -> 1548
    //   1582: aload_0
    //   1583: aload_1
    //   1584: invokevirtual detachAndScrapAttachedViews : (Landroidx/recyclerview/widget/RecyclerView$v;)V
    //   1587: aload_0
    //   1588: getfield q : Lom;
    //   1591: iconst_0
    //   1592: putfield a : Z
    //   1595: aload_0
    //   1596: iconst_0
    //   1597: putfield E : Z
    //   1600: aload_0
    //   1601: getfield f : Lum;
    //   1604: invokevirtual l : ()I
    //   1607: istore #7
    //   1609: aload_0
    //   1610: iload #7
    //   1612: aload_0
    //   1613: getfield b : I
    //   1616: idiv
    //   1617: putfield p : I
    //   1620: aload_0
    //   1621: iload #7
    //   1623: aload_0
    //   1624: getfield f : Lum;
    //   1627: invokevirtual i : ()I
    //   1630: invokestatic makeMeasureSpec : (II)I
    //   1633: putfield B : I
    //   1636: aload_0
    //   1637: aload #14
    //   1639: getfield a : I
    //   1642: aload_2
    //   1643: invokevirtual x : (ILandroidx/recyclerview/widget/RecyclerView$a0;)V
    //   1646: aload #14
    //   1648: getfield c : Z
    //   1651: ifeq -> 1709
    //   1654: aload_0
    //   1655: iconst_m1
    //   1656: invokevirtual u : (I)V
    //   1659: aload_0
    //   1660: aload_1
    //   1661: aload_0
    //   1662: getfield q : Lom;
    //   1665: aload_2
    //   1666: invokevirtual c : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   1669: pop
    //   1670: aload_0
    //   1671: iconst_1
    //   1672: invokevirtual u : (I)V
    //   1675: aload_0
    //   1676: getfield q : Lom;
    //   1679: astore #15
    //   1681: aload #15
    //   1683: aload #14
    //   1685: getfield a : I
    //   1688: aload #15
    //   1690: getfield d : I
    //   1693: iadd
    //   1694: putfield c : I
    //   1697: aload_0
    //   1698: aload_1
    //   1699: aload #15
    //   1701: aload_2
    //   1702: invokevirtual c : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   1705: pop
    //   1706: goto -> 1761
    //   1709: aload_0
    //   1710: iconst_1
    //   1711: invokevirtual u : (I)V
    //   1714: aload_0
    //   1715: aload_1
    //   1716: aload_0
    //   1717: getfield q : Lom;
    //   1720: aload_2
    //   1721: invokevirtual c : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   1724: pop
    //   1725: aload_0
    //   1726: iconst_m1
    //   1727: invokevirtual u : (I)V
    //   1730: aload_0
    //   1731: getfield q : Lom;
    //   1734: astore #15
    //   1736: aload #15
    //   1738: aload #14
    //   1740: getfield a : I
    //   1743: aload #15
    //   1745: getfield d : I
    //   1748: iadd
    //   1749: putfield c : I
    //   1752: aload_0
    //   1753: aload_1
    //   1754: aload #15
    //   1756: aload_2
    //   1757: invokevirtual c : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   1760: pop
    //   1761: aload_0
    //   1762: getfield f : Lum;
    //   1765: invokevirtual i : ()I
    //   1768: ldc_w 1073741824
    //   1771: if_icmpne -> 1777
    //   1774: goto -> 2132
    //   1777: fconst_0
    //   1778: fstore #4
    //   1780: aload_0
    //   1781: invokevirtual getChildCount : ()I
    //   1784: istore #9
    //   1786: iconst_0
    //   1787: istore #7
    //   1789: iload #7
    //   1791: iload #9
    //   1793: if_icmpge -> 1875
    //   1796: aload_0
    //   1797: iload #7
    //   1799: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1802: astore #15
    //   1804: aload_0
    //   1805: getfield f : Lum;
    //   1808: aload #15
    //   1810: invokevirtual c : (Landroid/view/View;)I
    //   1813: i2f
    //   1814: fstore #6
    //   1816: fload #6
    //   1818: fload #4
    //   1820: fcmpg
    //   1821: ifge -> 1827
    //   1824: goto -> 1866
    //   1827: fload #6
    //   1829: fstore #5
    //   1831: aload #15
    //   1833: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1836: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1839: getfield b : Z
    //   1842: ifeq -> 1857
    //   1845: fload #6
    //   1847: fconst_1
    //   1848: fmul
    //   1849: aload_0
    //   1850: getfield b : I
    //   1853: i2f
    //   1854: fdiv
    //   1855: fstore #5
    //   1857: fload #4
    //   1859: fload #5
    //   1861: invokestatic max : (FF)F
    //   1864: fstore #4
    //   1866: iload #7
    //   1868: iconst_1
    //   1869: iadd
    //   1870: istore #7
    //   1872: goto -> 1789
    //   1875: aload_0
    //   1876: getfield p : I
    //   1879: istore #11
    //   1881: fload #4
    //   1883: aload_0
    //   1884: getfield b : I
    //   1887: i2f
    //   1888: fmul
    //   1889: invokestatic round : (F)I
    //   1892: istore #8
    //   1894: iload #8
    //   1896: istore #7
    //   1898: aload_0
    //   1899: getfield f : Lum;
    //   1902: invokevirtual i : ()I
    //   1905: ldc -2147483648
    //   1907: if_icmpne -> 1924
    //   1910: iload #8
    //   1912: aload_0
    //   1913: getfield f : Lum;
    //   1916: invokevirtual l : ()I
    //   1919: invokestatic min : (II)I
    //   1922: istore #7
    //   1924: aload_0
    //   1925: iload #7
    //   1927: aload_0
    //   1928: getfield b : I
    //   1931: idiv
    //   1932: putfield p : I
    //   1935: aload_0
    //   1936: iload #7
    //   1938: aload_0
    //   1939: getfield f : Lum;
    //   1942: invokevirtual i : ()I
    //   1945: invokestatic makeMeasureSpec : (II)I
    //   1948: putfield B : I
    //   1951: aload_0
    //   1952: getfield p : I
    //   1955: iload #11
    //   1957: if_icmpne -> 1963
    //   1960: goto -> 2132
    //   1963: iconst_0
    //   1964: istore #7
    //   1966: iload #7
    //   1968: iload #9
    //   1970: if_icmpge -> 2132
    //   1973: aload_0
    //   1974: iload #7
    //   1976: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1979: astore #15
    //   1981: aload #15
    //   1983: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1986: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1989: astore #16
    //   1991: aload #16
    //   1993: getfield b : Z
    //   1996: ifeq -> 2002
    //   1999: goto -> 2123
    //   2002: aload_0
    //   2003: invokevirtual isLayoutRTL : ()Z
    //   2006: ifeq -> 2066
    //   2009: aload_0
    //   2010: getfield g : I
    //   2013: iconst_1
    //   2014: if_icmpne -> 2066
    //   2017: aload_0
    //   2018: getfield b : I
    //   2021: istore #8
    //   2023: aload #16
    //   2025: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2028: getfield e : I
    //   2031: istore #12
    //   2033: aload #15
    //   2035: iload #8
    //   2037: iconst_1
    //   2038: isub
    //   2039: iload #12
    //   2041: isub
    //   2042: ineg
    //   2043: aload_0
    //   2044: getfield p : I
    //   2047: imul
    //   2048: iload #8
    //   2050: iconst_1
    //   2051: isub
    //   2052: iload #12
    //   2054: isub
    //   2055: ineg
    //   2056: iload #11
    //   2058: imul
    //   2059: isub
    //   2060: invokevirtual offsetLeftAndRight : (I)V
    //   2063: goto -> 2123
    //   2066: aload #16
    //   2068: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2071: getfield e : I
    //   2074: istore #12
    //   2076: aload_0
    //   2077: getfield p : I
    //   2080: iload #12
    //   2082: imul
    //   2083: istore #8
    //   2085: iload #12
    //   2087: iload #11
    //   2089: imul
    //   2090: istore #12
    //   2092: aload_0
    //   2093: getfield g : I
    //   2096: iconst_1
    //   2097: if_icmpne -> 2113
    //   2100: aload #15
    //   2102: iload #8
    //   2104: iload #12
    //   2106: isub
    //   2107: invokevirtual offsetLeftAndRight : (I)V
    //   2110: goto -> 2123
    //   2113: aload #15
    //   2115: iload #8
    //   2117: iload #12
    //   2119: isub
    //   2120: invokevirtual offsetTopAndBottom : (I)V
    //   2123: iload #7
    //   2125: iconst_1
    //   2126: iadd
    //   2127: istore #7
    //   2129: goto -> 1966
    //   2132: aload_0
    //   2133: invokevirtual getChildCount : ()I
    //   2136: ifle -> 2177
    //   2139: aload_0
    //   2140: getfield s : Z
    //   2143: ifeq -> 2163
    //   2146: aload_0
    //   2147: aload_1
    //   2148: aload_2
    //   2149: iconst_1
    //   2150: invokevirtual f : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   2153: aload_0
    //   2154: aload_1
    //   2155: aload_2
    //   2156: iconst_0
    //   2157: invokevirtual g : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   2160: goto -> 2177
    //   2163: aload_0
    //   2164: aload_1
    //   2165: aload_2
    //   2166: iconst_1
    //   2167: invokevirtual g : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   2170: aload_0
    //   2171: aload_1
    //   2172: aload_2
    //   2173: iconst_0
    //   2174: invokevirtual f : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   2177: iload_3
    //   2178: ifeq -> 2253
    //   2181: aload_2
    //   2182: getfield g : Z
    //   2185: ifne -> 2253
    //   2188: aload_0
    //   2189: getfield x : I
    //   2192: ifeq -> 2222
    //   2195: aload_0
    //   2196: invokevirtual getChildCount : ()I
    //   2199: ifle -> 2222
    //   2202: aload_0
    //   2203: getfield E : Z
    //   2206: ifne -> 2216
    //   2209: aload_0
    //   2210: invokevirtual m : ()Landroid/view/View;
    //   2213: ifnull -> 2222
    //   2216: iconst_1
    //   2217: istore #7
    //   2219: goto -> 2225
    //   2222: iconst_0
    //   2223: istore #7
    //   2225: iload #7
    //   2227: ifeq -> 2253
    //   2230: aload_0
    //   2231: aload_0
    //   2232: getfield H : Ljava/lang/Runnable;
    //   2235: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   2238: pop
    //   2239: aload_0
    //   2240: invokevirtual b : ()Z
    //   2243: ifeq -> 2253
    //   2246: iload #10
    //   2248: istore #7
    //   2250: goto -> 2256
    //   2253: iconst_0
    //   2254: istore #7
    //   2256: aload_2
    //   2257: getfield g : Z
    //   2260: ifeq -> 2270
    //   2263: aload_0
    //   2264: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2267: invokevirtual b : ()V
    //   2270: aload_0
    //   2271: aload #14
    //   2273: getfield c : Z
    //   2276: putfield y : Z
    //   2279: aload_0
    //   2280: aload_0
    //   2281: invokevirtual isLayoutRTL : ()Z
    //   2284: putfield z : Z
    //   2287: iload #7
    //   2289: ifeq -> 2306
    //   2292: aload_0
    //   2293: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2296: invokevirtual b : ()V
    //   2299: aload_0
    //   2300: aload_1
    //   2301: aload_2
    //   2302: iconst_0
    //   2303: invokevirtual o : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;Z)V
    //   2306: return
  }
  
  public void offsetChildrenHorizontal(int paramInt) {
    super.offsetChildrenHorizontal(paramInt);
    for (int i = 0; i < this.b; i++) {
      f f1 = this.c[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public void offsetChildrenVertical(int paramInt) {
    super.offsetChildrenVertical(paramInt);
    for (int i = 0; i < this.b; i++) {
      f f1 = this.c[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public void onAdapterChanged(RecyclerView.g paramg1, RecyclerView.g paramg2) {
    this.w.b();
    for (int i = 0; i < this.b; i++)
      this.c[i].d(); 
  }
  
  public void onDetachedFromWindow(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.onDetachedFromWindow(paramRecyclerView, paramv);
    removeCallbacks(this.H);
    for (int i = 0; i < this.b; i++)
      this.c[i].d(); 
    paramRecyclerView.requestLayout();
  }
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: aload_1
    //   11: invokevirtual findContainingItemView : (Landroid/view/View;)Landroid/view/View;
    //   14: astore_1
    //   15: aload_1
    //   16: ifnonnull -> 21
    //   19: aconst_null
    //   20: areturn
    //   21: aload_0
    //   22: invokevirtual resolveShouldLayoutReverse : ()V
    //   25: iload_2
    //   26: iconst_1
    //   27: if_icmpeq -> 136
    //   30: iload_2
    //   31: iconst_2
    //   32: if_icmpeq -> 115
    //   35: iload_2
    //   36: bipush #17
    //   38: if_icmpeq -> 105
    //   41: iload_2
    //   42: bipush #33
    //   44: if_icmpeq -> 92
    //   47: iload_2
    //   48: bipush #66
    //   50: if_icmpeq -> 82
    //   53: iload_2
    //   54: sipush #130
    //   57: if_icmpeq -> 63
    //   60: goto -> 76
    //   63: aload_0
    //   64: getfield g : I
    //   67: iconst_1
    //   68: if_icmpne -> 76
    //   71: iconst_1
    //   72: istore_2
    //   73: goto -> 157
    //   76: ldc -2147483648
    //   78: istore_2
    //   79: goto -> 157
    //   82: aload_0
    //   83: getfield g : I
    //   86: ifne -> 76
    //   89: goto -> 71
    //   92: aload_0
    //   93: getfield g : I
    //   96: iconst_1
    //   97: if_icmpne -> 76
    //   100: iconst_m1
    //   101: istore_2
    //   102: goto -> 157
    //   105: aload_0
    //   106: getfield g : I
    //   109: ifne -> 76
    //   112: goto -> 100
    //   115: aload_0
    //   116: getfield g : I
    //   119: iconst_1
    //   120: if_icmpne -> 126
    //   123: goto -> 71
    //   126: aload_0
    //   127: invokevirtual isLayoutRTL : ()Z
    //   130: ifeq -> 71
    //   133: goto -> 144
    //   136: aload_0
    //   137: getfield g : I
    //   140: iconst_1
    //   141: if_icmpne -> 147
    //   144: goto -> 112
    //   147: aload_0
    //   148: invokevirtual isLayoutRTL : ()Z
    //   151: ifeq -> 100
    //   154: goto -> 71
    //   157: iload_2
    //   158: ldc -2147483648
    //   160: if_icmpne -> 165
    //   163: aconst_null
    //   164: areturn
    //   165: aload_1
    //   166: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   169: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   172: astore #10
    //   174: aload #10
    //   176: getfield b : Z
    //   179: istore #8
    //   181: aload #10
    //   183: getfield a : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   186: astore #10
    //   188: iload_2
    //   189: iconst_1
    //   190: if_icmpne -> 202
    //   193: aload_0
    //   194: invokevirtual i : ()I
    //   197: istore #5
    //   199: goto -> 208
    //   202: aload_0
    //   203: invokevirtual h : ()I
    //   206: istore #5
    //   208: aload_0
    //   209: iload #5
    //   211: aload #4
    //   213: invokevirtual x : (ILandroidx/recyclerview/widget/RecyclerView$a0;)V
    //   216: aload_0
    //   217: iload_2
    //   218: invokevirtual u : (I)V
    //   221: aload_0
    //   222: getfield q : Lom;
    //   225: astore #11
    //   227: aload #11
    //   229: aload #11
    //   231: getfield d : I
    //   234: iload #5
    //   236: iadd
    //   237: putfield c : I
    //   240: aload #11
    //   242: aload_0
    //   243: getfield d : Lum;
    //   246: invokevirtual l : ()I
    //   249: i2f
    //   250: ldc_w 0.33333334
    //   253: fmul
    //   254: f2i
    //   255: putfield b : I
    //   258: aload_0
    //   259: getfield q : Lom;
    //   262: astore #11
    //   264: aload #11
    //   266: iconst_1
    //   267: putfield h : Z
    //   270: iconst_0
    //   271: istore #7
    //   273: aload #11
    //   275: iconst_0
    //   276: putfield a : Z
    //   279: aload_0
    //   280: aload_3
    //   281: aload #11
    //   283: aload #4
    //   285: invokevirtual c : (Landroidx/recyclerview/widget/RecyclerView$v;Lom;Landroidx/recyclerview/widget/RecyclerView$a0;)I
    //   288: pop
    //   289: aload_0
    //   290: aload_0
    //   291: getfield s : Z
    //   294: putfield y : Z
    //   297: iload #8
    //   299: ifne -> 322
    //   302: aload #10
    //   304: iload #5
    //   306: iload_2
    //   307: invokevirtual k : (II)Landroid/view/View;
    //   310: astore_3
    //   311: aload_3
    //   312: ifnull -> 322
    //   315: aload_3
    //   316: aload_1
    //   317: if_acmpeq -> 322
    //   320: aload_3
    //   321: areturn
    //   322: aload_0
    //   323: iload_2
    //   324: invokevirtual p : (I)Z
    //   327: ifeq -> 377
    //   330: aload_0
    //   331: getfield b : I
    //   334: iconst_1
    //   335: isub
    //   336: istore #6
    //   338: iload #6
    //   340: iflt -> 423
    //   343: aload_0
    //   344: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   347: iload #6
    //   349: aaload
    //   350: iload #5
    //   352: iload_2
    //   353: invokevirtual k : (II)Landroid/view/View;
    //   356: astore_3
    //   357: aload_3
    //   358: ifnull -> 368
    //   361: aload_3
    //   362: aload_1
    //   363: if_acmpeq -> 368
    //   366: aload_3
    //   367: areturn
    //   368: iload #6
    //   370: iconst_1
    //   371: isub
    //   372: istore #6
    //   374: goto -> 338
    //   377: iconst_0
    //   378: istore #6
    //   380: iload #6
    //   382: aload_0
    //   383: getfield b : I
    //   386: if_icmpge -> 423
    //   389: aload_0
    //   390: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   393: iload #6
    //   395: aaload
    //   396: iload #5
    //   398: iload_2
    //   399: invokevirtual k : (II)Landroid/view/View;
    //   402: astore_3
    //   403: aload_3
    //   404: ifnull -> 414
    //   407: aload_3
    //   408: aload_1
    //   409: if_acmpeq -> 414
    //   412: aload_3
    //   413: areturn
    //   414: iload #6
    //   416: iconst_1
    //   417: iadd
    //   418: istore #6
    //   420: goto -> 380
    //   423: aload_0
    //   424: getfield r : Z
    //   427: istore #9
    //   429: iload_2
    //   430: iconst_m1
    //   431: if_icmpne -> 440
    //   434: iconst_1
    //   435: istore #5
    //   437: goto -> 443
    //   440: iconst_0
    //   441: istore #5
    //   443: iload #9
    //   445: iconst_1
    //   446: ixor
    //   447: iload #5
    //   449: if_icmpne -> 458
    //   452: iconst_1
    //   453: istore #5
    //   455: goto -> 461
    //   458: iconst_0
    //   459: istore #5
    //   461: iload #8
    //   463: ifne -> 506
    //   466: iload #5
    //   468: ifeq -> 481
    //   471: aload #10
    //   473: invokevirtual e : ()I
    //   476: istore #6
    //   478: goto -> 488
    //   481: aload #10
    //   483: invokevirtual f : ()I
    //   486: istore #6
    //   488: aload_0
    //   489: iload #6
    //   491: invokevirtual findViewByPosition : (I)Landroid/view/View;
    //   494: astore_3
    //   495: aload_3
    //   496: ifnull -> 506
    //   499: aload_3
    //   500: aload_1
    //   501: if_acmpeq -> 506
    //   504: aload_3
    //   505: areturn
    //   506: iload #7
    //   508: istore #6
    //   510: aload_0
    //   511: iload_2
    //   512: invokevirtual p : (I)Z
    //   515: ifeq -> 596
    //   518: aload_0
    //   519: getfield b : I
    //   522: iconst_1
    //   523: isub
    //   524: istore_2
    //   525: iload_2
    //   526: iflt -> 661
    //   529: iload_2
    //   530: aload #10
    //   532: getfield e : I
    //   535: if_icmpne -> 541
    //   538: goto -> 589
    //   541: iload #5
    //   543: ifeq -> 560
    //   546: aload_0
    //   547: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   550: iload_2
    //   551: aaload
    //   552: invokevirtual e : ()I
    //   555: istore #6
    //   557: goto -> 571
    //   560: aload_0
    //   561: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   564: iload_2
    //   565: aaload
    //   566: invokevirtual f : ()I
    //   569: istore #6
    //   571: aload_0
    //   572: iload #6
    //   574: invokevirtual findViewByPosition : (I)Landroid/view/View;
    //   577: astore_3
    //   578: aload_3
    //   579: ifnull -> 589
    //   582: aload_3
    //   583: aload_1
    //   584: if_acmpeq -> 589
    //   587: aload_3
    //   588: areturn
    //   589: iload_2
    //   590: iconst_1
    //   591: isub
    //   592: istore_2
    //   593: goto -> 525
    //   596: iload #6
    //   598: aload_0
    //   599: getfield b : I
    //   602: if_icmpge -> 661
    //   605: iload #5
    //   607: ifeq -> 624
    //   610: aload_0
    //   611: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   614: iload #6
    //   616: aaload
    //   617: invokevirtual e : ()I
    //   620: istore_2
    //   621: goto -> 635
    //   624: aload_0
    //   625: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   628: iload #6
    //   630: aaload
    //   631: invokevirtual f : ()I
    //   634: istore_2
    //   635: aload_0
    //   636: iload_2
    //   637: invokevirtual findViewByPosition : (I)Landroid/view/View;
    //   640: astore_3
    //   641: aload_3
    //   642: ifnull -> 652
    //   645: aload_3
    //   646: aload_1
    //   647: if_acmpeq -> 652
    //   650: aload_3
    //   651: areturn
    //   652: iload #6
    //   654: iconst_1
    //   655: iadd
    //   656: istore #6
    //   658: goto -> 596
    //   661: aconst_null
    //   662: areturn
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    if (getChildCount() > 0) {
      View view1 = e(false);
      View view2 = d(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = getPosition(view1);
        int j = getPosition(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    l(paramInt1, paramInt2, 1);
  }
  
  public void onItemsChanged(RecyclerView paramRecyclerView) {
    this.w.b();
    requestLayout();
  }
  
  public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    l(paramInt1, paramInt2, 8);
  }
  
  public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    l(paramInt1, paramInt2, 2);
  }
  
  public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    l(paramInt1, paramInt2, 4);
  }
  
  public void onLayoutChildren(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    o(paramv, parama0, true);
  }
  
  public void onLayoutCompleted(RecyclerView.a0 parama0) {
    super.onLayoutCompleted(parama0);
    this.u = -1;
    this.v = Integer.MIN_VALUE;
    this.A = null;
    this.D.b();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      paramParcelable = paramParcelable;
      this.A = (e)paramParcelable;
      if (this.u != -1) {
        ((e)paramParcelable).f = null;
        ((e)paramParcelable).d = 0;
        ((e)paramParcelable).b = -1;
        ((e)paramParcelable).c = -1;
        ((e)paramParcelable).f = null;
        ((e)paramParcelable).d = 0;
        ((e)paramParcelable).g = 0;
        ((e)paramParcelable).p = null;
        ((e)paramParcelable).q = null;
      } 
      requestLayout();
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;)V
    //   20: areturn
    //   21: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #5
    //   30: aload #5
    //   32: aload_0
    //   33: getfield r : Z
    //   36: putfield r : Z
    //   39: aload #5
    //   41: aload_0
    //   42: getfield y : Z
    //   45: putfield s : Z
    //   48: aload #5
    //   50: aload_0
    //   51: getfield z : Z
    //   54: putfield t : Z
    //   57: aload_0
    //   58: getfield w : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   61: astore #4
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #4
    //   67: ifnull -> 110
    //   70: aload #4
    //   72: getfield a : [I
    //   75: astore #6
    //   77: aload #6
    //   79: ifnull -> 110
    //   82: aload #5
    //   84: aload #6
    //   86: putfield p : [I
    //   89: aload #5
    //   91: aload #6
    //   93: arraylength
    //   94: putfield g : I
    //   97: aload #5
    //   99: aload #4
    //   101: getfield b : Ljava/util/List;
    //   104: putfield q : Ljava/util/List;
    //   107: goto -> 116
    //   110: aload #5
    //   112: iconst_0
    //   113: putfield g : I
    //   116: aload_0
    //   117: invokevirtual getChildCount : ()I
    //   120: istore_1
    //   121: iconst_m1
    //   122: istore_3
    //   123: iload_1
    //   124: ifle -> 312
    //   127: aload_0
    //   128: getfield y : Z
    //   131: ifeq -> 142
    //   134: aload_0
    //   135: invokevirtual i : ()I
    //   138: istore_1
    //   139: goto -> 147
    //   142: aload_0
    //   143: invokevirtual h : ()I
    //   146: istore_1
    //   147: aload #5
    //   149: iload_1
    //   150: putfield b : I
    //   153: aload_0
    //   154: getfield s : Z
    //   157: ifeq -> 170
    //   160: aload_0
    //   161: iconst_1
    //   162: invokevirtual d : (Z)Landroid/view/View;
    //   165: astore #4
    //   167: goto -> 177
    //   170: aload_0
    //   171: iconst_1
    //   172: invokevirtual e : (Z)Landroid/view/View;
    //   175: astore #4
    //   177: aload #4
    //   179: ifnonnull -> 187
    //   182: iload_3
    //   183: istore_1
    //   184: goto -> 194
    //   187: aload_0
    //   188: aload #4
    //   190: invokevirtual getPosition : (Landroid/view/View;)I
    //   193: istore_1
    //   194: aload #5
    //   196: iload_1
    //   197: putfield c : I
    //   200: aload_0
    //   201: getfield b : I
    //   204: istore_1
    //   205: aload #5
    //   207: iload_1
    //   208: putfield d : I
    //   211: aload #5
    //   213: iload_1
    //   214: newarray int
    //   216: putfield f : [I
    //   219: iload_2
    //   220: aload_0
    //   221: getfield b : I
    //   224: if_icmpge -> 330
    //   227: aload_0
    //   228: getfield y : Z
    //   231: ifeq -> 265
    //   234: aload_0
    //   235: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   238: iload_2
    //   239: aaload
    //   240: ldc -2147483648
    //   242: invokevirtual j : (I)I
    //   245: istore_3
    //   246: iload_3
    //   247: istore_1
    //   248: iload_3
    //   249: ldc -2147483648
    //   251: if_icmpeq -> 297
    //   254: aload_0
    //   255: getfield d : Lum;
    //   258: invokevirtual g : ()I
    //   261: istore_1
    //   262: goto -> 293
    //   265: aload_0
    //   266: getfield c : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   269: iload_2
    //   270: aaload
    //   271: ldc -2147483648
    //   273: invokevirtual m : (I)I
    //   276: istore_3
    //   277: iload_3
    //   278: istore_1
    //   279: iload_3
    //   280: ldc -2147483648
    //   282: if_icmpeq -> 297
    //   285: aload_0
    //   286: getfield d : Lum;
    //   289: invokevirtual k : ()I
    //   292: istore_1
    //   293: iload_3
    //   294: iload_1
    //   295: isub
    //   296: istore_1
    //   297: aload #5
    //   299: getfield f : [I
    //   302: iload_2
    //   303: iload_1
    //   304: iastore
    //   305: iload_2
    //   306: iconst_1
    //   307: iadd
    //   308: istore_2
    //   309: goto -> 219
    //   312: aload #5
    //   314: iconst_m1
    //   315: putfield b : I
    //   318: aload #5
    //   320: iconst_m1
    //   321: putfield c : I
    //   324: aload #5
    //   326: iconst_0
    //   327: putfield d : I
    //   330: aload #5
    //   332: areturn
  }
  
  public void onScrollStateChanged(int paramInt) {
    if (paramInt == 0)
      b(); 
  }
  
  public final boolean p(int paramInt) {
    boolean bool;
    if (this.g == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.s);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.s) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == isLayoutRTL());
  }
  
  public void q(int paramInt, RecyclerView.a0 parama0) {
    int i;
    byte b1;
    if (paramInt > 0) {
      i = i();
      b1 = 1;
    } else {
      i = h();
      b1 = -1;
    } 
    this.q.a = true;
    x(i, parama0);
    u(b1);
    om om1 = this.q;
    om1.c = i + om1.d;
    om1.b = Math.abs(paramInt);
  }
  
  public final void r(RecyclerView.v paramv, om paramom) {
    if (paramom.a) {
      if (paramom.i)
        return; 
      if (paramom.b == 0) {
        if (paramom.e == -1) {
          s(paramv, paramom.g);
          return;
        } 
        t(paramv, paramom.f);
        return;
      } 
      int k = paramom.e;
      int j = 1;
      int i = 1;
      if (k == -1) {
        int n = paramom.f;
        for (j = this.c[0].m(n); i < this.b; j = k) {
          int i1 = this.c[i].m(n);
          k = j;
          if (i1 > j)
            k = i1; 
          i++;
        } 
        i = n - j;
        if (i < 0) {
          i = paramom.g;
        } else {
          i = paramom.g - Math.min(i, paramom.b);
        } 
        s(paramv, i);
        return;
      } 
      int m = paramom.g;
      k = this.c[0].j(m);
      i = j;
      for (j = k; i < this.b; j = k) {
        int n = this.c[i].j(m);
        k = j;
        if (n < j)
          k = n; 
        i++;
      } 
      i = j - paramom.g;
      if (i < 0) {
        i = paramom.f;
      } else {
        j = paramom.f;
        i = Math.min(i, paramom.b) + j;
      } 
      t(paramv, i);
    } 
  }
  
  public final void resolveShouldLayoutReverse() {
    if (this.g == 1 || !isLayoutRTL()) {
      this.s = this.r;
      return;
    } 
    this.s = this.r ^ true;
  }
  
  public final void s(RecyclerView.v paramv, int paramInt) {
    int i = getChildCount() - 1;
    while (i >= 0) {
      View view = getChildAt(i);
      if (this.d.e(view) >= paramInt && this.d.o(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.b) {
          int k;
          byte b1 = 0;
          int j = 0;
          while (true) {
            k = b1;
            if (j < this.b) {
              if ((this.c[j]).a.size() == 1)
                return; 
              j++;
              continue;
            } 
            break;
          } 
          while (k < this.b) {
            this.c[k].n();
            k++;
          } 
        } else {
          if (c.a.a.size() == 1)
            return; 
          c.a.n();
        } 
        removeAndRecycleView(view, paramv);
        i--;
      } 
    } 
  }
  
  public int scrollBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (getChildCount() != 0) {
      if (paramInt == 0)
        return 0; 
      q(paramInt, parama0);
      int i = c(paramv, this.q, parama0);
      if (this.q.b >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.d.p(-paramInt);
      this.y = this.s;
      om om1 = this.q;
      om1.b = 0;
      r(paramv, om1);
      return paramInt;
    } 
    return 0;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return scrollBy(paramInt, paramv, parama0);
  }
  
  public void scrollToPosition(int paramInt) {
    e e1 = this.A;
    if (e1 != null && e1.b != paramInt) {
      e1.f = null;
      e1.d = 0;
      e1.b = -1;
      e1.c = -1;
    } 
    this.u = paramInt;
    this.v = Integer.MIN_VALUE;
    requestLayout();
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return scrollBy(paramInt, paramv, parama0);
  }
  
  public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2) {
    int i = getPaddingLeft();
    i = getPaddingRight() + i;
    int j = getPaddingTop();
    j = getPaddingBottom() + j;
    if (this.g == 1) {
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, paramRect.height() + j, getMinimumHeight());
      i = RecyclerView.o.chooseSize(paramInt1, this.p * this.b + i, getMinimumWidth());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, paramRect.width() + i, getMinimumWidth());
      i = RecyclerView.o.chooseSize(paramInt2, this.p * this.b + j, getMinimumHeight());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    setMeasuredDimension(paramInt2, paramInt1);
  }
  
  public void smoothScrollToPosition(RecyclerView paramRecyclerView, RecyclerView.a0 parama0, int paramInt) {
    pm pm = new pm(paramRecyclerView.getContext());
    pm.setTargetPosition(paramInt);
    startSmoothScroll((RecyclerView.z)pm);
  }
  
  public boolean supportsPredictiveItemAnimations() {
    return (this.A == null);
  }
  
  public final void t(RecyclerView.v paramv, int paramInt) {
    while (getChildCount() > 0) {
      byte b1 = 0;
      View view = getChildAt(0);
      if (this.d.b(view) <= paramInt && this.d.n(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.b) {
          int j;
          int i = 0;
          while (true) {
            j = b1;
            if (i < this.b) {
              if ((this.c[i]).a.size() == 1)
                return; 
              i++;
              continue;
            } 
            break;
          } 
          while (j < this.b) {
            this.c[j].o();
            j++;
          } 
        } else {
          if (c.a.a.size() == 1)
            return; 
          c.a.o();
        } 
        removeAndRecycleView(view, paramv);
      } 
    } 
  }
  
  public final void u(int paramInt) {
    boolean bool1;
    om om1 = this.q;
    om1.e = paramInt;
    boolean bool2 = this.s;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    om1.d = paramInt;
  }
  
  public void v(int paramInt) {
    assertNotInLayoutOrScroll(null);
    if (paramInt != this.b) {
      this.w.b();
      requestLayout();
      this.b = paramInt;
      this.t = new BitSet(this.b);
      this.c = new f[this.b];
      for (paramInt = 0; paramInt < this.b; paramInt++)
        this.c[paramInt] = new f(this, paramInt); 
      requestLayout();
    } 
  }
  
  public final void w(int paramInt1, int paramInt2) {
    for (int i = 0; i < this.b; i++) {
      if (!(this.c[i]).a.isEmpty())
        y(this.c[i], paramInt1, paramInt2); 
    } 
  }
  
  public final void x(int paramInt, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lom;
    //   4: astore #7
    //   6: iconst_0
    //   7: istore #5
    //   9: aload #7
    //   11: iconst_0
    //   12: putfield b : I
    //   15: aload #7
    //   17: iload_1
    //   18: putfield c : I
    //   21: aload_0
    //   22: invokevirtual isSmoothScrolling : ()Z
    //   25: ifeq -> 89
    //   28: aload_2
    //   29: getfield a : I
    //   32: istore_3
    //   33: iload_3
    //   34: iconst_m1
    //   35: if_icmpeq -> 89
    //   38: aload_0
    //   39: getfield s : Z
    //   42: istore #6
    //   44: iload_3
    //   45: iload_1
    //   46: if_icmpge -> 55
    //   49: iconst_1
    //   50: istore #4
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #4
    //   58: iload #6
    //   60: iload #4
    //   62: if_icmpne -> 76
    //   65: aload_0
    //   66: getfield d : Lum;
    //   69: invokevirtual l : ()I
    //   72: istore_1
    //   73: goto -> 91
    //   76: aload_0
    //   77: getfield d : Lum;
    //   80: invokevirtual l : ()I
    //   83: istore_3
    //   84: iconst_0
    //   85: istore_1
    //   86: goto -> 93
    //   89: iconst_0
    //   90: istore_1
    //   91: iconst_0
    //   92: istore_3
    //   93: aload_0
    //   94: invokevirtual getClipToPadding : ()Z
    //   97: ifeq -> 135
    //   100: aload_0
    //   101: getfield q : Lom;
    //   104: aload_0
    //   105: getfield d : Lum;
    //   108: invokevirtual k : ()I
    //   111: iload_3
    //   112: isub
    //   113: putfield f : I
    //   116: aload_0
    //   117: getfield q : Lom;
    //   120: aload_0
    //   121: getfield d : Lum;
    //   124: invokevirtual g : ()I
    //   127: iload_1
    //   128: iadd
    //   129: putfield g : I
    //   132: goto -> 160
    //   135: aload_0
    //   136: getfield q : Lom;
    //   139: aload_0
    //   140: getfield d : Lum;
    //   143: invokevirtual f : ()I
    //   146: iload_1
    //   147: iadd
    //   148: putfield g : I
    //   151: aload_0
    //   152: getfield q : Lom;
    //   155: iload_3
    //   156: ineg
    //   157: putfield f : I
    //   160: aload_0
    //   161: getfield q : Lom;
    //   164: astore_2
    //   165: aload_2
    //   166: iconst_0
    //   167: putfield h : Z
    //   170: aload_2
    //   171: iconst_1
    //   172: putfield a : Z
    //   175: iload #5
    //   177: istore #4
    //   179: aload_0
    //   180: getfield d : Lum;
    //   183: invokevirtual i : ()I
    //   186: ifne -> 206
    //   189: iload #5
    //   191: istore #4
    //   193: aload_0
    //   194: getfield d : Lum;
    //   197: invokevirtual f : ()I
    //   200: ifne -> 206
    //   203: iconst_1
    //   204: istore #4
    //   206: aload_2
    //   207: iload #4
    //   209: putfield i : Z
    //   212: return
  }
  
  public final void y(f paramf, int paramInt1, int paramInt2) {
    int i = paramf.d;
    if (paramInt1 == -1) {
      paramInt1 = paramf.b;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.c();
        paramInt1 = paramf.b;
      } 
      if (paramInt1 + i <= paramInt2) {
        this.t.set(paramf.e, false);
        return;
      } 
    } else {
      paramInt1 = paramf.c;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.b();
        paramInt1 = paramf.c;
      } 
      if (paramInt1 - i >= paramInt2)
        this.t.set(paramf.e, false); 
    } 
  }
  
  public final int z(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public class a implements Runnable {
    public a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.b.b();
    }
  }
  
  public class b {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public int[] f;
    
    public b(StaggeredGridLayoutManager this$0) {
      b();
    }
    
    public void a() {
      int i;
      if (this.c) {
        i = this.g.d.g();
      } else {
        i = this.g.d.k();
      } 
      this.b = i;
    }
    
    public void b() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
  }
  
  public static class c extends RecyclerView.p {
    public StaggeredGridLayoutManager.f a;
    
    public boolean b;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static class d {
    public int[] a;
    
    public List<a> b;
    
    public void a(a param1a) {
      if (this.b == null)
        this.b = new ArrayList<a>(); 
      int j = this.b.size();
      for (int i = 0; i < j; i++) {
        a a1 = this.b.get(i);
        if (a1.b == param1a.b)
          this.b.remove(i); 
        if (a1.b >= param1a.b) {
          this.b.add(i, param1a);
          return;
        } 
      } 
      this.b.add(param1a);
    }
    
    public void b() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    public void c(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int i;
        for (i = arrayOfInt.length; i <= param1Int; i *= 2);
        int[] arrayOfInt1 = new int[i];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    public int d(int param1Int) {
      List<a> list = this.b;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--) {
          if (((a)this.b.get(i)).b >= param1Int)
            this.b.remove(i); 
        }  
      return g(param1Int);
    }
    
    public a e(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      int j = list.size();
      int i;
      for (i = 0; i < j; i++) {
        a a = this.b.get(i);
        int k = a.b;
        if (k >= param1Int2)
          return null; 
        if (k >= param1Int1 && (param1Int3 == 0 || a.c == param1Int3 || (param1Boolean && a.f)))
          return a; 
      } 
      return null;
    }
    
    public a f(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.b == param1Int)
          return a; 
      } 
      return null;
    }
    
    public int g(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : [I
      //   4: astore #4
      //   6: aload #4
      //   8: ifnonnull -> 13
      //   11: iconst_m1
      //   12: ireturn
      //   13: iload_1
      //   14: aload #4
      //   16: arraylength
      //   17: if_icmplt -> 22
      //   20: iconst_m1
      //   21: ireturn
      //   22: aload_0
      //   23: getfield b : Ljava/util/List;
      //   26: ifnonnull -> 34
      //   29: iconst_m1
      //   30: istore_2
      //   31: goto -> 144
      //   34: aload_0
      //   35: iload_1
      //   36: invokevirtual f : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
      //   39: astore #4
      //   41: aload #4
      //   43: ifnull -> 58
      //   46: aload_0
      //   47: getfield b : Ljava/util/List;
      //   50: aload #4
      //   52: invokeinterface remove : (Ljava/lang/Object;)Z
      //   57: pop
      //   58: aload_0
      //   59: getfield b : Ljava/util/List;
      //   62: invokeinterface size : ()I
      //   67: istore_3
      //   68: iconst_0
      //   69: istore_2
      //   70: iload_2
      //   71: iload_3
      //   72: if_icmpge -> 105
      //   75: aload_0
      //   76: getfield b : Ljava/util/List;
      //   79: iload_2
      //   80: invokeinterface get : (I)Ljava/lang/Object;
      //   85: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   88: getfield b : I
      //   91: iload_1
      //   92: if_icmplt -> 98
      //   95: goto -> 107
      //   98: iload_2
      //   99: iconst_1
      //   100: iadd
      //   101: istore_2
      //   102: goto -> 70
      //   105: iconst_m1
      //   106: istore_2
      //   107: iload_2
      //   108: iconst_m1
      //   109: if_icmpeq -> 29
      //   112: aload_0
      //   113: getfield b : Ljava/util/List;
      //   116: iload_2
      //   117: invokeinterface get : (I)Ljava/lang/Object;
      //   122: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   125: astore #4
      //   127: aload_0
      //   128: getfield b : Ljava/util/List;
      //   131: iload_2
      //   132: invokeinterface remove : (I)Ljava/lang/Object;
      //   137: pop
      //   138: aload #4
      //   140: getfield b : I
      //   143: istore_2
      //   144: iload_2
      //   145: iconst_m1
      //   146: if_icmpne -> 171
      //   149: aload_0
      //   150: getfield a : [I
      //   153: astore #4
      //   155: aload #4
      //   157: iload_1
      //   158: aload #4
      //   160: arraylength
      //   161: iconst_m1
      //   162: invokestatic fill : ([IIII)V
      //   165: aload_0
      //   166: getfield a : [I
      //   169: arraylength
      //   170: ireturn
      //   171: iload_2
      //   172: iconst_1
      //   173: iadd
      //   174: aload_0
      //   175: getfield a : [I
      //   178: arraylength
      //   179: invokestatic min : (II)I
      //   182: istore_2
      //   183: aload_0
      //   184: getfield a : [I
      //   187: iload_1
      //   188: iload_2
      //   189: iconst_m1
      //   190: invokestatic fill : ([IIII)V
      //   193: iload_2
      //   194: ireturn
    }
    
    public void h(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        c(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int j = a.b;
          if (j >= param1Int1)
            a.b = j + param1Int2; 
        } 
      } 
    }
    
    public void i(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int j = param1Int1 + param1Int2;
        c(j);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, j, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (int i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int k = a.b;
          if (k >= param1Int1)
            if (k < j) {
              this.b.remove(i);
            } else {
              a.b = k - param1Int2;
            }  
        } 
      } 
    }
    
    @SuppressLint({"BanParcelableUsage"})
    public static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = new a();
      
      public int b;
      
      public int c;
      
      public int[] d;
      
      public boolean f;
      
      public a() {}
      
      public a(Parcel param2Parcel) {
        this.b = param2Parcel.readInt();
        this.c = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.f = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.d = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = s30.x0("FullSpanItem{mPosition=");
        stringBuilder.append(this.b);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.c);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.f);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.d));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
      
      public class a implements Parcelable.Creator<a> {
        public Object createFromParcel(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.d.a(param3Parcel);
        }
        
        public Object[] newArray(int param3Int) {
          return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
        }
      }
    }
    
    public class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.d.a(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new a();
    
    public int b;
    
    public int c;
    
    public int[] d;
    
    public boolean f;
    
    public a() {}
    
    public a(Parcel param1Parcel) {
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.f = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.d = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = s30.x0("FullSpanItem{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.d));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.d.a(param3Parcel);
      }
      
      public Object[] newArray(int param3Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<d.a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.d.a(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.d.a[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int[] f;
    
    public int g;
    
    public int[] p;
    
    public List<StaggeredGridLayoutManager.d.a> q;
    
    public boolean r;
    
    public boolean s;
    
    public boolean t;
    
    public e() {}
    
    public e(Parcel param1Parcel) {
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.d = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.f = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.g = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.p = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.r = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.s = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.t = bool1;
      this.q = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.d = param1e.d;
      this.b = param1e.b;
      this.c = param1e.c;
      this.f = param1e.f;
      this.g = param1e.g;
      this.p = param1e.p;
      this.r = param1e.r;
      this.s = param1e.s;
      this.t = param1e.t;
      this.q = param1e.q;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<e> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.e(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.e[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<e> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.e(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.e[param1Int];
    }
  }
  
  public class f {
    public ArrayList<View> a = new ArrayList<View>();
    
    public int b = Integer.MIN_VALUE;
    
    public int c = Integer.MIN_VALUE;
    
    public int d = 0;
    
    public final int e;
    
    public f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    public void a(View param1View) {
      StaggeredGridLayoutManager.c c = l(param1View);
      c.a = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.isItemRemoved() || c.isItemChanged()) {
        int i = this.d;
        this.d = this.f.d.c(param1View) + i;
      } 
    }
    
    public void b() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = l(view);
      this.c = this.f.d.b(view);
      if (c.b) {
        StaggeredGridLayoutManager.d.a a = this.f.w.f(c.getViewLayoutPosition());
        if (a != null && a.c == 1) {
          int j = this.c;
          int i = this.e;
          int[] arrayOfInt = a.d;
          if (arrayOfInt == null) {
            i = 0;
          } else {
            i = arrayOfInt[i];
          } 
          this.c = j + i;
        } 
      } 
    }
    
    public void c() {
      ArrayList<View> arrayList = this.a;
      int i = 0;
      View view = arrayList.get(0);
      StaggeredGridLayoutManager.c c = l(view);
      this.b = this.f.d.e(view);
      if (c.b) {
        StaggeredGridLayoutManager.d.a a = this.f.w.f(c.getViewLayoutPosition());
        if (a != null && a.c == -1) {
          int j = this.b;
          int k = this.e;
          int[] arrayOfInt = a.d;
          if (arrayOfInt != null)
            i = arrayOfInt[k]; 
          this.b = j - i;
        } 
      } 
    }
    
    public void d() {
      this.a.clear();
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
      this.d = 0;
    }
    
    public int e() {
      return this.f.r ? h(this.a.size() - 1, -1, true) : h(0, this.a.size(), true);
    }
    
    public int f() {
      return this.f.r ? h(0, this.a.size(), true) : h(this.a.size() - 1, -1, true);
    }
    
    public int g(int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      byte b;
      int i = this.f.d.k();
      int j = this.f.d.g();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.d.e(view);
        int m = this.f.d.b(view);
        boolean bool2 = false;
        if (param1Boolean3 ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean3 ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2)
          if (param1Boolean1 && param1Boolean2) {
            if (k >= i && m <= j)
              return this.f.getPosition(view); 
          } else {
            if (param1Boolean2)
              return this.f.getPosition(view); 
            if (k < i || m > j)
              return this.f.getPosition(view); 
          }  
        param1Int1 += b;
      } 
      return -1;
    }
    
    public int h(int param1Int1, int param1Int2, boolean param1Boolean) {
      return g(param1Int1, param1Int2, false, false, param1Boolean);
    }
    
    public int i(int param1Int1, int param1Int2, boolean param1Boolean) {
      return g(param1Int1, param1Int2, param1Boolean, true, false);
    }
    
    public int j(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      b();
      return this.c;
    }
    
    public View k(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield r : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual getPosition : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield r : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual getPosition : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield a : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield a : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield r : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual getPosition : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield r : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual getPosition : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    public StaggeredGridLayoutManager.c l(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    public int m(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.b;
    }
    
    public void n() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = l(view);
      c.a = null;
      if (c.isItemRemoved() || c.isItemChanged())
        this.d -= this.f.d.c(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    public void o() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = l(view);
      c.a = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.isItemRemoved() || c.isItemChanged())
        this.d -= this.f.d.c(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    public void p(View param1View) {
      StaggeredGridLayoutManager.c c = l(param1View);
      c.a = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.isItemRemoved() || c.isItemChanged()) {
        int i = this.d;
        this.d = this.f.d.c(param1View) + i;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */