package androidx.media;

import gq;

public interface AudioAttributesImpl extends gq {
  int a();
  
  public static interface a {
    a a(int param1Int);
    
    AudioAttributesImpl build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */