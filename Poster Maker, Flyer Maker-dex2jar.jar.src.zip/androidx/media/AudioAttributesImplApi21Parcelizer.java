package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import eq;
import java.util.Objects;

public class AudioAttributesImplApi21Parcelizer {
  public static AudioAttributesImplApi21 read(eq parameq) {
    AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
    audioAttributesImplApi21.a = (AudioAttributes)parameq.m((Parcelable)audioAttributesImplApi21.a, 1);
    audioAttributesImplApi21.b = parameq.k(audioAttributesImplApi21.b, 2);
    return audioAttributesImplApi21;
  }
  
  public static void write(AudioAttributesImplApi21 paramAudioAttributesImplApi21, eq parameq) {
    Objects.requireNonNull(parameq);
    AudioAttributes audioAttributes = paramAudioAttributesImplApi21.a;
    parameq.p(1);
    parameq.u((Parcelable)audioAttributes);
    int i = paramAudioAttributesImplApi21.b;
    parameq.p(2);
    parameq.t(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImplApi21Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */