package androidx.media;

import android.media.AudioAttributes;
import s30;

public class AudioAttributesImplApi21 implements AudioAttributesImpl {
  public AudioAttributes a;
  
  public int b = -1;
  
  public AudioAttributesImplApi21() {}
  
  public AudioAttributesImplApi21(AudioAttributes paramAudioAttributes) {
    this.a = paramAudioAttributes;
    this.b = -1;
  }
  
  public AudioAttributesImplApi21(AudioAttributes paramAudioAttributes, int paramInt) {
    this.a = paramAudioAttributes;
    this.b = paramInt;
  }
  
  public int a() {
    int i = this.b;
    return (i != -1) ? i : AudioAttributesCompat.b(false, this.a.getFlags(), this.a.getUsage());
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof AudioAttributesImplApi21))
      return false; 
    paramObject = paramObject;
    return this.a.equals(((AudioAttributesImplApi21)paramObject).a);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = s30.x0("AudioAttributesCompat: audioattributes=");
    stringBuilder.append(this.a);
    return stringBuilder.toString();
  }
  
  public static class a implements AudioAttributesImpl.a {
    public final AudioAttributes.Builder a = new AudioAttributes.Builder();
    
    public AudioAttributesImpl.a a(int param1Int) {
      this.a.setLegacyStreamType(param1Int);
      return this;
    }
    
    public AudioAttributesImpl build() {
      return new AudioAttributesImplApi21(this.a.build());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImplApi21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */