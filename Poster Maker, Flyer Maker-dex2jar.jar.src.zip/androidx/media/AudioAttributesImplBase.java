package androidx.media;

import android.util.SparseIntArray;
import java.util.Arrays;
import s30;

public class AudioAttributesImplBase implements AudioAttributesImpl {
  public int a = 0;
  
  public int b = 0;
  
  public int c = 0;
  
  public int d = -1;
  
  public AudioAttributesImplBase() {}
  
  public AudioAttributesImplBase(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.b = paramInt1;
    this.c = paramInt2;
    this.a = paramInt3;
    this.d = paramInt4;
  }
  
  public int a() {
    int i = this.d;
    return (i != -1) ? i : AudioAttributesCompat.b(false, this.c, this.a);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof AudioAttributesImplBase;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (this.b == ((AudioAttributesImplBase)paramObject).b) {
      int i;
      int m = this.c;
      int k = ((AudioAttributesImplBase)paramObject).c;
      int j = ((AudioAttributesImplBase)paramObject).d;
      if (j == -1)
        j = AudioAttributesCompat.b(false, k, ((AudioAttributesImplBase)paramObject).a); 
      if (j == 6) {
        i = k | 0x4;
      } else {
        i = k;
        if (j == 7)
          i = k | 0x1; 
      } 
      bool = bool1;
      if (m == (i & 0x111)) {
        bool = bool1;
        if (this.a == ((AudioAttributesImplBase)paramObject).a) {
          bool = bool1;
          if (this.d == ((AudioAttributesImplBase)paramObject).d)
            bool = true; 
        } 
      } 
    } 
    return bool;
  }
  
  public int hashCode() {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.b), Integer.valueOf(this.c), Integer.valueOf(this.a), Integer.valueOf(this.d) });
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("AudioAttributesCompat:");
    if (this.d != -1) {
      stringBuilder.append(" stream=");
      stringBuilder.append(this.d);
      stringBuilder.append(" derived");
    } 
    stringBuilder.append(" usage=");
    int i = this.a;
    SparseIntArray sparseIntArray = AudioAttributesCompat.a;
    switch (i) {
      default:
        str = s30.Z("unknown usage ", i);
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 16:
        str = "USAGE_ASSISTANT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 14:
        str = "USAGE_GAME";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 13:
        str = "USAGE_ASSISTANCE_SONIFICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 12:
        str = "USAGE_ASSISTANCE_NAVIGATION_GUIDANCE";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 11:
        str = "USAGE_ASSISTANCE_ACCESSIBILITY";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 10:
        str = "USAGE_NOTIFICATION_EVENT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 9:
        str = "USAGE_NOTIFICATION_COMMUNICATION_DELAYED";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 8:
        str = "USAGE_NOTIFICATION_COMMUNICATION_INSTANT";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 7:
        str = "USAGE_NOTIFICATION_COMMUNICATION_REQUEST";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 6:
        str = "USAGE_NOTIFICATION_RINGTONE";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 5:
        str = "USAGE_NOTIFICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 4:
        str = "USAGE_ALARM";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 3:
        str = "USAGE_VOICE_COMMUNICATION_SIGNALLING";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 2:
        str = "USAGE_VOICE_COMMUNICATION";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 1:
        str = "USAGE_MEDIA";
        stringBuilder.append(str);
        stringBuilder.append(" content=");
        stringBuilder.append(this.b);
        stringBuilder.append(" flags=0x");
        stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
        return stringBuilder.toString();
      case 0:
        break;
    } 
    String str = "USAGE_UNKNOWN";
    stringBuilder.append(str);
    stringBuilder.append(" content=");
    stringBuilder.append(this.b);
    stringBuilder.append(" flags=0x");
    stringBuilder.append(Integer.toHexString(this.c).toUpperCase());
    return stringBuilder.toString();
  }
  
  public static class a implements AudioAttributesImpl.a {
    public int a = 0;
    
    public int b = 0;
    
    public int c = 0;
    
    public int d = -1;
    
    public AudioAttributesImpl.a a(int param1Int) {
      if (param1Int != 10) {
        this.d = param1Int;
        byte b = 2;
        switch (param1Int) {
          case 10:
            this.b = 1;
            break;
          case 9:
            this.b = 4;
            break;
          case 8:
            this.b = 4;
            break;
          case 7:
            this.c |= 0x1;
          case 6:
            this.b = 1;
            this.c |= 0x4;
            break;
          case 5:
            this.b = 4;
            break;
          case 4:
            this.b = 4;
            break;
          case 3:
            this.b = 2;
            break;
          case 2:
            this.b = 4;
            break;
          case 1:
            this.b = 4;
            break;
          case 0:
            this.b = 1;
            break;
        } 
        switch (param1Int) {
          default:
            b = 0;
            break;
          case 10:
            b = 11;
            break;
          case 8:
            b = 3;
            break;
          case 5:
            b = 5;
            break;
          case 4:
            b = 4;
            break;
          case 3:
            b = 1;
            break;
          case 2:
            b = 6;
            break;
          case 1:
          case 7:
            b = 13;
            break;
          case 0:
          case 6:
            break;
        } 
        this.a = b;
        return this;
      } 
      throw new IllegalArgumentException("STREAM_ACCESSIBILITY is not a legacy stream type that was used for audio playback");
    }
    
    public AudioAttributesImpl build() {
      return new AudioAttributesImplBase(this.b, this.c, this.a, this.d);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */