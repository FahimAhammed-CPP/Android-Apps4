package androidx.media;

import eq;
import gq;
import java.util.Objects;

public class AudioAttributesCompatParcelizer {
  public static AudioAttributesCompat read(eq parameq) {
    gq gq;
    AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
    AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.b;
    if (!parameq.i(1)) {
      gq = audioAttributesImpl;
    } else {
      gq = gq.o();
    } 
    audioAttributesCompat.b = (AudioAttributesImpl)gq;
    return audioAttributesCompat;
  }
  
  public static void write(AudioAttributesCompat paramAudioAttributesCompat, eq parameq) {
    Objects.requireNonNull(parameq);
    AudioAttributesImpl audioAttributesImpl = paramAudioAttributesCompat.b;
    parameq.p(1);
    parameq.w(audioAttributesImpl);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */