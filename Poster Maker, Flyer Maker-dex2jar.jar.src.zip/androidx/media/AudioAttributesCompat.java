package androidx.media;

import android.media.AudioAttributes;
import android.os.Build;
import android.util.SparseIntArray;
import gq;
import s30;

public class AudioAttributesCompat implements gq {
  public static final SparseIntArray a;
  
  public AudioAttributesImpl b;
  
  static {
    SparseIntArray sparseIntArray = new SparseIntArray();
    a = sparseIntArray;
    sparseIntArray.put(5, 1);
    sparseIntArray.put(6, 2);
    sparseIntArray.put(7, 2);
    sparseIntArray.put(8, 1);
    sparseIntArray.put(9, 1);
    sparseIntArray.put(10, 1);
  }
  
  public AudioAttributesCompat() {}
  
  public AudioAttributesCompat(AudioAttributesImpl paramAudioAttributesImpl) {
    this.b = paramAudioAttributesImpl;
  }
  
  public static int b(boolean paramBoolean, int paramInt1, int paramInt2) {
    if ((paramInt1 & 0x1) == 1)
      return paramBoolean ? 1 : 7; 
    boolean bool = false;
    if ((paramInt1 & 0x4) == 4)
      return paramBoolean ? 0 : 6; 
    paramInt1 = bool;
    switch (paramInt2) {
      default:
        if (!paramBoolean)
          return 3; 
        throw new IllegalArgumentException(s30.a0("Unknown usage value ", paramInt2, " in audio attributes"));
      case 13:
        return 1;
      case 11:
        return 10;
      case 6:
        return 2;
      case 5:
      case 7:
      case 8:
      case 9:
      case 10:
        return 5;
      case 4:
        return 4;
      case 3:
        if (paramBoolean)
          return 0; 
        paramInt1 = 8;
      case 2:
        return paramInt1;
      case 0:
      case 1:
      case 12:
      case 14:
      case 16:
        break;
    } 
    return 3;
  }
  
  public static AudioAttributesCompat c(Object paramObject) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 26) ? new AudioAttributesCompat(new AudioAttributesImplApi26((AudioAttributes)paramObject)) : ((i >= 21) ? new AudioAttributesCompat(new AudioAttributesImplApi21((AudioAttributes)paramObject)) : null);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool1 = paramObject instanceof AudioAttributesCompat;
    boolean bool = false;
    if (!bool1)
      return false; 
    paramObject = paramObject;
    AudioAttributesImpl audioAttributesImpl = this.b;
    if (audioAttributesImpl == null) {
      if (((AudioAttributesCompat)paramObject).b == null)
        bool = true; 
      return bool;
    } 
    return audioAttributesImpl.equals(((AudioAttributesCompat)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public String toString() {
    return this.b.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */