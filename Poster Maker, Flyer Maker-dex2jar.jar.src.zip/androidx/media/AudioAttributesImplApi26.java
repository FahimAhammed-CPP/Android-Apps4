package androidx.media;

import android.media.AudioAttributes;

public class AudioAttributesImplApi26 extends AudioAttributesImplApi21 {
  public AudioAttributesImplApi26() {}
  
  public AudioAttributesImplApi26(AudioAttributes paramAudioAttributes) {
    super(paramAudioAttributes, -1);
  }
  
  public static class a extends AudioAttributesImplApi21.a {
    public AudioAttributesImpl build() {
      return new AudioAttributesImplApi26(this.a.build());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImplApi26.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */