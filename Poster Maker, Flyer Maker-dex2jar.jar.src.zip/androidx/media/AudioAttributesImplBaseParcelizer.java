package androidx.media;

import eq;
import java.util.Objects;

public class AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(eq parameq) {
    AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
    audioAttributesImplBase.a = parameq.k(audioAttributesImplBase.a, 1);
    audioAttributesImplBase.b = parameq.k(audioAttributesImplBase.b, 2);
    audioAttributesImplBase.c = parameq.k(audioAttributesImplBase.c, 3);
    audioAttributesImplBase.d = parameq.k(audioAttributesImplBase.d, 4);
    return audioAttributesImplBase;
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, eq parameq) {
    Objects.requireNonNull(parameq);
    int i = paramAudioAttributesImplBase.a;
    parameq.p(1);
    parameq.t(i);
    i = paramAudioAttributesImplBase.b;
    parameq.p(2);
    parameq.t(i);
    i = paramAudioAttributesImplBase.c;
    parameq.p(3);
    parameq.t(i);
    i = paramAudioAttributesImplBase.d;
    parameq.p(4);
    parameq.t(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */