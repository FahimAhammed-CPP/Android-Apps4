package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import com.google.common.util.concurrent.ListenableFuture;
import mv;

public abstract class Worker extends ListenableWorker {
  public mv<ListenableWorker.a> mFuture;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final ListenableFuture<ListenableWorker.a> startWork() {
    this.mFuture = new mv();
    getBackgroundExecutor().execute(new a(this));
    return (ListenableFuture<ListenableWorker.a>)this.mFuture;
  }
  
  public class a implements Runnable {
    public a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.b.mFuture.j(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */