package androidx.work;

import fr;
import java.lang.reflect.Array;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import jr;

public final class ArrayCreatingInputMerger extends jr {
  public fr a(List<fr> paramList) {
    fr.a a = new fr.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<fr> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      for (Object object1 : Collections.unmodifiableMap(((fr)iterator.next()).c).entrySet()) {
        String str = (String)object1.getKey();
        object1 = object1.getValue();
        Object object2 = object1.getClass();
        Object object3 = hashMap.get(str);
        if (object3 == null) {
          if (!object2.isArray()) {
            object2 = Array.newInstance(object1.getClass(), 1);
            Array.set(object2, 0, object1);
            object1 = object2;
          } 
        } else {
          Class<?> clazz = object3.getClass();
          if (clazz.equals(object2)) {
            if (clazz.isArray()) {
              int i = Array.getLength(object3);
              int j = Array.getLength(object1);
              object2 = Array.newInstance(object3.getClass().getComponentType(), i + j);
              System.arraycopy(object3, 0, object2, 0, i);
              System.arraycopy(object1, 0, object2, i, j);
              object1 = object2;
            } else {
              object2 = Array.newInstance(object3.getClass(), 2);
              Array.set(object2, 0, object3);
              Array.set(object2, 1, object1);
              object1 = object2;
            } 
          } else if (clazz.isArray() && clazz.getComponentType().equals(object2)) {
            object1 = b(object3, object1);
          } else if (object2.isArray() && object2.getComponentType().equals(clazz)) {
            object1 = b(object1, object3);
          } else {
            throw new IllegalArgumentException();
          } 
        } 
        hashMap.put(str, object1);
      } 
    } 
    a.b(hashMap);
    return a.a();
  }
  
  public final Object b(Object paramObject1, Object paramObject2) {
    int i = Array.getLength(paramObject1);
    Object object = Array.newInstance(paramObject2.getClass(), i + 1);
    System.arraycopy(paramObject1, 0, object, 0, i);
    Array.set(object, i, paramObject2);
    return object;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\ArrayCreatingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */