package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import as;
import cs;
import cv;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import ks;
import mr;
import nv;
import ov;

public class SystemJobService extends JobService implements as {
  public static final String b = mr.e("SystemJobService");
  
  public ks c;
  
  public final Map<String, JobParameters> d = new HashMap<String, JobParameters>();
  
  public static String a(JobParameters paramJobParameters) {
    try {
      PersistableBundle persistableBundle = paramJobParameters.getExtras();
      if (persistableBundle != null && persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
        return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
    } catch (NullPointerException nullPointerException) {}
    return null;
  }
  
  public void d(String paramString, boolean paramBoolean) {
    mr.c().a(b, String.format("%s executed on JobScheduler", new Object[] { paramString }), new Throwable[0]);
    synchronized (this.d) {
      JobParameters jobParameters = this.d.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    try {
      ks ks1 = ks.b(getApplicationContext());
      this.c = ks1;
      ks1.i.a(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        mr.c().f(b, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public void onDestroy() {
    super.onDestroy();
    ks ks1 = this.c;
    if (ks1 != null)
      ks1.i.e(this); 
  }
  
  public boolean onStartJob(JobParameters paramJobParameters) {
    Map<String, JobParameters> map;
    cv cv;
    if (this.c == null) {
      mr.c().a(b, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      jobFinished(paramJobParameters, true);
      return false;
    } 
    String str = a(paramJobParameters);
    if (TextUtils.isEmpty(str)) {
      mr.c().b(b, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    synchronized (this.d) {
      WorkerParameters.a a;
      if (this.d.containsKey(str)) {
        mr.c().a(b, String.format("Job is already being executed by SystemJobService: %s", new Object[] { str }), new Throwable[0]);
        return false;
      } 
      mr.c().a(b, String.format("onStartJob for %s", new Object[] { str }), new Throwable[0]);
      this.d.put(str, paramJobParameters);
      map = null;
      int i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        WorkerParameters.a a1 = new WorkerParameters.a();
        if (paramJobParameters.getTriggeredContentUris() != null)
          a1.b = Arrays.asList(paramJobParameters.getTriggeredContentUris()); 
        if (paramJobParameters.getTriggeredContentAuthorities() != null)
          a1.a = Arrays.asList(paramJobParameters.getTriggeredContentAuthorities()); 
        a = a1;
        if (i >= 28) {
          a1.c = paramJobParameters.getNetwork();
          a = a1;
        } 
      } 
      ks ks1 = this.c;
      nv nv = ks1.g;
      cv = new cv(ks1, str, a);
      ((ov)nv).a.execute((Runnable)cv);
      return true;
    } 
  }
  
  public boolean onStopJob(JobParameters paramJobParameters) {
    if (this.c == null) {
      mr.c().a(b, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      return true;
    } 
    null = a(paramJobParameters);
    if (TextUtils.isEmpty(null)) {
      mr.c().b(b, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    mr.c().a(b, String.format("onStopJob for %s", new Object[] { null }), new Throwable[0]);
    synchronized (this.d) {
      this.d.remove(null);
      this.c.f(null);
      cs cs = this.c.i;
      synchronized (cs.v) {
        boolean bool = cs.t.contains(null);
        return bool ^ true;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */