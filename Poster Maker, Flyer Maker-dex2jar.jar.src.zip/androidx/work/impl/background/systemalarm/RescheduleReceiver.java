package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Objects;
import ks;
import mr;
import ss;

public class RescheduleReceiver extends BroadcastReceiver {
  public static final String a = mr.e("RescheduleReceiver");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    mr.c().a(a, String.format("Received intent %s", new Object[] { paramIntent }), new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 23)
      try {
        null = ks.b(paramContext);
        BroadcastReceiver.PendingResult pendingResult = goAsync();
        Objects.requireNonNull(null);
        synchronized (ks.c) {
          null.l = pendingResult;
          if (null.k) {
            pendingResult.finish();
            null.l = null;
          } 
          return;
        } 
      } catch (IllegalStateException illegalStateException) {
        mr.c().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", new Throwable[] { illegalStateException });
        return;
      }  
    String str = ss.b;
    Intent intent = new Intent((Context)illegalStateException, SystemAlarmService.class);
    intent.setAction("ACTION_RESCHEDULE");
    illegalStateException.startService(intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\background\systemalarm\RescheduleReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */