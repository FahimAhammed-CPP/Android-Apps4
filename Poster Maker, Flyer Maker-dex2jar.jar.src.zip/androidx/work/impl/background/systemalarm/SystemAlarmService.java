package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import ev;
import java.util.HashMap;
import java.util.WeakHashMap;
import mr;
import vs;
import yj;

public class SystemAlarmService extends yj implements vs.c {
  public static final String c = mr.e("SystemAlarmService");
  
  public vs d;
  
  public boolean f;
  
  public final void a() {
    vs vs1 = new vs((Context)this);
    this.d = vs1;
    if (vs1.u != null) {
      mr.c().b(vs.b, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    vs1.u = this;
  }
  
  public void b() {
    this.f = true;
    mr.c().a(c, "All commands completed in dispatcher", new Throwable[0]);
    String str = ev.a;
    null = new HashMap<Object, Object>();
    synchronized (ev.b) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String str1 = String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          mr.c().f(ev.a, str1, new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    a();
    this.f = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.f = true;
    this.d.c();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.f) {
      mr.c().d(c, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.d.c();
      a();
      this.f = false;
    } 
    if (paramIntent != null)
      this.d.a(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */