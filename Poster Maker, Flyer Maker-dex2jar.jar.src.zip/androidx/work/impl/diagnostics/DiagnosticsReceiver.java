package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import ks;
import mr;
import or;

public class DiagnosticsReceiver extends BroadcastReceiver {
  public static final String a = mr.e("DiagnosticsRcvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    mr.c().a(a, "Requesting diagnostics", new Throwable[0]);
    try {
      ks.b(paramContext).a((new or.a(DiagnosticsWorker.class)).a());
      return;
    } catch (IllegalStateException illegalStateException) {
      mr.c().b(a, "WorkManager is not initialized", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */