package androidx.work.impl;

import bu;
import eu;
import hn;
import hu;
import java.util.concurrent.TimeUnit;
import ku;
import nu;
import qu;
import yt;

public abstract class WorkDatabase extends hn {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public abstract yt l();
  
  public abstract bu m();
  
  public abstract eu n();
  
  public abstract hu o();
  
  public abstract ku p();
  
  public abstract nu q();
  
  public abstract qu r();
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */