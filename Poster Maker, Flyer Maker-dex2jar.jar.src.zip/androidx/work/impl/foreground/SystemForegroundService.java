package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import java.util.Objects;
import java.util.UUID;
import ks;
import mr;
import nv;
import ov;
import su;
import tt;
import ut;
import yj;

public class SystemForegroundService extends yj implements ut.a {
  public static final String c = mr.e("SystemFgService");
  
  public Handler d;
  
  public boolean f;
  
  public ut g;
  
  public NotificationManager p;
  
  public final void a() {
    this.d = new Handler(Looper.getMainLooper());
    this.p = (NotificationManager)getApplicationContext().getSystemService("notification");
    ut ut1 = new ut(getApplicationContext());
    this.g = ut1;
    if (ut1.u != null) {
      mr.c().b(ut.b, "A callback already exists.", new Throwable[0]);
      return;
    } 
    ut1.u = this;
  }
  
  public void b(int paramInt1, int paramInt2, Notification paramNotification) {
    this.d.post(new a(this, paramInt1, paramNotification, paramInt2));
  }
  
  public void onCreate() {
    super.onCreate();
    a();
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.g.g();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.f) {
      mr.c().d(c, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
      this.g.g();
      a();
      this.f = false;
    } 
    if (paramIntent != null) {
      nv nv;
      ut ut1 = this.g;
      Objects.requireNonNull(ut1);
      String str = paramIntent.getAction();
      if ("ACTION_START_FOREGROUND".equals(str)) {
        mr.c().d(ut.b, String.format("Started foreground service %s", new Object[] { paramIntent }), new Throwable[0]);
        String str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
        WorkDatabase workDatabase = ut1.d.f;
        nv = ut1.f;
        tt tt = new tt(ut1, workDatabase, str1);
        ((ov)nv).a.execute((Runnable)tt);
        ut1.e(paramIntent);
      } else if ("ACTION_NOTIFY".equals(nv)) {
        ut1.e(paramIntent);
      } else {
        su su;
        String str1;
        if ("ACTION_CANCEL_WORK".equals(nv)) {
          mr.c().d(ut.b, String.format("Stopping foreground work for %s", new Object[] { paramIntent }), new Throwable[0]);
          str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
          if (str1 != null && !TextUtils.isEmpty(str1)) {
            ks ks = ut1.d;
            UUID uUID = UUID.fromString(str1);
            Objects.requireNonNull(ks);
            su = new su(ks, uUID);
            ((ov)ks.g).a.execute((Runnable)su);
          } 
        } else if ("ACTION_STOP_FOREGROUND".equals(str1)) {
          mr.c().d(ut.b, "Stopping foreground service", new Throwable[0]);
          ut.a a1 = ((ut)su).u;
          if (a1 != null) {
            a1 = a1;
            ((SystemForegroundService)a1).f = true;
            mr.c().a(c, "All commands completed.", new Throwable[0]);
            if (Build.VERSION.SDK_INT >= 26)
              a1.stopForeground(true); 
            a1.stopSelf();
          } 
        } 
      } 
    } 
    return 3;
  }
  
  public class a implements Runnable {
    public a(SystemForegroundService this$0, int param1Int1, Notification param1Notification, int param1Int2) {}
    
    public void run() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.f.startForeground(this.b, this.c, this.d);
        return;
      } 
      this.f.startForeground(this.b, this.c);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */