package androidx.work.impl;

import android.content.Context;
import bo;
import bu;
import cn;
import eu;
import gn;
import hu;
import in;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import ku;
import nu;
import pn;
import qu;
import xn;
import yn;
import yt;

public final class WorkDatabase_Impl extends WorkDatabase {
  public volatile nu m;
  
  public volatile yt n;
  
  public volatile qu o;
  
  public volatile eu p;
  
  public volatile hu q;
  
  public volatile ku r;
  
  public volatile bu s;
  
  public gn e() {
    return new gn(this, new HashMap<Object, Object>(0), new HashMap<Object, Object>(0), new String[] { "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference" });
  }
  
  public yn f(cn paramcn) {
    in in = new in(paramcn, new a(this, 12), "c103703e120ae8cc73c9248622f3cd1e", "49f946663a8deb7054212b8adda248c6");
    Context context = paramcn.b;
    String str = paramcn.c;
    if (context != null) {
      yn.b b = new yn.b(context, str, (yn.a)in, false);
      return paramcn.a.a(b);
    } 
    throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
  }
  
  public yt l() {
    // Byte code:
    //   0: aload_0
    //   1: getfield n : Lyt;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield n : Lyt;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield n : Lyt;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new zt
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield n : Lyt;
    //   33: aload_0
    //   34: getfield n : Lyt;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public bu m() {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : Lbu;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield s : Lbu;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield s : Lbu;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new cu
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield s : Lbu;
    //   33: aload_0
    //   34: getfield s : Lbu;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public eu n() {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Leu;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield p : Leu;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield p : Leu;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new fu
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield p : Leu;
    //   33: aload_0
    //   34: getfield p : Leu;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public hu o() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lhu;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield q : Lhu;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield q : Lhu;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new iu
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield q : Lhu;
    //   33: aload_0
    //   34: getfield q : Lhu;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public ku p() {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Lku;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield r : Lku;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield r : Lku;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new lu
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield r : Lku;
    //   33: aload_0
    //   34: getfield r : Lku;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public nu q() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Lnu;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield m : Lnu;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield m : Lnu;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new ou
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield m : Lnu;
    //   33: aload_0
    //   34: getfield m : Lnu;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public qu r() {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lqu;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield o : Lqu;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield o : Lqu;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new ru
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lhn;)V
    //   30: putfield o : Lqu;
    //   33: aload_0
    //   34: getfield o : Lqu;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public class a extends in.a {
    public a(WorkDatabase_Impl this$0, int param1Int) {
      super(param1Int);
    }
    
    public void a(xn param1xn) {
      ((bo)param1xn).c.execSQL("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      bo bo = (bo)param1xn;
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      bo.c.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
      bo.c.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      bo.c.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
    }
    
    public in.b b(xn param1xn) {
      StringBuilder stringBuilder;
      HashMap<Object, Object> hashMap7 = new HashMap<Object, Object>(2);
      hashMap7.put("work_spec_id", new pn.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap7.put("prerequisite_id", new pn.a("prerequisite_id", "TEXT", true, 2, null, 1));
      HashSet<pn.b> hashSet5 = new HashSet(2);
      hashSet5.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet5.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "prerequisite_id" }, ), Arrays.asList(new String[] { "id" })));
      HashSet<pn.d> hashSet6 = new HashSet(2);
      hashSet6.add(new pn.d("index_Dependency_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      hashSet6.add(new pn.d("index_Dependency_prerequisite_id", false, Arrays.asList(new String[] { "prerequisite_id" })));
      pn pn8 = new pn("Dependency", hashMap7, hashSet5, hashSet6);
      pn pn14 = pn.a(param1xn, "Dependency");
      if (!pn8.equals(pn14)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Dependency(androidx.work.impl.model.Dependency).\n Expected:\n");
        stringBuilder.append(pn8);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn14);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap6 = new HashMap<Object, Object>(25);
      hashMap6.put("id", new pn.a("id", "TEXT", true, 1, null, 1));
      hashMap6.put("state", new pn.a("state", "INTEGER", true, 0, null, 1));
      hashMap6.put("worker_class_name", new pn.a("worker_class_name", "TEXT", true, 0, null, 1));
      hashMap6.put("input_merger_class_name", new pn.a("input_merger_class_name", "TEXT", false, 0, null, 1));
      hashMap6.put("input", new pn.a("input", "BLOB", true, 0, null, 1));
      hashMap6.put("output", new pn.a("output", "BLOB", true, 0, null, 1));
      hashMap6.put("initial_delay", new pn.a("initial_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("interval_duration", new pn.a("interval_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("flex_duration", new pn.a("flex_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_attempt_count", new pn.a("run_attempt_count", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_policy", new pn.a("backoff_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_delay_duration", new pn.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("period_start_time", new pn.a("period_start_time", "INTEGER", true, 0, null, 1));
      hashMap6.put("minimum_retention_duration", new pn.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("schedule_requested_at", new pn.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_in_foreground", new pn.a("run_in_foreground", "INTEGER", true, 0, null, 1));
      hashMap6.put("out_of_quota_policy", new pn.a("out_of_quota_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("required_network_type", new pn.a("required_network_type", "INTEGER", false, 0, null, 1));
      hashMap6.put("requires_charging", new pn.a("requires_charging", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_device_idle", new pn.a("requires_device_idle", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_battery_not_low", new pn.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_storage_not_low", new pn.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_content_update_delay", new pn.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_max_content_delay", new pn.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("content_uri_triggers", new pn.a("content_uri_triggers", "BLOB", false, 0, null, 1));
      HashSet hashSet = new HashSet(0);
      hashSet6 = new HashSet<pn.d>(2);
      hashSet6.add(new pn.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList(new String[] { "schedule_requested_at" })));
      hashSet6.add(new pn.d("index_WorkSpec_period_start_time", false, Arrays.asList(new String[] { "period_start_time" })));
      pn pn7 = new pn("WorkSpec", hashMap6, hashSet, hashSet6);
      pn pn13 = pn.a((xn)stringBuilder, "WorkSpec");
      if (!pn7.equals(pn13)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n");
        stringBuilder.append(pn7);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn13);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap5 = new HashMap<Object, Object>(2);
      hashMap5.put("tag", new pn.a("tag", "TEXT", true, 1, null, 1));
      hashMap5.put("work_spec_id", new pn.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<pn.b> hashSet4 = new HashSet(1);
      hashSet4.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<pn.d>(1);
      hashSet6.add(new pn.d("index_WorkTag_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      pn pn6 = new pn("WorkTag", hashMap5, hashSet4, hashSet6);
      pn pn12 = pn.a((xn)stringBuilder, "WorkTag");
      if (!pn6.equals(pn12)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n");
        stringBuilder.append(pn6);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn12);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap4 = new HashMap<Object, Object>(2);
      hashMap4.put("work_spec_id", new pn.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap4.put("system_id", new pn.a("system_id", "INTEGER", true, 0, null, 1));
      HashSet<pn.b> hashSet3 = new HashSet(1);
      hashSet3.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      pn pn5 = new pn("SystemIdInfo", hashMap4, hashSet3, new HashSet(0));
      pn pn11 = pn.a((xn)stringBuilder, "SystemIdInfo");
      if (!pn5.equals(pn11)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n");
        stringBuilder.append(pn5);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn11);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>(2);
      hashMap3.put("name", new pn.a("name", "TEXT", true, 1, null, 1));
      hashMap3.put("work_spec_id", new pn.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<pn.b> hashSet2 = new HashSet(1);
      hashSet2.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<pn.d>(1);
      hashSet6.add(new pn.d("index_WorkName_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      pn pn4 = new pn("WorkName", hashMap3, hashSet2, hashSet6);
      pn pn10 = pn.a((xn)stringBuilder, "WorkName");
      if (!pn4.equals(pn10)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkName(androidx.work.impl.model.WorkName).\n Expected:\n");
        stringBuilder.append(pn4);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn10);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(2);
      hashMap2.put("work_spec_id", new pn.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap2.put("progress", new pn.a("progress", "BLOB", true, 0, null, 1));
      HashSet<pn.b> hashSet1 = new HashSet(1);
      hashSet1.add(new pn.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      pn pn3 = new pn("WorkProgress", hashMap2, hashSet1, new HashSet(0));
      pn pn9 = pn.a((xn)stringBuilder, "WorkProgress");
      if (!pn3.equals(pn9)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n");
        stringBuilder.append(pn3);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(pn9);
        return new in.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(2);
      hashMap1.put("key", new pn.a("key", "TEXT", true, 1, null, 1));
      hashMap1.put("long_value", new pn.a("long_value", "INTEGER", false, 0, null, 1));
      pn pn2 = new pn("Preference", hashMap1, new HashSet(0), new HashSet(0));
      pn pn1 = pn.a((xn)stringBuilder, "Preference");
      if (!pn2.equals(pn1)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Preference(androidx.work.impl.model.Preference).\n Expected:\n");
        stringBuilder1.append(pn2);
        stringBuilder1.append("\n Found:\n");
        stringBuilder1.append(pn1);
        return new in.b(false, stringBuilder1.toString());
      } 
      return new in.b(true, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\WorkDatabase_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */