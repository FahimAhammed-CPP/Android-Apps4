package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.activity.ComponentActivity;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import ao;
import dr;
import du;
import eu;
import fr;
import fu;
import hu;
import iu;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import jn;
import ks;
import mr;
import mu;
import nu;
import on;
import ou;
import qo;
import qu;
import ru;

public class DiagnosticsWorker extends Worker {
  public static final String a = mr.e("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(hu paramhu, qu paramqu, eu parameu, List<mu> paramList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (mu mu : paramList) {
      String str2;
      String str1 = mu.a;
      du du = ((fu)parameu).a(str1);
      if (du != null) {
        Integer integer = Integer.valueOf(du.b);
      } else {
        du = null;
      } 
      String str3 = mu.a;
      iu iu = (iu)paramhu;
      Objects.requireNonNull(iu);
      jn jn = jn.z("SELECT name FROM workname WHERE work_spec_id=?", 1);
      if (str3 == null) {
        jn.B(1);
      } else {
        jn.C(1, str3);
      } 
      iu.a.b();
      Cursor cursor = on.a(iu.a, (ao)jn, false, null);
      try {
        ArrayList<String> arrayList = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList.add(cursor.getString(0)); 
        cursor.close();
        jn.release();
        String str4 = mu.a;
        List list = ((ru)paramqu).a(str4);
        String str5 = TextUtils.join(",", arrayList);
      } finally {
        cursor.close();
        str2.release();
      } 
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.a doWork() {
    List<mu> list;
    String str;
    WorkDatabase workDatabase = (ks.b(getApplicationContext())).f;
    nu nu = workDatabase.q();
    hu hu = workDatabase.o();
    qu qu = workDatabase.r();
    eu eu = workDatabase.n();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    ou ou = (ou)nu;
    Objects.requireNonNull(ou);
    jn jn = jn.z("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    jn.A(1, l1 - l2);
    ou.a.b();
    Cursor cursor = on.a(ou.a, (ao)jn, false, null);
    try {
      int k = ComponentActivity.c.L(cursor, "required_network_type");
      int i1 = ComponentActivity.c.L(cursor, "requires_charging");
      int i = ComponentActivity.c.L(cursor, "requires_device_idle");
      int i5 = ComponentActivity.c.L(cursor, "requires_battery_not_low");
      int i6 = ComponentActivity.c.L(cursor, "requires_storage_not_low");
      int i7 = ComponentActivity.c.L(cursor, "trigger_content_update_delay");
      int i8 = ComponentActivity.c.L(cursor, "trigger_max_content_delay");
      int i9 = ComponentActivity.c.L(cursor, "content_uri_triggers");
      int m = ComponentActivity.c.L(cursor, "id");
      int j = ComponentActivity.c.L(cursor, "state");
      int i2 = ComponentActivity.c.L(cursor, "worker_class_name");
      int n = ComponentActivity.c.L(cursor, "input_merger_class_name");
      int i3 = ComponentActivity.c.L(cursor, "input");
      int i4 = ComponentActivity.c.L(cursor, "output");
      try {
        int i16 = ComponentActivity.c.L(cursor, "initial_delay");
        int i17 = ComponentActivity.c.L(cursor, "interval_duration");
        int i20 = ComponentActivity.c.L(cursor, "flex_duration");
        int i15 = ComponentActivity.c.L(cursor, "run_attempt_count");
        int i10 = ComponentActivity.c.L(cursor, "backoff_policy");
        int i11 = ComponentActivity.c.L(cursor, "backoff_delay_duration");
        int i19 = ComponentActivity.c.L(cursor, "period_start_time");
        int i13 = ComponentActivity.c.L(cursor, "minimum_retention_duration");
        int i14 = ComponentActivity.c.L(cursor, "schedule_requested_at");
        int i12 = ComponentActivity.c.L(cursor, "run_in_foreground");
        int i18 = ComponentActivity.c.L(cursor, "out_of_quota_policy");
        ArrayList<mu> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(i2);
            dr dr = new dr();
            dr.b = qo.E0(cursor.getInt(k));
            if (cursor.getInt(i1) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            dr.c = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            dr.d = bool;
            if (cursor.getInt(i5) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            dr.e = bool;
            if (cursor.getInt(i6) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            dr.f = bool;
            dr.g = cursor.getLong(i7);
            dr.h = cursor.getLong(i8);
            dr.i = qo.n(cursor.getBlob(i9));
            mu mu = new mu(str1, str2);
            mu.b = qo.G0(cursor.getInt(j));
            mu.d = cursor.getString(n);
            mu.e = fr.a(cursor.getBlob(i3));
            mu.f = fr.a(cursor.getBlob(i4));
            mu.g = cursor.getLong(i16);
            mu.h = cursor.getLong(i17);
            mu.i = cursor.getLong(i20);
            mu.k = cursor.getInt(i15);
            mu.l = qo.D0(cursor.getInt(i10));
            mu.m = cursor.getLong(i11);
            mu.n = cursor.getLong(i19);
            mu.o = cursor.getLong(i13);
            mu.p = cursor.getLong(i14);
            if (cursor.getInt(i12) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            mu.q = bool;
            mu.r = qo.F0(cursor.getInt(i18));
            mu.j = dr;
            arrayList.add(mu);
            continue;
          } 
          cursor.close();
          jn.release();
          ou ou1 = (ou)nu;
          List<mu> list1 = ou1.d();
          list = ou1.b(200);
          if (!arrayList.isEmpty()) {
            mr mr = mr.c();
            String str1 = a;
            mr.d(str1, "Recently completed work:\n\n", new Throwable[0]);
            mr.c().d(str1, a(hu, qu, eu, arrayList), new Throwable[0]);
          } 
          if (!((ArrayList)list1).isEmpty()) {
            mr mr = mr.c();
            String str1 = a;
            mr.d(str1, "Running work:\n\n", new Throwable[0]);
            mr.c().d(str1, a(hu, qu, eu, list1), new Throwable[0]);
          } 
          if (!((ArrayList)list).isEmpty()) {
            mr mr = mr.c();
            str = a;
            mr.d(str, "Enqueued work:\n\n", new Throwable[0]);
            mr.c().d(str, a(hu, qu, eu, list), new Throwable[0]);
          } 
          return (ListenableWorker.a)new ListenableWorker.a.c();
        } 
      } finally {}
    } finally {}
    str.close();
    list.release();
    throw hu;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */