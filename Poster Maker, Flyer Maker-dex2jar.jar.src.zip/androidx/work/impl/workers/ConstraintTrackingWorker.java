package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import bt;
import com.google.common.util.concurrent.ListenableFuture;
import ct;
import java.util.Collections;
import java.util.List;
import ks;
import mr;
import mu;
import mv;
import nu;
import nv;
import ou;

public class ConstraintTrackingWorker extends ListenableWorker implements bt {
  public static final String b = mr.e("ConstraintTrkngWrkr");
  
  public WorkerParameters c;
  
  public final Object d;
  
  public volatile boolean f;
  
  public mv<ListenableWorker.a> g;
  
  public ListenableWorker p;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.c = paramWorkerParameters;
    this.d = new Object();
    this.f = false;
    this.g = new mv();
  }
  
  public void a() {
    this.g.i(new ListenableWorker.a.a());
  }
  
  public void b(List<String> paramList) {
    mr.c().a(b, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.d) {
      this.f = true;
      return;
    } 
  }
  
  public void c() {
    this.g.i(new ListenableWorker.a.b());
  }
  
  public void f(List<String> paramList) {}
  
  public nv getTaskExecutor() {
    return (ks.b(getApplicationContext())).g;
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.p;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.p;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.p.stop(); 
  }
  
  public ListenableFuture<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (ListenableFuture<ListenableWorker.a>)this.g;
  }
  
  public class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      ConstraintTrackingWorker constraintTrackingWorker = this.b;
      String str1 = constraintTrackingWorker.getInputData().b("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (TextUtils.isEmpty(str1)) {
        mr.c().b(ConstraintTrackingWorker.b, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      ListenableWorker listenableWorker = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), str1, constraintTrackingWorker.c);
      constraintTrackingWorker.p = listenableWorker;
      if (listenableWorker == null) {
        mr.c().a(ConstraintTrackingWorker.b, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      nu nu = (ks.b(constraintTrackingWorker.getApplicationContext())).f.q();
      String str2 = constraintTrackingWorker.getId().toString();
      mu mu = ((ou)nu).i(str2);
      if (mu == null) {
        constraintTrackingWorker.a();
        return;
      } 
      ct ct = new ct(constraintTrackingWorker.getApplicationContext(), constraintTrackingWorker.getTaskExecutor(), constraintTrackingWorker);
      ct.b(Collections.singletonList(mu));
      if (ct.a(constraintTrackingWorker.getId().toString())) {
        mr.c().a(ConstraintTrackingWorker.b, String.format("Constraints met for delegate %s", new Object[] { str1 }), new Throwable[0]);
        try {
          return;
        } finally {
          ct = null;
          mr mr = mr.c();
          String str = ConstraintTrackingWorker.b;
          mr.a(str, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str1 }), new Throwable[] { (Throwable)ct });
        } 
      } 
      mr.c().a(ConstraintTrackingWorker.b, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str1 }), new Throwable[0]);
      constraintTrackingWorker.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */