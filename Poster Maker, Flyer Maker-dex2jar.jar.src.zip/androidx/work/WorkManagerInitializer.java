package androidx.work;

import android.content.Context;
import cr;
import io;
import java.util.Collections;
import java.util.List;
import ks;
import mr;
import vr;

public final class WorkManagerInitializer implements io<vr> {
  public static final String a = mr.e("WrkMgrInitializer");
  
  public Object a(Context paramContext) {
    mr.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    ks.c(paramContext, new cr(new cr.a()));
    return ks.b(paramContext);
  }
  
  public List<Class<? extends io<?>>> dependencies() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */