package androidx.work;

import fr;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import jr;

public final class OverwritingInputMerger extends jr {
  public fr a(List<fr> paramList) {
    fr.a a = new fr.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<fr> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(Collections.unmodifiableMap(((fr)iterator.next()).c)); 
    a.b(hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */