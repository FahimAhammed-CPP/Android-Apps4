package androidx.work;

import android.net.Network;
import android.net.Uri;
import fr;
import ir;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import nv;
import rr;
import yr;

public final class WorkerParameters {
  public UUID a;
  
  public fr b;
  
  public Set<String> c;
  
  public a d;
  
  public int e;
  
  public Executor f;
  
  public nv g;
  
  public yr h;
  
  public rr i;
  
  public ir j;
  
  public WorkerParameters(UUID paramUUID, fr paramfr, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, nv paramnv, yr paramyr, rr paramrr, ir paramir) {
    this.a = paramUUID;
    this.b = paramfr;
    this.c = new HashSet<String>(paramCollection);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutor;
    this.g = paramnv;
    this.h = paramyr;
    this.i = paramrr;
    this.j = paramir;
  }
  
  public static class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */