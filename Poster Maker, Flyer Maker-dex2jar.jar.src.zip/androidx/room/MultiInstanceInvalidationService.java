package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import en;
import fn;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  public int b = 0;
  
  public final HashMap<Integer, String> c = new HashMap<Integer, String>();
  
  public final RemoteCallbackList<en> d = new a(this);
  
  public final fn f = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.f;
  }
  
  public class a extends RemoteCallbackList<en> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public void onCallbackDied(IInterface param1IInterface, Object param1Object) {
      en en = (en)param1IInterface;
      this.a.c.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public class b extends fn {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public void b(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.b.d) {
        String str = this.b.c.get(Integer.valueOf(param1Int));
        if (str == null)
          return; 
        int j = this.b.d.beginBroadcast();
        int i = 0;
        while (true) {
          if (i < j) {
            try {
              int k = ((Integer)this.b.d.getBroadcastCookie(i)).intValue();
              String str1 = this.b.c.get(Integer.valueOf(k));
              if (param1Int != k) {
                boolean bool = str.equals(str1);
                if (bool)
                  try {
                    ((en)this.b.d.getBroadcastItem(i)).a(param1ArrayOfString);
                  } catch (RemoteException remoteException) {} 
              } 
            } finally {
              this.b.d.finishBroadcast();
            } 
            continue;
          } 
          this.b.d.finishBroadcast();
          return;
        } 
      } 
    }
    
    public int c(en param1en, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.b.d) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.b;
        int i = multiInstanceInvalidationService2.b + 1;
        multiInstanceInvalidationService2.b = i;
        if (multiInstanceInvalidationService2.d.register((IInterface)param1en, Integer.valueOf(i))) {
          this.b.c.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.b;
        multiInstanceInvalidationService1.b--;
        return 0;
      } 
    }
    
    public void d(en param1en, int param1Int) {
      synchronized (this.b.d) {
        this.b.d.unregister((IInterface)param1en);
        this.b.c.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */