package androidx.lifecycle;

import java.util.List;
import kj;
import qj;
import tj;
import vj;

@Deprecated
public class ReflectiveGenericLifecycleObserver implements tj {
  public final Object a;
  
  public final kj.a b;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.a = paramObject;
    this.b = kj.a.b(paramObject.getClass());
  }
  
  public void c(vj paramvj, qj.a parama) {
    kj.a a1 = this.b;
    Object object = this.a;
    kj.a.a((List)a1.a.get(parama), paramvj, parama, object);
    kj.a.a((List)a1.a.get(qj.a.ON_ANY), paramvj, parama, object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */