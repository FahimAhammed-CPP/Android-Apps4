package androidx.lifecycle;

import hk;
import java.util.HashSet;
import java.util.Objects;
import kk;
import qj;
import qk;
import rk;
import rn;
import tj;
import tn;
import uj;
import vj;
import wj;

public final class SavedStateHandleController implements tj {
  public final String a;
  
  public boolean b = false;
  
  public final hk c;
  
  public SavedStateHandleController(String paramString, hk paramhk) {
    this.a = paramString;
    this.c = paramhk;
  }
  
  public static void h(kk paramkk, rn paramrn, qj paramqj) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/Map;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 14
    //   9: aconst_null
    //   10: astore_0
    //   11: goto -> 30
    //   14: aload_3
    //   15: monitorenter
    //   16: aload_0
    //   17: getfield a : Ljava/util/Map;
    //   20: ldc 'androidx.lifecycle.savedstate.vm.tag'
    //   22: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   27: astore_0
    //   28: aload_3
    //   29: monitorexit
    //   30: aload_0
    //   31: checkcast androidx/lifecycle/SavedStateHandleController
    //   34: astore_0
    //   35: aload_0
    //   36: ifnull -> 57
    //   39: aload_0
    //   40: getfield b : Z
    //   43: ifne -> 57
    //   46: aload_0
    //   47: aload_1
    //   48: aload_2
    //   49: invokevirtual i : (Lrn;Lqj;)V
    //   52: aload_1
    //   53: aload_2
    //   54: invokestatic j : (Lrn;Lqj;)V
    //   57: return
    //   58: astore_0
    //   59: aload_3
    //   60: monitorexit
    //   61: aload_0
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   16	30	58	finally
    //   59	61	58	finally
  }
  
  public static void j(rn paramrn, qj paramqj) {
    qj.b b = ((wj)paramqj).b;
    if (b == qj.b.INITIALIZED || b.isAtLeast(qj.b.STARTED)) {
      paramrn.c(a.class);
      return;
    } 
    paramqj.a((uj)new tj(paramqj, paramrn) {
          public void c(vj param1vj, qj.a param1a) {
            if (param1a == qj.a.ON_START) {
              wj wj = (wj)this.a;
              wj.d("removeObserver");
              wj.a.e(this);
              this.b.c(SavedStateHandleController.a.class);
            } 
          }
        });
  }
  
  public void c(vj paramvj, qj.a parama) {
    if (parama == qj.a.ON_DESTROY) {
      this.b = false;
      wj wj = (wj)paramvj.getLifecycle();
      wj.d("removeObserver");
      wj.a.e(this);
    } 
  }
  
  public void i(rn paramrn, qj paramqj) {
    if (!this.b) {
      this.b = true;
      paramqj.a((uj)this);
      paramrn.b(this.a, this.c.e);
      return;
    } 
    throw new IllegalStateException("Already attached to lifecycleOwner");
  }
  
  public static final class a implements rn.a {
    public void a(tn param1tn) {
      if (param1tn instanceof rk) {
        qk qk = ((rk)param1tn).getViewModelStore();
        rn rn = param1tn.getSavedStateRegistry();
        Objects.requireNonNull(qk);
        for (String str : new HashSet(qk.a.keySet()))
          SavedStateHandleController.h((kk)qk.a.get(str), rn, param1tn.getLifecycle()); 
        if (!(new HashSet(qk.a.keySet())).isEmpty())
          rn.c(a.class); 
        return;
      } 
      IllegalStateException illegalStateException = new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
      throw illegalStateException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */