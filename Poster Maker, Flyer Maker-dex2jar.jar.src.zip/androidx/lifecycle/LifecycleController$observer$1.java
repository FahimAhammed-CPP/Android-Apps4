package androidx.lifecycle;

import java.util.Objects;
import qj;
import tj;
import vj;
import wj;
import y63;

public final class LifecycleController$observer$1 implements tj {
  public final void c(vj paramvj, qj.a parama) {
    y63.e(paramvj, "source");
    y63.e(parama, "<anonymous parameter 1>");
    qj qj2 = paramvj.getLifecycle();
    y63.d(qj2, "source.lifecycle");
    if (((wj)qj2).b == qj.b.DESTROYED)
      throw null; 
    qj qj1 = paramvj.getLifecycle();
    y63.d(qj1, "source.lifecycle");
    wj wj = (wj)qj1;
    Objects.requireNonNull(null);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\LifecycleController$observer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */