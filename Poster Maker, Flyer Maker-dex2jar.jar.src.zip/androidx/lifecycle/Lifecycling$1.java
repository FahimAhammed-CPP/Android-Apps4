package androidx.lifecycle;

import qj;
import tj;
import vj;

public class Lifecycling$1 implements tj {
  public void c(vj paramvj, qj.a parama) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\Lifecycling$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */