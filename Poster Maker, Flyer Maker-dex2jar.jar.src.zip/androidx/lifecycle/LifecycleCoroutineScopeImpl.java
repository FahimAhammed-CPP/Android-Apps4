package androidx.lifecycle;

import qj;
import rj;
import tj;
import vj;
import y63;

public final class LifecycleCoroutineScopeImpl extends rj implements tj {
  public void c(vj paramvj, qj.a parama) {
    y63.e(paramvj, "source");
    y63.e(parama, "event");
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScopeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */