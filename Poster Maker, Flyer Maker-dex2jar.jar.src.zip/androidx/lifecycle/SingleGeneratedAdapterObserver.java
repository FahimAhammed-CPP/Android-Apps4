package androidx.lifecycle;

import pj;
import qj;
import tj;
import vj;

public class SingleGeneratedAdapterObserver implements tj {
  public final pj a;
  
  public SingleGeneratedAdapterObserver(pj parampj) {
    this.a = parampj;
  }
  
  public void c(vj paramvj, qj.a parama) {
    this.a.a(paramvj, parama, false, null);
    this.a.a(paramvj, parama, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */