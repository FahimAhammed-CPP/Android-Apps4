package androidx.lifecycle;

import oj;
import qj;
import tj;
import vj;

public class FullLifecycleObserverAdapter implements tj {
  public final oj a;
  
  public final tj b;
  
  public FullLifecycleObserverAdapter(oj paramoj, tj paramtj) {
    this.a = paramoj;
    this.b = paramtj;
  }
  
  public void c(vj paramvj, qj.a parama) {
    switch (parama.ordinal()) {
      case 6:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 5:
        this.a.f(paramvj);
        break;
      case 4:
        this.a.e(paramvj);
        break;
      case 3:
        this.a.d(paramvj);
        break;
      case 2:
        this.a.a(paramvj);
        break;
      case 1:
        this.a.g(paramvj);
        break;
      case 0:
        this.a.b(paramvj);
        break;
    } 
    tj tj1 = this.b;
    if (tj1 != null)
      tj1.c(paramvj, parama); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */