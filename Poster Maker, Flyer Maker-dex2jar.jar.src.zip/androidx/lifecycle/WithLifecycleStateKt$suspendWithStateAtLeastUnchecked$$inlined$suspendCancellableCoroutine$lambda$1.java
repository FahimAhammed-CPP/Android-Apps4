package androidx.lifecycle;

import qj;
import tj;
import vj;
import y63;

public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 implements tj {
  public void c(vj paramvj, qj.a parama) {
    y63.e(paramvj, "source");
    y63.e(parama, "event");
    if (parama != qj.a.upTo(null)) {
      if (parama != qj.a.ON_DESTROY)
        return; 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */