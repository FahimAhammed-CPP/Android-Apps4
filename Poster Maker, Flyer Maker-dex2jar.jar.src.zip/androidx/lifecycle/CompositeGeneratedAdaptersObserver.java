package androidx.lifecycle;

import ak;
import pj;
import qj;
import tj;
import vj;

public class CompositeGeneratedAdaptersObserver implements tj {
  public final pj[] a;
  
  public CompositeGeneratedAdaptersObserver(pj[] paramArrayOfpj) {
    this.a = paramArrayOfpj;
  }
  
  public void c(vj paramvj, qj.a parama) {
    ak ak = new ak();
    pj[] arrayOfPj = this.a;
    int j = arrayOfPj.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      arrayOfPj[i].a(paramvj, parama, false, ak); 
    arrayOfPj = this.a;
    j = arrayOfPj.length;
    for (i = bool; i < j; i++)
      arrayOfPj[i].a(paramvj, parama, true, ak); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */