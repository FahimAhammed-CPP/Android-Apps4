package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import ek;
import fk;
import io;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import qj;
import sj;
import vj;

public final class ProcessLifecycleInitializer implements io<vj> {
  public Object a(Context paramContext) {
    if (!sj.a.getAndSet(true))
      ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new sj.a()); 
    ek ek = ek.b;
    Objects.requireNonNull(ek);
    ek.p = new Handler();
    ek.q.e(qj.a.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new fk(ek));
    return ek;
  }
  
  public List<Class<? extends io<?>>> dependencies() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */