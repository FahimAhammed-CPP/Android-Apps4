package androidx.lifecycle;

import ck;
import java.util.Map;
import qj;
import s30;
import tj;
import u4;
import uj;
import vj;
import wj;
import y4;

public abstract class LiveData<T> {
  public static final Object a = new Object();
  
  public final Object b = new Object();
  
  public y4<ck<? super T>, c> c = new y4();
  
  public int d = 0;
  
  public boolean e;
  
  public volatile Object f;
  
  public volatile Object g;
  
  public int h;
  
  public boolean i;
  
  public boolean j;
  
  public final Runnable k;
  
  public LiveData() {
    Object object = a;
    this.g = object;
    this.k = new a(this);
    this.f = object;
    this.h = -1;
  }
  
  public static void a(String paramString) {
    if (u4.d().b())
      return; 
    throw new IllegalStateException(s30.h0("Cannot invoke ", paramString, " on a background thread"));
  }
  
  public final void b(c paramc) {
    if (!paramc.b)
      return; 
    if (!paramc.k()) {
      paramc.h(false);
      return;
    } 
    int i = paramc.c;
    int j = this.h;
    if (i >= j)
      return; 
    paramc.c = j;
    paramc.a.a(this.f);
  }
  
  public void c(c paramc) {
    if (this.i) {
      this.j = true;
      return;
    } 
    this.i = true;
    while (true) {
      c c1;
      this.j = false;
      if (paramc != null) {
        b(paramc);
        c1 = null;
      } else {
        y4.d d = this.c.b();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            b((c)((Map.Entry)d.next()).getValue());
            if (this.j) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.j) {
        this.i = false;
        return;
      } 
    } 
  }
  
  public void d(vj paramvj, ck<? super T> paramck) {
    a("observe");
    if (((wj)paramvj.getLifecycle()).b == qj.b.DESTROYED)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramvj, paramck);
    c c = (c)this.c.d(paramck, lifecycleBoundObserver);
    if (c == null || c.j(paramvj)) {
      if (c != null)
        return; 
      paramvj.getLifecycle().a((uj)lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void e() {}
  
  public void f() {}
  
  public void g(ck<? super T> paramck) {
    a("removeObserver");
    c c = (c)this.c.e(paramck);
    if (c == null)
      return; 
    c.i();
    c.h(false);
  }
  
  public abstract void h(T paramT);
  
  public class LifecycleBoundObserver extends c implements tj {
    public final vj e;
    
    public LifecycleBoundObserver(LiveData this$0, vj param1vj, ck<? super T> param1ck) {
      super(this$0, param1ck);
      this.e = param1vj;
    }
    
    public void c(vj param1vj, qj.a param1a) {
      qj.b b = ((wj)this.e.getLifecycle()).b;
      if (b == qj.b.DESTROYED) {
        this.f.g(this.a);
        return;
      } 
      param1a = null;
      while (param1a != b) {
        h(((wj)this.e.getLifecycle()).b.isAtLeast(qj.b.STARTED));
        qj.b b2 = ((wj)this.e.getLifecycle()).b;
        qj.b b1 = b;
        b = b2;
      } 
    }
    
    public void i() {
      wj wj = (wj)this.e.getLifecycle();
      wj.d("removeObserver");
      wj.a.e(this);
    }
    
    public boolean j(vj param1vj) {
      return (this.e == param1vj);
    }
    
    public boolean k() {
      return ((wj)this.e.getLifecycle()).b.isAtLeast(qj.b.STARTED);
    }
  }
  
  public class a implements Runnable {
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.b.b) {
        Object object = this.b.g;
        this.b.g = LiveData.a;
        this.b.h(object);
        return;
      } 
    }
  }
  
  public class b extends c {
    public b(LiveData this$0, ck<? super T> param1ck) {
      super(this$0, param1ck);
    }
    
    public boolean k() {
      return true;
    }
  }
  
  public abstract class c {
    public final ck<? super T> a;
    
    public boolean b;
    
    public int c = -1;
    
    public c(LiveData this$0, ck<? super T> param1ck) {
      this.a = param1ck;
    }
    
    public void h(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      LiveData liveData = this.d;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      int i = liveData.d;
      liveData.d = b + i;
      if (!liveData.e) {
        liveData.e = true;
        while (true) {
          int j;
          try {
            j = liveData.d;
          } finally {
            liveData.e = false;
          } 
          if (i > 0 && j == 0) {
            i = 1;
          } else {
            i = 0;
          } 
          if (b != 0) {
            liveData.e();
          } else if (i != 0) {
            liveData.f();
          } 
          i = j;
        } 
      } 
      if (this.b)
        this.d.c(this); 
    }
    
    public void i() {}
    
    public boolean j(vj param1vj) {
      return false;
    }
    
    public abstract boolean k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */