package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import b7;
import c9;
import v6;
import v8;
import y6;

public class Barrier extends v8 {
  public int s;
  
  public int t;
  
  public v6 u;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  public boolean getAllowsGoneWidget() {
    return this.u.u0;
  }
  
  public int getMargin() {
    return this.u.v0;
  }
  
  public int getType() {
    return this.s;
  }
  
  public void j(AttributeSet paramAttributeSet) {
    super.j(paramAttributeSet);
    this.u = new v6();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, c9.ConstraintLayout_Layout);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == c9.ConstraintLayout_Layout_barrierDirection) {
          setType(typedArray.getInt(k, 0));
        } else if (k == c9.ConstraintLayout_Layout_barrierAllowsGoneWidgets) {
          this.u.u0 = typedArray.getBoolean(k, true);
        } else if (k == c9.ConstraintLayout_Layout_barrierMargin) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.u.v0 = k;
        } 
      } 
      typedArray.recycle();
    } 
    this.f = (b7)this.u;
    o();
  }
  
  public void k(y6 paramy6, boolean paramBoolean) {
    int i = this.s;
    this.t = i;
    if (paramBoolean) {
      if (i == 5) {
        this.t = 1;
      } else if (i == 6) {
        this.t = 0;
      } 
    } else if (i == 5) {
      this.t = 0;
    } else if (i == 6) {
      this.t = 1;
    } 
    if (paramy6 instanceof v6)
      ((v6)paramy6).t0 = this.t; 
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.u.u0 = paramBoolean;
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.u.v0 = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.u.v0 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.s = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */