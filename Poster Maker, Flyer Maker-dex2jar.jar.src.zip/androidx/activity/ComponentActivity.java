package androidx.activity;

import a7;
import af;
import ag;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.Application;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.icu.text.DecimalFormatSymbols;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.Trace;
import android.os.UserManager;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CompoundButton;
import android.widget.EdgeEffect;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.activity.result.ActivityResultRegistry;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import c4;
import c7;
import cg;
import ch;
import db;
import df;
import dh;
import e;
import e6;
import ef;
import fe;
import gk;
import h;
import hc;
import hf;
import i;
import ik;
import j;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import jf;
import l;
import l8;
import lg;
import m;
import ma;
import mb;
import mk;
import n;
import nb;
import nd;
import o;
import o9;
import ob;
import od;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import p;
import p4;
import pb;
import qa;
import qg;
import qj;
import qk;
import qn;
import qo;
import r9;
import ra;
import rd;
import re;
import rk;
import rn;
import s30;
import s9;
import sa;
import sd;
import sk;
import sn;
import t4;
import t7;
import ta;
import tc;
import td;
import tj;
import tk;
import tn;
import u8;
import u9;
import ua;
import uj;
import um;
import vh;
import vj;
import wj;
import x6;
import x9;
import y6;
import y9;
import z6;

public class ComponentActivity extends y9 implements vj, rk, tn, h, n {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry = new b(this);
  
  private int mContentLayoutId;
  
  public final i mContextAwareHelper = new i();
  
  private mk mDefaultFactory;
  
  private final wj mLifecycleRegistry = new wj(this);
  
  private final nd mMenuHostHelper = new nd((Runnable)new c(this));
  
  private final AtomicInteger mNextLocalRequestCode = new AtomicInteger();
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
  
  public final sn mSavedStateRegistryController = new sn(this);
  
  private qk mViewModelStore;
  
  public ComponentActivity() {
    if (getLifecycle() != null) {
      int j = Build.VERSION.SDK_INT;
      getLifecycle().a((uj)new tj(this) {
            public void c(vj param1vj, qj.a param1a) {
              if (param1a == qj.a.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  window.cancelPendingInputEvents(); 
              } 
            }
          });
      getLifecycle().a((uj)new tj(this) {
            public void c(vj param1vj, qj.a param1a) {
              if (param1a == qj.a.ON_DESTROY) {
                this.a.mContextAwareHelper.b = null;
                if (!this.a.isChangingConfigurations())
                  this.a.getViewModelStore().a(); 
              } 
            }
          });
      getLifecycle().a((uj)new tj(this) {
            public void c(vj param1vj, qj.a param1a) {
              this.a.ensureViewModelStore();
              wj wj = (wj)this.a.getLifecycle();
              wj.d("removeObserver");
              wj.a.e(this);
            }
          });
      if (j <= 23)
        getLifecycle().a((uj)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().b("android:support:activity-result", (rn.b)new e(this));
      addOnContextAvailableListener((j)new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private void initViewTreeOwners() {
    getWindow().getDecorView().setTag(sk.view_tree_lifecycle_owner, this);
    getWindow().getDecorView().setTag(tk.view_tree_view_model_store_owner, this);
    getWindow().getDecorView().setTag(qn.view_tree_saved_state_registry_owner, this);
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(od paramod) {
    nd nd1 = this.mMenuHostHelper;
    nd1.b.add(paramod);
    nd1.a.run();
  }
  
  public void addMenuProvider(od paramod, vj paramvj) {
    this.mMenuHostHelper.a(paramod, paramvj);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(od paramod, vj paramvj, qj.b paramb) {
    this.mMenuHostHelper.b(paramod, paramvj, paramb);
  }
  
  public final void addOnContextAvailableListener(j paramj) {
    i i1 = this.mContextAwareHelper;
    if (i1.b != null)
      paramj.a(i1.b); 
    i1.a.add(paramj);
  }
  
  public void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      d d = (d)getLastNonConfigurationInstance();
      if (d != null)
        this.mViewModelStore = d.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new qk(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public mk getDefaultViewModelProviderFactory() {
    if (getApplication() != null) {
      if (this.mDefaultFactory == null) {
        Bundle bundle;
        Application application = getApplication();
        if (getIntent() != null) {
          bundle = getIntent().getExtras();
        } else {
          bundle = null;
        } 
        this.mDefaultFactory = (mk)new ik(application, this, bundle);
      } 
      return this.mDefaultFactory;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    d d = (d)getLastNonConfigurationInstance();
    return (d != null) ? d.a : null;
  }
  
  public qj getLifecycle() {
    return (qj)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final rn getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b;
  }
  
  public qk getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public Bundle h() {
    Bundle bundle = new Bundle();
    ActivityResultRegistry activityResultRegistry = this.mActivityResultRegistry;
    Objects.requireNonNull(activityResultRegistry);
    bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(activityResultRegistry.c.values()));
    bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(activityResultRegistry.c.keySet()));
    bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(activityResultRegistry.e));
    bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)activityResultRegistry.h.clone());
    bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", activityResultRegistry.a);
    return bundle;
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  public void j(Context paramContext) {
    Bundle bundle = getSavedStateRegistry().a("android:support:activity-result");
    if (bundle != null) {
      ActivityResultRegistry activityResultRegistry = this.mActivityResultRegistry;
      Objects.requireNonNull(activityResultRegistry);
      ArrayList<Integer> arrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
      ArrayList<String> arrayList1 = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
      if (arrayList1 != null) {
        if (arrayList == null)
          return; 
        activityResultRegistry.e = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        activityResultRegistry.a = (Random)bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
        activityResultRegistry.h.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
        for (int j = 0; j < arrayList1.size(); j++) {
          String str = arrayList1.get(j);
          if (activityResultRegistry.c.containsKey(str)) {
            Integer integer = (Integer)activityResultRegistry.c.remove(str);
            if (!activityResultRegistry.h.containsKey(str))
              activityResultRegistry.b.remove(integer); 
          } 
          int k = ((Integer)arrayList.get(j)).intValue();
          str = arrayList1.get(j);
          activityResultRegistry.b.put(Integer.valueOf(k), str);
          activityResultRegistry.c.put(str, Integer.valueOf(k));
        } 
      } 
    } 
  }
  
  @Deprecated
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.a(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.a();
  }
  
  public void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.a(paramBundle);
    i i1 = this.mContextAwareHelper;
    i1.b = (Context)this;
    Iterator<j> iterator = i1.a.iterator();
    while (iterator.hasNext())
      ((j)iterator.next()).a((Context)this); 
    super.onCreate(paramBundle);
    gk.c((Activity)this);
    int j = this.mContentLayoutId;
    if (j != 0)
      setContentView(j); 
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    super.onCreateOptionsMenu(paramMenu);
    this.mMenuHostHelper.c(paramMenu, getMenuInflater());
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    return super.onOptionsItemSelected(paramMenuItem) ? true : this.mMenuHostHelper.d(paramMenuItem);
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.a(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    qk qk2 = this.mViewModelStore;
    qk qk1 = qk2;
    if (qk2 == null) {
      d d1 = (d)getLastNonConfigurationInstance();
      qk1 = qk2;
      if (d1 != null)
        qk1 = d1.b; 
    } 
    if (qk1 == null && object == null)
      return null; 
    d d = new d();
    d.a = object;
    d.b = qk1;
    return d;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    qj qj = getLifecycle();
    if (qj instanceof wj)
      ((wj)qj).i(qj.b.CREATED); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.b(paramBundle);
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.b;
  }
  
  public final <I, O> m<I> registerForActivityResult(p<I, O> paramp, ActivityResultRegistry paramActivityResultRegistry, l<O> paraml) {
    StringBuilder stringBuilder = s30.x0("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.d(stringBuilder.toString(), this, paramp, paraml);
  }
  
  public final <I, O> m<I> registerForActivityResult(p<I, O> paramp, l<O> paraml) {
    return registerForActivityResult(paramp, this.mActivityResultRegistry, paraml);
  }
  
  public void removeMenuProvider(od paramod) {
    this.mMenuHostHelper.e(paramod);
  }
  
  public final void removeOnContextAvailableListener(j paramj) {
    this.mContextAwareHelper.a.remove(paramj);
  }
  
  public void reportFullyDrawn() {
    try {
      if (qo.I0())
        Trace.beginSection("reportFullyDrawn() for ComponentActivity"); 
      int j = Build.VERSION.SDK_INT;
      if (j > 19) {
        super.reportFullyDrawn();
      } else if (j == 19 && ma.checkSelfPermission((Context)this, "android.permission.UPDATE_DEVICE_STATS") == 0) {
        super.reportFullyDrawn();
      } 
      return;
    } finally {
      Trace.endSection();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.b.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  public class b extends ActivityResultRegistry {
    public b(ComponentActivity this$0) {}
    
    public <I, O> void b(int param1Int, p<I, O> param1p, I param1I, u9 param1u9) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      o o;
      ComponentActivity componentActivity = this.i;
      p.a a = param1p.b((Context)componentActivity, param1I);
      if (a != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a));
        return;
      } 
      Intent intent = param1p.a((Context)componentActivity, param1I);
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else if (param1u9 == null) {
        param1p = null;
      } else {
        throw null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        s9.a((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        o = (o)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          IntentSender intentSender = o.b;
          Intent intent1 = o.c;
          int j = o.d;
          int k = o.f;
          int m = s9.a;
          componentActivity.startIntentSenderForResult(intentSender, param1Int, intent1, j, k, 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      int i = s9.a;
      componentActivity.startActivityForResult((Intent)o, param1Int, (Bundle)sendIntentException);
    }
    
    public class a implements Runnable {
      public a(ComponentActivity.b this$0, int param2Int, p.a param2a) {}
      
      public void run() {
        ComponentActivity.b b1 = this.d;
        int i = this.b;
        Object object = this.c.a;
        String str = (String)b1.b.get(Integer.valueOf(i));
        if (str == null)
          return; 
        ActivityResultRegistry.c c = (ActivityResultRegistry.c)b1.f.get(str);
        if (c != null) {
          l l = c.a;
          if (l == null) {
            b1.h.remove(str);
            b1.g.put(str, object);
            return;
          } 
          if (b1.e.remove(str)) {
            l.a(object);
            return;
          } 
          return;
        } 
        b1.h.remove(str);
        b1.g.put(str, object);
      }
    }
    
    public class b implements Runnable {
      public b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.d.a(this.b, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.c));
      }
    }
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0, int param1Int, p.a param1a) {}
    
    public void run() {
      ComponentActivity.b b1 = this.d;
      int i = this.b;
      Object object = this.c.a;
      String str = (String)b1.b.get(Integer.valueOf(i));
      if (str == null)
        return; 
      ActivityResultRegistry.c c = (ActivityResultRegistry.c)b1.f.get(str);
      if (c != null) {
        l l = c.a;
        if (l == null) {
          b1.h.remove(str);
          b1.g.put(str, object);
          return;
        } 
        if (b1.e.remove(str)) {
          l.a(object);
          return;
        } 
        return;
      } 
      b1.h.remove(str);
      b1.g.put(str, object);
    }
  }
  
  public class b implements Runnable {
    public b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.d.a(this.b, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.c));
    }
  }
  
  public static class c {
    public static Field a;
    
    public static boolean b;
    
    public static Class<?> c;
    
    public static boolean d;
    
    public static Field e;
    
    public static boolean f;
    
    public static Field g;
    
    public static boolean h;
    
    public static Method i;
    
    public static boolean j;
    
    public static Method k;
    
    public static boolean l;
    
    public static Field m;
    
    public static boolean n;
    
    public static Field o;
    
    public static boolean p;
    
    public static Method q;
    
    public static boolean r;
    
    public static Field s;
    
    public static boolean t;
    
    public static lg A(Context param1Context) {
      // Byte code:
      //   0: getstatic android/os/Build$VERSION.SDK_INT : I
      //   3: bipush #28
      //   5: if_icmplt -> 20
      //   8: new fg
      //   11: dup
      //   12: invokespecial <init> : ()V
      //   15: astore #4
      //   17: goto -> 29
      //   20: new eg
      //   23: dup
      //   24: invokespecial <init> : ()V
      //   27: astore #4
      //   29: aload_0
      //   30: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   33: astore #6
      //   35: aload #6
      //   37: ldc 'Package manager required to locate emoji font provider'
      //   39: invokestatic l : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   42: pop
      //   43: new android/content/Intent
      //   46: dup
      //   47: ldc 'androidx.content.action.LOAD_EMOJI_FONT'
      //   49: invokespecial <init> : (Ljava/lang/String;)V
      //   52: astore #5
      //   54: iconst_0
      //   55: istore_2
      //   56: aload #4
      //   58: aload #6
      //   60: aload #5
      //   62: iconst_0
      //   63: invokevirtual c : (Landroid/content/pm/PackageManager;Landroid/content/Intent;I)Ljava/util/List;
      //   66: invokeinterface iterator : ()Ljava/util/Iterator;
      //   71: astore #7
      //   73: aload #7
      //   75: invokeinterface hasNext : ()Z
      //   80: ifeq -> 142
      //   83: aload #4
      //   85: aload #7
      //   87: invokeinterface next : ()Ljava/lang/Object;
      //   92: checkcast android/content/pm/ResolveInfo
      //   95: invokevirtual a : (Landroid/content/pm/ResolveInfo;)Landroid/content/pm/ProviderInfo;
      //   98: astore #5
      //   100: iconst_1
      //   101: istore_1
      //   102: aload #5
      //   104: ifnull -> 133
      //   107: aload #5
      //   109: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
      //   112: astore #8
      //   114: aload #8
      //   116: ifnull -> 133
      //   119: aload #8
      //   121: getfield flags : I
      //   124: iconst_1
      //   125: iand
      //   126: iconst_1
      //   127: if_icmpne -> 133
      //   130: goto -> 135
      //   133: iconst_0
      //   134: istore_1
      //   135: iload_1
      //   136: ifeq -> 73
      //   139: goto -> 145
      //   142: aconst_null
      //   143: astore #5
      //   145: aload #5
      //   147: ifnonnull -> 153
      //   150: goto -> 251
      //   153: aload #5
      //   155: getfield authority : Ljava/lang/String;
      //   158: astore #7
      //   160: aload #5
      //   162: getfield packageName : Ljava/lang/String;
      //   165: astore #5
      //   167: aload #4
      //   169: aload #6
      //   171: aload #5
      //   173: invokevirtual b : (Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
      //   176: astore #4
      //   178: new java/util/ArrayList
      //   181: dup
      //   182: invokespecial <init> : ()V
      //   185: astore #6
      //   187: aload #4
      //   189: arraylength
      //   190: istore_3
      //   191: iload_2
      //   192: istore_1
      //   193: iload_1
      //   194: iload_3
      //   195: if_icmpge -> 218
      //   198: aload #6
      //   200: aload #4
      //   202: iload_1
      //   203: aaload
      //   204: invokevirtual toByteArray : ()[B
      //   207: invokevirtual add : (Ljava/lang/Object;)Z
      //   210: pop
      //   211: iload_1
      //   212: iconst_1
      //   213: iadd
      //   214: istore_1
      //   215: goto -> 193
      //   218: new hc
      //   221: dup
      //   222: aload #7
      //   224: aload #5
      //   226: ldc 'emojicompat-emoji-font'
      //   228: aload #6
      //   230: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
      //   233: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
      //   236: astore #4
      //   238: goto -> 254
      //   241: astore #4
      //   243: ldc 'emoji2.text.DefaultEmojiConfig'
      //   245: aload #4
      //   247: invokestatic wtf : (Ljava/lang/String;Ljava/lang/Throwable;)I
      //   250: pop
      //   251: aconst_null
      //   252: astore #4
      //   254: aload #4
      //   256: ifnonnull -> 261
      //   259: aconst_null
      //   260: areturn
      //   261: new lg
      //   264: dup
      //   265: aload_0
      //   266: aload #4
      //   268: invokespecial <init> : (Landroid/content/Context;Lhc;)V
      //   271: areturn
      // Exception table:
      //   from	to	target	type
      //   153	191	241	android/content/pm/PackageManager$NameNotFoundException
      //   198	211	241	android/content/pm/PackageManager$NameNotFoundException
      //   218	238	241	android/content/pm/PackageManager$NameNotFoundException
    }
    
    public static void A0(LayoutInflater param1LayoutInflater, LayoutInflater.Factory2 param1Factory2) {
      param1LayoutInflater.setFactory2(param1Factory2);
      if (Build.VERSION.SDK_INT < 21) {
        LayoutInflater.Factory factory = param1LayoutInflater.getFactory();
        if (factory instanceof LayoutInflater.Factory2) {
          I(param1LayoutInflater, (LayoutInflater.Factory2)factory);
          return;
        } 
        I(param1LayoutInflater, param1Factory2);
      } 
    }
    
    public static ThreadPoolExecutor B(String param1String) {
      ag ag = new ag(param1String);
      ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>(), (ThreadFactory)ag);
      threadPoolExecutor.allowCoreThreadTimeOut(true);
      return threadPoolExecutor;
    }
    
    public static void B0(TextView param1TextView, int param1Int) {
      int i;
      j(param1Int);
      if (Build.VERSION.SDK_INT >= 28) {
        param1TextView.setFirstBaselineToTopHeight(param1Int);
        return;
      } 
      Paint.FontMetricsInt fontMetricsInt = param1TextView.getPaint().getFontMetricsInt();
      if (param1TextView.getIncludeFontPadding()) {
        i = fontMetricsInt.top;
      } else {
        i = fontMetricsInt.ascent;
      } 
      if (param1Int > Math.abs(i))
        param1TextView.setPadding(param1TextView.getPaddingLeft(), param1Int + i, param1TextView.getPaddingRight(), param1TextView.getPaddingBottom()); 
    }
    
    public static db[] C(String param1String) {
      if (param1String == null)
        return null; 
      ArrayList<db> arrayList = new ArrayList();
      int j = 1;
      int i = 0;
      label77: while (true) {
        if (j < param1String.length()) {
          while (j < param1String.length()) {
            char c1 = param1String.charAt(j);
            if (((c1 - 90) * (c1 - 65) <= 0 || (c1 - 122) * (c1 - 97) <= 0) && c1 != 'e' && c1 != 'E')
              break; 
            j++;
          } 
          String str = param1String.substring(i, j).trim();
          if (str.length() > 0) {
            Object object;
            int k;
            int m;
            float[] arrayOfFloat;
            if (str.charAt(0) == 'z' || str.charAt(0) == 'Z') {
              arrayOfFloat = new float[0];
              continue;
            } 
            try {
              arrayOfFloat = new float[str.length()];
              m = str.length();
              boolean bool = true;
              k = 0;
            } catch (NumberFormatException numberFormatException) {
              throw new RuntimeException(s30.h0("error in parsing \"", str, "\""), numberFormatException);
            } 
            while (true) {
              if (object < m) {
                int n;
                int i1;
                boolean bool1 = false;
                i = 0;
                boolean bool2 = false;
                boolean bool3 = false;
                Object object1 = object;
                while (true) {
                  i1 = i;
                  n = object1 + 1;
                } 
                if (!i1)
                  n++; 
                continue;
              } 
              arrayOfFloat = w(arrayOfFloat, 0, k);
              arrayList.add(new db(str.charAt(0), arrayOfFloat));
              i = j;
              j++;
              continue label77;
              object = SYNTHETIC_LOCAL_VARIABLE_4;
              k = i;
            } 
            break;
          } 
          continue;
        } 
        if (j - i == 1 && i < numberFormatException.length())
          arrayList.add(new db(numberFormatException.charAt(i), new float[0])); 
        return arrayList.<db>toArray(new db[arrayList.size()]);
      } 
    }
    
    public static void C0(Drawable param1Drawable, float param1Float1, float param1Float2) {
      if (Build.VERSION.SDK_INT >= 21)
        param1Drawable.setHotspot(param1Float1, param1Float2); 
    }
    
    public static Path D(String param1String) {
      Path path = new Path();
      db[] arrayOfDb = C(param1String);
      if (arrayOfDb != null)
        try {
          db.b(arrayOfDb, path);
          return path;
        } catch (RuntimeException runtimeException) {
          throw new RuntimeException(s30.g0("Error in parsing ", param1String), runtimeException);
        }  
      return null;
    }
    
    public static void D0(Drawable param1Drawable, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (Build.VERSION.SDK_INT >= 21)
        param1Drawable.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public static db[] E(db[] param1ArrayOfdb) {
      if (param1ArrayOfdb == null)
        return null; 
      db[] arrayOfDb = new db[param1ArrayOfdb.length];
      for (int i = 0; i < param1ArrayOfdb.length; i++)
        arrayOfDb[i] = new db(param1ArrayOfdb[i]); 
      return arrayOfDb;
    }
    
    public static void E0(ImageView param1ImageView, ColorStateList param1ColorStateList) {
      Drawable drawable;
      int i = Build.VERSION.SDK_INT;
      if (i >= 21) {
        param1ImageView.setImageTintList(param1ColorStateList);
        if (i == 21) {
          drawable = param1ImageView.getDrawable();
          if (drawable != null && param1ImageView.getImageTintList() != null) {
            if (drawable.isStateful())
              drawable.setState(param1ImageView.getDrawableState()); 
            param1ImageView.setImageDrawable(drawable);
            return;
          } 
        } 
      } else if (param1ImageView instanceof jf) {
        ((jf)param1ImageView).setSupportImageTintList((ColorStateList)drawable);
      } 
    }
    
    public static t7 F(y6 param1y6, int param1Int, ArrayList<t7> param1ArrayList, t7 param1t7) {
      t7 t71;
      int i;
      t7 t72;
      if (param1Int == 0) {
        i = param1y6.p0;
      } else {
        i = param1y6.q0;
      } 
      boolean bool = false;
      if (i != -1 && (param1t7 == null || i != param1t7.c)) {
        int j = 0;
        while (true) {
          t72 = param1t7;
          if (j < param1ArrayList.size()) {
            t72 = param1ArrayList.get(j);
            if (t72.c == i) {
              if (param1t7 != null) {
                param1t7.d(param1Int, t72);
                param1ArrayList.remove(param1t7);
              } 
              break;
            } 
            j++;
            continue;
          } 
          break;
        } 
      } else {
        t72 = param1t7;
        if (i != -1)
          return param1t7; 
      } 
      param1t7 = t72;
      if (t72 == null) {
        param1t7 = t72;
        if (param1y6 instanceof c7) {
          c7 c7 = (c7)param1y6;
          i = 0;
          while (true) {
            if (i < c7.s0) {
              y6 y61 = c7.r0[i];
              if (param1Int == 0) {
                int j = y61.p0;
                if (j != -1) {
                  i = j;
                  break;
                } 
              } 
              if (param1Int == 1) {
                int j = y61.q0;
                if (j != -1) {
                  i = j;
                  break;
                } 
              } 
              i++;
              continue;
            } 
            i = -1;
            break;
          } 
          t71 = t72;
          if (i != -1) {
            int j = 0;
            while (true) {
              t71 = t72;
              if (j < param1ArrayList.size()) {
                t71 = param1ArrayList.get(j);
                if (t71.c == i)
                  break; 
                j++;
                continue;
              } 
              break;
            } 
          } 
        } 
        t72 = t71;
        if (t71 == null)
          t72 = new t7(param1Int); 
        param1ArrayList.add(t72);
        t71 = t72;
      } 
      if (t71.a(param1y6)) {
        if (param1y6 instanceof a7) {
          a7 a7 = (a7)param1y6;
          x6 x6 = a7.u0;
          i = bool;
          if (a7.v0 == 0)
            i = 1; 
          x6.b(i, param1ArrayList, t71);
        } 
        if (param1Int == 0) {
          param1y6.p0 = t71.c;
          param1y6.J.b(param1Int, param1ArrayList, t71);
          param1y6.L.b(param1Int, param1ArrayList, t71);
        } else {
          param1y6.q0 = t71.c;
          param1y6.K.b(param1Int, param1ArrayList, t71);
          param1y6.N.b(param1Int, param1ArrayList, t71);
          param1y6.M.b(param1Int, param1ArrayList, t71);
        } 
        param1y6.Q.b(param1Int, param1ArrayList, t71);
      } 
      return t71;
    }
    
    public static void F0(u8 param1u8, View param1View, float[] param1ArrayOffloat) {
      Class<?> clazz = param1View.getClass();
      StringBuilder stringBuilder = s30.x0("set");
      stringBuilder.append(param1u8.b);
      String str = stringBuilder.toString();
      try {
        Method method;
        StringBuilder stringBuilder1;
        ColorDrawable colorDrawable;
        int j;
        int k;
        int m;
        int i = param1u8.c.ordinal();
        boolean bool1 = true;
        switch (i) {
          case 6:
            clazz.getMethod(str, new Class[] { float.class }).invoke(param1View, new Object[] { Float.valueOf(param1ArrayOffloat[0]) });
            return;
          case 5:
            method = clazz.getMethod(str, new Class[] { boolean.class });
            if (param1ArrayOffloat[0] > 0.5F) {
              method.invoke(param1View, new Object[] { Boolean.valueOf(bool1) });
              return;
            } 
            break;
          case 4:
            stringBuilder1 = new StringBuilder();
            stringBuilder1.append("unable to interpolate strings ");
            stringBuilder1.append(((u8)method).b);
            throw new RuntimeException(stringBuilder1.toString());
          case 3:
            method = clazz.getMethod(str, new Class[] { Drawable.class });
            i = p((int)((float)Math.pow(stringBuilder1[0], 0.45454545454545453D) * 255.0F));
            j = p((int)((float)Math.pow(stringBuilder1[1], 0.45454545454545453D) * 255.0F));
            k = p((int)((float)Math.pow(stringBuilder1[2], 0.45454545454545453D) * 255.0F));
            m = p((int)(stringBuilder1[3] * 255.0F));
            colorDrawable = new ColorDrawable();
            colorDrawable.setColor(m << 24 | i << 16 | j << 8 | k);
            method.invoke(param1View, new Object[] { colorDrawable });
            return;
          case 2:
            method = clazz.getMethod(str, new Class[] { int.class });
            i = p((int)((float)Math.pow(colorDrawable[0], 0.45454545454545453D) * 255.0F));
            j = p((int)((float)Math.pow(colorDrawable[1], 0.45454545454545453D) * 255.0F));
            k = p((int)((float)Math.pow(colorDrawable[2], 0.45454545454545453D) * 255.0F));
            method.invoke(param1View, new Object[] { Integer.valueOf(p((int)(colorDrawable[3] * 255.0F)) << 24 | i << 16 | j << 8 | k) });
            return;
          case 1:
            clazz.getMethod(str, new Class[] { float.class }).invoke(param1View, new Object[] { Float.valueOf(colorDrawable[0]) });
            return;
          case 0:
            clazz.getMethod(str, new Class[] { int.class }).invoke(param1View, new Object[] { Integer.valueOf((int)colorDrawable[0]) });
            return;
          default:
            return;
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        R(param1View);
        noSuchMethodException.printStackTrace();
        return;
      } catch (IllegalAccessException illegalAccessException) {
        R(param1View);
        illegalAccessException.printStackTrace();
        return;
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
        return;
      } 
      boolean bool = false;
      invocationTargetException.invoke(param1View, new Object[] { Boolean.valueOf(bool) });
    }
    
    public static t7 G(ArrayList<t7> param1ArrayList, int param1Int) {
      int j = param1ArrayList.size();
      for (int i = 0; i < j; i++) {
        t7 t7 = param1ArrayList.get(i);
        if (param1Int == t7.c)
          return t7; 
      } 
      return null;
    }
    
    public static void G0(TextView param1TextView, int param1Int) {
      int i;
      j(param1Int);
      Paint.FontMetricsInt fontMetricsInt = param1TextView.getPaint().getFontMetricsInt();
      if (param1TextView.getIncludeFontPadding()) {
        i = fontMetricsInt.bottom;
      } else {
        i = fontMetricsInt.descent;
      } 
      if (param1Int > Math.abs(i))
        param1TextView.setPadding(param1TextView.getPaddingLeft(), param1TextView.getPaddingTop(), param1TextView.getPaddingRight(), param1Int - i); 
    }
    
    public static void H(Object param1Object) {
      Class<?> clazz1;
      if (!d) {
        try {
          c = Class.forName("android.content.res.ThemedResourceCache");
        } catch (ClassNotFoundException classNotFoundException) {}
        d = true;
      } 
      Class<?> clazz2 = c;
      if (clazz2 == null)
        return; 
      if (!f) {
        try {
          Field field1 = clazz2.getDeclaredField("mUnthemedEntries");
          e = field1;
          field1.setAccessible(true);
        } catch (NoSuchFieldException noSuchFieldException) {}
        f = true;
      } 
      Field field = e;
      if (field == null)
        return; 
      clazz2 = null;
      try {
        param1Object = field.get(param1Object);
      } catch (IllegalAccessException illegalAccessException) {
        clazz1 = clazz2;
      } 
      if (clazz1 != null)
        clazz1.clear(); 
    }
    
    public static boolean H0(Drawable param1Drawable, int param1Int) {
      if (Build.VERSION.SDK_INT >= 23)
        return param1Drawable.setLayoutDirection(param1Int); 
      if (!j) {
        try {
          Method method1 = Drawable.class.getDeclaredMethod("setLayoutDirection", new Class[] { int.class });
          i = method1;
          method1.setAccessible(true);
        } catch (NoSuchMethodException noSuchMethodException) {}
        j = true;
      } 
      Method method = i;
      if (method != null)
        try {
          method.invoke(param1Drawable, new Object[] { Integer.valueOf(param1Int) });
          return true;
        } catch (Exception exception) {
          i = null;
        }  
      return false;
    }
    
    public static void I(LayoutInflater param1LayoutInflater, LayoutInflater.Factory2 param1Factory2) {
      if (!n) {
        try {
          Field field1 = LayoutInflater.class.getDeclaredField("mFactory2");
          m = field1;
          field1.setAccessible(true);
        } catch (NoSuchFieldException noSuchFieldException) {}
        n = true;
      } 
      Field field = m;
      if (field != null)
        try {
          field.set(param1LayoutInflater, param1Factory2);
          return;
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("forceSetFactory2 could not set the Factory2 on LayoutInflater ");
          stringBuilder.append(param1LayoutInflater);
          stringBuilder.append("; inflation may have unexpected results.");
          stringBuilder.toString();
        }  
    }
    
    public static void I0(TextView param1TextView, int param1Int) {
      j(param1Int);
      int i = param1TextView.getPaint().getFontMetricsInt(null);
      if (param1Int != i)
        param1TextView.setLineSpacing((param1Int - i), 1.0F); 
    }
    
    public static Drawable J(CompoundButton param1CompoundButton) {
      if (Build.VERSION.SDK_INT >= 23)
        return param1CompoundButton.getButtonDrawable(); 
      if (!p) {
        try {
          Field field1 = CompoundButton.class.getDeclaredField("mButtonDrawable");
          o = field1;
          field1.setAccessible(true);
        } catch (NoSuchFieldException noSuchFieldException) {}
        p = true;
      } 
      Field field = o;
      if (field != null)
        try {
          return (Drawable)field.get(param1CompoundButton);
        } catch (IllegalAccessException illegalAccessException) {
          o = null;
        }  
      return null;
    }
    
    public static void J0(PopupWindow param1PopupWindow, boolean param1Boolean) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 23) {
        df.c(param1PopupWindow, param1Boolean);
        return;
      } 
      if (i >= 21) {
        if (!t) {
          try {
            Field field1 = PopupWindow.class.getDeclaredField("mOverlapAnchor");
            s = field1;
            field1.setAccessible(true);
          } catch (NoSuchFieldException noSuchFieldException) {}
          t = true;
        } 
        Field field = s;
        if (field != null)
          try {
            field.set(param1PopupWindow, Boolean.valueOf(param1Boolean));
            return;
          } catch (IllegalAccessException illegalAccessException) {
            return;
          }  
      } 
    }
    
    public static ColorStateList K(CompoundButton param1CompoundButton) {
      return (Build.VERSION.SDK_INT >= 21) ? param1CompoundButton.getButtonTintList() : ((hf)param1CompoundButton).getSupportButtonTintList();
    }
    
    public static void K0(TextView param1TextView, tc param1tc) {
      if (Build.VERSION.SDK_INT >= 29) {
        Objects.requireNonNull(param1tc);
        param1TextView.setText(null);
        return;
      } 
      tc.a a = b0(param1TextView);
      Objects.requireNonNull(param1tc);
      if (a.a(null)) {
        param1TextView.setText((CharSequence)param1tc);
        return;
      } 
      throw new IllegalArgumentException("Given text can not be applied to TextView.");
    }
    
    public static int L(Cursor param1Cursor, String param1String) {
      int i = param1Cursor.getColumnIndex(param1String);
      if (i >= 0)
        return i; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("`");
      stringBuilder.append(param1String);
      stringBuilder.append("`");
      return param1Cursor.getColumnIndexOrThrow(stringBuilder.toString());
    }
    
    public static void L0(TextView param1TextView, int param1Int) {
      if (Build.VERSION.SDK_INT >= 23) {
        param1TextView.setTextAppearance(param1Int);
        return;
      } 
      param1TextView.setTextAppearance(param1TextView.getContext(), param1Int);
    }
    
    public static float M(EdgeEffect param1EdgeEffect) {
      return e0() ? af.b(param1EdgeEffect) : 0.0F;
    }
    
    public static void M0(Drawable param1Drawable, int param1Int) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1Drawable.setTint(param1Int);
        return;
      } 
      if (param1Drawable instanceof mb)
        ((mb)param1Drawable).setTint(param1Int); 
    }
    
    public static Drawable N(Context param1Context, int param1Int) {
      return c4.d().f(param1Context, param1Int);
    }
    
    public static void N0(Drawable param1Drawable, ColorStateList param1ColorStateList) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1Drawable.setTintList(param1ColorStateList);
        return;
      } 
      if (param1Drawable instanceof mb)
        ((mb)param1Drawable).setTintList(param1ColorStateList); 
    }
    
    public static int O(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT >= 23)
        return param1Drawable.getLayoutDirection(); 
      if (!l) {
        try {
          Method method1 = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
          k = method1;
          method1.setAccessible(true);
        } catch (NoSuchMethodException noSuchMethodException) {}
        l = true;
      } 
      Method method = k;
      if (method != null)
        try {
          return ((Integer)method.invoke(param1Drawable, new Object[0])).intValue();
        } catch (Exception exception) {
          k = null;
        }  
      return 0;
    }
    
    public static void O0(Drawable param1Drawable, PorterDuff.Mode param1Mode) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1Drawable.setTintMode(param1Mode);
        return;
      } 
      if (param1Drawable instanceof mb)
        ((mb)param1Drawable).setTintMode(param1Mode); 
    }
    
    public static String P() {
      StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
      StringBuilder stringBuilder = s30.x0(".(");
      stringBuilder.append(stackTraceElement.getFileName());
      stringBuilder.append(":");
      stringBuilder.append(stackTraceElement.getLineNumber());
      stringBuilder.append(") ");
      stringBuilder.append(stackTraceElement.getMethodName());
      stringBuilder.append("()");
      return stringBuilder.toString();
    }
    
    public static void P0(View param1View, CharSequence param1CharSequence) {
      p4 p41;
      if (Build.VERSION.SDK_INT >= 26) {
        param1View.setTooltipText(param1CharSequence);
        return;
      } 
      p4 p42 = p4.b;
      if (p42 != null && p42.d == param1View)
        p4.c(null); 
      if (TextUtils.isEmpty(param1CharSequence)) {
        p41 = p4.c;
        if (p41 != null && p41.d == param1View)
          p41.b(); 
        param1View.setOnLongClickListener(null);
        param1View.setLongClickable(false);
        param1View.setOnHoverListener(null);
        return;
      } 
      new p4(param1View, (CharSequence)p41);
    }
    
    public static String Q(Context param1Context, int param1Int) {
      if (param1Int != -1)
        try {
          return param1Context.getResources().getResourceEntryName(param1Int);
        } catch (Exception exception) {
          return s30.Z("?", param1Int);
        }  
      return "UNKNOWN";
    }
    
    public static void Q0(PopupWindow param1PopupWindow, int param1Int) {
      if (Build.VERSION.SDK_INT >= 23) {
        df.d(param1PopupWindow, param1Int);
        return;
      } 
      if (!r) {
        try {
          Method method1 = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", new Class[] { int.class });
          q = method1;
          method1.setAccessible(true);
        } catch (Exception exception) {}
        r = true;
      } 
      Method method = q;
      if (method != null)
        try {
          method.invoke(param1PopupWindow, new Object[] { Integer.valueOf(param1Int) });
          return;
        } catch (Exception exception) {
          return;
        }  
    }
    
    public static String R(View param1View) {
      try {
        return param1View.getContext().getResources().getResourceEntryName(param1View.getId());
      } catch (Exception exception) {
        return "UNKNOWN";
      } 
    }
    
    public static void R0(XmlPullParser param1XmlPullParser) {
      for (int i = 1; i; i++) {
        int j = param1XmlPullParser.next();
        if (j != 2) {
          if (j != 3)
            continue; 
          i--;
          continue;
        } 
      } 
    }
    
    public static qa S(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, Resources.Theme param1Theme, String param1String, int param1Int1, int param1Int2) {
      if (c0(param1XmlPullParser, param1String)) {
        TypedValue typedValue = new TypedValue();
        param1TypedArray.getValue(param1Int1, typedValue);
        int i = typedValue.type;
        if (i >= 28 && i <= 31)
          return new qa(null, null, typedValue.data); 
        Resources resources = param1TypedArray.getResources();
        param1Int1 = param1TypedArray.getResourceId(param1Int1, 0);
        try {
          qa qa = qa.a(resources, param1Int1, param1Theme);
        } catch (Exception exception) {
          exception = null;
        } 
        if (exception != null)
          return (qa)exception; 
      } 
      return new qa(null, null, param1Int2);
    }
    
    public static List<byte[]> S0(String[] param1ArrayOfString) {
      ArrayList<byte[]> arrayList = new ArrayList();
      int j = param1ArrayOfString.length;
      for (int i = 0; i < j; i++)
        arrayList.add(Base64.decode(param1ArrayOfString[i], 0)); 
      return (List<byte[]>)arrayList;
    }
    
    public static int T(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, String param1String, int param1Int1, int param1Int2) {
      return !c0(param1XmlPullParser, param1String) ? param1Int2 : param1TypedArray.getInt(param1Int1, param1Int2);
    }
    
    public static <T extends Drawable> T T0(Drawable param1Drawable) {
      Drawable drawable = param1Drawable;
      if (param1Drawable instanceof nb)
        drawable = ((nb)param1Drawable).b(); 
      return (T)drawable;
    }
    
    public static int U(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, String param1String, int param1Int1, int param1Int2) {
      return !c0(param1XmlPullParser, param1String) ? param1Int2 : param1TypedArray.getResourceId(param1Int1, param1Int2);
    }
    
    public static ActionMode.Callback U0(ActionMode.Callback param1Callback) {
      ActionMode.Callback callback = param1Callback;
      if (param1Callback instanceof ef) {
        callback = param1Callback;
        if (Build.VERSION.SDK_INT >= 26)
          callback = ((ef)param1Callback).a; 
      } 
      return callback;
    }
    
    public static String V(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, String param1String, int param1Int) {
      return !c0(param1XmlPullParser, param1String) ? null : param1TypedArray.getString(param1Int);
    }
    
    public static boolean V0(y6.a param1a1, y6.a param1a2, y6.a param1a3, y6.a param1a4) {
      // Byte code:
      //   0: getstatic y6$a.FIXED : Ly6$a;
      //   3: astore #6
      //   5: aload_2
      //   6: aload #6
      //   8: if_acmpeq -> 44
      //   11: getstatic y6$a.WRAP_CONTENT : Ly6$a;
      //   14: astore #7
      //   16: aload_2
      //   17: aload #7
      //   19: if_acmpeq -> 44
      //   22: aload_2
      //   23: getstatic y6$a.MATCH_PARENT : Ly6$a;
      //   26: if_acmpne -> 38
      //   29: aload_0
      //   30: aload #7
      //   32: if_acmpeq -> 38
      //   35: goto -> 44
      //   38: iconst_0
      //   39: istore #4
      //   41: goto -> 47
      //   44: iconst_1
      //   45: istore #4
      //   47: aload_3
      //   48: aload #6
      //   50: if_acmpeq -> 83
      //   53: getstatic y6$a.WRAP_CONTENT : Ly6$a;
      //   56: astore_0
      //   57: aload_3
      //   58: aload_0
      //   59: if_acmpeq -> 83
      //   62: aload_3
      //   63: getstatic y6$a.MATCH_PARENT : Ly6$a;
      //   66: if_acmpne -> 77
      //   69: aload_1
      //   70: aload_0
      //   71: if_acmpeq -> 77
      //   74: goto -> 83
      //   77: iconst_0
      //   78: istore #5
      //   80: goto -> 86
      //   83: iconst_1
      //   84: istore #5
      //   86: iload #4
      //   88: ifne -> 100
      //   91: iload #5
      //   93: ifeq -> 98
      //   96: iconst_1
      //   97: ireturn
      //   98: iconst_0
      //   99: ireturn
      //   100: iconst_1
      //   101: ireturn
    }
    
    public static Intent W(Activity param1Activity) {
      Intent intent = param1Activity.getParentActivityIntent();
      if (intent != null)
        return intent; 
      try {
        String str = Y((Context)param1Activity, param1Activity.getComponentName());
        if (str == null)
          return null; 
        ComponentName componentName = new ComponentName((Context)param1Activity, str);
        try {
          return (Y((Context)param1Activity, componentName) == null) ? Intent.makeMainActivity(componentName) : (new Intent()).setComponent(componentName);
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          return null;
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new IllegalArgumentException(nameNotFoundException);
      } 
    }
    
    public static Drawable W0(Drawable param1Drawable) {
      int i = Build.VERSION.SDK_INT;
      return (Drawable)((i >= 23) ? param1Drawable : ((i >= 21) ? (!(param1Drawable instanceof mb) ? new pb(param1Drawable) : param1Drawable) : (!(param1Drawable instanceof mb) ? new ob(param1Drawable) : param1Drawable)));
    }
    
    public static Intent X(Context param1Context, ComponentName param1ComponentName) {
      String str = Y(param1Context, param1ComponentName);
      if (str == null)
        return null; 
      param1ComponentName = new ComponentName(param1ComponentName.getPackageName(), str);
      return (Y(param1Context, param1ComponentName) == null) ? Intent.makeMainActivity(param1ComponentName) : (new Intent()).setComponent(param1ComponentName);
    }
    
    public static ActionMode.Callback X0(TextView param1TextView, ActionMode.Callback param1Callback) {
      int i = Build.VERSION.SDK_INT;
      return (ActionMode.Callback)((i >= 26 && i <= 27 && !(param1Callback instanceof ef)) ? ((param1Callback == null) ? param1Callback : new ef(param1Callback, param1TextView)) : param1Callback);
    }
    
    public static String Y(Context param1Context, ComponentName param1ComponentName) {
      PackageManager packageManager = param1Context.getPackageManager();
      int j = Build.VERSION.SDK_INT;
      int i = 640;
      if (j >= 29) {
        i = 269222528;
      } else if (j >= 24) {
        i = 787072;
      } 
      ActivityInfo activityInfo = packageManager.getActivityInfo(param1ComponentName, i);
      String str2 = activityInfo.parentActivityName;
      if (str2 != null)
        return str2; 
      Bundle bundle = activityInfo.metaData;
      if (bundle == null)
        return null; 
      str2 = bundle.getString("android.support.PARENT_ACTIVITY");
      if (str2 == null)
        return null; 
      String str1 = str2;
      if (str2.charAt(0) == '.') {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Context.getPackageName());
        stringBuilder.append(str2);
        str1 = stringBuilder.toString();
      } 
      return str1;
    }
    
    public static String Z(l8 param1l8, int param1Int) {
      return (param1Int == -1) ? "UNDEFINED" : param1l8.getContext().getResources().getResourceEntryName(param1Int);
    }
    
    public static void a(z6 param1z6, e6 param1e6, ArrayList<y6> param1ArrayList, int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: astore #20
      //   3: iload_3
      //   4: ifne -> 27
      //   7: aload #20
      //   9: getfield A0 : I
      //   12: istore #8
      //   14: aload #20
      //   16: getfield D0 : [Lw6;
      //   19: astore #20
      //   21: iconst_0
      //   22: istore #13
      //   24: goto -> 44
      //   27: aload #20
      //   29: getfield B0 : I
      //   32: istore #8
      //   34: aload #20
      //   36: getfield C0 : [Lw6;
      //   39: astore #20
      //   41: iconst_2
      //   42: istore #13
      //   44: iconst_0
      //   45: istore #7
      //   47: aload_2
      //   48: astore #26
      //   50: aload_0
      //   51: astore #25
      //   53: iload #7
      //   55: iload #8
      //   57: if_icmpge -> 4037
      //   60: aload #20
      //   62: iload #7
      //   64: aaload
      //   65: astore #23
      //   67: aload #23
      //   69: getfield t : Z
      //   72: istore #19
      //   74: aconst_null
      //   75: astore #31
      //   77: iload #19
      //   79: ifne -> 920
      //   82: aload #23
      //   84: getfield o : I
      //   87: iconst_2
      //   88: imul
      //   89: istore #11
      //   91: aload #23
      //   93: getfield a : Ly6;
      //   96: astore #21
      //   98: aload #21
      //   100: astore #22
      //   102: iconst_0
      //   103: istore #9
      //   105: iload #9
      //   107: ifne -> 772
      //   110: aload #23
      //   112: aload #23
      //   114: getfield i : I
      //   117: iconst_1
      //   118: iadd
      //   119: putfield i : I
      //   122: aload #21
      //   124: getfield o0 : [Ly6;
      //   127: astore #24
      //   129: aload #23
      //   131: getfield o : I
      //   134: istore #10
      //   136: aload #24
      //   138: iload #10
      //   140: aconst_null
      //   141: aastore
      //   142: aload #21
      //   144: getfield n0 : [Ly6;
      //   147: iload #10
      //   149: aconst_null
      //   150: aastore
      //   151: aload #21
      //   153: getfield i0 : I
      //   156: bipush #8
      //   158: if_icmpeq -> 658
      //   161: aload #23
      //   163: aload #23
      //   165: getfield l : I
      //   168: iconst_1
      //   169: iadd
      //   170: putfield l : I
      //   173: aload #21
      //   175: iload #10
      //   177: invokevirtual k : (I)Ly6$a;
      //   180: astore #27
      //   182: getstatic y6$a.MATCH_CONSTRAINT : Ly6$a;
      //   185: astore #24
      //   187: aload #27
      //   189: aload #24
      //   191: if_acmpeq -> 252
      //   194: aload #23
      //   196: getfield m : I
      //   199: istore #12
      //   201: aload #23
      //   203: getfield o : I
      //   206: istore #10
      //   208: iload #10
      //   210: ifne -> 223
      //   213: aload #21
      //   215: invokevirtual u : ()I
      //   218: istore #10
      //   220: goto -> 242
      //   223: iload #10
      //   225: iconst_1
      //   226: if_icmpne -> 239
      //   229: aload #21
      //   231: invokevirtual l : ()I
      //   234: istore #10
      //   236: goto -> 242
      //   239: iconst_0
      //   240: istore #10
      //   242: aload #23
      //   244: iload #12
      //   246: iload #10
      //   248: iadd
      //   249: putfield m : I
      //   252: aload #23
      //   254: getfield m : I
      //   257: istore #10
      //   259: aload #21
      //   261: getfield R : [Lx6;
      //   264: iload #11
      //   266: aaload
      //   267: invokevirtual d : ()I
      //   270: iload #10
      //   272: iadd
      //   273: istore #12
      //   275: aload #23
      //   277: iload #12
      //   279: putfield m : I
      //   282: aload #21
      //   284: getfield R : [Lx6;
      //   287: astore #27
      //   289: iload #11
      //   291: iconst_1
      //   292: iadd
      //   293: istore #10
      //   295: aload #23
      //   297: aload #27
      //   299: iload #10
      //   301: aaload
      //   302: invokevirtual d : ()I
      //   305: iload #12
      //   307: iadd
      //   308: putfield m : I
      //   311: aload #23
      //   313: getfield n : I
      //   316: istore #12
      //   318: aload #21
      //   320: getfield R : [Lx6;
      //   323: iload #11
      //   325: aaload
      //   326: invokevirtual d : ()I
      //   329: iload #12
      //   331: iadd
      //   332: istore #12
      //   334: aload #23
      //   336: iload #12
      //   338: putfield n : I
      //   341: aload #23
      //   343: aload #21
      //   345: getfield R : [Lx6;
      //   348: iload #10
      //   350: aaload
      //   351: invokevirtual d : ()I
      //   354: iload #12
      //   356: iadd
      //   357: putfield n : I
      //   360: aload #23
      //   362: getfield b : Ly6;
      //   365: ifnonnull -> 375
      //   368: aload #23
      //   370: aload #21
      //   372: putfield b : Ly6;
      //   375: aload #23
      //   377: aload #21
      //   379: putfield d : Ly6;
      //   382: aload #21
      //   384: getfield U : [Ly6$a;
      //   387: astore #27
      //   389: aload #23
      //   391: getfield o : I
      //   394: istore #10
      //   396: aload #27
      //   398: iload #10
      //   400: aaload
      //   401: aload #24
      //   403: if_acmpne -> 658
      //   406: aload #21
      //   408: getfield t : [I
      //   411: astore #28
      //   413: aload #28
      //   415: iload #10
      //   417: iaload
      //   418: ifeq -> 445
      //   421: aload #28
      //   423: iload #10
      //   425: iaload
      //   426: iconst_3
      //   427: if_icmpeq -> 445
      //   430: aload #28
      //   432: iload #10
      //   434: iaload
      //   435: iconst_2
      //   436: if_icmpne -> 442
      //   439: goto -> 445
      //   442: goto -> 648
      //   445: aload #23
      //   447: aload #23
      //   449: getfield j : I
      //   452: iconst_1
      //   453: iadd
      //   454: putfield j : I
      //   457: aload #21
      //   459: getfield m0 : [F
      //   462: astore #29
      //   464: aload #29
      //   466: iload #10
      //   468: faload
      //   469: fstore #4
      //   471: fload #4
      //   473: fconst_0
      //   474: fcmpl
      //   475: ifle -> 497
      //   478: aload #23
      //   480: aload #23
      //   482: getfield k : F
      //   485: aload #29
      //   487: iload #10
      //   489: faload
      //   490: fadd
      //   491: putfield k : F
      //   494: goto -> 497
      //   497: aload #21
      //   499: getfield i0 : I
      //   502: bipush #8
      //   504: if_icmpeq -> 540
      //   507: aload #27
      //   509: iload #10
      //   511: aaload
      //   512: aload #24
      //   514: if_acmpne -> 540
      //   517: aload #28
      //   519: iload #10
      //   521: iaload
      //   522: ifeq -> 534
      //   525: aload #28
      //   527: iload #10
      //   529: iaload
      //   530: iconst_3
      //   531: if_icmpne -> 540
      //   534: iconst_1
      //   535: istore #10
      //   537: goto -> 543
      //   540: iconst_0
      //   541: istore #10
      //   543: iload #10
      //   545: ifeq -> 601
      //   548: fload #4
      //   550: fconst_0
      //   551: fcmpg
      //   552: ifge -> 564
      //   555: aload #23
      //   557: iconst_1
      //   558: putfield q : Z
      //   561: goto -> 570
      //   564: aload #23
      //   566: iconst_1
      //   567: putfield r : Z
      //   570: aload #23
      //   572: getfield h : Ljava/util/ArrayList;
      //   575: ifnonnull -> 590
      //   578: aload #23
      //   580: new java/util/ArrayList
      //   583: dup
      //   584: invokespecial <init> : ()V
      //   587: putfield h : Ljava/util/ArrayList;
      //   590: aload #23
      //   592: getfield h : Ljava/util/ArrayList;
      //   595: aload #21
      //   597: invokevirtual add : (Ljava/lang/Object;)Z
      //   600: pop
      //   601: aload #23
      //   603: getfield f : Ly6;
      //   606: ifnonnull -> 616
      //   609: aload #23
      //   611: aload #21
      //   613: putfield f : Ly6;
      //   616: aload #23
      //   618: getfield g : Ly6;
      //   621: astore #24
      //   623: aload #24
      //   625: ifnull -> 641
      //   628: aload #24
      //   630: getfield n0 : [Ly6;
      //   633: aload #23
      //   635: getfield o : I
      //   638: aload #21
      //   640: aastore
      //   641: aload #23
      //   643: aload #21
      //   645: putfield g : Ly6;
      //   648: aload #23
      //   650: getfield o : I
      //   653: istore #10
      //   655: goto -> 658
      //   658: aload #22
      //   660: aload #21
      //   662: if_acmpeq -> 678
      //   665: aload #22
      //   667: getfield o0 : [Ly6;
      //   670: aload #23
      //   672: getfield o : I
      //   675: aload #21
      //   677: aastore
      //   678: aload #21
      //   680: getfield R : [Lx6;
      //   683: iload #11
      //   685: iconst_1
      //   686: iadd
      //   687: aaload
      //   688: getfield f : Lx6;
      //   691: astore #22
      //   693: aload #22
      //   695: ifnull -> 739
      //   698: aload #22
      //   700: getfield d : Ly6;
      //   703: astore #22
      //   705: aload #22
      //   707: getfield R : [Lx6;
      //   710: astore #24
      //   712: aload #24
      //   714: iload #11
      //   716: aaload
      //   717: getfield f : Lx6;
      //   720: ifnull -> 739
      //   723: aload #24
      //   725: iload #11
      //   727: aaload
      //   728: getfield f : Lx6;
      //   731: getfield d : Ly6;
      //   734: aload #21
      //   736: if_acmpeq -> 742
      //   739: aconst_null
      //   740: astore #22
      //   742: aload #22
      //   744: ifnull -> 750
      //   747: goto -> 757
      //   750: aload #21
      //   752: astore #22
      //   754: iconst_1
      //   755: istore #9
      //   757: aload #21
      //   759: astore #24
      //   761: aload #22
      //   763: astore #21
      //   765: aload #24
      //   767: astore #22
      //   769: goto -> 105
      //   772: aload #23
      //   774: getfield b : Ly6;
      //   777: astore #22
      //   779: aload #22
      //   781: ifnull -> 806
      //   784: aload #23
      //   786: aload #23
      //   788: getfield m : I
      //   791: aload #22
      //   793: getfield R : [Lx6;
      //   796: iload #11
      //   798: aaload
      //   799: invokevirtual d : ()I
      //   802: isub
      //   803: putfield m : I
      //   806: aload #23
      //   808: getfield d : Ly6;
      //   811: astore #22
      //   813: aload #22
      //   815: ifnull -> 842
      //   818: aload #23
      //   820: aload #23
      //   822: getfield m : I
      //   825: aload #22
      //   827: getfield R : [Lx6;
      //   830: iload #11
      //   832: iconst_1
      //   833: iadd
      //   834: aaload
      //   835: invokevirtual d : ()I
      //   838: isub
      //   839: putfield m : I
      //   842: aload #23
      //   844: aload #21
      //   846: putfield c : Ly6;
      //   849: aload #23
      //   851: getfield o : I
      //   854: ifne -> 875
      //   857: aload #23
      //   859: getfield p : Z
      //   862: ifeq -> 875
      //   865: aload #23
      //   867: aload #21
      //   869: putfield e : Ly6;
      //   872: goto -> 885
      //   875: aload #23
      //   877: aload #23
      //   879: getfield a : Ly6;
      //   882: putfield e : Ly6;
      //   885: aload #23
      //   887: getfield r : Z
      //   890: ifeq -> 907
      //   893: aload #23
      //   895: getfield q : Z
      //   898: ifeq -> 907
      //   901: iconst_1
      //   902: istore #19
      //   904: goto -> 910
      //   907: iconst_0
      //   908: istore #19
      //   910: aload #23
      //   912: iload #19
      //   914: putfield s : Z
      //   917: goto -> 920
      //   920: aload #23
      //   922: iconst_1
      //   923: putfield t : Z
      //   926: aload #26
      //   928: ifnull -> 954
      //   931: aload #26
      //   933: aload #23
      //   935: getfield a : Ly6;
      //   938: invokevirtual contains : (Ljava/lang/Object;)Z
      //   941: ifeq -> 947
      //   944: goto -> 954
      //   947: iload #7
      //   949: istore #10
      //   951: goto -> 4028
      //   954: aload #23
      //   956: getfield a : Ly6;
      //   959: astore #30
      //   961: aload #23
      //   963: getfield c : Ly6;
      //   966: astore #34
      //   968: aload #23
      //   970: getfield b : Ly6;
      //   973: astore #28
      //   975: aload #23
      //   977: getfield d : Ly6;
      //   980: astore #29
      //   982: aload #23
      //   984: getfield e : Ly6;
      //   987: astore #22
      //   989: aload #23
      //   991: getfield k : F
      //   994: fstore #5
      //   996: aload #25
      //   998: getfield U : [Ly6$a;
      //   1001: iload_3
      //   1002: aaload
      //   1003: getstatic y6$a.WRAP_CONTENT : Ly6$a;
      //   1006: if_acmpne -> 1015
      //   1009: iconst_1
      //   1010: istore #15
      //   1012: goto -> 1018
      //   1015: iconst_0
      //   1016: istore #15
      //   1018: iload_3
      //   1019: ifne -> 1079
      //   1022: aload #22
      //   1024: getfield k0 : I
      //   1027: istore #14
      //   1029: iload #14
      //   1031: ifne -> 1040
      //   1034: iconst_1
      //   1035: istore #10
      //   1037: goto -> 1043
      //   1040: iconst_0
      //   1041: istore #10
      //   1043: iload #14
      //   1045: iconst_1
      //   1046: if_icmpne -> 1055
      //   1049: iconst_1
      //   1050: istore #9
      //   1052: goto -> 1058
      //   1055: iconst_0
      //   1056: istore #9
      //   1058: iload #9
      //   1060: istore #11
      //   1062: iload #10
      //   1064: istore #12
      //   1066: iload #14
      //   1068: iconst_2
      //   1069: if_icmpne -> 1151
      //   1072: iload #10
      //   1074: istore #11
      //   1076: goto -> 1137
      //   1079: aload #22
      //   1081: getfield l0 : I
      //   1084: istore #14
      //   1086: iload #14
      //   1088: ifne -> 1097
      //   1091: iconst_1
      //   1092: istore #9
      //   1094: goto -> 1100
      //   1097: iconst_0
      //   1098: istore #9
      //   1100: iload #14
      //   1102: iconst_1
      //   1103: if_icmpne -> 1112
      //   1106: iconst_1
      //   1107: istore #10
      //   1109: goto -> 1115
      //   1112: iconst_0
      //   1113: istore #10
      //   1115: iload #10
      //   1117: istore #11
      //   1119: iload #9
      //   1121: istore #12
      //   1123: iload #14
      //   1125: iconst_2
      //   1126: if_icmpne -> 1151
      //   1129: iload #9
      //   1131: istore #11
      //   1133: iload #10
      //   1135: istore #9
      //   1137: iconst_1
      //   1138: istore #16
      //   1140: iload #11
      //   1142: istore #14
      //   1144: iload #9
      //   1146: istore #12
      //   1148: goto -> 1165
      //   1151: iload #12
      //   1153: istore #14
      //   1155: iconst_0
      //   1156: istore #16
      //   1158: iload #11
      //   1160: istore #12
      //   1162: goto -> 1148
      //   1165: aload #30
      //   1167: astore #24
      //   1169: iconst_0
      //   1170: istore #9
      //   1172: iload #9
      //   1174: ifne -> 1615
      //   1177: aload #24
      //   1179: getfield R : [Lx6;
      //   1182: iload #13
      //   1184: aaload
      //   1185: astore #21
      //   1187: iload #16
      //   1189: ifeq -> 1198
      //   1192: iconst_1
      //   1193: istore #10
      //   1195: goto -> 1201
      //   1198: iconst_4
      //   1199: istore #10
      //   1201: aload #21
      //   1203: invokevirtual d : ()I
      //   1206: istore #11
      //   1208: aload #24
      //   1210: getfield U : [Ly6$a;
      //   1213: iload_3
      //   1214: aaload
      //   1215: astore #27
      //   1217: getstatic y6$a.MATCH_CONSTRAINT : Ly6$a;
      //   1220: astore #26
      //   1222: aload #27
      //   1224: aload #26
      //   1226: if_acmpne -> 1245
      //   1229: aload #24
      //   1231: getfield t : [I
      //   1234: iload_3
      //   1235: iaload
      //   1236: ifne -> 1245
      //   1239: iconst_1
      //   1240: istore #18
      //   1242: goto -> 1248
      //   1245: iconst_0
      //   1246: istore #18
      //   1248: aload #21
      //   1250: getfield f : Lx6;
      //   1253: astore #27
      //   1255: iload #11
      //   1257: istore #17
      //   1259: aload #27
      //   1261: ifnull -> 1285
      //   1264: iload #11
      //   1266: istore #17
      //   1268: aload #24
      //   1270: aload #30
      //   1272: if_acmpeq -> 1285
      //   1275: aload #27
      //   1277: invokevirtual d : ()I
      //   1280: iload #11
      //   1282: iadd
      //   1283: istore #17
      //   1285: iload #16
      //   1287: ifeq -> 1311
      //   1290: aload #24
      //   1292: aload #30
      //   1294: if_acmpeq -> 1311
      //   1297: aload #24
      //   1299: aload #28
      //   1301: if_acmpeq -> 1311
      //   1304: bipush #8
      //   1306: istore #10
      //   1308: goto -> 1311
      //   1311: aload #21
      //   1313: getfield f : Lx6;
      //   1316: astore #27
      //   1318: aload #27
      //   1320: ifnull -> 1443
      //   1323: aload #24
      //   1325: aload #28
      //   1327: if_acmpne -> 1351
      //   1330: aload_1
      //   1331: aload #21
      //   1333: getfield i : Li6;
      //   1336: aload #27
      //   1338: getfield i : Li6;
      //   1341: iload #17
      //   1343: bipush #6
      //   1345: invokevirtual f : (Li6;Li6;II)V
      //   1348: goto -> 1369
      //   1351: aload_1
      //   1352: aload #21
      //   1354: getfield i : Li6;
      //   1357: aload #27
      //   1359: getfield i : Li6;
      //   1362: iload #17
      //   1364: bipush #8
      //   1366: invokevirtual f : (Li6;Li6;II)V
      //   1369: iload #10
      //   1371: istore #11
      //   1373: iload #18
      //   1375: ifeq -> 1390
      //   1378: iload #10
      //   1380: istore #11
      //   1382: iload #16
      //   1384: ifne -> 1390
      //   1387: iconst_5
      //   1388: istore #11
      //   1390: aload #24
      //   1392: aload #28
      //   1394: if_acmpne -> 1418
      //   1397: iload #16
      //   1399: ifeq -> 1418
      //   1402: aload #24
      //   1404: getfield T : [Z
      //   1407: iload_3
      //   1408: baload
      //   1409: ifeq -> 1418
      //   1412: iconst_5
      //   1413: istore #11
      //   1415: goto -> 1418
      //   1418: aload_1
      //   1419: aload #21
      //   1421: getfield i : Li6;
      //   1424: aload #21
      //   1426: getfield f : Lx6;
      //   1429: getfield i : Li6;
      //   1432: iload #17
      //   1434: iload #11
      //   1436: invokevirtual d : (Li6;Li6;II)Lc6;
      //   1439: pop
      //   1440: goto -> 1443
      //   1443: iload #15
      //   1445: ifeq -> 1533
      //   1448: aload #24
      //   1450: getfield i0 : I
      //   1453: bipush #8
      //   1455: if_icmpeq -> 1504
      //   1458: aload #24
      //   1460: getfield U : [Ly6$a;
      //   1463: iload_3
      //   1464: aaload
      //   1465: aload #26
      //   1467: if_acmpne -> 1504
      //   1470: aload #24
      //   1472: getfield R : [Lx6;
      //   1475: astore #21
      //   1477: aload_1
      //   1478: aload #21
      //   1480: iload #13
      //   1482: iconst_1
      //   1483: iadd
      //   1484: aaload
      //   1485: getfield i : Li6;
      //   1488: aload #21
      //   1490: iload #13
      //   1492: aaload
      //   1493: getfield i : Li6;
      //   1496: iconst_0
      //   1497: iconst_5
      //   1498: invokevirtual f : (Li6;Li6;II)V
      //   1501: goto -> 1504
      //   1504: aload_1
      //   1505: aload #24
      //   1507: getfield R : [Lx6;
      //   1510: iload #13
      //   1512: aaload
      //   1513: getfield i : Li6;
      //   1516: aload #25
      //   1518: getfield R : [Lx6;
      //   1521: iload #13
      //   1523: aaload
      //   1524: getfield i : Li6;
      //   1527: iconst_0
      //   1528: bipush #8
      //   1530: invokevirtual f : (Li6;Li6;II)V
      //   1533: aload #24
      //   1535: getfield R : [Lx6;
      //   1538: iload #13
      //   1540: iconst_1
      //   1541: iadd
      //   1542: aaload
      //   1543: getfield f : Lx6;
      //   1546: astore #21
      //   1548: aload #21
      //   1550: ifnull -> 1594
      //   1553: aload #21
      //   1555: getfield d : Ly6;
      //   1558: astore #21
      //   1560: aload #21
      //   1562: getfield R : [Lx6;
      //   1565: astore #26
      //   1567: aload #26
      //   1569: iload #13
      //   1571: aaload
      //   1572: getfield f : Lx6;
      //   1575: ifnull -> 1594
      //   1578: aload #26
      //   1580: iload #13
      //   1582: aaload
      //   1583: getfield f : Lx6;
      //   1586: getfield d : Ly6;
      //   1589: aload #24
      //   1591: if_acmpeq -> 1597
      //   1594: aconst_null
      //   1595: astore #21
      //   1597: aload #21
      //   1599: ifnull -> 1609
      //   1602: aload #21
      //   1604: astore #24
      //   1606: goto -> 1612
      //   1609: iconst_1
      //   1610: istore #9
      //   1612: goto -> 1172
      //   1615: iload #8
      //   1617: istore #9
      //   1619: aload #20
      //   1621: astore #27
      //   1623: aload #29
      //   1625: ifnull -> 1824
      //   1628: aload #34
      //   1630: getfield R : [Lx6;
      //   1633: astore #20
      //   1635: iload #13
      //   1637: iconst_1
      //   1638: iadd
      //   1639: istore #10
      //   1641: aload #20
      //   1643: iload #10
      //   1645: aaload
      //   1646: getfield f : Lx6;
      //   1649: ifnull -> 1824
      //   1652: aload #29
      //   1654: getfield R : [Lx6;
      //   1657: iload #10
      //   1659: aaload
      //   1660: astore #20
      //   1662: aload #29
      //   1664: getfield U : [Ly6$a;
      //   1667: iload_3
      //   1668: aaload
      //   1669: getstatic y6$a.MATCH_CONSTRAINT : Ly6$a;
      //   1672: if_acmpne -> 1691
      //   1675: aload #29
      //   1677: getfield t : [I
      //   1680: iload_3
      //   1681: iaload
      //   1682: ifne -> 1691
      //   1685: iconst_1
      //   1686: istore #8
      //   1688: goto -> 1694
      //   1691: iconst_0
      //   1692: istore #8
      //   1694: iload #8
      //   1696: ifeq -> 1746
      //   1699: iload #16
      //   1701: ifne -> 1746
      //   1704: aload #20
      //   1706: getfield f : Lx6;
      //   1709: astore #21
      //   1711: aload #21
      //   1713: getfield d : Ly6;
      //   1716: aload #25
      //   1718: if_acmpne -> 1746
      //   1721: aload_1
      //   1722: aload #20
      //   1724: getfield i : Li6;
      //   1727: aload #21
      //   1729: getfield i : Li6;
      //   1732: aload #20
      //   1734: invokevirtual d : ()I
      //   1737: ineg
      //   1738: iconst_5
      //   1739: invokevirtual d : (Li6;Li6;II)Lc6;
      //   1742: pop
      //   1743: goto -> 1790
      //   1746: iload #16
      //   1748: ifeq -> 1790
      //   1751: aload #20
      //   1753: getfield f : Lx6;
      //   1756: astore #21
      //   1758: aload #21
      //   1760: getfield d : Ly6;
      //   1763: aload #25
      //   1765: if_acmpne -> 1790
      //   1768: aload_1
      //   1769: aload #20
      //   1771: getfield i : Li6;
      //   1774: aload #21
      //   1776: getfield i : Li6;
      //   1779: aload #20
      //   1781: invokevirtual d : ()I
      //   1784: ineg
      //   1785: iconst_4
      //   1786: invokevirtual d : (Li6;Li6;II)Lc6;
      //   1789: pop
      //   1790: aload_1
      //   1791: aload #20
      //   1793: getfield i : Li6;
      //   1796: aload #34
      //   1798: getfield R : [Lx6;
      //   1801: iload #10
      //   1803: aaload
      //   1804: getfield f : Lx6;
      //   1807: getfield i : Li6;
      //   1810: aload #20
      //   1812: invokevirtual d : ()I
      //   1815: ineg
      //   1816: bipush #6
      //   1818: invokevirtual g : (Li6;Li6;II)V
      //   1821: goto -> 1824
      //   1824: iload #15
      //   1826: ifeq -> 1883
      //   1829: aload #25
      //   1831: getfield R : [Lx6;
      //   1834: astore #20
      //   1836: iload #13
      //   1838: iconst_1
      //   1839: iadd
      //   1840: istore #8
      //   1842: aload #20
      //   1844: iload #8
      //   1846: aaload
      //   1847: getfield i : Li6;
      //   1850: astore #20
      //   1852: aload #34
      //   1854: getfield R : [Lx6;
      //   1857: astore #21
      //   1859: aload_1
      //   1860: aload #20
      //   1862: aload #21
      //   1864: iload #8
      //   1866: aaload
      //   1867: getfield i : Li6;
      //   1870: aload #21
      //   1872: iload #8
      //   1874: aaload
      //   1875: invokevirtual d : ()I
      //   1878: bipush #8
      //   1880: invokevirtual f : (Li6;Li6;II)V
      //   1883: aload #23
      //   1885: getfield h : Ljava/util/ArrayList;
      //   1888: astore #21
      //   1890: aload #23
      //   1892: astore #25
      //   1894: aload #21
      //   1896: ifnull -> 2417
      //   1899: aload #21
      //   1901: invokevirtual size : ()I
      //   1904: istore #8
      //   1906: aload #23
      //   1908: astore #25
      //   1910: iload #8
      //   1912: iconst_1
      //   1913: if_icmple -> 2417
      //   1916: aload #23
      //   1918: getfield q : Z
      //   1921: ifeq -> 1943
      //   1924: aload #23
      //   1926: getfield s : Z
      //   1929: ifne -> 1943
      //   1932: aload #23
      //   1934: getfield j : I
      //   1937: i2f
      //   1938: fstore #5
      //   1940: goto -> 1943
      //   1943: aconst_null
      //   1944: astore #24
      //   1946: fconst_0
      //   1947: fstore #6
      //   1949: iconst_0
      //   1950: istore #10
      //   1952: aload #23
      //   1954: astore #20
      //   1956: aload #20
      //   1958: astore #25
      //   1960: iload #10
      //   1962: iload #8
      //   1964: if_icmpge -> 2417
      //   1967: aload #21
      //   1969: iload #10
      //   1971: invokevirtual get : (I)Ljava/lang/Object;
      //   1974: checkcast y6
      //   1977: astore #23
      //   1979: aload #23
      //   1981: getfield m0 : [F
      //   1984: iload_3
      //   1985: faload
      //   1986: fstore #4
      //   1988: fload #4
      //   1990: fconst_0
      //   1991: fcmpg
      //   1992: ifge -> 2044
      //   1995: aload #20
      //   1997: getfield s : Z
      //   2000: ifeq -> 2038
      //   2003: aload #23
      //   2005: getfield R : [Lx6;
      //   2008: astore #23
      //   2010: aload_1
      //   2011: aload #23
      //   2013: iload #13
      //   2015: iconst_1
      //   2016: iadd
      //   2017: aaload
      //   2018: getfield i : Li6;
      //   2021: aload #23
      //   2023: iload #13
      //   2025: aaload
      //   2026: getfield i : Li6;
      //   2029: iconst_0
      //   2030: iconst_4
      //   2031: invokevirtual d : (Li6;Li6;II)Lc6;
      //   2034: pop
      //   2035: goto -> 2084
      //   2038: fconst_1
      //   2039: fstore #4
      //   2041: goto -> 2044
      //   2044: fload #4
      //   2046: fconst_0
      //   2047: fcmpl
      //   2048: ifne -> 2091
      //   2051: aload #23
      //   2053: getfield R : [Lx6;
      //   2056: astore #23
      //   2058: aload_1
      //   2059: aload #23
      //   2061: iload #13
      //   2063: iconst_1
      //   2064: iadd
      //   2065: aaload
      //   2066: getfield i : Li6;
      //   2069: aload #23
      //   2071: iload #13
      //   2073: aaload
      //   2074: getfield i : Li6;
      //   2077: iconst_0
      //   2078: bipush #8
      //   2080: invokevirtual d : (Li6;Li6;II)Lc6;
      //   2083: pop
      //   2084: fload #6
      //   2086: fstore #4
      //   2088: goto -> 2404
      //   2091: aload #24
      //   2093: ifnull -> 2400
      //   2096: aload #24
      //   2098: getfield R : [Lx6;
      //   2101: astore #25
      //   2103: aload #25
      //   2105: iload #13
      //   2107: aaload
      //   2108: getfield i : Li6;
      //   2111: astore #24
      //   2113: iload #13
      //   2115: iconst_1
      //   2116: iadd
      //   2117: istore #11
      //   2119: aload #25
      //   2121: iload #11
      //   2123: aaload
      //   2124: getfield i : Li6;
      //   2127: astore #25
      //   2129: aload #23
      //   2131: getfield R : [Lx6;
      //   2134: astore #32
      //   2136: aload #32
      //   2138: iload #13
      //   2140: aaload
      //   2141: getfield i : Li6;
      //   2144: astore #26
      //   2146: aload #32
      //   2148: iload #11
      //   2150: aaload
      //   2151: getfield i : Li6;
      //   2154: astore #32
      //   2156: aload_1
      //   2157: invokevirtual m : ()Lc6;
      //   2160: astore #33
      //   2162: aload #33
      //   2164: fconst_0
      //   2165: putfield b : F
      //   2168: fload #5
      //   2170: fconst_0
      //   2171: fcmpl
      //   2172: ifeq -> 2335
      //   2175: fload #6
      //   2177: fload #4
      //   2179: fcmpl
      //   2180: ifne -> 2186
      //   2183: goto -> 2335
      //   2186: fload #6
      //   2188: fconst_0
      //   2189: fcmpl
      //   2190: ifne -> 2224
      //   2193: aload #33
      //   2195: getfield d : Lc6$a;
      //   2198: aload #24
      //   2200: fconst_1
      //   2201: invokeinterface d : (Li6;F)V
      //   2206: aload #33
      //   2208: getfield d : Lc6$a;
      //   2211: aload #25
      //   2213: ldc_w -1.0
      //   2216: invokeinterface d : (Li6;F)V
      //   2221: goto -> 2391
      //   2224: fload #4
      //   2226: fconst_0
      //   2227: fcmpl
      //   2228: ifne -> 2262
      //   2231: aload #33
      //   2233: getfield d : Lc6$a;
      //   2236: aload #26
      //   2238: fconst_1
      //   2239: invokeinterface d : (Li6;F)V
      //   2244: aload #33
      //   2246: getfield d : Lc6$a;
      //   2249: aload #32
      //   2251: ldc_w -1.0
      //   2254: invokeinterface d : (Li6;F)V
      //   2259: goto -> 2391
      //   2262: fload #6
      //   2264: fload #5
      //   2266: fdiv
      //   2267: fload #4
      //   2269: fload #5
      //   2271: fdiv
      //   2272: fdiv
      //   2273: fstore #6
      //   2275: aload #33
      //   2277: getfield d : Lc6$a;
      //   2280: aload #24
      //   2282: fconst_1
      //   2283: invokeinterface d : (Li6;F)V
      //   2288: aload #33
      //   2290: getfield d : Lc6$a;
      //   2293: aload #25
      //   2295: ldc_w -1.0
      //   2298: invokeinterface d : (Li6;F)V
      //   2303: aload #33
      //   2305: getfield d : Lc6$a;
      //   2308: aload #32
      //   2310: fload #6
      //   2312: invokeinterface d : (Li6;F)V
      //   2317: aload #33
      //   2319: getfield d : Lc6$a;
      //   2322: aload #26
      //   2324: fload #6
      //   2326: fneg
      //   2327: invokeinterface d : (Li6;F)V
      //   2332: goto -> 2391
      //   2335: aload #33
      //   2337: getfield d : Lc6$a;
      //   2340: aload #24
      //   2342: fconst_1
      //   2343: invokeinterface d : (Li6;F)V
      //   2348: aload #33
      //   2350: getfield d : Lc6$a;
      //   2353: aload #25
      //   2355: ldc_w -1.0
      //   2358: invokeinterface d : (Li6;F)V
      //   2363: aload #33
      //   2365: getfield d : Lc6$a;
      //   2368: aload #32
      //   2370: fconst_1
      //   2371: invokeinterface d : (Li6;F)V
      //   2376: aload #33
      //   2378: getfield d : Lc6$a;
      //   2381: aload #26
      //   2383: ldc_w -1.0
      //   2386: invokeinterface d : (Li6;F)V
      //   2391: aload_1
      //   2392: aload #33
      //   2394: invokevirtual c : (Lc6;)V
      //   2397: goto -> 2400
      //   2400: aload #23
      //   2402: astore #24
      //   2404: iload #10
      //   2406: iconst_1
      //   2407: iadd
      //   2408: istore #10
      //   2410: fload #4
      //   2412: fstore #6
      //   2414: goto -> 1956
      //   2417: aload #28
      //   2419: ifnull -> 2624
      //   2422: aload #28
      //   2424: aload #29
      //   2426: if_acmpeq -> 2434
      //   2429: iload #16
      //   2431: ifeq -> 2624
      //   2434: aload #30
      //   2436: getfield R : [Lx6;
      //   2439: iload #13
      //   2441: aaload
      //   2442: astore #20
      //   2444: aload #34
      //   2446: getfield R : [Lx6;
      //   2449: astore #21
      //   2451: iload #13
      //   2453: iconst_1
      //   2454: iadd
      //   2455: istore #8
      //   2457: aload #21
      //   2459: iload #8
      //   2461: aaload
      //   2462: astore #23
      //   2464: aload #20
      //   2466: getfield f : Lx6;
      //   2469: astore #20
      //   2471: aload #20
      //   2473: ifnull -> 2486
      //   2476: aload #20
      //   2478: getfield i : Li6;
      //   2481: astore #20
      //   2483: goto -> 2489
      //   2486: aconst_null
      //   2487: astore #20
      //   2489: aload #23
      //   2491: getfield f : Lx6;
      //   2494: astore #21
      //   2496: aload #21
      //   2498: ifnull -> 2511
      //   2501: aload #21
      //   2503: getfield i : Li6;
      //   2506: astore #21
      //   2508: goto -> 2514
      //   2511: aconst_null
      //   2512: astore #21
      //   2514: aload #28
      //   2516: getfield R : [Lx6;
      //   2519: iload #13
      //   2521: aaload
      //   2522: astore #24
      //   2524: aload #29
      //   2526: ifnull -> 2539
      //   2529: aload #29
      //   2531: getfield R : [Lx6;
      //   2534: iload #8
      //   2536: aaload
      //   2537: astore #23
      //   2539: aload #20
      //   2541: ifnull -> 2621
      //   2544: aload #21
      //   2546: ifnull -> 2621
      //   2549: iload_3
      //   2550: ifne -> 2563
      //   2553: aload #22
      //   2555: getfield f0 : F
      //   2558: fstore #4
      //   2560: goto -> 2570
      //   2563: aload #22
      //   2565: getfield g0 : F
      //   2568: fstore #4
      //   2570: aload #24
      //   2572: invokevirtual d : ()I
      //   2575: istore #8
      //   2577: aload #23
      //   2579: invokevirtual d : ()I
      //   2582: istore #10
      //   2584: aload #24
      //   2586: getfield i : Li6;
      //   2589: astore #22
      //   2591: aload #23
      //   2593: getfield i : Li6;
      //   2596: astore #23
      //   2598: aload_1
      //   2599: aload #22
      //   2601: aload #20
      //   2603: iload #8
      //   2605: fload #4
      //   2607: aload #21
      //   2609: aload #23
      //   2611: iload #10
      //   2613: bipush #7
      //   2615: invokevirtual b : (Li6;Li6;IFLi6;Li6;II)V
      //   2618: goto -> 2621
      //   2621: goto -> 3710
      //   2624: aload #29
      //   2626: astore #32
      //   2628: aload #28
      //   2630: astore #22
      //   2632: iload #14
      //   2634: ifeq -> 3119
      //   2637: aload #22
      //   2639: ifnull -> 3119
      //   2642: aload #25
      //   2644: getfield j : I
      //   2647: istore #8
      //   2649: iload #8
      //   2651: ifle -> 2670
      //   2654: aload #25
      //   2656: getfield i : I
      //   2659: iload #8
      //   2661: if_icmpne -> 2670
      //   2664: iconst_1
      //   2665: istore #10
      //   2667: goto -> 2673
      //   2670: iconst_0
      //   2671: istore #10
      //   2673: aload #22
      //   2675: astore #23
      //   2677: aload #23
      //   2679: astore #24
      //   2681: iload #7
      //   2683: istore #8
      //   2685: iload #8
      //   2687: istore #7
      //   2689: aload #24
      //   2691: ifnull -> 2621
      //   2694: aload #24
      //   2696: getfield o0 : [Ly6;
      //   2699: iload_3
      //   2700: aaload
      //   2701: astore #20
      //   2703: aload #20
      //   2705: ifnull -> 2730
      //   2708: aload #20
      //   2710: getfield i0 : I
      //   2713: bipush #8
      //   2715: if_icmpne -> 2730
      //   2718: aload #20
      //   2720: getfield o0 : [Ly6;
      //   2723: iload_3
      //   2724: aaload
      //   2725: astore #20
      //   2727: goto -> 2703
      //   2730: aload #20
      //   2732: ifnonnull -> 2748
      //   2735: aload #24
      //   2737: aload #32
      //   2739: if_acmpne -> 2745
      //   2742: goto -> 2748
      //   2745: goto -> 3095
      //   2748: aload #24
      //   2750: getfield R : [Lx6;
      //   2753: iload #13
      //   2755: aaload
      //   2756: astore #25
      //   2758: aload #25
      //   2760: getfield i : Li6;
      //   2763: astore #33
      //   2765: aload #25
      //   2767: getfield f : Lx6;
      //   2770: astore #21
      //   2772: aload #21
      //   2774: ifnull -> 2787
      //   2777: aload #21
      //   2779: getfield i : Li6;
      //   2782: astore #21
      //   2784: goto -> 2790
      //   2787: aconst_null
      //   2788: astore #21
      //   2790: aload #23
      //   2792: aload #24
      //   2794: if_acmpeq -> 2815
      //   2797: aload #23
      //   2799: getfield R : [Lx6;
      //   2802: iload #13
      //   2804: iconst_1
      //   2805: iadd
      //   2806: aaload
      //   2807: getfield i : Li6;
      //   2810: astore #21
      //   2812: goto -> 2859
      //   2815: aload #24
      //   2817: aload #22
      //   2819: if_acmpne -> 2859
      //   2822: aload #30
      //   2824: getfield R : [Lx6;
      //   2827: astore #21
      //   2829: aload #21
      //   2831: iload #13
      //   2833: aaload
      //   2834: getfield f : Lx6;
      //   2837: ifnull -> 2856
      //   2840: aload #21
      //   2842: iload #13
      //   2844: aaload
      //   2845: getfield f : Lx6;
      //   2848: getfield i : Li6;
      //   2851: astore #21
      //   2853: goto -> 2859
      //   2856: aconst_null
      //   2857: astore #21
      //   2859: aload #25
      //   2861: invokevirtual d : ()I
      //   2864: istore #16
      //   2866: aload #24
      //   2868: getfield R : [Lx6;
      //   2871: astore #25
      //   2873: iload #13
      //   2875: iconst_1
      //   2876: iadd
      //   2877: istore #15
      //   2879: aload #25
      //   2881: iload #15
      //   2883: aaload
      //   2884: invokevirtual d : ()I
      //   2887: istore #11
      //   2889: aload #20
      //   2891: ifnull -> 2914
      //   2894: aload #20
      //   2896: getfield R : [Lx6;
      //   2899: iload #13
      //   2901: aaload
      //   2902: astore #26
      //   2904: aload #26
      //   2906: getfield i : Li6;
      //   2909: astore #25
      //   2911: goto -> 2939
      //   2914: aload #34
      //   2916: getfield R : [Lx6;
      //   2919: iload #15
      //   2921: aaload
      //   2922: getfield f : Lx6;
      //   2925: astore #26
      //   2927: aload #26
      //   2929: ifnull -> 2942
      //   2932: aload #26
      //   2934: getfield i : Li6;
      //   2937: astore #25
      //   2939: goto -> 2945
      //   2942: aconst_null
      //   2943: astore #25
      //   2945: aload #24
      //   2947: getfield R : [Lx6;
      //   2950: iload #15
      //   2952: aaload
      //   2953: getfield i : Li6;
      //   2956: astore #35
      //   2958: iload #11
      //   2960: istore #7
      //   2962: aload #26
      //   2964: ifnull -> 2977
      //   2967: iload #11
      //   2969: aload #26
      //   2971: invokevirtual d : ()I
      //   2974: iadd
      //   2975: istore #7
      //   2977: aload #23
      //   2979: getfield R : [Lx6;
      //   2982: iload #15
      //   2984: aaload
      //   2985: invokevirtual d : ()I
      //   2988: iload #16
      //   2990: iadd
      //   2991: istore #11
      //   2993: aload #33
      //   2995: ifnull -> 3095
      //   2998: aload #21
      //   3000: ifnull -> 3095
      //   3003: aload #25
      //   3005: ifnull -> 3095
      //   3008: aload #35
      //   3010: ifnull -> 3095
      //   3013: aload #24
      //   3015: aload #22
      //   3017: if_acmpne -> 3033
      //   3020: aload #22
      //   3022: getfield R : [Lx6;
      //   3025: iload #13
      //   3027: aaload
      //   3028: invokevirtual d : ()I
      //   3031: istore #11
      //   3033: aload #24
      //   3035: aload #32
      //   3037: if_acmpne -> 3056
      //   3040: aload #32
      //   3042: getfield R : [Lx6;
      //   3045: iload #15
      //   3047: aaload
      //   3048: invokevirtual d : ()I
      //   3051: istore #7
      //   3053: goto -> 3056
      //   3056: iload #10
      //   3058: ifeq -> 3068
      //   3061: bipush #8
      //   3063: istore #15
      //   3065: goto -> 3071
      //   3068: iconst_5
      //   3069: istore #15
      //   3071: aload_1
      //   3072: aload #33
      //   3074: aload #21
      //   3076: iload #11
      //   3078: ldc_w 0.5
      //   3081: aload #25
      //   3083: aload #35
      //   3085: iload #7
      //   3087: iload #15
      //   3089: invokevirtual b : (Li6;Li6;IFLi6;Li6;II)V
      //   3092: goto -> 3095
      //   3095: aload #24
      //   3097: getfield i0 : I
      //   3100: bipush #8
      //   3102: if_icmpeq -> 3112
      //   3105: aload #24
      //   3107: astore #23
      //   3109: goto -> 3112
      //   3112: aload #20
      //   3114: astore #24
      //   3116: goto -> 2685
      //   3119: iload #7
      //   3121: istore #8
      //   3123: iload #8
      //   3125: istore #7
      //   3127: iload #12
      //   3129: ifeq -> 3710
      //   3132: iload #8
      //   3134: istore #7
      //   3136: aload #22
      //   3138: ifnull -> 3710
      //   3141: aload #25
      //   3143: getfield j : I
      //   3146: istore #7
      //   3148: iload #7
      //   3150: ifle -> 3169
      //   3153: aload #25
      //   3155: getfield i : I
      //   3158: iload #7
      //   3160: if_icmpne -> 3169
      //   3163: iconst_1
      //   3164: istore #7
      //   3166: goto -> 3172
      //   3169: iconst_0
      //   3170: istore #7
      //   3172: aload #22
      //   3174: astore #21
      //   3176: aload #21
      //   3178: astore #25
      //   3180: aload #21
      //   3182: ifnull -> 3529
      //   3185: aload #21
      //   3187: getfield o0 : [Ly6;
      //   3190: iload_3
      //   3191: aaload
      //   3192: astore #20
      //   3194: aload #20
      //   3196: ifnull -> 3221
      //   3199: aload #20
      //   3201: getfield i0 : I
      //   3204: bipush #8
      //   3206: if_icmpne -> 3221
      //   3209: aload #20
      //   3211: getfield o0 : [Ly6;
      //   3214: iload_3
      //   3215: aaload
      //   3216: astore #20
      //   3218: goto -> 3194
      //   3221: aload #21
      //   3223: aload #22
      //   3225: if_acmpeq -> 3508
      //   3228: aload #21
      //   3230: aload #32
      //   3232: if_acmpeq -> 3508
      //   3235: aload #20
      //   3237: ifnull -> 3508
      //   3240: aload #20
      //   3242: aload #32
      //   3244: if_acmpne -> 3253
      //   3247: aconst_null
      //   3248: astore #20
      //   3250: goto -> 3253
      //   3253: aload #21
      //   3255: getfield R : [Lx6;
      //   3258: iload #13
      //   3260: aaload
      //   3261: astore #23
      //   3263: aload #23
      //   3265: getfield i : Li6;
      //   3268: astore #35
      //   3270: aload #25
      //   3272: getfield R : [Lx6;
      //   3275: astore #24
      //   3277: iload #13
      //   3279: iconst_1
      //   3280: iadd
      //   3281: istore #11
      //   3283: aload #24
      //   3285: iload #11
      //   3287: aaload
      //   3288: getfield i : Li6;
      //   3291: astore #36
      //   3293: aload #23
      //   3295: invokevirtual d : ()I
      //   3298: istore #15
      //   3300: aload #21
      //   3302: getfield R : [Lx6;
      //   3305: iload #11
      //   3307: aaload
      //   3308: invokevirtual d : ()I
      //   3311: istore #10
      //   3313: aload #20
      //   3315: ifnull -> 3363
      //   3318: aload #20
      //   3320: getfield R : [Lx6;
      //   3323: iload #13
      //   3325: aaload
      //   3326: astore #24
      //   3328: aload #24
      //   3330: getfield i : Li6;
      //   3333: astore #26
      //   3335: aload #24
      //   3337: getfield f : Lx6;
      //   3340: astore #23
      //   3342: aload #23
      //   3344: ifnull -> 3357
      //   3347: aload #23
      //   3349: getfield i : Li6;
      //   3352: astore #23
      //   3354: goto -> 3412
      //   3357: aconst_null
      //   3358: astore #23
      //   3360: goto -> 3412
      //   3363: aload #32
      //   3365: getfield R : [Lx6;
      //   3368: iload #13
      //   3370: aaload
      //   3371: astore #33
      //   3373: aload #33
      //   3375: ifnull -> 3388
      //   3378: aload #33
      //   3380: getfield i : Li6;
      //   3383: astore #24
      //   3385: goto -> 3391
      //   3388: aconst_null
      //   3389: astore #24
      //   3391: aload #21
      //   3393: getfield R : [Lx6;
      //   3396: iload #11
      //   3398: aaload
      //   3399: getfield i : Li6;
      //   3402: astore #23
      //   3404: aload #24
      //   3406: astore #26
      //   3408: aload #33
      //   3410: astore #24
      //   3412: aload #24
      //   3414: ifnull -> 3430
      //   3417: aload #24
      //   3419: invokevirtual d : ()I
      //   3422: iload #10
      //   3424: iadd
      //   3425: istore #10
      //   3427: goto -> 3430
      //   3430: aload #25
      //   3432: getfield R : [Lx6;
      //   3435: iload #11
      //   3437: aaload
      //   3438: invokevirtual d : ()I
      //   3441: istore #16
      //   3443: iload #7
      //   3445: ifeq -> 3455
      //   3448: bipush #8
      //   3450: istore #11
      //   3452: goto -> 3458
      //   3455: iconst_4
      //   3456: istore #11
      //   3458: aload #35
      //   3460: ifnull -> 3505
      //   3463: aload #36
      //   3465: ifnull -> 3505
      //   3468: aload #26
      //   3470: ifnull -> 3505
      //   3473: aload #23
      //   3475: ifnull -> 3505
      //   3478: aload_1
      //   3479: aload #35
      //   3481: aload #36
      //   3483: iload #16
      //   3485: iload #15
      //   3487: iadd
      //   3488: ldc_w 0.5
      //   3491: aload #26
      //   3493: aload #23
      //   3495: iload #10
      //   3497: iload #11
      //   3499: invokevirtual b : (Li6;Li6;IFLi6;Li6;II)V
      //   3502: goto -> 3505
      //   3505: goto -> 3508
      //   3508: aload #21
      //   3510: getfield i0 : I
      //   3513: bipush #8
      //   3515: if_icmpeq -> 3522
      //   3518: aload #21
      //   3520: astore #25
      //   3522: aload #20
      //   3524: astore #21
      //   3526: goto -> 3180
      //   3529: aload #22
      //   3531: getfield R : [Lx6;
      //   3534: iload #13
      //   3536: aaload
      //   3537: astore #20
      //   3539: aload #30
      //   3541: getfield R : [Lx6;
      //   3544: iload #13
      //   3546: aaload
      //   3547: getfield f : Lx6;
      //   3550: astore #21
      //   3552: aload #32
      //   3554: getfield R : [Lx6;
      //   3557: astore #23
      //   3559: iload #13
      //   3561: iconst_1
      //   3562: iadd
      //   3563: istore #7
      //   3565: aload #23
      //   3567: iload #7
      //   3569: aaload
      //   3570: astore #23
      //   3572: aload #34
      //   3574: getfield R : [Lx6;
      //   3577: iload #7
      //   3579: aaload
      //   3580: getfield f : Lx6;
      //   3583: astore #24
      //   3585: aload #21
      //   3587: ifnull -> 3664
      //   3590: aload #22
      //   3592: aload #32
      //   3594: if_acmpeq -> 3621
      //   3597: aload_1
      //   3598: aload #20
      //   3600: getfield i : Li6;
      //   3603: aload #21
      //   3605: getfield i : Li6;
      //   3608: aload #20
      //   3610: invokevirtual d : ()I
      //   3613: iconst_5
      //   3614: invokevirtual d : (Li6;Li6;II)Lc6;
      //   3617: pop
      //   3618: goto -> 3664
      //   3621: aload #24
      //   3623: ifnull -> 3664
      //   3626: aload_1
      //   3627: aload #20
      //   3629: getfield i : Li6;
      //   3632: aload #21
      //   3634: getfield i : Li6;
      //   3637: aload #20
      //   3639: invokevirtual d : ()I
      //   3642: ldc_w 0.5
      //   3645: aload #23
      //   3647: getfield i : Li6;
      //   3650: aload #24
      //   3652: getfield i : Li6;
      //   3655: aload #23
      //   3657: invokevirtual d : ()I
      //   3660: iconst_5
      //   3661: invokevirtual b : (Li6;Li6;IFLi6;Li6;II)V
      //   3664: iload #8
      //   3666: istore #7
      //   3668: aload #24
      //   3670: ifnull -> 3710
      //   3673: iload #8
      //   3675: istore #7
      //   3677: aload #22
      //   3679: aload #32
      //   3681: if_acmpeq -> 3710
      //   3684: aload_1
      //   3685: aload #23
      //   3687: getfield i : Li6;
      //   3690: aload #24
      //   3692: getfield i : Li6;
      //   3695: aload #23
      //   3697: invokevirtual d : ()I
      //   3700: ineg
      //   3701: iconst_5
      //   3702: invokevirtual d : (Li6;Li6;II)Lc6;
      //   3705: pop
      //   3706: iload #8
      //   3708: istore #7
      //   3710: iload #14
      //   3712: ifne -> 3732
      //   3715: iload #7
      //   3717: istore #10
      //   3719: aload #27
      //   3721: astore #20
      //   3723: iload #9
      //   3725: istore #8
      //   3727: iload #12
      //   3729: ifeq -> 4028
      //   3732: iload #7
      //   3734: istore #10
      //   3736: aload #27
      //   3738: astore #20
      //   3740: iload #9
      //   3742: istore #8
      //   3744: aload #28
      //   3746: ifnull -> 4028
      //   3749: iload #7
      //   3751: istore #10
      //   3753: aload #27
      //   3755: astore #20
      //   3757: iload #9
      //   3759: istore #8
      //   3761: aload #28
      //   3763: aload #29
      //   3765: if_acmpeq -> 4028
      //   3768: aload #28
      //   3770: getfield R : [Lx6;
      //   3773: astore #26
      //   3775: aload #26
      //   3777: iload #13
      //   3779: aaload
      //   3780: astore #24
      //   3782: aload #29
      //   3784: ifnonnull -> 3794
      //   3787: aload #28
      //   3789: astore #21
      //   3791: goto -> 3798
      //   3794: aload #29
      //   3796: astore #21
      //   3798: aload #21
      //   3800: getfield R : [Lx6;
      //   3803: astore #20
      //   3805: iload #13
      //   3807: iconst_1
      //   3808: iadd
      //   3809: istore #11
      //   3811: aload #20
      //   3813: iload #11
      //   3815: aaload
      //   3816: astore #25
      //   3818: aload #24
      //   3820: getfield f : Lx6;
      //   3823: astore #20
      //   3825: aload #20
      //   3827: ifnull -> 3840
      //   3830: aload #20
      //   3832: getfield i : Li6;
      //   3835: astore #22
      //   3837: goto -> 3843
      //   3840: aconst_null
      //   3841: astore #22
      //   3843: aload #25
      //   3845: getfield f : Lx6;
      //   3848: astore #20
      //   3850: aload #20
      //   3852: ifnull -> 3865
      //   3855: aload #20
      //   3857: getfield i : Li6;
      //   3860: astore #20
      //   3862: goto -> 3868
      //   3865: aconst_null
      //   3866: astore #20
      //   3868: aload #34
      //   3870: aload #21
      //   3872: if_acmpeq -> 3911
      //   3875: aload #34
      //   3877: getfield R : [Lx6;
      //   3880: iload #11
      //   3882: aaload
      //   3883: getfield f : Lx6;
      //   3886: astore #23
      //   3888: aload #31
      //   3890: astore #20
      //   3892: aload #23
      //   3894: ifnull -> 3904
      //   3897: aload #23
      //   3899: getfield i : Li6;
      //   3902: astore #20
      //   3904: aload #20
      //   3906: astore #23
      //   3908: goto -> 3915
      //   3911: aload #20
      //   3913: astore #23
      //   3915: aload #28
      //   3917: aload #21
      //   3919: if_acmpne -> 3936
      //   3922: aload #26
      //   3924: iload #13
      //   3926: aaload
      //   3927: astore #24
      //   3929: aload #26
      //   3931: iload #11
      //   3933: aaload
      //   3934: astore #25
      //   3936: iload #7
      //   3938: istore #10
      //   3940: aload #27
      //   3942: astore #20
      //   3944: iload #9
      //   3946: istore #8
      //   3948: aload #22
      //   3950: ifnull -> 4028
      //   3953: iload #7
      //   3955: istore #10
      //   3957: aload #27
      //   3959: astore #20
      //   3961: iload #9
      //   3963: istore #8
      //   3965: aload #23
      //   3967: ifnull -> 4028
      //   3970: aload #24
      //   3972: invokevirtual d : ()I
      //   3975: istore #8
      //   3977: aload #21
      //   3979: getfield R : [Lx6;
      //   3982: iload #11
      //   3984: aaload
      //   3985: invokevirtual d : ()I
      //   3988: istore #10
      //   3990: aload_1
      //   3991: aload #24
      //   3993: getfield i : Li6;
      //   3996: aload #22
      //   3998: iload #8
      //   4000: ldc_w 0.5
      //   4003: aload #23
      //   4005: aload #25
      //   4007: getfield i : Li6;
      //   4010: iload #10
      //   4012: iconst_5
      //   4013: invokevirtual b : (Li6;Li6;IFLi6;Li6;II)V
      //   4016: iload #9
      //   4018: istore #8
      //   4020: aload #27
      //   4022: astore #20
      //   4024: iload #7
      //   4026: istore #10
      //   4028: iload #10
      //   4030: iconst_1
      //   4031: iadd
      //   4032: istore #7
      //   4034: goto -> 47
      //   4037: return
    }
    
    public static File a0(Context param1Context) {
      File file = param1Context.getCacheDir();
      if (file == null)
        return null; 
      StringBuilder stringBuilder = s30.x0(".font");
      stringBuilder.append(Process.myPid());
      stringBuilder.append("-");
      stringBuilder.append(Process.myTid());
      stringBuilder.append("-");
      String str = stringBuilder.toString();
      int i = 0;
      while (true) {
        if (i < 100) {
          File file1 = new File(file, s30.Z(str, i));
          try {
            boolean bool = file1.createNewFile();
            if (bool)
              return file1; 
          } catch (IOException iOException) {}
          i++;
          continue;
        } 
        return null;
      } 
    }
    
    public static void b(Drawable param1Drawable, Resources.Theme param1Theme) {
      if (Build.VERSION.SDK_INT >= 21)
        param1Drawable.applyTheme(param1Theme); 
    }
    
    public static tc.a b0(TextView param1TextView) {
      TextDirectionHeuristic textDirectionHeuristic1;
      int j;
      int k = Build.VERSION.SDK_INT;
      if (k >= 28)
        return new tc.a(param1TextView.getTextMetricsParams()); 
      TextPaint textPaint = new TextPaint((Paint)param1TextView.getPaint());
      int i = Build.VERSION.SDK_INT;
      byte b = 0;
      if (i >= 23) {
        j = 1;
        i = 1;
      } else {
        j = 0;
        i = 0;
      } 
      TextDirectionHeuristic textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_LTR;
      if (k >= 23) {
        j = param1TextView.getBreakStrategy();
        i = param1TextView.getHyphenationFrequency();
      } 
      if (param1TextView.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod) {
        textDirectionHeuristic1 = TextDirectionHeuristics.LTR;
      } else if (k >= 28 && (textDirectionHeuristic1.getInputType() & 0xF) == 3) {
        b = Character.getDirectionality(DecimalFormatSymbols.getInstance(textDirectionHeuristic1.getTextLocale()).getDigitStrings()[0].codePointAt(0));
        if (b == 1 || b == 2) {
          textDirectionHeuristic1 = TextDirectionHeuristics.RTL;
          return new tc.a(textPaint, textDirectionHeuristic1, j, i);
        } 
        textDirectionHeuristic1 = TextDirectionHeuristics.LTR;
      } else {
        if (textDirectionHeuristic1.getLayoutDirection() == 1)
          b = 1; 
        switch (textDirectionHeuristic1.getTextDirection()) {
          default:
            if (b != 0) {
              textDirectionHeuristic1 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
              return new tc.a(textPaint, textDirectionHeuristic1, j, i);
            } 
            break;
          case 7:
            textDirectionHeuristic1 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
          case 6:
            textDirectionHeuristic1 = TextDirectionHeuristics.FIRSTSTRONG_LTR;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
          case 5:
            textDirectionHeuristic1 = TextDirectionHeuristics.LOCALE;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
          case 4:
            textDirectionHeuristic1 = TextDirectionHeuristics.RTL;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
          case 3:
            textDirectionHeuristic1 = TextDirectionHeuristics.LTR;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
          case 2:
            textDirectionHeuristic1 = TextDirectionHeuristics.ANYRTL_LTR;
            return new tc.a(textPaint, textDirectionHeuristic1, j, i);
        } 
        textDirectionHeuristic1 = TextDirectionHeuristics.FIRSTSTRONG_LTR;
      } 
      return new tc.a(textPaint, textDirectionHeuristic1, j, i);
    }
    
    public static boolean c(Bundle param1Bundle1, Bundle param1Bundle2) {
      return (param1Bundle1 == param1Bundle2) ? true : ((param1Bundle1 == null) ? ((param1Bundle2.getInt("android.media.browse.extra.PAGE", -1) == -1 && param1Bundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1)) : ((param1Bundle2 == null) ? ((param1Bundle1.getInt("android.media.browse.extra.PAGE", -1) == -1 && param1Bundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1)) : ((param1Bundle1.getInt("android.media.browse.extra.PAGE", -1) == param1Bundle2.getInt("android.media.browse.extra.PAGE", -1) && param1Bundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == param1Bundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1)))));
    }
    
    public static boolean c0(XmlPullParser param1XmlPullParser, String param1String) {
      return (param1XmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", param1String) != null);
    }
    
    public static boolean d(int param1Int, Rect param1Rect1, Rect param1Rect2, Rect param1Rect3) {
      // Byte code:
      //   0: iload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokestatic e : (ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z
      //   6: istore #7
      //   8: iload_0
      //   9: aload_1
      //   10: aload_3
      //   11: invokestatic e : (ILandroid/graphics/Rect;Landroid/graphics/Rect;)Z
      //   14: istore #8
      //   16: iconst_0
      //   17: istore #6
      //   19: iload #8
      //   21: ifne -> 268
      //   24: iload #7
      //   26: ifne -> 31
      //   29: iconst_0
      //   30: ireturn
      //   31: iload_0
      //   32: bipush #17
      //   34: if_icmpeq -> 109
      //   37: iload_0
      //   38: bipush #33
      //   40: if_icmpeq -> 95
      //   43: iload_0
      //   44: bipush #66
      //   46: if_icmpeq -> 81
      //   49: iload_0
      //   50: sipush #130
      //   53: if_icmpne -> 70
      //   56: aload_1
      //   57: getfield bottom : I
      //   60: aload_3
      //   61: getfield top : I
      //   64: if_icmpgt -> 126
      //   67: goto -> 120
      //   70: new java/lang/IllegalArgumentException
      //   73: dup
      //   74: ldc_w 'direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.'
      //   77: invokespecial <init> : (Ljava/lang/String;)V
      //   80: athrow
      //   81: aload_1
      //   82: getfield right : I
      //   85: aload_3
      //   86: getfield left : I
      //   89: if_icmpgt -> 126
      //   92: goto -> 120
      //   95: aload_1
      //   96: getfield top : I
      //   99: aload_3
      //   100: getfield bottom : I
      //   103: if_icmplt -> 126
      //   106: goto -> 120
      //   109: aload_1
      //   110: getfield left : I
      //   113: aload_3
      //   114: getfield right : I
      //   117: if_icmplt -> 126
      //   120: iconst_1
      //   121: istore #4
      //   123: goto -> 129
      //   126: iconst_0
      //   127: istore #4
      //   129: iload #4
      //   131: ifne -> 136
      //   134: iconst_1
      //   135: ireturn
      //   136: iload_0
      //   137: bipush #17
      //   139: if_icmpeq -> 266
      //   142: iload_0
      //   143: bipush #66
      //   145: if_icmpne -> 150
      //   148: iconst_1
      //   149: ireturn
      //   150: iload_0
      //   151: aload_1
      //   152: aload_2
      //   153: invokestatic k0 : (ILandroid/graphics/Rect;Landroid/graphics/Rect;)I
      //   156: istore #5
      //   158: iload_0
      //   159: bipush #17
      //   161: if_icmpeq -> 236
      //   164: iload_0
      //   165: bipush #33
      //   167: if_icmpeq -> 222
      //   170: iload_0
      //   171: bipush #66
      //   173: if_icmpeq -> 208
      //   176: iload_0
      //   177: sipush #130
      //   180: if_icmpne -> 197
      //   183: aload_3
      //   184: getfield bottom : I
      //   187: istore_0
      //   188: aload_1
      //   189: getfield bottom : I
      //   192: istore #4
      //   194: goto -> 247
      //   197: new java/lang/IllegalArgumentException
      //   200: dup
      //   201: ldc_w 'direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.'
      //   204: invokespecial <init> : (Ljava/lang/String;)V
      //   207: athrow
      //   208: aload_3
      //   209: getfield right : I
      //   212: istore_0
      //   213: aload_1
      //   214: getfield right : I
      //   217: istore #4
      //   219: goto -> 247
      //   222: aload_1
      //   223: getfield top : I
      //   226: istore_0
      //   227: aload_3
      //   228: getfield top : I
      //   231: istore #4
      //   233: goto -> 247
      //   236: aload_1
      //   237: getfield left : I
      //   240: istore_0
      //   241: aload_3
      //   242: getfield left : I
      //   245: istore #4
      //   247: iload #5
      //   249: iconst_1
      //   250: iload_0
      //   251: iload #4
      //   253: isub
      //   254: invokestatic max : (II)I
      //   257: if_icmpge -> 263
      //   260: iconst_1
      //   261: istore #6
      //   263: iload #6
      //   265: ireturn
      //   266: iconst_1
      //   267: ireturn
      //   268: iconst_0
      //   269: ireturn
    }
    
    public static int d0(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      throw new IllegalArgumentException(s30.Z("type needs to be >= FIRST and <= LAST, type=", param1Int));
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
    
    public static boolean e(int param1Int, Rect param1Rect1, Rect param1Rect2) {
      // Byte code:
      //   0: iload_0
      //   1: bipush #17
      //   3: if_icmpeq -> 65
      //   6: iload_0
      //   7: bipush #33
      //   9: if_icmpeq -> 39
      //   12: iload_0
      //   13: bipush #66
      //   15: if_icmpeq -> 65
      //   18: iload_0
      //   19: sipush #130
      //   22: if_icmpne -> 28
      //   25: goto -> 39
      //   28: new java/lang/IllegalArgumentException
      //   31: dup
      //   32: ldc_w 'direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.'
      //   35: invokespecial <init> : (Ljava/lang/String;)V
      //   38: athrow
      //   39: aload_2
      //   40: getfield right : I
      //   43: aload_1
      //   44: getfield left : I
      //   47: if_icmplt -> 63
      //   50: aload_2
      //   51: getfield left : I
      //   54: aload_1
      //   55: getfield right : I
      //   58: if_icmpgt -> 63
      //   61: iconst_1
      //   62: ireturn
      //   63: iconst_0
      //   64: ireturn
      //   65: aload_2
      //   66: getfield bottom : I
      //   69: aload_1
      //   70: getfield top : I
      //   73: if_icmplt -> 89
      //   76: aload_2
      //   77: getfield top : I
      //   80: aload_1
      //   81: getfield bottom : I
      //   84: if_icmpgt -> 89
      //   87: iconst_1
      //   88: ireturn
      //   89: iconst_0
      //   90: ireturn
    }
    
    public static boolean e0() {
      int i = Build.VERSION.SDK_INT;
      null = false;
      if (i < 31) {
        String str = Build.VERSION.CODENAME;
        if (!"REL".equals(str) && str.compareTo("S") >= 0) {
          i = 1;
        } else {
          i = 0;
        } 
        return (i != 0) ? true : null;
      } 
      return true;
    }
    
    public static void f(Object param1Object, StringBuilder param1StringBuilder) {
      if (param1Object == null) {
        param1StringBuilder.append("null");
        return;
      } 
      String str2 = param1Object.getClass().getSimpleName();
      String str1 = str2;
      if (str2.length() <= 0) {
        str2 = param1Object.getClass().getName();
        int i = str2.lastIndexOf('.');
        str1 = str2;
        if (i > 0)
          str1 = str2.substring(i + 1); 
      } 
      param1StringBuilder.append(str1);
      param1StringBuilder.append('{');
      param1StringBuilder.append(Integer.toHexString(System.identityHashCode(param1Object)));
    }
    
    public static boolean f0(Rect param1Rect1, Rect param1Rect2, int param1Int) {
      if (param1Int != 17) {
        if (param1Int != 33) {
          if (param1Int != 66) {
            if (param1Int == 130) {
              param1Int = param1Rect1.top;
              int m = param1Rect2.top;
              return ((param1Int < m || param1Rect1.bottom <= m) && param1Rect1.bottom < param1Rect2.bottom);
            } 
            throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
          } 
          param1Int = param1Rect1.left;
          int k = param1Rect2.left;
          return ((param1Int < k || param1Rect1.right <= k) && param1Rect1.right < param1Rect2.right);
        } 
        param1Int = param1Rect1.bottom;
        int j = param1Rect2.bottom;
        return ((param1Int > j || param1Rect1.top >= j) && param1Rect1.top > param1Rect2.top);
      } 
      param1Int = param1Rect1.right;
      int i = param1Rect2.right;
      return ((param1Int > i || param1Rect1.left >= i) && param1Rect1.left > param1Rect2.left);
    }
    
    public static boolean g(Drawable param1Drawable) {
      return (Build.VERSION.SDK_INT >= 21) ? param1Drawable.canApplyTheme() : false;
    }
    
    public static boolean g0(ViewGroup param1ViewGroup) {
      if (Build.VERSION.SDK_INT >= 21)
        return param1ViewGroup.isTransitionGroup(); 
      Boolean bool = (Boolean)param1ViewGroup.getTag(o9.tag_transition_group);
      return ((bool != null && bool.booleanValue()) || param1ViewGroup.getBackground() != null || fe.p((View)param1ViewGroup) != null);
    }
    
    public static boolean h(db[] param1ArrayOfdb1, db[] param1ArrayOfdb2) {
      if (param1ArrayOfdb1 != null) {
        if (param1ArrayOfdb2 == null)
          return false; 
        if (param1ArrayOfdb1.length != param1ArrayOfdb2.length)
          return false; 
        int i = 0;
        while (i < param1ArrayOfdb1.length) {
          if ((param1ArrayOfdb1[i]).a == (param1ArrayOfdb2[i]).a) {
            if ((param1ArrayOfdb1[i]).b.length != (param1ArrayOfdb2[i]).b.length)
              return false; 
            i++;
            continue;
          } 
          return false;
        } 
        return true;
      } 
      return false;
    }
    
    public static boolean h0(Context param1Context) {
      return (Build.VERSION.SDK_INT >= 24) ? ((UserManager)param1Context.getSystemService(UserManager.class)).isUserUnlocked() : true;
    }
    
    public static void i(boolean param1Boolean, Object param1Object) {
      if (param1Boolean)
        return; 
      throw new IllegalArgumentException(String.valueOf(param1Object));
    }
    
    public static vh i0(Context param1Context, Fragment param1Fragment, boolean param1Boolean1, boolean param1Boolean2) {
      int i;
      int k = param1Fragment.getNextTransition();
      if (param1Boolean2) {
        if (param1Boolean1) {
          i = param1Fragment.getPopEnterAnim();
        } else {
          i = param1Fragment.getPopExitAnim();
        } 
      } else if (param1Boolean1) {
        i = param1Fragment.getEnterAnim();
      } else {
        i = param1Fragment.getExitAnim();
      } 
      boolean bool = false;
      param1Fragment.setAnimations(0, 0, 0, 0);
      ViewGroup viewGroup = param1Fragment.mContainer;
      if (viewGroup != null) {
        int m = dh.visible_removing_fragment_view_tag;
        if (viewGroup.getTag(m) != null)
          param1Fragment.mContainer.setTag(m, null); 
      } 
      viewGroup = param1Fragment.mContainer;
      if (viewGroup != null && viewGroup.getLayoutTransition() != null)
        return null; 
      Animation animation = param1Fragment.onCreateAnimation(k, param1Boolean1, i);
      if (animation != null)
        return new vh(animation); 
      Animator animator = param1Fragment.onCreateAnimator(k, param1Boolean1, i);
      if (animator != null)
        return new vh(animator); 
      int j = i;
      if (i == 0) {
        j = i;
        if (k != 0)
          if (k != 4097) {
            if (k != 4099) {
              if (k != 8194) {
                j = -1;
              } else {
                if (param1Boolean1) {
                  i = ch.fragment_close_enter;
                } else {
                  i = ch.fragment_close_exit;
                } 
                j = i;
              } 
            } else {
              if (param1Boolean1) {
                i = ch.fragment_fade_enter;
              } else {
                i = ch.fragment_fade_exit;
              } 
              j = i;
            } 
          } else {
            if (param1Boolean1) {
              i = ch.fragment_open_enter;
            } else {
              i = ch.fragment_open_exit;
            } 
            j = i;
          }  
      } 
      if (j != 0) {
        param1Boolean1 = "anim".equals(param1Context.getResources().getResourceTypeName(j));
        i = bool;
        if (param1Boolean1)
          try {
            Animation animation1 = AnimationUtils.loadAnimation(param1Context, j);
            if (animation1 != null)
              return new vh(animation1); 
            i = 1;
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            throw notFoundException;
          } catch (RuntimeException runtimeException) {
            i = bool;
          }  
        if (i == 0)
          try {
            animator = AnimatorInflater.loadAnimator((Context)notFoundException, j);
            if (animator != null)
              return new vh(animator); 
          } catch (RuntimeException runtimeException) {
            if (!param1Boolean1) {
              Animation animation1 = AnimationUtils.loadAnimation((Context)notFoundException, j);
              if (animation1 != null)
                return new vh(animation1); 
            } else {
              throw runtimeException;
            } 
          }  
      } 
      return null;
    }
    
    public static int j(int param1Int) {
      if (param1Int >= 0)
        return param1Int; 
      throw new IllegalArgumentException();
    }
    
    public static Handler j0() {
      return (Build.VERSION.SDK_INT >= 28) ? cg.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper());
    }
    
    public static int k(int param1Int, String param1String) {
      if (param1Int >= 0)
        return param1Int; 
      throw new IllegalArgumentException(param1String);
    }
    
    public static int k0(int param1Int, Rect param1Rect1, Rect param1Rect2) {
      int i;
      if (param1Int != 17) {
        if (param1Int != 33) {
          if (param1Int != 66) {
            if (param1Int == 130) {
              param1Int = param1Rect2.top;
              i = param1Rect1.bottom;
            } else {
              throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            } 
          } else {
            param1Int = param1Rect2.left;
            i = param1Rect1.right;
          } 
        } else {
          param1Int = param1Rect1.top;
          i = param1Rect2.bottom;
        } 
      } else {
        param1Int = param1Rect1.left;
        i = param1Rect2.right;
      } 
      return Math.max(0, param1Int - i);
    }
    
    public static <T> T l(T param1T, Object param1Object) {
      if (param1T != null)
        return param1T; 
      throw new NullPointerException(String.valueOf(param1Object));
    }
    
    public static int l0(int param1Int, Rect param1Rect1, Rect param1Rect2) {
      if (param1Int != 17)
        if (param1Int != 33) {
          if (param1Int != 66) {
            if (param1Int != 130)
              throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}."); 
            param1Int = param1Rect1.left;
            int k = param1Rect1.width() / 2;
            int m = param1Rect2.left;
            return Math.abs(k + param1Int - param1Rect2.width() / 2 + m);
          } 
        } else {
          param1Int = param1Rect1.left;
          int k = param1Rect1.width() / 2;
          int m = param1Rect2.left;
          return Math.abs(k + param1Int - param1Rect2.width() / 2 + m);
        }  
      param1Int = param1Rect1.top;
      int i = param1Rect1.height() / 2;
      int j = param1Rect2.top;
      return Math.abs(i + param1Int - param1Rect2.height() / 2 + j);
    }
    
    public static int m(Context param1Context, String param1String) {
      null = Process.myPid();
      int i = Process.myUid();
      String str2 = param1Context.getPackageName();
      int j = param1Context.checkPermission(param1String, null, i);
      null = -1;
      if (j == -1)
        return -1; 
      j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        param1String = AppOpsManager.permissionToOp(param1String);
      } else {
        param1String = null;
      } 
      if (param1String == null)
        return 0; 
      String str1 = str2;
      if (str2 == null) {
        String[] arrayOfString = param1Context.getPackageManager().getPackagesForUid(i);
        if (arrayOfString != null) {
          if (arrayOfString.length <= 0)
            return -1; 
          str1 = arrayOfString[0];
        } else {
          return null;
        } 
      } 
      null = Process.myUid();
      str2 = param1Context.getPackageName();
      if (null == i && Objects.equals(str2, str1)) {
        null = 1;
      } else {
        null = 0;
      } 
      if (null != 0) {
        if (j >= 29) {
          AppOpsManager appOpsManager = x9.c(param1Context);
          null = x9.a(appOpsManager, param1String, Binder.getCallingUid(), str1);
          if (null == 0)
            null = x9.a(appOpsManager, param1String, i, x9.b(param1Context)); 
        } else {
          null = n0(param1Context, param1String, str1);
        } 
      } else {
        null = n0(param1Context, param1String, str1);
      } 
      return (null == 0) ? 0 : -2;
    }
    
    public static ByteBuffer m0(Context param1Context, CancellationSignal param1CancellationSignal, Uri param1Uri) {
      ContentResolver contentResolver = param1Context.getContentResolver();
      try {
        ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(param1Uri, "r", param1CancellationSignal);
        if (parcelFileDescriptor == null) {
          if (parcelFileDescriptor != null)
            parcelFileDescriptor.close(); 
          return null;
        } 
        try {
          FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptor.getFileDescriptor());
        } finally {
          try {
            parcelFileDescriptor.close();
          } finally {
            parcelFileDescriptor = null;
          } 
        } 
      } catch (IOException iOException) {
        return null;
      } 
    }
    
    public static void n(boolean param1Boolean, String param1String) {
      if (param1Boolean)
        return; 
      throw new IllegalStateException(param1String);
    }
    
    public static int n0(Context param1Context, String param1String1, String param1String2) {
      return (Build.VERSION.SDK_INT >= 23) ? ((AppOpsManager)param1Context.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(param1String1, param1String2) : 1;
    }
    
    public static float o(float param1Float1, float param1Float2, float param1Float3) {
      return (param1Float1 < param1Float2) ? param1Float2 : ((param1Float1 > param1Float3) ? param1Float3 : param1Float1);
    }
    
    public static TypedArray o0(Resources param1Resources, Resources.Theme param1Theme, AttributeSet param1AttributeSet, int[] param1ArrayOfint) {
      return (param1Theme == null) ? param1Resources.obtainAttributes(param1AttributeSet, param1ArrayOfint) : param1Theme.obtainStyledAttributes(param1AttributeSet, param1ArrayOfint, 0, 0);
    }
    
    public static int p(int param1Int) {
      param1Int = (param1Int & (param1Int >> 31 ^ 0xFFFFFFFF)) - 255;
      return (param1Int & param1Int >> 31) + 255;
    }
    
    public static InputConnection p0(InputConnection param1InputConnection, EditorInfo param1EditorInfo, View param1View) {
      if (param1InputConnection != null && param1EditorInfo.hintText == null)
        for (ViewParent viewParent = param1View.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
          if (viewParent instanceof t4) {
            param1EditorInfo.hintText = ((t4)viewParent).a();
            return param1InputConnection;
          } 
        }  
      return param1InputConnection;
    }
    
    public static int q(int param1Int1, int param1Int2, int param1Int3) {
      return (param1Int1 < param1Int2) ? param1Int2 : ((param1Int1 > param1Int3) ? param1Int3 : param1Int1);
    }
    
    public static boolean q0(ViewParent param1ViewParent, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      StringBuilder stringBuilder;
      if (Build.VERSION.SDK_INT >= 21) {
        try {
          return param1ViewParent.onNestedFling(param1View, param1Float1, param1Float2, param1Boolean);
        } catch (AbstractMethodError abstractMethodError) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("ViewParent ");
          stringBuilder.append(param1ViewParent);
          stringBuilder.append(" does not implement interface method onNestedFling");
          stringBuilder.toString();
        } 
      } else if (param1ViewParent instanceof td) {
        return ((td)param1ViewParent).onNestedFling((View)stringBuilder, param1Float1, param1Float2, param1Boolean);
      } 
      return false;
    }
    
    public static void r(Drawable param1Drawable) {
      DrawableContainer.DrawableContainerState drawableContainerState;
      int i = Build.VERSION.SDK_INT;
      if (i >= 23) {
        param1Drawable.clearColorFilter();
        return;
      } 
      if (i >= 21) {
        param1Drawable.clearColorFilter();
        if (param1Drawable instanceof InsetDrawable) {
          r(((InsetDrawable)param1Drawable).getDrawable());
          return;
        } 
        if (param1Drawable instanceof nb) {
          r(((nb)param1Drawable).b());
          return;
        } 
        if (param1Drawable instanceof DrawableContainer) {
          drawableContainerState = (DrawableContainer.DrawableContainerState)((DrawableContainer)param1Drawable).getConstantState();
          if (drawableContainerState != null) {
            i = 0;
            int j = drawableContainerState.getChildCount();
            while (i < j) {
              Drawable drawable = drawableContainerState.getChild(i);
              if (drawable != null)
                r(drawable); 
              i++;
            } 
          } 
        } 
      } else {
        drawableContainerState.clearColorFilter();
      } 
    }
    
    public static boolean r0(ViewParent param1ViewParent, View param1View, float param1Float1, float param1Float2) {
      StringBuilder stringBuilder;
      if (Build.VERSION.SDK_INT >= 21) {
        try {
          return param1ViewParent.onNestedPreFling(param1View, param1Float1, param1Float2);
        } catch (AbstractMethodError abstractMethodError) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("ViewParent ");
          stringBuilder.append(param1ViewParent);
          stringBuilder.append(" does not implement interface method onNestedPreFling");
          stringBuilder.toString();
        } 
      } else if (param1ViewParent instanceof td) {
        return ((td)param1ViewParent).onNestedPreFling((View)stringBuilder, param1Float1, param1Float2);
      } 
      return false;
    }
    
    public static void s(AutoCloseable param1AutoCloseable) {
      if (param1AutoCloseable != null)
        try {
          param1AutoCloseable.close();
          return;
        } catch (RuntimeException runtimeException) {
          throw runtimeException;
        } catch (Exception exception) {
          return;
        }  
    }
    
    public static void s0(ViewParent param1ViewParent, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {
      if (param1ViewParent instanceof rd) {
        ((rd)param1ViewParent).onNestedPreScroll(param1View, param1Int1, param1Int2, param1ArrayOfint, param1Int3);
        return;
      } 
      if (param1Int3 == 0) {
        StringBuilder stringBuilder;
        if (Build.VERSION.SDK_INT >= 21)
          try {
            param1ViewParent.onNestedPreScroll(param1View, param1Int1, param1Int2, param1ArrayOfint);
            return;
          } catch (AbstractMethodError abstractMethodError) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("ViewParent ");
            stringBuilder.append(param1ViewParent);
            stringBuilder.append(" does not implement interface method onNestedPreScroll");
            stringBuilder.toString();
            return;
          }  
        if (param1ViewParent instanceof td)
          ((td)param1ViewParent).onNestedPreScroll((View)stringBuilder, param1Int1, param1Int2, param1ArrayOfint); 
      } 
    }
    
    public static int t(RecyclerView.a0 param1a0, um param1um, View param1View1, View param1View2, RecyclerView.o param1o, boolean param1Boolean) {
      if (param1o.getChildCount() == 0 || param1a0.b() == 0 || param1View1 == null || param1View2 == null)
        return 0; 
      if (!param1Boolean)
        return Math.abs(param1o.getPosition(param1View1) - param1o.getPosition(param1View2)) + 1; 
      int i = param1um.b(param1View2);
      int j = param1um.e(param1View1);
      return Math.min(param1um.l(), i - j);
    }
    
    public static void t0(ViewParent param1ViewParent, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int[] param1ArrayOfint) {
      if (param1ViewParent instanceof sd) {
        ((sd)param1ViewParent).onNestedScroll(param1View, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5, param1ArrayOfint);
        return;
      } 
      param1ArrayOfint[0] = param1ArrayOfint[0] + param1Int3;
      param1ArrayOfint[1] = param1ArrayOfint[1] + param1Int4;
      if (param1ViewParent instanceof rd) {
        ((rd)param1ViewParent).onNestedScroll(param1View, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
        return;
      } 
      if (param1Int5 == 0) {
        StringBuilder stringBuilder;
        if (Build.VERSION.SDK_INT >= 21)
          try {
            param1ViewParent.onNestedScroll(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
            return;
          } catch (AbstractMethodError abstractMethodError) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("ViewParent ");
            stringBuilder.append(param1ViewParent);
            stringBuilder.append(" does not implement interface method onNestedScroll");
            stringBuilder.toString();
            return;
          }  
        if (param1ViewParent instanceof td)
          ((td)param1ViewParent).onNestedScroll((View)stringBuilder, param1Int1, param1Int2, param1Int3, param1Int4); 
      } 
    }
    
    public static int u(RecyclerView.a0 param1a0, um param1um, View param1View1, View param1View2, RecyclerView.o param1o, boolean param1Boolean1, boolean param1Boolean2) {
      if (param1o.getChildCount() != 0 && param1a0.b() != 0 && param1View1 != null) {
        if (param1View2 == null)
          return 0; 
        int i = Math.min(param1o.getPosition(param1View1), param1o.getPosition(param1View2));
        int j = Math.max(param1o.getPosition(param1View1), param1o.getPosition(param1View2));
        if (param1Boolean2) {
          i = Math.max(0, param1a0.b() - j - 1);
        } else {
          i = Math.max(0, i);
        } 
        if (!param1Boolean1)
          return i; 
        j = Math.abs(param1um.b(param1View2) - param1um.e(param1View1));
        int k = Math.abs(param1o.getPosition(param1View1) - param1o.getPosition(param1View2));
        float f = j / (k + 1);
        return Math.round(i * f + (param1um.k() - param1um.e(param1View1)));
      } 
      return 0;
    }
    
    public static void u0(EdgeEffect param1EdgeEffect, float param1Float1, float param1Float2) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1EdgeEffect.onPull(param1Float1, param1Float2);
        return;
      } 
      param1EdgeEffect.onPull(param1Float1);
    }
    
    public static int v(RecyclerView.a0 param1a0, um param1um, View param1View1, View param1View2, RecyclerView.o param1o, boolean param1Boolean) {
      if (param1o.getChildCount() == 0 || param1a0.b() == 0 || param1View1 == null || param1View2 == null)
        return 0; 
      if (!param1Boolean)
        return param1a0.b(); 
      int i = param1um.b(param1View2);
      int j = param1um.e(param1View1);
      int k = Math.abs(param1o.getPosition(param1View1) - param1o.getPosition(param1View2));
      return (int)((i - j) / (k + 1) * param1a0.b());
    }
    
    public static float v0(EdgeEffect param1EdgeEffect, float param1Float1, float param1Float2) {
      if (e0())
        return af.c(param1EdgeEffect, param1Float1, param1Float2); 
      if (Build.VERSION.SDK_INT >= 21) {
        param1EdgeEffect.onPull(param1Float1, param1Float2);
        return param1Float1;
      } 
      param1EdgeEffect.onPull(param1Float1);
      return param1Float1;
    }
    
    public static float[] w(float[] param1ArrayOffloat, int param1Int1, int param1Int2) {
      if (param1Int1 <= param1Int2) {
        int i = param1ArrayOffloat.length;
        if (param1Int1 >= 0 && param1Int1 <= i) {
          param1Int2 -= param1Int1;
          i = Math.min(param1Int2, i - param1Int1);
          float[] arrayOfFloat = new float[param1Int2];
          System.arraycopy(param1ArrayOffloat, param1Int1, arrayOfFloat, 0, i);
          return arrayOfFloat;
        } 
        throw new ArrayIndexOutOfBoundsException();
      } 
      throw new IllegalArgumentException();
    }
    
    public static ra w0(XmlPullParser param1XmlPullParser, Resources param1Resources) {
      int i;
      while (true) {
        i = param1XmlPullParser.next();
        if (i != 2 && i != 1)
          continue; 
        break;
      } 
      if (i == 2) {
        param1XmlPullParser.require(2, null, "font-family");
        if (param1XmlPullParser.getName().equals("font-family")) {
          TypedArray typedArray = param1Resources.obtainAttributes(Xml.asAttributeSet(param1XmlPullParser), r9.FontFamily);
          String str1 = typedArray.getString(r9.FontFamily_fontProviderAuthority);
          String str2 = typedArray.getString(r9.FontFamily_fontProviderPackage);
          String str3 = typedArray.getString(r9.FontFamily_fontProviderQuery);
          i = typedArray.getResourceId(r9.FontFamily_fontProviderCerts, 0);
          int j = typedArray.getInteger(r9.FontFamily_fontProviderFetchStrategy, 1);
          int k = typedArray.getInteger(r9.FontFamily_fontProviderFetchTimeout, 500);
          String str4 = typedArray.getString(r9.FontFamily_fontProviderSystemFontFamily);
          typedArray.recycle();
          if (str1 != null && str2 != null && str3 != null) {
            while (param1XmlPullParser.next() != 3)
              R0(param1XmlPullParser); 
            return (ra)new ua(new hc(str1, str2, str3, y0(param1Resources, i)), j, k, str4);
          } 
          ArrayList<ta> arrayList = new ArrayList();
          while (param1XmlPullParser.next() != 3) {
            if (param1XmlPullParser.getEventType() != 2)
              continue; 
            if (param1XmlPullParser.getName().equals("font")) {
              boolean bool;
              TypedArray typedArray1 = param1Resources.obtainAttributes(Xml.asAttributeSet(param1XmlPullParser), r9.FontFamilyFont);
              i = r9.FontFamilyFont_fontWeight;
              if (!typedArray1.hasValue(i))
                i = r9.FontFamilyFont_android_fontWeight; 
              k = typedArray1.getInt(i, 400);
              i = r9.FontFamilyFont_fontStyle;
              if (!typedArray1.hasValue(i))
                i = r9.FontFamilyFont_android_fontStyle; 
              if (1 == typedArray1.getInt(i, 0)) {
                bool = true;
              } else {
                bool = false;
              } 
              i = r9.FontFamilyFont_ttcIndex;
              if (!typedArray1.hasValue(i))
                i = r9.FontFamilyFont_android_ttcIndex; 
              j = r9.FontFamilyFont_fontVariationSettings;
              if (!typedArray1.hasValue(j))
                j = r9.FontFamilyFont_android_fontVariationSettings; 
              str2 = typedArray1.getString(j);
              j = typedArray1.getInt(i, 0);
              i = r9.FontFamilyFont_font;
              if (!typedArray1.hasValue(i))
                i = r9.FontFamilyFont_android_font; 
              int m = typedArray1.getResourceId(i, 0);
              str3 = typedArray1.getString(i);
              typedArray1.recycle();
              while (param1XmlPullParser.next() != 3)
                R0(param1XmlPullParser); 
              arrayList.add(new ta(str3, k, bool, str2, j, m));
              continue;
            } 
            R0(param1XmlPullParser);
          } 
          return (ra)(arrayList.isEmpty() ? null : new sa(arrayList.<ta>toArray(new ta[arrayList.size()])));
        } 
        R0(param1XmlPullParser);
        return null;
      } 
      XmlPullParserException xmlPullParserException = new XmlPullParserException("No start tag found");
      throw xmlPullParserException;
    }
    
    public static boolean x(File param1File, Resources param1Resources, int param1Int) {
      try {
        InputStream inputStream = param1Resources.openRawResource(param1Int);
      } finally {
        param1File = null;
      } 
      if (param1Resources != null)
        try {
          param1Resources.close();
        } catch (IOException iOException) {} 
      throw param1File;
    }
    
    public static qg x0(ByteBuffer param1ByteBuffer) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual duplicate : ()Ljava/nio/ByteBuffer;
      //   4: astore_0
      //   5: aload_0
      //   6: getstatic java/nio/ByteOrder.BIG_ENDIAN : Ljava/nio/ByteOrder;
      //   9: invokevirtual order : (Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
      //   12: pop
      //   13: aload_0
      //   14: aload_0
      //   15: invokevirtual position : ()I
      //   18: iconst_4
      //   19: iadd
      //   20: invokevirtual position : (I)Ljava/nio/Buffer;
      //   23: pop
      //   24: aload_0
      //   25: invokevirtual getShort : ()S
      //   28: ldc_w 65535
      //   31: iand
      //   32: istore_3
      //   33: iload_3
      //   34: bipush #100
      //   36: if_icmpgt -> 293
      //   39: aload_0
      //   40: aload_0
      //   41: invokevirtual position : ()I
      //   44: bipush #6
      //   46: iadd
      //   47: invokevirtual position : (I)Ljava/nio/Buffer;
      //   50: pop
      //   51: iconst_0
      //   52: istore_2
      //   53: iconst_0
      //   54: istore_1
      //   55: iload_1
      //   56: iload_3
      //   57: if_icmpge -> 117
      //   60: aload_0
      //   61: invokevirtual getInt : ()I
      //   64: istore #4
      //   66: aload_0
      //   67: aload_0
      //   68: invokevirtual position : ()I
      //   71: iconst_4
      //   72: iadd
      //   73: invokevirtual position : (I)Ljava/nio/Buffer;
      //   76: pop
      //   77: aload_0
      //   78: invokevirtual getInt : ()I
      //   81: i2l
      //   82: ldc2_w 4294967295
      //   85: land
      //   86: lstore #5
      //   88: aload_0
      //   89: aload_0
      //   90: invokevirtual position : ()I
      //   93: iconst_4
      //   94: iadd
      //   95: invokevirtual position : (I)Ljava/nio/Buffer;
      //   98: pop
      //   99: ldc_w 1835365473
      //   102: iload #4
      //   104: if_icmpne -> 110
      //   107: goto -> 122
      //   110: iload_1
      //   111: iconst_1
      //   112: iadd
      //   113: istore_1
      //   114: goto -> 55
      //   117: ldc2_w -1
      //   120: lstore #5
      //   122: lload #5
      //   124: ldc2_w -1
      //   127: lcmp
      //   128: ifeq -> 282
      //   131: lload #5
      //   133: aload_0
      //   134: invokevirtual position : ()I
      //   137: i2l
      //   138: lsub
      //   139: l2i
      //   140: istore_1
      //   141: aload_0
      //   142: aload_0
      //   143: invokevirtual position : ()I
      //   146: iload_1
      //   147: iadd
      //   148: invokevirtual position : (I)Ljava/nio/Buffer;
      //   151: pop
      //   152: aload_0
      //   153: aload_0
      //   154: invokevirtual position : ()I
      //   157: bipush #12
      //   159: iadd
      //   160: invokevirtual position : (I)Ljava/nio/Buffer;
      //   163: pop
      //   164: aload_0
      //   165: invokevirtual getInt : ()I
      //   168: i2l
      //   169: lstore #7
      //   171: iload_2
      //   172: istore_1
      //   173: iload_1
      //   174: i2l
      //   175: lload #7
      //   177: ldc2_w 4294967295
      //   180: land
      //   181: lcmp
      //   182: ifge -> 282
      //   185: aload_0
      //   186: invokevirtual getInt : ()I
      //   189: istore_2
      //   190: aload_0
      //   191: invokevirtual getInt : ()I
      //   194: i2l
      //   195: lstore #9
      //   197: aload_0
      //   198: invokevirtual getInt : ()I
      //   201: pop
      //   202: ldc_w 1164798569
      //   205: iload_2
      //   206: if_icmpeq -> 226
      //   209: ldc_w 1701669481
      //   212: iload_2
      //   213: if_icmpne -> 219
      //   216: goto -> 226
      //   219: iload_1
      //   220: iconst_1
      //   221: iadd
      //   222: istore_1
      //   223: goto -> 173
      //   226: aload_0
      //   227: lload #9
      //   229: ldc2_w 4294967295
      //   232: land
      //   233: lload #5
      //   235: ladd
      //   236: l2i
      //   237: invokevirtual position : (I)Ljava/nio/Buffer;
      //   240: pop
      //   241: new qg
      //   244: dup
      //   245: invokespecial <init> : ()V
      //   248: astore #11
      //   250: aload_0
      //   251: getstatic java/nio/ByteOrder.LITTLE_ENDIAN : Ljava/nio/ByteOrder;
      //   254: invokevirtual order : (Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;
      //   257: pop
      //   258: aload_0
      //   259: aload_0
      //   260: invokevirtual position : ()I
      //   263: invokevirtual getInt : (I)I
      //   266: istore_1
      //   267: aload #11
      //   269: aload_0
      //   270: invokevirtual position : ()I
      //   273: iload_1
      //   274: iadd
      //   275: aload_0
      //   276: invokevirtual b : (ILjava/nio/ByteBuffer;)V
      //   279: aload #11
      //   281: areturn
      //   282: new java/io/IOException
      //   285: dup
      //   286: ldc_w 'Cannot read metadata.'
      //   289: invokespecial <init> : (Ljava/lang/String;)V
      //   292: athrow
      //   293: new java/io/IOException
      //   296: dup
      //   297: ldc_w 'Cannot read metadata.'
      //   300: invokespecial <init> : (Ljava/lang/String;)V
      //   303: astore_0
      //   304: goto -> 309
      //   307: aload_0
      //   308: athrow
      //   309: goto -> 307
    }
    
    public static boolean y(File param1File, InputStream param1InputStream) {
      // Byte code:
      //   0: invokestatic allowThreadDiskWrites : ()Landroid/os/StrictMode$ThreadPolicy;
      //   3: astore #5
      //   5: aconst_null
      //   6: astore #4
      //   8: aconst_null
      //   9: astore_3
      //   10: new java/io/FileOutputStream
      //   13: dup
      //   14: aload_0
      //   15: iconst_0
      //   16: invokespecial <init> : (Ljava/io/File;Z)V
      //   19: astore_0
      //   20: sipush #1024
      //   23: newarray byte
      //   25: astore_3
      //   26: aload_1
      //   27: aload_3
      //   28: invokevirtual read : ([B)I
      //   31: istore_2
      //   32: iload_2
      //   33: iconst_m1
      //   34: if_icmpeq -> 47
      //   37: aload_0
      //   38: aload_3
      //   39: iconst_0
      //   40: iload_2
      //   41: invokevirtual write : ([BII)V
      //   44: goto -> 26
      //   47: aload_0
      //   48: invokevirtual close : ()V
      //   51: aload #5
      //   53: invokestatic setThreadPolicy : (Landroid/os/StrictMode$ThreadPolicy;)V
      //   56: iconst_1
      //   57: ireturn
      //   58: astore_1
      //   59: aload_0
      //   60: astore_3
      //   61: aload_1
      //   62: astore_0
      //   63: goto -> 102
      //   66: astore_1
      //   67: goto -> 78
      //   70: astore_0
      //   71: goto -> 102
      //   74: astore_1
      //   75: aload #4
      //   77: astore_0
      //   78: aload_0
      //   79: astore_3
      //   80: aload_1
      //   81: invokevirtual getMessage : ()Ljava/lang/String;
      //   84: pop
      //   85: aload_0
      //   86: ifnull -> 95
      //   89: aload_0
      //   90: invokeinterface close : ()V
      //   95: aload #5
      //   97: invokestatic setThreadPolicy : (Landroid/os/StrictMode$ThreadPolicy;)V
      //   100: iconst_0
      //   101: ireturn
      //   102: aload_3
      //   103: ifnull -> 112
      //   106: aload_3
      //   107: invokeinterface close : ()V
      //   112: aload #5
      //   114: invokestatic setThreadPolicy : (Landroid/os/StrictMode$ThreadPolicy;)V
      //   117: goto -> 122
      //   120: aload_0
      //   121: athrow
      //   122: goto -> 120
      //   125: astore_0
      //   126: goto -> 51
      //   129: astore_0
      //   130: goto -> 95
      //   133: astore_1
      //   134: goto -> 112
      // Exception table:
      //   from	to	target	type
      //   10	20	74	java/io/IOException
      //   10	20	70	finally
      //   20	26	66	java/io/IOException
      //   20	26	58	finally
      //   26	32	66	java/io/IOException
      //   26	32	58	finally
      //   37	44	66	java/io/IOException
      //   37	44	58	finally
      //   47	51	125	java/io/IOException
      //   80	85	70	finally
      //   89	95	129	java/io/IOException
      //   106	112	133	java/io/IOException
    }
    
    public static List<List<byte[]>> y0(Resources param1Resources, int param1Int) {
      int i;
      ArrayList<List<byte[]>> arrayList;
      if (param1Int == 0)
        return Collections.emptyList(); 
      TypedArray typedArray = param1Resources.obtainTypedArray(param1Int);
      try {
        if (typedArray.length() == 0)
          return (List)Collections.emptyList(); 
        arrayList = new ArrayList();
      } finally {
        typedArray.recycle();
      } 
      if (i == 1)
        for (param1Int = 0;; param1Int++) {
          if (param1Int < typedArray.length()) {
            i = typedArray.getResourceId(param1Int, 0);
            if (i != 0)
              arrayList.add(S0(param1Resources.getStringArray(i))); 
          } else {
            typedArray.recycle();
            return arrayList;
          } 
        }  
      arrayList.add(S0(param1Resources.getStringArray(param1Int)));
      typedArray.recycle();
      return arrayList;
    }
    
    public static Interpolator z(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      if (Build.VERSION.SDK_INT >= 21)
        return (Interpolator)new PathInterpolator(param1Float1, param1Float2, param1Float3, param1Float4); 
      Path path = new Path();
      path.moveTo(0.0F, 0.0F);
      path.cubicTo(param1Float1, param1Float2, param1Float3, param1Float4, 1.0F, 1.0F);
      return (Interpolator)new re(path);
    }
    
    public static void z0(CompoundButton param1CompoundButton, ColorStateList param1ColorStateList) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1CompoundButton.setButtonTintList(param1ColorStateList);
        return;
      } 
      if (param1CompoundButton instanceof hf)
        ((hf)param1CompoundButton).setSupportButtonTintList(param1ColorStateList); 
    }
  }
  
  public static final class d {
    public Object a;
    
    public qk b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */