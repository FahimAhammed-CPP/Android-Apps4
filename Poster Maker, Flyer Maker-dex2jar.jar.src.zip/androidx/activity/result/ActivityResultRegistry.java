package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import k;
import l;
import m;
import p;
import qj;
import s30;
import tj;
import u9;
import uj;
import vj;
import wj;

public abstract class ActivityResultRegistry {
  public Random a = new Random();
  
  public final Map<Integer, String> b = new HashMap<Integer, String>();
  
  public final Map<String, Integer> c = new HashMap<String, Integer>();
  
  public final Map<String, d> d = new HashMap<String, d>();
  
  public ArrayList<String> e = new ArrayList<String>();
  
  public final transient Map<String, c<?>> f = new HashMap<String, c<?>>();
  
  public final Map<String, Object> g = new HashMap<String, Object>();
  
  public final Bundle h = new Bundle();
  
  public final boolean a(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    c c = this.f.get(str);
    if (c != null && c.a != null && this.e.contains(str)) {
      c.a.a(c.b.c(paramInt2, paramIntent));
      this.e.remove(str);
    } else {
      this.g.remove(str);
      this.h.putParcelable(str, (Parcelable)new k(paramInt2, paramIntent));
    } 
    return true;
  }
  
  public abstract <I, O> void b(int paramInt, p<I, O> paramp, @SuppressLint({"UnknownNullness"}) I paramI, u9 paramu9);
  
  public final <I, O> m<I> c(String paramString, p<I, O> paramp, l<O> paraml) {
    e(paramString);
    this.f.put(paramString, new c(paraml, paramp));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      paraml.a(object);
    } 
    k k = (k)this.h.getParcelable(paramString);
    if (k != null) {
      this.h.remove(paramString);
      paraml.a(paramp.c(k.b, k.c));
    } 
    return new b(this, paramString, paramp);
  }
  
  public final <I, O> m<I> d(String paramString, vj paramvj, p<I, O> paramp, l<O> paraml) {
    d d1;
    d d2;
    qj qj = paramvj.getLifecycle();
    wj wj = (wj)qj;
    if (!wj.b.isAtLeast(qj.b.STARTED)) {
      e(paramString);
      d2 = this.d.get(paramString);
      d1 = d2;
      if (d2 == null)
        d1 = new d(qj); 
      tj tj = new tj(this, paramString, paraml, paramp) {
          public void c(vj param1vj, qj.a param1a) {
            if (qj.a.ON_START.equals(param1a)) {
              this.d.f.put(this.a, new ActivityResultRegistry.c(this.b, this.c));
              if (this.d.g.containsKey(this.a)) {
                param1vj = (vj)this.d.g.get(this.a);
                this.d.g.remove(this.a);
                this.b.a(param1vj);
              } 
              k k = (k)this.d.h.getParcelable(this.a);
              if (k != null) {
                this.d.h.remove(this.a);
                this.b.a(this.c.c(k.b, k.c));
                return;
              } 
            } else {
              if (qj.a.ON_STOP.equals(param1a)) {
                this.d.f.remove(this.a);
                return;
              } 
              if (qj.a.ON_DESTROY.equals(param1a))
                this.d.f(this.a); 
            } 
          }
        };
      d1.a.a((uj)tj);
      d1.b.add(tj);
      this.d.put(paramString, d1);
      return new a(this, paramString, paramp);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LifecycleOwner ");
    stringBuilder.append(d1);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(((wj)d2).b);
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final void e(String paramString) {
    if ((Integer)this.c.get(paramString) != null)
      return; 
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      this.b.put(Integer.valueOf(i), paramString);
      this.c.put(paramString, Integer.valueOf(i));
      return;
    } 
  }
  
  public final void f(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = s30.E0("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.g.get(paramString));
      stringBuilder.toString();
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = s30.E0("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      stringBuilder.toString();
      this.h.remove(paramString);
    } 
    d d = this.d.get(paramString);
    if (d != null) {
      for (tj tj : d.b)
        d.a.b((uj)tj); 
      d.b.clear();
      this.d.remove(paramString);
    } 
  }
  
  public class a extends m<I> {
    public a(ActivityResultRegistry this$0, String param1String, p param1p) {}
    
    public void a(I param1I, u9 param1u9) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.b(integer.intValue(), this.b, param1I, param1u9);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = s30.x0("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void b() {
      this.c.f(this.a);
    }
  }
  
  public class b extends m<I> {
    public b(ActivityResultRegistry this$0, String param1String, p param1p) {}
    
    public void a(I param1I, u9 param1u9) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        this.c.b(integer.intValue(), this.b, param1I, param1u9);
        return;
      } 
      StringBuilder stringBuilder = s30.x0("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(param1I);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void b() {
      this.c.f(this.a);
    }
  }
  
  public static class c<O> {
    public final l<O> a;
    
    public final p<?, O> b;
    
    public c(l<O> param1l, p<?, O> param1p) {
      this.a = param1l;
      this.b = param1p;
    }
  }
  
  public static class d {
    public final qj a;
    
    public final ArrayList<tj> b;
    
    public d(qj param1qj) {
      this.a = param1qj;
      this.b = new ArrayList<tj>();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */