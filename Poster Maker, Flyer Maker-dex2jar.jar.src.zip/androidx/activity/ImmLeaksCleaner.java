package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import java.lang.reflect.Field;
import qj;
import tj;
import vj;

public final class ImmLeaksCleaner implements tj {
  public static int a;
  
  public static Field b;
  
  public static Field c;
  
  public static Field d;
  
  public Activity e;
  
  public ImmLeaksCleaner(Activity paramActivity) {
    this.e = paramActivity;
  }
  
  public void c(vj paramvj, qj.a parama) {
    if (parama != qj.a.ON_DESTROY)
      return; 
    if (a == 0)
      try {
        a = 2;
        Field field = InputMethodManager.class.getDeclaredField("mServedView");
        c = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mNextServedView");
        d = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mH");
        b = field;
        field.setAccessible(true);
        a = 1;
      } catch (NoSuchFieldException noSuchFieldException) {} 
    if (a == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.e.getSystemService("input_method");
      try {
        Object object = b.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)c.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            d.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */