package androidx.activity;

import f;
import g;
import java.util.ArrayDeque;
import java.util.Iterator;
import qj;
import tj;
import uj;
import vj;
import wj;

public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final ArrayDeque<g> b = new ArrayDeque<g>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a() {
    Iterator<g> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      g g = iterator.next();
      if (g.a) {
        g.a();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public class LifecycleOnBackPressedCancellable implements tj, f {
    public final qj a;
    
    public final g b;
    
    public f c;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, qj param1qj, g param1g) {
      this.a = param1qj;
      this.b = param1g;
      param1qj.a((uj)this);
    }
    
    public void c(vj param1vj, qj.a param1a) {
      OnBackPressedDispatcher.a a1;
      if (param1a == qj.a.ON_START) {
        OnBackPressedDispatcher onBackPressedDispatcher = this.d;
        g g1 = this.b;
        onBackPressedDispatcher.b.add(g1);
        a1 = new OnBackPressedDispatcher.a(onBackPressedDispatcher, g1);
        g1.b.add(a1);
        this.c = a1;
        return;
      } 
      if (a1 == qj.a.ON_STOP) {
        f f1 = this.c;
        if (f1 != null) {
          f1.cancel();
          return;
        } 
      } else if (a1 == qj.a.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      wj wj = (wj)this.a;
      wj.d("removeObserver");
      wj.a.e(this);
      this.b.b.remove(this);
      f f1 = this.c;
      if (f1 != null) {
        f1.cancel();
        this.c = null;
      } 
    }
  }
  
  public class a implements f {
    public final g a;
    
    public a(OnBackPressedDispatcher this$0, g param1g) {
      this.a = param1g;
    }
    
    public void cancel() {
      this.b.b.remove(this.a);
      this.a.b.remove(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */