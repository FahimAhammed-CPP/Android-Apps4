package androidx.startup;

import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import ho;
import io;
import java.util.HashSet;
import java.util.Objects;
import jo;
import ko;

public final class InitializationProvider extends ContentProvider {
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public boolean onCreate() {
    Context context = getContext();
    if (context != null) {
      ho ho = ho.b(context);
      Objects.requireNonNull(ho);
      try {
        Trace.beginSection("Startup");
        ComponentName componentName = new ComponentName(ho.e.getPackageName(), InitializationProvider.class.getName());
        Bundle bundle = (ho.e.getPackageManager().getProviderInfo(componentName, 128)).metaData;
        String str = ho.e.getString(jo.androidx_startup);
        if (bundle != null) {
          HashSet hashSet = new HashSet();
          for (String str1 : bundle.keySet()) {
            if (str.equals(bundle.getString(str1, null))) {
              Class<?> clazz = Class.forName(str1);
              if (io.class.isAssignableFrom(clazz)) {
                ho.d.add(clazz);
                ho.a(clazz, hashSet);
              } 
            } 
          } 
        } 
        Trace.endSection();
        return true;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      
      } catch (ClassNotFoundException classNotFoundException) {
      
      } finally {}
      throw new ko(ho);
    } 
    ko ko = new ko("Context cannot be null");
    throw ko;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */