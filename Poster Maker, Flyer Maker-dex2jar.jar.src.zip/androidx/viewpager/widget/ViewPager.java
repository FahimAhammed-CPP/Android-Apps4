package androidx.viewpager.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import fe;
import hd;
import hq;
import iq;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import ma;
import nf;
import oe;
import s30;
import vd;

public class ViewPager extends ViewGroup {
  public static final int[] b = new int[] { 16842931 };
  
  public static final Comparator<e> c = new a();
  
  public static final Interpolator d = new b();
  
  public static final l f = new l();
  
  public int A;
  
  public Drawable B;
  
  public int C;
  
  public int D;
  
  public float E = -3.4028235E38F;
  
  public float F = Float.MAX_VALUE;
  
  public int G;
  
  public boolean H;
  
  public boolean I;
  
  public boolean J;
  
  public int K = 1;
  
  public boolean L;
  
  public boolean M;
  
  public int N;
  
  public int O;
  
  public int P;
  
  public float Q;
  
  public float R;
  
  public float S;
  
  public float T;
  
  public int U = -1;
  
  public VelocityTracker V;
  
  public int W;
  
  public int a0;
  
  public int b0;
  
  public int c0;
  
  public EdgeEffect d0;
  
  public EdgeEffect e0;
  
  public boolean f0 = true;
  
  public int g;
  
  public boolean g0;
  
  public int h0;
  
  public List<i> i0;
  
  public i j0;
  
  public List<h> k0;
  
  public final Runnable l0 = new c(this);
  
  public int m0 = 0;
  
  public final ArrayList<e> p = new ArrayList<e>();
  
  public final e q = new e();
  
  public final Rect r = new Rect();
  
  public hq s;
  
  public int t;
  
  public int u = -1;
  
  public Parcelable v = null;
  
  public ClassLoader w = null;
  
  public Scroller x;
  
  public boolean y;
  
  public j z;
  
  public ViewPager(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    paramContext = getContext();
    this.x = new Scroller(paramContext, d);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.P = viewConfiguration.getScaledPagingTouchSlop();
    this.W = (int)(400.0F * f);
    this.a0 = viewConfiguration.getScaledMaximumFlingVelocity();
    this.d0 = new EdgeEffect(paramContext);
    this.e0 = new EdgeEffect(paramContext);
    this.b0 = (int)(25.0F * f);
    this.c0 = (int)(2.0F * f);
    this.N = (int)(f * 16.0F);
    fe.C((View)this, new g(this));
    if (fe.d.c((View)this) == 0)
      fe.d.s((View)this, 1); 
    fe.G((View)this, (vd)new iq(this));
  }
  
  private int getClientWidth() {
    return getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean) {
    if (this.I != paramBoolean)
      this.I = paramBoolean; 
  }
  
  public e a(int paramInt1, int paramInt2) {
    e e1 = new e();
    e1.b = paramInt1;
    e1.a = this.s.instantiateItem(this, paramInt1);
    e1.d = this.s.getPageWidth(paramInt1);
    if (paramInt2 < 0 || paramInt2 >= this.p.size()) {
      this.p.add(e1);
      return e1;
    } 
    this.p.add(paramInt2, e1);
    return e1;
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    int k = paramArrayList.size();
    int m = getDescendantFocusability();
    if (m != 393216) {
      int n;
      for (n = 0; n < getChildCount(); n++) {
        View view = getChildAt(n);
        if (view.getVisibility() == 0) {
          e e1 = i(view);
          if (e1 != null && e1.b == this.t)
            view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        } 
      } 
    } 
    if (m != 262144 || k == paramArrayList.size()) {
      if (!isFocusable())
        return; 
      if ((paramInt2 & 0x1) == 1 && isInTouchMode() && !isFocusableInTouchMode())
        return; 
      paramArrayList.add(this);
    } 
  }
  
  public void addTouchables(ArrayList<View> paramArrayList) {
    for (int k = 0; k < getChildCount(); k++) {
      View view = getChildAt(k);
      if (view.getVisibility() == 0) {
        e e1 = i(view);
        if (e1 != null && e1.b == this.t)
          view.addTouchables(paramArrayList); 
      } 
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool1;
    ViewGroup.LayoutParams layoutParams = paramLayoutParams;
    if (!checkLayoutParams(paramLayoutParams))
      layoutParams = generateLayoutParams(paramLayoutParams); 
    paramLayoutParams = layoutParams;
    boolean bool2 = ((f)paramLayoutParams).a;
    if (paramView.getClass().getAnnotation(d.class) != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    bool2 |= bool1;
    ((f)paramLayoutParams).a = bool2;
    if (this.H) {
      if (!bool2) {
        ((f)paramLayoutParams).d = true;
        addViewInLayout(paramView, paramInt, layoutParams);
        return;
      } 
      throw new IllegalStateException("Cannot add pager decor view during layout");
    } 
    super.addView(paramView, paramInt, layoutParams);
  }
  
  public void b(i parami) {
    if (this.i0 == null)
      this.i0 = new ArrayList<i>(); 
    this.i0.add(parami);
  }
  
  public boolean c(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual findFocus : ()Landroid/view/View;
    //   4: astore #6
    //   6: iconst_0
    //   7: istore #4
    //   9: aload #6
    //   11: aload_0
    //   12: if_acmpne -> 21
    //   15: aconst_null
    //   16: astore #5
    //   18: goto -> 160
    //   21: aload #6
    //   23: astore #5
    //   25: aload #6
    //   27: ifnull -> 160
    //   30: aload #6
    //   32: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   35: astore #5
    //   37: aload #5
    //   39: instanceof android/view/ViewGroup
    //   42: ifeq -> 68
    //   45: aload #5
    //   47: aload_0
    //   48: if_acmpne -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 70
    //   56: aload #5
    //   58: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   63: astore #5
    //   65: goto -> 37
    //   68: iconst_0
    //   69: istore_2
    //   70: aload #6
    //   72: astore #5
    //   74: iload_2
    //   75: ifne -> 160
    //   78: new java/lang/StringBuilder
    //   81: dup
    //   82: invokespecial <init> : ()V
    //   85: astore #7
    //   87: aload #7
    //   89: aload #6
    //   91: invokevirtual getClass : ()Ljava/lang/Class;
    //   94: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload #6
    //   103: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   106: astore #5
    //   108: aload #5
    //   110: instanceof android/view/ViewGroup
    //   113: ifeq -> 151
    //   116: aload #7
    //   118: ldc_w ' => '
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: pop
    //   125: aload #7
    //   127: aload #5
    //   129: invokevirtual getClass : ()Ljava/lang/Class;
    //   132: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   138: pop
    //   139: aload #5
    //   141: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   146: astore #5
    //   148: goto -> 108
    //   151: aload #7
    //   153: invokevirtual toString : ()Ljava/lang/String;
    //   156: pop
    //   157: goto -> 15
    //   160: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   163: aload_0
    //   164: aload #5
    //   166: iload_1
    //   167: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   170: astore #6
    //   172: aload #6
    //   174: ifnull -> 310
    //   177: aload #6
    //   179: aload #5
    //   181: if_acmpeq -> 310
    //   184: iload_1
    //   185: bipush #17
    //   187: if_icmpne -> 247
    //   190: aload_0
    //   191: aload_0
    //   192: getfield r : Landroid/graphics/Rect;
    //   195: aload #6
    //   197: invokevirtual h : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   200: getfield left : I
    //   203: istore_2
    //   204: aload_0
    //   205: aload_0
    //   206: getfield r : Landroid/graphics/Rect;
    //   209: aload #5
    //   211: invokevirtual h : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   214: getfield left : I
    //   217: istore_3
    //   218: aload #5
    //   220: ifnull -> 237
    //   223: iload_2
    //   224: iload_3
    //   225: if_icmplt -> 237
    //   228: aload_0
    //   229: invokevirtual n : ()Z
    //   232: istore #4
    //   234: goto -> 244
    //   237: aload #6
    //   239: invokevirtual requestFocus : ()Z
    //   242: istore #4
    //   244: goto -> 350
    //   247: iload_1
    //   248: bipush #66
    //   250: if_icmpne -> 350
    //   253: aload_0
    //   254: aload_0
    //   255: getfield r : Landroid/graphics/Rect;
    //   258: aload #6
    //   260: invokevirtual h : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   263: getfield left : I
    //   266: istore_2
    //   267: aload_0
    //   268: aload_0
    //   269: getfield r : Landroid/graphics/Rect;
    //   272: aload #5
    //   274: invokevirtual h : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   277: getfield left : I
    //   280: istore_3
    //   281: aload #5
    //   283: ifnull -> 300
    //   286: iload_2
    //   287: iload_3
    //   288: if_icmpgt -> 300
    //   291: aload_0
    //   292: invokevirtual o : ()Z
    //   295: istore #4
    //   297: goto -> 244
    //   300: aload #6
    //   302: invokevirtual requestFocus : ()Z
    //   305: istore #4
    //   307: goto -> 244
    //   310: iload_1
    //   311: bipush #17
    //   313: if_icmpeq -> 344
    //   316: iload_1
    //   317: iconst_1
    //   318: if_icmpne -> 324
    //   321: goto -> 344
    //   324: iload_1
    //   325: bipush #66
    //   327: if_icmpeq -> 335
    //   330: iload_1
    //   331: iconst_2
    //   332: if_icmpne -> 350
    //   335: aload_0
    //   336: invokevirtual o : ()Z
    //   339: istore #4
    //   341: goto -> 350
    //   344: aload_0
    //   345: invokevirtual n : ()Z
    //   348: istore #4
    //   350: iload #4
    //   352: ifeq -> 363
    //   355: aload_0
    //   356: iload_1
    //   357: invokestatic getContantForFocusDirection : (I)I
    //   360: invokevirtual playSoundEffect : (I)V
    //   363: iload #4
    //   365: ireturn
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    hq hq1 = this.s;
    boolean bool2 = false;
    boolean bool1 = false;
    if (hq1 == null)
      return false; 
    int k = getClientWidth();
    int m = getScrollX();
    if (paramInt < 0) {
      if (m > (int)(k * this.E))
        bool1 = true; 
      return bool1;
    } 
    bool1 = bool2;
    if (paramInt > 0) {
      bool1 = bool2;
      if (m < (int)(k * this.F))
        bool1 = true; 
    } 
    return bool1;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    this.y = true;
    if (!this.x.isFinished() && this.x.computeScrollOffset()) {
      int k = getScrollX();
      int m = getScrollY();
      int n = this.x.getCurrX();
      int i1 = this.x.getCurrY();
      if (k != n || m != i1) {
        scrollTo(n, i1);
        if (!p(n)) {
          this.x.abortAnimation();
          scrollTo(0, i1);
        } 
      } 
      AtomicInteger atomicInteger = fe.a;
      fe.d.k((View)this);
      return;
    } 
    e(true);
  }
  
  public boolean d(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int m = paramView.getScrollX();
      int n = paramView.getScrollY();
      int k;
      for (k = viewGroup.getChildCount() - 1; k >= 0; k--) {
        View view = viewGroup.getChildAt(k);
        int i1 = paramInt2 + m;
        if (i1 >= view.getLeft() && i1 < view.getRight()) {
          int i2 = paramInt3 + n;
          if (i2 >= view.getTop() && i2 < view.getBottom() && d(view, true, paramInt1, i1 - view.getLeft(), i2 - view.getTop()))
            return true; 
        } 
      } 
    } 
    return (paramBoolean && paramView.canScrollHorizontally(-paramInt1));
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial dispatchKeyEvent : (Landroid/view/KeyEvent;)Z
    //   5: istore_3
    //   6: iconst_0
    //   7: istore #4
    //   9: iload_3
    //   10: ifne -> 137
    //   13: aload_1
    //   14: invokevirtual getAction : ()I
    //   17: ifne -> 131
    //   20: aload_1
    //   21: invokevirtual getKeyCode : ()I
    //   24: istore_2
    //   25: iload_2
    //   26: bipush #21
    //   28: if_icmpeq -> 105
    //   31: iload_2
    //   32: bipush #22
    //   34: if_icmpeq -> 79
    //   37: iload_2
    //   38: bipush #61
    //   40: if_icmpeq -> 46
    //   43: goto -> 131
    //   46: aload_1
    //   47: invokevirtual hasNoModifiers : ()Z
    //   50: ifeq -> 62
    //   53: aload_0
    //   54: iconst_2
    //   55: invokevirtual c : (I)Z
    //   58: istore_3
    //   59: goto -> 133
    //   62: aload_1
    //   63: iconst_1
    //   64: invokevirtual hasModifiers : (I)Z
    //   67: ifeq -> 131
    //   70: aload_0
    //   71: iconst_1
    //   72: invokevirtual c : (I)Z
    //   75: istore_3
    //   76: goto -> 133
    //   79: aload_1
    //   80: iconst_2
    //   81: invokevirtual hasModifiers : (I)Z
    //   84: ifeq -> 95
    //   87: aload_0
    //   88: invokevirtual o : ()Z
    //   91: istore_3
    //   92: goto -> 133
    //   95: aload_0
    //   96: bipush #66
    //   98: invokevirtual c : (I)Z
    //   101: istore_3
    //   102: goto -> 133
    //   105: aload_1
    //   106: iconst_2
    //   107: invokevirtual hasModifiers : (I)Z
    //   110: ifeq -> 121
    //   113: aload_0
    //   114: invokevirtual n : ()Z
    //   117: istore_3
    //   118: goto -> 133
    //   121: aload_0
    //   122: bipush #17
    //   124: invokevirtual c : (I)Z
    //   127: istore_3
    //   128: goto -> 133
    //   131: iconst_0
    //   132: istore_3
    //   133: iload_3
    //   134: ifeq -> 140
    //   137: iconst_1
    //   138: istore #4
    //   140: iload #4
    //   142: ireturn
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 4096)
      return super.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent); 
    int m = getChildCount();
    for (int k = 0; k < m; k++) {
      View view = getChildAt(k);
      if (view.getVisibility() == 0) {
        e e1 = i(view);
        if (e1 != null && e1.b == this.t && view.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))
          return true; 
      } 
    } 
    return false;
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: invokevirtual getOverScrollMode : ()I
    //   9: istore #4
    //   11: iconst_0
    //   12: istore_3
    //   13: iconst_0
    //   14: istore_2
    //   15: iload #4
    //   17: ifeq -> 66
    //   20: iload #4
    //   22: iconst_1
    //   23: if_icmpne -> 49
    //   26: aload_0
    //   27: getfield s : Lhq;
    //   30: astore #8
    //   32: aload #8
    //   34: ifnull -> 49
    //   37: aload #8
    //   39: invokevirtual getCount : ()I
    //   42: iconst_1
    //   43: if_icmple -> 49
    //   46: goto -> 66
    //   49: aload_0
    //   50: getfield d0 : Landroid/widget/EdgeEffect;
    //   53: invokevirtual finish : ()V
    //   56: aload_0
    //   57: getfield e0 : Landroid/widget/EdgeEffect;
    //   60: invokevirtual finish : ()V
    //   63: goto -> 260
    //   66: aload_0
    //   67: getfield d0 : Landroid/widget/EdgeEffect;
    //   70: invokevirtual isFinished : ()Z
    //   73: ifne -> 159
    //   76: aload_1
    //   77: invokevirtual save : ()I
    //   80: istore_3
    //   81: aload_0
    //   82: invokevirtual getHeight : ()I
    //   85: aload_0
    //   86: invokevirtual getPaddingTop : ()I
    //   89: isub
    //   90: aload_0
    //   91: invokevirtual getPaddingBottom : ()I
    //   94: isub
    //   95: istore_2
    //   96: aload_0
    //   97: invokevirtual getWidth : ()I
    //   100: istore #4
    //   102: aload_1
    //   103: ldc_w 270.0
    //   106: invokevirtual rotate : (F)V
    //   109: iload_2
    //   110: ineg
    //   111: istore #5
    //   113: aload_1
    //   114: aload_0
    //   115: invokevirtual getPaddingTop : ()I
    //   118: iload #5
    //   120: iadd
    //   121: i2f
    //   122: aload_0
    //   123: getfield E : F
    //   126: iload #4
    //   128: i2f
    //   129: fmul
    //   130: invokevirtual translate : (FF)V
    //   133: aload_0
    //   134: getfield d0 : Landroid/widget/EdgeEffect;
    //   137: iload_2
    //   138: iload #4
    //   140: invokevirtual setSize : (II)V
    //   143: iconst_0
    //   144: aload_0
    //   145: getfield d0 : Landroid/widget/EdgeEffect;
    //   148: aload_1
    //   149: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   152: ior
    //   153: istore_2
    //   154: aload_1
    //   155: iload_3
    //   156: invokevirtual restoreToCount : (I)V
    //   159: iload_2
    //   160: istore_3
    //   161: aload_0
    //   162: getfield e0 : Landroid/widget/EdgeEffect;
    //   165: invokevirtual isFinished : ()Z
    //   168: ifne -> 260
    //   171: aload_1
    //   172: invokevirtual save : ()I
    //   175: istore #4
    //   177: aload_0
    //   178: invokevirtual getWidth : ()I
    //   181: istore_3
    //   182: aload_0
    //   183: invokevirtual getHeight : ()I
    //   186: istore #5
    //   188: aload_0
    //   189: invokevirtual getPaddingTop : ()I
    //   192: istore #6
    //   194: aload_0
    //   195: invokevirtual getPaddingBottom : ()I
    //   198: istore #7
    //   200: aload_1
    //   201: ldc_w 90.0
    //   204: invokevirtual rotate : (F)V
    //   207: aload_1
    //   208: aload_0
    //   209: invokevirtual getPaddingTop : ()I
    //   212: ineg
    //   213: i2f
    //   214: aload_0
    //   215: getfield F : F
    //   218: fconst_1
    //   219: fadd
    //   220: fneg
    //   221: iload_3
    //   222: i2f
    //   223: fmul
    //   224: invokevirtual translate : (FF)V
    //   227: aload_0
    //   228: getfield e0 : Landroid/widget/EdgeEffect;
    //   231: iload #5
    //   233: iload #6
    //   235: isub
    //   236: iload #7
    //   238: isub
    //   239: iload_3
    //   240: invokevirtual setSize : (II)V
    //   243: iload_2
    //   244: aload_0
    //   245: getfield e0 : Landroid/widget/EdgeEffect;
    //   248: aload_1
    //   249: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   252: ior
    //   253: istore_3
    //   254: aload_1
    //   255: iload #4
    //   257: invokevirtual restoreToCount : (I)V
    //   260: iload_3
    //   261: ifeq -> 272
    //   264: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   267: astore_1
    //   268: aload_0
    //   269: invokestatic k : (Landroid/view/View;)V
    //   272: return
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.B;
    if (drawable != null && drawable.isStateful())
      drawable.setState(getDrawableState()); 
  }
  
  public final void e(boolean paramBoolean) {
    boolean bool;
    if (this.m0 == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      setScrollingCacheEnabled(false);
      if ((this.x.isFinished() ^ true) != 0) {
        this.x.abortAnimation();
        int m = getScrollX();
        int n = getScrollY();
        int i1 = this.x.getCurrX();
        int i2 = this.x.getCurrY();
        if (m != i1 || n != i2) {
          scrollTo(i1, i2);
          if (i1 != m)
            p(i1); 
        } 
      } 
    } 
    this.J = false;
    for (int k = 0; k < this.p.size(); k++) {
      e e1 = this.p.get(k);
      if (e1.c) {
        e1.c = false;
        bool = true;
      } 
    } 
    if (bool) {
      if (paramBoolean) {
        Runnable runnable = this.l0;
        AtomicInteger atomicInteger = fe.a;
        fe.d.m((View)this, runnable);
        return;
      } 
      this.l0.run();
    } 
  }
  
  public void f() {
    Object object1;
    int k;
    Object object2;
    int n;
    boolean bool2;
    int i2 = this.s.getCount();
    this.g = i2;
    if (this.p.size() < this.K * 2 + 1 && this.p.size() < i2) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    int m = this.t;
    int i1 = 0;
    boolean bool1 = false;
    while (i1 < this.p.size()) {
      e e1 = this.p.get(i1);
      int i6 = this.s.getItemPosition(e1.a);
      if (i6 == -1) {
        Object object3 = object1;
        int i7 = i1;
        Object object4 = object2;
        continue;
      } 
      if (i6 == -2) {
        byte b;
        this.p.remove(i1);
        int i7 = i1 - 1;
        Object object = object2;
        if (object2 == null) {
          this.s.startUpdate(this);
          b = 1;
        } 
        this.s.destroyItem(this, e1.b, e1.a);
        int i8 = this.t;
        i1 = i7;
        n = b;
        if (i8 == e1.b) {
          k = Math.max(0, Math.min(i8, i2 - 1));
          n = b;
          i1 = i7;
        } 
      } else {
        int i10 = e1.b;
        int i7 = k;
        int i9 = i1;
        int i8 = n;
        if (i10 != i6) {
          if (i10 == this.t)
            k = i6; 
          e1.b = i6;
        } else {
          continue;
        } 
      } 
      bool2 = true;
      int i3 = k;
      int i5 = i1;
      int i4 = n;
      continue;
      i1 = SYNTHETIC_LOCAL_VARIABLE_7 + 1;
      object1 = SYNTHETIC_LOCAL_VARIABLE_5;
      object2 = SYNTHETIC_LOCAL_VARIABLE_6;
    } 
    if (n)
      this.s.finishUpdate(this); 
    Collections.sort(this.p, c);
    if (bool2) {
      i1 = getChildCount();
      for (n = 0; n < i1; n++) {
        f f = (f)getChildAt(n).getLayoutParams();
        if (!f.a)
          f.c = 0.0F; 
      } 
      x(k, false, true, 0);
      requestLayout();
    } 
  }
  
  public final void g(int paramInt) {
    i i1 = this.j0;
    if (i1 != null)
      i1.onPageSelected(paramInt); 
    List<i> list = this.i0;
    if (list != null) {
      int k = 0;
      int m = list.size();
      while (k < m) {
        i i2 = this.i0.get(k);
        if (i2 != null)
          i2.onPageSelected(paramInt); 
        k++;
      } 
    } 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new f();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new f(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return generateDefaultLayoutParams();
  }
  
  public hq getAdapter() {
    return this.s;
  }
  
  public int getChildDrawingOrder(int paramInt1, int paramInt2) {
    throw null;
  }
  
  public int getCurrentItem() {
    return this.t;
  }
  
  public int getOffscreenPageLimit() {
    return this.K;
  }
  
  public int getPageMargin() {
    return this.A;
  }
  
  public final Rect h(Rect paramRect, View paramView) {
    Rect rect = paramRect;
    if (paramRect == null)
      rect = new Rect(); 
    if (paramView == null) {
      rect.set(0, 0, 0, 0);
      return rect;
    } 
    rect.left = paramView.getLeft();
    rect.right = paramView.getRight();
    rect.top = paramView.getTop();
    rect.bottom = paramView.getBottom();
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof ViewGroup && viewParent != this) {
      ViewGroup viewGroup = (ViewGroup)viewParent;
      int k = rect.left;
      rect.left = viewGroup.getLeft() + k;
      k = rect.right;
      rect.right = viewGroup.getRight() + k;
      k = rect.top;
      rect.top = viewGroup.getTop() + k;
      k = rect.bottom;
      rect.bottom = viewGroup.getBottom() + k;
      ViewParent viewParent1 = viewGroup.getParent();
    } 
    return rect;
  }
  
  public e i(View paramView) {
    for (int k = 0; k < this.p.size(); k++) {
      e e1 = this.p.get(k);
      if (this.s.isViewFromObject(paramView, e1.a))
        return e1; 
    } 
    return null;
  }
  
  public final e j() {
    float f1;
    float f2;
    int k = getClientWidth();
    float f3 = 0.0F;
    if (k > 0) {
      f1 = getScrollX() / k;
    } else {
      f1 = 0.0F;
    } 
    if (k > 0) {
      f2 = this.A / k;
    } else {
      f2 = 0.0F;
    } 
    e e1 = null;
    float f4 = 0.0F;
    int m = -1;
    k = 0;
    boolean bool = true;
    while (k < this.p.size()) {
      e e3 = this.p.get(k);
      int n = k;
      e e2 = e3;
      if (!bool) {
        int i1 = e3.b;
        m++;
        n = k;
        e2 = e3;
        if (i1 != m) {
          e2 = this.q;
          e2.e = f3 + f4 + f2;
          e2.b = m;
          e2.d = this.s.getPageWidth(m);
          n = k - 1;
        } 
      } 
      f3 = e2.e;
      f4 = e2.d;
      if (bool || f1 >= f3) {
        if (f1 >= f4 + f3 + f2) {
          if (n == this.p.size() - 1)
            return e2; 
          m = e2.b;
          f4 = e2.d;
          k = n + 1;
          bool = false;
          e1 = e2;
          continue;
        } 
        return e2;
      } 
      return e1;
    } 
    return e1;
  }
  
  public e k(int paramInt) {
    for (int k = 0; k < this.p.size(); k++) {
      e e1 = this.p.get(k);
      if (e1.b == paramInt)
        return e1; 
    } 
    return null;
  }
  
  public void l(int paramInt1, float paramFloat, int paramInt2) {
    int k = this.h0;
    boolean bool = false;
    if (k > 0) {
      int i2 = getScrollX();
      k = getPaddingLeft();
      int m = getPaddingRight();
      int i3 = getWidth();
      int i4 = getChildCount();
      int n;
      for (n = 0; n < i4; n++) {
        View view = getChildAt(n);
        f f = (f)view.getLayoutParams();
        if (f.a) {
          int i5 = f.b & 0x7;
          if (i5 != 1) {
            if (i5 != 3) {
              if (i5 != 5) {
                int i6 = k;
                i5 = k;
                k = i6;
              } else {
                i5 = i3 - m - view.getMeasuredWidth();
                m += view.getMeasuredWidth();
              } 
            } else {
              int i6 = view.getWidth() + k;
              i5 = k;
              k = i6;
            } 
          } else {
            i5 = Math.max((i3 - view.getMeasuredWidth()) / 2, k);
          } 
          i5 = i5 + i2 - view.getLeft();
          if (i5 != 0)
            view.offsetLeftAndRight(i5); 
        } 
      } 
    } 
    i i1 = this.j0;
    if (i1 != null)
      i1.onPageScrolled(paramInt1, paramFloat, paramInt2); 
    List<i> list = this.i0;
    if (list != null) {
      int m = list.size();
      for (k = bool; k < m; k++) {
        i i2 = this.i0.get(k);
        if (i2 != null)
          i2.onPageScrolled(paramInt1, paramFloat, paramInt2); 
      } 
    } 
    this.g0 = true;
  }
  
  public final void m(MotionEvent paramMotionEvent) {
    int k = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(k) == this.U) {
      if (k == 0) {
        k = 1;
      } else {
        k = 0;
      } 
      this.Q = paramMotionEvent.getX(k);
      this.U = paramMotionEvent.getPointerId(k);
      VelocityTracker velocityTracker = this.V;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean n() {
    int k = this.t;
    if (k > 0) {
      w(k - 1, true);
      return true;
    } 
    return false;
  }
  
  public boolean o() {
    hq hq1 = this.s;
    if (hq1 != null && this.t < hq1.getCount() - 1) {
      w(this.t + 1, true);
      return true;
    } 
    return false;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.f0 = true;
  }
  
  public void onDetachedFromWindow() {
    removeCallbacks(this.l0);
    Scroller scroller = this.x;
    if (scroller != null && !scroller.isFinished())
      this.x.abortAnimation(); 
    super.onDetachedFromWindow();
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.A > 0 && this.B != null && this.p.size() > 0 && this.s != null) {
      int n = getScrollX();
      int i1 = getWidth();
      float f1 = this.A;
      float f3 = i1;
      float f2 = f1 / f3;
      ArrayList<e> arrayList = this.p;
      int m = 0;
      e e1 = arrayList.get(0);
      f1 = e1.e;
      int i2 = this.p.size();
      int k = e1.b;
      int i3 = ((e)this.p.get(i2 - 1)).b;
      while (k < i3) {
        float f;
        int i4;
        e e2;
        while (true) {
          i4 = e1.b;
          if (k > i4 && m < i2) {
            ArrayList<e> arrayList1 = this.p;
            e2 = arrayList1.get(++m);
            continue;
          } 
          break;
        } 
        if (k == i4) {
          f1 = e2.e;
          float f4 = e2.d;
          f = (f1 + f4) * f3;
          f1 = f1 + f4 + f2;
        } else {
          float f4 = this.s.getPageWidth(k);
          f = (f1 + f4) * f3;
          f1 = f4 + f2 + f1;
        } 
        if (this.A + f > n) {
          this.B.setBounds(Math.round(f), this.C, Math.round(this.A + f), this.D);
          this.B.draw(paramCanvas);
        } 
        if (f > (n + i1))
          return; 
        k++;
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int k = paramMotionEvent.getAction() & 0xFF;
    if (k == 3 || k == 1) {
      u();
      return false;
    } 
    if (k != 0) {
      if (this.L)
        return true; 
      if (this.M)
        return false; 
    } 
    if (k != 0) {
      if (k != 2) {
        if (k == 6)
          m(paramMotionEvent); 
      } else {
        k = this.U;
        if (k != -1) {
          k = paramMotionEvent.findPointerIndex(k);
          float f2 = paramMotionEvent.getX(k);
          float f1 = f2 - this.Q;
          float f4 = Math.abs(f1);
          float f3 = paramMotionEvent.getY(k);
          float f5 = Math.abs(f3 - this.T);
          if (f1 != 0.0F) {
            float f = this.Q;
            if ((f < this.O && f1 > 0.0F) || (f > (getWidth() - this.O) && f1 < 0.0F)) {
              k = 1;
            } else {
              k = 0;
            } 
            if (k == 0 && d((View)this, false, (int)f1, (int)f2, (int)f3)) {
              this.Q = f2;
              this.R = f3;
              this.M = true;
              return false;
            } 
          } 
          k = this.P;
          if (f4 > k && f4 * 0.5F > f5) {
            this.L = true;
            t(true);
            setScrollState(1);
            if (f1 > 0.0F) {
              f1 = this.S + this.P;
            } else {
              f1 = this.S - this.P;
            } 
            this.Q = f1;
            this.R = f3;
            setScrollingCacheEnabled(true);
          } else if (f5 > k) {
            this.M = true;
          } 
          if (this.L && q(f2)) {
            AtomicInteger atomicInteger = fe.a;
            fe.d.k((View)this);
          } 
        } 
      } 
    } else {
      float f = paramMotionEvent.getX();
      this.S = f;
      this.Q = f;
      f = paramMotionEvent.getY();
      this.T = f;
      this.R = f;
      this.U = paramMotionEvent.getPointerId(0);
      this.M = false;
      this.y = true;
      this.x.computeScrollOffset();
      if (this.m0 == 2 && Math.abs(this.x.getFinalX() - this.x.getCurrX()) > this.c0) {
        this.x.abortAnimation();
        this.J = false;
        r(this.t);
        this.L = true;
        t(true);
        setScrollState(1);
      } else {
        e(false);
        this.L = false;
      } 
    } 
    if (this.V == null)
      this.V = VelocityTracker.obtain(); 
    this.V.addMovement(paramMotionEvent);
    return this.L;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i1 = getChildCount();
    int i2 = paramInt3 - paramInt1;
    int i3 = paramInt4 - paramInt2;
    paramInt2 = getPaddingLeft();
    paramInt1 = getPaddingTop();
    paramInt4 = getPaddingRight();
    paramInt3 = getPaddingBottom();
    int i4 = getScrollX();
    int n = 0;
    int m;
    for (m = 0; n < i1; m = i5) {
      View view = getChildAt(n);
      int i9 = paramInt2;
      int i8 = paramInt1;
      int i7 = paramInt4;
      int i6 = paramInt3;
      int i5 = m;
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        i9 = paramInt2;
        i8 = paramInt1;
        i7 = paramInt4;
        i6 = paramInt3;
        i5 = m;
        if (f.a) {
          i6 = f.b;
          i5 = i6 & 0x7;
          i7 = i6 & 0x70;
          if (i5 != 1) {
            if (i5 != 3) {
              if (i5 != 5) {
                i5 = paramInt2;
                i6 = paramInt2;
                paramInt2 = i5;
              } else {
                i5 = i2 - paramInt4 - view.getMeasuredWidth();
                paramInt4 += view.getMeasuredWidth();
                i6 = i5;
              } 
            } else {
              i5 = view.getMeasuredWidth() + paramInt2;
              i6 = paramInt2;
              paramInt2 = i5;
            } 
          } else {
            i5 = Math.max((i2 - view.getMeasuredWidth()) / 2, paramInt2);
            i6 = i5;
          } 
          if (i7 != 16) {
            if (i7 != 48) {
              if (i7 != 80) {
                i7 = paramInt1;
                i5 = paramInt1;
                paramInt1 = i7;
              } else {
                i5 = i3 - paramInt3 - view.getMeasuredHeight();
                paramInt3 += view.getMeasuredHeight();
              } 
            } else {
              i7 = view.getMeasuredHeight() + paramInt1;
              i5 = paramInt1;
              paramInt1 = i7;
            } 
          } else {
            i5 = Math.max((i3 - view.getMeasuredHeight()) / 2, paramInt1);
          } 
          i6 += i4;
          view.layout(i6, i5, view.getMeasuredWidth() + i6, view.getMeasuredHeight() + i5);
          i5 = m + 1;
          i6 = paramInt3;
          i7 = paramInt4;
          i8 = paramInt1;
          i9 = paramInt2;
        } 
      } 
      n++;
      paramInt2 = i9;
      paramInt1 = i8;
      paramInt4 = i7;
      paramInt3 = i6;
    } 
    int k;
    for (k = 0; k < i1; k++) {
      View view = getChildAt(k);
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        if (!f.a) {
          e e1 = i(view);
          if (e1 != null) {
            float f1 = (i2 - paramInt2 - paramInt4);
            n = (int)(e1.e * f1) + paramInt2;
            if (f.d) {
              f.d = false;
              view.measure(View.MeasureSpec.makeMeasureSpec((int)(f1 * f.c), 1073741824), View.MeasureSpec.makeMeasureSpec(i3 - paramInt1 - paramInt3, 1073741824));
            } 
            view.layout(n, paramInt1, view.getMeasuredWidth() + n, view.getMeasuredHeight() + paramInt1);
          } 
        } 
      } 
    } 
    this.C = paramInt1;
    this.D = i3 - paramInt3;
    this.h0 = m;
    if (this.f0)
      v(this.t, false, 0, false); 
    this.f0 = false;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #11
    //   3: aload_0
    //   4: iconst_0
    //   5: iload_1
    //   6: invokestatic getDefaultSize : (II)I
    //   9: iconst_0
    //   10: iload_2
    //   11: invokestatic getDefaultSize : (II)I
    //   14: invokevirtual setMeasuredDimension : (II)V
    //   17: aload_0
    //   18: invokevirtual getMeasuredWidth : ()I
    //   21: istore_1
    //   22: aload_0
    //   23: iload_1
    //   24: bipush #10
    //   26: idiv
    //   27: aload_0
    //   28: getfield N : I
    //   31: invokestatic min : (II)I
    //   34: putfield O : I
    //   37: iload_1
    //   38: aload_0
    //   39: invokevirtual getPaddingLeft : ()I
    //   42: isub
    //   43: aload_0
    //   44: invokevirtual getPaddingRight : ()I
    //   47: isub
    //   48: istore_1
    //   49: aload_0
    //   50: invokevirtual getMeasuredHeight : ()I
    //   53: aload_0
    //   54: invokevirtual getPaddingTop : ()I
    //   57: isub
    //   58: aload_0
    //   59: invokevirtual getPaddingBottom : ()I
    //   62: isub
    //   63: istore_2
    //   64: aload_0
    //   65: invokevirtual getChildCount : ()I
    //   68: istore #12
    //   70: iconst_0
    //   71: istore #5
    //   73: iconst_1
    //   74: istore #8
    //   76: ldc_w 1073741824
    //   79: istore #10
    //   81: iload #5
    //   83: iload #12
    //   85: if_icmpge -> 418
    //   88: aload_0
    //   89: iload #5
    //   91: invokevirtual getChildAt : (I)Landroid/view/View;
    //   94: astore #13
    //   96: iload_1
    //   97: istore_3
    //   98: iload_2
    //   99: istore #4
    //   101: aload #13
    //   103: invokevirtual getVisibility : ()I
    //   106: bipush #8
    //   108: if_icmpeq -> 404
    //   111: aload #13
    //   113: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   116: checkcast androidx/viewpager/widget/ViewPager$f
    //   119: astore #14
    //   121: iload_1
    //   122: istore_3
    //   123: iload_2
    //   124: istore #4
    //   126: aload #14
    //   128: ifnull -> 404
    //   131: iload_1
    //   132: istore_3
    //   133: iload_2
    //   134: istore #4
    //   136: aload #14
    //   138: getfield a : Z
    //   141: ifeq -> 404
    //   144: aload #14
    //   146: getfield b : I
    //   149: istore #4
    //   151: iload #4
    //   153: bipush #7
    //   155: iand
    //   156: istore_3
    //   157: iload #4
    //   159: bipush #112
    //   161: iand
    //   162: istore #4
    //   164: iload #4
    //   166: bipush #48
    //   168: if_icmpeq -> 187
    //   171: iload #4
    //   173: bipush #80
    //   175: if_icmpne -> 181
    //   178: goto -> 187
    //   181: iconst_0
    //   182: istore #7
    //   184: goto -> 190
    //   187: iconst_1
    //   188: istore #7
    //   190: iload #8
    //   192: istore #6
    //   194: iload_3
    //   195: iconst_3
    //   196: if_icmpeq -> 214
    //   199: iload_3
    //   200: iconst_5
    //   201: if_icmpne -> 211
    //   204: iload #8
    //   206: istore #6
    //   208: goto -> 214
    //   211: iconst_0
    //   212: istore #6
    //   214: ldc_w -2147483648
    //   217: istore_3
    //   218: iload #7
    //   220: ifeq -> 231
    //   223: ldc_w 1073741824
    //   226: istore #4
    //   228: goto -> 253
    //   231: iload_3
    //   232: istore #4
    //   234: iload #6
    //   236: ifeq -> 253
    //   239: ldc_w 1073741824
    //   242: istore #8
    //   244: iload_3
    //   245: istore #4
    //   247: iload #8
    //   249: istore_3
    //   250: goto -> 257
    //   253: ldc_w -2147483648
    //   256: istore_3
    //   257: aload #14
    //   259: getfield width : I
    //   262: istore #8
    //   264: iload #8
    //   266: bipush #-2
    //   268: if_icmpeq -> 299
    //   271: iload #8
    //   273: iconst_m1
    //   274: if_icmpeq -> 284
    //   277: iload #8
    //   279: istore #4
    //   281: goto -> 287
    //   284: iload_1
    //   285: istore #4
    //   287: ldc_w 1073741824
    //   290: istore #8
    //   292: iload #4
    //   294: istore #9
    //   296: goto -> 306
    //   299: iload_1
    //   300: istore #9
    //   302: iload #4
    //   304: istore #8
    //   306: aload #14
    //   308: getfield height : I
    //   311: istore #4
    //   313: iload #4
    //   315: bipush #-2
    //   317: if_icmpeq -> 337
    //   320: iload #4
    //   322: iconst_m1
    //   323: if_icmpeq -> 332
    //   326: iload #4
    //   328: istore_3
    //   329: goto -> 346
    //   332: iload_2
    //   333: istore_3
    //   334: goto -> 346
    //   337: iload_2
    //   338: istore #4
    //   340: iload_3
    //   341: istore #10
    //   343: iload #4
    //   345: istore_3
    //   346: aload #13
    //   348: iload #9
    //   350: iload #8
    //   352: invokestatic makeMeasureSpec : (II)I
    //   355: iload_3
    //   356: iload #10
    //   358: invokestatic makeMeasureSpec : (II)I
    //   361: invokevirtual measure : (II)V
    //   364: iload #7
    //   366: ifeq -> 383
    //   369: iload_2
    //   370: aload #13
    //   372: invokevirtual getMeasuredHeight : ()I
    //   375: isub
    //   376: istore #4
    //   378: iload_1
    //   379: istore_3
    //   380: goto -> 404
    //   383: iload_1
    //   384: istore_3
    //   385: iload_2
    //   386: istore #4
    //   388: iload #6
    //   390: ifeq -> 404
    //   393: iload_1
    //   394: aload #13
    //   396: invokevirtual getMeasuredWidth : ()I
    //   399: isub
    //   400: istore_3
    //   401: iload_2
    //   402: istore #4
    //   404: iload #5
    //   406: iconst_1
    //   407: iadd
    //   408: istore #5
    //   410: iload_3
    //   411: istore_1
    //   412: iload #4
    //   414: istore_2
    //   415: goto -> 73
    //   418: iload_1
    //   419: ldc_w 1073741824
    //   422: invokestatic makeMeasureSpec : (II)I
    //   425: pop
    //   426: aload_0
    //   427: iload_2
    //   428: ldc_w 1073741824
    //   431: invokestatic makeMeasureSpec : (II)I
    //   434: putfield G : I
    //   437: aload_0
    //   438: iconst_1
    //   439: putfield H : Z
    //   442: aload_0
    //   443: aload_0
    //   444: getfield t : I
    //   447: invokevirtual r : (I)V
    //   450: aload_0
    //   451: iconst_0
    //   452: putfield H : Z
    //   455: aload_0
    //   456: invokevirtual getChildCount : ()I
    //   459: istore_3
    //   460: iload #11
    //   462: istore_2
    //   463: iload_2
    //   464: iload_3
    //   465: if_icmpge -> 539
    //   468: aload_0
    //   469: iload_2
    //   470: invokevirtual getChildAt : (I)Landroid/view/View;
    //   473: astore #13
    //   475: aload #13
    //   477: invokevirtual getVisibility : ()I
    //   480: bipush #8
    //   482: if_icmpeq -> 532
    //   485: aload #13
    //   487: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   490: checkcast androidx/viewpager/widget/ViewPager$f
    //   493: astore #14
    //   495: aload #14
    //   497: ifnull -> 508
    //   500: aload #14
    //   502: getfield a : Z
    //   505: ifne -> 532
    //   508: aload #13
    //   510: iload_1
    //   511: i2f
    //   512: aload #14
    //   514: getfield c : F
    //   517: fmul
    //   518: f2i
    //   519: ldc_w 1073741824
    //   522: invokestatic makeMeasureSpec : (II)I
    //   525: aload_0
    //   526: getfield G : I
    //   529: invokevirtual measure : (II)V
    //   532: iload_2
    //   533: iconst_1
    //   534: iadd
    //   535: istore_2
    //   536: goto -> 463
    //   539: return
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    byte b;
    int k = getChildCount();
    int m = -1;
    if ((paramInt & 0x2) != 0) {
      m = k;
      k = 0;
      b = 1;
    } else {
      k--;
      b = -1;
    } 
    while (k != m) {
      View view = getChildAt(k);
      if (view.getVisibility() == 0) {
        e e1 = i(view);
        if (e1 != null && e1.b == this.t && view.requestFocus(paramInt, paramRect))
          return true; 
      } 
      k += b;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof k)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    k k = (k)paramParcelable;
    super.onRestoreInstanceState(k.getSuperState());
    hq hq1 = this.s;
    if (hq1 != null) {
      hq1.restoreState(k.c, k.d);
      x(k.b, false, true, 0);
      return;
    } 
    this.u = k.b;
    this.v = k.c;
    this.w = k.d;
  }
  
  public Parcelable onSaveInstanceState() {
    k k = new k(super.onSaveInstanceState());
    k.b = this.t;
    hq hq1 = this.s;
    if (hq1 != null)
      k.c = hq1.saveState(); 
    return (Parcelable)k;
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3) {
      paramInt2 = this.A;
      s(paramInt1, paramInt3, paramInt2, paramInt2);
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore #6
    //   6: iconst_0
    //   7: istore #9
    //   9: iload #6
    //   11: ifne -> 23
    //   14: aload_1
    //   15: invokevirtual getEdgeFlags : ()I
    //   18: ifeq -> 23
    //   21: iconst_0
    //   22: ireturn
    //   23: aload_0
    //   24: getfield s : Lhq;
    //   27: astore #10
    //   29: aload #10
    //   31: ifnull -> 746
    //   34: aload #10
    //   36: invokevirtual getCount : ()I
    //   39: ifne -> 44
    //   42: iconst_0
    //   43: ireturn
    //   44: aload_0
    //   45: getfield V : Landroid/view/VelocityTracker;
    //   48: ifnonnull -> 58
    //   51: aload_0
    //   52: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   55: putfield V : Landroid/view/VelocityTracker;
    //   58: aload_0
    //   59: getfield V : Landroid/view/VelocityTracker;
    //   62: aload_1
    //   63: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   66: aload_1
    //   67: invokevirtual getAction : ()I
    //   70: sipush #255
    //   73: iand
    //   74: istore #6
    //   76: iload #6
    //   78: ifeq -> 672
    //   81: iload #6
    //   83: iconst_1
    //   84: if_icmpeq -> 397
    //   87: iload #6
    //   89: iconst_2
    //   90: if_icmpeq -> 195
    //   93: iload #6
    //   95: iconst_3
    //   96: if_icmpeq -> 168
    //   99: iload #6
    //   101: iconst_5
    //   102: if_icmpeq -> 139
    //   105: iload #6
    //   107: bipush #6
    //   109: if_icmpeq -> 115
    //   112: goto -> 731
    //   115: aload_0
    //   116: aload_1
    //   117: invokevirtual m : (Landroid/view/MotionEvent;)V
    //   120: aload_0
    //   121: aload_1
    //   122: aload_1
    //   123: aload_0
    //   124: getfield U : I
    //   127: invokevirtual findPointerIndex : (I)I
    //   130: invokevirtual getX : (I)F
    //   133: putfield Q : F
    //   136: goto -> 731
    //   139: aload_1
    //   140: invokevirtual getActionIndex : ()I
    //   143: istore #6
    //   145: aload_0
    //   146: aload_1
    //   147: iload #6
    //   149: invokevirtual getX : (I)F
    //   152: putfield Q : F
    //   155: aload_0
    //   156: aload_1
    //   157: iload #6
    //   159: invokevirtual getPointerId : (I)I
    //   162: putfield U : I
    //   165: goto -> 731
    //   168: aload_0
    //   169: getfield L : Z
    //   172: ifeq -> 731
    //   175: aload_0
    //   176: aload_0
    //   177: getfield t : I
    //   180: iconst_1
    //   181: iconst_0
    //   182: iconst_0
    //   183: invokevirtual v : (IZIZ)V
    //   186: aload_0
    //   187: invokevirtual u : ()Z
    //   190: istore #9
    //   192: goto -> 731
    //   195: aload_0
    //   196: getfield L : Z
    //   199: ifne -> 367
    //   202: aload_1
    //   203: aload_0
    //   204: getfield U : I
    //   207: invokevirtual findPointerIndex : (I)I
    //   210: istore #6
    //   212: iload #6
    //   214: iconst_m1
    //   215: if_icmpne -> 227
    //   218: aload_0
    //   219: invokevirtual u : ()Z
    //   222: istore #9
    //   224: goto -> 731
    //   227: aload_1
    //   228: iload #6
    //   230: invokevirtual getX : (I)F
    //   233: fstore_2
    //   234: fload_2
    //   235: aload_0
    //   236: getfield Q : F
    //   239: fsub
    //   240: invokestatic abs : (F)F
    //   243: fstore #4
    //   245: aload_1
    //   246: iload #6
    //   248: invokevirtual getY : (I)F
    //   251: fstore_3
    //   252: fload_3
    //   253: aload_0
    //   254: getfield R : F
    //   257: fsub
    //   258: invokestatic abs : (F)F
    //   261: fstore #5
    //   263: fload #4
    //   265: aload_0
    //   266: getfield P : I
    //   269: i2f
    //   270: fcmpl
    //   271: ifle -> 367
    //   274: fload #4
    //   276: fload #5
    //   278: fcmpl
    //   279: ifle -> 367
    //   282: aload_0
    //   283: iconst_1
    //   284: putfield L : Z
    //   287: aload_0
    //   288: iconst_1
    //   289: invokevirtual t : (Z)V
    //   292: aload_0
    //   293: getfield S : F
    //   296: fstore #4
    //   298: fload_2
    //   299: fload #4
    //   301: fsub
    //   302: fconst_0
    //   303: fcmpl
    //   304: ifle -> 319
    //   307: fload #4
    //   309: aload_0
    //   310: getfield P : I
    //   313: i2f
    //   314: fadd
    //   315: fstore_2
    //   316: goto -> 328
    //   319: fload #4
    //   321: aload_0
    //   322: getfield P : I
    //   325: i2f
    //   326: fsub
    //   327: fstore_2
    //   328: aload_0
    //   329: fload_2
    //   330: putfield Q : F
    //   333: aload_0
    //   334: fload_3
    //   335: putfield R : F
    //   338: aload_0
    //   339: iconst_1
    //   340: invokevirtual setScrollState : (I)V
    //   343: aload_0
    //   344: iconst_1
    //   345: invokespecial setScrollingCacheEnabled : (Z)V
    //   348: aload_0
    //   349: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   352: astore #10
    //   354: aload #10
    //   356: ifnull -> 367
    //   359: aload #10
    //   361: iconst_1
    //   362: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   367: aload_0
    //   368: getfield L : Z
    //   371: ifeq -> 731
    //   374: iconst_0
    //   375: aload_0
    //   376: aload_1
    //   377: aload_1
    //   378: aload_0
    //   379: getfield U : I
    //   382: invokevirtual findPointerIndex : (I)I
    //   385: invokevirtual getX : (I)F
    //   388: invokevirtual q : (F)Z
    //   391: ior
    //   392: istore #9
    //   394: goto -> 731
    //   397: aload_0
    //   398: getfield L : Z
    //   401: ifeq -> 731
    //   404: aload_0
    //   405: getfield V : Landroid/view/VelocityTracker;
    //   408: astore #10
    //   410: aload #10
    //   412: sipush #1000
    //   415: aload_0
    //   416: getfield a0 : I
    //   419: i2f
    //   420: invokevirtual computeCurrentVelocity : (IF)V
    //   423: aload #10
    //   425: aload_0
    //   426: getfield U : I
    //   429: invokevirtual getXVelocity : (I)F
    //   432: f2i
    //   433: istore #8
    //   435: aload_0
    //   436: iconst_1
    //   437: putfield J : Z
    //   440: aload_0
    //   441: invokespecial getClientWidth : ()I
    //   444: istore #6
    //   446: aload_0
    //   447: invokevirtual getScrollX : ()I
    //   450: istore #7
    //   452: aload_0
    //   453: invokevirtual j : ()Landroidx/viewpager/widget/ViewPager$e;
    //   456: astore #10
    //   458: aload_0
    //   459: getfield A : I
    //   462: i2f
    //   463: fstore_3
    //   464: iload #6
    //   466: i2f
    //   467: fstore_2
    //   468: fload_3
    //   469: fload_2
    //   470: fdiv
    //   471: fstore_3
    //   472: aload #10
    //   474: getfield b : I
    //   477: istore #6
    //   479: iload #7
    //   481: i2f
    //   482: fload_2
    //   483: fdiv
    //   484: aload #10
    //   486: getfield e : F
    //   489: fsub
    //   490: aload #10
    //   492: getfield d : F
    //   495: fload_3
    //   496: fadd
    //   497: fdiv
    //   498: fstore_3
    //   499: aload_1
    //   500: aload_1
    //   501: aload_0
    //   502: getfield U : I
    //   505: invokevirtual findPointerIndex : (I)I
    //   508: invokevirtual getX : (I)F
    //   511: aload_0
    //   512: getfield S : F
    //   515: fsub
    //   516: f2i
    //   517: invokestatic abs : (I)I
    //   520: aload_0
    //   521: getfield b0 : I
    //   524: if_icmple -> 556
    //   527: iload #8
    //   529: invokestatic abs : (I)I
    //   532: aload_0
    //   533: getfield W : I
    //   536: if_icmple -> 556
    //   539: iload #8
    //   541: ifle -> 547
    //   544: goto -> 585
    //   547: iload #6
    //   549: iconst_1
    //   550: iadd
    //   551: istore #6
    //   553: goto -> 585
    //   556: iload #6
    //   558: aload_0
    //   559: getfield t : I
    //   562: if_icmplt -> 572
    //   565: ldc_w 0.4
    //   568: fstore_2
    //   569: goto -> 576
    //   572: ldc_w 0.6
    //   575: fstore_2
    //   576: iload #6
    //   578: fload_3
    //   579: fload_2
    //   580: fadd
    //   581: f2i
    //   582: iadd
    //   583: istore #6
    //   585: iload #6
    //   587: istore #7
    //   589: aload_0
    //   590: getfield p : Ljava/util/ArrayList;
    //   593: invokevirtual size : ()I
    //   596: ifle -> 653
    //   599: aload_0
    //   600: getfield p : Ljava/util/ArrayList;
    //   603: iconst_0
    //   604: invokevirtual get : (I)Ljava/lang/Object;
    //   607: checkcast androidx/viewpager/widget/ViewPager$e
    //   610: astore_1
    //   611: aload_0
    //   612: getfield p : Ljava/util/ArrayList;
    //   615: astore #10
    //   617: aload #10
    //   619: aload #10
    //   621: invokevirtual size : ()I
    //   624: iconst_1
    //   625: isub
    //   626: invokevirtual get : (I)Ljava/lang/Object;
    //   629: checkcast androidx/viewpager/widget/ViewPager$e
    //   632: astore #10
    //   634: aload_1
    //   635: getfield b : I
    //   638: iload #6
    //   640: aload #10
    //   642: getfield b : I
    //   645: invokestatic min : (II)I
    //   648: invokestatic max : (II)I
    //   651: istore #7
    //   653: aload_0
    //   654: iload #7
    //   656: iconst_1
    //   657: iconst_1
    //   658: iload #8
    //   660: invokevirtual x : (IZZI)V
    //   663: aload_0
    //   664: invokevirtual u : ()Z
    //   667: istore #9
    //   669: goto -> 731
    //   672: aload_0
    //   673: getfield x : Landroid/widget/Scroller;
    //   676: invokevirtual abortAnimation : ()V
    //   679: aload_0
    //   680: iconst_0
    //   681: putfield J : Z
    //   684: aload_0
    //   685: aload_0
    //   686: getfield t : I
    //   689: invokevirtual r : (I)V
    //   692: aload_1
    //   693: invokevirtual getX : ()F
    //   696: fstore_2
    //   697: aload_0
    //   698: fload_2
    //   699: putfield S : F
    //   702: aload_0
    //   703: fload_2
    //   704: putfield Q : F
    //   707: aload_1
    //   708: invokevirtual getY : ()F
    //   711: fstore_2
    //   712: aload_0
    //   713: fload_2
    //   714: putfield T : F
    //   717: aload_0
    //   718: fload_2
    //   719: putfield R : F
    //   722: aload_0
    //   723: aload_1
    //   724: iconst_0
    //   725: invokevirtual getPointerId : (I)I
    //   728: putfield U : I
    //   731: iload #9
    //   733: ifeq -> 744
    //   736: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   739: astore_1
    //   740: aload_0
    //   741: invokestatic k : (Landroid/view/View;)V
    //   744: iconst_1
    //   745: ireturn
    //   746: iconst_0
    //   747: ireturn
  }
  
  public final boolean p(int paramInt) {
    if (this.p.size() == 0) {
      if (this.f0)
        return false; 
      this.g0 = false;
      l(0, 0.0F, 0);
      if (this.g0)
        return false; 
      throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    } 
    e e1 = j();
    int m = getClientWidth();
    int n = this.A;
    float f2 = n;
    float f1 = m;
    f2 /= f1;
    int k = e1.b;
    f1 = (paramInt / f1 - e1.e) / (e1.d + f2);
    paramInt = (int)((m + n) * f1);
    this.g0 = false;
    l(k, f1, paramInt);
    if (this.g0)
      return true; 
    throw new IllegalStateException("onPageScrolled did not call superclass implementation");
  }
  
  public final boolean q(float paramFloat) {
    boolean bool1;
    float f1 = this.Q;
    this.Q = paramFloat;
    float f2 = getScrollX() + f1 - paramFloat;
    float f3 = getClientWidth();
    paramFloat = this.E * f3;
    f1 = this.F * f3;
    ArrayList<e> arrayList1 = this.p;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool2 = false;
    e e1 = arrayList1.get(0);
    ArrayList<e> arrayList2 = this.p;
    e e2 = arrayList2.get(arrayList2.size() - 1);
    if (e1.b != 0) {
      paramFloat = e1.e * f3;
      k = 0;
    } else {
      k = 1;
    } 
    if (e2.b != this.s.getCount() - 1) {
      f1 = e2.e * f3;
      bool1 = false;
    } else {
      bool1 = true;
    } 
    if (f2 < paramFloat) {
      if (k) {
        this.d0.onPull(Math.abs(paramFloat - f2) / f3);
        bool2 = true;
      } 
    } else {
      bool2 = bool4;
      paramFloat = f2;
      if (f2 > f1) {
        bool2 = bool3;
        if (bool1) {
          this.e0.onPull(Math.abs(f2 - f1) / f3);
          bool2 = true;
        } 
        paramFloat = f1;
      } 
    } 
    f1 = this.Q;
    int k = (int)paramFloat;
    this.Q = paramFloat - k + f1;
    scrollTo(k, getScrollY());
    p(k);
    return bool2;
  }
  
  public void r(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : I
    //   4: istore #5
    //   6: iload #5
    //   8: iload_1
    //   9: if_icmpeq -> 28
    //   12: aload_0
    //   13: iload #5
    //   15: invokevirtual k : (I)Landroidx/viewpager/widget/ViewPager$e;
    //   18: astore #15
    //   20: aload_0
    //   21: iload_1
    //   22: putfield t : I
    //   25: goto -> 31
    //   28: aconst_null
    //   29: astore #15
    //   31: aload_0
    //   32: getfield s : Lhq;
    //   35: ifnonnull -> 39
    //   38: return
    //   39: aload_0
    //   40: getfield J : Z
    //   43: ifeq -> 47
    //   46: return
    //   47: aload_0
    //   48: invokevirtual getWindowToken : ()Landroid/os/IBinder;
    //   51: ifnonnull -> 55
    //   54: return
    //   55: aload_0
    //   56: getfield s : Lhq;
    //   59: aload_0
    //   60: invokevirtual startUpdate : (Landroid/view/ViewGroup;)V
    //   63: aload_0
    //   64: getfield K : I
    //   67: istore_1
    //   68: iconst_0
    //   69: aload_0
    //   70: getfield t : I
    //   73: iload_1
    //   74: isub
    //   75: invokestatic max : (II)I
    //   78: istore #11
    //   80: aload_0
    //   81: getfield s : Lhq;
    //   84: invokevirtual getCount : ()I
    //   87: istore #9
    //   89: iload #9
    //   91: iconst_1
    //   92: isub
    //   93: aload_0
    //   94: getfield t : I
    //   97: iload_1
    //   98: iadd
    //   99: invokestatic min : (II)I
    //   102: istore #10
    //   104: iload #9
    //   106: aload_0
    //   107: getfield g : I
    //   110: if_icmpne -> 1928
    //   113: iconst_0
    //   114: istore #6
    //   116: iload #6
    //   118: aload_0
    //   119: getfield p : Ljava/util/ArrayList;
    //   122: invokevirtual size : ()I
    //   125: if_icmpge -> 178
    //   128: aload_0
    //   129: getfield p : Ljava/util/ArrayList;
    //   132: iload #6
    //   134: invokevirtual get : (I)Ljava/lang/Object;
    //   137: checkcast androidx/viewpager/widget/ViewPager$e
    //   140: astore #13
    //   142: aload #13
    //   144: getfield b : I
    //   147: istore_1
    //   148: aload_0
    //   149: getfield t : I
    //   152: istore #5
    //   154: iload_1
    //   155: iload #5
    //   157: if_icmplt -> 169
    //   160: iload_1
    //   161: iload #5
    //   163: if_icmpne -> 178
    //   166: goto -> 181
    //   169: iload #6
    //   171: iconst_1
    //   172: iadd
    //   173: istore #6
    //   175: goto -> 116
    //   178: aconst_null
    //   179: astore #13
    //   181: aload #13
    //   183: astore #14
    //   185: aload #13
    //   187: ifnonnull -> 211
    //   190: aload #13
    //   192: astore #14
    //   194: iload #9
    //   196: ifle -> 211
    //   199: aload_0
    //   200: aload_0
    //   201: getfield t : I
    //   204: iload #6
    //   206: invokevirtual a : (II)Landroidx/viewpager/widget/ViewPager$e;
    //   209: astore #14
    //   211: aload #14
    //   213: ifnull -> 1677
    //   216: iload #6
    //   218: iconst_1
    //   219: isub
    //   220: istore #7
    //   222: iload #7
    //   224: iflt -> 244
    //   227: aload_0
    //   228: getfield p : Ljava/util/ArrayList;
    //   231: iload #7
    //   233: invokevirtual get : (I)Ljava/lang/Object;
    //   236: checkcast androidx/viewpager/widget/ViewPager$e
    //   239: astore #13
    //   241: goto -> 247
    //   244: aconst_null
    //   245: astore #13
    //   247: aload_0
    //   248: invokespecial getClientWidth : ()I
    //   251: istore #12
    //   253: iload #12
    //   255: ifgt -> 264
    //   258: fconst_0
    //   259: fstore #4
    //   261: goto -> 283
    //   264: fconst_2
    //   265: aload #14
    //   267: getfield d : F
    //   270: fsub
    //   271: aload_0
    //   272: invokevirtual getPaddingLeft : ()I
    //   275: i2f
    //   276: iload #12
    //   278: i2f
    //   279: fdiv
    //   280: fadd
    //   281: fstore #4
    //   283: aload_0
    //   284: getfield t : I
    //   287: iconst_1
    //   288: isub
    //   289: istore #8
    //   291: fconst_0
    //   292: fstore_3
    //   293: aload #13
    //   295: astore #16
    //   297: iload #8
    //   299: iflt -> 601
    //   302: fload_3
    //   303: fload #4
    //   305: fcmpl
    //   306: iflt -> 445
    //   309: iload #8
    //   311: iload #11
    //   313: if_icmpge -> 445
    //   316: aload #16
    //   318: ifnonnull -> 324
    //   321: goto -> 601
    //   324: iload #6
    //   326: istore_1
    //   327: iload #7
    //   329: istore #5
    //   331: aload #16
    //   333: astore #13
    //   335: fload_3
    //   336: fstore_2
    //   337: iload #8
    //   339: aload #16
    //   341: getfield b : I
    //   344: if_icmpne -> 579
    //   347: iload #6
    //   349: istore_1
    //   350: iload #7
    //   352: istore #5
    //   354: aload #16
    //   356: astore #13
    //   358: fload_3
    //   359: fstore_2
    //   360: aload #16
    //   362: getfield c : Z
    //   365: ifne -> 579
    //   368: aload_0
    //   369: getfield p : Ljava/util/ArrayList;
    //   372: iload #7
    //   374: invokevirtual remove : (I)Ljava/lang/Object;
    //   377: pop
    //   378: aload_0
    //   379: getfield s : Lhq;
    //   382: aload_0
    //   383: iload #8
    //   385: aload #16
    //   387: getfield a : Ljava/lang/Object;
    //   390: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   393: iload #7
    //   395: iconst_1
    //   396: isub
    //   397: istore #7
    //   399: iload #6
    //   401: iconst_1
    //   402: isub
    //   403: istore #6
    //   405: iload #6
    //   407: istore_1
    //   408: iload #7
    //   410: istore #5
    //   412: fload_3
    //   413: fstore_2
    //   414: iload #7
    //   416: iflt -> 576
    //   419: aload_0
    //   420: getfield p : Ljava/util/ArrayList;
    //   423: iload #7
    //   425: invokevirtual get : (I)Ljava/lang/Object;
    //   428: checkcast androidx/viewpager/widget/ViewPager$e
    //   431: astore #13
    //   433: iload #6
    //   435: istore_1
    //   436: iload #7
    //   438: istore #5
    //   440: fload_3
    //   441: fstore_2
    //   442: goto -> 579
    //   445: aload #16
    //   447: ifnull -> 514
    //   450: iload #8
    //   452: aload #16
    //   454: getfield b : I
    //   457: if_icmpne -> 514
    //   460: fload_3
    //   461: aload #16
    //   463: getfield d : F
    //   466: fadd
    //   467: fstore_3
    //   468: iload #7
    //   470: iconst_1
    //   471: isub
    //   472: istore #7
    //   474: iload #6
    //   476: istore_1
    //   477: iload #7
    //   479: istore #5
    //   481: fload_3
    //   482: fstore_2
    //   483: iload #7
    //   485: iflt -> 576
    //   488: aload_0
    //   489: getfield p : Ljava/util/ArrayList;
    //   492: iload #7
    //   494: invokevirtual get : (I)Ljava/lang/Object;
    //   497: checkcast androidx/viewpager/widget/ViewPager$e
    //   500: astore #13
    //   502: iload #6
    //   504: istore_1
    //   505: iload #7
    //   507: istore #5
    //   509: fload_3
    //   510: fstore_2
    //   511: goto -> 579
    //   514: fload_3
    //   515: aload_0
    //   516: iload #8
    //   518: iload #7
    //   520: iconst_1
    //   521: iadd
    //   522: invokevirtual a : (II)Landroidx/viewpager/widget/ViewPager$e;
    //   525: getfield d : F
    //   528: fadd
    //   529: fstore_3
    //   530: iload #6
    //   532: iconst_1
    //   533: iadd
    //   534: istore #6
    //   536: iload #6
    //   538: istore_1
    //   539: iload #7
    //   541: istore #5
    //   543: fload_3
    //   544: fstore_2
    //   545: iload #7
    //   547: iflt -> 576
    //   550: aload_0
    //   551: getfield p : Ljava/util/ArrayList;
    //   554: iload #7
    //   556: invokevirtual get : (I)Ljava/lang/Object;
    //   559: checkcast androidx/viewpager/widget/ViewPager$e
    //   562: astore #13
    //   564: iload #6
    //   566: istore_1
    //   567: iload #7
    //   569: istore #5
    //   571: fload_3
    //   572: fstore_2
    //   573: goto -> 579
    //   576: aconst_null
    //   577: astore #13
    //   579: iload #8
    //   581: iconst_1
    //   582: isub
    //   583: istore #8
    //   585: iload_1
    //   586: istore #6
    //   588: iload #5
    //   590: istore #7
    //   592: aload #13
    //   594: astore #16
    //   596: fload_2
    //   597: fstore_3
    //   598: goto -> 297
    //   601: aload #14
    //   603: getfield d : F
    //   606: fstore_3
    //   607: iload #6
    //   609: iconst_1
    //   610: iadd
    //   611: istore #7
    //   613: fload_3
    //   614: fconst_2
    //   615: fcmpg
    //   616: ifge -> 972
    //   619: iload #7
    //   621: aload_0
    //   622: getfield p : Ljava/util/ArrayList;
    //   625: invokevirtual size : ()I
    //   628: if_icmpge -> 648
    //   631: aload_0
    //   632: getfield p : Ljava/util/ArrayList;
    //   635: iload #7
    //   637: invokevirtual get : (I)Ljava/lang/Object;
    //   640: checkcast androidx/viewpager/widget/ViewPager$e
    //   643: astore #13
    //   645: goto -> 651
    //   648: aconst_null
    //   649: astore #13
    //   651: iload #12
    //   653: ifgt -> 662
    //   656: fconst_0
    //   657: fstore #4
    //   659: goto -> 675
    //   662: aload_0
    //   663: invokevirtual getPaddingRight : ()I
    //   666: i2f
    //   667: iload #12
    //   669: i2f
    //   670: fdiv
    //   671: fconst_2
    //   672: fadd
    //   673: fstore #4
    //   675: aload_0
    //   676: getfield t : I
    //   679: iconst_1
    //   680: iadd
    //   681: istore #8
    //   683: iload #7
    //   685: istore #5
    //   687: aload #13
    //   689: astore #16
    //   691: iload #8
    //   693: iload #9
    //   695: if_icmpge -> 972
    //   698: fload_3
    //   699: fload #4
    //   701: fcmpl
    //   702: iflt -> 820
    //   705: iload #8
    //   707: iload #10
    //   709: if_icmple -> 820
    //   712: aload #16
    //   714: ifnonnull -> 720
    //   717: goto -> 972
    //   720: fload_3
    //   721: fstore_2
    //   722: aload #16
    //   724: astore #13
    //   726: iload #5
    //   728: istore_1
    //   729: iload #8
    //   731: aload #16
    //   733: getfield b : I
    //   736: if_icmpne -> 954
    //   739: fload_3
    //   740: fstore_2
    //   741: aload #16
    //   743: astore #13
    //   745: iload #5
    //   747: istore_1
    //   748: aload #16
    //   750: getfield c : Z
    //   753: ifne -> 954
    //   756: aload_0
    //   757: getfield p : Ljava/util/ArrayList;
    //   760: iload #5
    //   762: invokevirtual remove : (I)Ljava/lang/Object;
    //   765: pop
    //   766: aload_0
    //   767: getfield s : Lhq;
    //   770: aload_0
    //   771: iload #8
    //   773: aload #16
    //   775: getfield a : Ljava/lang/Object;
    //   778: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   781: fload_3
    //   782: fstore_2
    //   783: iload #5
    //   785: istore_1
    //   786: iload #5
    //   788: aload_0
    //   789: getfield p : Ljava/util/ArrayList;
    //   792: invokevirtual size : ()I
    //   795: if_icmpge -> 951
    //   798: aload_0
    //   799: getfield p : Ljava/util/ArrayList;
    //   802: iload #5
    //   804: invokevirtual get : (I)Ljava/lang/Object;
    //   807: checkcast androidx/viewpager/widget/ViewPager$e
    //   810: astore #13
    //   812: fload_3
    //   813: fstore_2
    //   814: iload #5
    //   816: istore_1
    //   817: goto -> 954
    //   820: aload #16
    //   822: ifnull -> 888
    //   825: iload #8
    //   827: aload #16
    //   829: getfield b : I
    //   832: if_icmpne -> 888
    //   835: fload_3
    //   836: aload #16
    //   838: getfield d : F
    //   841: fadd
    //   842: fstore_3
    //   843: iload #5
    //   845: iconst_1
    //   846: iadd
    //   847: istore #5
    //   849: fload_3
    //   850: fstore_2
    //   851: iload #5
    //   853: istore_1
    //   854: iload #5
    //   856: aload_0
    //   857: getfield p : Ljava/util/ArrayList;
    //   860: invokevirtual size : ()I
    //   863: if_icmpge -> 951
    //   866: aload_0
    //   867: getfield p : Ljava/util/ArrayList;
    //   870: iload #5
    //   872: invokevirtual get : (I)Ljava/lang/Object;
    //   875: checkcast androidx/viewpager/widget/ViewPager$e
    //   878: astore #13
    //   880: fload_3
    //   881: fstore_2
    //   882: iload #5
    //   884: istore_1
    //   885: goto -> 954
    //   888: aload_0
    //   889: iload #8
    //   891: iload #5
    //   893: invokevirtual a : (II)Landroidx/viewpager/widget/ViewPager$e;
    //   896: astore #13
    //   898: iload #5
    //   900: iconst_1
    //   901: iadd
    //   902: istore #5
    //   904: fload_3
    //   905: aload #13
    //   907: getfield d : F
    //   910: fadd
    //   911: fstore_3
    //   912: fload_3
    //   913: fstore_2
    //   914: iload #5
    //   916: istore_1
    //   917: iload #5
    //   919: aload_0
    //   920: getfield p : Ljava/util/ArrayList;
    //   923: invokevirtual size : ()I
    //   926: if_icmpge -> 951
    //   929: aload_0
    //   930: getfield p : Ljava/util/ArrayList;
    //   933: iload #5
    //   935: invokevirtual get : (I)Ljava/lang/Object;
    //   938: checkcast androidx/viewpager/widget/ViewPager$e
    //   941: astore #13
    //   943: fload_3
    //   944: fstore_2
    //   945: iload #5
    //   947: istore_1
    //   948: goto -> 954
    //   951: aconst_null
    //   952: astore #13
    //   954: iload #8
    //   956: iconst_1
    //   957: iadd
    //   958: istore #8
    //   960: fload_2
    //   961: fstore_3
    //   962: aload #13
    //   964: astore #16
    //   966: iload_1
    //   967: istore #5
    //   969: goto -> 691
    //   972: aload_0
    //   973: getfield s : Lhq;
    //   976: invokevirtual getCount : ()I
    //   979: istore #9
    //   981: aload_0
    //   982: invokespecial getClientWidth : ()I
    //   985: istore_1
    //   986: iload_1
    //   987: ifle -> 1002
    //   990: aload_0
    //   991: getfield A : I
    //   994: i2f
    //   995: iload_1
    //   996: i2f
    //   997: fdiv
    //   998: fstore_3
    //   999: goto -> 1004
    //   1002: fconst_0
    //   1003: fstore_3
    //   1004: aload #15
    //   1006: ifnull -> 1355
    //   1009: aload #15
    //   1011: getfield b : I
    //   1014: istore_1
    //   1015: aload #14
    //   1017: getfield b : I
    //   1020: istore #5
    //   1022: iload_1
    //   1023: iload #5
    //   1025: if_icmpge -> 1197
    //   1028: aload #15
    //   1030: getfield e : F
    //   1033: aload #15
    //   1035: getfield d : F
    //   1038: fadd
    //   1039: fload_3
    //   1040: fadd
    //   1041: fstore_2
    //   1042: iconst_0
    //   1043: istore #5
    //   1045: iload_1
    //   1046: iconst_1
    //   1047: iadd
    //   1048: istore #8
    //   1050: iload #8
    //   1052: aload #14
    //   1054: getfield b : I
    //   1057: if_icmpgt -> 1355
    //   1060: iload #5
    //   1062: aload_0
    //   1063: getfield p : Ljava/util/ArrayList;
    //   1066: invokevirtual size : ()I
    //   1069: if_icmpge -> 1355
    //   1072: aload_0
    //   1073: getfield p : Ljava/util/ArrayList;
    //   1076: iload #5
    //   1078: invokevirtual get : (I)Ljava/lang/Object;
    //   1081: checkcast androidx/viewpager/widget/ViewPager$e
    //   1084: astore #13
    //   1086: iload #8
    //   1088: istore_1
    //   1089: fload_2
    //   1090: fstore #4
    //   1092: iload #8
    //   1094: aload #13
    //   1096: getfield b : I
    //   1099: if_icmple -> 1145
    //   1102: iload #8
    //   1104: istore_1
    //   1105: fload_2
    //   1106: fstore #4
    //   1108: iload #5
    //   1110: aload_0
    //   1111: getfield p : Ljava/util/ArrayList;
    //   1114: invokevirtual size : ()I
    //   1117: iconst_1
    //   1118: isub
    //   1119: if_icmpge -> 1145
    //   1122: iload #5
    //   1124: iconst_1
    //   1125: iadd
    //   1126: istore #5
    //   1128: aload_0
    //   1129: getfield p : Ljava/util/ArrayList;
    //   1132: iload #5
    //   1134: invokevirtual get : (I)Ljava/lang/Object;
    //   1137: checkcast androidx/viewpager/widget/ViewPager$e
    //   1140: astore #13
    //   1142: goto -> 1086
    //   1145: iload_1
    //   1146: aload #13
    //   1148: getfield b : I
    //   1151: if_icmpge -> 1176
    //   1154: fload #4
    //   1156: aload_0
    //   1157: getfield s : Lhq;
    //   1160: iload_1
    //   1161: invokevirtual getPageWidth : (I)F
    //   1164: fload_3
    //   1165: fadd
    //   1166: fadd
    //   1167: fstore #4
    //   1169: iload_1
    //   1170: iconst_1
    //   1171: iadd
    //   1172: istore_1
    //   1173: goto -> 1145
    //   1176: aload #13
    //   1178: fload #4
    //   1180: putfield e : F
    //   1183: fload #4
    //   1185: aload #13
    //   1187: getfield d : F
    //   1190: fload_3
    //   1191: fadd
    //   1192: fadd
    //   1193: fstore_2
    //   1194: goto -> 1045
    //   1197: iload_1
    //   1198: iload #5
    //   1200: if_icmple -> 1355
    //   1203: aload_0
    //   1204: getfield p : Ljava/util/ArrayList;
    //   1207: invokevirtual size : ()I
    //   1210: iconst_1
    //   1211: isub
    //   1212: istore #5
    //   1214: aload #15
    //   1216: getfield e : F
    //   1219: fstore_2
    //   1220: iload_1
    //   1221: iconst_1
    //   1222: isub
    //   1223: istore #8
    //   1225: iload #8
    //   1227: aload #14
    //   1229: getfield b : I
    //   1232: if_icmplt -> 1355
    //   1235: iload #5
    //   1237: iflt -> 1355
    //   1240: aload_0
    //   1241: getfield p : Ljava/util/ArrayList;
    //   1244: iload #5
    //   1246: invokevirtual get : (I)Ljava/lang/Object;
    //   1249: checkcast androidx/viewpager/widget/ViewPager$e
    //   1252: astore #13
    //   1254: fload_2
    //   1255: fstore #4
    //   1257: iload #8
    //   1259: istore_1
    //   1260: iload #8
    //   1262: aload #13
    //   1264: getfield b : I
    //   1267: if_icmpge -> 1304
    //   1270: fload_2
    //   1271: fstore #4
    //   1273: iload #8
    //   1275: istore_1
    //   1276: iload #5
    //   1278: ifle -> 1304
    //   1281: iload #5
    //   1283: iconst_1
    //   1284: isub
    //   1285: istore #5
    //   1287: aload_0
    //   1288: getfield p : Ljava/util/ArrayList;
    //   1291: iload #5
    //   1293: invokevirtual get : (I)Ljava/lang/Object;
    //   1296: checkcast androidx/viewpager/widget/ViewPager$e
    //   1299: astore #13
    //   1301: goto -> 1254
    //   1304: iload_1
    //   1305: aload #13
    //   1307: getfield b : I
    //   1310: if_icmple -> 1335
    //   1313: fload #4
    //   1315: aload_0
    //   1316: getfield s : Lhq;
    //   1319: iload_1
    //   1320: invokevirtual getPageWidth : (I)F
    //   1323: fload_3
    //   1324: fadd
    //   1325: fsub
    //   1326: fstore #4
    //   1328: iload_1
    //   1329: iconst_1
    //   1330: isub
    //   1331: istore_1
    //   1332: goto -> 1304
    //   1335: fload #4
    //   1337: aload #13
    //   1339: getfield d : F
    //   1342: fload_3
    //   1343: fadd
    //   1344: fsub
    //   1345: fstore_2
    //   1346: aload #13
    //   1348: fload_2
    //   1349: putfield e : F
    //   1352: goto -> 1220
    //   1355: aload_0
    //   1356: getfield p : Ljava/util/ArrayList;
    //   1359: invokevirtual size : ()I
    //   1362: istore #8
    //   1364: aload #14
    //   1366: getfield e : F
    //   1369: fstore_2
    //   1370: aload #14
    //   1372: getfield b : I
    //   1375: istore #5
    //   1377: iload #5
    //   1379: iconst_1
    //   1380: isub
    //   1381: istore_1
    //   1382: iload #5
    //   1384: ifne -> 1393
    //   1387: fload_2
    //   1388: fstore #4
    //   1390: goto -> 1397
    //   1393: ldc -3.4028235E38
    //   1395: fstore #4
    //   1397: aload_0
    //   1398: fload #4
    //   1400: putfield E : F
    //   1403: iload #9
    //   1405: iconst_1
    //   1406: isub
    //   1407: istore #9
    //   1409: iload #5
    //   1411: iload #9
    //   1413: if_icmpne -> 1430
    //   1416: aload #14
    //   1418: getfield d : F
    //   1421: fload_2
    //   1422: fadd
    //   1423: fconst_1
    //   1424: fsub
    //   1425: fstore #4
    //   1427: goto -> 1434
    //   1430: ldc 3.4028235E38
    //   1432: fstore #4
    //   1434: aload_0
    //   1435: fload #4
    //   1437: putfield F : F
    //   1440: iload #6
    //   1442: iconst_1
    //   1443: isub
    //   1444: istore #5
    //   1446: iload #5
    //   1448: iflt -> 1537
    //   1451: aload_0
    //   1452: getfield p : Ljava/util/ArrayList;
    //   1455: iload #5
    //   1457: invokevirtual get : (I)Ljava/lang/Object;
    //   1460: checkcast androidx/viewpager/widget/ViewPager$e
    //   1463: astore #13
    //   1465: aload #13
    //   1467: getfield b : I
    //   1470: istore #6
    //   1472: iload_1
    //   1473: iload #6
    //   1475: if_icmple -> 1498
    //   1478: fload_2
    //   1479: aload_0
    //   1480: getfield s : Lhq;
    //   1483: iload_1
    //   1484: invokevirtual getPageWidth : (I)F
    //   1487: fload_3
    //   1488: fadd
    //   1489: fsub
    //   1490: fstore_2
    //   1491: iload_1
    //   1492: iconst_1
    //   1493: isub
    //   1494: istore_1
    //   1495: goto -> 1465
    //   1498: fload_2
    //   1499: aload #13
    //   1501: getfield d : F
    //   1504: fload_3
    //   1505: fadd
    //   1506: fsub
    //   1507: fstore_2
    //   1508: aload #13
    //   1510: fload_2
    //   1511: putfield e : F
    //   1514: iload #6
    //   1516: ifne -> 1524
    //   1519: aload_0
    //   1520: fload_2
    //   1521: putfield E : F
    //   1524: iload #5
    //   1526: iconst_1
    //   1527: isub
    //   1528: istore #5
    //   1530: iload_1
    //   1531: iconst_1
    //   1532: isub
    //   1533: istore_1
    //   1534: goto -> 1446
    //   1537: aload #14
    //   1539: getfield e : F
    //   1542: aload #14
    //   1544: getfield d : F
    //   1547: fadd
    //   1548: fload_3
    //   1549: fadd
    //   1550: fstore_2
    //   1551: aload #14
    //   1553: getfield b : I
    //   1556: istore_1
    //   1557: iload_1
    //   1558: iconst_1
    //   1559: iadd
    //   1560: istore_1
    //   1561: iload #7
    //   1563: iload #8
    //   1565: if_icmpge -> 1660
    //   1568: aload_0
    //   1569: getfield p : Ljava/util/ArrayList;
    //   1572: iload #7
    //   1574: invokevirtual get : (I)Ljava/lang/Object;
    //   1577: checkcast androidx/viewpager/widget/ViewPager$e
    //   1580: astore #13
    //   1582: aload #13
    //   1584: getfield b : I
    //   1587: istore #5
    //   1589: iload_1
    //   1590: iload #5
    //   1592: if_icmpge -> 1615
    //   1595: fload_2
    //   1596: aload_0
    //   1597: getfield s : Lhq;
    //   1600: iload_1
    //   1601: invokevirtual getPageWidth : (I)F
    //   1604: fload_3
    //   1605: fadd
    //   1606: fadd
    //   1607: fstore_2
    //   1608: iload_1
    //   1609: iconst_1
    //   1610: iadd
    //   1611: istore_1
    //   1612: goto -> 1582
    //   1615: iload #5
    //   1617: iload #9
    //   1619: if_icmpne -> 1635
    //   1622: aload_0
    //   1623: aload #13
    //   1625: getfield d : F
    //   1628: fload_2
    //   1629: fadd
    //   1630: fconst_1
    //   1631: fsub
    //   1632: putfield F : F
    //   1635: aload #13
    //   1637: fload_2
    //   1638: putfield e : F
    //   1641: fload_2
    //   1642: aload #13
    //   1644: getfield d : F
    //   1647: fload_3
    //   1648: fadd
    //   1649: fadd
    //   1650: fstore_2
    //   1651: iload #7
    //   1653: iconst_1
    //   1654: iadd
    //   1655: istore #7
    //   1657: goto -> 1557
    //   1660: aload_0
    //   1661: getfield s : Lhq;
    //   1664: aload_0
    //   1665: aload_0
    //   1666: getfield t : I
    //   1669: aload #14
    //   1671: getfield a : Ljava/lang/Object;
    //   1674: invokevirtual setPrimaryItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   1677: aload_0
    //   1678: getfield s : Lhq;
    //   1681: aload_0
    //   1682: invokevirtual finishUpdate : (Landroid/view/ViewGroup;)V
    //   1685: aload_0
    //   1686: invokevirtual getChildCount : ()I
    //   1689: istore #5
    //   1691: iconst_0
    //   1692: istore_1
    //   1693: iload_1
    //   1694: iload #5
    //   1696: if_icmpge -> 1780
    //   1699: aload_0
    //   1700: iload_1
    //   1701: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1704: astore #14
    //   1706: aload #14
    //   1708: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1711: checkcast androidx/viewpager/widget/ViewPager$f
    //   1714: astore #13
    //   1716: aload #13
    //   1718: iload_1
    //   1719: putfield f : I
    //   1722: aload #13
    //   1724: getfield a : Z
    //   1727: ifne -> 1773
    //   1730: aload #13
    //   1732: getfield c : F
    //   1735: fconst_0
    //   1736: fcmpl
    //   1737: ifne -> 1773
    //   1740: aload_0
    //   1741: aload #14
    //   1743: invokevirtual i : (Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$e;
    //   1746: astore #14
    //   1748: aload #14
    //   1750: ifnull -> 1773
    //   1753: aload #13
    //   1755: aload #14
    //   1757: getfield d : F
    //   1760: putfield c : F
    //   1763: aload #13
    //   1765: aload #14
    //   1767: getfield b : I
    //   1770: putfield e : I
    //   1773: iload_1
    //   1774: iconst_1
    //   1775: iadd
    //   1776: istore_1
    //   1777: goto -> 1693
    //   1780: aload_0
    //   1781: invokevirtual hasFocus : ()Z
    //   1784: ifeq -> 1927
    //   1787: aload_0
    //   1788: invokevirtual findFocus : ()Landroid/view/View;
    //   1791: astore #13
    //   1793: aload #13
    //   1795: ifnull -> 1848
    //   1798: aload #13
    //   1800: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1803: astore #14
    //   1805: aload #14
    //   1807: aload_0
    //   1808: if_acmpeq -> 1837
    //   1811: aload #14
    //   1813: ifnull -> 1848
    //   1816: aload #14
    //   1818: instanceof android/view/View
    //   1821: ifne -> 1827
    //   1824: goto -> 1848
    //   1827: aload #14
    //   1829: checkcast android/view/View
    //   1832: astore #13
    //   1834: goto -> 1798
    //   1837: aload_0
    //   1838: aload #13
    //   1840: invokevirtual i : (Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$e;
    //   1843: astore #13
    //   1845: goto -> 1851
    //   1848: aconst_null
    //   1849: astore #13
    //   1851: aload #13
    //   1853: ifnull -> 1868
    //   1856: aload #13
    //   1858: getfield b : I
    //   1861: aload_0
    //   1862: getfield t : I
    //   1865: if_icmpeq -> 1927
    //   1868: iconst_0
    //   1869: istore_1
    //   1870: iload_1
    //   1871: aload_0
    //   1872: invokevirtual getChildCount : ()I
    //   1875: if_icmpge -> 1927
    //   1878: aload_0
    //   1879: iload_1
    //   1880: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1883: astore #13
    //   1885: aload_0
    //   1886: aload #13
    //   1888: invokevirtual i : (Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$e;
    //   1891: astore #14
    //   1893: aload #14
    //   1895: ifnull -> 1920
    //   1898: aload #14
    //   1900: getfield b : I
    //   1903: aload_0
    //   1904: getfield t : I
    //   1907: if_icmpne -> 1920
    //   1910: aload #13
    //   1912: iconst_2
    //   1913: invokevirtual requestFocus : (I)Z
    //   1916: ifeq -> 1920
    //   1919: return
    //   1920: iload_1
    //   1921: iconst_1
    //   1922: iadd
    //   1923: istore_1
    //   1924: goto -> 1870
    //   1927: return
    //   1928: aload_0
    //   1929: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1932: aload_0
    //   1933: invokevirtual getId : ()I
    //   1936: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1939: astore #13
    //   1941: goto -> 1953
    //   1944: aload_0
    //   1945: invokevirtual getId : ()I
    //   1948: invokestatic toHexString : (I)Ljava/lang/String;
    //   1951: astore #13
    //   1953: ldc_w 'The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: '
    //   1956: invokestatic x0 : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1959: astore #14
    //   1961: aload #14
    //   1963: aload_0
    //   1964: getfield g : I
    //   1967: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1970: pop
    //   1971: aload #14
    //   1973: ldc_w ', found: '
    //   1976: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1979: pop
    //   1980: aload #14
    //   1982: iload #9
    //   1984: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1987: pop
    //   1988: aload #14
    //   1990: ldc_w ' Pager id: '
    //   1993: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1996: pop
    //   1997: aload #14
    //   1999: aload #13
    //   2001: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2004: pop
    //   2005: aload #14
    //   2007: ldc_w ' Pager class: '
    //   2010: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2013: pop
    //   2014: aload #14
    //   2016: aload_0
    //   2017: invokevirtual getClass : ()Ljava/lang/Class;
    //   2020: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2023: pop
    //   2024: aload #14
    //   2026: ldc_w ' Problematic adapter: '
    //   2029: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2032: pop
    //   2033: aload #14
    //   2035: aload_0
    //   2036: getfield s : Lhq;
    //   2039: invokevirtual getClass : ()Ljava/lang/Class;
    //   2042: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2045: pop
    //   2046: new java/lang/IllegalStateException
    //   2049: dup
    //   2050: aload #14
    //   2052: invokevirtual toString : ()Ljava/lang/String;
    //   2055: invokespecial <init> : (Ljava/lang/String;)V
    //   2058: astore #13
    //   2060: goto -> 2066
    //   2063: aload #13
    //   2065: athrow
    //   2066: goto -> 2063
    //   2069: astore #13
    //   2071: goto -> 1944
    // Exception table:
    //   from	to	target	type
    //   1928	1941	2069	android/content/res/Resources$NotFoundException
  }
  
  public void removeView(View paramView) {
    if (this.H) {
      removeViewInLayout(paramView);
      return;
    } 
    super.removeView(paramView);
  }
  
  public final void s(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f;
    if (paramInt2 > 0 && !this.p.isEmpty()) {
      if (!this.x.isFinished()) {
        this.x.setFinalX(getCurrentItem() * getClientWidth());
        return;
      } 
      int k = getPaddingLeft();
      int m = getPaddingRight();
      int n = getPaddingLeft();
      int i1 = getPaddingRight();
      scrollTo((int)(getScrollX() / (paramInt2 - n - i1 + paramInt4) * (paramInt1 - k - m + paramInt3)), getScrollY());
      return;
    } 
    e e1 = k(this.t);
    if (e1 != null) {
      f = Math.min(e1.e, this.F);
    } else {
      f = 0.0F;
    } 
    paramInt1 = (int)(f * (paramInt1 - getPaddingLeft() - getPaddingRight()));
    if (paramInt1 != getScrollX()) {
      e(false);
      scrollTo(paramInt1, getScrollY());
    } 
  }
  
  public void setAdapter(hq paramhq) {
    hq hq1 = this.s;
    byte b = 0;
    if (hq1 != null) {
      hq1.setViewPagerObserver(null);
      this.s.startUpdate(this);
      int k;
      for (k = 0; k < this.p.size(); k++) {
        e e1 = this.p.get(k);
        this.s.destroyItem(this, e1.b, e1.a);
      } 
      this.s.finishUpdate(this);
      this.p.clear();
      for (k = 0; k < getChildCount(); k = m + 1) {
        int m = k;
        if (!((f)getChildAt(k).getLayoutParams()).a) {
          removeViewAt(k);
          m = k - 1;
        } 
      } 
      this.t = 0;
      scrollTo(0, 0);
    } 
    hq1 = this.s;
    this.s = paramhq;
    this.g = 0;
    if (paramhq != null) {
      if (this.z == null)
        this.z = new j(this); 
      this.s.setViewPagerObserver(this.z);
      this.J = false;
      boolean bool = this.f0;
      this.f0 = true;
      this.g = this.s.getCount();
      if (this.u >= 0) {
        this.s.restoreState(this.v, this.w);
        x(this.u, false, true, 0);
        this.u = -1;
        this.v = null;
        this.w = null;
      } else if (!bool) {
        r(this.t);
      } else {
        requestLayout();
      } 
    } 
    List<h> list = this.k0;
    if (list != null && !list.isEmpty()) {
      int m = this.k0.size();
      for (int k = b; k < m; k++)
        ((h)this.k0.get(k)).onAdapterChanged(this, hq1, paramhq); 
    } 
  }
  
  public void setCurrentItem(int paramInt) {
    this.J = false;
    x(paramInt, this.f0 ^ true, false, 0);
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    int k = paramInt;
    if (paramInt < 1)
      k = 1; 
    if (k != this.K) {
      this.K = k;
      r(this.t);
    } 
  }
  
  @Deprecated
  public void setOnPageChangeListener(i parami) {
    this.j0 = parami;
  }
  
  public void setPageMargin(int paramInt) {
    int k = this.A;
    this.A = paramInt;
    int m = getWidth();
    s(m, m, paramInt, k);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt) {
    setPageMarginDrawable(ma.getDrawable(getContext(), paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable) {
    boolean bool;
    this.B = paramDrawable;
    if (paramDrawable != null)
      refreshDrawableState(); 
    if (paramDrawable == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
  }
  
  public void setScrollState(int paramInt) {
    if (this.m0 == paramInt)
      return; 
    this.m0 = paramInt;
    i i1 = this.j0;
    if (i1 != null)
      i1.onPageScrollStateChanged(paramInt); 
    List<i> list = this.i0;
    if (list != null) {
      int k = 0;
      int m = list.size();
      while (k < m) {
        i i2 = this.i0.get(k);
        if (i2 != null)
          i2.onPageScrollStateChanged(paramInt); 
        k++;
      } 
    } 
  }
  
  public final void t(boolean paramBoolean) {
    ViewParent viewParent = getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(paramBoolean); 
  }
  
  public final boolean u() {
    this.U = -1;
    boolean bool = false;
    this.L = false;
    this.M = false;
    VelocityTracker velocityTracker = this.V;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.V = null;
    } 
    this.d0.onRelease();
    this.e0.onRelease();
    if (this.d0.isFinished() || this.e0.isFinished())
      bool = true; 
    return bool;
  }
  
  public final void v(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2) {
    int k;
    e e1 = k(paramInt1);
    if (e1 != null) {
      float f = getClientWidth();
      k = (int)(Math.max(this.E, Math.min(e1.e, this.F)) * f);
    } else {
      k = 0;
    } 
    if (paramBoolean1) {
      if (getChildCount() == 0) {
        setScrollingCacheEnabled(false);
      } else {
        int m;
        Scroller scroller = this.x;
        if (scroller != null && !scroller.isFinished()) {
          m = 1;
        } else {
          m = 0;
        } 
        if (m) {
          if (this.y) {
            m = this.x.getCurrX();
          } else {
            m = this.x.getStartX();
          } 
          this.x.abortAnimation();
          setScrollingCacheEnabled(false);
        } else {
          m = getScrollX();
        } 
        int n = getScrollY();
        k -= m;
        int i1 = 0 - n;
        if (k == 0 && i1 == 0) {
          e(false);
          r(this.t);
          setScrollState(0);
        } else {
          setScrollingCacheEnabled(true);
          setScrollState(2);
          int i2 = getClientWidth();
          int i3 = i2 / 2;
          float f2 = Math.abs(k);
          float f1 = i2;
          float f3 = Math.min(1.0F, f2 * 1.0F / f1);
          f2 = i3;
          f3 = (float)Math.sin(((f3 - 0.5F) * 0.47123894F));
          paramInt2 = Math.abs(paramInt2);
          if (paramInt2 > 0) {
            paramInt2 = Math.round(Math.abs((f3 * f2 + f2) / paramInt2) * 1000.0F) * 4;
          } else {
            f2 = this.s.getPageWidth(this.t);
            paramInt2 = (int)((Math.abs(k) / (f2 * f1 + this.A) + 1.0F) * 100.0F);
          } 
          paramInt2 = Math.min(paramInt2, 600);
          this.y = false;
          this.x.startScroll(m, n, k, i1, paramInt2);
          AtomicInteger atomicInteger = fe.a;
          fe.d.k((View)this);
        } 
      } 
      if (paramBoolean2) {
        g(paramInt1);
        return;
      } 
    } else {
      if (paramBoolean2)
        g(paramInt1); 
      e(false);
      scrollTo(k, 0);
      p(k);
    } 
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.B);
  }
  
  public void w(int paramInt, boolean paramBoolean) {
    this.J = false;
    x(paramInt, paramBoolean, false, 0);
  }
  
  public void x(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    int k;
    hq hq1 = this.s;
    boolean bool = false;
    if (hq1 == null || hq1.getCount() <= 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (!paramBoolean2 && this.t == paramInt1 && this.p.size() != 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (paramInt1 < 0) {
      k = 0;
    } else {
      k = paramInt1;
      if (paramInt1 >= this.s.getCount())
        k = this.s.getCount() - 1; 
    } 
    paramInt1 = this.K;
    int m = this.t;
    if (k > m + paramInt1 || k < m - paramInt1)
      for (paramInt1 = 0; paramInt1 < this.p.size(); paramInt1++)
        ((e)this.p.get(paramInt1)).c = true;  
    paramBoolean2 = bool;
    if (this.t != k)
      paramBoolean2 = true; 
    if (this.f0) {
      this.t = k;
      if (paramBoolean2)
        g(k); 
      requestLayout();
      return;
    } 
    r(k);
    v(k, paramBoolean1, paramInt2, paramBoolean2);
  }
  
  public static final class a implements Comparator<e> {
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      return ((ViewPager.e)param1Object1).b - ((ViewPager.e)param1Object2).b;
    }
  }
  
  public static final class b implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  public class c implements Runnable {
    public c(ViewPager this$0) {}
    
    public void run() {
      this.b.setScrollState(0);
      ViewPager viewPager = this.b;
      viewPager.r(viewPager.t);
    }
  }
  
  @Inherited
  @Retention(RetentionPolicy.RUNTIME)
  @Target({ElementType.TYPE})
  public static @interface d {}
  
  public static class e {
    public Object a;
    
    public int b;
    
    public boolean c;
    
    public float d;
    
    public float e;
  }
  
  public static class f extends ViewGroup.LayoutParams {
    public boolean a;
    
    public int b;
    
    public float c = 0.0F;
    
    public boolean d;
    
    public int e;
    
    public int f;
    
    public f() {
      super(-1, -1);
    }
    
    public f(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ViewPager.b);
      this.b = typedArray.getInteger(0, 48);
      typedArray.recycle();
    }
  }
  
  public class g extends hd {
    public g(ViewPager this$0) {}
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ViewPager.class.getName());
      hq hq = this.a.s;
      boolean bool = true;
      if (hq == null || hq.getCount() <= 1)
        bool = false; 
      param1AccessibilityEvent.setScrollable(bool);
      if (param1AccessibilityEvent.getEventType() == 4096) {
        hq = this.a.s;
        if (hq != null) {
          param1AccessibilityEvent.setItemCount(hq.getCount());
          param1AccessibilityEvent.setFromIndex(this.a.t);
          param1AccessibilityEvent.setToIndex(this.a.t);
        } 
      } 
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, oe param1oe) {
      boolean bool;
      super.onInitializeAccessibilityNodeInfo(param1View, param1oe);
      String str = ViewPager.class.getName();
      param1oe.b.setClassName(str);
      hq hq = this.a.s;
      if (hq != null && hq.getCount() > 1) {
        bool = true;
      } else {
        bool = false;
      } 
      param1oe.b.setScrollable(bool);
      if (this.a.canScrollHorizontally(1))
        param1oe.b.addAction(4096); 
      if (this.a.canScrollHorizontally(-1))
        param1oe.b.addAction(8192); 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        if (this.a.canScrollHorizontally(-1)) {
          ViewPager viewPager = this.a;
          viewPager.setCurrentItem(viewPager.t - 1);
          return true;
        } 
        return false;
      } 
      if (this.a.canScrollHorizontally(1)) {
        ViewPager viewPager = this.a;
        viewPager.setCurrentItem(viewPager.t + 1);
        return true;
      } 
      return false;
    }
  }
  
  public static interface h {
    void onAdapterChanged(ViewPager param1ViewPager, hq param1hq1, hq param1hq2);
  }
  
  public static interface i {
    void onPageScrollStateChanged(int param1Int);
    
    void onPageScrolled(int param1Int1, float param1Float, int param1Int2);
    
    void onPageSelected(int param1Int);
  }
  
  public class j extends DataSetObserver {
    public j(ViewPager this$0) {}
    
    public void onChanged() {
      this.a.f();
    }
    
    public void onInvalidated() {
      this.a.f();
    }
  }
  
  public static class k extends nf {
    public static final Parcelable.Creator<k> CREATOR = (Parcelable.Creator<k>)new a();
    
    public int b;
    
    public Parcelable c;
    
    public ClassLoader d;
    
    public k(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      ClassLoader classLoader = param1ClassLoader;
      if (param1ClassLoader == null)
        classLoader = k.class.getClassLoader(); 
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readParcelable(classLoader);
      this.d = classLoader;
    }
    
    public k(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = s30.x0("FragmentPager.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" position=");
      return s30.l0(stringBuilder, this.b, "}");
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.b);
      param1Parcel.writeParcelable(this.c, param1Int);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<k> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new ViewPager.k(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new ViewPager.k(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new ViewPager.k[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<k> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new ViewPager.k(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager.k(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new ViewPager.k[param1Int];
    }
  }
  
  public static class l implements Comparator<View> {
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      param1Object1 = param1Object1.getLayoutParams();
      param1Object2 = param1Object2.getLayoutParams();
      boolean bool = ((ViewPager.f)param1Object1).a;
      return (bool != ((ViewPager.f)param1Object2).a) ? (bool ? 1 : -1) : (((ViewPager.f)param1Object1).e - ((ViewPager.f)param1Object2).e);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\viewpager\widget\ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */