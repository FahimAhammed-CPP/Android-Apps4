package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;
import eq;
import gq;
import java.util.Objects;

public class RemoteActionCompatParcelizer {
  public static RemoteActionCompat read(eq parameq) {
    gq gq;
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
    IconCompat iconCompat = remoteActionCompat.a;
    if (parameq.i(1))
      gq = parameq.o(); 
    remoteActionCompat.a = (IconCompat)gq;
    CharSequence charSequence = remoteActionCompat.b;
    if (parameq.i(2))
      charSequence = parameq.h(); 
    remoteActionCompat.b = charSequence;
    charSequence = remoteActionCompat.c;
    if (parameq.i(3))
      charSequence = parameq.h(); 
    remoteActionCompat.c = charSequence;
    remoteActionCompat.d = (PendingIntent)parameq.m((Parcelable)remoteActionCompat.d, 4);
    boolean bool = remoteActionCompat.e;
    if (parameq.i(5))
      bool = parameq.f(); 
    remoteActionCompat.e = bool;
    bool = remoteActionCompat.f;
    if (parameq.i(6))
      bool = parameq.f(); 
    remoteActionCompat.f = bool;
    return remoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, eq parameq) {
    Objects.requireNonNull(parameq);
    IconCompat iconCompat = paramRemoteActionCompat.a;
    parameq.p(1);
    parameq.w((gq)iconCompat);
    CharSequence charSequence = paramRemoteActionCompat.b;
    parameq.p(2);
    parameq.s(charSequence);
    charSequence = paramRemoteActionCompat.c;
    parameq.p(3);
    parameq.s(charSequence);
    PendingIntent pendingIntent = paramRemoteActionCompat.d;
    parameq.p(4);
    parameq.u((Parcelable)pendingIntent);
    boolean bool = paramRemoteActionCompat.e;
    parameq.p(5);
    parameq.q(bool);
    bool = paramRemoteActionCompat.f;
    parameq.p(6);
    parameq.q(bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\core\app\RemoteActionCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */