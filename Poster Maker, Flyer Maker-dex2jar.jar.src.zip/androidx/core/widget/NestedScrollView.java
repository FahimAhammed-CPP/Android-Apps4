package androidx.core.widget;

import af;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.activity.ComponentActivity;
import fe;
import hd;
import java.util.concurrent.atomic.AtomicInteger;
import oe;
import pd;
import qd;
import s30;
import sd;
import ud;

public class NestedScrollView extends FrameLayout implements sd, pd {
  public static final a b = new a();
  
  public static final int[] c = new int[] { 16843130 };
  
  public int A;
  
  public int B;
  
  public int C;
  
  public final int[] D;
  
  public final int[] E;
  
  public int F;
  
  public int G;
  
  public c H;
  
  public final ud I;
  
  public final qd J;
  
  public float K;
  
  public b L;
  
  public long d;
  
  public final Rect f;
  
  public OverScroller g;
  
  public EdgeEffect p;
  
  public EdgeEffect q;
  
  public int r;
  
  public boolean s;
  
  public boolean t;
  
  public View u;
  
  public boolean v;
  
  public VelocityTracker w;
  
  public boolean x;
  
  public boolean y;
  
  public int z;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, i);
    EdgeEffect edgeEffect;
    this.f = new Rect();
    this.s = true;
    this.t = false;
    this.u = null;
    this.v = false;
    this.y = true;
    this.C = -1;
    this.D = new int[2];
    this.E = new int[2];
    if (ComponentActivity.c.e0()) {
      edgeEffect = af.a(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.p = edgeEffect;
    if (ComponentActivity.c.e0()) {
      edgeEffect = af.a(paramContext, paramAttributeSet);
    } else {
      edgeEffect = new EdgeEffect(paramContext);
    } 
    this.q = edgeEffect;
    this.g = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.z = viewConfiguration.getScaledTouchSlop();
    this.A = viewConfiguration.getScaledMinimumFlingVelocity();
    this.B = viewConfiguration.getScaledMaximumFlingVelocity();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c, i, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.I = new ud();
    this.J = new qd((View)this);
    setNestedScrollingEnabled(true);
    fe.C((View)this, b);
  }
  
  public static int c(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.K == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.K = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.K;
  }
  
  public static boolean k(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && k((View)viewParent, paramView2));
  }
  
  public final void a() {
    this.g.abortAnimation();
    this.J.j(1);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && l(view2, i, getHeight())) {
      view2.getDrawingRect(this.f);
      offsetDescendantRectToMyCoords(view2, this.f);
      f(d(this.f));
      view2.requestFocus(paramInt);
    } else {
      int j;
      if (paramInt == 33 && getScrollY() < i) {
        j = getScrollY();
      } else {
        j = i;
        if (paramInt == 130) {
          j = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            j = view2.getBottom();
            int k = layoutParams.bottomMargin;
            int m = getScrollY();
            j = Math.min(j + k - getHeight() + m - getPaddingBottom(), i);
          } 
        } 
      } 
      if (j == 0)
        return false; 
      if (paramInt != 130)
        j = -j; 
      f(j);
    } 
    if (view1 != null && view1.isFocused() && (l(view1, 0, getHeight()) ^ true) != 0) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield g : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield g : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield G : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield G : I
    //   39: aload_0
    //   40: getfield E : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual e : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield E : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 160
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: invokevirtual o : (IIIIIIII)Z
    //   105: pop
    //   106: aload_0
    //   107: invokevirtual getScrollY : ()I
    //   110: iload_1
    //   111: isub
    //   112: istore_1
    //   113: iload_2
    //   114: iload_1
    //   115: isub
    //   116: istore_2
    //   117: aload_0
    //   118: getfield E : [I
    //   121: astore #6
    //   123: aload #6
    //   125: iconst_1
    //   126: iconst_0
    //   127: iastore
    //   128: aload_0
    //   129: getfield D : [I
    //   132: astore #7
    //   134: aload_0
    //   135: getfield J : Lqd;
    //   138: iconst_0
    //   139: iload_1
    //   140: iconst_0
    //   141: iload_2
    //   142: aload #7
    //   144: iconst_1
    //   145: aload #6
    //   147: invokevirtual e : (IIII[II[I)Z
    //   150: pop
    //   151: iload_2
    //   152: aload_0
    //   153: getfield E : [I
    //   156: iconst_1
    //   157: iaload
    //   158: isub
    //   159: istore_1
    //   160: iload_1
    //   161: ifeq -> 257
    //   164: aload_0
    //   165: invokevirtual getOverScrollMode : ()I
    //   168: istore #5
    //   170: iload #5
    //   172: ifeq -> 190
    //   175: iload_3
    //   176: istore_2
    //   177: iload #5
    //   179: iconst_1
    //   180: if_icmpne -> 192
    //   183: iload_3
    //   184: istore_2
    //   185: iload #4
    //   187: ifle -> 192
    //   190: iconst_1
    //   191: istore_2
    //   192: iload_2
    //   193: ifeq -> 253
    //   196: iload_1
    //   197: ifge -> 228
    //   200: aload_0
    //   201: getfield p : Landroid/widget/EdgeEffect;
    //   204: invokevirtual isFinished : ()Z
    //   207: ifeq -> 253
    //   210: aload_0
    //   211: getfield p : Landroid/widget/EdgeEffect;
    //   214: aload_0
    //   215: getfield g : Landroid/widget/OverScroller;
    //   218: invokevirtual getCurrVelocity : ()F
    //   221: f2i
    //   222: invokevirtual onAbsorb : (I)V
    //   225: goto -> 253
    //   228: aload_0
    //   229: getfield q : Landroid/widget/EdgeEffect;
    //   232: invokevirtual isFinished : ()Z
    //   235: ifeq -> 253
    //   238: aload_0
    //   239: getfield q : Landroid/widget/EdgeEffect;
    //   242: aload_0
    //   243: getfield g : Landroid/widget/OverScroller;
    //   246: invokevirtual getCurrVelocity : ()F
    //   249: f2i
    //   250: invokevirtual onAbsorb : (I)V
    //   253: aload_0
    //   254: invokevirtual a : ()V
    //   257: aload_0
    //   258: getfield g : Landroid/widget/OverScroller;
    //   261: invokevirtual isFinished : ()Z
    //   264: ifne -> 277
    //   267: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   270: astore #6
    //   272: aload_0
    //   273: invokestatic k : (Landroid/view/View;)V
    //   276: return
    //   277: aload_0
    //   278: getfield J : Lqd;
    //   281: iconst_1
    //   282: invokevirtual j : (I)V
    //   285: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int j = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (j == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    j = view.getBottom() + layoutParams.bottomMargin;
    int k = getScrollY();
    int m = Math.max(0, j - i);
    if (k < 0)
      return j - k; 
    i = j;
    if (k > m)
      i = j + k - m; 
    return i;
  }
  
  public int d(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int m = getHeight();
    int j = getScrollY();
    int k = j + m;
    int n = getVerticalFadingEdgeLength();
    i = j;
    if (paramRect.top > 0)
      i = j + n; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      j = k - n;
    } else {
      j = k;
    } 
    n = paramRect.bottom;
    if (n > j && paramRect.top > i) {
      if (paramRect.height() > m) {
        i = paramRect.top - i;
      } else {
        i = paramRect.bottom - j;
      } 
      return Math.min(i + 0, view.getBottom() + layoutParams.bottomMargin - k);
    } 
    k = bool;
    if (paramRect.top < i) {
      k = bool;
      if (n < j) {
        if (paramRect.height() > m) {
          i = 0 - j - paramRect.bottom;
        } else {
          i = 0 - i - paramRect.top;
        } 
        k = Math.max(i, -getScrollY());
      } 
    } 
    return k;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || g(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.J.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.J.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return e(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.J.d(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: invokevirtual getScrollY : ()I
    //   9: istore #9
    //   11: aload_0
    //   12: getfield p : Landroid/widget/EdgeEffect;
    //   15: invokevirtual isFinished : ()Z
    //   18: istore #12
    //   20: iconst_0
    //   21: istore #6
    //   23: iload #12
    //   25: ifne -> 203
    //   28: aload_1
    //   29: invokevirtual save : ()I
    //   32: istore #10
    //   34: aload_0
    //   35: invokevirtual getWidth : ()I
    //   38: istore_2
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: istore #8
    //   45: iconst_0
    //   46: iload #9
    //   48: invokestatic min : (II)I
    //   51: istore #7
    //   53: getstatic android/os/Build$VERSION.SDK_INT : I
    //   56: istore #11
    //   58: iload #11
    //   60: bipush #21
    //   62: if_icmplt -> 80
    //   65: aload_0
    //   66: invokevirtual getClipToPadding : ()Z
    //   69: ifeq -> 75
    //   72: goto -> 80
    //   75: iconst_0
    //   76: istore_3
    //   77: goto -> 101
    //   80: aload_0
    //   81: invokevirtual getPaddingLeft : ()I
    //   84: istore_3
    //   85: iload_2
    //   86: aload_0
    //   87: invokevirtual getPaddingRight : ()I
    //   90: iload_3
    //   91: iadd
    //   92: isub
    //   93: istore_2
    //   94: aload_0
    //   95: invokevirtual getPaddingLeft : ()I
    //   98: iconst_0
    //   99: iadd
    //   100: istore_3
    //   101: iload #8
    //   103: istore #5
    //   105: iload #7
    //   107: istore #4
    //   109: iload #11
    //   111: bipush #21
    //   113: if_icmplt -> 158
    //   116: iload #8
    //   118: istore #5
    //   120: iload #7
    //   122: istore #4
    //   124: aload_0
    //   125: invokevirtual getClipToPadding : ()Z
    //   128: ifeq -> 158
    //   131: aload_0
    //   132: invokevirtual getPaddingTop : ()I
    //   135: istore #4
    //   137: iload #8
    //   139: aload_0
    //   140: invokevirtual getPaddingBottom : ()I
    //   143: iload #4
    //   145: iadd
    //   146: isub
    //   147: istore #5
    //   149: iload #7
    //   151: aload_0
    //   152: invokevirtual getPaddingTop : ()I
    //   155: iadd
    //   156: istore #4
    //   158: aload_1
    //   159: iload_3
    //   160: i2f
    //   161: iload #4
    //   163: i2f
    //   164: invokevirtual translate : (FF)V
    //   167: aload_0
    //   168: getfield p : Landroid/widget/EdgeEffect;
    //   171: iload_2
    //   172: iload #5
    //   174: invokevirtual setSize : (II)V
    //   177: aload_0
    //   178: getfield p : Landroid/widget/EdgeEffect;
    //   181: aload_1
    //   182: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   185: ifeq -> 197
    //   188: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   191: astore #13
    //   193: aload_0
    //   194: invokestatic k : (Landroid/view/View;)V
    //   197: aload_1
    //   198: iload #10
    //   200: invokevirtual restoreToCount : (I)V
    //   203: aload_0
    //   204: getfield q : Landroid/widget/EdgeEffect;
    //   207: invokevirtual isFinished : ()Z
    //   210: ifne -> 406
    //   213: aload_1
    //   214: invokevirtual save : ()I
    //   217: istore #10
    //   219: aload_0
    //   220: invokevirtual getWidth : ()I
    //   223: istore #4
    //   225: aload_0
    //   226: invokevirtual getHeight : ()I
    //   229: istore #7
    //   231: aload_0
    //   232: invokevirtual getScrollRange : ()I
    //   235: iload #9
    //   237: invokestatic max : (II)I
    //   240: iload #7
    //   242: iadd
    //   243: istore #8
    //   245: getstatic android/os/Build$VERSION.SDK_INT : I
    //   248: istore #9
    //   250: iload #9
    //   252: bipush #21
    //   254: if_icmplt -> 270
    //   257: iload #6
    //   259: istore_3
    //   260: iload #4
    //   262: istore_2
    //   263: aload_0
    //   264: invokevirtual getClipToPadding : ()Z
    //   267: ifeq -> 292
    //   270: aload_0
    //   271: invokevirtual getPaddingLeft : ()I
    //   274: istore_2
    //   275: iload #4
    //   277: aload_0
    //   278: invokevirtual getPaddingRight : ()I
    //   281: iload_2
    //   282: iadd
    //   283: isub
    //   284: istore_2
    //   285: iconst_0
    //   286: aload_0
    //   287: invokevirtual getPaddingLeft : ()I
    //   290: iadd
    //   291: istore_3
    //   292: iload #8
    //   294: istore #5
    //   296: iload #7
    //   298: istore #4
    //   300: iload #9
    //   302: bipush #21
    //   304: if_icmplt -> 349
    //   307: iload #8
    //   309: istore #5
    //   311: iload #7
    //   313: istore #4
    //   315: aload_0
    //   316: invokevirtual getClipToPadding : ()Z
    //   319: ifeq -> 349
    //   322: aload_0
    //   323: invokevirtual getPaddingTop : ()I
    //   326: istore #4
    //   328: iload #7
    //   330: aload_0
    //   331: invokevirtual getPaddingBottom : ()I
    //   334: iload #4
    //   336: iadd
    //   337: isub
    //   338: istore #4
    //   340: iload #8
    //   342: aload_0
    //   343: invokevirtual getPaddingBottom : ()I
    //   346: isub
    //   347: istore #5
    //   349: aload_1
    //   350: iload_3
    //   351: iload_2
    //   352: isub
    //   353: i2f
    //   354: iload #5
    //   356: i2f
    //   357: invokevirtual translate : (FF)V
    //   360: aload_1
    //   361: ldc_w 180.0
    //   364: iload_2
    //   365: i2f
    //   366: fconst_0
    //   367: invokevirtual rotate : (FFF)V
    //   370: aload_0
    //   371: getfield q : Landroid/widget/EdgeEffect;
    //   374: iload_2
    //   375: iload #4
    //   377: invokevirtual setSize : (II)V
    //   380: aload_0
    //   381: getfield q : Landroid/widget/EdgeEffect;
    //   384: aload_1
    //   385: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   388: ifeq -> 400
    //   391: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   394: astore #13
    //   396: aload_0
    //   397: invokestatic k : (Landroid/view/View;)V
    //   400: aload_1
    //   401: iload #10
    //   403: invokevirtual restoreToCount : (I)V
    //   406: return
  }
  
  public boolean e(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.J.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public final void f(int paramInt) {
    if (paramInt != 0) {
      if (this.y) {
        t(0, paramInt, 250, false);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public boolean g(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Landroid/graphics/Rect;
    //   4: invokevirtual setEmpty : ()V
    //   7: aload_0
    //   8: invokevirtual getChildCount : ()I
    //   11: istore_2
    //   12: iconst_0
    //   13: istore #6
    //   15: iload_2
    //   16: ifle -> 75
    //   19: aload_0
    //   20: iconst_0
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: astore #7
    //   26: aload #7
    //   28: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   31: checkcast android/widget/FrameLayout$LayoutParams
    //   34: astore #8
    //   36: aload #7
    //   38: invokevirtual getHeight : ()I
    //   41: aload #8
    //   43: getfield topMargin : I
    //   46: iadd
    //   47: aload #8
    //   49: getfield bottomMargin : I
    //   52: iadd
    //   53: aload_0
    //   54: invokevirtual getHeight : ()I
    //   57: aload_0
    //   58: invokevirtual getPaddingTop : ()I
    //   61: isub
    //   62: aload_0
    //   63: invokevirtual getPaddingBottom : ()I
    //   66: isub
    //   67: if_icmple -> 75
    //   70: iconst_1
    //   71: istore_2
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_2
    //   78: ifne -> 150
    //   81: aload_0
    //   82: invokevirtual isFocused : ()Z
    //   85: ifeq -> 148
    //   88: aload_1
    //   89: invokevirtual getKeyCode : ()I
    //   92: iconst_4
    //   93: if_icmpeq -> 148
    //   96: aload_0
    //   97: invokevirtual findFocus : ()Landroid/view/View;
    //   100: astore #7
    //   102: aload #7
    //   104: astore_1
    //   105: aload #7
    //   107: aload_0
    //   108: if_acmpne -> 113
    //   111: aconst_null
    //   112: astore_1
    //   113: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   116: aload_0
    //   117: aload_1
    //   118: sipush #130
    //   121: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   124: astore_1
    //   125: aload_1
    //   126: ifnull -> 146
    //   129: aload_1
    //   130: aload_0
    //   131: if_acmpeq -> 146
    //   134: aload_1
    //   135: sipush #130
    //   138: invokevirtual requestFocus : (I)Z
    //   141: ifeq -> 146
    //   144: iconst_1
    //   145: ireturn
    //   146: iconst_0
    //   147: ireturn
    //   148: iconst_0
    //   149: ireturn
    //   150: aload_1
    //   151: invokevirtual getAction : ()I
    //   154: ifne -> 421
    //   157: aload_1
    //   158: invokevirtual getKeyCode : ()I
    //   161: istore_3
    //   162: bipush #33
    //   164: istore_2
    //   165: iload_3
    //   166: bipush #19
    //   168: if_icmpeq -> 399
    //   171: iload_3
    //   172: bipush #20
    //   174: if_icmpeq -> 376
    //   177: iload_3
    //   178: bipush #62
    //   180: if_icmpeq -> 185
    //   183: iconst_0
    //   184: ireturn
    //   185: aload_1
    //   186: invokevirtual isShiftPressed : ()Z
    //   189: ifeq -> 195
    //   192: goto -> 199
    //   195: sipush #130
    //   198: istore_2
    //   199: iload_2
    //   200: sipush #130
    //   203: if_icmpne -> 211
    //   206: iconst_1
    //   207: istore_3
    //   208: goto -> 213
    //   211: iconst_0
    //   212: istore_3
    //   213: aload_0
    //   214: invokevirtual getHeight : ()I
    //   217: istore #4
    //   219: iload_3
    //   220: ifeq -> 312
    //   223: aload_0
    //   224: getfield f : Landroid/graphics/Rect;
    //   227: aload_0
    //   228: invokevirtual getScrollY : ()I
    //   231: iload #4
    //   233: iadd
    //   234: putfield top : I
    //   237: aload_0
    //   238: invokevirtual getChildCount : ()I
    //   241: istore_3
    //   242: iload_3
    //   243: ifle -> 343
    //   246: aload_0
    //   247: iload_3
    //   248: iconst_1
    //   249: isub
    //   250: invokevirtual getChildAt : (I)Landroid/view/View;
    //   253: astore_1
    //   254: aload_1
    //   255: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   258: checkcast android/widget/FrameLayout$LayoutParams
    //   261: astore #7
    //   263: aload_1
    //   264: invokevirtual getBottom : ()I
    //   267: istore_3
    //   268: aload #7
    //   270: getfield bottomMargin : I
    //   273: istore #5
    //   275: aload_0
    //   276: invokevirtual getPaddingBottom : ()I
    //   279: iload_3
    //   280: iload #5
    //   282: iadd
    //   283: iadd
    //   284: istore_3
    //   285: aload_0
    //   286: getfield f : Landroid/graphics/Rect;
    //   289: astore_1
    //   290: aload_1
    //   291: getfield top : I
    //   294: iload #4
    //   296: iadd
    //   297: iload_3
    //   298: if_icmple -> 343
    //   301: aload_1
    //   302: iload_3
    //   303: iload #4
    //   305: isub
    //   306: putfield top : I
    //   309: goto -> 343
    //   312: aload_0
    //   313: getfield f : Landroid/graphics/Rect;
    //   316: aload_0
    //   317: invokevirtual getScrollY : ()I
    //   320: iload #4
    //   322: isub
    //   323: putfield top : I
    //   326: aload_0
    //   327: getfield f : Landroid/graphics/Rect;
    //   330: astore_1
    //   331: aload_1
    //   332: getfield top : I
    //   335: ifge -> 343
    //   338: aload_1
    //   339: iconst_0
    //   340: putfield top : I
    //   343: aload_0
    //   344: getfield f : Landroid/graphics/Rect;
    //   347: astore_1
    //   348: aload_1
    //   349: getfield top : I
    //   352: istore_3
    //   353: iload #4
    //   355: iload_3
    //   356: iadd
    //   357: istore #4
    //   359: aload_1
    //   360: iload #4
    //   362: putfield bottom : I
    //   365: aload_0
    //   366: iload_2
    //   367: iload_3
    //   368: iload #4
    //   370: invokevirtual r : (III)Z
    //   373: pop
    //   374: iconst_0
    //   375: ireturn
    //   376: aload_1
    //   377: invokevirtual isAltPressed : ()Z
    //   380: ifne -> 391
    //   383: aload_0
    //   384: sipush #130
    //   387: invokevirtual b : (I)Z
    //   390: ireturn
    //   391: aload_0
    //   392: sipush #130
    //   395: invokevirtual i : (I)Z
    //   398: ireturn
    //   399: aload_1
    //   400: invokevirtual isAltPressed : ()Z
    //   403: ifne -> 413
    //   406: aload_0
    //   407: bipush #33
    //   409: invokevirtual b : (I)Z
    //   412: ireturn
    //   413: aload_0
    //   414: bipush #33
    //   416: invokevirtual i : (I)Z
    //   419: istore #6
    //   421: iload #6
    //   423: ireturn
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int j = getHeight();
    int k = getPaddingBottom();
    j = view.getBottom() + layoutParams.bottomMargin - getScrollY() - j - k;
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.I.a();
  }
  
  public int getScrollRange() {
    int j = getChildCount();
    int i = 0;
    if (j > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public void h(int paramInt) {
    if (getChildCount() > 0) {
      this.g.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      q(true);
    } 
  }
  
  public boolean hasNestedScrollingParent() {
    return j(0);
  }
  
  public boolean i(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    Rect rect = this.f;
    rect.top = 0;
    rect.bottom = j;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        Rect rect2 = this.f;
        i = view.getBottom();
        int k = layoutParams.bottomMargin;
        rect2.bottom = getPaddingBottom() + i + k;
        Rect rect1 = this.f;
        rect1.top = rect1.bottom - j;
      } 
    } 
    rect = this.f;
    return r(paramInt, rect.top, rect.bottom);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.J.d;
  }
  
  public boolean j(int paramInt) {
    return (this.J.f(paramInt) != null);
  }
  
  public final boolean l(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.f);
    offsetDescendantRectToMyCoords(paramView, this.f);
    return (this.f.bottom + paramInt1 >= getScrollY() && this.f.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public final void m(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.J.e(0, i, 0, paramInt1 - i, null, paramInt2, paramArrayOfint);
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramInt2 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt2, layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramInt3 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt3 + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public final void n(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.C) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.r = (int)paramMotionEvent.getY(i);
      this.C = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.w;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean o(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #11
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: istore #9
    //   12: aload_0
    //   13: invokevirtual computeHorizontalScrollExtent : ()I
    //   16: istore #10
    //   18: iconst_0
    //   19: istore #14
    //   21: iload #9
    //   23: iload #10
    //   25: if_icmple -> 34
    //   28: iconst_1
    //   29: istore #9
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #9
    //   37: aload_0
    //   38: invokevirtual computeVerticalScrollRange : ()I
    //   41: aload_0
    //   42: invokevirtual computeVerticalScrollExtent : ()I
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #10
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #10
    //   57: iload #11
    //   59: ifeq -> 82
    //   62: iload #11
    //   64: iconst_1
    //   65: if_icmpne -> 76
    //   68: iload #9
    //   70: ifeq -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #9
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #9
    //   85: iload #11
    //   87: ifeq -> 110
    //   90: iload #11
    //   92: iconst_1
    //   93: if_icmpne -> 104
    //   96: iload #10
    //   98: ifeq -> 104
    //   101: goto -> 110
    //   104: iconst_0
    //   105: istore #10
    //   107: goto -> 113
    //   110: iconst_1
    //   111: istore #10
    //   113: iload_3
    //   114: iload_1
    //   115: iadd
    //   116: istore_3
    //   117: iload #9
    //   119: ifne -> 127
    //   122: iconst_0
    //   123: istore_1
    //   124: goto -> 130
    //   127: iload #7
    //   129: istore_1
    //   130: iload #4
    //   132: iload_2
    //   133: iadd
    //   134: istore #4
    //   136: iload #10
    //   138: ifne -> 146
    //   141: iconst_0
    //   142: istore_2
    //   143: goto -> 149
    //   146: iload #8
    //   148: istore_2
    //   149: iload_1
    //   150: ineg
    //   151: istore #7
    //   153: iload_1
    //   154: iload #5
    //   156: iadd
    //   157: istore_1
    //   158: iload_2
    //   159: ineg
    //   160: istore #5
    //   162: iload_2
    //   163: iload #6
    //   165: iadd
    //   166: istore #6
    //   168: iload_3
    //   169: iload_1
    //   170: if_icmple -> 181
    //   173: iconst_1
    //   174: istore #12
    //   176: iload_1
    //   177: istore_2
    //   178: goto -> 198
    //   181: iload_3
    //   182: iload #7
    //   184: if_icmpge -> 193
    //   187: iload #7
    //   189: istore_1
    //   190: goto -> 173
    //   193: iconst_0
    //   194: istore #12
    //   196: iload_3
    //   197: istore_2
    //   198: iload #4
    //   200: iload #6
    //   202: if_icmple -> 214
    //   205: iload #6
    //   207: istore_1
    //   208: iconst_1
    //   209: istore #13
    //   211: goto -> 233
    //   214: iload #4
    //   216: iload #5
    //   218: if_icmpge -> 227
    //   221: iload #5
    //   223: istore_1
    //   224: goto -> 208
    //   227: iconst_0
    //   228: istore #13
    //   230: iload #4
    //   232: istore_1
    //   233: iload #13
    //   235: ifeq -> 263
    //   238: aload_0
    //   239: iconst_1
    //   240: invokevirtual j : (I)Z
    //   243: ifne -> 263
    //   246: aload_0
    //   247: getfield g : Landroid/widget/OverScroller;
    //   250: iload_2
    //   251: iload_1
    //   252: iconst_0
    //   253: iconst_0
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getScrollRange : ()I
    //   259: invokevirtual springBack : (IIIIII)Z
    //   262: pop
    //   263: aload_0
    //   264: iload_2
    //   265: iload_1
    //   266: iload #12
    //   268: iload #13
    //   270: invokevirtual onOverScrolled : (IIZZ)V
    //   273: iload #12
    //   275: ifne -> 287
    //   278: iload #14
    //   280: istore #12
    //   282: iload #13
    //   284: ifeq -> 290
    //   287: iconst_1
    //   288: istore #12
    //   290: iload #12
    //   292: ireturn
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.t = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.v) {
        float f = paramMotionEvent.getAxisValue(9);
        if (f != 0.0F) {
          int j = (int)(f * getVerticalScrollFactorCompat());
          int i = getScrollRange();
          int k = getScrollY();
          j = k - j;
          if (j < 0) {
            i = 0;
          } else if (j <= i) {
            i = j;
          } 
          if (i != k) {
            super.scrollTo(getScrollX(), i);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_2
    //   5: iconst_1
    //   6: istore #7
    //   8: iconst_1
    //   9: istore #6
    //   11: iload_2
    //   12: iconst_2
    //   13: if_icmpne -> 25
    //   16: aload_0
    //   17: getfield v : Z
    //   20: ifeq -> 25
    //   23: iconst_1
    //   24: ireturn
    //   25: iload_2
    //   26: sipush #255
    //   29: iand
    //   30: istore_2
    //   31: iload_2
    //   32: ifeq -> 240
    //   35: iload_2
    //   36: iconst_1
    //   37: if_icmpeq -> 182
    //   40: iload_2
    //   41: iconst_2
    //   42: if_icmpeq -> 67
    //   45: iload_2
    //   46: iconst_3
    //   47: if_icmpeq -> 182
    //   50: iload_2
    //   51: bipush #6
    //   53: if_icmpeq -> 59
    //   56: goto -> 471
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual n : (Landroid/view/MotionEvent;)V
    //   64: goto -> 471
    //   67: aload_0
    //   68: getfield C : I
    //   71: istore_2
    //   72: iload_2
    //   73: iconst_m1
    //   74: if_icmpne -> 80
    //   77: goto -> 471
    //   80: aload_1
    //   81: iload_2
    //   82: invokevirtual findPointerIndex : (I)I
    //   85: istore_2
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpne -> 94
    //   91: goto -> 471
    //   94: aload_1
    //   95: iload_2
    //   96: invokevirtual getY : (I)F
    //   99: f2i
    //   100: istore_2
    //   101: iload_2
    //   102: aload_0
    //   103: getfield r : I
    //   106: isub
    //   107: invokestatic abs : (I)I
    //   110: aload_0
    //   111: getfield z : I
    //   114: if_icmple -> 471
    //   117: iconst_2
    //   118: aload_0
    //   119: invokevirtual getNestedScrollAxes : ()I
    //   122: iand
    //   123: ifne -> 471
    //   126: aload_0
    //   127: iconst_1
    //   128: putfield v : Z
    //   131: aload_0
    //   132: iload_2
    //   133: putfield r : I
    //   136: aload_0
    //   137: getfield w : Landroid/view/VelocityTracker;
    //   140: ifnonnull -> 150
    //   143: aload_0
    //   144: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   147: putfield w : Landroid/view/VelocityTracker;
    //   150: aload_0
    //   151: getfield w : Landroid/view/VelocityTracker;
    //   154: aload_1
    //   155: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   158: aload_0
    //   159: iconst_0
    //   160: putfield F : I
    //   163: aload_0
    //   164: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   167: astore_1
    //   168: aload_1
    //   169: ifnull -> 471
    //   172: aload_1
    //   173: iconst_1
    //   174: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   179: goto -> 471
    //   182: aload_0
    //   183: iconst_0
    //   184: putfield v : Z
    //   187: aload_0
    //   188: iconst_m1
    //   189: putfield C : I
    //   192: aload_0
    //   193: invokevirtual p : ()V
    //   196: aload_0
    //   197: getfield g : Landroid/widget/OverScroller;
    //   200: aload_0
    //   201: invokevirtual getScrollX : ()I
    //   204: aload_0
    //   205: invokevirtual getScrollY : ()I
    //   208: iconst_0
    //   209: iconst_0
    //   210: iconst_0
    //   211: aload_0
    //   212: invokevirtual getScrollRange : ()I
    //   215: invokevirtual springBack : (IIIIII)Z
    //   218: ifeq -> 229
    //   221: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   224: astore_1
    //   225: aload_0
    //   226: invokestatic k : (Landroid/view/View;)V
    //   229: aload_0
    //   230: getfield J : Lqd;
    //   233: iconst_0
    //   234: invokevirtual j : (I)V
    //   237: goto -> 471
    //   240: aload_1
    //   241: invokevirtual getY : ()F
    //   244: f2i
    //   245: istore_3
    //   246: aload_1
    //   247: invokevirtual getX : ()F
    //   250: f2i
    //   251: istore_2
    //   252: aload_0
    //   253: invokevirtual getChildCount : ()I
    //   256: ifle -> 319
    //   259: aload_0
    //   260: invokevirtual getScrollY : ()I
    //   263: istore #4
    //   265: aload_0
    //   266: iconst_0
    //   267: invokevirtual getChildAt : (I)Landroid/view/View;
    //   270: astore #8
    //   272: iload_3
    //   273: aload #8
    //   275: invokevirtual getTop : ()I
    //   278: iload #4
    //   280: isub
    //   281: if_icmplt -> 319
    //   284: iload_3
    //   285: aload #8
    //   287: invokevirtual getBottom : ()I
    //   290: iload #4
    //   292: isub
    //   293: if_icmpge -> 319
    //   296: iload_2
    //   297: aload #8
    //   299: invokevirtual getLeft : ()I
    //   302: if_icmplt -> 319
    //   305: iload_2
    //   306: aload #8
    //   308: invokevirtual getRight : ()I
    //   311: if_icmpge -> 319
    //   314: iconst_1
    //   315: istore_2
    //   316: goto -> 321
    //   319: iconst_0
    //   320: istore_2
    //   321: iload_2
    //   322: ifne -> 370
    //   325: iload #6
    //   327: istore #5
    //   329: aload_0
    //   330: aload_1
    //   331: invokevirtual v : (Landroid/view/MotionEvent;)Z
    //   334: ifne -> 357
    //   337: aload_0
    //   338: getfield g : Landroid/widget/OverScroller;
    //   341: invokevirtual isFinished : ()Z
    //   344: ifne -> 354
    //   347: iload #6
    //   349: istore #5
    //   351: goto -> 357
    //   354: iconst_0
    //   355: istore #5
    //   357: aload_0
    //   358: iload #5
    //   360: putfield v : Z
    //   363: aload_0
    //   364: invokevirtual p : ()V
    //   367: goto -> 471
    //   370: aload_0
    //   371: iload_3
    //   372: putfield r : I
    //   375: aload_0
    //   376: aload_1
    //   377: iconst_0
    //   378: invokevirtual getPointerId : (I)I
    //   381: putfield C : I
    //   384: aload_0
    //   385: getfield w : Landroid/view/VelocityTracker;
    //   388: astore #8
    //   390: aload #8
    //   392: ifnonnull -> 405
    //   395: aload_0
    //   396: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   399: putfield w : Landroid/view/VelocityTracker;
    //   402: goto -> 410
    //   405: aload #8
    //   407: invokevirtual clear : ()V
    //   410: aload_0
    //   411: getfield w : Landroid/view/VelocityTracker;
    //   414: aload_1
    //   415: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   418: aload_0
    //   419: getfield g : Landroid/widget/OverScroller;
    //   422: invokevirtual computeScrollOffset : ()Z
    //   425: pop
    //   426: iload #7
    //   428: istore #5
    //   430: aload_0
    //   431: aload_1
    //   432: invokevirtual v : (Landroid/view/MotionEvent;)Z
    //   435: ifne -> 458
    //   438: aload_0
    //   439: getfield g : Landroid/widget/OverScroller;
    //   442: invokevirtual isFinished : ()Z
    //   445: ifne -> 455
    //   448: iload #7
    //   450: istore #5
    //   452: goto -> 458
    //   455: iconst_0
    //   456: istore #5
    //   458: aload_0
    //   459: iload #5
    //   461: putfield v : Z
    //   464: aload_0
    //   465: iconst_2
    //   466: iconst_0
    //   467: invokevirtual u : (II)Z
    //   470: pop
    //   471: aload_0
    //   472: getfield v : Z
    //   475: ireturn
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.s = false;
    View view = this.u;
    if (view != null && k(view, (View)this))
      s(this.u); 
    this.u = null;
    if (!this.t) {
      if (this.H != null) {
        scrollTo(getScrollX(), this.H.b);
        this.H = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int i = getPaddingTop();
      int j = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = c(paramInt3, paramInt4 - paramInt2 - i - j, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.t = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.x)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (i < paramInt2) {
        i = getPaddingLeft();
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + i + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      h((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    e(paramInt1, paramInt2, paramArrayOfint, null, 0);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    e(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    m(paramInt4, 0, null);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    m(paramInt4, paramInt5, null);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    m(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.I.a = paramInt;
    u(2, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    ud ud1 = this.I;
    if (paramInt2 == 1) {
      ud1.b = paramInt1;
    } else {
      ud1.a = paramInt1;
    } 
    u(2, paramInt2);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (((true ^ l(view, 0, getHeight())) != 0) ? false : view.requestFocus(i, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.H = c1;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.b = getScrollY();
    return (Parcelable)c1;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.L;
    if (b1 != null)
      b1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (l(view, 0, paramInt4)) {
        view.getDrawingRect(this.f);
        offsetDescendantRectToMyCoords(view, this.f);
        f(d(this.f));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) != 0);
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.I.a = 0;
    w(0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    ud ud1 = this.I;
    if (paramInt == 1) {
      ud1.b = 0;
    } else {
      ud1.a = 0;
    } 
    w(paramInt);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield w : Landroid/view/VelocityTracker;
    //   4: ifnonnull -> 14
    //   7: aload_0
    //   8: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   11: putfield w : Landroid/view/VelocityTracker;
    //   14: aload_1
    //   15: invokevirtual getActionMasked : ()I
    //   18: istore #5
    //   20: iconst_0
    //   21: istore #8
    //   23: iload #5
    //   25: ifne -> 33
    //   28: aload_0
    //   29: iconst_0
    //   30: putfield F : I
    //   33: aload_1
    //   34: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    //   37: astore #13
    //   39: aload_0
    //   40: getfield F : I
    //   43: i2f
    //   44: fstore_3
    //   45: fconst_0
    //   46: fstore_2
    //   47: aload #13
    //   49: fconst_0
    //   50: fload_3
    //   51: invokevirtual offsetLocation : (FF)V
    //   54: iload #5
    //   56: ifeq -> 1128
    //   59: iload #5
    //   61: iconst_1
    //   62: if_icmpeq -> 921
    //   65: iload #5
    //   67: iconst_2
    //   68: if_icmpeq -> 234
    //   71: iload #5
    //   73: iconst_3
    //   74: if_icmpeq -> 148
    //   77: iload #5
    //   79: iconst_5
    //   80: if_icmpeq -> 118
    //   83: iload #5
    //   85: bipush #6
    //   87: if_icmpeq -> 93
    //   90: goto -> 1202
    //   93: aload_0
    //   94: aload_1
    //   95: invokevirtual n : (Landroid/view/MotionEvent;)V
    //   98: aload_0
    //   99: aload_1
    //   100: aload_1
    //   101: aload_0
    //   102: getfield C : I
    //   105: invokevirtual findPointerIndex : (I)I
    //   108: invokevirtual getY : (I)F
    //   111: f2i
    //   112: putfield r : I
    //   115: goto -> 1202
    //   118: aload_1
    //   119: invokevirtual getActionIndex : ()I
    //   122: istore #5
    //   124: aload_0
    //   125: aload_1
    //   126: iload #5
    //   128: invokevirtual getY : (I)F
    //   131: f2i
    //   132: putfield r : I
    //   135: aload_0
    //   136: aload_1
    //   137: iload #5
    //   139: invokevirtual getPointerId : (I)I
    //   142: putfield C : I
    //   145: goto -> 1202
    //   148: aload_0
    //   149: getfield v : Z
    //   152: ifeq -> 195
    //   155: aload_0
    //   156: invokevirtual getChildCount : ()I
    //   159: ifle -> 195
    //   162: aload_0
    //   163: getfield g : Landroid/widget/OverScroller;
    //   166: aload_0
    //   167: invokevirtual getScrollX : ()I
    //   170: aload_0
    //   171: invokevirtual getScrollY : ()I
    //   174: iconst_0
    //   175: iconst_0
    //   176: iconst_0
    //   177: aload_0
    //   178: invokevirtual getScrollRange : ()I
    //   181: invokevirtual springBack : (IIIIII)Z
    //   184: ifeq -> 195
    //   187: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   190: astore_1
    //   191: aload_0
    //   192: invokestatic k : (Landroid/view/View;)V
    //   195: aload_0
    //   196: iconst_m1
    //   197: putfield C : I
    //   200: aload_0
    //   201: iconst_0
    //   202: putfield v : Z
    //   205: aload_0
    //   206: invokevirtual p : ()V
    //   209: aload_0
    //   210: getfield J : Lqd;
    //   213: iconst_0
    //   214: invokevirtual j : (I)V
    //   217: aload_0
    //   218: getfield p : Landroid/widget/EdgeEffect;
    //   221: invokevirtual onRelease : ()V
    //   224: aload_0
    //   225: getfield q : Landroid/widget/EdgeEffect;
    //   228: invokevirtual onRelease : ()V
    //   231: goto -> 1202
    //   234: aload_1
    //   235: aload_0
    //   236: getfield C : I
    //   239: invokevirtual findPointerIndex : (I)I
    //   242: istore #9
    //   244: iload #9
    //   246: iconst_m1
    //   247: if_icmpne -> 253
    //   250: goto -> 1202
    //   253: aload_1
    //   254: iload #9
    //   256: invokevirtual getY : (I)F
    //   259: f2i
    //   260: istore #7
    //   262: aload_0
    //   263: getfield r : I
    //   266: iload #7
    //   268: isub
    //   269: istore #5
    //   271: aload_1
    //   272: iload #9
    //   274: invokevirtual getX : (I)F
    //   277: aload_0
    //   278: invokevirtual getWidth : ()I
    //   281: i2f
    //   282: fdiv
    //   283: fstore_3
    //   284: iload #5
    //   286: i2f
    //   287: aload_0
    //   288: invokevirtual getHeight : ()I
    //   291: i2f
    //   292: fdiv
    //   293: fstore #4
    //   295: aload_0
    //   296: getfield p : Landroid/widget/EdgeEffect;
    //   299: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   302: fconst_0
    //   303: fcmpl
    //   304: ifeq -> 346
    //   307: aload_0
    //   308: getfield p : Landroid/widget/EdgeEffect;
    //   311: fload #4
    //   313: fneg
    //   314: fload_3
    //   315: invokestatic v0 : (Landroid/widget/EdgeEffect;FF)F
    //   318: fneg
    //   319: fstore_3
    //   320: fload_3
    //   321: fstore_2
    //   322: aload_0
    //   323: getfield p : Landroid/widget/EdgeEffect;
    //   326: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   329: fconst_0
    //   330: fcmpl
    //   331: ifne -> 343
    //   334: aload_0
    //   335: getfield p : Landroid/widget/EdgeEffect;
    //   338: invokevirtual onRelease : ()V
    //   341: fload_3
    //   342: fstore_2
    //   343: goto -> 397
    //   346: aload_0
    //   347: getfield q : Landroid/widget/EdgeEffect;
    //   350: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   353: fconst_0
    //   354: fcmpl
    //   355: ifeq -> 397
    //   358: aload_0
    //   359: getfield q : Landroid/widget/EdgeEffect;
    //   362: fload #4
    //   364: fconst_1
    //   365: fload_3
    //   366: fsub
    //   367: invokestatic v0 : (Landroid/widget/EdgeEffect;FF)F
    //   370: fstore_3
    //   371: fload_3
    //   372: fstore_2
    //   373: aload_0
    //   374: getfield q : Landroid/widget/EdgeEffect;
    //   377: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   380: fconst_0
    //   381: fcmpl
    //   382: ifne -> 343
    //   385: aload_0
    //   386: getfield q : Landroid/widget/EdgeEffect;
    //   389: invokevirtual onRelease : ()V
    //   392: fload_3
    //   393: fstore_2
    //   394: goto -> 343
    //   397: fload_2
    //   398: aload_0
    //   399: invokevirtual getHeight : ()I
    //   402: i2f
    //   403: fmul
    //   404: invokestatic round : (F)I
    //   407: istore #6
    //   409: iload #6
    //   411: ifeq -> 418
    //   414: aload_0
    //   415: invokevirtual invalidate : ()V
    //   418: iload #5
    //   420: iload #6
    //   422: isub
    //   423: istore #6
    //   425: iload #6
    //   427: istore #5
    //   429: aload_0
    //   430: getfield v : Z
    //   433: ifne -> 502
    //   436: iload #6
    //   438: istore #5
    //   440: iload #6
    //   442: invokestatic abs : (I)I
    //   445: aload_0
    //   446: getfield z : I
    //   449: if_icmple -> 502
    //   452: aload_0
    //   453: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   456: astore #14
    //   458: aload #14
    //   460: ifnull -> 471
    //   463: aload #14
    //   465: iconst_1
    //   466: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   471: aload_0
    //   472: iconst_1
    //   473: putfield v : Z
    //   476: iload #6
    //   478: ifle -> 493
    //   481: iload #6
    //   483: aload_0
    //   484: getfield z : I
    //   487: isub
    //   488: istore #5
    //   490: goto -> 502
    //   493: iload #6
    //   495: aload_0
    //   496: getfield z : I
    //   499: iadd
    //   500: istore #5
    //   502: aload_0
    //   503: getfield v : Z
    //   506: ifeq -> 1202
    //   509: iload #5
    //   511: istore #6
    //   513: aload_0
    //   514: iconst_0
    //   515: iload #5
    //   517: aload_0
    //   518: getfield E : [I
    //   521: aload_0
    //   522: getfield D : [I
    //   525: iconst_0
    //   526: invokevirtual e : (II[I[II)Z
    //   529: ifeq -> 558
    //   532: iload #5
    //   534: aload_0
    //   535: getfield E : [I
    //   538: iconst_1
    //   539: iaload
    //   540: isub
    //   541: istore #6
    //   543: aload_0
    //   544: aload_0
    //   545: getfield F : I
    //   548: aload_0
    //   549: getfield D : [I
    //   552: iconst_1
    //   553: iaload
    //   554: iadd
    //   555: putfield F : I
    //   558: aload_0
    //   559: iload #7
    //   561: aload_0
    //   562: getfield D : [I
    //   565: iconst_1
    //   566: iaload
    //   567: isub
    //   568: putfield r : I
    //   571: aload_0
    //   572: invokevirtual getScrollY : ()I
    //   575: istore #11
    //   577: aload_0
    //   578: invokevirtual getScrollRange : ()I
    //   581: istore #10
    //   583: aload_0
    //   584: invokevirtual getOverScrollMode : ()I
    //   587: istore #5
    //   589: iload #5
    //   591: ifeq -> 614
    //   594: iload #5
    //   596: iconst_1
    //   597: if_icmpne -> 608
    //   600: iload #10
    //   602: ifle -> 608
    //   605: goto -> 614
    //   608: iconst_0
    //   609: istore #7
    //   611: goto -> 617
    //   614: iconst_1
    //   615: istore #7
    //   617: aload_0
    //   618: iconst_0
    //   619: iload #6
    //   621: iconst_0
    //   622: aload_0
    //   623: invokevirtual getScrollY : ()I
    //   626: iconst_0
    //   627: iload #10
    //   629: iconst_0
    //   630: iconst_0
    //   631: invokevirtual o : (IIIIIIII)Z
    //   634: ifeq -> 651
    //   637: aload_0
    //   638: iconst_0
    //   639: invokevirtual j : (I)Z
    //   642: ifne -> 651
    //   645: iconst_1
    //   646: istore #5
    //   648: goto -> 654
    //   651: iconst_0
    //   652: istore #5
    //   654: aload_0
    //   655: invokevirtual getScrollY : ()I
    //   658: iload #11
    //   660: isub
    //   661: istore #12
    //   663: aload_0
    //   664: getfield E : [I
    //   667: astore #14
    //   669: aload #14
    //   671: iconst_1
    //   672: iconst_0
    //   673: iastore
    //   674: aload_0
    //   675: getfield D : [I
    //   678: astore #15
    //   680: aload_0
    //   681: getfield J : Lqd;
    //   684: iconst_0
    //   685: iload #12
    //   687: iconst_0
    //   688: iload #6
    //   690: iload #12
    //   692: isub
    //   693: aload #15
    //   695: iconst_0
    //   696: aload #14
    //   698: invokevirtual e : (IIII[II[I)Z
    //   701: pop
    //   702: aload_0
    //   703: getfield r : I
    //   706: istore #12
    //   708: aload_0
    //   709: getfield D : [I
    //   712: astore #14
    //   714: aload_0
    //   715: iload #12
    //   717: aload #14
    //   719: iconst_1
    //   720: iaload
    //   721: isub
    //   722: putfield r : I
    //   725: aload_0
    //   726: aload_0
    //   727: getfield F : I
    //   730: aload #14
    //   732: iconst_1
    //   733: iaload
    //   734: iadd
    //   735: putfield F : I
    //   738: iload #7
    //   740: ifeq -> 906
    //   743: iload #6
    //   745: aload_0
    //   746: getfield E : [I
    //   749: iconst_1
    //   750: iaload
    //   751: isub
    //   752: istore #6
    //   754: iload #11
    //   756: iload #6
    //   758: iadd
    //   759: istore #7
    //   761: iload #7
    //   763: ifge -> 816
    //   766: aload_0
    //   767: getfield p : Landroid/widget/EdgeEffect;
    //   770: iload #6
    //   772: ineg
    //   773: i2f
    //   774: aload_0
    //   775: invokevirtual getHeight : ()I
    //   778: i2f
    //   779: fdiv
    //   780: aload_1
    //   781: iload #9
    //   783: invokevirtual getX : (I)F
    //   786: aload_0
    //   787: invokevirtual getWidth : ()I
    //   790: i2f
    //   791: fdiv
    //   792: invokestatic v0 : (Landroid/widget/EdgeEffect;FF)F
    //   795: pop
    //   796: aload_0
    //   797: getfield q : Landroid/widget/EdgeEffect;
    //   800: invokevirtual isFinished : ()Z
    //   803: ifne -> 871
    //   806: aload_0
    //   807: getfield q : Landroid/widget/EdgeEffect;
    //   810: invokevirtual onRelease : ()V
    //   813: goto -> 871
    //   816: iload #7
    //   818: iload #10
    //   820: if_icmple -> 871
    //   823: aload_0
    //   824: getfield q : Landroid/widget/EdgeEffect;
    //   827: iload #6
    //   829: i2f
    //   830: aload_0
    //   831: invokevirtual getHeight : ()I
    //   834: i2f
    //   835: fdiv
    //   836: fconst_1
    //   837: aload_1
    //   838: iload #9
    //   840: invokevirtual getX : (I)F
    //   843: aload_0
    //   844: invokevirtual getWidth : ()I
    //   847: i2f
    //   848: fdiv
    //   849: fsub
    //   850: invokestatic v0 : (Landroid/widget/EdgeEffect;FF)F
    //   853: pop
    //   854: aload_0
    //   855: getfield p : Landroid/widget/EdgeEffect;
    //   858: invokevirtual isFinished : ()Z
    //   861: ifne -> 871
    //   864: aload_0
    //   865: getfield p : Landroid/widget/EdgeEffect;
    //   868: invokevirtual onRelease : ()V
    //   871: aload_0
    //   872: getfield p : Landroid/widget/EdgeEffect;
    //   875: invokevirtual isFinished : ()Z
    //   878: ifeq -> 891
    //   881: aload_0
    //   882: getfield q : Landroid/widget/EdgeEffect;
    //   885: invokevirtual isFinished : ()Z
    //   888: ifne -> 906
    //   891: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   894: astore_1
    //   895: aload_0
    //   896: invokestatic k : (Landroid/view/View;)V
    //   899: iload #8
    //   901: istore #5
    //   903: goto -> 906
    //   906: iload #5
    //   908: ifeq -> 1202
    //   911: aload_0
    //   912: getfield w : Landroid/view/VelocityTracker;
    //   915: invokevirtual clear : ()V
    //   918: goto -> 1202
    //   921: aload_0
    //   922: getfield w : Landroid/view/VelocityTracker;
    //   925: astore_1
    //   926: aload_1
    //   927: sipush #1000
    //   930: aload_0
    //   931: getfield B : I
    //   934: i2f
    //   935: invokevirtual computeCurrentVelocity : (IF)V
    //   938: aload_1
    //   939: aload_0
    //   940: getfield C : I
    //   943: invokevirtual getYVelocity : (I)F
    //   946: f2i
    //   947: istore #6
    //   949: iload #6
    //   951: invokestatic abs : (I)I
    //   954: aload_0
    //   955: getfield A : I
    //   958: if_icmplt -> 1056
    //   961: aload_0
    //   962: getfield p : Landroid/widget/EdgeEffect;
    //   965: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   968: fconst_0
    //   969: fcmpl
    //   970: ifeq -> 985
    //   973: aload_0
    //   974: getfield p : Landroid/widget/EdgeEffect;
    //   977: iload #6
    //   979: invokevirtual onAbsorb : (I)V
    //   982: goto -> 1007
    //   985: aload_0
    //   986: getfield q : Landroid/widget/EdgeEffect;
    //   989: invokestatic M : (Landroid/widget/EdgeEffect;)F
    //   992: fconst_0
    //   993: fcmpl
    //   994: ifeq -> 1013
    //   997: aload_0
    //   998: getfield q : Landroid/widget/EdgeEffect;
    //   1001: iload #6
    //   1003: ineg
    //   1004: invokevirtual onAbsorb : (I)V
    //   1007: iconst_1
    //   1008: istore #5
    //   1010: goto -> 1016
    //   1013: iconst_0
    //   1014: istore #5
    //   1016: iload #5
    //   1018: ifne -> 1089
    //   1021: iload #6
    //   1023: ineg
    //   1024: istore #5
    //   1026: iload #5
    //   1028: i2f
    //   1029: fstore_2
    //   1030: aload_0
    //   1031: fconst_0
    //   1032: fload_2
    //   1033: invokevirtual dispatchNestedPreFling : (FF)Z
    //   1036: ifne -> 1089
    //   1039: aload_0
    //   1040: fconst_0
    //   1041: fload_2
    //   1042: iconst_1
    //   1043: invokevirtual dispatchNestedFling : (FFZ)Z
    //   1046: pop
    //   1047: aload_0
    //   1048: iload #5
    //   1050: invokevirtual h : (I)V
    //   1053: goto -> 1089
    //   1056: aload_0
    //   1057: getfield g : Landroid/widget/OverScroller;
    //   1060: aload_0
    //   1061: invokevirtual getScrollX : ()I
    //   1064: aload_0
    //   1065: invokevirtual getScrollY : ()I
    //   1068: iconst_0
    //   1069: iconst_0
    //   1070: iconst_0
    //   1071: aload_0
    //   1072: invokevirtual getScrollRange : ()I
    //   1075: invokevirtual springBack : (IIIIII)Z
    //   1078: ifeq -> 1089
    //   1081: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   1084: astore_1
    //   1085: aload_0
    //   1086: invokestatic k : (Landroid/view/View;)V
    //   1089: aload_0
    //   1090: iconst_m1
    //   1091: putfield C : I
    //   1094: aload_0
    //   1095: iconst_0
    //   1096: putfield v : Z
    //   1099: aload_0
    //   1100: invokevirtual p : ()V
    //   1103: aload_0
    //   1104: getfield J : Lqd;
    //   1107: iconst_0
    //   1108: invokevirtual j : (I)V
    //   1111: aload_0
    //   1112: getfield p : Landroid/widget/EdgeEffect;
    //   1115: invokevirtual onRelease : ()V
    //   1118: aload_0
    //   1119: getfield q : Landroid/widget/EdgeEffect;
    //   1122: invokevirtual onRelease : ()V
    //   1125: goto -> 1202
    //   1128: aload_0
    //   1129: invokevirtual getChildCount : ()I
    //   1132: ifne -> 1137
    //   1135: iconst_0
    //   1136: ireturn
    //   1137: aload_0
    //   1138: getfield v : Z
    //   1141: ifeq -> 1163
    //   1144: aload_0
    //   1145: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   1148: astore #14
    //   1150: aload #14
    //   1152: ifnull -> 1163
    //   1155: aload #14
    //   1157: iconst_1
    //   1158: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   1163: aload_0
    //   1164: getfield g : Landroid/widget/OverScroller;
    //   1167: invokevirtual isFinished : ()Z
    //   1170: ifne -> 1177
    //   1173: aload_0
    //   1174: invokevirtual a : ()V
    //   1177: aload_0
    //   1178: aload_1
    //   1179: invokevirtual getY : ()F
    //   1182: f2i
    //   1183: putfield r : I
    //   1186: aload_0
    //   1187: aload_1
    //   1188: iconst_0
    //   1189: invokevirtual getPointerId : (I)I
    //   1192: putfield C : I
    //   1195: aload_0
    //   1196: iconst_2
    //   1197: iconst_0
    //   1198: invokevirtual u : (II)Z
    //   1201: pop
    //   1202: aload_0
    //   1203: getfield w : Landroid/view/VelocityTracker;
    //   1206: astore_1
    //   1207: aload_1
    //   1208: ifnull -> 1217
    //   1211: aload_1
    //   1212: aload #13
    //   1214: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   1217: aload #13
    //   1219: invokevirtual recycle : ()V
    //   1222: iconst_1
    //   1223: ireturn
  }
  
  public final void p() {
    VelocityTracker velocityTracker = this.w;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.w = null;
    } 
  }
  
  public final void q(boolean paramBoolean) {
    if (paramBoolean) {
      u(2, 1);
    } else {
      this.J.j(1);
    } 
    this.G = getScrollY();
    AtomicInteger atomicInteger = fe.a;
    fe.d.k((View)this);
  }
  
  public final boolean r(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getHeight : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getScrollY : ()I
    //   10: istore #10
    //   12: iload #4
    //   14: iload #10
    //   16: iadd
    //   17: istore #11
    //   19: iload_1
    //   20: bipush #33
    //   22: if_icmpne -> 31
    //   25: iconst_1
    //   26: istore #6
    //   28: goto -> 34
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: iconst_2
    //   36: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   39: astore #18
    //   41: aload #18
    //   43: invokeinterface size : ()I
    //   48: istore #12
    //   50: aconst_null
    //   51: astore #16
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #7
    //   61: iload #12
    //   63: if_icmpge -> 285
    //   66: aload #18
    //   68: iload #7
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: checkcast android/view/View
    //   78: astore #17
    //   80: aload #17
    //   82: invokevirtual getTop : ()I
    //   85: istore #9
    //   87: aload #17
    //   89: invokevirtual getBottom : ()I
    //   92: istore #13
    //   94: aload #16
    //   96: astore #15
    //   98: iload #8
    //   100: istore #5
    //   102: iload_2
    //   103: iload #13
    //   105: if_icmpge -> 268
    //   108: aload #16
    //   110: astore #15
    //   112: iload #8
    //   114: istore #5
    //   116: iload #9
    //   118: iload_3
    //   119: if_icmpge -> 268
    //   122: iload_2
    //   123: iload #9
    //   125: if_icmpge -> 140
    //   128: iload #13
    //   130: iload_3
    //   131: if_icmpge -> 140
    //   134: iconst_1
    //   135: istore #4
    //   137: goto -> 143
    //   140: iconst_0
    //   141: istore #4
    //   143: aload #16
    //   145: ifnonnull -> 159
    //   148: aload #17
    //   150: astore #15
    //   152: iload #4
    //   154: istore #5
    //   156: goto -> 268
    //   159: iload #6
    //   161: ifeq -> 174
    //   164: iload #9
    //   166: aload #16
    //   168: invokevirtual getTop : ()I
    //   171: if_icmplt -> 189
    //   174: iload #6
    //   176: ifne -> 195
    //   179: iload #13
    //   181: aload #16
    //   183: invokevirtual getBottom : ()I
    //   186: if_icmple -> 195
    //   189: iconst_1
    //   190: istore #9
    //   192: goto -> 198
    //   195: iconst_0
    //   196: istore #9
    //   198: iload #8
    //   200: ifeq -> 232
    //   203: aload #16
    //   205: astore #15
    //   207: iload #8
    //   209: istore #5
    //   211: iload #4
    //   213: ifeq -> 268
    //   216: aload #16
    //   218: astore #15
    //   220: iload #8
    //   222: istore #5
    //   224: iload #9
    //   226: ifeq -> 268
    //   229: goto -> 260
    //   232: iload #4
    //   234: ifeq -> 247
    //   237: aload #17
    //   239: astore #15
    //   241: iconst_1
    //   242: istore #5
    //   244: goto -> 268
    //   247: aload #16
    //   249: astore #15
    //   251: iload #8
    //   253: istore #5
    //   255: iload #9
    //   257: ifeq -> 268
    //   260: aload #17
    //   262: astore #15
    //   264: iload #8
    //   266: istore #5
    //   268: iload #7
    //   270: iconst_1
    //   271: iadd
    //   272: istore #7
    //   274: aload #15
    //   276: astore #16
    //   278: iload #5
    //   280: istore #8
    //   282: goto -> 59
    //   285: aload #16
    //   287: astore #15
    //   289: aload #16
    //   291: ifnonnull -> 297
    //   294: aload_0
    //   295: astore #15
    //   297: iload_2
    //   298: iload #10
    //   300: if_icmplt -> 315
    //   303: iload_3
    //   304: iload #11
    //   306: if_icmpgt -> 315
    //   309: iconst_0
    //   310: istore #14
    //   312: goto -> 341
    //   315: iload #6
    //   317: ifeq -> 328
    //   320: iload_2
    //   321: iload #10
    //   323: isub
    //   324: istore_2
    //   325: goto -> 333
    //   328: iload_3
    //   329: iload #11
    //   331: isub
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: invokevirtual f : (I)V
    //   338: iconst_1
    //   339: istore #14
    //   341: aload #15
    //   343: aload_0
    //   344: invokevirtual findFocus : ()Landroid/view/View;
    //   347: if_acmpeq -> 357
    //   350: aload #15
    //   352: iload_1
    //   353: invokevirtual requestFocus : (I)Z
    //   356: pop
    //   357: iload #14
    //   359: ireturn
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.s) {
      s(paramView2);
    } else {
      this.u = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    int i = d(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      t(0, i, 250, false);
    } 
    return bool;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      p(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.s = true;
    super.requestLayout();
  }
  
  public final void s(View paramView) {
    paramView.getDrawingRect(this.f);
    offsetDescendantRectToMyCoords(paramView, this.f);
    int i = d(this.f);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i2 = getWidth();
      int i3 = getPaddingLeft();
      int i4 = getPaddingRight();
      int i5 = view.getWidth();
      int i6 = layoutParams.leftMargin;
      int i7 = layoutParams.rightMargin;
      int i = getHeight();
      int j = getPaddingTop();
      int k = getPaddingBottom();
      int m = view.getHeight();
      int n = layoutParams.topMargin;
      int i1 = layoutParams.bottomMargin;
      paramInt1 = c(paramInt1, i2 - i3 - i4, i5 + i6 + i7);
      paramInt2 = c(paramInt2, i - j - k, m + n + i1);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.x) {
      this.x = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.J.h(paramBoolean);
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.L = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.J.i(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.J.j(0);
  }
  
  public final void t(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.d > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getHeight();
      int j = layoutParams.topMargin;
      int k = layoutParams.bottomMargin;
      int m = getHeight();
      int n = getPaddingTop();
      int i1 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, i + j + k - m - n - i1)));
      this.g.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      q(paramBoolean);
    } else {
      if (!this.g.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.d = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public boolean u(int paramInt1, int paramInt2) {
    return this.J.i(paramInt1, paramInt2);
  }
  
  public final boolean v(MotionEvent paramMotionEvent) {
    boolean bool;
    if (ComponentActivity.c.M(this.p) != 0.0F) {
      ComponentActivity.c.v0(this.p, 0.0F, paramMotionEvent.getY() / getHeight());
      bool = true;
    } else {
      bool = false;
    } 
    if (ComponentActivity.c.M(this.q) != 0.0F) {
      ComponentActivity.c.v0(this.q, 0.0F, 1.0F - paramMotionEvent.getY() / getHeight());
      return true;
    } 
    return bool;
  }
  
  public void w(int paramInt) {
    this.J.j(paramInt);
  }
  
  public static class a extends hd {
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      param1AccessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, oe param1oe) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1oe);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      String str = ScrollView.class.getName();
      param1oe.b.setClassName(str);
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1oe.b.setScrollable(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1oe.a(oe.a.c);
            param1oe.a(oe.a.g);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1oe.a(oe.a.b);
            param1oe.a(oe.a.h);
          } 
        } 
      } 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.t(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.t(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
        return true;
      } 
      return false;
    }
  }
  
  public static interface b {
    void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
  
  public static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = new a();
    
    public int b;
    
    public c(Parcel param1Parcel) {
      super(param1Parcel);
      this.b = param1Parcel.readInt();
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = s30.x0("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      return s30.l0(stringBuilder, this.b, "}");
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.b);
    }
    
    public class a implements Parcelable.Creator<c> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new NestedScrollView.c(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new NestedScrollView.c[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<c> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new NestedScrollView.c(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new NestedScrollView.c[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */