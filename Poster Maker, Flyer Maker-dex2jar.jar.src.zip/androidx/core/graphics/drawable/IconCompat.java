package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode a = PorterDuff.Mode.SRC_IN;
  
  public int b = -1;
  
  public Object c;
  
  public byte[] d = null;
  
  public Parcelable e = null;
  
  public int f = 0;
  
  public int g = 0;
  
  public ColorStateList h = null;
  
  public PorterDuff.Mode i = a;
  
  public String j = null;
  
  public String k;
  
  public IconCompat() {}
  
  public IconCompat(int paramInt) {
    this.b = paramInt;
  }
  
  public static Bitmap b(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat c(Resources paramResources, String paramString, int paramInt) {
    if (paramString != null) {
      if (paramInt != 0) {
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f = paramInt;
        if (paramResources != null)
          try {
            iconCompat.c = paramResources.getResourceName(paramInt);
            iconCompat.k = paramString;
            return iconCompat;
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            throw new IllegalArgumentException("Icon resource cannot be found");
          }  
        iconCompat.c = paramString;
        iconCompat.k = paramString;
        return iconCompat;
      } 
      throw new IllegalArgumentException("Drawable resource ID must not be 0");
    } 
    throw new IllegalArgumentException("Package must not be null.");
  }
  
  public static Resources f(Context paramContext, String paramString) {
    if ("android".equals(paramString))
      return Resources.getSystem(); 
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramString, 8192);
      return (applicationInfo != null) ? packageManager.getResourcesForApplication(applicationInfo) : null;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      String.format("Unable to find pkg=%s for icon", new Object[] { paramString });
      return null;
    } 
  }
  
  public int d() {
    int i = this.b;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.c;
        if (j >= 28)
          return icon.getResId(); 
        try {
          return ((Integer)icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException|InvocationTargetException|NoSuchMethodException illegalAccessException) {
          return 0;
        } 
      } 
    } 
    if (i == 2)
      return this.f; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String e() {
    int i = this.b;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.c;
        if (j >= 28)
          return icon.getResPackage(); 
        try {
          return (String)icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException|InvocationTargetException|NoSuchMethodException illegalAccessException) {
          return null;
        } 
      } 
    } 
    if (i == 2)
      return TextUtils.isEmpty(this.k) ? ((String)this.c).split(":", -1)[0] : this.k; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int g() {
    int i = this.b;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.c;
        if (j >= 28)
          return icon.getType(); 
        try {
          return ((Integer)icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          stringBuilder.toString();
          return -1;
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          stringBuilder.toString();
          return -1;
        } catch (NoSuchMethodException noSuchMethodException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to get icon type ");
          stringBuilder.append(icon);
          stringBuilder.toString();
          return -1;
        } 
      } 
    } 
    return i;
  }
  
  public Uri h() {
    int i = this.b;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.c;
        if (j >= 28)
          return icon.getUri(); 
        try {
          return (Uri)icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException|InvocationTargetException|NoSuchMethodException illegalAccessException) {
          return null;
        } 
      } 
    } 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.c); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public InputStream i(Context paramContext) {
    Uri uri = h();
    String str = uri.getScheme();
    if ("content".equals(str) || "file".equals(str)) {
      try {
        return paramContext.getContentResolver().openInputStream(uri);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to load image from URI: ");
        stringBuilder.append(uri);
        stringBuilder.toString();
      } 
      return null;
    } 
    try {
      return new FileInputStream(new File((String)this.c));
    } catch (FileNotFoundException fileNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to load image from path: ");
      stringBuilder.append(uri);
      stringBuilder.toString();
    } 
    return null;
  }
  
  @Deprecated
  public Icon j() {
    return k(null);
  }
  
  public Icon k(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : I
    //   4: tableswitch default -> 52, -1 -> 323, 0 -> 52, 1 -> 277, 2 -> 262, 3 -> 240, 4 -> 226, 5 -> 186, 6 -> 63
    //   52: new java/lang/IllegalArgumentException
    //   55: dup
    //   56: ldc_w 'Unknown type'
    //   59: invokespecial <init> : (Ljava/lang/String;)V
    //   62: athrow
    //   63: getstatic android/os/Build$VERSION.SDK_INT : I
    //   66: istore_2
    //   67: iload_2
    //   68: bipush #30
    //   70: if_icmplt -> 84
    //   73: aload_0
    //   74: invokevirtual h : ()Landroid/net/Uri;
    //   77: invokestatic createWithAdaptiveBitmapContentUri : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    //   80: astore_1
    //   81: goto -> 288
    //   84: aload_1
    //   85: ifnull -> 158
    //   88: aload_0
    //   89: aload_1
    //   90: invokevirtual i : (Landroid/content/Context;)Ljava/io/InputStream;
    //   93: astore_1
    //   94: aload_1
    //   95: ifnull -> 130
    //   98: iload_2
    //   99: bipush #26
    //   101: if_icmplt -> 115
    //   104: aload_1
    //   105: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   108: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   111: astore_1
    //   112: goto -> 288
    //   115: aload_1
    //   116: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   119: iconst_0
    //   120: invokestatic b : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   123: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   126: astore_1
    //   127: goto -> 288
    //   130: ldc_w 'Cannot load adaptive icon from uri: '
    //   133: invokestatic x0 : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   136: astore_1
    //   137: aload_1
    //   138: aload_0
    //   139: invokevirtual h : ()Landroid/net/Uri;
    //   142: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: new java/lang/IllegalStateException
    //   149: dup
    //   150: aload_1
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: invokespecial <init> : (Ljava/lang/String;)V
    //   157: athrow
    //   158: ldc_w 'Context is required to resolve the file uri of the icon: '
    //   161: invokestatic x0 : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: astore_1
    //   165: aload_1
    //   166: aload_0
    //   167: invokevirtual h : ()Landroid/net/Uri;
    //   170: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   173: pop
    //   174: new java/lang/IllegalArgumentException
    //   177: dup
    //   178: aload_1
    //   179: invokevirtual toString : ()Ljava/lang/String;
    //   182: invokespecial <init> : (Ljava/lang/String;)V
    //   185: athrow
    //   186: getstatic android/os/Build$VERSION.SDK_INT : I
    //   189: bipush #26
    //   191: if_icmplt -> 208
    //   194: aload_0
    //   195: getfield c : Ljava/lang/Object;
    //   198: checkcast android/graphics/Bitmap
    //   201: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   204: astore_1
    //   205: goto -> 288
    //   208: aload_0
    //   209: getfield c : Ljava/lang/Object;
    //   212: checkcast android/graphics/Bitmap
    //   215: iconst_0
    //   216: invokestatic b : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   219: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   222: astore_1
    //   223: goto -> 288
    //   226: aload_0
    //   227: getfield c : Ljava/lang/Object;
    //   230: checkcast java/lang/String
    //   233: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
    //   236: astore_1
    //   237: goto -> 288
    //   240: aload_0
    //   241: getfield c : Ljava/lang/Object;
    //   244: checkcast [B
    //   247: aload_0
    //   248: getfield f : I
    //   251: aload_0
    //   252: getfield g : I
    //   255: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
    //   258: astore_1
    //   259: goto -> 288
    //   262: aload_0
    //   263: invokevirtual e : ()Ljava/lang/String;
    //   266: aload_0
    //   267: getfield f : I
    //   270: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
    //   273: astore_1
    //   274: goto -> 288
    //   277: aload_0
    //   278: getfield c : Ljava/lang/Object;
    //   281: checkcast android/graphics/Bitmap
    //   284: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   287: astore_1
    //   288: aload_0
    //   289: getfield h : Landroid/content/res/ColorStateList;
    //   292: astore_3
    //   293: aload_3
    //   294: ifnull -> 303
    //   297: aload_1
    //   298: aload_3
    //   299: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
    //   302: pop
    //   303: aload_0
    //   304: getfield i : Landroid/graphics/PorterDuff$Mode;
    //   307: astore_3
    //   308: aload_3
    //   309: getstatic androidx/core/graphics/drawable/IconCompat.a : Landroid/graphics/PorterDuff$Mode;
    //   312: if_acmpeq -> 321
    //   315: aload_1
    //   316: aload_3
    //   317: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
    //   320: pop
    //   321: aload_1
    //   322: areturn
    //   323: aload_0
    //   324: getfield c : Ljava/lang/Object;
    //   327: checkcast android/graphics/drawable/Icon
    //   330: areturn
  }
  
  public String toString() {
    String str;
    if (this.b == -1)
      return String.valueOf(this.c); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    switch (this.b) {
      default:
        str = "UNKNOWN";
        break;
      case 6:
        str = "URI_MASKABLE";
        break;
      case 5:
        str = "BITMAP_MASKABLE";
        break;
      case 4:
        str = "URI";
        break;
      case 3:
        str = "DATA";
        break;
      case 2:
        str = "RESOURCE";
        break;
      case 1:
        str = "BITMAP";
        break;
    } 
    stringBuilder.append(str);
    switch (this.b) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.c);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.f);
        if (this.g != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.g);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.k);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(d()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.c).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.c).getHeight());
        break;
    } 
    if (this.h != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.h);
    } 
    if (this.i != a) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.i);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */