package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import eq;
import java.nio.charset.Charset;
import java.util.Objects;

public class IconCompatParcelizer {
  public static IconCompat read(eq parameq) {
    String str1;
    Parcelable parcelable2;
    byte[] arrayOfByte1;
    IconCompat iconCompat = new IconCompat();
    iconCompat.b = parameq.k(iconCompat.b, 1);
    byte[] arrayOfByte2 = iconCompat.d;
    if (parameq.i(2))
      arrayOfByte2 = parameq.g(); 
    iconCompat.d = arrayOfByte2;
    iconCompat.e = parameq.m(iconCompat.e, 3);
    iconCompat.f = parameq.k(iconCompat.f, 4);
    iconCompat.g = parameq.k(iconCompat.g, 5);
    iconCompat.h = (ColorStateList)parameq.m((Parcelable)iconCompat.h, 6);
    String str2 = iconCompat.j;
    if (parameq.i(7))
      str2 = parameq.n(); 
    iconCompat.j = str2;
    str2 = iconCompat.k;
    if (!parameq.i(8)) {
      str1 = str2;
    } else {
      str1 = str1.n();
    } 
    iconCompat.k = str1;
    iconCompat.i = PorterDuff.Mode.valueOf(iconCompat.j);
    switch (iconCompat.b) {
      default:
        return iconCompat;
      case 3:
        iconCompat.c = iconCompat.d;
        return iconCompat;
      case 2:
      case 4:
      case 6:
        str1 = new String(iconCompat.d, Charset.forName("UTF-16"));
        iconCompat.c = str1;
        if (iconCompat.b == 2 && iconCompat.k == null) {
          iconCompat.k = str1.split(":", -1)[0];
          return iconCompat;
        } 
        return iconCompat;
      case 1:
      case 5:
        parcelable2 = iconCompat.e;
        if (parcelable2 != null) {
          iconCompat.c = parcelable2;
          return iconCompat;
        } 
        arrayOfByte1 = iconCompat.d;
        iconCompat.c = arrayOfByte1;
        iconCompat.b = 3;
        iconCompat.f = 0;
        iconCompat.g = arrayOfByte1.length;
        return iconCompat;
      case -1:
        break;
    } 
    Parcelable parcelable1 = iconCompat.e;
    if (parcelable1 != null) {
      iconCompat.c = parcelable1;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public static void write(IconCompat paramIconCompat, eq parameq) {
    Objects.requireNonNull(parameq);
    paramIconCompat.j = paramIconCompat.i.name();
    switch (paramIconCompat.b) {
      case 4:
      case 6:
        paramIconCompat.d = paramIconCompat.c.toString().getBytes(Charset.forName("UTF-16"));
        break;
      case 3:
        paramIconCompat.d = (byte[])paramIconCompat.c;
        break;
      case 2:
        paramIconCompat.d = ((String)paramIconCompat.c).getBytes(Charset.forName("UTF-16"));
        break;
      case 1:
      case 5:
        paramIconCompat.e = (Parcelable)paramIconCompat.c;
        break;
      case -1:
        paramIconCompat.e = (Parcelable)paramIconCompat.c;
        break;
    } 
    int i = paramIconCompat.b;
    if (-1 != i) {
      parameq.p(1);
      parameq.t(i);
    } 
    byte[] arrayOfByte = paramIconCompat.d;
    if (arrayOfByte != null) {
      parameq.p(2);
      parameq.r(arrayOfByte);
    } 
    Parcelable parcelable = paramIconCompat.e;
    if (parcelable != null) {
      parameq.p(3);
      parameq.u(parcelable);
    } 
    i = paramIconCompat.f;
    if (i != 0) {
      parameq.p(4);
      parameq.t(i);
    } 
    i = paramIconCompat.g;
    if (i != 0) {
      parameq.p(5);
      parameq.t(i);
    } 
    ColorStateList colorStateList = paramIconCompat.h;
    if (colorStateList != null) {
      parameq.p(6);
      parameq.u((Parcelable)colorStateList);
    } 
    String str2 = paramIconCompat.j;
    if (str2 != null) {
      parameq.p(7);
      parameq.v(str2);
    } 
    String str1 = paramIconCompat.k;
    if (str1 != null) {
      parameq.p(8);
      parameq.v(str1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */