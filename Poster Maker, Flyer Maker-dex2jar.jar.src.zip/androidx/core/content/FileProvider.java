package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import ma;
import org.xmlpull.v1.XmlPullParserException;
import s30;

public class FileProvider extends ContentProvider {
  public static final String[] b = new String[] { "_display_name", "_size" };
  
  public static final File c = new File("/");
  
  public static HashMap<String, a> d = new HashMap<String, a>();
  
  public a f;
  
  public static a a(Context paramContext, String paramString) {
    synchronized (d) {
      a a2 = d.get(paramString);
      a a1 = a2;
      if (a2 == null)
        try {
          a1 = c(paramContext, paramString);
          d.put(paramString, a1);
        } catch (IOException iOException) {
          throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", iOException);
        } catch (XmlPullParserException xmlPullParserException) {
          throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", xmlPullParserException);
        }  
      return a1;
    } 
  }
  
  public static Uri b(Context paramContext, String paramString, File paramFile) {
    return a(paramContext, paramString).b(paramFile);
  }
  
  public static a c(Context paramContext, String paramString) {
    File file;
    b b = new b(paramString);
    ProviderInfo providerInfo = paramContext.getPackageManager().resolveContentProvider(paramString, 128);
    if (providerInfo != null) {
      XmlResourceParser xmlResourceParser = providerInfo.loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
      if (xmlResourceParser != null)
        while (true) {
          int i = xmlResourceParser.next();
          if (i != 1) {
            if (i == 2) {
              String str3 = xmlResourceParser.getName();
              providerInfo = null;
              String str1 = xmlResourceParser.getAttributeValue(null, "name");
              String str2 = xmlResourceParser.getAttributeValue(null, "path");
              boolean bool = "root-path".equals(str3);
              i = 0;
              if (bool) {
                file = c;
              } else if ("files-path".equals(str3)) {
                file = paramContext.getFilesDir();
              } else if ("cache-path".equals(str3)) {
                file = paramContext.getCacheDir();
              } else if ("external-path".equals(str3)) {
                file = Environment.getExternalStorageDirectory();
              } else {
                File[] arrayOfFile;
                if ("external-files-path".equals(str3)) {
                  arrayOfFile = ma.getExternalFilesDirs(paramContext, null);
                  ProviderInfo providerInfo1 = providerInfo;
                  if (arrayOfFile.length > 0)
                    file = arrayOfFile[0]; 
                } else if ("external-cache-path".equals(arrayOfFile)) {
                  arrayOfFile = ma.getExternalCacheDirs(paramContext);
                  ProviderInfo providerInfo1 = providerInfo;
                  if (arrayOfFile.length > 0)
                    file = arrayOfFile[0]; 
                } else {
                  ProviderInfo providerInfo1 = providerInfo;
                  if (Build.VERSION.SDK_INT >= 21) {
                    providerInfo1 = providerInfo;
                    if ("external-media-path".equals(arrayOfFile)) {
                      arrayOfFile = paramContext.getExternalMediaDirs();
                      providerInfo1 = providerInfo;
                      if (arrayOfFile.length > 0)
                        file = arrayOfFile[0]; 
                    } 
                  } 
                } 
              } 
              if (file != null) {
                while (i < 1) {
                  (new String[1])[0] = str2;
                  str3 = (new String[1])[i];
                  File file1 = file;
                  if (str3 != null)
                    file1 = new File(file, str3); 
                  i++;
                  file = file1;
                } 
                if (!TextUtils.isEmpty(str1)) {
                  try {
                    File file1 = file.getCanonicalFile();
                    b.b.put(str1, file1);
                  } catch (IOException iOException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Failed to resolve canonical path for ");
                    stringBuilder.append(file);
                    throw new IllegalArgumentException(stringBuilder.toString(), iOException);
                  } 
                  continue;
                } 
                throw new IllegalArgumentException("Name must not be empty");
              } 
            } 
            continue;
          } 
          return b;
        }  
      throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException(s30.g0("Couldn't find meta-data for provider with authority ", (String)file));
    throw illegalArgumentException;
  }
  
  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    super.attachInfo(paramContext, paramProviderInfo);
    if (!paramProviderInfo.exported) {
      if (paramProviderInfo.grantUriPermissions) {
        this.f = a(paramContext, paramProviderInfo.authority.split(";")[0]);
        return;
      } 
      throw new SecurityException("Provider must grant uri permissions");
    } 
    throw new SecurityException("Provider must not be exported");
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public String getType(Uri paramUri) {
    File file = this.f.a(paramUri);
    int i = file.getName().lastIndexOf('.');
    if (i >= 0) {
      String str = file.getName().substring(i + 1);
      str = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str);
      if (str != null)
        return str; 
    } 
    return "application/octet-stream";
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new UnsupportedOperationException("No external inserts");
  }
  
  public boolean onCreate() {
    return true;
  }
  
  @SuppressLint({"UnknownNullness"})
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString) {
    int i;
    File file = this.f.a(paramUri);
    if ("r".equals(paramString)) {
      i = 268435456;
    } else {
      if ("w".equals(paramString) || "wt".equals(paramString)) {
        i = 738197504;
        return ParcelFileDescriptor.open(file, i);
      } 
      if ("wa".equals(paramString)) {
        i = 704643072;
      } else if ("rw".equals(paramString)) {
        i = 939524096;
      } else if ("rwt".equals(paramString)) {
        i = 1006632960;
      } else {
        throw new IllegalArgumentException(s30.g0("Invalid mode: ", paramString));
      } 
    } 
    return ParcelFileDescriptor.open(file, i);
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    Object object;
    int i;
    File file = this.f.a(paramUri);
    paramString1 = paramUri.getQueryParameter("displayName");
    String[] arrayOfString1 = paramArrayOfString1;
    if (paramArrayOfString1 == null)
      arrayOfString1 = b; 
    String[] arrayOfString2 = new String[arrayOfString1.length];
    Object[] arrayOfObject2 = new Object[arrayOfString1.length];
    int k = arrayOfString1.length;
    int j = 0;
    boolean bool = false;
    while (j < k) {
      String str = arrayOfString1[j];
      if ("_display_name".equals(str)) {
        arrayOfString2[object] = "_display_name";
        int n = object + 1;
        if (paramString1 == null) {
          str = file.getName();
        } else {
          str = paramString1;
        } 
        arrayOfObject2[object] = str;
        i = n;
      } else {
        int n = i;
        if ("_size".equals(str)) {
          arrayOfString2[i] = "_size";
          n = i + 1;
          arrayOfObject2[i] = Long.valueOf(file.length());
          i = n;
        } else {
          continue;
        } 
      } 
      int m = i;
      continue;
      j++;
      object = SYNTHETIC_LOCAL_VARIABLE_8;
    } 
    arrayOfString1 = new String[i];
    System.arraycopy(arrayOfString2, 0, arrayOfString1, 0, i);
    Object[] arrayOfObject1 = new Object[i];
    System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, i);
    MatrixCursor matrixCursor = new MatrixCursor(arrayOfString1, 1);
    matrixCursor.addRow(arrayOfObject1);
    return (Cursor)matrixCursor;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new UnsupportedOperationException("No external updates");
  }
  
  public static interface a {
    File a(Uri param1Uri);
    
    Uri b(File param1File);
  }
  
  public static class b implements a {
    public final String a;
    
    public final HashMap<String, File> b = new HashMap<String, File>();
    
    public b(String param1String) {
      this.a = param1String;
    }
    
    public File a(Uri param1Uri) {
      File file1;
      String str2 = param1Uri.getEncodedPath();
      int i = str2.indexOf('/', 1);
      String str1 = Uri.decode(str2.substring(1, i));
      str2 = Uri.decode(str2.substring(i + 1));
      File file2 = this.b.get(str1);
      if (file2 != null) {
        file1 = new File(file2, str2);
        try {
          File file = file1.getCanonicalFile();
          if (file.getPath().startsWith(file2.getPath()))
            return file; 
          throw new SecurityException("Resolved path jumped beyond configured root");
        } catch (IOException iOException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to resolve canonical path for ");
          stringBuilder.append(file1);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } 
      throw new IllegalArgumentException(s30.e0("Unable to find configured root for ", file1));
    }
    
    public Uri b(File param1File) {
      String str;
      try {
        Map.Entry<String, File> entry;
        StringBuilder stringBuilder;
        String str1 = param1File.getCanonicalPath();
        param1File = null;
        for (Map.Entry<String, File> entry1 : this.b.entrySet()) {
          String str2 = ((File)entry1.getValue()).getPath();
          if (str1.startsWith(str2) && (param1File == null || str2.length() > ((File)param1File.getValue()).getPath().length()))
            entry = entry1; 
        } 
        if (entry != null) {
          String str2 = ((File)entry.getValue()).getPath();
          if (str2.endsWith("/")) {
            str2 = str1.substring(str2.length());
          } else {
            str2 = str1.substring(str2.length() + 1);
          } 
          stringBuilder = new StringBuilder();
          stringBuilder.append(Uri.encode(entry.getKey()));
          stringBuilder.append('/');
          stringBuilder.append(Uri.encode(str2, "/"));
          str = stringBuilder.toString();
          return (new Uri.Builder()).scheme("content").authority(this.a).encodedPath(str).build();
        } 
        throw new IllegalArgumentException(s30.g0("Failed to find configured root that contains ", stringBuilder));
      } catch (IOException iOException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to resolve canonical path for ");
        stringBuilder.append(str);
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\core\content\FileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */