package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import androidx.activity.ComponentActivity;
import bd;
import fe;
import g9;
import h9;
import i9;
import j9;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import k9;
import le;
import ma;
import nf;
import rd;
import s30;
import sd;
import ud;
import vd;
import zc;

public class CoordinatorLayout extends ViewGroup implements rd, sd {
  public static final Class<?>[] CONSTRUCTOR_PARAMS;
  
  public static final int EVENT_NESTED_SCROLL = 1;
  
  public static final int EVENT_PRE_DRAW = 0;
  
  public static final int EVENT_VIEW_REMOVED = 2;
  
  public static final String TAG = "CoordinatorLayout";
  
  public static final Comparator<View> TOP_SORTED_CHILDREN_COMPARATOR;
  
  private static final int TYPE_ON_INTERCEPT = 0;
  
  private static final int TYPE_ON_TOUCH = 1;
  
  public static final String WIDGET_PACKAGE_NAME;
  
  public static final ThreadLocal<Map<String, Constructor<c>>> sConstructors;
  
  private static final zc<Rect> sRectPool;
  
  private vd mApplyWindowInsetsListener;
  
  private final int[] mBehaviorConsumed;
  
  private View mBehaviorTouchView;
  
  private final j9<View> mChildDag;
  
  private final List<View> mDependencySortedChildren;
  
  private boolean mDisallowInterceptReset;
  
  private boolean mDrawStatusBarBackground;
  
  private boolean mIsAttachedToWindow;
  
  private int[] mKeylines;
  
  private le mLastInsets;
  
  private boolean mNeedsPreDrawListener;
  
  private final ud mNestedScrollingParentHelper;
  
  private View mNestedScrollingTarget;
  
  private final int[] mNestedScrollingV2ConsumedCompat;
  
  public ViewGroup.OnHierarchyChangeListener mOnHierarchyChangeListener;
  
  private g mOnPreDrawListener;
  
  private Paint mScrimPaint;
  
  private Drawable mStatusBarBackground;
  
  private final List<View> mTempDependenciesList;
  
  private final List<View> mTempList1;
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    WIDGET_PACKAGE_NAME = (String)package_;
    if (Build.VERSION.SDK_INT >= 21) {
      TOP_SORTED_CHILDREN_COMPARATOR = new i();
    } else {
      TOP_SORTED_CHILDREN_COMPARATOR = null;
    } 
    CONSTRUCTOR_PARAMS = new Class[] { Context.class, AttributeSet.class };
    sConstructors = new ThreadLocal<Map<String, Constructor<c>>>();
    sRectPool = (zc<Rect>)new bd(12);
  }
  
  public CoordinatorLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, g9.coordinatorLayoutStyle);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray;
    this.mDependencySortedChildren = new ArrayList<View>();
    this.mChildDag = new j9();
    this.mTempList1 = new ArrayList<View>();
    this.mTempDependenciesList = new ArrayList<View>();
    this.mBehaviorConsumed = new int[2];
    this.mNestedScrollingV2ConsumedCompat = new int[2];
    this.mNestedScrollingParentHelper = new ud();
    boolean bool = false;
    if (paramInt == 0) {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, i9.CoordinatorLayout, 0, h9.Widget_Support_CoordinatorLayout);
    } else {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, i9.CoordinatorLayout, paramInt, 0);
    } 
    if (Build.VERSION.SDK_INT >= 29)
      if (paramInt == 0) {
        saveAttributeDataForStyleable(paramContext, i9.CoordinatorLayout, paramAttributeSet, typedArray, 0, h9.Widget_Support_CoordinatorLayout);
      } else {
        saveAttributeDataForStyleable(paramContext, i9.CoordinatorLayout, paramAttributeSet, typedArray, paramInt, 0);
      }  
    paramInt = typedArray.getResourceId(i9.CoordinatorLayout_keylines, 0);
    if (paramInt != 0) {
      Resources resources = paramContext.getResources();
      this.mKeylines = resources.getIntArray(paramInt);
      float f = (resources.getDisplayMetrics()).density;
      int i = this.mKeylines.length;
      for (paramInt = bool; paramInt < i; paramInt++) {
        int[] arrayOfInt = this.mKeylines;
        arrayOfInt[paramInt] = (int)(arrayOfInt[paramInt] * f);
      } 
    } 
    this.mStatusBarBackground = typedArray.getDrawable(i9.CoordinatorLayout_statusBarBackground);
    typedArray.recycle();
    setupForInsets();
    super.setOnHierarchyChangeListener(new e(this));
    AtomicInteger atomicInteger = fe.a;
    if (fe.d.c((View)this) == 0)
      fe.d.s((View)this, 1); 
  }
  
  private static Rect acquireTempRect() {
    Rect rect2 = (Rect)sRectPool.acquire();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  private static int clamp(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  private void constrainChildRect(f paramf, Rect paramRect, int paramInt1, int paramInt2) {
    int j = getWidth();
    int i = getHeight();
    j = Math.max(getPaddingLeft() + paramf.leftMargin, Math.min(paramRect.left, j - getPaddingRight() - paramInt1 - paramf.rightMargin));
    i = Math.max(getPaddingTop() + paramf.topMargin, Math.min(paramRect.top, i - getPaddingBottom() - paramInt2 - paramf.bottomMargin));
    paramRect.set(j, i, paramInt1 + j, paramInt2 + i);
  }
  
  private le dispatchApplyWindowInsetsToBehaviors(le paramle) {
    if (paramle.h())
      return paramle; 
    int i = 0;
    int j = getChildCount();
    while (i < j) {
      View view = getChildAt(i);
      AtomicInteger atomicInteger = fe.a;
      le le1 = paramle;
      if (fe.d.b(view)) {
        c<View> c = ((f)view.getLayoutParams()).a;
        le1 = paramle;
        if (c != null) {
          paramle = c.onApplyWindowInsets(this, view, paramle);
          le1 = paramle;
          if (paramle.h())
            return paramle; 
        } 
      } 
      i++;
      paramle = le1;
    } 
    return paramle;
  }
  
  private void getDesiredAnchoredChildRectWithoutConstraints(View paramView, int paramInt1, Rect paramRect1, Rect paramRect2, f paramf, int paramInt2, int paramInt3) {
    int i = Gravity.getAbsoluteGravity(resolveAnchoredChildGravity(paramf.c), paramInt1);
    paramInt1 = Gravity.getAbsoluteGravity(resolveGravity(paramf.d), paramInt1);
    int m = i & 0x7;
    int k = i & 0x70;
    int j = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (j != 1) {
      if (j != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (m != 1) {
      j = paramInt1;
      if (m != 5)
        j = paramInt1 - paramInt2; 
    } else {
      j = paramInt1 - paramInt2 / 2;
    } 
    if (k != 16) {
      paramInt1 = i;
      if (k != 80)
        paramInt1 = i - paramInt3; 
    } else {
      paramInt1 = i - paramInt3 / 2;
    } 
    paramRect2.set(j, paramInt1, paramInt2 + j, paramInt3 + paramInt1);
  }
  
  private int getKeyline(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.mKeylines;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      stringBuilder.toString();
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      stringBuilder.toString();
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  private void getTopSortedChildren(List<View> paramList) {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int j = getChildCount();
    for (int i = j - 1; i >= 0; i--) {
      int k;
      if (bool) {
        k = getChildDrawingOrder(j, i);
      } else {
        k = i;
      } 
      paramList.add(getChildAt(k));
    } 
    Comparator<View> comparator = TOP_SORTED_CHILDREN_COMPARATOR;
    if (comparator != null)
      Collections.sort(paramList, comparator); 
  }
  
  private boolean hasDependencies(View paramView) {
    j9<View> j91 = this.mChildDag;
    int j = j91.b.q;
    for (int i = 0; i < j; i++) {
      ArrayList arrayList = (ArrayList)j91.b.l(i);
      if (arrayList != null && arrayList.contains(paramView))
        return true; 
    } 
    return false;
  }
  
  private void layoutChild(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    Rect rect1 = acquireTempRect();
    rect1.set(getPaddingLeft() + f.leftMargin, getPaddingTop() + f.topMargin, getWidth() - getPaddingRight() - f.rightMargin, getHeight() - getPaddingBottom() - f.bottomMargin);
    if (this.mLastInsets != null) {
      AtomicInteger atomicInteger = fe.a;
      if (fe.d.b((View)this) && !fe.d.b(paramView)) {
        int i = rect1.left;
        rect1.left = this.mLastInsets.d() + i;
        i = rect1.top;
        rect1.top = this.mLastInsets.f() + i;
        rect1.right -= this.mLastInsets.e();
        rect1.bottom -= this.mLastInsets.c();
      } 
    } 
    Rect rect2 = acquireTempRect();
    Gravity.apply(resolveGravity(f.c), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
    paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    releaseTempRect(rect1);
    releaseTempRect(rect2);
  }
  
  private void layoutChildWithAnchor(View paramView1, View paramView2, int paramInt) {
    Rect rect1 = acquireTempRect();
    Rect rect2 = acquireTempRect();
    try {
      getDescendantRect(paramView2, rect1);
      getDesiredAnchoredChildRect(paramView1, paramInt, rect1, rect2);
      paramView1.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      return;
    } finally {
      releaseTempRect(rect1);
      releaseTempRect(rect2);
    } 
  }
  
  private void layoutChildWithKeyline(View paramView, int paramInt1, int paramInt2) {
    f f = (f)paramView.getLayoutParams();
    int i = Gravity.getAbsoluteGravity(resolveKeylineGravity(f.c), paramInt2);
    int i2 = i & 0x7;
    int i1 = i & 0x70;
    int n = getWidth();
    int m = getHeight();
    int j = paramView.getMeasuredWidth();
    int k = paramView.getMeasuredHeight();
    i = paramInt1;
    if (paramInt2 == 1)
      i = n - paramInt1; 
    paramInt1 = getKeyline(i) - j;
    paramInt2 = 0;
    if (i2 != 1) {
      if (i2 == 5)
        paramInt1 += j; 
    } else {
      paramInt1 += j / 2;
    } 
    if (i1 != 16) {
      if (i1 == 80)
        paramInt2 = k + 0; 
    } else {
      paramInt2 = 0 + k / 2;
    } 
    paramInt1 = Math.max(getPaddingLeft() + f.leftMargin, Math.min(paramInt1, n - getPaddingRight() - j - f.rightMargin));
    paramInt2 = Math.max(getPaddingTop() + f.topMargin, Math.min(paramInt2, m - getPaddingBottom() - k - f.bottomMargin));
    paramView.layout(paramInt1, paramInt2, j + paramInt1, k + paramInt2);
  }
  
  private void offsetChildByInset(View paramView, Rect paramRect, int paramInt) {
    // Byte code:
    //   0: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   3: astore #9
    //   5: aload_1
    //   6: invokestatic c : (Landroid/view/View;)Z
    //   9: ifne -> 13
    //   12: return
    //   13: aload_1
    //   14: invokevirtual getWidth : ()I
    //   17: ifle -> 455
    //   20: aload_1
    //   21: invokevirtual getHeight : ()I
    //   24: ifgt -> 28
    //   27: return
    //   28: aload_1
    //   29: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   32: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   35: astore #11
    //   37: aload #11
    //   39: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   42: astore #12
    //   44: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   47: astore #9
    //   49: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   52: astore #10
    //   54: aload #10
    //   56: aload_1
    //   57: invokevirtual getLeft : ()I
    //   60: aload_1
    //   61: invokevirtual getTop : ()I
    //   64: aload_1
    //   65: invokevirtual getRight : ()I
    //   68: aload_1
    //   69: invokevirtual getBottom : ()I
    //   72: invokevirtual set : (IIII)V
    //   75: aload #12
    //   77: ifnull -> 152
    //   80: aload #12
    //   82: aload_0
    //   83: aload_1
    //   84: aload #9
    //   86: invokevirtual getInsetDodgeRect : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   89: ifeq -> 152
    //   92: aload #10
    //   94: aload #9
    //   96: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   99: ifeq -> 105
    //   102: goto -> 159
    //   105: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   108: invokestatic x0 : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: astore_1
    //   112: aload_1
    //   113: aload #9
    //   115: invokevirtual toShortString : ()Ljava/lang/String;
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: pop
    //   122: aload_1
    //   123: ldc_w ' | Bounds:'
    //   126: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: pop
    //   130: aload_1
    //   131: aload #10
    //   133: invokevirtual toShortString : ()Ljava/lang/String;
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: new java/lang/IllegalArgumentException
    //   143: dup
    //   144: aload_1
    //   145: invokevirtual toString : ()Ljava/lang/String;
    //   148: invokespecial <init> : (Ljava/lang/String;)V
    //   151: athrow
    //   152: aload #9
    //   154: aload #10
    //   156: invokevirtual set : (Landroid/graphics/Rect;)V
    //   159: aload #10
    //   161: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   164: aload #9
    //   166: invokevirtual isEmpty : ()Z
    //   169: ifeq -> 178
    //   172: aload #9
    //   174: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   177: return
    //   178: aload #11
    //   180: getfield h : I
    //   183: iload_3
    //   184: invokestatic getAbsoluteGravity : (II)I
    //   187: istore #6
    //   189: iconst_1
    //   190: istore #5
    //   192: iload #6
    //   194: bipush #48
    //   196: iand
    //   197: bipush #48
    //   199: if_icmpne -> 246
    //   202: aload #9
    //   204: getfield top : I
    //   207: aload #11
    //   209: getfield topMargin : I
    //   212: isub
    //   213: aload #11
    //   215: getfield j : I
    //   218: isub
    //   219: istore_3
    //   220: aload_2
    //   221: getfield top : I
    //   224: istore #4
    //   226: iload_3
    //   227: iload #4
    //   229: if_icmpge -> 246
    //   232: aload_0
    //   233: aload_1
    //   234: iload #4
    //   236: iload_3
    //   237: isub
    //   238: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   241: iconst_1
    //   242: istore_3
    //   243: goto -> 248
    //   246: iconst_0
    //   247: istore_3
    //   248: iload_3
    //   249: istore #4
    //   251: iload #6
    //   253: bipush #80
    //   255: iand
    //   256: bipush #80
    //   258: if_icmpne -> 314
    //   261: aload_0
    //   262: invokevirtual getHeight : ()I
    //   265: aload #9
    //   267: getfield bottom : I
    //   270: isub
    //   271: aload #11
    //   273: getfield bottomMargin : I
    //   276: isub
    //   277: aload #11
    //   279: getfield j : I
    //   282: iadd
    //   283: istore #7
    //   285: aload_2
    //   286: getfield bottom : I
    //   289: istore #8
    //   291: iload_3
    //   292: istore #4
    //   294: iload #7
    //   296: iload #8
    //   298: if_icmpge -> 314
    //   301: aload_0
    //   302: aload_1
    //   303: iload #7
    //   305: iload #8
    //   307: isub
    //   308: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   311: iconst_1
    //   312: istore #4
    //   314: iload #4
    //   316: ifne -> 325
    //   319: aload_0
    //   320: aload_1
    //   321: iconst_0
    //   322: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   325: iload #6
    //   327: iconst_3
    //   328: iand
    //   329: iconst_3
    //   330: if_icmpne -> 377
    //   333: aload #9
    //   335: getfield left : I
    //   338: aload #11
    //   340: getfield leftMargin : I
    //   343: isub
    //   344: aload #11
    //   346: getfield i : I
    //   349: isub
    //   350: istore_3
    //   351: aload_2
    //   352: getfield left : I
    //   355: istore #4
    //   357: iload_3
    //   358: iload #4
    //   360: if_icmpge -> 377
    //   363: aload_0
    //   364: aload_1
    //   365: iload #4
    //   367: iload_3
    //   368: isub
    //   369: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   372: iconst_1
    //   373: istore_3
    //   374: goto -> 379
    //   377: iconst_0
    //   378: istore_3
    //   379: iload #6
    //   381: iconst_5
    //   382: iand
    //   383: iconst_5
    //   384: if_icmpne -> 440
    //   387: aload_0
    //   388: invokevirtual getWidth : ()I
    //   391: aload #9
    //   393: getfield right : I
    //   396: isub
    //   397: aload #11
    //   399: getfield rightMargin : I
    //   402: isub
    //   403: aload #11
    //   405: getfield i : I
    //   408: iadd
    //   409: istore #4
    //   411: aload_2
    //   412: getfield right : I
    //   415: istore #6
    //   417: iload #4
    //   419: iload #6
    //   421: if_icmpge -> 440
    //   424: aload_0
    //   425: aload_1
    //   426: iload #4
    //   428: iload #6
    //   430: isub
    //   431: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   434: iload #5
    //   436: istore_3
    //   437: goto -> 440
    //   440: iload_3
    //   441: ifne -> 450
    //   444: aload_0
    //   445: aload_1
    //   446: iconst_0
    //   447: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   450: aload #9
    //   452: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   455: return
  }
  
  public static c parseBehavior(Context paramContext, AttributeSet paramAttributeSet, String paramString) {
    String str;
    if (TextUtils.isEmpty(paramString))
      return null; 
    if (paramString.startsWith(".")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(paramString);
      str = stringBuilder.toString();
    } else if (paramString.indexOf('.') >= 0) {
      str = paramString;
    } else {
      String str1 = WIDGET_PACKAGE_NAME;
      str = paramString;
      if (!TextUtils.isEmpty(str1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append('.');
        stringBuilder.append(paramString);
        str = stringBuilder.toString();
      } 
    } 
    try {
      ThreadLocal<Map<String, Constructor<c>>> threadLocal = sConstructors;
      Map<Object, Object> map2 = (Map)threadLocal.get();
      Map<Object, Object> map1 = map2;
      if (map2 == null) {
        map1 = new HashMap<Object, Object>();
        threadLocal.set(map1);
      } 
      Constructor<?> constructor2 = (Constructor)map1.get(str);
      Constructor<?> constructor1 = constructor2;
      if (constructor2 == null) {
        constructor1 = Class.forName(str, false, paramContext.getClassLoader()).getConstructor(CONSTRUCTOR_PARAMS);
        constructor1.setAccessible(true);
        map1.put(str, constructor1);
      } 
      return (c)constructor1.newInstance(new Object[] { paramContext, paramAttributeSet });
    } catch (Exception exception) {
      throw new RuntimeException(s30.g0("Could not inflate Behavior subclass ", str), exception);
    } 
  }
  
  private boolean performIntercept(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    int j = paramMotionEvent.getActionMasked();
    List<View> list = this.mTempList1;
    getTopSortedChildren(list);
    int k = list.size();
    f f = null;
    int i = 0;
    boolean bool1 = false;
    boolean bool = false;
    while (true) {
      bool2 = bool1;
      if (i < k) {
        MotionEvent motionEvent;
        f f1;
        View view = list.get(i);
        f f2 = (f)view.getLayoutParams();
        c<View> c = f2.a;
        boolean bool3 = true;
        if ((bool1 || bool) && j != 0) {
          f2 = f;
          bool2 = bool1;
          bool3 = bool;
          if (c != null) {
            f2 = f;
            if (f == null) {
              long l = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt != 1) {
                bool2 = bool1;
                bool3 = bool;
              } else {
                c.onTouchEvent(this, view, motionEvent);
                bool2 = bool1;
                bool3 = bool;
              } 
            } else {
              c.onInterceptTouchEvent(this, view, motionEvent);
              bool2 = bool1;
              bool3 = bool;
            } 
          } 
        } else {
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (c != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = c.onTouchEvent(this, view, paramMotionEvent); 
              } else {
                bool1 = c.onInterceptTouchEvent(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.mBehaviorTouchView = view;
                bool2 = bool1;
              } 
            } 
          } 
          c = ((f)motionEvent).a;
          if (c == null)
            ((f)motionEvent).m = false; 
          boolean bool4 = ((f)motionEvent).m;
          if (bool4) {
            bool1 = true;
          } else {
            if (c != null) {
              bool1 = c.blocksInteractionBelow(this, view);
            } else {
              bool1 = false;
            } 
            bool1 |= bool4;
            ((f)motionEvent).m = bool1;
          } 
          if (bool1 && !bool4) {
            bool = bool3;
          } else {
            bool = false;
          } 
          if (bool1 && !bool)
            break; 
          bool3 = bool;
          f1 = f;
        } 
        i++;
        f = f1;
        bool1 = bool2;
        bool = bool3;
        continue;
      } 
      break;
    } 
    list.clear();
    return bool2;
  }
  
  private void prepareChildren() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mDependencySortedChildren : Ljava/util/List;
    //   4: invokeinterface clear : ()V
    //   9: aload_0
    //   10: getfield mChildDag : Lj9;
    //   13: astore #7
    //   15: aload #7
    //   17: getfield b : Lz5;
    //   20: getfield q : I
    //   23: istore_2
    //   24: iconst_0
    //   25: istore #4
    //   27: iconst_0
    //   28: istore_1
    //   29: iload_1
    //   30: iload_2
    //   31: if_icmpge -> 78
    //   34: aload #7
    //   36: getfield b : Lz5;
    //   39: iload_1
    //   40: invokevirtual l : (I)Ljava/lang/Object;
    //   43: checkcast java/util/ArrayList
    //   46: astore #8
    //   48: aload #8
    //   50: ifnull -> 71
    //   53: aload #8
    //   55: invokevirtual clear : ()V
    //   58: aload #7
    //   60: getfield a : Lzc;
    //   63: aload #8
    //   65: invokeinterface a : (Ljava/lang/Object;)Z
    //   70: pop
    //   71: iload_1
    //   72: iconst_1
    //   73: iadd
    //   74: istore_1
    //   75: goto -> 29
    //   78: aload #7
    //   80: getfield b : Lz5;
    //   83: invokevirtual clear : ()V
    //   86: aload_0
    //   87: invokevirtual getChildCount : ()I
    //   90: istore #5
    //   92: iconst_0
    //   93: istore_1
    //   94: iload_1
    //   95: iload #5
    //   97: if_icmpge -> 828
    //   100: aload_0
    //   101: iload_1
    //   102: invokevirtual getChildAt : (I)Landroid/view/View;
    //   105: astore #9
    //   107: aload_0
    //   108: aload #9
    //   110: invokevirtual getResolvedLayoutParams : (Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;
    //   113: astore #10
    //   115: aload #10
    //   117: getfield f : I
    //   120: iconst_m1
    //   121: if_icmpne -> 139
    //   124: aload #10
    //   126: aconst_null
    //   127: putfield l : Landroid/view/View;
    //   130: aload #10
    //   132: aconst_null
    //   133: putfield k : Landroid/view/View;
    //   136: goto -> 435
    //   139: aload #10
    //   141: getfield k : Landroid/view/View;
    //   144: astore #7
    //   146: aload #7
    //   148: ifnull -> 259
    //   151: aload #7
    //   153: invokevirtual getId : ()I
    //   156: aload #10
    //   158: getfield f : I
    //   161: if_icmpeq -> 167
    //   164: goto -> 241
    //   167: aload #10
    //   169: getfield k : Landroid/view/View;
    //   172: astore #8
    //   174: aload #8
    //   176: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   179: astore #7
    //   181: aload #7
    //   183: aload_0
    //   184: if_acmpeq -> 246
    //   187: aload #7
    //   189: ifnull -> 229
    //   192: aload #7
    //   194: aload #9
    //   196: if_acmpne -> 202
    //   199: goto -> 229
    //   202: aload #7
    //   204: instanceof android/view/View
    //   207: ifeq -> 217
    //   210: aload #7
    //   212: checkcast android/view/View
    //   215: astore #8
    //   217: aload #7
    //   219: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   224: astore #7
    //   226: goto -> 181
    //   229: aload #10
    //   231: aconst_null
    //   232: putfield l : Landroid/view/View;
    //   235: aload #10
    //   237: aconst_null
    //   238: putfield k : Landroid/view/View;
    //   241: iconst_0
    //   242: istore_2
    //   243: goto -> 255
    //   246: aload #10
    //   248: aload #8
    //   250: putfield l : Landroid/view/View;
    //   253: iconst_1
    //   254: istore_2
    //   255: iload_2
    //   256: ifne -> 435
    //   259: aload_0
    //   260: aload #10
    //   262: getfield f : I
    //   265: invokevirtual findViewById : (I)Landroid/view/View;
    //   268: astore #8
    //   270: aload #10
    //   272: aload #8
    //   274: putfield k : Landroid/view/View;
    //   277: aload #8
    //   279: ifnull -> 416
    //   282: aload #8
    //   284: aload_0
    //   285: if_acmpne -> 321
    //   288: aload_0
    //   289: invokevirtual isInEditMode : ()Z
    //   292: ifeq -> 310
    //   295: aload #10
    //   297: aconst_null
    //   298: putfield l : Landroid/view/View;
    //   301: aload #10
    //   303: aconst_null
    //   304: putfield k : Landroid/view/View;
    //   307: goto -> 435
    //   310: new java/lang/IllegalStateException
    //   313: dup
    //   314: ldc_w 'View can not be anchored to the the parent CoordinatorLayout'
    //   317: invokespecial <init> : (Ljava/lang/String;)V
    //   320: athrow
    //   321: aload #8
    //   323: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   326: astore #7
    //   328: aload #7
    //   330: aload_0
    //   331: if_acmpeq -> 406
    //   334: aload #7
    //   336: ifnull -> 406
    //   339: aload #7
    //   341: aload #9
    //   343: if_acmpne -> 379
    //   346: aload_0
    //   347: invokevirtual isInEditMode : ()Z
    //   350: ifeq -> 368
    //   353: aload #10
    //   355: aconst_null
    //   356: putfield l : Landroid/view/View;
    //   359: aload #10
    //   361: aconst_null
    //   362: putfield k : Landroid/view/View;
    //   365: goto -> 435
    //   368: new java/lang/IllegalStateException
    //   371: dup
    //   372: ldc_w 'Anchor must not be a descendant of the anchored view'
    //   375: invokespecial <init> : (Ljava/lang/String;)V
    //   378: athrow
    //   379: aload #7
    //   381: instanceof android/view/View
    //   384: ifeq -> 394
    //   387: aload #7
    //   389: checkcast android/view/View
    //   392: astore #8
    //   394: aload #7
    //   396: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   401: astore #7
    //   403: goto -> 328
    //   406: aload #10
    //   408: aload #8
    //   410: putfield l : Landroid/view/View;
    //   413: goto -> 435
    //   416: aload_0
    //   417: invokevirtual isInEditMode : ()Z
    //   420: ifeq -> 772
    //   423: aload #10
    //   425: aconst_null
    //   426: putfield l : Landroid/view/View;
    //   429: aload #10
    //   431: aconst_null
    //   432: putfield k : Landroid/view/View;
    //   435: aload_0
    //   436: getfield mChildDag : Lj9;
    //   439: aload #9
    //   441: invokevirtual a : (Ljava/lang/Object;)V
    //   444: iconst_0
    //   445: istore_2
    //   446: iload_2
    //   447: iload #5
    //   449: if_icmpge -> 765
    //   452: iload_2
    //   453: iload_1
    //   454: if_icmpne -> 460
    //   457: goto -> 758
    //   460: aload_0
    //   461: iload_2
    //   462: invokevirtual getChildAt : (I)Landroid/view/View;
    //   465: astore #11
    //   467: aload #11
    //   469: aload #10
    //   471: getfield l : Landroid/view/View;
    //   474: if_acmpeq -> 570
    //   477: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   480: astore #7
    //   482: aload_0
    //   483: invokestatic d : (Landroid/view/View;)I
    //   486: istore_3
    //   487: aload #11
    //   489: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   492: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   495: getfield g : I
    //   498: iload_3
    //   499: invokestatic getAbsoluteGravity : (II)I
    //   502: istore #6
    //   504: iload #6
    //   506: ifeq -> 531
    //   509: aload #10
    //   511: getfield h : I
    //   514: iload_3
    //   515: invokestatic getAbsoluteGravity : (II)I
    //   518: iload #6
    //   520: iand
    //   521: iload #6
    //   523: if_icmpne -> 531
    //   526: iconst_1
    //   527: istore_3
    //   528: goto -> 533
    //   531: iconst_0
    //   532: istore_3
    //   533: iload_3
    //   534: ifne -> 570
    //   537: aload #10
    //   539: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   542: astore #7
    //   544: aload #7
    //   546: ifnull -> 565
    //   549: aload #7
    //   551: aload_0
    //   552: aload #9
    //   554: aload #11
    //   556: invokevirtual layoutDependsOn : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   559: ifeq -> 565
    //   562: goto -> 570
    //   565: iconst_0
    //   566: istore_3
    //   567: goto -> 572
    //   570: iconst_1
    //   571: istore_3
    //   572: iload_3
    //   573: ifeq -> 758
    //   576: aload_0
    //   577: getfield mChildDag : Lj9;
    //   580: getfield b : Lz5;
    //   583: aload #11
    //   585: invokevirtual e : (Ljava/lang/Object;)I
    //   588: iflt -> 596
    //   591: iconst_1
    //   592: istore_3
    //   593: goto -> 598
    //   596: iconst_0
    //   597: istore_3
    //   598: iload_3
    //   599: ifne -> 611
    //   602: aload_0
    //   603: getfield mChildDag : Lj9;
    //   606: aload #11
    //   608: invokevirtual a : (Ljava/lang/Object;)V
    //   611: aload_0
    //   612: getfield mChildDag : Lj9;
    //   615: astore #12
    //   617: aload #12
    //   619: getfield b : Lz5;
    //   622: aload #11
    //   624: invokevirtual e : (Ljava/lang/Object;)I
    //   627: iflt -> 635
    //   630: iconst_1
    //   631: istore_3
    //   632: goto -> 637
    //   635: iconst_0
    //   636: istore_3
    //   637: iload_3
    //   638: ifeq -> 747
    //   641: aload #12
    //   643: getfield b : Lz5;
    //   646: aload #9
    //   648: invokevirtual e : (Ljava/lang/Object;)I
    //   651: iflt -> 659
    //   654: iconst_1
    //   655: istore_3
    //   656: goto -> 661
    //   659: iconst_0
    //   660: istore_3
    //   661: iload_3
    //   662: ifeq -> 747
    //   665: aload #12
    //   667: getfield b : Lz5;
    //   670: aload #11
    //   672: aconst_null
    //   673: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   676: checkcast java/util/ArrayList
    //   679: astore #8
    //   681: aload #8
    //   683: astore #7
    //   685: aload #8
    //   687: ifnonnull -> 736
    //   690: aload #12
    //   692: getfield a : Lzc;
    //   695: invokeinterface acquire : ()Ljava/lang/Object;
    //   700: checkcast java/util/ArrayList
    //   703: astore #8
    //   705: aload #8
    //   707: astore #7
    //   709: aload #8
    //   711: ifnonnull -> 723
    //   714: new java/util/ArrayList
    //   717: dup
    //   718: invokespecial <init> : ()V
    //   721: astore #7
    //   723: aload #12
    //   725: getfield b : Lz5;
    //   728: aload #11
    //   730: aload #7
    //   732: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   735: pop
    //   736: aload #7
    //   738: aload #9
    //   740: invokevirtual add : (Ljava/lang/Object;)Z
    //   743: pop
    //   744: goto -> 758
    //   747: new java/lang/IllegalArgumentException
    //   750: dup
    //   751: ldc_w 'All nodes must be present in the graph before being added as an edge'
    //   754: invokespecial <init> : (Ljava/lang/String;)V
    //   757: athrow
    //   758: iload_2
    //   759: iconst_1
    //   760: iadd
    //   761: istore_2
    //   762: goto -> 446
    //   765: iload_1
    //   766: iconst_1
    //   767: iadd
    //   768: istore_1
    //   769: goto -> 94
    //   772: ldc_w 'Could not find CoordinatorLayout descendant view with id '
    //   775: invokestatic x0 : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   778: astore #7
    //   780: aload #7
    //   782: aload_0
    //   783: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   786: aload #10
    //   788: getfield f : I
    //   791: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   794: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   797: pop
    //   798: aload #7
    //   800: ldc_w ' to anchor view '
    //   803: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   806: pop
    //   807: aload #7
    //   809: aload #9
    //   811: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   814: pop
    //   815: new java/lang/IllegalStateException
    //   818: dup
    //   819: aload #7
    //   821: invokevirtual toString : ()Ljava/lang/String;
    //   824: invokespecial <init> : (Ljava/lang/String;)V
    //   827: athrow
    //   828: aload_0
    //   829: getfield mDependencySortedChildren : Ljava/util/List;
    //   832: astore #7
    //   834: aload_0
    //   835: getfield mChildDag : Lj9;
    //   838: astore #8
    //   840: aload #8
    //   842: getfield c : Ljava/util/ArrayList;
    //   845: invokevirtual clear : ()V
    //   848: aload #8
    //   850: getfield d : Ljava/util/HashSet;
    //   853: invokevirtual clear : ()V
    //   856: aload #8
    //   858: getfield b : Lz5;
    //   861: getfield q : I
    //   864: istore_2
    //   865: iload #4
    //   867: istore_1
    //   868: iload_1
    //   869: iload_2
    //   870: if_icmpge -> 904
    //   873: aload #8
    //   875: aload #8
    //   877: getfield b : Lz5;
    //   880: iload_1
    //   881: invokevirtual h : (I)Ljava/lang/Object;
    //   884: aload #8
    //   886: getfield c : Ljava/util/ArrayList;
    //   889: aload #8
    //   891: getfield d : Ljava/util/HashSet;
    //   894: invokevirtual b : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    //   897: iload_1
    //   898: iconst_1
    //   899: iadd
    //   900: istore_1
    //   901: goto -> 868
    //   904: aload #7
    //   906: aload #8
    //   908: getfield c : Ljava/util/ArrayList;
    //   911: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   916: pop
    //   917: aload_0
    //   918: getfield mDependencySortedChildren : Ljava/util/List;
    //   921: invokestatic reverse : (Ljava/util/List;)V
    //   924: return
  }
  
  private static void releaseTempRect(Rect paramRect) {
    paramRect.setEmpty();
    sRectPool.a(paramRect);
  }
  
  private void resetTouchBehaviors(boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      c<View> c = ((f)view.getLayoutParams()).a;
      if (c != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          c.onInterceptTouchEvent(this, view, motionEvent);
        } else {
          c.onTouchEvent(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (i = 0; i < j; i++)
      ((f)getChildAt(i).getLayoutParams()).m = false; 
    this.mBehaviorTouchView = null;
    this.mDisallowInterceptReset = false;
  }
  
  private static int resolveAnchoredChildGravity(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 17; 
    return i;
  }
  
  private static int resolveGravity(int paramInt) {
    int i = paramInt;
    if ((paramInt & 0x7) == 0)
      i = paramInt | 0x800003; 
    paramInt = i;
    if ((i & 0x70) == 0)
      paramInt = i | 0x30; 
    return paramInt;
  }
  
  private static int resolveKeylineGravity(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 8388661; 
    return i;
  }
  
  private void setInsetOffsetX(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.i;
    if (i != paramInt) {
      fe.t(paramView, paramInt - i);
      f.i = paramInt;
    } 
  }
  
  private void setInsetOffsetY(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.j;
    if (i != paramInt) {
      fe.u(paramView, paramInt - i);
      f.j = paramInt;
    } 
  }
  
  private void setupForInsets() {
    if (Build.VERSION.SDK_INT < 21)
      return; 
    AtomicInteger atomicInteger = fe.a;
    if (fe.d.b((View)this)) {
      if (this.mApplyWindowInsetsListener == null)
        this.mApplyWindowInsetsListener = new a(this); 
      fe.G((View)this, this.mApplyWindowInsetsListener);
      setSystemUiVisibility(1280);
      return;
    } 
    fe.G((View)this, null);
  }
  
  public void addPreDrawListener() {
    if (this.mIsAttachedToWindow) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
    } 
    this.mNeedsPreDrawListener = true;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void dispatchDependentViewsChanged(View paramView) {
    List<View> list = (List)this.mChildDag.b.getOrDefault(paramView, null);
    if (list != null && !list.isEmpty())
      for (int i = 0; i < list.size(); i++) {
        View view = list.get(i);
        c<View> c = ((f)view.getLayoutParams()).a;
        if (c != null)
          c.onDependentViewChanged(this, view, paramView); 
      }  
  }
  
  public boolean doViewsOverlap(View paramView1, View paramView2) {
    int i = paramView1.getVisibility();
    boolean bool = false;
    if (i == 0 && paramView2.getVisibility() == 0) {
      Rect rect2 = acquireTempRect();
      if (paramView1.getParent() != this) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      getChildRect(paramView1, bool1, rect2);
      Rect rect1 = acquireTempRect();
      if (paramView2.getParent() != this) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      getChildRect(paramView2, bool1, rect1);
      boolean bool1 = bool;
      try {
        if (rect2.left <= rect1.right) {
          bool1 = bool;
          if (rect2.top <= rect1.bottom) {
            bool1 = bool;
            if (rect2.right >= rect1.left) {
              i = rect2.bottom;
              int j = rect1.top;
              bool1 = bool;
              if (i >= j)
                bool1 = true; 
            } 
          } 
        } 
        return bool1;
      } finally {
        releaseTempRect(rect2);
        releaseTempRect(rect1);
      } 
    } 
    return false;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    f f = (f)paramView.getLayoutParams();
    c<View> c = f.a;
    if (c != null) {
      float f1 = c.getScrimOpacity(this, paramView);
      if (f1 > 0.0F) {
        if (this.mScrimPaint == null)
          this.mScrimPaint = new Paint(); 
        this.mScrimPaint.setColor(f.a.getScrimColor(this, paramView));
        this.mScrimPaint.setAlpha(clamp(Math.round(f1 * 255.0F), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque())
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE); 
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), (getWidth() - getPaddingRight()), (getHeight() - getPaddingBottom()), this.mScrimPaint);
        paramCanvas.restoreToCount(i);
      } 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.mStatusBarBackground;
    byte b = 0;
    int i = b;
    if (drawable != null) {
      i = b;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  public void ensurePreDrawListener() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (hasDependencies(getChildAt(i))) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1 != this.mNeedsPreDrawListener) {
      if (bool1) {
        addPreDrawListener();
        return;
      } 
      removePreDrawListener();
    } 
  }
  
  public f generateDefaultLayoutParams() {
    return new f(-2, -2);
  }
  
  public f generateLayoutParams(AttributeSet paramAttributeSet) {
    return new f(getContext(), paramAttributeSet);
  }
  
  public f generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams));
  }
  
  public void getChildRect(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      getDescendantRect(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  public List<View> getDependencies(View paramView) {
    j9<View> j91 = this.mChildDag;
    int j = j91.b.q;
    ArrayList<Object> arrayList = null;
    int i = 0;
    while (i < j) {
      ArrayList arrayList2 = (ArrayList)j91.b.l(i);
      ArrayList<Object> arrayList1 = arrayList;
      if (arrayList2 != null) {
        arrayList1 = arrayList;
        if (arrayList2.contains(paramView)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(j91.b.h(i));
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    this.mTempDependenciesList.clear();
    if (arrayList != null)
      this.mTempDependenciesList.addAll(arrayList); 
    return this.mTempDependenciesList;
  }
  
  public final List<View> getDependencySortedChildren() {
    prepareChildren();
    return Collections.unmodifiableList(this.mDependencySortedChildren);
  }
  
  public List<View> getDependents(View paramView) {
    List<? extends View> list = (List)this.mChildDag.b.getOrDefault(paramView, null);
    this.mTempDependenciesList.clear();
    if (list != null)
      this.mTempDependenciesList.addAll(list); 
    return this.mTempDependenciesList;
  }
  
  public void getDescendantRect(View paramView, Rect paramRect) {
    ThreadLocal threadLocal = k9.a;
    paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
    ThreadLocal<Matrix> threadLocal1 = k9.a;
    Matrix matrix = threadLocal1.get();
    if (matrix == null) {
      matrix = new Matrix();
      threadLocal1.set(matrix);
    } else {
      matrix.reset();
    } 
    k9.a((ViewParent)this, paramView, matrix);
    ThreadLocal<RectF> threadLocal2 = k9.b;
    RectF rectF2 = threadLocal2.get();
    RectF rectF1 = rectF2;
    if (rectF2 == null) {
      rectF1 = new RectF();
      threadLocal2.set(rectF1);
    } 
    rectF1.set(paramRect);
    matrix.mapRect(rectF1);
    paramRect.set((int)(rectF1.left + 0.5F), (int)(rectF1.top + 0.5F), (int)(rectF1.right + 0.5F), (int)(rectF1.bottom + 0.5F));
  }
  
  public void getDesiredAnchoredChildRect(View paramView, int paramInt, Rect paramRect1, Rect paramRect2) {
    f f = (f)paramView.getLayoutParams();
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    getDesiredAnchoredChildRectWithoutConstraints(paramView, paramInt, paramRect1, paramRect2, f, i, j);
    constrainChildRect(f, paramRect2, i, j);
  }
  
  public void getLastChildRect(View paramView, Rect paramRect) {
    paramRect.set(((f)paramView.getLayoutParams()).q);
  }
  
  public final le getLastWindowInsets() {
    return this.mLastInsets;
  }
  
  public int getNestedScrollAxes() {
    return this.mNestedScrollingParentHelper.a();
  }
  
  public f getResolvedLayoutParams(View paramView) {
    f f = (f)paramView.getLayoutParams();
    if (!f.b) {
      d d;
      if (paramView instanceof b) {
        f.b(((b)paramView).getBehavior());
        f.b = true;
        return f;
      } 
      Class<?> clazz = paramView.getClass();
      paramView = null;
      while (true) {
        View view = paramView;
        if (clazz != null) {
          d d1 = clazz.<d>getAnnotation(d.class);
          d = d1;
          if (d1 == null) {
            clazz = clazz.getSuperclass();
            continue;
          } 
        } 
        break;
      } 
      if (d != null)
        try {
          f.b(d.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
        } catch (Exception exception) {
          d.value().getName();
        }  
      f.b = true;
    } 
    return f;
  }
  
  public Drawable getStatusBarBackground() {
    return this.mStatusBarBackground;
  }
  
  public int getSuggestedMinimumHeight() {
    int i = super.getSuggestedMinimumHeight();
    int j = getPaddingTop();
    return Math.max(i, getPaddingBottom() + j);
  }
  
  public int getSuggestedMinimumWidth() {
    int i = super.getSuggestedMinimumWidth();
    int j = getPaddingLeft();
    return Math.max(i, getPaddingRight() + j);
  }
  
  public boolean isPointInChildBounds(View paramView, int paramInt1, int paramInt2) {
    Rect rect = acquireTempRect();
    getDescendantRect(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      releaseTempRect(rect);
    } 
  }
  
  public void offsetChildToAnchor(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   7: astore #6
    //   9: aload #6
    //   11: getfield k : Landroid/view/View;
    //   14: ifnull -> 212
    //   17: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   20: astore #7
    //   22: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   25: astore #8
    //   27: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   30: astore #9
    //   32: aload_0
    //   33: aload #6
    //   35: getfield k : Landroid/view/View;
    //   38: aload #7
    //   40: invokevirtual getDescendantRect : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   43: iconst_0
    //   44: istore_3
    //   45: aload_0
    //   46: aload_1
    //   47: iconst_0
    //   48: aload #8
    //   50: invokevirtual getChildRect : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   53: aload_1
    //   54: invokevirtual getMeasuredWidth : ()I
    //   57: istore #4
    //   59: aload_1
    //   60: invokevirtual getMeasuredHeight : ()I
    //   63: istore #5
    //   65: aload_0
    //   66: aload_1
    //   67: iload_2
    //   68: aload #7
    //   70: aload #9
    //   72: aload #6
    //   74: iload #4
    //   76: iload #5
    //   78: invokespecial getDesiredAnchoredChildRectWithoutConstraints : (Landroid/view/View;ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V
    //   81: aload #9
    //   83: getfield left : I
    //   86: aload #8
    //   88: getfield left : I
    //   91: if_icmpne -> 109
    //   94: iload_3
    //   95: istore_2
    //   96: aload #9
    //   98: getfield top : I
    //   101: aload #8
    //   103: getfield top : I
    //   106: if_icmpeq -> 111
    //   109: iconst_1
    //   110: istore_2
    //   111: aload_0
    //   112: aload #6
    //   114: aload #9
    //   116: iload #4
    //   118: iload #5
    //   120: invokespecial constrainChildRect : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    //   123: aload #9
    //   125: getfield left : I
    //   128: aload #8
    //   130: getfield left : I
    //   133: isub
    //   134: istore_3
    //   135: aload #9
    //   137: getfield top : I
    //   140: aload #8
    //   142: getfield top : I
    //   145: isub
    //   146: istore #4
    //   148: iload_3
    //   149: ifeq -> 157
    //   152: aload_1
    //   153: iload_3
    //   154: invokestatic t : (Landroid/view/View;I)V
    //   157: iload #4
    //   159: ifeq -> 168
    //   162: aload_1
    //   163: iload #4
    //   165: invokestatic u : (Landroid/view/View;I)V
    //   168: iload_2
    //   169: ifeq -> 197
    //   172: aload #6
    //   174: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   177: astore #10
    //   179: aload #10
    //   181: ifnull -> 197
    //   184: aload #10
    //   186: aload_0
    //   187: aload_1
    //   188: aload #6
    //   190: getfield k : Landroid/view/View;
    //   193: invokevirtual onDependentViewChanged : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   196: pop
    //   197: aload #7
    //   199: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   202: aload #8
    //   204: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   207: aload #9
    //   209: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   212: return
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    resetTouchBehaviors(false);
    if (this.mNeedsPreDrawListener) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
    } 
    if (this.mLastInsets == null) {
      AtomicInteger atomicInteger = fe.a;
      if (fe.d.b((View)this))
        fe.A((View)this); 
    } 
    this.mIsAttachedToWindow = true;
  }
  
  public final void onChildViewsChanged(int paramInt) {
    AtomicInteger atomicInteger = fe.a;
    int j = fe.e.d((View)this);
    int k = this.mDependencySortedChildren.size();
    Rect rect1 = acquireTempRect();
    Rect rect2 = acquireTempRect();
    Rect rect3 = acquireTempRect();
    for (int i = 0; i < k; i++) {
      View view = this.mDependencySortedChildren.get(i);
      f f = (f)view.getLayoutParams();
      if (paramInt == 0 && view.getVisibility() == 8)
        continue; 
      int m;
      for (m = 0; m < i; m++) {
        View view1 = this.mDependencySortedChildren.get(m);
        if (f.l == view1)
          offsetChildToAnchor(view, j); 
      } 
      getChildRect(view, true, rect2);
      if (f.g != 0 && !rect2.isEmpty()) {
        m = Gravity.getAbsoluteGravity(f.g, j);
        int n = m & 0x70;
        if (n != 48) {
          if (n == 80)
            rect1.bottom = Math.max(rect1.bottom, getHeight() - rect2.top); 
        } else {
          rect1.top = Math.max(rect1.top, rect2.bottom);
        } 
        m &= 0x7;
        if (m != 3) {
          if (m == 5)
            rect1.right = Math.max(rect1.right, getWidth() - rect2.left); 
        } else {
          rect1.left = Math.max(rect1.left, rect2.right);
        } 
      } 
      if (f.h != 0 && view.getVisibility() == 0)
        offsetChildByInset(view, rect1, j); 
      if (paramInt != 2) {
        getLastChildRect(view, rect3);
        if (rect3.equals(rect2))
          continue; 
        recordLastChildRect(view, rect2);
      } 
      for (m = i + 1; m < k; m++) {
        View view1 = this.mDependencySortedChildren.get(m);
        f f1 = (f)view1.getLayoutParams();
        c<View> c = f1.a;
        if (c != null && c.layoutDependsOn(this, view1, view))
          if (paramInt == 0 && f1.p) {
            f1.p = false;
          } else {
            boolean bool;
            if (paramInt != 2) {
              bool = c.onDependentViewChanged(this, view1, view);
            } else {
              c.onDependentViewRemoved(this, view1, view);
              bool = true;
            } 
            if (paramInt == 1)
              f1.p = bool; 
          }  
      } 
      continue;
    } 
    releaseTempRect(rect1);
    releaseTempRect(rect2);
    releaseTempRect(rect3);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    resetTouchBehaviors(false);
    if (this.mNeedsPreDrawListener && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener); 
    View view = this.mNestedScrollingTarget;
    if (view != null)
      onStopNestedScroll(view); 
    this.mIsAttachedToWindow = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null) {
      boolean bool;
      le le1 = this.mLastInsets;
      if (le1 != null) {
        bool = le1.f();
      } else {
        bool = false;
      } 
      if (bool) {
        this.mStatusBarBackground.setBounds(0, 0, getWidth(), bool);
        this.mStatusBarBackground.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      resetTouchBehaviors(true); 
    boolean bool = performIntercept(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      resetTouchBehaviors(true); 
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    AtomicInteger atomicInteger = fe.a;
    paramInt2 = fe.e.d((View)this);
    paramInt3 = this.mDependencySortedChildren.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = this.mDependencySortedChildren.get(paramInt1);
      if (view.getVisibility() != 8) {
        c<View> c = ((f)view.getLayoutParams()).a;
        if (c == null || !c.onLayoutChild(this, view, paramInt2))
          onLayoutChild(view, paramInt2); 
      } 
    } 
  }
  
  public void onLayoutChild(View paramView, int paramInt) {
    int i;
    f f = (f)paramView.getLayoutParams();
    View view = f.k;
    if (view == null && f.f != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i) {
      if (view != null) {
        layoutChildWithAnchor(paramView, view, paramInt);
        return;
      } 
      i = f.e;
      if (i >= 0) {
        layoutChildWithKeyline(paramView, i, paramInt);
        return;
      } 
      layoutChild(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial prepareChildren : ()V
    //   4: aload_0
    //   5: invokevirtual ensurePreDrawListener : ()V
    //   8: aload_0
    //   9: invokevirtual getPaddingLeft : ()I
    //   12: istore #13
    //   14: aload_0
    //   15: invokevirtual getPaddingTop : ()I
    //   18: istore #15
    //   20: aload_0
    //   21: invokevirtual getPaddingRight : ()I
    //   24: istore #16
    //   26: aload_0
    //   27: invokevirtual getPaddingBottom : ()I
    //   30: istore #17
    //   32: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   35: astore #25
    //   37: aload_0
    //   38: invokestatic d : (Landroid/view/View;)I
    //   41: istore #18
    //   43: iload #18
    //   45: iconst_1
    //   46: if_icmpne -> 55
    //   49: iconst_1
    //   50: istore #5
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #5
    //   58: iload_1
    //   59: invokestatic getMode : (I)I
    //   62: istore #19
    //   64: iload_1
    //   65: invokestatic getSize : (I)I
    //   68: istore #20
    //   70: iload_2
    //   71: invokestatic getMode : (I)I
    //   74: istore #21
    //   76: iload_2
    //   77: invokestatic getSize : (I)I
    //   80: istore #22
    //   82: aload_0
    //   83: invokevirtual getSuggestedMinimumWidth : ()I
    //   86: istore #11
    //   88: aload_0
    //   89: invokevirtual getSuggestedMinimumHeight : ()I
    //   92: istore #10
    //   94: aload_0
    //   95: getfield mLastInsets : Lle;
    //   98: ifnull -> 114
    //   101: aload_0
    //   102: invokestatic b : (Landroid/view/View;)Z
    //   105: ifeq -> 114
    //   108: iconst_1
    //   109: istore #6
    //   111: goto -> 117
    //   114: iconst_0
    //   115: istore #6
    //   117: aload_0
    //   118: getfield mDependencySortedChildren : Ljava/util/List;
    //   121: invokeinterface size : ()I
    //   126: istore #7
    //   128: iconst_0
    //   129: istore #4
    //   131: iconst_0
    //   132: istore #8
    //   134: iload #13
    //   136: istore_3
    //   137: iload_3
    //   138: istore #9
    //   140: iload #8
    //   142: iload #7
    //   144: if_icmpge -> 518
    //   147: aload_0
    //   148: getfield mDependencySortedChildren : Ljava/util/List;
    //   151: iload #8
    //   153: invokeinterface get : (I)Ljava/lang/Object;
    //   158: checkcast android/view/View
    //   161: astore #26
    //   163: aload #26
    //   165: invokevirtual getVisibility : ()I
    //   168: bipush #8
    //   170: if_icmpne -> 176
    //   173: goto -> 506
    //   176: aload #26
    //   178: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   181: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   184: astore #25
    //   186: aload #25
    //   188: getfield e : I
    //   191: istore_3
    //   192: iload_3
    //   193: iflt -> 296
    //   196: iload #19
    //   198: ifeq -> 296
    //   201: aload_0
    //   202: iload_3
    //   203: invokespecial getKeyline : (I)I
    //   206: istore_3
    //   207: aload #25
    //   209: getfield c : I
    //   212: invokestatic resolveKeylineGravity : (I)I
    //   215: iload #18
    //   217: invokestatic getAbsoluteGravity : (II)I
    //   220: bipush #7
    //   222: iand
    //   223: istore #12
    //   225: iload #12
    //   227: iconst_3
    //   228: if_icmpne -> 236
    //   231: iload #5
    //   233: ifeq -> 247
    //   236: iload #12
    //   238: iconst_5
    //   239: if_icmpne -> 262
    //   242: iload #5
    //   244: ifeq -> 262
    //   247: iconst_0
    //   248: iload #20
    //   250: iload #16
    //   252: isub
    //   253: iload_3
    //   254: isub
    //   255: invokestatic max : (II)I
    //   258: istore_3
    //   259: goto -> 298
    //   262: iload #12
    //   264: iconst_5
    //   265: if_icmpne -> 273
    //   268: iload #5
    //   270: ifeq -> 284
    //   273: iload #12
    //   275: iconst_3
    //   276: if_icmpne -> 296
    //   279: iload #5
    //   281: ifeq -> 296
    //   284: iconst_0
    //   285: iload_3
    //   286: iload #9
    //   288: isub
    //   289: invokestatic max : (II)I
    //   292: istore_3
    //   293: goto -> 298
    //   296: iconst_0
    //   297: istore_3
    //   298: iload #4
    //   300: istore #14
    //   302: iload #6
    //   304: ifeq -> 384
    //   307: aload #26
    //   309: invokestatic b : (Landroid/view/View;)Z
    //   312: ifne -> 384
    //   315: aload_0
    //   316: getfield mLastInsets : Lle;
    //   319: invokevirtual d : ()I
    //   322: istore #4
    //   324: aload_0
    //   325: getfield mLastInsets : Lle;
    //   328: invokevirtual e : ()I
    //   331: istore #24
    //   333: aload_0
    //   334: getfield mLastInsets : Lle;
    //   337: invokevirtual f : ()I
    //   340: istore #12
    //   342: aload_0
    //   343: getfield mLastInsets : Lle;
    //   346: invokevirtual c : ()I
    //   349: istore #23
    //   351: iload #20
    //   353: iload #24
    //   355: iload #4
    //   357: iadd
    //   358: isub
    //   359: iload #19
    //   361: invokestatic makeMeasureSpec : (II)I
    //   364: istore #4
    //   366: iload #22
    //   368: iload #23
    //   370: iload #12
    //   372: iadd
    //   373: isub
    //   374: iload #21
    //   376: invokestatic makeMeasureSpec : (II)I
    //   379: istore #12
    //   381: goto -> 390
    //   384: iload_1
    //   385: istore #4
    //   387: iload_2
    //   388: istore #12
    //   390: aload #25
    //   392: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   395: astore #27
    //   397: aload #27
    //   399: ifnull -> 422
    //   402: aload #27
    //   404: aload_0
    //   405: aload #26
    //   407: iload #4
    //   409: iload_3
    //   410: iload #12
    //   412: iconst_0
    //   413: invokevirtual onMeasureChild : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   416: ifne -> 434
    //   419: goto -> 422
    //   422: aload_0
    //   423: aload #26
    //   425: iload #4
    //   427: iload_3
    //   428: iload #12
    //   430: iconst_0
    //   431: invokevirtual onMeasureChild : (Landroid/view/View;IIII)V
    //   434: iload #11
    //   436: aload #26
    //   438: invokevirtual getMeasuredWidth : ()I
    //   441: iload #13
    //   443: iload #16
    //   445: iadd
    //   446: iadd
    //   447: aload #25
    //   449: getfield leftMargin : I
    //   452: iadd
    //   453: aload #25
    //   455: getfield rightMargin : I
    //   458: iadd
    //   459: invokestatic max : (II)I
    //   462: istore #11
    //   464: iload #10
    //   466: aload #26
    //   468: invokevirtual getMeasuredHeight : ()I
    //   471: iload #15
    //   473: iload #17
    //   475: iadd
    //   476: iadd
    //   477: aload #25
    //   479: getfield topMargin : I
    //   482: iadd
    //   483: aload #25
    //   485: getfield bottomMargin : I
    //   488: iadd
    //   489: invokestatic max : (II)I
    //   492: istore #10
    //   494: iload #14
    //   496: aload #26
    //   498: invokevirtual getMeasuredState : ()I
    //   501: invokestatic combineMeasuredStates : (II)I
    //   504: istore #4
    //   506: iload #8
    //   508: iconst_1
    //   509: iadd
    //   510: istore #8
    //   512: iload #9
    //   514: istore_3
    //   515: goto -> 137
    //   518: aload_0
    //   519: iload #11
    //   521: iload_1
    //   522: ldc_w -16777216
    //   525: iload #4
    //   527: iand
    //   528: invokestatic resolveSizeAndState : (III)I
    //   531: iload #10
    //   533: iload_2
    //   534: iload #4
    //   536: bipush #16
    //   538: ishl
    //   539: invokestatic resolveSizeAndState : (III)I
    //   542: invokevirtual setMeasuredDimension : (II)V
    //   545: return
  }
  
  public void onMeasureChild(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(0)) {
          bool1 = bool;
        } else {
          c<View> c = f.a;
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.onNestedFling(this, view, paramView, paramFloat1, paramFloat2, paramBoolean); 
        } 
      } 
      i++;
    } 
    if (bool)
      onChildViewsChanged(1); 
    return bool;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(0)) {
          bool1 = bool;
        } else {
          c<View> c = f.a;
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.onNestedPreFling(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int m = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < m; j = n) {
      int n;
      int i1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i1 = k;
        n = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt3)) {
          i1 = k;
          n = j;
        } else {
          c<View> c = f.a;
          i1 = k;
          n = j;
          if (c != null) {
            int[] arrayOfInt2 = this.mBehaviorConsumed;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.onNestedPreScroll(this, view, paramView, paramInt1, paramInt2, arrayOfInt2, paramInt3);
            int[] arrayOfInt1 = this.mBehaviorConsumed;
            if (paramInt1 > 0) {
              n = Math.max(k, arrayOfInt1[0]);
            } else {
              n = Math.min(k, arrayOfInt1[0]);
            } 
            k = n;
            arrayOfInt1 = this.mBehaviorConsumed;
            if (paramInt2 > 0) {
              n = Math.max(j, arrayOfInt1[1]);
            } else {
              n = Math.min(j, arrayOfInt1[1]);
            } 
            bool = true;
            i1 = k;
          } 
        } 
      } 
      i++;
      k = i1;
    } 
    paramArrayOfint[0] = k;
    paramArrayOfint[1] = j;
    if (bool)
      onChildViewsChanged(1); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.mNestedScrollingV2ConsumedCompat);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int m = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < m; j = n) {
      int n;
      int i1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i1 = k;
        n = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt5)) {
          i1 = k;
          n = j;
        } else {
          c<View> c = f.a;
          i1 = k;
          n = j;
          if (c != null) {
            int[] arrayOfInt2 = this.mBehaviorConsumed;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.onNestedScroll(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, arrayOfInt2);
            int[] arrayOfInt1 = this.mBehaviorConsumed;
            if (paramInt3 > 0) {
              n = Math.max(k, arrayOfInt1[0]);
            } else {
              n = Math.min(k, arrayOfInt1[0]);
            } 
            k = n;
            if (paramInt4 > 0) {
              n = Math.max(j, this.mBehaviorConsumed[1]);
            } else {
              n = Math.min(j, this.mBehaviorConsumed[1]);
            } 
            bool = true;
            i1 = k;
          } 
        } 
      } 
      i++;
      k = i1;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + k;
    paramArrayOfint[1] = paramArrayOfint[1] + j;
    if (bool)
      onChildViewsChanged(1); 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    onNestedScrollAccepted(paramView1, paramView2, paramInt, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    ud ud1 = this.mNestedScrollingParentHelper;
    if (paramInt2 == 1) {
      ud1.b = paramInt1;
    } else {
      ud1.a = paramInt1;
    } 
    this.mNestedScrollingTarget = paramView2;
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = (f)view.getLayoutParams();
      if (f.a(paramInt2)) {
        c<View> c = f.a;
        if (c != null)
          c.onNestedScrollAccepted(this, view, paramView1, paramView2, paramInt1, paramInt2); 
      } 
    } 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof h)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    h h = (h)paramParcelable;
    super.onRestoreInstanceState(h.getSuperState());
    SparseArray<Parcelable> sparseArray = h.b;
    int i = 0;
    int j = getChildCount();
    while (i < j) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = (getResolvedLayoutParams(view)).a;
      if (k != -1 && c != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(k);
        if (parcelable != null)
          c.onRestoreInstanceState(this, view, parcelable); 
      } 
      i++;
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    h h = new h(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = ((f)view.getLayoutParams()).a;
      if (k != -1 && c != null) {
        Parcelable parcelable = c.onSaveInstanceState(this, view);
        if (parcelable != null)
          sparseArray.append(k, parcelable); 
      } 
    } 
    h.b = sparseArray;
    return (Parcelable)h;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return onStartNestedScroll(paramView1, paramView2, paramInt, 0);
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int j = getChildCount();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        c<View> c = f.a;
        if (c != null) {
          boolean bool1 = c.onStartNestedScroll(this, view, paramView1, paramView2, paramInt1, paramInt2);
          bool |= bool1;
          f.c(paramInt2, bool1);
        } else {
          f.c(paramInt2, false);
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void onStopNestedScroll(View paramView) {
    onStopNestedScroll(paramView, 0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    ud ud1 = this.mNestedScrollingParentHelper;
    if (paramInt == 1) {
      ud1.b = 0;
    } else {
      ud1.a = 0;
    } 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = (f)view.getLayoutParams();
      if (f.a(paramInt)) {
        c<View> c = f.a;
        if (c != null)
          c.onStopNestedScroll(this, view, paramView, paramInt); 
        f.c(paramInt, false);
        f.p = false;
      } 
    } 
    this.mNestedScrollingTarget = null;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield mBehaviorTouchView : Landroid/view/View;
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokespecial performIntercept : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: istore #4
    //   22: iload_3
    //   23: ifeq -> 76
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield mBehaviorTouchView : Landroid/view/View;
    //   35: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   38: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   41: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   44: astore #8
    //   46: iload_3
    //   47: istore #4
    //   49: aload #8
    //   51: ifnull -> 76
    //   54: aload #8
    //   56: aload_0
    //   57: aload_0
    //   58: getfield mBehaviorTouchView : Landroid/view/View;
    //   61: aload_1
    //   62: invokevirtual onTouchEvent : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   65: istore #5
    //   67: iload_3
    //   68: istore #4
    //   70: iload #5
    //   72: istore_3
    //   73: goto -> 78
    //   76: iconst_0
    //   77: istore_3
    //   78: aload_0
    //   79: getfield mBehaviorTouchView : Landroid/view/View;
    //   82: astore #9
    //   84: aconst_null
    //   85: astore #8
    //   87: aload #9
    //   89: ifnonnull -> 107
    //   92: iload_3
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   98: ior
    //   99: istore #5
    //   101: aload #8
    //   103: astore_1
    //   104: goto -> 144
    //   107: iload_3
    //   108: istore #5
    //   110: aload #8
    //   112: astore_1
    //   113: iload #4
    //   115: ifeq -> 144
    //   118: invokestatic uptimeMillis : ()J
    //   121: lstore #6
    //   123: lload #6
    //   125: lload #6
    //   127: iconst_3
    //   128: fconst_0
    //   129: fconst_0
    //   130: iconst_0
    //   131: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   134: astore_1
    //   135: aload_0
    //   136: aload_1
    //   137: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   140: pop
    //   141: iload_3
    //   142: istore #5
    //   144: aload_1
    //   145: ifnull -> 152
    //   148: aload_1
    //   149: invokevirtual recycle : ()V
    //   152: iload_2
    //   153: iconst_1
    //   154: if_icmpeq -> 162
    //   157: iload_2
    //   158: iconst_3
    //   159: if_icmpne -> 167
    //   162: aload_0
    //   163: iconst_0
    //   164: invokespecial resetTouchBehaviors : (Z)V
    //   167: iload #5
    //   169: ireturn
  }
  
  public void recordLastChildRect(View paramView, Rect paramRect) {
    ((f)paramView.getLayoutParams()).q.set(paramRect);
  }
  
  public void removePreDrawListener() {
    if (this.mIsAttachedToWindow && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener); 
    this.mNeedsPreDrawListener = false;
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    c<View> c = ((f)paramView.getLayoutParams()).a;
    return (c != null && c.onRequestChildRectangleOnScreen(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.mDisallowInterceptReset) {
      resetTouchBehaviors(false);
      this.mDisallowInterceptReset = true;
    } 
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    setupForInsets();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.mOnHierarchyChangeListener = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.mStatusBarBackground;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.mStatusBarBackground = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.mStatusBarBackground.setState(getDrawableState()); 
        paramDrawable = this.mStatusBarBackground;
        AtomicInteger atomicInteger1 = fe.a;
        ComponentActivity.c.H0(paramDrawable, fe.e.d((View)this));
        paramDrawable = this.mStatusBarBackground;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.mStatusBarBackground.setCallback((Drawable.Callback)this);
      } 
      AtomicInteger atomicInteger = fe.a;
      fe.d.k((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = ma.getDrawable(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.mStatusBarBackground;
    if (drawable != null && drawable.isVisible() != bool)
      this.mStatusBarBackground.setVisible(bool, false); 
  }
  
  public final le setWindowInsets(le paramle) {
    le le1 = paramle;
    if (!Objects.equals(this.mLastInsets, paramle)) {
      boolean bool1;
      this.mLastInsets = paramle;
      boolean bool2 = true;
      if (paramle != null && paramle.f() > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.mDrawStatusBarBackground = bool1;
      if (!bool1 && getBackground() == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      setWillNotDraw(bool1);
      le1 = dispatchApplyWindowInsetsToBehaviors(paramle);
      requestLayout();
    } 
    return le1;
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mStatusBarBackground);
  }
  
  public class a implements vd {
    public a(CoordinatorLayout this$0) {}
    
    public le onApplyWindowInsets(View param1View, le param1le) {
      return this.a.setWindowInsets(param1le);
    }
  }
  
  public static interface b {
    CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View> {
    public c() {}
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public static Object getTag(View param1View) {
      return ((CoordinatorLayout.f)param1View.getLayoutParams()).r;
    }
    
    public static void setTag(View param1View, Object param1Object) {
      ((CoordinatorLayout.f)param1View.getLayoutParams()).r = param1Object;
    }
    
    public boolean blocksInteractionBelow(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (getScrimOpacity(param1CoordinatorLayout, param1V) > 0.0F);
    }
    
    public boolean getInsetDodgeRect(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect) {
      return false;
    }
    
    public int getScrimColor(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return -16777216;
    }
    
    public float getScrimOpacity(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return 0.0F;
    }
    
    public boolean layoutDependsOn(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public le onApplyWindowInsets(CoordinatorLayout param1CoordinatorLayout, V param1V, le param1le) {
      return param1le;
    }
    
    public void onAttachedToLayoutParams(CoordinatorLayout.f param1f) {}
    
    public boolean onDependentViewChanged(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void onDependentViewRemoved(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void onDetachedFromLayoutParams() {}
    
    public boolean onInterceptTouchEvent(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean onLayoutChild(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean onMeasureChild(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean onNestedFling(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return false;
    }
    
    public boolean onNestedPreFling(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    @Deprecated
    public void onNestedPreScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint) {}
    
    public void onNestedPreScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {
      if (param1Int3 == 0)
        onNestedPreScroll(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1ArrayOfint); 
    }
    
    @Deprecated
    public void onNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    @Deprecated
    public void onNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      if (param1Int5 == 0)
        onNestedScroll(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public void onNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int[] param1ArrayOfint) {
      param1ArrayOfint[0] = param1ArrayOfint[0] + param1Int3;
      param1ArrayOfint[1] = param1ArrayOfint[1] + param1Int4;
      onNestedScroll(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
    }
    
    @Deprecated
    public void onNestedScrollAccepted(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {}
    
    public void onNestedScrollAccepted(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        onNestedScrollAccepted(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1); 
    }
    
    public boolean onRequestChildRectangleOnScreen(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public void onRestoreInstanceState(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public Parcelable onSaveInstanceState(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    @Deprecated
    public boolean onStartNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {
      return false;
    }
    
    public boolean onStartNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      return (param1Int2 == 0) ? onStartNestedScroll(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1) : false;
    }
    
    @Deprecated
    public void onStopNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void onStopNestedScroll(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int) {
      if (param1Int == 0)
        onStopNestedScroll(param1CoordinatorLayout, param1V, param1View); 
    }
    
    public boolean onTouchEvent(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d {
    Class<? extends CoordinatorLayout.c> value();
  }
  
  public class e implements ViewGroup.OnHierarchyChangeListener {
    public e(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.b.mOnHierarchyChangeListener;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.b.onChildViewsChanged(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.b.mOnHierarchyChangeListener;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    public CoordinatorLayout.c a;
    
    public boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    public int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    public int i;
    
    public int j;
    
    public View k;
    
    public View l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public final Rect q = new Rect();
    
    public Object r;
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public f(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i9.CoordinatorLayout_Layout);
      this.c = typedArray.getInteger(i9.CoordinatorLayout_Layout_android_layout_gravity, 0);
      this.f = typedArray.getResourceId(i9.CoordinatorLayout_Layout_layout_anchor, -1);
      this.d = typedArray.getInteger(i9.CoordinatorLayout_Layout_layout_anchorGravity, 0);
      this.e = typedArray.getInteger(i9.CoordinatorLayout_Layout_layout_keyline, -1);
      this.g = typedArray.getInt(i9.CoordinatorLayout_Layout_layout_insetEdge, 0);
      this.h = typedArray.getInt(i9.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
      int i = i9.CoordinatorLayout_Layout_layout_behavior;
      boolean bool = typedArray.hasValue(i);
      this.b = bool;
      if (bool)
        this.a = CoordinatorLayout.parseBehavior(param1Context, param1AttributeSet, typedArray.getString(i)); 
      typedArray.recycle();
      CoordinatorLayout.c c1 = this.a;
      if (c1 != null)
        c1.onAttachedToLayoutParams(this); 
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public f(f param1f) {
      super(param1f);
    }
    
    public boolean a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    public void b(CoordinatorLayout.c param1c) {
      CoordinatorLayout.c c1 = this.a;
      if (c1 != param1c) {
        if (c1 != null)
          c1.onDetachedFromLayoutParams(); 
        this.a = param1c;
        this.r = null;
        this.b = true;
        if (param1c != null)
          param1c.onAttachedToLayoutParams(this); 
      } 
    }
    
    public void c(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int != 1)
          return; 
        this.o = param1Boolean;
        return;
      } 
      this.n = param1Boolean;
    }
  }
  
  public class g implements ViewTreeObserver.OnPreDrawListener {
    public g(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.b.onChildViewsChanged(0);
      return true;
    }
  }
  
  public static class h extends nf {
    public static final Parcelable.Creator<h> CREATOR = (Parcelable.Creator<h>)new a();
    
    public SparseArray<Parcelable> b;
    
    public h(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int j = param1Parcel.readInt();
      int[] arrayOfInt = new int[j];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.b = new SparseArray(j);
      for (int i = 0; i < j; i++)
        this.b.append(arrayOfInt[i], arrayOfParcelable[i]); 
    }
    
    public h(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b;
      super.writeToParcel(param1Parcel, param1Int);
      SparseArray<Parcelable> sparseArray = this.b;
      int i = 0;
      if (sparseArray != null) {
        b = sparseArray.size();
      } else {
        b = 0;
      } 
      param1Parcel.writeInt(b);
      int[] arrayOfInt = new int[b];
      Parcelable[] arrayOfParcelable = new Parcelable[b];
      while (i < b) {
        arrayOfInt[i] = this.b.keyAt(i);
        arrayOfParcelable[i] = (Parcelable)this.b.valueAt(i);
        i++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<h> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new CoordinatorLayout.h(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.h(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new CoordinatorLayout.h[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<h> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new CoordinatorLayout.h(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.h(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new CoordinatorLayout.h[param1Int];
    }
  }
  
  public static class i implements Comparator<View> {
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      float f1 = fe.q((View)param1Object1);
      float f2 = fe.q((View)param1Object2);
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */