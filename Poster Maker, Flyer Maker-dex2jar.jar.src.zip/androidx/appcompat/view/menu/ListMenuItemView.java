package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import b0;
import e2;
import fe;
import j2;
import java.util.concurrent.atomic.AtomicInteger;
import m4;
import s;
import x;
import y;
import z;

public class ListMenuItemView extends LinearLayout implements j2.a, AbsListView.SelectionBoundsAdjuster {
  public boolean A;
  
  public e2 b;
  
  public ImageView c;
  
  public RadioButton d;
  
  public TextView f;
  
  public CheckBox g;
  
  public TextView p;
  
  public ImageView q;
  
  public ImageView r;
  
  public LinearLayout s;
  
  public Drawable t;
  
  public int u;
  
  public Context v;
  
  public boolean w;
  
  public Drawable x;
  
  public boolean y;
  
  public LayoutInflater z;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    m4 m4 = m4.r(getContext(), paramAttributeSet, b0.MenuView, i, 0);
    this.t = m4.g(b0.MenuView_android_itemBackground);
    this.u = m4.m(b0.MenuView_android_itemTextAppearance, -1);
    this.w = m4.a(b0.MenuView_preserveIconSpacing, false);
    this.v = paramContext;
    this.x = m4.g(b0.MenuView_subMenuArrow);
    Resources.Theme theme = paramContext.getTheme();
    i = s.dropDownListViewStyle;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, i, 0);
    this.y = typedArray.hasValue(0);
    m4.b.recycle();
    typedArray.recycle();
  }
  
  private LayoutInflater getInflater() {
    if (this.z == null)
      this.z = LayoutInflater.from(getContext()); 
    return this.z;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.q;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public final void a() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(y.abc_list_menu_item_checkbox, (ViewGroup)this, false);
    this.g = checkBox;
    LinearLayout linearLayout = this.s;
    if (linearLayout != null) {
      linearLayout.addView((View)checkBox, -1);
      return;
    } 
    addView((View)checkBox, -1);
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.r;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.r.getLayoutParams();
      int i = paramRect.top;
      paramRect.top = this.r.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + i;
    } 
  }
  
  public final void b() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(y.abc_list_menu_item_radio, (ViewGroup)this, false);
    this.d = radioButton;
    LinearLayout linearLayout = this.s;
    if (linearLayout != null) {
      linearLayout.addView((View)radioButton, -1);
      return;
    } 
    addView((View)radioButton, -1);
  }
  
  public void c(boolean paramBoolean) {
    byte b;
    if (paramBoolean && this.b.n()) {
      b = 0;
    } else {
      b = 8;
    } 
    if (b == 0) {
      String str;
      TextView textView = this.p;
      e2 e21 = this.b;
      char c = e21.e();
      if (c == '\000') {
        str = "";
      } else {
        int i;
        Resources resources = ((e2)str).n.getContext().getResources();
        StringBuilder stringBuilder = new StringBuilder();
        if (ViewConfiguration.get(((e2)str).n.getContext()).hasPermanentMenuKey())
          stringBuilder.append(resources.getString(z.abc_prepend_shortcut_label)); 
        if (((e2)str).n.isQwertyMode()) {
          i = ((e2)str).k;
        } else {
          i = ((e2)str).i;
        } 
        e2.c(stringBuilder, i, 65536, resources.getString(z.abc_menu_meta_shortcut_label));
        e2.c(stringBuilder, i, 4096, resources.getString(z.abc_menu_ctrl_shortcut_label));
        e2.c(stringBuilder, i, 2, resources.getString(z.abc_menu_alt_shortcut_label));
        e2.c(stringBuilder, i, 1, resources.getString(z.abc_menu_shift_shortcut_label));
        e2.c(stringBuilder, i, 4, resources.getString(z.abc_menu_sym_shortcut_label));
        e2.c(stringBuilder, i, 8, resources.getString(z.abc_menu_function_shortcut_label));
        if (c != '\b') {
          if (c != '\n') {
            if (c != ' ') {
              stringBuilder.append(c);
            } else {
              stringBuilder.append(resources.getString(z.abc_menu_space_shortcut_label));
            } 
          } else {
            stringBuilder.append(resources.getString(z.abc_menu_enter_shortcut_label));
          } 
        } else {
          stringBuilder.append(resources.getString(z.abc_menu_delete_shortcut_label));
        } 
        str = stringBuilder.toString();
      } 
      textView.setText(str);
    } 
    if (this.p.getVisibility() != b)
      this.p.setVisibility(b); 
  }
  
  public e2 getItemData() {
    return this.b;
  }
  
  public void initialize(e2 parame2, int paramInt) {
    this.b = parame2;
    if (parame2.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(parame2.e);
    setCheckable(parame2.isCheckable());
    boolean bool = parame2.n();
    parame2.e();
    c(bool);
    setIcon(parame2.getIcon());
    setEnabled(parame2.isEnabled());
    setSubMenuArrowVisible(parame2.hasSubMenu());
    setContentDescription(parame2.q);
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    Drawable drawable = this.t;
    AtomicInteger atomicInteger = fe.a;
    fe.d.q((View)this, drawable);
    TextView textView = (TextView)findViewById(x.title);
    this.f = textView;
    int i = this.u;
    if (i != -1)
      textView.setTextAppearance(this.v, i); 
    this.p = (TextView)findViewById(x.shortcut);
    ImageView imageView = (ImageView)findViewById(x.submenuarrow);
    this.q = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.x); 
    this.r = (ImageView)findViewById(x.group_divider);
    this.s = (LinearLayout)findViewById(x.content);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.c != null && this.w) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.c.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.d == null && this.g == null)
      return; 
    if (this.b.h()) {
      if (this.d == null)
        b(); 
      RadioButton radioButton1 = this.d;
      CheckBox checkBox1 = this.g;
    } else {
      if (this.g == null)
        a(); 
      checkBox = this.g;
      radioButton = this.d;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.b.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.g;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.d;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.b.h()) {
      if (this.d == null)
        b(); 
      RadioButton radioButton = this.d;
    } else {
      if (this.g == null)
        a(); 
      checkBox = this.g;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.A = paramBoolean;
    this.w = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.r;
    if (imageView != null) {
      byte b;
      if (!this.y && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.b.n.getOptionalIconsVisible() || this.A) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.w)
      return; 
    ImageView imageView = this.c;
    if (imageView == null && paramDrawable == null && !this.w)
      return; 
    if (imageView == null) {
      imageView = (ImageView)getInflater().inflate(y.abc_list_menu_item_icon, (ViewGroup)this, false);
      this.c = imageView;
      LinearLayout linearLayout = this.s;
      if (linearLayout != null) {
        linearLayout.addView((View)imageView, 0);
      } else {
        addView((View)imageView, 0);
      } 
    } 
    if (paramDrawable != null || this.w) {
      imageView = this.c;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.c.getVisibility() != 0)
        this.c.setVisibility(0); 
      return;
    } 
    this.c.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.f.setText(paramCharSequence);
      if (this.f.getVisibility() != 0) {
        this.f.setVisibility(0);
        return;
      } 
    } else if (this.f.getVisibility() != 8) {
      this.f.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */