package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import b0;
import c2;
import e2;
import g2;
import j2;
import l2;
import s2;
import x3;

public class ActionMenuItemView extends AppCompatTextView implements j2.a, View.OnClickListener, ActionMenuView.a {
  public e2 b;
  
  public CharSequence c;
  
  public Drawable d;
  
  public c2.b f;
  
  public x3 g;
  
  public b p;
  
  public boolean q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    Resources resources = paramContext.getResources();
    this.q = d();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, b0.ActionMenuItemView, 0, 0);
    this.s = typedArray.getDimensionPixelSize(b0.ActionMenuItemView_android_minWidth, 0);
    typedArray.recycle();
    this.u = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.t = -1;
    setSaveEnabled(false);
  }
  
  public boolean a() {
    return c();
  }
  
  public boolean b() {
    return (c() && this.b.getIcon() == null);
  }
  
  public boolean c() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public final boolean d() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  public final void e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield d : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 66
    //   19: aload_0
    //   20: getfield b : Le2;
    //   23: getfield y : I
    //   26: iconst_4
    //   27: iand
    //   28: iconst_4
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 64
    //   43: iload_2
    //   44: istore_1
    //   45: aload_0
    //   46: getfield q : Z
    //   49: ifne -> 66
    //   52: aload_0
    //   53: getfield r : Z
    //   56: ifeq -> 64
    //   59: iload_2
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_3
    //   67: iconst_1
    //   68: ixor
    //   69: iload_1
    //   70: iand
    //   71: istore_1
    //   72: aconst_null
    //   73: astore #5
    //   75: iload_1
    //   76: ifeq -> 88
    //   79: aload_0
    //   80: getfield c : Ljava/lang/CharSequence;
    //   83: astore #4
    //   85: goto -> 91
    //   88: aconst_null
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   97: aload_0
    //   98: getfield b : Le2;
    //   101: getfield q : Ljava/lang/CharSequence;
    //   104: astore #4
    //   106: aload #4
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifeq -> 142
    //   114: iload_1
    //   115: ifeq -> 124
    //   118: aconst_null
    //   119: astore #4
    //   121: goto -> 133
    //   124: aload_0
    //   125: getfield b : Le2;
    //   128: getfield e : Ljava/lang/CharSequence;
    //   131: astore #4
    //   133: aload_0
    //   134: aload #4
    //   136: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   139: goto -> 148
    //   142: aload_0
    //   143: aload #4
    //   145: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   148: aload_0
    //   149: getfield b : Le2;
    //   152: getfield r : Ljava/lang/CharSequence;
    //   155: astore #4
    //   157: aload #4
    //   159: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   162: ifeq -> 192
    //   165: iload_1
    //   166: ifeq -> 176
    //   169: aload #5
    //   171: astore #4
    //   173: goto -> 185
    //   176: aload_0
    //   177: getfield b : Le2;
    //   180: getfield e : Ljava/lang/CharSequence;
    //   183: astore #4
    //   185: aload_0
    //   186: aload #4
    //   188: invokestatic P0 : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   191: return
    //   192: aload_0
    //   193: aload #4
    //   195: invokestatic P0 : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   198: return
  }
  
  public e2 getItemData() {
    return this.b;
  }
  
  public void initialize(e2 parame2, int paramInt) {
    this.b = parame2;
    setIcon(parame2.getIcon());
    setTitle(parame2.getTitleCondensed());
    setId(parame2.a);
    if (parame2.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(parame2.isEnabled());
    if (parame2.hasSubMenu() && this.g == null)
      this.g = new a(this); 
  }
  
  public void onClick(View paramView) {
    c2.b b1 = this.f;
    if (b1 != null)
      b1.a(this.b); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.q = d();
    e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = c();
    if (bool) {
      int k = this.t;
      if (k >= 0)
        super.setPadding(k, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.s);
    } else {
      paramInt1 = this.s;
    } 
    if (i != 1073741824 && this.s > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.d != null)
      super.setPadding((getMeasuredWidth() - this.d.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.b.hasSubMenu()) {
      x3 x31 = this.g;
      if (x31 != null && x31.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.r != paramBoolean) {
      this.r = paramBoolean;
      e2 e21 = this.b;
      if (e21 != null)
        e21.n.onItemActionRequestChanged(e21); 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.d = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.u;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    e();
  }
  
  public void setItemInvoker(c2.b paramb) {
    this.f = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.t = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.p = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.c = paramCharSequence;
    e();
  }
  
  public class a extends x3 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public l2 b() {
      ActionMenuItemView.b b = this.t.p;
      g2 g22 = null;
      g2 g21 = g22;
      if (b != null) {
        s2.a a1 = ((s2.b)b).a.F;
        g21 = g22;
        if (a1 != null)
          g21 = a1.a(); 
      } 
      return (l2)g21;
    }
    
    public boolean c() {
      ActionMenuItemView actionMenuItemView = this.t;
      c2.b b = actionMenuItemView.f;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.b)) {
          l2 l2 = b();
          bool1 = bool2;
          if (l2 != null) {
            bool1 = bool2;
            if (l2.a())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */