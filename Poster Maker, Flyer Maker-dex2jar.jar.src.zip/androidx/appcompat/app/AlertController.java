package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import b0;
import java.lang.ref.WeakReference;
import s;
import w0;

public class AlertController {
  public NestedScrollView A;
  
  public int B = 0;
  
  public Drawable C;
  
  public ImageView D;
  
  public TextView E;
  
  public TextView F;
  
  public View G;
  
  public ListAdapter H;
  
  public int I = -1;
  
  public int J;
  
  public int K;
  
  public int L;
  
  public int M;
  
  public int N;
  
  public int O;
  
  public boolean P;
  
  public Handler Q;
  
  public final View.OnClickListener R = new a(this);
  
  public final Context a;
  
  public final w0 b;
  
  public final Window c;
  
  public final int d;
  
  public CharSequence e;
  
  public CharSequence f;
  
  public ListView g;
  
  public View h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public boolean n = false;
  
  public Button o;
  
  public CharSequence p;
  
  public Message q;
  
  public Drawable r;
  
  public Button s;
  
  public CharSequence t;
  
  public Message u;
  
  public Drawable v;
  
  public Button w;
  
  public CharSequence x;
  
  public Message y;
  
  public Drawable z;
  
  public AlertController(Context paramContext, w0 paramw0, Window paramWindow) {
    this.a = paramContext;
    this.b = paramw0;
    this.c = paramWindow;
    this.Q = new c((DialogInterface)paramw0);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, b0.AlertDialog, s.alertDialogStyle, 0);
    this.J = typedArray.getResourceId(b0.AlertDialog_android_layout, 0);
    this.K = typedArray.getResourceId(b0.AlertDialog_buttonPanelSideLayout, 0);
    this.L = typedArray.getResourceId(b0.AlertDialog_listLayout, 0);
    this.M = typedArray.getResourceId(b0.AlertDialog_multiChoiceItemLayout, 0);
    this.N = typedArray.getResourceId(b0.AlertDialog_singleChoiceItemLayout, 0);
    this.O = typedArray.getResourceId(b0.AlertDialog_listItemLayout, 0);
    this.P = typedArray.getBoolean(b0.AlertDialog_showTitle, true);
    this.d = typedArray.getDimensionPixelSize(b0.AlertDialog_buttonIconDimen, 0);
    typedArray.recycle();
    paramw0.supportRequestWindowFeature(1);
  }
  
  public static boolean a(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      int j = i - 1;
      i = j;
      if (a(viewGroup.getChildAt(j)))
        return true; 
    } 
    return false;
  }
  
  public static void c(View paramView1, View paramView2, View paramView3) {
    byte b = 4;
    if (paramView2 != null) {
      byte b1;
      if (paramView1.canScrollVertically(-1)) {
        b1 = 0;
      } else {
        b1 = 4;
      } 
      paramView2.setVisibility(b1);
    } 
    if (paramView3 != null) {
      byte b1 = b;
      if (paramView1.canScrollVertically(1))
        b1 = 0; 
      paramView3.setVisibility(b1);
    } 
  }
  
  public final void b(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  public final ViewGroup d(View paramView1, View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  public void e(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable) {
    if (paramOnClickListener != null) {
      Message message = this.Q.obtainMessage(paramInt, paramOnClickListener);
    } else {
      paramOnClickListener = null;
    } 
    if (paramInt != -3) {
      if (paramInt != -2) {
        if (paramInt == -1) {
          this.p = paramCharSequence;
          this.q = (Message)paramOnClickListener;
          this.r = paramDrawable;
          return;
        } 
        throw new IllegalArgumentException("Button does not exist");
      } 
      this.t = paramCharSequence;
      this.u = (Message)paramOnClickListener;
      this.v = paramDrawable;
      return;
    } 
    this.x = paramCharSequence;
    this.y = (Message)paramOnClickListener;
    this.z = paramDrawable;
  }
  
  public void f(int paramInt) {
    this.C = null;
    this.B = paramInt;
    ImageView imageView = this.D;
    if (imageView != null) {
      if (paramInt != 0) {
        imageView.setVisibility(0);
        this.D.setImageResource(this.B);
        return;
      } 
      imageView.setVisibility(8);
    } 
  }
  
  public static class RecycleListView extends ListView {
    public final int b;
    
    public final int c;
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, b0.RecycleListView);
      this.c = typedArray.getDimensionPixelOffset(b0.RecycleListView_paddingBottomNoButtons, -1);
      this.b = typedArray.getDimensionPixelOffset(b0.RecycleListView_paddingTopNoTitle, -1);
    }
  }
  
  public class a implements View.OnClickListener {
    public a(AlertController this$0) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Landroidx/appcompat/app/AlertController;
      //   4: astore_2
      //   5: aload_1
      //   6: aload_2
      //   7: getfield o : Landroid/widget/Button;
      //   10: if_acmpne -> 30
      //   13: aload_2
      //   14: getfield q : Landroid/os/Message;
      //   17: astore_3
      //   18: aload_3
      //   19: ifnull -> 30
      //   22: aload_3
      //   23: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   26: astore_1
      //   27: goto -> 82
      //   30: aload_1
      //   31: aload_2
      //   32: getfield s : Landroid/widget/Button;
      //   35: if_acmpne -> 55
      //   38: aload_2
      //   39: getfield u : Landroid/os/Message;
      //   42: astore_3
      //   43: aload_3
      //   44: ifnull -> 55
      //   47: aload_3
      //   48: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   51: astore_1
      //   52: goto -> 82
      //   55: aload_1
      //   56: aload_2
      //   57: getfield w : Landroid/widget/Button;
      //   60: if_acmpne -> 80
      //   63: aload_2
      //   64: getfield y : Landroid/os/Message;
      //   67: astore_1
      //   68: aload_1
      //   69: ifnull -> 80
      //   72: aload_1
      //   73: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   76: astore_1
      //   77: goto -> 82
      //   80: aconst_null
      //   81: astore_1
      //   82: aload_1
      //   83: ifnull -> 90
      //   86: aload_1
      //   87: invokevirtual sendToTarget : ()V
      //   90: aload_0
      //   91: getfield b : Landroidx/appcompat/app/AlertController;
      //   94: astore_1
      //   95: aload_1
      //   96: getfield Q : Landroid/os/Handler;
      //   99: iconst_1
      //   100: aload_1
      //   101: getfield b : Lw0;
      //   104: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
      //   107: invokevirtual sendToTarget : ()V
      //   110: return
    }
  }
  
  public static class b {
    public int A;
    
    public int B;
    
    public int C;
    
    public boolean D = false;
    
    public boolean[] E;
    
    public boolean F;
    
    public boolean G;
    
    public int H = -1;
    
    public DialogInterface.OnMultiChoiceClickListener I;
    
    public Cursor J;
    
    public String K;
    
    public String L;
    
    public AdapterView.OnItemSelectedListener M;
    
    public final Context a;
    
    public final LayoutInflater b;
    
    public int c = 0;
    
    public Drawable d;
    
    public CharSequence e;
    
    public View f;
    
    public CharSequence g;
    
    public CharSequence h;
    
    public Drawable i;
    
    public DialogInterface.OnClickListener j;
    
    public CharSequence k;
    
    public Drawable l;
    
    public DialogInterface.OnClickListener m;
    
    public CharSequence n;
    
    public Drawable o;
    
    public DialogInterface.OnClickListener p;
    
    public boolean q;
    
    public DialogInterface.OnCancelListener r;
    
    public DialogInterface.OnDismissListener s;
    
    public DialogInterface.OnKeyListener t;
    
    public CharSequence[] u;
    
    public ListAdapter v;
    
    public DialogInterface.OnClickListener w;
    
    public int x;
    
    public View y;
    
    public int z;
    
    public b(Context param1Context) {
      this.a = param1Context;
      this.q = true;
      this.b = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
  }
  
  public static final class c extends Handler {
    public WeakReference<DialogInterface> a;
    
    public c(DialogInterface param1DialogInterface) {
      this.a = new WeakReference<DialogInterface>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != -3 && i != -2 && i != -1) {
        if (i != 1)
          return; 
        ((DialogInterface)param1Message.obj).dismiss();
        return;
      } 
      ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.a.get(), param1Message.what);
    }
  }
  
  public static class d extends ArrayAdapter<CharSequence> {
    public d(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public boolean hasStableIds() {
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */