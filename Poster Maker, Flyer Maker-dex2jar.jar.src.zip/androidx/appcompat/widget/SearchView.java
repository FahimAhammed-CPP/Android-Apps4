package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import b0;
import fe;
import g4;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;
import kf;
import m4;
import nf;
import p1;
import s;
import s30;
import s4;
import t2;
import v;
import x;
import y;
import z;

public class SearchView extends LinearLayoutCompat implements p1 {
  public static final n b;
  
  public final Drawable A;
  
  public final int B;
  
  public final int C;
  
  public final Intent D;
  
  public final Intent E;
  
  public final CharSequence F;
  
  public l G;
  
  public k H;
  
  public View.OnFocusChangeListener I;
  
  public m J;
  
  public View.OnClickListener K;
  
  public boolean L;
  
  public boolean M;
  
  public kf N;
  
  public boolean O;
  
  public CharSequence P;
  
  public boolean Q;
  
  public boolean R;
  
  public int S;
  
  public boolean T;
  
  public CharSequence U;
  
  public CharSequence V;
  
  public boolean W;
  
  public int a0;
  
  public SearchableInfo b0;
  
  public final SearchAutoComplete c;
  
  public Bundle c0;
  
  public final View d;
  
  public final Runnable d0 = new b(this);
  
  public Runnable e0 = new c(this);
  
  public final View f;
  
  public final WeakHashMap<String, Drawable.ConstantState> f0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  public final View g;
  
  public final View.OnClickListener g0;
  
  public View.OnKeyListener h0;
  
  public final TextView.OnEditorActionListener i0;
  
  public final AdapterView.OnItemClickListener j0;
  
  public final AdapterView.OnItemSelectedListener k0;
  
  public TextWatcher l0;
  
  public final ImageView p;
  
  public final ImageView q;
  
  public final ImageView r;
  
  public final ImageView s;
  
  public final View t;
  
  public p u;
  
  public Rect v = new Rect();
  
  public Rect w = new Rect();
  
  public int[] x = new int[2];
  
  public int[] y = new int[2];
  
  public final ImageView z;
  
  static {
    n n1;
    if (Build.VERSION.SDK_INT < 29) {
      n1 = new n();
    } else {
      n1 = null;
    } 
    b = n1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, s.searchViewStyle);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f f = new f(this);
    this.g0 = f;
    this.h0 = new g(this);
    h h = new h(this);
    this.i0 = h;
    i i = new i(this);
    this.j0 = i;
    j j = new j(this);
    this.k0 = j;
    this.l0 = new a(this);
    int[] arrayOfInt = b0.SearchView;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt, 0);
    m4 m4 = new m4(paramContext, typedArray);
    fe.B((View)this, paramContext, arrayOfInt, paramAttributeSet, typedArray, paramInt, 0);
    LayoutInflater.from(paramContext).inflate(m4.m(b0.SearchView_layout, y.abc_search_view), this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(x.search_src_text);
    this.c = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.d = findViewById(x.search_edit_frame);
    View view2 = findViewById(x.search_plate);
    this.f = view2;
    View view3 = findViewById(x.submit_area);
    this.g = view3;
    ImageView imageView1 = (ImageView)findViewById(x.search_button);
    this.p = imageView1;
    ImageView imageView2 = (ImageView)findViewById(x.search_go_btn);
    this.q = imageView2;
    ImageView imageView3 = (ImageView)findViewById(x.search_close_btn);
    this.r = imageView3;
    ImageView imageView4 = (ImageView)findViewById(x.search_voice_btn);
    this.s = imageView4;
    ImageView imageView5 = (ImageView)findViewById(x.search_mag_icon);
    this.z = imageView5;
    fe.d.q(view2, m4.g(b0.SearchView_queryBackground));
    fe.d.q(view3, m4.g(b0.SearchView_submitBackground));
    paramInt = b0.SearchView_searchIcon;
    imageView1.setImageDrawable(m4.g(paramInt));
    imageView2.setImageDrawable(m4.g(b0.SearchView_goIcon));
    imageView3.setImageDrawable(m4.g(b0.SearchView_closeIcon));
    imageView4.setImageDrawable(m4.g(b0.SearchView_voiceIcon));
    imageView5.setImageDrawable(m4.g(paramInt));
    this.A = m4.g(b0.SearchView_searchHintIcon);
    ComponentActivity.c.P0((View)imageView1, getResources().getString(z.abc_searchview_description_search));
    this.B = m4.m(b0.SearchView_suggestionRowLayout, y.abc_search_dropdown_item_icons_2line);
    this.C = m4.m(b0.SearchView_commitIcon, 0);
    imageView1.setOnClickListener(f);
    imageView3.setOnClickListener(f);
    imageView2.setOnClickListener(f);
    imageView4.setOnClickListener(f);
    searchAutoComplete.setOnClickListener(f);
    searchAutoComplete.addTextChangedListener(this.l0);
    searchAutoComplete.setOnEditorActionListener(h);
    searchAutoComplete.setOnItemClickListener(i);
    searchAutoComplete.setOnItemSelectedListener(j);
    searchAutoComplete.setOnKeyListener(this.h0);
    searchAutoComplete.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(m4.a(b0.SearchView_iconifiedByDefault, true));
    paramInt = m4.f(b0.SearchView_android_maxWidth, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.F = m4.o(b0.SearchView_defaultQueryHint);
    this.P = m4.o(b0.SearchView_queryHint);
    paramInt = m4.j(b0.SearchView_android_imeOptions, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = m4.j(b0.SearchView_android_inputType, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(m4.a(b0.SearchView_android_focusable, true));
    typedArray.recycle();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.D = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.E = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.t = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener(new e(this)); 
    t(this.L);
    q();
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(v.abc_search_view_preferred_height);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(v.abc_search_view_preferred_width);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.c.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.c;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  public void b() {
    if (this.W)
      return; 
    this.W = true;
    int i = this.c.getImeOptions();
    this.a0 = i;
    this.c.setImeOptions(i | 0x2000000);
    this.c.setText("");
    setIconified(false);
  }
  
  public void c() {
    this.c.setText("");
    SearchAutoComplete searchAutoComplete = this.c;
    searchAutoComplete.setSelection(searchAutoComplete.length());
    this.V = "";
    clearFocus();
    t(true);
    this.c.setImeOptions(this.a0);
    this.W = false;
  }
  
  public void clearFocus() {
    this.R = true;
    super.clearFocus();
    this.c.clearFocus();
    this.c.setImeVisibility(false);
    this.R = false;
  }
  
  public final Intent d(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.V);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.c0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.b0.getSearchActivity());
    return intent;
  }
  
  public final Intent e(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1107296256);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.c0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int j = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (j != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  public void f() {
    if (Build.VERSION.SDK_INT >= 29) {
      this.c.refreshAutoCompleteResults();
      return;
    } 
    n n2 = b;
    SearchAutoComplete searchAutoComplete = this.c;
    Objects.requireNonNull(n2);
    n.a();
    Method method2 = n2.a;
    if (method2 != null)
      try {
        method2.invoke(searchAutoComplete, new Object[0]);
      } catch (Exception exception) {} 
    n n1 = b;
    searchAutoComplete = this.c;
    Objects.requireNonNull(n1);
    n.a();
    Method method1 = n1.b;
    if (method1 != null)
      try {
        method1.invoke(searchAutoComplete, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public void g(int paramInt, String paramString1, String paramString2) {
    Intent intent = d("android.intent.action.SEARCH", null, null, paramString2, paramInt, null);
    getContext().startActivity(intent);
  }
  
  public int getImeOptions() {
    return this.c.getImeOptions();
  }
  
  public int getInputType() {
    return this.c.getInputType();
  }
  
  public int getMaxWidth() {
    return this.S;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.c.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.P;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.b0;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.b0.getHintId()) : this.F;
  }
  
  public int getSuggestionCommitIconResId() {
    return this.C;
  }
  
  public int getSuggestionRowLayout() {
    return this.B;
  }
  
  public kf getSuggestionsAdapter() {
    return this.N;
  }
  
  public void h() {
    if (TextUtils.isEmpty((CharSequence)this.c.getText())) {
      if (this.L) {
        k k1 = this.H;
        if (k1 == null || !k1.a()) {
          clearFocus();
          t(true);
          return;
        } 
      } 
    } else {
      this.c.setText("");
      this.c.requestFocus();
      this.c.setImeVisibility(true);
    } 
  }
  
  public boolean i(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield J : Landroidx/appcompat/widget/SearchView$m;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 24
    //   9: aload_2
    //   10: iload_1
    //   11: invokeinterface b : (I)Z
    //   16: ifne -> 22
    //   19: goto -> 24
    //   22: iconst_0
    //   23: ireturn
    //   24: aload_0
    //   25: getfield N : Lkf;
    //   28: getfield d : Landroid/database/Cursor;
    //   31: astore #6
    //   33: aload #6
    //   35: ifnull -> 311
    //   38: aload #6
    //   40: iload_1
    //   41: invokeinterface moveToPosition : (I)Z
    //   46: ifeq -> 311
    //   49: aconst_null
    //   50: astore #5
    //   52: getstatic g4.v : I
    //   55: istore_1
    //   56: aload #6
    //   58: aload #6
    //   60: ldc_w 'suggest_intent_action'
    //   63: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   68: invokestatic h : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   71: astore_3
    //   72: aload_3
    //   73: astore_2
    //   74: aload_3
    //   75: ifnonnull -> 343
    //   78: aload_0
    //   79: getfield b0 : Landroid/app/SearchableInfo;
    //   82: invokevirtual getSuggestIntentAction : ()Ljava/lang/String;
    //   85: astore_2
    //   86: goto -> 343
    //   89: aload #6
    //   91: aload #6
    //   93: ldc_w 'suggest_intent_data'
    //   96: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   101: invokestatic h : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   104: astore #4
    //   106: aload #4
    //   108: astore_2
    //   109: aload #4
    //   111: ifnonnull -> 122
    //   114: aload_0
    //   115: getfield b0 : Landroid/app/SearchableInfo;
    //   118: invokevirtual getSuggestIntentData : ()Ljava/lang/String;
    //   121: astore_2
    //   122: aload_2
    //   123: astore #4
    //   125: aload_2
    //   126: ifnull -> 356
    //   129: aload #6
    //   131: aload #6
    //   133: ldc_w 'suggest_intent_data_id'
    //   136: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   141: invokestatic h : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   144: astore #7
    //   146: aload_2
    //   147: astore #4
    //   149: aload #7
    //   151: ifnull -> 356
    //   154: new java/lang/StringBuilder
    //   157: dup
    //   158: invokespecial <init> : ()V
    //   161: astore #4
    //   163: aload #4
    //   165: aload_2
    //   166: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: pop
    //   170: aload #4
    //   172: ldc_w '/'
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: aload #4
    //   181: aload #7
    //   183: invokestatic encode : (Ljava/lang/String;)Ljava/lang/String;
    //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: pop
    //   190: aload #4
    //   192: invokevirtual toString : ()Ljava/lang/String;
    //   195: astore #4
    //   197: goto -> 356
    //   200: aload #4
    //   202: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   205: astore_2
    //   206: aload #6
    //   208: aload #6
    //   210: ldc_w 'suggest_intent_query'
    //   213: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   218: invokestatic h : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   221: astore #4
    //   223: aload_0
    //   224: aload_3
    //   225: aload_2
    //   226: aload #6
    //   228: aload #6
    //   230: ldc_w 'suggest_intent_extra_data'
    //   233: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   238: invokestatic h : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   241: aload #4
    //   243: iconst_0
    //   244: aconst_null
    //   245: invokevirtual d : (Ljava/lang/String;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/content/Intent;
    //   248: astore_2
    //   249: goto -> 266
    //   252: aload #6
    //   254: invokeinterface getPosition : ()I
    //   259: pop
    //   260: aload #5
    //   262: astore_2
    //   263: goto -> 266
    //   266: aload_2
    //   267: ifnonnull -> 273
    //   270: goto -> 311
    //   273: aload_0
    //   274: invokevirtual getContext : ()Landroid/content/Context;
    //   277: aload_2
    //   278: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   281: goto -> 311
    //   284: new java/lang/StringBuilder
    //   287: dup
    //   288: invokespecial <init> : ()V
    //   291: astore_3
    //   292: aload_3
    //   293: ldc_w 'Failed launch activity: '
    //   296: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   299: pop
    //   300: aload_3
    //   301: aload_2
    //   302: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   305: pop
    //   306: aload_3
    //   307: invokevirtual toString : ()Ljava/lang/String;
    //   310: pop
    //   311: aload_0
    //   312: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   315: iconst_0
    //   316: invokevirtual setImeVisibility : (Z)V
    //   319: aload_0
    //   320: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   323: invokevirtual dismissDropDown : ()V
    //   326: iconst_1
    //   327: ireturn
    //   328: astore_2
    //   329: goto -> 252
    //   332: astore_2
    //   333: aload #5
    //   335: astore_2
    //   336: goto -> 266
    //   339: astore_3
    //   340: goto -> 284
    //   343: aload_2
    //   344: astore_3
    //   345: aload_2
    //   346: ifnonnull -> 89
    //   349: ldc_w 'android.intent.action.SEARCH'
    //   352: astore_3
    //   353: goto -> 89
    //   356: aload #4
    //   358: ifnonnull -> 200
    //   361: aconst_null
    //   362: astore_2
    //   363: goto -> 206
    // Exception table:
    //   from	to	target	type
    //   52	72	328	java/lang/RuntimeException
    //   78	86	328	java/lang/RuntimeException
    //   89	106	328	java/lang/RuntimeException
    //   114	122	328	java/lang/RuntimeException
    //   129	146	328	java/lang/RuntimeException
    //   154	197	328	java/lang/RuntimeException
    //   200	206	328	java/lang/RuntimeException
    //   206	249	328	java/lang/RuntimeException
    //   252	260	332	java/lang/RuntimeException
    //   273	281	339	java/lang/RuntimeException
  }
  
  public boolean j(int paramInt) {
    m m1 = this.J;
    if (m1 == null || !m1.a(paramInt)) {
      Editable editable = this.c.getText();
      Cursor cursor = this.N.d;
      if (cursor != null)
        if (cursor.moveToPosition(paramInt)) {
          CharSequence charSequence = this.N.c(cursor);
          if (charSequence != null) {
            setQuery(charSequence);
          } else {
            setQuery((CharSequence)editable);
          } 
        } else {
          setQuery((CharSequence)editable);
        }  
      return true;
    } 
    return false;
  }
  
  public void k(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public void l() {
    t(false);
    this.c.requestFocus();
    this.c.setImeVisibility(true);
    View.OnClickListener onClickListener = this.K;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  public void m() {
    Editable editable = this.c.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      l l1 = this.G;
      if (l1 == null || !l1.onQueryTextSubmit(editable.toString())) {
        if (this.b0 != null)
          g(0, null, editable.toString()); 
        this.c.setImeVisibility(false);
        this.c.dismissDropDown();
      } 
    } 
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    if (this.b0 == null)
      return false; 
    if (this.N == null)
      return false; 
    if (paramKeyEvent.getAction() == 0 && paramKeyEvent.hasNoModifiers()) {
      if (paramInt == 66 || paramInt == 84 || paramInt == 61)
        return i(this.c.getListSelection()); 
      if (paramInt == 21 || paramInt == 22) {
        if (paramInt == 21) {
          paramInt = 0;
        } else {
          paramInt = this.c.length();
        } 
        this.c.setSelection(paramInt);
        this.c.setListSelection(0);
        this.c.clearListSelection();
        this.c.a();
        return true;
      } 
      if (paramInt == 19 && this.c.getListSelection() == 0)
        return false; 
    } 
    return false;
  }
  
  public final void o() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.c.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.L && !this.W) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.r;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.r.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  public void onDetachedFromWindow() {
    removeCallbacks(this.d0);
    post(this.e0);
    super.onDetachedFromWindow();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      SearchAutoComplete searchAutoComplete = this.c;
      Rect rect2 = this.v;
      searchAutoComplete.getLocationInWindow(this.x);
      getLocationInWindow(this.y);
      int[] arrayOfInt1 = this.x;
      paramInt1 = arrayOfInt1[1];
      int[] arrayOfInt2 = this.y;
      paramInt1 -= arrayOfInt2[1];
      paramInt3 = arrayOfInt1[0] - arrayOfInt2[0];
      rect2.set(paramInt3, paramInt1, searchAutoComplete.getWidth() + paramInt3, searchAutoComplete.getHeight() + paramInt1);
      Rect rect1 = this.w;
      rect2 = this.v;
      rect1.set(rect2.left, 0, rect2.right, paramInt4 - paramInt2);
      p p2 = this.u;
      if (p2 == null) {
        p2 = new p(this.w, this.v, (View)this.c);
        this.u = p2;
        setTouchDelegate(p2);
        return;
      } 
      p2.a(this.w, this.v);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.M) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.S;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.S;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.S;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.getSuperState());
    t(o.b);
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.b = this.M;
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    post(this.d0);
  }
  
  public void p() {
    int[] arrayOfInt;
    if (this.c.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.f.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.g.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public final void q() {
    SpannableStringBuilder spannableStringBuilder;
    CharSequence charSequence2 = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.c;
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    charSequence2 = charSequence1;
    if (this.L)
      if (this.A == null) {
        charSequence2 = charSequence1;
      } else {
        double d = searchAutoComplete.getTextSize();
        Double.isNaN(d);
        Double.isNaN(d);
        int i = (int)(d * 1.25D);
        this.A.setBounds(0, 0, i, i);
        spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.A), 1, 2, 33);
        spannableStringBuilder.append(charSequence1);
      }  
    searchAutoComplete.setHint((CharSequence)spannableStringBuilder);
  }
  
  public final void r() {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield T : Z
    //   15: ifeq -> 30
    //   18: aload_0
    //   19: getfield M : Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 63
    //   36: iload_2
    //   37: istore_1
    //   38: aload_0
    //   39: getfield q : Landroid/widget/ImageView;
    //   42: invokevirtual getVisibility : ()I
    //   45: ifeq -> 66
    //   48: aload_0
    //   49: getfield s : Landroid/widget/ImageView;
    //   52: invokevirtual getVisibility : ()I
    //   55: ifne -> 63
    //   58: iload_2
    //   59: istore_1
    //   60: goto -> 66
    //   63: bipush #8
    //   65: istore_1
    //   66: aload_0
    //   67: getfield g : Landroid/view/View;
    //   70: iload_1
    //   71: invokevirtual setVisibility : (I)V
    //   74: return
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.R)
      return false; 
    if (!isFocusable())
      return false; 
    if (!this.M) {
      boolean bool = this.c.requestFocus(paramInt, paramRect);
      if (bool)
        t(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public final void s(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iload #4
    //   10: ifeq -> 68
    //   13: iload #4
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield T : Z
    //   22: ifeq -> 37
    //   25: aload_0
    //   26: getfield M : Z
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: ifeq -> 68
    //   43: aload_0
    //   44: invokevirtual hasFocus : ()Z
    //   47: ifeq -> 68
    //   50: iload_3
    //   51: istore_2
    //   52: iload_1
    //   53: ifne -> 71
    //   56: aload_0
    //   57: getfield T : Z
    //   60: ifne -> 68
    //   63: iload_3
    //   64: istore_2
    //   65: goto -> 71
    //   68: bipush #8
    //   70: istore_2
    //   71: aload_0
    //   72: getfield q : Landroid/widget/ImageView;
    //   75: iload_2
    //   76: invokevirtual setVisibility : (I)V
    //   79: return
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.c0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      h();
      return;
    } 
    l();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.L == paramBoolean)
      return; 
    this.L = paramBoolean;
    t(paramBoolean);
    q();
  }
  
  public void setImeOptions(int paramInt) {
    this.c.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.c.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.S = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(k paramk) {
    this.H = paramk;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.I = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(l paraml) {
    this.G = paraml;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.K = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(m paramm) {
    this.J = paramm;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.P = paramCharSequence;
    q();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.Q = paramBoolean;
    kf kf1 = this.N;
    if (kf1 instanceof g4) {
      boolean bool;
      g4 g4 = (g4)kf1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      g4.B = bool;
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield b0 : Landroid/app/SearchableInfo;
    //   5: iconst_1
    //   6: istore #4
    //   8: aconst_null
    //   9: astore #5
    //   11: aload_1
    //   12: ifnull -> 183
    //   15: aload_0
    //   16: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   19: aload_1
    //   20: invokevirtual getSuggestThreshold : ()I
    //   23: invokevirtual setThreshold : (I)V
    //   26: aload_0
    //   27: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   30: aload_0
    //   31: getfield b0 : Landroid/app/SearchableInfo;
    //   34: invokevirtual getImeOptions : ()I
    //   37: invokevirtual setImeOptions : (I)V
    //   40: aload_0
    //   41: getfield b0 : Landroid/app/SearchableInfo;
    //   44: invokevirtual getInputType : ()I
    //   47: istore_3
    //   48: iload_3
    //   49: istore_2
    //   50: iload_3
    //   51: bipush #15
    //   53: iand
    //   54: iconst_1
    //   55: if_icmpne -> 86
    //   58: iload_3
    //   59: ldc_w -65537
    //   62: iand
    //   63: istore_3
    //   64: iload_3
    //   65: istore_2
    //   66: aload_0
    //   67: getfield b0 : Landroid/app/SearchableInfo;
    //   70: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   73: ifnull -> 86
    //   76: iload_3
    //   77: ldc_w 65536
    //   80: ior
    //   81: ldc_w 524288
    //   84: ior
    //   85: istore_2
    //   86: aload_0
    //   87: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   90: iload_2
    //   91: invokevirtual setInputType : (I)V
    //   94: aload_0
    //   95: getfield N : Lkf;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_1
    //   104: aconst_null
    //   105: invokevirtual b : (Landroid/database/Cursor;)V
    //   108: aload_0
    //   109: getfield b0 : Landroid/app/SearchableInfo;
    //   112: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   115: ifnull -> 179
    //   118: new g4
    //   121: dup
    //   122: aload_0
    //   123: invokevirtual getContext : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_0
    //   128: getfield b0 : Landroid/app/SearchableInfo;
    //   131: aload_0
    //   132: getfield f0 : Ljava/util/WeakHashMap;
    //   135: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V
    //   138: astore_1
    //   139: aload_0
    //   140: aload_1
    //   141: putfield N : Lkf;
    //   144: aload_0
    //   145: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   148: aload_1
    //   149: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   152: aload_0
    //   153: getfield N : Lkf;
    //   156: checkcast g4
    //   159: astore_1
    //   160: aload_0
    //   161: getfield Q : Z
    //   164: ifeq -> 172
    //   167: iconst_2
    //   168: istore_2
    //   169: goto -> 174
    //   172: iconst_1
    //   173: istore_2
    //   174: aload_1
    //   175: iload_2
    //   176: putfield B : I
    //   179: aload_0
    //   180: invokevirtual q : ()V
    //   183: aload_0
    //   184: getfield b0 : Landroid/app/SearchableInfo;
    //   187: astore_1
    //   188: aload_1
    //   189: ifnull -> 259
    //   192: aload_1
    //   193: invokevirtual getVoiceSearchEnabled : ()Z
    //   196: ifeq -> 259
    //   199: aload_0
    //   200: getfield b0 : Landroid/app/SearchableInfo;
    //   203: invokevirtual getVoiceSearchLaunchWebSearch : ()Z
    //   206: ifeq -> 217
    //   209: aload_0
    //   210: getfield D : Landroid/content/Intent;
    //   213: astore_1
    //   214: goto -> 235
    //   217: aload #5
    //   219: astore_1
    //   220: aload_0
    //   221: getfield b0 : Landroid/app/SearchableInfo;
    //   224: invokevirtual getVoiceSearchLaunchRecognizer : ()Z
    //   227: ifeq -> 235
    //   230: aload_0
    //   231: getfield E : Landroid/content/Intent;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnull -> 259
    //   239: aload_0
    //   240: invokevirtual getContext : ()Landroid/content/Context;
    //   243: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   246: aload_1
    //   247: ldc_w 65536
    //   250: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   253: ifnull -> 259
    //   256: goto -> 262
    //   259: iconst_0
    //   260: istore #4
    //   262: aload_0
    //   263: iload #4
    //   265: putfield T : Z
    //   268: iload #4
    //   270: ifeq -> 283
    //   273: aload_0
    //   274: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   277: ldc_w 'nm'
    //   280: invokevirtual setPrivateImeOptions : (Ljava/lang/String;)V
    //   283: aload_0
    //   284: aload_0
    //   285: getfield M : Z
    //   288: invokevirtual t : (Z)V
    //   291: return
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.O = paramBoolean;
    t(this.M);
  }
  
  public void setSuggestionsAdapter(kf paramkf) {
    this.N = paramkf;
    this.c.setAdapter((ListAdapter)paramkf);
  }
  
  public final void t(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield M : Z
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_1
    //   8: ifeq -> 16
    //   11: iconst_0
    //   12: istore_2
    //   13: goto -> 19
    //   16: bipush #8
    //   18: istore_2
    //   19: aload_0
    //   20: getfield c : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   23: invokevirtual getText : ()Landroid/text/Editable;
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: iconst_1
    //   30: ixor
    //   31: istore #4
    //   33: aload_0
    //   34: getfield p : Landroid/widget/ImageView;
    //   37: iload_2
    //   38: invokevirtual setVisibility : (I)V
    //   41: aload_0
    //   42: iload #4
    //   44: invokevirtual s : (Z)V
    //   47: aload_0
    //   48: getfield d : Landroid/view/View;
    //   51: astore #5
    //   53: iload_1
    //   54: ifeq -> 63
    //   57: bipush #8
    //   59: istore_2
    //   60: goto -> 65
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #5
    //   67: iload_2
    //   68: invokevirtual setVisibility : (I)V
    //   71: aload_0
    //   72: getfield z : Landroid/widget/ImageView;
    //   75: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
    //   78: ifnull -> 90
    //   81: iload_3
    //   82: istore_2
    //   83: aload_0
    //   84: getfield L : Z
    //   87: ifeq -> 93
    //   90: bipush #8
    //   92: istore_2
    //   93: aload_0
    //   94: getfield z : Landroid/widget/ImageView;
    //   97: iload_2
    //   98: invokevirtual setVisibility : (I)V
    //   101: aload_0
    //   102: invokevirtual o : ()V
    //   105: aload_0
    //   106: iload #4
    //   108: iconst_1
    //   109: ixor
    //   110: invokevirtual u : (Z)V
    //   113: aload_0
    //   114: invokevirtual r : ()V
    //   117: return
  }
  
  public final void u(boolean paramBoolean) {
    boolean bool = this.T;
    byte b2 = 8;
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (!this.M) {
        b1 = b2;
        if (paramBoolean) {
          this.q.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.s.setVisibility(b1);
  }
  
  public static class SearchAutoComplete extends t2 {
    public int b = getThreshold();
    
    public SearchView c;
    
    public boolean d;
    
    public final Runnable f = new a(this);
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet, s.autoCompleteTextViewStyle);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    public void a() {
      if (Build.VERSION.SDK_INT >= 29) {
        setInputMethodMode(1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        SearchView.n n = SearchView.b;
        Objects.requireNonNull(n);
        SearchView.n.a();
        Method method = n.c;
        if (method != null)
          try {
            method.invoke(this, new Object[] { Boolean.TRUE });
            return;
          } catch (Exception exception) {
            return;
          }  
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.b <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.d) {
        removeCallbacks(this.f);
        post(this.f);
      } 
      return inputConnection;
    }
    
    public void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    public void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      SearchView searchView = this.c;
      searchView.t(searchView.M);
      searchView.post(searchView.d0);
      if (searchView.c.hasFocus())
        searchView.f(); 
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.c.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.c.hasFocus() && getVisibility() == 0) {
        boolean bool = true;
        this.d = true;
        Context context = getContext();
        SearchView.n n = SearchView.b;
        if ((context.getResources().getConfiguration()).orientation != 2)
          bool = false; 
        if (bool)
          a(); 
      } 
    }
    
    public void performCompletion() {}
    
    public void replaceText(CharSequence param1CharSequence) {}
    
    public void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.d = false;
        removeCallbacks(this.f);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.d = false;
        removeCallbacks(this.f);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.d = true;
    }
    
    public void setSearchView(SearchView param1SearchView) {
      this.c = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.b = param1Int;
    }
    
    public class a implements Runnable {
      public a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        SearchView.SearchAutoComplete searchAutoComplete = this.b;
        if (searchAutoComplete.d) {
          ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
          searchAutoComplete.d = false;
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(SearchView this$0) {}
    
    public void run() {
      SearchView.SearchAutoComplete searchAutoComplete = this.b;
      if (searchAutoComplete.d) {
        ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
        searchAutoComplete.d = false;
      } 
    }
  }
  
  public class a implements TextWatcher {
    public a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      SearchView searchView = this.b;
      Editable editable = searchView.c.getText();
      searchView.V = (CharSequence)editable;
      int i = TextUtils.isEmpty((CharSequence)editable) ^ true;
      searchView.s(i);
      searchView.u(i ^ 0x1);
      searchView.o();
      searchView.r();
      if (searchView.G != null && !TextUtils.equals(param1CharSequence, searchView.U))
        searchView.G.onQueryTextChange(param1CharSequence.toString()); 
      searchView.U = param1CharSequence.toString();
    }
  }
  
  public class b implements Runnable {
    public b(SearchView this$0) {}
    
    public void run() {
      this.b.p();
    }
  }
  
  public class c implements Runnable {
    public c(SearchView this$0) {}
    
    public void run() {
      kf kf = this.b.N;
      if (kf instanceof g4)
        kf.b(null); 
    }
  }
  
  public class d implements View.OnFocusChangeListener {
    public d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.a;
      View.OnFocusChangeListener onFocusChangeListener = searchView.I;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  public class e implements View.OnLayoutChangeListener {
    public e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      SearchView searchView = this.b;
      if (searchView.t.getWidth() > 1) {
        Resources resources = searchView.getContext().getResources();
        param1Int3 = searchView.f.getPaddingLeft();
        Rect rect = new Rect();
        boolean bool = s4.a((View)searchView);
        if (searchView.L) {
          param1Int1 = resources.getDimensionPixelSize(v.abc_dropdownitem_icon_width);
          param1Int1 = resources.getDimensionPixelSize(v.abc_dropdownitem_text_padding_left) + param1Int1;
        } else {
          param1Int1 = 0;
        } 
        searchView.c.getDropDownBackground().getPadding(rect);
        if (bool) {
          param1Int2 = -rect.left;
        } else {
          param1Int2 = param1Int3 - rect.left + param1Int1;
        } 
        searchView.c.setDropDownHorizontalOffset(param1Int2);
        param1Int2 = searchView.t.getWidth();
        param1Int4 = rect.left;
        param1Int5 = rect.right;
        searchView.c.setDropDownWidth(param1Int2 + param1Int4 + param1Int5 + param1Int1 - param1Int3);
      } 
    }
  }
  
  public class f implements View.OnClickListener {
    public f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.b;
      if (param1View == searchView.p) {
        searchView.l();
        return;
      } 
      if (param1View == searchView.r) {
        searchView.h();
        return;
      } 
      if (param1View == searchView.q) {
        searchView.m();
        return;
      } 
      if (param1View == searchView.s) {
        SearchableInfo searchableInfo = searchView.b0;
        if (searchableInfo == null)
          return; 
        try {
          String str;
          if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
            Intent intent = new Intent(searchView.D);
            ComponentName componentName = searchableInfo.getSearchActivity();
            if (componentName == null) {
              componentName = null;
            } else {
              str = componentName.flattenToShortString();
            } 
            intent.putExtra("calling_package", str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          if (str.getVoiceSearchLaunchRecognizer()) {
            Intent intent = searchView.e(searchView.E, (SearchableInfo)str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          return;
        } 
      } 
      if (activityNotFoundException == searchView.c)
        searchView.f(); 
    }
  }
  
  public class g implements View.OnKeyListener {
    public g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      boolean bool;
      SearchView searchView = this.b;
      if (searchView.b0 == null)
        return false; 
      if (searchView.c.isPopupShowing() && this.b.c.getListSelection() != -1)
        return this.b.n(param1Int, param1KeyEvent); 
      if (TextUtils.getTrimmedLength((CharSequence)this.b.c.getText()) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        param1View.cancelLongPress();
        SearchView searchView1 = this.b;
        searchView1.g(0, null, searchView1.c.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  public class h implements TextView.OnEditorActionListener {
    public h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.b.m();
      return true;
    }
  }
  
  public class i implements AdapterView.OnItemClickListener {
    public i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.i(param1Int);
    }
  }
  
  public class j implements AdapterView.OnItemSelectedListener {
    public j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.j(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public static interface k {
    boolean a();
  }
  
  public static interface l {
    boolean onQueryTextChange(String param1String);
    
    boolean onQueryTextSubmit(String param1String);
  }
  
  public static interface m {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  public static class n {
    public Method a = null;
    
    public Method b = null;
    
    public Method c = null;
    
    @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
    public n() {
      a();
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a = method;
        method.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b = method;
        method.setAccessible(true);
        try {
          method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException) {}
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException1) {}
      } 
    }
    
    public static void a() {
      if (Build.VERSION.SDK_INT < 29)
        return; 
      throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
    }
  }
  
  public static class o extends nf {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new a();
    
    public boolean b;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.b = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    public o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = s30.x0("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.b);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.b));
    }
    
    public class a implements Parcelable.ClassLoaderCreator<o> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new SearchView.o(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SearchView.o(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new SearchView.o[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<o> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new SearchView.o(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SearchView.o(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new SearchView.o[param1Int];
    }
  }
  
  public static class p extends TouchDelegate {
    public final View a;
    
    public final Rect b;
    
    public final Rect c;
    
    public final Rect d;
    
    public final int e;
    
    public boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getX : ()F
      //   4: f2i
      //   5: istore_3
      //   6: aload_1
      //   7: invokevirtual getY : ()F
      //   10: f2i
      //   11: istore #4
      //   13: aload_1
      //   14: invokevirtual getAction : ()I
      //   17: istore_2
      //   18: iconst_1
      //   19: istore #5
      //   21: iconst_0
      //   22: istore #7
      //   24: iload_2
      //   25: ifeq -> 106
      //   28: iload_2
      //   29: iconst_1
      //   30: if_icmpeq -> 60
      //   33: iload_2
      //   34: iconst_2
      //   35: if_icmpeq -> 60
      //   38: iload_2
      //   39: iconst_3
      //   40: if_icmpeq -> 46
      //   43: goto -> 127
      //   46: aload_0
      //   47: getfield f : Z
      //   50: istore #5
      //   52: aload_0
      //   53: iconst_0
      //   54: putfield f : Z
      //   57: goto -> 101
      //   60: aload_0
      //   61: getfield f : Z
      //   64: istore #6
      //   66: iload #6
      //   68: istore #5
      //   70: iload #6
      //   72: ifeq -> 101
      //   75: iload #6
      //   77: istore #5
      //   79: aload_0
      //   80: getfield d : Landroid/graphics/Rect;
      //   83: iload_3
      //   84: iload #4
      //   86: invokevirtual contains : (II)Z
      //   89: ifne -> 101
      //   92: iload #6
      //   94: istore #5
      //   96: iconst_0
      //   97: istore_2
      //   98: goto -> 132
      //   101: iconst_1
      //   102: istore_2
      //   103: goto -> 132
      //   106: aload_0
      //   107: getfield b : Landroid/graphics/Rect;
      //   110: iload_3
      //   111: iload #4
      //   113: invokevirtual contains : (II)Z
      //   116: ifeq -> 127
      //   119: aload_0
      //   120: iconst_1
      //   121: putfield f : Z
      //   124: goto -> 101
      //   127: iconst_1
      //   128: istore_2
      //   129: iconst_0
      //   130: istore #5
      //   132: iload #7
      //   134: istore #6
      //   136: iload #5
      //   138: ifeq -> 222
      //   141: iload_2
      //   142: ifeq -> 185
      //   145: aload_0
      //   146: getfield c : Landroid/graphics/Rect;
      //   149: iload_3
      //   150: iload #4
      //   152: invokevirtual contains : (II)Z
      //   155: ifne -> 185
      //   158: aload_1
      //   159: aload_0
      //   160: getfield a : Landroid/view/View;
      //   163: invokevirtual getWidth : ()I
      //   166: iconst_2
      //   167: idiv
      //   168: i2f
      //   169: aload_0
      //   170: getfield a : Landroid/view/View;
      //   173: invokevirtual getHeight : ()I
      //   176: iconst_2
      //   177: idiv
      //   178: i2f
      //   179: invokevirtual setLocation : (FF)V
      //   182: goto -> 212
      //   185: aload_0
      //   186: getfield c : Landroid/graphics/Rect;
      //   189: astore #8
      //   191: aload_1
      //   192: iload_3
      //   193: aload #8
      //   195: getfield left : I
      //   198: isub
      //   199: i2f
      //   200: iload #4
      //   202: aload #8
      //   204: getfield top : I
      //   207: isub
      //   208: i2f
      //   209: invokevirtual setLocation : (FF)V
      //   212: aload_0
      //   213: getfield a : Landroid/view/View;
      //   216: aload_1
      //   217: invokevirtual dispatchTouchEvent : (Landroid/view/MotionEvent;)Z
      //   220: istore #6
      //   222: iload #6
      //   224: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */