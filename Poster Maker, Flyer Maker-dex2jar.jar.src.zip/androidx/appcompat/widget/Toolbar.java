package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import b0;
import c0;
import c2;
import d3;
import e2;
import e4;
import fe;
import i2;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import m4;
import n2;
import nd;
import nf;
import o4;
import od;
import p1;
import p2;
import qj;
import s;
import s2;
import s4;
import t1;
import t3;
import vj;

public class Toolbar extends ViewGroup {
  private static final String TAG = "Toolbar";
  
  private i2.a mActionMenuPresenterCallback;
  
  public int mButtonGravity;
  
  public ImageButton mCollapseButtonView;
  
  private CharSequence mCollapseDescription;
  
  private Drawable mCollapseIcon;
  
  private boolean mCollapsible;
  
  private int mContentInsetEndWithActions;
  
  private int mContentInsetStartWithNavigation;
  
  private e4 mContentInsets;
  
  private boolean mEatingHover;
  
  private boolean mEatingTouch;
  
  public View mExpandedActionView;
  
  private d mExpandedMenuPresenter;
  
  private int mGravity = 8388627;
  
  private final ArrayList<View> mHiddenViews = new ArrayList<View>();
  
  private ImageView mLogoView;
  
  private int mMaxButtonHeight;
  
  private c2.a mMenuBuilderCallback;
  
  public final nd mMenuHostHelper = new nd((Runnable)new p2(this));
  
  private ActionMenuView mMenuView;
  
  private final ActionMenuView.e mMenuViewItemClickListener = new a(this);
  
  private ImageButton mNavButtonView;
  
  public f mOnMenuItemClickListener;
  
  private s2 mOuterActionMenuPresenter;
  
  private Context mPopupContext;
  
  private int mPopupTheme;
  
  private ArrayList<MenuItem> mProvidedMenuItems = new ArrayList<MenuItem>();
  
  private final Runnable mShowOverflowMenuRunnable = new b(this);
  
  private CharSequence mSubtitleText;
  
  private int mSubtitleTextAppearance;
  
  private ColorStateList mSubtitleTextColor;
  
  private TextView mSubtitleTextView;
  
  private final int[] mTempMargins = new int[2];
  
  private final ArrayList<View> mTempViews = new ArrayList<View>();
  
  private int mTitleMarginBottom;
  
  private int mTitleMarginEnd;
  
  private int mTitleMarginStart;
  
  private int mTitleMarginTop;
  
  private CharSequence mTitleText;
  
  private int mTitleTextAppearance;
  
  private ColorStateList mTitleTextColor;
  
  private TextView mTitleTextView;
  
  private o4 mWrapper;
  
  public Toolbar(Context paramContext) {
    this(paramContext, null);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, s.toolbarStyle);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = b0.Toolbar;
    m4 m4 = m4.r(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    fe.B((View)this, paramContext, arrayOfInt, paramAttributeSet, m4.b, paramInt, 0);
    this.mTitleTextAppearance = m4.m(b0.Toolbar_titleTextAppearance, 0);
    this.mSubtitleTextAppearance = m4.m(b0.Toolbar_subtitleTextAppearance, 0);
    this.mGravity = m4.k(b0.Toolbar_android_gravity, this.mGravity);
    this.mButtonGravity = m4.k(b0.Toolbar_buttonGravity, 48);
    int i = m4.e(b0.Toolbar_titleMargin, 0);
    int j = b0.Toolbar_titleMargins;
    paramInt = i;
    if (m4.p(j))
      paramInt = m4.e(j, i); 
    this.mTitleMarginBottom = paramInt;
    this.mTitleMarginTop = paramInt;
    this.mTitleMarginEnd = paramInt;
    this.mTitleMarginStart = paramInt;
    paramInt = m4.e(b0.Toolbar_titleMarginStart, -1);
    if (paramInt >= 0)
      this.mTitleMarginStart = paramInt; 
    paramInt = m4.e(b0.Toolbar_titleMarginEnd, -1);
    if (paramInt >= 0)
      this.mTitleMarginEnd = paramInt; 
    paramInt = m4.e(b0.Toolbar_titleMarginTop, -1);
    if (paramInt >= 0)
      this.mTitleMarginTop = paramInt; 
    paramInt = m4.e(b0.Toolbar_titleMarginBottom, -1);
    if (paramInt >= 0)
      this.mTitleMarginBottom = paramInt; 
    this.mMaxButtonHeight = m4.f(b0.Toolbar_maxButtonHeight, -1);
    paramInt = m4.e(b0.Toolbar_contentInsetStart, -2147483648);
    i = m4.e(b0.Toolbar_contentInsetEnd, -2147483648);
    j = m4.f(b0.Toolbar_contentInsetLeft, 0);
    int k = m4.f(b0.Toolbar_contentInsetRight, 0);
    ensureContentInsets();
    e4 e41 = this.mContentInsets;
    e41.h = false;
    if (j != Integer.MIN_VALUE) {
      e41.e = j;
      e41.a = j;
    } 
    if (k != Integer.MIN_VALUE) {
      e41.f = k;
      e41.b = k;
    } 
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      e41.a(paramInt, i); 
    this.mContentInsetStartWithNavigation = m4.e(b0.Toolbar_contentInsetStartWithNavigation, -2147483648);
    this.mContentInsetEndWithActions = m4.e(b0.Toolbar_contentInsetEndWithActions, -2147483648);
    this.mCollapseIcon = m4.g(b0.Toolbar_collapseIcon);
    this.mCollapseDescription = m4.o(b0.Toolbar_collapseContentDescription);
    CharSequence charSequence3 = m4.o(b0.Toolbar_title);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = m4.o(b0.Toolbar_subtitle);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.mPopupContext = getContext();
    setPopupTheme(m4.m(b0.Toolbar_popupTheme, 0));
    Drawable drawable2 = m4.g(b0.Toolbar_navigationIcon);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = m4.o(b0.Toolbar_navigationContentDescription);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = m4.g(b0.Toolbar_logo);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = m4.o(b0.Toolbar_logoDescription);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = b0.Toolbar_titleTextColor;
    if (m4.p(paramInt))
      setTitleTextColor(m4.c(paramInt)); 
    paramInt = b0.Toolbar_subtitleTextColor;
    if (m4.p(paramInt))
      setSubtitleTextColor(m4.c(paramInt)); 
    paramInt = b0.Toolbar_menu;
    if (m4.p(paramInt))
      inflateMenu(m4.m(paramInt, 0)); 
    m4.b.recycle();
  }
  
  private void addCustomViewsWithGravity(List<View> paramList, int paramInt) {
    AtomicInteger atomicInteger = fe.a;
    int i = fe.e.d((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = Gravity.getAbsoluteGravity(paramInt, fe.e.d((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && shouldLayout(view) && getChildHorizontalGravity(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && shouldLayout(view) && getChildHorizontalGravity(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void addSystemView(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = generateDefaultLayoutParams();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = generateLayoutParams((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.mExpandedActionView != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.mHiddenViews.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private void ensureContentInsets() {
    if (this.mContentInsets == null)
      this.mContentInsets = new e4(); 
  }
  
  private void ensureLogoView() {
    if (this.mLogoView == null)
      this.mLogoView = new AppCompatImageView(getContext()); 
  }
  
  private void ensureMenu() {
    ensureMenuView();
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView.b == null) {
      c2 c2 = (c2)actionMenuView.getMenu();
      if (this.mExpandedMenuPresenter == null)
        this.mExpandedMenuPresenter = new d(this); 
      this.mMenuView.setExpandedActionViewsExclusive(true);
      c2.addMenuPresenter(this.mExpandedMenuPresenter, this.mPopupContext);
    } 
  }
  
  private void ensureMenuView() {
    if (this.mMenuView == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
      this.mMenuView = actionMenuView;
      actionMenuView.setPopupTheme(this.mPopupTheme);
      this.mMenuView.setOnMenuItemClickListener(this.mMenuViewItemClickListener);
      actionMenuView = this.mMenuView;
      i2.a a1 = this.mActionMenuPresenterCallback;
      c2.a a2 = this.mMenuBuilderCallback;
      actionMenuView.p = a1;
      actionMenuView.q = a2;
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800005 | this.mButtonGravity & 0x70;
      this.mMenuView.setLayoutParams((ViewGroup.LayoutParams)e1);
      addSystemView((View)this.mMenuView, false);
    } 
  }
  
  private void ensureNavButtonView() {
    if (this.mNavButtonView == null) {
      this.mNavButtonView = (ImageButton)new d3(getContext(), null, s.toolbarNavigationButtonStyle);
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800003 | this.mButtonGravity & 0x70;
      this.mNavButtonView.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int getChildHorizontalGravity(int paramInt) {
    AtomicInteger atomicInteger = fe.a;
    int i = fe.e.d((View)this);
    int j = Gravity.getAbsoluteGravity(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int getChildTop(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = getChildVerticalGravity(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int getChildVerticalGravity(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.mGravity & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private int getHorizontalMargins(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new t1(getContext());
  }
  
  private int getVerticalMargins(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int getViewListMeasuredWidth(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)e1).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)e1).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += view.getMeasuredWidth() + i1 + i2;
      i++;
    } 
    return j;
  }
  
  private boolean isChildOrHidden(View paramView) {
    return (paramView.getParent() == this || this.mHiddenViews.contains(paramView));
  }
  
  private int layoutChildLeft(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = getChildTop(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return i + ((ViewGroup.MarginLayoutParams)e1).rightMargin + paramInt1;
  }
  
  private int layoutChildRight(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = getChildTop(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int measureChildCollapseMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j);
    i = Math.max(0, k) + i;
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    j = getPaddingLeft();
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + j + i + paramInt2, marginLayoutParams.width);
    paramInt2 = getPaddingTop();
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  private void measureChildConstrained(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getPaddingLeft();
    i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt1 = getPaddingTop();
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt1 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void onCreateMenu() {
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.mMenuHostHelper.c(getMenu(), getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.mProvidedMenuItems = arrayList2;
  }
  
  private void postShowOverflowMenu() {
    removeCallbacks(this.mShowOverflowMenuRunnable);
    post(this.mShowOverflowMenuRunnable);
  }
  
  private boolean shouldCollapse() {
    if (!this.mCollapsible)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (shouldLayout(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean shouldLayout(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  public void addChildrenForExpandedActionView() {
    for (int i = this.mHiddenViews.size() - 1; i >= 0; i--)
      addView(this.mHiddenViews.get(i)); 
    this.mHiddenViews.clear();
  }
  
  public void addMenuProvider(od paramod) {
    nd nd1 = this.mMenuHostHelper;
    nd1.b.add(paramod);
    nd1.a.run();
  }
  
  public void addMenuProvider(od paramod, vj paramvj) {
    this.mMenuHostHelper.a(paramod, paramvj);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(od paramod, vj paramvj, qj.b paramb) {
    this.mMenuHostHelper.b(paramod, paramvj, paramb);
  }
  
  public boolean canShowOverflowMenu() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.mMenuView;
      if (actionMenuView != null && actionMenuView.f)
        return true; 
    } 
    return false;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public void collapseActionView() {
    e2 e2;
    d d1 = this.mExpandedMenuPresenter;
    if (d1 == null) {
      d1 = null;
    } else {
      e2 = d1.c;
    } 
    if (e2 != null)
      e2.collapseActionView(); 
  }
  
  public void dismissPopupMenus() {
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      s2 s21 = actionMenuView.g;
      if (s21 != null)
        s21.a(); 
    } 
  }
  
  public void ensureCollapseButtonView() {
    if (this.mCollapseButtonView == null) {
      d3 d3 = new d3(getContext(), null, s.toolbarNavigationButtonStyle);
      this.mCollapseButtonView = (ImageButton)d3;
      d3.setImageDrawable(this.mCollapseIcon);
      this.mCollapseButtonView.setContentDescription(this.mCollapseDescription);
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800003 | this.mButtonGravity & 0x70;
      e1.b = 2;
      this.mCollapseButtonView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.mCollapseButtonView.setOnClickListener(new c(this));
    } 
  }
  
  public e generateDefaultLayoutParams() {
    return new e(-2, -2);
  }
  
  public e generateLayoutParams(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  public e generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof c0.a) ? new e((c0.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.mCollapseButtonView;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.mCollapseButtonView;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    e4 e41 = this.mContentInsets;
    return (e41 != null) ? (e41.g ? e41.a : e41.b) : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.mContentInsetEndWithActions;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    e4 e41 = this.mContentInsets;
    return (e41 != null) ? e41.a : 0;
  }
  
  public int getContentInsetRight() {
    e4 e41 = this.mContentInsets;
    return (e41 != null) ? e41.b : 0;
  }
  
  public int getContentInsetStart() {
    e4 e41 = this.mContentInsets;
    return (e41 != null) ? (e41.g ? e41.b : e41.a) : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.mContentInsetStartWithNavigation;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMenuView : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: getfield b : Lc2;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield mContentInsetEndWithActions : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    AtomicInteger atomicInteger = fe.a;
    return (fe.e.d((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    AtomicInteger atomicInteger = fe.a;
    return (fe.e.d((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.mContentInsetStartWithNavigation, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.mLogoView;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.mLogoView;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    ensureMenu();
    return this.mMenuView.getMenu();
  }
  
  public View getNavButtonView() {
    return (View)this.mNavButtonView;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.mNavButtonView;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.mNavButtonView;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public s2 getOuterActionMenuPresenter() {
    return this.mOuterActionMenuPresenter;
  }
  
  public Drawable getOverflowIcon() {
    ensureMenu();
    return this.mMenuView.getOverflowIcon();
  }
  
  public Context getPopupContext() {
    return this.mPopupContext;
  }
  
  public int getPopupTheme() {
    return this.mPopupTheme;
  }
  
  public CharSequence getSubtitle() {
    return this.mSubtitleText;
  }
  
  public final TextView getSubtitleTextView() {
    return this.mSubtitleTextView;
  }
  
  public CharSequence getTitle() {
    return this.mTitleText;
  }
  
  public int getTitleMarginBottom() {
    return this.mTitleMarginBottom;
  }
  
  public int getTitleMarginEnd() {
    return this.mTitleMarginEnd;
  }
  
  public int getTitleMarginStart() {
    return this.mTitleMarginStart;
  }
  
  public int getTitleMarginTop() {
    return this.mTitleMarginTop;
  }
  
  public final TextView getTitleTextView() {
    return this.mTitleTextView;
  }
  
  public t3 getWrapper() {
    if (this.mWrapper == null)
      this.mWrapper = new o4(this, true); 
    return (t3)this.mWrapper;
  }
  
  public boolean hasExpandedActionView() {
    d d1 = this.mExpandedMenuPresenter;
    return (d1 != null && d1.c != null);
  }
  
  public boolean hideOverflowMenu() {
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      boolean bool;
      s2 s21 = actionMenuView.g;
      if (s21 != null && s21.c()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void inflateMenu(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void invalidateMenu() {
    for (MenuItem menuItem : this.mProvidedMenuItems)
      getMenu().removeItem(menuItem.getItemId()); 
    onCreateMenu();
  }
  
  public boolean isOverflowMenuShowPending() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMenuView : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 59
    //   9: aload_2
    //   10: getfield g : Ls2;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 51
    //   18: aload_2
    //   19: getfield G : Ls2$c;
    //   22: ifnonnull -> 40
    //   25: aload_2
    //   26: invokevirtual e : ()Z
    //   29: ifeq -> 35
    //   32: goto -> 40
    //   35: iconst_0
    //   36: istore_1
    //   37: goto -> 42
    //   40: iconst_1
    //   41: istore_1
    //   42: iload_1
    //   43: ifeq -> 51
    //   46: iconst_1
    //   47: istore_1
    //   48: goto -> 53
    //   51: iconst_0
    //   52: istore_1
    //   53: iload_1
    //   54: ifeq -> 59
    //   57: iconst_1
    //   58: ireturn
    //   59: iconst_0
    //   60: ireturn
  }
  
  public boolean isOverflowMenuShowing() {
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      boolean bool;
      s2 s21 = actionMenuView.g;
      if (s21 != null && s21.e()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public boolean isTitleTruncated() {
    TextView textView = this.mTitleTextView;
    if (textView == null)
      return false; 
    Layout layout = textView.getLayout();
    if (layout == null)
      return false; 
    int j = layout.getLineCount();
    for (int i = 0; i < j; i++) {
      if (layout.getEllipsisCount(i) > 0)
        return true; 
    } 
    return false;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.mShowOverflowMenuRunnable);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.mEatingHover = false; 
    if (!this.mEatingHover) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.mEatingHover = true; 
    } 
    if (i == 10 || i == 3)
      this.mEatingHover = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    AtomicInteger atomicInteger = fe.a;
    if (fe.e.d((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.mTempMargins;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = fe.d.d((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (shouldLayout((View)this.mNavButtonView)) {
      if (k) {
        j = layoutChildRight((View)this.mNavButtonView, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = layoutChildLeft((View)this.mNavButtonView, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (shouldLayout((View)this.mCollapseButtonView))
      if (k) {
        paramInt2 = layoutChildRight((View)this.mCollapseButtonView, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = layoutChildLeft((View)this.mCollapseButtonView, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (shouldLayout((View)this.mMenuView))
      if (k) {
        j = layoutChildLeft((View)this.mMenuView, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = layoutChildRight((View)this.mMenuView, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (shouldLayout(this.mExpandedActionView))
      if (k) {
        j = layoutChildRight(this.mExpandedActionView, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = layoutChildLeft(this.mExpandedActionView, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (shouldLayout((View)this.mLogoView))
      if (k) {
        paramInt2 = layoutChildRight((View)this.mLogoView, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = layoutChildLeft((View)this.mLogoView, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = shouldLayout((View)this.mTitleTextView);
    boolean bool = shouldLayout((View)this.mSubtitleTextView);
    if (paramBoolean) {
      e e1 = (e)this.mTitleTextView.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 = this.mTitleTextView.getMeasuredHeight() + paramInt1 + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.mSubtitleTextView.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 += this.mSubtitleTextView.getMeasuredHeight() + j + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.mTitleTextView;
      } else {
        textView1 = this.mSubtitleTextView;
      } 
      if (bool) {
        textView2 = this.mSubtitleTextView;
      } else {
        textView2 = this.mTitleTextView;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.mTitleTextView.getMeasuredWidth() > 0) || (bool && this.mSubtitleTextView.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.mGravity & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.mTitleMarginTop;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.mTitleMarginBottom;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.mTitleMarginBottom - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.mTitleMarginTop;
      } 
      if (k) {
        if (j != 0) {
          k = this.mTitleMarginStart;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.mTitleTextView.getLayoutParams();
          m = paramInt2 - this.mTitleTextView.getMeasuredWidth();
          k = this.mTitleTextView.getMeasuredHeight() + paramInt1;
          this.mTitleTextView.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.mTitleMarginEnd;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.mSubtitleTextView.getLayoutParams()).topMargin;
          m = this.mSubtitleTextView.getMeasuredWidth();
          i2 = this.mSubtitleTextView.getMeasuredHeight();
          this.mSubtitleTextView.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.mTitleMarginEnd;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.mTitleMarginStart;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 = Math.max(0, k) + paramInt3;
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.mTitleTextView.getLayoutParams();
          k = this.mTitleTextView.getMeasuredWidth() + paramInt3;
          m = this.mTitleTextView.getMeasuredHeight() + paramInt1;
          this.mTitleTextView.layout(paramInt3, paramInt1, k, m);
          k += this.mTitleMarginEnd;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.mSubtitleTextView.getLayoutParams()).topMargin;
          m = this.mSubtitleTextView.getMeasuredWidth() + paramInt3;
          i2 = this.mSubtitleTextView.getMeasuredHeight();
          this.mSubtitleTextView.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.mTitleMarginEnd;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        addCustomViewsWithGravity(this.mTempViews, 3);
        k = this.mTempViews.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    addCustomViewsWithGravity(this.mTempViews, 3);
    int k = this.mTempViews.size();
    paramInt2 = 0;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int[] arrayOfInt = this.mTempMargins;
    boolean bool1 = s4.a((View)this);
    boolean bool = false;
    if (bool1) {
      i1 = 1;
      n = 0;
    } else {
      i1 = 0;
      n = 1;
    } 
    if (shouldLayout((View)this.mNavButtonView)) {
      measureChildConstrained((View)this.mNavButtonView, paramInt1, 0, paramInt2, 0, this.mMaxButtonHeight);
      i = this.mNavButtonView.getMeasuredWidth() + getHorizontalMargins((View)this.mNavButtonView);
      m = Math.max(0, this.mNavButtonView.getMeasuredHeight() + getVerticalMargins((View)this.mNavButtonView));
      k = View.combineMeasuredStates(0, this.mNavButtonView.getMeasuredState());
    } else {
      i = 0;
      m = 0;
      k = 0;
    } 
    int i2 = i;
    int j = m;
    int i = k;
    if (shouldLayout((View)this.mCollapseButtonView)) {
      measureChildConstrained((View)this.mCollapseButtonView, paramInt1, 0, paramInt2, 0, this.mMaxButtonHeight);
      i2 = this.mCollapseButtonView.getMeasuredWidth() + getHorizontalMargins((View)this.mCollapseButtonView);
      j = Math.max(m, this.mCollapseButtonView.getMeasuredHeight() + getVerticalMargins((View)this.mCollapseButtonView));
      i = View.combineMeasuredStates(k, this.mCollapseButtonView.getMeasuredState());
    } 
    int k = getCurrentContentInsetStart();
    int m = Math.max(k, i2) + 0;
    arrayOfInt[i1] = Math.max(0, k - i2);
    if (shouldLayout((View)this.mMenuView)) {
      measureChildConstrained((View)this.mMenuView, paramInt1, m, paramInt2, 0, this.mMaxButtonHeight);
      k = this.mMenuView.getMeasuredWidth() + getHorizontalMargins((View)this.mMenuView);
      j = Math.max(j, this.mMenuView.getMeasuredHeight() + getVerticalMargins((View)this.mMenuView));
      i = View.combineMeasuredStates(i, this.mMenuView.getMeasuredState());
    } else {
      k = 0;
    } 
    int i1 = getCurrentContentInsetEnd();
    i2 = Math.max(i1, k) + m;
    arrayOfInt[n] = Math.max(0, i1 - k);
    i1 = i2;
    m = j;
    k = i;
    if (shouldLayout(this.mExpandedActionView)) {
      i1 = i2 + measureChildCollapseMargins(this.mExpandedActionView, paramInt1, i2, paramInt2, 0, arrayOfInt);
      m = Math.max(j, this.mExpandedActionView.getMeasuredHeight() + getVerticalMargins(this.mExpandedActionView));
      k = View.combineMeasuredStates(i, this.mExpandedActionView.getMeasuredState());
    } 
    j = i1;
    int n = m;
    i = k;
    if (shouldLayout((View)this.mLogoView)) {
      j = i1 + measureChildCollapseMargins((View)this.mLogoView, paramInt1, i1, paramInt2, 0, arrayOfInt);
      n = Math.max(m, this.mLogoView.getMeasuredHeight() + getVerticalMargins((View)this.mLogoView));
      i = View.combineMeasuredStates(k, this.mLogoView.getMeasuredState());
    } 
    int i3 = getChildCount();
    k = 0;
    m = j;
    while (k < i3) {
      View view = getChildAt(k);
      i2 = m;
      i1 = n;
      j = i;
      if (((e)view.getLayoutParams()).b == 0)
        if (!shouldLayout(view)) {
          i2 = m;
          i1 = n;
          j = i;
        } else {
          i2 = m + measureChildCollapseMargins(view, paramInt1, m, paramInt2, 0, arrayOfInt);
          i1 = Math.max(n, view.getMeasuredHeight() + getVerticalMargins(view));
          j = View.combineMeasuredStates(i, view.getMeasuredState());
        }  
      k++;
      m = i2;
      n = i1;
      i = j;
    } 
    i1 = this.mTitleMarginTop + this.mTitleMarginBottom;
    i2 = this.mTitleMarginStart + this.mTitleMarginEnd;
    if (shouldLayout((View)this.mTitleTextView)) {
      measureChildCollapseMargins((View)this.mTitleTextView, paramInt1, m + i2, paramInt2, i1, arrayOfInt);
      j = this.mTitleTextView.getMeasuredWidth();
      i3 = getHorizontalMargins((View)this.mTitleTextView);
      k = this.mTitleTextView.getMeasuredHeight();
      int i4 = getVerticalMargins((View)this.mTitleTextView);
      i = View.combineMeasuredStates(i, this.mTitleTextView.getMeasuredState());
      k += i4;
      j += i3;
    } else {
      j = 0;
      k = 0;
    } 
    if (shouldLayout((View)this.mSubtitleTextView)) {
      j = Math.max(j, measureChildCollapseMargins((View)this.mSubtitleTextView, paramInt1, m + i2, paramInt2, k + i1, arrayOfInt));
      k += this.mSubtitleTextView.getMeasuredHeight() + getVerticalMargins((View)this.mSubtitleTextView);
      i = View.combineMeasuredStates(i, this.mSubtitleTextView.getMeasuredState());
    } 
    k = Math.max(n, k);
    i2 = getPaddingLeft();
    i3 = getPaddingRight();
    n = getPaddingTop();
    i1 = getPaddingBottom();
    j = View.resolveSizeAndState(Math.max(i3 + i2 + m + j, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & i);
    paramInt1 = View.resolveSizeAndState(Math.max(i1 + n + k, getSuggestedMinimumHeight()), paramInt2, i << 16);
    if (shouldCollapse())
      paramInt1 = bool; 
    setMeasuredDimension(j, paramInt1);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.getSuperState());
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      c2 c2 = actionMenuView.b;
    } else {
      actionMenuView = null;
    } 
    int i = g.b;
    if (i != 0 && this.mExpandedMenuPresenter != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.c)
      postShowOverflowMenu(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    ensureContentInsets();
    e4 e41 = this.mContentInsets;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    if (bool == e41.g)
      return; 
    e41.g = bool;
    if (e41.h) {
      if (bool) {
        paramInt = e41.d;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = e41.e; 
        e41.a = paramInt;
        paramInt = e41.c;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = e41.f; 
        e41.b = paramInt;
        return;
      } 
      paramInt = e41.c;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = e41.e; 
      e41.a = paramInt;
      paramInt = e41.d;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = e41.f; 
      e41.b = paramInt;
      return;
    } 
    e41.a = e41.e;
    e41.b = e41.f;
  }
  
  public Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.mExpandedMenuPresenter;
    if (d1 != null) {
      e2 e2 = d1.c;
      if (e2 != null)
        g.b = e2.a; 
    } 
    g.c = isOverflowMenuShowing();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.mEatingTouch = false; 
    if (!this.mEatingTouch) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.mEatingTouch = true; 
    } 
    if (i == 1 || i == 3)
      this.mEatingTouch = false; 
    return true;
  }
  
  public void removeChildrenForExpandedActionView() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.mMenuView) {
        removeViewAt(i);
        this.mHiddenViews.add(view);
      } 
    } 
  }
  
  public void removeMenuProvider(od paramod) {
    this.mMenuHostHelper.e(paramod);
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      ensureCollapseButtonView(); 
    ImageButton imageButton = this.mCollapseButtonView;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(ComponentActivity.c.N(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      ensureCollapseButtonView();
      this.mCollapseButtonView.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.mCollapseButtonView;
    if (imageButton != null)
      imageButton.setImageDrawable(this.mCollapseIcon); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.mCollapsible = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.mContentInsetEndWithActions) {
      this.mContentInsetEndWithActions = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.mContentInsetStartWithNavigation) {
      this.mContentInsetStartWithNavigation = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetsAbsolute(int paramInt1, int paramInt2) {
    ensureContentInsets();
    e4 e41 = this.mContentInsets;
    e41.h = false;
    if (paramInt1 != Integer.MIN_VALUE) {
      e41.e = paramInt1;
      e41.a = paramInt1;
    } 
    if (paramInt2 != Integer.MIN_VALUE) {
      e41.f = paramInt2;
      e41.b = paramInt2;
    } 
  }
  
  public void setContentInsetsRelative(int paramInt1, int paramInt2) {
    ensureContentInsets();
    this.mContentInsets.a(paramInt1, paramInt2);
  }
  
  public void setLogo(int paramInt) {
    setLogo(ComponentActivity.c.N(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      ensureLogoView();
      if (!isChildOrHidden((View)this.mLogoView))
        addSystemView((View)this.mLogoView, true); 
    } else {
      ImageView imageView1 = this.mLogoView;
      if (imageView1 != null && isChildOrHidden((View)imageView1)) {
        removeView((View)this.mLogoView);
        this.mHiddenViews.remove(this.mLogoView);
      } 
    } 
    ImageView imageView = this.mLogoView;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      ensureLogoView(); 
    ImageView imageView = this.mLogoView;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setMenu(c2 paramc2, s2 params2) {
    if (paramc2 == null && this.mMenuView == null)
      return; 
    ensureMenuView();
    c2 c21 = this.mMenuView.b;
    if (c21 == paramc2)
      return; 
    if (c21 != null) {
      c21.removeMenuPresenter((i2)this.mOuterActionMenuPresenter);
      c21.removeMenuPresenter(this.mExpandedMenuPresenter);
    } 
    if (this.mExpandedMenuPresenter == null)
      this.mExpandedMenuPresenter = new d(this); 
    params2.B = true;
    if (paramc2 != null) {
      paramc2.addMenuPresenter((i2)params2, this.mPopupContext);
      paramc2.addMenuPresenter(this.mExpandedMenuPresenter, this.mPopupContext);
    } else {
      params2.initForMenu(this.mPopupContext, null);
      d d1 = this.mExpandedMenuPresenter;
      c21 = d1.b;
      if (c21 != null) {
        e2 e2 = d1.c;
        if (e2 != null)
          c21.collapseItemActionView(e2); 
      } 
      d1.b = null;
      params2.updateMenuView(true);
      this.mExpandedMenuPresenter.updateMenuView(true);
    } 
    this.mMenuView.setPopupTheme(this.mPopupTheme);
    this.mMenuView.setPresenter(params2);
    this.mOuterActionMenuPresenter = params2;
  }
  
  public void setMenuCallbacks(i2.a parama, c2.a parama1) {
    this.mActionMenuPresenterCallback = parama;
    this.mMenuBuilderCallback = parama1;
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      actionMenuView.p = parama;
      actionMenuView.q = parama1;
    } 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      ensureNavButtonView(); 
    ImageButton imageButton = this.mNavButtonView;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      ComponentActivity.c.P0((View)this.mNavButtonView, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(ComponentActivity.c.N(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      ensureNavButtonView();
      if (!isChildOrHidden((View)this.mNavButtonView))
        addSystemView((View)this.mNavButtonView, true); 
    } else {
      ImageButton imageButton1 = this.mNavButtonView;
      if (imageButton1 != null && isChildOrHidden((View)imageButton1)) {
        removeView((View)this.mNavButtonView);
        this.mHiddenViews.remove(this.mNavButtonView);
      } 
    } 
    ImageButton imageButton = this.mNavButtonView;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    ensureNavButtonView();
    this.mNavButtonView.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.mOnMenuItemClickListener = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    ensureMenu();
    this.mMenuView.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.mPopupTheme != paramInt) {
      this.mPopupTheme = paramInt;
      if (paramInt == 0) {
        this.mPopupContext = getContext();
        return;
      } 
      this.mPopupContext = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.mSubtitleTextView == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.mSubtitleTextView = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.mSubtitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.mSubtitleTextAppearance;
        if (i != 0)
          this.mSubtitleTextView.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.mSubtitleTextColor;
        if (colorStateList != null)
          this.mSubtitleTextView.setTextColor(colorStateList); 
      } 
      if (!isChildOrHidden((View)this.mSubtitleTextView))
        addSystemView((View)this.mSubtitleTextView, true); 
    } else {
      TextView textView1 = this.mSubtitleTextView;
      if (textView1 != null && isChildOrHidden((View)textView1)) {
        removeView((View)this.mSubtitleTextView);
        this.mHiddenViews.remove(this.mSubtitleTextView);
      } 
    } 
    TextView textView = this.mSubtitleTextView;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.mSubtitleText = paramCharSequence;
  }
  
  public void setSubtitleTextAppearance(Context paramContext, int paramInt) {
    this.mSubtitleTextAppearance = paramInt;
    TextView textView = this.mSubtitleTextView;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.mSubtitleTextColor = paramColorStateList;
    TextView textView = this.mSubtitleTextView;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.mTitleTextView == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.mTitleTextView = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.mTitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.mTitleTextAppearance;
        if (i != 0)
          this.mTitleTextView.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.mTitleTextColor;
        if (colorStateList != null)
          this.mTitleTextView.setTextColor(colorStateList); 
      } 
      if (!isChildOrHidden((View)this.mTitleTextView))
        addSystemView((View)this.mTitleTextView, true); 
    } else {
      TextView textView1 = this.mTitleTextView;
      if (textView1 != null && isChildOrHidden((View)textView1)) {
        removeView((View)this.mTitleTextView);
        this.mHiddenViews.remove(this.mTitleTextView);
      } 
    } 
    TextView textView = this.mTitleTextView;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.mTitleText = paramCharSequence;
  }
  
  public void setTitleMargin(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mTitleMarginStart = paramInt1;
    this.mTitleMarginTop = paramInt2;
    this.mTitleMarginEnd = paramInt3;
    this.mTitleMarginBottom = paramInt4;
    requestLayout();
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.mTitleMarginBottom = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.mTitleMarginEnd = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.mTitleMarginStart = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.mTitleMarginTop = paramInt;
    requestLayout();
  }
  
  public void setTitleTextAppearance(Context paramContext, int paramInt) {
    this.mTitleTextAppearance = paramInt;
    TextView textView = this.mTitleTextView;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.mTitleTextColor = paramColorStateList;
    TextView textView = this.mTitleTextView;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean showOverflowMenu() {
    ActionMenuView actionMenuView = this.mMenuView;
    if (actionMenuView != null) {
      boolean bool;
      s2 s21 = actionMenuView.g;
      if (s21 != null && s21.f()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public class a implements ActionMenuView.e {
    public a(Toolbar this$0) {}
  }
  
  public class b implements Runnable {
    public b(Toolbar this$0) {}
    
    public void run() {
      this.b.showOverflowMenu();
    }
  }
  
  public class c implements View.OnClickListener {
    public c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.b.collapseActionView();
    }
  }
  
  public class d implements i2 {
    public c2 b;
    
    public e2 c;
    
    public d(Toolbar this$0) {}
    
    public boolean collapseItemActionView(c2 param1c2, e2 param1e2) {
      View view = this.d.mExpandedActionView;
      if (view instanceof p1)
        ((p1)view).c(); 
      Toolbar toolbar = this.d;
      toolbar.removeView(toolbar.mExpandedActionView);
      toolbar = this.d;
      toolbar.removeView((View)toolbar.mCollapseButtonView);
      toolbar = this.d;
      toolbar.mExpandedActionView = null;
      toolbar.addChildrenForExpandedActionView();
      this.c = null;
      this.d.requestLayout();
      param1e2.C = false;
      param1e2.n.onItemsChanged(false);
      return true;
    }
    
    public boolean expandItemActionView(c2 param1c2, e2 param1e2) {
      this.d.ensureCollapseButtonView();
      ViewParent viewParent = this.d.mCollapseButtonView.getParent();
      Toolbar toolbar = this.d;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.mCollapseButtonView); 
        Toolbar toolbar1 = this.d;
        toolbar1.addView((View)toolbar1.mCollapseButtonView);
      } 
      this.d.mExpandedActionView = param1e2.getActionView();
      this.c = param1e2;
      viewParent = this.d.mExpandedActionView.getParent();
      toolbar = this.d;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.mExpandedActionView); 
        Toolbar.e e = this.d.generateDefaultLayoutParams();
        toolbar = this.d;
        e.a = 0x800003 | toolbar.mButtonGravity & 0x70;
        e.b = 2;
        toolbar.mExpandedActionView.setLayoutParams((ViewGroup.LayoutParams)e);
        Toolbar toolbar1 = this.d;
        toolbar1.addView(toolbar1.mExpandedActionView);
      } 
      this.d.removeChildrenForExpandedActionView();
      this.d.requestLayout();
      param1e2.C = true;
      param1e2.n.onItemsChanged(false);
      View view = this.d.mExpandedActionView;
      if (view instanceof p1)
        ((p1)view).b(); 
      return true;
    }
    
    public boolean flagActionItems() {
      return false;
    }
    
    public int getId() {
      return 0;
    }
    
    public void initForMenu(Context param1Context, c2 param1c2) {
      c2 c21 = this.b;
      if (c21 != null) {
        e2 e21 = this.c;
        if (e21 != null)
          c21.collapseItemActionView(e21); 
      } 
      this.b = param1c2;
    }
    
    public void onCloseMenu(c2 param1c2, boolean param1Boolean) {}
    
    public void onRestoreInstanceState(Parcelable param1Parcelable) {}
    
    public Parcelable onSaveInstanceState() {
      return null;
    }
    
    public boolean onSubMenuSelected(n2 param1n2) {
      return false;
    }
    
    public void updateMenuView(boolean param1Boolean) {
      if (this.c != null) {
        c2 c21 = this.b;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (c21 != null) {
          int j = c21.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < j) {
              if (this.b.getItem(i) == this.c) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          collapseItemActionView(this.b, this.c); 
      } 
    }
  }
  
  public static class e extends c0.a {
    public int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(c0.a param1a) {
      super(param1a);
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends nf {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    public int b;
    
    public boolean c;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.b = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.c = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.ClassLoaderCreator<g> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new Toolbar.g[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<g> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */