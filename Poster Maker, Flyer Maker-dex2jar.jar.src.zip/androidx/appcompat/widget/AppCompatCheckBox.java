package androidx.appcompat.widget;

import ae;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import c3;
import h4;
import hf;
import j4;
import o3;
import s;
import u2;
import y2;

public class AppCompatCheckBox extends CheckBox implements hf, ae {
  private c3 mAppCompatEmojiTextHelper;
  
  private final u2 mBackgroundTintHelper;
  
  private final y2 mCompoundButtonHelper;
  
  private final o3 mTextHelper;
  
  public AppCompatCheckBox(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, s.checkboxStyle);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(j4.a(paramContext), paramAttributeSet, paramInt);
    h4.a((View)this, getContext());
    y2 y21 = new y2((CompoundButton)this);
    this.mCompoundButtonHelper = y21;
    y21.b(paramAttributeSet, paramInt);
    u2 u21 = new u2((View)this);
    this.mBackgroundTintHelper = u21;
    u21.d(paramAttributeSet, paramInt);
    o3 o31 = new o3((TextView)this);
    this.mTextHelper = o31;
    o31.e(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().b(paramAttributeSet, paramInt);
  }
  
  private c3 getEmojiTextViewHelper() {
    if (this.mAppCompatEmojiTextHelper == null)
      this.mAppCompatEmojiTextHelper = new c3((TextView)this); 
    return this.mAppCompatEmojiTextHelper;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.a(); 
    o3 o31 = this.mTextHelper;
    if (o31 != null)
      o31.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int i = super.getCompoundPaddingLeft();
    y2 y21 = this.mCompoundButtonHelper;
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    u2 u21 = this.mBackgroundTintHelper;
    return (u21 != null) ? u21.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    u2 u21 = this.mBackgroundTintHelper;
    return (u21 != null) ? u21.c() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    y2 y21 = this.mCompoundButtonHelper;
    return (y21 != null) ? y21.b : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    y2 y21 = this.mCompoundButtonHelper;
    return (y21 != null) ? y21.c : null;
  }
  
  public boolean isEmojiCompatEnabled() {
    return getEmojiTextViewHelper().a();
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    (getEmojiTextViewHelper()).b.a.c(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.f(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(ComponentActivity.c.N(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    y2 y21 = this.mCompoundButtonHelper;
    if (y21 != null) {
      if (y21.f) {
        y21.f = false;
        return;
      } 
      y21.f = true;
      y21.a();
    } 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    (getEmojiTextViewHelper()).b.a.d(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters((getEmojiTextViewHelper()).b.a.a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.i(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    y2 y21 = this.mCompoundButtonHelper;
    if (y21 != null) {
      y21.b = paramColorStateList;
      y21.d = true;
      y21.a();
    } 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    y2 y21 = this.mCompoundButtonHelper;
    if (y21 != null) {
      y21.c = paramMode;
      y21.e = true;
      y21.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */