package androidx.appcompat.widget;

import ae;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import e3;
import h4;
import j4;
import jf;
import k4;
import u2;

public class AppCompatImageView extends ImageView implements ae, jf {
  private final u2 mBackgroundTintHelper;
  
  private boolean mHasLevel = false;
  
  private final e3 mImageHelper;
  
  public AppCompatImageView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(j4.a(paramContext), paramAttributeSet, paramInt);
    h4.a((View)this, getContext());
    u2 u21 = new u2((View)this);
    this.mBackgroundTintHelper = u21;
    u21.d(paramAttributeSet, paramInt);
    e3 e31 = new e3(this);
    this.mImageHelper = e31;
    e31.c(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.a(); 
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.a(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    u2 u21 = this.mBackgroundTintHelper;
    return (u21 != null) ? u21.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    u2 u21 = this.mBackgroundTintHelper;
    return (u21 != null) ? u21.c() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    e3 e31 = this.mImageHelper;
    if (e31 != null) {
      k4 k4 = e31.b;
      if (k4 != null)
        return k4.a; 
    } 
    return null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    e3 e31 = this.mImageHelper;
    if (e31 != null) {
      k4 k4 = e31.b;
      if (k4 != null)
        return k4.b; 
    } 
    return null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.mImageHelper.b() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.f(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.a(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    e3 e32 = this.mImageHelper;
    if (e32 != null && paramDrawable != null && !this.mHasLevel)
      e32.d = paramDrawable.getLevel(); 
    super.setImageDrawable(paramDrawable);
    e3 e31 = this.mImageHelper;
    if (e31 != null) {
      e31.a();
      if (!this.mHasLevel) {
        e31 = this.mImageHelper;
        if (e31.a.getDrawable() != null)
          e31.a.getDrawable().setLevel(e31.d); 
      } 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.mHasLevel = true;
  }
  
  public void setImageResource(int paramInt) {
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.d(paramInt); 
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.a(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    u2 u21 = this.mBackgroundTintHelper;
    if (u21 != null)
      u21.i(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.e(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    e3 e31 = this.mImageHelper;
    if (e31 != null)
      e31.f(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */