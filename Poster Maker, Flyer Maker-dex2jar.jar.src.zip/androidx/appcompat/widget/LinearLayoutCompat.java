package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import fe;
import java.util.concurrent.atomic.AtomicInteger;
import s30;
import s4;

public class LinearLayoutCompat extends ViewGroup {
  private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
  
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned;
  
  private int mBaselineAlignedChildIndex;
  
  private int mBaselineChildTop;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield mBaselineAligned : Z
    //   12: aload_0
    //   13: iconst_m1
    //   14: putfield mBaselineAlignedChildIndex : I
    //   17: aload_0
    //   18: iconst_0
    //   19: putfield mBaselineChildTop : I
    //   22: aload_0
    //   23: ldc 8388659
    //   25: putfield mGravity : I
    //   28: getstatic b0.LinearLayoutCompat : [I
    //   31: astore #7
    //   33: aload_1
    //   34: aload_2
    //   35: aload #7
    //   37: iload_3
    //   38: iconst_0
    //   39: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   42: astore #6
    //   44: aload_0
    //   45: aload_1
    //   46: aload #7
    //   48: aload_2
    //   49: aload #6
    //   51: iload_3
    //   52: iconst_0
    //   53: invokestatic B : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   56: aload #6
    //   58: getstatic b0.LinearLayoutCompat_android_orientation : I
    //   61: iconst_m1
    //   62: invokevirtual getInt : (II)I
    //   65: istore_3
    //   66: iload_3
    //   67: iflt -> 75
    //   70: aload_0
    //   71: iload_3
    //   72: invokevirtual setOrientation : (I)V
    //   75: aload #6
    //   77: getstatic b0.LinearLayoutCompat_android_gravity : I
    //   80: iconst_m1
    //   81: invokevirtual getInt : (II)I
    //   84: istore_3
    //   85: iload_3
    //   86: iflt -> 94
    //   89: aload_0
    //   90: iload_3
    //   91: invokevirtual setGravity : (I)V
    //   94: aload #6
    //   96: getstatic b0.LinearLayoutCompat_android_baselineAligned : I
    //   99: iconst_1
    //   100: invokevirtual getBoolean : (IZ)Z
    //   103: istore #5
    //   105: iload #5
    //   107: ifne -> 116
    //   110: aload_0
    //   111: iload #5
    //   113: invokevirtual setBaselineAligned : (Z)V
    //   116: aload_0
    //   117: aload #6
    //   119: getstatic b0.LinearLayoutCompat_android_weightSum : I
    //   122: ldc -1.0
    //   124: invokevirtual getFloat : (IF)F
    //   127: putfield mWeightSum : F
    //   130: aload_0
    //   131: aload #6
    //   133: getstatic b0.LinearLayoutCompat_android_baselineAlignedChildIndex : I
    //   136: iconst_m1
    //   137: invokevirtual getInt : (II)I
    //   140: putfield mBaselineAlignedChildIndex : I
    //   143: aload_0
    //   144: aload #6
    //   146: getstatic b0.LinearLayoutCompat_measureWithLargestChild : I
    //   149: iconst_0
    //   150: invokevirtual getBoolean : (IZ)Z
    //   153: putfield mUseLargestChild : Z
    //   156: getstatic b0.LinearLayoutCompat_divider : I
    //   159: istore_3
    //   160: aload #6
    //   162: iload_3
    //   163: invokevirtual hasValue : (I)Z
    //   166: ifeq -> 193
    //   169: aload #6
    //   171: iload_3
    //   172: iconst_0
    //   173: invokevirtual getResourceId : (II)I
    //   176: istore #4
    //   178: iload #4
    //   180: ifeq -> 193
    //   183: aload_1
    //   184: iload #4
    //   186: invokestatic N : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   189: astore_1
    //   190: goto -> 200
    //   193: aload #6
    //   195: iload_3
    //   196: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   199: astore_1
    //   200: aload_0
    //   201: aload_1
    //   202: invokevirtual setDividerDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   205: aload_0
    //   206: aload #6
    //   208: getstatic b0.LinearLayoutCompat_showDividers : I
    //   211: iconst_0
    //   212: invokevirtual getInt : (II)I
    //   215: putfield mShowDividers : I
    //   218: aload_0
    //   219: aload #6
    //   221: getstatic b0.LinearLayoutCompat_dividerPadding : I
    //   224: iconst_0
    //   225: invokevirtual getDimensionPixelSize : (II)I
    //   228: putfield mDividerPadding : I
    //   231: aload #6
    //   233: invokevirtual recycle : ()V
    //   236: return
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.height == -1) {
          int k = a.width;
          a.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          a.width = k;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = s4.a((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + a.rightMargin;
        } else {
          k = view.getLeft() - a.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - a.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + a.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  public void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        a a = (a)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - a.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        a a = (a)view.getLayoutParams();
        i = view.getBottom() + a.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  public void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  public void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  public a generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a generateLayoutParams(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  public a generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  public int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  public int getLocationOffset(View paramView) {
    return 0;
  }
  
  public int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  public View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  public boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.mShowDividers & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  public void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = s4.a((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.mGravity;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    AtomicInteger atomicInteger = fe.a;
    paramInt2 = Gravity.getAbsoluteGravity(0x800007 & paramInt2, fe.e.d((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b2 * i + b1;
      View view = getVirtualChildAt(i2);
      if (view == null) {
        paramInt2 = measureNullChild(i2) + paramInt2;
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        a a = (a)view.getLayoutParams();
        if (bool2 && a.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = a.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - a.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = a.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = arrayOfInt1[1] - i3 + i4; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + a.topMargin - a.bottomMargin;
        } 
        int i3 = paramInt2;
        if (hasDividerBeforeChildAt(i2))
          i3 = paramInt2 + this.mDividerWidth; 
        paramInt2 = a.leftMargin + i3;
        setChildFrame(view, getLocationOffset(view) + paramInt2, paramInt1, i5, i6);
        paramInt1 = a.rightMargin;
        paramInt2 = getNextLocationOffset(view) + i5 + paramInt1 + paramInt2;
        i = getChildrenSkipCount(view, i2) + i;
      } 
      i++;
    } 
  }
  
  public void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = measureNullChild(paramInt2) + paramInt1;
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          a a = (a)view.getLayoutParams();
          paramInt4 = a.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          AtomicInteger atomicInteger = fe.a;
          paramInt3 = Gravity.getAbsoluteGravity(paramInt3, fe.e.d((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = a.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
            paramInt4 = a.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + a.topMargin;
          setChildFrame(view, paramInt3, getLocationOffset(view) + paramInt1, i3, i2);
          paramInt3 = a.bottomMargin;
          paramInt3 = getNextLocationOffset(view) + i2 + paramInt3 + paramInt1;
          paramInt4 = paramInt2 + getChildrenSkipCount(view, paramInt2);
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  public void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #22
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #21
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #26
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #26
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #26
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #26
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #26
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #24
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #25
    //   115: iload #22
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #9
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #13
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 873
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   173: astore #27
    //   175: aload #27
    //   177: ifnonnull -> 202
    //   180: aload_0
    //   181: getfield mTotalLength : I
    //   184: istore #14
    //   186: aload_0
    //   187: aload_0
    //   188: iload #8
    //   190: invokevirtual measureNullChild : (I)I
    //   193: iload #14
    //   195: iadd
    //   196: putfield mTotalLength : I
    //   199: goto -> 864
    //   202: aload #27
    //   204: invokevirtual getVisibility : ()I
    //   207: bipush #8
    //   209: if_icmpne -> 228
    //   212: iload #8
    //   214: aload_0
    //   215: aload #27
    //   217: iload #8
    //   219: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   222: iadd
    //   223: istore #8
    //   225: goto -> 199
    //   228: aload_0
    //   229: iload #8
    //   231: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   234: ifeq -> 250
    //   237: aload_0
    //   238: aload_0
    //   239: getfield mTotalLength : I
    //   242: aload_0
    //   243: getfield mDividerWidth : I
    //   246: iadd
    //   247: putfield mTotalLength : I
    //   250: aload #27
    //   252: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   255: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   258: astore #29
    //   260: aload #29
    //   262: getfield weight : F
    //   265: fstore #4
    //   267: fload_3
    //   268: fload #4
    //   270: fadd
    //   271: fstore_3
    //   272: iload #22
    //   274: ldc 1073741824
    //   276: if_icmpne -> 389
    //   279: aload #29
    //   281: getfield width : I
    //   284: ifne -> 389
    //   287: fload #4
    //   289: fconst_0
    //   290: fcmpl
    //   291: ifle -> 389
    //   294: iload #15
    //   296: ifeq -> 326
    //   299: aload_0
    //   300: getfield mTotalLength : I
    //   303: istore #14
    //   305: aload_0
    //   306: aload #29
    //   308: getfield leftMargin : I
    //   311: aload #29
    //   313: getfield rightMargin : I
    //   316: iadd
    //   317: iload #14
    //   319: iadd
    //   320: putfield mTotalLength : I
    //   323: goto -> 355
    //   326: aload_0
    //   327: getfield mTotalLength : I
    //   330: istore #14
    //   332: aload_0
    //   333: iload #14
    //   335: aload #29
    //   337: getfield leftMargin : I
    //   340: iload #14
    //   342: iadd
    //   343: aload #29
    //   345: getfield rightMargin : I
    //   348: iadd
    //   349: invokestatic max : (II)I
    //   352: putfield mTotalLength : I
    //   355: iload #24
    //   357: ifeq -> 383
    //   360: iconst_0
    //   361: iconst_0
    //   362: invokestatic makeMeasureSpec : (II)I
    //   365: istore #14
    //   367: aload #27
    //   369: iload #14
    //   371: iload #14
    //   373: invokevirtual measure : (II)V
    //   376: iload #7
    //   378: istore #14
    //   380: goto -> 590
    //   383: iconst_1
    //   384: istore #12
    //   386: goto -> 594
    //   389: aload #29
    //   391: getfield width : I
    //   394: ifne -> 417
    //   397: fload #4
    //   399: fconst_0
    //   400: fcmpl
    //   401: ifle -> 417
    //   404: aload #29
    //   406: bipush #-2
    //   408: putfield width : I
    //   411: iconst_0
    //   412: istore #14
    //   414: goto -> 422
    //   417: ldc_w -2147483648
    //   420: istore #14
    //   422: fload_3
    //   423: fconst_0
    //   424: fcmpl
    //   425: ifne -> 437
    //   428: aload_0
    //   429: getfield mTotalLength : I
    //   432: istore #17
    //   434: goto -> 440
    //   437: iconst_0
    //   438: istore #17
    //   440: aload_0
    //   441: aload #27
    //   443: iload #8
    //   445: iload_1
    //   446: iload #17
    //   448: iload_2
    //   449: iconst_0
    //   450: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   453: iload #14
    //   455: ldc_w -2147483648
    //   458: if_icmpeq -> 468
    //   461: aload #29
    //   463: iload #14
    //   465: putfield width : I
    //   468: aload #27
    //   470: invokevirtual getMeasuredWidth : ()I
    //   473: istore #17
    //   475: iload #15
    //   477: ifeq -> 525
    //   480: aload_0
    //   481: getfield mTotalLength : I
    //   484: istore #14
    //   486: aload #29
    //   488: getfield leftMargin : I
    //   491: istore #18
    //   493: aload #29
    //   495: getfield rightMargin : I
    //   498: istore #19
    //   500: aload_0
    //   501: aload_0
    //   502: aload #27
    //   504: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   507: iload #18
    //   509: iload #17
    //   511: iadd
    //   512: iload #19
    //   514: iadd
    //   515: iadd
    //   516: iload #14
    //   518: iadd
    //   519: putfield mTotalLength : I
    //   522: goto -> 572
    //   525: aload_0
    //   526: getfield mTotalLength : I
    //   529: istore #14
    //   531: aload #29
    //   533: getfield leftMargin : I
    //   536: istore #18
    //   538: aload #29
    //   540: getfield rightMargin : I
    //   543: istore #19
    //   545: aload_0
    //   546: iload #14
    //   548: aload_0
    //   549: aload #27
    //   551: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   554: iload #14
    //   556: iload #17
    //   558: iadd
    //   559: iload #18
    //   561: iadd
    //   562: iload #19
    //   564: iadd
    //   565: iadd
    //   566: invokestatic max : (II)I
    //   569: putfield mTotalLength : I
    //   572: iload #7
    //   574: istore #14
    //   576: iload #25
    //   578: ifeq -> 590
    //   581: iload #17
    //   583: iload #7
    //   585: invokestatic max : (II)I
    //   588: istore #14
    //   590: iload #14
    //   592: istore #7
    //   594: iload #8
    //   596: istore #18
    //   598: iload #21
    //   600: ldc 1073741824
    //   602: if_icmpeq -> 623
    //   605: aload #29
    //   607: getfield height : I
    //   610: iconst_m1
    //   611: if_icmpne -> 623
    //   614: iconst_1
    //   615: istore #8
    //   617: iconst_1
    //   618: istore #10
    //   620: goto -> 626
    //   623: iconst_0
    //   624: istore #8
    //   626: aload #29
    //   628: getfield topMargin : I
    //   631: aload #29
    //   633: getfield bottomMargin : I
    //   636: iadd
    //   637: istore #14
    //   639: aload #27
    //   641: invokevirtual getMeasuredHeight : ()I
    //   644: iload #14
    //   646: iadd
    //   647: istore #17
    //   649: iload #13
    //   651: aload #27
    //   653: invokevirtual getMeasuredState : ()I
    //   656: invokestatic combineMeasuredStates : (II)I
    //   659: istore #19
    //   661: iload #24
    //   663: ifeq -> 748
    //   666: aload #27
    //   668: invokevirtual getBaseline : ()I
    //   671: istore #23
    //   673: iload #23
    //   675: iconst_m1
    //   676: if_icmpeq -> 748
    //   679: aload #29
    //   681: getfield gravity : I
    //   684: istore #20
    //   686: iload #20
    //   688: istore #13
    //   690: iload #20
    //   692: ifge -> 701
    //   695: aload_0
    //   696: getfield mGravity : I
    //   699: istore #13
    //   701: iload #13
    //   703: bipush #112
    //   705: iand
    //   706: iconst_4
    //   707: ishr
    //   708: bipush #-2
    //   710: iand
    //   711: iconst_1
    //   712: ishr
    //   713: istore #13
    //   715: aload #28
    //   717: iload #13
    //   719: aload #28
    //   721: iload #13
    //   723: iaload
    //   724: iload #23
    //   726: invokestatic max : (II)I
    //   729: iastore
    //   730: aload #26
    //   732: iload #13
    //   734: aload #26
    //   736: iload #13
    //   738: iaload
    //   739: iload #17
    //   741: iload #23
    //   743: isub
    //   744: invokestatic max : (II)I
    //   747: iastore
    //   748: iload #9
    //   750: iload #17
    //   752: invokestatic max : (II)I
    //   755: istore #9
    //   757: iload #5
    //   759: ifeq -> 777
    //   762: aload #29
    //   764: getfield height : I
    //   767: iconst_m1
    //   768: if_icmpne -> 777
    //   771: iconst_1
    //   772: istore #5
    //   774: goto -> 780
    //   777: iconst_0
    //   778: istore #5
    //   780: aload #29
    //   782: getfield weight : F
    //   785: fconst_0
    //   786: fcmpl
    //   787: ifle -> 814
    //   790: iload #8
    //   792: ifeq -> 798
    //   795: goto -> 802
    //   798: iload #17
    //   800: istore #14
    //   802: iload #11
    //   804: iload #14
    //   806: invokestatic max : (II)I
    //   809: istore #8
    //   811: goto -> 839
    //   814: iload #8
    //   816: ifeq -> 822
    //   819: goto -> 826
    //   822: iload #17
    //   824: istore #14
    //   826: iload #6
    //   828: iload #14
    //   830: invokestatic max : (II)I
    //   833: istore #6
    //   835: iload #11
    //   837: istore #8
    //   839: aload_0
    //   840: aload #27
    //   842: iload #18
    //   844: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   847: iload #18
    //   849: iadd
    //   850: istore #14
    //   852: iload #19
    //   854: istore #13
    //   856: iload #8
    //   858: istore #11
    //   860: iload #14
    //   862: istore #8
    //   864: iload #8
    //   866: iconst_1
    //   867: iadd
    //   868: istore #8
    //   870: goto -> 160
    //   873: aload_0
    //   874: getfield mTotalLength : I
    //   877: ifle -> 902
    //   880: aload_0
    //   881: iload #16
    //   883: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   886: ifeq -> 902
    //   889: aload_0
    //   890: aload_0
    //   891: getfield mTotalLength : I
    //   894: aload_0
    //   895: getfield mDividerWidth : I
    //   898: iadd
    //   899: putfield mTotalLength : I
    //   902: aload #28
    //   904: iconst_1
    //   905: iaload
    //   906: iconst_m1
    //   907: if_icmpne -> 940
    //   910: aload #28
    //   912: iconst_0
    //   913: iaload
    //   914: iconst_m1
    //   915: if_icmpne -> 940
    //   918: aload #28
    //   920: iconst_2
    //   921: iaload
    //   922: iconst_m1
    //   923: if_icmpne -> 940
    //   926: aload #28
    //   928: iconst_3
    //   929: iaload
    //   930: iconst_m1
    //   931: if_icmpeq -> 937
    //   934: goto -> 940
    //   937: goto -> 1002
    //   940: aload #28
    //   942: iconst_3
    //   943: iaload
    //   944: aload #28
    //   946: iconst_0
    //   947: iaload
    //   948: aload #28
    //   950: iconst_1
    //   951: iaload
    //   952: aload #28
    //   954: iconst_2
    //   955: iaload
    //   956: invokestatic max : (II)I
    //   959: invokestatic max : (II)I
    //   962: invokestatic max : (II)I
    //   965: istore #8
    //   967: iload #9
    //   969: aload #26
    //   971: iconst_3
    //   972: iaload
    //   973: aload #26
    //   975: iconst_0
    //   976: iaload
    //   977: aload #26
    //   979: iconst_1
    //   980: iaload
    //   981: aload #26
    //   983: iconst_2
    //   984: iaload
    //   985: invokestatic max : (II)I
    //   988: invokestatic max : (II)I
    //   991: invokestatic max : (II)I
    //   994: iload #8
    //   996: iadd
    //   997: invokestatic max : (II)I
    //   1000: istore #9
    //   1002: iload #9
    //   1004: istore #14
    //   1006: iload #25
    //   1008: ifeq -> 1224
    //   1011: iload #22
    //   1013: ldc_w -2147483648
    //   1016: if_icmpeq -> 1028
    //   1019: iload #9
    //   1021: istore #14
    //   1023: iload #22
    //   1025: ifne -> 1224
    //   1028: aload_0
    //   1029: iconst_0
    //   1030: putfield mTotalLength : I
    //   1033: iconst_0
    //   1034: istore #8
    //   1036: iload #9
    //   1038: istore #14
    //   1040: iload #8
    //   1042: iload #16
    //   1044: if_icmpge -> 1224
    //   1047: aload_0
    //   1048: iload #8
    //   1050: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1053: astore #27
    //   1055: aload #27
    //   1057: ifnonnull -> 1082
    //   1060: aload_0
    //   1061: getfield mTotalLength : I
    //   1064: istore #14
    //   1066: aload_0
    //   1067: aload_0
    //   1068: iload #8
    //   1070: invokevirtual measureNullChild : (I)I
    //   1073: iload #14
    //   1075: iadd
    //   1076: putfield mTotalLength : I
    //   1079: goto -> 1105
    //   1082: aload #27
    //   1084: invokevirtual getVisibility : ()I
    //   1087: bipush #8
    //   1089: if_icmpne -> 1108
    //   1092: iload #8
    //   1094: aload_0
    //   1095: aload #27
    //   1097: iload #8
    //   1099: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1102: iadd
    //   1103: istore #8
    //   1105: goto -> 1215
    //   1108: aload #27
    //   1110: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1113: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1116: astore #29
    //   1118: iload #15
    //   1120: ifeq -> 1168
    //   1123: aload_0
    //   1124: getfield mTotalLength : I
    //   1127: istore #14
    //   1129: aload #29
    //   1131: getfield leftMargin : I
    //   1134: istore #17
    //   1136: aload #29
    //   1138: getfield rightMargin : I
    //   1141: istore #18
    //   1143: aload_0
    //   1144: aload_0
    //   1145: aload #27
    //   1147: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1150: iload #17
    //   1152: iload #7
    //   1154: iadd
    //   1155: iload #18
    //   1157: iadd
    //   1158: iadd
    //   1159: iload #14
    //   1161: iadd
    //   1162: putfield mTotalLength : I
    //   1165: goto -> 1105
    //   1168: aload_0
    //   1169: getfield mTotalLength : I
    //   1172: istore #14
    //   1174: aload #29
    //   1176: getfield leftMargin : I
    //   1179: istore #17
    //   1181: aload #29
    //   1183: getfield rightMargin : I
    //   1186: istore #18
    //   1188: aload_0
    //   1189: iload #14
    //   1191: aload_0
    //   1192: aload #27
    //   1194: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1197: iload #14
    //   1199: iload #7
    //   1201: iadd
    //   1202: iload #17
    //   1204: iadd
    //   1205: iload #18
    //   1207: iadd
    //   1208: iadd
    //   1209: invokestatic max : (II)I
    //   1212: putfield mTotalLength : I
    //   1215: iload #8
    //   1217: iconst_1
    //   1218: iadd
    //   1219: istore #8
    //   1221: goto -> 1036
    //   1224: aload_0
    //   1225: getfield mTotalLength : I
    //   1228: istore #8
    //   1230: aload_0
    //   1231: invokevirtual getPaddingLeft : ()I
    //   1234: istore #9
    //   1236: aload_0
    //   1237: invokevirtual getPaddingRight : ()I
    //   1240: iload #9
    //   1242: iadd
    //   1243: iload #8
    //   1245: iadd
    //   1246: istore #8
    //   1248: aload_0
    //   1249: iload #8
    //   1251: putfield mTotalLength : I
    //   1254: iload #8
    //   1256: aload_0
    //   1257: invokevirtual getSuggestedMinimumWidth : ()I
    //   1260: invokestatic max : (II)I
    //   1263: iload_1
    //   1264: iconst_0
    //   1265: invokestatic resolveSizeAndState : (III)I
    //   1268: istore #18
    //   1270: ldc_w 16777215
    //   1273: iload #18
    //   1275: iand
    //   1276: aload_0
    //   1277: getfield mTotalLength : I
    //   1280: isub
    //   1281: istore #17
    //   1283: iload #12
    //   1285: ifne -> 1421
    //   1288: iload #17
    //   1290: ifeq -> 1302
    //   1293: fload_3
    //   1294: fconst_0
    //   1295: fcmpl
    //   1296: ifle -> 1302
    //   1299: goto -> 1421
    //   1302: iload #6
    //   1304: iload #11
    //   1306: invokestatic max : (II)I
    //   1309: istore #9
    //   1311: iload #25
    //   1313: ifeq -> 1406
    //   1316: iload #22
    //   1318: ldc 1073741824
    //   1320: if_icmpeq -> 1406
    //   1323: iconst_0
    //   1324: istore #6
    //   1326: iload #6
    //   1328: iload #16
    //   1330: if_icmpge -> 1406
    //   1333: aload_0
    //   1334: iload #6
    //   1336: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1339: astore #26
    //   1341: aload #26
    //   1343: ifnull -> 1397
    //   1346: aload #26
    //   1348: invokevirtual getVisibility : ()I
    //   1351: bipush #8
    //   1353: if_icmpne -> 1359
    //   1356: goto -> 1397
    //   1359: aload #26
    //   1361: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1364: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1367: getfield weight : F
    //   1370: fconst_0
    //   1371: fcmpl
    //   1372: ifle -> 1397
    //   1375: aload #26
    //   1377: iload #7
    //   1379: ldc 1073741824
    //   1381: invokestatic makeMeasureSpec : (II)I
    //   1384: aload #26
    //   1386: invokevirtual getMeasuredHeight : ()I
    //   1389: ldc 1073741824
    //   1391: invokestatic makeMeasureSpec : (II)I
    //   1394: invokevirtual measure : (II)V
    //   1397: iload #6
    //   1399: iconst_1
    //   1400: iadd
    //   1401: istore #6
    //   1403: goto -> 1326
    //   1406: iload #16
    //   1408: istore #8
    //   1410: iload #14
    //   1412: istore #7
    //   1414: iload #9
    //   1416: istore #6
    //   1418: goto -> 2206
    //   1421: aload_0
    //   1422: getfield mWeightSum : F
    //   1425: fstore #4
    //   1427: fload #4
    //   1429: fconst_0
    //   1430: fcmpl
    //   1431: ifle -> 1437
    //   1434: fload #4
    //   1436: fstore_3
    //   1437: aload #28
    //   1439: iconst_3
    //   1440: iconst_m1
    //   1441: iastore
    //   1442: aload #28
    //   1444: iconst_2
    //   1445: iconst_m1
    //   1446: iastore
    //   1447: aload #28
    //   1449: iconst_1
    //   1450: iconst_m1
    //   1451: iastore
    //   1452: aload #28
    //   1454: iconst_0
    //   1455: iconst_m1
    //   1456: iastore
    //   1457: aload #26
    //   1459: iconst_3
    //   1460: iconst_m1
    //   1461: iastore
    //   1462: aload #26
    //   1464: iconst_2
    //   1465: iconst_m1
    //   1466: iastore
    //   1467: aload #26
    //   1469: iconst_1
    //   1470: iconst_m1
    //   1471: iastore
    //   1472: aload #26
    //   1474: iconst_0
    //   1475: iconst_m1
    //   1476: iastore
    //   1477: aload_0
    //   1478: iconst_0
    //   1479: putfield mTotalLength : I
    //   1482: iload #13
    //   1484: istore #9
    //   1486: iconst_m1
    //   1487: istore #11
    //   1489: iconst_0
    //   1490: istore #13
    //   1492: iload #5
    //   1494: istore #8
    //   1496: iload #16
    //   1498: istore #7
    //   1500: iload #9
    //   1502: istore #5
    //   1504: iload #6
    //   1506: istore #9
    //   1508: iload #17
    //   1510: istore #6
    //   1512: iload #13
    //   1514: iload #7
    //   1516: if_icmpge -> 2056
    //   1519: aload_0
    //   1520: iload #13
    //   1522: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1525: astore #27
    //   1527: aload #27
    //   1529: ifnull -> 2047
    //   1532: aload #27
    //   1534: invokevirtual getVisibility : ()I
    //   1537: bipush #8
    //   1539: if_icmpne -> 1545
    //   1542: goto -> 2047
    //   1545: aload #27
    //   1547: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1550: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1553: astore #29
    //   1555: aload #29
    //   1557: getfield weight : F
    //   1560: fstore #4
    //   1562: fload #4
    //   1564: fconst_0
    //   1565: fcmpl
    //   1566: ifle -> 1733
    //   1569: iload #6
    //   1571: i2f
    //   1572: fload #4
    //   1574: fmul
    //   1575: fload_3
    //   1576: fdiv
    //   1577: f2i
    //   1578: istore #14
    //   1580: aload_0
    //   1581: invokevirtual getPaddingTop : ()I
    //   1584: istore #12
    //   1586: iload_2
    //   1587: aload_0
    //   1588: invokevirtual getPaddingBottom : ()I
    //   1591: iload #12
    //   1593: iadd
    //   1594: aload #29
    //   1596: getfield topMargin : I
    //   1599: iadd
    //   1600: aload #29
    //   1602: getfield bottomMargin : I
    //   1605: iadd
    //   1606: aload #29
    //   1608: getfield height : I
    //   1611: invokestatic getChildMeasureSpec : (III)I
    //   1614: istore #17
    //   1616: aload #29
    //   1618: getfield width : I
    //   1621: ifne -> 1666
    //   1624: iload #22
    //   1626: ldc 1073741824
    //   1628: if_icmpeq -> 1634
    //   1631: goto -> 1666
    //   1634: iload #14
    //   1636: ifle -> 1646
    //   1639: iload #14
    //   1641: istore #12
    //   1643: goto -> 1649
    //   1646: iconst_0
    //   1647: istore #12
    //   1649: aload #27
    //   1651: iload #12
    //   1653: ldc 1073741824
    //   1655: invokestatic makeMeasureSpec : (II)I
    //   1658: iload #17
    //   1660: invokevirtual measure : (II)V
    //   1663: goto -> 1702
    //   1666: aload #27
    //   1668: invokevirtual getMeasuredWidth : ()I
    //   1671: iload #14
    //   1673: iadd
    //   1674: istore #16
    //   1676: iload #16
    //   1678: istore #12
    //   1680: iload #16
    //   1682: ifge -> 1688
    //   1685: iconst_0
    //   1686: istore #12
    //   1688: aload #27
    //   1690: iload #12
    //   1692: ldc 1073741824
    //   1694: invokestatic makeMeasureSpec : (II)I
    //   1697: iload #17
    //   1699: invokevirtual measure : (II)V
    //   1702: iload #5
    //   1704: aload #27
    //   1706: invokevirtual getMeasuredState : ()I
    //   1709: ldc_w -16777216
    //   1712: iand
    //   1713: invokestatic combineMeasuredStates : (II)I
    //   1716: istore #5
    //   1718: fload_3
    //   1719: fload #4
    //   1721: fsub
    //   1722: fstore_3
    //   1723: iload #6
    //   1725: iload #14
    //   1727: isub
    //   1728: istore #6
    //   1730: goto -> 1733
    //   1733: iload #15
    //   1735: ifeq -> 1790
    //   1738: aload_0
    //   1739: getfield mTotalLength : I
    //   1742: istore #12
    //   1744: aload #27
    //   1746: invokevirtual getMeasuredWidth : ()I
    //   1749: istore #14
    //   1751: aload #29
    //   1753: getfield leftMargin : I
    //   1756: istore #16
    //   1758: aload #29
    //   1760: getfield rightMargin : I
    //   1763: istore #17
    //   1765: aload_0
    //   1766: aload_0
    //   1767: aload #27
    //   1769: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1772: iload #14
    //   1774: iload #16
    //   1776: iadd
    //   1777: iload #17
    //   1779: iadd
    //   1780: iadd
    //   1781: iload #12
    //   1783: iadd
    //   1784: putfield mTotalLength : I
    //   1787: goto -> 1844
    //   1790: aload_0
    //   1791: getfield mTotalLength : I
    //   1794: istore #12
    //   1796: aload #27
    //   1798: invokevirtual getMeasuredWidth : ()I
    //   1801: istore #14
    //   1803: aload #29
    //   1805: getfield leftMargin : I
    //   1808: istore #16
    //   1810: aload #29
    //   1812: getfield rightMargin : I
    //   1815: istore #17
    //   1817: aload_0
    //   1818: iload #12
    //   1820: aload_0
    //   1821: aload #27
    //   1823: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1826: iload #14
    //   1828: iload #12
    //   1830: iadd
    //   1831: iload #16
    //   1833: iadd
    //   1834: iload #17
    //   1836: iadd
    //   1837: iadd
    //   1838: invokestatic max : (II)I
    //   1841: putfield mTotalLength : I
    //   1844: iload #21
    //   1846: ldc 1073741824
    //   1848: if_icmpeq -> 1866
    //   1851: aload #29
    //   1853: getfield height : I
    //   1856: iconst_m1
    //   1857: if_icmpne -> 1866
    //   1860: iconst_1
    //   1861: istore #12
    //   1863: goto -> 1869
    //   1866: iconst_0
    //   1867: istore #12
    //   1869: aload #29
    //   1871: getfield topMargin : I
    //   1874: aload #29
    //   1876: getfield bottomMargin : I
    //   1879: iadd
    //   1880: istore #17
    //   1882: aload #27
    //   1884: invokevirtual getMeasuredHeight : ()I
    //   1887: iload #17
    //   1889: iadd
    //   1890: istore #16
    //   1892: iload #11
    //   1894: iload #16
    //   1896: invokestatic max : (II)I
    //   1899: istore #14
    //   1901: iload #12
    //   1903: ifeq -> 1913
    //   1906: iload #17
    //   1908: istore #11
    //   1910: goto -> 1917
    //   1913: iload #16
    //   1915: istore #11
    //   1917: iload #9
    //   1919: iload #11
    //   1921: invokestatic max : (II)I
    //   1924: istore #11
    //   1926: iload #8
    //   1928: ifeq -> 1946
    //   1931: aload #29
    //   1933: getfield height : I
    //   1936: iconst_m1
    //   1937: if_icmpne -> 1946
    //   1940: iconst_1
    //   1941: istore #8
    //   1943: goto -> 1949
    //   1946: iconst_0
    //   1947: istore #8
    //   1949: iload #24
    //   1951: ifeq -> 2036
    //   1954: aload #27
    //   1956: invokevirtual getBaseline : ()I
    //   1959: istore #17
    //   1961: iload #17
    //   1963: iconst_m1
    //   1964: if_icmpeq -> 2036
    //   1967: aload #29
    //   1969: getfield gravity : I
    //   1972: istore #12
    //   1974: iload #12
    //   1976: istore #9
    //   1978: iload #12
    //   1980: ifge -> 1989
    //   1983: aload_0
    //   1984: getfield mGravity : I
    //   1987: istore #9
    //   1989: iload #9
    //   1991: bipush #112
    //   1993: iand
    //   1994: iconst_4
    //   1995: ishr
    //   1996: bipush #-2
    //   1998: iand
    //   1999: iconst_1
    //   2000: ishr
    //   2001: istore #9
    //   2003: aload #28
    //   2005: iload #9
    //   2007: aload #28
    //   2009: iload #9
    //   2011: iaload
    //   2012: iload #17
    //   2014: invokestatic max : (II)I
    //   2017: iastore
    //   2018: aload #26
    //   2020: iload #9
    //   2022: aload #26
    //   2024: iload #9
    //   2026: iaload
    //   2027: iload #16
    //   2029: iload #17
    //   2031: isub
    //   2032: invokestatic max : (II)I
    //   2035: iastore
    //   2036: iload #11
    //   2038: istore #9
    //   2040: iload #14
    //   2042: istore #11
    //   2044: goto -> 2047
    //   2047: iload #13
    //   2049: iconst_1
    //   2050: iadd
    //   2051: istore #13
    //   2053: goto -> 1512
    //   2056: aload_0
    //   2057: getfield mTotalLength : I
    //   2060: istore #6
    //   2062: aload_0
    //   2063: invokevirtual getPaddingLeft : ()I
    //   2066: istore #12
    //   2068: aload_0
    //   2069: aload_0
    //   2070: invokevirtual getPaddingRight : ()I
    //   2073: iload #12
    //   2075: iadd
    //   2076: iload #6
    //   2078: iadd
    //   2079: putfield mTotalLength : I
    //   2082: aload #28
    //   2084: iconst_1
    //   2085: iaload
    //   2086: iconst_m1
    //   2087: if_icmpne -> 2124
    //   2090: aload #28
    //   2092: iconst_0
    //   2093: iaload
    //   2094: iconst_m1
    //   2095: if_icmpne -> 2124
    //   2098: aload #28
    //   2100: iconst_2
    //   2101: iaload
    //   2102: iconst_m1
    //   2103: if_icmpne -> 2124
    //   2106: aload #28
    //   2108: iconst_3
    //   2109: iaload
    //   2110: iconst_m1
    //   2111: if_icmpeq -> 2117
    //   2114: goto -> 2124
    //   2117: iload #11
    //   2119: istore #6
    //   2121: goto -> 2186
    //   2124: aload #28
    //   2126: iconst_3
    //   2127: iaload
    //   2128: aload #28
    //   2130: iconst_0
    //   2131: iaload
    //   2132: aload #28
    //   2134: iconst_1
    //   2135: iaload
    //   2136: aload #28
    //   2138: iconst_2
    //   2139: iaload
    //   2140: invokestatic max : (II)I
    //   2143: invokestatic max : (II)I
    //   2146: invokestatic max : (II)I
    //   2149: istore #6
    //   2151: iload #11
    //   2153: aload #26
    //   2155: iconst_3
    //   2156: iaload
    //   2157: aload #26
    //   2159: iconst_0
    //   2160: iaload
    //   2161: aload #26
    //   2163: iconst_1
    //   2164: iaload
    //   2165: aload #26
    //   2167: iconst_2
    //   2168: iaload
    //   2169: invokestatic max : (II)I
    //   2172: invokestatic max : (II)I
    //   2175: invokestatic max : (II)I
    //   2178: iload #6
    //   2180: iadd
    //   2181: invokestatic max : (II)I
    //   2184: istore #6
    //   2186: iload #5
    //   2188: istore #13
    //   2190: iload #8
    //   2192: istore #5
    //   2194: iload #7
    //   2196: istore #8
    //   2198: iload #6
    //   2200: istore #7
    //   2202: iload #9
    //   2204: istore #6
    //   2206: iload #5
    //   2208: ifne -> 2221
    //   2211: iload #21
    //   2213: ldc 1073741824
    //   2215: if_icmpeq -> 2221
    //   2218: goto -> 2225
    //   2221: iload #7
    //   2223: istore #6
    //   2225: aload_0
    //   2226: invokevirtual getPaddingTop : ()I
    //   2229: istore #5
    //   2231: aload_0
    //   2232: iload #18
    //   2234: iload #13
    //   2236: ldc_w -16777216
    //   2239: iand
    //   2240: ior
    //   2241: aload_0
    //   2242: invokevirtual getPaddingBottom : ()I
    //   2245: iload #5
    //   2247: iadd
    //   2248: iload #6
    //   2250: iadd
    //   2251: aload_0
    //   2252: invokevirtual getSuggestedMinimumHeight : ()I
    //   2255: invokestatic max : (II)I
    //   2258: iload_2
    //   2259: iload #13
    //   2261: bipush #16
    //   2263: ishl
    //   2264: invokestatic resolveSizeAndState : (III)I
    //   2267: invokevirtual setMeasuredDimension : (II)V
    //   2270: iload #10
    //   2272: ifeq -> 2282
    //   2275: aload_0
    //   2276: iload #8
    //   2278: iload_1
    //   2279: invokespecial forceUniformHeight : (II)V
    //   2282: return
  }
  
  public int measureNullChild(int paramInt) {
    return 0;
  }
  
  public void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i2 = getVirtualChildCount();
    int i8 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i9 = this.mBaselineAlignedChildIndex;
    boolean bool1 = this.mUseLargestChild;
    float f = 0.0F;
    int i = 0;
    int i4 = 0;
    int n = 0;
    int j = 0;
    int m = 0;
    int i1 = 0;
    int i3 = 0;
    int k = 1;
    boolean bool = false;
    while (i1 < i2) {
      View view = getVirtualChildAt(i1);
      if (view == null) {
        int i10 = this.mTotalLength;
        this.mTotalLength = measureNullChild(i1) + i10;
      } else if (view.getVisibility() == 8) {
        i1 += getChildrenSkipCount(view, i1);
      } else {
        if (hasDividerBeforeChildAt(i1))
          this.mTotalLength += this.mDividerHeight; 
        a a = (a)view.getLayoutParams();
        float f1 = a.weight;
        f += f1;
        if (i5 == 1073741824 && a.height == 0 && f1 > 0.0F) {
          i3 = this.mTotalLength;
          this.mTotalLength = Math.max(i3, a.topMargin + i3 + a.bottomMargin);
          i3 = 1;
        } else {
          if (a.height == 0 && f1 > 0.0F) {
            a.height = -2;
            i11 = 0;
          } else {
            i11 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i12 = this.mTotalLength;
          } else {
            i12 = 0;
          } 
          measureChildBeforeLayout(view, i1, paramInt1, 0, paramInt2, i12);
          if (i11 != Integer.MIN_VALUE)
            a.height = i11; 
          int i11 = view.getMeasuredHeight();
          int i12 = this.mTotalLength;
          int i13 = a.topMargin;
          int i14 = a.bottomMargin;
          this.mTotalLength = Math.max(i12, getNextLocationOffset(view) + i12 + i11 + i13 + i14);
          if (bool1)
            n = Math.max(i11, n); 
        } 
        int i10 = i1;
        if (i9 >= 0 && i9 == i10 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i10 >= i9 || a.weight <= 0.0F) {
          if (i8 != 1073741824 && a.width == -1) {
            i1 = 1;
            bool = true;
          } else {
            i1 = 0;
          } 
          int i11 = a.leftMargin + a.rightMargin;
          int i12 = view.getMeasuredWidth() + i11;
          i4 = Math.max(i4, i12);
          int i13 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && a.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (a.weight > 0.0F) {
            if (i1 == 0)
              i11 = i12; 
            j = Math.max(j, i11);
            k = m;
          } else {
            if (i1 == 0)
              i11 = i12; 
            k = Math.max(m, i11);
          } 
          i1 = getChildrenSkipCount(view, i10);
          m = k;
          i11 = i13;
          i1 += i10;
          k = i;
          i = i11;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i2))
      this.mTotalLength += this.mDividerHeight; 
    if (bool1 && (i5 == Integer.MIN_VALUE || i5 == 0)) {
      this.mTotalLength = 0;
      for (i1 = 0; i1 < i2; i1++) {
        View view = getVirtualChildAt(i1);
        if (view == null) {
          int i10 = this.mTotalLength;
          this.mTotalLength = measureNullChild(i1) + i10;
        } else if (view.getVisibility() == 8) {
          i1 += getChildrenSkipCount(view, i1);
        } else {
          a a = (a)view.getLayoutParams();
          int i10 = this.mTotalLength;
          int i11 = a.topMargin;
          int i12 = a.bottomMargin;
          this.mTotalLength = Math.max(i10, getNextLocationOffset(view) + i10 + n + i11 + i12);
        } 
      } 
    } 
    i1 = this.mTotalLength;
    int i6 = getPaddingTop();
    i1 = getPaddingBottom() + i6 + i1;
    this.mTotalLength = i1;
    int i7 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i7) - this.mTotalLength;
    if (i3 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      j = i1;
      for (n = 0; n < i2; n++) {
        View view = getVirtualChildAt(n);
        if (view.getVisibility() != 8) {
          a a = (a)view.getLayoutParams();
          f1 = a.weight;
          if (f1 > 0.0F) {
            i3 = (int)(j * f1 / f);
            i6 = getPaddingLeft();
            int i11 = getPaddingRight();
            int i12 = a.leftMargin;
            i9 = a.rightMargin;
            int i13 = a.width;
            i1 = j - i3;
            i6 = ViewGroup.getChildMeasureSpec(paramInt1, i11 + i6 + i12 + i9, i13);
            if (a.height != 0 || i5 != 1073741824) {
              i3 = view.getMeasuredHeight() + i3;
              j = i3;
              if (i3 < 0)
                j = 0; 
              view.measure(i6, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i3 > 0) {
                j = i3;
              } else {
                j = 0;
              } 
              view.measure(i6, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i1;
          } 
          i3 = a.leftMargin + a.rightMargin;
          i6 = view.getMeasuredWidth() + i3;
          i4 = Math.max(i4, i6);
          if (i8 != 1073741824 && a.width == -1) {
            i1 = 1;
          } else {
            i1 = 0;
          } 
          if (i1 != 0) {
            i1 = i3;
          } else {
            i1 = i6;
          } 
          m = Math.max(m, i1);
          if (k != 0 && a.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          i1 = this.mTotalLength;
          i3 = view.getMeasuredHeight();
          i6 = a.topMargin;
          int i10 = a.bottomMargin;
          this.mTotalLength = Math.max(i1, getNextLocationOffset(view) + i3 + i1 + i6 + i10);
        } 
      } 
      j = this.mTotalLength;
      n = getPaddingTop();
      this.mTotalLength = getPaddingBottom() + n + j;
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool1 && i5 != 1073741824)
        for (j = 0; j < i2; j++) {
          View view = getVirtualChildAt(j);
          if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
    } 
    if (k != 0 || i8 == 1073741824)
      i = i4; 
    k = getPaddingLeft();
    setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + k + i, getSuggestedMinimumWidth()), paramInt1, j), i7);
    if (bool)
      forceUniformWidth(i2, paramInt2); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
      return;
    } 
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
      return;
    } 
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = s30.x0("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class a extends LinearLayout.LayoutParams {
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */