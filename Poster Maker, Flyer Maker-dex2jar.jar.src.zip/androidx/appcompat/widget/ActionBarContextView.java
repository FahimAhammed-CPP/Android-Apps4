package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import c2;
import fe;
import i2;
import j2;
import java.util.concurrent.atomic.AtomicInteger;
import o1;
import q2;
import s2;
import s4;
import x;
import x1;
import y;

public class ActionBarContextView extends q2 {
  public int A;
  
  public int B;
  
  public boolean C;
  
  public int D;
  
  public CharSequence s;
  
  public CharSequence t;
  
  public View u;
  
  public View v;
  
  public View w;
  
  public LinearLayout x;
  
  public TextView y;
  
  public TextView z;
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: getstatic s.actionModeStyle : I
    //   3: istore_3
    //   4: aload_0
    //   5: aload_1
    //   6: aload_2
    //   7: iload_3
    //   8: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   11: aload_1
    //   12: aload_2
    //   13: getstatic b0.ActionMode : [I
    //   16: iload_3
    //   17: iconst_0
    //   18: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   21: astore_2
    //   22: getstatic b0.ActionMode_background : I
    //   25: istore_3
    //   26: aload_2
    //   27: iload_3
    //   28: invokevirtual hasValue : (I)Z
    //   31: ifeq -> 57
    //   34: aload_2
    //   35: iload_3
    //   36: iconst_0
    //   37: invokevirtual getResourceId : (II)I
    //   40: istore #4
    //   42: iload #4
    //   44: ifeq -> 57
    //   47: aload_1
    //   48: iload #4
    //   50: invokestatic N : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   53: astore_1
    //   54: goto -> 63
    //   57: aload_2
    //   58: iload_3
    //   59: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   62: astore_1
    //   63: getstatic fe.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   66: astore #5
    //   68: aload_0
    //   69: aload_1
    //   70: invokestatic q : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   73: aload_0
    //   74: aload_2
    //   75: getstatic b0.ActionMode_titleTextStyle : I
    //   78: iconst_0
    //   79: invokevirtual getResourceId : (II)I
    //   82: putfield A : I
    //   85: aload_0
    //   86: aload_2
    //   87: getstatic b0.ActionMode_subtitleTextStyle : I
    //   90: iconst_0
    //   91: invokevirtual getResourceId : (II)I
    //   94: putfield B : I
    //   97: aload_0
    //   98: aload_2
    //   99: getstatic b0.ActionMode_height : I
    //   102: iconst_0
    //   103: invokevirtual getLayoutDimension : (II)I
    //   106: putfield g : I
    //   109: aload_0
    //   110: aload_2
    //   111: getstatic b0.ActionMode_closeItemLayout : I
    //   114: getstatic y.abc_action_mode_close_item_material : I
    //   117: invokevirtual getResourceId : (II)I
    //   120: putfield D : I
    //   123: aload_2
    //   124: invokevirtual recycle : ()V
    //   127: return
  }
  
  public void f(o1 paramo1) {
    View view = this.u;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.D, (ViewGroup)this, false);
      this.u = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.u);
    } 
    view = this.u.findViewById(x.action_mode_close_button);
    this.v = view;
    view.setOnClickListener(new a(this, paramo1));
    c2 c2 = (c2)paramo1.c();
    s2 s21 = this.f;
    if (s21 != null)
      s21.a(); 
    s21 = new s2(getContext());
    this.f = s21;
    s21.w = true;
    s21.x = true;
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    c2.addMenuPresenter((i2)this.f, this.c);
    s2 s22 = this.f;
    j2 j21 = ((x1)s22).r;
    if (j21 == null) {
      j2 j2 = (j2)((x1)s22).f.inflate(((x1)s22).p, (ViewGroup)this, false);
      ((x1)s22).r = j2;
      j2.initialize(((x1)s22).d);
      s22.updateMenuView(true);
    } 
    j2 j22 = ((x1)s22).r;
    if (j21 != j22)
      ((ActionMenuView)j22).setPresenter(s22); 
    ActionMenuView actionMenuView = (ActionMenuView)j22;
    this.d = actionMenuView;
    AtomicInteger atomicInteger = fe.a;
    fe.d.q((View)actionMenuView, null);
    addView((View)this.d, layoutParams);
  }
  
  public final void g() {
    if (this.x == null) {
      LayoutInflater.from(getContext()).inflate(y.abc_action_bar_title_item, (ViewGroup)this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.x = linearLayout1;
      this.y = (TextView)linearLayout1.findViewById(x.action_bar_title);
      this.z = (TextView)this.x.findViewById(x.action_bar_subtitle);
      if (this.A != 0)
        this.y.setTextAppearance(getContext(), this.A); 
      if (this.B != 0)
        this.z.setTextAppearance(getContext(), this.B); 
    } 
    this.y.setText(this.s);
    this.z.setText(this.t);
    boolean bool1 = TextUtils.isEmpty(this.s);
    int i = TextUtils.isEmpty(this.t) ^ true;
    TextView textView = this.z;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.x;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.x.getParent() == null)
      addView((View)this.x); 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.t;
  }
  
  public CharSequence getTitle() {
    return this.s;
  }
  
  public void h() {
    removeAllViews();
    this.w = null;
    this.d = null;
    this.f = null;
    View view = this.v;
    if (view != null)
      view.setOnClickListener(null); 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    s2 s2 = this.f;
    if (s2 != null) {
      s2.c();
      this.f.d();
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = s4.a((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.u;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.u.getLayoutParams();
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.rightMargin;
        } else {
          paramInt4 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.leftMargin;
        } else {
          paramInt2 = marginLayoutParams.rightMargin;
        } 
        if (paramBoolean) {
          paramInt4 = i - paramInt4;
        } else {
          paramInt4 = i + paramInt4;
        } 
        paramInt4 += d(this.u, paramInt4, j, k, paramBoolean);
        if (paramBoolean) {
          paramInt2 = paramInt4 - paramInt2;
        } else {
          paramInt2 = paramInt4 + paramInt2;
        } 
      } 
    } 
    LinearLayout linearLayout = this.x;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.w == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + d((View)this.x, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.w;
    if (view1 != null)
      d(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.d;
    if (actionMenuView != null)
      d((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.g;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        paramInt1 = getPaddingTop();
        int i1 = getPaddingBottom() + paramInt1;
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.u;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.u.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.d;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.d, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.x;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.w == null)
            if (this.C) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.x.measure(paramInt2, k);
              int i2 = this.x.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.x;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.w;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.w.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.g <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
    throw illegalStateException;
  }
  
  public void setContentHeight(int paramInt) {
    this.g = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.w;
    if (view != null)
      removeView(view); 
    this.w = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.x;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.x = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.t = paramCharSequence;
    g();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.s = paramCharSequence;
    g();
    fe.D((View)this, paramCharSequence);
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.C)
      requestLayout(); 
    this.C = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a implements View.OnClickListener {
    public a(ActionBarContextView this$0, o1 param1o1) {}
    
    public void onClick(View param1View) {
      this.b.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */