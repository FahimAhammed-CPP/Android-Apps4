package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import bb;
import d1;
import fe;
import i2;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import le;
import rd;
import s;
import s3;
import s30;
import s4;
import sd;
import t3;
import td;
import u1;
import ud;
import x;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements s3, td, rd, sd {
  public static final int[] b = new int[] { s.actionBarSize, 16842841 };
  
  public final Rect A = new Rect();
  
  public final Rect B = new Rect();
  
  public final Rect C = new Rect();
  
  public final Rect D = new Rect();
  
  public final Rect E = new Rect();
  
  public le F;
  
  public le G;
  
  public le H;
  
  public le I;
  
  public d J;
  
  public OverScroller K;
  
  public ViewPropertyAnimator L;
  
  public final AnimatorListenerAdapter M;
  
  public final Runnable N;
  
  public final Runnable O;
  
  public final ud P;
  
  public int c;
  
  public int d = 0;
  
  public ContentFrameLayout f;
  
  public ActionBarContainer g;
  
  public t3 p;
  
  public Drawable q;
  
  public boolean r;
  
  public boolean s;
  
  public boolean t;
  
  public boolean u;
  
  public boolean v;
  
  public int w;
  
  public int x;
  
  public final Rect y = new Rect();
  
  public final Rect z = new Rect();
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    le le1 = le.a;
    this.F = le1;
    this.G = le1;
    this.H = le1;
    this.I = le1;
    this.M = new a(this);
    this.N = new b(this);
    this.O = new c(this);
    l(paramContext);
    this.P = new ud();
  }
  
  public void a(Menu paramMenu, i2.a parama) {
    m();
    this.p.a(paramMenu, parama);
  }
  
  public boolean b() {
    m();
    return this.p.b();
  }
  
  public void c() {
    m();
    this.p.c();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public boolean d() {
    m();
    return this.p.d();
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.q != null && !this.r) {
      byte b;
      if (this.g.getVisibility() == 0) {
        float f = this.g.getBottom();
        b = (int)(this.g.getTranslationY() + f + 0.5F);
      } else {
        b = 0;
      } 
      this.q.setBounds(0, b, getWidth(), this.q.getIntrinsicHeight() + b);
      this.q.draw(paramCanvas);
    } 
  }
  
  public boolean e() {
    m();
    return this.p.e();
  }
  
  public boolean f() {
    m();
    return this.p.f();
  }
  
  public boolean fitSystemWindows(Rect paramRect) {
    if (Build.VERSION.SDK_INT >= 21)
      return super.fitSystemWindows(paramRect); 
    m();
    boolean bool = j((View)this.g, paramRect, true, true, false, true);
    this.B.set(paramRect);
    paramRect = this.B;
    Rect rect = this.y;
    Method method = s4.a;
    if (method != null)
      try {
        method.invoke(this, new Object[] { paramRect, rect });
      } catch (Exception exception) {} 
    if (!this.C.equals(this.B)) {
      this.C.set(this.B);
      bool = true;
    } 
    if (!this.z.equals(this.y)) {
      this.z.set(this.y);
      bool = true;
    } 
    if (bool)
      requestLayout(); 
    return true;
  }
  
  public boolean g() {
    m();
    return this.p.g();
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.g;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.P.a();
  }
  
  public CharSequence getTitle() {
    m();
    return this.p.getTitle();
  }
  
  public void h(int paramInt) {
    m();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.p.y();
      return;
    } 
    this.p.x();
  }
  
  public void i() {
    m();
    this.p.h();
  }
  
  public final boolean j(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$e
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  public void k() {
    removeCallbacks(this.N);
    removeCallbacks(this.O);
    ViewPropertyAnimator viewPropertyAnimator = this.L;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void l(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(b);
    boolean bool2 = false;
    this.c = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.q = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.r = bool1;
    this.K = new OverScroller(paramContext);
  }
  
  public void m() {
    if (this.f == null) {
      t3 t31;
      this.f = (ContentFrameLayout)findViewById(x.action_bar_activity_content);
      this.g = (ActionBarContainer)findViewById(x.action_bar_container);
      View view = findViewById(x.action_bar);
      if (view instanceof t3) {
        t31 = (t3)view;
      } else if (t31 instanceof Toolbar) {
        t31 = ((Toolbar)t31).getWrapper();
      } else {
        StringBuilder stringBuilder = s30.x0("Can't make a decor toolbar out of ");
        stringBuilder.append(t31.getClass().getSimpleName());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      this.p = t31;
      return;
    } 
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    m();
    le le1 = le.l(paramWindowInsets, (View)this);
    Rect rect = new Rect(le1.d(), le1.f(), le1.e(), le1.c());
    boolean bool1 = j((View)this.g, rect, true, true, false, true);
    rect = this.y;
    AtomicInteger atomicInteger = fe.a;
    if (Build.VERSION.SDK_INT >= 21)
      fe.i.b((View)this, le1, rect); 
    rect = this.y;
    int i = rect.left;
    int j = rect.top;
    int k = rect.right;
    int m = rect.bottom;
    le le2 = le1.b.l(i, j, k, m);
    this.F = le2;
    boolean bool2 = this.G.equals(le2);
    boolean bool = true;
    if (!bool2) {
      this.G = this.F;
      bool1 = true;
    } 
    if (!this.z.equals(this.y)) {
      this.z.set(this.y);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return (le1.b.a().a()).b.b().j();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    l(getContext());
    fe.A((View)this);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    k();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int i = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int k = e.leftMargin + paramInt3;
        int m = e.topMargin + paramInt4;
        view.layout(k, m, i + k, j + m);
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    m();
    measureChildWithMargins((View)this.g, paramInt1, 0, paramInt2, 0);
    e e2 = (e)this.g.getLayoutParams();
    int i1 = Math.max(0, this.g.getMeasuredWidth() + e2.leftMargin + e2.rightMargin);
    int n = Math.max(0, this.g.getMeasuredHeight() + e2.topMargin + e2.bottomMargin);
    int m = View.combineMeasuredStates(0, this.g.getMeasuredState());
    AtomicInteger atomicInteger = fe.a;
    if ((fe.d.g((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i2 = this.c;
      i = i2;
      if (this.t) {
        i = i2;
        if (this.g.getTabContainer() != null)
          i = i2 + this.c; 
      } 
    } else if (this.g.getVisibility() != 8) {
      i = this.g.getMeasuredHeight();
    } else {
      i = 0;
    } 
    this.A.set(this.y);
    int k = Build.VERSION.SDK_INT;
    if (k >= 21) {
      this.H = this.F;
    } else {
      this.D.set(this.B);
    } 
    if (!this.s && !j) {
      Rect rect = this.A;
      rect.top += i;
      rect.bottom += 0;
      if (k >= 21)
        this.H = this.H.b.l(0, i, 0, 0); 
    } else if (k >= 21) {
      le.d d1;
      le.e e;
      bb bb = bb.b(this.H.d(), this.H.f() + i, this.H.e(), this.H.c() + 0);
      le le1 = this.H;
      if (k >= 30) {
        d1 = new le.d(le1);
      } else {
        le.c c;
        if (k >= 29) {
          c = new le.c((le)d1);
        } else {
          le.b b;
          if (k >= 20) {
            b = new le.b((le)c);
          } else {
            e = new le.e((le)b);
          } 
        } 
      } 
      e.d(bb);
      this.H = e.b();
    } else {
      Rect rect = this.D;
      rect.top += i;
      rect.bottom += 0;
    } 
    j((View)this.f, this.A, true, true, true, true);
    if (k >= 21 && !this.I.equals(this.H)) {
      le le1 = this.H;
      this.I = le1;
      fe.e((View)this.f, le1);
    } else if (k < 21 && !this.E.equals(this.D)) {
      this.E.set(this.D);
      this.f.a(this.D);
    } 
    measureChildWithMargins((View)this.f, paramInt1, 0, paramInt2, 0);
    e e1 = (e)this.f.getLayoutParams();
    int i = Math.max(i1, this.f.getMeasuredWidth() + e1.leftMargin + e1.rightMargin);
    int j = Math.max(n, this.f.getMeasuredHeight() + e1.topMargin + e1.bottomMargin);
    k = View.combineMeasuredStates(m, this.f.getMeasuredState());
    m = getPaddingLeft();
    n = getPaddingRight();
    i1 = getPaddingTop();
    j = Math.max(getPaddingBottom() + i1 + j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(n + m + i, getSuggestedMinimumWidth()), paramInt1, k), View.resolveSizeAndState(j, paramInt2, k << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    boolean bool1 = this.u;
    boolean bool = false;
    if (bool1) {
      if (!paramBoolean)
        return false; 
      this.K.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
      if (this.K.getFinalY() > this.g.getHeight())
        bool = true; 
      if (bool) {
        k();
        this.O.run();
      } else {
        k();
        this.N.run();
      } 
      this.v = true;
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.w + paramInt2;
    this.w = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.P.a = paramInt;
    this.w = getActionBarHideOffset();
    k();
    d d1 = this.J;
    if (d1 != null) {
      d1 d11 = (d1)d1;
      u1 u1 = d11.w;
      if (u1 != null) {
        u1.a();
        d11.w = null;
      } 
    } 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.g.getVisibility() != 0) ? false : this.u;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.u && !this.v)
      if (this.w <= this.g.getHeight()) {
        k();
        postDelayed(this.N, 600L);
      } else {
        k();
        postDelayed(this.O, 600L);
      }  
    d d1 = this.J;
    if (d1 != null)
      Objects.requireNonNull((d1)d1); 
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  @Deprecated
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    boolean bool2;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    m();
    int i = this.x;
    this.x = paramInt;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    d d1 = this.J;
    if (d1 != null) {
      d1 d11;
      ((d1)d1).r = bool2 ^ true;
      if (bool1 || !bool2) {
        d11 = (d1)d1;
        if (d11.t) {
          d11.t = false;
          d11.D(true);
        } 
      } else {
        d11 = d11;
        if (!d11.t) {
          d11.t = true;
          d11.D(true);
        } 
      } 
    } 
    if (((i ^ paramInt) & 0x100) != 0 && this.J != null)
      fe.A((View)this); 
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.d = paramInt;
    d d1 = this.J;
    if (d1 != null)
      ((d1)d1).q = paramInt; 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    k();
    paramInt = Math.max(0, Math.min(paramInt, this.g.getHeight()));
    this.g.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.J = paramd;
    if (getWindowToken() != null) {
      paramd = this.J;
      int i = this.d;
      ((d1)paramd).q = i;
      i = this.x;
      if (i != 0) {
        onWindowSystemUiVisibilityChanged(i);
        fe.A((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.u) {
      this.u = paramBoolean;
      if (!paramBoolean) {
        k();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    m();
    this.p.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    m();
    this.p.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    m();
    this.p.o(paramInt);
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.s = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.r = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    m();
    this.p.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    m();
    this.p.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.L = null;
      actionBarOverlayLayout.v = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.L = null;
      actionBarOverlayLayout.v = false;
    }
  }
  
  public class b implements Runnable {
    public b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.b.k();
      ActionBarOverlayLayout actionBarOverlayLayout = this.b;
      actionBarOverlayLayout.L = actionBarOverlayLayout.g.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.b.M);
    }
  }
  
  public class c implements Runnable {
    public c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.b.k();
      ActionBarOverlayLayout actionBarOverlayLayout = this.b;
      actionBarOverlayLayout.L = actionBarOverlayLayout.g.animate().translationY(-this.b.g.getHeight()).setListener((Animator.AnimatorListener)this.b.M);
    }
  }
  
  public static interface d {}
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */