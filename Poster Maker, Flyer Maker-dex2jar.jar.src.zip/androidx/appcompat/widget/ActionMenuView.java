package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import c2;
import e2;
import i2;
import j2;
import s2;
import s30;
import s4;
import x1;

public class ActionMenuView extends LinearLayoutCompat implements c2.b, j2 {
  public c2 b;
  
  public Context c;
  
  public int d;
  
  public boolean f;
  
  public s2 g;
  
  public i2.a p;
  
  public c2.a q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public e v;
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.t = (int)(56.0F * f);
    this.u = (int)(f * 4.0F);
    this.c = paramContext;
    this.d = 0;
  }
  
  public static int g(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    c c = (c)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool2 = false;
    if (actionMenuItemView != null && actionMenuItemView.c()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int k = paramView.getMeasuredWidth();
      int j = k / paramInt1;
      paramInt2 = j;
      if (k % paramInt1 != 0)
        paramInt2 = j + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    boolean bool1 = bool2;
    if (!c.a) {
      bool1 = bool2;
      if (paramInt3 != 0)
        bool1 = true; 
    } 
    c.d = bool1;
    c.b = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  public boolean a(e2 parame2) {
    return this.b.performItemAction((MenuItem)parame2, 0);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof c;
  }
  
  public c d() {
    c c = new c(-2, -2);
    c.gravity = 16;
    return c;
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public c e(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      c c;
      if (paramLayoutParams instanceof c) {
        c = new c((c)paramLayoutParams);
      } else {
        c = new c((ViewGroup.LayoutParams)c);
      } 
      if (c.gravity <= 0)
        c.gravity = 16; 
      return c;
    } 
    return d();
  }
  
  public boolean f(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof a)
        i = false | ((a)view1).a(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof a)
        bool = i | ((a)view2).b(); 
    } 
    return bool;
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new c(getContext(), paramAttributeSet);
  }
  
  public LinearLayoutCompat.a generateLayoutParams(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  public Menu getMenu() {
    if (this.b == null) {
      Context context = getContext();
      c2 c21 = new c2(context);
      this.b = c21;
      c21.setCallback(new d(this));
      s2 s22 = new s2(context);
      this.g = s22;
      s22.w = true;
      s22.x = true;
      i2.a a1 = this.p;
      if (a1 == null)
        a1 = new b(); 
      ((x1)s22).g = a1;
      this.b.addMenuPresenter((i2)s22, this.c);
      s2 s21 = this.g;
      ((x1)s21).r = this;
      this.b = ((x1)s21).d;
    } 
    return (Menu)this.b;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    s2 s21 = this.g;
    s2.d d = s21.t;
    return (d != null) ? d.getDrawable() : (s21.v ? s21.u : null);
  }
  
  public int getPopupTheme() {
    return this.d;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public void initialize(c2 paramc2) {
    this.b = paramc2;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    s2 s21 = this.g;
    if (s21 != null) {
      s21.updateMenuView(false);
      if (this.g.e()) {
        this.g.c();
        this.g.f();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    s2 s21 = this.g;
    if (s21 != null)
      s21.a(); 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.r) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int j = getChildCount();
    int i = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    paramInt1 = m - getPaddingRight() - getPaddingLeft();
    paramBoolean = s4.a((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < j) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        c c = (c)view.getLayoutParams();
        if (c.a) {
          int i1;
          int n = view.getMeasuredWidth();
          paramInt4 = n;
          if (f(paramInt2))
            paramInt4 = n + k; 
          int i2 = view.getMeasuredHeight();
          if (paramBoolean) {
            i1 = getPaddingLeft() + c.leftMargin;
            n = i1 + paramInt4;
          } else {
            n = getWidth() - getPaddingRight() - c.rightMargin;
            i1 = n - paramInt4;
          } 
          int i3 = i - i2 / 2;
          view.layout(i1, i3, n, i2 + i3);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + c.leftMargin + c.rightMargin;
          f(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (j == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = m / 2 - paramInt1 / 2;
      paramInt4 = i - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= c.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2 - paramInt3, i1, paramInt2, n + i1);
            paramInt3 = paramInt2 - paramInt3 + c.leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += c.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2, i1, paramInt2 + paramInt3, n + i1);
            paramInt3 = s30.c(paramInt3, c.rightMargin, paramInt4, paramInt2);
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Z
    //   4: istore #25
    //   6: iload_1
    //   7: invokestatic getMode : (I)I
    //   10: ldc 1073741824
    //   12: if_icmpne -> 21
    //   15: iconst_1
    //   16: istore #24
    //   18: goto -> 24
    //   21: iconst_0
    //   22: istore #24
    //   24: aload_0
    //   25: iload #24
    //   27: putfield r : Z
    //   30: iload #25
    //   32: iload #24
    //   34: if_icmpeq -> 42
    //   37: aload_0
    //   38: iconst_0
    //   39: putfield s : I
    //   42: iload_1
    //   43: invokestatic getSize : (I)I
    //   46: istore #6
    //   48: aload_0
    //   49: getfield r : Z
    //   52: ifeq -> 87
    //   55: aload_0
    //   56: getfield b : Lc2;
    //   59: astore #34
    //   61: aload #34
    //   63: ifnull -> 87
    //   66: iload #6
    //   68: aload_0
    //   69: getfield s : I
    //   72: if_icmpeq -> 87
    //   75: aload_0
    //   76: iload #6
    //   78: putfield s : I
    //   81: aload #34
    //   83: iconst_1
    //   84: invokevirtual onItemsChanged : (Z)V
    //   87: aload_0
    //   88: invokevirtual getChildCount : ()I
    //   91: istore #7
    //   93: aload_0
    //   94: getfield r : Z
    //   97: ifeq -> 1333
    //   100: iload #7
    //   102: ifle -> 1333
    //   105: iload_2
    //   106: invokestatic getMode : (I)I
    //   109: istore #20
    //   111: iload_1
    //   112: invokestatic getSize : (I)I
    //   115: istore_1
    //   116: iload_2
    //   117: invokestatic getSize : (I)I
    //   120: istore #6
    //   122: aload_0
    //   123: invokevirtual getPaddingLeft : ()I
    //   126: istore #7
    //   128: aload_0
    //   129: invokevirtual getPaddingRight : ()I
    //   132: istore #8
    //   134: aload_0
    //   135: invokevirtual getPaddingTop : ()I
    //   138: istore #9
    //   140: aload_0
    //   141: invokevirtual getPaddingBottom : ()I
    //   144: iload #9
    //   146: iadd
    //   147: istore #14
    //   149: iload_2
    //   150: iload #14
    //   152: bipush #-2
    //   154: invokestatic getChildMeasureSpec : (III)I
    //   157: istore #21
    //   159: iload_1
    //   160: iload #8
    //   162: iload #7
    //   164: iadd
    //   165: isub
    //   166: istore #10
    //   168: aload_0
    //   169: getfield t : I
    //   172: istore_2
    //   173: iload #10
    //   175: iload_2
    //   176: idiv
    //   177: istore_1
    //   178: iload_1
    //   179: ifne -> 190
    //   182: aload_0
    //   183: iload #10
    //   185: iconst_0
    //   186: invokevirtual setMeasuredDimension : (II)V
    //   189: return
    //   190: iload #10
    //   192: iload_2
    //   193: irem
    //   194: iload_1
    //   195: idiv
    //   196: iload_2
    //   197: iadd
    //   198: istore #22
    //   200: aload_0
    //   201: invokevirtual getChildCount : ()I
    //   204: istore #23
    //   206: iconst_0
    //   207: istore #12
    //   209: iconst_0
    //   210: istore #8
    //   212: iconst_0
    //   213: istore #11
    //   215: iconst_0
    //   216: istore_2
    //   217: iconst_0
    //   218: istore #13
    //   220: iconst_0
    //   221: istore #7
    //   223: lconst_0
    //   224: lstore #26
    //   226: iload #13
    //   228: iload #23
    //   230: if_icmpge -> 491
    //   233: aload_0
    //   234: iload #13
    //   236: invokevirtual getChildAt : (I)Landroid/view/View;
    //   239: astore #34
    //   241: aload #34
    //   243: invokevirtual getVisibility : ()I
    //   246: bipush #8
    //   248: if_icmpne -> 254
    //   251: goto -> 482
    //   254: aload #34
    //   256: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   259: istore #24
    //   261: iload #12
    //   263: iconst_1
    //   264: iadd
    //   265: istore #12
    //   267: iload #24
    //   269: ifeq -> 292
    //   272: aload_0
    //   273: getfield u : I
    //   276: istore #9
    //   278: aload #34
    //   280: iload #9
    //   282: iconst_0
    //   283: iload #9
    //   285: iconst_0
    //   286: invokevirtual setPadding : (IIII)V
    //   289: goto -> 292
    //   292: aload #34
    //   294: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   297: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   300: astore #35
    //   302: aload #35
    //   304: iconst_0
    //   305: putfield f : Z
    //   308: aload #35
    //   310: iconst_0
    //   311: putfield c : I
    //   314: aload #35
    //   316: iconst_0
    //   317: putfield b : I
    //   320: aload #35
    //   322: iconst_0
    //   323: putfield d : Z
    //   326: aload #35
    //   328: iconst_0
    //   329: putfield leftMargin : I
    //   332: aload #35
    //   334: iconst_0
    //   335: putfield rightMargin : I
    //   338: iload #24
    //   340: ifeq -> 360
    //   343: aload #34
    //   345: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   348: invokevirtual c : ()Z
    //   351: ifeq -> 360
    //   354: iconst_1
    //   355: istore #24
    //   357: goto -> 363
    //   360: iconst_0
    //   361: istore #24
    //   363: aload #35
    //   365: iload #24
    //   367: putfield e : Z
    //   370: aload #35
    //   372: getfield a : Z
    //   375: ifeq -> 384
    //   378: iconst_1
    //   379: istore #9
    //   381: goto -> 387
    //   384: iload_1
    //   385: istore #9
    //   387: aload #34
    //   389: iload #22
    //   391: iload #9
    //   393: iload #21
    //   395: iload #14
    //   397: invokestatic g : (Landroid/view/View;IIII)I
    //   400: istore #15
    //   402: iload #11
    //   404: iload #15
    //   406: invokestatic max : (II)I
    //   409: istore #11
    //   411: iload_2
    //   412: istore #9
    //   414: aload #35
    //   416: getfield d : Z
    //   419: ifeq -> 427
    //   422: iload_2
    //   423: iconst_1
    //   424: iadd
    //   425: istore #9
    //   427: aload #35
    //   429: getfield a : Z
    //   432: ifeq -> 438
    //   435: iconst_1
    //   436: istore #7
    //   438: iload_1
    //   439: iload #15
    //   441: isub
    //   442: istore_1
    //   443: iload #8
    //   445: aload #34
    //   447: invokevirtual getMeasuredHeight : ()I
    //   450: invokestatic max : (II)I
    //   453: istore #8
    //   455: lload #26
    //   457: lstore #28
    //   459: iload #15
    //   461: iconst_1
    //   462: if_icmpne -> 475
    //   465: lload #26
    //   467: iconst_1
    //   468: iload #13
    //   470: ishl
    //   471: i2l
    //   472: lor
    //   473: lstore #28
    //   475: lload #28
    //   477: lstore #26
    //   479: iload #9
    //   481: istore_2
    //   482: iload #13
    //   484: iconst_1
    //   485: iadd
    //   486: istore #13
    //   488: goto -> 226
    //   491: iload #7
    //   493: ifeq -> 508
    //   496: iload #12
    //   498: iconst_2
    //   499: if_icmpne -> 508
    //   502: iconst_1
    //   503: istore #9
    //   505: goto -> 511
    //   508: iconst_0
    //   509: istore #9
    //   511: iconst_0
    //   512: istore #15
    //   514: iload_2
    //   515: istore #14
    //   517: iload_1
    //   518: istore #13
    //   520: iload #15
    //   522: istore_2
    //   523: iload #8
    //   525: istore_1
    //   526: iload #14
    //   528: ifle -> 854
    //   531: iload #13
    //   533: ifle -> 854
    //   536: ldc_w 2147483647
    //   539: istore #15
    //   541: iconst_0
    //   542: istore #17
    //   544: iconst_0
    //   545: istore #16
    //   547: lconst_0
    //   548: lstore #30
    //   550: iload_2
    //   551: istore #8
    //   553: iload #17
    //   555: iload #23
    //   557: if_icmpge -> 681
    //   560: aload_0
    //   561: iload #17
    //   563: invokevirtual getChildAt : (I)Landroid/view/View;
    //   566: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   569: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   572: astore #34
    //   574: aload #34
    //   576: getfield d : Z
    //   579: ifne -> 596
    //   582: iload #15
    //   584: istore #18
    //   586: iload #16
    //   588: istore_2
    //   589: lload #30
    //   591: lstore #28
    //   593: goto -> 661
    //   596: aload #34
    //   598: getfield b : I
    //   601: istore #19
    //   603: iload #19
    //   605: iload #15
    //   607: if_icmpge -> 625
    //   610: lconst_1
    //   611: iload #17
    //   613: lshl
    //   614: lstore #28
    //   616: iload #19
    //   618: istore #18
    //   620: iconst_1
    //   621: istore_2
    //   622: goto -> 661
    //   625: iload #15
    //   627: istore #18
    //   629: iload #16
    //   631: istore_2
    //   632: lload #30
    //   634: lstore #28
    //   636: iload #19
    //   638: iload #15
    //   640: if_icmpne -> 661
    //   643: iload #16
    //   645: iconst_1
    //   646: iadd
    //   647: istore_2
    //   648: lload #30
    //   650: lconst_1
    //   651: iload #17
    //   653: lshl
    //   654: lor
    //   655: lstore #28
    //   657: iload #15
    //   659: istore #18
    //   661: iload #17
    //   663: iconst_1
    //   664: iadd
    //   665: istore #17
    //   667: iload #18
    //   669: istore #15
    //   671: iload_2
    //   672: istore #16
    //   674: lload #28
    //   676: lstore #30
    //   678: goto -> 553
    //   681: iload_1
    //   682: istore_2
    //   683: iload #8
    //   685: istore_1
    //   686: lload #26
    //   688: lload #30
    //   690: lor
    //   691: lstore #26
    //   693: iload #16
    //   695: iload #13
    //   697: if_icmple -> 703
    //   700: goto -> 862
    //   703: iconst_0
    //   704: istore_1
    //   705: iload_1
    //   706: iload #23
    //   708: if_icmpge -> 847
    //   711: aload_0
    //   712: iload_1
    //   713: invokevirtual getChildAt : (I)Landroid/view/View;
    //   716: astore #34
    //   718: aload #34
    //   720: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   723: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   726: astore #35
    //   728: iconst_1
    //   729: iload_1
    //   730: ishl
    //   731: i2l
    //   732: lstore #32
    //   734: lload #30
    //   736: lload #32
    //   738: land
    //   739: lconst_0
    //   740: lcmp
    //   741: ifne -> 774
    //   744: lload #26
    //   746: lstore #28
    //   748: aload #35
    //   750: getfield b : I
    //   753: iload #15
    //   755: iconst_1
    //   756: iadd
    //   757: if_icmpne -> 767
    //   760: lload #26
    //   762: lload #32
    //   764: lor
    //   765: lstore #28
    //   767: lload #28
    //   769: lstore #26
    //   771: goto -> 840
    //   774: iload #9
    //   776: ifeq -> 816
    //   779: aload #35
    //   781: getfield e : Z
    //   784: ifeq -> 816
    //   787: iload #13
    //   789: iconst_1
    //   790: if_icmpne -> 816
    //   793: aload_0
    //   794: getfield u : I
    //   797: istore #8
    //   799: aload #34
    //   801: iload #8
    //   803: iload #22
    //   805: iadd
    //   806: iconst_0
    //   807: iload #8
    //   809: iconst_0
    //   810: invokevirtual setPadding : (IIII)V
    //   813: goto -> 816
    //   816: aload #35
    //   818: aload #35
    //   820: getfield b : I
    //   823: iconst_1
    //   824: iadd
    //   825: putfield b : I
    //   828: aload #35
    //   830: iconst_1
    //   831: putfield f : Z
    //   834: iload #13
    //   836: iconst_1
    //   837: isub
    //   838: istore #13
    //   840: iload_1
    //   841: iconst_1
    //   842: iadd
    //   843: istore_1
    //   844: goto -> 705
    //   847: iload_2
    //   848: istore_1
    //   849: iconst_1
    //   850: istore_2
    //   851: goto -> 526
    //   854: iload_2
    //   855: istore #8
    //   857: iload_1
    //   858: istore_2
    //   859: iload #8
    //   861: istore_1
    //   862: iload #7
    //   864: ifne -> 879
    //   867: iload #12
    //   869: iconst_1
    //   870: if_icmpne -> 879
    //   873: iconst_1
    //   874: istore #7
    //   876: goto -> 882
    //   879: iconst_0
    //   880: istore #7
    //   882: iload_1
    //   883: istore #8
    //   885: iload #13
    //   887: ifle -> 1238
    //   890: iload_1
    //   891: istore #8
    //   893: lload #26
    //   895: lconst_0
    //   896: lcmp
    //   897: ifeq -> 1238
    //   900: iload #13
    //   902: iload #12
    //   904: iconst_1
    //   905: isub
    //   906: if_icmplt -> 923
    //   909: iload #7
    //   911: ifne -> 923
    //   914: iload_1
    //   915: istore #8
    //   917: iload #11
    //   919: iconst_1
    //   920: if_icmple -> 1238
    //   923: lload #26
    //   925: invokestatic bitCount : (J)I
    //   928: i2f
    //   929: fstore #5
    //   931: fload #5
    //   933: fstore #4
    //   935: iload #7
    //   937: ifne -> 1029
    //   940: fload #5
    //   942: fstore_3
    //   943: lload #26
    //   945: lconst_1
    //   946: land
    //   947: lconst_0
    //   948: lcmp
    //   949: ifeq -> 979
    //   952: fload #5
    //   954: fstore_3
    //   955: aload_0
    //   956: iconst_0
    //   957: invokevirtual getChildAt : (I)Landroid/view/View;
    //   960: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   963: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   966: getfield e : Z
    //   969: ifne -> 979
    //   972: fload #5
    //   974: ldc_w 0.5
    //   977: fsub
    //   978: fstore_3
    //   979: iload #23
    //   981: iconst_1
    //   982: isub
    //   983: istore #7
    //   985: fload_3
    //   986: fstore #4
    //   988: lload #26
    //   990: iconst_1
    //   991: iload #7
    //   993: ishl
    //   994: i2l
    //   995: land
    //   996: lconst_0
    //   997: lcmp
    //   998: ifeq -> 1029
    //   1001: fload_3
    //   1002: fstore #4
    //   1004: aload_0
    //   1005: iload #7
    //   1007: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1010: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1013: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1016: getfield e : Z
    //   1019: ifne -> 1029
    //   1022: fload_3
    //   1023: ldc_w 0.5
    //   1026: fsub
    //   1027: fstore #4
    //   1029: fload #4
    //   1031: fconst_0
    //   1032: fcmpl
    //   1033: ifle -> 1051
    //   1036: iload #13
    //   1038: iload #22
    //   1040: imul
    //   1041: i2f
    //   1042: fload #4
    //   1044: fdiv
    //   1045: f2i
    //   1046: istore #7
    //   1048: goto -> 1054
    //   1051: iconst_0
    //   1052: istore #7
    //   1054: iconst_0
    //   1055: istore #9
    //   1057: iload_1
    //   1058: istore #8
    //   1060: iload #9
    //   1062: iload #23
    //   1064: if_icmpge -> 1238
    //   1067: lload #26
    //   1069: iconst_1
    //   1070: iload #9
    //   1072: ishl
    //   1073: i2l
    //   1074: land
    //   1075: lconst_0
    //   1076: lcmp
    //   1077: ifne -> 1086
    //   1080: iload_1
    //   1081: istore #8
    //   1083: goto -> 1226
    //   1086: aload_0
    //   1087: iload #9
    //   1089: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1092: astore #34
    //   1094: aload #34
    //   1096: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1099: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1102: astore #35
    //   1104: aload #34
    //   1106: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   1109: ifeq -> 1151
    //   1112: aload #35
    //   1114: iload #7
    //   1116: putfield c : I
    //   1119: aload #35
    //   1121: iconst_1
    //   1122: putfield f : Z
    //   1125: iload #9
    //   1127: ifne -> 1148
    //   1130: aload #35
    //   1132: getfield e : Z
    //   1135: ifne -> 1148
    //   1138: aload #35
    //   1140: iload #7
    //   1142: ineg
    //   1143: iconst_2
    //   1144: idiv
    //   1145: putfield leftMargin : I
    //   1148: goto -> 1182
    //   1151: aload #35
    //   1153: getfield a : Z
    //   1156: ifeq -> 1188
    //   1159: aload #35
    //   1161: iload #7
    //   1163: putfield c : I
    //   1166: aload #35
    //   1168: iconst_1
    //   1169: putfield f : Z
    //   1172: aload #35
    //   1174: iload #7
    //   1176: ineg
    //   1177: iconst_2
    //   1178: idiv
    //   1179: putfield rightMargin : I
    //   1182: iconst_1
    //   1183: istore #8
    //   1185: goto -> 1226
    //   1188: iload #9
    //   1190: ifeq -> 1202
    //   1193: aload #35
    //   1195: iload #7
    //   1197: iconst_2
    //   1198: idiv
    //   1199: putfield leftMargin : I
    //   1202: iload_1
    //   1203: istore #8
    //   1205: iload #9
    //   1207: iload #23
    //   1209: iconst_1
    //   1210: isub
    //   1211: if_icmpeq -> 1226
    //   1214: aload #35
    //   1216: iload #7
    //   1218: iconst_2
    //   1219: idiv
    //   1220: putfield rightMargin : I
    //   1223: iload_1
    //   1224: istore #8
    //   1226: iload #9
    //   1228: iconst_1
    //   1229: iadd
    //   1230: istore #9
    //   1232: iload #8
    //   1234: istore_1
    //   1235: goto -> 1057
    //   1238: iload #8
    //   1240: ifeq -> 1312
    //   1243: iconst_0
    //   1244: istore_1
    //   1245: iload_1
    //   1246: iload #23
    //   1248: if_icmpge -> 1312
    //   1251: aload_0
    //   1252: iload_1
    //   1253: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1256: astore #34
    //   1258: aload #34
    //   1260: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1263: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1266: astore #35
    //   1268: aload #35
    //   1270: getfield f : Z
    //   1273: ifne -> 1279
    //   1276: goto -> 1305
    //   1279: aload #34
    //   1281: aload #35
    //   1283: getfield b : I
    //   1286: iload #22
    //   1288: imul
    //   1289: aload #35
    //   1291: getfield c : I
    //   1294: iadd
    //   1295: ldc 1073741824
    //   1297: invokestatic makeMeasureSpec : (II)I
    //   1300: iload #21
    //   1302: invokevirtual measure : (II)V
    //   1305: iload_1
    //   1306: iconst_1
    //   1307: iadd
    //   1308: istore_1
    //   1309: goto -> 1245
    //   1312: iload #20
    //   1314: ldc 1073741824
    //   1316: if_icmpeq -> 1322
    //   1319: goto -> 1325
    //   1322: iload #6
    //   1324: istore_2
    //   1325: aload_0
    //   1326: iload #10
    //   1328: iload_2
    //   1329: invokevirtual setMeasuredDimension : (II)V
    //   1332: return
    //   1333: iconst_0
    //   1334: istore #6
    //   1336: iload #6
    //   1338: iload #7
    //   1340: if_icmpge -> 1378
    //   1343: aload_0
    //   1344: iload #6
    //   1346: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1349: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1352: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1355: astore #34
    //   1357: aload #34
    //   1359: iconst_0
    //   1360: putfield rightMargin : I
    //   1363: aload #34
    //   1365: iconst_0
    //   1366: putfield leftMargin : I
    //   1369: iload #6
    //   1371: iconst_1
    //   1372: iadd
    //   1373: istore #6
    //   1375: goto -> 1336
    //   1378: aload_0
    //   1379: iload_1
    //   1380: iload_2
    //   1381: invokespecial onMeasure : (II)V
    //   1384: return
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.g.B = paramBoolean;
  }
  
  public void setOnMenuItemClickListener(e parame) {
    this.v = parame;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    s2 s21 = this.g;
    s2.d d = s21.t;
    if (d != null) {
      d.setImageDrawable(paramDrawable);
      return;
    } 
    s21.v = true;
    s21.u = paramDrawable;
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.d != paramInt) {
      this.d = paramInt;
      if (paramInt == 0) {
        this.c = getContext();
        return;
      } 
      this.c = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(s2 params2) {
    this.g = params2;
    ((x1)params2).r = this;
    this.b = ((x1)params2).d;
  }
  
  public static interface a {
    boolean a();
    
    boolean b();
  }
  
  public static class b implements i2.a {
    public boolean a(c2 param1c2) {
      return false;
    }
    
    public void onCloseMenu(c2 param1c2, boolean param1Boolean) {}
  }
  
  public static class c extends LinearLayoutCompat.a {
    @ExportedProperty
    public boolean a;
    
    @ExportedProperty
    public int b;
    
    @ExportedProperty
    public int c;
    
    @ExportedProperty
    public boolean d;
    
    @ExportedProperty
    public boolean e;
    
    public boolean f;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = false;
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(c param1c) {
      super((ViewGroup.LayoutParams)param1c);
      this.a = param1c.a;
    }
  }
  
  public class d implements c2.a {
    public d(ActionMenuView this$0) {}
    
    public boolean onMenuItemSelected(c2 param1c2, MenuItem param1MenuItem) {
      ActionMenuView.e e = this.b.v;
      if (e != null) {
        boolean bool;
        e = e;
        if (((Toolbar.a)e).a.mMenuHostHelper.d(param1MenuItem)) {
          bool = true;
        } else {
          Toolbar.f f = ((Toolbar.a)e).a.mOnMenuItemClickListener;
          if (f != null) {
            bool = f.onMenuItemClick(param1MenuItem);
          } else {
            bool = false;
          } 
        } 
        if (bool)
          return true; 
      } 
      return false;
    }
    
    public void onMenuModeChange(c2 param1c2) {
      c2.a a1 = this.b.q;
      if (a1 != null)
        a1.onMenuModeChange(param1c2); 
    }
  }
  
  public static interface e {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */