package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import qj;
import rn;
import s30;
import tj;
import tn;
import vj;
import wj;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements tj {
  public final tn a;
  
  public Recreator(tn paramtn) {
    this.a = paramtn;
  }
  
  public void c(vj paramvj, qj.a parama) {
    if (parama == qj.a.ON_CREATE) {
      wj wj = (wj)paramvj.getLifecycle();
      wj.d("removeObserver");
      wj.a.e(this);
      Bundle bundle = this.a.getSavedStateRegistry().a("androidx.savedstate.Restarter");
      if (bundle == null)
        return; 
      ArrayList arrayList = bundle.getStringArrayList("classes_to_restore");
      if (arrayList != null) {
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
          String str = iterator.next();
          try {
            Class<? extends rn.a> clazz = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(rn.a.class);
            try {
              Constructor<? extends rn.a> constructor = clazz.getDeclaredConstructor(new Class[0]);
              constructor.setAccessible(true);
              try {
                rn.a a1 = constructor.newInstance(new Object[0]);
                a1.a(this.a);
              } catch (Exception exception) {
                throw new RuntimeException(s30.g0("Failed to instantiate ", str), exception);
              } 
            } catch (NoSuchMethodException noSuchMethodException) {
              StringBuilder stringBuilder = s30.x0("Class");
              stringBuilder.append(exception.getSimpleName());
              stringBuilder.append(" must have default constructor in order to be automatically recreated");
              throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
            } 
          } catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException(s30.h0("Class ", noSuchMethodException, " wasn't found"), classNotFoundException);
          } 
        } 
        return;
      } 
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    } 
    AssertionError assertionError = new AssertionError("Next event must be ON_CREATE");
    throw assertionError;
  }
  
  public static final class a implements rn.b {
    public final Set<String> a = new HashSet<String>();
    
    public a(rn param1rn) {
      param1rn.b("androidx.savedstate.Restarter", this);
    }
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      bundle.putStringArrayList("classes_to_restore", new ArrayList<String>(this.a));
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */