package androidx.savedstate;

import qj;
import rn;
import tj;
import vj;

public class SavedStateRegistry$1 implements tj {
  public SavedStateRegistry$1(rn paramrn) {}
  
  public void c(vj paramvj, qj.a parama) {
    if (parama == qj.a.ON_START) {
      this.a.e = true;
      return;
    } 
    if (parama == qj.a.ON_STOP)
      this.a.e = false; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\savedstate\SavedStateRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */