package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import dh;
import di;
import eh;
import fe;
import fh;
import java.util.ArrayList;
import ki;
import le;
import ni;
import s30;

public final class FragmentContainerView extends FrameLayout {
  public ArrayList<View> b;
  
  public ArrayList<View> c;
  
  public View.OnApplyWindowInsetsListener d;
  
  public boolean f = true;
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    if (paramAttributeSet != null) {
      String str1;
      String str2;
      String str3 = paramAttributeSet.getClassAttribute();
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, eh.FragmentContainerView);
      if (str3 == null) {
        str1 = typedArray.getString(eh.FragmentContainerView_android_name);
        str2 = "android:name";
      } else {
        str2 = "class";
        str1 = str3;
      } 
      typedArray.recycle();
      if (str1 != null) {
        if (isInEditMode())
          return; 
        throw new UnsupportedOperationException(s30.j0("FragmentContainerView must be within a FragmentActivity to use ", str2, "=\"", str1, "\""));
      } 
    } 
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, di paramdi) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, eh.FragmentContainerView);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(eh.FragmentContainerView_android_name); 
    str2 = typedArray.getString(eh.FragmentContainerView_android_tag);
    typedArray.recycle();
    int i = getId();
    Fragment fragment = paramdi.H(i);
    if (str1 != null && fragment == null) {
      String str;
      if (i <= 0) {
        if (str2 != null) {
          str = s30.g0(" with tag ", str2);
        } else {
          str = "";
        } 
        throw new IllegalStateException(s30.h0("FragmentContainerView must have an android:id to add Fragment ", str1, str));
      } 
      Fragment fragment1 = paramdi.M().a(str.getClassLoader(), str1);
      fragment1.onInflate((Context)str, paramAttributeSet, (Bundle)null);
      fh fh = new fh(paramdi);
      ((ni)fh).p = true;
      fragment1.mContainer = (ViewGroup)this;
      fh.g(getId(), fragment1, str2, 1);
      fh.f();
    } 
    for (ki ki : paramdi.c.f()) {
      Fragment fragment1 = ki.c;
      if (fragment1.mContainerId == getId()) {
        View view = fragment1.mView;
        if (view != null && view.getParent() == null) {
          fragment1.mContainer = (ViewGroup)this;
          ki.b();
        } 
      } 
    } 
  }
  
  public final void a(View paramView) {
    ArrayList<View> arrayList = this.c;
    if (arrayList != null && arrayList.contains(paramView)) {
      if (this.b == null)
        this.b = new ArrayList<View>(); 
      this.b.add(paramView);
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    Object object = paramView.getTag(dh.fragment_container_view_tag);
    if (object instanceof Fragment) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    Object object = paramView.getTag(dh.fragment_container_view_tag);
    if (object instanceof Fragment) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null)
      return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    le le = le.l(paramWindowInsets, null);
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.d;
    if (onApplyWindowInsetsListener != null) {
      le = le.k(onApplyWindowInsetsListener.onApplyWindowInsets((View)this, paramWindowInsets));
    } else {
      le = fe.v((View)this, le);
    } 
    if (!le.h()) {
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        fe.e(getChildAt(i), le); 
    } 
    return paramWindowInsets;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (this.f && this.b != null)
      for (int i = 0; i < this.b.size(); i++)
        super.drawChild(paramCanvas, this.b.get(i), getDrawingTime());  
    super.dispatchDraw(paramCanvas);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.f) {
      ArrayList<View> arrayList = this.b;
      if (arrayList != null && arrayList.size() > 0 && this.b.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    ArrayList<View> arrayList = this.c;
    if (arrayList != null) {
      arrayList.remove(paramView);
      arrayList = this.b;
      if (arrayList != null && arrayList.remove(paramView))
        this.f = true; 
    } 
    super.endViewTransition(paramView);
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      a(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean) {
    if (paramBoolean)
      a(paramView); 
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeView(View paramView) {
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    a(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    this.d = paramOnApplyWindowInsetsListener;
  }
  
  public void startViewTransition(View paramView) {
    if (paramView.getParent() == this) {
      if (this.c == null)
        this.c = new ArrayList<View>(); 
      this.c.add(paramView);
    } 
    super.startViewTransition(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\fragment\app\FragmentContainerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */