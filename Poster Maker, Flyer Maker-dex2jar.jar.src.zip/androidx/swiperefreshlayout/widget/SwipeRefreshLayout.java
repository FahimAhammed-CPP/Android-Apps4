package androidx.swiperefreshlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import fe;
import java.util.Objects;
import lo;
import ma;
import oo;
import pd;
import po;
import qd;
import td;
import ud;

public class SwipeRefreshLayout extends ViewGroup implements td, pd {
  public static final String b = SwipeRefreshLayout.class.getSimpleName();
  
  public static final int[] c = new int[] { 16842766 };
  
  public float A;
  
  public boolean B;
  
  public int C = -1;
  
  public final DecelerateInterpolator D;
  
  public lo E;
  
  public int F = -1;
  
  public int G;
  
  public int H;
  
  public int I;
  
  public int J;
  
  public oo K;
  
  public Animation L;
  
  public Animation M;
  
  public Animation N;
  
  public Animation O;
  
  public boolean P;
  
  public int Q;
  
  public g R;
  
  public Animation.AnimationListener S = new a(this);
  
  public final Animation T = new e(this);
  
  public final Animation U = new f(this);
  
  public View d;
  
  public h f;
  
  public boolean g = false;
  
  public int p;
  
  public float q = -1.0F;
  
  public float r;
  
  public final ud s;
  
  public final qd t;
  
  public final int[] u = new int[2];
  
  public final int[] v = new int[2];
  
  public boolean w;
  
  public int x;
  
  public int y;
  
  public float z;
  
  public SwipeRefreshLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.p = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    this.x = getResources().getInteger(17694721);
    setWillNotDraw(false);
    this.D = new DecelerateInterpolator(2.0F);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    this.Q = (int)(displayMetrics.density * 40.0F);
    this.E = new lo(getContext(), -328966);
    oo oo1 = new oo(getContext());
    this.K = oo1;
    oo1.c(1);
    this.E.setImageDrawable((Drawable)this.K);
    this.E.setVisibility(8);
    addView((View)this.E);
    setChildrenDrawingOrderEnabled(true);
    int i = (int)(displayMetrics.density * 64.0F);
    this.I = i;
    this.q = i;
    this.s = new ud();
    this.t = new qd((View)this);
    setNestedScrollingEnabled(true);
    i = -this.Q;
    this.y = i;
    this.H = i;
    f(1.0F);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c);
    setEnabled(typedArray.getBoolean(0, true));
    typedArray.recycle();
  }
  
  private void setColorViewAlpha(int paramInt) {
    this.E.getBackground().setAlpha(paramInt);
    oo oo1 = this.K;
    oo1.f.t = paramInt;
    oo1.invalidateSelf();
  }
  
  public boolean a() {
    g g1 = this.R;
    if (g1 != null)
      return g1.a(this, this.d); 
    View view = this.d;
    return (view instanceof ListView) ? ((ListView)view).canScrollList(-1) : view.canScrollVertically(-1);
  }
  
  public final void b() {
    if (this.d == null)
      for (int i = 0; i < getChildCount(); i++) {
        View view = getChildAt(i);
        if (!view.equals(this.E)) {
          this.d = view;
          return;
        } 
      }  
  }
  
  public final void c(float paramFloat) {
    if (paramFloat > this.q) {
      i(true, true);
      return;
    } 
    this.g = false;
    oo oo2 = this.K;
    oo.a a2 = oo2.f;
    a2.e = 0.0F;
    a2.f = 0.0F;
    oo2.invalidateSelf();
    d d = new d(this);
    this.G = this.y;
    this.U.reset();
    this.U.setDuration(200L);
    this.U.setInterpolator((Interpolator)this.D);
    lo lo1 = this.E;
    lo1.b = d;
    lo1.clearAnimation();
    this.E.startAnimation(this.U);
    oo oo1 = this.K;
    oo.a a1 = oo1.f;
    if (a1.n)
      a1.n = false; 
    oo1.invalidateSelf();
  }
  
  public final boolean d(Animation paramAnimation) {
    return (paramAnimation != null && paramAnimation.hasStarted() && !paramAnimation.hasEnded());
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.t.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.t.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return this.t.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.t.d(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public final void e(float paramFloat) {
    oo oo1 = this.K;
    oo.a a = oo1.f;
    if (a.n != true)
      a.n = true; 
    oo1.invalidateSelf();
    float f2 = Math.min(1.0F, Math.abs(paramFloat / this.q));
    double d1 = f2;
    Double.isNaN(d1);
    Double.isNaN(d1);
    float f1 = (float)Math.max(d1 - 0.4D, 0.0D) * 5.0F / 3.0F;
    float f4 = Math.abs(paramFloat);
    float f5 = this.q;
    int i = this.J;
    if (i <= 0)
      i = this.I; 
    float f3 = i;
    d1 = (Math.max(0.0F, Math.min(f4 - f5, f3 * 2.0F) / f3) / 4.0F);
    double d2 = Math.pow(d1, 2.0D);
    Double.isNaN(d1);
    Double.isNaN(d1);
    f4 = (float)(d1 - d2) * 2.0F;
    i = this.H;
    int j = (int)(f3 * f2 + f3 * f4 * 2.0F);
    if (this.E.getVisibility() != 0)
      this.E.setVisibility(0); 
    this.E.setScaleX(1.0F);
    this.E.setScaleY(1.0F);
    if (paramFloat < this.q) {
      if (this.K.f.t > 76 && !d(this.N))
        this.N = j(this.K.f.t, 76); 
    } else if (this.K.f.t < 255 && !d(this.O)) {
      this.O = j(this.K.f.t, 255);
    } 
    oo1 = this.K;
    paramFloat = Math.min(0.8F, f1 * 0.8F);
    a = oo1.f;
    a.e = 0.0F;
    a.f = paramFloat;
    oo1.invalidateSelf();
    oo1 = this.K;
    paramFloat = Math.min(1.0F, f1);
    a = oo1.f;
    if (paramFloat != a.p)
      a.p = paramFloat; 
    oo1.invalidateSelf();
    oo1 = this.K;
    oo1.f.g = (f4 * 2.0F + f1 * 0.4F - 0.25F) * 0.5F;
    oo1.invalidateSelf();
    setTargetOffsetTopAndBottom(i + j - this.y);
  }
  
  public void f(float paramFloat) {
    int i = this.G;
    setTargetOffsetTopAndBottom(i + (int)((this.H - i) * paramFloat) - this.E.getTop());
  }
  
  public final void g(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.C) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.C = paramMotionEvent.getPointerId(i);
    } 
  }
  
  public int getChildDrawingOrder(int paramInt1, int paramInt2) {
    int i = this.F;
    if (i < 0)
      return paramInt2; 
    if (paramInt2 == paramInt1 - 1)
      return i; 
    paramInt1 = paramInt2;
    if (paramInt2 >= i)
      paramInt1 = paramInt2 + 1; 
    return paramInt1;
  }
  
  public int getNestedScrollAxes() {
    return this.s.a();
  }
  
  public int getProgressCircleDiameter() {
    return this.Q;
  }
  
  public int getProgressViewEndOffset() {
    return this.I;
  }
  
  public int getProgressViewStartOffset() {
    return this.H;
  }
  
  public void h() {
    this.E.clearAnimation();
    this.K.stop();
    this.E.setVisibility(8);
    setColorViewAlpha(255);
    setTargetOffsetTopAndBottom(this.H - this.y);
    this.y = this.E.getTop();
  }
  
  public boolean hasNestedScrollingParent() {
    return this.t.g(0);
  }
  
  public final void i(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.g != paramBoolean1) {
      this.P = paramBoolean2;
      b();
      this.g = paramBoolean1;
      if (paramBoolean1) {
        int i = this.y;
        Animation.AnimationListener animationListener = this.S;
        this.G = i;
        this.T.reset();
        this.T.setDuration(200L);
        this.T.setInterpolator((Interpolator)this.D);
        if (animationListener != null)
          this.E.b = animationListener; 
        this.E.clearAnimation();
        this.E.startAnimation(this.T);
        return;
      } 
      l(this.S);
    } 
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.t.d;
  }
  
  public final Animation j(int paramInt1, int paramInt2) {
    c c = new c(this, paramInt1, paramInt2);
    c.setDuration(300L);
    lo lo1 = this.E;
    lo1.b = null;
    lo1.clearAnimation();
    this.E.startAnimation(c);
    return c;
  }
  
  public final void k(float paramFloat) {
    float f = this.A;
    int i = this.p;
    if (paramFloat - f > i && !this.B) {
      this.z = f + i;
      this.B = true;
      this.K.setAlpha(76);
    } 
  }
  
  public void l(Animation.AnimationListener paramAnimationListener) {
    b b = new b(this);
    this.M = b;
    b.setDuration(150L);
    lo lo1 = this.E;
    lo1.b = paramAnimationListener;
    lo1.clearAnimation();
    this.E.startAnimation(this.M);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    h();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    b();
    int i = paramMotionEvent.getActionMasked();
    if (isEnabled() && !a() && !this.g) {
      if (this.w)
        return false; 
      if (i != 0) {
        if (i != 1)
          if (i != 2) {
            if (i != 3) {
              if (i == 6)
                g(paramMotionEvent); 
              return this.B;
            } 
          } else {
            i = this.C;
            if (i == -1)
              return false; 
            i = paramMotionEvent.findPointerIndex(i);
            if (i < 0)
              return false; 
            k(paramMotionEvent.getY(i));
            return this.B;
          }  
        this.B = false;
        this.C = -1;
      } else {
        setTargetOffsetTopAndBottom(this.H - this.E.getTop());
        i = paramMotionEvent.getPointerId(0);
        this.C = i;
        this.B = false;
        i = paramMotionEvent.findPointerIndex(i);
        if (i < 0)
          return false; 
        this.A = paramMotionEvent.getY(i);
      } 
      return this.B;
    } 
    return false;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = getMeasuredWidth();
    paramInt2 = getMeasuredHeight();
    if (getChildCount() == 0)
      return; 
    if (this.d == null)
      b(); 
    View view = this.d;
    if (view == null)
      return; 
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    view.layout(paramInt3, paramInt4, paramInt1 - getPaddingLeft() - getPaddingRight() + paramInt3, paramInt2 - getPaddingTop() - getPaddingBottom() + paramInt4);
    paramInt3 = this.E.getMeasuredWidth();
    paramInt2 = this.E.getMeasuredHeight();
    lo lo1 = this.E;
    paramInt1 /= 2;
    paramInt3 /= 2;
    paramInt4 = this.y;
    lo1.layout(paramInt1 - paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.d == null)
      b(); 
    View view = this.d;
    if (view == null)
      return; 
    view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), 1073741824));
    this.E.measure(View.MeasureSpec.makeMeasureSpec(this.Q, 1073741824), View.MeasureSpec.makeMeasureSpec(this.Q, 1073741824));
    this.F = -1;
    for (paramInt1 = 0; paramInt1 < getChildCount(); paramInt1++) {
      if (getChildAt(paramInt1) == this.E) {
        this.F = paramInt1;
        return;
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    if (paramInt2 > 0) {
      float f = this.r;
      if (f > 0.0F) {
        float f1 = paramInt2;
        if (f1 > f) {
          paramArrayOfint[1] = paramInt2 - (int)f;
          this.r = 0.0F;
        } else {
          this.r = f - f1;
          paramArrayOfint[1] = paramInt2;
        } 
        e(this.r);
      } 
    } 
    int[] arrayOfInt = this.u;
    if (dispatchNestedPreScroll(paramInt1 - paramArrayOfint[0], paramInt2 - paramArrayOfint[1], arrayOfInt, null)) {
      paramArrayOfint[0] = paramArrayOfint[0] + arrayOfInt[0];
      paramArrayOfint[1] = paramArrayOfint[1] + arrayOfInt[1];
    } 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, this.v);
    paramInt1 = paramInt4 + this.v[1];
    if (paramInt1 < 0 && !a()) {
      float f = this.r + Math.abs(paramInt1);
      this.r = f;
      e(f);
    } 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.s.a = paramInt;
    startNestedScroll(paramInt & 0x2);
    this.r = 0.0F;
    this.w = true;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return (isEnabled() && !this.g && (paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.s.b(0);
    this.w = false;
    float f = this.r;
    if (f > 0.0F) {
      c(f);
      this.r = 0.0F;
    } 
    stopNestedScroll();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (isEnabled() && !a() && !this.g) {
      if (this.w)
        return false; 
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i != 5) {
                if (i != 6)
                  return true; 
                g(paramMotionEvent);
                return true;
              } 
              i = paramMotionEvent.getActionIndex();
              if (i < 0)
                return false; 
              this.C = paramMotionEvent.getPointerId(i);
              return true;
            } 
            return false;
          } 
          i = paramMotionEvent.findPointerIndex(this.C);
          if (i < 0)
            return false; 
          float f = paramMotionEvent.getY(i);
          k(f);
          if (this.B) {
            f = (f - this.z) * 0.5F;
            if (f > 0.0F) {
              e(f);
              return true;
            } 
            return false;
          } 
        } else {
          i = paramMotionEvent.findPointerIndex(this.C);
          if (i < 0)
            return false; 
          if (this.B) {
            float f1 = paramMotionEvent.getY(i);
            float f2 = this.z;
            this.B = false;
            c((f1 - f2) * 0.5F);
          } 
          this.C = -1;
          return false;
        } 
      } else {
        this.C = paramMotionEvent.getPointerId(0);
        this.B = false;
      } 
      return true;
    } 
    return false;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 21 || !(this.d instanceof android.widget.AbsListView)) {
      View view = this.d;
      if (view != null && !fe.r(view))
        return; 
      super.requestDisallowInterceptTouchEvent(paramBoolean);
    } 
  }
  
  public void setAnimationProgress(float paramFloat) {
    this.E.setScaleX(paramFloat);
    this.E.setScaleY(paramFloat);
  }
  
  @Deprecated
  public void setColorScheme(int... paramVarArgs) {
    setColorSchemeResources(paramVarArgs);
  }
  
  public void setColorSchemeColors(int... paramVarArgs) {
    b();
    oo oo1 = this.K;
    oo.a a = oo1.f;
    a.i = paramVarArgs;
    a.a(0);
    oo1.f.a(0);
    oo1.invalidateSelf();
  }
  
  public void setColorSchemeResources(int... paramVarArgs) {
    Context context = getContext();
    int[] arrayOfInt = new int[paramVarArgs.length];
    for (int i = 0; i < paramVarArgs.length; i++)
      arrayOfInt[i] = ma.getColor(context, paramVarArgs[i]); 
    setColorSchemeColors(arrayOfInt);
  }
  
  public void setDistanceToTriggerSync(int paramInt) {
    this.q = paramInt;
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (!paramBoolean)
      h(); 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.t.h(paramBoolean);
  }
  
  public void setOnChildScrollUpCallback(g paramg) {
    this.R = paramg;
  }
  
  public void setOnRefreshListener(h paramh) {
    this.f = paramh;
  }
  
  @Deprecated
  public void setProgressBackgroundColor(int paramInt) {
    setProgressBackgroundColorSchemeResource(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeColor(int paramInt) {
    this.E.setBackgroundColor(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeResource(int paramInt) {
    setProgressBackgroundColorSchemeColor(ma.getColor(getContext(), paramInt));
  }
  
  public void setRefreshing(boolean paramBoolean) {
    if (paramBoolean && this.g != paramBoolean) {
      this.g = paramBoolean;
      setTargetOffsetTopAndBottom(this.I + this.H - this.y);
      this.P = false;
      Animation.AnimationListener animationListener = this.S;
      this.E.setVisibility(0);
      this.K.setAlpha(255);
      po po = new po(this);
      this.L = (Animation)po;
      po.setDuration(this.x);
      if (animationListener != null)
        this.E.b = animationListener; 
      this.E.clearAnimation();
      this.E.startAnimation(this.L);
      return;
    } 
    i(paramBoolean, false);
  }
  
  public void setSize(int paramInt) {
    if (paramInt != 0 && paramInt != 1)
      return; 
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    if (paramInt == 0) {
      this.Q = (int)(displayMetrics.density * 56.0F);
    } else {
      this.Q = (int)(displayMetrics.density * 40.0F);
    } 
    this.E.setImageDrawable(null);
    this.K.c(paramInt);
    this.E.setImageDrawable((Drawable)this.K);
  }
  
  public void setSlingshotDistance(int paramInt) {
    this.J = paramInt;
  }
  
  public void setTargetOffsetTopAndBottom(int paramInt) {
    this.E.bringToFront();
    fe.u((View)this.E, paramInt);
    this.y = this.E.getTop();
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.t.i(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.t.j(0);
  }
  
  public class a implements Animation.AnimationListener {
    public a(SwipeRefreshLayout this$0) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      SwipeRefreshLayout swipeRefreshLayout = this.a;
      if (swipeRefreshLayout.g) {
        swipeRefreshLayout.K.setAlpha(255);
        this.a.K.start();
        swipeRefreshLayout = this.a;
        if (swipeRefreshLayout.P) {
          SwipeRefreshLayout.h h = swipeRefreshLayout.f;
          if (h != null)
            h.a(); 
        } 
        swipeRefreshLayout = this.a;
        swipeRefreshLayout.y = swipeRefreshLayout.E.getTop();
        return;
      } 
      swipeRefreshLayout.h();
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  public class b extends Animation {
    public b(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      this.b.setAnimationProgress(1.0F - param1Float);
    }
  }
  
  public class c extends Animation {
    public c(SwipeRefreshLayout this$0, int param1Int1, int param1Int2) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      oo oo = this.d.K;
      int i = this.b;
      float f = i;
      oo.setAlpha((int)((this.c - i) * param1Float + f));
    }
  }
  
  public class d implements Animation.AnimationListener {
    public d(SwipeRefreshLayout this$0) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      Objects.requireNonNull(this.a);
      this.a.l(null);
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  public class e extends Animation {
    public e(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      Objects.requireNonNull(this.b);
      SwipeRefreshLayout swipeRefreshLayout = this.b;
      int j = swipeRefreshLayout.I;
      int k = Math.abs(swipeRefreshLayout.H);
      swipeRefreshLayout = this.b;
      int i = swipeRefreshLayout.G;
      j = (int)((j - k - i) * param1Float);
      k = swipeRefreshLayout.E.getTop();
      this.b.setTargetOffsetTopAndBottom(i + j - k);
      oo oo = this.b.K;
      param1Float = 1.0F - param1Float;
      oo.a a = oo.f;
      if (param1Float != a.p)
        a.p = param1Float; 
      oo.invalidateSelf();
    }
  }
  
  public class f extends Animation {
    public f(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      this.b.f(param1Float);
    }
  }
  
  public static interface g {
    boolean a(SwipeRefreshLayout param1SwipeRefreshLayout, View param1View);
  }
  
  public static interface h {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\swiperefreshlayout\widget\SwipeRefreshLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */