package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import h5;
import i5;
import k5;
import l5;
import m5;
import n5;
import p5;
import q5;

public class CardView extends FrameLayout {
  private static final int[] COLOR_BACKGROUND_ATTR = new int[] { 16842801 };
  
  private static final q5 IMPL;
  
  private final p5 mCardViewDelegate;
  
  private boolean mCompatPadding;
  
  public final Rect mContentPadding;
  
  private boolean mPreventCornerOverlap;
  
  public final Rect mShadowBounds;
  
  public int mUserSetMinHeight;
  
  public int mUserSetMinWidth;
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      IMPL = (q5)new n5();
    } else {
      IMPL = (q5)new m5();
    } 
    IMPL.j();
  }
  
  public CardView(Context paramContext) {
    this(paramContext, null);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, h5.cardViewStyle);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.mContentPadding = rect;
    this.mShadowBounds = new Rect();
    a a = new a(this);
    this.mCardViewDelegate = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, l5.CardView, paramInt, k5.CardView);
    paramInt = l5.CardView_cardBackgroundColor;
    if (typedArray.hasValue(paramInt)) {
      colorStateList = typedArray.getColorStateList(paramInt);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(COLOR_BACKGROUND_ATTR);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        paramInt = getResources().getColor(i5.cardview_light_background);
      } else {
        paramInt = getResources().getColor(i5.cardview_dark_background);
      } 
      colorStateList = ColorStateList.valueOf(paramInt);
    } 
    float f3 = typedArray.getDimension(l5.CardView_cardCornerRadius, 0.0F);
    float f2 = typedArray.getDimension(l5.CardView_cardElevation, 0.0F);
    float f1 = typedArray.getDimension(l5.CardView_cardMaxElevation, 0.0F);
    this.mCompatPadding = typedArray.getBoolean(l5.CardView_cardUseCompatPadding, false);
    this.mPreventCornerOverlap = typedArray.getBoolean(l5.CardView_cardPreventCornerOverlap, true);
    paramInt = typedArray.getDimensionPixelSize(l5.CardView_contentPadding, 0);
    rect.left = typedArray.getDimensionPixelSize(l5.CardView_contentPaddingLeft, paramInt);
    rect.top = typedArray.getDimensionPixelSize(l5.CardView_contentPaddingTop, paramInt);
    rect.right = typedArray.getDimensionPixelSize(l5.CardView_contentPaddingRight, paramInt);
    rect.bottom = typedArray.getDimensionPixelSize(l5.CardView_contentPaddingBottom, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.mUserSetMinWidth = typedArray.getDimensionPixelSize(l5.CardView_android_minWidth, 0);
    this.mUserSetMinHeight = typedArray.getDimensionPixelSize(l5.CardView_android_minHeight, 0);
    typedArray.recycle();
    IMPL.a(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return IMPL.h(this.mCardViewDelegate);
  }
  
  public float getCardElevation() {
    return IMPL.c(this.mCardViewDelegate);
  }
  
  public int getContentPaddingBottom() {
    return this.mContentPadding.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.mContentPadding.left;
  }
  
  public int getContentPaddingRight() {
    return this.mContentPadding.right;
  }
  
  public int getContentPaddingTop() {
    return this.mContentPadding.top;
  }
  
  public float getMaxCardElevation() {
    return IMPL.g(this.mCardViewDelegate);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.mPreventCornerOverlap;
  }
  
  public float getRadius() {
    return IMPL.d(this.mCardViewDelegate);
  }
  
  public boolean getUseCompatPadding() {
    return this.mCompatPadding;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    q5 q51 = IMPL;
    if (!(q51 instanceof n5)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(q51.l(this.mCardViewDelegate)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(q51.k(this.mCardViewDelegate)), View.MeasureSpec.getSize(paramInt2)), i); 
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    IMPL.n(this.mCardViewDelegate, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    IMPL.n(this.mCardViewDelegate, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    IMPL.f(this.mCardViewDelegate, paramFloat);
  }
  
  public void setContentPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mContentPadding.set(paramInt1, paramInt2, paramInt3, paramInt4);
    IMPL.i(this.mCardViewDelegate);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    IMPL.o(this.mCardViewDelegate, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.mUserSetMinHeight = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.mUserSetMinWidth = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.mPreventCornerOverlap) {
      this.mPreventCornerOverlap = paramBoolean;
      IMPL.m(this.mCardViewDelegate);
    } 
  }
  
  public void setRadius(float paramFloat) {
    IMPL.b(this.mCardViewDelegate, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.mCompatPadding != paramBoolean) {
      this.mCompatPadding = paramBoolean;
      IMPL.e(this.mCardViewDelegate);
    } 
  }
  
  public class a implements p5 {
    public Drawable a;
    
    public a(CardView this$0) {}
    
    public boolean a() {
      return this.b.getPreventCornerOverlap();
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.mShadowBounds.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.mContentPadding;
      cardView.setPadding(param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */