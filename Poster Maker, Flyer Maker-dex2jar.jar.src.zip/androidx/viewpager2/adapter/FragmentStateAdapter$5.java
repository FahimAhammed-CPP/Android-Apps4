package androidx.viewpager2.adapter;

import android.os.Handler;
import qj;
import tj;
import vj;
import wj;

public class FragmentStateAdapter$5 implements tj {
  public FragmentStateAdapter$5(FragmentStateAdapter paramFragmentStateAdapter, Handler paramHandler, Runnable paramRunnable) {}
  
  public void c(vj paramvj, qj.a parama) {
    if (parama == qj.a.ON_DESTROY) {
      this.a.removeCallbacks(this.b);
      wj wj = (wj)paramvj.getLifecycle();
      wj.d("removeObserver");
      wj.a.e(this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */