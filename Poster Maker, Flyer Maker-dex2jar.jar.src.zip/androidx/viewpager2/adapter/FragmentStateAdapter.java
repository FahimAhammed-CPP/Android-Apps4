package androidx.viewpager2.adapter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import ci;
import di;
import fe;
import fh;
import java.util.concurrent.atomic.AtomicInteger;
import kq;
import lq;
import mq;
import ni;
import nq;
import oq;
import pq;
import qj;
import qq;
import s30;
import tj;
import uj;
import vj;
import w5;
import wj;

public abstract class FragmentStateAdapter extends RecyclerView.g<pq> implements qq {
  public final qj b;
  
  public final di c;
  
  public final w5<Fragment> d = new w5(10);
  
  public final w5<Fragment.m> f = new w5(10);
  
  public final w5<Integer> g = new w5(10);
  
  public b p;
  
  public boolean q = false;
  
  public boolean r = false;
  
  public FragmentStateAdapter(di paramdi, qj paramqj) {
    this.c = paramdi;
    this.b = paramqj;
    super.setHasStableIds(true);
  }
  
  public static boolean k(String paramString1, String paramString2) {
    return (paramString1.startsWith(paramString2) && paramString1.length() > paramString2.length());
  }
  
  public final Parcelable a() {
    int j;
    int i = this.d.l();
    Bundle bundle = new Bundle(this.f.l() + i);
    byte b1 = 0;
    i = 0;
    while (true) {
      j = b1;
      if (i < this.d.l()) {
        long l = this.d.i(i);
        Fragment fragment = (Fragment)this.d.f(l);
        if (fragment != null && fragment.isAdded()) {
          String str = s30.d0("f#", l);
          this.c.a0(bundle, str, fragment);
        } 
        i++;
        continue;
      } 
      break;
    } 
    while (j < this.f.l()) {
      long l = this.f.i(j);
      if (h(l))
        bundle.putParcelable(s30.d0("s#", l), (Parcelable)this.f.f(l)); 
      j++;
    } 
    return (Parcelable)bundle;
  }
  
  public final void c(Parcelable paramParcelable) {
    if (this.f.h() && this.d.h()) {
      Bundle bundle = (Bundle)paramParcelable;
      if (bundle.getClassLoader() == null)
        bundle.setClassLoader(getClass().getClassLoader()); 
      for (String str : bundle.keySet()) {
        Fragment fragment;
        Fragment.m m;
        if (k(str, "f#")) {
          long l = Long.parseLong(str.substring(2));
          fragment = this.c.K(bundle, str);
          this.d.j(l, fragment);
          continue;
        } 
        if (k((String)fragment, "s#")) {
          long l = Long.parseLong(fragment.substring(2));
          m = (Fragment.m)bundle.getParcelable((String)fragment);
          if (h(l))
            this.f.j(l, m); 
          continue;
        } 
        throw new IllegalArgumentException(s30.g0("Unexpected key in savedState: ", m));
      } 
      if (!this.d.h()) {
        this.r = true;
        this.q = true;
        j();
        Handler handler = new Handler(Looper.getMainLooper());
        mq mq = new mq(this);
        this.b.a((uj)new FragmentStateAdapter$5(this, handler, (Runnable)mq));
        handler.postDelayed((Runnable)mq, 10000L);
      } 
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Expected the adapter to be 'fresh' while restoring state.");
    throw illegalStateException;
  }
  
  public void g(View paramView, FrameLayout paramFrameLayout) {
    if (paramFrameLayout.getChildCount() <= 1) {
      if (paramView.getParent() == paramFrameLayout)
        return; 
      if (paramFrameLayout.getChildCount() > 0)
        paramFrameLayout.removeAllViews(); 
      if (paramView.getParent() != null)
        ((ViewGroup)paramView.getParent()).removeView(paramView); 
      paramFrameLayout.addView(paramView);
      return;
    } 
    throw new IllegalStateException("Design assumption violated.");
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public boolean h(long paramLong) {
    return (paramLong >= 0L && paramLong < getItemCount());
  }
  
  public abstract Fragment i(int paramInt);
  
  public void j() {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Z
    //   4: ifeq -> 242
    //   7: aload_0
    //   8: invokevirtual o : ()Z
    //   11: ifeq -> 15
    //   14: return
    //   15: new u5
    //   18: dup
    //   19: iconst_0
    //   20: invokespecial <init> : (I)V
    //   23: astore #6
    //   25: iconst_0
    //   26: istore_1
    //   27: iload_1
    //   28: aload_0
    //   29: getfield d : Lw5;
    //   32: invokevirtual l : ()I
    //   35: if_icmpge -> 80
    //   38: aload_0
    //   39: getfield d : Lw5;
    //   42: iload_1
    //   43: invokevirtual i : (I)J
    //   46: lstore_3
    //   47: aload_0
    //   48: lload_3
    //   49: invokevirtual h : (J)Z
    //   52: ifne -> 73
    //   55: aload #6
    //   57: lload_3
    //   58: invokestatic valueOf : (J)Ljava/lang/Long;
    //   61: invokevirtual add : (Ljava/lang/Object;)Z
    //   64: pop
    //   65: aload_0
    //   66: getfield g : Lw5;
    //   69: lload_3
    //   70: invokevirtual k : (J)V
    //   73: iload_1
    //   74: iconst_1
    //   75: iadd
    //   76: istore_1
    //   77: goto -> 27
    //   80: aload_0
    //   81: getfield q : Z
    //   84: ifne -> 205
    //   87: aload_0
    //   88: iconst_0
    //   89: putfield r : Z
    //   92: iconst_0
    //   93: istore_1
    //   94: iload_1
    //   95: aload_0
    //   96: getfield d : Lw5;
    //   99: invokevirtual l : ()I
    //   102: if_icmpge -> 205
    //   105: aload_0
    //   106: getfield d : Lw5;
    //   109: iload_1
    //   110: invokevirtual i : (I)J
    //   113: lstore_3
    //   114: aload_0
    //   115: getfield g : Lw5;
    //   118: lload_3
    //   119: invokevirtual d : (J)Z
    //   122: istore #5
    //   124: iconst_1
    //   125: istore_2
    //   126: iload #5
    //   128: ifeq -> 134
    //   131: goto -> 184
    //   134: aload_0
    //   135: getfield d : Lw5;
    //   138: lload_3
    //   139: aconst_null
    //   140: invokevirtual g : (JLjava/lang/Object;)Ljava/lang/Object;
    //   143: checkcast androidx/fragment/app/Fragment
    //   146: astore #7
    //   148: aload #7
    //   150: ifnonnull -> 156
    //   153: goto -> 182
    //   156: aload #7
    //   158: invokevirtual getView : ()Landroid/view/View;
    //   161: astore #7
    //   163: aload #7
    //   165: ifnonnull -> 171
    //   168: goto -> 182
    //   171: aload #7
    //   173: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   176: ifnull -> 182
    //   179: goto -> 184
    //   182: iconst_0
    //   183: istore_2
    //   184: iload_2
    //   185: ifne -> 198
    //   188: aload #6
    //   190: lload_3
    //   191: invokestatic valueOf : (J)Ljava/lang/Long;
    //   194: invokevirtual add : (Ljava/lang/Object;)Z
    //   197: pop
    //   198: iload_1
    //   199: iconst_1
    //   200: iadd
    //   201: istore_1
    //   202: goto -> 94
    //   205: aload #6
    //   207: invokevirtual iterator : ()Ljava/util/Iterator;
    //   210: astore #6
    //   212: aload #6
    //   214: invokeinterface hasNext : ()Z
    //   219: ifeq -> 242
    //   222: aload_0
    //   223: aload #6
    //   225: invokeinterface next : ()Ljava/lang/Object;
    //   230: checkcast java/lang/Long
    //   233: invokevirtual longValue : ()J
    //   236: invokevirtual n : (J)V
    //   239: goto -> 212
    //   242: return
  }
  
  public final Long l(int paramInt) {
    Long long_ = null;
    int i = 0;
    while (i < this.g.l()) {
      Long long_1 = long_;
      if (((Integer)this.g.n(i)).intValue() == paramInt)
        if (long_ == null) {
          long_1 = Long.valueOf(this.g.i(i));
        } else {
          throw new IllegalStateException("Design assumption violated: a ViewHolder can only be bound to one item at a time.");
        }  
      i++;
      long_ = long_1;
    } 
    return long_;
  }
  
  public void m(pq parampq) {
    Fragment fragment = (Fragment)this.d.f(parampq.getItemId());
    if (fragment != null) {
      FrameLayout frameLayout = (FrameLayout)((RecyclerView.d0)parampq).itemView;
      View view = fragment.getView();
      if (fragment.isAdded() || view == null) {
        di di1;
        lq lq;
        if (fragment.isAdded() && view == null) {
          di1 = this.c;
          lq = new lq(this, fragment, frameLayout);
          di1.n.a.add(new ci.a((di.k)lq, false));
          return;
        } 
        if (lq.isAdded() && view.getParent() != null) {
          if (view.getParent() != frameLayout)
            g(view, frameLayout); 
          return;
        } 
        if (lq.isAdded()) {
          g(view, frameLayout);
          return;
        } 
        if (!o()) {
          di di2 = this.c;
          lq lq1 = new lq(this, (Fragment)lq, frameLayout);
          di2.n.a.add(new ci.a((di.k)lq1, false));
          fh fh = new fh(this.c);
          StringBuilder stringBuilder = s30.x0("f");
          stringBuilder.append(di1.getItemId());
          fh.g(0, (Fragment)lq, stringBuilder.toString(), 1);
          fh.k((Fragment)lq, qj.b.STARTED);
          fh.e();
          this.p.b(false);
          return;
        } 
        if (this.c.D)
          return; 
        this.b.a((uj)new tj(this, (pq)di1) {
              public void c(vj param1vj, qj.a param1a) {
                if (this.b.o())
                  return; 
                wj wj = (wj)param1vj.getLifecycle();
                wj.d("removeObserver");
                wj.a.e(this);
                FrameLayout frameLayout = (FrameLayout)((RecyclerView.d0)this.a).itemView;
                AtomicInteger atomicInteger = fe.a;
                if (fe.g.b((View)frameLayout))
                  this.b.m(this.a); 
              }
            });
        return;
      } 
      throw new IllegalStateException("Design assumption violated.");
    } 
    throw new IllegalStateException("Design assumption violated.");
  }
  
  public final void n(long paramLong) {
    Fragment fragment = (Fragment)this.d.g(paramLong, null);
    if (fragment == null)
      return; 
    if (fragment.getView() != null) {
      ViewParent viewParent = fragment.getView().getParent();
      if (viewParent != null)
        ((FrameLayout)viewParent).removeAllViews(); 
    } 
    if (!h(paramLong))
      this.f.k(paramLong); 
    if (!fragment.isAdded()) {
      this.d.k(paramLong);
      return;
    } 
    if (o()) {
      this.r = true;
      return;
    } 
    if (fragment.isAdded() && h(paramLong))
      this.f.j(paramLong, this.c.f0(fragment)); 
    fh fh = new fh(this.c);
    fh.h(fragment);
    fh.e();
    this.d.k(paramLong);
  }
  
  public boolean o() {
    return this.c.T();
  }
  
  public void onAttachedToRecyclerView(RecyclerView paramRecyclerView) {
    boolean bool;
    if (this.p == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      b b1 = new b(this);
      this.p = b1;
      b1.d = b1.a(paramRecyclerView);
      nq nq = new nq(b1);
      b1.a = (ViewPager2.e)nq;
      b1.d.d.a.add(nq);
      oq oq = new oq(b1);
      b1.b = (RecyclerView.i)oq;
      registerAdapterDataObserver((RecyclerView.i)oq);
      FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 = new FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3(b1);
      b1.c = fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3;
      this.b.a((uj)fragmentStateAdapter$FragmentMaxLifecycleEnforcer$3);
      return;
    } 
    throw new IllegalArgumentException();
  }
  
  public void onBindViewHolder(RecyclerView.d0 paramd0, int paramInt) {
    pq pq = (pq)paramd0;
    long l = pq.getItemId();
    int i = ((FrameLayout)((RecyclerView.d0)pq).itemView).getId();
    Long long_ = l(i);
    if (long_ != null && long_.longValue() != l) {
      n(long_.longValue());
      this.g.k(long_.longValue());
    } 
    this.g.j(l, Integer.valueOf(i));
    l = getItemId(paramInt);
    if (!this.d.d(l)) {
      Fragment fragment = i(paramInt);
      fragment.setInitialSavedState((Fragment.m)this.f.f(l));
      this.d.j(l, fragment);
    } 
    FrameLayout frameLayout = (FrameLayout)((RecyclerView.d0)pq).itemView;
    AtomicInteger atomicInteger = fe.a;
    if (fe.g.b((View)frameLayout))
      if (frameLayout.getParent() == null) {
        frameLayout.addOnLayoutChangeListener((View.OnLayoutChangeListener)new kq(this, frameLayout, pq));
      } else {
        throw new IllegalStateException("Design assumption violated.");
      }  
    j();
  }
  
  public RecyclerView.d0 onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) {
    paramInt = pq.a;
    FrameLayout frameLayout = new FrameLayout(paramViewGroup.getContext());
    frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
    AtomicInteger atomicInteger = fe.a;
    frameLayout.setId(fe.e.a());
    frameLayout.setSaveEnabled(false);
    return (RecyclerView.d0)new pq(frameLayout);
  }
  
  public void onDetachedFromRecyclerView(RecyclerView paramRecyclerView) {
    b b1 = this.p;
    b1.a(paramRecyclerView).e(b1.a);
    b1.f.unregisterAdapterDataObserver(b1.b);
    b1.f.b.b((uj)b1.c);
    b1.d = null;
    this.p = null;
  }
  
  public void onViewAttachedToWindow(RecyclerView.d0 paramd0) {
    m((pq)paramd0);
    j();
  }
  
  public void onViewRecycled(RecyclerView.d0 paramd0) {
    Long long_ = l(((FrameLayout)paramd0.itemView).getId());
    if (long_ != null) {
      n(long_.longValue());
      this.g.k(long_.longValue());
    } 
  }
  
  public final void setHasStableIds(boolean paramBoolean) {
    throw new UnsupportedOperationException("Stable Ids are required for the adapter to function properly, and the adapter takes care of setting the flag.");
  }
  
  public static abstract class a extends RecyclerView.i {
    public a(kq param1kq) {}
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2, Object param1Object) {
      onChanged();
    }
    
    public final void onItemRangeInserted(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeMoved(int param1Int1, int param1Int2, int param1Int3) {
      onChanged();
    }
    
    public final void onItemRangeRemoved(int param1Int1, int param1Int2) {
      onChanged();
    }
  }
  
  public class b {
    public ViewPager2.e a;
    
    public RecyclerView.i b;
    
    public tj c;
    
    public ViewPager2 d;
    
    public long e = -1L;
    
    public b(FragmentStateAdapter this$0) {}
    
    public final ViewPager2 a(RecyclerView param1RecyclerView) {
      ViewParent viewParent = param1RecyclerView.getParent();
      if (viewParent instanceof ViewPager2)
        return (ViewPager2)viewParent; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected ViewPager2 instance. Got: ");
      stringBuilder.append(viewParent);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void b(boolean param1Boolean) {
      if (this.f.o())
        return; 
      if (this.d.getScrollState() != 0)
        return; 
      if (!this.f.d.h()) {
        if (this.f.getItemCount() == 0)
          return; 
        int j = this.d.getCurrentItem();
        if (j >= this.f.getItemCount())
          return; 
        long l = this.f.getItemId(j);
        if (l == this.e && !param1Boolean)
          return; 
        Fragment fragment = (Fragment)this.f.d.f(l);
        if (fragment != null) {
          if (!fragment.isAdded())
            return; 
          this.e = l;
          fh fh = new fh(this.f.c);
          fragment = null;
          for (j = 0; j < this.f.d.l(); j++) {
            l = this.f.d.i(j);
            Fragment fragment1 = (Fragment)this.f.d.n(j);
            if (fragment1.isAdded()) {
              if (l != this.e) {
                fh.k(fragment1, qj.b.STARTED);
              } else {
                fragment = fragment1;
              } 
              if (l == this.e) {
                param1Boolean = true;
              } else {
                param1Boolean = false;
              } 
              fragment1.setMenuVisibility(param1Boolean);
            } 
          } 
          if (fragment != null)
            fh.k(fragment, qj.b.RESUMED); 
          if (!((ni)fh).a.isEmpty())
            fh.e(); 
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */