package androidx.viewpager2.adapter;

import qj;
import tj;
import vj;

public class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements tj {
  public FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3(FragmentStateAdapter.b paramb) {}
  
  public void c(vj paramvj, qj.a parama) {
    this.a.b(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */