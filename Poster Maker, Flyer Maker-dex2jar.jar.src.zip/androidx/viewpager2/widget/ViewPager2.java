package androidx.viewpager2.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import fe;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import jq;
import oe;
import qe;
import qq;
import tq;
import uq;
import vm;
import vq;
import wq;
import xq;
import yq;
import zq;

public final class ViewPager2 extends ViewGroup {
  public boolean A = false;
  
  public boolean B = true;
  
  public int C = -1;
  
  public b D = new f(this);
  
  public final Rect b = new Rect();
  
  public final Rect c = new Rect();
  
  public tq d = new tq(3);
  
  public int f;
  
  public boolean g = false;
  
  public RecyclerView.i p = new a(this);
  
  public LinearLayoutManager q;
  
  public int r = -1;
  
  public Parcelable s;
  
  public RecyclerView t;
  
  public vm u;
  
  public wq v;
  
  public tq w;
  
  public uq x;
  
  public vq y;
  
  public RecyclerView.l z = null;
  
  public ViewPager2(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    i i1 = new i(this, paramContext);
    this.t = i1;
    AtomicInteger atomicInteger = fe.a;
    i1.setId(fe.e.a());
    this.t.setDescendantFocusability(131072);
    d d = new d(this, paramContext);
    this.q = d;
    this.t.setLayoutManager((RecyclerView.o)d);
    this.t.setScrollingTouchSlop(1);
    int[] arrayOfInt = jq.ViewPager2;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt);
    if (Build.VERSION.SDK_INT >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt, paramAttributeSet, typedArray, 0, 0); 
    try {
      setOrientation(typedArray.getInt(jq.ViewPager2_android_orientation, 0));
      typedArray.recycle();
      this.t.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
      this.t.addOnChildAttachStateChangeListener((RecyclerView.q)new zq(this));
      wq wq1 = new wq(this);
      this.v = wq1;
      this.x = new uq(this, wq1, this.t);
      h h = new h(this);
      this.u = h;
      h.a(this.t);
      this.t.addOnScrollListener((RecyclerView.t)this.v);
      tq tq2 = new tq(3);
      this.w = tq2;
      this.v.a = (e)tq2;
      xq xq = new xq(this);
      yq yq = new yq(this);
      this.w.a.add(xq);
      this.w.a.add(yq);
      this.D.a(this.w, this.t);
      tq tq1 = this.w;
      tq tq3 = this.d;
      tq1.a.add(tq3);
      vq vq1 = new vq(this.q);
      this.y = vq1;
      this.w.a.add(vq1);
      RecyclerView recyclerView = this.t;
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public boolean a() {
    return (this.q.getLayoutDirection() == 1);
  }
  
  public void b(e parame) {
    this.d.a.add(parame);
  }
  
  public final void c() {
    if (this.r == -1)
      return; 
    RecyclerView.g g = getAdapter();
    if (g == null)
      return; 
    Parcelable parcelable = this.s;
    if (parcelable != null) {
      if (g instanceof qq)
        ((qq)g).c(parcelable); 
      this.s = null;
    } 
    int j = Math.max(0, Math.min(this.r, g.getItemCount() - 1));
    this.f = j;
    this.r = -1;
    this.t.scrollToPosition(j);
    ((f)this.D).c();
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    return this.t.canScrollHorizontally(paramInt);
  }
  
  public boolean canScrollVertically(int paramInt) {
    return this.t.canScrollVertically(paramInt);
  }
  
  public void d(int paramInt, boolean paramBoolean) {
    RecyclerView.g g = getAdapter();
    boolean bool = false;
    if (g == null) {
      if (this.r != -1)
        this.r = Math.max(paramInt, 0); 
      return;
    } 
    if (g.getItemCount() <= 0)
      return; 
    int j = Math.min(Math.max(paramInt, 0), g.getItemCount() - 1);
    int k = this.f;
    if (j == k) {
      if (this.v.f == 0) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (paramInt != 0)
        return; 
    } 
    if (j == k && paramBoolean)
      return; 
    double d1 = k;
    this.f = j;
    ((f)this.D).c();
    wq wq1 = this.v;
    if (wq1.f == 0) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt == 0) {
      wq1.g();
      wq.a a = wq1.g;
      d1 = a.a;
      double d = a.b;
      Double.isNaN(d1);
      Double.isNaN(d);
      Double.isNaN(d1);
      Double.isNaN(d);
      Double.isNaN(d1);
      Double.isNaN(d);
      d1 += d;
    } 
    wq1 = this.v;
    if (paramBoolean) {
      paramInt = 2;
    } else {
      paramInt = 3;
    } 
    wq1.e = paramInt;
    wq1.m = false;
    paramInt = bool;
    if (wq1.i != j)
      paramInt = 1; 
    wq1.i = j;
    wq1.d(2);
    if (paramInt != 0) {
      e e = wq1.a;
      if (e != null)
        e.onPageSelected(j); 
    } 
    if (!paramBoolean) {
      this.t.scrollToPosition(j);
      return;
    } 
    double d2 = j;
    Double.isNaN(d2);
    Double.isNaN(d2);
    if (Math.abs(d2 - d1) > 3.0D) {
      RecyclerView recyclerView = this.t;
      if (d2 > d1) {
        paramInt = j - 3;
      } else {
        paramInt = j + 3;
      } 
      recyclerView.scrollToPosition(paramInt);
      recyclerView = this.t;
      recyclerView.post(new k(j, recyclerView));
      return;
    } 
    this.t.smoothScrollToPosition(j);
  }
  
  public void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray) {
    Parcelable parcelable = (Parcelable)paramSparseArray.get(getId());
    if (parcelable instanceof j) {
      int j = ((j)parcelable).b;
      paramSparseArray.put(this.t.getId(), paramSparseArray.get(j));
      paramSparseArray.remove(j);
    } 
    super.dispatchRestoreInstanceState(paramSparseArray);
    c();
  }
  
  public void e(e parame) {
    this.d.a.remove(parame);
  }
  
  public void f() {
    vm vm1 = this.u;
    if (vm1 != null) {
      View view = vm1.d((RecyclerView.o)this.q);
      if (view == null)
        return; 
      int j = this.q.getPosition(view);
      if (j != this.f && getScrollState() == 0)
        this.w.onPageSelected(j); 
      this.g = false;
      return;
    } 
    throw new IllegalStateException("Design assumption violated.");
  }
  
  public CharSequence getAccessibilityClassName() {
    b b1 = this.D;
    Objects.requireNonNull(b1);
    if (b1 instanceof f) {
      Objects.requireNonNull(this.D);
      return "androidx.viewpager.widget.ViewPager";
    } 
    return super.getAccessibilityClassName();
  }
  
  public RecyclerView.g getAdapter() {
    return this.t.getAdapter();
  }
  
  public int getCurrentItem() {
    return this.f;
  }
  
  public int getItemDecorationCount() {
    return this.t.getItemDecorationCount();
  }
  
  public int getOffscreenPageLimit() {
    return this.C;
  }
  
  public int getOrientation() {
    return this.q.getOrientation();
  }
  
  public int getPageSize() {
    int j;
    int k;
    RecyclerView recyclerView = this.t;
    if (getOrientation() == 0) {
      k = recyclerView.getWidth() - recyclerView.getPaddingLeft();
      j = recyclerView.getPaddingRight();
    } else {
      k = recyclerView.getHeight() - recyclerView.getPaddingTop();
      j = recyclerView.getPaddingBottom();
    } 
    return k - j;
  }
  
  public int getScrollState() {
    return this.v.f;
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    boolean bool1;
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    f f = (f)this.D;
    if (f.d.getAdapter() != null) {
      if (f.d.getOrientation() == 1) {
        bool1 = f.d.getAdapter().getItemCount();
      } else {
        int j = f.d.getAdapter().getItemCount();
        bool1 = false;
        paramAccessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo)(oe.b.a(bool1, j, false, 0)).a);
        RecyclerView.g g1 = f.d.getAdapter();
      } 
    } else {
      bool1 = false;
    } 
    boolean bool2 = false;
    paramAccessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo)(oe.b.a(bool1, bool2, false, 0)).a);
    RecyclerView.g g = f.d.getAdapter();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int j = this.t.getMeasuredWidth();
    int k = this.t.getMeasuredHeight();
    this.b.left = getPaddingLeft();
    this.b.right = paramInt3 - paramInt1 - getPaddingRight();
    this.b.top = getPaddingTop();
    this.b.bottom = paramInt4 - paramInt2 - getPaddingBottom();
    Gravity.apply(8388659, j, k, this.b, this.c);
    RecyclerView recyclerView = this.t;
    Rect rect = this.c;
    recyclerView.layout(rect.left, rect.top, rect.right, rect.bottom);
    if (this.g)
      f(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    measureChild((View)this.t, paramInt1, paramInt2);
    int i1 = this.t.getMeasuredWidth();
    int k = this.t.getMeasuredHeight();
    int j = this.t.getMeasuredState();
    int i2 = getPaddingLeft();
    int i3 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    i1 = Math.max(i3 + i2 + i1, getSuggestedMinimumWidth());
    k = Math.max(n + m + k, getSuggestedMinimumHeight());
    setMeasuredDimension(ViewGroup.resolveSizeAndState(i1, paramInt1, j), ViewGroup.resolveSizeAndState(k, paramInt2, j << 16));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof j)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    j j = (j)paramParcelable;
    super.onRestoreInstanceState(j.getSuperState());
    this.r = j.c;
    this.s = j.d;
  }
  
  public Parcelable onSaveInstanceState() {
    j j1 = new j(super.onSaveInstanceState());
    j1.b = this.t.getId();
    int k = this.r;
    int j = k;
    if (k == -1)
      j = this.f; 
    j1.c = j;
    Parcelable parcelable = this.s;
    if (parcelable != null) {
      j1.d = parcelable;
      return (Parcelable)j1;
    } 
    RecyclerView.g g = this.t.getAdapter();
    if (g instanceof qq)
      j1.d = ((qq)g).a(); 
    return (Parcelable)j1;
  }
  
  public void onViewAdded(View paramView) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(ViewPager2.class.getSimpleName());
    stringBuilder.append(" does not support direct child views");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean performAccessibilityAction(int paramInt, Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: getfield D : Landroidx/viewpager2/widget/ViewPager2$b;
    //   4: checkcast androidx/viewpager2/widget/ViewPager2$f
    //   7: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: pop
    //   11: iconst_0
    //   12: istore #4
    //   14: iload_1
    //   15: sipush #8192
    //   18: if_icmpeq -> 36
    //   21: iload_1
    //   22: sipush #4096
    //   25: if_icmpne -> 31
    //   28: goto -> 36
    //   31: iconst_0
    //   32: istore_3
    //   33: goto -> 38
    //   36: iconst_1
    //   37: istore_3
    //   38: iload_3
    //   39: ifeq -> 123
    //   42: aload_0
    //   43: getfield D : Landroidx/viewpager2/widget/ViewPager2$b;
    //   46: checkcast androidx/viewpager2/widget/ViewPager2$f
    //   49: astore_2
    //   50: aload_2
    //   51: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   54: pop
    //   55: iload_1
    //   56: sipush #8192
    //   59: if_icmpeq -> 72
    //   62: iload #4
    //   64: istore_3
    //   65: iload_1
    //   66: sipush #4096
    //   69: if_icmpne -> 74
    //   72: iconst_1
    //   73: istore_3
    //   74: iload_3
    //   75: ifeq -> 115
    //   78: iload_1
    //   79: sipush #8192
    //   82: if_icmpne -> 98
    //   85: aload_2
    //   86: getfield d : Landroidx/viewpager2/widget/ViewPager2;
    //   89: invokevirtual getCurrentItem : ()I
    //   92: iconst_1
    //   93: isub
    //   94: istore_1
    //   95: goto -> 108
    //   98: aload_2
    //   99: getfield d : Landroidx/viewpager2/widget/ViewPager2;
    //   102: invokevirtual getCurrentItem : ()I
    //   105: iconst_1
    //   106: iadd
    //   107: istore_1
    //   108: aload_2
    //   109: iload_1
    //   110: invokevirtual b : (I)V
    //   113: iconst_1
    //   114: ireturn
    //   115: new java/lang/IllegalStateException
    //   118: dup
    //   119: invokespecial <init> : ()V
    //   122: athrow
    //   123: aload_0
    //   124: iload_1
    //   125: aload_2
    //   126: invokespecial performAccessibilityAction : (ILandroid/os/Bundle;)Z
    //   129: ireturn
  }
  
  public void setAdapter(RecyclerView.g paramg) {
    RecyclerView.g g1 = this.t.getAdapter();
    f f2 = (f)this.D;
    Objects.requireNonNull(f2);
    if (g1 != null)
      g1.unregisterAdapterDataObserver(f2.c); 
    if (g1 != null)
      g1.unregisterAdapterDataObserver(this.p); 
    this.t.setAdapter(paramg);
    this.f = 0;
    c();
    f f1 = (f)this.D;
    f1.c();
    if (paramg != null)
      paramg.registerAdapterDataObserver(f1.c); 
    if (paramg != null)
      paramg.registerAdapterDataObserver(this.p); 
  }
  
  public void setCurrentItem(int paramInt) {
    if (!this.x.a.m) {
      d(paramInt, true);
      return;
    } 
    throw new IllegalStateException("Cannot change current item when ViewPager2 is fake dragging");
  }
  
  public void setLayoutDirection(int paramInt) {
    super.setLayoutDirection(paramInt);
    ((f)this.D).c();
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    if (paramInt >= 1 || paramInt == -1) {
      this.C = paramInt;
      this.t.requestLayout();
      return;
    } 
    throw new IllegalArgumentException("Offscreen page limit must be OFFSCREEN_PAGE_LIMIT_DEFAULT or a number > 0");
  }
  
  public void setOrientation(int paramInt) {
    this.q.setOrientation(paramInt);
    ((f)this.D).c();
  }
  
  public void setPageTransformer(g paramg) {
    if (paramg != null) {
      if (!this.A) {
        this.z = this.t.getItemAnimator();
        this.A = true;
      } 
      this.t.setItemAnimator(null);
    } else if (this.A) {
      this.t.setItemAnimator(this.z);
      this.z = null;
      this.A = false;
    } 
    vq vq1 = this.y;
    if (paramg == vq1.b)
      return; 
    vq1.b = paramg;
    if (paramg == null)
      return; 
    wq wq1 = this.v;
    wq1.g();
    wq.a a = wq1.g;
    double d1 = a.a;
    double d2 = a.b;
    Double.isNaN(d1);
    Double.isNaN(d2);
    Double.isNaN(d1);
    Double.isNaN(d2);
    Double.isNaN(d1);
    Double.isNaN(d2);
    Double.isNaN(d1);
    Double.isNaN(d2);
    d1 += d2;
    int j = (int)d1;
    d2 = j;
    Double.isNaN(d2);
    Double.isNaN(d2);
    Double.isNaN(d2);
    float f = (float)(d1 - d2);
    int k = Math.round(getPageSize() * f);
    this.y.onPageScrolled(j, f, k);
  }
  
  public void setUserInputEnabled(boolean paramBoolean) {
    this.B = paramBoolean;
    f f = (f)this.D;
    f.c();
    if (Build.VERSION.SDK_INT < 21)
      f.d.sendAccessibilityEvent(2048); 
  }
  
  public class a extends c {
    public a(ViewPager2 this$0) {
      super(null);
    }
    
    public void onChanged() {
      ViewPager2 viewPager2 = this.a;
      viewPager2.g = true;
      viewPager2.v.l = true;
    }
  }
  
  public abstract class b {
    public b(ViewPager2 this$0, ViewPager2.a param1a) {}
    
    public abstract void a(tq param1tq, RecyclerView param1RecyclerView);
  }
  
  public static abstract class c extends RecyclerView.i {
    public c(ViewPager2.a param1a) {}
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2, Object param1Object) {
      onChanged();
    }
    
    public final void onItemRangeInserted(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeMoved(int param1Int1, int param1Int2, int param1Int3) {
      onChanged();
    }
    
    public final void onItemRangeRemoved(int param1Int1, int param1Int2) {
      onChanged();
    }
  }
  
  public class d extends LinearLayoutManager {
    public d(ViewPager2 this$0, Context param1Context) {
      super(param1Context);
    }
    
    public void calculateExtraLayoutSpace(RecyclerView.a0 param1a0, int[] param1ArrayOfint) {
      int i = this.b.getOffscreenPageLimit();
      if (i == -1) {
        super.calculateExtraLayoutSpace(param1a0, param1ArrayOfint);
        return;
      } 
      i = this.b.getPageSize() * i;
      param1ArrayOfint[0] = i;
      param1ArrayOfint[1] = i;
    }
    
    public void onInitializeAccessibilityNodeInfo(RecyclerView.v param1v, RecyclerView.a0 param1a0, oe param1oe) {
      super.onInitializeAccessibilityNodeInfo(param1v, param1a0, param1oe);
      Objects.requireNonNull(this.b.D);
    }
    
    public boolean performAccessibilityAction(RecyclerView.v param1v, RecyclerView.a0 param1a0, int param1Int, Bundle param1Bundle) {
      Objects.requireNonNull(this.b.D);
      return super.performAccessibilityAction(param1v, param1a0, param1Int, param1Bundle);
    }
    
    public boolean requestChildRectangleOnScreen(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean1, boolean param1Boolean2) {
      return false;
    }
  }
  
  public static abstract class e {
    public void onPageScrollStateChanged(int param1Int) {}
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {}
    
    public void onPageSelected(int param1Int) {}
  }
  
  public class f extends b {
    public final qe a = new a(this);
    
    public final qe b = new b(this);
    
    public RecyclerView.i c;
    
    public f(ViewPager2 this$0) {
      super(this$0, null);
    }
    
    public void a(tq param1tq, RecyclerView param1RecyclerView) {
      AtomicInteger atomicInteger = fe.a;
      fe.d.s((View)param1RecyclerView, 2);
      this.c = new c(this);
      if (fe.d.c((View)this.d) == 0)
        fe.d.s((View)this.d, 1); 
    }
    
    public void b(int param1Int) {
      ViewPager2 viewPager2 = this.d;
      if (viewPager2.B)
        viewPager2.d(param1Int, true); 
    }
    
    public void c() {
      ViewPager2 viewPager21 = this.d;
      int j = 16908360;
      fe.x((View)viewPager21, 16908360);
      fe.x((View)viewPager21, 16908361);
      fe.x((View)viewPager21, 16908358);
      fe.x((View)viewPager21, 16908359);
      if (this.d.getAdapter() == null)
        return; 
      int k = this.d.getAdapter().getItemCount();
      if (k == 0)
        return; 
      ViewPager2 viewPager22 = this.d;
      if (!viewPager22.B)
        return; 
      if (viewPager22.getOrientation() == 0) {
        int m;
        boolean bool = this.d.a();
        if (bool) {
          m = 16908360;
        } else {
          m = 16908361;
        } 
        if (bool)
          j = 16908361; 
        if (this.d.f < k - 1)
          fe.z((View)viewPager21, new oe.a(m, null), null, this.a); 
        if (this.d.f > 0) {
          fe.z((View)viewPager21, new oe.a(j, null), null, this.b);
          return;
        } 
      } else {
        if (this.d.f < k - 1)
          fe.z((View)viewPager21, new oe.a(16908359, null), null, this.a); 
        if (this.d.f > 0)
          fe.z((View)viewPager21, new oe.a(16908358, null), null, this.b); 
      } 
    }
    
    public class a implements qe {
      public a(ViewPager2.f this$0) {}
      
      public boolean perform(View param2View, qe.a param2a) {
        ViewPager2 viewPager2 = (ViewPager2)param2View;
        this.a.b(viewPager2.getCurrentItem() + 1);
        return true;
      }
    }
    
    public class b implements qe {
      public b(ViewPager2.f this$0) {}
      
      public boolean perform(View param2View, qe.a param2a) {
        ViewPager2 viewPager2 = (ViewPager2)param2View;
        this.a.b(viewPager2.getCurrentItem() - 1);
        return true;
      }
    }
    
    public class c extends ViewPager2.c {
      public c(ViewPager2.f this$0) {
        super(null);
      }
      
      public void onChanged() {
        this.a.c();
      }
    }
  }
  
  public class a implements qe {
    public a(ViewPager2 this$0) {}
    
    public boolean perform(View param1View, qe.a param1a) {
      ViewPager2 viewPager2 = (ViewPager2)param1View;
      this.a.b(viewPager2.getCurrentItem() + 1);
      return true;
    }
  }
  
  public class b implements qe {
    public b(ViewPager2 this$0) {}
    
    public boolean perform(View param1View, qe.a param1a) {
      ViewPager2 viewPager2 = (ViewPager2)param1View;
      this.a.b(viewPager2.getCurrentItem() - 1);
      return true;
    }
  }
  
  public class c extends c {
    public c(ViewPager2 this$0) {
      super(null);
    }
    
    public void onChanged() {
      this.a.c();
    }
  }
  
  public static interface g {}
  
  public class h extends vm {
    public h(ViewPager2 this$0) {}
    
    public View d(RecyclerView.o param1o) {
      return this.f.x.a.m ? null : super.d(param1o);
    }
  }
  
  public class i extends RecyclerView {
    public i(ViewPager2 this$0, Context param1Context) {
      super(param1Context);
    }
    
    public CharSequence getAccessibilityClassName() {
      Objects.requireNonNull(this.b.D);
      return super.getAccessibilityClassName();
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setFromIndex(this.b.f);
      param1AccessibilityEvent.setToIndex(this.b.f);
      param1AccessibilityEvent.setSource((View)((ViewPager2.f)this.b.D).d);
      param1AccessibilityEvent.setClassName("androidx.viewpager.widget.ViewPager");
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      return (this.b.B && super.onInterceptTouchEvent(param1MotionEvent));
    }
    
    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      return (this.b.B && super.onTouchEvent(param1MotionEvent));
    }
  }
  
  public static class j extends View.BaseSavedState {
    public static final Parcelable.Creator<j> CREATOR = (Parcelable.Creator<j>)new a();
    
    public int b;
    
    public int c;
    
    public Parcelable d;
    
    public j(Parcel param1Parcel) {
      super(param1Parcel);
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readParcelable(null);
    }
    
    public j(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readParcelable(param1ClassLoader);
    }
    
    public j(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.b);
      param1Parcel.writeInt(this.c);
      param1Parcel.writeParcelable(this.d, param1Int);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<j> {
      public Object createFromParcel(Parcel param2Parcel) {
        return (Build.VERSION.SDK_INT >= 24) ? new ViewPager2.j(param2Parcel, null) : new ViewPager2.j(param2Parcel);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return (Build.VERSION.SDK_INT >= 24) ? new ViewPager2.j(param2Parcel, param2ClassLoader) : new ViewPager2.j(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new ViewPager2.j[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<j> {
    public Object createFromParcel(Parcel param1Parcel) {
      return (Build.VERSION.SDK_INT >= 24) ? new ViewPager2.j(param1Parcel, null) : new ViewPager2.j(param1Parcel);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return (Build.VERSION.SDK_INT >= 24) ? new ViewPager2.j(param1Parcel, param1ClassLoader) : new ViewPager2.j(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new ViewPager2.j[param1Int];
    }
  }
  
  public static class k implements Runnable {
    public final int b;
    
    public final RecyclerView c;
    
    public k(int param1Int, RecyclerView param1RecyclerView) {
      this.b = param1Int;
      this.c = param1RecyclerView;
    }
    
    public void run() {
      this.c.smoothScrollToPosition(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\viewpager2\widget\ViewPager2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */