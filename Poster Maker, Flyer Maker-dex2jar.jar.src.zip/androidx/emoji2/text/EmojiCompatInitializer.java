package androidx.emoji2.text;

import android.content.Context;
import android.os.Trace;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.ProcessLifecycleInitializer;
import bg;
import cc;
import gg;
import ho;
import io;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;
import qj;
import uj;
import vj;

public class EmojiCompatInitializer implements io<Boolean> {
  public Boolean b(Context paramContext) {
    a a = new a(paramContext);
    if (gg.b == null)
      synchronized (gg.a) {
        if (gg.b == null)
          gg.b = new gg(a); 
      }  
    ho ho = ho.b(paramContext);
    Objects.requireNonNull(ho);
    qj qj = ((vj)ho.a(ProcessLifecycleInitializer.class, new HashSet())).getLifecycle();
    qj.a((uj)new EmojiCompatInitializer$1(this, qj));
    return Boolean.TRUE;
  }
  
  public List<Class<? extends io<?>>> dependencies() {
    return (List)Collections.singletonList(ProcessLifecycleInitializer.class);
  }
  
  public static class a extends gg.c {
    public a(Context param1Context) {
      super(new EmojiCompatInitializer.b(param1Context));
      this.b = 1;
    }
  }
  
  public static class b implements gg.g {
    public final Context a;
    
    public b(Context param1Context) {
      this.a = param1Context.getApplicationContext();
    }
    
    public void a(gg.h param1h) {
      ThreadPoolExecutor threadPoolExecutor = ComponentActivity.c.B("EmojiCompatInitializer");
      threadPoolExecutor.execute((Runnable)new bg(this, param1h, threadPoolExecutor));
    }
  }
  
  public static class c implements Runnable {
    public void run() {
      try {
        int i = cc.a;
        Trace.beginSection("EmojiCompat.EmojiCompatInitializer.run");
        return;
      } finally {
        int i = cc.a;
        Trace.endSection();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */