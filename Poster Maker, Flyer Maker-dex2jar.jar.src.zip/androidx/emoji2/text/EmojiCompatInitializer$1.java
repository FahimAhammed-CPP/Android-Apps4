package androidx.emoji2.text;

import androidx.activity.ComponentActivity;
import java.util.Objects;
import lj;
import mj;
import qj;
import vj;
import wj;

public class EmojiCompatInitializer$1 implements mj {
  public EmojiCompatInitializer$1(EmojiCompatInitializer paramEmojiCompatInitializer, qj paramqj) {}
  
  public void a(vj paramvj) {
    Objects.requireNonNull(this.b);
    ComponentActivity.c.j0().postDelayed(new EmojiCompatInitializer.c(), 500L);
    wj wj = (wj)this.a;
    wj.d("removeObserver");
    wj.a.e(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */