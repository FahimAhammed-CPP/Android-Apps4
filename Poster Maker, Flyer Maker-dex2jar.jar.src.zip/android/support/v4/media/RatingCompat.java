package android.support.v4.media;

import android.annotation.SuppressLint;
import android.media.Rating;
import android.os.Parcel;
import android.os.Parcelable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import s30;

@SuppressLint({"BanParcelableUsage"})
public final class RatingCompat implements Parcelable {
  public static final Parcelable.Creator<RatingCompat> CREATOR = new Parcelable.Creator<RatingCompat>() {
      public RatingCompat createFromParcel(Parcel param1Parcel) {
        return new RatingCompat(param1Parcel.readInt(), param1Parcel.readFloat());
      }
      
      public RatingCompat[] newArray(int param1Int) {
        return new RatingCompat[param1Int];
      }
    };
  
  public static final int RATING_3_STARS = 3;
  
  public static final int RATING_4_STARS = 4;
  
  public static final int RATING_5_STARS = 5;
  
  public static final int RATING_HEART = 1;
  
  public static final int RATING_NONE = 0;
  
  private static final float RATING_NOT_RATED = -1.0F;
  
  public static final int RATING_PERCENTAGE = 6;
  
  public static final int RATING_THUMB_UP_DOWN = 2;
  
  private static final String TAG = "Rating";
  
  private Object mRatingObj;
  
  private final int mRatingStyle;
  
  private final float mRatingValue;
  
  public RatingCompat(int paramInt, float paramFloat) {
    this.mRatingStyle = paramInt;
    this.mRatingValue = paramFloat;
  }
  
  public static RatingCompat fromRating(Object paramObject) {
    RatingCompat ratingCompat;
    Rating rating = null;
    if (paramObject != null) {
      rating = (Rating)paramObject;
      int i = Api19Impl.getRatingStyle(rating);
      if (Api19Impl.isRated(rating)) {
        switch (i) {
          default:
            return null;
          case 6:
            ratingCompat = newPercentageRating(Api19Impl.getPercentRating(rating));
            break;
          case 3:
          case 4:
          case 5:
            ratingCompat = newStarRating(i, Api19Impl.getStarRating((Rating)ratingCompat));
            break;
          case 2:
            ratingCompat = newThumbRating(Api19Impl.isThumbUp((Rating)ratingCompat));
            break;
          case 1:
            ratingCompat = newHeartRating(Api19Impl.hasHeart((Rating)ratingCompat));
            break;
        } 
      } else {
        ratingCompat = newUnratedRating(i);
      } 
      ratingCompat.mRatingObj = paramObject;
    } 
    return ratingCompat;
  }
  
  public static RatingCompat newHeartRating(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return new RatingCompat(1, f);
  }
  
  public static RatingCompat newPercentageRating(float paramFloat) {
    return (paramFloat < 0.0F || paramFloat > 100.0F) ? null : new RatingCompat(6, paramFloat);
  }
  
  public static RatingCompat newStarRating(int paramInt, float paramFloat) {
    float f;
    if (paramInt != 3) {
      if (paramInt != 4) {
        if (paramInt != 5)
          return null; 
        f = 5.0F;
      } else {
        f = 4.0F;
      } 
    } else {
      f = 3.0F;
    } 
    return (paramFloat >= 0.0F) ? ((paramFloat > f) ? null : new RatingCompat(paramInt, paramFloat)) : null;
  }
  
  public static RatingCompat newThumbRating(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return new RatingCompat(2, f);
  }
  
  public static RatingCompat newUnratedRating(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
        break;
    } 
    return new RatingCompat(paramInt, -1.0F);
  }
  
  public int describeContents() {
    return this.mRatingStyle;
  }
  
  public float getPercentRating() {
    return (this.mRatingStyle != 6 || !isRated()) ? -1.0F : this.mRatingValue;
  }
  
  public Object getRating() {
    if (this.mRatingObj == null)
      if (isRated()) {
        int i = this.mRatingStyle;
        switch (i) {
          default:
            return null;
          case 6:
            this.mRatingObj = Api19Impl.newPercentageRating(getPercentRating());
            return this.mRatingObj;
          case 3:
          case 4:
          case 5:
            this.mRatingObj = Api19Impl.newStarRating(i, getStarRating());
            return this.mRatingObj;
          case 2:
            this.mRatingObj = Api19Impl.newThumbRating(isThumbUp());
            return this.mRatingObj;
          case 1:
            break;
        } 
        this.mRatingObj = Api19Impl.newHeartRating(hasHeart());
      } else {
        this.mRatingObj = Api19Impl.newUnratedRating(this.mRatingStyle);
      }  
    return this.mRatingObj;
  }
  
  public int getRatingStyle() {
    return this.mRatingStyle;
  }
  
  public float getStarRating() {
    int i = this.mRatingStyle;
    return ((i == 3 || i == 4 || i == 5) && isRated()) ? this.mRatingValue : -1.0F;
  }
  
  public boolean hasHeart() {
    int i = this.mRatingStyle;
    boolean bool = false;
    if (i != 1)
      return false; 
    if (this.mRatingValue == 1.0F)
      bool = true; 
    return bool;
  }
  
  public boolean isRated() {
    return (this.mRatingValue >= 0.0F);
  }
  
  public boolean isThumbUp() {
    int i = this.mRatingStyle;
    boolean bool = false;
    if (i != 2)
      return false; 
    if (this.mRatingValue == 1.0F)
      bool = true; 
    return bool;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = s30.x0("Rating:style=");
    stringBuilder.append(this.mRatingStyle);
    stringBuilder.append(" rating=");
    float f = this.mRatingValue;
    if (f < 0.0F) {
      str = "unrated";
    } else {
      str = String.valueOf(f);
    } 
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mRatingStyle);
    paramParcel.writeFloat(this.mRatingValue);
  }
  
  public static class Api19Impl {
    public static float getPercentRating(Rating param1Rating) {
      return param1Rating.getPercentRating();
    }
    
    public static int getRatingStyle(Rating param1Rating) {
      return param1Rating.getRatingStyle();
    }
    
    public static float getStarRating(Rating param1Rating) {
      return param1Rating.getStarRating();
    }
    
    public static boolean hasHeart(Rating param1Rating) {
      return param1Rating.hasHeart();
    }
    
    public static boolean isRated(Rating param1Rating) {
      return param1Rating.isRated();
    }
    
    public static boolean isThumbUp(Rating param1Rating) {
      return param1Rating.isThumbUp();
    }
    
    public static Rating newHeartRating(boolean param1Boolean) {
      return Rating.newHeartRating(param1Boolean);
    }
    
    public static Rating newPercentageRating(float param1Float) {
      return Rating.newPercentageRating(param1Float);
    }
    
    public static Rating newStarRating(int param1Int, float param1Float) {
      return Rating.newStarRating(param1Int, param1Float);
    }
    
    public static Rating newThumbRating(boolean param1Boolean) {
      return Rating.newThumbRating(param1Boolean);
    }
    
    public static Rating newUnratedRating(int param1Int) {
      return Rating.newUnratedRating(param1Int);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface StarStyle {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Style {}
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\android\support\v4\media\RatingCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */