package android.support.v4.media;

import androidx.media.AudioAttributesImplBase;
import androidx.media.AudioAttributesImplBaseParcelizer;
import eq;

public final class AudioAttributesImplBaseParcelizer extends AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(eq parameq) {
    return AudioAttributesImplBaseParcelizer.read(parameq);
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, eq parameq) {
    AudioAttributesImplBaseParcelizer.write(paramAudioAttributesImplBase, parameq);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Poster Maker, Flyer Maker-dex2jar.jar!\android\support\v4\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */