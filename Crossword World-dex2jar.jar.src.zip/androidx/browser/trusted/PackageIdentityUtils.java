package androidx.browser.trusted;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.util.Log;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

class PackageIdentityUtils {
  private static final String TAG = "PackageIdentity";
  
  static byte[] getCertificateSHA256Fingerprint(Signature paramSignature) {
    try {
      return MessageDigest.getInstance("SHA256").digest(paramSignature.toByteArray());
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      return null;
    } 
  }
  
  static List<byte[]> getFingerprintsForPackage(String paramString, PackageManager paramPackageManager) {
    try {
      return getImpl().getFingerprintsForPackage(paramString, paramPackageManager);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("PackageIdentity", "Could not get fingerprint for package.", (Throwable)nameNotFoundException);
      return null;
    } 
  }
  
  private static SignaturesCompat getImpl() {
    return (SignaturesCompat)((Build.VERSION.SDK_INT >= 28) ? new Api28Implementation() : new Pre28Implementation());
  }
  
  static boolean packageMatchesToken(String paramString, PackageManager paramPackageManager, TokenContents paramTokenContents) {
    try {
      return getImpl().packageMatchesToken(paramString, paramPackageManager, paramTokenContents);
    } catch (IOException iOException) {
    
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    Log.e("PackageIdentity", "Could not check if package matches token.", (Throwable)nameNotFoundException);
    return false;
  }
  
  static class Api28Implementation implements SignaturesCompat {
    public List<byte[]> getFingerprintsForPackage(String param1String, PackageManager param1PackageManager) throws PackageManager.NameNotFoundException {
      Signature[] arrayOfSignature;
      PackageInfo packageInfo = param1PackageManager.getPackageInfo(param1String, 134217728);
      ArrayList<byte[]> arrayList = new ArrayList();
      SigningInfo signingInfo = packageInfo.signingInfo;
      boolean bool = signingInfo.hasMultipleSigners();
      int i = 0;
      if (bool) {
        arrayOfSignature = signingInfo.getApkContentsSigners();
        int j = arrayOfSignature.length;
        while (i < j) {
          arrayList.add(PackageIdentityUtils.getCertificateSHA256Fingerprint(arrayOfSignature[i]));
          i++;
        } 
      } else {
        arrayList.add(PackageIdentityUtils.getCertificateSHA256Fingerprint(arrayOfSignature.getSigningCertificateHistory()[0]));
      } 
      return (List<byte[]>)arrayList;
    }
    
    public boolean packageMatchesToken(String param1String, PackageManager param1PackageManager, TokenContents param1TokenContents) throws PackageManager.NameNotFoundException, IOException {
      if (!param1TokenContents.getPackageName().equals(param1String))
        return false; 
      List<byte[]> list = getFingerprintsForPackage(param1String, param1PackageManager);
      return (list == null) ? false : ((list.size() == 1) ? param1PackageManager.hasSigningCertificate(param1String, param1TokenContents.getFingerprint(0), 1) : param1TokenContents.equals(TokenContents.create(param1String, list)));
    }
  }
  
  static class Pre28Implementation implements SignaturesCompat {
    public List<byte[]> getFingerprintsForPackage(String param1String, PackageManager param1PackageManager) throws PackageManager.NameNotFoundException {
      PackageInfo packageInfo = param1PackageManager.getPackageInfo(param1String, 64);
      ArrayList<byte[]> arrayList = new ArrayList(packageInfo.signatures.length);
      Signature[] arrayOfSignature = packageInfo.signatures;
      int j = arrayOfSignature.length;
      for (int i = 0; i < j; i++) {
        byte[] arrayOfByte = PackageIdentityUtils.getCertificateSHA256Fingerprint(arrayOfSignature[i]);
        if (arrayOfByte == null)
          return null; 
        arrayList.add(arrayOfByte);
      } 
      return (List<byte[]>)arrayList;
    }
    
    public boolean packageMatchesToken(String param1String, PackageManager param1PackageManager, TokenContents param1TokenContents) throws IOException, PackageManager.NameNotFoundException {
      if (!param1String.equals(param1TokenContents.getPackageName()))
        return false; 
      List<byte[]> list = getFingerprintsForPackage(param1String, param1PackageManager);
      return (list == null) ? false : param1TokenContents.equals(TokenContents.create(param1String, list));
    }
  }
  
  static interface SignaturesCompat {
    List<byte[]> getFingerprintsForPackage(String param1String, PackageManager param1PackageManager) throws PackageManager.NameNotFoundException;
    
    boolean packageMatchesToken(String param1String, PackageManager param1PackageManager, TokenContents param1TokenContents) throws IOException, PackageManager.NameNotFoundException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\browser\trusted\PackageIdentityUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */