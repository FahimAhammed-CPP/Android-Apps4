package androidx.browser.trusted;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.customtabs.trusted.ITrustedWebActivityService;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class ConnectionHolder implements ServiceConnection {
  private static final int STATE_AWAITING_CONNECTION = 0;
  
  private static final int STATE_CANCELLED = 3;
  
  private static final int STATE_CONNECTED = 1;
  
  private static final int STATE_DISCONNECTED = 2;
  
  private Exception mCancellationException;
  
  private final Runnable mCloseRunnable;
  
  private List<CallbackToFutureAdapter.Completer<TrustedWebActivityServiceConnection>> mCompleters = new ArrayList<CallbackToFutureAdapter.Completer<TrustedWebActivityServiceConnection>>();
  
  private TrustedWebActivityServiceConnection mService;
  
  private int mState = 0;
  
  private final WrapperFactory mWrapperFactory;
  
  ConnectionHolder(Runnable paramRunnable) {
    this(paramRunnable, new WrapperFactory());
  }
  
  ConnectionHolder(Runnable paramRunnable, WrapperFactory paramWrapperFactory) {
    this.mCloseRunnable = paramRunnable;
    this.mWrapperFactory = paramWrapperFactory;
  }
  
  public void cancel(Exception paramException) {
    Iterator<CallbackToFutureAdapter.Completer<TrustedWebActivityServiceConnection>> iterator = this.mCompleters.iterator();
    while (iterator.hasNext())
      ((CallbackToFutureAdapter.Completer)iterator.next()).setException(paramException); 
    this.mCompleters.clear();
    this.mCloseRunnable.run();
    this.mState = 3;
    this.mCancellationException = paramException;
  }
  
  public ListenableFuture<TrustedWebActivityServiceConnection> getServiceWrapper() {
    return CallbackToFutureAdapter.getFuture(new -$$Lambda$ConnectionHolder$AU_vyFTWietXr1KAI5OuiE799PQ(this));
  }
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    this.mService = this.mWrapperFactory.create(paramComponentName, paramIBinder);
    Iterator<CallbackToFutureAdapter.Completer<TrustedWebActivityServiceConnection>> iterator = this.mCompleters.iterator();
    while (iterator.hasNext())
      ((CallbackToFutureAdapter.Completer)iterator.next()).set(this.mService); 
    this.mCompleters.clear();
    this.mState = 1;
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    this.mService = null;
    this.mCloseRunnable.run();
    this.mState = 2;
  }
  
  static class WrapperFactory {
    TrustedWebActivityServiceConnection create(ComponentName param1ComponentName, IBinder param1IBinder) {
      return new TrustedWebActivityServiceConnection(ITrustedWebActivityService.Stub.asInterface(param1IBinder), param1ComponentName);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\browser\trusted\ConnectionHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */