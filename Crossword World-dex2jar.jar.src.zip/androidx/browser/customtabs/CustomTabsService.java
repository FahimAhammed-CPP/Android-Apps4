package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.customtabs.ICustomTabsCallback;
import android.support.customtabs.ICustomTabsService;
import androidx.collection.SimpleArrayMap;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.NoSuchElementException;

public abstract class CustomTabsService extends Service {
  public static final String ACTION_CUSTOM_TABS_CONNECTION = "android.support.customtabs.action.CustomTabsService";
  
  public static final String CATEGORY_COLOR_SCHEME_CUSTOMIZATION = "androidx.browser.customtabs.category.ColorSchemeCustomization";
  
  public static final String CATEGORY_NAVBAR_COLOR_CUSTOMIZATION = "androidx.browser.customtabs.category.NavBarColorCustomization";
  
  public static final String CATEGORY_TRUSTED_WEB_ACTIVITY_IMMERSIVE_MODE = "androidx.browser.trusted.category.ImmersiveMode";
  
  public static final String CATEGORY_WEB_SHARE_TARGET_V2 = "androidx.browser.trusted.category.WebShareTargetV2";
  
  public static final int FILE_PURPOSE_TRUSTED_WEB_ACTIVITY_SPLASH_IMAGE = 1;
  
  public static final String KEY_SUCCESS = "androidx.browser.customtabs.SUCCESS";
  
  public static final String KEY_URL = "android.support.customtabs.otherurls.URL";
  
  public static final int RELATION_HANDLE_ALL_URLS = 2;
  
  public static final int RELATION_USE_AS_ORIGIN = 1;
  
  public static final int RESULT_FAILURE_DISALLOWED = -1;
  
  public static final int RESULT_FAILURE_MESSAGING_ERROR = -3;
  
  public static final int RESULT_FAILURE_REMOTE_ERROR = -2;
  
  public static final int RESULT_SUCCESS = 0;
  
  public static final String TRUSTED_WEB_ACTIVITY_CATEGORY = "androidx.browser.trusted.category.TrustedWebActivities";
  
  private ICustomTabsService.Stub mBinder = new ICustomTabsService.Stub() {
      private PendingIntent getSessionIdFromBundle(Bundle param1Bundle) {
        if (param1Bundle == null)
          return null; 
        PendingIntent pendingIntent = (PendingIntent)param1Bundle.getParcelable("android.support.customtabs.extra.SESSION_ID");
        param1Bundle.remove("android.support.customtabs.extra.SESSION_ID");
        return pendingIntent;
      }
      
      private boolean newSessionInternal(ICustomTabsCallback param1ICustomTabsCallback, PendingIntent param1PendingIntent) {
        CustomTabsSessionToken customTabsSessionToken = new CustomTabsSessionToken(param1ICustomTabsCallback, param1PendingIntent);
        try {
          -$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M -$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M = new -$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M(this, customTabsSessionToken);
          synchronized (CustomTabsService.this.mDeathRecipientMap) {
            param1ICustomTabsCallback.asBinder().linkToDeath(-$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M, 0);
            CustomTabsService.this.mDeathRecipientMap.put(param1ICustomTabsCallback.asBinder(), -$$Lambda$CustomTabsService$1$3KabmmsBQr_A7ceXhU8FiwltY6M);
            return CustomTabsService.this.newSession(customTabsSessionToken);
          } 
        } catch (RemoteException remoteException) {
          return false;
        } 
      }
      
      public Bundle extraCommand(String param1String, Bundle param1Bundle) {
        return CustomTabsService.this.extraCommand(param1String, param1Bundle);
      }
      
      public boolean mayLaunchUrl(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri, Bundle param1Bundle, List<Bundle> param1List) {
        return CustomTabsService.this.mayLaunchUrl(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1Uri, param1Bundle, param1List);
      }
      
      public boolean newSession(ICustomTabsCallback param1ICustomTabsCallback) {
        return newSessionInternal(param1ICustomTabsCallback, null);
      }
      
      public boolean newSessionWithExtras(ICustomTabsCallback param1ICustomTabsCallback, Bundle param1Bundle) {
        return newSessionInternal(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle));
      }
      
      public int postMessage(ICustomTabsCallback param1ICustomTabsCallback, String param1String, Bundle param1Bundle) {
        return CustomTabsService.this.postMessage(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1String, param1Bundle);
      }
      
      public boolean receiveFile(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri, int param1Int, Bundle param1Bundle) {
        return CustomTabsService.this.receiveFile(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1Uri, param1Int, param1Bundle);
      }
      
      public boolean requestPostMessageChannel(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri) {
        return CustomTabsService.this.requestPostMessageChannel(new CustomTabsSessionToken(param1ICustomTabsCallback, null), param1Uri);
      }
      
      public boolean requestPostMessageChannelWithExtras(ICustomTabsCallback param1ICustomTabsCallback, Uri param1Uri, Bundle param1Bundle) {
        return CustomTabsService.this.requestPostMessageChannel(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1Uri);
      }
      
      public boolean updateVisuals(ICustomTabsCallback param1ICustomTabsCallback, Bundle param1Bundle) {
        return CustomTabsService.this.updateVisuals(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1Bundle);
      }
      
      public boolean validateRelationship(ICustomTabsCallback param1ICustomTabsCallback, int param1Int, Uri param1Uri, Bundle param1Bundle) {
        return CustomTabsService.this.validateRelationship(new CustomTabsSessionToken(param1ICustomTabsCallback, getSessionIdFromBundle(param1Bundle)), param1Int, param1Uri, param1Bundle);
      }
      
      public boolean warmup(long param1Long) {
        return CustomTabsService.this.warmup(param1Long);
      }
    };
  
  final SimpleArrayMap<IBinder, IBinder.DeathRecipient> mDeathRecipientMap = new SimpleArrayMap();
  
  protected boolean cleanUpSession(CustomTabsSessionToken paramCustomTabsSessionToken) {
    try {
      synchronized (this.mDeathRecipientMap) {
        IBinder iBinder = paramCustomTabsSessionToken.getCallbackBinder();
        if (iBinder == null)
          return false; 
        iBinder.unlinkToDeath((IBinder.DeathRecipient)this.mDeathRecipientMap.get(iBinder), 0);
        this.mDeathRecipientMap.remove(iBinder);
        return true;
      } 
    } catch (NoSuchElementException noSuchElementException) {
      return false;
    } 
  }
  
  protected abstract Bundle extraCommand(String paramString, Bundle paramBundle);
  
  protected abstract boolean mayLaunchUrl(CustomTabsSessionToken paramCustomTabsSessionToken, Uri paramUri, Bundle paramBundle, List<Bundle> paramList);
  
  protected abstract boolean newSession(CustomTabsSessionToken paramCustomTabsSessionToken);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.mBinder;
  }
  
  protected abstract int postMessage(CustomTabsSessionToken paramCustomTabsSessionToken, String paramString, Bundle paramBundle);
  
  protected abstract boolean receiveFile(CustomTabsSessionToken paramCustomTabsSessionToken, Uri paramUri, int paramInt, Bundle paramBundle);
  
  protected abstract boolean requestPostMessageChannel(CustomTabsSessionToken paramCustomTabsSessionToken, Uri paramUri);
  
  protected abstract boolean updateVisuals(CustomTabsSessionToken paramCustomTabsSessionToken, Bundle paramBundle);
  
  protected abstract boolean validateRelationship(CustomTabsSessionToken paramCustomTabsSessionToken, int paramInt, Uri paramUri, Bundle paramBundle);
  
  protected abstract boolean warmup(long paramLong);
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface FilePurpose {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Relation {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Result {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\browser\customtabs\CustomTabsService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */