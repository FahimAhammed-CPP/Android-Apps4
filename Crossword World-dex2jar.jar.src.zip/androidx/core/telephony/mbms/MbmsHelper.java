package androidx.core.telephony.mbms;

import android.content.Context;
import android.os.Build;
import android.telephony.mbms.ServiceInfo;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

public final class MbmsHelper {
  public static CharSequence getBestNameForService(Context paramContext, ServiceInfo paramServiceInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getBestNameForService(paramContext, paramServiceInfo) : null;
  }
  
  static class Api28Impl {
    static CharSequence getBestNameForService(Context param1Context, ServiceInfo param1ServiceInfo) {
      Set set = param1ServiceInfo.getNamedContentLocales();
      if (set.isEmpty())
        return null; 
      String[] arrayOfString = new String[set.size()];
      int i = 0;
      Iterator<Locale> iterator = param1ServiceInfo.getNamedContentLocales().iterator();
      while (iterator.hasNext()) {
        arrayOfString[i] = ((Locale)iterator.next()).toLanguageTag();
        i++;
      } 
      Locale locale = param1Context.getResources().getConfiguration().getLocales().getFirstMatch(arrayOfString);
      return (locale == null) ? null : param1ServiceInfo.getNameForLocale(locale);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\telephony\mbms\MbmsHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */