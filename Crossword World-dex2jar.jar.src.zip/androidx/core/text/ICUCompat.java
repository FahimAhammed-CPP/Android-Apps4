package androidx.core.text;

import android.icu.util.ULocale;
import android.os.Build;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public final class ICUCompat {
  private static final String TAG = "ICUCompat";
  
  private static Method sAddLikelySubtagsMethod;
  
  private static Method sGetScriptMethod;
  
  static {
    if (Build.VERSION.SDK_INT < 21)
      try {
        Class<?> clazz = Class.forName("libcore.icu.ICU");
        sGetScriptMethod = clazz.getMethod("getScript", new Class[] { String.class });
        sAddLikelySubtagsMethod = clazz.getMethod("addLikelySubtags", new Class[] { String.class });
        return;
      } catch (Exception exception) {
        sGetScriptMethod = null;
        sAddLikelySubtagsMethod = null;
        Log.w("ICUCompat", exception);
        return;
      }  
    if (Build.VERSION.SDK_INT < 24)
      try {
        sAddLikelySubtagsMethod = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[] { Locale.class });
        return;
      } catch (Exception exception) {
        throw new IllegalStateException(exception);
      }  
  }
  
  private static String addLikelySubtagsBelowApi21(Locale paramLocale) {
    String str = paramLocale.toString();
    try {
      if (sAddLikelySubtagsMethod != null)
        return (String)sAddLikelySubtagsMethod.invoke(null, new Object[] { str }); 
    } catch (IllegalAccessException illegalAccessException) {
      Log.w("ICUCompat", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Log.w("ICUCompat", invocationTargetException);
      return str;
    } 
    return str;
  }
  
  private static String getScriptBelowApi21(String paramString) {
    try {
      if (sGetScriptMethod != null)
        return (String)sGetScriptMethod.invoke(null, new Object[] { paramString }); 
    } catch (IllegalAccessException illegalAccessException) {
      Log.w("ICUCompat", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Log.w("ICUCompat", invocationTargetException);
      return null;
    } 
    return null;
  }
  
  public static String maximizeAndGetScript(Locale paramLocale) {
    if (Build.VERSION.SDK_INT >= 24)
      return Api24Impl.getScript(Api24Impl.addLikelySubtags(Api24Impl.forLocale(paramLocale))); 
    if (Build.VERSION.SDK_INT >= 21) {
      try {
        return Api21Impl.getScript((Locale)sAddLikelySubtagsMethod.invoke(null, new Object[] { paramLocale }));
      } catch (InvocationTargetException invocationTargetException) {
        Log.w("ICUCompat", invocationTargetException);
      } catch (IllegalAccessException illegalAccessException) {
        Log.w("ICUCompat", illegalAccessException);
      } 
      return Api21Impl.getScript(paramLocale);
    } 
    String str = addLikelySubtagsBelowApi21(paramLocale);
    return (str != null) ? getScriptBelowApi21(str) : null;
  }
  
  static class Api21Impl {
    static String getScript(Locale param1Locale) {
      return param1Locale.getScript();
    }
  }
  
  static class Api24Impl {
    static ULocale addLikelySubtags(Object param1Object) {
      return ULocale.addLikelySubtags((ULocale)param1Object);
    }
    
    static ULocale forLocale(Locale param1Locale) {
      return ULocale.forLocale(param1Locale);
    }
    
    static String getScript(Object param1Object) {
      return ((ULocale)param1Object).getScript();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\text\ICUCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */