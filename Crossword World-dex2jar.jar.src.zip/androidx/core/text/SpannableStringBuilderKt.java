package androidx.core.text;

import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.UnderlineSpan;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000:\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\000\n\000\n\002\020\021\n\002\b\004\n\002\020\007\n\002\b\005\032%\020\000\032\0020\0012\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\0323\020\007\032\0020\004*\0020\0042\b\b\001\020\b\032\0020\t2\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032)\020\n\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\0323\020\b\032\0020\004*\0020\0042\b\b\001\020\b\032\0020\t2\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\0321\020\013\032\0020\004*\0020\0042\006\020\f\032\0020\r2\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032B\020\013\032\0020\004*\0020\0042\022\020\016\032\n\022\006\b\001\022\0020\r0\017\"\0020\r2\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000¢\006\002\020\020\032)\020\021\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\0321\020\022\032\0020\004*\0020\0042\006\020\023\032\0020\0242\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032)\020\025\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032)\020\026\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032)\020\027\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\032)\020\030\032\0020\004*\0020\0042\027\020\002\032\023\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\002\b\006H\bø\001\000\002\007\n\005\b20\001¨\006\031"}, d2 = {"buildSpannedString", "Landroid/text/SpannedString;", "builderAction", "Lkotlin/Function1;", "Landroid/text/SpannableStringBuilder;", "", "Lkotlin/ExtensionFunctionType;", "backgroundColor", "color", "", "bold", "inSpans", "span", "", "spans", "", "(Landroid/text/SpannableStringBuilder;[Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Landroid/text/SpannableStringBuilder;", "italic", "scale", "proportion", "", "strikeThrough", "subscript", "superscript", "underline", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class SpannableStringBuilderKt {
  public static final SpannableStringBuilder backgroundColor(SpannableStringBuilder paramSpannableStringBuilder, int paramInt, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    BackgroundColorSpan backgroundColorSpan = new BackgroundColorSpan(paramInt);
    paramInt = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(backgroundColorSpan, paramInt, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder bold(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    StyleSpan styleSpan = new StyleSpan(1);
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(styleSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannedString buildSpannedString(Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
    paramFunction1.invoke(spannableStringBuilder);
    return new SpannedString((CharSequence)spannableStringBuilder);
  }
  
  public static final SpannableStringBuilder color(SpannableStringBuilder paramSpannableStringBuilder, int paramInt, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(paramInt);
    paramInt = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(foregroundColorSpan, paramInt, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder inSpans(SpannableStringBuilder paramSpannableStringBuilder, Object paramObject, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramObject, "span");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(paramObject, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder inSpans(SpannableStringBuilder paramSpannableStringBuilder, Object[] paramArrayOfObject, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramArrayOfObject, "spans");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    int j = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    int k = paramArrayOfObject.length;
    for (int i = 0; i < k; i++)
      paramSpannableStringBuilder.setSpan(paramArrayOfObject[i], j, paramSpannableStringBuilder.length(), 17); 
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder italic(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    StyleSpan styleSpan = new StyleSpan(2);
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(styleSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder scale(SpannableStringBuilder paramSpannableStringBuilder, float paramFloat, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    RelativeSizeSpan relativeSizeSpan = new RelativeSizeSpan(paramFloat);
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(relativeSizeSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder strikeThrough(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    StrikethroughSpan strikethroughSpan = new StrikethroughSpan();
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(strikethroughSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder subscript(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    SubscriptSpan subscriptSpan = new SubscriptSpan();
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(subscriptSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder superscript(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    SuperscriptSpan superscriptSpan = new SuperscriptSpan();
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(superscriptSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
  
  public static final SpannableStringBuilder underline(SpannableStringBuilder paramSpannableStringBuilder, Function1<? super SpannableStringBuilder, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramSpannableStringBuilder, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "builderAction");
    UnderlineSpan underlineSpan = new UnderlineSpan();
    int i = paramSpannableStringBuilder.length();
    paramFunction1.invoke(paramSpannableStringBuilder);
    paramSpannableStringBuilder.setSpan(underlineSpan, i, paramSpannableStringBuilder.length(), 17);
    return paramSpannableStringBuilder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\text\SpannableStringBuilderKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */