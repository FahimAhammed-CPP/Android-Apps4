package androidx.core.text.util;

import java.util.Comparator;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\tex\\util\-$$Lambda$LinkifyCompat$nt9PERUlPSYYalCm-wKpkQ4BBCw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */