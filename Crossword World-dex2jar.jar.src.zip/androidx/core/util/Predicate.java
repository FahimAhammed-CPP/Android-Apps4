package androidx.core.util;

public interface Predicate<T> {
  Predicate<T> and(Predicate<? super T> paramPredicate);
  
  Predicate<T> negate();
  
  Predicate<T> or(Predicate<? super T> paramPredicate);
  
  boolean test(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\cor\\util\Predicate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */