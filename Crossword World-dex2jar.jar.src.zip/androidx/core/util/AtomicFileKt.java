package androidx.core.util;

import android.util.AtomicFile;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

@Metadata(d1 = {"\000.\n\000\n\002\020\022\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\007\032\r\020\000\032\0020\001*\0020\002H\b\032\026\020\003\032\0020\004*\0020\0022\b\b\002\020\005\032\0020\006H\007\0323\020\007\032\0020\b*\0020\0022!\020\t\032\035\022\023\022\0210\013¢\006\f\b\f\022\b\b\r\022\004\b\b(\016\022\004\022\0020\b0\nH\bø\001\000\032\024\020\017\032\0020\b*\0020\0022\006\020\020\032\0020\001H\007\032\036\020\021\032\0020\b*\0020\0022\006\020\022\032\0020\0042\b\b\002\020\005\032\0020\006H\007\002\007\n\005\b20\001¨\006\023"}, d2 = {"readBytes", "", "Landroid/util/AtomicFile;", "readText", "", "charset", "Ljava/nio/charset/Charset;", "tryWrite", "", "block", "Lkotlin/Function1;", "Ljava/io/FileOutputStream;", "Lkotlin/ParameterName;", "name", "out", "writeBytes", "array", "writeText", "text", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class AtomicFileKt {
  public static final byte[] readBytes(AtomicFile paramAtomicFile) {
    Intrinsics.checkNotNullParameter(paramAtomicFile, "<this>");
    byte[] arrayOfByte = paramAtomicFile.readFully();
    Intrinsics.checkNotNullExpressionValue(arrayOfByte, "readFully()");
    return arrayOfByte;
  }
  
  public static final String readText(AtomicFile paramAtomicFile, Charset paramCharset) {
    Intrinsics.checkNotNullParameter(paramAtomicFile, "<this>");
    Intrinsics.checkNotNullParameter(paramCharset, "charset");
    byte[] arrayOfByte = paramAtomicFile.readFully();
    Intrinsics.checkNotNullExpressionValue(arrayOfByte, "readFully()");
    return new String(arrayOfByte, paramCharset);
  }
  
  public static final void tryWrite(AtomicFile paramAtomicFile, Function1<? super FileOutputStream, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAtomicFile, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "block");
    FileOutputStream fileOutputStream = paramAtomicFile.startWrite();
    try {
      Intrinsics.checkNotNullExpressionValue(fileOutputStream, "stream");
      paramFunction1.invoke(fileOutputStream);
      return;
    } finally {
      InlineMarker.finallyStart(1);
      paramAtomicFile.failWrite(fileOutputStream);
      InlineMarker.finallyEnd(1);
    } 
  }
  
  public static final void writeBytes(AtomicFile paramAtomicFile, byte[] paramArrayOfbyte) {
    Intrinsics.checkNotNullParameter(paramAtomicFile, "<this>");
    Intrinsics.checkNotNullParameter(paramArrayOfbyte, "array");
    FileOutputStream fileOutputStream = paramAtomicFile.startWrite();
    try {
      Intrinsics.checkNotNullExpressionValue(fileOutputStream, "stream");
      fileOutputStream.write(paramArrayOfbyte);
      return;
    } finally {
      paramAtomicFile.failWrite(fileOutputStream);
    } 
  }
  
  public static final void writeText(AtomicFile paramAtomicFile, String paramString, Charset paramCharset) {
    Intrinsics.checkNotNullParameter(paramAtomicFile, "<this>");
    Intrinsics.checkNotNullParameter(paramString, "text");
    Intrinsics.checkNotNullParameter(paramCharset, "charset");
    byte[] arrayOfByte = paramString.getBytes(paramCharset);
    Intrinsics.checkNotNullExpressionValue(arrayOfByte, "this as java.lang.String).getBytes(charset)");
    writeBytes(paramAtomicFile, arrayOfByte);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\cor\\util\AtomicFileKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */