package androidx.core.util;

import android.util.Pair;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\032\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\032*\020\000\032\002H\001\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\003H\n¢\006\002\020\004\032*\020\000\032\002H\001\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\005H\n¢\006\002\020\006\032*\020\007\032\002H\002\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\003H\n¢\006\002\020\004\032*\020\007\032\002H\002\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\005H\n¢\006\002\020\006\0321\020\b\032\016\022\004\022\002H\001\022\004\022\002H\0020\003\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\tH\b\0321\020\n\032\016\022\004\022\002H\001\022\004\022\002H\0020\005\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\tH\b\0321\020\013\032\016\022\004\022\002H\001\022\004\022\002H\0020\t\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\003H\b\0321\020\013\032\016\022\004\022\002H\001\022\004\022\002H\0020\t\"\004\b\000\020\001\"\004\b\001\020\002*\016\022\004\022\002H\001\022\004\022\002H\0020\005H\b¨\006\f"}, d2 = {"component1", "F", "S", "Landroid/util/Pair;", "(Landroid/util/Pair;)Ljava/lang/Object;", "Landroidx/core/util/Pair;", "(Landroidx/core/util/Pair;)Ljava/lang/Object;", "component2", "toAndroidPair", "Lkotlin/Pair;", "toAndroidXPair", "toKotlinPair", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class PairKt {
  public static final <F, S> F component1(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return (F)paramPair.first;
  }
  
  public static final <F, S> F component1(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return paramPair.first;
  }
  
  public static final <F, S> S component2(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return (S)paramPair.second;
  }
  
  public static final <F, S> S component2(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return paramPair.second;
  }
  
  public static final <F, S> Pair<F, S> toAndroidPair(Pair<? extends F, ? extends S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return new Pair(paramPair.getFirst(), paramPair.getSecond());
  }
  
  public static final <F, S> Pair<F, S> toAndroidXPair(Pair<? extends F, ? extends S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return new Pair<F, S>((F)paramPair.getFirst(), (S)paramPair.getSecond());
  }
  
  public static final <F, S> Pair<F, S> toKotlinPair(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return new Pair(paramPair.first, paramPair.second);
  }
  
  public static final <F, S> Pair<F, S> toKotlinPair(Pair<F, S> paramPair) {
    Intrinsics.checkNotNullParameter(paramPair, "<this>");
    return new Pair(paramPair.first, paramPair.second);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\cor\\util\PairKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */