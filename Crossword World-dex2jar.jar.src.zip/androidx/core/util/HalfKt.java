package androidx.core.util;

import android.util.Half;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\030\n\000\n\002\030\002\n\002\020\006\n\002\020\007\n\002\020\n\n\002\020\016\n\000\032\r\020\000\032\0020\001*\0020\002H\b\032\r\020\000\032\0020\001*\0020\003H\b\032\r\020\000\032\0020\001*\0020\004H\b\032\r\020\000\032\0020\001*\0020\005H\b¨\006\006"}, d2 = {"toHalf", "Landroid/util/Half;", "", "", "", "", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class HalfKt {
  public static final Half toHalf(double paramDouble) {
    Half half = Half.valueOf((float)paramDouble);
    Intrinsics.checkNotNullExpressionValue(half, "valueOf(this)");
    return half;
  }
  
  public static final Half toHalf(float paramFloat) {
    Half half = Half.valueOf(paramFloat);
    Intrinsics.checkNotNullExpressionValue(half, "valueOf(this)");
    return half;
  }
  
  public static final Half toHalf(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "<this>");
    Half half = Half.valueOf(paramString);
    Intrinsics.checkNotNullExpressionValue(half, "valueOf(this)");
    return half;
  }
  
  public static final Half toHalf(short paramShort) {
    Half half = Half.valueOf(paramShort);
    Intrinsics.checkNotNullExpressionValue(half, "valueOf(this)");
    return half;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\cor\\util\HalfKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */