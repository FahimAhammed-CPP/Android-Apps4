package androidx.core.location;

import androidx.core.os.CancellationSignal;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\-$$Lambda$Rm-tsL1vBLtxem9QO8Tljt80voA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */