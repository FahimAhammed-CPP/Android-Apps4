package androidx.core.location;

import android.content.Context;
import android.location.GnssMeasurementsEvent;
import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.location.LocationRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.collection.SimpleArrayMap;
import androidx.core.os.CancellationSignal;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.Consumer;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class LocationManagerCompat {
  private static final long GET_CURRENT_LOCATION_TIMEOUT_MS = 30000L;
  
  private static final long MAX_CURRENT_LOCATION_AGE_MS = 10000L;
  
  private static final long PRE_N_LOOPER_TIMEOUT_S = 5L;
  
  private static Field sContextField;
  
  private static Method sGnssRequestBuilderBuildMethod;
  
  private static Class<?> sGnssRequestBuilderClass;
  
  static final WeakHashMap<LocationListenerKey, WeakReference<LocationListenerTransport>> sLocationListeners = new WeakHashMap<LocationListenerKey, WeakReference<LocationListenerTransport>>();
  
  private static Method sRegisterGnssMeasurementsCallbackMethod;
  
  public static void getCurrentLocation(LocationManager paramLocationManager, String paramString, CancellationSignal paramCancellationSignal, Executor paramExecutor, Consumer<Location> paramConsumer) {
    if (Build.VERSION.SDK_INT >= 30) {
      Api30Impl.getCurrentLocation(paramLocationManager, paramString, paramCancellationSignal, paramExecutor, paramConsumer);
      return;
    } 
    if (paramCancellationSignal != null)
      paramCancellationSignal.throwIfCanceled(); 
    Location location = paramLocationManager.getLastKnownLocation(paramString);
    if (location != null && SystemClock.elapsedRealtime() - LocationCompat.getElapsedRealtimeMillis(location) < 10000L) {
      paramExecutor.execute(new -$$Lambda$LocationManagerCompat$SrSMNW-UkhqndmvA7sNfRlGt0Lc(paramConsumer, location));
      return;
    } 
    CancellableLocationListener cancellableLocationListener = new CancellableLocationListener(paramLocationManager, paramExecutor, paramConsumer);
    paramLocationManager.requestLocationUpdates(paramString, 0L, 0.0F, cancellableLocationListener, Looper.getMainLooper());
    if (paramCancellationSignal != null)
      paramCancellationSignal.setOnCancelListener(new -$$Lambda$Rm-tsL1vBLtxem9QO8Tljt80voA(cancellableLocationListener)); 
    cancellableLocationListener.startTimeout(30000L);
  }
  
  public static String getGnssHardwareModelName(LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssHardwareModelName(paramLocationManager) : null;
  }
  
  public static int getGnssYearOfHardware(LocationManager paramLocationManager) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getGnssYearOfHardware(paramLocationManager) : 0;
  }
  
  public static boolean hasProvider(LocationManager paramLocationManager, String paramString) {
    if (Build.VERSION.SDK_INT >= 31)
      return Api31Impl.hasProvider(paramLocationManager, paramString); 
    if (paramLocationManager.getAllProviders().contains(paramString))
      return true; 
    try {
      LocationProvider locationProvider = paramLocationManager.getProvider(paramString);
      return (locationProvider != null);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  public static boolean isLocationEnabled(LocationManager paramLocationManager) {
    if (Build.VERSION.SDK_INT >= 28)
      return Api28Impl.isLocationEnabled(paramLocationManager); 
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i <= 19)
      try {
        if (sContextField == null) {
          Field field = LocationManager.class.getDeclaredField("mContext");
          sContextField = field;
          field.setAccessible(true);
        } 
        Context context = (Context)sContextField.get(paramLocationManager);
        if (context != null) {
          if (Build.VERSION.SDK_INT == 19) {
            if (Settings.Secure.getInt(context.getContentResolver(), "location_mode", 0) != 0)
              return true; 
          } else {
            boolean bool1 = TextUtils.isEmpty(Settings.Secure.getString(context.getContentResolver(), "location_providers_allowed"));
            return bool1 ^ true;
          } 
          return false;
        } 
      } catch (ClassCastException|SecurityException|NoSuchFieldException|IllegalAccessException classCastException) {} 
    if (paramLocationManager.isProviderEnabled("network") || paramLocationManager.isProviderEnabled("gps"))
      bool = true; 
    return bool;
  }
  
  public static boolean registerGnssMeasurementsCallback(LocationManager paramLocationManager, GnssMeasurementsEvent.Callback paramCallback, Handler paramHandler) {
    return (Build.VERSION.SDK_INT != 30) ? Api24Impl.registerGnssMeasurementsCallback(paramLocationManager, paramCallback, paramHandler) : registerGnssMeasurementsCallbackOnR(paramLocationManager, ExecutorCompat.create(paramHandler), paramCallback);
  }
  
  public static boolean registerGnssMeasurementsCallback(LocationManager paramLocationManager, Executor paramExecutor, GnssMeasurementsEvent.Callback paramCallback) {
    return (Build.VERSION.SDK_INT > 30) ? Api31Impl.registerGnssMeasurementsCallback(paramLocationManager, paramExecutor, paramCallback) : registerGnssMeasurementsCallbackOnR(paramLocationManager, paramExecutor, paramCallback);
  }
  
  private static boolean registerGnssMeasurementsCallbackOnR(LocationManager paramLocationManager, Executor paramExecutor, GnssMeasurementsEvent.Callback paramCallback) {
    if (Build.VERSION.SDK_INT == 30) {
      boolean bool = false;
      try {
        if (sGnssRequestBuilderClass == null)
          sGnssRequestBuilderClass = Class.forName("android.location.GnssRequest$Builder"); 
        if (sGnssRequestBuilderBuildMethod == null) {
          Method method = sGnssRequestBuilderClass.getDeclaredMethod("build", new Class[0]);
          sGnssRequestBuilderBuildMethod = method;
          method.setAccessible(true);
        } 
        if (sRegisterGnssMeasurementsCallbackMethod == null) {
          Method method = LocationManager.class.getDeclaredMethod("registerGnssMeasurementsCallback", new Class[] { Class.forName("android.location.GnssRequest"), Executor.class, GnssMeasurementsEvent.Callback.class });
          sRegisterGnssMeasurementsCallbackMethod = method;
          method.setAccessible(true);
        } 
        Object object = sRegisterGnssMeasurementsCallbackMethod.invoke(paramLocationManager, new Object[] { sGnssRequestBuilderBuildMethod.invoke(sGnssRequestBuilderClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]), new Object[0]), paramExecutor, paramCallback });
        boolean bool1 = bool;
        if (object != null) {
          boolean bool2 = ((Boolean)object).booleanValue();
          bool1 = bool;
          if (bool2)
            bool1 = true; 
        } 
        return bool1;
      } catch (ClassNotFoundException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|IllegalAccessException|InstantiationException classNotFoundException) {
        return false;
      } 
    } 
    throw new IllegalStateException();
  }
  
  private static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Handler paramHandler, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #30
    //   5: if_icmplt -> 16
    //   8: aload_0
    //   9: aload_1
    //   10: aload_2
    //   11: aload_3
    //   12: invokestatic registerGnssStatusCallback : (Landroid/location/LocationManager;Landroid/os/Handler;Ljava/util/concurrent/Executor;Landroidx/core/location/GnssStatusCompat$Callback;)Z
    //   15: ireturn
    //   16: getstatic android/os/Build$VERSION.SDK_INT : I
    //   19: bipush #24
    //   21: if_icmplt -> 32
    //   24: aload_0
    //   25: aload_1
    //   26: aload_2
    //   27: aload_3
    //   28: invokestatic registerGnssStatusCallback : (Landroid/location/LocationManager;Landroid/os/Handler;Ljava/util/concurrent/Executor;Landroidx/core/location/GnssStatusCompat$Callback;)Z
    //   31: ireturn
    //   32: iconst_1
    //   33: istore #6
    //   35: iconst_1
    //   36: istore #7
    //   38: iconst_1
    //   39: istore #5
    //   41: aload_1
    //   42: ifnull -> 51
    //   45: iconst_1
    //   46: istore #8
    //   48: goto -> 54
    //   51: iconst_0
    //   52: istore #8
    //   54: iload #8
    //   56: invokestatic checkArgument : (Z)V
    //   59: getstatic androidx/core/location/LocationManagerCompat$GnssListenersHolder.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   62: astore #16
    //   64: aload #16
    //   66: monitorenter
    //   67: getstatic androidx/core/location/LocationManagerCompat$GnssListenersHolder.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   70: aload_3
    //   71: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   74: checkcast androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   77: astore #15
    //   79: aload #15
    //   81: ifnonnull -> 98
    //   84: new androidx/core/location/LocationManagerCompat$GpsStatusTransport
    //   87: dup
    //   88: aload_0
    //   89: aload_3
    //   90: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/GnssStatusCompat$Callback;)V
    //   93: astore #15
    //   95: goto -> 103
    //   98: aload #15
    //   100: invokevirtual unregister : ()V
    //   103: aload #15
    //   105: aload_2
    //   106: invokevirtual register : (Ljava/util/concurrent/Executor;)V
    //   109: new java/util/concurrent/FutureTask
    //   112: dup
    //   113: new androidx/core/location/-$$Lambda$LocationManagerCompat$fu801Wuouky3eCUQq_47RLHOKzQ
    //   116: dup
    //   117: aload_0
    //   118: aload #15
    //   120: invokespecial <init> : (Landroid/location/LocationManager;Landroidx/core/location/LocationManagerCompat$GpsStatusTransport;)V
    //   123: invokespecial <init> : (Ljava/util/concurrent/Callable;)V
    //   126: astore_0
    //   127: invokestatic myLooper : ()Landroid/os/Looper;
    //   130: aload_1
    //   131: invokevirtual getLooper : ()Landroid/os/Looper;
    //   134: if_acmpne -> 144
    //   137: aload_0
    //   138: invokevirtual run : ()V
    //   141: goto -> 156
    //   144: aload_1
    //   145: aload_0
    //   146: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   149: istore #8
    //   151: iload #8
    //   153: ifeq -> 437
    //   156: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   159: ldc2_w 5
    //   162: invokevirtual toNanos : (J)J
    //   165: lstore #11
    //   167: invokestatic nanoTime : ()J
    //   170: lstore #13
    //   172: iconst_0
    //   173: istore #4
    //   175: lload #11
    //   177: lstore #9
    //   179: aload_0
    //   180: lload #9
    //   182: getstatic java/util/concurrent/TimeUnit.NANOSECONDS : Ljava/util/concurrent/TimeUnit;
    //   185: invokevirtual get : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   188: checkcast java/lang/Boolean
    //   191: invokevirtual booleanValue : ()Z
    //   194: ifeq -> 223
    //   197: getstatic androidx/core/location/LocationManagerCompat$GnssListenersHolder.sGnssStatusListeners : Landroidx/collection/SimpleArrayMap;
    //   200: aload_3
    //   201: aload #15
    //   203: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   206: pop
    //   207: iload #4
    //   209: ifeq -> 218
    //   212: invokestatic currentThread : ()Ljava/lang/Thread;
    //   215: invokevirtual interrupt : ()V
    //   218: aload #16
    //   220: monitorexit
    //   221: iconst_1
    //   222: ireturn
    //   223: iload #4
    //   225: ifeq -> 234
    //   228: invokestatic currentThread : ()Ljava/lang/Thread;
    //   231: invokevirtual interrupt : ()V
    //   234: aload #16
    //   236: monitorexit
    //   237: iconst_0
    //   238: ireturn
    //   239: astore_0
    //   240: goto -> 424
    //   243: astore_0
    //   244: iload #4
    //   246: istore #5
    //   248: goto -> 307
    //   251: astore_0
    //   252: iload #4
    //   254: istore #5
    //   256: goto -> 358
    //   259: iload #7
    //   261: istore #4
    //   263: invokestatic nanoTime : ()J
    //   266: lstore #9
    //   268: lload #13
    //   270: lload #11
    //   272: ladd
    //   273: lload #9
    //   275: lsub
    //   276: lstore #9
    //   278: iconst_1
    //   279: istore #4
    //   281: goto -> 179
    //   284: astore_0
    //   285: goto -> 307
    //   288: astore_0
    //   289: iload #6
    //   291: istore #5
    //   293: goto -> 358
    //   296: astore_0
    //   297: iconst_0
    //   298: istore #4
    //   300: goto -> 424
    //   303: astore_0
    //   304: iconst_0
    //   305: istore #5
    //   307: iload #5
    //   309: istore #4
    //   311: new java/lang/StringBuilder
    //   314: dup
    //   315: invokespecial <init> : ()V
    //   318: astore_2
    //   319: iload #5
    //   321: istore #4
    //   323: aload_2
    //   324: aload_1
    //   325: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   328: pop
    //   329: iload #5
    //   331: istore #4
    //   333: aload_2
    //   334: ldc_w ' appears to be blocked, please run registerGnssStatusCallback() directly on a Looper thread or ensure the main Looper is not blocked by this thread'
    //   337: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   340: pop
    //   341: iload #5
    //   343: istore #4
    //   345: new java/lang/IllegalStateException
    //   348: dup
    //   349: aload_2
    //   350: invokevirtual toString : ()Ljava/lang/String;
    //   353: aload_0
    //   354: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   357: athrow
    //   358: iload #5
    //   360: istore #4
    //   362: aload_0
    //   363: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   366: instanceof java/lang/RuntimeException
    //   369: ifne -> 411
    //   372: iload #5
    //   374: istore #4
    //   376: aload_0
    //   377: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   380: instanceof java/lang/Error
    //   383: ifeq -> 398
    //   386: iload #5
    //   388: istore #4
    //   390: aload_0
    //   391: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   394: checkcast java/lang/Error
    //   397: athrow
    //   398: iload #5
    //   400: istore #4
    //   402: new java/lang/IllegalStateException
    //   405: dup
    //   406: aload_0
    //   407: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   410: athrow
    //   411: iload #5
    //   413: istore #4
    //   415: aload_0
    //   416: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   419: checkcast java/lang/RuntimeException
    //   422: athrow
    //   423: astore_0
    //   424: iload #4
    //   426: ifeq -> 435
    //   429: invokestatic currentThread : ()Ljava/lang/Thread;
    //   432: invokevirtual interrupt : ()V
    //   435: aload_0
    //   436: athrow
    //   437: new java/lang/StringBuilder
    //   440: dup
    //   441: invokespecial <init> : ()V
    //   444: astore_0
    //   445: aload_0
    //   446: aload_1
    //   447: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload_0
    //   452: ldc_w ' is shutting down'
    //   455: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   458: pop
    //   459: new java/lang/IllegalStateException
    //   462: dup
    //   463: aload_0
    //   464: invokevirtual toString : ()Ljava/lang/String;
    //   467: invokespecial <init> : (Ljava/lang/String;)V
    //   470: athrow
    //   471: astore_0
    //   472: aload #16
    //   474: monitorexit
    //   475: aload_0
    //   476: athrow
    //   477: astore_2
    //   478: goto -> 259
    //   481: astore_0
    //   482: iconst_0
    //   483: istore #5
    //   485: goto -> 358
    // Exception table:
    //   from	to	target	type
    //   67	79	471	finally
    //   84	95	471	finally
    //   98	103	471	finally
    //   103	141	471	finally
    //   144	151	471	finally
    //   156	172	481	java/util/concurrent/ExecutionException
    //   156	172	303	java/util/concurrent/TimeoutException
    //   156	172	296	finally
    //   179	207	477	java/lang/InterruptedException
    //   179	207	251	java/util/concurrent/ExecutionException
    //   179	207	243	java/util/concurrent/TimeoutException
    //   179	207	239	finally
    //   212	218	471	finally
    //   218	221	471	finally
    //   228	234	471	finally
    //   234	237	471	finally
    //   263	268	288	java/util/concurrent/ExecutionException
    //   263	268	284	java/util/concurrent/TimeoutException
    //   263	268	423	finally
    //   311	319	423	finally
    //   323	329	423	finally
    //   333	341	423	finally
    //   345	358	423	finally
    //   362	372	423	finally
    //   376	386	423	finally
    //   390	398	423	finally
    //   402	411	423	finally
    //   415	423	423	finally
    //   429	435	471	finally
    //   435	437	471	finally
    //   437	471	471	finally
    //   472	475	471	finally
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback, Handler paramHandler) {
    return (Build.VERSION.SDK_INT >= 30) ? registerGnssStatusCallback(paramLocationManager, ExecutorCompat.create(paramHandler), paramCallback) : registerGnssStatusCallback(paramLocationManager, new InlineHandlerExecutor(paramHandler), paramCallback);
  }
  
  public static boolean registerGnssStatusCallback(LocationManager paramLocationManager, Executor paramExecutor, GnssStatusCompat.Callback paramCallback) {
    if (Build.VERSION.SDK_INT >= 30)
      return registerGnssStatusCallback(paramLocationManager, null, paramExecutor, paramCallback); 
    Looper looper2 = Looper.myLooper();
    Looper looper1 = looper2;
    if (looper2 == null)
      looper1 = Looper.getMainLooper(); 
    return registerGnssStatusCallback(paramLocationManager, new Handler(looper1), paramExecutor, paramCallback);
  }
  
  static void registerLocationListenerTransport(LocationManager paramLocationManager, LocationListenerTransport paramLocationListenerTransport) {
    WeakReference<LocationListenerTransport> weakReference = sLocationListeners.put(paramLocationListenerTransport.getKey(), new WeakReference<LocationListenerTransport>(paramLocationListenerTransport));
    if (weakReference != null) {
      LocationListenerTransport locationListenerTransport = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (weakReference != null) {
      weakReference.unregister();
      paramLocationManager.removeUpdates((LocationListener)weakReference);
    } 
  }
  
  public static void removeUpdates(LocationManager paramLocationManager, LocationListenerCompat paramLocationListenerCompat) {
    // Byte code:
    //   0: getstatic androidx/core/location/LocationManagerCompat.sLocationListeners : Ljava/util/WeakHashMap;
    //   3: astore #4
    //   5: aload #4
    //   7: monitorenter
    //   8: aconst_null
    //   9: astore_2
    //   10: getstatic androidx/core/location/LocationManagerCompat.sLocationListeners : Ljava/util/WeakHashMap;
    //   13: invokevirtual values : ()Ljava/util/Collection;
    //   16: invokeinterface iterator : ()Ljava/util/Iterator;
    //   21: astore #5
    //   23: aload #5
    //   25: invokeinterface hasNext : ()Z
    //   30: ifeq -> 112
    //   33: aload #5
    //   35: invokeinterface next : ()Ljava/lang/Object;
    //   40: checkcast java/lang/ref/WeakReference
    //   43: invokevirtual get : ()Ljava/lang/Object;
    //   46: checkcast androidx/core/location/LocationManagerCompat$LocationListenerTransport
    //   49: astore #6
    //   51: aload #6
    //   53: ifnonnull -> 59
    //   56: goto -> 23
    //   59: aload #6
    //   61: invokevirtual getKey : ()Landroidx/core/location/LocationManagerCompat$LocationListenerKey;
    //   64: astore #7
    //   66: aload #7
    //   68: getfield mListener : Landroidx/core/location/LocationListenerCompat;
    //   71: aload_1
    //   72: if_acmpne -> 23
    //   75: aload_2
    //   76: astore_3
    //   77: aload_2
    //   78: ifnonnull -> 89
    //   81: new java/util/ArrayList
    //   84: dup
    //   85: invokespecial <init> : ()V
    //   88: astore_3
    //   89: aload_3
    //   90: aload #7
    //   92: invokevirtual add : (Ljava/lang/Object;)Z
    //   95: pop
    //   96: aload #6
    //   98: invokevirtual unregister : ()V
    //   101: aload_0
    //   102: aload #6
    //   104: invokevirtual removeUpdates : (Landroid/location/LocationListener;)V
    //   107: aload_3
    //   108: astore_2
    //   109: goto -> 23
    //   112: aload_2
    //   113: ifnull -> 151
    //   116: aload_2
    //   117: invokevirtual iterator : ()Ljava/util/Iterator;
    //   120: astore_2
    //   121: aload_2
    //   122: invokeinterface hasNext : ()Z
    //   127: ifeq -> 151
    //   130: aload_2
    //   131: invokeinterface next : ()Ljava/lang/Object;
    //   136: checkcast androidx/core/location/LocationManagerCompat$LocationListenerKey
    //   139: astore_3
    //   140: getstatic androidx/core/location/LocationManagerCompat.sLocationListeners : Ljava/util/WeakHashMap;
    //   143: aload_3
    //   144: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   147: pop
    //   148: goto -> 121
    //   151: aload #4
    //   153: monitorexit
    //   154: aload_0
    //   155: aload_1
    //   156: invokevirtual removeUpdates : (Landroid/location/LocationListener;)V
    //   159: return
    //   160: astore_0
    //   161: aload #4
    //   163: monitorexit
    //   164: aload_0
    //   165: athrow
    // Exception table:
    //   from	to	target	type
    //   10	23	160	finally
    //   23	51	160	finally
    //   59	75	160	finally
    //   81	89	160	finally
    //   89	107	160	finally
    //   116	121	160	finally
    //   121	148	160	finally
    //   151	154	160	finally
    //   161	164	160	finally
  }
  
  public static void requestLocationUpdates(LocationManager paramLocationManager, String paramString, LocationRequestCompat paramLocationRequestCompat, LocationListenerCompat paramLocationListenerCompat, Looper paramLooper) {
    if (Build.VERSION.SDK_INT >= 31) {
      Api31Impl.requestLocationUpdates(paramLocationManager, paramString, paramLocationRequestCompat.toLocationRequest(), ExecutorCompat.create(new Handler(paramLooper)), paramLocationListenerCompat);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 19 && Api19Impl.tryRequestLocationUpdates(paramLocationManager, paramString, paramLocationRequestCompat, paramLocationListenerCompat, paramLooper))
      return; 
    paramLocationManager.requestLocationUpdates(paramString, paramLocationRequestCompat.getIntervalMillis(), paramLocationRequestCompat.getMinUpdateDistanceMeters(), paramLocationListenerCompat, paramLooper);
  }
  
  public static void requestLocationUpdates(LocationManager paramLocationManager, String paramString, LocationRequestCompat paramLocationRequestCompat, Executor paramExecutor, LocationListenerCompat paramLocationListenerCompat) {
    if (Build.VERSION.SDK_INT >= 31) {
      Api31Impl.requestLocationUpdates(paramLocationManager, paramString, paramLocationRequestCompat.toLocationRequest(), paramExecutor, paramLocationListenerCompat);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 30 && Api30Impl.tryRequestLocationUpdates(paramLocationManager, paramString, paramLocationRequestCompat, paramExecutor, paramLocationListenerCompat))
      return; 
    LocationListenerTransport locationListenerTransport = new LocationListenerTransport(new LocationListenerKey(paramString, paramLocationListenerCompat), paramExecutor);
    if (Build.VERSION.SDK_INT >= 19 && Api19Impl.tryRequestLocationUpdates(paramLocationManager, paramString, paramLocationRequestCompat, locationListenerTransport))
      return; 
    synchronized (sLocationListeners) {
      paramLocationManager.requestLocationUpdates(paramString, paramLocationRequestCompat.getIntervalMillis(), paramLocationRequestCompat.getMinUpdateDistanceMeters(), locationListenerTransport, Looper.getMainLooper());
      registerLocationListenerTransport(paramLocationManager, locationListenerTransport);
      return;
    } 
  }
  
  public static void unregisterGnssMeasurementsCallback(LocationManager paramLocationManager, GnssMeasurementsEvent.Callback paramCallback) {
    Api24Impl.unregisterGnssMeasurementsCallback(paramLocationManager, paramCallback);
  }
  
  public static void unregisterGnssStatusCallback(LocationManager paramLocationManager, GnssStatusCompat.Callback paramCallback) {
    Object object;
    if (Build.VERSION.SDK_INT >= 24)
      synchronized (GnssListenersHolder.sGnssStatusListeners) {
        object = GnssListenersHolder.sGnssStatusListeners.remove(paramCallback);
        if (object != null)
          Api24Impl.unregisterGnssStatusCallback(paramLocationManager, object); 
        return;
      }  
    synchronized (GnssListenersHolder.sGnssStatusListeners) {
      object = GnssListenersHolder.sGnssStatusListeners.remove(object);
      if (object != null) {
        object.unregister();
        paramLocationManager.removeGpsStatusListener((GpsStatus.Listener)object);
      } 
      return;
    } 
  }
  
  static class Api19Impl {
    private static Class<?> sLocationRequestClass;
    
    private static Method sRequestLocationUpdatesLooperMethod;
    
    static boolean tryRequestLocationUpdates(LocationManager param1LocationManager, String param1String, LocationRequestCompat param1LocationRequestCompat, LocationListenerCompat param1LocationListenerCompat, Looper param1Looper) {
      if (Build.VERSION.SDK_INT >= 19)
        try {
          if (sLocationRequestClass == null)
            sLocationRequestClass = Class.forName("android.location.LocationRequest"); 
          if (sRequestLocationUpdatesLooperMethod == null) {
            Method method = LocationManager.class.getDeclaredMethod("requestLocationUpdates", new Class[] { sLocationRequestClass, LocationListener.class, Looper.class });
            sRequestLocationUpdatesLooperMethod = method;
            method.setAccessible(true);
          } 
          LocationRequest locationRequest = param1LocationRequestCompat.toLocationRequest(param1String);
          if (locationRequest != null) {
            sRequestLocationUpdatesLooperMethod.invoke(param1LocationManager, new Object[] { locationRequest, param1LocationListenerCompat, param1Looper });
            return true;
          } 
          return false;
        } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException|ClassNotFoundException|UnsupportedOperationException noSuchMethodException) {
          return false;
        }  
      return false;
    }
    
    static boolean tryRequestLocationUpdates(LocationManager param1LocationManager, String param1String, LocationRequestCompat param1LocationRequestCompat, LocationManagerCompat.LocationListenerTransport param1LocationListenerTransport) {
      if (Build.VERSION.SDK_INT >= 19)
        try {
          if (sLocationRequestClass == null)
            sLocationRequestClass = Class.forName("android.location.LocationRequest"); 
          if (sRequestLocationUpdatesLooperMethod == null) {
            Method method = LocationManager.class.getDeclaredMethod("requestLocationUpdates", new Class[] { sLocationRequestClass, LocationListener.class, Looper.class });
            sRequestLocationUpdatesLooperMethod = method;
            method.setAccessible(true);
          } 
          LocationRequest locationRequest = param1LocationRequestCompat.toLocationRequest(param1String);
          if (locationRequest != null)
            synchronized (LocationManagerCompat.sLocationListeners) {
              sRequestLocationUpdatesLooperMethod.invoke(param1LocationManager, new Object[] { locationRequest, param1LocationListenerTransport, Looper.getMainLooper() });
              LocationManagerCompat.registerLocationListenerTransport(param1LocationManager, param1LocationListenerTransport);
              return true;
            }  
          return false;
        } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException|ClassNotFoundException|UnsupportedOperationException noSuchMethodException) {
          return false;
        }  
      return false;
    }
  }
  
  static class Api24Impl {
    static boolean registerGnssMeasurementsCallback(LocationManager param1LocationManager, GnssMeasurementsEvent.Callback param1Callback, Handler param1Handler) {
      return param1LocationManager.registerGnssMeasurementsCallback(param1Callback, param1Handler);
    }
    
    static boolean registerGnssStatusCallback(LocationManager param1LocationManager, Handler param1Handler, Executor param1Executor, GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Handler != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool);
      synchronized (LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners) {
        LocationManagerCompat.PreRGnssStatusTransport preRGnssStatusTransport = (LocationManagerCompat.PreRGnssStatusTransport)LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners.get(param1Callback);
        if (preRGnssStatusTransport == null) {
          preRGnssStatusTransport = new LocationManagerCompat.PreRGnssStatusTransport(param1Callback);
        } else {
          preRGnssStatusTransport.unregister();
        } 
        preRGnssStatusTransport.register(param1Executor);
        if (param1LocationManager.registerGnssStatusCallback(preRGnssStatusTransport, param1Handler)) {
          LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners.put(param1Callback, preRGnssStatusTransport);
          return true;
        } 
        return false;
      } 
    }
    
    static void unregisterGnssMeasurementsCallback(LocationManager param1LocationManager, GnssMeasurementsEvent.Callback param1Callback) {
      param1LocationManager.unregisterGnssMeasurementsCallback(param1Callback);
    }
    
    static void unregisterGnssStatusCallback(LocationManager param1LocationManager, Object param1Object) {
      if (param1Object instanceof LocationManagerCompat.PreRGnssStatusTransport)
        ((LocationManagerCompat.PreRGnssStatusTransport)param1Object).unregister(); 
      param1LocationManager.unregisterGnssStatusCallback((GnssStatus.Callback)param1Object);
    }
  }
  
  private static class Api28Impl {
    static String getGnssHardwareModelName(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssHardwareModelName();
    }
    
    static int getGnssYearOfHardware(LocationManager param1LocationManager) {
      return param1LocationManager.getGnssYearOfHardware();
    }
    
    static boolean isLocationEnabled(LocationManager param1LocationManager) {
      return param1LocationManager.isLocationEnabled();
    }
  }
  
  private static class Api30Impl {
    private static Class<?> sLocationRequestClass;
    
    private static Method sRequestLocationUpdatesExecutorMethod;
    
    static void getCurrentLocation(LocationManager param1LocationManager, String param1String, CancellationSignal param1CancellationSignal, Executor param1Executor, Consumer<Location> param1Consumer) {
      if (param1CancellationSignal != null) {
        CancellationSignal cancellationSignal = (CancellationSignal)param1CancellationSignal.getCancellationSignalObject();
      } else {
        param1CancellationSignal = null;
      } 
      Objects.requireNonNull(param1Consumer);
      param1LocationManager.getCurrentLocation(param1String, (CancellationSignal)param1CancellationSignal, param1Executor, new -$$Lambda$0OhB_BtsGyESugufsOb9t8Ob9OU(param1Consumer));
    }
    
    public static boolean registerGnssStatusCallback(LocationManager param1LocationManager, Handler param1Handler, Executor param1Executor, GnssStatusCompat.Callback param1Callback) {
      synchronized (LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners) {
        LocationManagerCompat.GnssStatusTransport gnssStatusTransport2 = (LocationManagerCompat.GnssStatusTransport)LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners.get(param1Callback);
        LocationManagerCompat.GnssStatusTransport gnssStatusTransport1 = gnssStatusTransport2;
        if (gnssStatusTransport2 == null)
          gnssStatusTransport1 = new LocationManagerCompat.GnssStatusTransport(param1Callback); 
        if (param1LocationManager.registerGnssStatusCallback(param1Executor, gnssStatusTransport1)) {
          LocationManagerCompat.GnssListenersHolder.sGnssStatusListeners.put(param1Callback, gnssStatusTransport1);
          return true;
        } 
        return false;
      } 
    }
    
    public static boolean tryRequestLocationUpdates(LocationManager param1LocationManager, String param1String, LocationRequestCompat param1LocationRequestCompat, Executor param1Executor, LocationListenerCompat param1LocationListenerCompat) {
      if (Build.VERSION.SDK_INT >= 30)
        try {
          if (sLocationRequestClass == null)
            sLocationRequestClass = Class.forName("android.location.LocationRequest"); 
          if (sRequestLocationUpdatesExecutorMethod == null) {
            Method method = LocationManager.class.getDeclaredMethod("requestLocationUpdates", new Class[] { sLocationRequestClass, Executor.class, LocationListener.class });
            sRequestLocationUpdatesExecutorMethod = method;
            method.setAccessible(true);
          } 
          LocationRequest locationRequest = param1LocationRequestCompat.toLocationRequest(param1String);
          if (locationRequest != null) {
            sRequestLocationUpdatesExecutorMethod.invoke(param1LocationManager, new Object[] { locationRequest, param1Executor, param1LocationListenerCompat });
            return true;
          } 
          return false;
        } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException|ClassNotFoundException|UnsupportedOperationException noSuchMethodException) {
          return false;
        }  
      return false;
    }
  }
  
  private static class Api31Impl {
    static boolean hasProvider(LocationManager param1LocationManager, String param1String) {
      return param1LocationManager.hasProvider(param1String);
    }
    
    static boolean registerGnssMeasurementsCallback(LocationManager param1LocationManager, Executor param1Executor, GnssMeasurementsEvent.Callback param1Callback) {
      return param1LocationManager.registerGnssMeasurementsCallback(param1Executor, param1Callback);
    }
    
    static void requestLocationUpdates(LocationManager param1LocationManager, String param1String, LocationRequest param1LocationRequest, Executor param1Executor, LocationListener param1LocationListener) {
      param1LocationManager.requestLocationUpdates(param1String, param1LocationRequest, param1Executor, param1LocationListener);
    }
  }
  
  private static final class CancellableLocationListener implements LocationListener {
    private Consumer<Location> mConsumer;
    
    private final Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    private final Handler mTimeoutHandler;
    
    Runnable mTimeoutRunnable;
    
    private boolean mTriggered;
    
    CancellableLocationListener(LocationManager param1LocationManager, Executor param1Executor, Consumer<Location> param1Consumer) {
      this.mLocationManager = param1LocationManager;
      this.mExecutor = param1Executor;
      this.mTimeoutHandler = new Handler(Looper.getMainLooper());
      this.mConsumer = param1Consumer;
    }
    
    private void cleanup() {
      this.mConsumer = null;
      this.mLocationManager.removeUpdates(this);
      Runnable runnable = this.mTimeoutRunnable;
      if (runnable != null) {
        this.mTimeoutHandler.removeCallbacks(runnable);
        this.mTimeoutRunnable = null;
      } 
    }
    
    public void cancel() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: invokespecial cleanup : ()V
      //   23: return
      //   24: astore_1
      //   25: aload_0
      //   26: monitorexit
      //   27: aload_1
      //   28: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	24	finally
      //   12	19	24	finally
      //   25	27	24	finally
    }
    
    public void onLocationChanged(Location param1Location) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield mTriggered : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: getfield mConsumer : Landroidx/core/util/Consumer;
      //   23: astore_2
      //   24: aload_0
      //   25: getfield mExecutor : Ljava/util/concurrent/Executor;
      //   28: new androidx/core/location/-$$Lambda$LocationManagerCompat$CancellableLocationListener$0jNHW-vRqJcS-ecqUIfyMpUofp4
      //   31: dup
      //   32: aload_2
      //   33: aload_1
      //   34: invokespecial <init> : (Landroidx/core/util/Consumer;Landroid/location/Location;)V
      //   37: invokeinterface execute : (Ljava/lang/Runnable;)V
      //   42: aload_0
      //   43: invokespecial cleanup : ()V
      //   46: return
      //   47: astore_1
      //   48: aload_0
      //   49: monitorexit
      //   50: aload_1
      //   51: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	47	finally
      //   12	19	47	finally
      //   48	50	47	finally
    }
    
    public void onProviderDisabled(String param1String) {
      onLocationChanged((Location)null);
    }
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
    
    public void startTimeout(long param1Long) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mTriggered : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: new androidx/core/location/-$$Lambda$LocationManagerCompat$CancellableLocationListener$XFREfvCR0RQsr4QSpeLGcmdL5VY
      //   15: dup
      //   16: aload_0
      //   17: invokespecial <init> : (Landroidx/core/location/LocationManagerCompat$CancellableLocationListener;)V
      //   20: astore_3
      //   21: aload_0
      //   22: aload_3
      //   23: putfield mTimeoutRunnable : Ljava/lang/Runnable;
      //   26: aload_0
      //   27: getfield mTimeoutHandler : Landroid/os/Handler;
      //   30: aload_3
      //   31: lload_1
      //   32: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
      //   35: pop
      //   36: aload_0
      //   37: monitorexit
      //   38: return
      //   39: astore_3
      //   40: aload_0
      //   41: monitorexit
      //   42: aload_3
      //   43: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	39	finally
      //   12	38	39	finally
      //   40	42	39	finally
    }
  }
  
  private static class GnssListenersHolder {
    static final SimpleArrayMap<Object, Object> sGnssStatusListeners = new SimpleArrayMap();
  }
  
  private static class GnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    GnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(int param1Int) {
      this.mCallback.onFirstFix(param1Int);
    }
    
    public void onSatelliteStatusChanged(GnssStatus param1GnssStatus) {
      this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(param1GnssStatus));
    }
    
    public void onStarted() {
      this.mCallback.onStarted();
    }
    
    public void onStopped() {
      this.mCallback.onStopped();
    }
  }
  
  private static class GpsStatusTransport implements GpsStatus.Listener {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    private final LocationManager mLocationManager;
    
    GpsStatusTransport(LocationManager param1LocationManager, GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mLocationManager = param1LocationManager;
      this.mCallback = param1Callback;
    }
    
    public void onGpsStatusChanged(int param1Int) {
      Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4)
              return; 
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new -$$Lambda$LocationManagerCompat$GpsStatusTransport$VPu-nedyTL-3FmVz96fRBB74pTQ(this, executor, GnssStatusCompat.wrap(gpsStatus)));
              return;
            } 
          } else {
            GpsStatus gpsStatus = this.mLocationManager.getGpsStatus(null);
            if (gpsStatus != null) {
              executor.execute(new -$$Lambda$LocationManagerCompat$GpsStatusTransport$xo8hHdE4ZYYqFGTfGO5Zi05HaZU(this, executor, gpsStatus.getTimeToFirstFix()));
              return;
            } 
          } 
        } else {
          executor.execute(new -$$Lambda$LocationManagerCompat$GpsStatusTransport$hBOoKQPkfWxGp247Po0CFKEJDhc(this, executor));
          return;
        } 
      } else {
        executor.execute(new -$$Lambda$LocationManagerCompat$GpsStatusTransport$j0W7cZXQ8B5GcgKXX-PLQ1_45cM(this, executor));
      } 
    }
    
    public void register(Executor param1Executor) {
      boolean bool;
      if (this.mExecutor == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
  
  private static final class InlineHandlerExecutor implements Executor {
    private final Handler mHandler;
    
    InlineHandlerExecutor(Handler param1Handler) {
      this.mHandler = (Handler)Preconditions.checkNotNull(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (Looper.myLooper() == this.mHandler.getLooper()) {
        param1Runnable.run();
        return;
      } 
      if (this.mHandler.post((Runnable)Preconditions.checkNotNull(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.mHandler);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
  
  private static class LocationListenerKey {
    final LocationListenerCompat mListener;
    
    final String mProvider;
    
    LocationListenerKey(String param1String, LocationListenerCompat param1LocationListenerCompat) {
      this.mProvider = (String)ObjectsCompat.requireNonNull(param1String, "invalid null provider");
      this.mListener = (LocationListenerCompat)ObjectsCompat.requireNonNull(param1LocationListenerCompat, "invalid null listener");
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = param1Object instanceof LocationListenerKey;
      boolean bool1 = false;
      if (!bool)
        return false; 
      param1Object = param1Object;
      bool = bool1;
      if (this.mProvider.equals(((LocationListenerKey)param1Object).mProvider)) {
        bool = bool1;
        if (this.mListener.equals(((LocationListenerKey)param1Object).mListener))
          bool = true; 
      } 
      return bool;
    }
    
    public int hashCode() {
      return ObjectsCompat.hash(new Object[] { this.mProvider, this.mListener });
    }
  }
  
  private static class LocationListenerTransport implements LocationListener {
    final Executor mExecutor;
    
    volatile LocationManagerCompat.LocationListenerKey mKey;
    
    LocationListenerTransport(LocationManagerCompat.LocationListenerKey param1LocationListenerKey, Executor param1Executor) {
      this.mKey = param1LocationListenerKey;
      this.mExecutor = param1Executor;
    }
    
    public LocationManagerCompat.LocationListenerKey getKey() {
      return (LocationManagerCompat.LocationListenerKey)ObjectsCompat.requireNonNull(this.mKey);
    }
    
    public void onFlushComplete(int param1Int) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$kqasnwAxRGKEmlXaiyQCRSnW8F4(this, param1Int));
    }
    
    public void onLocationChanged(Location param1Location) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$yXVRvJ1K4U4VDQmd6Fh8X5yVvJs(this, param1Location));
    }
    
    public void onLocationChanged(List<Location> param1List) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$gEQSvoJSAh8n9MEKN7yEq88XqUs(this, param1List));
    }
    
    public void onProviderDisabled(String param1String) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$m457C3HZPVSvUSgEHsXZG2QbUCs(this, param1String));
    }
    
    public void onProviderEnabled(String param1String) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$3gyNilM2kssgUjWVOK4DYrrEOYY(this, param1String));
    }
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {
      if (this.mKey == null)
        return; 
      this.mExecutor.execute(new -$$Lambda$LocationManagerCompat$LocationListenerTransport$2HObgKvsX6qFkA892bzTJaHCZMw(this, param1String, param1Int, param1Bundle));
    }
    
    public void unregister() {
      this.mKey = null;
    }
  }
  
  private static class PreRGnssStatusTransport extends GnssStatus.Callback {
    final GnssStatusCompat.Callback mCallback;
    
    volatile Executor mExecutor;
    
    PreRGnssStatusTransport(GnssStatusCompat.Callback param1Callback) {
      boolean bool;
      if (param1Callback != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "invalid null callback");
      this.mCallback = param1Callback;
    }
    
    public void onFirstFix(int param1Int) {
      Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new -$$Lambda$LocationManagerCompat$PreRGnssStatusTransport$8nbToOT18WgoqeBSbT0bG2sUNNk(this, executor, param1Int));
    }
    
    public void onSatelliteStatusChanged(GnssStatus param1GnssStatus) {
      Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new -$$Lambda$LocationManagerCompat$PreRGnssStatusTransport$s-TnLfiDVGH4N0rN5wrXmuIUDvQ(this, executor, param1GnssStatus));
    }
    
    public void onStarted() {
      Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new -$$Lambda$LocationManagerCompat$PreRGnssStatusTransport$zz0o3hpdxt08mbAiXpwSIzy9-9Y(this, executor));
    }
    
    public void onStopped() {
      Executor executor = this.mExecutor;
      if (executor == null)
        return; 
      executor.execute(new -$$Lambda$LocationManagerCompat$PreRGnssStatusTransport$M17Zu8b0ZwoI1OHa8xznVxvaynA(this, executor));
    }
    
    public void register(Executor param1Executor) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Executor != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      Preconditions.checkArgument(bool1, "invalid null executor");
      if (this.mExecutor == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Preconditions.checkState(bool1);
      this.mExecutor = param1Executor;
    }
    
    public void unregister() {
      this.mExecutor = null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\LocationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */