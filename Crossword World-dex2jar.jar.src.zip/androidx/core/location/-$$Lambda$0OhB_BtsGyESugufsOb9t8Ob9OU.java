package androidx.core.location;

import androidx.core.util.Consumer;
import java.util.function.Consumer;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\-$$Lambda$0OhB_BtsGyESugufsOb9t8Ob9OU.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */