package androidx.core.location;

import android.location.LocationRequest;
import android.os.Build;
import androidx.core.util.Preconditions;
import androidx.core.util.TimeUtils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

public final class LocationRequestCompat {
  private static final long IMPLICIT_MIN_UPDATE_INTERVAL = -1L;
  
  public static final long PASSIVE_INTERVAL = 9223372036854775807L;
  
  public static final int QUALITY_BALANCED_POWER_ACCURACY = 102;
  
  public static final int QUALITY_HIGH_ACCURACY = 100;
  
  public static final int QUALITY_LOW_POWER = 104;
  
  final long mDurationMillis;
  
  final long mIntervalMillis;
  
  final long mMaxUpdateDelayMillis;
  
  final int mMaxUpdates;
  
  final float mMinUpdateDistanceMeters;
  
  final long mMinUpdateIntervalMillis;
  
  final int mQuality;
  
  LocationRequestCompat(long paramLong1, int paramInt1, long paramLong2, int paramInt2, long paramLong3, float paramFloat, long paramLong4) {
    this.mIntervalMillis = paramLong1;
    this.mQuality = paramInt1;
    this.mMinUpdateIntervalMillis = paramLong3;
    this.mDurationMillis = paramLong2;
    this.mMaxUpdates = paramInt2;
    this.mMinUpdateDistanceMeters = paramFloat;
    this.mMaxUpdateDelayMillis = paramLong4;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof LocationRequestCompat))
      return false; 
    paramObject = paramObject;
    return (this.mQuality == ((LocationRequestCompat)paramObject).mQuality && this.mIntervalMillis == ((LocationRequestCompat)paramObject).mIntervalMillis && this.mMinUpdateIntervalMillis == ((LocationRequestCompat)paramObject).mMinUpdateIntervalMillis && this.mDurationMillis == ((LocationRequestCompat)paramObject).mDurationMillis && this.mMaxUpdates == ((LocationRequestCompat)paramObject).mMaxUpdates && Float.compare(((LocationRequestCompat)paramObject).mMinUpdateDistanceMeters, this.mMinUpdateDistanceMeters) == 0 && this.mMaxUpdateDelayMillis == ((LocationRequestCompat)paramObject).mMaxUpdateDelayMillis);
  }
  
  public long getDurationMillis() {
    return this.mDurationMillis;
  }
  
  public long getIntervalMillis() {
    return this.mIntervalMillis;
  }
  
  public long getMaxUpdateDelayMillis() {
    return this.mMaxUpdateDelayMillis;
  }
  
  public int getMaxUpdates() {
    return this.mMaxUpdates;
  }
  
  public float getMinUpdateDistanceMeters() {
    return this.mMinUpdateDistanceMeters;
  }
  
  public long getMinUpdateIntervalMillis() {
    long l2 = this.mMinUpdateIntervalMillis;
    long l1 = l2;
    if (l2 == -1L)
      l1 = this.mIntervalMillis; 
    return l1;
  }
  
  public int getQuality() {
    return this.mQuality;
  }
  
  public int hashCode() {
    int i = this.mQuality;
    long l = this.mIntervalMillis;
    int j = (int)(l ^ l >>> 32L);
    l = this.mMinUpdateIntervalMillis;
    return (i * 31 + j) * 31 + (int)(l ^ l >>> 32L);
  }
  
  public LocationRequest toLocationRequest() {
    return Api31Impl.toLocationRequest(this);
  }
  
  public LocationRequest toLocationRequest(String paramString) {
    return (Build.VERSION.SDK_INT >= 31) ? toLocationRequest() : (LocationRequest)Api19Impl.toLocationRequest(this, paramString);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Request[");
    if (this.mIntervalMillis != Long.MAX_VALUE) {
      stringBuilder.append("@");
      TimeUtils.formatDuration(this.mIntervalMillis, stringBuilder);
      int i = this.mQuality;
      if (i != 100) {
        if (i != 102) {
          if (i == 104)
            stringBuilder.append(" LOW_POWER"); 
        } else {
          stringBuilder.append(" BALANCED");
        } 
      } else {
        stringBuilder.append(" HIGH_ACCURACY");
      } 
    } else {
      stringBuilder.append("PASSIVE");
    } 
    if (this.mDurationMillis != Long.MAX_VALUE) {
      stringBuilder.append(", duration=");
      TimeUtils.formatDuration(this.mDurationMillis, stringBuilder);
    } 
    if (this.mMaxUpdates != Integer.MAX_VALUE) {
      stringBuilder.append(", maxUpdates=");
      stringBuilder.append(this.mMaxUpdates);
    } 
    long l = this.mMinUpdateIntervalMillis;
    if (l != -1L && l < this.mIntervalMillis) {
      stringBuilder.append(", minUpdateInterval=");
      TimeUtils.formatDuration(this.mMinUpdateIntervalMillis, stringBuilder);
    } 
    if (this.mMinUpdateDistanceMeters > 0.0D) {
      stringBuilder.append(", minUpdateDistance=");
      stringBuilder.append(this.mMinUpdateDistanceMeters);
    } 
    if (this.mMaxUpdateDelayMillis / 2L > this.mIntervalMillis) {
      stringBuilder.append(", maxUpdateDelay=");
      TimeUtils.formatDuration(this.mMaxUpdateDelayMillis, stringBuilder);
    } 
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
  
  private static class Api19Impl {
    private static Method sCreateFromDeprecatedProviderMethod;
    
    private static Class<?> sLocationRequestClass;
    
    private static Method sSetExpireInMethod;
    
    private static Method sSetFastestIntervalMethod;
    
    private static Method sSetNumUpdatesMethod;
    
    private static Method sSetQualityMethod;
    
    public static Object toLocationRequest(LocationRequestCompat param1LocationRequestCompat, String param1String) {
      if (Build.VERSION.SDK_INT >= 19)
        try {
          if (sLocationRequestClass == null)
            sLocationRequestClass = Class.forName("android.location.LocationRequest"); 
          if (sCreateFromDeprecatedProviderMethod == null) {
            Method method = sLocationRequestClass.getDeclaredMethod("createFromDeprecatedProvider", new Class[] { String.class, long.class, float.class, boolean.class });
            sCreateFromDeprecatedProviderMethod = method;
            method.setAccessible(true);
          } 
          Object object = sCreateFromDeprecatedProviderMethod.invoke(null, new Object[] { param1String, Long.valueOf(param1LocationRequestCompat.getIntervalMillis()), Float.valueOf(param1LocationRequestCompat.getMinUpdateDistanceMeters()), Boolean.valueOf(false) });
          if (object == null)
            return null; 
          if (sSetQualityMethod == null) {
            Method method = sLocationRequestClass.getDeclaredMethod("setQuality", new Class[] { int.class });
            sSetQualityMethod = method;
            method.setAccessible(true);
          } 
          sSetQualityMethod.invoke(object, new Object[] { Integer.valueOf(param1LocationRequestCompat.getQuality()) });
          if (sSetFastestIntervalMethod == null) {
            Method method = sLocationRequestClass.getDeclaredMethod("setFastestInterval", new Class[] { long.class });
            sSetFastestIntervalMethod = method;
            method.setAccessible(true);
          } 
          sSetFastestIntervalMethod.invoke(object, new Object[] { Long.valueOf(param1LocationRequestCompat.getMinUpdateIntervalMillis()) });
          if (param1LocationRequestCompat.getMaxUpdates() < Integer.MAX_VALUE) {
            if (sSetNumUpdatesMethod == null) {
              Method method = sLocationRequestClass.getDeclaredMethod("setNumUpdates", new Class[] { int.class });
              sSetNumUpdatesMethod = method;
              method.setAccessible(true);
            } 
            sSetNumUpdatesMethod.invoke(object, new Object[] { Integer.valueOf(param1LocationRequestCompat.getMaxUpdates()) });
          } 
          if (param1LocationRequestCompat.getDurationMillis() < Long.MAX_VALUE) {
            if (sSetExpireInMethod == null) {
              Method method = sLocationRequestClass.getDeclaredMethod("setExpireIn", new Class[] { long.class });
              sSetExpireInMethod = method;
              method.setAccessible(true);
            } 
            sSetExpireInMethod.invoke(object, new Object[] { Long.valueOf(param1LocationRequestCompat.getDurationMillis()) });
          } 
          return object;
        } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException|ClassNotFoundException noSuchMethodException) {
          return null;
        }  
      return null;
    }
  }
  
  private static class Api31Impl {
    public static LocationRequest toLocationRequest(LocationRequestCompat param1LocationRequestCompat) {
      return (new LocationRequest.Builder(param1LocationRequestCompat.getIntervalMillis())).setQuality(param1LocationRequestCompat.getQuality()).setMinUpdateIntervalMillis(param1LocationRequestCompat.getMinUpdateIntervalMillis()).setDurationMillis(param1LocationRequestCompat.getDurationMillis()).setMaxUpdates(param1LocationRequestCompat.getMaxUpdates()).setMinUpdateDistanceMeters(param1LocationRequestCompat.getMinUpdateDistanceMeters()).setMaxUpdateDelayMillis(param1LocationRequestCompat.getMaxUpdateDelayMillis()).build();
    }
  }
  
  public static final class Builder {
    private long mDurationMillis;
    
    private long mIntervalMillis;
    
    private long mMaxUpdateDelayMillis;
    
    private int mMaxUpdates;
    
    private float mMinUpdateDistanceMeters;
    
    private long mMinUpdateIntervalMillis;
    
    private int mQuality;
    
    public Builder(long param1Long) {
      setIntervalMillis(param1Long);
      this.mQuality = 102;
      this.mDurationMillis = Long.MAX_VALUE;
      this.mMaxUpdates = Integer.MAX_VALUE;
      this.mMinUpdateIntervalMillis = -1L;
      this.mMinUpdateDistanceMeters = 0.0F;
      this.mMaxUpdateDelayMillis = 0L;
    }
    
    public Builder(LocationRequestCompat param1LocationRequestCompat) {
      this.mIntervalMillis = param1LocationRequestCompat.mIntervalMillis;
      this.mQuality = param1LocationRequestCompat.mQuality;
      this.mDurationMillis = param1LocationRequestCompat.mDurationMillis;
      this.mMaxUpdates = param1LocationRequestCompat.mMaxUpdates;
      this.mMinUpdateIntervalMillis = param1LocationRequestCompat.mMinUpdateIntervalMillis;
      this.mMinUpdateDistanceMeters = param1LocationRequestCompat.mMinUpdateDistanceMeters;
      this.mMaxUpdateDelayMillis = param1LocationRequestCompat.mMaxUpdateDelayMillis;
    }
    
    public LocationRequestCompat build() {
      if (this.mIntervalMillis != Long.MAX_VALUE || this.mMinUpdateIntervalMillis != -1L) {
        boolean bool1 = true;
        Preconditions.checkState(bool1, "passive location requests must have an explicit minimum update interval");
        long l1 = this.mIntervalMillis;
        return new LocationRequestCompat(l1, this.mQuality, this.mDurationMillis, this.mMaxUpdates, Math.min(this.mMinUpdateIntervalMillis, l1), this.mMinUpdateDistanceMeters, this.mMaxUpdateDelayMillis);
      } 
      boolean bool = false;
      Preconditions.checkState(bool, "passive location requests must have an explicit minimum update interval");
      long l = this.mIntervalMillis;
      return new LocationRequestCompat(l, this.mQuality, this.mDurationMillis, this.mMaxUpdates, Math.min(this.mMinUpdateIntervalMillis, l), this.mMinUpdateDistanceMeters, this.mMaxUpdateDelayMillis);
    }
    
    public Builder clearMinUpdateIntervalMillis() {
      this.mMinUpdateIntervalMillis = -1L;
      return this;
    }
    
    public Builder setDurationMillis(long param1Long) {
      this.mDurationMillis = Preconditions.checkArgumentInRange(param1Long, 1L, Long.MAX_VALUE, "durationMillis");
      return this;
    }
    
    public Builder setIntervalMillis(long param1Long) {
      this.mIntervalMillis = Preconditions.checkArgumentInRange(param1Long, 0L, Long.MAX_VALUE, "intervalMillis");
      return this;
    }
    
    public Builder setMaxUpdateDelayMillis(long param1Long) {
      this.mMaxUpdateDelayMillis = param1Long;
      this.mMaxUpdateDelayMillis = Preconditions.checkArgumentInRange(param1Long, 0L, Long.MAX_VALUE, "maxUpdateDelayMillis");
      return this;
    }
    
    public Builder setMaxUpdates(int param1Int) {
      this.mMaxUpdates = Preconditions.checkArgumentInRange(param1Int, 1, 2147483647, "maxUpdates");
      return this;
    }
    
    public Builder setMinUpdateDistanceMeters(float param1Float) {
      this.mMinUpdateDistanceMeters = param1Float;
      this.mMinUpdateDistanceMeters = Preconditions.checkArgumentInRange(param1Float, 0.0F, Float.MAX_VALUE, "minUpdateDistanceMeters");
      return this;
    }
    
    public Builder setMinUpdateIntervalMillis(long param1Long) {
      this.mMinUpdateIntervalMillis = Preconditions.checkArgumentInRange(param1Long, 0L, Long.MAX_VALUE, "minUpdateIntervalMillis");
      return this;
    }
    
    public Builder setQuality(int param1Int) {
      if (param1Int == 104 || param1Int == 102 || param1Int == 100) {
        boolean bool1 = true;
        Preconditions.checkArgument(bool1, "quality must be a defined QUALITY constant, not %d", new Object[] { Integer.valueOf(param1Int) });
        this.mQuality = param1Int;
        return this;
      } 
      boolean bool = false;
      Preconditions.checkArgument(bool, "quality must be a defined QUALITY constant, not %d", new Object[] { Integer.valueOf(param1Int) });
      this.mQuality = param1Int;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Quality {}
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\LocationRequestCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */