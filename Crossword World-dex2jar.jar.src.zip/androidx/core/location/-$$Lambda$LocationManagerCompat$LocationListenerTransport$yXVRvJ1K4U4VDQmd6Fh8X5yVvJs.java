package androidx.core.location;

import android.location.Location;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\-$$Lambda$LocationManagerCompat$LocationListenerTransport$yXVRvJ1K4U4VDQmd6Fh8X5yVvJs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */