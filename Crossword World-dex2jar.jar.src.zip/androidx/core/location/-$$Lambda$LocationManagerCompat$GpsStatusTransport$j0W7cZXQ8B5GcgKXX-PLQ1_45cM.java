package androidx.core.location;

import java.util.concurrent.Executor;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\-$$Lambda$LocationManagerCompat$GpsStatusTransport$j0W7cZXQ8B5GcgKXX-PLQ1_45cM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */