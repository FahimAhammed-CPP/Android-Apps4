package androidx.core.location;

import java.util.concurrent.Executor;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\-$$Lambda$LocationManagerCompat$PreRGnssStatusTransport$M17Zu8b0ZwoI1OHa8xznVxvaynA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */