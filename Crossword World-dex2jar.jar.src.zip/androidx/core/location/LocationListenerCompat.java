package androidx.core.location;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import java.util.List;

public interface LocationListenerCompat extends LocationListener {
  void onFlushComplete(int paramInt);
  
  void onLocationChanged(List<Location> paramList);
  
  void onProviderDisabled(String paramString);
  
  void onProviderEnabled(String paramString);
  
  void onStatusChanged(String paramString, int paramInt, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\location\LocationListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */