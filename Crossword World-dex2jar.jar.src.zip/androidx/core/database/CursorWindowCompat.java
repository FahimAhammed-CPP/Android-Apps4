package androidx.core.database;

import android.database.CursorWindow;
import android.os.Build;

public final class CursorWindowCompat {
  public static CursorWindow create(String paramString, long paramLong) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.createCursorWindow(paramString, paramLong) : ((Build.VERSION.SDK_INT >= 15) ? Api15Impl.createCursorWindow(paramString) : new CursorWindow(false));
  }
  
  static class Api15Impl {
    static CursorWindow createCursorWindow(String param1String) {
      return new CursorWindow(param1String);
    }
  }
  
  static class Api28Impl {
    static CursorWindow createCursorWindow(String param1String, long param1Long) {
      return new CursorWindow(param1String, param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\database\CursorWindowCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */