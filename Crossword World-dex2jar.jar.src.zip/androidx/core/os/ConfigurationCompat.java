package androidx.core.os;

import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

public final class ConfigurationCompat {
  public static LocaleListCompat getLocales(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? LocaleListCompat.wrap(Api24Impl.getLocales(paramConfiguration)) : LocaleListCompat.create(new Locale[] { paramConfiguration.locale });
  }
  
  static class Api24Impl {
    static LocaleList getLocales(Configuration param1Configuration) {
      return param1Configuration.getLocales();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\ConfigurationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */