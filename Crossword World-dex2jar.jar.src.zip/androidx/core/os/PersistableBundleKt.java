package androidx.core.os;

import android.os.PersistableBundle;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\"\n\000\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\020\016\n\002\020\000\n\002\b\002\n\002\020$\n\000\032\b\020\000\032\0020\001H\007\032=\020\000\032\0020\0012.\020\002\032\030\022\024\b\001\022\020\022\004\022\0020\005\022\006\022\004\030\0010\0060\0040\003\"\020\022\004\022\0020\005\022\006\022\004\030\0010\0060\004H\007¢\006\002\020\007\032\032\020\b\032\0020\001*\020\022\004\022\0020\005\022\006\022\004\030\0010\0060\tH\007¨\006\n"}, d2 = {"persistableBundleOf", "Landroid/os/PersistableBundle;", "pairs", "", "Lkotlin/Pair;", "", "", "([Lkotlin/Pair;)Landroid/os/PersistableBundle;", "toPersistableBundle", "", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class PersistableBundleKt {
  public static final PersistableBundle persistableBundleOf() {
    return PersistableBundleApi21ImplKt.createPersistableBundle(0);
  }
  
  public static final PersistableBundle persistableBundleOf(Pair<String, ? extends Object>... paramVarArgs) {
    Intrinsics.checkNotNullParameter(paramVarArgs, "pairs");
    PersistableBundle persistableBundle = PersistableBundleApi21ImplKt.createPersistableBundle(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      Pair<String, ? extends Object> pair = paramVarArgs[i];
      PersistableBundleApi21ImplKt.putValue(persistableBundle, (String)pair.component1(), pair.component2());
    } 
    return persistableBundle;
  }
  
  public static final PersistableBundle toPersistableBundle(Map<String, ? extends Object> paramMap) {
    Intrinsics.checkNotNullParameter(paramMap, "<this>");
    PersistableBundle persistableBundle = PersistableBundleApi21ImplKt.createPersistableBundle(paramMap.size());
    for (Map.Entry<String, ? extends Object> entry : paramMap.entrySet())
      PersistableBundleApi21ImplKt.putValue(persistableBundle, (String)entry.getKey(), entry.getValue()); 
    return persistableBundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\PersistableBundleKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */