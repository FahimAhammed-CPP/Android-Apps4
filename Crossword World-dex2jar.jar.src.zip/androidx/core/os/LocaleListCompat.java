package androidx.core.os;

import android.os.Build;
import android.os.LocaleList;
import androidx.core.text.ICUCompat;
import java.util.Locale;

public final class LocaleListCompat {
  private static final LocaleListCompat sEmptyLocaleList = create(new Locale[0]);
  
  private final LocaleListInterface mImpl;
  
  private LocaleListCompat(LocaleListInterface paramLocaleListInterface) {
    this.mImpl = paramLocaleListInterface;
  }
  
  public static LocaleListCompat create(Locale... paramVarArgs) {
    return (Build.VERSION.SDK_INT >= 24) ? wrap(Api24Impl.createLocaleList(paramVarArgs)) : new LocaleListCompat(new LocaleListCompatWrapper(paramVarArgs));
  }
  
  static Locale forLanguageTagCompat(String paramString) {
    if (paramString.contains("-")) {
      String[] arrayOfString = paramString.split("-", -1);
      if (arrayOfString.length > 2)
        return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
      if (arrayOfString.length > 1)
        return new Locale(arrayOfString[0], arrayOfString[1]); 
      if (arrayOfString.length == 1)
        return new Locale(arrayOfString[0]); 
    } else {
      if (paramString.contains("_")) {
        String[] arrayOfString = paramString.split("_", -1);
        if (arrayOfString.length > 2)
          return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
        if (arrayOfString.length > 1)
          return new Locale(arrayOfString[0], arrayOfString[1]); 
        if (arrayOfString.length == 1)
          return new Locale(arrayOfString[0]); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Can not parse language tag: [");
        stringBuilder1.append(paramString);
        stringBuilder1.append("]");
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      return new Locale(paramString);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can not parse language tag: [");
    stringBuilder.append(paramString);
    stringBuilder.append("]");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static LocaleListCompat forLanguageTags(String paramString) {
    if (paramString == null || paramString.isEmpty())
      return getEmptyLocaleList(); 
    String[] arrayOfString = paramString.split(",", -1);
    int j = arrayOfString.length;
    Locale[] arrayOfLocale = new Locale[j];
    for (int i = 0; i < j; i++) {
      Locale locale;
      if (Build.VERSION.SDK_INT >= 21) {
        locale = Api21Impl.forLanguageTag(arrayOfString[i]);
      } else {
        locale = forLanguageTagCompat(arrayOfString[i]);
      } 
      arrayOfLocale[i] = locale;
    } 
    return create(arrayOfLocale);
  }
  
  public static LocaleListCompat getAdjustedDefault() {
    return (Build.VERSION.SDK_INT >= 24) ? wrap(Api24Impl.getAdjustedDefault()) : create(new Locale[] { Locale.getDefault() });
  }
  
  public static LocaleListCompat getDefault() {
    return (Build.VERSION.SDK_INT >= 24) ? wrap(Api24Impl.getDefault()) : create(new Locale[] { Locale.getDefault() });
  }
  
  public static LocaleListCompat getEmptyLocaleList() {
    return sEmptyLocaleList;
  }
  
  public static boolean matchesLanguageAndScript(Locale paramLocale1, Locale paramLocale2) {
    if (BuildCompat.isAtLeastT())
      return LocaleList.matchesLanguageAndScript(paramLocale1, paramLocale2); 
    if (Build.VERSION.SDK_INT >= 21)
      return Api21Impl.matchesLanguageAndScript(paramLocale1, paramLocale2); 
    throw new UnsupportedOperationException("This method is only supported on API level 21+");
  }
  
  public static LocaleListCompat wrap(LocaleList paramLocaleList) {
    return new LocaleListCompat(new LocaleListPlatformWrapper(paramLocaleList));
  }
  
  @Deprecated
  public static LocaleListCompat wrap(Object paramObject) {
    return wrap((LocaleList)paramObject);
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof LocaleListCompat && this.mImpl.equals(((LocaleListCompat)paramObject).mImpl));
  }
  
  public Locale get(int paramInt) {
    return this.mImpl.get(paramInt);
  }
  
  public Locale getFirstMatch(String[] paramArrayOfString) {
    return this.mImpl.getFirstMatch(paramArrayOfString);
  }
  
  public int hashCode() {
    return this.mImpl.hashCode();
  }
  
  public int indexOf(Locale paramLocale) {
    return this.mImpl.indexOf(paramLocale);
  }
  
  public boolean isEmpty() {
    return this.mImpl.isEmpty();
  }
  
  public int size() {
    return this.mImpl.size();
  }
  
  public String toLanguageTags() {
    return this.mImpl.toLanguageTags();
  }
  
  public String toString() {
    return this.mImpl.toString();
  }
  
  public Object unwrap() {
    return this.mImpl.getLocaleList();
  }
  
  static class Api21Impl {
    private static final Locale[] PSEUDO_LOCALE = new Locale[] { new Locale("en", "XA"), new Locale("ar", "XB") };
    
    static Locale forLanguageTag(String param1String) {
      return Locale.forLanguageTag(param1String);
    }
    
    private static boolean isPseudoLocale(Locale param1Locale) {
      Locale[] arrayOfLocale = PSEUDO_LOCALE;
      int j = arrayOfLocale.length;
      for (int i = 0; i < j; i++) {
        if (arrayOfLocale[i].equals(param1Locale))
          return true; 
      } 
      return false;
    }
    
    static boolean matchesLanguageAndScript(Locale param1Locale1, Locale param1Locale2) {
      boolean bool1 = param1Locale1.equals(param1Locale2);
      boolean bool = true;
      if (bool1)
        return true; 
      if (!param1Locale1.getLanguage().equals(param1Locale2.getLanguage()))
        return false; 
      if (!isPseudoLocale(param1Locale1)) {
        if (isPseudoLocale(param1Locale2))
          return false; 
        String str = ICUCompat.maximizeAndGetScript(param1Locale1);
        if (str.isEmpty()) {
          String str1 = param1Locale1.getCountry();
          if (!str1.isEmpty()) {
            if (str1.equals(param1Locale2.getCountry()))
              return true; 
            bool = false;
          } 
          return bool;
        } 
        return str.equals(ICUCompat.maximizeAndGetScript(param1Locale2));
      } 
      return false;
    }
  }
  
  static class Api24Impl {
    static LocaleList createLocaleList(Locale... param1VarArgs) {
      return new LocaleList(param1VarArgs);
    }
    
    static LocaleList getAdjustedDefault() {
      return LocaleList.getAdjustedDefault();
    }
    
    static LocaleList getDefault() {
      return LocaleList.getDefault();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\LocaleListCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */