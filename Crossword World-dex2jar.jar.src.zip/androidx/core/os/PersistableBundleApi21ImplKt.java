package androidx.core.os;

import android.os.Build;
import android.os.PersistableBundle;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\000\n\002\020\002\n\002\b\002\n\002\020\016\n\002\b\002\bÃ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007J$\020\007\032\0020\b2\006\020\t\032\0020\0042\b\020\n\032\004\030\0010\0132\b\020\f\032\004\030\0010\001H\007¨\006\r"}, d2 = {"Landroidx/core/os/PersistableBundleApi21ImplKt;", "", "()V", "createPersistableBundle", "Landroid/os/PersistableBundle;", "capacity", "", "putValue", "", "persistableBundle", "key", "", "value", "core-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
final class PersistableBundleApi21ImplKt {
  public static final PersistableBundleApi21ImplKt INSTANCE = new PersistableBundleApi21ImplKt();
  
  @JvmStatic
  public static final PersistableBundle createPersistableBundle(int paramInt) {
    return new PersistableBundle(paramInt);
  }
  
  @JvmStatic
  public static final void putValue(PersistableBundle paramPersistableBundle, String paramString, Object paramObject) {
    StringBuilder stringBuilder;
    Intrinsics.checkNotNullParameter(paramPersistableBundle, "persistableBundle");
    if (paramObject == null) {
      paramPersistableBundle.putString(paramString, null);
      return;
    } 
    if (paramObject instanceof Boolean) {
      if (Build.VERSION.SDK_INT >= 22) {
        PersistableBundleApi22ImplKt.putBoolean(paramPersistableBundle, paramString, ((Boolean)paramObject).booleanValue());
        return;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Illegal value type boolean for key \"");
      stringBuilder.append(paramString);
      stringBuilder.append('"');
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (paramObject instanceof Double) {
      stringBuilder.putDouble(paramString, ((Number)paramObject).doubleValue());
      return;
    } 
    if (paramObject instanceof Integer) {
      stringBuilder.putInt(paramString, ((Number)paramObject).intValue());
      return;
    } 
    if (paramObject instanceof Long) {
      stringBuilder.putLong(paramString, ((Number)paramObject).longValue());
      return;
    } 
    if (paramObject instanceof String) {
      stringBuilder.putString(paramString, (String)paramObject);
      return;
    } 
    if (paramObject instanceof boolean[]) {
      if (Build.VERSION.SDK_INT >= 22) {
        PersistableBundleApi22ImplKt.putBooleanArray((PersistableBundle)stringBuilder, paramString, (boolean[])paramObject);
        return;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Illegal value type boolean[] for key \"");
      stringBuilder.append(paramString);
      stringBuilder.append('"');
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (paramObject instanceof double[]) {
      stringBuilder.putDoubleArray(paramString, (double[])paramObject);
      return;
    } 
    if (paramObject instanceof int[]) {
      stringBuilder.putIntArray(paramString, (int[])paramObject);
      return;
    } 
    if (paramObject instanceof long[]) {
      stringBuilder.putLongArray(paramString, (long[])paramObject);
      return;
    } 
    if (paramObject instanceof Object[]) {
      Class<?> clazz = paramObject.getClass().getComponentType();
      Intrinsics.checkNotNull(clazz);
      if (String.class.isAssignableFrom(clazz)) {
        Intrinsics.checkNotNull(paramObject, "null cannot be cast to non-null type kotlin.Array<kotlin.String>");
        stringBuilder.putStringArray(paramString, (String[])paramObject);
        return;
      } 
      String str1 = clazz.getCanonicalName();
      paramObject = new StringBuilder();
      paramObject.append("Illegal value array type ");
      paramObject.append(str1);
      paramObject.append(" for key \"");
      paramObject.append(paramString);
      paramObject.append('"');
      throw new IllegalArgumentException(paramObject.toString());
    } 
    String str = paramObject.getClass().getCanonicalName();
    paramObject = new StringBuilder();
    paramObject.append("Illegal value type ");
    paramObject.append(str);
    paramObject.append(" for key \"");
    paramObject.append(paramString);
    paramObject.append('"');
    throw new IllegalArgumentException(paramObject.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\PersistableBundleApi21ImplKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */