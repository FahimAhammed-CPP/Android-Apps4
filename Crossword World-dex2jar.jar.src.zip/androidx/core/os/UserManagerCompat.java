package androidx.core.os;

import android.content.Context;
import android.os.Build;
import android.os.UserManager;

public class UserManagerCompat {
  public static boolean isUserUnlocked(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.isUserUnlocked(paramContext) : true;
  }
  
  static class Api24Impl {
    static boolean isUserUnlocked(Context param1Context) {
      return ((UserManager)param1Context.getSystemService(UserManager.class)).isUserUnlocked();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\UserManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */