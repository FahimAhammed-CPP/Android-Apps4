package androidx.core.os;

public final class CancellationSignal {
  private boolean mCancelInProgress;
  
  private Object mCancellationSignalObj;
  
  private boolean mIsCanceled;
  
  private OnCancelListener mOnCancelListener;
  
  private void waitForCancelFinishedLocked() {
    while (true) {
      if (this.mCancelInProgress) {
        try {
          wait();
        } catch (InterruptedException interruptedException) {}
        continue;
      } 
      return;
    } 
  }
  
  public void cancel() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIsCanceled : Z
    //   6: ifeq -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: iconst_1
    //   14: putfield mIsCanceled : Z
    //   17: aload_0
    //   18: iconst_1
    //   19: putfield mCancelInProgress : Z
    //   22: aload_0
    //   23: getfield mOnCancelListener : Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   26: astore_1
    //   27: aload_0
    //   28: getfield mCancellationSignalObj : Ljava/lang/Object;
    //   31: astore_2
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: ifnull -> 47
    //   38: aload_1
    //   39: invokeinterface onCancel : ()V
    //   44: goto -> 47
    //   47: aload_2
    //   48: ifnull -> 86
    //   51: getstatic android/os/Build$VERSION.SDK_INT : I
    //   54: bipush #16
    //   56: if_icmplt -> 86
    //   59: aload_2
    //   60: invokestatic cancel : (Ljava/lang/Object;)V
    //   63: goto -> 86
    //   66: aload_0
    //   67: monitorenter
    //   68: aload_0
    //   69: iconst_0
    //   70: putfield mCancelInProgress : Z
    //   73: aload_0
    //   74: invokevirtual notifyAll : ()V
    //   77: aload_0
    //   78: monitorexit
    //   79: aload_1
    //   80: athrow
    //   81: astore_1
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_1
    //   85: athrow
    //   86: aload_0
    //   87: monitorenter
    //   88: aload_0
    //   89: iconst_0
    //   90: putfield mCancelInProgress : Z
    //   93: aload_0
    //   94: invokevirtual notifyAll : ()V
    //   97: aload_0
    //   98: monitorexit
    //   99: return
    //   100: astore_1
    //   101: aload_0
    //   102: monitorexit
    //   103: aload_1
    //   104: athrow
    //   105: astore_1
    //   106: aload_0
    //   107: monitorexit
    //   108: aload_1
    //   109: athrow
    //   110: astore_1
    //   111: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   2	11	105	finally
    //   12	34	105	finally
    //   38	44	110	finally
    //   51	63	110	finally
    //   68	79	81	finally
    //   82	84	81	finally
    //   88	99	100	finally
    //   101	103	100	finally
    //   106	108	105	finally
  }
  
  public Object getCancellationSignalObject() {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #16
    //   5: if_icmpge -> 10
    //   8: aconst_null
    //   9: areturn
    //   10: aload_0
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield mCancellationSignalObj : Ljava/lang/Object;
    //   16: ifnonnull -> 39
    //   19: invokestatic createCancellationSignal : ()Landroid/os/CancellationSignal;
    //   22: astore_1
    //   23: aload_0
    //   24: aload_1
    //   25: putfield mCancellationSignalObj : Ljava/lang/Object;
    //   28: aload_0
    //   29: getfield mIsCanceled : Z
    //   32: ifeq -> 39
    //   35: aload_1
    //   36: invokestatic cancel : (Ljava/lang/Object;)V
    //   39: aload_0
    //   40: getfield mCancellationSignalObj : Ljava/lang/Object;
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: areturn
    //   48: astore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   12	39	48	finally
    //   39	46	48	finally
    //   49	51	48	finally
  }
  
  public boolean isCanceled() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIsCanceled : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	11	finally
    //   12	14	11	finally
  }
  
  public void setOnCancelListener(OnCancelListener paramOnCancelListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial waitForCancelFinishedLocked : ()V
    //   6: aload_0
    //   7: getfield mOnCancelListener : Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   10: aload_1
    //   11: if_acmpne -> 17
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: aload_1
    //   19: putfield mOnCancelListener : Landroidx/core/os/CancellationSignal$OnCancelListener;
    //   22: aload_0
    //   23: getfield mIsCanceled : Z
    //   26: ifeq -> 45
    //   29: aload_1
    //   30: ifnonnull -> 36
    //   33: goto -> 45
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: invokeinterface onCancel : ()V
    //   44: return
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: astore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	48	finally
    //   17	29	48	finally
    //   36	38	48	finally
    //   45	47	48	finally
    //   49	51	48	finally
  }
  
  public void throwIfCanceled() {
    if (!isCanceled())
      return; 
    throw new OperationCanceledException();
  }
  
  static class Api16Impl {
    static void cancel(Object param1Object) {
      ((android.os.CancellationSignal)param1Object).cancel();
    }
    
    static android.os.CancellationSignal createCancellationSignal() {
      return new android.os.CancellationSignal();
    }
  }
  
  public static interface OnCancelListener {
    void onCancel();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\CancellationSignal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */