package androidx.core.os;

import android.os.Build;
import android.os.Message;

public final class MessageCompat {
  private static boolean sTryIsAsynchronous = true;
  
  private static boolean sTrySetAsynchronous = true;
  
  public static boolean isAsynchronous(Message paramMessage) {
    if (Build.VERSION.SDK_INT >= 22)
      return Api22Impl.isAsynchronous(paramMessage); 
    if (sTryIsAsynchronous && Build.VERSION.SDK_INT >= 16)
      try {
        return Api22Impl.isAsynchronous(paramMessage);
      } catch (NoSuchMethodError noSuchMethodError) {
        sTryIsAsynchronous = false;
      }  
    return false;
  }
  
  public static void setAsynchronous(Message paramMessage, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 22) {
      Api22Impl.setAsynchronous(paramMessage, paramBoolean);
      return;
    } 
    if (sTrySetAsynchronous && Build.VERSION.SDK_INT >= 16)
      try {
        Api22Impl.setAsynchronous(paramMessage, paramBoolean);
        return;
      } catch (NoSuchMethodError noSuchMethodError) {
        sTrySetAsynchronous = false;
      }  
  }
  
  static class Api22Impl {
    static boolean isAsynchronous(Message param1Message) {
      return param1Message.isAsynchronous();
    }
    
    static void setAsynchronous(Message param1Message, boolean param1Boolean) {
      param1Message.setAsynchronous(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\MessageCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */