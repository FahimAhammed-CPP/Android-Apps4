package androidx.core.os;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ParcelCompat {
  public static <T> T[] readArray(Parcel paramParcel, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (T[])(BuildCompat.isAtLeastT() ? (Object)TiramisuImpl.readArray(paramParcel, paramClassLoader, paramClass) : paramParcel.readArray(paramClassLoader));
  }
  
  public static <T> ArrayList<T> readArrayList(Parcel paramParcel, ClassLoader paramClassLoader, Class<? extends T> paramClass) {
    return BuildCompat.isAtLeastT() ? TiramisuImpl.readArrayList(paramParcel, paramClassLoader, paramClass) : paramParcel.readArrayList(paramClassLoader);
  }
  
  public static boolean readBoolean(Parcel paramParcel) {
    return (paramParcel.readInt() != 0);
  }
  
  public static <K, V> HashMap<K, V> readHashMap(Parcel paramParcel, ClassLoader paramClassLoader, Class<? extends K> paramClass, Class<? extends V> paramClass1) {
    return BuildCompat.isAtLeastT() ? TiramisuImpl.readHashMap(paramParcel, paramClassLoader, paramClass, paramClass1) : paramParcel.readHashMap(paramClassLoader);
  }
  
  public static <T> void readList(Parcel paramParcel, List<? super T> paramList, ClassLoader paramClassLoader, Class<T> paramClass) {
    if (BuildCompat.isAtLeastT()) {
      TiramisuImpl.readList(paramParcel, paramList, paramClassLoader, paramClass);
      return;
    } 
    paramParcel.readList(paramList, paramClassLoader);
  }
  
  public static <K, V> void readMap(Parcel paramParcel, Map<? super K, ? super V> paramMap, ClassLoader paramClassLoader, Class<K> paramClass, Class<V> paramClass1) {
    if (BuildCompat.isAtLeastT()) {
      TiramisuImpl.readMap(paramParcel, paramMap, paramClassLoader, paramClass, paramClass1);
      return;
    } 
    paramParcel.readMap(paramMap, paramClassLoader);
  }
  
  public static <T extends Parcelable> T readParcelable(Parcel paramParcel, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (T)(BuildCompat.isAtLeastT() ? (Object)TiramisuImpl.readParcelable(paramParcel, paramClassLoader, paramClass) : paramParcel.readParcelable(paramClassLoader));
  }
  
  public static <T> T[] readParcelableArray(Parcel paramParcel, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (T[])(BuildCompat.isAtLeastT() ? (Object)TiramisuImpl.readParcelableArray(paramParcel, paramClassLoader, paramClass) : paramParcel.readParcelableArray(paramClassLoader));
  }
  
  public static <T> Parcelable.Creator<T> readParcelableCreator(Parcel paramParcel, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (Parcelable.Creator)(BuildCompat.isAtLeastT() ? TiramisuImpl.readParcelableCreator(paramParcel, paramClassLoader, paramClass) : Api30Impl.readParcelableCreator(paramParcel, paramClassLoader));
  }
  
  public static <T> List<T> readParcelableList(Parcel paramParcel, List<T> paramList, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (List<T>)(BuildCompat.isAtLeastT() ? TiramisuImpl.readParcelableList(paramParcel, paramList, paramClassLoader, paramClass) : Api29Impl.readParcelableList(paramParcel, (List)paramList, paramClassLoader));
  }
  
  public static <T extends java.io.Serializable> T readSerializable(Parcel paramParcel, ClassLoader paramClassLoader, Class<T> paramClass) {
    return (T)(BuildCompat.isAtLeastT() ? (Object)TiramisuImpl.readSerializable(paramParcel, paramClassLoader, paramClass) : paramParcel.readSerializable());
  }
  
  public static <T> SparseArray<T> readSparseArray(Parcel paramParcel, ClassLoader paramClassLoader, Class<? extends T> paramClass) {
    return BuildCompat.isAtLeastT() ? TiramisuImpl.readSparseArray(paramParcel, paramClassLoader, paramClass) : paramParcel.readSparseArray(paramClassLoader);
  }
  
  public static void writeBoolean(Parcel paramParcel, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  static class Api29Impl {
    static final <T extends Parcelable> List<T> readParcelableList(Parcel param1Parcel, List<T> param1List, ClassLoader param1ClassLoader) {
      return param1Parcel.readParcelableList(param1List, param1ClassLoader);
    }
  }
  
  static class Api30Impl {
    static final Parcelable.Creator<?> readParcelableCreator(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return param1Parcel.readParcelableCreator(param1ClassLoader);
    }
  }
  
  static class TiramisuImpl {
    public static <T> T[] readArray(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return (T[])param1Parcel.readArray(param1ClassLoader, param1Class);
    }
    
    public static <T> ArrayList<T> readArrayList(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<? extends T> param1Class) {
      return param1Parcel.readArrayList(param1ClassLoader, param1Class);
    }
    
    public static <V, K> HashMap<K, V> readHashMap(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<? extends K> param1Class, Class<? extends V> param1Class1) {
      return param1Parcel.readHashMap(param1ClassLoader, param1Class, param1Class1);
    }
    
    public static <T> void readList(Parcel param1Parcel, List<? super T> param1List, ClassLoader param1ClassLoader, Class<T> param1Class) {
      param1Parcel.readList(param1List, param1ClassLoader, param1Class);
    }
    
    public static <K, V> void readMap(Parcel param1Parcel, Map<? super K, ? super V> param1Map, ClassLoader param1ClassLoader, Class<K> param1Class, Class<V> param1Class1) {
      param1Parcel.readMap(param1Map, param1ClassLoader, param1Class, param1Class1);
    }
    
    static <T extends Parcelable> T readParcelable(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return (T)param1Parcel.readParcelable(param1ClassLoader, param1Class);
    }
    
    static <T> T[] readParcelableArray(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return (T[])param1Parcel.readParcelableArray(param1ClassLoader, param1Class);
    }
    
    public static <T> Parcelable.Creator<T> readParcelableCreator(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return param1Parcel.readParcelableCreator(param1ClassLoader, param1Class);
    }
    
    static <T> List<T> readParcelableList(Parcel param1Parcel, List<T> param1List, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return param1Parcel.readParcelableList(param1List, param1ClassLoader, param1Class);
    }
    
    static <T extends java.io.Serializable> T readSerializable(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<T> param1Class) {
      return (T)param1Parcel.readSerializable(param1ClassLoader, param1Class);
    }
    
    public static <T> SparseArray<T> readSparseArray(Parcel param1Parcel, ClassLoader param1ClassLoader, Class<? extends T> param1Class) {
      return param1Parcel.readSparseArray(param1ClassLoader, param1Class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\ParcelCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */