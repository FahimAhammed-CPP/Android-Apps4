package androidx.core.os;

import androidx.core.util.ObjectsCompat;

public class OperationCanceledException extends RuntimeException {
  public OperationCanceledException() {
    this(null);
  }
  
  public OperationCanceledException(String paramString) {
    super(ObjectsCompat.toString(paramString, "The operation has been canceled."));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\os\OperationCanceledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */