package androidx.core.hardware.fingerprint;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.core.os.CancellationSignal;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

@Deprecated
public class FingerprintManagerCompat {
  private final Context mContext;
  
  private FingerprintManagerCompat(Context paramContext) {
    this.mContext = paramContext;
  }
  
  public static FingerprintManagerCompat from(Context paramContext) {
    return new FingerprintManagerCompat(paramContext);
  }
  
  private static FingerprintManager getFingerprintManagerOrNull(Context paramContext) {
    return Api23Impl.getFingerprintManagerOrNull(paramContext);
  }
  
  static CryptoObject unwrapCryptoObject(FingerprintManager.CryptoObject paramCryptoObject) {
    return Api23Impl.unwrapCryptoObject(paramCryptoObject);
  }
  
  private static FingerprintManager.AuthenticationCallback wrapCallback(final AuthenticationCallback callback) {
    return new FingerprintManager.AuthenticationCallback() {
        public void onAuthenticationError(int param1Int, CharSequence param1CharSequence) {
          callback.onAuthenticationError(param1Int, param1CharSequence);
        }
        
        public void onAuthenticationFailed() {
          callback.onAuthenticationFailed();
        }
        
        public void onAuthenticationHelp(int param1Int, CharSequence param1CharSequence) {
          callback.onAuthenticationHelp(param1Int, param1CharSequence);
        }
        
        public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult param1AuthenticationResult) {
          callback.onAuthenticationSucceeded(new FingerprintManagerCompat.AuthenticationResult(FingerprintManagerCompat.unwrapCryptoObject(FingerprintManagerCompat.Api23Impl.getCryptoObject(param1AuthenticationResult))));
        }
      };
  }
  
  private static FingerprintManager.CryptoObject wrapCryptoObject(CryptoObject paramCryptoObject) {
    return Api23Impl.wrapCryptoObject(paramCryptoObject);
  }
  
  public void authenticate(CryptoObject paramCryptoObject, int paramInt, CancellationSignal paramCancellationSignal, AuthenticationCallback paramAuthenticationCallback, Handler paramHandler) {
    if (Build.VERSION.SDK_INT >= 23) {
      FingerprintManager fingerprintManager = getFingerprintManagerOrNull(this.mContext);
      if (fingerprintManager != null) {
        if (paramCancellationSignal != null) {
          CancellationSignal cancellationSignal = (CancellationSignal)paramCancellationSignal.getCancellationSignalObject();
        } else {
          paramCancellationSignal = null;
        } 
        Api23Impl.authenticate(fingerprintManager, wrapCryptoObject(paramCryptoObject), (CancellationSignal)paramCancellationSignal, paramInt, wrapCallback(paramAuthenticationCallback), paramHandler);
      } 
    } 
  }
  
  public boolean hasEnrolledFingerprints() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 23) {
      FingerprintManager fingerprintManager = getFingerprintManagerOrNull(this.mContext);
      bool1 = bool2;
      if (fingerprintManager != null) {
        bool1 = bool2;
        if (Api23Impl.hasEnrolledFingerprints(fingerprintManager))
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean isHardwareDetected() {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i >= 23) {
      FingerprintManager fingerprintManager = getFingerprintManagerOrNull(this.mContext);
      bool1 = bool2;
      if (fingerprintManager != null) {
        bool1 = bool2;
        if (Api23Impl.isHardwareDetected(fingerprintManager))
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  static class Api23Impl {
    static void authenticate(Object param1Object1, Object param1Object2, CancellationSignal param1CancellationSignal, int param1Int, Object param1Object3, Handler param1Handler) {
      ((FingerprintManager)param1Object1).authenticate((FingerprintManager.CryptoObject)param1Object2, param1CancellationSignal, param1Int, (FingerprintManager.AuthenticationCallback)param1Object3, param1Handler);
    }
    
    static FingerprintManager.CryptoObject getCryptoObject(Object param1Object) {
      return ((FingerprintManager.AuthenticationResult)param1Object).getCryptoObject();
    }
    
    public static FingerprintManager getFingerprintManagerOrNull(Context param1Context) {
      return (Build.VERSION.SDK_INT == 23) ? (FingerprintManager)param1Context.getSystemService(FingerprintManager.class) : ((Build.VERSION.SDK_INT > 23 && param1Context.getPackageManager().hasSystemFeature("android.hardware.fingerprint")) ? (FingerprintManager)param1Context.getSystemService(FingerprintManager.class) : null);
    }
    
    static boolean hasEnrolledFingerprints(Object param1Object) {
      return ((FingerprintManager)param1Object).hasEnrolledFingerprints();
    }
    
    static boolean isHardwareDetected(Object param1Object) {
      return ((FingerprintManager)param1Object).isHardwareDetected();
    }
    
    public static FingerprintManagerCompat.CryptoObject unwrapCryptoObject(Object param1Object) {
      FingerprintManager.CryptoObject cryptoObject = (FingerprintManager.CryptoObject)param1Object;
      param1Object = null;
      if (cryptoObject == null)
        return null; 
      if (cryptoObject.getCipher() != null)
        return new FingerprintManagerCompat.CryptoObject(cryptoObject.getCipher()); 
      if (cryptoObject.getSignature() != null)
        return new FingerprintManagerCompat.CryptoObject(cryptoObject.getSignature()); 
      if (cryptoObject.getMac() != null)
        param1Object = new FingerprintManagerCompat.CryptoObject(cryptoObject.getMac()); 
      return (FingerprintManagerCompat.CryptoObject)param1Object;
    }
    
    public static FingerprintManager.CryptoObject wrapCryptoObject(FingerprintManagerCompat.CryptoObject param1CryptoObject) {
      FingerprintManager.CryptoObject cryptoObject = null;
      if (param1CryptoObject == null)
        return null; 
      if (param1CryptoObject.getCipher() != null)
        return new FingerprintManager.CryptoObject(param1CryptoObject.getCipher()); 
      if (param1CryptoObject.getSignature() != null)
        return new FingerprintManager.CryptoObject(param1CryptoObject.getSignature()); 
      if (param1CryptoObject.getMac() != null)
        cryptoObject = new FingerprintManager.CryptoObject(param1CryptoObject.getMac()); 
      return cryptoObject;
    }
  }
  
  public static abstract class AuthenticationCallback {
    public void onAuthenticationError(int param1Int, CharSequence param1CharSequence) {}
    
    public void onAuthenticationFailed() {}
    
    public void onAuthenticationHelp(int param1Int, CharSequence param1CharSequence) {}
    
    public void onAuthenticationSucceeded(FingerprintManagerCompat.AuthenticationResult param1AuthenticationResult) {}
  }
  
  public static final class AuthenticationResult {
    private final FingerprintManagerCompat.CryptoObject mCryptoObject;
    
    public AuthenticationResult(FingerprintManagerCompat.CryptoObject param1CryptoObject) {
      this.mCryptoObject = param1CryptoObject;
    }
    
    public FingerprintManagerCompat.CryptoObject getCryptoObject() {
      return this.mCryptoObject;
    }
  }
  
  public static class CryptoObject {
    private final Cipher mCipher;
    
    private final Mac mMac;
    
    private final Signature mSignature;
    
    public CryptoObject(Signature param1Signature) {
      this.mSignature = param1Signature;
      this.mCipher = null;
      this.mMac = null;
    }
    
    public CryptoObject(Cipher param1Cipher) {
      this.mCipher = param1Cipher;
      this.mSignature = null;
      this.mMac = null;
    }
    
    public CryptoObject(Mac param1Mac) {
      this.mMac = param1Mac;
      this.mCipher = null;
      this.mSignature = null;
    }
    
    public Cipher getCipher() {
      return this.mCipher;
    }
    
    public Mac getMac() {
      return this.mMac;
    }
    
    public Signature getSignature() {
      return this.mSignature;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\hardware\fingerprint\FingerprintManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */