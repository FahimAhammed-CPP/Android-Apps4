package androidx.core.app;

import androidx.core.util.Consumer;

public interface OnPictureInPictureModeChangedProvider {
  void addOnPictureInPictureModeChangedListener(Consumer<PictureInPictureModeChangedInfo> paramConsumer);
  
  void removeOnPictureInPictureModeChangedListener(Consumer<PictureInPictureModeChangedInfo> paramConsumer);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\app\OnPictureInPictureModeChangedProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */