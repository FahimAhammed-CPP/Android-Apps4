package androidx.core.app;

import androidx.core.util.Consumer;

public interface OnMultiWindowModeChangedProvider {
  void addOnMultiWindowModeChangedListener(Consumer<MultiWindowModeChangedInfo> paramConsumer);
  
  void removeOnMultiWindowModeChangedListener(Consumer<MultiWindowModeChangedInfo> paramConsumer);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\app\OnMultiWindowModeChangedProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */