package androidx.core.app;

import android.app.PendingIntent;
import android.app.RemoteAction;
import android.graphics.drawable.Icon;
import android.os.Build;
import androidx.core.graphics.drawable.IconCompat;
import androidx.core.util.Preconditions;
import androidx.versionedparcelable.VersionedParcelable;

public final class RemoteActionCompat implements VersionedParcelable {
  public PendingIntent mActionIntent;
  
  public CharSequence mContentDescription;
  
  public boolean mEnabled;
  
  public IconCompat mIcon;
  
  public boolean mShouldShowIcon;
  
  public CharSequence mTitle;
  
  public RemoteActionCompat() {}
  
  public RemoteActionCompat(RemoteActionCompat paramRemoteActionCompat) {
    Preconditions.checkNotNull(paramRemoteActionCompat);
    this.mIcon = paramRemoteActionCompat.mIcon;
    this.mTitle = paramRemoteActionCompat.mTitle;
    this.mContentDescription = paramRemoteActionCompat.mContentDescription;
    this.mActionIntent = paramRemoteActionCompat.mActionIntent;
    this.mEnabled = paramRemoteActionCompat.mEnabled;
    this.mShouldShowIcon = paramRemoteActionCompat.mShouldShowIcon;
  }
  
  public RemoteActionCompat(IconCompat paramIconCompat, CharSequence paramCharSequence1, CharSequence paramCharSequence2, PendingIntent paramPendingIntent) {
    this.mIcon = (IconCompat)Preconditions.checkNotNull(paramIconCompat);
    this.mTitle = (CharSequence)Preconditions.checkNotNull(paramCharSequence1);
    this.mContentDescription = (CharSequence)Preconditions.checkNotNull(paramCharSequence2);
    this.mActionIntent = (PendingIntent)Preconditions.checkNotNull(paramPendingIntent);
    this.mEnabled = true;
    this.mShouldShowIcon = true;
  }
  
  public static RemoteActionCompat createFromRemoteAction(RemoteAction paramRemoteAction) {
    Preconditions.checkNotNull(paramRemoteAction);
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat(IconCompat.createFromIcon(Api26Impl.getIcon(paramRemoteAction)), Api26Impl.getTitle(paramRemoteAction), Api26Impl.getContentDescription(paramRemoteAction), Api26Impl.getActionIntent(paramRemoteAction));
    remoteActionCompat.setEnabled(Api26Impl.isEnabled(paramRemoteAction));
    if (Build.VERSION.SDK_INT >= 28)
      remoteActionCompat.setShouldShowIcon(Api28Impl.shouldShowIcon(paramRemoteAction)); 
    return remoteActionCompat;
  }
  
  public PendingIntent getActionIntent() {
    return this.mActionIntent;
  }
  
  public CharSequence getContentDescription() {
    return this.mContentDescription;
  }
  
  public IconCompat getIcon() {
    return this.mIcon;
  }
  
  public CharSequence getTitle() {
    return this.mTitle;
  }
  
  public boolean isEnabled() {
    return this.mEnabled;
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.mEnabled = paramBoolean;
  }
  
  public void setShouldShowIcon(boolean paramBoolean) {
    this.mShouldShowIcon = paramBoolean;
  }
  
  public boolean shouldShowIcon() {
    return this.mShouldShowIcon;
  }
  
  public RemoteAction toRemoteAction() {
    RemoteAction remoteAction = Api26Impl.createRemoteAction(this.mIcon.toIcon(), this.mTitle, this.mContentDescription, this.mActionIntent);
    Api26Impl.setEnabled(remoteAction, isEnabled());
    if (Build.VERSION.SDK_INT >= 28)
      Api28Impl.setShouldShowIcon(remoteAction, shouldShowIcon()); 
    return remoteAction;
  }
  
  static class Api26Impl {
    static RemoteAction createRemoteAction(Icon param1Icon, CharSequence param1CharSequence1, CharSequence param1CharSequence2, PendingIntent param1PendingIntent) {
      return new RemoteAction(param1Icon, param1CharSequence1, param1CharSequence2, param1PendingIntent);
    }
    
    static PendingIntent getActionIntent(RemoteAction param1RemoteAction) {
      return param1RemoteAction.getActionIntent();
    }
    
    static CharSequence getContentDescription(RemoteAction param1RemoteAction) {
      return param1RemoteAction.getContentDescription();
    }
    
    static Icon getIcon(RemoteAction param1RemoteAction) {
      return param1RemoteAction.getIcon();
    }
    
    static CharSequence getTitle(RemoteAction param1RemoteAction) {
      return param1RemoteAction.getTitle();
    }
    
    static boolean isEnabled(RemoteAction param1RemoteAction) {
      return param1RemoteAction.isEnabled();
    }
    
    static void setEnabled(RemoteAction param1RemoteAction, boolean param1Boolean) {
      param1RemoteAction.setEnabled(param1Boolean);
    }
  }
  
  static class Api28Impl {
    static void setShouldShowIcon(RemoteAction param1RemoteAction, boolean param1Boolean) {
      param1RemoteAction.setShouldShowIcon(param1Boolean);
    }
    
    static boolean shouldShowIcon(RemoteAction param1RemoteAction) {
      return param1RemoteAction.shouldShowIcon();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */