package androidx.core.app;

import android.app.SharedElementCallback;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\app\-$$Lambda$ActivityCompat$SharedElementCallback21Impl$UQYxTVUGBXZA2YdDvfsJsu7Oz1c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */