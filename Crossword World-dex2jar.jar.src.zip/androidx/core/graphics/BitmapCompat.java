package androidx.core.graphics;

import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.os.Build;

public final class BitmapCompat {
  public static Bitmap createScaledBitmap(Bitmap paramBitmap, int paramInt1, int paramInt2, Rect paramRect, boolean paramBoolean) {
    if (paramInt1 > 0 && paramInt2 > 0) {
      if (paramRect == null || (!paramRect.isEmpty() && paramRect.left >= 0 && paramRect.right <= paramBitmap.getWidth() && paramRect.top >= 0 && paramRect.bottom <= paramBitmap.getHeight())) {
        Bitmap bitmap1;
        double d1;
        byte b;
        int j;
        int k;
        int m;
        Bitmap bitmap2;
        if (Build.VERSION.SDK_INT >= 27) {
          bitmap2 = Api27Impl.copyBitmapIfHardware(paramBitmap);
        } else {
          bitmap2 = paramBitmap;
        } 
        if (paramRect != null) {
          k = paramRect.width();
        } else {
          k = paramBitmap.getWidth();
        } 
        if (paramRect != null) {
          m = paramRect.height();
        } else {
          m = paramBitmap.getHeight();
        } 
        float f1 = paramInt1 / k;
        float f2 = paramInt2 / m;
        if (paramRect != null) {
          b = paramRect.left;
        } else {
          b = 0;
        } 
        if (paramRect != null) {
          i = paramRect.top;
        } else {
          i = 0;
        } 
        if (!b && !i && paramInt1 == paramBitmap.getWidth() && paramInt2 == paramBitmap.getHeight())
          return (paramBitmap.isMutable() && paramBitmap == bitmap2) ? paramBitmap.copy(paramBitmap.getConfig(), true) : bitmap2; 
        Paint paint = new Paint(1);
        paint.setFilterBitmap(true);
        if (Build.VERSION.SDK_INT >= 29) {
          Api29Impl.setPaintBlendMode(paint);
        } else {
          paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.SRC));
        } 
        if (k == paramInt1 && m == paramInt2) {
          paramBitmap = Bitmap.createBitmap(paramInt1, paramInt2, bitmap2.getConfig());
          (new Canvas(paramBitmap)).drawBitmap(bitmap2, -b, -i, paint);
          return paramBitmap;
        } 
        double d2 = Math.log(2.0D);
        if (f1 > 1.0F) {
          d1 = Math.ceil(Math.log(f1) / d2);
        } else {
          d1 = Math.floor(Math.log(f1) / d2);
        } 
        int i1 = (int)d1;
        if (f2 > 1.0F) {
          d1 = Math.ceil(Math.log(f2) / d2);
        } else {
          d1 = Math.floor(Math.log(f2) / d2);
        } 
        int i2 = (int)d1;
        paramRect = null;
        if (paramBoolean && Build.VERSION.SDK_INT >= 27 && !Api27Impl.isAlreadyF16AndLinear(paramBitmap)) {
          int i3;
          if (i1 > 0) {
            j = sizeAtStep(k, paramInt1, 1, i1);
          } else {
            j = k;
          } 
          if (i2 > 0) {
            i3 = sizeAtStep(m, paramInt2, 1, i2);
          } else {
            i3 = m;
          } 
          Bitmap bitmap = Api27Impl.createBitmapWithSourceColorspace(j, i3, paramBitmap, true);
          (new Canvas(bitmap)).drawBitmap(bitmap2, -b, -i, paint);
          i = 0;
          j = 0;
          b = 1;
          bitmap1 = bitmap2;
          bitmap2 = bitmap;
        } else {
          j = b;
          b = 0;
        } 
        Rect rect2 = new Rect(j, i, k, m);
        Rect rect3 = new Rect();
        int i = i1;
        int n = i2;
        Bitmap bitmap3 = bitmap2;
        Rect rect1 = rect3;
        while (true) {
          if (i != 0 || n != 0) {
            int i3;
            if (i < 0) {
              j = i + 1;
            } else {
              j = i;
              if (i > 0)
                j = i - 1; 
            } 
            if (n < 0) {
              i = n + 1;
            } else {
              i = n;
              if (n > 0)
                i = n - 1; 
            } 
            rect1.set(0, 0, sizeAtStep(k, paramInt1, j, i1), sizeAtStep(m, paramInt2, i, i2));
            if (j == 0 && i == 0) {
              n = 1;
            } else {
              n = 0;
            } 
            if (bitmap1 != null && bitmap1.getWidth() == paramInt1 && bitmap1.getHeight() == paramInt2) {
              i3 = 1;
            } else {
              i3 = 0;
            } 
            if (bitmap1 == null || bitmap1 == paramBitmap || (paramBoolean && Build.VERSION.SDK_INT >= 27 && !Api27Impl.isAlreadyF16AndLinear(bitmap1)) || (n != 0 && (!i3 || b != 0))) {
              if (bitmap1 != paramBitmap && bitmap1 != null)
                bitmap1.recycle(); 
              if (j > 0) {
                i3 = b;
              } else {
                i3 = j;
              } 
              int i4 = sizeAtStep(k, paramInt1, i3, i1);
              if (i > 0) {
                i3 = b;
              } else {
                i3 = i;
              } 
              i3 = sizeAtStep(m, paramInt2, i3, i2);
              if (Build.VERSION.SDK_INT >= 27) {
                boolean bool;
                if (paramBoolean && n == 0) {
                  bool = true;
                } else {
                  bool = false;
                } 
                bitmap1 = Api27Impl.createBitmapWithSourceColorspace(i4, i3, paramBitmap, bool);
              } else {
                bitmap1 = Bitmap.createBitmap(i4, i3, bitmap3.getConfig());
              } 
            } 
            (new Canvas(bitmap1)).drawBitmap(bitmap3, rect2, rect1, paint);
            rect2.set(rect1);
            n = i;
            Paint paint2 = paint;
            Bitmap bitmap = bitmap3;
            bitmap3 = bitmap1;
            bitmap1 = bitmap;
            i = j;
            Paint paint1 = paint2;
            continue;
          } 
          if (bitmap1 != paramBitmap && bitmap1 != null)
            bitmap1.recycle(); 
          return bitmap3;
        } 
      } 
      throw new IllegalArgumentException("srcRect must be contained by srcBm!");
    } 
    throw new IllegalArgumentException("dstW and dstH must be > 0!");
  }
  
  public static int getAllocationByteCount(Bitmap paramBitmap) {
    return (Build.VERSION.SDK_INT >= 19) ? Api19Impl.getAllocationByteCount(paramBitmap) : paramBitmap.getByteCount();
  }
  
  public static boolean hasMipMap(Bitmap paramBitmap) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.hasMipMap(paramBitmap) : false;
  }
  
  public static void setHasMipMap(Bitmap paramBitmap, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 17)
      Api17Impl.setHasMipMap(paramBitmap, paramBoolean); 
  }
  
  public static int sizeAtStep(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (paramInt3 == 0) ? paramInt2 : ((paramInt3 > 0) ? (paramInt1 * (1 << paramInt4 - paramInt3)) : (paramInt2 << -paramInt3 - 1));
  }
  
  static class Api17Impl {
    static boolean hasMipMap(Bitmap param1Bitmap) {
      return param1Bitmap.hasMipMap();
    }
    
    static void setHasMipMap(Bitmap param1Bitmap, boolean param1Boolean) {
      param1Bitmap.setHasMipMap(param1Boolean);
    }
  }
  
  static class Api19Impl {
    static int getAllocationByteCount(Bitmap param1Bitmap) {
      return param1Bitmap.getAllocationByteCount();
    }
  }
  
  static class Api27Impl {
    static Bitmap copyBitmapIfHardware(Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap.getConfig() == Bitmap.Config.HARDWARE) {
        Bitmap.Config config = Bitmap.Config.ARGB_8888;
        if (Build.VERSION.SDK_INT >= 31)
          config = BitmapCompat.Api31Impl.getHardwareBitmapConfig(param1Bitmap); 
        bitmap = param1Bitmap.copy(config, true);
      } 
      return bitmap;
    }
    
    static Bitmap createBitmapWithSourceColorspace(int param1Int1, int param1Int2, Bitmap param1Bitmap, boolean param1Boolean) {
      Bitmap.Config config = param1Bitmap.getConfig();
      ColorSpace colorSpace2 = param1Bitmap.getColorSpace();
      ColorSpace colorSpace1 = ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
      if (param1Boolean && !param1Bitmap.getColorSpace().equals(colorSpace1)) {
        config = Bitmap.Config.RGBA_F16;
      } else {
        colorSpace1 = colorSpace2;
        if (param1Bitmap.getConfig() == Bitmap.Config.HARDWARE) {
          config = Bitmap.Config.ARGB_8888;
          colorSpace1 = colorSpace2;
          if (Build.VERSION.SDK_INT >= 31) {
            config = BitmapCompat.Api31Impl.getHardwareBitmapConfig(param1Bitmap);
            colorSpace1 = colorSpace2;
          } 
        } 
      } 
      return Bitmap.createBitmap(param1Int1, param1Int2, config, param1Bitmap.hasAlpha(), colorSpace1);
    }
    
    static boolean isAlreadyF16AndLinear(Bitmap param1Bitmap) {
      ColorSpace colorSpace = ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
      return (param1Bitmap.getConfig() == Bitmap.Config.RGBA_F16 && param1Bitmap.getColorSpace().equals(colorSpace));
    }
  }
  
  static class Api29Impl {
    static void setPaintBlendMode(Paint param1Paint) {
      param1Paint.setBlendMode(BlendMode.SRC);
    }
  }
  
  static class Api31Impl {
    static Bitmap.Config getHardwareBitmapConfig(Bitmap param1Bitmap) {
      return (param1Bitmap.getHardwareBuffer().getFormat() == 22) ? Bitmap.Config.RGBA_F16 : Bitmap.Config.ARGB_8888;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\BitmapCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */