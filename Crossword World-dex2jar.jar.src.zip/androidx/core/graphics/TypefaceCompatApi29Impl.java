package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.os.CancellationSignal;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.provider.FontsContractCompat;
import java.io.IOException;
import java.io.InputStream;

public class TypefaceCompatApi29Impl extends TypefaceCompatBaseImpl {
  private Font findBaseFont(FontFamily paramFontFamily, int paramInt) {
    if ((paramInt & 0x1) != 0) {
      i = 700;
    } else {
      i = 400;
    } 
    int j = 1;
    if ((paramInt & 0x2) != 0) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    FontStyle fontStyle = new FontStyle(i, paramInt);
    Font font = paramFontFamily.getFont(0);
    int i = getMatchScore(fontStyle, font.getStyle());
    paramInt = j;
    while (paramInt < paramFontFamily.getSize()) {
      Font font1 = paramFontFamily.getFont(paramInt);
      int k = getMatchScore(fontStyle, font1.getStyle());
      j = i;
      if (k < i) {
        font = font1;
        j = k;
      } 
      paramInt++;
      i = j;
    } 
    return font;
  }
  
  private static int getMatchScore(FontStyle paramFontStyle1, FontStyle paramFontStyle2) {
    byte b;
    int i = Math.abs(paramFontStyle1.getWeight() - paramFontStyle2.getWeight()) / 100;
    if (paramFontStyle1.getSlant() == paramFontStyle2.getSlant()) {
      b = 0;
    } else {
      b = 2;
    } 
    return i + b;
  }
  
  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt) {
    try {
      FontResourcesParserCompat.FontFileResourceEntry[] arrayOfFontFileResourceEntry = paramFontFamilyFilesResourceEntry.getEntries();
      int j = arrayOfFontFileResourceEntry.length;
      paramContext = null;
      int i = 0;
      while (true) {
        FontFamily.Builder builder;
        if (i < j) {
          FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = arrayOfFontFileResourceEntry[i];
          try {
            FontFamily.Builder builder1;
            boolean bool;
            Font.Builder builder2 = (new Font.Builder(paramResources, fontFileResourceEntry.getResourceId())).setWeight(fontFileResourceEntry.getWeight());
            if (fontFileResourceEntry.isItalic()) {
              bool = true;
            } else {
              bool = false;
            } 
            Font font = builder2.setSlant(bool).setTtcIndex(fontFileResourceEntry.getTtcIndex()).setFontVariationSettings(fontFileResourceEntry.getVariationSettings()).build();
            if (paramContext == null) {
              builder1 = new FontFamily.Builder(font);
              builder = builder1;
            } else {
              builder.addFont((Font)builder1);
            } 
          } catch (IOException iOException) {}
          i++;
          continue;
        } 
        if (builder == null)
          return null; 
        FontFamily fontFamily = builder.build();
        return (new Typeface.CustomFallbackBuilder(fontFamily)).setStyle(findBaseFont(fontFamily, paramInt).getStyle()).build();
      } 
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public Typeface createFromFontInfo(Context paramContext, CancellationSignal paramCancellationSignal, FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: astore #9
    //   6: aload_3
    //   7: arraylength
    //   8: istore #7
    //   10: aconst_null
    //   11: astore_1
    //   12: iconst_0
    //   13: istore #5
    //   15: iload #5
    //   17: iload #7
    //   19: if_icmpge -> 210
    //   22: aload_3
    //   23: iload #5
    //   25: aaload
    //   26: astore #11
    //   28: aload_1
    //   29: astore #8
    //   31: aload #9
    //   33: aload #11
    //   35: invokevirtual getUri : ()Landroid/net/Uri;
    //   38: ldc 'r'
    //   40: aload_2
    //   41: invokevirtual openFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   44: astore #10
    //   46: aload #10
    //   48: ifnonnull -> 73
    //   51: aload_1
    //   52: astore #8
    //   54: aload #10
    //   56: ifnull -> 198
    //   59: aload_1
    //   60: astore #8
    //   62: aload #10
    //   64: invokevirtual close : ()V
    //   67: aload_1
    //   68: astore #8
    //   70: goto -> 198
    //   73: new android/graphics/fonts/Font$Builder
    //   76: dup
    //   77: aload #10
    //   79: invokespecial <init> : (Landroid/os/ParcelFileDescriptor;)V
    //   82: aload #11
    //   84: invokevirtual getWeight : ()I
    //   87: invokevirtual setWeight : (I)Landroid/graphics/fonts/Font$Builder;
    //   90: astore #8
    //   92: aload #11
    //   94: invokevirtual isItalic : ()Z
    //   97: ifeq -> 255
    //   100: iconst_1
    //   101: istore #6
    //   103: goto -> 106
    //   106: aload #8
    //   108: iload #6
    //   110: invokevirtual setSlant : (I)Landroid/graphics/fonts/Font$Builder;
    //   113: aload #11
    //   115: invokevirtual getTtcIndex : ()I
    //   118: invokevirtual setTtcIndex : (I)Landroid/graphics/fonts/Font$Builder;
    //   121: invokevirtual build : ()Landroid/graphics/fonts/Font;
    //   124: astore #8
    //   126: aload_1
    //   127: ifnonnull -> 147
    //   130: new android/graphics/fonts/FontFamily$Builder
    //   133: dup
    //   134: aload #8
    //   136: invokespecial <init> : (Landroid/graphics/fonts/Font;)V
    //   139: astore #8
    //   141: aload #8
    //   143: astore_1
    //   144: goto -> 154
    //   147: aload_1
    //   148: aload #8
    //   150: invokevirtual addFont : (Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/FontFamily$Builder;
    //   153: pop
    //   154: aload_1
    //   155: astore #8
    //   157: aload #10
    //   159: ifnull -> 198
    //   162: goto -> 59
    //   165: astore #11
    //   167: aload #10
    //   169: ifnull -> 192
    //   172: aload #10
    //   174: invokevirtual close : ()V
    //   177: goto -> 192
    //   180: astore #10
    //   182: aload_1
    //   183: astore #8
    //   185: aload #11
    //   187: aload #10
    //   189: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   192: aload_1
    //   193: astore #8
    //   195: aload #11
    //   197: athrow
    //   198: iload #5
    //   200: iconst_1
    //   201: iadd
    //   202: istore #5
    //   204: aload #8
    //   206: astore_1
    //   207: goto -> 15
    //   210: aload_1
    //   211: ifnonnull -> 216
    //   214: aconst_null
    //   215: areturn
    //   216: aload_1
    //   217: invokevirtual build : ()Landroid/graphics/fonts/FontFamily;
    //   220: astore_1
    //   221: new android/graphics/Typeface$CustomFallbackBuilder
    //   224: dup
    //   225: aload_1
    //   226: invokespecial <init> : (Landroid/graphics/fonts/FontFamily;)V
    //   229: aload_0
    //   230: aload_1
    //   231: iload #4
    //   233: invokespecial findBaseFont : (Landroid/graphics/fonts/FontFamily;I)Landroid/graphics/fonts/Font;
    //   236: invokevirtual getStyle : ()Landroid/graphics/fonts/FontStyle;
    //   239: invokevirtual setStyle : (Landroid/graphics/fonts/FontStyle;)Landroid/graphics/Typeface$CustomFallbackBuilder;
    //   242: invokevirtual build : ()Landroid/graphics/Typeface;
    //   245: astore_1
    //   246: aload_1
    //   247: areturn
    //   248: astore_1
    //   249: aconst_null
    //   250: areturn
    //   251: astore_1
    //   252: goto -> 198
    //   255: iconst_0
    //   256: istore #6
    //   258: goto -> 106
    // Exception table:
    //   from	to	target	type
    //   6	10	248	java/lang/Exception
    //   31	46	251	java/io/IOException
    //   31	46	248	java/lang/Exception
    //   62	67	251	java/io/IOException
    //   62	67	248	java/lang/Exception
    //   73	100	165	finally
    //   106	126	165	finally
    //   130	141	165	finally
    //   147	154	165	finally
    //   172	177	180	finally
    //   185	192	251	java/io/IOException
    //   185	192	248	java/lang/Exception
    //   195	198	251	java/io/IOException
    //   195	198	248	java/lang/Exception
    //   216	246	248	java/lang/Exception
  }
  
  protected Typeface createFromInputStream(Context paramContext, InputStream paramInputStream) {
    throw new RuntimeException("Do not use this function in API 29 or later.");
  }
  
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    try {
      Font font = (new Font.Builder(paramResources, paramInt1)).build();
      return (new Typeface.CustomFallbackBuilder((new FontFamily.Builder(font)).build())).setStyle(font.getStyle()).build();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  Typeface createWeightStyle(Context paramContext, Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    return Typeface.create(paramTypeface, paramInt, paramBoolean);
  }
  
  protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    throw new RuntimeException("Do not use this function in API 29 or later.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\TypefaceCompatApi29Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */