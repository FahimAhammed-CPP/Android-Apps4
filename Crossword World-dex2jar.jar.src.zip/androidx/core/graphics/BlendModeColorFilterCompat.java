package androidx.core.graphics;

import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;

public class BlendModeColorFilterCompat {
  public static ColorFilter createBlendModeColorFilterCompat(int paramInt, BlendModeCompat paramBlendModeCompat) {
    ColorFilter colorFilter;
    int i = Build.VERSION.SDK_INT;
    Object object2 = null;
    BlendModeCompat blendModeCompat = null;
    if (i >= 29) {
      object2 = BlendModeUtils.Api29Impl.obtainBlendModeFromCompat(paramBlendModeCompat);
      paramBlendModeCompat = blendModeCompat;
      if (object2 != null)
        colorFilter = Api29Impl.createBlendModeColorFilter(paramInt, object2); 
      return colorFilter;
    } 
    PorterDuff.Mode mode = BlendModeUtils.obtainPorterDuffFromCompat((BlendModeCompat)colorFilter);
    Object object1 = object2;
    if (mode != null)
      object1 = new PorterDuffColorFilter(paramInt, mode); 
    return (ColorFilter)object1;
  }
  
  static class Api29Impl {
    static ColorFilter createBlendModeColorFilter(int param1Int, Object param1Object) {
      return (ColorFilter)new BlendModeColorFilter(param1Int, (BlendMode)param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\BlendModeColorFilterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */