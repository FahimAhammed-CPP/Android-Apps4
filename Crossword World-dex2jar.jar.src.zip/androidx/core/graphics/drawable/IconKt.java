package androidx.core.graphics.drawable;

import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.net.Uri;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\026\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\020\022\n\000\032\r\020\000\032\0020\001*\0020\002H\b\032\r\020\003\032\0020\001*\0020\002H\b\032\r\020\003\032\0020\001*\0020\004H\b\032\r\020\003\032\0020\001*\0020\005H\b¨\006\006"}, d2 = {"toAdaptiveIcon", "Landroid/graphics/drawable/Icon;", "Landroid/graphics/Bitmap;", "toIcon", "Landroid/net/Uri;", "", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class IconKt {
  public static final Icon toAdaptiveIcon(Bitmap paramBitmap) {
    Intrinsics.checkNotNullParameter(paramBitmap, "<this>");
    Icon icon = Icon.createWithAdaptiveBitmap(paramBitmap);
    Intrinsics.checkNotNullExpressionValue(icon, "createWithAdaptiveBitmap(this)");
    return icon;
  }
  
  public static final Icon toIcon(Bitmap paramBitmap) {
    Intrinsics.checkNotNullParameter(paramBitmap, "<this>");
    Icon icon = Icon.createWithBitmap(paramBitmap);
    Intrinsics.checkNotNullExpressionValue(icon, "createWithBitmap(this)");
    return icon;
  }
  
  public static final Icon toIcon(Uri paramUri) {
    Intrinsics.checkNotNullParameter(paramUri, "<this>");
    Icon icon = Icon.createWithContentUri(paramUri);
    Intrinsics.checkNotNullExpressionValue(icon, "createWithContentUri(this)");
    return icon;
  }
  
  public static final Icon toIcon(byte[] paramArrayOfbyte) {
    Intrinsics.checkNotNullParameter(paramArrayOfbyte, "<this>");
    Icon icon = Icon.createWithData(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    Intrinsics.checkNotNullExpressionValue(icon, "createWithData(this, 0, size)");
    return icon;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\drawable\IconKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */