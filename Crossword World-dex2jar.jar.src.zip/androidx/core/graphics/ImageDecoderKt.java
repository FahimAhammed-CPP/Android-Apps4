package androidx.core.graphics;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Drawable;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\0000\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\000\032U\020\000\032\0020\001*\0020\0022C\b\004\020\003\032=\022\004\022\0020\005\022\023\022\0210\006¢\006\f\b\007\022\b\b\b\022\004\b\b(\t\022\023\022\0210\002¢\006\f\b\007\022\b\b\b\022\004\b\b(\n\022\004\022\0020\0130\004¢\006\002\b\fH\bø\001\000\032U\020\r\032\0020\016*\0020\0022C\b\004\020\003\032=\022\004\022\0020\005\022\023\022\0210\006¢\006\f\b\007\022\b\b\b\022\004\b\b(\t\022\023\022\0210\002¢\006\f\b\007\022\b\b\b\022\004\b\b(\n\022\004\022\0020\0130\004¢\006\002\b\fH\bø\001\000\002\007\n\005\b20\001¨\006\017"}, d2 = {"decodeBitmap", "Landroid/graphics/Bitmap;", "Landroid/graphics/ImageDecoder$Source;", "action", "Lkotlin/Function3;", "Landroid/graphics/ImageDecoder;", "Landroid/graphics/ImageDecoder$ImageInfo;", "Lkotlin/ParameterName;", "name", "info", "source", "", "Lkotlin/ExtensionFunctionType;", "decodeDrawable", "Landroid/graphics/drawable/Drawable;", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class ImageDecoderKt {
  public static final Bitmap decodeBitmap(ImageDecoder.Source paramSource, Function3<? super ImageDecoder, ? super ImageDecoder.ImageInfo, ? super ImageDecoder.Source, Unit> paramFunction3) {
    Intrinsics.checkNotNullParameter(paramSource, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction3, "action");
    Bitmap bitmap = ImageDecoder.decodeBitmap(paramSource, new ImageDecoderKt$decodeBitmap$1(paramFunction3));
    Intrinsics.checkNotNullExpressionValue(bitmap, "crossinline action: Imag…ction(info, source)\n    }");
    return bitmap;
  }
  
  public static final Drawable decodeDrawable(ImageDecoder.Source paramSource, Function3<? super ImageDecoder, ? super ImageDecoder.ImageInfo, ? super ImageDecoder.Source, Unit> paramFunction3) {
    Intrinsics.checkNotNullParameter(paramSource, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction3, "action");
    Drawable drawable = ImageDecoder.decodeDrawable(paramSource, new ImageDecoderKt$decodeDrawable$1(paramFunction3));
    Intrinsics.checkNotNullExpressionValue(drawable, "crossinline action: Imag…ction(info, source)\n    }");
    return drawable;
  }
  
  @Metadata(d1 = {"\000\032\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\007H\n¢\006\002\b\b"}, d2 = {"<anonymous>", "", "decoder", "Landroid/graphics/ImageDecoder;", "info", "Landroid/graphics/ImageDecoder$ImageInfo;", "source", "Landroid/graphics/ImageDecoder$Source;", "onHeaderDecoded"}, k = 3, mv = {1, 7, 1}, xi = 176)
  public static final class ImageDecoderKt$decodeBitmap$1 implements ImageDecoder.OnHeaderDecodedListener {
    public ImageDecoderKt$decodeBitmap$1(Function3<? super ImageDecoder, ? super ImageDecoder.ImageInfo, ? super ImageDecoder.Source, Unit> param1Function3) {}
    
    public final void onHeaderDecoded(ImageDecoder param1ImageDecoder, ImageDecoder.ImageInfo param1ImageInfo, ImageDecoder.Source param1Source) {
      Intrinsics.checkNotNullParameter(param1ImageDecoder, "decoder");
      Intrinsics.checkNotNullParameter(param1ImageInfo, "info");
      Intrinsics.checkNotNullParameter(param1Source, "source");
      this.$action.invoke(param1ImageDecoder, param1ImageInfo, param1Source);
    }
  }
  
  @Metadata(d1 = {"\000\032\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\007H\n¢\006\002\b\b"}, d2 = {"<anonymous>", "", "decoder", "Landroid/graphics/ImageDecoder;", "info", "Landroid/graphics/ImageDecoder$ImageInfo;", "source", "Landroid/graphics/ImageDecoder$Source;", "onHeaderDecoded"}, k = 3, mv = {1, 7, 1}, xi = 176)
  public static final class ImageDecoderKt$decodeDrawable$1 implements ImageDecoder.OnHeaderDecodedListener {
    public ImageDecoderKt$decodeDrawable$1(Function3<? super ImageDecoder, ? super ImageDecoder.ImageInfo, ? super ImageDecoder.Source, Unit> param1Function3) {}
    
    public final void onHeaderDecoded(ImageDecoder param1ImageDecoder, ImageDecoder.ImageInfo param1ImageInfo, ImageDecoder.Source param1Source) {
      Intrinsics.checkNotNullParameter(param1ImageDecoder, "decoder");
      Intrinsics.checkNotNullParameter(param1ImageInfo, "info");
      Intrinsics.checkNotNullParameter(param1Source, "source");
      this.$action.invoke(param1ImageDecoder, param1ImageInfo, param1Source);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\ImageDecoderKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */