package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class PathParser {
  private static final String LOGTAG = "PathParser";
  
  private static void addNode(ArrayList<PathDataNode> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new PathDataNode(paramChar, paramArrayOffloat));
  }
  
  public static boolean canMorph(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    if (paramArrayOfPathDataNode1 != null) {
      if (paramArrayOfPathDataNode2 == null)
        return false; 
      if (paramArrayOfPathDataNode1.length != paramArrayOfPathDataNode2.length)
        return false; 
      int i = 0;
      while (i < paramArrayOfPathDataNode1.length) {
        if ((paramArrayOfPathDataNode1[i]).mType == (paramArrayOfPathDataNode2[i]).mType) {
          if ((paramArrayOfPathDataNode1[i]).mParams.length != (paramArrayOfPathDataNode2[i]).mParams.length)
            return false; 
          i++;
          continue;
        } 
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  static float[] copyOfRange(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        paramInt2 -= paramInt1;
        i = Math.min(paramInt2, i - paramInt1);
        float[] arrayOfFloat = new float[paramInt2];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, i);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  public static PathDataNode[] createNodesFromPathData(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<PathDataNode> arrayList = new ArrayList();
    int j = 1;
    int i = 0;
    while (j < paramString.length()) {
      j = nextStart(paramString, j);
      String str = paramString.substring(i, j).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = getFloats(str);
        addNode(arrayList, str.charAt(0), arrayOfFloat);
      } 
      i = j;
      j++;
    } 
    if (j - i == 1 && i < paramString.length())
      addNode(arrayList, paramString.charAt(i), new float[0]); 
    return arrayList.<PathDataNode>toArray(new PathDataNode[arrayList.size()]);
  }
  
  public static Path createPathFromPathData(String paramString) {
    Path path = new Path();
    PathDataNode[] arrayOfPathDataNode = createNodesFromPathData(paramString);
    if (arrayOfPathDataNode != null)
      try {
        PathDataNode.nodesToPath(arrayOfPathDataNode, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static PathDataNode[] deepCopyNodes(PathDataNode[] paramArrayOfPathDataNode) {
    if (paramArrayOfPathDataNode == null)
      return null; 
    PathDataNode[] arrayOfPathDataNode = new PathDataNode[paramArrayOfPathDataNode.length];
    for (int i = 0; i < paramArrayOfPathDataNode.length; i++)
      arrayOfPathDataNode[i] = new PathDataNode(paramArrayOfPathDataNode[i]); 
    return arrayOfPathDataNode;
  }
  
  private static void extract(String paramString, int paramInt, ExtractFloatResult paramExtractFloatResult) {
    paramExtractFloatResult.mEndWithNegOrDot = false;
    int i = paramInt;
    boolean bool1 = false;
    boolean bool3 = false;
    boolean bool2 = false;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != ' ') {
        if (c != 'E' && c != 'e') {
          switch (c) {
            default:
              bool1 = false;
              break;
            case '.':
              if (!bool3) {
                bool1 = false;
                bool3 = true;
                break;
              } 
              paramExtractFloatResult.mEndWithNegOrDot = true;
            case '-':
            
            case ',':
              bool1 = false;
              bool2 = true;
              break;
          } 
        } else {
          bool1 = true;
        } 
        if (bool2)
          break; 
        continue;
      } 
      i++;
    } 
    paramExtractFloatResult.mEndPosition = i;
  }
  
  private static float[] getFloats(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      float[] arrayOfFloat = new float[paramString.length()];
      ExtractFloatResult extractFloatResult = new ExtractFloatResult();
      int k = paramString.length();
      int i = 1;
      for (int j = 0;; j = m) {
        int m;
        int n;
        if (i < k) {
          extract(paramString, i, extractFloatResult);
          n = extractFloatResult.mEndPosition;
          m = j;
          if (i < n) {
            arrayOfFloat[j] = Float.parseFloat(paramString.substring(i, n));
            m = j + 1;
          } 
          if (extractFloatResult.mEndWithNegOrDot) {
            i = n;
            j = m;
            continue;
          } 
        } else {
          return copyOfRange(arrayOfFloat, 0, j);
        } 
        i = n + 1;
      } 
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  public static boolean interpolatePathDataNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2, PathDataNode[] paramArrayOfPathDataNode3, float paramFloat) {
    if (paramArrayOfPathDataNode1 != null && paramArrayOfPathDataNode2 != null && paramArrayOfPathDataNode3 != null) {
      if (paramArrayOfPathDataNode1.length == paramArrayOfPathDataNode2.length && paramArrayOfPathDataNode2.length == paramArrayOfPathDataNode3.length) {
        boolean bool = canMorph(paramArrayOfPathDataNode2, paramArrayOfPathDataNode3);
        int i = 0;
        if (!bool)
          return false; 
        while (i < paramArrayOfPathDataNode1.length) {
          paramArrayOfPathDataNode1[i].interpolatePathDataNode(paramArrayOfPathDataNode2[i], paramArrayOfPathDataNode3[i], paramFloat);
          i++;
        } 
        return true;
      } 
      throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
    } 
    throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
  }
  
  private static int nextStart(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  public static void updateNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    for (int i = 0; i < paramArrayOfPathDataNode2.length; i++) {
      (paramArrayOfPathDataNode1[i]).mType = (paramArrayOfPathDataNode2[i]).mType;
      for (int j = 0; j < (paramArrayOfPathDataNode2[i]).mParams.length; j++)
        (paramArrayOfPathDataNode1[i]).mParams[j] = (paramArrayOfPathDataNode2[i]).mParams[j]; 
    } 
  }
  
  private static class ExtractFloatResult {
    int mEndPosition;
    
    boolean mEndWithNegOrDot;
  }
  
  public static class PathDataNode {
    public float[] mParams;
    
    public char mType;
    
    PathDataNode(char param1Char, float[] param1ArrayOffloat) {
      this.mType = param1Char;
      this.mParams = param1ArrayOffloat;
    }
    
    PathDataNode(PathDataNode param1PathDataNode) {
      this.mType = param1PathDataNode.mType;
      float[] arrayOfFloat = param1PathDataNode.mParams;
      this.mParams = PathParser.copyOfRange(arrayOfFloat, 0, arrayOfFloat.length);
    }
    
    private static void addCommand(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: faload
      //   3: fstore #11
      //   5: aload_1
      //   6: iconst_1
      //   7: faload
      //   8: fstore #12
      //   10: aload_1
      //   11: iconst_2
      //   12: faload
      //   13: fstore #13
      //   15: aload_1
      //   16: iconst_3
      //   17: faload
      //   18: fstore #14
      //   20: aload_1
      //   21: iconst_4
      //   22: faload
      //   23: fstore #10
      //   25: aload_1
      //   26: iconst_5
      //   27: faload
      //   28: fstore #9
      //   30: fload #11
      //   32: fstore #5
      //   34: fload #12
      //   36: fstore #6
      //   38: fload #13
      //   40: fstore #7
      //   42: fload #14
      //   44: fstore #8
      //   46: iload_3
      //   47: lookupswitch default -> 216, 65 -> 336, 67 -> 313, 72 -> 291, 76 -> 232, 77 -> 232, 81 -> 269, 83 -> 269, 84 -> 232, 86 -> 291, 90 -> 238, 97 -> 336, 99 -> 313, 104 -> 291, 108 -> 232, 109 -> 232, 113 -> 269, 115 -> 269, 116 -> 232, 118 -> 291, 122 -> 238
      //   216: fload #14
      //   218: fstore #8
      //   220: fload #13
      //   222: fstore #7
      //   224: fload #12
      //   226: fstore #6
      //   228: fload #11
      //   230: fstore #5
      //   232: iconst_2
      //   233: istore #15
      //   235: goto -> 356
      //   238: aload_0
      //   239: invokevirtual close : ()V
      //   242: aload_0
      //   243: fload #10
      //   245: fload #9
      //   247: invokevirtual moveTo : (FF)V
      //   250: fload #10
      //   252: fstore #5
      //   254: fload #5
      //   256: fstore #7
      //   258: fload #9
      //   260: fstore #6
      //   262: fload #6
      //   264: fstore #8
      //   266: goto -> 232
      //   269: iconst_4
      //   270: istore #15
      //   272: fload #11
      //   274: fstore #5
      //   276: fload #12
      //   278: fstore #6
      //   280: fload #13
      //   282: fstore #7
      //   284: fload #14
      //   286: fstore #8
      //   288: goto -> 356
      //   291: iconst_1
      //   292: istore #15
      //   294: fload #11
      //   296: fstore #5
      //   298: fload #12
      //   300: fstore #6
      //   302: fload #13
      //   304: fstore #7
      //   306: fload #14
      //   308: fstore #8
      //   310: goto -> 356
      //   313: bipush #6
      //   315: istore #15
      //   317: fload #11
      //   319: fstore #5
      //   321: fload #12
      //   323: fstore #6
      //   325: fload #13
      //   327: fstore #7
      //   329: fload #14
      //   331: fstore #8
      //   333: goto -> 356
      //   336: bipush #7
      //   338: istore #15
      //   340: fload #14
      //   342: fstore #8
      //   344: fload #13
      //   346: fstore #7
      //   348: fload #12
      //   350: fstore #6
      //   352: fload #11
      //   354: fstore #5
      //   356: iconst_0
      //   357: istore #17
      //   359: iload_2
      //   360: istore #16
      //   362: fload #9
      //   364: fstore #11
      //   366: fload #10
      //   368: fstore #12
      //   370: iload #17
      //   372: istore_2
      //   373: iload_3
      //   374: istore #17
      //   376: iload_2
      //   377: aload #4
      //   379: arraylength
      //   380: if_icmpge -> 2147
      //   383: iload #17
      //   385: bipush #65
      //   387: if_icmpeq -> 1993
      //   390: iload #17
      //   392: bipush #67
      //   394: if_icmpeq -> 1877
      //   397: iload #17
      //   399: bipush #72
      //   401: if_icmpeq -> 1851
      //   404: iload #17
      //   406: bipush #81
      //   408: if_icmpeq -> 1757
      //   411: iload #17
      //   413: bipush #86
      //   415: if_icmpeq -> 1731
      //   418: iload #17
      //   420: bipush #97
      //   422: if_icmpeq -> 1591
      //   425: iload #17
      //   427: bipush #99
      //   429: if_icmpeq -> 1448
      //   432: iload #17
      //   434: bipush #104
      //   436: if_icmpeq -> 1420
      //   439: iload #17
      //   441: bipush #113
      //   443: if_icmpeq -> 1320
      //   446: iload #17
      //   448: bipush #118
      //   450: if_icmpeq -> 1295
      //   453: iload #17
      //   455: bipush #76
      //   457: if_icmpeq -> 1250
      //   460: iload #17
      //   462: bipush #77
      //   464: if_icmpeq -> 1180
      //   467: iload #17
      //   469: bipush #83
      //   471: if_icmpeq -> 1035
      //   474: iload #17
      //   476: bipush #84
      //   478: if_icmpeq -> 924
      //   481: iload #17
      //   483: bipush #108
      //   485: if_icmpeq -> 869
      //   488: iload #17
      //   490: bipush #109
      //   492: if_icmpeq -> 801
      //   495: iload #17
      //   497: bipush #115
      //   499: if_icmpeq -> 643
      //   502: iload #17
      //   504: bipush #116
      //   506: if_icmpeq -> 512
      //   509: goto -> 2136
      //   512: iload #16
      //   514: bipush #113
      //   516: if_icmpeq -> 552
      //   519: iload #16
      //   521: bipush #116
      //   523: if_icmpeq -> 552
      //   526: iload #16
      //   528: bipush #81
      //   530: if_icmpeq -> 552
      //   533: iload #16
      //   535: bipush #84
      //   537: if_icmpne -> 543
      //   540: goto -> 552
      //   543: fconst_0
      //   544: fstore #8
      //   546: fconst_0
      //   547: fstore #7
      //   549: goto -> 566
      //   552: fload #5
      //   554: fload #7
      //   556: fsub
      //   557: fstore #7
      //   559: fload #6
      //   561: fload #8
      //   563: fsub
      //   564: fstore #8
      //   566: iload_2
      //   567: iconst_0
      //   568: iadd
      //   569: istore #16
      //   571: aload #4
      //   573: iload #16
      //   575: faload
      //   576: fstore #9
      //   578: iload_2
      //   579: iconst_1
      //   580: iadd
      //   581: istore #17
      //   583: aload_0
      //   584: fload #7
      //   586: fload #8
      //   588: fload #9
      //   590: aload #4
      //   592: iload #17
      //   594: faload
      //   595: invokevirtual rQuadTo : (FFFF)V
      //   598: fload #5
      //   600: aload #4
      //   602: iload #16
      //   604: faload
      //   605: fadd
      //   606: fstore #9
      //   608: fload #6
      //   610: aload #4
      //   612: iload #17
      //   614: faload
      //   615: fadd
      //   616: fstore #10
      //   618: fload #8
      //   620: fload #6
      //   622: fadd
      //   623: fstore #8
      //   625: fload #7
      //   627: fload #5
      //   629: fadd
      //   630: fstore #7
      //   632: fload #10
      //   634: fstore #6
      //   636: fload #9
      //   638: fstore #5
      //   640: goto -> 509
      //   643: iload #16
      //   645: bipush #99
      //   647: if_icmpeq -> 683
      //   650: iload #16
      //   652: bipush #115
      //   654: if_icmpeq -> 683
      //   657: iload #16
      //   659: bipush #67
      //   661: if_icmpeq -> 683
      //   664: iload #16
      //   666: bipush #83
      //   668: if_icmpne -> 674
      //   671: goto -> 683
      //   674: fconst_0
      //   675: fstore #7
      //   677: fconst_0
      //   678: fstore #8
      //   680: goto -> 697
      //   683: fload #6
      //   685: fload #8
      //   687: fsub
      //   688: fstore #8
      //   690: fload #5
      //   692: fload #7
      //   694: fsub
      //   695: fstore #7
      //   697: iload_2
      //   698: iconst_0
      //   699: iadd
      //   700: istore #16
      //   702: aload #4
      //   704: iload #16
      //   706: faload
      //   707: fstore #9
      //   709: iload_2
      //   710: iconst_1
      //   711: iadd
      //   712: istore #17
      //   714: aload #4
      //   716: iload #17
      //   718: faload
      //   719: fstore #10
      //   721: iload_2
      //   722: iconst_2
      //   723: iadd
      //   724: istore #18
      //   726: aload #4
      //   728: iload #18
      //   730: faload
      //   731: fstore #13
      //   733: iload_2
      //   734: iconst_3
      //   735: iadd
      //   736: istore #19
      //   738: aload_0
      //   739: fload #7
      //   741: fload #8
      //   743: fload #9
      //   745: fload #10
      //   747: fload #13
      //   749: aload #4
      //   751: iload #19
      //   753: faload
      //   754: invokevirtual rCubicTo : (FFFFFF)V
      //   757: aload #4
      //   759: iload #16
      //   761: faload
      //   762: fload #5
      //   764: fadd
      //   765: fstore #10
      //   767: aload #4
      //   769: iload #17
      //   771: faload
      //   772: fload #6
      //   774: fadd
      //   775: fstore #7
      //   777: fload #5
      //   779: aload #4
      //   781: iload #18
      //   783: faload
      //   784: fadd
      //   785: fstore #8
      //   787: aload #4
      //   789: iload #19
      //   791: faload
      //   792: fstore #9
      //   794: fload #10
      //   796: fstore #5
      //   798: goto -> 1565
      //   801: iload_2
      //   802: iconst_0
      //   803: iadd
      //   804: istore #16
      //   806: fload #5
      //   808: aload #4
      //   810: iload #16
      //   812: faload
      //   813: fadd
      //   814: fstore #5
      //   816: iload_2
      //   817: iconst_1
      //   818: iadd
      //   819: istore #17
      //   821: fload #6
      //   823: aload #4
      //   825: iload #17
      //   827: faload
      //   828: fadd
      //   829: fstore #6
      //   831: iload_2
      //   832: ifle -> 852
      //   835: aload_0
      //   836: aload #4
      //   838: iload #16
      //   840: faload
      //   841: aload #4
      //   843: iload #17
      //   845: faload
      //   846: invokevirtual rLineTo : (FF)V
      //   849: goto -> 509
      //   852: aload_0
      //   853: aload #4
      //   855: iload #16
      //   857: faload
      //   858: aload #4
      //   860: iload #17
      //   862: faload
      //   863: invokevirtual rMoveTo : (FF)V
      //   866: goto -> 1239
      //   869: iload_2
      //   870: iconst_0
      //   871: iadd
      //   872: istore #16
      //   874: aload #4
      //   876: iload #16
      //   878: faload
      //   879: fstore #9
      //   881: iload_2
      //   882: iconst_1
      //   883: iadd
      //   884: istore #17
      //   886: aload_0
      //   887: fload #9
      //   889: aload #4
      //   891: iload #17
      //   893: faload
      //   894: invokevirtual rLineTo : (FF)V
      //   897: fload #5
      //   899: aload #4
      //   901: iload #16
      //   903: faload
      //   904: fadd
      //   905: fstore #5
      //   907: aload #4
      //   909: iload #17
      //   911: faload
      //   912: fstore #9
      //   914: fload #6
      //   916: fload #9
      //   918: fadd
      //   919: fstore #6
      //   921: goto -> 509
      //   924: iload #16
      //   926: bipush #113
      //   928: if_icmpeq -> 960
      //   931: iload #16
      //   933: bipush #116
      //   935: if_icmpeq -> 960
      //   938: iload #16
      //   940: bipush #81
      //   942: if_icmpeq -> 960
      //   945: fload #6
      //   947: fstore #10
      //   949: fload #5
      //   951: fstore #9
      //   953: iload #16
      //   955: bipush #84
      //   957: if_icmpne -> 978
      //   960: fload #5
      //   962: fconst_2
      //   963: fmul
      //   964: fload #7
      //   966: fsub
      //   967: fstore #9
      //   969: fload #6
      //   971: fconst_2
      //   972: fmul
      //   973: fload #8
      //   975: fsub
      //   976: fstore #10
      //   978: iload_2
      //   979: iconst_0
      //   980: iadd
      //   981: istore #16
      //   983: aload #4
      //   985: iload #16
      //   987: faload
      //   988: fstore #5
      //   990: iload_2
      //   991: iconst_1
      //   992: iadd
      //   993: istore #17
      //   995: aload_0
      //   996: fload #9
      //   998: fload #10
      //   1000: fload #5
      //   1002: aload #4
      //   1004: iload #17
      //   1006: faload
      //   1007: invokevirtual quadTo : (FFFF)V
      //   1010: aload #4
      //   1012: iload #16
      //   1014: faload
      //   1015: fstore #5
      //   1017: aload #4
      //   1019: iload #17
      //   1021: faload
      //   1022: fstore #6
      //   1024: fload #10
      //   1026: fstore #8
      //   1028: fload #9
      //   1030: fstore #7
      //   1032: goto -> 2136
      //   1035: iload #16
      //   1037: bipush #99
      //   1039: if_icmpeq -> 1071
      //   1042: iload #16
      //   1044: bipush #115
      //   1046: if_icmpeq -> 1071
      //   1049: iload #16
      //   1051: bipush #67
      //   1053: if_icmpeq -> 1071
      //   1056: fload #6
      //   1058: fstore #10
      //   1060: fload #5
      //   1062: fstore #9
      //   1064: iload #16
      //   1066: bipush #83
      //   1068: if_icmpne -> 1089
      //   1071: fload #5
      //   1073: fconst_2
      //   1074: fmul
      //   1075: fload #7
      //   1077: fsub
      //   1078: fstore #9
      //   1080: fload #6
      //   1082: fconst_2
      //   1083: fmul
      //   1084: fload #8
      //   1086: fsub
      //   1087: fstore #10
      //   1089: iload_2
      //   1090: iconst_0
      //   1091: iadd
      //   1092: istore #16
      //   1094: aload #4
      //   1096: iload #16
      //   1098: faload
      //   1099: fstore #5
      //   1101: iload_2
      //   1102: iconst_1
      //   1103: iadd
      //   1104: istore #17
      //   1106: aload #4
      //   1108: iload #17
      //   1110: faload
      //   1111: fstore #6
      //   1113: iload_2
      //   1114: iconst_2
      //   1115: iadd
      //   1116: istore #18
      //   1118: aload #4
      //   1120: iload #18
      //   1122: faload
      //   1123: fstore #7
      //   1125: iload_2
      //   1126: iconst_3
      //   1127: iadd
      //   1128: istore #19
      //   1130: aload_0
      //   1131: fload #9
      //   1133: fload #10
      //   1135: fload #5
      //   1137: fload #6
      //   1139: fload #7
      //   1141: aload #4
      //   1143: iload #19
      //   1145: faload
      //   1146: invokevirtual cubicTo : (FFFFFF)V
      //   1149: aload #4
      //   1151: iload #16
      //   1153: faload
      //   1154: fstore #5
      //   1156: aload #4
      //   1158: iload #17
      //   1160: faload
      //   1161: fstore #7
      //   1163: aload #4
      //   1165: iload #18
      //   1167: faload
      //   1168: fstore #9
      //   1170: aload #4
      //   1172: iload #19
      //   1174: faload
      //   1175: fstore #6
      //   1177: goto -> 1576
      //   1180: iload_2
      //   1181: iconst_0
      //   1182: iadd
      //   1183: istore #16
      //   1185: aload #4
      //   1187: iload #16
      //   1189: faload
      //   1190: fstore #5
      //   1192: iload_2
      //   1193: iconst_1
      //   1194: iadd
      //   1195: istore #17
      //   1197: aload #4
      //   1199: iload #17
      //   1201: faload
      //   1202: fstore #6
      //   1204: iload_2
      //   1205: ifle -> 1225
      //   1208: aload_0
      //   1209: aload #4
      //   1211: iload #16
      //   1213: faload
      //   1214: aload #4
      //   1216: iload #17
      //   1218: faload
      //   1219: invokevirtual lineTo : (FF)V
      //   1222: goto -> 509
      //   1225: aload_0
      //   1226: aload #4
      //   1228: iload #16
      //   1230: faload
      //   1231: aload #4
      //   1233: iload #17
      //   1235: faload
      //   1236: invokevirtual moveTo : (FF)V
      //   1239: fload #6
      //   1241: fstore #11
      //   1243: fload #5
      //   1245: fstore #12
      //   1247: goto -> 2136
      //   1250: iload_2
      //   1251: iconst_0
      //   1252: iadd
      //   1253: istore #16
      //   1255: aload #4
      //   1257: iload #16
      //   1259: faload
      //   1260: fstore #5
      //   1262: iload_2
      //   1263: iconst_1
      //   1264: iadd
      //   1265: istore #17
      //   1267: aload_0
      //   1268: fload #5
      //   1270: aload #4
      //   1272: iload #17
      //   1274: faload
      //   1275: invokevirtual lineTo : (FF)V
      //   1278: aload #4
      //   1280: iload #16
      //   1282: faload
      //   1283: fstore #5
      //   1285: aload #4
      //   1287: iload #17
      //   1289: faload
      //   1290: fstore #6
      //   1292: goto -> 509
      //   1295: iload_2
      //   1296: iconst_0
      //   1297: iadd
      //   1298: istore #16
      //   1300: aload_0
      //   1301: fconst_0
      //   1302: aload #4
      //   1304: iload #16
      //   1306: faload
      //   1307: invokevirtual rLineTo : (FF)V
      //   1310: aload #4
      //   1312: iload #16
      //   1314: faload
      //   1315: fstore #9
      //   1317: goto -> 914
      //   1320: iload_2
      //   1321: iconst_0
      //   1322: iadd
      //   1323: istore #16
      //   1325: aload #4
      //   1327: iload #16
      //   1329: faload
      //   1330: fstore #7
      //   1332: iload_2
      //   1333: iconst_1
      //   1334: iadd
      //   1335: istore #17
      //   1337: aload #4
      //   1339: iload #17
      //   1341: faload
      //   1342: fstore #8
      //   1344: iload_2
      //   1345: iconst_2
      //   1346: iadd
      //   1347: istore #18
      //   1349: aload #4
      //   1351: iload #18
      //   1353: faload
      //   1354: fstore #9
      //   1356: iload_2
      //   1357: iconst_3
      //   1358: iadd
      //   1359: istore #19
      //   1361: aload_0
      //   1362: fload #7
      //   1364: fload #8
      //   1366: fload #9
      //   1368: aload #4
      //   1370: iload #19
      //   1372: faload
      //   1373: invokevirtual rQuadTo : (FFFF)V
      //   1376: aload #4
      //   1378: iload #16
      //   1380: faload
      //   1381: fload #5
      //   1383: fadd
      //   1384: fstore #10
      //   1386: aload #4
      //   1388: iload #17
      //   1390: faload
      //   1391: fload #6
      //   1393: fadd
      //   1394: fstore #7
      //   1396: fload #5
      //   1398: aload #4
      //   1400: iload #18
      //   1402: faload
      //   1403: fadd
      //   1404: fstore #8
      //   1406: aload #4
      //   1408: iload #19
      //   1410: faload
      //   1411: fstore #9
      //   1413: fload #10
      //   1415: fstore #5
      //   1417: goto -> 1565
      //   1420: iload_2
      //   1421: iconst_0
      //   1422: iadd
      //   1423: istore #16
      //   1425: aload_0
      //   1426: aload #4
      //   1428: iload #16
      //   1430: faload
      //   1431: fconst_0
      //   1432: invokevirtual rLineTo : (FF)V
      //   1435: fload #5
      //   1437: aload #4
      //   1439: iload #16
      //   1441: faload
      //   1442: fadd
      //   1443: fstore #5
      //   1445: goto -> 509
      //   1448: aload #4
      //   1450: iload_2
      //   1451: iconst_0
      //   1452: iadd
      //   1453: faload
      //   1454: fstore #7
      //   1456: aload #4
      //   1458: iload_2
      //   1459: iconst_1
      //   1460: iadd
      //   1461: faload
      //   1462: fstore #8
      //   1464: iload_2
      //   1465: iconst_2
      //   1466: iadd
      //   1467: istore #16
      //   1469: aload #4
      //   1471: iload #16
      //   1473: faload
      //   1474: fstore #9
      //   1476: iload_2
      //   1477: iconst_3
      //   1478: iadd
      //   1479: istore #17
      //   1481: aload #4
      //   1483: iload #17
      //   1485: faload
      //   1486: fstore #10
      //   1488: iload_2
      //   1489: iconst_4
      //   1490: iadd
      //   1491: istore #18
      //   1493: aload #4
      //   1495: iload #18
      //   1497: faload
      //   1498: fstore #13
      //   1500: iload_2
      //   1501: iconst_5
      //   1502: iadd
      //   1503: istore #19
      //   1505: aload_0
      //   1506: fload #7
      //   1508: fload #8
      //   1510: fload #9
      //   1512: fload #10
      //   1514: fload #13
      //   1516: aload #4
      //   1518: iload #19
      //   1520: faload
      //   1521: invokevirtual rCubicTo : (FFFFFF)V
      //   1524: aload #4
      //   1526: iload #16
      //   1528: faload
      //   1529: fload #5
      //   1531: fadd
      //   1532: fstore #10
      //   1534: aload #4
      //   1536: iload #17
      //   1538: faload
      //   1539: fload #6
      //   1541: fadd
      //   1542: fstore #7
      //   1544: fload #5
      //   1546: aload #4
      //   1548: iload #18
      //   1550: faload
      //   1551: fadd
      //   1552: fstore #8
      //   1554: aload #4
      //   1556: iload #19
      //   1558: faload
      //   1559: fstore #9
      //   1561: fload #10
      //   1563: fstore #5
      //   1565: fload #6
      //   1567: fload #9
      //   1569: fadd
      //   1570: fstore #6
      //   1572: fload #8
      //   1574: fstore #9
      //   1576: fload #7
      //   1578: fstore #8
      //   1580: fload #5
      //   1582: fstore #7
      //   1584: fload #9
      //   1586: fstore #5
      //   1588: goto -> 509
      //   1591: iload_2
      //   1592: iconst_5
      //   1593: iadd
      //   1594: istore #16
      //   1596: aload #4
      //   1598: iload #16
      //   1600: faload
      //   1601: fstore #7
      //   1603: iload_2
      //   1604: bipush #6
      //   1606: iadd
      //   1607: istore #17
      //   1609: aload #4
      //   1611: iload #17
      //   1613: faload
      //   1614: fstore #8
      //   1616: aload #4
      //   1618: iload_2
      //   1619: iconst_0
      //   1620: iadd
      //   1621: faload
      //   1622: fstore #9
      //   1624: aload #4
      //   1626: iload_2
      //   1627: iconst_1
      //   1628: iadd
      //   1629: faload
      //   1630: fstore #10
      //   1632: aload #4
      //   1634: iload_2
      //   1635: iconst_2
      //   1636: iadd
      //   1637: faload
      //   1638: fstore #13
      //   1640: aload #4
      //   1642: iload_2
      //   1643: iconst_3
      //   1644: iadd
      //   1645: faload
      //   1646: fconst_0
      //   1647: fcmpl
      //   1648: ifeq -> 1657
      //   1651: iconst_1
      //   1652: istore #20
      //   1654: goto -> 1660
      //   1657: iconst_0
      //   1658: istore #20
      //   1660: aload #4
      //   1662: iload_2
      //   1663: iconst_4
      //   1664: iadd
      //   1665: faload
      //   1666: fconst_0
      //   1667: fcmpl
      //   1668: ifeq -> 1677
      //   1671: iconst_1
      //   1672: istore #21
      //   1674: goto -> 1680
      //   1677: iconst_0
      //   1678: istore #21
      //   1680: aload_0
      //   1681: fload #5
      //   1683: fload #6
      //   1685: fload #7
      //   1687: fload #5
      //   1689: fadd
      //   1690: fload #8
      //   1692: fload #6
      //   1694: fadd
      //   1695: fload #9
      //   1697: fload #10
      //   1699: fload #13
      //   1701: iload #20
      //   1703: iload #21
      //   1705: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   1708: fload #5
      //   1710: aload #4
      //   1712: iload #16
      //   1714: faload
      //   1715: fadd
      //   1716: fstore #5
      //   1718: fload #6
      //   1720: aload #4
      //   1722: iload #17
      //   1724: faload
      //   1725: fadd
      //   1726: fstore #6
      //   1728: goto -> 2128
      //   1731: iload_2
      //   1732: iconst_0
      //   1733: iadd
      //   1734: istore #16
      //   1736: aload_0
      //   1737: fload #5
      //   1739: aload #4
      //   1741: iload #16
      //   1743: faload
      //   1744: invokevirtual lineTo : (FF)V
      //   1747: aload #4
      //   1749: iload #16
      //   1751: faload
      //   1752: fstore #6
      //   1754: goto -> 2136
      //   1757: iload_2
      //   1758: istore #16
      //   1760: iload #16
      //   1762: iconst_0
      //   1763: iadd
      //   1764: istore #17
      //   1766: aload #4
      //   1768: iload #17
      //   1770: faload
      //   1771: fstore #5
      //   1773: iload #16
      //   1775: iconst_1
      //   1776: iadd
      //   1777: istore #18
      //   1779: aload #4
      //   1781: iload #18
      //   1783: faload
      //   1784: fstore #6
      //   1786: iload #16
      //   1788: iconst_2
      //   1789: iadd
      //   1790: istore #19
      //   1792: aload #4
      //   1794: iload #19
      //   1796: faload
      //   1797: fstore #7
      //   1799: iload #16
      //   1801: iconst_3
      //   1802: iadd
      //   1803: istore #16
      //   1805: aload_0
      //   1806: fload #5
      //   1808: fload #6
      //   1810: fload #7
      //   1812: aload #4
      //   1814: iload #16
      //   1816: faload
      //   1817: invokevirtual quadTo : (FFFF)V
      //   1820: aload #4
      //   1822: iload #17
      //   1824: faload
      //   1825: fstore #7
      //   1827: aload #4
      //   1829: iload #18
      //   1831: faload
      //   1832: fstore #8
      //   1834: aload #4
      //   1836: iload #19
      //   1838: faload
      //   1839: fstore #5
      //   1841: aload #4
      //   1843: iload #16
      //   1845: faload
      //   1846: fstore #6
      //   1848: goto -> 2136
      //   1851: iload_2
      //   1852: iconst_0
      //   1853: iadd
      //   1854: istore #16
      //   1856: aload_0
      //   1857: aload #4
      //   1859: iload #16
      //   1861: faload
      //   1862: fload #6
      //   1864: invokevirtual lineTo : (FF)V
      //   1867: aload #4
      //   1869: iload #16
      //   1871: faload
      //   1872: fstore #5
      //   1874: goto -> 2136
      //   1877: iload_2
      //   1878: istore #16
      //   1880: aload #4
      //   1882: iload #16
      //   1884: iconst_0
      //   1885: iadd
      //   1886: faload
      //   1887: fstore #5
      //   1889: aload #4
      //   1891: iload #16
      //   1893: iconst_1
      //   1894: iadd
      //   1895: faload
      //   1896: fstore #6
      //   1898: iload #16
      //   1900: iconst_2
      //   1901: iadd
      //   1902: istore #17
      //   1904: aload #4
      //   1906: iload #17
      //   1908: faload
      //   1909: fstore #7
      //   1911: iload #16
      //   1913: iconst_3
      //   1914: iadd
      //   1915: istore #18
      //   1917: aload #4
      //   1919: iload #18
      //   1921: faload
      //   1922: fstore #8
      //   1924: iload #16
      //   1926: iconst_4
      //   1927: iadd
      //   1928: istore #19
      //   1930: aload #4
      //   1932: iload #19
      //   1934: faload
      //   1935: fstore #9
      //   1937: iload #16
      //   1939: iconst_5
      //   1940: iadd
      //   1941: istore #16
      //   1943: aload_0
      //   1944: fload #5
      //   1946: fload #6
      //   1948: fload #7
      //   1950: fload #8
      //   1952: fload #9
      //   1954: aload #4
      //   1956: iload #16
      //   1958: faload
      //   1959: invokevirtual cubicTo : (FFFFFF)V
      //   1962: aload #4
      //   1964: iload #19
      //   1966: faload
      //   1967: fstore #5
      //   1969: aload #4
      //   1971: iload #16
      //   1973: faload
      //   1974: fstore #6
      //   1976: aload #4
      //   1978: iload #17
      //   1980: faload
      //   1981: fstore #7
      //   1983: aload #4
      //   1985: iload #18
      //   1987: faload
      //   1988: fstore #8
      //   1990: goto -> 2136
      //   1993: iload_2
      //   1994: istore #16
      //   1996: iload #16
      //   1998: iconst_5
      //   1999: iadd
      //   2000: istore #17
      //   2002: aload #4
      //   2004: iload #17
      //   2006: faload
      //   2007: fstore #7
      //   2009: iload #16
      //   2011: bipush #6
      //   2013: iadd
      //   2014: istore #18
      //   2016: aload #4
      //   2018: iload #18
      //   2020: faload
      //   2021: fstore #8
      //   2023: aload #4
      //   2025: iload #16
      //   2027: iconst_0
      //   2028: iadd
      //   2029: faload
      //   2030: fstore #9
      //   2032: aload #4
      //   2034: iload #16
      //   2036: iconst_1
      //   2037: iadd
      //   2038: faload
      //   2039: fstore #10
      //   2041: aload #4
      //   2043: iload #16
      //   2045: iconst_2
      //   2046: iadd
      //   2047: faload
      //   2048: fstore #13
      //   2050: aload #4
      //   2052: iload #16
      //   2054: iconst_3
      //   2055: iadd
      //   2056: faload
      //   2057: fconst_0
      //   2058: fcmpl
      //   2059: ifeq -> 2068
      //   2062: iconst_1
      //   2063: istore #20
      //   2065: goto -> 2071
      //   2068: iconst_0
      //   2069: istore #20
      //   2071: aload #4
      //   2073: iload #16
      //   2075: iconst_4
      //   2076: iadd
      //   2077: faload
      //   2078: fconst_0
      //   2079: fcmpl
      //   2080: ifeq -> 2089
      //   2083: iconst_1
      //   2084: istore #21
      //   2086: goto -> 2092
      //   2089: iconst_0
      //   2090: istore #21
      //   2092: aload_0
      //   2093: fload #5
      //   2095: fload #6
      //   2097: fload #7
      //   2099: fload #8
      //   2101: fload #9
      //   2103: fload #10
      //   2105: fload #13
      //   2107: iload #20
      //   2109: iload #21
      //   2111: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   2114: aload #4
      //   2116: iload #17
      //   2118: faload
      //   2119: fstore #5
      //   2121: aload #4
      //   2123: iload #18
      //   2125: faload
      //   2126: fstore #6
      //   2128: fload #6
      //   2130: fstore #8
      //   2132: fload #5
      //   2134: fstore #7
      //   2136: iload_2
      //   2137: iload #15
      //   2139: iadd
      //   2140: istore_2
      //   2141: iload_3
      //   2142: istore #16
      //   2144: goto -> 373
      //   2147: aload_1
      //   2148: iconst_0
      //   2149: fload #5
      //   2151: fastore
      //   2152: aload_1
      //   2153: iconst_1
      //   2154: fload #6
      //   2156: fastore
      //   2157: aload_1
      //   2158: iconst_2
      //   2159: fload #7
      //   2161: fastore
      //   2162: aload_1
      //   2163: iconst_3
      //   2164: fload #8
      //   2166: fastore
      //   2167: aload_1
      //   2168: iconst_4
      //   2169: fload #12
      //   2171: fastore
      //   2172: aload_1
      //   2173: iconst_5
      //   2174: fload #11
      //   2176: fastore
      //   2177: return
    }
    
    private static void arcToBezier(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d4 = Math.cos(param1Double7);
      double d5 = Math.sin(param1Double7);
      double d2 = Math.cos(param1Double8);
      double d3 = Math.sin(param1Double8);
      param1Double7 = -param1Double3;
      double d7 = param1Double7 * d4;
      double d8 = param1Double4 * d5;
      param1Double7 *= d5;
      double d9 = param1Double4 * d4;
      double d6 = param1Double9 / i;
      double d1 = d3 * param1Double7 + d2 * d9;
      d2 = d7 * d3 - d8 * d2;
      int j = 0;
      d3 = param1Double8;
      param1Double9 = param1Double6;
      param1Double4 = param1Double7;
      param1Double8 = param1Double5;
      param1Double7 = d6;
      param1Double6 = d5;
      param1Double5 = d4;
      while (true) {
        d4 = param1Double3;
        if (j < i) {
          d6 = d3 + param1Double7;
          double d10 = Math.sin(d6);
          double d12 = Math.cos(d6);
          double d11 = param1Double1 + d4 * param1Double5 * d12 - d8 * d10;
          d4 = param1Double2 + d4 * param1Double6 * d12 + d9 * d10;
          d5 = d7 * d10 - d8 * d12;
          d10 = d10 * param1Double4 + d12 * d9;
          d3 = d6 - d3;
          d12 = Math.tan(d3 / 2.0D);
          d3 = Math.sin(d3) * (Math.sqrt(d12 * 3.0D * d12 + 4.0D) - 1.0D) / 3.0D;
          param1Path.rLineTo(0.0F, 0.0F);
          param1Path.cubicTo((float)(param1Double8 + d2 * d3), (float)(param1Double9 + d1 * d3), (float)(d11 - d3 * d5), (float)(d4 - d3 * d10), (float)d11, (float)d4);
          j++;
          param1Double8 = d11;
          d3 = d6;
          d1 = d10;
          d2 = d5;
          param1Double9 = d4;
          continue;
        } 
        break;
      } 
    }
    
    private static void drawArc(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d5 = Math.toRadians(param1Float7);
      double d6 = Math.cos(d5);
      double d7 = Math.sin(d5);
      double d8 = param1Float1;
      double d9 = param1Float2;
      double d10 = param1Float5;
      double d1 = (d8 * d6 + d9 * d7) / d10;
      double d2 = -param1Float1;
      double d11 = param1Float6;
      double d4 = (d2 * d7 + d9 * d6) / d11;
      double d3 = param1Float3;
      d2 = param1Float4;
      double d12 = (d3 * d6 + d2 * d7) / d10;
      double d13 = (-param1Float3 * d7 + d2 * d6) / d11;
      double d15 = d1 - d12;
      double d14 = d4 - d13;
      d3 = (d1 + d12) / 2.0D;
      d2 = (d4 + d13) / 2.0D;
      double d16 = d15 * d15 + d14 * d14;
      if (d16 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d17 = 1.0D / d16 - 0.25D;
      if (d17 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Points are too far apart ");
        stringBuilder.append(d16);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d16) / 1.99999D);
        drawArc(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      d16 = Math.sqrt(d17);
      d15 *= d16;
      d14 = d16 * d14;
      if (param1Boolean1 == param1Boolean2) {
        d3 -= d14;
        d2 += d15;
      } else {
        d3 += d14;
        d2 -= d15;
      } 
      d14 = Math.atan2(d4 - d2, d1 - d3);
      d4 = Math.atan2(d13 - d2, d12 - d3) - d14;
      int i = d4 cmp 0.0D;
      if (i >= 0) {
        param1Boolean1 = true;
      } else {
        param1Boolean1 = false;
      } 
      d1 = d4;
      if (param1Boolean2 != param1Boolean1)
        if (i > 0) {
          d1 = d4 - 6.283185307179586D;
        } else {
          d1 = d4 + 6.283185307179586D;
        }  
      d3 *= d10;
      d2 *= d11;
      arcToBezier(param1Path, d3 * d6 - d2 * d7, d3 * d7 + d2 * d6, d10, d11, d8, d9, d5, d14, d1);
    }
    
    public static void nodesToPath(PathDataNode[] param1ArrayOfPathDataNode, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c = 'm';
      for (int i = 0; i < param1ArrayOfPathDataNode.length; i++) {
        addCommand(param1Path, arrayOfFloat, c, (param1ArrayOfPathDataNode[i]).mType, (param1ArrayOfPathDataNode[i]).mParams);
        c = (param1ArrayOfPathDataNode[i]).mType;
      } 
    }
    
    public void interpolatePathDataNode(PathDataNode param1PathDataNode1, PathDataNode param1PathDataNode2, float param1Float) {
      this.mType = param1PathDataNode1.mType;
      int i = 0;
      while (true) {
        float[] arrayOfFloat = param1PathDataNode1.mParams;
        if (i < arrayOfFloat.length) {
          this.mParams[i] = arrayOfFloat[i] * (1.0F - param1Float) + param1PathDataNode2.mParams[i] * param1Float;
          i++;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\PathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */