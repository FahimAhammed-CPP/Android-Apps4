package androidx.core.graphics;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;
import android.util.SparseArray;
import androidx.collection.LongSparseArray;
import androidx.core.content.res.FontResourcesParserCompat;
import java.lang.reflect.Field;

final class WeightTypefaceApi14 {
  private static final String NATIVE_INSTANCE_FIELD = "native_instance";
  
  private static final String TAG = "WeightTypeface";
  
  private static final Field sNativeInstance;
  
  private static final Object sWeightCacheLock;
  
  private static final LongSparseArray<SparseArray<Typeface>> sWeightTypefaceCache = new LongSparseArray(3);
  
  static {
    sWeightCacheLock = new Object();
  }
  
  static Typeface createWeightStyle(TypefaceCompatBaseImpl paramTypefaceCompatBaseImpl, Context paramContext, Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    if (!isPrivateApiAvailable())
      return null; 
    int i = paramInt << 1 | paramBoolean;
    synchronized (sWeightCacheLock) {
      long l = getNativeInstance(paramTypeface);
      SparseArray sparseArray = (SparseArray)sWeightTypefaceCache.get(l);
      if (sparseArray == null) {
        sparseArray = new SparseArray(4);
        sWeightTypefaceCache.put(l, sparseArray);
      } else {
        Typeface typeface = (Typeface)sparseArray.get(i);
        if (typeface != null)
          return typeface; 
      } 
      Typeface typeface2 = getBestFontFromFamily(paramTypefaceCompatBaseImpl, paramContext, paramTypeface, paramInt, paramBoolean);
      Typeface typeface1 = typeface2;
      if (typeface2 == null)
        typeface1 = platformTypefaceCreate(paramTypeface, paramInt, paramBoolean); 
      sparseArray.put(i, typeface1);
      return typeface1;
    } 
  }
  
  private static Typeface getBestFontFromFamily(TypefaceCompatBaseImpl paramTypefaceCompatBaseImpl, Context paramContext, Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry = paramTypefaceCompatBaseImpl.getFontFamily(paramTypeface);
    return (fontFamilyFilesResourceEntry == null) ? null : paramTypefaceCompatBaseImpl.createFromFontFamilyFilesResourceEntry(paramContext, fontFamilyFilesResourceEntry, paramContext.getResources(), paramInt, paramBoolean);
  }
  
  private static long getNativeInstance(Typeface paramTypeface) {
    try {
      return ((Number)sNativeInstance.get(paramTypeface)).longValue();
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean isPrivateApiAvailable() {
    return (sNativeInstance != null);
  }
  
  private static Typeface platformTypefaceCreate(Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    boolean bool = true;
    if (paramInt >= 600) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt == 0 && !paramBoolean) {
      paramInt = 0;
    } else if (paramInt == 0) {
      paramInt = 2;
    } else if (!paramBoolean) {
      paramInt = bool;
    } else {
      paramInt = 3;
    } 
    return Typeface.create(paramTypeface, paramInt);
  }
  
  static {
    try {
      Field field = Typeface.class.getDeclaredField("native_instance");
      field.setAccessible(true);
    } catch (Exception exception) {
      Log.e("WeightTypeface", exception.getClass().getName(), exception);
      exception = null;
    } 
    sNativeInstance = (Field)exception;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\WeightTypefaceApi14.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */