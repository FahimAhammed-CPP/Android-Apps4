package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.provider.FontsContractCompat;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentHashMap;

class TypefaceCompatBaseImpl {
  private static final int INVALID_KEY = 0;
  
  private static final String TAG = "TypefaceCompatBaseImpl";
  
  private ConcurrentHashMap<Long, FontResourcesParserCompat.FontFamilyFilesResourceEntry> mFontFamilies = new ConcurrentHashMap<Long, FontResourcesParserCompat.FontFamilyFilesResourceEntry>();
  
  private void addFontFamily(Typeface paramTypeface, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry) {
    long l = getUniqueKey(paramTypeface);
    if (l != 0L)
      this.mFontFamilies.put(Long.valueOf(l), paramFontFamilyFilesResourceEntry); 
  }
  
  private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, int paramInt) {
    return findBestFont(paramFontFamilyFilesResourceEntry.getEntries(), paramInt, new StyleExtractor<FontResourcesParserCompat.FontFileResourceEntry>() {
          public int getWeight(FontResourcesParserCompat.FontFileResourceEntry param1FontFileResourceEntry) {
            return param1FontFileResourceEntry.getWeight();
          }
          
          public boolean isItalic(FontResourcesParserCompat.FontFileResourceEntry param1FontFileResourceEntry) {
            return param1FontFileResourceEntry.isItalic();
          }
        });
  }
  
  private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, int paramInt, boolean paramBoolean) {
    return findBestFont(paramFontFamilyFilesResourceEntry.getEntries(), paramInt, paramBoolean, new StyleExtractor<FontResourcesParserCompat.FontFileResourceEntry>() {
          public int getWeight(FontResourcesParserCompat.FontFileResourceEntry param1FontFileResourceEntry) {
            return param1FontFileResourceEntry.getWeight();
          }
          
          public boolean isItalic(FontResourcesParserCompat.FontFileResourceEntry param1FontFileResourceEntry) {
            return param1FontFileResourceEntry.isItalic();
          }
        });
  }
  
  private static <T> T findBestFont(T[] paramArrayOfT, int paramInt, StyleExtractor<T> paramStyleExtractor) {
    char c;
    boolean bool;
    if ((paramInt & 0x1) == 0) {
      c = 'Ɛ';
    } else {
      c = 'ʼ';
    } 
    if ((paramInt & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return findBestFont(paramArrayOfT, c, bool, paramStyleExtractor);
  }
  
  private static <T> T findBestFont(T[] paramArrayOfT, int paramInt, boolean paramBoolean, StyleExtractor<T> paramStyleExtractor) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: istore #8
    //   4: aconst_null
    //   5: astore #9
    //   7: ldc 2147483647
    //   9: istore #5
    //   11: iconst_0
    //   12: istore #4
    //   14: iload #4
    //   16: iload #8
    //   18: if_icmpge -> 109
    //   21: aload_0
    //   22: iload #4
    //   24: aaload
    //   25: astore #10
    //   27: aload_3
    //   28: aload #10
    //   30: invokeinterface getWeight : (Ljava/lang/Object;)I
    //   35: iload_1
    //   36: isub
    //   37: invokestatic abs : (I)I
    //   40: istore #7
    //   42: aload_3
    //   43: aload #10
    //   45: invokeinterface isItalic : (Ljava/lang/Object;)Z
    //   50: iload_2
    //   51: if_icmpne -> 60
    //   54: iconst_0
    //   55: istore #6
    //   57: goto -> 63
    //   60: iconst_1
    //   61: istore #6
    //   63: iload #7
    //   65: iconst_2
    //   66: imul
    //   67: iload #6
    //   69: iadd
    //   70: istore #7
    //   72: aload #9
    //   74: ifnull -> 88
    //   77: iload #5
    //   79: istore #6
    //   81: iload #5
    //   83: iload #7
    //   85: if_icmple -> 96
    //   88: aload #10
    //   90: astore #9
    //   92: iload #7
    //   94: istore #6
    //   96: iload #4
    //   98: iconst_1
    //   99: iadd
    //   100: istore #4
    //   102: iload #6
    //   104: istore #5
    //   106: goto -> 14
    //   109: aload #9
    //   111: areturn
  }
  
  private static long getUniqueKey(Typeface paramTypeface) {
    if (paramTypeface == null)
      return 0L; 
    try {
      Field field = Typeface.class.getDeclaredField("native_instance");
      field.setAccessible(true);
      return ((Number)field.get(paramTypeface)).longValue();
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", noSuchFieldException);
      return 0L;
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", illegalAccessException);
      return 0L;
    } 
  }
  
  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt) {
    FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = findBestEntry(paramFontFamilyFilesResourceEntry, paramInt);
    if (fontFileResourceEntry == null)
      return null; 
    Typeface typeface = TypefaceCompat.createFromResourcesFontFile(paramContext, paramResources, fontFileResourceEntry.getResourceId(), fontFileResourceEntry.getFileName(), 0, paramInt);
    addFontFamily(typeface, paramFontFamilyFilesResourceEntry);
    return typeface;
  }
  
  Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt, boolean paramBoolean) {
    FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = findBestEntry(paramFontFamilyFilesResourceEntry, paramInt, paramBoolean);
    if (fontFileResourceEntry == null)
      return null; 
    Typeface typeface = TypefaceCompat.createFromResourcesFontFile(paramContext, paramResources, fontFileResourceEntry.getResourceId(), fontFileResourceEntry.getFileName(), 0, 0);
    addFontFamily(typeface, paramFontFamilyFilesResourceEntry);
    return typeface;
  }
  
  public Typeface createFromFontInfo(Context paramContext, CancellationSignal paramCancellationSignal, FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    int i = paramArrayOfFontInfo.length;
    Context context = null;
    if (i < 1)
      return null; 
    null = findBestInfo(paramArrayOfFontInfo, paramInt);
    try {
      InputStream inputStream1;
      FontsContractCompat.FontInfo[] arrayOfFontInfo;
      InputStream inputStream2 = paramContext.getContentResolver().openInputStream(null.getUri());
      try {
        return typeface;
      } catch (IOException iOException) {
      
      } finally {
        paramArrayOfFontInfo = null;
        inputStream1 = inputStream2;
      } 
      TypefaceCompatUtil.closeQuietly(inputStream1);
      throw arrayOfFontInfo;
    } catch (IOException iOException) {
    
    } finally {
      paramContext = context;
      TypefaceCompatUtil.closeQuietly((Closeable)paramContext);
    } 
    TypefaceCompatUtil.closeQuietly((Closeable)paramCancellationSignal);
    return null;
  }
  
  protected Typeface createFromInputStream(Context paramContext, InputStream paramInputStream) {
    File file = TypefaceCompatUtil.getTempFile(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = TypefaceCompatUtil.copyToFile(file, paramInputStream);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    File file = TypefaceCompatUtil.getTempFile(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = TypefaceCompatUtil.copyToFile(file, paramResources, paramInt1);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  Typeface createWeightStyle(Context paramContext, Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    try {
      Typeface typeface = WeightTypefaceApi14.createWeightStyle(this, paramContext, paramTypeface, paramInt, paramBoolean);
    } catch (RuntimeException runtimeException) {
      runtimeException = null;
    } 
    return (Typeface)((runtimeException == null) ? paramTypeface : runtimeException);
  }
  
  protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    return findBestFont(paramArrayOfFontInfo, paramInt, new StyleExtractor<FontsContractCompat.FontInfo>() {
          public int getWeight(FontsContractCompat.FontInfo param1FontInfo) {
            return param1FontInfo.getWeight();
          }
          
          public boolean isItalic(FontsContractCompat.FontInfo param1FontInfo) {
            return param1FontInfo.isItalic();
          }
        });
  }
  
  FontResourcesParserCompat.FontFamilyFilesResourceEntry getFontFamily(Typeface paramTypeface) {
    long l = getUniqueKey(paramTypeface);
    return (l == 0L) ? null : this.mFontFamilies.get(Long.valueOf(l));
  }
  
  private static interface StyleExtractor<T> {
    int getWeight(T param1T);
    
    boolean isItalic(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\TypefaceCompatBaseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */