package androidx.core.graphics;

import android.graphics.Typeface;
import android.util.Log;
import android.util.SparseArray;
import androidx.collection.LongSparseArray;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

final class WeightTypefaceApi26 {
  private static final String NATIVE_CREATE_FROM_TYPEFACE_WITH_EXACT_STYLE_METHOD = "nativeCreateFromTypefaceWithExactStyle";
  
  private static final String NATIVE_INSTANCE_FIELD = "native_instance";
  
  private static final String TAG = "WeightTypeface";
  
  private static final Constructor<Typeface> sConstructor;
  
  private static final Method sNativeCreateFromTypefaceWithExactStyle;
  
  private static final Field sNativeInstance;
  
  private static final Object sWeightCacheLock;
  
  private static final LongSparseArray<SparseArray<Typeface>> sWeightTypefaceCache;
  
  static {
    Method method1;
    Method method2;
    NoSuchFieldException noSuchFieldException = null;
    try {
      Field field = Typeface.class.getDeclaredField("native_instance");
      method1 = Typeface.class.getDeclaredMethod("nativeCreateFromTypefaceWithExactStyle", new Class[] { long.class, int.class, boolean.class });
      method1.setAccessible(true);
      Constructor<Typeface> constructor = Typeface.class.getDeclaredConstructor(new Class[] { long.class });
      constructor.setAccessible(true);
    } catch (NoSuchFieldException noSuchFieldException1) {
      Log.e("WeightTypeface", noSuchFieldException1.getClass().getName(), noSuchFieldException1);
      method1 = null;
      method2 = method1;
      noSuchFieldException1 = noSuchFieldException;
    } catch (NoSuchMethodException noSuchMethodException) {}
    sNativeInstance = (Field)noSuchMethodException;
    sNativeCreateFromTypefaceWithExactStyle = method1;
    sConstructor = (Constructor<Typeface>)method2;
    sWeightTypefaceCache = new LongSparseArray(3);
    sWeightCacheLock = new Object();
  }
  
  private static Typeface create(long paramLong) {
    try {
      return sConstructor.newInstance(new Object[] { Long.valueOf(paramLong) });
    } catch (IllegalAccessException|InstantiationException|InvocationTargetException illegalAccessException) {
      return null;
    } 
  }
  
  static Typeface createWeightStyle(Typeface paramTypeface, int paramInt, boolean paramBoolean) {
    if (!isPrivateApiAvailable())
      return null; 
    int i = paramInt << 1 | paramBoolean;
    synchronized (sWeightCacheLock) {
      long l = getNativeInstance(paramTypeface);
      SparseArray sparseArray = (SparseArray)sWeightTypefaceCache.get(l);
      if (sparseArray == null) {
        sparseArray = new SparseArray(4);
        sWeightTypefaceCache.put(l, sparseArray);
      } else {
        Typeface typeface1 = (Typeface)sparseArray.get(i);
        if (typeface1 != null)
          return typeface1; 
      } 
      Typeface typeface = create(nativeCreateFromTypefaceWithExactStyle(l, paramInt, paramBoolean));
      sparseArray.put(i, typeface);
      return typeface;
    } 
  }
  
  private static long getNativeInstance(Typeface paramTypeface) {
    try {
      return sNativeInstance.getLong(paramTypeface);
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean isPrivateApiAvailable() {
    return (sNativeInstance != null);
  }
  
  private static long nativeCreateFromTypefaceWithExactStyle(long paramLong, int paramInt, boolean paramBoolean) {
    try {
      return ((Long)sNativeCreateFromTypefaceWithExactStyle.invoke(null, new Object[] { Long.valueOf(paramLong), Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).longValue();
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\graphics\WeightTypefaceApi26.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */