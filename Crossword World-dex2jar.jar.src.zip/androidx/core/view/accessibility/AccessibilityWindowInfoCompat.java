package androidx.core.view.accessibility;

import android.graphics.Rect;
import android.graphics.Region;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

public class AccessibilityWindowInfoCompat {
  public static final int TYPE_ACCESSIBILITY_OVERLAY = 4;
  
  public static final int TYPE_APPLICATION = 1;
  
  public static final int TYPE_INPUT_METHOD = 2;
  
  public static final int TYPE_SPLIT_SCREEN_DIVIDER = 5;
  
  public static final int TYPE_SYSTEM = 3;
  
  private static final int UNDEFINED = -1;
  
  private final Object mInfo;
  
  private AccessibilityWindowInfoCompat(Object paramObject) {
    this.mInfo = paramObject;
  }
  
  public static AccessibilityWindowInfoCompat obtain() {
    return (Build.VERSION.SDK_INT >= 21) ? wrapNonNullInstance(Api21Impl.obtain()) : null;
  }
  
  public static AccessibilityWindowInfoCompat obtain(AccessibilityWindowInfoCompat paramAccessibilityWindowInfoCompat) {
    int i = Build.VERSION.SDK_INT;
    AccessibilityWindowInfoCompat accessibilityWindowInfoCompat = null;
    if (i >= 21) {
      if (paramAccessibilityWindowInfoCompat == null)
        return null; 
      accessibilityWindowInfoCompat = wrapNonNullInstance(Api21Impl.obtain((AccessibilityWindowInfo)paramAccessibilityWindowInfoCompat.mInfo));
    } 
    return accessibilityWindowInfoCompat;
  }
  
  private static String typeToString(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? "<UNKNOWN>" : "TYPE_ACCESSIBILITY_OVERLAY") : "TYPE_SYSTEM") : "TYPE_INPUT_METHOD") : "TYPE_APPLICATION";
  }
  
  static AccessibilityWindowInfoCompat wrapNonNullInstance(Object paramObject) {
    return (paramObject != null) ? new AccessibilityWindowInfoCompat(paramObject) : null;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof AccessibilityWindowInfoCompat))
      return false; 
    paramObject = paramObject;
    Object object = this.mInfo;
    return (object == null) ? ((((AccessibilityWindowInfoCompat)paramObject).mInfo == null)) : object.equals(((AccessibilityWindowInfoCompat)paramObject).mInfo);
  }
  
  public AccessibilityNodeInfoCompat getAnchor() {
    return (Build.VERSION.SDK_INT >= 24) ? AccessibilityNodeInfoCompat.wrapNonNullInstance(Api24Impl.getAnchor((AccessibilityWindowInfo)this.mInfo)) : null;
  }
  
  public void getBoundsInScreen(Rect paramRect) {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.getBoundsInScreen((AccessibilityWindowInfo)this.mInfo, paramRect); 
  }
  
  public AccessibilityWindowInfoCompat getChild(int paramInt) {
    return (Build.VERSION.SDK_INT >= 21) ? wrapNonNullInstance(Api21Impl.getChild((AccessibilityWindowInfo)this.mInfo, paramInt)) : null;
  }
  
  public int getChildCount() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getChildCount((AccessibilityWindowInfo)this.mInfo) : 0;
  }
  
  public int getDisplayId() {
    return (Build.VERSION.SDK_INT >= 33) ? Api33Impl.getDisplayId((AccessibilityWindowInfo)this.mInfo) : 0;
  }
  
  public int getId() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getId((AccessibilityWindowInfo)this.mInfo) : -1;
  }
  
  public int getLayer() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getLayer((AccessibilityWindowInfo)this.mInfo) : -1;
  }
  
  public AccessibilityWindowInfoCompat getParent() {
    return (Build.VERSION.SDK_INT >= 21) ? wrapNonNullInstance(Api21Impl.getParent((AccessibilityWindowInfo)this.mInfo)) : null;
  }
  
  public void getRegionInScreen(Region paramRegion) {
    if (Build.VERSION.SDK_INT >= 33) {
      Api33Impl.getRegionInScreen((AccessibilityWindowInfo)this.mInfo, paramRegion);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      Rect rect = new Rect();
      Api21Impl.getBoundsInScreen((AccessibilityWindowInfo)this.mInfo, rect);
      paramRegion.set(rect);
    } 
  }
  
  public AccessibilityNodeInfoCompat getRoot() {
    return (Build.VERSION.SDK_INT >= 21) ? AccessibilityNodeInfoCompat.wrapNonNullInstance(Api21Impl.getRoot((AccessibilityWindowInfo)this.mInfo)) : null;
  }
  
  public CharSequence getTitle() {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.getTitle((AccessibilityWindowInfo)this.mInfo) : null;
  }
  
  public int getType() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.getType((AccessibilityWindowInfo)this.mInfo) : -1;
  }
  
  public int hashCode() {
    Object object = this.mInfo;
    return (object == null) ? 0 : object.hashCode();
  }
  
  public boolean isAccessibilityFocused() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.isAccessibilityFocused((AccessibilityWindowInfo)this.mInfo) : true;
  }
  
  public boolean isActive() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.isActive((AccessibilityWindowInfo)this.mInfo) : true;
  }
  
  public boolean isFocused() {
    return (Build.VERSION.SDK_INT >= 21) ? Api21Impl.isFocused((AccessibilityWindowInfo)this.mInfo) : true;
  }
  
  public boolean isInPictureInPictureMode() {
    return (Build.VERSION.SDK_INT >= 33) ? Api33Impl.isInPictureInPictureMode((AccessibilityWindowInfo)this.mInfo) : false;
  }
  
  public void recycle() {
    if (Build.VERSION.SDK_INT >= 21)
      Api21Impl.recycle((AccessibilityWindowInfo)this.mInfo); 
  }
  
  public String toString() {
    boolean bool1;
    StringBuilder stringBuilder = new StringBuilder();
    Rect rect = new Rect();
    getBoundsInScreen(rect);
    stringBuilder.append("AccessibilityWindowInfo[");
    stringBuilder.append("id=");
    stringBuilder.append(getId());
    stringBuilder.append(", type=");
    stringBuilder.append(typeToString(getType()));
    stringBuilder.append(", layer=");
    stringBuilder.append(getLayer());
    stringBuilder.append(", bounds=");
    stringBuilder.append(rect);
    stringBuilder.append(", focused=");
    stringBuilder.append(isFocused());
    stringBuilder.append(", active=");
    stringBuilder.append(isActive());
    stringBuilder.append(", hasParent=");
    AccessibilityWindowInfoCompat accessibilityWindowInfoCompat = getParent();
    boolean bool2 = true;
    if (accessibilityWindowInfoCompat != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    stringBuilder.append(bool1);
    stringBuilder.append(", hasChildren=");
    if (getChildCount() > 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    stringBuilder.append(bool1);
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
  
  public AccessibilityWindowInfo unwrap() {
    return (Build.VERSION.SDK_INT >= 21) ? (AccessibilityWindowInfo)this.mInfo : null;
  }
  
  private static class Api21Impl {
    static void getBoundsInScreen(AccessibilityWindowInfo param1AccessibilityWindowInfo, Rect param1Rect) {
      param1AccessibilityWindowInfo.getBoundsInScreen(param1Rect);
    }
    
    static AccessibilityWindowInfo getChild(AccessibilityWindowInfo param1AccessibilityWindowInfo, int param1Int) {
      return param1AccessibilityWindowInfo.getChild(param1Int);
    }
    
    static int getChildCount(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getChildCount();
    }
    
    static int getId(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getId();
    }
    
    static int getLayer(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getLayer();
    }
    
    static AccessibilityWindowInfo getParent(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getParent();
    }
    
    static AccessibilityNodeInfo getRoot(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getRoot();
    }
    
    static int getType(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getType();
    }
    
    static boolean isAccessibilityFocused(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.isAccessibilityFocused();
    }
    
    static boolean isActive(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.isActive();
    }
    
    static boolean isFocused(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.isFocused();
    }
    
    static AccessibilityWindowInfo obtain() {
      return AccessibilityWindowInfo.obtain();
    }
    
    static AccessibilityWindowInfo obtain(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return AccessibilityWindowInfo.obtain(param1AccessibilityWindowInfo);
    }
    
    static void recycle(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      param1AccessibilityWindowInfo.recycle();
    }
  }
  
  private static class Api24Impl {
    static AccessibilityNodeInfo getAnchor(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getAnchor();
    }
    
    static CharSequence getTitle(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getTitle();
    }
  }
  
  private static class Api33Impl {
    static int getDisplayId(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.getDisplayId();
    }
    
    static void getRegionInScreen(AccessibilityWindowInfo param1AccessibilityWindowInfo, Region param1Region) {
      param1AccessibilityWindowInfo.getRegionInScreen(param1Region);
    }
    
    static boolean isInPictureInPictureMode(AccessibilityWindowInfo param1AccessibilityWindowInfo) {
      return param1AccessibilityWindowInfo.isInPictureInPictureMode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\view\accessibility\AccessibilityWindowInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */