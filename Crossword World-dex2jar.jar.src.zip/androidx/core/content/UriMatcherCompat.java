package androidx.core.content;

import android.content.UriMatcher;
import android.net.Uri;
import androidx.core.util.Predicate;

public class UriMatcherCompat {
  public static Predicate<Uri> asPredicate(UriMatcher paramUriMatcher) {
    return new -$$Lambda$UriMatcherCompat$8fA7vT34PWr0u8V07hLP9kNYaek(paramUriMatcher);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\content\UriMatcherCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */