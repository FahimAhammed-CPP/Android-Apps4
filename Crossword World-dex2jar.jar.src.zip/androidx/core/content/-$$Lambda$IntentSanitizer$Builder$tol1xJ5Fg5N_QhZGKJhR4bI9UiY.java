package androidx.core.content;

import androidx.core.util.Predicate;



/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\content\-$$Lambda$IntentSanitizer$Builder$tol1xJ5Fg5N_QhZGKJhR4bI9UiY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */