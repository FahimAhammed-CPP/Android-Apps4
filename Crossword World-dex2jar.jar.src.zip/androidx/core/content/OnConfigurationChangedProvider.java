package androidx.core.content;

import android.content.res.Configuration;
import androidx.core.util.Consumer;

public interface OnConfigurationChangedProvider {
  void addOnConfigurationChangedListener(Consumer<Configuration> paramConsumer);
  
  void removeOnConfigurationChangedListener(Consumer<Configuration> paramConsumer);
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\content\OnConfigurationChangedProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */