package androidx.core.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import androidx.core.content.res.FontResourcesParserCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class FontProvider {
  private static final Comparator<byte[]> sByteArrayComparator = -$$Lambda$FontProvider$s5vSNk9mJZQ4hwJAC4Of3xvWgHU.INSTANCE;
  
  private static List<byte[]> convertToByteArrayList(Signature[] paramArrayOfSignature) {
    ArrayList<byte[]> arrayList = new ArrayList();
    int j = paramArrayOfSignature.length;
    for (int i = 0; i < j; i++)
      arrayList.add(paramArrayOfSignature[i].toByteArray()); 
    return (List<byte[]>)arrayList;
  }
  
  private static boolean equalsByteArrayList(List<byte[]> paramList1, List<byte[]> paramList2) {
    if (paramList1.size() != paramList2.size())
      return false; 
    for (int i = 0; i < paramList1.size(); i++) {
      if (!Arrays.equals(paramList1.get(i), paramList2.get(i)))
        return false; 
    } 
    return true;
  }
  
  private static List<List<byte[]>> getCertificates(FontRequest paramFontRequest, Resources paramResources) {
    return (paramFontRequest.getCertificates() != null) ? paramFontRequest.getCertificates() : FontResourcesParserCompat.readCerts(paramResources, paramFontRequest.getCertificatesArrayResId());
  }
  
  static FontsContractCompat.FontFamilyResult getFontFamilyResult(Context paramContext, FontRequest paramFontRequest, CancellationSignal paramCancellationSignal) throws PackageManager.NameNotFoundException {
    ProviderInfo providerInfo = getProvider(paramContext.getPackageManager(), paramFontRequest, paramContext.getResources());
    return (providerInfo == null) ? FontsContractCompat.FontFamilyResult.create(1, null) : FontsContractCompat.FontFamilyResult.create(0, query(paramContext, paramFontRequest, providerInfo.authority, paramCancellationSignal));
  }
  
  static ProviderInfo getProvider(PackageManager paramPackageManager, FontRequest paramFontRequest, Resources paramResources) throws PackageManager.NameNotFoundException {
    String str = paramFontRequest.getProviderAuthority();
    int i = 0;
    ProviderInfo providerInfo = paramPackageManager.resolveContentProvider(str, 0);
    if (providerInfo != null) {
      List<List<byte[]>> list;
      if (providerInfo.packageName.equals(paramFontRequest.getProviderPackage())) {
        List<byte[]> list1 = convertToByteArrayList((paramPackageManager.getPackageInfo(providerInfo.packageName, 64)).signatures);
        Collections.sort((List)list1, (Comparator)sByteArrayComparator);
        list = getCertificates(paramFontRequest, paramResources);
        while (i < list.size()) {
          ArrayList<byte> arrayList = new ArrayList(list.get(i));
          Collections.sort(arrayList, (Comparator)sByteArrayComparator);
          if (equalsByteArrayList(list1, (List)arrayList))
            return providerInfo; 
          i++;
        } 
        return null;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Found content provider ");
      stringBuilder1.append(str);
      stringBuilder1.append(", but package was not ");
      stringBuilder1.append(list.getProviderPackage());
      throw new PackageManager.NameNotFoundException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No package found for authority: ");
    stringBuilder.append(str);
    throw new PackageManager.NameNotFoundException(stringBuilder.toString());
  }
  
  static FontsContractCompat.FontInfo[] query(Context paramContext, FontRequest paramFontRequest, String paramString, CancellationSignal paramCancellationSignal) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #14
    //   9: new android/net/Uri$Builder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: ldc 'content'
    //   18: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   21: aload_2
    //   22: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   25: invokevirtual build : ()Landroid/net/Uri;
    //   28: astore #16
    //   30: new android/net/Uri$Builder
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: ldc 'content'
    //   39: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   42: aload_2
    //   43: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   46: ldc 'file'
    //   48: invokevirtual appendPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   51: invokevirtual build : ()Landroid/net/Uri;
    //   54: astore #17
    //   56: aconst_null
    //   57: astore #15
    //   59: aload #15
    //   61: astore_2
    //   62: bipush #7
    //   64: anewarray java/lang/String
    //   67: astore #18
    //   69: aload #18
    //   71: iconst_0
    //   72: ldc '_id'
    //   74: aastore
    //   75: aload #18
    //   77: iconst_1
    //   78: ldc 'file_id'
    //   80: aastore
    //   81: aload #18
    //   83: iconst_2
    //   84: ldc 'font_ttc_index'
    //   86: aastore
    //   87: aload #18
    //   89: iconst_3
    //   90: ldc 'font_variation_settings'
    //   92: aastore
    //   93: aload #18
    //   95: iconst_4
    //   96: ldc 'font_weight'
    //   98: aastore
    //   99: aload #18
    //   101: iconst_5
    //   102: ldc 'font_italic'
    //   104: aastore
    //   105: aload #18
    //   107: bipush #6
    //   109: ldc 'result_code'
    //   111: aastore
    //   112: aload #15
    //   114: astore_2
    //   115: aload_0
    //   116: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   119: astore_0
    //   120: aload #15
    //   122: astore_2
    //   123: getstatic android/os/Build$VERSION.SDK_INT : I
    //   126: bipush #16
    //   128: if_icmple -> 161
    //   131: aload #15
    //   133: astore_2
    //   134: aload_0
    //   135: aload #16
    //   137: aload #18
    //   139: ldc 'query = ?'
    //   141: iconst_1
    //   142: anewarray java/lang/String
    //   145: dup
    //   146: iconst_0
    //   147: aload_1
    //   148: invokevirtual getQuery : ()Ljava/lang/String;
    //   151: aastore
    //   152: aconst_null
    //   153: aload_3
    //   154: invokestatic query : (Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    //   157: astore_0
    //   158: goto -> 187
    //   161: aload #15
    //   163: astore_2
    //   164: aload_0
    //   165: aload #16
    //   167: aload #18
    //   169: ldc 'query = ?'
    //   171: iconst_1
    //   172: anewarray java/lang/String
    //   175: dup
    //   176: iconst_0
    //   177: aload_1
    //   178: invokevirtual getQuery : ()Ljava/lang/String;
    //   181: aastore
    //   182: aconst_null
    //   183: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   186: astore_0
    //   187: aload #14
    //   189: astore_1
    //   190: aload_0
    //   191: ifnull -> 459
    //   194: aload #14
    //   196: astore_1
    //   197: aload_0
    //   198: astore_2
    //   199: aload_0
    //   200: invokeinterface getCount : ()I
    //   205: ifle -> 459
    //   208: aload_0
    //   209: astore_2
    //   210: aload_0
    //   211: ldc 'result_code'
    //   213: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   218: istore #7
    //   220: aload_0
    //   221: astore_2
    //   222: new java/util/ArrayList
    //   225: dup
    //   226: invokespecial <init> : ()V
    //   229: astore_3
    //   230: aload_0
    //   231: astore_2
    //   232: aload_0
    //   233: ldc '_id'
    //   235: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   240: istore #8
    //   242: aload_0
    //   243: astore_2
    //   244: aload_0
    //   245: ldc 'file_id'
    //   247: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   252: istore #9
    //   254: aload_0
    //   255: astore_2
    //   256: aload_0
    //   257: ldc 'font_ttc_index'
    //   259: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   264: istore #10
    //   266: aload_0
    //   267: astore_2
    //   268: aload_0
    //   269: ldc 'font_weight'
    //   271: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   276: istore #11
    //   278: aload_0
    //   279: astore_2
    //   280: aload_0
    //   281: ldc 'font_italic'
    //   283: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   288: istore #12
    //   290: aload_0
    //   291: astore_2
    //   292: aload_0
    //   293: invokeinterface moveToNext : ()Z
    //   298: ifeq -> 457
    //   301: iload #7
    //   303: iconst_m1
    //   304: if_icmpeq -> 494
    //   307: aload_0
    //   308: astore_2
    //   309: aload_0
    //   310: iload #7
    //   312: invokeinterface getInt : (I)I
    //   317: istore #4
    //   319: goto -> 322
    //   322: iload #10
    //   324: iconst_m1
    //   325: if_icmpeq -> 500
    //   328: aload_0
    //   329: astore_2
    //   330: aload_0
    //   331: iload #10
    //   333: invokeinterface getInt : (I)I
    //   338: istore #5
    //   340: goto -> 343
    //   343: iload #9
    //   345: iconst_m1
    //   346: if_icmpne -> 368
    //   349: aload_0
    //   350: astore_2
    //   351: aload #16
    //   353: aload_0
    //   354: iload #8
    //   356: invokeinterface getLong : (I)J
    //   361: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   364: astore_1
    //   365: goto -> 384
    //   368: aload_0
    //   369: astore_2
    //   370: aload #17
    //   372: aload_0
    //   373: iload #9
    //   375: invokeinterface getLong : (I)J
    //   380: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   383: astore_1
    //   384: iload #4
    //   386: istore #6
    //   388: iload #11
    //   390: iconst_m1
    //   391: if_icmpeq -> 506
    //   394: aload_0
    //   395: astore_2
    //   396: aload_0
    //   397: iload #11
    //   399: invokeinterface getInt : (I)I
    //   404: istore #4
    //   406: goto -> 409
    //   409: iload #12
    //   411: iconst_m1
    //   412: if_icmpeq -> 514
    //   415: aload_0
    //   416: astore_2
    //   417: aload_0
    //   418: iload #12
    //   420: invokeinterface getInt : (I)I
    //   425: iconst_1
    //   426: if_icmpne -> 514
    //   429: iconst_1
    //   430: istore #13
    //   432: goto -> 435
    //   435: aload_0
    //   436: astore_2
    //   437: aload_3
    //   438: aload_1
    //   439: iload #5
    //   441: iload #4
    //   443: iload #13
    //   445: iload #6
    //   447: invokestatic create : (Landroid/net/Uri;IIZI)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   450: invokevirtual add : (Ljava/lang/Object;)Z
    //   453: pop
    //   454: goto -> 290
    //   457: aload_3
    //   458: astore_1
    //   459: aload_0
    //   460: ifnull -> 469
    //   463: aload_0
    //   464: invokeinterface close : ()V
    //   469: aload_1
    //   470: iconst_0
    //   471: anewarray androidx/core/provider/FontsContractCompat$FontInfo
    //   474: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   477: checkcast [Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   480: areturn
    //   481: astore_0
    //   482: aload_2
    //   483: ifnull -> 492
    //   486: aload_2
    //   487: invokeinterface close : ()V
    //   492: aload_0
    //   493: athrow
    //   494: iconst_0
    //   495: istore #4
    //   497: goto -> 322
    //   500: iconst_0
    //   501: istore #5
    //   503: goto -> 343
    //   506: sipush #400
    //   509: istore #4
    //   511: goto -> 409
    //   514: iconst_0
    //   515: istore #13
    //   517: goto -> 435
    // Exception table:
    //   from	to	target	type
    //   62	69	481	finally
    //   115	120	481	finally
    //   123	131	481	finally
    //   134	158	481	finally
    //   164	187	481	finally
    //   199	208	481	finally
    //   210	220	481	finally
    //   222	230	481	finally
    //   232	242	481	finally
    //   244	254	481	finally
    //   256	266	481	finally
    //   268	278	481	finally
    //   280	290	481	finally
    //   292	301	481	finally
    //   309	319	481	finally
    //   330	340	481	finally
    //   351	365	481	finally
    //   370	384	481	finally
    //   396	406	481	finally
    //   417	429	481	finally
    //   437	454	481	finally
  }
  
  static class Api16Impl {
    static Cursor query(ContentResolver param1ContentResolver, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2, Object param1Object) {
      return param1ContentResolver.query(param1Uri, param1ArrayOfString1, param1String1, param1ArrayOfString2, param1String2, (CancellationSignal)param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Crossword World-dex2jar.jar!\androidx\core\provider\FontProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */