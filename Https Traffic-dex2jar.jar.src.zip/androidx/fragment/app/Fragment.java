package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import c.h.b.h;
import c.m.a.b0;
import c.m.a.c0;
import c.m.a.g;
import c.m.a.g0;
import c.m.a.i;
import c.m.a.j;
import c.m.a.n;
import c.m.a.z0;
import c.p.e;
import c.p.f;
import c.p.g;
import c.p.h;
import c.p.j;
import c.p.o;
import c.p.w;
import c.p.x;
import c.v.a;
import c.v.c;
import c.v.d;
import d.a.a.a.a;
import java.util.Objects;
import java.util.UUID;

public abstract class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, h, x, d {
  public static final Object W = new Object();
  
  public String A;
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public boolean E = true;
  
  public boolean F;
  
  public ViewGroup G;
  
  public View H;
  
  public View I;
  
  public boolean J;
  
  public boolean K = true;
  
  public g L;
  
  public boolean M;
  
  public boolean N;
  
  public float O;
  
  public LayoutInflater P;
  
  public boolean Q;
  
  public e.b R = e.b.i;
  
  public j S;
  
  public z0 T;
  
  public o<h> U = new o();
  
  public c V;
  
  public int e = 0;
  
  public Bundle f;
  
  public SparseArray<Parcelable> g;
  
  public String h = UUID.randomUUID().toString();
  
  public Bundle i;
  
  public Fragment j;
  
  public String k = null;
  
  public int l;
  
  public Boolean m = null;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public int t;
  
  public c0 u;
  
  public i v;
  
  public c0 w = new c0();
  
  public Fragment x;
  
  public int y;
  
  public int z;
  
  public Fragment() {
    w();
  }
  
  public void A(Context paramContext) {
    Activity activity;
    this.F = true;
    i i1 = this.v;
    if (i1 == null) {
      i1 = null;
    } else {
      activity = i1.e;
    } 
    if (activity != null) {
      this.F = false;
      this.F = true;
    } 
  }
  
  public void B(Bundle paramBundle) {
    boolean bool = true;
    this.F = true;
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.w.h0(parcelable);
        this.w.m();
      } 
    } 
    c0 c01 = this.w;
    if (c01.s < 1)
      bool = false; 
    if (!bool)
      c01.m(); 
  }
  
  public View C(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return null;
  }
  
  public void D() {
    this.F = true;
  }
  
  public void E() {
    this.F = true;
  }
  
  public void F() {
    this.F = true;
  }
  
  public LayoutInflater G(Bundle paramBundle) {
    i i1 = this.v;
    if (i1 != null) {
      LayoutInflater layoutInflater = i1.i.getLayoutInflater().cloneInContext((Context)i1.i);
      c0 c01 = this.w;
      Objects.requireNonNull(c01);
      layoutInflater.setFactory2((LayoutInflater.Factory2)c01);
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void H(AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.F = true;
    i i1 = this.v;
    if (i1 == null) {
      i1 = null;
    } else {
      activity = i1.e;
    } 
    if (activity != null) {
      this.F = false;
      this.F = true;
    } 
  }
  
  public void I(Bundle paramBundle) {}
  
  public void J() {
    this.F = true;
  }
  
  public void K() {
    this.F = true;
  }
  
  public void L(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.w.d0();
    boolean bool = true;
    this.s = true;
    this.T = new z0();
    View view = C(paramLayoutInflater, paramViewGroup, paramBundle);
    this.H = view;
    if (view != null) {
      z0 z01 = this.T;
      if (z01.e == null)
        z01.e = new j((h)z01); 
      this.U.d(this.T);
      return;
    } 
    if (this.T.e == null)
      bool = false; 
    if (!bool) {
      this.T = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  public void M() {
    this.F = true;
    this.w.p();
  }
  
  public boolean N(Menu paramMenu) {
    boolean bool = this.B;
    int k = 0;
    if (!bool)
      k = false | this.w.J(paramMenu); 
    return k;
  }
  
  public final n O() {
    c0 c01 = this.u;
    if (c01 != null)
      return (n)c01; 
    throw new IllegalStateException(a.e("Fragment ", this, " not associated with a fragment manager."));
  }
  
  public final View P() {
    View view = this.H;
    if (view != null)
      return view; 
    throw new IllegalStateException(a.e("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
  }
  
  public void Q(View paramView) {
    (c()).a = paramView;
  }
  
  public void R(Animator paramAnimator) {
    (c()).b = paramAnimator;
  }
  
  public void S(Bundle paramBundle) {
    c0 c01 = this.u;
    if (c01 != null) {
      boolean bool;
      if (c01 == null) {
        bool = false;
      } else {
        bool = c01.W();
      } 
      if (bool)
        throw new IllegalStateException("Fragment already added and state has been saved"); 
    } 
    this.i = paramBundle;
  }
  
  public void T(boolean paramBoolean) {
    (c()).k = paramBoolean;
  }
  
  public void U(int paramInt) {
    if (this.L == null && paramInt == 0)
      return; 
    (c()).d = paramInt;
  }
  
  public void V(b0 paramb0) {
    c();
    b0 b01 = this.L.j;
    if (paramb0 == b01)
      return; 
    if (paramb0 == null || b01 == null) {
      if (paramb0 != null)
        paramb0.c++; 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final a b() {
    return this.V.b;
  }
  
  public final g c() {
    if (this.L == null)
      this.L = new g(); 
    return this.L;
  }
  
  public Fragment d(String paramString) {
    return paramString.equals(this.h) ? this : this.w.S(paramString);
  }
  
  public final j e() {
    i i1 = this.v;
    return (i1 == null) ? null : (j)i1.e;
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public View f() {
    g g1 = this.L;
    return (g1 == null) ? null : g1.a;
  }
  
  public Animator g() {
    g g1 = this.L;
    return (g1 == null) ? null : g1.b;
  }
  
  public final n h() {
    if (this.v != null)
      return (n)this.w; 
    throw new IllegalStateException(a.e("Fragment ", this, " has not been attached yet."));
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public w i() {
    c0 c01 = this.u;
    if (c01 != null) {
      g0 g0 = c01.I;
      w w2 = (w)g0.d.get(this.h);
      w w1 = w2;
      if (w2 == null) {
        w1 = new w();
        g0.d.put(this.h, w1);
      } 
      return w1;
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public Context j() {
    i i1 = this.v;
    return (i1 == null) ? null : i1.f;
  }
  
  public Object k() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Objects.requireNonNull(g1);
    return null;
  }
  
  public e l() {
    return (e)this.S;
  }
  
  public void m() {
    g g1 = this.L;
    if (g1 == null)
      return; 
    Objects.requireNonNull(g1);
  }
  
  public Object n() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Objects.requireNonNull(g1);
    return null;
  }
  
  public int o() {
    g g1 = this.L;
    return (g1 == null) ? 0 : g1.d;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.F = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    j j1 = e();
    if (j1 != null) {
      j1.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
      return;
    } 
    throw new IllegalStateException(a.e("Fragment ", this, " not attached to an activity."));
  }
  
  public void onLowMemory() {
    this.F = true;
  }
  
  public int p() {
    g g1 = this.L;
    return (g1 == null) ? 0 : g1.e;
  }
  
  public int q() {
    g g1 = this.L;
    return (g1 == null) ? 0 : g1.f;
  }
  
  public Object r() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Object object = g1.h;
    if (object == W) {
      n();
      return null;
    } 
    return object;
  }
  
  public Object s() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Object object = g1.g;
    if (object == W) {
      k();
      return null;
    } 
    return object;
  }
  
  public Object t() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Objects.requireNonNull(g1);
    return null;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    h.c(this, stringBuilder);
    stringBuilder.append(" (");
    stringBuilder.append(this.h);
    stringBuilder.append(")");
    if (this.y != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.y));
    } 
    if (this.A != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.A);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public Object u() {
    g g1 = this.L;
    if (g1 == null)
      return null; 
    Object object = g1.i;
    if (object == W) {
      t();
      return null;
    } 
    return object;
  }
  
  public int v() {
    g g1 = this.L;
    return (g1 == null) ? 0 : g1.c;
  }
  
  public final void w() {
    this.S = new j(this);
    this.V = new c(this);
    this.S.a((g)new f(this) {
          public void d(h param1h, e.a param1a) {
            if (param1a == e.a.ON_STOP) {
              View view = this.e.H;
              if (view != null)
                view.cancelPendingInputEvents(); 
            } 
          }
        });
  }
  
  public boolean x() {
    g g1 = this.L;
    return (g1 == null) ? false : g1.k;
  }
  
  public final boolean y() {
    return (this.t > 0);
  }
  
  public void z(Bundle paramBundle) {
    this.F = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */