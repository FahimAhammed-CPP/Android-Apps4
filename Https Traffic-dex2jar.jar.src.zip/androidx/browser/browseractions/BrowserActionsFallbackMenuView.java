package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class BrowserActionsFallbackMenuView extends LinearLayout {
  public final int e = getResources().getDimensionPixelOffset(2131100489);
  
  public final int f = getResources().getDimensionPixelOffset(2131100488);
  
  public BrowserActionsFallbackMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min((getResources().getDisplayMetrics()).widthPixels - this.e * 2, this.f), 1073741824), paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsFallbackMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */