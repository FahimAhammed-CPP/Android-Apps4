package androidx.lifecycle;

import c.p.c;
import c.p.e;
import c.p.f;
import c.p.h;

public class FullLifecycleObserverAdapter implements f {
  public final c e;
  
  public final f f;
  
  public void d(h paramh, e.a parama) {
    switch (parama.ordinal()) {
      case 6:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 5:
        this.e.b(paramh);
        break;
      case 4:
        this.e.g(paramh);
        break;
      case 3:
        this.e.e(paramh);
        break;
      case 2:
        this.e.a(paramh);
        break;
      case 1:
        this.e.f(paramh);
        break;
      case 0:
        this.e.c(paramh);
        break;
    } 
    f f1 = this.f;
    if (f1 != null)
      f1.d(paramh, parama); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */