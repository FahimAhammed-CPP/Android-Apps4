package androidx.lifecycle;

import c.p.d;
import c.p.e;
import c.p.f;
import c.p.h;

public class SingleGeneratedAdapterObserver implements f {
  public final d e;
  
  public SingleGeneratedAdapterObserver(d paramd) {
    this.e = paramd;
  }
  
  public void d(h paramh, e.a parama) {
    this.e.a(paramh, parama, false, null);
    this.e.a(paramh, parama, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */