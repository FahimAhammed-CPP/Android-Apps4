package androidx.lifecycle;

import c.p.a;
import c.p.e;
import c.p.f;
import c.p.h;
import java.util.List;

public class ReflectiveGenericLifecycleObserver implements f {
  public final Object e;
  
  public final a.a f;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.e = paramObject;
    this.f = a.c.b(paramObject.getClass());
  }
  
  public void d(h paramh, e.a parama) {
    a.a a1 = this.f;
    Object object = this.e;
    a.a.a((List)a1.a.get(parama), paramh, parama, object);
    a.a.a((List)a1.a.get(e.a.ON_ANY), paramh, parama, object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */