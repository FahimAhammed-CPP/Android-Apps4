package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import c.b.g.b;
import c.b.g.n.l;
import c.b.g.n.y;
import c.b.g.n.z;
import c.b.h.b;
import c.b.h.m;
import c.b.h.t2;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class ActionBarContextView extends b {
  public CharSequence m;
  
  public CharSequence n;
  
  public View o;
  
  public View p;
  
  public LinearLayout q;
  
  public TextView r;
  
  public TextView s;
  
  public int t;
  
  public int u;
  
  public boolean v;
  
  public int w;
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130903067
    //   5: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   8: aload_1
    //   9: aload_2
    //   10: getstatic c/b/b.d : [I
    //   13: ldc 2130903067
    //   15: iconst_0
    //   16: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   19: astore_2
    //   20: aload_2
    //   21: iconst_0
    //   22: invokevirtual hasValue : (I)Z
    //   25: ifeq -> 48
    //   28: aload_2
    //   29: iconst_0
    //   30: iconst_0
    //   31: invokevirtual getResourceId : (II)I
    //   34: istore_3
    //   35: iload_3
    //   36: ifeq -> 48
    //   39: aload_1
    //   40: iload_3
    //   41: invokestatic a : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   44: astore_1
    //   45: goto -> 54
    //   48: aload_2
    //   49: iconst_0
    //   50: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   53: astore_1
    //   54: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   57: astore #4
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual setBackground : (Landroid/graphics/drawable/Drawable;)V
    //   64: aload_0
    //   65: aload_2
    //   66: iconst_5
    //   67: iconst_0
    //   68: invokevirtual getResourceId : (II)I
    //   71: putfield t : I
    //   74: aload_0
    //   75: aload_2
    //   76: iconst_4
    //   77: iconst_0
    //   78: invokevirtual getResourceId : (II)I
    //   81: putfield u : I
    //   84: aload_0
    //   85: aload_2
    //   86: iconst_3
    //   87: iconst_0
    //   88: invokevirtual getLayoutDimension : (II)I
    //   91: putfield i : I
    //   94: aload_0
    //   95: aload_2
    //   96: iconst_2
    //   97: ldc 2131427333
    //   99: invokevirtual getResourceId : (II)I
    //   102: putfield w : I
    //   105: aload_2
    //   106: invokevirtual recycle : ()V
    //   109: return
  }
  
  public void f(b paramb) {
    View view = this.o;
    if (view == null) {
      view = LayoutInflater.from(getContext()).inflate(this.w, (ViewGroup)this, false);
      this.o = view;
      addView(view);
    } else if (view.getParent() == null) {
      addView(this.o);
    } 
    this.o.findViewById(2131230784).setOnClickListener(new a(this, paramb));
    l l = (l)paramb.e();
    m m1 = this.h;
    if (m1 != null)
      m1.b(); 
    m1 = new m(getContext());
    this.h = m1;
    m1.q = true;
    m1.r = true;
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    l.b((y)this.h, this.f);
    m m2 = this.h;
    z z1 = m2.l;
    if (z1 == null) {
      z z = (z)m2.h.inflate(m2.j, (ViewGroup)this, false);
      m2.l = z;
      z.b(m2.g);
      m2.h(true);
    } 
    z z2 = m2.l;
    if (z1 != z2)
      ((ActionMenuView)z2).setPresenter(m2); 
    ActionMenuView actionMenuView = (ActionMenuView)z2;
    this.g = actionMenuView;
    AtomicInteger atomicInteger = u.a;
    actionMenuView.setBackground(null);
    addView((View)this.g, layoutParams);
  }
  
  public final void g() {
    if (this.q == null) {
      LayoutInflater.from(getContext()).inflate(2131427328, (ViewGroup)this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.q = linearLayout1;
      this.r = (TextView)linearLayout1.findViewById(2131230775);
      this.s = (TextView)this.q.findViewById(2131230774);
      if (this.t != 0)
        this.r.setTextAppearance(getContext(), this.t); 
      if (this.u != 0)
        this.s.setTextAppearance(getContext(), this.u); 
    } 
    this.r.setText(this.m);
    this.s.setText(this.n);
    boolean bool1 = TextUtils.isEmpty(this.m);
    int i = TextUtils.isEmpty(this.n) ^ true;
    TextView textView = this.s;
    boolean bool = false;
    if (i != 0) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    textView.setVisibility(b1);
    LinearLayout linearLayout = this.q;
    byte b1 = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b1 = bool;
      } else {
        b1 = 8;
      }  
    linearLayout.setVisibility(b1);
    if (this.q.getParent() == null)
      addView((View)this.q); 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public int getAnimatedVisibility() {
    return (this.j != null) ? this.e.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.i;
  }
  
  public CharSequence getSubtitle() {
    return this.n;
  }
  
  public CharSequence getTitle() {
    return this.m;
  }
  
  public void h() {
    removeAllViews();
    this.p = null;
    this.g = null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    m m = this.h;
    if (m != null) {
      m.g();
      this.h.n();
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 32) {
      paramAccessibilityEvent.setSource((View)this);
      paramAccessibilityEvent.setClassName(getClass().getName());
      paramAccessibilityEvent.setPackageName(getContext().getPackageName());
      paramAccessibilityEvent.setContentDescription(this.m);
      return;
    } 
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = t2.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.o;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.o.getLayoutParams();
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.rightMargin;
        } else {
          paramInt4 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.leftMargin;
        } else {
          paramInt2 = marginLayoutParams.rightMargin;
        } 
        if (paramBoolean) {
          paramInt4 = i - paramInt4;
        } else {
          paramInt4 = i + paramInt4;
        } 
        paramInt4 += d(this.o, paramInt4, j, k, paramBoolean);
        if (paramBoolean) {
          paramInt2 = paramInt4 - paramInt2;
        } else {
          paramInt2 = paramInt4 + paramInt2;
        } 
      } 
    } 
    LinearLayout linearLayout = this.q;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.p == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + d((View)this.q, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.p;
    if (view1 != null)
      d(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.g;
    if (actionMenuView != null)
      d((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.i;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        paramInt1 = getPaddingTop();
        int i1 = getPaddingBottom() + paramInt1;
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.o;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.o.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.g;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.g, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.q;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.p == null)
            if (this.v) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.q.measure(paramInt2, k);
              int i2 = this.q.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.q;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.p;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.p.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.i <= 0) {
          j = getChildCount();
          paramInt2 = 0;
          paramInt1 = bool;
          while (paramInt1 < j) {
            k = getChildAt(paramInt1).getMeasuredHeight() + i1;
            i = paramInt2;
            if (k > paramInt2)
              i = k; 
            paramInt1++;
            paramInt2 = i;
          } 
          setMeasuredDimension(n, paramInt2);
          return;
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setContentHeight(int paramInt) {
    this.i = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.p;
    if (view != null)
      removeView(view); 
    this.p = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.q;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.q = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.n = paramCharSequence;
    g();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.m = paramCharSequence;
    g();
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.v)
      requestLayout(); 
    this.v = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a implements View.OnClickListener {
    public a(ActionBarContextView this$0, b param1b) {}
    
    public void onClick(View param1View) {
      this.e.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */