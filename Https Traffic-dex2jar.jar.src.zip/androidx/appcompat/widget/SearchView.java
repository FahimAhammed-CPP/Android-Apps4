package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import c.b.g.c;
import c.b.h.c2;
import c.b.h.e2;
import c.b.h.j2;
import c.b.h.t2;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;

public class SearchView extends LinearLayoutCompat implements c {
  public static final n u0;
  
  public final ImageView A;
  
  public final View B;
  
  public p C;
  
  public Rect D = new Rect();
  
  public Rect E = new Rect();
  
  public int[] F = new int[2];
  
  public int[] G = new int[2];
  
  public final ImageView H;
  
  public final Drawable I;
  
  public final int J;
  
  public final int K;
  
  public final Intent L;
  
  public final Intent M;
  
  public final CharSequence N;
  
  public l O;
  
  public k P;
  
  public View.OnFocusChangeListener Q;
  
  public m R;
  
  public View.OnClickListener S;
  
  public boolean T;
  
  public boolean U;
  
  public c.i.a.c V;
  
  public boolean W;
  
  public CharSequence a0;
  
  public boolean b0;
  
  public boolean c0;
  
  public int d0;
  
  public boolean e0;
  
  public CharSequence f0;
  
  public CharSequence g0;
  
  public boolean h0;
  
  public int i0;
  
  public SearchableInfo j0;
  
  public Bundle k0;
  
  public final Runnable l0 = new b(this);
  
  public Runnable m0 = new c(this);
  
  public final WeakHashMap<String, Drawable.ConstantState> n0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  public final View.OnClickListener o0;
  
  public View.OnKeyListener p0;
  
  public final TextView.OnEditorActionListener q0;
  
  public final AdapterView.OnItemClickListener r0;
  
  public final AdapterView.OnItemSelectedListener s0;
  
  public final SearchAutoComplete t;
  
  public TextWatcher t0;
  
  public final View u;
  
  public final View v;
  
  public final View w;
  
  public final ImageView x;
  
  public final ImageView y;
  
  public final ImageView z;
  
  static {
    n n1;
    if (Build.VERSION.SDK_INT < 29) {
      n1 = new n();
    } else {
      n1 = null;
    } 
    u0 = n1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903722);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f f = new f(this);
    this.o0 = f;
    this.p0 = new g(this);
    h h = new h(this);
    this.q0 = h;
    i i = new i(this);
    this.r0 = i;
    j j = new j(this);
    this.s0 = j;
    this.t0 = new a(this);
    j2 j2 = new j2(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, c.b.b.v, paramInt, 0));
    LayoutInflater.from(paramContext).inflate(j2.l(9, 2131427353), this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(2131231072);
    this.t = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.u = findViewById(2131231068);
    View view2 = findViewById(2131231071);
    this.v = view2;
    View view3 = findViewById(2131231109);
    this.w = view3;
    ImageView imageView1 = (ImageView)findViewById(2131231066);
    this.x = imageView1;
    ImageView imageView2 = (ImageView)findViewById(2131231069);
    this.y = imageView2;
    ImageView imageView3 = (ImageView)findViewById(2131231067);
    this.z = imageView3;
    ImageView imageView4 = (ImageView)findViewById(2131231073);
    this.A = imageView4;
    ImageView imageView5 = (ImageView)findViewById(2131231070);
    this.H = imageView5;
    view2.setBackground(j2.g(10));
    view3.setBackground(j2.g(14));
    imageView1.setImageDrawable(j2.g(13));
    imageView2.setImageDrawable(j2.g(7));
    imageView3.setImageDrawable(j2.g(4));
    imageView4.setImageDrawable(j2.g(16));
    imageView5.setImageDrawable(j2.g(13));
    this.I = j2.g(12);
    c.b.a.f((View)imageView1, getResources().getString(2131755029));
    this.J = j2.l(15, 2131427352);
    this.K = j2.l(5, 0);
    imageView1.setOnClickListener(f);
    imageView3.setOnClickListener(f);
    imageView2.setOnClickListener(f);
    imageView4.setOnClickListener(f);
    searchAutoComplete.setOnClickListener(f);
    searchAutoComplete.addTextChangedListener(this.t0);
    searchAutoComplete.setOnEditorActionListener(h);
    searchAutoComplete.setOnItemClickListener(i);
    searchAutoComplete.setOnItemSelectedListener(j);
    searchAutoComplete.setOnKeyListener(this.p0);
    searchAutoComplete.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(j2.a(8, true));
    paramInt = j2.f(1, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.N = j2.n(6);
    this.a0 = j2.n(11);
    paramInt = j2.j(3, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = j2.j(2, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(j2.a(0, true));
    j2.b.recycle();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.L = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.M = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.B = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener(new e(this)); 
    G(this.T);
    D();
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(2131100462);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(2131100463);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.t.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.t;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  public boolean A(int paramInt, KeyEvent paramKeyEvent) {
    if (this.j0 == null)
      return false; 
    if (this.V == null)
      return false; 
    if (paramKeyEvent.getAction() == 0 && paramKeyEvent.hasNoModifiers()) {
      if (paramInt == 66 || paramInt == 84 || paramInt == 61)
        return v(this.t.getListSelection()); 
      if (paramInt == 21 || paramInt == 22) {
        if (paramInt == 21) {
          paramInt = 0;
        } else {
          paramInt = this.t.length();
        } 
        this.t.setSelection(paramInt);
        this.t.setListSelection(0);
        this.t.clearListSelection();
        this.t.a();
        return true;
      } 
      if (paramInt == 19 && this.t.getListSelection() == 0)
        return false; 
    } 
    return false;
  }
  
  public final void B() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.t.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.T && !this.h0) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.z;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.z.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  public void C() {
    int[] arrayOfInt;
    if (this.t.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.v.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.w.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public final void D() {
    SpannableStringBuilder spannableStringBuilder;
    CharSequence charSequence2 = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.t;
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    charSequence2 = charSequence1;
    if (this.T)
      if (this.I == null) {
        charSequence2 = charSequence1;
      } else {
        int i = (int)(searchAutoComplete.getTextSize() * 1.25D);
        this.I.setBounds(0, 0, i, i);
        spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.I), 1, 2, 33);
        spannableStringBuilder.append(charSequence1);
      }  
    searchAutoComplete.setHint((CharSequence)spannableStringBuilder);
  }
  
  public final void E() {
    // Byte code:
    //   0: aload_0
    //   1: getfield W : Z
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield e0 : Z
    //   15: ifeq -> 30
    //   18: aload_0
    //   19: getfield U : Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 63
    //   36: iload_2
    //   37: istore_1
    //   38: aload_0
    //   39: getfield y : Landroid/widget/ImageView;
    //   42: invokevirtual getVisibility : ()I
    //   45: ifeq -> 66
    //   48: aload_0
    //   49: getfield A : Landroid/widget/ImageView;
    //   52: invokevirtual getVisibility : ()I
    //   55: ifne -> 63
    //   58: iload_2
    //   59: istore_1
    //   60: goto -> 66
    //   63: bipush #8
    //   65: istore_1
    //   66: aload_0
    //   67: getfield w : Landroid/view/View;
    //   70: iload_1
    //   71: invokevirtual setVisibility : (I)V
    //   74: return
  }
  
  public final void F(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield W : Z
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iload #4
    //   10: ifeq -> 68
    //   13: iload #4
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield e0 : Z
    //   22: ifeq -> 37
    //   25: aload_0
    //   26: getfield U : Z
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: ifeq -> 68
    //   43: aload_0
    //   44: invokevirtual hasFocus : ()Z
    //   47: ifeq -> 68
    //   50: iload_3
    //   51: istore_2
    //   52: iload_1
    //   53: ifne -> 71
    //   56: aload_0
    //   57: getfield e0 : Z
    //   60: ifne -> 68
    //   63: iload_3
    //   64: istore_2
    //   65: goto -> 71
    //   68: bipush #8
    //   70: istore_2
    //   71: aload_0
    //   72: getfield y : Landroid/widget/ImageView;
    //   75: iload_2
    //   76: invokevirtual setVisibility : (I)V
    //   79: return
  }
  
  public final void G(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield U : Z
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_1
    //   8: ifeq -> 16
    //   11: iconst_0
    //   12: istore_2
    //   13: goto -> 19
    //   16: bipush #8
    //   18: istore_2
    //   19: aload_0
    //   20: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   23: invokevirtual getText : ()Landroid/text/Editable;
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: iconst_1
    //   30: ixor
    //   31: istore #4
    //   33: aload_0
    //   34: getfield x : Landroid/widget/ImageView;
    //   37: iload_2
    //   38: invokevirtual setVisibility : (I)V
    //   41: aload_0
    //   42: iload #4
    //   44: invokevirtual F : (Z)V
    //   47: aload_0
    //   48: getfield u : Landroid/view/View;
    //   51: astore #5
    //   53: iload_1
    //   54: ifeq -> 63
    //   57: bipush #8
    //   59: istore_2
    //   60: goto -> 65
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #5
    //   67: iload_2
    //   68: invokevirtual setVisibility : (I)V
    //   71: aload_0
    //   72: getfield H : Landroid/widget/ImageView;
    //   75: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
    //   78: ifnull -> 90
    //   81: iload_3
    //   82: istore_2
    //   83: aload_0
    //   84: getfield T : Z
    //   87: ifeq -> 93
    //   90: bipush #8
    //   92: istore_2
    //   93: aload_0
    //   94: getfield H : Landroid/widget/ImageView;
    //   97: iload_2
    //   98: invokevirtual setVisibility : (I)V
    //   101: aload_0
    //   102: invokevirtual B : ()V
    //   105: aload_0
    //   106: iload #4
    //   108: iconst_1
    //   109: ixor
    //   110: invokevirtual H : (Z)V
    //   113: aload_0
    //   114: invokevirtual E : ()V
    //   117: return
  }
  
  public final void H(boolean paramBoolean) {
    boolean bool = this.e0;
    byte b2 = 8;
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (!this.U) {
        b1 = b2;
        if (paramBoolean) {
          this.y.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.A.setVisibility(b1);
  }
  
  public void c() {
    if (this.h0)
      return; 
    this.h0 = true;
    int i = this.t.getImeOptions();
    this.i0 = i;
    this.t.setImeOptions(i | 0x2000000);
    this.t.setText("");
    setIconified(false);
  }
  
  public void clearFocus() {
    this.c0 = true;
    super.clearFocus();
    this.t.clearFocus();
    this.t.setImeVisibility(false);
    this.c0 = false;
  }
  
  public void d() {
    this.t.setText("");
    SearchAutoComplete searchAutoComplete = this.t;
    searchAutoComplete.setSelection(searchAutoComplete.length());
    this.g0 = "";
    clearFocus();
    G(true);
    this.t.setImeOptions(this.i0);
    this.h0 = false;
  }
  
  public int getImeOptions() {
    return this.t.getImeOptions();
  }
  
  public int getInputType() {
    return this.t.getInputType();
  }
  
  public int getMaxWidth() {
    return this.d0;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.t.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.a0;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.j0;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.j0.getHintId()) : this.N;
  }
  
  public int getSuggestionCommitIconResId() {
    return this.K;
  }
  
  public int getSuggestionRowLayout() {
    return this.J;
  }
  
  public c.i.a.c getSuggestionsAdapter() {
    return this.V;
  }
  
  public void onDetachedFromWindow() {
    removeCallbacks(this.l0);
    post(this.m0);
    super.onDetachedFromWindow();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      SearchAutoComplete searchAutoComplete = this.t;
      Rect rect2 = this.D;
      searchAutoComplete.getLocationInWindow(this.F);
      getLocationInWindow(this.G);
      int[] arrayOfInt1 = this.F;
      paramInt1 = arrayOfInt1[1];
      int[] arrayOfInt2 = this.G;
      paramInt1 -= arrayOfInt2[1];
      paramInt3 = arrayOfInt1[0] - arrayOfInt2[0];
      rect2.set(paramInt3, paramInt1, searchAutoComplete.getWidth() + paramInt3, searchAutoComplete.getHeight() + paramInt1);
      Rect rect1 = this.E;
      rect2 = this.D;
      rect1.set(rect2.left, 0, rect2.right, paramInt4 - paramInt2);
      p p1 = this.C;
      if (p1 == null) {
        p1 = new p(this.E, this.D, (View)this.t);
        this.C = p1;
        setTouchDelegate(p1);
        return;
      } 
      p1.a(this.E, this.D);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.U) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.d0;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.d0;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.d0;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.e);
    G(o.g);
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.g = this.U;
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    post(this.l0);
  }
  
  public final Intent q(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.g0);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.k0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.j0.getSearchActivity());
    return intent;
  }
  
  public final Intent r(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1073741824);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.k0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int j = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (j != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.c0)
      return false; 
    if (!isFocusable())
      return false; 
    if (!this.U) {
      boolean bool = this.t.requestFocus(paramInt, paramRect);
      if (bool)
        G(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void s() {
    if (Build.VERSION.SDK_INT >= 29) {
      this.t.refreshAutoCompleteResults();
      return;
    } 
    n n2 = u0;
    SearchAutoComplete searchAutoComplete = this.t;
    Objects.requireNonNull(n2);
    n.a();
    Method method2 = n2.a;
    if (method2 != null)
      try {
        method2.invoke(searchAutoComplete, new Object[0]);
      } catch (Exception exception) {} 
    n n1 = u0;
    searchAutoComplete = this.t;
    Objects.requireNonNull(n1);
    n.a();
    Method method1 = n1.b;
    if (method1 != null)
      try {
        method1.invoke(searchAutoComplete, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.k0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      u();
      return;
    } 
    y();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.T == paramBoolean)
      return; 
    this.T = paramBoolean;
    G(paramBoolean);
    D();
  }
  
  public void setImeOptions(int paramInt) {
    this.t.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.t.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.d0 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(k paramk) {
    this.P = paramk;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.Q = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(l paraml) {
    this.O = paraml;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.S = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(m paramm) {
    this.R = paramm;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.a0 = paramCharSequence;
    D();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.b0 = paramBoolean;
    c.i.a.c c1 = this.V;
    if (c1 instanceof e2) {
      boolean bool;
      e2 e2 = (e2)c1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      e2.u = bool;
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield j0 : Landroid/app/SearchableInfo;
    //   5: iconst_1
    //   6: istore #4
    //   8: aconst_null
    //   9: astore #5
    //   11: aload_1
    //   12: ifnull -> 183
    //   15: aload_0
    //   16: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   19: aload_1
    //   20: invokevirtual getSuggestThreshold : ()I
    //   23: invokevirtual setThreshold : (I)V
    //   26: aload_0
    //   27: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   30: aload_0
    //   31: getfield j0 : Landroid/app/SearchableInfo;
    //   34: invokevirtual getImeOptions : ()I
    //   37: invokevirtual setImeOptions : (I)V
    //   40: aload_0
    //   41: getfield j0 : Landroid/app/SearchableInfo;
    //   44: invokevirtual getInputType : ()I
    //   47: istore_3
    //   48: iload_3
    //   49: istore_2
    //   50: iload_3
    //   51: bipush #15
    //   53: iand
    //   54: iconst_1
    //   55: if_icmpne -> 86
    //   58: iload_3
    //   59: ldc_w -65537
    //   62: iand
    //   63: istore_3
    //   64: iload_3
    //   65: istore_2
    //   66: aload_0
    //   67: getfield j0 : Landroid/app/SearchableInfo;
    //   70: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   73: ifnull -> 86
    //   76: iload_3
    //   77: ldc_w 65536
    //   80: ior
    //   81: ldc_w 524288
    //   84: ior
    //   85: istore_2
    //   86: aload_0
    //   87: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   90: iload_2
    //   91: invokevirtual setInputType : (I)V
    //   94: aload_0
    //   95: getfield V : Lc/i/a/c;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_1
    //   104: aconst_null
    //   105: invokevirtual b : (Landroid/database/Cursor;)V
    //   108: aload_0
    //   109: getfield j0 : Landroid/app/SearchableInfo;
    //   112: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   115: ifnull -> 179
    //   118: new c/b/h/e2
    //   121: dup
    //   122: aload_0
    //   123: invokevirtual getContext : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_0
    //   128: getfield j0 : Landroid/app/SearchableInfo;
    //   131: aload_0
    //   132: getfield n0 : Ljava/util/WeakHashMap;
    //   135: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V
    //   138: astore_1
    //   139: aload_0
    //   140: aload_1
    //   141: putfield V : Lc/i/a/c;
    //   144: aload_0
    //   145: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   148: aload_1
    //   149: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   152: aload_0
    //   153: getfield V : Lc/i/a/c;
    //   156: checkcast c/b/h/e2
    //   159: astore_1
    //   160: aload_0
    //   161: getfield b0 : Z
    //   164: ifeq -> 172
    //   167: iconst_2
    //   168: istore_2
    //   169: goto -> 174
    //   172: iconst_1
    //   173: istore_2
    //   174: aload_1
    //   175: iload_2
    //   176: putfield u : I
    //   179: aload_0
    //   180: invokevirtual D : ()V
    //   183: aload_0
    //   184: getfield j0 : Landroid/app/SearchableInfo;
    //   187: astore_1
    //   188: aload_1
    //   189: ifnull -> 259
    //   192: aload_1
    //   193: invokevirtual getVoiceSearchEnabled : ()Z
    //   196: ifeq -> 259
    //   199: aload_0
    //   200: getfield j0 : Landroid/app/SearchableInfo;
    //   203: invokevirtual getVoiceSearchLaunchWebSearch : ()Z
    //   206: ifeq -> 217
    //   209: aload_0
    //   210: getfield L : Landroid/content/Intent;
    //   213: astore_1
    //   214: goto -> 235
    //   217: aload #5
    //   219: astore_1
    //   220: aload_0
    //   221: getfield j0 : Landroid/app/SearchableInfo;
    //   224: invokevirtual getVoiceSearchLaunchRecognizer : ()Z
    //   227: ifeq -> 235
    //   230: aload_0
    //   231: getfield M : Landroid/content/Intent;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnull -> 259
    //   239: aload_0
    //   240: invokevirtual getContext : ()Landroid/content/Context;
    //   243: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   246: aload_1
    //   247: ldc_w 65536
    //   250: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   253: ifnull -> 259
    //   256: goto -> 262
    //   259: iconst_0
    //   260: istore #4
    //   262: aload_0
    //   263: iload #4
    //   265: putfield e0 : Z
    //   268: iload #4
    //   270: ifeq -> 283
    //   273: aload_0
    //   274: getfield t : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   277: ldc_w 'nm'
    //   280: invokevirtual setPrivateImeOptions : (Ljava/lang/String;)V
    //   283: aload_0
    //   284: aload_0
    //   285: getfield U : Z
    //   288: invokevirtual G : (Z)V
    //   291: return
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.W = paramBoolean;
    G(this.U);
  }
  
  public void setSuggestionsAdapter(c.i.a.c paramc) {
    this.V = paramc;
    this.t.setAdapter((ListAdapter)paramc);
  }
  
  public void t(int paramInt, String paramString1, String paramString2) {
    Intent intent = q("android.intent.action.SEARCH", null, null, paramString2, paramInt, null);
    getContext().startActivity(intent);
  }
  
  public void u() {
    if (TextUtils.isEmpty((CharSequence)this.t.getText())) {
      if (this.T) {
        k k1 = this.P;
        if (k1 == null || !k1.a()) {
          clearFocus();
          G(true);
          return;
        } 
      } 
    } else {
      this.t.setText("");
      this.t.requestFocus();
      this.t.setImeVisibility(true);
    } 
  }
  
  public boolean v(int paramInt) {
    Intent intent;
    m m1 = this.R;
    if (m1 == null || !m1.b(paramInt)) {
      Uri uri;
      String str2;
      Cursor cursor = this.V.g;
      if (cursor != null && cursor.moveToPosition(paramInt)) {
        RuntimeException runtimeException = null;
        try {
          paramInt = e2.C;
          str2 = e2.r(cursor, cursor.getColumnIndex("suggest_intent_action"));
          String str = str2;
          if (str2 == null)
            str = this.j0.getSuggestIntentAction(); 
        } catch (RuntimeException runtimeException1) {
          try {
            paramInt = cursor.getPosition();
          } catch (RuntimeException runtimeException3) {
            paramInt = -1;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Search suggestions cursor at row ");
          stringBuilder.append(paramInt);
          stringBuilder.append(" returned exception.");
          Log.w("SearchView", stringBuilder.toString(), runtimeException1);
          runtimeException1 = runtimeException;
          if (runtimeException1 != null)
            try {
              getContext().startActivity((Intent)runtimeException1);
            } catch (RuntimeException runtimeException3) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failed launch activity: ");
              stringBuilder1.append(runtimeException1);
              Log.e("SearchView", stringBuilder1.toString(), runtimeException3);
            }  
          this.t.setImeVisibility(false);
          this.t.dismissDropDown();
          return true;
        } 
      } else {
        this.t.setImeVisibility(false);
        this.t.dismissDropDown();
        return true;
      } 
      RuntimeException runtimeException2 = runtimeException1;
      if (runtimeException1 == null)
        str2 = "android.intent.action.SEARCH"; 
      String str3 = e2.r(cursor, cursor.getColumnIndex("suggest_intent_data"));
      String str1 = str3;
      if (str3 == null)
        str1 = this.j0.getSuggestIntentData(); 
      str3 = str1;
      if (str1 != null) {
        String str = e2.r(cursor, cursor.getColumnIndex("suggest_intent_data_id"));
        str3 = str1;
        if (str != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("/");
          stringBuilder.append(Uri.encode(str));
          str3 = stringBuilder.toString();
        } 
      } 
      if (str3 == null) {
        str1 = null;
      } else {
        uri = Uri.parse(str3);
      } 
      str3 = e2.r(cursor, cursor.getColumnIndex("suggest_intent_query"));
      intent = q(str2, uri, e2.r(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), str3, 0, null);
    } else {
      return false;
    } 
    if (intent != null)
      try {
        getContext().startActivity(intent);
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed launch activity: ");
        stringBuilder.append(intent);
        Log.e("SearchView", stringBuilder.toString(), runtimeException);
      }  
    this.t.setImeVisibility(false);
    this.t.dismissDropDown();
    return true;
  }
  
  public boolean w(int paramInt) {
    m m1 = this.R;
    if (m1 == null || !m1.a(paramInt)) {
      Editable editable = this.t.getText();
      Cursor cursor = this.V.g;
      if (cursor != null)
        if (cursor.moveToPosition(paramInt)) {
          CharSequence charSequence = this.V.c(cursor);
          if (charSequence != null) {
            setQuery(charSequence);
          } else {
            setQuery((CharSequence)editable);
          } 
        } else {
          setQuery((CharSequence)editable);
        }  
      return true;
    } 
    return false;
  }
  
  public void x(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public void y() {
    G(false);
    this.t.requestFocus();
    this.t.setImeVisibility(true);
    View.OnClickListener onClickListener = this.S;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  public void z() {
    Editable editable = this.t.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      l l1 = this.O;
      if (l1 == null || !l1.b(editable.toString())) {
        if (this.j0 != null)
          t(0, null, editable.toString()); 
        this.t.setImeVisibility(false);
        this.t.dismissDropDown();
      } 
    } 
  }
  
  public static class SearchAutoComplete extends c.b.h.n {
    public int h = getThreshold();
    
    public SearchView i;
    
    public boolean j;
    
    public final Runnable k = new a(this);
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet, 2130903094);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    public void a() {
      if (Build.VERSION.SDK_INT >= 29) {
        setInputMethodMode(1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        SearchView.n n1 = SearchView.u0;
        Objects.requireNonNull(n1);
        SearchView.n.a();
        Method method = n1.c;
        if (method != null)
          try {
            method.invoke(this, new Object[] { Boolean.TRUE });
            return;
          } catch (Exception exception) {
            return;
          }  
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.h <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.j) {
        removeCallbacks(this.k);
        post(this.k);
      } 
      return inputConnection;
    }
    
    public void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    public void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      SearchView searchView = this.i;
      searchView.G(searchView.U);
      searchView.post(searchView.l0);
      if (searchView.t.hasFocus())
        searchView.s(); 
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.i.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.i.hasFocus() && getVisibility() == 0) {
        boolean bool = true;
        this.j = true;
        Context context = getContext();
        SearchView.n n1 = SearchView.u0;
        if ((context.getResources().getConfiguration()).orientation != 2)
          bool = false; 
        if (bool)
          a(); 
      } 
    }
    
    public void performCompletion() {}
    
    public void replaceText(CharSequence param1CharSequence) {}
    
    public void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.j = false;
        removeCallbacks(this.k);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.j = false;
        removeCallbacks(this.k);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.j = true;
    }
    
    public void setSearchView(SearchView param1SearchView) {
      this.i = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.h = param1Int;
    }
    
    public class a implements Runnable {
      public a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        SearchView.SearchAutoComplete searchAutoComplete = this.e;
        if (searchAutoComplete.j) {
          ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
          searchAutoComplete.j = false;
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(SearchView this$0) {}
    
    public void run() {
      SearchView.SearchAutoComplete searchAutoComplete = this.e;
      if (searchAutoComplete.j) {
        ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
        searchAutoComplete.j = false;
      } 
    }
  }
  
  public class a implements TextWatcher {
    public a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      SearchView searchView = this.e;
      Editable editable = searchView.t.getText();
      searchView.g0 = (CharSequence)editable;
      int i = TextUtils.isEmpty((CharSequence)editable) ^ true;
      searchView.F(i);
      searchView.H(i ^ 0x1);
      searchView.B();
      searchView.E();
      if (searchView.O != null && !TextUtils.equals(param1CharSequence, searchView.f0))
        searchView.O.a(param1CharSequence.toString()); 
      searchView.f0 = param1CharSequence.toString();
    }
  }
  
  public class b implements Runnable {
    public b(SearchView this$0) {}
    
    public void run() {
      this.e.C();
    }
  }
  
  public class c implements Runnable {
    public c(SearchView this$0) {}
    
    public void run() {
      c.i.a.c c1 = this.e.V;
      if (c1 instanceof e2)
        c1.b(null); 
    }
  }
  
  public class d implements View.OnFocusChangeListener {
    public d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.a;
      View.OnFocusChangeListener onFocusChangeListener = searchView.Q;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  public class e implements View.OnLayoutChangeListener {
    public e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      SearchView searchView = this.a;
      if (searchView.B.getWidth() > 1) {
        Resources resources = searchView.getContext().getResources();
        param1Int3 = searchView.v.getPaddingLeft();
        Rect rect = new Rect();
        boolean bool = t2.b((View)searchView);
        if (searchView.T) {
          param1Int1 = resources.getDimensionPixelSize(2131100449);
          param1Int1 = resources.getDimensionPixelSize(2131100450) + param1Int1;
        } else {
          param1Int1 = 0;
        } 
        searchView.t.getDropDownBackground().getPadding(rect);
        if (bool) {
          param1Int2 = -rect.left;
        } else {
          param1Int2 = param1Int3 - rect.left + param1Int1;
        } 
        searchView.t.setDropDownHorizontalOffset(param1Int2);
        param1Int2 = searchView.B.getWidth();
        param1Int4 = rect.left;
        param1Int5 = rect.right;
        searchView.t.setDropDownWidth(param1Int2 + param1Int4 + param1Int5 + param1Int1 - param1Int3);
      } 
    }
  }
  
  public class f implements View.OnClickListener {
    public f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.e;
      if (param1View == searchView.x) {
        searchView.y();
        return;
      } 
      if (param1View == searchView.z) {
        searchView.u();
        return;
      } 
      if (param1View == searchView.y) {
        searchView.z();
        return;
      } 
      if (param1View == searchView.A) {
        SearchableInfo searchableInfo = searchView.j0;
        if (searchableInfo == null)
          return; 
        try {
          String str;
          if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
            Intent intent = new Intent(searchView.L);
            ComponentName componentName = searchableInfo.getSearchActivity();
            if (componentName == null) {
              componentName = null;
            } else {
              str = componentName.flattenToShortString();
            } 
            intent.putExtra("calling_package", str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          if (str.getVoiceSearchLaunchRecognizer()) {
            Intent intent = searchView.r(searchView.M, (SearchableInfo)str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          Log.w("SearchView", "Could not find voice search activity");
          return;
        } 
      } 
      if (activityNotFoundException == searchView.t)
        searchView.s(); 
    }
  }
  
  public class g implements View.OnKeyListener {
    public g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      boolean bool;
      SearchView searchView = this.e;
      if (searchView.j0 == null)
        return false; 
      if (searchView.t.isPopupShowing() && this.e.t.getListSelection() != -1)
        return this.e.A(param1Int, param1KeyEvent); 
      if (TextUtils.getTrimmedLength((CharSequence)this.e.t.getText()) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        param1View.cancelLongPress();
        SearchView searchView1 = this.e;
        searchView1.t(0, null, searchView1.t.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  public class h implements TextView.OnEditorActionListener {
    public h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.a.z();
      return true;
    }
  }
  
  public class i implements AdapterView.OnItemClickListener {
    public i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.e.v(param1Int);
    }
  }
  
  public class j implements AdapterView.OnItemSelectedListener {
    public j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.e.w(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public static interface k {
    boolean a();
  }
  
  public static interface l {
    boolean a(String param1String);
    
    boolean b(String param1String);
  }
  
  public static interface m {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  public static class n {
    public Method a = null;
    
    public Method b = null;
    
    public Method c = null;
    
    public n() {
      a();
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a = method;
        method.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b = method;
        method.setAccessible(true);
        try {
          method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException) {}
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException1) {}
      } 
    }
    
    public static void a() {
      if (Build.VERSION.SDK_INT < 29)
        return; 
      throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
    }
  }
  
  public static class o extends c.j.a.c {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new c2();
    
    public boolean g;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.g = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    public o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.g);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable(this.e, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.g));
    }
  }
  
  public static class p extends TouchDelegate {
    public final View a;
    
    public final Rect b;
    
    public final Rect c;
    
    public final Rect d;
    
    public final int e;
    
    public boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getX : ()F
      //   4: f2i
      //   5: istore_3
      //   6: aload_1
      //   7: invokevirtual getY : ()F
      //   10: f2i
      //   11: istore #4
      //   13: aload_1
      //   14: invokevirtual getAction : ()I
      //   17: istore_2
      //   18: iconst_1
      //   19: istore #5
      //   21: iconst_0
      //   22: istore #7
      //   24: iload_2
      //   25: ifeq -> 106
      //   28: iload_2
      //   29: iconst_1
      //   30: if_icmpeq -> 60
      //   33: iload_2
      //   34: iconst_2
      //   35: if_icmpeq -> 60
      //   38: iload_2
      //   39: iconst_3
      //   40: if_icmpeq -> 46
      //   43: goto -> 129
      //   46: aload_0
      //   47: getfield f : Z
      //   50: istore #5
      //   52: aload_0
      //   53: iconst_0
      //   54: putfield f : Z
      //   57: goto -> 101
      //   60: aload_0
      //   61: getfield f : Z
      //   64: istore #6
      //   66: iload #6
      //   68: istore #5
      //   70: iload #6
      //   72: ifeq -> 101
      //   75: iload #6
      //   77: istore #5
      //   79: aload_0
      //   80: getfield d : Landroid/graphics/Rect;
      //   83: iload_3
      //   84: iload #4
      //   86: invokevirtual contains : (II)Z
      //   89: ifne -> 101
      //   92: iload #6
      //   94: istore #5
      //   96: iconst_0
      //   97: istore_2
      //   98: goto -> 134
      //   101: iconst_1
      //   102: istore_2
      //   103: goto -> 134
      //   106: aload_0
      //   107: getfield b : Landroid/graphics/Rect;
      //   110: iload_3
      //   111: iload #4
      //   113: invokevirtual contains : (II)Z
      //   116: ifeq -> 129
      //   119: aload_0
      //   120: iconst_1
      //   121: putfield f : Z
      //   124: iconst_1
      //   125: istore_2
      //   126: goto -> 134
      //   129: iconst_1
      //   130: istore_2
      //   131: iconst_0
      //   132: istore #5
      //   134: iload #7
      //   136: istore #6
      //   138: iload #5
      //   140: ifeq -> 224
      //   143: iload_2
      //   144: ifeq -> 187
      //   147: aload_0
      //   148: getfield c : Landroid/graphics/Rect;
      //   151: iload_3
      //   152: iload #4
      //   154: invokevirtual contains : (II)Z
      //   157: ifne -> 187
      //   160: aload_1
      //   161: aload_0
      //   162: getfield a : Landroid/view/View;
      //   165: invokevirtual getWidth : ()I
      //   168: iconst_2
      //   169: idiv
      //   170: i2f
      //   171: aload_0
      //   172: getfield a : Landroid/view/View;
      //   175: invokevirtual getHeight : ()I
      //   178: iconst_2
      //   179: idiv
      //   180: i2f
      //   181: invokevirtual setLocation : (FF)V
      //   184: goto -> 214
      //   187: aload_0
      //   188: getfield c : Landroid/graphics/Rect;
      //   191: astore #8
      //   193: aload_1
      //   194: iload_3
      //   195: aload #8
      //   197: getfield left : I
      //   200: isub
      //   201: i2f
      //   202: iload #4
      //   204: aload #8
      //   206: getfield top : I
      //   209: isub
      //   210: i2f
      //   211: invokevirtual setLocation : (FF)V
      //   214: aload_0
      //   215: getfield a : Landroid/view/View;
      //   218: aload_1
      //   219: invokevirtual dispatchTouchEvent : (Landroid/view/MotionEvent;)Z
      //   222: istore #6
      //   224: iload #6
      //   226: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */