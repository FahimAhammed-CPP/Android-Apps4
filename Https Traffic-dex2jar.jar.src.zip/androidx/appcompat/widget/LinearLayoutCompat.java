package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import c.b.b;
import c.b.h.t2;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class LinearLayoutCompat extends ViewGroup {
  public boolean e;
  
  public int f;
  
  public int g;
  
  public int h;
  
  public int i;
  
  public int j;
  
  public float k;
  
  public boolean l;
  
  public int[] m;
  
  public int[] n;
  
  public Drawable o;
  
  public int p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield e : Z
    //   12: aload_0
    //   13: iconst_m1
    //   14: putfield f : I
    //   17: aload_0
    //   18: iconst_0
    //   19: putfield g : I
    //   22: aload_0
    //   23: ldc 8388659
    //   25: putfield i : I
    //   28: getstatic c/b/b.n : [I
    //   31: astore #6
    //   33: aload_1
    //   34: aload_2
    //   35: aload #6
    //   37: iload_3
    //   38: iconst_0
    //   39: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   42: astore #5
    //   44: aload_0
    //   45: aload_1
    //   46: aload #6
    //   48: aload_2
    //   49: aload #5
    //   51: iload_3
    //   52: iconst_0
    //   53: invokestatic m : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   56: aload #5
    //   58: iconst_1
    //   59: iconst_m1
    //   60: invokevirtual getInt : (II)I
    //   63: istore_3
    //   64: iload_3
    //   65: iflt -> 73
    //   68: aload_0
    //   69: iload_3
    //   70: invokevirtual setOrientation : (I)V
    //   73: aload #5
    //   75: iconst_0
    //   76: iconst_m1
    //   77: invokevirtual getInt : (II)I
    //   80: istore_3
    //   81: iload_3
    //   82: iflt -> 90
    //   85: aload_0
    //   86: iload_3
    //   87: invokevirtual setGravity : (I)V
    //   90: aload #5
    //   92: iconst_2
    //   93: iconst_1
    //   94: invokevirtual getBoolean : (IZ)Z
    //   97: istore #4
    //   99: iload #4
    //   101: ifne -> 110
    //   104: aload_0
    //   105: iload #4
    //   107: invokevirtual setBaselineAligned : (Z)V
    //   110: aload_0
    //   111: aload #5
    //   113: iconst_4
    //   114: ldc -1.0
    //   116: invokevirtual getFloat : (IF)F
    //   119: putfield k : F
    //   122: aload_0
    //   123: aload #5
    //   125: iconst_3
    //   126: iconst_m1
    //   127: invokevirtual getInt : (II)I
    //   130: putfield f : I
    //   133: aload_0
    //   134: aload #5
    //   136: bipush #7
    //   138: iconst_0
    //   139: invokevirtual getBoolean : (IZ)Z
    //   142: putfield l : Z
    //   145: aload #5
    //   147: iconst_5
    //   148: invokevirtual hasValue : (I)Z
    //   151: ifeq -> 175
    //   154: aload #5
    //   156: iconst_5
    //   157: iconst_0
    //   158: invokevirtual getResourceId : (II)I
    //   161: istore_3
    //   162: iload_3
    //   163: ifeq -> 175
    //   166: aload_1
    //   167: iload_3
    //   168: invokestatic a : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   171: astore_1
    //   172: goto -> 182
    //   175: aload #5
    //   177: iconst_5
    //   178: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   181: astore_1
    //   182: aload_0
    //   183: aload_1
    //   184: invokevirtual setDividerDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   187: aload_0
    //   188: aload #5
    //   190: bipush #8
    //   192: iconst_0
    //   193: invokevirtual getInt : (II)I
    //   196: putfield r : I
    //   199: aload_0
    //   200: aload #5
    //   202: bipush #6
    //   204: iconst_0
    //   205: invokevirtual getDimensionPixelSize : (II)I
    //   208: putfield s : I
    //   211: aload #5
    //   213: invokevirtual recycle : ()V
    //   216: return
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void e(Canvas paramCanvas, int paramInt) {
    this.o.setBounds(getPaddingLeft() + this.s, paramInt, getWidth() - getPaddingRight() - this.s, this.q + paramInt);
    this.o.draw(paramCanvas);
  }
  
  public void g(Canvas paramCanvas, int paramInt) {
    this.o.setBounds(paramInt, getPaddingTop() + this.s, this.p + paramInt, getHeight() - getPaddingBottom() - this.s);
    this.o.draw(paramCanvas);
  }
  
  public int getBaseline() {
    if (this.f < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.f;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.f == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.g;
      i = j;
      if (this.h == 1) {
        int m = this.i & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.j;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.j) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.f;
  }
  
  public Drawable getDividerDrawable() {
    return this.o;
  }
  
  public int getDividerPadding() {
    return this.s;
  }
  
  public int getDividerWidth() {
    return this.p;
  }
  
  public int getGravity() {
    return this.i;
  }
  
  public int getOrientation() {
    return this.h;
  }
  
  public int getShowDividers() {
    return this.r;
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.k;
  }
  
  public a h() {
    int i = this.h;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a i(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  public a j(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  public int k() {
    return 0;
  }
  
  public int l() {
    return 0;
  }
  
  public int m() {
    return 0;
  }
  
  public boolean n(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.r & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.r & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.r & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public void o(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.o == null)
      return; 
    int k = this.h;
    int j = 0;
    int i = 0;
    if (k == 1) {
      j = getVirtualChildCount();
      while (i < j) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && n(i)) {
          a a = (a)view.getLayoutParams();
          e(paramCanvas, view.getTop() - a.topMargin - this.q);
        } 
        i++;
      } 
      if (n(j)) {
        View view = getChildAt(j - 1);
        if (view == null) {
          i = getHeight() - getPaddingBottom() - this.q;
        } else {
          a a = (a)view.getLayoutParams();
          i = view.getBottom() + a.bottomMargin;
        } 
        e(paramCanvas, i);
        return;
      } 
    } else {
      k = getVirtualChildCount();
      boolean bool = t2.b((View)this);
      for (i = j; i < k; i++) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && n(i)) {
          a a = (a)view.getLayoutParams();
          if (bool) {
            j = view.getRight() + a.rightMargin;
          } else {
            j = view.getLeft() - a.leftMargin - this.p;
          } 
          g(paramCanvas, j);
        } 
      } 
      if (n(k)) {
        View view = getChildAt(k - 1);
        if (view == null) {
          if (bool) {
            i = getPaddingLeft();
          } else {
            i = getWidth() - getPaddingRight();
            j = this.p;
            i -= j;
          } 
        } else {
          a a = (a)view.getLayoutParams();
          if (bool) {
            i = view.getLeft() - a.leftMargin;
            j = this.p;
          } else {
            i = view.getRight() + a.rightMargin;
            g(paramCanvas, i);
          } 
          i -= j;
        } 
      } else {
        return;
      } 
      g(paramCanvas, i);
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.h == 1) {
      int i = getPaddingLeft();
      int j = paramInt3 - paramInt1;
      int k = getPaddingRight();
      int m = getPaddingRight();
      int n = getVirtualChildCount();
      int i1 = this.i;
      paramInt1 = i1 & 0x70;
      if (paramInt1 != 16) {
        if (paramInt1 != 80) {
          paramInt2 = getPaddingTop();
        } else {
          paramInt2 = getPaddingTop() + paramInt4 - paramInt2 - this.j;
        } 
      } else {
        paramInt2 = getPaddingTop() + (paramInt4 - paramInt2 - this.j) / 2;
      } 
      paramInt1 = 0;
      while (paramInt1 < n) {
        View view = getChildAt(paramInt1);
        if (view == null) {
          paramInt2 = p() + paramInt2;
        } else {
          paramInt3 = paramInt2;
          paramInt4 = paramInt1;
          if (view.getVisibility() != 8) {
            int i3 = view.getMeasuredWidth();
            int i2 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            paramInt4 = a.b;
            paramInt3 = paramInt4;
            if (paramInt4 < 0)
              paramInt3 = 0x800007 & i1; 
            AtomicInteger atomicInteger = u.a;
            paramInt3 = Gravity.getAbsoluteGravity(paramInt3, getLayoutDirection()) & 0x7;
            if (paramInt3 != 1) {
              if (paramInt3 != 5) {
                paramInt3 = a.leftMargin + i;
              } else {
                paramInt3 = j - k - i3;
                paramInt4 = a.rightMargin;
                paramInt3 -= paramInt4;
              } 
            } else {
              paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
            paramInt4 = paramInt2;
            if (n(paramInt1))
              paramInt4 = paramInt2 + this.q; 
            paramInt2 = paramInt4 + a.topMargin;
            paramInt4 = l() + paramInt2;
            view.layout(paramInt3, paramInt4, i3 + paramInt3, i2 + paramInt4);
            paramInt3 = a.bottomMargin;
            paramInt2 = m() + i2 + paramInt3 + paramInt2;
            paramInt1 = k() + paramInt1;
          } else {
            continue;
          } 
        } 
        paramInt4 = paramInt1;
        paramInt3 = paramInt2;
        continue;
        paramInt1 = paramInt4 + 1;
        paramInt2 = paramInt3;
      } 
    } else {
      byte b1;
      byte b2;
      boolean bool = t2.b((View)this);
      int j = getPaddingTop();
      int k = paramInt4 - paramInt2;
      int m = getPaddingBottom();
      int n = getPaddingBottom();
      int i = getVirtualChildCount();
      paramInt2 = this.i;
      paramInt4 = paramInt2 & 0x70;
      paramBoolean = this.e;
      int[] arrayOfInt1 = this.m;
      int[] arrayOfInt2 = this.n;
      AtomicInteger atomicInteger = u.a;
      paramInt2 = Gravity.getAbsoluteGravity(0x800007 & paramInt2, getLayoutDirection());
      if (paramInt2 != 1) {
        if (paramInt2 != 5) {
          paramInt3 = getPaddingLeft();
        } else {
          paramInt3 = getPaddingLeft() + paramInt3 - paramInt1 - this.j;
        } 
      } else {
        paramInt3 = getPaddingLeft() + (paramInt3 - paramInt1 - this.j) / 2;
      } 
      if (bool) {
        b2 = i - 1;
        paramInt2 = 0;
        b1 = -1;
      } else {
        b1 = 1;
        paramInt2 = 0;
        b2 = 0;
      } 
      while (paramInt2 < i) {
        int i1 = b1 * paramInt2 + b2;
        View view = getChildAt(i1);
        if (view == null) {
          paramInt1 = p() + paramInt3;
        } else {
          paramInt1 = paramInt3;
          if (view.getVisibility() != 8) {
            int i4 = view.getMeasuredWidth();
            int i5 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            if (paramBoolean && a.height != -1) {
              i2 = view.getBaseline();
            } else {
              i2 = -1;
            } 
            int i3 = a.b;
            paramInt1 = i3;
            if (i3 < 0)
              paramInt1 = paramInt4; 
            paramInt1 &= 0x70;
            if (paramInt1 != 16) {
              if (paramInt1 != 48) {
                if (paramInt1 != 80) {
                  paramInt1 = j;
                } else {
                  i3 = k - m - i5 - a.bottomMargin;
                  paramInt1 = i3;
                  if (i2 != -1) {
                    paramInt1 = view.getMeasuredHeight();
                    paramInt1 = i3 - arrayOfInt2[2] - paramInt1 - i2;
                  } 
                } 
              } else {
                i3 = a.topMargin + j;
                paramInt1 = i3;
                if (i2 != -1)
                  paramInt1 = arrayOfInt1[1] - i2 + i3; 
              } 
            } else {
              paramInt1 = (k - j - n - i5) / 2 + j + a.topMargin - a.bottomMargin;
            } 
            int i2 = paramInt3;
            if (n(i1))
              i2 = paramInt3 + this.p; 
            paramInt3 = i2 + a.leftMargin;
            i2 = l() + paramInt3;
            view.layout(i2, paramInt1, i4 + i2, i5 + paramInt1);
            paramInt1 = a.rightMargin;
            paramInt3 += m() + i4 + paramInt1;
            paramInt2 = k() + paramInt2;
            continue;
          } 
        } 
        paramInt3 = paramInt1;
        continue;
        paramInt2++;
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int j = this.h;
    int i = 1;
    if (j == 1) {
      this.j = 0;
      int i9 = getVirtualChildCount();
      j = View.MeasureSpec.getMode(paramInt1);
      int i4 = View.MeasureSpec.getMode(paramInt2);
      int i5 = this.f;
      boolean bool = this.l;
      int i7 = 0;
      int i3 = i7;
      int m = i3;
      int n = m;
      int i1 = n;
      int i8 = i1;
      int i6 = i8;
      int i2 = i6;
      int k = 1;
      float f = 0.0F;
      while (true) {
        int i12;
        int i13;
        if (i7 < i9) {
          View view = getChildAt(i7);
          if (view == null) {
            int i14 = this.j;
            this.j = p() + i14;
          } else if (view.getVisibility() == 8) {
            i7 += k();
          } else {
            int i14;
            int i15;
            if (n(i7))
              this.j += this.q; 
            a a = (a)view.getLayoutParams();
            float f1 = a.a;
            f += f1;
            if (i4 == 1073741824 && a.height == 0 && f1 > 0.0F) {
              i = this.j;
              this.j = Math.max(i, a.topMargin + i + a.bottomMargin);
              i = 1;
            } else {
              if (a.height == 0 && f1 > 0.0F) {
                a.height = -2;
                i = 0;
              } else {
                i = Integer.MIN_VALUE;
              } 
              if (f == 0.0F) {
                i14 = this.j;
              } else {
                i14 = 0;
              } 
              a a1 = a;
              o(view, paramInt1, 0, paramInt2, i14);
              if (i != Integer.MIN_VALUE)
                a1.height = i; 
              i = view.getMeasuredHeight();
              i14 = this.j;
              i15 = a1.topMargin;
              int i16 = a1.bottomMargin;
              this.j = Math.max(i14, m() + i14 + i + i15 + i16);
              if (bool)
                m = Math.max(i, m); 
              i = i8;
            } 
            boolean bool1 = true;
            i8 = i5;
            if (i8 >= 0 && i8 == i7 + 1)
              this.g = this.j; 
            if (i7 >= i8 || a.a <= 0.0F) {
              i8 = j;
              if (i8 != 1073741824 && a.width == -1) {
                i14 = 1;
                i2 = i14;
              } else {
                i14 = 0;
              } 
              i15 = a.leftMargin + a.rightMargin;
              int i16 = view.getMeasuredWidth() + i15;
              i1 = Math.max(i1, i16);
              i6 = View.combineMeasuredStates(i6, view.getMeasuredState());
              if (k && a.width == -1) {
                j = 1;
              } else {
                j = 0;
              } 
              if (a.a > 0.0F) {
                if (!i14)
                  i15 = i16; 
                k = Math.max(i3, i15);
              } else {
                if (!i14)
                  i15 = i16; 
                n = Math.max(n, i15);
                k = i3;
              } 
              i7 += k();
              i15 = i;
              i = bool1;
              i14 = j;
              i3 = k;
              j = i1;
              i1 = i8;
            } else {
              throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
            } 
            i7++;
            k = i1;
            i1 = j;
            j = k;
            i8 = i15;
            k = i14;
          } 
          i12 = i1;
          i1 = j;
          j = i12;
          i13 = i8;
          i12 = k;
        } else {
          break;
        } 
        i7++;
        k = i1;
        i1 = j;
        j = k;
        i8 = i13;
        k = i12;
      } 
      int i10 = n;
      if (this.j > 0 && n(i9))
        this.j += this.q; 
      i5 = i4;
      if (bool && (i5 == Integer.MIN_VALUE || i5 == 0)) {
        this.j = 0;
        for (n = 0; n < i9; n++) {
          View view = getChildAt(n);
          if (view == null) {
            i4 = this.j;
            this.j = p() + i4;
          } else if (view.getVisibility() == 8) {
            n += k();
          } else {
            a a = (a)view.getLayoutParams();
            i4 = this.j;
            i7 = a.topMargin;
            int i12 = a.bottomMargin;
            this.j = Math.max(i4, m() + i4 + m + i7 + i12);
          } 
        } 
      } 
      n = this.j;
      i4 = getPaddingTop();
      n = getPaddingBottom() + i4 + n;
      this.j = n;
      int i11 = View.resolveSizeAndState(Math.max(n, getSuggestedMinimumHeight()), paramInt2, 0);
      i4 = (0xFFFFFF & i11) - this.j;
      if (i8 != 0 || (i4 != 0 && f > 0.0F)) {
        float f1 = this.k;
        if (f1 > 0.0F)
          f = f1; 
        this.j = 0;
        i7 = 0;
        m = k;
        k = i6;
        i6 = i5;
        n = i10;
        while (i7 < i9) {
          View view = getChildAt(i7);
          if (view.getVisibility() != 8) {
            a a = (a)view.getLayoutParams();
            float f2 = a.a;
            i5 = i4;
            i3 = k;
            f1 = f;
            if (f2 > 0.0F) {
              i5 = (int)(i4 * f2 / f);
              f1 = f - f2;
              i3 = getPaddingLeft();
              i10 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i3 + a.leftMargin + a.rightMargin, a.width);
              if (a.height != 0 || i6 != 1073741824) {
                i8 = view.getMeasuredHeight() + i5;
                i3 = i8;
                if (i8 < 0)
                  i3 = 0; 
                view.measure(i10, View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
              } else {
                if (i5 > 0) {
                  i3 = i5;
                } else {
                  i3 = 0;
                } 
                view.measure(i10, View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
              } 
              i3 = View.combineMeasuredStates(k, view.getMeasuredState() & 0xFFFFFF00);
              i5 = i4 - i5;
            } 
            i4 = a.leftMargin + a.rightMargin;
            i8 = view.getMeasuredWidth() + i4;
            i1 = Math.max(i1, i8);
            if (j != 1073741824 && a.width == -1) {
              k = i;
            } else {
              k = 0;
            } 
            if (k != 0) {
              k = i4;
            } else {
              k = i8;
            } 
            n = Math.max(n, k);
            if (m != 0 && a.width == -1) {
              k = i;
            } else {
              k = 0;
            } 
            m = this.j;
            i4 = view.getMeasuredHeight();
            i8 = a.topMargin;
            i10 = a.bottomMargin;
            this.j = Math.max(m, m() + i4 + m + i8 + i10);
            i4 = i5;
            m = k;
            f = f1;
            k = i3;
          } 
          i7++;
        } 
        i = this.j;
        i3 = getPaddingTop();
        this.j = getPaddingBottom() + i3 + i;
        i = i1;
        i3 = k;
        i4 = m;
      } else {
        i7 = Math.max(i10, i3);
        n = i7;
        i = i1;
        i3 = i6;
        i4 = k;
        if (bool) {
          n = i7;
          i = i1;
          i3 = i6;
          i4 = k;
          if (i5 != 1073741824) {
            i5 = 0;
            while (true) {
              n = i7;
              i = i1;
              i3 = i6;
              i4 = k;
              if (i5 < i9) {
                View view = getChildAt(i5);
                if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).a > 0.0F)
                  view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(m, 1073741824)); 
                i5++;
                continue;
              } 
              break;
            } 
          } 
        } 
      } 
      if (i4 != 0 || j == 1073741824)
        n = i; 
      i = getPaddingLeft();
      setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + i + n, getSuggestedMinimumWidth()), paramInt1, i3), i11);
      if (i2 != 0) {
        i = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (paramInt1 = 0; paramInt1 < i9; paramInt1++) {
          View view = getChildAt(paramInt1);
          if (view.getVisibility() != 8) {
            a a = (a)view.getLayoutParams();
            if (a.width == -1) {
              j = a.height;
              a.height = view.getMeasuredHeight();
              measureChildWithMargins(view, i, 0, paramInt2, 0);
              a.height = j;
            } 
          } 
        } 
      } 
    } else {
      boolean bool2;
      this.j = 0;
      int i5 = getVirtualChildCount();
      int i8 = View.MeasureSpec.getMode(paramInt1);
      int i7 = View.MeasureSpec.getMode(paramInt2);
      if (this.m == null || this.n == null) {
        this.m = new int[4];
        this.n = new int[4];
      } 
      int[] arrayOfInt1 = this.m;
      int[] arrayOfInt2 = this.n;
      arrayOfInt1[3] = -1;
      arrayOfInt1[2] = -1;
      arrayOfInt1[1] = -1;
      arrayOfInt1[0] = -1;
      arrayOfInt2[3] = -1;
      arrayOfInt2[2] = -1;
      arrayOfInt2[1] = -1;
      arrayOfInt2[0] = -1;
      boolean bool3 = this.e;
      boolean bool4 = this.l;
      if (i8 == 1073741824) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      int k = 1;
      int n = 0;
      float f = 0.0F;
      i = 0;
      j = 0;
      int m = 0;
      int i3 = 0;
      int i1 = 0;
      int i2 = 0;
      boolean bool1 = false;
      while (true) {
        int i9;
        if (j < i5) {
          View view = getChildAt(j);
          if (view == null) {
            i9 = this.j;
            this.j = p() + i9;
            i9 = k;
          } else if (view.getVisibility() == 8) {
            j += k();
            i9 = k;
          } else {
            if (n(j))
              this.j += this.p; 
            a a = (a)view.getLayoutParams();
            float f1 = a.a;
            f += f1;
            if (i8 == 1073741824 && a.width == 0 && f1 > 0.0F) {
              if (bool2) {
                i9 = this.j;
                this.j = a.leftMargin + a.rightMargin + i9;
              } else {
                i9 = this.j;
                this.j = Math.max(i9, a.leftMargin + i9 + a.rightMargin);
              } 
              if (bool3) {
                i9 = View.MeasureSpec.makeMeasureSpec(0, 0);
                view.measure(i9, i9);
                i9 = j;
                j = m;
              } else {
                i9 = j;
                j = 1;
                i2 = i;
                int i11 = n;
              } 
            } else {
              if (a.width == 0 && f1 > 0.0F) {
                a.width = -2;
                i9 = 0;
              } else {
                i9 = Integer.MIN_VALUE;
              } 
              if (f == 0.0F) {
                i12 = this.j;
              } else {
                i12 = 0;
              } 
              int i11 = j;
              o(view, paramInt1, i12, paramInt2, 0);
              if (i9 != Integer.MIN_VALUE)
                a.width = i9; 
              a a1 = a;
              int i12 = view.getMeasuredWidth();
              if (bool2) {
                j = this.j;
                i9 = a1.leftMargin;
                int i13 = a1.rightMargin;
                this.j = m() + i9 + i12 + i13 + j;
              } else {
                j = this.j;
                i9 = a1.leftMargin;
                int i13 = a1.rightMargin;
                this.j = Math.max(j, m() + j + i12 + i9 + i13);
              } 
              j = m;
              i9 = i11;
              if (bool4) {
                j = Math.max(i12, m);
                i9 = i11;
              } 
            } 
            m = j;
            j = i2;
            i2 = i;
            int i10 = n;
          } 
        } else {
          break;
        } 
        j++;
        k = i9;
      } 
      j = i;
      if (this.j > 0 && n(i5))
        this.j += this.p; 
      if (arrayOfInt1[1] != -1 || arrayOfInt1[0] != -1 || arrayOfInt1[2] != -1 || arrayOfInt1[3] != -1) {
        i = Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2])));
        i1 = Math.max(i1, Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))) + i);
      } 
      if (bool4 && (i8 == Integer.MIN_VALUE || i8 == 0)) {
        this.j = 0;
        for (i = 0; i < i5; i++) {
          View view = getChildAt(i);
          if (view == null) {
            int i9 = this.j;
            this.j = p() + i9;
          } else if (view.getVisibility() == 8) {
            i += k();
          } else {
            a a = (a)view.getLayoutParams();
            if (bool2) {
              int i9 = this.j;
              int i10 = a.leftMargin;
              int i11 = a.rightMargin;
              this.j = m() + i10 + m + i11 + i9;
            } else {
              int i9 = this.j;
              int i10 = a.leftMargin;
              int i11 = a.rightMargin;
              this.j = Math.max(i9, m() + i9 + m + i10 + i11);
            } 
          } 
        } 
      } 
      i = this.j;
      int i4 = getPaddingLeft();
      i = getPaddingRight() + i4 + i;
      this.j = i;
      int i6 = View.resolveSizeAndState(Math.max(i, getSuggestedMinimumWidth()), paramInt1, 0);
      i = (0xFFFFFF & i6) - this.j;
      if (i2 != 0 || (i != 0 && f > 0.0F)) {
        float f1 = this.k;
        if (f1 > 0.0F)
          f = f1; 
        arrayOfInt1[3] = -1;
        arrayOfInt1[2] = -1;
        arrayOfInt1[1] = -1;
        arrayOfInt1[0] = -1;
        arrayOfInt2[3] = -1;
        arrayOfInt2[2] = -1;
        arrayOfInt2[1] = -1;
        arrayOfInt2[0] = -1;
        this.j = 0;
        m = i;
        i = i3;
        i1 = -1;
        i3 = 0;
        n = i5;
        while (i3 < n) {
          View view = getChildAt(i3);
          if (view == null || view.getVisibility() == 8) {
            i2 = k;
            k = m;
          } else {
            a a = (a)view.getLayoutParams();
            f1 = a.a;
            if (f1 > 0.0F) {
              i4 = (int)(m * f1 / f);
              i2 = getPaddingTop();
              int i10 = ViewGroup.getChildMeasureSpec(paramInt2, getPaddingBottom() + i2 + a.topMargin + a.bottomMargin, a.height);
              if (a.width != 0 || i8 != 1073741824) {
                i5 = view.getMeasuredWidth() + i4;
                i2 = i5;
                if (i5 < 0)
                  i2 = 0; 
                view.measure(View.MeasureSpec.makeMeasureSpec(i2, 1073741824), i10);
              } else {
                if (i4 > 0) {
                  i2 = i4;
                } else {
                  i2 = 0;
                } 
                view.measure(View.MeasureSpec.makeMeasureSpec(i2, 1073741824), i10);
              } 
              i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFF000000);
              f -= f1;
              m -= i4;
            } 
            if (bool2) {
              i2 = this.j;
              i4 = view.getMeasuredWidth();
              i5 = a.leftMargin;
              int i10 = a.rightMargin;
              this.j = m() + i4 + i5 + i10 + i2;
            } else {
              i2 = this.j;
              i4 = view.getMeasuredWidth();
              i5 = a.leftMargin;
              int i10 = a.rightMargin;
              this.j = Math.max(i2, m() + i4 + i2 + i5 + i10);
            } 
            if (i7 != 1073741824 && a.height == -1) {
              i2 = 1;
            } else {
              i2 = 0;
            } 
            int i9 = a.topMargin + a.bottomMargin;
            i5 = view.getMeasuredHeight() + i9;
            i4 = Math.max(i1, i5);
            if (i2 != 0) {
              i1 = i9;
            } else {
              i1 = i5;
            } 
            i1 = Math.max(j, i1);
            if (k != 0 && a.height == -1) {
              j = 1;
            } else {
              j = 0;
            } 
            if (bool3) {
              i9 = view.getBaseline();
              if (i9 != -1) {
                i2 = a.b;
                k = i2;
                if (i2 < 0)
                  k = this.i; 
                k = ((k & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
                arrayOfInt1[k] = Math.max(arrayOfInt1[k], i9);
                arrayOfInt2[k] = Math.max(arrayOfInt2[k], i5 - i9);
              } 
            } 
            i2 = j;
            k = m;
            j = i1;
            i1 = i4;
          } 
          i3++;
          m = k;
          k = i2;
        } 
        m = this.j;
        i2 = getPaddingLeft();
        this.j = getPaddingRight() + i2 + m;
        if (arrayOfInt1[1] != -1 || arrayOfInt1[0] != -1 || arrayOfInt1[2] != -1 || arrayOfInt1[3] != -1) {
          m = Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2])));
          i1 = Math.max(i1, Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))) + m);
        } 
      } else {
        j = Math.max(j, n);
        if (bool4 && i8 != 1073741824)
          for (i = 0; i < i5; i++) {
            View view = getChildAt(i);
            if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).a > 0.0F)
              view.measure(View.MeasureSpec.makeMeasureSpec(m, 1073741824), View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824)); 
          }  
        n = i5;
        i = i3;
      } 
      if (k != 0 || i7 == 1073741824)
        j = i1; 
      k = getPaddingTop();
      setMeasuredDimension(0xFF000000 & i | i6, View.resolveSizeAndState(Math.max(getPaddingBottom() + k + j, getSuggestedMinimumHeight()), paramInt2, i << 16));
      if (bool1) {
        i = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (paramInt2 = 0; paramInt2 < n; paramInt2++) {
          View view = getChildAt(paramInt2);
          if (view.getVisibility() != 8) {
            a a = (a)view.getLayoutParams();
            if (a.height == -1) {
              j = a.width;
              a.width = view.getMeasuredWidth();
              measureChildWithMargins(view, paramInt1, 0, i, 0);
              a.width = j;
            } 
          } 
        } 
      } 
    } 
  }
  
  public int p() {
    return 0;
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.f = paramInt;
      return;
    } 
    StringBuilder stringBuilder = d.a.a.a.a.p("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.o)
      return; 
    this.o = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.p = paramDrawable.getIntrinsicWidth();
      this.q = paramDrawable.getIntrinsicHeight();
    } else {
      this.p = 0;
      this.q = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.s = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.i != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.i = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.i;
    if ((0x800007 & i) != paramInt) {
      this.i = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.l = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.h != paramInt) {
      this.h = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.r)
      requestLayout(); 
    this.r = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.i;
    if ((i & 0x70) != paramInt) {
      this.i = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.k = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class a extends ViewGroup.MarginLayoutParams {
    public float a;
    
    public int b = -1;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 0.0F;
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, b.o);
      this.a = typedArray.getFloat(3, 0.0F);
      this.b = typedArray.getInt(0, -1);
      typedArray.recycle();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */