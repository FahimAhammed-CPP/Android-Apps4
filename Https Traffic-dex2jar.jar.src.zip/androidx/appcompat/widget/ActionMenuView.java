package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import c.b.c.p0;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.g.n.y;
import c.b.g.n.z;
import c.b.h.h;
import c.b.h.m;
import c.b.h.t2;

public class ActionMenuView extends LinearLayoutCompat implements l.b, z {
  public boolean A;
  
  public int B;
  
  public int C;
  
  public int D;
  
  public e E;
  
  public l t;
  
  public Context u;
  
  public int v;
  
  public boolean w;
  
  public m x;
  
  public y.a y;
  
  public l.a z;
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.C = (int)(56.0F * f);
    this.D = (int)(f * 4.0F);
    this.u = paramContext;
    this.v = 0;
  }
  
  public static int t(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    c c = (c)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool2 = false;
    if (actionMenuItemView != null && actionMenuItemView.g()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int k = paramView.getMeasuredWidth();
      int j = k / paramInt1;
      paramInt2 = j;
      if (k % paramInt1 != 0)
        paramInt2 = j + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    boolean bool1 = bool2;
    if (!c.c) {
      bool1 = bool2;
      if (paramInt3 != 0)
        bool1 = true; 
    } 
    c.f = bool1;
    c.d = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  public boolean a(o paramo) {
    return this.t.s((MenuItem)paramo, null, 0);
  }
  
  public void b(l paraml) {
    this.t = paraml;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof c;
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new c(getContext(), paramAttributeSet);
  }
  
  public Menu getMenu() {
    if (this.t == null) {
      Context context = getContext();
      l l1 = new l(context);
      this.t = l1;
      l1.e = new d(this);
      m m2 = new m(context);
      this.x = m2;
      m2.q = true;
      m2.r = true;
      y.a a1 = this.y;
      if (a1 == null)
        a1 = new b(); 
      m2.i = a1;
      this.t.b((y)m2, this.u);
      m m1 = this.x;
      m1.l = this;
      this.t = m1.g;
    } 
    return (Menu)this.t;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    m m1 = this.x;
    h h = m1.n;
    return (h != null) ? h.getDrawable() : (m1.p ? m1.o : null);
  }
  
  public int getPopupTheme() {
    return this.v;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public LinearLayoutCompat.a i(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    m m1 = this.x;
    if (m1 != null) {
      m1.h(false);
      if (this.x.o()) {
        this.x.g();
        this.x.p();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    m m1 = this.x;
    if (m1 != null)
      m1.b(); 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.A) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int k = getChildCount();
    int j = (paramInt4 - paramInt2) / 2;
    int n = getDividerWidth();
    int i1 = paramInt3 - paramInt1;
    paramInt1 = i1 - getPaddingRight() - getPaddingLeft();
    paramBoolean = t2.b((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < k) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        c c = (c)view.getLayoutParams();
        if (c.c) {
          int i3;
          int i2 = view.getMeasuredWidth();
          paramInt4 = i2;
          if (s(paramInt2))
            paramInt4 = i2 + n; 
          int i4 = view.getMeasuredHeight();
          if (paramBoolean) {
            i3 = getPaddingLeft() + c.leftMargin;
            i2 = i3 + paramInt4;
          } else {
            i2 = getWidth() - getPaddingRight() - c.rightMargin;
            i3 = i2 - paramInt4;
          } 
          int i5 = j - i4 / 2;
          view.layout(i3, i5, i2, i4 + i5);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + c.leftMargin + c.rightMargin;
          s(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (k == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = i1 / 2 - paramInt1 / 2;
      paramInt4 = j - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = 0;
    paramInt3 = 0;
    int i = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = paramInt3;
      while (paramInt1 < k) {
        View view = getChildAt(paramInt1);
        c c = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c.c) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= c.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            paramInt4 = view.getMeasuredHeight();
            int i2 = j - paramInt4 / 2;
            view.layout(paramInt2 - paramInt3, i2, paramInt2, paramInt4 + i2);
            paramInt3 = paramInt2 - paramInt3 + c.leftMargin + i;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = paramInt4;
      while (paramInt1 < k) {
        View view = getChildAt(paramInt1);
        c c = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c.c) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += c.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            paramInt4 = view.getMeasuredHeight();
            int i2 = j - paramInt4 / 2;
            view.layout(paramInt2, i2, paramInt2 + paramInt3, paramInt4 + i2);
            paramInt3 = d.a.a.a.a.b(paramInt3, c.rightMargin, i, paramInt2);
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Z
    //   4: istore #25
    //   6: iload_1
    //   7: invokestatic getMode : (I)I
    //   10: ldc 1073741824
    //   12: if_icmpne -> 21
    //   15: iconst_1
    //   16: istore #24
    //   18: goto -> 24
    //   21: iconst_0
    //   22: istore #24
    //   24: aload_0
    //   25: iload #24
    //   27: putfield A : Z
    //   30: iload #25
    //   32: iload #24
    //   34: if_icmpeq -> 42
    //   37: aload_0
    //   38: iconst_0
    //   39: putfield B : I
    //   42: iload_1
    //   43: invokestatic getSize : (I)I
    //   46: istore #6
    //   48: aload_0
    //   49: getfield A : Z
    //   52: ifeq -> 87
    //   55: aload_0
    //   56: getfield t : Lc/b/g/n/l;
    //   59: astore #34
    //   61: aload #34
    //   63: ifnull -> 87
    //   66: iload #6
    //   68: aload_0
    //   69: getfield B : I
    //   72: if_icmpeq -> 87
    //   75: aload_0
    //   76: iload #6
    //   78: putfield B : I
    //   81: aload #34
    //   83: iconst_1
    //   84: invokevirtual q : (Z)V
    //   87: aload_0
    //   88: invokevirtual getChildCount : ()I
    //   91: istore #7
    //   93: aload_0
    //   94: getfield A : Z
    //   97: ifeq -> 1355
    //   100: iload #7
    //   102: ifle -> 1355
    //   105: iload_2
    //   106: invokestatic getMode : (I)I
    //   109: istore #20
    //   111: iload_1
    //   112: invokestatic getSize : (I)I
    //   115: istore_1
    //   116: iload_2
    //   117: invokestatic getSize : (I)I
    //   120: istore #9
    //   122: aload_0
    //   123: invokevirtual getPaddingLeft : ()I
    //   126: istore #6
    //   128: aload_0
    //   129: invokevirtual getPaddingRight : ()I
    //   132: istore #7
    //   134: aload_0
    //   135: invokevirtual getPaddingTop : ()I
    //   138: istore #8
    //   140: aload_0
    //   141: invokevirtual getPaddingBottom : ()I
    //   144: iload #8
    //   146: iadd
    //   147: istore #15
    //   149: iload_2
    //   150: iload #15
    //   152: bipush #-2
    //   154: invokestatic getChildMeasureSpec : (III)I
    //   157: istore #21
    //   159: iload_1
    //   160: iload #7
    //   162: iload #6
    //   164: iadd
    //   165: isub
    //   166: istore #10
    //   168: aload_0
    //   169: getfield C : I
    //   172: istore_1
    //   173: iload #10
    //   175: iload_1
    //   176: idiv
    //   177: istore #14
    //   179: iload #14
    //   181: ifne -> 192
    //   184: aload_0
    //   185: iload #10
    //   187: iconst_0
    //   188: invokevirtual setMeasuredDimension : (II)V
    //   191: return
    //   192: iload #10
    //   194: iload_1
    //   195: irem
    //   196: iload #14
    //   198: idiv
    //   199: iload_1
    //   200: iadd
    //   201: istore #22
    //   203: aload_0
    //   204: invokevirtual getChildCount : ()I
    //   207: istore #23
    //   209: iconst_0
    //   210: istore #12
    //   212: iload #12
    //   214: istore #8
    //   216: iload #8
    //   218: istore_1
    //   219: iload_1
    //   220: istore_2
    //   221: iload_2
    //   222: istore #6
    //   224: iload #6
    //   226: istore #7
    //   228: lconst_0
    //   229: lstore #26
    //   231: iload #6
    //   233: istore #13
    //   235: iload_1
    //   236: istore #11
    //   238: iload #14
    //   240: istore_1
    //   241: iload #9
    //   243: istore #6
    //   245: iload #13
    //   247: iload #23
    //   249: if_icmpge -> 510
    //   252: aload_0
    //   253: iload #13
    //   255: invokevirtual getChildAt : (I)Landroid/view/View;
    //   258: astore #34
    //   260: aload #34
    //   262: invokevirtual getVisibility : ()I
    //   265: bipush #8
    //   267: if_icmpne -> 273
    //   270: goto -> 501
    //   273: aload #34
    //   275: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   278: istore #24
    //   280: iload #12
    //   282: iconst_1
    //   283: iadd
    //   284: istore #12
    //   286: iload #24
    //   288: ifeq -> 311
    //   291: aload_0
    //   292: getfield D : I
    //   295: istore #9
    //   297: aload #34
    //   299: iload #9
    //   301: iconst_0
    //   302: iload #9
    //   304: iconst_0
    //   305: invokevirtual setPadding : (IIII)V
    //   308: goto -> 311
    //   311: aload #34
    //   313: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   316: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   319: astore #35
    //   321: aload #35
    //   323: iconst_0
    //   324: putfield h : Z
    //   327: aload #35
    //   329: iconst_0
    //   330: putfield e : I
    //   333: aload #35
    //   335: iconst_0
    //   336: putfield d : I
    //   339: aload #35
    //   341: iconst_0
    //   342: putfield f : Z
    //   345: aload #35
    //   347: iconst_0
    //   348: putfield leftMargin : I
    //   351: aload #35
    //   353: iconst_0
    //   354: putfield rightMargin : I
    //   357: iload #24
    //   359: ifeq -> 379
    //   362: aload #34
    //   364: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   367: invokevirtual g : ()Z
    //   370: ifeq -> 379
    //   373: iconst_1
    //   374: istore #24
    //   376: goto -> 382
    //   379: iconst_0
    //   380: istore #24
    //   382: aload #35
    //   384: iload #24
    //   386: putfield g : Z
    //   389: aload #35
    //   391: getfield c : Z
    //   394: ifeq -> 403
    //   397: iconst_1
    //   398: istore #9
    //   400: goto -> 406
    //   403: iload_1
    //   404: istore #9
    //   406: aload #34
    //   408: iload #22
    //   410: iload #9
    //   412: iload #21
    //   414: iload #15
    //   416: invokestatic t : (Landroid/view/View;IIII)I
    //   419: istore #14
    //   421: iload #11
    //   423: iload #14
    //   425: invokestatic max : (II)I
    //   428: istore #11
    //   430: iload_2
    //   431: istore #9
    //   433: aload #35
    //   435: getfield f : Z
    //   438: ifeq -> 446
    //   441: iload_2
    //   442: iconst_1
    //   443: iadd
    //   444: istore #9
    //   446: aload #35
    //   448: getfield c : Z
    //   451: ifeq -> 457
    //   454: iconst_1
    //   455: istore #7
    //   457: iload_1
    //   458: iload #14
    //   460: isub
    //   461: istore_1
    //   462: iload #8
    //   464: aload #34
    //   466: invokevirtual getMeasuredHeight : ()I
    //   469: invokestatic max : (II)I
    //   472: istore #8
    //   474: lload #26
    //   476: lstore #28
    //   478: iload #14
    //   480: iconst_1
    //   481: if_icmpne -> 494
    //   484: lload #26
    //   486: iconst_1
    //   487: iload #13
    //   489: ishl
    //   490: i2l
    //   491: lor
    //   492: lstore #28
    //   494: lload #28
    //   496: lstore #26
    //   498: iload #9
    //   500: istore_2
    //   501: iload #13
    //   503: iconst_1
    //   504: iadd
    //   505: istore #13
    //   507: goto -> 245
    //   510: iload #7
    //   512: ifeq -> 527
    //   515: iload #12
    //   517: iconst_2
    //   518: if_icmpne -> 527
    //   521: iconst_1
    //   522: istore #9
    //   524: goto -> 530
    //   527: iconst_0
    //   528: istore #9
    //   530: iconst_0
    //   531: istore #15
    //   533: iload_2
    //   534: istore #14
    //   536: iload_1
    //   537: istore #13
    //   539: iload #15
    //   541: istore_2
    //   542: iload #8
    //   544: istore_1
    //   545: iload #14
    //   547: ifle -> 873
    //   550: iload #13
    //   552: ifle -> 873
    //   555: ldc_w 2147483647
    //   558: istore #15
    //   560: iconst_0
    //   561: istore #17
    //   563: iconst_0
    //   564: istore #16
    //   566: lconst_0
    //   567: lstore #30
    //   569: iload_2
    //   570: istore #8
    //   572: iload #17
    //   574: iload #23
    //   576: if_icmpge -> 700
    //   579: aload_0
    //   580: iload #17
    //   582: invokevirtual getChildAt : (I)Landroid/view/View;
    //   585: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   588: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   591: astore #34
    //   593: aload #34
    //   595: getfield f : Z
    //   598: ifne -> 615
    //   601: iload #15
    //   603: istore #18
    //   605: iload #16
    //   607: istore_2
    //   608: lload #30
    //   610: lstore #28
    //   612: goto -> 680
    //   615: aload #34
    //   617: getfield d : I
    //   620: istore #19
    //   622: iload #19
    //   624: iload #15
    //   626: if_icmpge -> 644
    //   629: lconst_1
    //   630: iload #17
    //   632: lshl
    //   633: lstore #28
    //   635: iload #19
    //   637: istore #18
    //   639: iconst_1
    //   640: istore_2
    //   641: goto -> 680
    //   644: iload #15
    //   646: istore #18
    //   648: iload #16
    //   650: istore_2
    //   651: lload #30
    //   653: lstore #28
    //   655: iload #19
    //   657: iload #15
    //   659: if_icmpne -> 680
    //   662: iload #16
    //   664: iconst_1
    //   665: iadd
    //   666: istore_2
    //   667: lload #30
    //   669: lconst_1
    //   670: iload #17
    //   672: lshl
    //   673: lor
    //   674: lstore #28
    //   676: iload #15
    //   678: istore #18
    //   680: iload #17
    //   682: iconst_1
    //   683: iadd
    //   684: istore #17
    //   686: iload #18
    //   688: istore #15
    //   690: iload_2
    //   691: istore #16
    //   693: lload #28
    //   695: lstore #30
    //   697: goto -> 572
    //   700: iload_1
    //   701: istore_2
    //   702: iload #8
    //   704: istore_1
    //   705: lload #26
    //   707: lload #30
    //   709: lor
    //   710: lstore #26
    //   712: iload #16
    //   714: iload #13
    //   716: if_icmple -> 722
    //   719: goto -> 881
    //   722: iconst_0
    //   723: istore_1
    //   724: iload_1
    //   725: iload #23
    //   727: if_icmpge -> 866
    //   730: aload_0
    //   731: iload_1
    //   732: invokevirtual getChildAt : (I)Landroid/view/View;
    //   735: astore #34
    //   737: aload #34
    //   739: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   742: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   745: astore #35
    //   747: iconst_1
    //   748: iload_1
    //   749: ishl
    //   750: i2l
    //   751: lstore #32
    //   753: lload #30
    //   755: lload #32
    //   757: land
    //   758: lconst_0
    //   759: lcmp
    //   760: ifne -> 793
    //   763: lload #26
    //   765: lstore #28
    //   767: aload #35
    //   769: getfield d : I
    //   772: iload #15
    //   774: iconst_1
    //   775: iadd
    //   776: if_icmpne -> 786
    //   779: lload #26
    //   781: lload #32
    //   783: lor
    //   784: lstore #28
    //   786: lload #28
    //   788: lstore #26
    //   790: goto -> 859
    //   793: iload #9
    //   795: ifeq -> 835
    //   798: aload #35
    //   800: getfield g : Z
    //   803: ifeq -> 835
    //   806: iload #13
    //   808: iconst_1
    //   809: if_icmpne -> 835
    //   812: aload_0
    //   813: getfield D : I
    //   816: istore #8
    //   818: aload #34
    //   820: iload #8
    //   822: iload #22
    //   824: iadd
    //   825: iconst_0
    //   826: iload #8
    //   828: iconst_0
    //   829: invokevirtual setPadding : (IIII)V
    //   832: goto -> 835
    //   835: aload #35
    //   837: aload #35
    //   839: getfield d : I
    //   842: iconst_1
    //   843: iadd
    //   844: putfield d : I
    //   847: aload #35
    //   849: iconst_1
    //   850: putfield h : Z
    //   853: iload #13
    //   855: iconst_1
    //   856: isub
    //   857: istore #13
    //   859: iload_1
    //   860: iconst_1
    //   861: iadd
    //   862: istore_1
    //   863: goto -> 724
    //   866: iload_2
    //   867: istore_1
    //   868: iconst_1
    //   869: istore_2
    //   870: goto -> 545
    //   873: iload_2
    //   874: istore #8
    //   876: iload_1
    //   877: istore_2
    //   878: iload #8
    //   880: istore_1
    //   881: iload #7
    //   883: ifne -> 898
    //   886: iload #12
    //   888: iconst_1
    //   889: if_icmpne -> 898
    //   892: iconst_1
    //   893: istore #8
    //   895: goto -> 901
    //   898: iconst_0
    //   899: istore #8
    //   901: iload_1
    //   902: istore #7
    //   904: iload #13
    //   906: ifle -> 1260
    //   909: iload_1
    //   910: istore #7
    //   912: lload #26
    //   914: lconst_0
    //   915: lcmp
    //   916: ifeq -> 1260
    //   919: iload #13
    //   921: iload #12
    //   923: iconst_1
    //   924: isub
    //   925: if_icmplt -> 942
    //   928: iload #8
    //   930: ifne -> 942
    //   933: iload_1
    //   934: istore #7
    //   936: iload #11
    //   938: iconst_1
    //   939: if_icmple -> 1260
    //   942: lload #26
    //   944: invokestatic bitCount : (J)I
    //   947: i2f
    //   948: fstore #5
    //   950: fload #5
    //   952: fstore #4
    //   954: iload #8
    //   956: ifne -> 1048
    //   959: fload #5
    //   961: fstore_3
    //   962: lload #26
    //   964: lconst_1
    //   965: land
    //   966: lconst_0
    //   967: lcmp
    //   968: ifeq -> 998
    //   971: fload #5
    //   973: fstore_3
    //   974: aload_0
    //   975: iconst_0
    //   976: invokevirtual getChildAt : (I)Landroid/view/View;
    //   979: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   982: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   985: getfield g : Z
    //   988: ifne -> 998
    //   991: fload #5
    //   993: ldc_w 0.5
    //   996: fsub
    //   997: fstore_3
    //   998: iload #23
    //   1000: iconst_1
    //   1001: isub
    //   1002: istore #7
    //   1004: fload_3
    //   1005: fstore #4
    //   1007: lload #26
    //   1009: iconst_1
    //   1010: iload #7
    //   1012: ishl
    //   1013: i2l
    //   1014: land
    //   1015: lconst_0
    //   1016: lcmp
    //   1017: ifeq -> 1048
    //   1020: fload_3
    //   1021: fstore #4
    //   1023: aload_0
    //   1024: iload #7
    //   1026: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1029: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1032: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1035: getfield g : Z
    //   1038: ifne -> 1048
    //   1041: fload_3
    //   1042: ldc_w 0.5
    //   1045: fsub
    //   1046: fstore #4
    //   1048: fload #4
    //   1050: fconst_0
    //   1051: fcmpl
    //   1052: ifle -> 1070
    //   1055: iload #13
    //   1057: iload #22
    //   1059: imul
    //   1060: i2f
    //   1061: fload #4
    //   1063: fdiv
    //   1064: f2i
    //   1065: istore #8
    //   1067: goto -> 1073
    //   1070: iconst_0
    //   1071: istore #8
    //   1073: iconst_0
    //   1074: istore #9
    //   1076: iload_1
    //   1077: istore #7
    //   1079: iload #9
    //   1081: iload #23
    //   1083: if_icmpge -> 1260
    //   1086: lload #26
    //   1088: iconst_1
    //   1089: iload #9
    //   1091: ishl
    //   1092: i2l
    //   1093: land
    //   1094: lconst_0
    //   1095: lcmp
    //   1096: ifne -> 1105
    //   1099: iload_1
    //   1100: istore #7
    //   1102: goto -> 1248
    //   1105: aload_0
    //   1106: iload #9
    //   1108: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1111: astore #34
    //   1113: aload #34
    //   1115: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1118: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1121: astore #35
    //   1123: aload #34
    //   1125: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   1128: ifeq -> 1173
    //   1131: aload #35
    //   1133: iload #8
    //   1135: putfield e : I
    //   1138: aload #35
    //   1140: iconst_1
    //   1141: putfield h : Z
    //   1144: iload #9
    //   1146: ifne -> 1167
    //   1149: aload #35
    //   1151: getfield g : Z
    //   1154: ifne -> 1167
    //   1157: aload #35
    //   1159: iload #8
    //   1161: ineg
    //   1162: iconst_2
    //   1163: idiv
    //   1164: putfield leftMargin : I
    //   1167: iconst_1
    //   1168: istore #7
    //   1170: goto -> 1248
    //   1173: aload #35
    //   1175: getfield c : Z
    //   1178: ifeq -> 1210
    //   1181: aload #35
    //   1183: iload #8
    //   1185: putfield e : I
    //   1188: aload #35
    //   1190: iconst_1
    //   1191: putfield h : Z
    //   1194: aload #35
    //   1196: iload #8
    //   1198: ineg
    //   1199: iconst_2
    //   1200: idiv
    //   1201: putfield rightMargin : I
    //   1204: iconst_1
    //   1205: istore #7
    //   1207: goto -> 1248
    //   1210: iload #9
    //   1212: ifeq -> 1224
    //   1215: aload #35
    //   1217: iload #8
    //   1219: iconst_2
    //   1220: idiv
    //   1221: putfield leftMargin : I
    //   1224: iload_1
    //   1225: istore #7
    //   1227: iload #9
    //   1229: iload #23
    //   1231: iconst_1
    //   1232: isub
    //   1233: if_icmpeq -> 1248
    //   1236: aload #35
    //   1238: iload #8
    //   1240: iconst_2
    //   1241: idiv
    //   1242: putfield rightMargin : I
    //   1245: iload_1
    //   1246: istore #7
    //   1248: iload #9
    //   1250: iconst_1
    //   1251: iadd
    //   1252: istore #9
    //   1254: iload #7
    //   1256: istore_1
    //   1257: goto -> 1076
    //   1260: iload #7
    //   1262: ifeq -> 1334
    //   1265: iconst_0
    //   1266: istore_1
    //   1267: iload_1
    //   1268: iload #23
    //   1270: if_icmpge -> 1334
    //   1273: aload_0
    //   1274: iload_1
    //   1275: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1278: astore #34
    //   1280: aload #34
    //   1282: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1285: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1288: astore #35
    //   1290: aload #35
    //   1292: getfield h : Z
    //   1295: ifne -> 1301
    //   1298: goto -> 1327
    //   1301: aload #34
    //   1303: aload #35
    //   1305: getfield d : I
    //   1308: iload #22
    //   1310: imul
    //   1311: aload #35
    //   1313: getfield e : I
    //   1316: iadd
    //   1317: ldc 1073741824
    //   1319: invokestatic makeMeasureSpec : (II)I
    //   1322: iload #21
    //   1324: invokevirtual measure : (II)V
    //   1327: iload_1
    //   1328: iconst_1
    //   1329: iadd
    //   1330: istore_1
    //   1331: goto -> 1267
    //   1334: iload #20
    //   1336: ldc 1073741824
    //   1338: if_icmpeq -> 1344
    //   1341: goto -> 1347
    //   1344: iload #6
    //   1346: istore_2
    //   1347: aload_0
    //   1348: iload #10
    //   1350: iload_2
    //   1351: invokevirtual setMeasuredDimension : (II)V
    //   1354: return
    //   1355: iconst_0
    //   1356: istore #6
    //   1358: iload #6
    //   1360: iload #7
    //   1362: if_icmpge -> 1400
    //   1365: aload_0
    //   1366: iload #6
    //   1368: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1371: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1374: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1377: astore #34
    //   1379: aload #34
    //   1381: iconst_0
    //   1382: putfield rightMargin : I
    //   1385: aload #34
    //   1387: iconst_0
    //   1388: putfield leftMargin : I
    //   1391: iload #6
    //   1393: iconst_1
    //   1394: iadd
    //   1395: istore #6
    //   1397: goto -> 1358
    //   1400: aload_0
    //   1401: iload_1
    //   1402: iload_2
    //   1403: invokespecial onMeasure : (II)V
    //   1406: return
  }
  
  public c q() {
    c c = new c(-2, -2);
    c.b = 16;
    return c;
  }
  
  public c r(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      c c;
      if (paramLayoutParams instanceof c) {
        c = new c((c)paramLayoutParams);
      } else {
        c = new c((ViewGroup.LayoutParams)c);
      } 
      if (c.b <= 0)
        c.b = 16; 
      return c;
    } 
    return q();
  }
  
  public boolean s(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof a)
        i = false | ((a)view1).a(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof a)
        bool = i | ((a)view2).b(); 
    } 
    return bool;
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.x.v = paramBoolean;
  }
  
  public void setOnMenuItemClickListener(e parame) {
    this.E = parame;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    m m1 = this.x;
    h h = m1.n;
    if (h != null) {
      h.setImageDrawable(paramDrawable);
      return;
    } 
    m1.p = true;
    m1.o = paramDrawable;
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.v != paramInt) {
      this.v = paramInt;
      if (paramInt == 0) {
        this.u = getContext();
        return;
      } 
      this.u = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(m paramm) {
    this.x = paramm;
    paramm.l = this;
    this.t = paramm.g;
  }
  
  public static interface a {
    boolean a();
    
    boolean b();
  }
  
  public static class b implements y.a {
    public void a(l param1l, boolean param1Boolean) {}
    
    public boolean b(l param1l) {
      return false;
    }
  }
  
  public static class c extends LinearLayoutCompat.a {
    @ExportedProperty
    public boolean c;
    
    @ExportedProperty
    public int d;
    
    @ExportedProperty
    public int e;
    
    @ExportedProperty
    public boolean f;
    
    @ExportedProperty
    public boolean g;
    
    public boolean h;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = false;
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(c param1c) {
      super((ViewGroup.LayoutParams)param1c);
      this.c = param1c.c;
    }
  }
  
  public class d implements l.a {
    public d(ActionMenuView this$0) {}
    
    public boolean a(l param1l, MenuItem param1MenuItem) {
      ActionMenuView.e e = this.e.E;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (e != null) {
        boolean bool;
        Toolbar.f f = ((Toolbar.a)e).a.K;
        if (f != null) {
          bool = ((p0)f).a.c.onMenuItemSelected(0, param1MenuItem);
        } else {
          bool = false;
        } 
        bool1 = bool2;
        if (bool)
          bool1 = true; 
      } 
      return bool1;
    }
    
    public void b(l param1l) {
      l.a a1 = this.e.z;
      if (a1 != null)
        a1.b(param1l); 
    }
  }
  
  public static interface e {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */